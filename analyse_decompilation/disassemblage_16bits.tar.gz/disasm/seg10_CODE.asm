; ================================================================
; seg10_CODE  (23971 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	0a 00                	or     al,BYTE PTR [bx+si]
       2:	c5 12                	lds    dx,DWORD PTR [bp+si]
       4:	21 03                	and    WORD PTR [bp+di],ax
       6:	b0 00                	mov    al,0x0
       8:	00 00                	add    BYTE PTR [bx+si],al
       a:	9e                   	sahf
       b:	00 32                	add    BYTE PTR [bp+si],dh
       d:	06                   	push   es
       e:	fb                   	sti
       f:	04 de                	add    al,0xde
      11:	12 39                	adc    bh,BYTE PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f f1 12 cb       	call   0xcb12:0xf11f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 9b 1f d6          	adc    BYTE PTR [bp+di-0x29e1],bl
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c a3                	sbb    al,0xa3
      61:	13 e2                	adc    sp,dx
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	11 54 46             	adc    WORD PTR [si+0x46],dx
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	46                   	inc    si
      a8:	5f                   	pop    di
      a9:	46                   	inc    si
      aa:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
      af:	65 20 00             	and    BYTE PTR gs:[bx+si],al
      b2:	16                   	push   ss
      b3:	2c c6                	sub    al,0xc6
      b5:	00 0d                	add    BYTE PTR [di],cl
      b7:	51                   	push   cx
      b8:	75 69                	jne    0x123
      ba:	74 74                	je     0x130
      bc:	65 72 31             	gs jb  0xf0
      bf:	43                   	inc    bx
      c0:	6c                   	ins    BYTE PTR es:[di],dx
      c1:	69 63 6b f7 2b       	imul   sp,WORD PTR [bp+di+0x6b],0x2bf7
      c6:	d4 00                	aam    0x0
      c8:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
      cb:	72 6d                	jb     0x13a
      cd:	43                   	inc    bx
      ce:	6c                   	ins    BYTE PTR es:[di],dx
      cf:	6f                   	outs   dx,WORD PTR ds:[si]
      d0:	73 65                	jae    0x137
      d2:	51                   	push   cx
      d3:	15 e7 00             	adc    ax,0xe7
      d6:	0e                   	push   cs
      d7:	49                   	dec    cx
      d8:	6d                   	ins    WORD PTR es:[di],dx
      d9:	70 72                	jo     0x14d
      db:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      e0:	43                   	inc    bx
      e1:	6c                   	ins    BYTE PTR es:[di],dx
      e2:	69 63 6b 2e 2c       	imul   sp,WORD PTR [bp+di+0x6b],0x2c2e
      e7:	fc                   	cld
      e8:	00 10                	add    BYTE PTR [bx+si],dl
      ea:	50                   	push   ax
      eb:	6c                   	ins    BYTE PTR es:[di],dx
      ec:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
      f2:	61                   	popa
      f3:	6e                   	outs   dx,BYTE PTR ds:[si]
      f4:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      f7:	69 63 6b 8c 45       	imul   sp,WORD PTR [bp+di+0x6b],0x458c
      fc:	0c 01                	or     al,0x1
      fe:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
     101:	64 65 78 31          	fs gs js 0x136
     105:	43                   	inc    bx
     106:	6c                   	ins    BYTE PTR es:[di],dx
     107:	69 63 6b ab 45       	imul   sp,WORD PTR [bp+di+0x6b],0x45ab
     10c:	21 01                	and    WORD PTR [bx+di],ax
     10e:	10 52 65             	adc    BYTE PTR [bp+si+0x65],dl
     111:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     114:	72 63                	jb     0x179
     116:	68 65 72             	push   0x7265
     119:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     11c:	69 63 6b cc 45       	imul   sp,WORD PTR [bp+di+0x6b],0x45cc
     121:	39 01                	cmp    WORD PTR [bx+di],ax
     123:	13 55 74             	adc    dx,WORD PTR [di+0x74]
     126:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     12b:	72 6c                	jb     0x199
     12d:	61                   	popa
     12e:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     133:	6c                   	ins    BYTE PTR es:[di],dx
     134:	69 63 6b eb 45       	imul   sp,WORD PTR [bp+di+0x6b],0x45eb
     139:	4b                   	dec    bx
     13a:	01 0d                	add    WORD PTR [di],cx
     13c:	41                   	inc    cx
     13d:	70 72                	jo     0x1b1
     13f:	6f                   	outs   dx,WORD PTR ds:[si]
     140:	70 6f                	jo     0x1b1
     142:	73 31                	jae    0x175
     144:	43                   	inc    bx
     145:	6c                   	ins    BYTE PTR es:[di],dx
     146:	69 63 6b 95 43       	imul   sp,WORD PTR [bp+di+0x6b],0x4395
     14b:	5b                   	pop    bx
     14c:	01 0b                	add    WORD PTR [bp+di],cx
     14e:	46                   	inc    si
     14f:	6f                   	outs   dx,WORD PTR ds:[si]
     150:	72 6d                	jb     0x1bf
     152:	4b                   	dec    bx
     153:	65 79 44             	gs jns 0x19a
     156:	6f                   	outs   dx,WORD PTR ds:[si]
     157:	77 6e                	ja     0x1c7
     159:	70 2f                	jo     0x18a
     15b:	6a 01                	push   0x1
     15d:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     160:	72 6d                	jb     0x1cf
     162:	52                   	push   dx
     163:	65 73 69             	gs jae 0x1cf
     166:	7a 65                	jp     0x1cd
     168:	03 28                	add    bp,WORD PTR [bx+si]
     16a:	79 01                	jns    0x16d
     16c:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     16f:	72 6d                	jb     0x1de
     171:	43                   	inc    bx
     172:	72 65                	jb     0x1d9
     174:	61                   	popa
     175:	74 65                	je     0x1dc
     177:	e0 31                	loopne 0x1aa
     179:	90                   	nop
     17a:	01 12                	add    WORD PTR [bp+si],dx
     17c:	54                   	push   sp
     17d:	61                   	popa
     17e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     181:	45                   	inc    bp
     182:	52                   	push   dx
     183:	47                   	inc    di
     184:	43                   	inc    bx
     185:	61                   	popa
     186:	6c                   	ins    BYTE PTR es:[di],dx
     187:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     18a:	65 6c                	gs ins BYTE PTR es:[di],dx
     18c:	64 73 87             	fs jae 0x116
     18f:	2d a2 01             	sub    ax,0x1a2
     192:	0d 50 65             	or     ax,0x6550
     195:	72 69                	jb     0x200
     197:	6f                   	outs   dx,WORD PTR ds:[si]
     198:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     19d:	69 63 6b cc 2e       	imul   sp,WORD PTR [bp+di+0x6b],0x2ecc
     1a2:	af                   	scas   ax,WORD PTR es:[di]
     1a3:	01 08                	add    WORD PTR [bx+si],cx
     1a5:	4e                   	dec    si
     1a6:	31 31                	xor    WORD PTR [bx+di],si
     1a8:	43                   	inc    bx
     1a9:	6c                   	ins    BYTE PTR es:[di],dx
     1aa:	69 63 6b c2 1a       	imul   sp,WORD PTR [bp+di+0x6b],0x1ac2
     1af:	c1 01 0d             	rol    WORD PTR [bx+di],0xd
     1b2:	44                   	inc    sp
     1b3:	42                   	inc    dx
     1b4:	45                   	inc    bp
     1b5:	64 69 74 31 31 31    	imul   si,WORD PTR fs:[si+0x31],0x3131
     1bb:	45                   	inc    bp
     1bc:	78 69                	js     0x227
     1be:	74 72                	je     0x232
     1c0:	1b d6                	sbb    dx,si
     1c2:	01 10                	add    WORD PTR [bx+si],dx
     1c4:	44                   	inc    sp
     1c5:	42                   	inc    dx
     1c6:	45                   	inc    bp
     1c7:	64 69 74 31 31 31    	imul   si,WORD PTR fs:[si+0x31],0x3131
     1cd:	4b                   	dec    bx
     1ce:	65 79 44             	gs jns 0x215
     1d1:	6f                   	outs   dx,WORD PTR ds:[si]
     1d2:	77 6e                	ja     0x242
     1d4:	0f 1b e9             	nop    cx
     1d7:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     1db:	45                   	inc    bp
     1dc:	64 69 74 31 31 31    	imul   si,WORD PTR fs:[si+0x31],0x3131
     1e2:	4b                   	dec    bx
     1e3:	65 79 55             	gs jns 0x23b
     1e6:	70 dc                	jo     0x1c4
     1e8:	2b f6                	sub    si,si
     1ea:	01 08                	add    WORD PTR [bx+si],cx
     1ec:	46                   	inc    si
     1ed:	6f                   	outs   dx,WORD PTR ds:[si]
     1ee:	72 6d                	jb     0x25d
     1f0:	53                   	push   bx
     1f1:	68 6f 77             	push   0x776f
     1f4:	83 46 0d 02          	add    WORD PTR [bp+0xd],0x2
     1f8:	12 44 42             	adc    al,BYTE PTR [si+0x42]
     1fb:	45                   	inc    bp
     1fc:	64 69 74 31 31 31    	imul   si,WORD PTR fs:[si+0x31],0x3131
     202:	4d                   	dec    bp
     203:	6f                   	outs   dx,WORD PTR ds:[si]
     204:	75 73                	jne    0x279
     206:	65 44                	gs inc sp
     208:	6f                   	outs   dx,WORD PTR ds:[si]
     209:	77 6e                	ja     0x279
     20b:	61                   	popa
     20c:	45                   	inc    bp
     20d:	1d 02 0b             	sbb    ax,0xb02
     210:	46                   	inc    si
     211:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     216:	43                   	inc    bx
     217:	6c                   	ins    BYTE PTR es:[di],dx
     218:	69 63 6b 8e 4c       	imul   sp,WORD PTR [bp+di+0x6b],0x4c8e
     21d:	2e 02 0c             	add    cl,BYTE PTR cs:[si]
     220:	43                   	inc    bx
     221:	6f                   	outs   dx,WORD PTR ds:[si]
     222:	70 69                	jo     0x28d
     224:	65 72 31             	gs jb  0x258
     227:	43                   	inc    bx
     228:	6c                   	ins    BYTE PTR es:[di],dx
     229:	69 63 6b 3a 47       	imul   sp,WORD PTR [bp+di+0x6b],0x473a
     22e:	44                   	inc    sp
     22f:	02 11                	add    dl,BYTE PTR [bx+di]
     231:	50                   	push   ax
     232:	61                   	popa
     233:	6e                   	outs   dx,BYTE PTR ds:[si]
     234:	65 6c                	gs ins BYTE PTR es:[di],dx
     236:	31 31                	xor    WORD PTR [bx+di],si
     238:	31 4d 6f             	xor    WORD PTR [di+0x6f],cx
     23b:	75 73                	jne    0x2b0
     23d:	65 44                	gs inc sp
     23f:	6f                   	outs   dx,WORD PTR ds:[si]
     240:	77 6e                	ja     0x2b0
     242:	6c                   	ins    BYTE PTR es:[di],dx
     243:	5c                   	pop    sp
     244:	58                   	pop    ax
     245:	02 0f                	add    cl,BYTE PTR [bx]
     247:	53                   	push   bx
     248:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     24d:	69 6f 6e 31 43       	imul   bp,WORD PTR [bx+0x6e],0x4331
     252:	6c                   	ins    BYTE PTR es:[di],dx
     253:	69 63 6b 9a 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c9a
     258:	74 02                	je     0x25c
     25a:	17                   	pop    ss
     25b:	43                   	inc    bx
     25c:	6f                   	outs   dx,WORD PTR ds:[si]
     25d:	6d                   	ins    WORD PTR es:[di],dx
     25e:	70 74                	jo     0x2d4
     260:	65 44                	gs inc sp
     262:	65 52                	gs push dx
     264:	65 73 75             	gs jae 0x2dc
     267:	6c                   	ins    BYTE PTR es:[di],dx
     268:	74 61                	je     0x2cb
     26a:	74 73                	je     0x2df
     26c:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     26f:	69 63 6b c8 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5cc8
     274:	84 02                	test   BYTE PTR [bp+si],al
     276:	0b 42 69             	or     ax,WORD PTR [bp+si+0x69]
     279:	6c                   	ins    BYTE PTR es:[di],dx
     27a:	61                   	popa
     27b:	6e                   	outs   dx,BYTE PTR ds:[si]
     27c:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     27f:	69 63 6b f6 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5cf6
     284:	a3 02 1a             	mov    ds:0x1a02,ax
     287:	54                   	push   sp
     288:	61                   	popa
     289:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     28c:	61                   	popa
     28d:	75 44                	jne    0x2d3
     28f:	65 46                	gs inc si
     291:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     296:	65 6d                	gs ins WORD PTR es:[di],dx
     298:	65 6e                	outs   dx,BYTE PTR gs:[si]
     29a:	74 31                	je     0x2cd
     29c:	43                   	inc    bx
     29d:	6c                   	ins    BYTE PTR es:[di],dx
     29e:	69 63 6b 24 5d       	imul   sp,WORD PTR [bp+di+0x6b],0x5d24
     2a3:	c1 02 19             	rol    WORD PTR [bp+si],0x19
     2a6:	54                   	push   sp
     2a7:	61                   	popa
     2a8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2ab:	61                   	popa
     2ac:	75 44                	jne    0x2f2
     2ae:	65 54                	gs push sp
     2b0:	72 65                	jb     0x317
     2b2:	73 6f                	jae    0x323
     2b4:	72 65                	jb     0x31b
     2b6:	72 69                	jb     0x321
     2b8:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2bc:	69 63 6b 80 5d       	imul   sp,WORD PTR [bp+di+0x6b],0x5d80
     2c1:	de 02                	fiadd  WORD PTR [bp+si]
     2c3:	18 52 61             	sbb    BYTE PTR [bp+si+0x61],dl
     2c6:	70 70                	jo     0x338
     2c8:	65 6c                	gs ins BYTE PTR es:[di],dx
     2ca:	44                   	inc    sp
     2cb:	65 73 44             	gs jae 0x312
     2ce:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     2d2:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     2d7:	43                   	inc    bx
     2d8:	6c                   	ins    BYTE PTR es:[di],dx
     2d9:	69 63 6b 6a 2c       	imul   sp,WORD PTR [bp+di+0x6b],0x2c6a
     2de:	ed                   	in     ax,dx
     2df:	02 0a                	add    cl,BYTE PTR [bp+si]
     2e1:	4e                   	dec    si
     2e2:	31 30                	xor    WORD PTR [bx+si],si
     2e4:	30 31                	xor    BYTE PTR [bx+di],dh
     2e6:	43                   	inc    bx
     2e7:	6c                   	ins    BYTE PTR es:[di],dx
     2e8:	69 63 6b a3 47       	imul   sp,WORD PTR [bp+di+0x6b],0x47a3
     2ed:	08 03                	or     BYTE PTR [bp+di],al
     2ef:	16                   	push   ss
     2f0:	49                   	dec    cx
     2f1:	6d                   	ins    WORD PTR es:[di],dx
     2f2:	70 72                	jo     0x366
     2f4:	65 73 73             	gs jae 0x36a
     2f7:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     2fc:	70 69                	jo     0x367
     2fe:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     303:	69 63 6b ce 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2dce
     308:	15 03 08             	adc    ax,0x803
     30b:	4e                   	dec    si
     30c:	31 32                	xor    WORD PTR [bp+si],si
     30e:	43                   	inc    bx
     30f:	6c                   	ins    BYTE PTR es:[di],dx
     310:	69 63 6b 52 5d       	imul   sp,WORD PTR [bp+di+0x6b],0x5d52
     315:	da 12                	ficom  DWORD PTR [bp+si]
     317:	09 53 49             	or     WORD PTR [bp+di+0x49],dx
     31a:	47                   	inc    di
     31b:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     31e:	69 63 6b ec 00       	imul   sp,WORD PTR [bp+di+0x6b],0xec
     323:	8b 12                	mov    dx,WORD PTR [bp+si]
     325:	7c 01                	jl     0x328
     327:	00 00                	add    BYTE PTR [bx+si],al
     329:	06                   	push   es
     32a:	50                   	push   ax
     32b:	61                   	popa
     32c:	6e                   	outs   dx,BYTE PTR ds:[si]
     32d:	65 6c                	gs ins BYTE PTR es:[di],dx
     32f:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     333:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     337:	6e                   	outs   dx,BYTE PTR ds:[si]
     338:	65 6c                	gs ins BYTE PTR es:[di],dx
     33a:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     33e:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     342:	6e                   	outs   dx,BYTE PTR ds:[si]
     343:	65 6c                	gs ins BYTE PTR es:[di],dx
     345:	35 88 01             	xor    ax,0x188
     348:	00 00                	add    BYTE PTR [bx+si],al
     34a:	06                   	push   es
     34b:	50                   	push   ax
     34c:	61                   	popa
     34d:	6e                   	outs   dx,BYTE PTR ds:[si]
     34e:	65 6c                	gs ins BYTE PTR es:[di],dx
     350:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     354:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     358:	6e                   	outs   dx,BYTE PTR ds:[si]
     359:	65 6c                	gs ins BYTE PTR es:[di],dx
     35b:	36 90                	ss nop
     35d:	01 00                	add    WORD PTR [bx+si],ax
     35f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     363:	6e                   	outs   dx,BYTE PTR ds:[si]
     364:	65 6c                	gs ins BYTE PTR es:[di],dx
     366:	37                   	aaa
     367:	94                   	xchg   sp,ax
     368:	01 00                	add    WORD PTR [bx+si],ax
     36a:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     36e:	6e                   	outs   dx,BYTE PTR ds:[si]
     36f:	65 6c                	gs ins BYTE PTR es:[di],dx
     371:	38 98 01 00          	cmp    BYTE PTR [bx+si+0x1],bl
     375:	00 07                	add    BYTE PTR [bx],al
     377:	50                   	push   ax
     378:	61                   	popa
     379:	6e                   	outs   dx,BYTE PTR ds:[si]
     37a:	65 6c                	gs ins BYTE PTR es:[di],dx
     37c:	33 37                	xor    si,WORD PTR [bx]
     37e:	9c                   	pushf
     37f:	01 00                	add    WORD PTR [bx+si],ax
     381:	00 07                	add    BYTE PTR [bx],al
     383:	50                   	push   ax
     384:	61                   	popa
     385:	6e                   	outs   dx,BYTE PTR ds:[si]
     386:	65 6c                	gs ins BYTE PTR es:[di],dx
     388:	33 38                	xor    di,WORD PTR [bx+si]
     38a:	a0 01 04             	mov    al,ds:0x401
     38d:	00 09                	add    BYTE PTR [bx+di],cl
     38f:	4d                   	dec    bp
     390:	61                   	popa
     391:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     396:	75 31                	jne    0x3c9
     398:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     399:	01 08                	add    WORD PTR [bx+si],cx
     39b:	00 08                	add    BYTE PTR [bx+si],cl
     39d:	46                   	inc    si
     39e:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     3a3:	72 31                	jb     0x3d6
     3a5:	a8 01                	test   al,0x1
     3a7:	08 00                	or     BYTE PTR [bx+si],al
     3a9:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     3ac:	70 72                	jo     0x420
     3ae:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     3b3:	ac                   	lods   al,BYTE PTR ds:[si]
     3b4:	01 08                	add    WORD PTR [bx+si],cx
     3b6:	00 02                	add    BYTE PTR [bp+si],al
     3b8:	4e                   	dec    si
     3b9:	31 b0 01 08          	xor    WORD PTR [bx+si+0x801],si
     3bd:	00 08                	add    BYTE PTR [bx+si],cl
     3bf:	51                   	push   cx
     3c0:	75 69                	jne    0x42b
     3c2:	74 74                	je     0x438
     3c4:	65 72 31             	gs jb  0x3f8
     3c7:	b4 01                	mov    ah,0x1
     3c9:	08 00                	or     BYTE PTR [bx+si],al
     3cb:	0a 41 66             	or     al,BYTE PTR [bx+di+0x66]
     3ce:	66 69 63 68 61 67 65 	imul   esp,DWORD PTR [bp+di+0x68],0x31656761
     3d5:	31 
     3d6:	b8 01 08             	mov    ax,0x801
     3d9:	00 0d                	add    BYTE PTR [di],cl
     3db:	42                   	inc    dx
     3dc:	61                   	popa
     3dd:	72 72                	jb     0x451
     3df:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     3e2:	75 74                	jne    0x458
     3e4:	69 6c 73 31 bc       	imul   bp,WORD PTR [si+0x73],0xbc31
     3e9:	01 08                	add    WORD PTR [bx+si],cx
     3eb:	00 0b                	add    BYTE PTR [bp+di],cl
     3ed:	50                   	push   ax
     3ee:	6c                   	ins    BYTE PTR es:[di],dx
     3ef:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     3f5:	61                   	popa
     3f6:	6e                   	outs   dx,BYTE PTR ds:[si]
     3f7:	31 c0                	xor    ax,ax
     3f9:	01 08                	add    WORD PTR [bx+si],cx
     3fb:	00 02                	add    BYTE PTR [bp+si],al
     3fd:	4e                   	dec    si
     3fe:	32 c4                	xor    al,ah
     400:	01 08                	add    WORD PTR [bx+si],cx
     402:	00 05                	add    BYTE PTR [di],al
     404:	5a                   	pop    dx
     405:	6f                   	outs   dx,WORD PTR ds:[si]
     406:	6f                   	outs   dx,WORD PTR ds:[si]
     407:	6d                   	ins    WORD PTR es:[di],dx
     408:	31 c8                	xor    ax,cx
     40a:	01 08                	add    WORD PTR [bx+si],cx
     40c:	00 05                	add    BYTE PTR [di],al
     40e:	41                   	inc    cx
     40f:	69 64 65 31 cc       	imul   sp,WORD PTR [si+0x65],0xcc31
     414:	01 08                	add    WORD PTR [bx+si],cx
     416:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     41a:	64 65 78 31          	fs gs js 0x44f
     41e:	d0 01                	rol    BYTE PTR [bx+di],1
     420:	08 00                	or     BYTE PTR [bx+si],al
     422:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     425:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     428:	72 63                	jb     0x48d
     42a:	68 65 72             	push   0x7265
     42d:	31 d4                	xor    sp,dx
     42f:	01 08                	add    WORD PTR [bx+si],cx
     431:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     435:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     43a:	72 6c                	jb     0x4a8
     43c:	61                   	popa
     43d:	69 64 65 31 d8       	imul   sp,WORD PTR [si+0x65],0xd831
     442:	01 08                	add    WORD PTR [bx+si],cx
     444:	00 08                	add    BYTE PTR [bx+si],cl
     446:	41                   	inc    cx
     447:	70 72                	jo     0x4bb
     449:	6f                   	outs   dx,WORD PTR ds:[si]
     44a:	70 6f                	jo     0x4bb
     44c:	73 31                	jae    0x47f
     44e:	dc 01                	fadd   QWORD PTR [bx+di]
     450:	0c 00                	or     al,0x0
     452:	08 54 61             	or     BYTE PTR [si+0x61],dl
     455:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     458:	41                   	inc    cx
     459:	44                   	inc    sp
     45a:	47                   	inc    di
     45b:	e0 01                	loopne 0x45e
     45d:	0c 00                	or     al,0x0
     45f:	0c 54                	or     al,0x54
     461:	61                   	popa
     462:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     465:	45                   	inc    bp
     466:	52                   	push   dx
     467:	47                   	inc    di
     468:	5f                   	pop    di
     469:	4f                   	dec    di
     46a:	6c                   	ins    BYTE PTR es:[di],dx
     46b:	64 e4 01             	fs in  al,0x1
     46e:	0c 00                	or     al,0x0
     470:	0d 54 61             	or     ax,0x6154
     473:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     476:	45                   	inc    bp
     477:	52                   	push   dx
     478:	50                   	push   ax
     479:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     47c:	6c                   	ins    BYTE PTR es:[di],dx
     47d:	64 e8 01 0c          	fs call 0x1082
     481:	00 0d                	add    BYTE PTR [di],cl
     483:	54                   	push   sp
     484:	61                   	popa
     485:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     488:	45                   	inc    bp
     489:	52                   	push   dx
     48a:	50                   	push   ax
     48b:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     48e:	6c                   	ins    BYTE PTR es:[di],dx
     48f:	64 ec                	fs in  al,dx
     491:	01 0c                	add    WORD PTR [si],cx
     493:	00 08                	add    BYTE PTR [bx+si],cl
     495:	54                   	push   sp
     496:	61                   	popa
     497:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     49a:	45                   	inc    bp
     49b:	44                   	inc    sp
     49c:	47                   	inc    di
     49d:	f0 01 0c             	lock add WORD PTR [si],cx
     4a0:	00 08                	add    BYTE PTR [bx+si],cl
     4a2:	54                   	push   sp
     4a3:	61                   	popa
     4a4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4a7:	45                   	inc    bp
     4a8:	52                   	push   dx
     4a9:	47                   	inc    di
     4aa:	f4                   	hlt
     4ab:	01 0c                	add    WORD PTR [si],cx
     4ad:	00 09                	add    BYTE PTR [bx+di],cl
     4af:	54                   	push   sp
     4b0:	61                   	popa
     4b1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4b4:	45                   	inc    bp
     4b5:	52                   	push   dx
     4b6:	50                   	push   ax
     4b7:	31 f8                	xor    ax,di
     4b9:	01 0c                	add    WORD PTR [si],cx
     4bb:	00 09                	add    BYTE PTR [bx+di],cl
     4bd:	54                   	push   sp
     4be:	61                   	popa
     4bf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4c2:	45                   	inc    bp
     4c3:	52                   	push   dx
     4c4:	50                   	push   ax
     4c5:	32 fc                	xor    bh,ah
     4c7:	01 10                	add    WORD PTR [bx+si],dx
     4c9:	00 0d                	add    BYTE PTR [di],cl
     4cb:	44                   	inc    sp
     4cc:	61                   	popa
     4cd:	74 61                	je     0x530
     4cf:	53                   	push   bx
     4d0:	6f                   	outs   dx,WORD PTR ds:[si]
     4d1:	75 72                	jne    0x545
     4d3:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     4d6:	52                   	push   dx
     4d7:	47                   	inc    di
     4d8:	00 02                	add    BYTE PTR [bp+si],al
     4da:	14 00                	adc    al,0x0
     4dc:	1e                   	push   ds
     4dd:	54                   	push   sp
     4de:	61                   	popa
     4df:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4e2:	45                   	inc    bp
     4e3:	52                   	push   dx
     4e4:	47                   	inc    di
     4e5:	56                   	push   si
     4e6:	61                   	popa
     4e7:	72 69                	jb     0x552
     4e9:	61                   	popa
     4ea:	74 69                	je     0x555
     4ec:	6f                   	outs   dx,WORD PTR ds:[si]
     4ed:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ee:	43                   	inc    bx
     4ef:	61                   	popa
     4f0:	70 69                	jo     0x55b
     4f2:	74 61                	je     0x555
     4f4:	6c                   	ins    BYTE PTR es:[di],dx
     4f5:	50                   	push   ax
     4f6:	72 6f                	jb     0x567
     4f8:	70 72                	jo     0x56c
     4fa:	65 04 02             	gs add al,0x2
     4fd:	14 00                	adc    al,0x0
     4ff:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     502:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     505:	45                   	inc    bp
     506:	52                   	push   dx
     507:	47                   	inc    di
     508:	56                   	push   si
     509:	61                   	popa
     50a:	72 69                	jb     0x575
     50c:	61                   	popa
     50d:	74 69                	je     0x578
     50f:	6f                   	outs   dx,WORD PTR ds:[si]
     510:	6e                   	outs   dx,BYTE PTR ds:[si]
     511:	45                   	inc    bp
     512:	6d                   	ins    WORD PTR es:[di],dx
     513:	70 72                	jo     0x587
     515:	75 6e                	jne    0x585
     517:	74 08                	je     0x521
     519:	02 14                	add    dl,BYTE PTR [si]
     51b:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     51f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     522:	45                   	inc    bp
     523:	52                   	push   dx
     524:	47                   	inc    di
     525:	49                   	dec    cx
     526:	6e                   	outs   dx,BYTE PTR ds:[si]
     527:	76 65                	jbe    0x58e
     529:	73 74                	jae    0x59f
     52b:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     530:	65 6e                	outs   dx,BYTE PTR gs:[si]
     532:	74 0c                	je     0x540
     534:	02 14                	add    dl,BYTE PTR [si]
     536:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     53a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     53d:	45                   	inc    bp
     53e:	52                   	push   dx
     53f:	47                   	inc    di
     540:	56                   	push   si
     541:	41                   	inc    cx
     542:	52                   	push   dx
     543:	46                   	inc    si
     544:	4f                   	dec    di
     545:	4e                   	dec    si
     546:	44                   	inc    sp
     547:	52                   	push   dx
     548:	4f                   	dec    di
     549:	55                   	push   bp
     54a:	4c                   	dec    sp
     54b:	4e                   	dec    si
     54c:	45                   	inc    bp
     54d:	54                   	push   sp
     54e:	10 02                	adc    BYTE PTR [bp+si],al
     550:	14 00                	adc    al,0x0
     552:	1c 54                	sbb    al,0x54
     554:	61                   	popa
     555:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     558:	45                   	inc    bp
     559:	52                   	push   dx
     55a:	47                   	inc    di
     55b:	56                   	push   si
     55c:	61                   	popa
     55d:	72 69                	jb     0x5c8
     55f:	61                   	popa
     560:	74 69                	je     0x5cb
     562:	6f                   	outs   dx,WORD PTR ds:[si]
     563:	6e                   	outs   dx,BYTE PTR ds:[si]
     564:	46                   	inc    si
     565:	6f                   	outs   dx,WORD PTR ds:[si]
     566:	75 72                	jne    0x5da
     568:	6e                   	outs   dx,BYTE PTR ds:[si]
     569:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     56e:	72 14                	jb     0x584
     570:	02 14                	add    dl,BYTE PTR [si]
     572:	00 17                	add    BYTE PTR [bx],dl
     574:	54                   	push   sp
     575:	61                   	popa
     576:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     579:	45                   	inc    bp
     57a:	52                   	push   dx
     57b:	47                   	inc    di
     57c:	56                   	push   si
     57d:	61                   	popa
     57e:	72 69                	jb     0x5e9
     580:	61                   	popa
     581:	74 69                	je     0x5ec
     583:	6f                   	outs   dx,WORD PTR ds:[si]
     584:	6e                   	outs   dx,BYTE PTR ds:[si]
     585:	43                   	inc    bx
     586:	6c                   	ins    BYTE PTR es:[di],dx
     587:	69 65 6e 74 18       	imul   sp,WORD PTR [di+0x6e],0x1874
     58c:	02 14                	add    dl,BYTE PTR [si]
     58e:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     592:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     595:	45                   	inc    bp
     596:	52                   	push   dx
     597:	47                   	inc    di
     598:	56                   	push   si
     599:	61                   	popa
     59a:	72 69                	jb     0x605
     59c:	61                   	popa
     59d:	74 69                	je     0x608
     59f:	6f                   	outs   dx,WORD PTR ds:[si]
     5a0:	6e                   	outs   dx,BYTE PTR ds:[si]
     5a1:	49                   	dec    cx
     5a2:	6d                   	ins    WORD PTR es:[di],dx
     5a3:	70 6f                	jo     0x614
     5a5:	74 1c                	je     0x5c3
     5a7:	02 14                	add    dl,BYTE PTR [si]
     5a9:	00 19                	add    BYTE PTR [bx+di],bl
     5ab:	54                   	push   sp
     5ac:	61                   	popa
     5ad:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5b0:	45                   	inc    bp
     5b1:	52                   	push   dx
     5b2:	47                   	inc    di
     5b3:	56                   	push   si
     5b4:	41                   	inc    cx
     5b5:	52                   	push   dx
     5b6:	42                   	inc    dx
     5b7:	45                   	inc    bp
     5b8:	53                   	push   bx
     5b9:	4f                   	dec    di
     5ba:	49                   	dec    cx
     5bb:	4e                   	dec    si
     5bc:	46                   	inc    si
     5bd:	4f                   	dec    di
     5be:	4e                   	dec    si
     5bf:	44                   	inc    sp
     5c0:	52                   	push   dx
     5c1:	4f                   	dec    di
     5c2:	55                   	push   bp
     5c3:	4c                   	dec    sp
     5c4:	20 02                	and    BYTE PTR [bp+si],al
     5c6:	14 00                	adc    al,0x0
     5c8:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     5cb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ce:	45                   	inc    bp
     5cf:	52                   	push   dx
     5d0:	47                   	inc    di
     5d1:	56                   	push   si
     5d2:	61                   	popa
     5d3:	72 69                	jb     0x63e
     5d5:	61                   	popa
     5d6:	74 69                	je     0x641
     5d8:	6f                   	outs   dx,WORD PTR ds:[si]
     5d9:	6e                   	outs   dx,BYTE PTR ds:[si]
     5da:	54                   	push   sp
     5db:	72 65                	jb     0x642
     5dd:	73 6f                	jae    0x64e
     5df:	72 65                	jb     0x646
     5e1:	72 69                	jb     0x64c
     5e3:	65 24 02             	gs and al,0x2
     5e6:	14 00                	adc    al,0x0
     5e8:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     5eb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ee:	45                   	inc    bp
     5ef:	52                   	push   dx
     5f0:	47                   	inc    di
     5f1:	56                   	push   si
     5f2:	61                   	popa
     5f3:	72 69                	jb     0x65e
     5f5:	61                   	popa
     5f6:	74 69                	je     0x661
     5f8:	6f                   	outs   dx,WORD PTR ds:[si]
     5f9:	6e                   	outs   dx,BYTE PTR ds:[si]
     5fa:	53                   	push   bx
     5fb:	74 6f                	je     0x66c
     5fd:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
     600:	31 28                	xor    WORD PTR [bx+si],bp
     602:	02 14                	add    dl,BYTE PTR [si]
     604:	00 18                	add    BYTE PTR [bx+si],bl
     606:	54                   	push   sp
     607:	61                   	popa
     608:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     60b:	45                   	inc    bp
     60c:	52                   	push   dx
     60d:	47                   	inc    di
     60e:	56                   	push   si
     60f:	61                   	popa
     610:	72 69                	jb     0x67b
     612:	61                   	popa
     613:	74 69                	je     0x67e
     615:	6f                   	outs   dx,WORD PTR ds:[si]
     616:	6e                   	outs   dx,BYTE PTR ds:[si]
     617:	53                   	push   bx
     618:	74 6f                	je     0x689
     61a:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
     61d:	32 2c                	xor    ch,BYTE PTR [si]
     61f:	02 08                	add    cl,BYTE PTR [bx+si]
     621:	00 08                	add    BYTE PTR [bx+si],cl
     623:	50                   	push   ax
     624:	65 72 69             	gs jb  0x690
     627:	6f                   	outs   dx,WORD PTR ds:[si]
     628:	64 65 31 30          	fs xor WORD PTR gs:[bx+si],si
     62c:	02 08                	add    cl,BYTE PTR [bx+si]
     62e:	00 0b                	add    BYTE PTR [bp+di],cl
     630:	45                   	inc    bp
     631:	6e                   	outs   dx,BYTE PTR ds:[si]
     632:	74 72                	je     0x6a6
     634:	65 70 72             	gs jo  0x6a9
     637:	69 73 65 31 34       	imul   si,WORD PTR [bp+di+0x65],0x3431
     63c:	02 18                	add    bl,BYTE PTR [bx+si]
     63e:	00 0c                	add    BYTE PTR [si],cl
     640:	50                   	push   ax
     641:	72 69                	jb     0x6ac
     643:	6e                   	outs   dx,BYTE PTR ds:[si]
     644:	74 44                	je     0x68a
     646:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     64b:	31 38                	xor    WORD PTR [bx+si],di
     64d:	02 08                	add    cl,BYTE PTR [bx+si]
     64f:	00 03                	add    BYTE PTR [bp+di],al
     651:	4e                   	dec    si
     652:	31 31                	xor    WORD PTR [bx+di],si
     654:	3c 02                	cmp    al,0x2
     656:	08 00                	or     BYTE PTR [bx+si],al
     658:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     65b:	31 40 02             	xor    WORD PTR [bx+si+0x2],ax
     65e:	08 00                	or     BYTE PTR [bx+si],al
     660:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     663:	31 44 02             	xor    WORD PTR [si+0x2],ax
     666:	08 00                	or     BYTE PTR [bx+si],al
     668:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     66b:	31 48 02             	xor    WORD PTR [bx+si+0x2],cx
     66e:	08 00                	or     BYTE PTR [bx+si],al
     670:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     673:	31 4c 02             	xor    WORD PTR [si+0x2],cx
     676:	08 00                	or     BYTE PTR [bx+si],al
     678:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
     67b:	31 50 02             	xor    WORD PTR [bx+si+0x2],dx
     67e:	08 00                	or     BYTE PTR [bx+si],al
     680:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     683:	31 54 02             	xor    WORD PTR [si+0x2],dx
     686:	08 00                	or     BYTE PTR [bx+si],al
     688:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     68b:	31 58 02             	xor    WORD PTR [bx+si+0x2],bx
     68e:	00 00                	add    BYTE PTR [bx+si],al
     690:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     693:	6e                   	outs   dx,BYTE PTR ds:[si]
     694:	65 6c                	gs ins BYTE PTR es:[di],dx
     696:	4c                   	dec    sp
     697:	4f                   	dec    di
     698:	55                   	push   bp
     699:	50                   	push   ax
     69a:	45                   	inc    bp
     69b:	5c                   	pop    sp
     69c:	02 1c                	add    bl,BYTE PTR [si]
     69e:	00 11                	add    BYTE PTR [bx+di],dl
     6a0:	54                   	push   sp
     6a1:	61                   	popa
     6a2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a5:	45                   	inc    bp
     6a6:	52                   	push   dx
     6a7:	47                   	inc    di
     6a8:	50                   	push   ax
     6a9:	65 72 69             	gs jb  0x715
     6ac:	6f                   	outs   dx,WORD PTR ds:[si]
     6ad:	64 65 4e             	fs gs dec si
     6b0:	6f                   	outs   dx,WORD PTR ds:[si]
     6b1:	60                   	pusha
     6b2:	02 1c                	add    bl,BYTE PTR [si]
     6b4:	00 14                	add    BYTE PTR [si],dl
     6b6:	54                   	push   sp
     6b7:	61                   	popa
     6b8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6bb:	45                   	inc    bp
     6bc:	52                   	push   dx
     6bd:	47                   	inc    di
     6be:	45                   	inc    bp
     6bf:	6e                   	outs   dx,BYTE PTR ds:[si]
     6c0:	74 72                	je     0x734
     6c2:	65 70 72             	gs jo  0x737
     6c5:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     6ca:	64 02 20             	add    ah,BYTE PTR fs:[bx+si]
     6cd:	00 15                	add    BYTE PTR [di],dl
     6cf:	54                   	push   sp
     6d0:	61                   	popa
     6d1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6d4:	45                   	inc    bp
     6d5:	52                   	push   dx
     6d6:	47                   	inc    di
     6d7:	43                   	inc    bx
     6d8:	61                   	popa
     6d9:	70 69                	jo     0x744
     6db:	74 61                	je     0x73e
     6dd:	6c                   	ins    BYTE PTR es:[di],dx
     6de:	53                   	push   bx
     6df:	6f                   	outs   dx,WORD PTR ds:[si]
     6e0:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     6e3:	6c                   	ins    BYTE PTR es:[di],dx
     6e4:	68 02 20             	push   0x2002
     6e7:	00 10                	add    BYTE PTR [bx+si],dl
     6e9:	54                   	push   sp
     6ea:	61                   	popa
     6eb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6ee:	45                   	inc    bp
     6ef:	52                   	push   dx
     6f0:	47                   	inc    di
     6f1:	52                   	push   dx
     6f2:	65 73 65             	gs jae 0x75a
     6f5:	72 76                	jb     0x76d
     6f7:	65 73 6c             	gs jae 0x766
     6fa:	02 20                	add    ah,BYTE PTR [bx+si]
     6fc:	00 13                	add    BYTE PTR [bp+di],dl
     6fe:	54                   	push   sp
     6ff:	61                   	popa
     700:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     703:	45                   	inc    bp
     704:	52                   	push   dx
     705:	47                   	inc    di
     706:	52                   	push   dx
     707:	65 73 75             	gs jae 0x77f
     70a:	6c                   	ins    BYTE PTR es:[di],dx
     70b:	74 61                	je     0x76e
     70d:	74 4e                	je     0x75d
     70f:	65 74 70             	gs je  0x782
     712:	02 20                	add    ah,BYTE PTR [bx+si]
     714:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     718:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     71b:	45                   	inc    bp
     71c:	52                   	push   dx
     71d:	47                   	inc    di
     71e:	53                   	push   bx
     71f:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     724:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     729:	74 74                	je     0x79f
     72b:	65 74 02             	gs je  0x730
     72e:	20 00                	and    BYTE PTR [bx+si],al
     730:	0b 54 61             	or     dx,WORD PTR [si+0x61]
     733:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     736:	45                   	inc    bp
     737:	52                   	push   dx
     738:	47                   	inc    di
     739:	43                   	inc    bx
     73a:	41                   	inc    cx
     73b:	46                   	inc    si
     73c:	78 02                	js     0x740
     73e:	20 00                	and    BYTE PTR [bx+si],al
     740:	0d 54 61             	or     ax,0x6154
     743:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     746:	45                   	inc    bp
     747:	52                   	push   dx
     748:	47                   	inc    di
     749:	49                   	dec    cx
     74a:	6d                   	ins    WORD PTR es:[di],dx
     74b:	70 6f                	jo     0x7bc
     74d:	74 7c                	je     0x7cb
     74f:	02 20                	add    ah,BYTE PTR [bx+si]
     751:	00 0b                	add    BYTE PTR [bp+di],cl
     753:	54                   	push   sp
     754:	61                   	popa
     755:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     758:	45                   	inc    bp
     759:	52                   	push   dx
     75a:	47                   	inc    di
     75b:	49                   	dec    cx
     75c:	46                   	inc    si
     75d:	41                   	inc    cx
     75e:	80 02 20             	add    BYTE PTR [bp+si],0x20
     761:	00 0f                	add    BYTE PTR [bx],cl
     763:	54                   	push   sp
     764:	61                   	popa
     765:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     768:	45                   	inc    bp
     769:	52                   	push   dx
     76a:	47                   	inc    di
     76b:	43                   	inc    bx
     76c:	6c                   	ins    BYTE PTR es:[di],dx
     76d:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     772:	84 02                	test   BYTE PTR [bp+si],al
     774:	20 00                	and    BYTE PTR [bx+si],al
     776:	14 54                	adc    al,0x54
     778:	61                   	popa
     779:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     77c:	45                   	inc    bp
     77d:	52                   	push   dx
     77e:	47                   	inc    di
     77f:	46                   	inc    si
     780:	6f                   	outs   dx,WORD PTR ds:[si]
     781:	75 72                	jne    0x7f5
     783:	6e                   	outs   dx,BYTE PTR ds:[si]
     784:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     789:	72 73                	jb     0x7fe
     78b:	88 02                	mov    BYTE PTR [bp+si],al
     78d:	20 00                	and    BYTE PTR [bx+si],al
     78f:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     792:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     795:	45                   	inc    bp
     796:	52                   	push   dx
     797:	47                   	inc    di
     798:	54                   	push   sp
     799:	72 65                	jb     0x800
     79b:	73 6f                	jae    0x80c
     79d:	72 65                	jb     0x804
     79f:	72 69                	jb     0x80a
     7a1:	65 8c 02             	mov    WORD PTR gs:[bp+si],es
     7a4:	20 00                	and    BYTE PTR [bx+si],al
     7a6:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     7aa:	6c                   	ins    BYTE PTR es:[di],dx
     7ab:	65 45                	gs inc bp
     7ad:	52                   	push   dx
     7ae:	47                   	inc    di
     7af:	45                   	inc    bp
     7b0:	6d                   	ins    WORD PTR es:[di],dx
     7b1:	70 72                	jo     0x825
     7b3:	75 6e                	jne    0x823
     7b5:	74 90                	je     0x747
     7b7:	02 20                	add    ah,BYTE PTR [bx+si]
     7b9:	00 15                	add    BYTE PTR [di],dl
     7bb:	54                   	push   sp
     7bc:	61                   	popa
     7bd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7c0:	45                   	inc    bp
     7c1:	52                   	push   dx
     7c2:	47                   	inc    di
     7c3:	44                   	inc    sp
     7c4:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     7c8:	76 65                	jbe    0x82f
     7ca:	72 74                	jb     0x840
     7cc:	41                   	inc    cx
     7cd:	75 74                	jne    0x843
     7cf:	6f                   	outs   dx,WORD PTR ds:[si]
     7d0:	94                   	xchg   sp,ax
     7d1:	02 20                	add    ah,BYTE PTR [bx+si]
     7d3:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     7d7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7da:	45                   	inc    bp
     7db:	52                   	push   dx
     7dc:	47                   	inc    di
     7dd:	44                   	inc    sp
     7de:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     7e2:	76 65                	jbe    0x849
     7e4:	72 74                	jb     0x85a
     7e6:	4e                   	dec    si
     7e7:	41                   	inc    cx
     7e8:	75 74                	jne    0x85e
     7ea:	6f                   	outs   dx,WORD PTR ds:[si]
     7eb:	98                   	cbw
     7ec:	02 20                	add    ah,BYTE PTR [bx+si]
     7ee:	00 15                	add    BYTE PTR [di],dl
     7f0:	54                   	push   sp
     7f1:	61                   	popa
     7f2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7f5:	45                   	inc    bp
     7f6:	52                   	push   dx
     7f7:	47                   	inc    di
     7f8:	41                   	inc    cx
     7f9:	6d                   	ins    WORD PTR es:[di],dx
     7fa:	6f                   	outs   dx,WORD PTR ds:[si]
     7fb:	72 74                	jb     0x871
     7fd:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     802:	65 6e                	outs   dx,BYTE PTR gs:[si]
     804:	74 9c                	je     0x7a2
     806:	02 20                	add    ah,BYTE PTR [bx+si]
     808:	00 10                	add    BYTE PTR [bx+si],dl
     80a:	54                   	push   sp
     80b:	61                   	popa
     80c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     80f:	45                   	inc    bp
     810:	52                   	push   dx
     811:	47                   	inc    di
     812:	43                   	inc    bx
     813:	65 73 73             	gs jae 0x889
     816:	69 6f 6e 73 a0       	imul   bp,WORD PTR [bx+0x6e],0xa073
     81b:	02 1c                	add    bl,BYTE PTR [si]
     81d:	00 10                	add    BYTE PTR [bx+si],dl
     81f:	54                   	push   sp
     820:	61                   	popa
     821:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     824:	45                   	inc    bp
     825:	52                   	push   dx
     826:	47                   	inc    di
     827:	4d                   	dec    bp
     828:	61                   	popa
     829:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     82c:	6e                   	outs   dx,BYTE PTR ds:[si]
     82d:	65 73 a4             	gs jae 0x7d4
     830:	02 20                	add    ah,BYTE PTR [bx+si]
     832:	00 1d                	add    BYTE PTR [di],bl
     834:	54                   	push   sp
     835:	61                   	popa
     836:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     839:	45                   	inc    bp
     83a:	52                   	push   dx
     83b:	47                   	inc    di
     83c:	49                   	dec    cx
     83d:	6d                   	ins    WORD PTR es:[di],dx
     83e:	6d                   	ins    WORD PTR es:[di],dx
     83f:	6f                   	outs   dx,WORD PTR ds:[si]
     840:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     843:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     848:	6f                   	outs   dx,WORD PTR ds:[si]
     849:	6e                   	outs   dx,BYTE PTR ds:[si]
     84a:	73 42                	jae    0x88e
     84c:	72 75                	jb     0x8c3
     84e:	74 65                	je     0x8b5
     850:	73 a8                	jae    0x7fa
     852:	02 20                	add    ah,BYTE PTR [bx+si]
     854:	00 1c                	add    BYTE PTR [si],bl
     856:	54                   	push   sp
     857:	61                   	popa
     858:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     85b:	45                   	inc    bp
     85c:	52                   	push   dx
     85d:	47                   	inc    di
     85e:	43                   	inc    bx
     85f:	6f                   	outs   dx,WORD PTR ds:[si]
     860:	75 74                	jne    0x8d6
     862:	73 46                	jae    0x8aa
     864:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     869:	72 6f                	jb     0x8da
     86b:	64 75 63             	fs jne 0x8d1
     86e:	74 69                	je     0x8d9
     870:	6f                   	outs   dx,WORD PTR ds:[si]
     871:	6e                   	outs   dx,BYTE PTR ds:[si]
     872:	ac                   	lods   al,BYTE PTR ds:[si]
     873:	02 1c                	add    bl,BYTE PTR [si]
     875:	00 12                	add    BYTE PTR [bp+si],dl
     877:	54                   	push   sp
     878:	61                   	popa
     879:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     87c:	45                   	inc    bp
     87d:	52                   	push   dx
     87e:	47                   	inc    di
     87f:	50                   	push   ax
     880:	72 6f                	jb     0x8f1
     882:	64 75 63             	fs jne 0x8e8
     885:	74 69                	je     0x8f0
     887:	66 73 b0             	data32 jae 0x83a
     88a:	02 1c                	add    bl,BYTE PTR [si]
     88c:	00 10                	add    BYTE PTR [bx+si],dl
     88e:	54                   	push   sp
     88f:	61                   	popa
     890:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     893:	45                   	inc    bp
     894:	52                   	push   dx
     895:	47                   	inc    di
     896:	56                   	push   si
     897:	65 6e                	outs   dx,BYTE PTR gs:[si]
     899:	64 65 75 72          	fs gs jne 0x90f
     89d:	73 b4                	jae    0x853
     89f:	02 1c                	add    bl,BYTE PTR [si]
     8a1:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     8a5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8a8:	45                   	inc    bp
     8a9:	52                   	push   dx
     8aa:	47                   	inc    di
     8ab:	43                   	inc    bx
     8ac:	61                   	popa
     8ad:	64 72 65             	fs jb  0x915
     8b0:	73 b8                	jae    0x86a
     8b2:	02 20                	add    ah,BYTE PTR [bx+si]
     8b4:	00 14                	add    BYTE PTR [si],dl
     8b6:	54                   	push   sp
     8b7:	61                   	popa
     8b8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8bb:	45                   	inc    bp
     8bc:	52                   	push   dx
     8bd:	47                   	inc    di
     8be:	43                   	inc    bx
     8bf:	6f                   	outs   dx,WORD PTR ds:[si]
     8c0:	75 74                	jne    0x936
     8c2:	45                   	inc    bp
     8c3:	6d                   	ins    WORD PTR es:[di],dx
     8c4:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     8c7:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     8ca:	bc 02 20             	mov    sp,0x2002
     8cd:	00 14                	add    BYTE PTR [si],dl
     8cf:	54                   	push   sp
     8d0:	61                   	popa
     8d1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8d4:	45                   	inc    bp
     8d5:	52                   	push   dx
     8d6:	47                   	inc    di
     8d7:	43                   	inc    bx
     8d8:	6f                   	outs   dx,WORD PTR ds:[si]
     8d9:	75 74                	jne    0x94f
     8db:	4c                   	dec    sp
     8dc:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     8e1:	69 65 c0 02 20       	imul   sp,WORD PTR [di-0x40],0x2002
     8e6:	00 15                	add    BYTE PTR [di],dl
     8e8:	54                   	push   sp
     8e9:	61                   	popa
     8ea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8ed:	45                   	inc    bp
     8ee:	52                   	push   dx
     8ef:	47                   	inc    di
     8f0:	43                   	inc    bx
     8f1:	6f                   	outs   dx,WORD PTR ds:[si]
     8f2:	75 74                	jne    0x968
     8f4:	46                   	inc    si
     8f5:	6f                   	outs   dx,WORD PTR ds:[si]
     8f6:	72 6d                	jb     0x965
     8f8:	61                   	popa
     8f9:	74 69                	je     0x964
     8fb:	6f                   	outs   dx,WORD PTR ds:[si]
     8fc:	6e                   	outs   dx,BYTE PTR ds:[si]
     8fd:	c4 02                	les    ax,DWORD PTR [bp+si]
     8ff:	20 00                	and    BYTE PTR [bx+si],al
     901:	15 54 61             	adc    ax,0x6154
     904:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     907:	45                   	inc    bp
     908:	52                   	push   dx
     909:	47                   	inc    di
     90a:	44                   	inc    sp
     90b:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     910:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     913:	69 6f 6e 73 c8       	imul   bp,WORD PTR [bx+0x6e],0xc873
     918:	02 1c                	add    bl,BYTE PTR [si]
     91a:	00 0f                	add    BYTE PTR [bx],cl
     91c:	54                   	push   sp
     91d:	61                   	popa
     91e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     921:	45                   	inc    bp
     922:	52                   	push   dx
     923:	47                   	inc    di
     924:	53                   	push   bx
     925:	70 65                	jo     0x98c
     927:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     92a:	6c                   	ins    BYTE PTR es:[di],dx
     92b:	cc                   	int3
     92c:	02 20                	add    ah,BYTE PTR [bx+si]
     92e:	00 15                	add    BYTE PTR [di],dl
     930:	54                   	push   sp
     931:	61                   	popa
     932:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     935:	45                   	inc    bp
     936:	52                   	push   dx
     937:	47                   	inc    di
     938:	54                   	push   sp
     939:	56                   	push   si
     93a:	41                   	inc    cx
     93b:	44                   	inc    sp
     93c:	65 64 75 63          	gs fs jne 0x9a3
     940:	74 69                	je     0x9ab
     942:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     945:	d0 02                	rol    BYTE PTR [bp+si],1
     947:	20 00                	and    BYTE PTR [bx+si],al
     949:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     94c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     94f:	45                   	inc    bp
     950:	52                   	push   dx
     951:	47                   	inc    di
     952:	52                   	push   dx
     953:	65 6d                	gs ins WORD PTR es:[di],dx
     955:	75 6e                	jne    0x9c5
     957:	65 72 61             	gs jb  0x9bb
     95a:	74 69                	je     0x9c5
     95c:	6f                   	outs   dx,WORD PTR ds:[si]
     95d:	6e                   	outs   dx,BYTE PTR ds:[si]
     95e:	43                   	inc    bx
     95f:	61                   	popa
     960:	64 72 65             	fs jb  0x9c8
     963:	73 d4                	jae    0x939
     965:	02 20                	add    ah,BYTE PTR [bx+si]
     967:	00 14                	add    BYTE PTR [si],dl
     969:	54                   	push   sp
     96a:	61                   	popa
     96b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     96e:	45                   	inc    bp
     96f:	52                   	push   dx
     970:	47                   	inc    di
     971:	54                   	push   sp
     972:	56                   	push   si
     973:	41                   	inc    cx
     974:	43                   	inc    bx
     975:	6f                   	outs   dx,WORD PTR ds:[si]
     976:	6c                   	ins    BYTE PTR es:[di],dx
     977:	6c                   	ins    BYTE PTR es:[di],dx
     978:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     97c:	65 d8 02             	fadd   DWORD PTR gs:[bp+si]
     97f:	08 00                	or     BYTE PTR [bx+si],al
     981:	06                   	push   es
     982:	46                   	inc    si
     983:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     988:	dc 02                	fadd   QWORD PTR [bp+si]
     98a:	08 00                	or     BYTE PTR [bx+si],al
     98c:	02 4e 33             	add    cl,BYTE PTR [bp+0x33]
     98f:	e0 02                	loopne 0x993
     991:	00 00                	add    BYTE PTR [bx+si],al
     993:	07                   	pop    es
     994:	50                   	push   ax
     995:	61                   	popa
     996:	6e                   	outs   dx,BYTE PTR ds:[si]
     997:	65 6c                	gs ins BYTE PTR es:[di],dx
     999:	34 34                	xor    al,0x34
     99b:	e4 02                	in     al,0x2
     99d:	24 00                	and    al,0x0
     99f:	07                   	pop    es
     9a0:	4c                   	dec    sp
     9a1:	61                   	popa
     9a2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9a5:	55                   	push   bp
     9a6:	30 e8                	xor    al,ch
     9a8:	02 24                	add    ah,BYTE PTR [si]
     9aa:	00 07                	add    BYTE PTR [bx],al
     9ac:	4c                   	dec    sp
     9ad:	61                   	popa
     9ae:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9b1:	55                   	push   bp
     9b2:	31 ec                	xor    sp,bp
     9b4:	02 24                	add    ah,BYTE PTR [si]
     9b6:	00 07                	add    BYTE PTR [bx],al
     9b8:	4c                   	dec    sp
     9b9:	61                   	popa
     9ba:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9bd:	55                   	push   bp
     9be:	32 f0                	xor    dh,al
     9c0:	02 24                	add    ah,BYTE PTR [si]
     9c2:	00 07                	add    BYTE PTR [bx],al
     9c4:	4c                   	dec    sp
     9c5:	61                   	popa
     9c6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9c9:	55                   	push   bp
     9ca:	33 f4                	xor    si,sp
     9cc:	02 28                	add    ch,BYTE PTR [bx+si]
     9ce:	00 05                	add    BYTE PTR [di],al
     9d0:	4d                   	dec    bp
     9d1:	65 6d                	gs ins WORD PTR es:[di],dx
     9d3:	6f                   	outs   dx,WORD PTR ds:[si]
     9d4:	31 f8                	xor    ax,di
     9d6:	02 08                	add    cl,BYTE PTR [bx+si]
     9d8:	00 08                	add    BYTE PTR [bx+si],cl
     9da:	45                   	inc    bp
     9db:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     9e1:	31 fc                	xor    sp,di
     9e3:	02 08                	add    cl,BYTE PTR [bx+si]
     9e5:	00 07                	add    BYTE PTR [bx],al
     9e7:	43                   	inc    bx
     9e8:	6f                   	outs   dx,WORD PTR ds:[si]
     9e9:	70 69                	jo     0xa54
     9eb:	65 72 31             	gs jb  0xa1f
     9ee:	00 03                	add    BYTE PTR [bp+di],al
     9f0:	20 00                	and    BYTE PTR [bx+si],al
     9f2:	17                   	pop    ss
     9f3:	54                   	push   sp
     9f4:	61                   	popa
     9f5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9f8:	45                   	inc    bp
     9f9:	52                   	push   dx
     9fa:	47                   	inc    di
     9fb:	50                   	push   ax
     9fc:	72 69                	jb     0xa67
     9fe:	6d                   	ins    WORD PTR es:[di],dx
     9ff:	65 73 41             	gs jae 0xa43
     a02:	73 73                	jae    0xa77
     a04:	75 72                	jne    0xa78
     a06:	61                   	popa
     a07:	6e                   	outs   dx,BYTE PTR ds:[si]
     a08:	63 65 04             	arpl   WORD PTR [di+0x4],sp
     a0b:	03 08                	add    cx,WORD PTR [bx+si]
     a0d:	00 0f                	add    BYTE PTR [bx],cl
     a0f:	41                   	inc    cx
     a10:	75 74                	jne    0xa86
     a12:	72 65                	jb     0xa79
     a14:	73 72                	jae    0xa88
     a16:	73 75                	jae    0xa8d
     a18:	6c                   	ins    BYTE PTR es:[di],dx
     a19:	74 61                	je     0xa7c
     a1b:	74 73                	je     0xa90
     a1d:	31 08                	xor    WORD PTR [bx+si],cx
     a1f:	03 08                	add    cx,WORD PTR [bx+si]
     a21:	00 13                	add    BYTE PTR [bp+di],dl
     a23:	52                   	push   dx
     a24:	61                   	popa
     a25:	70 70                	jo     0xa97
     a27:	65 6c                	gs ins BYTE PTR es:[di],dx
     a29:	44                   	inc    sp
     a2a:	65 73 44             	gs jae 0xa71
     a2d:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     a31:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     a36:	0c 03                	or     al,0x3
     a38:	08 00                	or     BYTE PTR [bx+si],al
     a3a:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
     a3d:	10 03                	adc    BYTE PTR [bp+di],al
     a3f:	08 00                	or     BYTE PTR [bx+si],al
     a41:	14 54                	adc    al,0x54
     a43:	61                   	popa
     a44:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a47:	61                   	popa
     a48:	75 44                	jne    0xa8e
     a4a:	65 54                	gs push sp
     a4c:	72 65                	jb     0xab3
     a4e:	73 6f                	jae    0xabf
     a50:	72 65                	jb     0xab7
     a52:	72 69                	jb     0xabd
     a54:	65 31 14             	xor    WORD PTR gs:[si],dx
     a57:	03 08                	add    cx,WORD PTR [bx+si]
     a59:	00 15                	add    BYTE PTR [di],dl
     a5b:	54                   	push   sp
     a5c:	61                   	popa
     a5d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a60:	61                   	popa
     a61:	75 44                	jne    0xaa7
     a63:	65 46                	gs inc si
     a65:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     a6a:	65 6d                	gs ins WORD PTR es:[di],dx
     a6c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a6e:	74 31                	je     0xaa1
     a70:	18 03                	sbb    BYTE PTR [bp+di],al
     a72:	08 00                	or     BYTE PTR [bx+si],al
     a74:	06                   	push   es
     a75:	42                   	inc    dx
     a76:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
     a7b:	1c 03                	sbb    al,0x3
     a7d:	08 00                	or     BYTE PTR [bx+si],al
     a7f:	12 43 6f             	adc    al,BYTE PTR [bp+di+0x6f]
     a82:	6d                   	ins    WORD PTR es:[di],dx
     a83:	70 74                	jo     0xaf9
     a85:	65 44                	gs inc sp
     a87:	65 52                	gs push dx
     a89:	65 73 75             	gs jae 0xb01
     a8c:	6c                   	ins    BYTE PTR es:[di],dx
     a8d:	74 61                	je     0xaf0
     a8f:	74 73                	je     0xb04
     a91:	31 20                	xor    WORD PTR [bx+si],sp
     a93:	03 08                	add    cx,WORD PTR [bx+si]
     a95:	00 0a                	add    BYTE PTR [bp+si],cl
     a97:	53                   	push   bx
     a98:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     a9d:	69 6f 6e 31 24       	imul   bp,WORD PTR [bx+0x6e],0x2431
     aa2:	03 08                	add    cx,WORD PTR [bx+si]
     aa4:	00 05                	add    BYTE PTR [di],al
     aa6:	4e                   	dec    si
     aa7:	31 30                	xor    WORD PTR [bx+si],si
     aa9:	30 31                	xor    BYTE PTR [bx+di],dh
     aab:	28 03                	sub    BYTE PTR [bp+di],al
     aad:	08 00                	or     BYTE PTR [bx+si],al
     aaf:	05 4e 31             	add    ax,0x314e
     ab2:	35 30 31             	xor    ax,0x3130
     ab5:	2c 03                	sub    al,0x3
     ab7:	08 00                	or     BYTE PTR [bx+si],al
     ab9:	05 4e 32             	add    ax,0x324e
     abc:	30 30                	xor    BYTE PTR [bx+si],dh
     abe:	31 30                	xor    WORD PTR [bx+si],si
     ac0:	03 08                	add    cx,WORD PTR [bx+si]
     ac2:	00 04                	add    BYTE PTR [si],al
     ac4:	4e                   	dec    si
     ac5:	37                   	aaa
     ac6:	35 31 34             	xor    ax,0x3431
     ac9:	03 08                	add    cx,WORD PTR [bx+si]
     acb:	00 04                	add    BYTE PTR [si],al
     acd:	4e                   	dec    si
     ace:	35 30 31             	xor    ax,0x3130
     ad1:	38 03                	cmp    BYTE PTR [bp+di],al
     ad3:	08 00                	or     BYTE PTR [bx+si],al
     ad5:	02 4e 35             	add    cl,BYTE PTR [bp+0x35]
     ad8:	3c 03                	cmp    al,0x3
     ada:	08 00                	or     BYTE PTR [bx+si],al
     adc:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     adf:	70 72                	jo     0xb53
     ae1:	65 73 73             	gs jae 0xb57
     ae4:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     ae9:	70 69                	jo     0xb54
     aeb:	64 65 31 40 03       	fs xor WORD PTR gs:[bx+si+0x3],ax
     af0:	08 00                	or     BYTE PTR [bx+si],al
     af2:	02 4e 36             	add    cl,BYTE PTR [bp+0x36]
     af5:	44                   	inc    sp
     af6:	03 08                	add    cx,WORD PTR [bx+si]
     af8:	00 05                	add    BYTE PTR [di],al
     afa:	4e                   	dec    si
     afb:	31 32                	xor    WORD PTR [bp+si],si
     afd:	35 31 48             	xor    ax,0x4831
     b00:	03 08                	add    cx,WORD PTR [bx+si]
     b02:	00 08                	add    BYTE PTR [bx+si],cl
     b04:	50                   	push   ax
     b05:	65 72 69             	gs jb  0xb71
     b08:	6f                   	outs   dx,WORD PTR ds:[si]
     b09:	64 65 32 4c 03       	fs xor cl,BYTE PTR gs:[si+0x3]
     b0e:	08 00                	or     BYTE PTR [bx+si],al
     b10:	06                   	push   es
     b11:	61                   	popa
     b12:	75 74                	jne    0xb88
     b14:	72 65                	jb     0xb7b
     b16:	31 50 03             	xor    WORD PTR [bx+si+0x3],dx
     b19:	08 00                	or     BYTE PTR [bx+si],al
     b1b:	04 4e                	add    al,0x4e
     b1d:	32 30                	xor    dh,BYTE PTR [bx+si]
     b1f:	31 54 03             	xor    WORD PTR [si+0x3],dx
     b22:	08 00                	or     BYTE PTR [bx+si],al
     b24:	04 4e                	add    al,0x4e
     b26:	31 39                	xor    WORD PTR [bx+di],di
     b28:	31 58 03             	xor    WORD PTR [bx+si+0x3],bx
     b2b:	08 00                	or     BYTE PTR [bx+si],al
     b2d:	04 4e                	add    al,0x4e
     b2f:	31 38                	xor    WORD PTR [bx+si],di
     b31:	31 5c 03             	xor    WORD PTR [si+0x3],bx
     b34:	08 00                	or     BYTE PTR [bx+si],al
     b36:	04 4e                	add    al,0x4e
     b38:	31 37                	xor    WORD PTR [bx],si
     b3a:	31 60 03             	xor    WORD PTR [bx+si+0x3],sp
     b3d:	08 00                	or     BYTE PTR [bx+si],al
     b3f:	04 4e                	add    al,0x4e
     b41:	31 36 31 64          	xor    WORD PTR ds:0x6431,si
     b45:	03 08                	add    cx,WORD PTR [bx+si]
     b47:	00 04                	add    BYTE PTR [si],al
     b49:	4e                   	dec    si
     b4a:	31 35                	xor    WORD PTR [di],si
     b4c:	31 68 03             	xor    WORD PTR [bx+si+0x3],bp
     b4f:	08 00                	or     BYTE PTR [bx+si],al
     b51:	04 4e                	add    al,0x4e
     b53:	31 34                	xor    WORD PTR [si],si
     b55:	31 6c 03             	xor    WORD PTR [si+0x3],bp
     b58:	08 00                	or     BYTE PTR [bx+si],al
     b5a:	04 4e                	add    al,0x4e
     b5c:	31 33                	xor    WORD PTR [bp+di],si
     b5e:	31 70 03             	xor    WORD PTR [bx+si+0x3],si
     b61:	08 00                	or     BYTE PTR [bx+si],al
     b63:	04 4e                	add    al,0x4e
     b65:	31 32                	xor    WORD PTR [bp+si],si
     b67:	31 74 03             	xor    WORD PTR [si+0x3],si
     b6a:	08 00                	or     BYTE PTR [bx+si],al
     b6c:	04 4e                	add    al,0x4e
     b6e:	31 31                	xor    WORD PTR [bx+di],si
     b70:	31 78 03             	xor    WORD PTR [bx+si+0x3],di
     b73:	08 00                	or     BYTE PTR [bx+si],al
     b75:	04 4e                	add    al,0x4e
     b77:	31 30                	xor    WORD PTR [bx+si],si
     b79:	31 7c 03             	xor    WORD PTR [si+0x3],di
     b7c:	08 00                	or     BYTE PTR [bx+si],al
     b7e:	03 4e 39             	add    cx,WORD PTR [bp+0x39]
     b81:	31 80 03 08          	xor    WORD PTR [bx+si+0x803],ax
     b85:	00 03                	add    BYTE PTR [bp+di],al
     b87:	4e                   	dec    si
     b88:	38 32                	cmp    BYTE PTR [bp+si],dh
     b8a:	84 03                	test   BYTE PTR [bp+di],al
     b8c:	08 00                	or     BYTE PTR [bx+si],al
     b8e:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     b91:	32 88 03 08          	xor    cl,BYTE PTR [bx+si+0x803]
     b95:	00 03                	add    BYTE PTR [bp+di],al
     b97:	4e                   	dec    si
     b98:	36 32 8c 03 08       	xor    cl,BYTE PTR ss:[si+0x803]
     b9d:	00 03                	add    BYTE PTR [bp+di],al
     b9f:	4e                   	dec    si
     ba0:	35 32 90             	xor    ax,0x9032
     ba3:	03 08                	add    cx,WORD PTR [bx+si]
     ba5:	00 03                	add    BYTE PTR [bp+di],al
     ba7:	4e                   	dec    si
     ba8:	34 32                	xor    al,0x32
     baa:	94                   	xchg   sp,ax
     bab:	03 08                	add    cx,WORD PTR [bx+si]
     bad:	00 03                	add    BYTE PTR [bp+di],al
     baf:	4e                   	dec    si
     bb0:	33 32                	xor    si,WORD PTR [bp+si]
     bb2:	98                   	cbw
     bb3:	03 08                	add    cx,WORD PTR [bx+si]
     bb5:	00 03                	add    BYTE PTR [bp+di],al
     bb7:	4e                   	dec    si
     bb8:	32 32                	xor    dh,BYTE PTR [bp+si]
     bba:	9c                   	pushf
     bbb:	03 08                	add    cx,WORD PTR [bx+si]
     bbd:	00 03                	add    BYTE PTR [bp+di],al
     bbf:	4e                   	dec    si
     bc0:	31 32                	xor    WORD PTR [bp+si],si
     bc2:	a0 03 2c             	mov    al,ds:0x2c03
     bc5:	00 09                	add    BYTE PTR [bx+di],cl
     bc7:	47                   	inc    di
     bc8:	72 6f                	jb     0xc39
     bca:	75 70                	jne    0xc3c
     bcc:	42                   	inc    dx
     bcd:	6f                   	outs   dx,WORD PTR ds:[si]
     bce:	78 31                	js     0xc01
     bd0:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     bd1:	03 2c                	add    bp,WORD PTR [si]
     bd3:	00 0a                	add    BYTE PTR [bp+si],cl
     bd5:	47                   	inc    di
     bd6:	72 6f                	jb     0xc47
     bd8:	75 70                	jne    0xc4a
     bda:	42                   	inc    dx
     bdb:	6f                   	outs   dx,WORD PTR ds:[si]
     bdc:	78 31                	js     0xc0f
     bde:	31 a8 03 00          	xor    WORD PTR [bx+si+0x3],bp
     be2:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     be6:	6e                   	outs   dx,BYTE PTR ds:[si]
     be7:	65 6c                	gs ins BYTE PTR es:[di],dx
     be9:	34 ac                	xor    al,0xac
     beb:	03 30                	add    si,WORD PTR [bx+si]
     bed:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
     bf1:	61                   	popa
     bf2:	70 65                	jo     0xc59
     bf4:	33 b0 03 00          	xor    si,WORD PTR [bx+si+0x3]
     bf8:	00 08                	add    BYTE PTR [bx+si],cl
     bfa:	50                   	push   ax
     bfb:	61                   	popa
     bfc:	6e                   	outs   dx,BYTE PTR ds:[si]
     bfd:	65 6c                	gs ins BYTE PTR es:[di],dx
     bff:	31 31                	xor    WORD PTR [bx+di],si
     c01:	32 b4 03 00          	xor    dh,BYTE PTR [si+0x3]
     c05:	00 08                	add    BYTE PTR [bx+si],cl
     c07:	50                   	push   ax
     c08:	61                   	popa
     c09:	6e                   	outs   dx,BYTE PTR ds:[si]
     c0a:	65 6c                	gs ins BYTE PTR es:[di],dx
     c0c:	31 31                	xor    WORD PTR [bx+di],si
     c0e:	33 b8 03 00          	xor    di,WORD PTR [bx+si+0x3]
     c12:	00 08                	add    BYTE PTR [bx+si],cl
     c14:	50                   	push   ax
     c15:	61                   	popa
     c16:	6e                   	outs   dx,BYTE PTR ds:[si]
     c17:	65 6c                	gs ins BYTE PTR es:[di],dx
     c19:	31 31                	xor    WORD PTR [bx+di],si
     c1b:	34 bc                	xor    al,0xbc
     c1d:	03 34                	add    si,WORD PTR [si]
     c1f:	00 09                	add    BYTE PTR [bx+di],cl
     c21:	44                   	inc    sp
     c22:	42                   	inc    dx
     c23:	45                   	inc    bp
     c24:	64 69 74 31 31 32    	imul   si,WORD PTR fs:[si+0x31],0x3231
     c2a:	c0 03 34             	rol    BYTE PTR [bp+di],0x34
     c2d:	00 09                	add    BYTE PTR [bx+di],cl
     c2f:	44                   	inc    sp
     c30:	42                   	inc    dx
     c31:	45                   	inc    bp
     c32:	64 69 74 31 31 33    	imul   si,WORD PTR fs:[si+0x31],0x3331
     c38:	c4 03                	les    ax,DWORD PTR [bp+di]
     c3a:	34 00                	xor    al,0x0
     c3c:	09 44 42             	or     WORD PTR [si+0x42],ax
     c3f:	45                   	inc    bp
     c40:	64 69 74 31 31 34    	imul   si,WORD PTR fs:[si+0x31],0x3431
     c46:	c8 03 00 00          	enter  0x3,0x0
     c4a:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     c4d:	6e                   	outs   dx,BYTE PTR ds:[si]
     c4e:	65 6c                	gs ins BYTE PTR es:[di],dx
     c50:	31 31                	xor    WORD PTR [bx+di],si
     c52:	35 cc 03             	xor    ax,0x3cc
     c55:	34 00                	xor    al,0x0
     c57:	09 44 42             	or     WORD PTR [si+0x42],ax
     c5a:	45                   	inc    bp
     c5b:	64 69 74 31 31 35    	imul   si,WORD PTR fs:[si+0x31],0x3531
     c61:	d0 03                	rol    BYTE PTR [bp+di],1
     c63:	2c 00                	sub    al,0x0
     c65:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     c68:	6f                   	outs   dx,WORD PTR ds:[si]
     c69:	75 70                	jne    0xcdb
     c6b:	42                   	inc    dx
     c6c:	6f                   	outs   dx,WORD PTR ds:[si]
     c6d:	78 31                	js     0xca0
     c6f:	32 d4                	xor    dl,ah
     c71:	03 00                	add    ax,WORD PTR [bx+si]
     c73:	00 07                	add    BYTE PTR [bx],al
     c75:	50                   	push   ax
     c76:	61                   	popa
     c77:	6e                   	outs   dx,BYTE PTR ds:[si]
     c78:	65 6c                	gs ins BYTE PTR es:[di],dx
     c7a:	31 30                	xor    WORD PTR [bx+si],si
     c7c:	d8 03                	fadd   DWORD PTR [bp+di]
     c7e:	30 00                	xor    BYTE PTR [bx+si],al
     c80:	06                   	push   es
     c81:	53                   	push   bx
     c82:	68 61 70             	push   0x7061
     c85:	65 34 dc             	gs xor al,0xdc
     c88:	03 00                	add    ax,WORD PTR [bx+si]
     c8a:	00 08                	add    BYTE PTR [bx+si],cl
     c8c:	50                   	push   ax
     c8d:	61                   	popa
     c8e:	6e                   	outs   dx,BYTE PTR ds:[si]
     c8f:	65 6c                	gs ins BYTE PTR es:[di],dx
     c91:	31 32                	xor    WORD PTR [bp+si],si
     c93:	31 e0                	xor    ax,sp
     c95:	03 00                	add    ax,WORD PTR [bx+si]
     c97:	00 08                	add    BYTE PTR [bx+si],cl
     c99:	50                   	push   ax
     c9a:	61                   	popa
     c9b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c9c:	65 6c                	gs ins BYTE PTR es:[di],dx
     c9e:	31 32                	xor    WORD PTR [bp+si],si
     ca0:	32 e4                	xor    ah,ah
     ca2:	03 00                	add    ax,WORD PTR [bx+si]
     ca4:	00 08                	add    BYTE PTR [bx+si],cl
     ca6:	50                   	push   ax
     ca7:	61                   	popa
     ca8:	6e                   	outs   dx,BYTE PTR ds:[si]
     ca9:	65 6c                	gs ins BYTE PTR es:[di],dx
     cab:	31 32                	xor    WORD PTR [bp+si],si
     cad:	33 e8                	xor    bp,ax
     caf:	03 00                	add    ax,WORD PTR [bx+si]
     cb1:	00 08                	add    BYTE PTR [bx+si],cl
     cb3:	50                   	push   ax
     cb4:	61                   	popa
     cb5:	6e                   	outs   dx,BYTE PTR ds:[si]
     cb6:	65 6c                	gs ins BYTE PTR es:[di],dx
     cb8:	31 32                	xor    WORD PTR [bp+si],si
     cba:	34 ec                	xor    al,0xec
     cbc:	03 34                	add    si,WORD PTR [si]
     cbe:	00 09                	add    BYTE PTR [bx+di],cl
     cc0:	44                   	inc    sp
     cc1:	42                   	inc    dx
     cc2:	45                   	inc    bp
     cc3:	64 69 74 31 32 31    	imul   si,WORD PTR fs:[si+0x31],0x3132
     cc9:	f0 03 34             	lock add si,WORD PTR [si]
     ccc:	00 09                	add    BYTE PTR [bx+di],cl
     cce:	44                   	inc    sp
     ccf:	42                   	inc    dx
     cd0:	45                   	inc    bp
     cd1:	64 69 74 31 32 32    	imul   si,WORD PTR fs:[si+0x31],0x3232
     cd7:	f4                   	hlt
     cd8:	03 34                	add    si,WORD PTR [si]
     cda:	00 09                	add    BYTE PTR [bx+di],cl
     cdc:	44                   	inc    sp
     cdd:	42                   	inc    dx
     cde:	45                   	inc    bp
     cdf:	64 69 74 31 32 33    	imul   si,WORD PTR fs:[si+0x31],0x3332
     ce5:	f8                   	clc
     ce6:	03 34                	add    si,WORD PTR [si]
     ce8:	00 09                	add    BYTE PTR [bx+di],cl
     cea:	44                   	inc    sp
     ceb:	42                   	inc    dx
     cec:	45                   	inc    bp
     ced:	64 69 74 31 32 34    	imul   si,WORD PTR fs:[si+0x31],0x3432
     cf3:	fc                   	cld
     cf4:	03 00                	add    ax,WORD PTR [bx+si]
     cf6:	00 08                	add    BYTE PTR [bx+si],cl
     cf8:	50                   	push   ax
     cf9:	61                   	popa
     cfa:	6e                   	outs   dx,BYTE PTR ds:[si]
     cfb:	65 6c                	gs ins BYTE PTR es:[di],dx
     cfd:	31 32                	xor    WORD PTR [bp+si],si
     cff:	35 00 04             	xor    ax,0x400
     d02:	34 00                	xor    al,0x0
     d04:	09 44 42             	or     WORD PTR [si+0x42],ax
     d07:	45                   	inc    bp
     d08:	64 69 74 31 32 35    	imul   si,WORD PTR fs:[si+0x31],0x3532
     d0e:	04 04                	add    al,0x4
     d10:	00 00                	add    BYTE PTR [bx+si],al
     d12:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     d15:	6e                   	outs   dx,BYTE PTR ds:[si]
     d16:	65 6c                	gs ins BYTE PTR es:[di],dx
     d18:	31 31                	xor    WORD PTR [bx+di],si
     d1a:	36 08 04             	or     BYTE PTR ss:[si],al
     d1d:	34 00                	xor    al,0x0
     d1f:	09 44 42             	or     WORD PTR [si+0x42],ax
     d22:	45                   	inc    bp
     d23:	64 69 74 31 31 36    	imul   si,WORD PTR fs:[si+0x31],0x3631
     d29:	0c 04                	or     al,0x4
     d2b:	00 00                	add    BYTE PTR [bx+si],al
     d2d:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     d30:	6e                   	outs   dx,BYTE PTR ds:[si]
     d31:	65 6c                	gs ins BYTE PTR es:[di],dx
     d33:	31 32                	xor    WORD PTR [bp+si],si
     d35:	36 10 04             	adc    BYTE PTR ss:[si],al
     d38:	34 00                	xor    al,0x0
     d3a:	09 44 42             	or     WORD PTR [si+0x42],ax
     d3d:	45                   	inc    bp
     d3e:	64 69 74 31 32 36    	imul   si,WORD PTR fs:[si+0x31],0x3632
     d44:	14 04                	adc    al,0x4
     d46:	2c 00                	sub    al,0x0
     d48:	09 47 72             	or     WORD PTR [bx+0x72],ax
     d4b:	6f                   	outs   dx,WORD PTR ds:[si]
     d4c:	75 70                	jne    0xdbe
     d4e:	42                   	inc    dx
     d4f:	6f                   	outs   dx,WORD PTR ds:[si]
     d50:	78 32                	js     0xd84
     d52:	18 04                	sbb    BYTE PTR [si],al
     d54:	2c 00                	sub    al,0x0
     d56:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     d59:	6f                   	outs   dx,WORD PTR ds:[si]
     d5a:	75 70                	jne    0xdcc
     d5c:	42                   	inc    dx
     d5d:	6f                   	outs   dx,WORD PTR ds:[si]
     d5e:	78 32                	js     0xd92
     d60:	31 1c                	xor    WORD PTR [si],bx
     d62:	04 00                	add    al,0x0
     d64:	00 07                	add    BYTE PTR [bx],al
     d66:	50                   	push   ax
     d67:	61                   	popa
     d68:	6e                   	outs   dx,BYTE PTR ds:[si]
     d69:	65 6c                	gs ins BYTE PTR es:[di],dx
     d6b:	32 38                	xor    bh,BYTE PTR [bx+si]
     d6d:	20 04                	and    BYTE PTR [si],al
     d6f:	30 00                	xor    BYTE PTR [bx+si],al
     d71:	06                   	push   es
     d72:	53                   	push   bx
     d73:	68 61 70             	push   0x7061
     d76:	65 35 24 04          	gs xor ax,0x424
     d7a:	00 00                	add    BYTE PTR [bx+si],al
     d7c:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     d7f:	6e                   	outs   dx,BYTE PTR ds:[si]
     d80:	65 6c                	gs ins BYTE PTR es:[di],dx
     d82:	32 31                	xor    dh,BYTE PTR [bx+di]
     d84:	31 28                	xor    WORD PTR [bx+si],bp
     d86:	04 00                	add    al,0x0
     d88:	00 08                	add    BYTE PTR [bx+si],cl
     d8a:	50                   	push   ax
     d8b:	61                   	popa
     d8c:	6e                   	outs   dx,BYTE PTR ds:[si]
     d8d:	65 6c                	gs ins BYTE PTR es:[di],dx
     d8f:	32 31                	xor    dh,BYTE PTR [bx+di]
     d91:	32 2c                	xor    ch,BYTE PTR [si]
     d93:	04 00                	add    al,0x0
     d95:	00 08                	add    BYTE PTR [bx+si],cl
     d97:	50                   	push   ax
     d98:	61                   	popa
     d99:	6e                   	outs   dx,BYTE PTR ds:[si]
     d9a:	65 6c                	gs ins BYTE PTR es:[di],dx
     d9c:	32 31                	xor    dh,BYTE PTR [bx+di]
     d9e:	33 30                	xor    si,WORD PTR [bx+si]
     da0:	04 00                	add    al,0x0
     da2:	00 08                	add    BYTE PTR [bx+si],cl
     da4:	50                   	push   ax
     da5:	61                   	popa
     da6:	6e                   	outs   dx,BYTE PTR ds:[si]
     da7:	65 6c                	gs ins BYTE PTR es:[di],dx
     da9:	32 31                	xor    dh,BYTE PTR [bx+di]
     dab:	34 34                	xor    al,0x34
     dad:	04 34                	add    al,0x34
     daf:	00 09                	add    BYTE PTR [bx+di],cl
     db1:	44                   	inc    sp
     db2:	42                   	inc    dx
     db3:	45                   	inc    bp
     db4:	64 69 74 32 31 31    	imul   si,WORD PTR fs:[si+0x32],0x3131
     dba:	38 04                	cmp    BYTE PTR [si],al
     dbc:	34 00                	xor    al,0x0
     dbe:	09 44 42             	or     WORD PTR [si+0x42],ax
     dc1:	45                   	inc    bp
     dc2:	64 69 74 32 31 32    	imul   si,WORD PTR fs:[si+0x32],0x3231
     dc8:	3c 04                	cmp    al,0x4
     dca:	34 00                	xor    al,0x0
     dcc:	09 44 42             	or     WORD PTR [si+0x42],ax
     dcf:	45                   	inc    bp
     dd0:	64 69 74 32 31 33    	imul   si,WORD PTR fs:[si+0x32],0x3331
     dd6:	40                   	inc    ax
     dd7:	04 34                	add    al,0x34
     dd9:	00 09                	add    BYTE PTR [bx+di],cl
     ddb:	44                   	inc    sp
     ddc:	42                   	inc    dx
     ddd:	45                   	inc    bp
     dde:	64 69 74 32 31 34    	imul   si,WORD PTR fs:[si+0x32],0x3431
     de4:	44                   	inc    sp
     de5:	04 00                	add    al,0x0
     de7:	00 08                	add    BYTE PTR [bx+si],cl
     de9:	50                   	push   ax
     dea:	61                   	popa
     deb:	6e                   	outs   dx,BYTE PTR ds:[si]
     dec:	65 6c                	gs ins BYTE PTR es:[di],dx
     dee:	32 31                	xor    dh,BYTE PTR [bx+di]
     df0:	37                   	aaa
     df1:	48                   	dec    ax
     df2:	04 34                	add    al,0x34
     df4:	00 09                	add    BYTE PTR [bx+di],cl
     df6:	44                   	inc    sp
     df7:	42                   	inc    dx
     df8:	45                   	inc    bp
     df9:	64 69 74 32 31 37    	imul   si,WORD PTR fs:[si+0x32],0x3731
     dff:	4c                   	dec    sp
     e00:	04 00                	add    al,0x0
     e02:	00 08                	add    BYTE PTR [bx+si],cl
     e04:	50                   	push   ax
     e05:	61                   	popa
     e06:	6e                   	outs   dx,BYTE PTR ds:[si]
     e07:	65 6c                	gs ins BYTE PTR es:[di],dx
     e09:	32 31                	xor    dh,BYTE PTR [bx+di]
     e0b:	35 50 04             	xor    ax,0x450
     e0e:	34 00                	xor    al,0x0
     e10:	09 44 42             	or     WORD PTR [si+0x42],ax
     e13:	45                   	inc    bp
     e14:	64 69 74 32 31 35    	imul   si,WORD PTR fs:[si+0x32],0x3531
     e1a:	54                   	push   sp
     e1b:	04 00                	add    al,0x0
     e1d:	00 08                	add    BYTE PTR [bx+si],cl
     e1f:	50                   	push   ax
     e20:	61                   	popa
     e21:	6e                   	outs   dx,BYTE PTR ds:[si]
     e22:	65 6c                	gs ins BYTE PTR es:[di],dx
     e24:	32 31                	xor    dh,BYTE PTR [bx+di]
     e26:	36 58                	ss pop ax
     e28:	04 34                	add    al,0x34
     e2a:	00 09                	add    BYTE PTR [bx+di],cl
     e2c:	44                   	inc    sp
     e2d:	42                   	inc    dx
     e2e:	45                   	inc    bp
     e2f:	64 69 74 32 31 36    	imul   si,WORD PTR fs:[si+0x32],0x3631
     e35:	5c                   	pop    sp
     e36:	04 2c                	add    al,0x2c
     e38:	00 0a                	add    BYTE PTR [bp+si],cl
     e3a:	47                   	inc    di
     e3b:	72 6f                	jb     0xeac
     e3d:	75 70                	jne    0xeaf
     e3f:	42                   	inc    dx
     e40:	6f                   	outs   dx,WORD PTR ds:[si]
     e41:	78 32                	js     0xe75
     e43:	32 60 04             	xor    ah,BYTE PTR [bx+si+0x4]
     e46:	00 00                	add    BYTE PTR [bx+si],al
     e48:	07                   	pop    es
     e49:	50                   	push   ax
     e4a:	61                   	popa
     e4b:	6e                   	outs   dx,BYTE PTR ds:[si]
     e4c:	65 6c                	gs ins BYTE PTR es:[di],dx
     e4e:	33 35                	xor    si,WORD PTR [di]
     e50:	64 04 30             	fs add al,0x30
     e53:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
     e57:	61                   	popa
     e58:	70 65                	jo     0xebf
     e5a:	36 68 04 00          	ss push 0x4
     e5e:	00 08                	add    BYTE PTR [bx+si],cl
     e60:	50                   	push   ax
     e61:	61                   	popa
     e62:	6e                   	outs   dx,BYTE PTR ds:[si]
     e63:	65 6c                	gs ins BYTE PTR es:[di],dx
     e65:	32 32                	xor    dh,BYTE PTR [bp+si]
     e67:	31 6c 04             	xor    WORD PTR [si+0x4],bp
     e6a:	00 00                	add    BYTE PTR [bx+si],al
     e6c:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e6f:	6e                   	outs   dx,BYTE PTR ds:[si]
     e70:	65 6c                	gs ins BYTE PTR es:[di],dx
     e72:	32 32                	xor    dh,BYTE PTR [bp+si]
     e74:	32 70 04             	xor    dh,BYTE PTR [bx+si+0x4]
     e77:	00 00                	add    BYTE PTR [bx+si],al
     e79:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e7c:	6e                   	outs   dx,BYTE PTR ds:[si]
     e7d:	65 6c                	gs ins BYTE PTR es:[di],dx
     e7f:	32 32                	xor    dh,BYTE PTR [bp+si]
     e81:	33 74 04             	xor    si,WORD PTR [si+0x4]
     e84:	00 00                	add    BYTE PTR [bx+si],al
     e86:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e89:	6e                   	outs   dx,BYTE PTR ds:[si]
     e8a:	65 6c                	gs ins BYTE PTR es:[di],dx
     e8c:	32 32                	xor    dh,BYTE PTR [bp+si]
     e8e:	34 78                	xor    al,0x78
     e90:	04 34                	add    al,0x34
     e92:	00 09                	add    BYTE PTR [bx+di],cl
     e94:	44                   	inc    sp
     e95:	42                   	inc    dx
     e96:	45                   	inc    bp
     e97:	64 69 74 32 32 31    	imul   si,WORD PTR fs:[si+0x32],0x3132
     e9d:	7c 04                	jl     0xea3
     e9f:	34 00                	xor    al,0x0
     ea1:	09 44 42             	or     WORD PTR [si+0x42],ax
     ea4:	45                   	inc    bp
     ea5:	64 69 74 32 32 32    	imul   si,WORD PTR fs:[si+0x32],0x3232
     eab:	80 04 34             	add    BYTE PTR [si],0x34
     eae:	00 09                	add    BYTE PTR [bx+di],cl
     eb0:	44                   	inc    sp
     eb1:	42                   	inc    dx
     eb2:	45                   	inc    bp
     eb3:	64 69 74 32 32 33    	imul   si,WORD PTR fs:[si+0x32],0x3332
     eb9:	84 04                	test   BYTE PTR [si],al
     ebb:	34 00                	xor    al,0x0
     ebd:	09 44 42             	or     WORD PTR [si+0x42],ax
     ec0:	45                   	inc    bp
     ec1:	64 69 74 32 32 34    	imul   si,WORD PTR fs:[si+0x32],0x3432
     ec7:	88 04                	mov    BYTE PTR [si],al
     ec9:	00 00                	add    BYTE PTR [bx+si],al
     ecb:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     ece:	6e                   	outs   dx,BYTE PTR ds:[si]
     ecf:	65 6c                	gs ins BYTE PTR es:[di],dx
     ed1:	32 32                	xor    dh,BYTE PTR [bp+si]
     ed3:	37                   	aaa
     ed4:	8c 04                	mov    WORD PTR [si],es
     ed6:	34 00                	xor    al,0x0
     ed8:	09 44 42             	or     WORD PTR [si+0x42],ax
     edb:	45                   	inc    bp
     edc:	64 69 74 32 32 37    	imul   si,WORD PTR fs:[si+0x32],0x3732
     ee2:	90                   	nop
     ee3:	04 00                	add    al,0x0
     ee5:	00 08                	add    BYTE PTR [bx+si],cl
     ee7:	50                   	push   ax
     ee8:	61                   	popa
     ee9:	6e                   	outs   dx,BYTE PTR ds:[si]
     eea:	65 6c                	gs ins BYTE PTR es:[di],dx
     eec:	32 32                	xor    dh,BYTE PTR [bp+si]
     eee:	35 94 04             	xor    ax,0x494
     ef1:	34 00                	xor    al,0x0
     ef3:	09 44 42             	or     WORD PTR [si+0x42],ax
     ef6:	45                   	inc    bp
     ef7:	64 69 74 32 32 35    	imul   si,WORD PTR fs:[si+0x32],0x3532
     efd:	98                   	cbw
     efe:	04 00                	add    al,0x0
     f00:	00 08                	add    BYTE PTR [bx+si],cl
     f02:	50                   	push   ax
     f03:	61                   	popa
     f04:	6e                   	outs   dx,BYTE PTR ds:[si]
     f05:	65 6c                	gs ins BYTE PTR es:[di],dx
     f07:	32 32                	xor    dh,BYTE PTR [bp+si]
     f09:	36 9c                	ss pushf
     f0b:	04 34                	add    al,0x34
     f0d:	00 09                	add    BYTE PTR [bx+di],cl
     f0f:	44                   	inc    sp
     f10:	42                   	inc    dx
     f11:	45                   	inc    bp
     f12:	64 69 74 32 32 36    	imul   si,WORD PTR fs:[si+0x32],0x3632
     f18:	a0 04 00             	mov    al,ds:0x4
     f1b:	00 08                	add    BYTE PTR [bx+si],cl
     f1d:	50                   	push   ax
     f1e:	61                   	popa
     f1f:	6e                   	outs   dx,BYTE PTR ds:[si]
     f20:	65 6c                	gs ins BYTE PTR es:[di],dx
     f22:	32 31                	xor    dh,BYTE PTR [bx+di]
     f24:	38 a4 04 34          	cmp    BYTE PTR [si+0x3404],ah
     f28:	00 09                	add    BYTE PTR [bx+di],cl
     f2a:	44                   	inc    sp
     f2b:	42                   	inc    dx
     f2c:	45                   	inc    bp
     f2d:	64 69 74 32 31 38    	imul   si,WORD PTR fs:[si+0x32],0x3831
     f33:	a8 04                	test   al,0x4
     f35:	00 00                	add    BYTE PTR [bx+si],al
     f37:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     f3a:	6e                   	outs   dx,BYTE PTR ds:[si]
     f3b:	65 6c                	gs ins BYTE PTR es:[di],dx
     f3d:	32 32                	xor    dh,BYTE PTR [bp+si]
     f3f:	38 ac 04 34          	cmp    BYTE PTR [si+0x3404],ch
     f43:	00 09                	add    BYTE PTR [bx+di],cl
     f45:	44                   	inc    sp
     f46:	42                   	inc    dx
     f47:	45                   	inc    bp
     f48:	64 69 74 32 32 38    	imul   si,WORD PTR fs:[si+0x32],0x3832
     f4e:	b0 04                	mov    al,0x4
     f50:	00 00                	add    BYTE PTR [bx+si],al
     f52:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     f55:	6e                   	outs   dx,BYTE PTR ds:[si]
     f56:	65 6c                	gs ins BYTE PTR es:[di],dx
     f58:	31 31                	xor    WORD PTR [bx+di],si
     f5a:	31 b4 04 34          	xor    WORD PTR [si+0x3404],si
     f5e:	00 09                	add    BYTE PTR [bx+di],cl
     f60:	44                   	inc    sp
     f61:	42                   	inc    dx
     f62:	45                   	inc    bp
     f63:	64 69 74 31 31 31    	imul   si,WORD PTR fs:[si+0x31],0x3131
     f69:	b8 04 14             	mov    ax,0x1404
     f6c:	00 15                	add    BYTE PTR [di],dl
     f6e:	54                   	push   sp
     f6f:	61                   	popa
     f70:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f73:	45                   	inc    bp
     f74:	52                   	push   dx
     f75:	47                   	inc    di
     f76:	52                   	push   dx
     f77:	65 64 75 63          	gs fs jne 0xfde
     f7b:	74 43                	je     0xfc0
     f7d:	61                   	popa
     f7e:	70 69                	jo     0xfe9
     f80:	74 61                	je     0xfe3
     f82:	6c                   	ins    BYTE PTR es:[di],dx
     f83:	bc 04 14             	mov    sp,0x1404
     f86:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     f8a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f8d:	45                   	inc    bp
     f8e:	52                   	push   dx
     f8f:	47                   	inc    di
     f90:	41                   	inc    cx
     f91:	75 67                	jne    0xffa
     f93:	6d                   	ins    WORD PTR es:[di],dx
     f94:	65 6e                	outs   dx,BYTE PTR gs:[si]
     f96:	74 43                	je     0xfdb
     f98:	61                   	popa
     f99:	70 69                	jo     0x1004
     f9b:	74 61                	je     0xffe
     f9d:	6c                   	ins    BYTE PTR es:[di],dx
     f9e:	c0 04 14             	rol    BYTE PTR [si],0x14
     fa1:	00 12                	add    BYTE PTR [bp+si],dl
     fa3:	54                   	push   sp
     fa4:	61                   	popa
     fa5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fa8:	45                   	inc    bp
     fa9:	52                   	push   dx
     faa:	47                   	inc    di
     fab:	45                   	inc    bp
     fac:	6d                   	ins    WORD PTR es:[di],dx
     fad:	70 6c                	jo     0x101b
     faf:	6f                   	outs   dx,WORD PTR ds:[si]
     fb0:	69 73 43 41 46       	imul   si,WORD PTR [bp+di+0x43],0x4641
     fb5:	c4 04                	les    ax,DWORD PTR [si]
     fb7:	14 00                	adc    al,0x0
     fb9:	15 54 61             	adc    ax,0x6154
     fbc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fbf:	45                   	inc    bp
     fc0:	52                   	push   dx
     fc1:	47                   	inc    di
     fc2:	52                   	push   dx
     fc3:	65 73 73             	gs jae 0x1039
     fc6:	6f                   	outs   dx,WORD PTR ds:[si]
     fc7:	75 72                	jne    0x103b
     fc9:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     fcc:	43                   	inc    bx
     fcd:	41                   	inc    cx
     fce:	46                   	inc    si
     fcf:	c8 04 14 00          	enter  0x1404,0x0
     fd3:	17                   	pop    ss
     fd4:	54                   	push   sp
     fd5:	61                   	popa
     fd6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fd9:	45                   	inc    bp
     fda:	52                   	push   dx
     fdb:	47                   	inc    di
     fdc:	52                   	push   dx
     fdd:	65 6d                	gs ins WORD PTR es:[di],dx
     fdf:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
     fe2:	72 73                	jb     0x1057
     fe4:	45                   	inc    bp
     fe5:	6d                   	ins    WORD PTR es:[di],dx
     fe6:	70 72                	jo     0x105a
     fe8:	75 6e                	jne    0x1058
     fea:	74 cc                	je     0xfb8
     fec:	04 14                	add    al,0x14
     fee:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     ff2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ff5:	45                   	inc    bp
     ff6:	52                   	push   dx
     ff7:	47                   	inc    di
     ff8:	45                   	inc    bp
     ff9:	6e                   	outs   dx,BYTE PTR ds:[si]
     ffa:	63 61 69             	arpl   WORD PTR [bx+di+0x69],sp
     ffd:	73 73                	jae    0x1072
     fff:	45                   	inc    bp
    1000:	6d                   	ins    WORD PTR es:[di],dx
    1001:	70 72                	jo     0x1075
    1003:	75 6e                	jne    0x1073
    1005:	74 d0                	je     0xfd7
    1007:	04 14                	add    al,0x14
    1009:	00 18                	add    BYTE PTR [bx+si],bl
    100b:	54                   	push   sp
    100c:	61                   	popa
    100d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1010:	45                   	inc    bp
    1011:	52                   	push   dx
    1012:	47                   	inc    di
    1013:	41                   	inc    cx
    1014:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    1017:	74 73                	je     0x108c
    1019:	44                   	inc    sp
    101a:	65 4d                	gs dec bp
    101c:	61                   	popa
    101d:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1020:	6e                   	outs   dx,BYTE PTR ds:[si]
    1021:	65 73 d4             	gs jae 0xff8
    1024:	04 14                	add    al,0x14
    1026:	00 1a                	add    BYTE PTR [bp+si],bl
    1028:	54                   	push   sp
    1029:	61                   	popa
    102a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    102d:	45                   	inc    bp
    102e:	52                   	push   dx
    102f:	47                   	inc    di
    1030:	43                   	inc    bx
    1031:	65 73 73             	gs jae 0x10a7
    1034:	69 6f 6e 73 44       	imul   bp,WORD PTR [bx+0x6e],0x4473
    1039:	65 4d                	gs dec bp
    103b:	61                   	popa
    103c:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    103f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1040:	65 73 d8             	gs jae 0x101b
    1043:	04 14                	add    al,0x14
    1045:	00 14                	add    BYTE PTR [si],dl
    1047:	54                   	push   sp
    1048:	61                   	popa
    1049:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    104c:	45                   	inc    bp
    104d:	52                   	push   dx
    104e:	47                   	inc    di
    104f:	45                   	inc    bp
    1050:	6d                   	ins    WORD PTR es:[di],dx
    1051:	70 6c                	jo     0x10bf
    1053:	6f                   	outs   dx,WORD PTR ds:[si]
    1054:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    1059:	46                   	inc    si
    105a:	52                   	push   dx
    105b:	dc 04                	fadd   QWORD PTR [si]
    105d:	14 00                	adc    al,0x0
    105f:	17                   	pop    ss
    1060:	54                   	push   sp
    1061:	61                   	popa
    1062:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1065:	45                   	inc    bp
    1066:	52                   	push   dx
    1067:	47                   	inc    di
    1068:	52                   	push   dx
    1069:	65 73 73             	gs jae 0x10df
    106c:	6f                   	outs   dx,WORD PTR ds:[si]
    106d:	75 72                	jne    0x10e1
    106f:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    1072:	56                   	push   si
    1073:	61                   	popa
    1074:	72 46                	jb     0x10bc
    1076:	52                   	push   dx
    1077:	e0 04                	loopne 0x107d
    1079:	14 00                	adc    al,0x0
    107b:	14 54                	adc    al,0x54
    107d:	61                   	popa
    107e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1081:	45                   	inc    bp
    1082:	52                   	push   dx
    1083:	47                   	inc    di
    1084:	45                   	inc    bp
    1085:	6d                   	ins    WORD PTR es:[di],dx
    1086:	6f                   	outs   dx,WORD PTR ds:[si]
    1087:	69 6e 73 52 56       	imul   bp,WORD PTR [bp+0x73],0x5652
    108c:	61                   	popa
    108d:	72 46                	jb     0x10d5
    108f:	52                   	push   dx
    1090:	e4 04                	in     al,0x4
    1092:	14 00                	adc    al,0x0
    1094:	14 54                	adc    al,0x54
    1096:	61                   	popa
    1097:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    109a:	45                   	inc    bp
    109b:	52                   	push   dx
    109c:	47                   	inc    di
    109d:	52                   	push   dx
    109e:	6d                   	ins    WORD PTR es:[di],dx
    109f:	6f                   	outs   dx,WORD PTR ds:[si]
    10a0:	69 6e 73 45 56       	imul   bp,WORD PTR [bp+0x73],0x5645
    10a5:	61                   	popa
    10a6:	72 46                	jb     0x10ee
    10a8:	52                   	push   dx
    10a9:	e8 04 14             	call   0x24b0
    10ac:	00 19                	add    BYTE PTR [bx+di],bl
    10ae:	54                   	push   sp
    10af:	61                   	popa
    10b0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10b3:	45                   	inc    bp
    10b4:	52                   	push   dx
    10b5:	47                   	inc    di
    10b6:	45                   	inc    bp
    10b7:	6d                   	ins    WORD PTR es:[di],dx
    10b8:	70 6c                	jo     0x1126
    10ba:	6f                   	outs   dx,WORD PTR ds:[si]
    10bb:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    10c0:	53                   	push   bx
    10c1:	74 6f                	je     0x1132
    10c3:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    10c6:	31 ec                	xor    sp,bp
    10c8:	04 14                	add    al,0x14
    10ca:	00 19                	add    BYTE PTR [bx+di],bl
    10cc:	54                   	push   sp
    10cd:	61                   	popa
    10ce:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10d1:	45                   	inc    bp
    10d2:	52                   	push   dx
    10d3:	47                   	inc    di
    10d4:	45                   	inc    bp
    10d5:	6d                   	ins    WORD PTR es:[di],dx
    10d6:	70 6c                	jo     0x1144
    10d8:	6f                   	outs   dx,WORD PTR ds:[si]
    10d9:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    10de:	53                   	push   bx
    10df:	74 6f                	je     0x1150
    10e1:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    10e4:	32 f0                	xor    dh,al
    10e6:	04 14                	add    al,0x14
    10e8:	00 1c                	add    BYTE PTR [si],bl
    10ea:	54                   	push   sp
    10eb:	61                   	popa
    10ec:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10ef:	45                   	inc    bp
    10f0:	52                   	push   dx
    10f1:	47                   	inc    di
    10f2:	52                   	push   dx
    10f3:	65 73 73             	gs jae 0x1169
    10f6:	6f                   	outs   dx,WORD PTR ds:[si]
    10f7:	75 72                	jne    0x116b
    10f9:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    10fc:	56                   	push   si
    10fd:	61                   	popa
    10fe:	72 53                	jb     0x1153
    1100:	74 6f                	je     0x1171
    1102:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    1105:	31 f4                	xor    sp,si
    1107:	04 14                	add    al,0x14
    1109:	00 1c                	add    BYTE PTR [si],bl
    110b:	54                   	push   sp
    110c:	61                   	popa
    110d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1110:	45                   	inc    bp
    1111:	52                   	push   dx
    1112:	47                   	inc    di
    1113:	52                   	push   dx
    1114:	65 73 73             	gs jae 0x118a
    1117:	6f                   	outs   dx,WORD PTR ds:[si]
    1118:	75 72                	jne    0x118c
    111a:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    111d:	56                   	push   si
    111e:	61                   	popa
    111f:	72 53                	jb     0x1174
    1121:	74 6f                	je     0x1192
    1123:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    1126:	32 f8                	xor    bh,al
    1128:	04 14                	add    al,0x14
    112a:	00 19                	add    BYTE PTR [bx+di],bl
    112c:	54                   	push   sp
    112d:	61                   	popa
    112e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1131:	45                   	inc    bp
    1132:	52                   	push   dx
    1133:	47                   	inc    di
    1134:	44                   	inc    sp
    1135:	69 6d 69 6e 75       	imul   bp,WORD PTR [di+0x69],0x756e
    113a:	74 43                	je     0x117f
    113c:	72 65                	jb     0x11a3
    113e:	64 69 74 46 6f 75    	imul   si,WORD PTR fs:[si+0x46],0x756f
    1144:	72 fc                	jb     0x1142
    1146:	04 14                	add    al,0x14
    1148:	00 19                	add    BYTE PTR [bx+di],bl
    114a:	54                   	push   sp
    114b:	61                   	popa
    114c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    114f:	45                   	inc    bp
    1150:	52                   	push   dx
    1151:	47                   	inc    di
    1152:	41                   	inc    cx
    1153:	75 67                	jne    0x11bc
    1155:	6d                   	ins    WORD PTR es:[di],dx
    1156:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1158:	74 43                	je     0x119d
    115a:	72 65                	jb     0x11c1
    115c:	64 69 74 46 6f 75    	imul   si,WORD PTR fs:[si+0x46],0x756f
    1162:	72 00                	jb     0x1164
    1164:	05 14 00             	add    ax,0x14
    1167:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
    116a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    116d:	45                   	inc    bp
    116e:	52                   	push   dx
    116f:	47                   	inc    di
    1170:	41                   	inc    cx
    1171:	75 67                	jne    0x11da
    1173:	6d                   	ins    WORD PTR es:[di],dx
    1174:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1176:	74 43                	je     0x11bb
    1178:	72 65                	jb     0x11df
    117a:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    1180:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1182:	74 04                	je     0x1188
    1184:	05 14 00             	add    ax,0x14
    1187:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
    118a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    118d:	45                   	inc    bp
    118e:	52                   	push   dx
    118f:	47                   	inc    di
    1190:	44                   	inc    sp
    1191:	69 6d 69 6e 75       	imul   bp,WORD PTR [di+0x69],0x756e
    1196:	74 43                	je     0x11db
    1198:	72 65                	jb     0x11ff
    119a:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    11a0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    11a2:	74 08                	je     0x11ac
    11a4:	05 14 00             	add    ax,0x14
    11a7:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    11aa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11ad:	45                   	inc    bp
    11ae:	52                   	push   dx
    11af:	47                   	inc    di
    11b0:	44                   	inc    sp
    11b1:	69 6d 69 6e 75       	imul   bp,WORD PTR [di+0x69],0x756e
    11b6:	74 44                	je     0x11fc
    11b8:	65 74 74             	gs je  0x122f
    11bb:	65 73 46             	gs jae 0x1204
    11be:	69 73 63 0c 05       	imul   si,WORD PTR [bp+di+0x63],0x50c
    11c3:	14 00                	adc    al,0x0
    11c5:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    11c8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11cb:	45                   	inc    bp
    11cc:	52                   	push   dx
    11cd:	47                   	inc    di
    11ce:	41                   	inc    cx
    11cf:	75 67                	jne    0x1238
    11d1:	6d                   	ins    WORD PTR es:[di],dx
    11d2:	65 6e                	outs   dx,BYTE PTR gs:[si]
    11d4:	74 44                	je     0x121a
    11d6:	65 74 74             	gs je  0x124d
    11d9:	65 73 46             	gs jae 0x1222
    11dc:	69 73 63 10 05       	imul   si,WORD PTR [bp+di+0x63],0x510
    11e1:	14 00                	adc    al,0x0
    11e3:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    11e6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11e9:	45                   	inc    bp
    11ea:	52                   	push   dx
    11eb:	47                   	inc    di
    11ec:	41                   	inc    cx
    11ed:	75 67                	jne    0x1256
    11ef:	6d                   	ins    WORD PTR es:[di],dx
    11f0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    11f2:	74 54                	je     0x1248
    11f4:	72 65                	jb     0x125b
    11f6:	73 6f                	jae    0x1267
    11f8:	72 65                	jb     0x125f
    11fa:	72 69                	jb     0x1265
    11fc:	65 14 05             	gs adc al,0x5
    11ff:	14 00                	adc    al,0x0
    1201:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1204:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1207:	45                   	inc    bp
    1208:	52                   	push   dx
    1209:	47                   	inc    di
    120a:	44                   	inc    sp
    120b:	69 6d 69 6e 75       	imul   bp,WORD PTR [di+0x69],0x756e
    1210:	74 54                	je     0x1266
    1212:	72 65                	jb     0x1279
    1214:	73 6f                	jae    0x1285
    1216:	72 65                	jb     0x127d
    1218:	72 69                	jb     0x1283
    121a:	65 18 05             	sbb    BYTE PTR gs:[di],al
    121d:	14 00                	adc    al,0x0
    121f:	14 54                	adc    al,0x54
    1221:	61                   	popa
    1222:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1225:	45                   	inc    bp
    1226:	52                   	push   dx
    1227:	47                   	inc    di
    1228:	45                   	inc    bp
    1229:	6d                   	ins    WORD PTR es:[di],dx
    122a:	70 6c                	jo     0x1298
    122c:	6f                   	outs   dx,WORD PTR ds:[si]
    122d:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    1232:	41                   	inc    cx
    1233:	43                   	inc    bx
    1234:	1c 05                	sbb    al,0x5
    1236:	14 00                	adc    al,0x0
    1238:	17                   	pop    ss
    1239:	54                   	push   sp
    123a:	61                   	popa
    123b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    123e:	45                   	inc    bp
    123f:	52                   	push   dx
    1240:	47                   	inc    di
    1241:	52                   	push   dx
    1242:	65 73 73             	gs jae 0x12b8
    1245:	6f                   	outs   dx,WORD PTR ds:[si]
    1246:	75 72                	jne    0x12ba
    1248:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    124b:	56                   	push   si
    124c:	61                   	popa
    124d:	72 41                	jb     0x1290
    124f:	43                   	inc    bx
    1250:	20 05                	and    BYTE PTR [di],al
    1252:	14 00                	adc    al,0x0
    1254:	14 54                	adc    al,0x54
    1256:	61                   	popa
    1257:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    125a:	45                   	inc    bp
    125b:	52                   	push   dx
    125c:	47                   	inc    di
    125d:	45                   	inc    bp
    125e:	6d                   	ins    WORD PTR es:[di],dx
    125f:	6f                   	outs   dx,WORD PTR ds:[si]
    1260:	69 6e 73 52 56       	imul   bp,WORD PTR [bp+0x73],0x5652
    1265:	61                   	popa
    1266:	72 41                	jb     0x12a9
    1268:	43                   	inc    bx
    1269:	24 05                	and    al,0x5
    126b:	14 00                	adc    al,0x0
    126d:	14 54                	adc    al,0x54
    126f:	61                   	popa
    1270:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1273:	45                   	inc    bp
    1274:	52                   	push   dx
    1275:	47                   	inc    di
    1276:	52                   	push   dx
    1277:	6d                   	ins    WORD PTR es:[di],dx
    1278:	6f                   	outs   dx,WORD PTR ds:[si]
    1279:	69 6e 73 45 56       	imul   bp,WORD PTR [bp+0x73],0x5645
    127e:	61                   	popa
    127f:	72 41                	jb     0x12c2
    1281:	43                   	inc    bx
    1282:	28 05                	sub    BYTE PTR [di],al
    1284:	08 00                	or     BYTE PTR [bx+si],al
    1286:	04 53                	add    al,0x53
    1288:	49                   	dec    cx
    1289:	47                   	inc    di
    128a:	31 0e 00 ad          	xor    WORD PTR ds:0xad00,cx
    128e:	0d bf 12             	or     ax,0x12bf
    1291:	ef                   	out    dx,ax
    1292:	02 97 12 94          	add    dl,BYTE PTR [bx-0x6bee]
    1296:	00 64 23             	add    BYTE PTR [si+0x23],ah
    1299:	38 01                	cmp    BYTE PTR [bx+di],al
    129b:	a3 12 c8             	mov    ds:0xc812,ax
    129e:	08 d4                	or     ah,dl
    12a0:	16                   	push   ss
    12a1:	58                   	pop    ax
    12a2:	0a ab 12 7e          	or     ch,BYTE PTR [bp+di+0x7e12]
    12a6:	08 6c 15             	or     BYTE PTR [si+0x15],ch
    12a9:	c8 07 af 12          	enter  0xaf07,0x12
    12ad:	67 0c e6             	addr32 or al,0xe6
    12b0:	16                   	push   ss
    12b1:	17                   	pop    ss
    12b2:	06                   	push   es
    12b3:	b7 12                	mov    bh,0x12
    12b5:	91                   	xchg   cx,ax
    12b6:	12 bb 12 0c          	adc    bh,BYTE PTR [bp+di+0xc12]
    12ba:	01 87 4c 7d          	add    WORD PTR [bx+0x7d4c],ax
    12be:	00 0d                	add    BYTE PTR [di],cl
    12c0:	4e                   	dec    si
    12c1:	22 00                	and    al,BYTE PTR [bx+si]
    12c3:	ba 16 07             	mov    dx,0x716
    12c6:	11 54 46             	adc    WORD PTR [si+0x46],dx
    12c9:	6f                   	outs   dx,WORD PTR ds:[si]
    12ca:	72 6d                	jb     0x1339
    12cc:	53                   	push   bx
    12cd:	45                   	inc    bp
    12ce:	52                   	push   dx
    12cf:	46                   	inc    si
    12d0:	5f                   	pop    di
    12d1:	46                   	inc    si
    12d2:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    12d7:	65 22 00             	and    al,BYTE PTR gs:[bx+si]
    12da:	18 13                	sbb    BYTE PTR [bp+di],dl
    12dc:	7b 06                	jnp    0x12e4
    12de:	09 13                	or     WORD PTR [bp+di],dx
    12e0:	38 00                	cmp    BYTE PTR [bx+si],al
    12e2:	04 53                	add    al,0x53
    12e4:	65 72 66             	gs jb  0x134d
    12e7:	00 00                	add    BYTE PTR [bx+si],al
    12e9:	55                   	push   bp
    12ea:	89 e5                	mov    bp,sp
    12ec:	31 c0                	xor    ax,ax
    12ee:	9a 44 04 23 13       	call   0x1323:0x444
    12f3:	6a 00                	push   0x0
    12f5:	9a c2 38 01 15       	call   0x1501:0x38c2
    12fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12fd:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    1304:	06                   	push   es
    1305:	57                   	push   di
    1306:	9a 56 55 31 13       	call   0x1331:0x5556
    130b:	9a c3 28 4f 17       	call   0x174f:0x28c3
    1310:	c9                   	leave
    1311:	ca 04 00             	retf   0x4
    1314:	00 00                	add    BYTE PTR [bx+si],al
    1316:	c7                   	(bad)
    1317:	13 4b 13             	adc    cx,WORD PTR [bp+di+0x13]
    131a:	55                   	push   bp
    131b:	89 e5                	mov    bp,sp
    131d:	b8 08 00             	mov    ax,0x8
    1320:	9a 44 04 e5 13       	call   0x13e5:0x444
    1325:	83 ec 08             	sub    sp,0x8
    1328:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    132c:	06                   	push   es
    132d:	57                   	push   di
    132e:	9a 03 73 52 13       	call   0x1352:0x7303
    1333:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    1337:	7f 03                	jg     0x133c
    1339:	e9 96 00             	jmp    0x13d2
    133c:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1340:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1344:	b0 01                	mov    al,0x1
    1346:	50                   	push   ax
    1347:	b8 22 00             	mov    ax,0x22
    134a:	ba 86 13             	mov    dx,0x1386
    134d:	52                   	push   dx
    134e:	50                   	push   ax
    134f:	9a 53 25 af 13       	call   0x13af:0x2553
    1354:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1357:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    135a:	b8 14 13             	mov    ax,0x1314
    135d:	0e                   	push   cs
    135e:	50                   	push   ax
    135f:	55                   	push   bp
    1360:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1364:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1368:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    136b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    136e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1371:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1374:	26 89 85 30 05       	mov    WORD PTR es:[di+0x530],ax
    1379:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    137c:	26 89 85 2e 05       	mov    WORD PTR es:[di+0x52e],ax
    1381:	06                   	push   es
    1382:	57                   	push   di
    1383:	9a 0d 20 95 13       	call   0x1395:0x200d
    1388:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    138b:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    1390:	06                   	push   es
    1391:	57                   	push   di
    1392:	9a b3 27 da 13       	call   0x13da:0x27b3
    1397:	6a ff                	push   0xffff
    1399:	6a f0                	push   0xfff0
    139b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    139e:	06                   	push   es
    139f:	57                   	push   di
    13a0:	9a d5 1e 8e 14       	call   0x148e:0x1ed5
    13a5:	6a 02                	push   0x2
    13a7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    13aa:	06                   	push   es
    13ab:	57                   	push   di
    13ac:	9a 14 3a b9 13       	call   0x13b9:0x3a14
    13b1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    13b4:	06                   	push   es
    13b5:	57                   	push   di
    13b6:	9a 45 5d cf 13       	call   0x13cf:0x5d45
    13bb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    13bf:	83 c4 06             	add    sp,0x6
    13c2:	b8 d2 13             	mov    ax,0x13d2
    13c5:	0e                   	push   cs
    13c6:	50                   	push   ax
    13c7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    13ca:	06                   	push   es
    13cb:	57                   	push   di
    13cc:	9a 1d 5f f3 13       	call   0x13f3:0x5f1d
    13d1:	cb                   	retf
    13d2:	c9                   	leave
    13d3:	ca 04 00             	retf   0x4
    13d6:	00 00                	add    BYTE PTR [bx+si],al
    13d8:	1a 15                	sbb    dl,BYTE PTR [di]
    13da:	35 14 55             	xor    ax,0x5514
    13dd:	89 e5                	mov    bp,sp
    13df:	b8 0a 00             	mov    ax,0xa
    13e2:	9a 44 04 31 15       	call   0x1531:0x444
    13e7:	83 ec 0a             	sub    sp,0xa
    13ea:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    13ee:	06                   	push   es
    13ef:	57                   	push   di
    13f0:	9a 03 73 3c 14       	call   0x143c:0x7303
    13f5:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    13f9:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    13fd:	7e 1e                	jle    0x141d
    13ff:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1403:	75 14                	jne    0x1419
    1405:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1409:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    140f:	b0 00                	mov    al,0x0
    1411:	75 01                	jne    0x1414
    1413:	40                   	inc    ax
    1414:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    1417:	eb 04                	jmp    0x141d
    1419:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    141d:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1421:	75 03                	jne    0x1426
    1423:	e9 ff 00             	jmp    0x1525
    1426:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    142a:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    142e:	b0 01                	mov    al,0x1
    1430:	50                   	push   ax
    1431:	b8 22 00             	mov    ax,0x22
    1434:	ba 70 14             	mov    dx,0x1470
    1437:	52                   	push   dx
    1438:	50                   	push   ax
    1439:	9a 53 25 9c 14       	call   0x149c:0x2553
    143e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1441:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1444:	b8 d6 13             	mov    ax,0x13d6
    1447:	0e                   	push   cs
    1448:	50                   	push   ax
    1449:	55                   	push   bp
    144a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    144e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1452:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1455:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1458:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    145b:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    145e:	26 89 85 30 05       	mov    WORD PTR es:[di+0x530],ax
    1463:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1466:	26 89 85 2e 05       	mov    WORD PTR es:[di+0x52e],ax
    146b:	06                   	push   es
    146c:	57                   	push   di
    146d:	9a 0d 20 7f 14       	call   0x147f:0x200d
    1472:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1475:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    147a:	06                   	push   es
    147b:	57                   	push   di
    147c:	9a b3 27 d6 14       	call   0x14d6:0x27b3
    1481:	68 ff 00             	push   0xff
    1484:	6a ff                	push   0xffff
    1486:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1489:	06                   	push   es
    148a:	57                   	push   di
    148b:	9a d5 1e be 14       	call   0x14be:0x1ed5
    1490:	6a 00                	push   0x0
    1492:	6a 00                	push   0x0
    1494:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1497:	06                   	push   es
    1498:	57                   	push   di
    1499:	9a b2 36 a8 14       	call   0x14a8:0x36b2
    149e:	6a 02                	push   0x2
    14a0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    14a3:	06                   	push   es
    14a4:	57                   	push   di
    14a5:	9a 14 3a b4 14       	call   0x14b4:0x3a14
    14aa:	6a 01                	push   0x1
    14ac:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    14af:	06                   	push   es
    14b0:	57                   	push   di
    14b1:	9a e5 34 e3 14       	call   0x14e3:0x34e5
    14b6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    14b9:	06                   	push   es
    14ba:	57                   	push   di
    14bb:	9a b9 62 09 1b       	call   0x1b09:0x62b9
    14c0:	50                   	push   ax
    14c1:	6a 04                	push   0x4
    14c3:	9a ff ff 00 00       	call   0x0:0xffff
    14c8:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    14cc:	74 0c                	je     0x14da
    14ce:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14d1:	06                   	push   es
    14d2:	57                   	push   di
    14d3:	9a 32 48 45 15       	call   0x1545:0x4832
    14d8:	eb 34                	jmp    0x150e
    14da:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    14de:	06                   	push   es
    14df:	57                   	push   di
    14e0:	9a 03 73 0c 15       	call   0x150c:0x7303
    14e5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14e8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    14eb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14ee:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    14f3:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    14f8:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    14fc:	06                   	push   es
    14fd:	57                   	push   di
    14fe:	9a 1a 31 a6 15       	call   0x15a6:0x311a
    1503:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1507:	06                   	push   es
    1508:	57                   	push   di
    1509:	9a 03 73 22 15       	call   0x1522:0x7303
    150e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1512:	83 c4 06             	add    sp,0x6
    1515:	b8 25 15             	mov    ax,0x1525
    1518:	0e                   	push   cs
    1519:	50                   	push   ax
    151a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    151d:	06                   	push   es
    151e:	57                   	push   di
    151f:	9a 1d 5f 97 15       	call   0x1597:0x5f1d
    1524:	cb                   	retf
    1525:	c9                   	leave
    1526:	ca 06 00             	retf   0x6
    1529:	55                   	push   bp
    152a:	89 e5                	mov    bp,sp
    152c:	31 c0                	xor    ax,ax
    152e:	9a 44 04 5a 15       	call   0x155a:0x444
    1533:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1536:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    153b:	26 ff b5 30 05       	push   WORD PTR es:[di+0x530]
    1540:	6a 00                	push   0x0
    1542:	9a dc 13 4f 15       	call   0x154f:0x13dc
    1547:	c9                   	leave
    1548:	ca 08 00             	retf   0x8
    154b:	00 00                	add    BYTE PTR [bx+si],al
    154d:	0c 16                	or     al,0x16
    154f:	e0 15                	loopne 0x1566
    1551:	55                   	push   bp
    1552:	89 e5                	mov    bp,sp
    1554:	b8 08 00             	mov    ax,0x8
    1557:	9a 44 04 5b 16       	call   0x165b:0x444
    155c:	83 ec 08             	sub    sp,0x8
    155f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1562:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1567:	06                   	push   es
    1568:	57                   	push   di
    1569:	9a 17 2f ba 47       	call   0x47ba:0x2f17
    156e:	08 c0                	or     al,al
    1570:	75 03                	jne    0x1575
    1572:	e9 b3 00             	jmp    0x1628
    1575:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1578:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    157d:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    1582:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1585:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1588:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    158d:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    1592:	06                   	push   es
    1593:	57                   	push   di
    1594:	9a d0 3f ad 15       	call   0x15ad:0x3fd0
    1599:	ff 76 08             	push   WORD PTR [bp+0x8]
    159c:	ff 76 06             	push   WORD PTR [bp+0x6]
    159f:	b0 01                	mov    al,0x1
    15a1:	50                   	push   ax
    15a2:	b8 b4 25             	mov    ax,0x25b4
    15a5:	ba d5 15             	mov    dx,0x15d5
    15a8:	52                   	push   dx
    15a9:	50                   	push   ax
    15aa:	9a 53 25 fe 15       	call   0x15fe:0x2553
    15af:	a3 04 20             	mov    ds:0x2004,ax
    15b2:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    15b6:	b8 4b 15             	mov    ax,0x154b
    15b9:	0e                   	push   cs
    15ba:	50                   	push   ax
    15bb:	55                   	push   bp
    15bc:	ff 36 58 18          	push   WORD PTR ds:0x1858
    15c0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    15c4:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    15c8:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    15cb:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    15ce:	6a 01                	push   0x1
    15d0:	06                   	push   es
    15d1:	57                   	push   di
    15d2:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    15d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15da:	06                   	push   es
    15db:	57                   	push   di
    15dc:	b8 29 15             	mov    ax,0x1529
    15df:	ba ff 1f             	mov    dx,0x1fff
    15e2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    15e5:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    15ea:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    15ef:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    15f4:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    15f9:	06                   	push   es
    15fa:	57                   	push   di
    15fb:	9a 45 5d 15 16       	call   0x1615:0x5d45
    1600:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1604:	83 c4 06             	add    sp,0x6
    1607:	b8 18 16             	mov    ax,0x1618
    160a:	0e                   	push   cs
    160b:	50                   	push   ax
    160c:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1610:	06                   	push   es
    1611:	57                   	push   di
    1612:	9a 1d 5f 26 16       	call   0x1626:0x5f1d
    1617:	cb                   	retf
    1618:	ff 76 fe             	push   WORD PTR [bp-0x2]
    161b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    161e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1621:	06                   	push   es
    1622:	57                   	push   di
    1623:	9a d0 3f 74 16       	call   0x1674:0x3fd0
    1628:	c9                   	leave
    1629:	ca 08 00             	retf   0x8
    162c:	0a 23                	or     ah,BYTE PTR [bp+di]
    162e:	2c 23                	sub    al,0x23
    1630:	23 30                	and    si,WORD PTR [bx+si]
    1632:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1635:	23 23                	and    sp,WORD PTR [bp+di]
    1637:	07                   	pop    es
    1638:	23 30                	and    si,WORD PTR [bx+si]
    163a:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    163d:	23 23                	and    sp,WORD PTR [bp+di]
    163f:	07                   	pop    es
    1640:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    1644:	2b 30                	sub    si,WORD PTR [bx+si]
    1646:	30 01                	xor    BYTE PTR [bx+di],al
    1648:	30 05                	xor    BYTE PTR [di],al
    164a:	23 2c                	and    bp,WORD PTR [si]
    164c:	23 23                	and    sp,WORD PTR [bp+di]
    164e:	30 02                	xor    BYTE PTR [bp+si],al
    1650:	23 30                	and    si,WORD PTR [bx+si]
    1652:	55                   	push   bp
    1653:	89 e5                	mov    bp,sp
    1655:	b8 14 03             	mov    ax,0x314
    1658:	9a 44 04 ed 16       	call   0x16ed:0x444
    165d:	81 ec 14 03          	sub    sp,0x314
    1661:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1664:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    1668:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    166c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    166f:	06                   	push   es
    1670:	57                   	push   di
    1671:	9a d5 33 9e 16       	call   0x169e:0x33d5
    1676:	89 c7                	mov    di,ax
    1678:	8e c2                	mov    es,dx
    167a:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    167e:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    1682:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    1686:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    168a:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    168e:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1692:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1696:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1699:	06                   	push   es
    169a:	57                   	push   di
    169b:	9a d5 33 6d 17       	call   0x176d:0x33d5
    16a0:	89 c7                	mov    di,ax
    16a2:	8e c2                	mov    es,dx
    16a4:	06                   	push   es
    16a5:	57                   	push   di
    16a6:	9a 99 20 78 17       	call   0x1778:0x2099
    16ab:	8d be f4 fc          	lea    di,[bp-0x30c]
    16af:	16                   	push   ss
    16b0:	57                   	push   di
    16b1:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    16b5:	06                   	push   es
    16b6:	57                   	push   di
    16b7:	9a 9f 1a c5 16       	call   0x16c5:0x1a9f
    16bc:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    16c0:	06                   	push   es
    16c1:	57                   	push   di
    16c2:	9a 5f 1a d6 1a       	call   0x1ad6:0x1a5f
    16c7:	89 c7                	mov    di,ax
    16c9:	8e c2                	mov    es,dx
    16cb:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    16cf:	06                   	push   es
    16d0:	57                   	push   di
    16d1:	9a 9b 3b 5c 1c       	call   0x1c5c:0x3b9b
    16d6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    16d9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    16dc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    16df:	ff 76 fc             	push   WORD PTR [bp-0x4]
    16e2:	bf 58 0a             	mov    di,0xa58
    16e5:	b8 00 17             	mov    ax,0x1700
    16e8:	50                   	push   ax
    16e9:	57                   	push   di
    16ea:	9a 55 22 07 17       	call   0x1707:0x2255
    16ef:	08 c0                	or     al,al
    16f1:	75 03                	jne    0x16f6
    16f3:	e9 bb 01             	jmp    0x18b1
    16f6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    16f9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    16fc:	bf 58 0a             	mov    di,0xa58
    16ff:	b8 ac 18             	mov    ax,0x18ac
    1702:	50                   	push   ax
    1703:	57                   	push   di
    1704:	9a 73 22 26 17       	call   0x1726:0x2273
    1709:	89 c7                	mov    di,ax
    170b:	8e c2                	mov    es,dx
    170d:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1711:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1715:	bf 2c 16             	mov    di,0x162c
    1718:	0e                   	push   cs
    1719:	57                   	push   di
    171a:	8d be fc fd          	lea    di,[bp-0x204]
    171e:	16                   	push   ss
    171f:	57                   	push   di
    1720:	68 ff 00             	push   0xff
    1723:	9a e7 17 5d 17       	call   0x175d:0x17e7
    1728:	8d be f0 fc          	lea    di,[bp-0x310]
    172c:	16                   	push   ss
    172d:	57                   	push   di
    172e:	8d be fc fd          	lea    di,[bp-0x204]
    1732:	16                   	push   ss
    1733:	57                   	push   di
    1734:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1738:	06                   	push   es
    1739:	57                   	push   di
    173a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    173d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1741:	83 ec 0a             	sub    sp,0xa
    1744:	89 e3                	mov    bx,sp
    1746:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    174a:	90                   	nop
    174b:	9b                   	fwait
    174c:	9a d4 10 cf 17       	call   0x17cf:0x10d4
    1751:	8d be fc fe          	lea    di,[bp-0x104]
    1755:	16                   	push   ss
    1756:	57                   	push   di
    1757:	68 ff 00             	push   0xff
    175a:	9a e7 17 8c 17       	call   0x178c:0x17e7
    175f:	8d be fc fe          	lea    di,[bp-0x104]
    1763:	16                   	push   ss
    1764:	57                   	push   di
    1765:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1768:	06                   	push   es
    1769:	57                   	push   di
    176a:	9a d5 33 ed 17       	call   0x17ed:0x33d5
    176f:	89 c7                	mov    di,ax
    1771:	8e c2                	mov    es,dx
    1773:	06                   	push   es
    1774:	57                   	push   di
    1775:	9a 03 20 f8 17       	call   0x17f8:0x2003
    177a:	8b d0                	mov    dx,ax
    177c:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1780:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1784:	2d 05 00             	sub    ax,0x5
    1787:	71 05                	jno    0x178e
    1789:	9a 3e 04 a6 17       	call   0x17a6:0x43e
    178e:	3b c2                	cmp    ax,dx
    1790:	7e 03                	jle    0x1795
    1792:	e9 08 01             	jmp    0x189d
    1795:	bf 37 16             	mov    di,0x1637
    1798:	0e                   	push   cs
    1799:	57                   	push   di
    179a:	8d be fc fd          	lea    di,[bp-0x204]
    179e:	16                   	push   ss
    179f:	57                   	push   di
    17a0:	68 ff 00             	push   0xff
    17a3:	9a e7 17 dd 17       	call   0x17dd:0x17e7
    17a8:	8d be f0 fc          	lea    di,[bp-0x310]
    17ac:	16                   	push   ss
    17ad:	57                   	push   di
    17ae:	8d be fc fd          	lea    di,[bp-0x204]
    17b2:	16                   	push   ss
    17b3:	57                   	push   di
    17b4:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    17b8:	06                   	push   es
    17b9:	57                   	push   di
    17ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17bd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    17c1:	83 ec 0a             	sub    sp,0xa
    17c4:	89 e3                	mov    bx,sp
    17c6:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    17ca:	90                   	nop
    17cb:	9b                   	fwait
    17cc:	9a d4 10 31 19       	call   0x1931:0x10d4
    17d1:	8d be fc fe          	lea    di,[bp-0x104]
    17d5:	16                   	push   ss
    17d6:	57                   	push   di
    17d7:	68 ff 00             	push   0xff
    17da:	9a e7 17 0c 18       	call   0x180c:0x17e7
    17df:	8d be fc fe          	lea    di,[bp-0x104]
    17e3:	16                   	push   ss
    17e4:	57                   	push   di
    17e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e8:	06                   	push   es
    17e9:	57                   	push   di
    17ea:	9a d5 33 36 18       	call   0x1836:0x33d5
    17ef:	89 c7                	mov    di,ax
    17f1:	8e c2                	mov    es,dx
    17f3:	06                   	push   es
    17f4:	57                   	push   di
    17f5:	9a 03 20 41 18       	call   0x1841:0x2003
    17fa:	8b d0                	mov    dx,ax
    17fc:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1800:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1804:	2d 05 00             	sub    ax,0x5
    1807:	71 05                	jno    0x180e
    1809:	9a 3e 04 26 18       	call   0x1826:0x43e
    180e:	3b c2                	cmp    ax,dx
    1810:	7e 03                	jle    0x1815
    1812:	e9 88 00             	jmp    0x189d
    1815:	bf 3f 16             	mov    di,0x163f
    1818:	0e                   	push   cs
    1819:	57                   	push   di
    181a:	8d be fc fd          	lea    di,[bp-0x204]
    181e:	16                   	push   ss
    181f:	57                   	push   di
    1820:	68 ff 00             	push   0xff
    1823:	9a e7 17 55 18       	call   0x1855:0x17e7
    1828:	8d be fc fd          	lea    di,[bp-0x204]
    182c:	16                   	push   ss
    182d:	57                   	push   di
    182e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1831:	06                   	push   es
    1832:	57                   	push   di
    1833:	9a d5 33 4f 19       	call   0x194f:0x33d5
    1838:	89 c7                	mov    di,ax
    183a:	8e c2                	mov    es,dx
    183c:	06                   	push   es
    183d:	57                   	push   di
    183e:	9a 03 20 5a 19       	call   0x195a:0x2003
    1843:	8b d0                	mov    dx,ax
    1845:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1849:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    184d:	2d 05 00             	sub    ax,0x5
    1850:	71 05                	jno    0x1857
    1852:	9a 3e 04 83 18       	call   0x1883:0x43e
    1857:	3b c2                	cmp    ax,dx
    1859:	b0 00                	mov    al,0x0
    185b:	7e 01                	jle    0x185e
    185d:	40                   	inc    ax
    185e:	8a d0                	mov    dl,al
    1860:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1865:	b0 00                	mov    al,0x0
    1867:	73 01                	jae    0x186a
    1869:	40                   	inc    ax
    186a:	22 c2                	and    al,dl
    186c:	08 c0                	or     al,al
    186e:	74 17                	je     0x1887
    1870:	bf 47 16             	mov    di,0x1647
    1873:	0e                   	push   cs
    1874:	57                   	push   di
    1875:	8d be fc fd          	lea    di,[bp-0x204]
    1879:	16                   	push   ss
    187a:	57                   	push   di
    187b:	68 ff 00             	push   0xff
    187e:	6a 03                	push   0x3
    1880:	9a 16 19 9b 18       	call   0x189b:0x1916
    1885:	eb a1                	jmp    0x1828
    1887:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    188c:	76 0f                	jbe    0x189d
    188e:	8d be fc fd          	lea    di,[bp-0x204]
    1892:	16                   	push   ss
    1893:	57                   	push   di
    1894:	6a 03                	push   0x3
    1896:	6a 01                	push   0x1
    1898:	9a 75 19 c2 18       	call   0x18c2:0x1975
    189d:	8d be fc fd          	lea    di,[bp-0x204]
    18a1:	16                   	push   ss
    18a2:	57                   	push   di
    18a3:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    18a7:	06                   	push   es
    18a8:	57                   	push   di
    18a9:	9a f9 60 bb 18       	call   0x18bb:0x60f9
    18ae:	e9 ec 01             	jmp    0x1a9d
    18b1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    18b4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    18b7:	bf c8 07             	mov    di,0x7c8
    18ba:	b8 d5 18             	mov    ax,0x18d5
    18bd:	50                   	push   ax
    18be:	57                   	push   di
    18bf:	9a 55 22 dc 18       	call   0x18dc:0x2255
    18c4:	08 c0                	or     al,al
    18c6:	75 03                	jne    0x18cb
    18c8:	e9 d2 01             	jmp    0x1a9d
    18cb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    18ce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    18d1:	bf c8 07             	mov    di,0x7c8
    18d4:	b8 9b 1a             	mov    ax,0x1a9b
    18d7:	50                   	push   ax
    18d8:	57                   	push   di
    18d9:	9a 73 22 fb 18       	call   0x18fb:0x2273
    18de:	89 c7                	mov    di,ax
    18e0:	8e c2                	mov    es,dx
    18e2:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    18e6:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    18ea:	bf 49 16             	mov    di,0x1649
    18ed:	0e                   	push   cs
    18ee:	57                   	push   di
    18ef:	8d be fc fd          	lea    di,[bp-0x204]
    18f3:	16                   	push   ss
    18f4:	57                   	push   di
    18f5:	68 ff 00             	push   0xff
    18f8:	9a e7 17 3f 19       	call   0x193f:0x17e7
    18fd:	8d be ec fc          	lea    di,[bp-0x314]
    1901:	16                   	push   ss
    1902:	57                   	push   di
    1903:	8d be fc fd          	lea    di,[bp-0x204]
    1907:	16                   	push   ss
    1908:	57                   	push   di
    1909:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    190d:	06                   	push   es
    190e:	57                   	push   di
    190f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1912:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1916:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    191a:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    191e:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1923:	83 ec 0a             	sub    sp,0xa
    1926:	89 e3                	mov    bx,sp
    1928:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    192c:	90                   	nop
    192d:	9b                   	fwait
    192e:	9a d4 10 be 19       	call   0x19be:0x10d4
    1933:	8d be fc fe          	lea    di,[bp-0x104]
    1937:	16                   	push   ss
    1938:	57                   	push   di
    1939:	68 ff 00             	push   0xff
    193c:	9a e7 17 6e 19       	call   0x196e:0x17e7
    1941:	8d be fc fe          	lea    di,[bp-0x104]
    1945:	16                   	push   ss
    1946:	57                   	push   di
    1947:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    194a:	06                   	push   es
    194b:	57                   	push   di
    194c:	9a d5 33 dc 19       	call   0x19dc:0x33d5
    1951:	89 c7                	mov    di,ax
    1953:	8e c2                	mov    es,dx
    1955:	06                   	push   es
    1956:	57                   	push   di
    1957:	9a 03 20 e7 19       	call   0x19e7:0x2003
    195c:	8b d0                	mov    dx,ax
    195e:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1962:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1966:	2d 05 00             	sub    ax,0x5
    1969:	71 05                	jno    0x1970
    196b:	9a 3e 04 88 19       	call   0x1988:0x43e
    1970:	3b c2                	cmp    ax,dx
    1972:	7e 03                	jle    0x1977
    1974:	e9 15 01             	jmp    0x1a8c
    1977:	bf 4f 16             	mov    di,0x164f
    197a:	0e                   	push   cs
    197b:	57                   	push   di
    197c:	8d be fc fd          	lea    di,[bp-0x204]
    1980:	16                   	push   ss
    1981:	57                   	push   di
    1982:	68 ff 00             	push   0xff
    1985:	9a e7 17 cc 19       	call   0x19cc:0x17e7
    198a:	8d be ec fc          	lea    di,[bp-0x314]
    198e:	16                   	push   ss
    198f:	57                   	push   di
    1990:	8d be fc fd          	lea    di,[bp-0x204]
    1994:	16                   	push   ss
    1995:	57                   	push   di
    1996:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    199a:	06                   	push   es
    199b:	57                   	push   di
    199c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    199f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    19a3:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    19a7:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    19ab:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    19b0:	83 ec 0a             	sub    sp,0xa
    19b3:	89 e3                	mov    bx,sp
    19b5:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    19b9:	90                   	nop
    19ba:	9b                   	fwait
    19bb:	9a d4 10 c0 1c       	call   0x1cc0:0x10d4
    19c0:	8d be fc fe          	lea    di,[bp-0x104]
    19c4:	16                   	push   ss
    19c5:	57                   	push   di
    19c6:	68 ff 00             	push   0xff
    19c9:	9a e7 17 fb 19       	call   0x19fb:0x17e7
    19ce:	8d be fc fe          	lea    di,[bp-0x104]
    19d2:	16                   	push   ss
    19d3:	57                   	push   di
    19d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d7:	06                   	push   es
    19d8:	57                   	push   di
    19d9:	9a d5 33 25 1a       	call   0x1a25:0x33d5
    19de:	89 c7                	mov    di,ax
    19e0:	8e c2                	mov    es,dx
    19e2:	06                   	push   es
    19e3:	57                   	push   di
    19e4:	9a 03 20 30 1a       	call   0x1a30:0x2003
    19e9:	8b d0                	mov    dx,ax
    19eb:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    19ef:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    19f3:	2d 05 00             	sub    ax,0x5
    19f6:	71 05                	jno    0x19fd
    19f8:	9a 3e 04 15 1a       	call   0x1a15:0x43e
    19fd:	3b c2                	cmp    ax,dx
    19ff:	7e 03                	jle    0x1a04
    1a01:	e9 88 00             	jmp    0x1a8c
    1a04:	bf 3f 16             	mov    di,0x163f
    1a07:	0e                   	push   cs
    1a08:	57                   	push   di
    1a09:	8d be fc fd          	lea    di,[bp-0x204]
    1a0d:	16                   	push   ss
    1a0e:	57                   	push   di
    1a0f:	68 ff 00             	push   0xff
    1a12:	9a e7 17 44 1a       	call   0x1a44:0x17e7
    1a17:	8d be fc fd          	lea    di,[bp-0x204]
    1a1b:	16                   	push   ss
    1a1c:	57                   	push   di
    1a1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a20:	06                   	push   es
    1a21:	57                   	push   di
    1a22:	9a d5 33 b1 1a       	call   0x1ab1:0x33d5
    1a27:	89 c7                	mov    di,ax
    1a29:	8e c2                	mov    es,dx
    1a2b:	06                   	push   es
    1a2c:	57                   	push   di
    1a2d:	9a 03 20 bc 1a       	call   0x1abc:0x2003
    1a32:	8b d0                	mov    dx,ax
    1a34:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a38:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1a3c:	2d 05 00             	sub    ax,0x5
    1a3f:	71 05                	jno    0x1a46
    1a41:	9a 3e 04 72 1a       	call   0x1a72:0x43e
    1a46:	3b c2                	cmp    ax,dx
    1a48:	b0 00                	mov    al,0x0
    1a4a:	7e 01                	jle    0x1a4d
    1a4c:	40                   	inc    ax
    1a4d:	8a d0                	mov    dl,al
    1a4f:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1a54:	b0 00                	mov    al,0x0
    1a56:	73 01                	jae    0x1a59
    1a58:	40                   	inc    ax
    1a59:	22 c2                	and    al,dl
    1a5b:	08 c0                	or     al,al
    1a5d:	74 17                	je     0x1a76
    1a5f:	bf 47 16             	mov    di,0x1647
    1a62:	0e                   	push   cs
    1a63:	57                   	push   di
    1a64:	8d be fc fd          	lea    di,[bp-0x204]
    1a68:	16                   	push   ss
    1a69:	57                   	push   di
    1a6a:	68 ff 00             	push   0xff
    1a6d:	6a 03                	push   0x3
    1a6f:	9a 16 19 8a 1a       	call   0x1a8a:0x1916
    1a74:	eb a1                	jmp    0x1a17
    1a76:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1a7b:	76 0f                	jbe    0x1a8c
    1a7d:	8d be fc fd          	lea    di,[bp-0x204]
    1a81:	16                   	push   ss
    1a82:	57                   	push   di
    1a83:	6a 03                	push   0x3
    1a85:	6a 01                	push   0x1
    1a87:	9a 75 19 ca 1a       	call   0x1aca:0x1975
    1a8c:	8d be fc fd          	lea    di,[bp-0x204]
    1a90:	16                   	push   ss
    1a91:	57                   	push   di
    1a92:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1a96:	06                   	push   es
    1a97:	57                   	push   di
    1a98:	9a f9 60 6e 1c       	call   0x1c6e:0x60f9
    1a9d:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1aa1:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1aa5:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1aa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aac:	06                   	push   es
    1aad:	57                   	push   di
    1aae:	9a d5 33 d5 1b       	call   0x1bd5:0x33d5
    1ab3:	89 c7                	mov    di,ax
    1ab5:	8e c2                	mov    es,dx
    1ab7:	06                   	push   es
    1ab8:	57                   	push   di
    1ab9:	9a 99 20 38 1e       	call   0x1e38:0x2099
    1abe:	c9                   	leave
    1abf:	ca 08 00             	retf   0x8
    1ac2:	55                   	push   bp
    1ac3:	89 e5                	mov    bp,sp
    1ac5:	31 c0                	xor    ax,ax
    1ac7:	9a 44 04 dd 1a       	call   0x1add:0x444
    1acc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1acf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ad2:	bf a2 0b             	mov    di,0xba2
    1ad5:	b8 ea 1a             	mov    ax,0x1aea
    1ad8:	50                   	push   ax
    1ad9:	57                   	push   di
    1ada:	9a 55 22 f1 1a       	call   0x1af1:0x2255
    1adf:	50                   	push   ax
    1ae0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ae3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ae6:	bf 22 00             	mov    di,0x22
    1ae9:	b8 2c 1b             	mov    ax,0x1b2c
    1aec:	50                   	push   ax
    1aed:	57                   	push   di
    1aee:	9a 55 22 17 1b       	call   0x1b17:0x2255
    1af3:	5a                   	pop    dx
    1af4:	0a c2                	or     al,dl
    1af6:	08 c0                	or     al,al
    1af8:	74 11                	je     0x1b0b
    1afa:	6a 00                	push   0x0
    1afc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aff:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1b04:	06                   	push   es
    1b05:	57                   	push   di
    1b06:	9a 77 1c 5f 1b       	call   0x1b5f:0x1c77
    1b0b:	c9                   	leave
    1b0c:	ca 08 00             	retf   0x8
    1b0f:	55                   	push   bp
    1b10:	89 e5                	mov    bp,sp
    1b12:	31 c0                	xor    ax,ax
    1b14:	9a 44 04 33 1b       	call   0x1b33:0x444
    1b19:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1b1c:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    1b20:	75 3f                	jne    0x1b61
    1b22:	ff 76 12             	push   WORD PTR [bp+0x12]
    1b25:	ff 76 10             	push   WORD PTR [bp+0x10]
    1b28:	bf a2 0b             	mov    di,0xba2
    1b2b:	b8 40 1b             	mov    ax,0x1b40
    1b2e:	50                   	push   ax
    1b2f:	57                   	push   di
    1b30:	9a 55 22 47 1b       	call   0x1b47:0x2255
    1b35:	50                   	push   ax
    1b36:	ff 76 12             	push   WORD PTR [bp+0x12]
    1b39:	ff 76 10             	push   WORD PTR [bp+0x10]
    1b3c:	bf 22 00             	mov    di,0x22
    1b3f:	b8 04 1c             	mov    ax,0x1c04
    1b42:	50                   	push   ax
    1b43:	57                   	push   di
    1b44:	9a 55 22 7b 1b       	call   0x1b7b:0x2255
    1b49:	5a                   	pop    dx
    1b4a:	0a c2                	or     al,dl
    1b4c:	08 c0                	or     al,al
    1b4e:	74 11                	je     0x1b61
    1b50:	6a 00                	push   0x0
    1b52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b55:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1b5a:	06                   	push   es
    1b5b:	57                   	push   di
    1b5c:	9a 77 1c 94 1b       	call   0x1b94:0x1c77
    1b61:	c9                   	leave
    1b62:	ca 0e 00             	retf   0xe
    1b65:	0a 23                	or     ah,BYTE PTR [bp+di]
    1b67:	2c 23                	sub    al,0x23
    1b69:	23 30                	and    si,WORD PTR [bx+si]
    1b6b:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1b6e:	23 23                	and    sp,WORD PTR [bp+di]
    1b70:	01 20                	add    WORD PTR [bx+si],sp
    1b72:	55                   	push   bp
    1b73:	89 e5                	mov    bp,sp
    1b75:	b8 10 02             	mov    ax,0x210
    1b78:	9a 44 04 9b 1b       	call   0x1b9b:0x444
    1b7d:	81 ec 10 02          	sub    sp,0x210
    1b81:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1b84:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    1b88:	75 4d                	jne    0x1bd7
    1b8a:	ff 76 12             	push   WORD PTR [bp+0x12]
    1b8d:	ff 76 10             	push   WORD PTR [bp+0x10]
    1b90:	bf c1 05             	mov    di,0x5c1
    1b93:	b8 b5 1b             	mov    ax,0x1bb5
    1b96:	50                   	push   ax
    1b97:	57                   	push   di
    1b98:	9a 55 22 bc 1b       	call   0x1bbc:0x2255
    1b9d:	08 c0                	or     al,al
    1b9f:	74 36                	je     0x1bd7
    1ba1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1ba4:	31 c0                	xor    ax,ax
    1ba6:	26 89 05             	mov    WORD PTR es:[di],ax
    1ba9:	6a 08                	push   0x8
    1bab:	ff 76 12             	push   WORD PTR [bp+0x12]
    1bae:	ff 76 10             	push   WORD PTR [bp+0x10]
    1bb1:	bf c1 05             	mov    di,0x5c1
    1bb4:	b8 2a 1d             	mov    ax,0x1d2a
    1bb7:	50                   	push   ax
    1bb8:	57                   	push   di
    1bb9:	9a 73 22 0b 1c       	call   0x1c0b:0x2273
    1bbe:	89 c7                	mov    di,ax
    1bc0:	8e c2                	mov    es,dx
    1bc2:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    1bc7:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    1bcc:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1bd0:	06                   	push   es
    1bd1:	57                   	push   di
    1bd2:	9a b2 77 11 1e       	call   0x1e11:0x77b2
    1bd7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1bda:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    1bde:	74 03                	je     0x1be3
    1be0:	e9 9e 03             	jmp    0x1f81
    1be3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1be6:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1beb:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1bf0:	74 03                	je     0x1bf5
    1bf2:	e9 8c 03             	jmp    0x1f81
    1bf5:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    1bfa:	ff 76 12             	push   WORD PTR [bp+0x12]
    1bfd:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c00:	bf 22 00             	mov    di,0x22
    1c03:	b8 1e 1c             	mov    ax,0x1c1e
    1c06:	50                   	push   ax
    1c07:	57                   	push   di
    1c08:	9a 55 22 25 1c       	call   0x1c25:0x2255
    1c0d:	08 c0                	or     al,al
    1c0f:	75 03                	jne    0x1c14
    1c11:	e9 1e 01             	jmp    0x1d32
    1c14:	ff 76 12             	push   WORD PTR [bp+0x12]
    1c17:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c1a:	bf 22 00             	mov    di,0x22
    1c1d:	b8 42 1c             	mov    ax,0x1c42
    1c20:	50                   	push   ax
    1c21:	57                   	push   di
    1c22:	9a 73 22 75 1c       	call   0x1c75:0x2273
    1c27:	89 c7                	mov    di,ax
    1c29:	8e c2                	mov    es,dx
    1c2b:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1c2f:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1c33:	8d be f4 fd          	lea    di,[bp-0x20c]
    1c37:	16                   	push   ss
    1c38:	57                   	push   di
    1c39:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1c3d:	06                   	push   es
    1c3e:	57                   	push   di
    1c3f:	9a 9f 1a 4d 1c       	call   0x1c4d:0x1a9f
    1c44:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1c48:	06                   	push   es
    1c49:	57                   	push   di
    1c4a:	9a 5f 1a 3c 1d       	call   0x1d3c:0x1a5f
    1c4f:	89 c7                	mov    di,ax
    1c51:	8e c2                	mov    es,dx
    1c53:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1c57:	06                   	push   es
    1c58:	57                   	push   di
    1c59:	9a 9b 3b 2e 20       	call   0x202e:0x3b9b
    1c5e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1c61:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1c64:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1c67:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1c6a:	bf 58 0a             	mov    di,0xa58
    1c6d:	b8 85 1c             	mov    ax,0x1c85
    1c70:	50                   	push   ax
    1c71:	57                   	push   di
    1c72:	9a 55 22 8c 1c       	call   0x1c8c:0x2255
    1c77:	08 c0                	or     al,al
    1c79:	74 57                	je     0x1cd2
    1c7b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1c7e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1c81:	bf 58 0a             	mov    di,0xa58
    1c84:	b8 3a 20             	mov    ax,0x203a
    1c87:	50                   	push   ax
    1c88:	57                   	push   di
    1c89:	9a 73 22 ce 1c       	call   0x1cce:0x2273
    1c8e:	89 c7                	mov    di,ax
    1c90:	8e c2                	mov    es,dx
    1c92:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    1c96:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    1c9a:	8d be f0 fd          	lea    di,[bp-0x210]
    1c9e:	16                   	push   ss
    1c9f:	57                   	push   di
    1ca0:	bf 65 1b             	mov    di,0x1b65
    1ca3:	0e                   	push   cs
    1ca4:	57                   	push   di
    1ca5:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1ca9:	06                   	push   es
    1caa:	57                   	push   di
    1cab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1cae:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1cb2:	83 ec 0a             	sub    sp,0xa
    1cb5:	89 e3                	mov    bx,sp
    1cb7:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1cbb:	90                   	nop
    1cbc:	9b                   	fwait
    1cbd:	9a d4 10 04 22       	call   0x2204:0x10d4
    1cc2:	8d be f8 fe          	lea    di,[bp-0x108]
    1cc6:	16                   	push   ss
    1cc7:	57                   	push   di
    1cc8:	68 ff 00             	push   0xff
    1ccb:	9a e7 17 ef 1c       	call   0x1cef:0x17e7
    1cd0:	eb 1f                	jmp    0x1cf1
    1cd2:	8d be f4 fd          	lea    di,[bp-0x20c]
    1cd6:	16                   	push   ss
    1cd7:	57                   	push   di
    1cd8:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1cdc:	06                   	push   es
    1cdd:	57                   	push   di
    1cde:	9a 24 15 4f 4f       	call   0x4f4f:0x1524
    1ce3:	8d be f8 fe          	lea    di,[bp-0x108]
    1ce7:	16                   	push   ss
    1ce8:	57                   	push   di
    1ce9:	68 ff 00             	push   0xff
    1cec:	9a e7 17 01 1d       	call   0x1d01:0x17e7
    1cf1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1cf5:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1cf9:	2d 04 00             	sub    ax,0x4
    1cfc:	71 05                	jno    0x1d03
    1cfe:	9a 3e 04 16 1d       	call   0x1d16:0x43e
    1d03:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d06:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d0a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1d0e:	2d 04 00             	sub    ax,0x4
    1d11:	71 05                	jno    0x1d18
    1d13:	9a 3e 04 43 1d       	call   0x1d43:0x43e
    1d18:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d1b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1d1e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1d21:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d25:	06                   	push   es
    1d26:	57                   	push   di
    1d27:	9a d4 19 7a 1d       	call   0x1d7a:0x19d4
    1d2c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d2f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1d32:	ff 76 12             	push   WORD PTR [bp+0x12]
    1d35:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d38:	bf a2 0b             	mov    di,0xba2
    1d3b:	b8 56 1d             	mov    ax,0x1d56
    1d3e:	50                   	push   ax
    1d3f:	57                   	push   di
    1d40:	9a 55 22 5d 1d       	call   0x1d5d:0x2255
    1d45:	08 c0                	or     al,al
    1d47:	75 03                	jne    0x1d4c
    1d49:	e9 7f 00             	jmp    0x1dcb
    1d4c:	ff 76 12             	push   WORD PTR [bp+0x12]
    1d4f:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d52:	bf a2 0b             	mov    di,0xba2
    1d55:	b8 cc 1f             	mov    ax,0x1fcc
    1d58:	50                   	push   ax
    1d59:	57                   	push   di
    1d5a:	9a 73 22 88 1d       	call   0x1d88:0x2273
    1d5f:	89 c7                	mov    di,ax
    1d61:	8e c2                	mov    es,dx
    1d63:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1d67:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1d6b:	8d be f4 fd          	lea    di,[bp-0x20c]
    1d6f:	16                   	push   ss
    1d70:	57                   	push   di
    1d71:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d75:	06                   	push   es
    1d76:	57                   	push   di
    1d77:	9a 53 1d c3 1d       	call   0x1dc3:0x1d53
    1d7c:	8d be f8 fe          	lea    di,[bp-0x108]
    1d80:	16                   	push   ss
    1d81:	57                   	push   di
    1d82:	68 ff 00             	push   0xff
    1d85:	9a e7 17 9a 1d       	call   0x1d9a:0x17e7
    1d8a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d8e:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1d92:	2d 04 00             	sub    ax,0x4
    1d95:	71 05                	jno    0x1d9c
    1d97:	9a 3e 04 af 1d       	call   0x1daf:0x43e
    1d9c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d9f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1da3:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1da7:	2d 04 00             	sub    ax,0x4
    1daa:	71 05                	jno    0x1db1
    1dac:	9a 3e 04 e3 1d       	call   0x1de3:0x43e
    1db1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1db4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1db7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1dba:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1dbe:	06                   	push   es
    1dbf:	57                   	push   di
    1dc0:	9a d4 19 07 1e       	call   0x1e07:0x19d4
    1dc5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1dc8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1dcb:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    1dd0:	77 03                	ja     0x1dd5
    1dd2:	e9 ac 01             	jmp    0x1f81
    1dd5:	8d be f8 fd          	lea    di,[bp-0x208]
    1dd9:	16                   	push   ss
    1dda:	57                   	push   di
    1ddb:	bf 70 1b             	mov    di,0x1b70
    1dde:	0e                   	push   cs
    1ddf:	57                   	push   di
    1de0:	9a cd 17 ee 1d       	call   0x1dee:0x17cd
    1de5:	8d be f8 fe          	lea    di,[bp-0x108]
    1de9:	16                   	push   ss
    1dea:	57                   	push   di
    1deb:	9a 4c 18 f8 1d       	call   0x1df8:0x184c
    1df0:	bf 70 1b             	mov    di,0x1b70
    1df3:	0e                   	push   cs
    1df4:	57                   	push   di
    1df5:	9a 4c 18 94 1e       	call   0x1e94:0x184c
    1dfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dfd:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1e02:	06                   	push   es
    1e03:	57                   	push   di
    1e04:	9a 8c 1d 4d 1e       	call   0x1e4d:0x1d8c
    1e09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0c:	06                   	push   es
    1e0d:	57                   	push   di
    1e0e:	9a d5 33 4c 29       	call   0x294c:0x33d5
    1e13:	89 c7                	mov    di,ax
    1e15:	8e c2                	mov    es,dx
    1e17:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1e1b:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1e1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e22:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1e27:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1e2b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1e2f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e33:	06                   	push   es
    1e34:	57                   	push   di
    1e35:	9a 99 20 58 1e       	call   0x1e58:0x2099
    1e3a:	8d be f4 fd          	lea    di,[bp-0x20c]
    1e3e:	16                   	push   ss
    1e3f:	57                   	push   di
    1e40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e43:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1e48:	06                   	push   es
    1e49:	57                   	push   di
    1e4a:	9a 53 1d 68 1e       	call   0x1e68:0x1d53
    1e4f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e53:	06                   	push   es
    1e54:	57                   	push   di
    1e55:	9a 03 20 88 1e       	call   0x1e88:0x2003
    1e5a:	50                   	push   ax
    1e5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e5e:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1e63:	06                   	push   es
    1e64:	57                   	push   di
    1e65:	9a bf 17 7d 1e       	call   0x1e7d:0x17bf
    1e6a:	8d be f4 fd          	lea    di,[bp-0x20c]
    1e6e:	16                   	push   ss
    1e6f:	57                   	push   di
    1e70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e73:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1e78:	06                   	push   es
    1e79:	57                   	push   di
    1e7a:	9a 53 1d aa 1e       	call   0x1eaa:0x1d53
    1e7f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e83:	06                   	push   es
    1e84:	57                   	push   di
    1e85:	9a 4e 20 f8 47       	call   0x47f8:0x204e
    1e8a:	b9 03 00             	mov    cx,0x3
    1e8d:	f7 e9                	imul   cx
    1e8f:	71 05                	jno    0x1e96
    1e91:	9a 3e 04 07 1f       	call   0x1f07:0x43e
    1e96:	99                   	cwd
    1e97:	b9 02 00             	mov    cx,0x2
    1e9a:	f7 f9                	idiv   cx
    1e9c:	50                   	push   ax
    1e9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ea0:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1ea5:	06                   	push   es
    1ea6:	57                   	push   di
    1ea7:	9a e1 17 ba 1e       	call   0x1eba:0x17e1
    1eac:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1eaf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1eb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb5:	06                   	push   es
    1eb6:	57                   	push   di
    1eb7:	9a 06 1a da 1e       	call   0x1eda:0x1a06
    1ebc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ebf:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ec2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec5:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1eca:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1ece:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1ed2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ed5:	06                   	push   es
    1ed6:	57                   	push   di
    1ed7:	9a 7b 17 e8 1e       	call   0x1ee8:0x177b
    1edc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1edf:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1ee3:	06                   	push   es
    1ee4:	57                   	push   di
    1ee5:	9a 9d 17 f2 1e       	call   0x1ef2:0x179d
    1eea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eed:	06                   	push   es
    1eee:	57                   	push   di
    1eef:	9a a9 18 29 1f       	call   0x1f29:0x18a9
    1ef4:	8b d0                	mov    dx,ax
    1ef6:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1efa:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    1efe:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    1f02:	71 05                	jno    0x1f09
    1f04:	9a 3e 04 1d 1f       	call   0x1f1d:0x43e
    1f09:	3b c2                	cmp    ax,dx
    1f0b:	7e 20                	jle    0x1f2d
    1f0d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f11:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    1f15:	2d 08 00             	sub    ax,0x8
    1f18:	71 05                	jno    0x1f1f
    1f1a:	9a 3e 04 4a 1f       	call   0x1f4a:0x43e
    1f1f:	50                   	push   ax
    1f20:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f24:	06                   	push   es
    1f25:	57                   	push   di
    1f26:	9a 7b 17 35 1f       	call   0x1f35:0x177b
    1f2b:	eb bd                	jmp    0x1eea
    1f2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f30:	06                   	push   es
    1f31:	57                   	push   di
    1f32:	9a f4 18 6c 1f       	call   0x1f6c:0x18f4
    1f37:	8b d0                	mov    dx,ax
    1f39:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f3d:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1f41:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    1f45:	71 05                	jno    0x1f4c
    1f47:	9a 3e 04 60 1f       	call   0x1f60:0x43e
    1f4c:	3b c2                	cmp    ax,dx
    1f4e:	7e 20                	jle    0x1f70
    1f50:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f54:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1f58:	2d 08 00             	sub    ax,0x8
    1f5b:	71 05                	jno    0x1f62
    1f5d:	9a 3e 04 8e 1f       	call   0x1f8e:0x43e
    1f62:	50                   	push   ax
    1f63:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f67:	06                   	push   es
    1f68:	57                   	push   di
    1f69:	9a 9d 17 7f 1f       	call   0x1f7f:0x179d
    1f6e:	eb bd                	jmp    0x1f2d
    1f70:	6a 01                	push   0x1
    1f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f75:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1f7a:	06                   	push   es
    1f7b:	57                   	push   di
    1f7c:	9a 77 1c 13 22       	call   0x2213:0x1c77
    1f81:	c9                   	leave
    1f82:	ca 0e 00             	retf   0xe
    1f85:	55                   	push   bp
    1f86:	89 e5                	mov    bp,sp
    1f88:	b8 04 00             	mov    ax,0x4
    1f8b:	9a 44 04 a5 1f       	call   0x1fa5:0x444
    1f90:	83 ec 04             	sub    sp,0x4
    1f93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f96:	06                   	push   es
    1f97:	57                   	push   di
    1f98:	9a 7d 52 c4 1f       	call   0x1fc4:0x527d
    1f9d:	2d 01 00             	sub    ax,0x1
    1fa0:	71 05                	jno    0x1fa7
    1fa2:	9a 3e 04 d3 1f       	call   0x1fd3:0x43e
    1fa7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1faa:	31 c0                	xor    ax,ax
    1fac:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1faf:	7f 58                	jg     0x2009
    1fb1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fb4:	eb 03                	jmp    0x1fb9
    1fb6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1fb9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fbf:	06                   	push   es
    1fc0:	57                   	push   di
    1fc1:	9a 46 52 e4 1f       	call   0x1fe4:0x5246
    1fc6:	52                   	push   dx
    1fc7:	50                   	push   ax
    1fc8:	bf 22 00             	mov    di,0x22
    1fcb:	b8 ec 1f             	mov    ax,0x1fec
    1fce:	50                   	push   ax
    1fcf:	57                   	push   di
    1fd0:	9a 55 22 f3 1f       	call   0x1ff3:0x2255
    1fd5:	08 c0                	or     al,al
    1fd7:	74 28                	je     0x2001
    1fd9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fdf:	06                   	push   es
    1fe0:	57                   	push   di
    1fe1:	9a 46 52 67 29       	call   0x2967:0x5246
    1fe6:	52                   	push   dx
    1fe7:	50                   	push   ax
    1fe8:	bf 22 00             	mov    di,0x22
    1feb:	b8 11 4f             	mov    ax,0x4f11
    1fee:	50                   	push   ax
    1fef:	57                   	push   di
    1ff0:	9a 73 22 16 20       	call   0x2016:0x2273
    1ff5:	52                   	push   dx
    1ff6:	50                   	push   ax
    1ff7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ffa:	06                   	push   es
    1ffb:	57                   	push   di
    1ffc:	9a 52 16 3c 24       	call   0x243c:0x1652
    2001:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2004:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2007:	75 ad                	jne    0x1fb6
    2009:	c9                   	leave
    200a:	ca 04 00             	retf   0x4
    200d:	55                   	push   bp
    200e:	89 e5                	mov    bp,sp
    2010:	b8 04 00             	mov    ax,0x4
    2013:	9a 44 04 ea 21       	call   0x21ea:0x444
    2018:	83 ec 04             	sub    sp,0x4
    201b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    201e:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    2023:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2026:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2029:	06                   	push   es
    202a:	57                   	push   di
    202b:	9a d2 31 50 20       	call   0x2050:0x31d2
    2030:	6a 01                	push   0x1
    2032:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2035:	06                   	push   es
    2036:	57                   	push   di
    2037:	9a fb 2f 46 20       	call   0x2046:0x2ffb
    203c:	6a 00                	push   0x0
    203e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2041:	06                   	push   es
    2042:	57                   	push   di
    2043:	9a d2 2e 71 20       	call   0x2071:0x2ed2
    2048:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    204b:	06                   	push   es
    204c:	57                   	push   di
    204d:	9a bf 31 65 20       	call   0x2065:0x31bf
    2052:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2055:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    205a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    205d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2060:	06                   	push   es
    2061:	57                   	push   di
    2062:	9a d2 31 87 20       	call   0x2087:0x31d2
    2067:	6a 01                	push   0x1
    2069:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    206c:	06                   	push   es
    206d:	57                   	push   di
    206e:	9a fb 2f 7d 20       	call   0x207d:0x2ffb
    2073:	6a 00                	push   0x0
    2075:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2078:	06                   	push   es
    2079:	57                   	push   di
    207a:	9a d2 2e a8 20       	call   0x20a8:0x2ed2
    207f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2082:	06                   	push   es
    2083:	57                   	push   di
    2084:	9a bf 31 9c 20       	call   0x209c:0x31bf
    2089:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    208c:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    2091:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2094:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2097:	06                   	push   es
    2098:	57                   	push   di
    2099:	9a d2 31 be 20       	call   0x20be:0x31d2
    209e:	6a 01                	push   0x1
    20a0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20a3:	06                   	push   es
    20a4:	57                   	push   di
    20a5:	9a fb 2f b4 20       	call   0x20b4:0x2ffb
    20aa:	6a 00                	push   0x0
    20ac:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20af:	06                   	push   es
    20b0:	57                   	push   di
    20b1:	9a d2 2e df 20       	call   0x20df:0x2ed2
    20b6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20b9:	06                   	push   es
    20ba:	57                   	push   di
    20bb:	9a bf 31 d3 20       	call   0x20d3:0x31bf
    20c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20c3:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    20c8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    20cb:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    20ce:	06                   	push   es
    20cf:	57                   	push   di
    20d0:	9a d2 31 f5 20       	call   0x20f5:0x31d2
    20d5:	6a 01                	push   0x1
    20d7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20da:	06                   	push   es
    20db:	57                   	push   di
    20dc:	9a fb 2f eb 20       	call   0x20eb:0x2ffb
    20e1:	6a 00                	push   0x0
    20e3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20e6:	06                   	push   es
    20e7:	57                   	push   di
    20e8:	9a d2 2e 16 21       	call   0x2116:0x2ed2
    20ed:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20f0:	06                   	push   es
    20f1:	57                   	push   di
    20f2:	9a bf 31 0a 21       	call   0x210a:0x31bf
    20f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20fa:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    20ff:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2102:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2105:	06                   	push   es
    2106:	57                   	push   di
    2107:	9a d2 31 2c 21       	call   0x212c:0x31d2
    210c:	6a 01                	push   0x1
    210e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2111:	06                   	push   es
    2112:	57                   	push   di
    2113:	9a fb 2f 22 21       	call   0x2122:0x2ffb
    2118:	6a 00                	push   0x0
    211a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    211d:	06                   	push   es
    211e:	57                   	push   di
    211f:	9a d2 2e 4d 21       	call   0x214d:0x2ed2
    2124:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2127:	06                   	push   es
    2128:	57                   	push   di
    2129:	9a bf 31 41 21       	call   0x2141:0x31bf
    212e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2131:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    2136:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2139:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    213c:	06                   	push   es
    213d:	57                   	push   di
    213e:	9a d2 31 63 21       	call   0x2163:0x31d2
    2143:	6a 01                	push   0x1
    2145:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2148:	06                   	push   es
    2149:	57                   	push   di
    214a:	9a fb 2f 59 21       	call   0x2159:0x2ffb
    214f:	6a 00                	push   0x0
    2151:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2154:	06                   	push   es
    2155:	57                   	push   di
    2156:	9a d2 2e 84 21       	call   0x2184:0x2ed2
    215b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    215e:	06                   	push   es
    215f:	57                   	push   di
    2160:	9a bf 31 78 21       	call   0x2178:0x31bf
    2165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2168:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    216d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2170:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2173:	06                   	push   es
    2174:	57                   	push   di
    2175:	9a d2 31 9a 21       	call   0x219a:0x31d2
    217a:	6a 01                	push   0x1
    217c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    217f:	06                   	push   es
    2180:	57                   	push   di
    2181:	9a fb 2f 90 21       	call   0x2190:0x2ffb
    2186:	6a 00                	push   0x0
    2188:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    218b:	06                   	push   es
    218c:	57                   	push   di
    218d:	9a d2 2e bb 21       	call   0x21bb:0x2ed2
    2192:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2195:	06                   	push   es
    2196:	57                   	push   di
    2197:	9a bf 31 af 21       	call   0x21af:0x31bf
    219c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    219f:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    21a4:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21a7:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21aa:	06                   	push   es
    21ab:	57                   	push   di
    21ac:	9a d2 31 d1 21       	call   0x21d1:0x31d2
    21b1:	6a 01                	push   0x1
    21b3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21b6:	06                   	push   es
    21b7:	57                   	push   di
    21b8:	9a fb 2f c7 21       	call   0x21c7:0x2ffb
    21bd:	6a 00                	push   0x0
    21bf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21c2:	06                   	push   es
    21c3:	57                   	push   di
    21c4:	9a d2 2e 2e 24       	call   0x242e:0x2ed2
    21c9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21cc:	06                   	push   es
    21cd:	57                   	push   di
    21ce:	9a bf 31 44 27       	call   0x2744:0x31bf
    21d3:	c9                   	leave
    21d4:	ca 04 00             	retf   0x4
    21d7:	01 23                	add    WORD PTR [bp+di],sp
    21d9:	00 00                	add    BYTE PTR [bx+si],al
    21db:	00 00                	add    BYTE PTR [bx+si],al
    21dd:	ff 00                	inc    WORD PTR [bx+si]
    21df:	00 00                	add    BYTE PTR [bx+si],al
    21e1:	55                   	push   bp
    21e2:	89 e5                	mov    bp,sp
    21e4:	b8 02 02             	mov    ax,0x202
    21e7:	9a 44 04 4f 22       	call   0x224f:0x444
    21ec:	81 ec 02 02          	sub    sp,0x202
    21f0:	8d be fe fd          	lea    di,[bp-0x202]
    21f4:	16                   	push   ss
    21f5:	57                   	push   di
    21f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21f9:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    21fe:	99                   	cwd
    21ff:	52                   	push   dx
    2200:	50                   	push   ax
    2201:	9a a9 08 29 22       	call   0x2229:0x8a9
    2206:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2209:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    220e:	06                   	push   es
    220f:	57                   	push   di
    2210:	9a 8c 1d 38 22       	call   0x2238:0x1d8c
    2215:	8d be fe fd          	lea    di,[bp-0x202]
    2219:	16                   	push   ss
    221a:	57                   	push   di
    221b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    221e:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2223:	99                   	cwd
    2224:	52                   	push   dx
    2225:	50                   	push   ax
    2226:	9a a9 08 9a 22       	call   0x229a:0x8a9
    222b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    222e:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2233:	06                   	push   es
    2234:	57                   	push   di
    2235:	9a 8c 1d 1d 23       	call   0x231d:0x1d8c
    223a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223d:	81 c7 32 05          	add    di,0x532
    2241:	06                   	push   es
    2242:	57                   	push   di
    2243:	8d be fe fe          	lea    di,[bp-0x102]
    2247:	16                   	push   ss
    2248:	57                   	push   di
    2249:	68 ff 00             	push   0xff
    224c:	9a e7 17 5f 22       	call   0x225f:0x17e7
    2251:	bf d7 21             	mov    di,0x21d7
    2254:	0e                   	push   cs
    2255:	57                   	push   di
    2256:	8d be fe fe          	lea    di,[bp-0x102]
    225a:	16                   	push   ss
    225b:	57                   	push   di
    225c:	9a 78 18 68 22       	call   0x2268:0x1878
    2261:	99                   	cwd
    2262:	bf d9 21             	mov    di,0x21d9
    2265:	9a 16 04 84 22       	call   0x2284:0x416
    226a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    226d:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2271:	76 3d                	jbe    0x22b0
    2273:	8d be fe fe          	lea    di,[bp-0x102]
    2277:	16                   	push   ss
    2278:	57                   	push   di
    2279:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    227c:	30 e4                	xor    ah,ah
    227e:	50                   	push   ax
    227f:	6a 01                	push   0x1
    2281:	9a 75 19 ae 22       	call   0x22ae:0x1975
    2286:	8d be fe fd          	lea    di,[bp-0x202]
    228a:	16                   	push   ss
    228b:	57                   	push   di
    228c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    228f:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2294:	99                   	cwd
    2295:	52                   	push   dx
    2296:	50                   	push   ax
    2297:	9a a9 08 f9 22       	call   0x22f9:0x8a9
    229c:	8d be fe fe          	lea    di,[bp-0x102]
    22a0:	16                   	push   ss
    22a1:	57                   	push   di
    22a2:	68 ff 00             	push   0xff
    22a5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    22a8:	30 e4                	xor    ah,ah
    22aa:	50                   	push   ax
    22ab:	9a 16 19 be 22       	call   0x22be:0x1916
    22b0:	bf d7 21             	mov    di,0x21d7
    22b3:	0e                   	push   cs
    22b4:	57                   	push   di
    22b5:	8d be fe fe          	lea    di,[bp-0x102]
    22b9:	16                   	push   ss
    22ba:	57                   	push   di
    22bb:	9a 78 18 c7 22       	call   0x22c7:0x1878
    22c0:	99                   	cwd
    22c1:	bf d9 21             	mov    di,0x21d9
    22c4:	9a 16 04 e3 22       	call   0x22e3:0x416
    22c9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    22cc:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    22d0:	76 3d                	jbe    0x230f
    22d2:	8d be fe fe          	lea    di,[bp-0x102]
    22d6:	16                   	push   ss
    22d7:	57                   	push   di
    22d8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    22db:	30 e4                	xor    ah,ah
    22dd:	50                   	push   ax
    22de:	6a 01                	push   0x1
    22e0:	9a 75 19 0d 23       	call   0x230d:0x1975
    22e5:	8d be fe fd          	lea    di,[bp-0x202]
    22e9:	16                   	push   ss
    22ea:	57                   	push   di
    22eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ee:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    22f3:	99                   	cwd
    22f4:	52                   	push   dx
    22f5:	50                   	push   ax
    22f6:	9a a9 08 bf 2a       	call   0x2abf:0x8a9
    22fb:	8d be fe fe          	lea    di,[bp-0x102]
    22ff:	16                   	push   ss
    2300:	57                   	push   di
    2301:	68 ff 00             	push   0xff
    2304:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2307:	30 e4                	xor    ah,ah
    2309:	50                   	push   ax
    230a:	9a 16 19 45 23       	call   0x2345:0x1916
    230f:	8d be fe fe          	lea    di,[bp-0x102]
    2313:	16                   	push   ss
    2314:	57                   	push   di
    2315:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2318:	06                   	push   es
    2319:	57                   	push   di
    231a:	9a 8c 1d 44 28       	call   0x2844:0x1d8c
    231f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2322:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    2327:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    232b:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    232f:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2333:	eb 03                	jmp    0x2338
    2335:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    2338:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    233b:	30 e4                	xor    ah,ah
    233d:	05 01 00             	add    ax,0x1
    2340:	71 05                	jno    0x2347
    2342:	9a 3e 04 96 23       	call   0x2396:0x43e
    2347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234a:	26 3b 85 2e 05       	cmp    ax,WORD PTR es:[di+0x52e]
    234f:	b0 00                	mov    al,0x0
    2351:	75 01                	jne    0x2354
    2353:	40                   	inc    ax
    2354:	50                   	push   ax
    2355:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2358:	30 e4                	xor    ah,ah
    235a:	50                   	push   ax
    235b:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    235f:	06                   	push   es
    2360:	57                   	push   di
    2361:	9a 53 13 6f 23       	call   0x236f:0x1353
    2366:	89 c7                	mov    di,ax
    2368:	8e c2                	mov    es,dx
    236a:	06                   	push   es
    236b:	57                   	push   di
    236c:	9a 75 12 8c 23       	call   0x238c:0x1275
    2371:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    2375:	75 be                	jne    0x2335
    2377:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    237a:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    237f:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2383:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2387:	06                   	push   es
    2388:	57                   	push   di
    2389:	9a 26 13 e1 23       	call   0x23e1:0x1326
    238e:	2d 01 00             	sub    ax,0x1
    2391:	71 05                	jno    0x2398
    2393:	9a 3e 04 9f 23       	call   0x239f:0x43e
    2398:	99                   	cwd
    2399:	bf d9 21             	mov    di,0x21d9
    239c:	9a 16 04 c2 23       	call   0x23c2:0x416
    23a1:	88 86 f9 fe          	mov    BYTE PTR [bp-0x107],al
    23a5:	b0 00                	mov    al,0x0
    23a7:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    23ab:	77 4a                	ja     0x23f7
    23ad:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    23b0:	eb 03                	jmp    0x23b5
    23b2:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    23b5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    23b8:	30 e4                	xor    ah,ah
    23ba:	05 01 00             	add    ax,0x1
    23bd:	71 05                	jno    0x23c4
    23bf:	9a 3e 04 5e 24       	call   0x245e:0x43e
    23c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c7:	26 3b 85 30 05       	cmp    ax,WORD PTR es:[di+0x530]
    23cc:	b0 00                	mov    al,0x0
    23ce:	75 01                	jne    0x23d1
    23d0:	40                   	inc    ax
    23d1:	50                   	push   ax
    23d2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    23d5:	30 e4                	xor    ah,ah
    23d7:	50                   	push   ax
    23d8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    23dc:	06                   	push   es
    23dd:	57                   	push   di
    23de:	9a 53 13 ec 23       	call   0x23ec:0x1353
    23e3:	89 c7                	mov    di,ax
    23e5:	8e c2                	mov    es,dx
    23e7:	06                   	push   es
    23e8:	57                   	push   di
    23e9:	9a 75 12 9c 28       	call   0x289c:0x1275
    23ee:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    23f1:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    23f5:	75 bb                	jne    0x23b2
    23f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fa:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    23ff:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2403:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2407:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240a:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    240f:	99                   	cwd
    2410:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2414:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2418:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    241d:	8d be f2 fe          	lea    di,[bp-0x10e]
    2421:	16                   	push   ss
    2422:	57                   	push   di
    2423:	6a 00                	push   0x0
    2425:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2429:	06                   	push   es
    242a:	57                   	push   di
    242b:	9a 95 28 a6 24       	call   0x24a6:0x2895
    2430:	08 c0                	or     al,al
    2432:	75 0a                	jne    0x243e
    2434:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2437:	06                   	push   es
    2438:	57                   	push   di
    2439:	9a e9 12 b4 24       	call   0x24b4:0x12e9
    243e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2441:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    2446:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    244a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    244e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2451:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2456:	2d 01 00             	sub    ax,0x1
    2459:	71 05                	jno    0x2460
    245b:	9a 3e 04 d6 24       	call   0x24d6:0x43e
    2460:	99                   	cwd
    2461:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2465:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2469:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    246e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2471:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    2476:	99                   	cwd
    2477:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    247b:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    247f:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2484:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    248a:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2490:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2495:	8d be e2 fe          	lea    di,[bp-0x11e]
    2499:	16                   	push   ss
    249a:	57                   	push   di
    249b:	6a 02                	push   0x2
    249d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    24a1:	06                   	push   es
    24a2:	57                   	push   di
    24a3:	9a 95 28 1e 25       	call   0x251e:0x2895
    24a8:	08 c0                	or     al,al
    24aa:	75 0a                	jne    0x24b6
    24ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24af:	06                   	push   es
    24b0:	57                   	push   di
    24b1:	9a e9 12 2c 25       	call   0x252c:0x12e9
    24b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b9:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    24be:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    24c2:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    24c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c9:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    24ce:	2d 01 00             	sub    ax,0x1
    24d1:	71 05                	jno    0x24d8
    24d3:	9a 3e 04 4e 25       	call   0x254e:0x43e
    24d8:	99                   	cwd
    24d9:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    24dd:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    24e1:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    24e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e9:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    24ee:	99                   	cwd
    24ef:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    24f3:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    24f7:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    24fc:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2502:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2508:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    250d:	8d be e2 fe          	lea    di,[bp-0x11e]
    2511:	16                   	push   ss
    2512:	57                   	push   di
    2513:	6a 02                	push   0x2
    2515:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2519:	06                   	push   es
    251a:	57                   	push   di
    251b:	9a 95 28 85 25       	call   0x2585:0x2895
    2520:	08 c0                	or     al,al
    2522:	75 0a                	jne    0x252e
    2524:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2527:	06                   	push   es
    2528:	57                   	push   di
    2529:	9a e9 12 93 25       	call   0x2593:0x12e9
    252e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2531:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2536:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    253a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    253e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2541:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2546:	2d 01 00             	sub    ax,0x1
    2549:	71 05                	jno    0x2550
    254b:	9a 3e 04 35 27       	call   0x2735:0x43e
    2550:	99                   	cwd
    2551:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2555:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2559:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    255e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2561:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    2566:	99                   	cwd
    2567:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    256b:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    256f:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2574:	8d be ea fe          	lea    di,[bp-0x116]
    2578:	16                   	push   ss
    2579:	57                   	push   di
    257a:	6a 01                	push   0x1
    257c:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2580:	06                   	push   es
    2581:	57                   	push   di
    2582:	9a 95 28 df 25       	call   0x25df:0x2895
    2587:	08 c0                	or     al,al
    2589:	75 0a                	jne    0x2595
    258b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    258e:	06                   	push   es
    258f:	57                   	push   di
    2590:	9a e9 12 ed 25       	call   0x25ed:0x12e9
    2595:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2598:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    259d:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    25a1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    25a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a8:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    25ad:	99                   	cwd
    25ae:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    25b2:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    25b6:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    25bb:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    25c0:	99                   	cwd
    25c1:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    25c5:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    25c9:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    25ce:	8d be ea fe          	lea    di,[bp-0x116]
    25d2:	16                   	push   ss
    25d3:	57                   	push   di
    25d4:	6a 01                	push   0x1
    25d6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    25da:	06                   	push   es
    25db:	57                   	push   di
    25dc:	9a 95 28 4a 26       	call   0x264a:0x2895
    25e1:	08 c0                	or     al,al
    25e3:	75 0a                	jne    0x25ef
    25e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e8:	06                   	push   es
    25e9:	57                   	push   di
    25ea:	9a e9 12 58 26       	call   0x2658:0x12e9
    25ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f2:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    25f7:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    25fb:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    25ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2602:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2607:	99                   	cwd
    2608:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    260c:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2610:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2615:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    261a:	99                   	cwd
    261b:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    261f:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2623:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2628:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    262e:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2634:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2639:	8d be e2 fe          	lea    di,[bp-0x11e]
    263d:	16                   	push   ss
    263e:	57                   	push   di
    263f:	6a 02                	push   0x2
    2641:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2645:	06                   	push   es
    2646:	57                   	push   di
    2647:	9a 95 28 b5 26       	call   0x26b5:0x2895
    264c:	08 c0                	or     al,al
    264e:	75 0a                	jne    0x265a
    2650:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2653:	06                   	push   es
    2654:	57                   	push   di
    2655:	9a e9 12 c3 26       	call   0x26c3:0x12e9
    265a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    265d:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    2662:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2666:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    266a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    266d:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2672:	99                   	cwd
    2673:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2677:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    267b:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2680:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    2685:	99                   	cwd
    2686:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    268a:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    268e:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2693:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2699:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    269f:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    26a4:	8d be e2 fe          	lea    di,[bp-0x11e]
    26a8:	16                   	push   ss
    26a9:	57                   	push   di
    26aa:	6a 02                	push   0x2
    26ac:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    26b0:	06                   	push   es
    26b1:	57                   	push   di
    26b2:	9a 95 28 0f 27       	call   0x270f:0x2895
    26b7:	08 c0                	or     al,al
    26b9:	75 0a                	jne    0x26c5
    26bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26be:	06                   	push   es
    26bf:	57                   	push   di
    26c0:	9a e9 12 1d 27       	call   0x271d:0x12e9
    26c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c8:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    26cd:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    26d1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    26d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d8:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    26dd:	99                   	cwd
    26de:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    26e2:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    26e6:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    26eb:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    26f0:	99                   	cwd
    26f1:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    26f5:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    26f9:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    26fe:	8d be ea fe          	lea    di,[bp-0x116]
    2702:	16                   	push   ss
    2703:	57                   	push   di
    2704:	6a 01                	push   0x1
    2706:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    270a:	06                   	push   es
    270b:	57                   	push   di
    270c:	9a 95 28 2b 2b       	call   0x2b2b:0x2895
    2711:	08 c0                	or     al,al
    2713:	75 0a                	jne    0x271f
    2715:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2718:	06                   	push   es
    2719:	57                   	push   di
    271a:	9a e9 12 27 27       	call   0x2727:0x12e9
    271f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2722:	06                   	push   es
    2723:	57                   	push   di
    2724:	9a 85 1f cd 27       	call   0x27cd:0x1f85
    2729:	c9                   	leave
    272a:	ca 04 00             	retf   0x4
    272d:	55                   	push   bp
    272e:	89 e5                	mov    bp,sp
    2730:	31 c0                	xor    ax,ax
    2732:	9a 44 04 bb 27       	call   0x27bb:0x444
    2737:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    273a:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    273f:	06                   	push   es
    2740:	57                   	push   di
    2741:	9a d2 31 53 27       	call   0x2753:0x31d2
    2746:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2749:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    274e:	06                   	push   es
    274f:	57                   	push   di
    2750:	9a d2 31 62 27       	call   0x2762:0x31d2
    2755:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2758:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    275d:	06                   	push   es
    275e:	57                   	push   di
    275f:	9a d2 31 71 27       	call   0x2771:0x31d2
    2764:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2767:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    276c:	06                   	push   es
    276d:	57                   	push   di
    276e:	9a d2 31 80 27       	call   0x2780:0x31d2
    2773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2776:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    277b:	06                   	push   es
    277c:	57                   	push   di
    277d:	9a d2 31 8f 27       	call   0x278f:0x31d2
    2782:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2785:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    278a:	06                   	push   es
    278b:	57                   	push   di
    278c:	9a d2 31 9e 27       	call   0x279e:0x31d2
    2791:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2794:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    2799:	06                   	push   es
    279a:	57                   	push   di
    279b:	9a d2 31 ad 27       	call   0x27ad:0x31d2
    27a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a3:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    27a8:	06                   	push   es
    27a9:	57                   	push   di
    27aa:	9a d2 31 1d 32       	call   0x321d:0x31d2
    27af:	c9                   	leave
    27b0:	ca 04 00             	retf   0x4
    27b3:	55                   	push   bp
    27b4:	89 e5                	mov    bp,sp
    27b6:	31 c0                	xor    ax,ax
    27b8:	9a 44 04 db 27       	call   0x27db:0x444
    27bd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    27c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c3:	26 89 85 2e 05       	mov    WORD PTR es:[di+0x52e],ax
    27c8:	06                   	push   es
    27c9:	57                   	push   di
    27ca:	9a e1 21 ed 27       	call   0x27ed:0x21e1
    27cf:	c9                   	leave
    27d0:	ca 06 00             	retf   0x6
    27d3:	55                   	push   bp
    27d4:	89 e5                	mov    bp,sp
    27d6:	31 c0                	xor    ax,ax
    27d8:	9a 44 04 0c 28       	call   0x280c:0x444
    27dd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    27e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e3:	26 89 85 30 05       	mov    WORD PTR es:[di+0x530],ax
    27e8:	06                   	push   es
    27e9:	57                   	push   di
    27ea:	9a e1 21 09 2c       	call   0x2c09:0x21e1
    27ef:	c9                   	leave
    27f0:	ca 06 00             	retf   0x6
    27f3:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    27f6:	6d                   	ins    WORD PTR es:[di],dx
    27f7:	73 74                	jae    0x286d
    27f9:	72 61                	jb     0x285c
    27fb:	74 20                	je     0x281d
    27fd:	2d 20 03             	sub    ax,0x320
    2800:	20 2d                	and    BYTE PTR [di],ch
    2802:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2805:	e5 b8                	in     ax,0xb8
    2807:	02 03                	add    al,BYTE PTR [bp+di]
    2809:	9a 44 04 20 28       	call   0x2820:0x444
    280e:	81 ec 02 03          	sub    sp,0x302
    2812:	8d be fe fe          	lea    di,[bp-0x102]
    2816:	16                   	push   ss
    2817:	57                   	push   di
    2818:	bf f3 27             	mov    di,0x27f3
    281b:	0e                   	push   cs
    281c:	57                   	push   di
    281d:	9a cd 17 2a 28       	call   0x282a:0x17cd
    2822:	bf fa 1d             	mov    di,0x1dfa
    2825:	1e                   	push   ds
    2826:	57                   	push   di
    2827:	9a 4c 18 34 28       	call   0x2834:0x184c
    282c:	bf ff 27             	mov    di,0x27ff
    282f:	0e                   	push   cs
    2830:	57                   	push   di
    2831:	9a 4c 18 49 28       	call   0x2849:0x184c
    2836:	8d be fe fd          	lea    di,[bp-0x202]
    283a:	16                   	push   ss
    283b:	57                   	push   di
    283c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    283f:	06                   	push   es
    2840:	57                   	push   di
    2841:	9a 53 1d 6e 28       	call   0x286e:0x1d53
    2846:	9a 4c 18 5a 28       	call   0x285a:0x184c
    284b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284e:	81 c7 32 05          	add    di,0x532
    2852:	06                   	push   es
    2853:	57                   	push   di
    2854:	68 ff 00             	push   0xff
    2857:	9a e7 17 a6 28       	call   0x28a6:0x17e7
    285c:	bf fa 1d             	mov    di,0x1dfa
    285f:	1e                   	push   ds
    2860:	57                   	push   di
    2861:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2864:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    2869:	06                   	push   es
    286a:	57                   	push   di
    286b:	9a 8c 1d 9b 29       	call   0x299b:0x1d8c
    2870:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2873:	26 c7 85 2c 05 64 00 	mov    WORD PTR es:[di+0x52c],0x64
    287a:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    2880:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    2886:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    288c:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    2891:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2894:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2897:	06                   	push   es
    2898:	57                   	push   di
    2899:	9a 26 13 d0 28       	call   0x28d0:0x1326
    289e:	2d 01 00             	sub    ax,0x1
    28a1:	71 05                	jno    0x28a8
    28a3:	9a 3e 04 08 29       	call   0x2908:0x43e
    28a8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    28ab:	31 c0                	xor    ax,ax
    28ad:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    28b0:	7f 33                	jg     0x28e5
    28b2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    28b5:	eb 03                	jmp    0x28ba
    28b7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    28ba:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    28bd:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    28c1:	7c 1a                	jl     0x28dd
    28c3:	6a 00                	push   0x0
    28c5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28c8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    28cb:	06                   	push   es
    28cc:	57                   	push   di
    28cd:	9a 53 13 db 28       	call   0x28db:0x1353
    28d2:	89 c7                	mov    di,ax
    28d4:	8e c2                	mov    es,dx
    28d6:	06                   	push   es
    28d7:	57                   	push   di
    28d8:	9a a5 13 2a 29       	call   0x292a:0x13a5
    28dd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    28e0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    28e3:	75 d2                	jne    0x28b7
    28e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28e8:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    28ed:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    28f0:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    28f3:	31 c0                	xor    ax,ax
    28f5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    28f8:	eb 03                	jmp    0x28fd
    28fa:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    28fd:	a1 4c 01             	mov    ax,ds:0x14c
    2900:	2d 01 00             	sub    ax,0x1
    2903:	71 05                	jno    0x290a
    2905:	9a 3e 04 17 29       	call   0x2917:0x43e
    290a:	8b d0                	mov    dx,ax
    290c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    290f:	05 01 00             	add    ax,0x1
    2912:	71 05                	jno    0x2919
    2914:	9a 3e 04 71 29       	call   0x2971:0x43e
    2919:	3b c2                	cmp    ax,dx
    291b:	7e 1a                	jle    0x2937
    291d:	6a 00                	push   0x0
    291f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2922:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2925:	06                   	push   es
    2926:	57                   	push   di
    2927:	9a 53 13 35 29       	call   0x2935:0x1353
    292c:	89 c7                	mov    di,ax
    292e:	8e c2                	mov    es,dx
    2930:	06                   	push   es
    2931:	57                   	push   di
    2932:	9a a5 13 8d 2c       	call   0x2c8d:0x13a5
    2937:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    293b:	75 bd                	jne    0x28fa
    293d:	6a 00                	push   0x0
    293f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2942:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2947:	06                   	push   es
    2948:	57                   	push   di
    2949:	9a d0 1c 5d 29       	call   0x295d:0x1cd0
    294e:	6a 00                	push   0x0
    2950:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2953:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2958:	06                   	push   es
    2959:	57                   	push   di
    295a:	9a d0 1c f1 2b       	call   0x2bf1:0x1cd0
    295f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2962:	06                   	push   es
    2963:	57                   	push   di
    2964:	9a 7d 52 93 29       	call   0x2993:0x527d
    2969:	2d 01 00             	sub    ax,0x1
    296c:	71 05                	jno    0x2973
    296e:	9a 3e 04 a2 29       	call   0x29a2:0x43e
    2973:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2976:	31 c0                	xor    ax,ax
    2978:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    297b:	7e 03                	jle    0x2980
    297d:	e9 a7 00             	jmp    0x2a27
    2980:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2983:	eb 03                	jmp    0x2988
    2985:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2988:	ff 76 fe             	push   WORD PTR [bp-0x2]
    298b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    298e:	06                   	push   es
    298f:	57                   	push   di
    2990:	9a 46 52 b3 29       	call   0x29b3:0x5246
    2995:	52                   	push   dx
    2996:	50                   	push   ax
    2997:	bf 99 03             	mov    di,0x399
    299a:	b8 bb 29             	mov    ax,0x29bb
    299d:	50                   	push   ax
    299e:	57                   	push   di
    299f:	9a 55 22 c2 29       	call   0x29c2:0x2255
    29a4:	08 c0                	or     al,al
    29a6:	74 74                	je     0x2a1c
    29a8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ae:	06                   	push   es
    29af:	57                   	push   di
    29b0:	9a 46 52 23 2f       	call   0x2f23:0x5246
    29b5:	52                   	push   dx
    29b6:	50                   	push   ax
    29b7:	bf 99 03             	mov    di,0x399
    29ba:	b8 1a 2a             	mov    ax,0x2a1a
    29bd:	50                   	push   ax
    29be:	57                   	push   di
    29bf:	9a 73 22 ff 29       	call   0x29ff:0x2273
    29c4:	89 c7                	mov    di,ax
    29c6:	8e c2                	mov    es,dx
    29c8:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    29cb:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    29ce:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    29d3:	74 47                	je     0x2a1c
    29d5:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    29d9:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    29dd:	74 3d                	je     0x2a1c
    29df:	a1 06 1e             	mov    ax,ds:0x1e06
    29e2:	99                   	cwd
    29e3:	8b c8                	mov    cx,ax
    29e5:	8b da                	mov    bx,dx
    29e7:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    29eb:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    29ef:	09 d2                	or     dx,dx
    29f1:	79 07                	jns    0x29fa
    29f3:	f7 d2                	not    dx
    29f5:	f7 d8                	neg    ax
    29f7:	83 da ff             	sbb    dx,0xffff
    29fa:	71 05                	jno    0x2a01
    29fc:	9a 3e 04 b4 2a       	call   0x2ab4:0x43e
    2a01:	3b d3                	cmp    dx,bx
    2a03:	7c 0a                	jl     0x2a0f
    2a05:	7f 04                	jg     0x2a0b
    2a07:	3b c1                	cmp    ax,cx
    2a09:	76 04                	jbe    0x2a0f
    2a0b:	b0 00                	mov    al,0x0
    2a0d:	eb 02                	jmp    0x2a11
    2a0f:	b0 01                	mov    al,0x1
    2a11:	50                   	push   ax
    2a12:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2a15:	06                   	push   es
    2a16:	57                   	push   di
    2a17:	9a 77 1c 3b 2a       	call   0x2a3b:0x1c77
    2a1c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a1f:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2a22:	74 03                	je     0x2a27
    2a24:	e9 5e ff             	jmp    0x2985
    2a27:	8d be fe fe          	lea    di,[bp-0x102]
    2a2b:	16                   	push   ss
    2a2c:	57                   	push   di
    2a2d:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2a31:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    2a36:	06                   	push   es
    2a37:	57                   	push   di
    2a38:	9a 53 1d 4a 2a       	call   0x2a4a:0x1d53
    2a3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a40:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    2a45:	06                   	push   es
    2a46:	57                   	push   di
    2a47:	9a 8c 1d 60 2a       	call   0x2a60:0x1d8c
    2a4c:	8d be fe fe          	lea    di,[bp-0x102]
    2a50:	16                   	push   ss
    2a51:	57                   	push   di
    2a52:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2a56:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2a5b:	06                   	push   es
    2a5c:	57                   	push   di
    2a5d:	9a 53 1d 6f 2a       	call   0x2a6f:0x1d53
    2a62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a65:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    2a6a:	06                   	push   es
    2a6b:	57                   	push   di
    2a6c:	9a 8c 1d 85 2a       	call   0x2a85:0x1d8c
    2a71:	8d be fe fe          	lea    di,[bp-0x102]
    2a75:	16                   	push   ss
    2a76:	57                   	push   di
    2a77:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2a7b:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    2a80:	06                   	push   es
    2a81:	57                   	push   di
    2a82:	9a 53 1d 94 2a       	call   0x2a94:0x1d53
    2a87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a8a:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
    2a8f:	06                   	push   es
    2a90:	57                   	push   di
    2a91:	9a 8c 1d aa 2a       	call   0x2aaa:0x1d8c
    2a96:	8d be fe fe          	lea    di,[bp-0x102]
    2a9a:	16                   	push   ss
    2a9b:	57                   	push   di
    2a9c:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2aa0:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    2aa5:	06                   	push   es
    2aa6:	57                   	push   di
    2aa7:	9a 53 1d 17 2b       	call   0x2b17:0x1d53
    2aac:	bf ff 27             	mov    di,0x27ff
    2aaf:	0e                   	push   cs
    2ab0:	57                   	push   di
    2ab1:	9a 4c 18 d4 2a       	call   0x2ad4:0x184c
    2ab6:	8d be fe fd          	lea    di,[bp-0x202]
    2aba:	16                   	push   ss
    2abb:	57                   	push   di
    2abc:	9a fe 15 cf 2a       	call   0x2acf:0x15fe
    2ac1:	83 ec 08             	sub    sp,0x8
    2ac4:	89 e3                	mov    bx,sp
    2ac6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2aca:	90                   	nop
    2acb:	9b                   	fwait
    2acc:	9a bf 1c e9 2a       	call   0x2ae9:0x1cbf
    2ad1:	9a 4c 18 de 2a       	call   0x2ade:0x184c
    2ad6:	bf ff 27             	mov    di,0x27ff
    2ad9:	0e                   	push   cs
    2ada:	57                   	push   di
    2adb:	9a 4c 18 fe 2a       	call   0x2afe:0x184c
    2ae0:	8d be fe fc          	lea    di,[bp-0x302]
    2ae4:	16                   	push   ss
    2ae5:	57                   	push   di
    2ae6:	9a fe 15 f9 2a       	call   0x2af9:0x15fe
    2aeb:	83 ec 08             	sub    sp,0x8
    2aee:	89 e3                	mov    bx,sp
    2af0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2af4:	90                   	nop
    2af5:	9b                   	fwait
    2af6:	9a e4 1c 35 2f       	call   0x2f35:0x1ce4
    2afb:	9a 4c 18 08 2b       	call   0x2b08:0x184c
    2b00:	bf ff 27             	mov    di,0x27ff
    2b03:	0e                   	push   cs
    2b04:	57                   	push   di
    2b05:	9a 4c 18 ce 2b       	call   0x2bce:0x184c
    2b0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b0d:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    2b12:	06                   	push   es
    2b13:	57                   	push   di
    2b14:	9a 8c 1d 76 2d       	call   0x2d76:0x1d8c
    2b19:	bf 32 1e             	mov    di,0x1e32
    2b1c:	1e                   	push   ds
    2b1d:	57                   	push   di
    2b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b21:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    2b26:	06                   	push   es
    2b27:	57                   	push   di
    2b28:	9a 17 30 3f 2b       	call   0x2b3f:0x3017
    2b2d:	bf 78 1e             	mov    di,0x1e78
    2b30:	1e                   	push   ds
    2b31:	57                   	push   di
    2b32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b35:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2b3a:	06                   	push   es
    2b3b:	57                   	push   di
    2b3c:	9a 17 30 53 2b       	call   0x2b53:0x3017
    2b41:	bf 86 1e             	mov    di,0x1e86
    2b44:	1e                   	push   ds
    2b45:	57                   	push   di
    2b46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b49:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    2b4e:	06                   	push   es
    2b4f:	57                   	push   di
    2b50:	9a 17 30 67 2b       	call   0x2b67:0x3017
    2b55:	bf 86 1e             	mov    di,0x1e86
    2b58:	1e                   	push   ds
    2b59:	57                   	push   di
    2b5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b5d:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    2b62:	06                   	push   es
    2b63:	57                   	push   di
    2b64:	9a 17 30 7b 2b       	call   0x2b7b:0x3017
    2b69:	bf 4e 1e             	mov    di,0x1e4e
    2b6c:	1e                   	push   ds
    2b6d:	57                   	push   di
    2b6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b71:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    2b76:	06                   	push   es
    2b77:	57                   	push   di
    2b78:	9a 17 30 8f 2b       	call   0x2b8f:0x3017
    2b7d:	bf 78 1e             	mov    di,0x1e78
    2b80:	1e                   	push   ds
    2b81:	57                   	push   di
    2b82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b85:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2b8a:	06                   	push   es
    2b8b:	57                   	push   di
    2b8c:	9a 17 30 a3 2b       	call   0x2ba3:0x3017
    2b91:	bf 86 1e             	mov    di,0x1e86
    2b94:	1e                   	push   ds
    2b95:	57                   	push   di
    2b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b99:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    2b9e:	06                   	push   es
    2b9f:	57                   	push   di
    2ba0:	9a 17 30 b7 2b       	call   0x2bb7:0x3017
    2ba5:	bf 86 1e             	mov    di,0x1e86
    2ba8:	1e                   	push   ds
    2ba9:	57                   	push   di
    2baa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bad:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    2bb2:	06                   	push   es
    2bb3:	57                   	push   di
    2bb4:	9a 17 30 f8 31       	call   0x31f8:0x3017
    2bb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bbc:	26 c7 85 30 05 01 00 	mov    WORD PTR es:[di+0x530],0x1
    2bc3:	a1 4c 01             	mov    ax,ds:0x14c
    2bc6:	2d 01 00             	sub    ax,0x1
    2bc9:	71 05                	jno    0x2bd0
    2bcb:	9a 3e 04 e4 2b       	call   0x2be4:0x43e
    2bd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd3:	26 89 85 2e 05       	mov    WORD PTR es:[di+0x52e],ax
    2bd8:	c9                   	leave
    2bd9:	ca 08 00             	retf   0x8
    2bdc:	55                   	push   bp
    2bdd:	89 e5                	mov    bp,sp
    2bdf:	31 c0                	xor    ax,ax
    2be1:	9a 44 04 ff 2b       	call   0x2bff:0x444
    2be6:	6a fe                	push   0xfffe
    2be8:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2bec:	06                   	push   es
    2bed:	57                   	push   di
    2bee:	9a a9 63 28 2c       	call   0x2c28:0x63a9
    2bf3:	c9                   	leave
    2bf4:	ca 08 00             	retf   0x8
    2bf7:	55                   	push   bp
    2bf8:	89 e5                	mov    bp,sp
    2bfa:	31 c0                	xor    ax,ax
    2bfc:	9a 44 04 1e 2c       	call   0x2c1e:0x444
    2c01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c04:	06                   	push   es
    2c05:	57                   	push   di
    2c06:	9a 2d 27 c8 2d       	call   0x2dc8:0x272d
    2c0b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c0e:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    2c12:	c9                   	leave
    2c13:	ca 0c 00             	retf   0xc
    2c16:	55                   	push   bp
    2c17:	89 e5                	mov    bp,sp
    2c19:	31 c0                	xor    ax,ax
    2c1b:	9a 44 04 36 2c       	call   0x2c36:0x444
    2c20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c23:	06                   	push   es
    2c24:	57                   	push   di
    2c25:	9a 56 55 4a 2c       	call   0x2c4a:0x5556
    2c2a:	c9                   	leave
    2c2b:	ca 08 00             	retf   0x8
    2c2e:	55                   	push   bp
    2c2f:	89 e5                	mov    bp,sp
    2c31:	31 c0                	xor    ax,ax
    2c33:	9a 44 04 73 2c       	call   0x2c73:0x444
    2c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c3b:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    2c41:	75 0b                	jne    0x2c4e
    2c43:	6a 00                	push   0x0
    2c45:	06                   	push   es
    2c46:	57                   	push   di
    2c47:	9a 14 3a 58 2c       	call   0x2c58:0x3a14
    2c4c:	eb 0c                	jmp    0x2c5a
    2c4e:	6a 02                	push   0x2
    2c50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c53:	06                   	push   es
    2c54:	57                   	push   di
    2c55:	9a 14 3a e9 43       	call   0x43e9:0x3a14
    2c5a:	c9                   	leave
    2c5b:	ca 08 00             	retf   0x8
    2c5e:	d5 2c                	aad    0x2c
    2c60:	dc 2c                	fsubr  QWORD PTR [si]
    2c62:	e3 2c                	jcxz   0x2c90
    2c64:	ea 2c f1 2c f8       	jmp    0xf82c:0xf12c
    2c69:	2c 55                	sub    al,0x55
    2c6b:	89 e5                	mov    bp,sp
    2c6d:	b8 0e 00             	mov    ax,0xe
    2c70:	9a 44 04 94 2c       	call   0x2c94:0x444
    2c75:	83 ec 0e             	sub    sp,0xe
    2c78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c7b:	26 8b 85 2c 05       	mov    ax,WORD PTR es:[di+0x52c]
    2c80:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2c83:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c86:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c89:	bf 94 00             	mov    di,0x94
    2c8c:	b8 a7 2c             	mov    ax,0x2ca7
    2c8f:	50                   	push   ax
    2c90:	57                   	push   di
    2c91:	9a 55 22 ae 2c       	call   0x2cae:0x2255
    2c96:	08 c0                	or     al,al
    2c98:	75 03                	jne    0x2c9d
    2c9a:	e9 bf 00             	jmp    0x2d5c
    2c9d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ca0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ca3:	bf 94 00             	mov    di,0x94
    2ca6:	b8 bf 2c             	mov    ax,0x2cbf
    2ca9:	50                   	push   ax
    2caa:	57                   	push   di
    2cab:	9a 73 22 1c 2d       	call   0x2d1c:0x2273
    2cb0:	52                   	push   dx
    2cb1:	50                   	push   ax
    2cb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb5:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2cba:	06                   	push   es
    2cbb:	57                   	push   di
    2cbc:	9a 2b 16 12 2d       	call   0x2d12:0x162b
    2cc1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2cc4:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2cc7:	3d 05 00             	cmp    ax,0x5
    2cca:	77 33                	ja     0x2cff
    2ccc:	89 c3                	mov    bx,ax
    2cce:	d1 e3                	shl    bx,1
    2cd0:	2e ff a7 5e 2c       	jmp    WORD PTR cs:[bx+0x2c5e]
    2cd5:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    2cda:	eb 23                	jmp    0x2cff
    2cdc:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    2ce1:	eb 1c                	jmp    0x2cff
    2ce3:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    2ce8:	eb 15                	jmp    0x2cff
    2cea:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    2cef:	eb 0e                	jmp    0x2cff
    2cf1:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    2cf6:	eb 07                	jmp    0x2cff
    2cf8:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    2cfd:	eb 00                	jmp    0x2cff
    2cff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d02:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2d07:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2d0a:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2d0d:	06                   	push   es
    2d0e:	57                   	push   di
    2d0f:	9a 26 13 47 2d       	call   0x2d47:0x1326
    2d14:	2d 01 00             	sub    ax,0x1
    2d17:	71 05                	jno    0x2d1e
    2d19:	9a 3e 04 90 2d       	call   0x2d90:0x43e
    2d1e:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2d21:	31 c0                	xor    ax,ax
    2d23:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    2d26:	7f 34                	jg     0x2d5c
    2d28:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2d2b:	eb 03                	jmp    0x2d30
    2d2d:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    2d30:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2d33:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    2d36:	b0 00                	mov    al,0x0
    2d38:	75 01                	jne    0x2d3b
    2d3a:	40                   	inc    ax
    2d3b:	50                   	push   ax
    2d3c:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2d3f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2d42:	06                   	push   es
    2d43:	57                   	push   di
    2d44:	9a 53 13 52 2d       	call   0x2d52:0x1353
    2d49:	89 c7                	mov    di,ax
    2d4b:	8e c2                	mov    es,dx
    2d4d:	06                   	push   es
    2d4e:	57                   	push   di
    2d4f:	9a 75 12 e6 2d       	call   0x2de6:0x1275
    2d54:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2d57:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    2d5a:	75 d1                	jne    0x2d2d
    2d5c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d62:	26 3b 85 2c 05       	cmp    ax,WORD PTR es:[di+0x52c]
    2d67:	74 1a                	je     0x2d83
    2d69:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d6c:	26 ff b5 2c 05       	push   WORD PTR es:[di+0x52c]
    2d71:	06                   	push   es
    2d72:	57                   	push   di
    2d73:	9a f4 5d 45 44       	call   0x4445:0x5df4
    2d78:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7e:	26 89 85 2c 05       	mov    WORD PTR es:[di+0x52c],ax
    2d83:	c9                   	leave
    2d84:	ca 08 00             	retf   0x8
    2d87:	55                   	push   bp
    2d88:	89 e5                	mov    bp,sp
    2d8a:	b8 02 00             	mov    ax,0x2
    2d8d:	9a 44 04 a0 2d       	call   0x2da0:0x444
    2d92:	83 ec 02             	sub    sp,0x2
    2d95:	a1 4c 01             	mov    ax,ds:0x14c
    2d98:	2d 01 00             	sub    ax,0x1
    2d9b:	71 05                	jno    0x2da2
    2d9d:	9a 3e 04 d7 2d       	call   0x2dd7:0x43e
    2da2:	50                   	push   ax
    2da3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da6:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    2dab:	9a 32 3e a4 2e       	call   0x2ea4:0x3e32
    2db0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2db3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db9:	26 3b 85 2e 05       	cmp    ax,WORD PTR es:[di+0x52e]
    2dbe:	74 0a                	je     0x2dca
    2dc0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2dc3:	06                   	push   es
    2dc4:	57                   	push   di
    2dc5:	9a b3 27 be 2e       	call   0x2ebe:0x27b3
    2dca:	c9                   	leave
    2dcb:	ca 08 00             	retf   0x8
    2dce:	55                   	push   bp
    2dcf:	89 e5                	mov    bp,sp
    2dd1:	b8 08 00             	mov    ax,0x8
    2dd4:	9a 44 04 ed 2d       	call   0x2ded:0x444
    2dd9:	83 ec 08             	sub    sp,0x8
    2ddc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ddf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2de2:	bf 94 00             	mov    di,0x94
    2de5:	b8 00 2e             	mov    ax,0x2e00
    2de8:	50                   	push   ax
    2de9:	57                   	push   di
    2dea:	9a 55 22 07 2e       	call   0x2e07:0x2255
    2def:	08 c0                	or     al,al
    2df1:	75 03                	jne    0x2df6
    2df3:	e9 ca 00             	jmp    0x2ec0
    2df6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2df9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2dfc:	bf 94 00             	mov    di,0x94
    2dff:	b8 22 2e             	mov    ax,0x2e22
    2e02:	50                   	push   ax
    2e03:	57                   	push   di
    2e04:	9a 73 22 29 2e       	call   0x2e29:0x2273
    2e09:	89 c7                	mov    di,ax
    2e0b:	8e c2                	mov    es,dx
    2e0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e10:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    2e15:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e18:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e1b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2e1e:	bf 94 00             	mov    di,0x94
    2e21:	b8 3a 2e             	mov    ax,0x2e3a
    2e24:	50                   	push   ax
    2e25:	57                   	push   di
    2e26:	9a 73 22 4a 2e       	call   0x2e4a:0x2273
    2e2b:	52                   	push   dx
    2e2c:	50                   	push   ax
    2e2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e30:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    2e35:	06                   	push   es
    2e36:	57                   	push   di
    2e37:	9a 2b 16 e5 2e       	call   0x2ee5:0x162b
    2e3c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2e3f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e42:	05 01 00             	add    ax,0x1
    2e45:	71 05                	jno    0x2e4c
    2e47:	9a 3e 04 7e 2e       	call   0x2e7e:0x43e
    2e4c:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    2e50:	b0 00                	mov    al,0x0
    2e52:	7d 01                	jge    0x2e55
    2e54:	40                   	inc    ax
    2e55:	8a c8                	mov    cl,al
    2e57:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2e5b:	b0 00                	mov    al,0x0
    2e5d:	7d 01                	jge    0x2e60
    2e5f:	40                   	inc    ax
    2e60:	8a d0                	mov    dl,al
    2e62:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2e66:	b0 00                	mov    al,0x0
    2e68:	7c 01                	jl     0x2e6b
    2e6a:	40                   	inc    ax
    2e6b:	22 c2                	and    al,dl
    2e6d:	22 c1                	and    al,cl
    2e6f:	08 c0                	or     al,al
    2e71:	74 12                	je     0x2e85
    2e73:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e76:	05 01 00             	add    ax,0x1
    2e79:	71 05                	jno    0x2e80
    2e7b:	9a 3e 04 96 2e       	call   0x2e96:0x43e
    2e80:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e83:	eb 24                	jmp    0x2ea9
    2e85:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2e89:	75 1e                	jne    0x2ea9
    2e8b:	a1 4c 01             	mov    ax,ds:0x14c
    2e8e:	2d 01 00             	sub    ax,0x1
    2e91:	71 05                	jno    0x2e98
    2e93:	9a 3e 04 d5 2e       	call   0x2ed5:0x43e
    2e98:	50                   	push   ax
    2e99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9c:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    2ea1:	9a 32 3e ff ff       	call   0xffff:0x3e32
    2ea6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ea9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2eac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eaf:	26 3b 85 2e 05       	cmp    ax,WORD PTR es:[di+0x52e]
    2eb4:	74 0a                	je     0x2ec0
    2eb6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2eb9:	06                   	push   es
    2eba:	57                   	push   di
    2ebb:	9a b3 27 6a 2f       	call   0x2f6a:0x27b3
    2ec0:	c9                   	leave
    2ec1:	ca 08 00             	retf   0x8
    2ec4:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2ec8:	ff                   	(bad)
    2ec9:	7f 00                	jg     0x2ecb
    2ecb:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2ece:	e5 b8                	in     ax,0xb8
    2ed0:	06                   	push   es
    2ed1:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    2ed5:	ec                   	in     al,dx
    2ed6:	2e 81 ec 06 02       	cs sub sp,0x206
    2edb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ede:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ee1:	bf 94 00             	mov    di,0x94
    2ee4:	b8 fc 2e             	mov    ax,0x2efc
    2ee7:	50                   	push   ax
    2ee8:	57                   	push   di
    2ee9:	9a 55 22 03 2f       	call   0x2f03:0x2255
    2eee:	08 c0                	or     al,al
    2ef0:	74 7a                	je     0x2f6c
    2ef2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ef5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ef8:	bf 94 00             	mov    di,0x94
    2efb:	b8 93 2f             	mov    ax,0x2f93
    2efe:	50                   	push   ax
    2eff:	57                   	push   di
    2f00:	9a 73 22 30 2f       	call   0x2f30:0x2273
    2f05:	89 c7                	mov    di,ax
    2f07:	8e c2                	mov    es,dx
    2f09:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2f0c:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2f0f:	8d be fa fd          	lea    di,[bp-0x206]
    2f13:	16                   	push   ss
    2f14:	57                   	push   di
    2f15:	8d be fa fe          	lea    di,[bp-0x106]
    2f19:	16                   	push   ss
    2f1a:	57                   	push   di
    2f1b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2f1e:	06                   	push   es
    2f1f:	57                   	push   di
    2f20:	9a 2a 51 ff ff       	call   0xffff:0x512a
    2f25:	83 c4 04             	add    sp,0x4
    2f28:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    2f2c:	50                   	push   ax
    2f2d:	9a e9 18 3d 2f       	call   0x2f3d:0x18e9
    2f32:	9a da 08 ff ff       	call   0xffff:0x8da
    2f37:	bf c4 2e             	mov    di,0x2ec4
    2f3a:	9a 16 04 78 2f       	call   0x2f78:0x416
    2f3f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f45:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    2f49:	b0 00                	mov    al,0x0
    2f4b:	7f 01                	jg     0x2f4e
    2f4d:	40                   	inc    ax
    2f4e:	8a d0                	mov    dl,al
    2f50:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2f54:	b0 00                	mov    al,0x0
    2f56:	7e 01                	jle    0x2f59
    2f58:	40                   	inc    ax
    2f59:	22 c2                	and    al,dl
    2f5b:	08 c0                	or     al,al
    2f5d:	74 0d                	je     0x2f6c
    2f5f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f65:	06                   	push   es
    2f66:	57                   	push   di
    2f67:	9a d3 27 21 47       	call   0x4721:0x27d3
    2f6c:	c9                   	leave
    2f6d:	ca 08 00             	retf   0x8
    2f70:	55                   	push   bp
    2f71:	89 e5                	mov    bp,sp
    2f73:	31 c0                	xor    ax,ax
    2f75:	9a 44 04 e9 31       	call   0x31e9:0x444
    2f7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f7d:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    2f83:	b0 00                	mov    al,0x0
    2f85:	75 01                	jne    0x2f88
    2f87:	40                   	inc    ax
    2f88:	50                   	push   ax
    2f89:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2f8e:	06                   	push   es
    2f8f:	57                   	push   di
    2f90:	9a 75 12 ff ff       	call   0xffff:0x1275
    2f95:	c9                   	leave
    2f96:	ca 08 00             	retf   0x8
    2f99:	10 56 61             	adc    BYTE PTR [bp+0x61],dl
    2f9c:	72 69                	jb     0x3007
    2f9e:	61                   	popa
    2f9f:	74 69                	je     0x300a
    2fa1:	6f                   	outs   dx,WORD PTR ds:[si]
    2fa2:	6e                   	outs   dx,BYTE PTR ds:[si]
    2fa3:	43                   	inc    bx
    2fa4:	61                   	popa
    2fa5:	70 69                	jo     0x3010
    2fa7:	74 61                	je     0x300a
    2fa9:	6c                   	ins    BYTE PTR es:[di],dx
    2faa:	0d 44 69             	or     ax,0x6944
    2fad:	73 74                	jae    0x3023
    2faf:	72 69                	jb     0x301a
    2fb1:	62 75 74             	bound  si,DWORD PTR [di+0x74]
    2fb4:	69 6f 6e 73 00       	imul   bp,WORD PTR [bx+0x6e],0x73
    2fb9:	00 00                	add    BYTE PTR [bx+si],al
    2fbb:	00 0d                	add    BYTE PTR [di],cl
    2fbd:	52                   	push   dx
    2fbe:	65 64 75 63          	gs fs jne 0x3025
    2fc2:	74 43                	je     0x3007
    2fc4:	61                   	popa
    2fc5:	70 69                	jo     0x3030
    2fc7:	74 61                	je     0x302a
    2fc9:	6c                   	ins    BYTE PTR es:[di],dx
    2fca:	0e                   	push   cs
    2fcb:	41                   	inc    cx
    2fcc:	75 67                	jne    0x3035
    2fce:	6d                   	ins    WORD PTR es:[di],dx
    2fcf:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2fd1:	74 43                	je     0x3016
    2fd3:	61                   	popa
    2fd4:	70 69                	jo     0x303f
    2fd6:	74 61                	je     0x3039
    2fd8:	6c                   	ins    BYTE PTR es:[di],dx
    2fd9:	03 43 41             	add    ax,WORD PTR [bp+di+0x41]
    2fdc:	46                   	inc    si
    2fdd:	0a 45 6d             	or     al,BYTE PTR [di+0x6d]
    2fe0:	70 6c                	jo     0x304e
    2fe2:	6f                   	outs   dx,WORD PTR ds:[si]
    2fe3:	69 73 43 41 46       	imul   si,WORD PTR [bp+di+0x43],0x4641
    2fe8:	0d 52 65             	or     ax,0x6552
    2feb:	73 73                	jae    0x3060
    2fed:	6f                   	outs   dx,WORD PTR ds:[si]
    2fee:	75 72                	jne    0x3062
    2ff0:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    2ff3:	43                   	inc    bx
    2ff4:	41                   	inc    cx
    2ff5:	46                   	inc    si
    2ff6:	07                   	pop    es
    2ff7:	45                   	inc    bp
    2ff8:	6d                   	ins    WORD PTR es:[di],dx
    2ff9:	70 72                	jo     0x306d
    2ffb:	75 6e                	jne    0x306b
    2ffd:	74 0f                	je     0x300e
    2fff:	52                   	push   dx
    3000:	65 6d                	gs ins WORD PTR es:[di],dx
    3002:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    3005:	72 73                	jb     0x307a
    3007:	45                   	inc    bp
    3008:	6d                   	ins    WORD PTR es:[di],dx
    3009:	70 72                	jo     0x307d
    300b:	75 6e                	jne    0x307b
    300d:	74 0e                	je     0x301d
    300f:	45                   	inc    bp
    3010:	6e                   	outs   dx,BYTE PTR ds:[si]
    3011:	63 61 69             	arpl   WORD PTR [bx+di+0x69],sp
    3014:	73 73                	jae    0x3089
    3016:	45                   	inc    bp
    3017:	6d                   	ins    WORD PTR es:[di],dx
    3018:	70 72                	jo     0x308c
    301a:	75 6e                	jne    0x308a
    301c:	74 0d                	je     0x302b
    301e:	41                   	inc    cx
    301f:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    3022:	74 4d                	je     0x3071
    3024:	61                   	popa
    3025:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3028:	6e                   	outs   dx,BYTE PTR ds:[si]
    3029:	65 73 10             	gs jae 0x303c
    302c:	43                   	inc    bx
    302d:	6f                   	outs   dx,WORD PTR ds:[si]
    302e:	75 74                	jne    0x30a4
    3030:	55                   	push   bp
    3031:	6e                   	outs   dx,BYTE PTR ds:[si]
    3032:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
    3037:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    303a:	6e                   	outs   dx,BYTE PTR ds:[si]
    303b:	65 10 41 63          	adc    BYTE PTR gs:[bx+di+0x63],al
    303f:	68 61 74             	push   0x7461
    3042:	73 44                	jae    0x3088
    3044:	65 4d                	gs dec bp
    3046:	61                   	popa
    3047:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    304a:	6e                   	outs   dx,BYTE PTR ds:[si]
    304b:	65 73 12             	gs jae 0x3060
    304e:	43                   	inc    bx
    304f:	65 73 73             	gs jae 0x30c5
    3052:	69 6f 6e 73 44       	imul   bp,WORD PTR [bx+0x6e],0x4473
    3057:	65 4d                	gs dec bp
    3059:	61                   	popa
    305a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    305d:	6e                   	outs   dx,BYTE PTR ds:[si]
    305e:	65 73 08             	gs jae 0x3069
    3061:	43                   	inc    bx
    3062:	65 73 73             	gs jae 0x30d8
    3065:	69 6f 6e 73 0c       	imul   bp,WORD PTR [bx+0x6e],0xc73
    306a:	45                   	inc    bp
    306b:	6d                   	ins    WORD PTR es:[di],dx
    306c:	70 6c                	jo     0x30da
    306e:	6f                   	outs   dx,WORD PTR ds:[si]
    306f:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    3074:	46                   	inc    si
    3075:	52                   	push   dx
    3076:	0f 52 65 73          	rsqrtps xmm4,XMMWORD PTR [di+0x73]
    307a:	73 6f                	jae    0x30eb
    307c:	75 72                	jne    0x30f0
    307e:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    3081:	56                   	push   si
    3082:	61                   	popa
    3083:	72 46                	jb     0x30cb
    3085:	52                   	push   dx
    3086:	0c 45                	or     al,0x45
    3088:	6d                   	ins    WORD PTR es:[di],dx
    3089:	6f                   	outs   dx,WORD PTR ds:[si]
    308a:	69 6e 73 52 56       	imul   bp,WORD PTR [bp+0x73],0x5652
    308f:	61                   	popa
    3090:	72 46                	jb     0x30d8
    3092:	52                   	push   dx
    3093:	0c 52                	or     al,0x52
    3095:	6d                   	ins    WORD PTR es:[di],dx
    3096:	6f                   	outs   dx,WORD PTR ds:[si]
    3097:	69 6e 73 45 56       	imul   bp,WORD PTR [bp+0x73],0x5645
    309c:	61                   	popa
    309d:	72 46                	jb     0x30e5
    309f:	52                   	push   dx
    30a0:	0b 56 61             	or     dx,WORD PTR [bp+0x61]
    30a3:	6c                   	ins    BYTE PTR es:[di],dx
    30a4:	65 75 72             	gs jne 0x3119
    30a7:	53                   	push   bx
    30a8:	74 6f                	je     0x3119
    30aa:	63 6b 11             	arpl   WORD PTR [bp+di+0x11],bp
    30ad:	45                   	inc    bp
    30ae:	6d                   	ins    WORD PTR es:[di],dx
    30af:	70 6c                	jo     0x311d
    30b1:	6f                   	outs   dx,WORD PTR ds:[si]
    30b2:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    30b7:	53                   	push   bx
    30b8:	74 6f                	je     0x3129
    30ba:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    30bd:	31 14                	xor    WORD PTR [si],dx
    30bf:	52                   	push   dx
    30c0:	65 73 73             	gs jae 0x3136
    30c3:	6f                   	outs   dx,WORD PTR ds:[si]
    30c4:	75 72                	jne    0x3138
    30c6:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    30c9:	56                   	push   si
    30ca:	61                   	popa
    30cb:	72 53                	jb     0x3120
    30cd:	74 6f                	je     0x313e
    30cf:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    30d2:	31 11                	xor    WORD PTR [bx+di],dx
    30d4:	45                   	inc    bp
    30d5:	6d                   	ins    WORD PTR es:[di],dx
    30d6:	70 6c                	jo     0x3144
    30d8:	6f                   	outs   dx,WORD PTR ds:[si]
    30d9:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    30de:	53                   	push   bx
    30df:	74 6f                	je     0x3150
    30e1:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    30e4:	32 14                	xor    dl,BYTE PTR [si]
    30e6:	52                   	push   dx
    30e7:	65 73 73             	gs jae 0x315d
    30ea:	6f                   	outs   dx,WORD PTR ds:[si]
    30eb:	75 72                	jne    0x315f
    30ed:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    30f0:	56                   	push   si
    30f1:	61                   	popa
    30f2:	72 53                	jb     0x3147
    30f4:	74 6f                	je     0x3165
    30f6:	63 6b 50             	arpl   WORD PTR [bp+di+0x50],bp
    30f9:	32 0c                	xor    cl,BYTE PTR [si]
    30fb:	46                   	inc    si
    30fc:	6f                   	outs   dx,WORD PTR ds:[si]
    30fd:	75 72                	jne    0x3171
    30ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    3100:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    3105:	72 73                	jb     0x317a
    3107:	11 44 69             	adc    WORD PTR [si+0x69],ax
    310a:	6d                   	ins    WORD PTR es:[di],dx
    310b:	69 6e 75 74 43       	imul   bp,WORD PTR [bp+0x75],0x4374
    3110:	72 65                	jb     0x3177
    3112:	64 69 74 46 6f 75    	imul   si,WORD PTR fs:[si+0x46],0x756f
    3118:	72 11                	jb     0x312b
    311a:	41                   	inc    cx
    311b:	75 67                	jne    0x3184
    311d:	6d                   	ins    WORD PTR es:[di],dx
    311e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3120:	74 43                	je     0x3165
    3122:	72 65                	jb     0x3189
    3124:	64 69 74 46 6f 75    	imul   si,WORD PTR fs:[si+0x46],0x756f
    312a:	72 07                	jb     0x3133
    312c:	43                   	inc    bx
    312d:	6c                   	ins    BYTE PTR es:[di],dx
    312e:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    3133:	13 41 75             	adc    ax,WORD PTR [bx+di+0x75]
    3136:	67 6d                	ins    WORD PTR es:[edi],dx
    3138:	65 6e                	outs   dx,BYTE PTR gs:[si]
    313a:	74 43                	je     0x317f
    313c:	72 65                	jb     0x31a3
    313e:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    3144:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3146:	74 13                	je     0x315b
    3148:	44                   	inc    sp
    3149:	69 6d 69 6e 75       	imul   bp,WORD PTR [di+0x69],0x756e
    314e:	74 43                	je     0x3193
    3150:	72 65                	jb     0x31b7
    3152:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    3158:	65 6e                	outs   dx,BYTE PTR gs:[si]
    315a:	74 05                	je     0x3161
    315c:	49                   	dec    cx
    315d:	6d                   	ins    WORD PTR es:[di],dx
    315e:	70 6f                	jo     0x31cf
    3160:	74 11                	je     0x3173
    3162:	44                   	inc    sp
    3163:	69 6d 69 6e 75       	imul   bp,WORD PTR [di+0x69],0x756e
    3168:	74 44                	je     0x31ae
    316a:	65 74 74             	gs je  0x31e1
    316d:	65 73 46             	gs jae 0x31b6
    3170:	69 73 63 11 41       	imul   si,WORD PTR [bp+di+0x63],0x4111
    3175:	75 67                	jne    0x31de
    3177:	6d                   	ins    WORD PTR es:[di],dx
    3178:	65 6e                	outs   dx,BYTE PTR gs:[si]
    317a:	74 44                	je     0x31c0
    317c:	65 74 74             	gs je  0x31f3
    317f:	65 73 46             	gs jae 0x31c8
    3182:	69 73 63 11 41       	imul   si,WORD PTR [bp+di+0x63],0x4111
    3187:	75 67                	jne    0x31f0
    3189:	6d                   	ins    WORD PTR es:[di],dx
    318a:	65 6e                	outs   dx,BYTE PTR gs:[si]
    318c:	74 54                	je     0x31e2
    318e:	72 65                	jb     0x31f5
    3190:	73 6f                	jae    0x3201
    3192:	72 65                	jb     0x31f9
    3194:	72 69                	jb     0x31ff
    3196:	65 11 44 69          	adc    WORD PTR gs:[si+0x69],ax
    319a:	6d                   	ins    WORD PTR es:[di],dx
    319b:	69 6e 75 74 54       	imul   bp,WORD PTR [bp+0x75],0x5474
    31a0:	72 65                	jb     0x3207
    31a2:	73 6f                	jae    0x3213
    31a4:	72 65                	jb     0x320b
    31a6:	72 69                	jb     0x3211
    31a8:	65 0c 45             	gs or  al,0x45
    31ab:	6d                   	ins    WORD PTR es:[di],dx
    31ac:	70 6c                	jo     0x321a
    31ae:	6f                   	outs   dx,WORD PTR ds:[si]
    31af:	69 73 56 61 72       	imul   si,WORD PTR [bp+di+0x56],0x7261
    31b4:	41                   	inc    cx
    31b5:	43                   	inc    bx
    31b6:	0f 52 65 73          	rsqrtps xmm4,XMMWORD PTR [di+0x73]
    31ba:	73 6f                	jae    0x322b
    31bc:	75 72                	jne    0x3230
    31be:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    31c1:	56                   	push   si
    31c2:	61                   	popa
    31c3:	72 41                	jb     0x3206
    31c5:	43                   	inc    bx
    31c6:	0c 45                	or     al,0x45
    31c8:	6d                   	ins    WORD PTR es:[di],dx
    31c9:	6f                   	outs   dx,WORD PTR ds:[si]
    31ca:	69 6e 73 52 56       	imul   bp,WORD PTR [bp+0x73],0x5652
    31cf:	61                   	popa
    31d0:	72 41                	jb     0x3213
    31d2:	43                   	inc    bx
    31d3:	0c 52                	or     al,0x52
    31d5:	6d                   	ins    WORD PTR es:[di],dx
    31d6:	6f                   	outs   dx,WORD PTR ds:[si]
    31d7:	69 6e 73 45 56       	imul   bp,WORD PTR [bp+0x73],0x5645
    31dc:	61                   	popa
    31dd:	72 41                	jb     0x3220
    31df:	43                   	inc    bx
    31e0:	55                   	push   bp
    31e1:	89 e5                	mov    bp,sp
    31e3:	b8 5e 00             	mov    ax,0x5e
    31e6:	9a 44 04 ff 31       	call   0x31ff:0x444
    31eb:	83 ec 5e             	sub    sp,0x5e
    31ee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    31f1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    31f4:	bf 38 01             	mov    di,0x138
    31f7:	b8 ff ff             	mov    ax,0xffff
    31fa:	50                   	push   ax
    31fb:	57                   	push   di
    31fc:	9a 73 22 9e 43       	call   0x439e:0x2273
    3201:	89 c7                	mov    di,ax
    3203:	8e c2                	mov    es,dx
    3205:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    3208:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    320b:	bf 99 2f             	mov    di,0x2f99
    320e:	0e                   	push   cs
    320f:	57                   	push   di
    3210:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3213:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3218:	06                   	push   es
    3219:	57                   	push   di
    321a:	9a 9b 3b 3d 32       	call   0x323d:0x3b9b
    321f:	89 c7                	mov    di,ax
    3221:	8e c2                	mov    es,dx
    3223:	06                   	push   es
    3224:	57                   	push   di
    3225:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3228:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    322c:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3230:	bf aa 2f             	mov    di,0x2faa
    3233:	0e                   	push   cs
    3234:	57                   	push   di
    3235:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3238:	06                   	push   es
    3239:	57                   	push   di
    323a:	9a 9b 3b 94 32       	call   0x3294:0x3b9b
    323f:	89 c7                	mov    di,ax
    3241:	8e c2                	mov    es,dx
    3243:	06                   	push   es
    3244:	57                   	push   di
    3245:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3248:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    324c:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3250:	9b de e1             	fsubrp st(1),st
    3253:	83 ec 08             	sub    sp,0x8
    3256:	89 e3                	mov    bx,sp
    3258:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    325c:	90                   	nop
    325d:	9b                   	fwait
    325e:	9a a6 2f 4d 34       	call   0x344d:0x2fa6
    3263:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3267:	90                   	nop
    3268:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    326d:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    3273:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3277:	90                   	nop
    3278:	9b                   	fwait
    3279:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    327c:	9e                   	sahf
    327d:	76 4e                	jbe    0x32cd
    327f:	6a 00                	push   0x0
    3281:	6a 00                	push   0x0
    3283:	6a 00                	push   0x0
    3285:	6a 00                	push   0x0
    3287:	bf bc 2f             	mov    di,0x2fbc
    328a:	0e                   	push   cs
    328b:	57                   	push   di
    328c:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    328f:	06                   	push   es
    3290:	57                   	push   di
    3291:	9a 9b 3b bc 32       	call   0x32bc:0x3b9b
    3296:	89 c7                	mov    di,ax
    3298:	8e c2                	mov    es,dx
    329a:	06                   	push   es
    329b:	57                   	push   di
    329c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    329f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    32a3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    32a6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    32a9:	ff 76 fa             	push   WORD PTR [bp-0x6]
    32ac:	ff 76 f8             	push   WORD PTR [bp-0x8]
    32af:	bf ca 2f             	mov    di,0x2fca
    32b2:	0e                   	push   cs
    32b3:	57                   	push   di
    32b4:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    32b7:	06                   	push   es
    32b8:	57                   	push   di
    32b9:	9a 9b 3b ec 32       	call   0x32ec:0x3b9b
    32be:	89 c7                	mov    di,ax
    32c0:	8e c2                	mov    es,dx
    32c2:	06                   	push   es
    32c3:	57                   	push   di
    32c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32c7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    32cb:	eb 52                	jmp    0x331f
    32cd:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    32d1:	9b d9 e0             	fchs
    32d4:	83 ec 08             	sub    sp,0x8
    32d7:	89 e3                	mov    bx,sp
    32d9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    32dd:	90                   	nop
    32de:	9b                   	fwait
    32df:	bf bc 2f             	mov    di,0x2fbc
    32e2:	0e                   	push   cs
    32e3:	57                   	push   di
    32e4:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    32e7:	06                   	push   es
    32e8:	57                   	push   di
    32e9:	9a 9b 3b 10 33       	call   0x3310:0x3b9b
    32ee:	89 c7                	mov    di,ax
    32f0:	8e c2                	mov    es,dx
    32f2:	06                   	push   es
    32f3:	57                   	push   di
    32f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32f7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    32fb:	6a 00                	push   0x0
    32fd:	6a 00                	push   0x0
    32ff:	6a 00                	push   0x0
    3301:	6a 00                	push   0x0
    3303:	bf ca 2f             	mov    di,0x2fca
    3306:	0e                   	push   cs
    3307:	57                   	push   di
    3308:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    330b:	06                   	push   es
    330c:	57                   	push   di
    330d:	9a 9b 3b 2c 33       	call   0x332c:0x3b9b
    3312:	89 c7                	mov    di,ax
    3314:	8e c2                	mov    es,dx
    3316:	06                   	push   es
    3317:	57                   	push   di
    3318:	26 c4 3d             	les    di,DWORD PTR es:[di]
    331b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    331f:	bf d9 2f             	mov    di,0x2fd9
    3322:	0e                   	push   cs
    3323:	57                   	push   di
    3324:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3327:	06                   	push   es
    3328:	57                   	push   di
    3329:	9a 9b 3b 6c 33       	call   0x336c:0x3b9b
    332e:	89 c7                	mov    di,ax
    3330:	8e c2                	mov    es,dx
    3332:	06                   	push   es
    3333:	57                   	push   di
    3334:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3337:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    333b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    333f:	90                   	nop
    3340:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    3345:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    334b:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    334f:	90                   	nop
    3350:	9b                   	fwait
    3351:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3354:	9e                   	sahf
    3355:	76 4e                	jbe    0x33a5
    3357:	6a 00                	push   0x0
    3359:	6a 00                	push   0x0
    335b:	6a 00                	push   0x0
    335d:	6a 00                	push   0x0
    335f:	bf dd 2f             	mov    di,0x2fdd
    3362:	0e                   	push   cs
    3363:	57                   	push   di
    3364:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3367:	06                   	push   es
    3368:	57                   	push   di
    3369:	9a 9b 3b 94 33       	call   0x3394:0x3b9b
    336e:	89 c7                	mov    di,ax
    3370:	8e c2                	mov    es,dx
    3372:	06                   	push   es
    3373:	57                   	push   di
    3374:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3377:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    337b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    337e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3381:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3384:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3387:	bf e8 2f             	mov    di,0x2fe8
    338a:	0e                   	push   cs
    338b:	57                   	push   di
    338c:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    338f:	06                   	push   es
    3390:	57                   	push   di
    3391:	9a 9b 3b c4 33       	call   0x33c4:0x3b9b
    3396:	89 c7                	mov    di,ax
    3398:	8e c2                	mov    es,dx
    339a:	06                   	push   es
    339b:	57                   	push   di
    339c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    339f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    33a3:	eb 52                	jmp    0x33f7
    33a5:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    33a9:	9b d9 e0             	fchs
    33ac:	83 ec 08             	sub    sp,0x8
    33af:	89 e3                	mov    bx,sp
    33b1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    33b5:	90                   	nop
    33b6:	9b                   	fwait
    33b7:	bf dd 2f             	mov    di,0x2fdd
    33ba:	0e                   	push   cs
    33bb:	57                   	push   di
    33bc:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    33bf:	06                   	push   es
    33c0:	57                   	push   di
    33c1:	9a 9b 3b e8 33       	call   0x33e8:0x3b9b
    33c6:	89 c7                	mov    di,ax
    33c8:	8e c2                	mov    es,dx
    33ca:	06                   	push   es
    33cb:	57                   	push   di
    33cc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33cf:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    33d3:	6a 00                	push   0x0
    33d5:	6a 00                	push   0x0
    33d7:	6a 00                	push   0x0
    33d9:	6a 00                	push   0x0
    33db:	bf e8 2f             	mov    di,0x2fe8
    33de:	0e                   	push   cs
    33df:	57                   	push   di
    33e0:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    33e3:	06                   	push   es
    33e4:	57                   	push   di
    33e5:	9a 9b 3b 04 34       	call   0x3404:0x3b9b
    33ea:	89 c7                	mov    di,ax
    33ec:	8e c2                	mov    es,dx
    33ee:	06                   	push   es
    33ef:	57                   	push   di
    33f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33f3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    33f7:	bf f6 2f             	mov    di,0x2ff6
    33fa:	0e                   	push   cs
    33fb:	57                   	push   di
    33fc:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    33ff:	06                   	push   es
    3400:	57                   	push   di
    3401:	9a 9b 3b 29 34       	call   0x3429:0x3b9b
    3406:	89 c7                	mov    di,ax
    3408:	8e c2                	mov    es,dx
    340a:	06                   	push   es
    340b:	57                   	push   di
    340c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    340f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3413:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3417:	bf f6 2f             	mov    di,0x2ff6
    341a:	0e                   	push   cs
    341b:	57                   	push   di
    341c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341f:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3424:	06                   	push   es
    3425:	57                   	push   di
    3426:	9a 9b 3b 80 34       	call   0x3480:0x3b9b
    342b:	89 c7                	mov    di,ax
    342d:	8e c2                	mov    es,dx
    342f:	06                   	push   es
    3430:	57                   	push   di
    3431:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3434:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3438:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    343c:	9b de e1             	fsubrp st(1),st
    343f:	83 ec 08             	sub    sp,0x8
    3442:	89 e3                	mov    bx,sp
    3444:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3448:	90                   	nop
    3449:	9b                   	fwait
    344a:	9a a6 2f 70 35       	call   0x3570:0x2fa6
    344f:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3453:	90                   	nop
    3454:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    3459:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    345f:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3463:	90                   	nop
    3464:	9b                   	fwait
    3465:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3468:	9e                   	sahf
    3469:	76 4e                	jbe    0x34b9
    346b:	6a 00                	push   0x0
    346d:	6a 00                	push   0x0
    346f:	6a 00                	push   0x0
    3471:	6a 00                	push   0x0
    3473:	bf fe 2f             	mov    di,0x2ffe
    3476:	0e                   	push   cs
    3477:	57                   	push   di
    3478:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    347b:	06                   	push   es
    347c:	57                   	push   di
    347d:	9a 9b 3b a8 34       	call   0x34a8:0x3b9b
    3482:	89 c7                	mov    di,ax
    3484:	8e c2                	mov    es,dx
    3486:	06                   	push   es
    3487:	57                   	push   di
    3488:	26 c4 3d             	les    di,DWORD PTR es:[di]
    348b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    348f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3492:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3495:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3498:	ff 76 f8             	push   WORD PTR [bp-0x8]
    349b:	bf 0e 30             	mov    di,0x300e
    349e:	0e                   	push   cs
    349f:	57                   	push   di
    34a0:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    34a3:	06                   	push   es
    34a4:	57                   	push   di
    34a5:	9a 9b 3b d8 34       	call   0x34d8:0x3b9b
    34aa:	89 c7                	mov    di,ax
    34ac:	8e c2                	mov    es,dx
    34ae:	06                   	push   es
    34af:	57                   	push   di
    34b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34b3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    34b7:	eb 52                	jmp    0x350b
    34b9:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    34bd:	9b d9 e0             	fchs
    34c0:	83 ec 08             	sub    sp,0x8
    34c3:	89 e3                	mov    bx,sp
    34c5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    34c9:	90                   	nop
    34ca:	9b                   	fwait
    34cb:	bf fe 2f             	mov    di,0x2ffe
    34ce:	0e                   	push   cs
    34cf:	57                   	push   di
    34d0:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    34d3:	06                   	push   es
    34d4:	57                   	push   di
    34d5:	9a 9b 3b fc 34       	call   0x34fc:0x3b9b
    34da:	89 c7                	mov    di,ax
    34dc:	8e c2                	mov    es,dx
    34de:	06                   	push   es
    34df:	57                   	push   di
    34e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34e3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    34e7:	6a 00                	push   0x0
    34e9:	6a 00                	push   0x0
    34eb:	6a 00                	push   0x0
    34ed:	6a 00                	push   0x0
    34ef:	bf 0e 30             	mov    di,0x300e
    34f2:	0e                   	push   cs
    34f3:	57                   	push   di
    34f4:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    34f7:	06                   	push   es
    34f8:	57                   	push   di
    34f9:	9a 9b 3b 1d 35       	call   0x351d:0x3b9b
    34fe:	89 c7                	mov    di,ax
    3500:	8e c2                	mov    es,dx
    3502:	06                   	push   es
    3503:	57                   	push   di
    3504:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3507:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    350b:	bf 1d 30             	mov    di,0x301d
    350e:	0e                   	push   cs
    350f:	57                   	push   di
    3510:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3513:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3518:	06                   	push   es
    3519:	57                   	push   di
    351a:	9a 9b 3b 4c 35       	call   0x354c:0x3b9b
    351f:	89 c7                	mov    di,ax
    3521:	8e c2                	mov    es,dx
    3523:	06                   	push   es
    3524:	57                   	push   di
    3525:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3528:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    352c:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    352f:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    3532:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    3536:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    353a:	bf 2b 30             	mov    di,0x302b
    353d:	0e                   	push   cs
    353e:	57                   	push   di
    353f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3542:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3547:	06                   	push   es
    3548:	57                   	push   di
    3549:	9a 9b 3b 91 35       	call   0x3591:0x3b9b
    354e:	89 c7                	mov    di,ax
    3550:	8e c2                	mov    es,dx
    3552:	06                   	push   es
    3553:	57                   	push   di
    3554:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3557:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    355b:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    355f:	9b de c9             	fmulp  st(1),st
    3562:	83 ec 08             	sub    sp,0x8
    3565:	89 e3                	mov    bx,sp
    3567:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    356b:	90                   	nop
    356c:	9b                   	fwait
    356d:	9a a6 2f 82 36       	call   0x3682:0x2fa6
    3572:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3576:	90                   	nop
    3577:	9b                   	fwait
    3578:	ff 76 fe             	push   WORD PTR [bp-0x2]
    357b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    357e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3581:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3584:	bf 3c 30             	mov    di,0x303c
    3587:	0e                   	push   cs
    3588:	57                   	push   di
    3589:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    358c:	06                   	push   es
    358d:	57                   	push   di
    358e:	9a 9b 3b ad 35       	call   0x35ad:0x3b9b
    3593:	89 c7                	mov    di,ax
    3595:	8e c2                	mov    es,dx
    3597:	06                   	push   es
    3598:	57                   	push   di
    3599:	26 c4 3d             	les    di,DWORD PTR es:[di]
    359c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    35a0:	bf 60 30             	mov    di,0x3060
    35a3:	0e                   	push   cs
    35a4:	57                   	push   di
    35a5:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    35a8:	06                   	push   es
    35a9:	57                   	push   di
    35aa:	9a 9b 3b d4 35       	call   0x35d4:0x3b9b
    35af:	89 c7                	mov    di,ax
    35b1:	8e c2                	mov    es,dx
    35b3:	06                   	push   es
    35b4:	57                   	push   di
    35b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35b8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    35bc:	83 ec 08             	sub    sp,0x8
    35bf:	89 e3                	mov    bx,sp
    35c1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    35c5:	90                   	nop
    35c6:	9b                   	fwait
    35c7:	bf 4d 30             	mov    di,0x304d
    35ca:	0e                   	push   cs
    35cb:	57                   	push   di
    35cc:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    35cf:	06                   	push   es
    35d0:	57                   	push   di
    35d1:	9a 9b 3b f0 35       	call   0x35f0:0x3b9b
    35d6:	89 c7                	mov    di,ax
    35d8:	8e c2                	mov    es,dx
    35da:	06                   	push   es
    35db:	57                   	push   di
    35dc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35df:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    35e3:	bf bc 2f             	mov    di,0x2fbc
    35e6:	0e                   	push   cs
    35e7:	57                   	push   di
    35e8:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    35eb:	06                   	push   es
    35ec:	57                   	push   di
    35ed:	9a 9b 3b 10 36       	call   0x3610:0x3b9b
    35f2:	89 c7                	mov    di,ax
    35f4:	8e c2                	mov    es,dx
    35f6:	06                   	push   es
    35f7:	57                   	push   di
    35f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35fb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    35ff:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3603:	bf dd 2f             	mov    di,0x2fdd
    3606:	0e                   	push   cs
    3607:	57                   	push   di
    3608:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    360b:	06                   	push   es
    360c:	57                   	push   di
    360d:	9a 9b 3b 37 36       	call   0x3637:0x3b9b
    3612:	89 c7                	mov    di,ax
    3614:	8e c2                	mov    es,dx
    3616:	06                   	push   es
    3617:	57                   	push   di
    3618:	26 c4 3d             	les    di,DWORD PTR es:[di]
    361b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    361f:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3623:	9b de c1             	faddp  st(1),st
    3626:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    362a:	bf fe 2f             	mov    di,0x2ffe
    362d:	0e                   	push   cs
    362e:	57                   	push   di
    362f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3632:	06                   	push   es
    3633:	57                   	push   di
    3634:	9a 9b 3b 5e 36       	call   0x365e:0x3b9b
    3639:	89 c7                	mov    di,ax
    363b:	8e c2                	mov    es,dx
    363d:	06                   	push   es
    363e:	57                   	push   di
    363f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3642:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3646:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    364a:	9b de c1             	faddp  st(1),st
    364d:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    3651:	bf 3c 30             	mov    di,0x303c
    3654:	0e                   	push   cs
    3655:	57                   	push   di
    3656:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3659:	06                   	push   es
    365a:	57                   	push   di
    365b:	9a 9b 3b 9c 36       	call   0x369c:0x3b9b
    3660:	89 c7                	mov    di,ax
    3662:	8e c2                	mov    es,dx
    3664:	06                   	push   es
    3665:	57                   	push   di
    3666:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3669:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    366d:	9b db 6e b6          	fld    TBYTE PTR [bp-0x4a]
    3671:	9b de c1             	faddp  st(1),st
    3674:	83 ec 08             	sub    sp,0x8
    3677:	89 e3                	mov    bx,sp
    3679:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    367d:	90                   	nop
    367e:	9b                   	fwait
    367f:	9a a6 2f 4a 37       	call   0x374a:0x2fa6
    3684:	83 ec 08             	sub    sp,0x8
    3687:	89 e3                	mov    bx,sp
    3689:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    368d:	90                   	nop
    368e:	9b                   	fwait
    368f:	bf 69 30             	mov    di,0x3069
    3692:	0e                   	push   cs
    3693:	57                   	push   di
    3694:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3697:	06                   	push   es
    3698:	57                   	push   di
    3699:	9a 9b 3b b8 36       	call   0x36b8:0x3b9b
    369e:	89 c7                	mov    di,ax
    36a0:	8e c2                	mov    es,dx
    36a2:	06                   	push   es
    36a3:	57                   	push   di
    36a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36a7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    36ab:	bf ca 2f             	mov    di,0x2fca
    36ae:	0e                   	push   cs
    36af:	57                   	push   di
    36b0:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    36b3:	06                   	push   es
    36b4:	57                   	push   di
    36b5:	9a 9b 3b d8 36       	call   0x36d8:0x3b9b
    36ba:	89 c7                	mov    di,ax
    36bc:	8e c2                	mov    es,dx
    36be:	06                   	push   es
    36bf:	57                   	push   di
    36c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36c3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    36c7:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    36cb:	bf e8 2f             	mov    di,0x2fe8
    36ce:	0e                   	push   cs
    36cf:	57                   	push   di
    36d0:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    36d3:	06                   	push   es
    36d4:	57                   	push   di
    36d5:	9a 9b 3b ff 36       	call   0x36ff:0x3b9b
    36da:	89 c7                	mov    di,ax
    36dc:	8e c2                	mov    es,dx
    36de:	06                   	push   es
    36df:	57                   	push   di
    36e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36e3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    36e7:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    36eb:	9b de c1             	faddp  st(1),st
    36ee:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    36f2:	bf 0e 30             	mov    di,0x300e
    36f5:	0e                   	push   cs
    36f6:	57                   	push   di
    36f7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    36fa:	06                   	push   es
    36fb:	57                   	push   di
    36fc:	9a 9b 3b 26 37       	call   0x3726:0x3b9b
    3701:	89 c7                	mov    di,ax
    3703:	8e c2                	mov    es,dx
    3705:	06                   	push   es
    3706:	57                   	push   di
    3707:	26 c4 3d             	les    di,DWORD PTR es:[di]
    370a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    370e:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    3712:	9b de c1             	faddp  st(1),st
    3715:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    3719:	bf 4d 30             	mov    di,0x304d
    371c:	0e                   	push   cs
    371d:	57                   	push   di
    371e:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3721:	06                   	push   es
    3722:	57                   	push   di
    3723:	9a 9b 3b 64 37       	call   0x3764:0x3b9b
    3728:	89 c7                	mov    di,ax
    372a:	8e c2                	mov    es,dx
    372c:	06                   	push   es
    372d:	57                   	push   di
    372e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3731:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3735:	9b db 6e b6          	fld    TBYTE PTR [bp-0x4a]
    3739:	9b de c1             	faddp  st(1),st
    373c:	83 ec 08             	sub    sp,0x8
    373f:	89 e3                	mov    bx,sp
    3741:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3745:	90                   	nop
    3746:	9b                   	fwait
    3747:	9a a6 2f d7 38       	call   0x38d7:0x2fa6
    374c:	83 ec 08             	sub    sp,0x8
    374f:	89 e3                	mov    bx,sp
    3751:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3755:	90                   	nop
    3756:	9b                   	fwait
    3757:	bf 76 30             	mov    di,0x3076
    375a:	0e                   	push   cs
    375b:	57                   	push   di
    375c:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    375f:	06                   	push   es
    3760:	57                   	push   di
    3761:	9a 9b 3b 80 37       	call   0x3780:0x3b9b
    3766:	89 c7                	mov    di,ax
    3768:	8e c2                	mov    es,dx
    376a:	06                   	push   es
    376b:	57                   	push   di
    376c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    376f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3773:	bf 69 30             	mov    di,0x3069
    3776:	0e                   	push   cs
    3777:	57                   	push   di
    3778:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    377b:	06                   	push   es
    377c:	57                   	push   di
    377d:	9a 9b 3b a0 37       	call   0x37a0:0x3b9b
    3782:	89 c7                	mov    di,ax
    3784:	8e c2                	mov    es,dx
    3786:	06                   	push   es
    3787:	57                   	push   di
    3788:	26 c4 3d             	les    di,DWORD PTR es:[di]
    378b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    378f:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3793:	bf 76 30             	mov    di,0x3076
    3796:	0e                   	push   cs
    3797:	57                   	push   di
    3798:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    379b:	06                   	push   es
    379c:	57                   	push   di
    379d:	9a 9b 3b f5 37       	call   0x37f5:0x3b9b
    37a2:	89 c7                	mov    di,ax
    37a4:	8e c2                	mov    es,dx
    37a6:	06                   	push   es
    37a7:	57                   	push   di
    37a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37ab:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    37af:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    37b3:	9b de e1             	fsubrp st(1),st
    37b6:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    37ba:	90                   	nop
    37bb:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    37c0:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    37c4:	90                   	nop
    37c5:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    37ca:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    37d0:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    37d4:	90                   	nop
    37d5:	9b                   	fwait
    37d6:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    37d9:	9e                   	sahf
    37da:	72 4e                	jb     0x382a
    37dc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    37df:	ff 76 fc             	push   WORD PTR [bp-0x4]
    37e2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    37e5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    37e8:	bf 86 30             	mov    di,0x3086
    37eb:	0e                   	push   cs
    37ec:	57                   	push   di
    37ed:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    37f0:	06                   	push   es
    37f1:	57                   	push   di
    37f2:	9a 9b 3b 19 38       	call   0x3819:0x3b9b
    37f7:	89 c7                	mov    di,ax
    37f9:	8e c2                	mov    es,dx
    37fb:	06                   	push   es
    37fc:	57                   	push   di
    37fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3800:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3804:	6a 00                	push   0x0
    3806:	6a 00                	push   0x0
    3808:	6a 00                	push   0x0
    380a:	6a 00                	push   0x0
    380c:	bf 93 30             	mov    di,0x3093
    380f:	0e                   	push   cs
    3810:	57                   	push   di
    3811:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3814:	06                   	push   es
    3815:	57                   	push   di
    3816:	9a 9b 3b 3f 38       	call   0x383f:0x3b9b
    381b:	89 c7                	mov    di,ax
    381d:	8e c2                	mov    es,dx
    381f:	06                   	push   es
    3820:	57                   	push   di
    3821:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3824:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3828:	eb 52                	jmp    0x387c
    382a:	6a 00                	push   0x0
    382c:	6a 00                	push   0x0
    382e:	6a 00                	push   0x0
    3830:	6a 00                	push   0x0
    3832:	bf 86 30             	mov    di,0x3086
    3835:	0e                   	push   cs
    3836:	57                   	push   di
    3837:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    383a:	06                   	push   es
    383b:	57                   	push   di
    383c:	9a 9b 3b 6d 38       	call   0x386d:0x3b9b
    3841:	89 c7                	mov    di,ax
    3843:	8e c2                	mov    es,dx
    3845:	06                   	push   es
    3846:	57                   	push   di
    3847:	26 c4 3d             	les    di,DWORD PTR es:[di]
    384a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    384e:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    3852:	9b d9 e0             	fchs
    3855:	83 ec 08             	sub    sp,0x8
    3858:	89 e3                	mov    bx,sp
    385a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    385e:	90                   	nop
    385f:	9b                   	fwait
    3860:	bf 93 30             	mov    di,0x3093
    3863:	0e                   	push   cs
    3864:	57                   	push   di
    3865:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3868:	06                   	push   es
    3869:	57                   	push   di
    386a:	9a 9b 3b 8e 38       	call   0x388e:0x3b9b
    386f:	89 c7                	mov    di,ax
    3871:	8e c2                	mov    es,dx
    3873:	06                   	push   es
    3874:	57                   	push   di
    3875:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3878:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    387c:	bf a0 30             	mov    di,0x30a0
    387f:	0e                   	push   cs
    3880:	57                   	push   di
    3881:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3884:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3889:	06                   	push   es
    388a:	57                   	push   di
    388b:	9a 9b 3b b3 38       	call   0x38b3:0x3b9b
    3890:	89 c7                	mov    di,ax
    3892:	8e c2                	mov    es,dx
    3894:	06                   	push   es
    3895:	57                   	push   di
    3896:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3899:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    389d:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    38a1:	bf a0 30             	mov    di,0x30a0
    38a4:	0e                   	push   cs
    38a5:	57                   	push   di
    38a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a9:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    38ae:	06                   	push   es
    38af:	57                   	push   di
    38b0:	9a 9b 3b 0e 39       	call   0x390e:0x3b9b
    38b5:	89 c7                	mov    di,ax
    38b7:	8e c2                	mov    es,dx
    38b9:	06                   	push   es
    38ba:	57                   	push   di
    38bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38be:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    38c2:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    38c6:	9b de e1             	fsubrp st(1),st
    38c9:	83 ec 08             	sub    sp,0x8
    38cc:	89 e3                	mov    bx,sp
    38ce:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    38d2:	90                   	nop
    38d3:	9b                   	fwait
    38d4:	9a a6 2f f0 39       	call   0x39f0:0x2fa6
    38d9:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    38dd:	90                   	nop
    38de:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    38e3:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    38e9:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    38ed:	90                   	nop
    38ee:	9b                   	fwait
    38ef:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    38f2:	9e                   	sahf
    38f3:	76 4e                	jbe    0x3943
    38f5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    38f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    38fb:	ff 76 fa             	push   WORD PTR [bp-0x6]
    38fe:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3901:	bf ac 30             	mov    di,0x30ac
    3904:	0e                   	push   cs
    3905:	57                   	push   di
    3906:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3909:	06                   	push   es
    390a:	57                   	push   di
    390b:	9a 9b 3b 32 39       	call   0x3932:0x3b9b
    3910:	89 c7                	mov    di,ax
    3912:	8e c2                	mov    es,dx
    3914:	06                   	push   es
    3915:	57                   	push   di
    3916:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3919:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    391d:	6a 00                	push   0x0
    391f:	6a 00                	push   0x0
    3921:	6a 00                	push   0x0
    3923:	6a 00                	push   0x0
    3925:	bf be 30             	mov    di,0x30be
    3928:	0e                   	push   cs
    3929:	57                   	push   di
    392a:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    392d:	06                   	push   es
    392e:	57                   	push   di
    392f:	9a 9b 3b 58 39       	call   0x3958:0x3b9b
    3934:	89 c7                	mov    di,ax
    3936:	8e c2                	mov    es,dx
    3938:	06                   	push   es
    3939:	57                   	push   di
    393a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    393d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3941:	eb 52                	jmp    0x3995
    3943:	6a 00                	push   0x0
    3945:	6a 00                	push   0x0
    3947:	6a 00                	push   0x0
    3949:	6a 00                	push   0x0
    394b:	bf ac 30             	mov    di,0x30ac
    394e:	0e                   	push   cs
    394f:	57                   	push   di
    3950:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3953:	06                   	push   es
    3954:	57                   	push   di
    3955:	9a 9b 3b 86 39       	call   0x3986:0x3b9b
    395a:	89 c7                	mov    di,ax
    395c:	8e c2                	mov    es,dx
    395e:	06                   	push   es
    395f:	57                   	push   di
    3960:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3963:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3967:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    396b:	9b d9 e0             	fchs
    396e:	83 ec 08             	sub    sp,0x8
    3971:	89 e3                	mov    bx,sp
    3973:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3977:	90                   	nop
    3978:	9b                   	fwait
    3979:	bf be 30             	mov    di,0x30be
    397c:	0e                   	push   cs
    397d:	57                   	push   di
    397e:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3981:	06                   	push   es
    3982:	57                   	push   di
    3983:	9a 9b 3b a7 39       	call   0x39a7:0x3b9b
    3988:	89 c7                	mov    di,ax
    398a:	8e c2                	mov    es,dx
    398c:	06                   	push   es
    398d:	57                   	push   di
    398e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3991:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3995:	bf a0 30             	mov    di,0x30a0
    3998:	0e                   	push   cs
    3999:	57                   	push   di
    399a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    399d:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    39a2:	06                   	push   es
    39a3:	57                   	push   di
    39a4:	9a 9b 3b cc 39       	call   0x39cc:0x3b9b
    39a9:	89 c7                	mov    di,ax
    39ab:	8e c2                	mov    es,dx
    39ad:	06                   	push   es
    39ae:	57                   	push   di
    39af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39b2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    39b6:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    39ba:	bf a0 30             	mov    di,0x30a0
    39bd:	0e                   	push   cs
    39be:	57                   	push   di
    39bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c2:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    39c7:	06                   	push   es
    39c8:	57                   	push   di
    39c9:	9a 9b 3b 27 3a       	call   0x3a27:0x3b9b
    39ce:	89 c7                	mov    di,ax
    39d0:	8e c2                	mov    es,dx
    39d2:	06                   	push   es
    39d3:	57                   	push   di
    39d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39d7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    39db:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    39df:	9b de e1             	fsubrp st(1),st
    39e2:	83 ec 08             	sub    sp,0x8
    39e5:	89 e3                	mov    bx,sp
    39e7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    39eb:	90                   	nop
    39ec:	9b                   	fwait
    39ed:	9a a6 2f 04 3b       	call   0x3b04:0x2fa6
    39f2:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    39f6:	90                   	nop
    39f7:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    39fc:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    3a02:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3a06:	90                   	nop
    3a07:	9b                   	fwait
    3a08:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3a0b:	9e                   	sahf
    3a0c:	76 4e                	jbe    0x3a5c
    3a0e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3a11:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a14:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3a17:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3a1a:	bf d3 30             	mov    di,0x30d3
    3a1d:	0e                   	push   cs
    3a1e:	57                   	push   di
    3a1f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3a22:	06                   	push   es
    3a23:	57                   	push   di
    3a24:	9a 9b 3b 4b 3a       	call   0x3a4b:0x3b9b
    3a29:	89 c7                	mov    di,ax
    3a2b:	8e c2                	mov    es,dx
    3a2d:	06                   	push   es
    3a2e:	57                   	push   di
    3a2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a32:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3a36:	6a 00                	push   0x0
    3a38:	6a 00                	push   0x0
    3a3a:	6a 00                	push   0x0
    3a3c:	6a 00                	push   0x0
    3a3e:	bf e5 30             	mov    di,0x30e5
    3a41:	0e                   	push   cs
    3a42:	57                   	push   di
    3a43:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3a46:	06                   	push   es
    3a47:	57                   	push   di
    3a48:	9a 9b 3b 71 3a       	call   0x3a71:0x3b9b
    3a4d:	89 c7                	mov    di,ax
    3a4f:	8e c2                	mov    es,dx
    3a51:	06                   	push   es
    3a52:	57                   	push   di
    3a53:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a56:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3a5a:	eb 52                	jmp    0x3aae
    3a5c:	6a 00                	push   0x0
    3a5e:	6a 00                	push   0x0
    3a60:	6a 00                	push   0x0
    3a62:	6a 00                	push   0x0
    3a64:	bf d3 30             	mov    di,0x30d3
    3a67:	0e                   	push   cs
    3a68:	57                   	push   di
    3a69:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3a6c:	06                   	push   es
    3a6d:	57                   	push   di
    3a6e:	9a 9b 3b 9f 3a       	call   0x3a9f:0x3b9b
    3a73:	89 c7                	mov    di,ax
    3a75:	8e c2                	mov    es,dx
    3a77:	06                   	push   es
    3a78:	57                   	push   di
    3a79:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a7c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3a80:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    3a84:	9b d9 e0             	fchs
    3a87:	83 ec 08             	sub    sp,0x8
    3a8a:	89 e3                	mov    bx,sp
    3a8c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3a90:	90                   	nop
    3a91:	9b                   	fwait
    3a92:	bf e5 30             	mov    di,0x30e5
    3a95:	0e                   	push   cs
    3a96:	57                   	push   di
    3a97:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3a9a:	06                   	push   es
    3a9b:	57                   	push   di
    3a9c:	9a 9b 3b bb 3a       	call   0x3abb:0x3b9b
    3aa1:	89 c7                	mov    di,ax
    3aa3:	8e c2                	mov    es,dx
    3aa5:	06                   	push   es
    3aa6:	57                   	push   di
    3aa7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3aaa:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3aae:	bf fa 30             	mov    di,0x30fa
    3ab1:	0e                   	push   cs
    3ab2:	57                   	push   di
    3ab3:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3ab6:	06                   	push   es
    3ab7:	57                   	push   di
    3ab8:	9a 9b 3b e0 3a       	call   0x3ae0:0x3b9b
    3abd:	89 c7                	mov    di,ax
    3abf:	8e c2                	mov    es,dx
    3ac1:	06                   	push   es
    3ac2:	57                   	push   di
    3ac3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ac6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3aca:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3ace:	bf fa 30             	mov    di,0x30fa
    3ad1:	0e                   	push   cs
    3ad2:	57                   	push   di
    3ad3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad6:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3adb:	06                   	push   es
    3adc:	57                   	push   di
    3add:	9a 9b 3b 37 3b       	call   0x3b37:0x3b9b
    3ae2:	89 c7                	mov    di,ax
    3ae4:	8e c2                	mov    es,dx
    3ae6:	06                   	push   es
    3ae7:	57                   	push   di
    3ae8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3aeb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3aef:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3af3:	9b de e1             	fsubrp st(1),st
    3af6:	83 ec 08             	sub    sp,0x8
    3af9:	89 e3                	mov    bx,sp
    3afb:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3aff:	90                   	nop
    3b00:	9b                   	fwait
    3b01:	9a a6 2f 18 3c       	call   0x3c18:0x2fa6
    3b06:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3b0a:	90                   	nop
    3b0b:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    3b10:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    3b16:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3b1a:	90                   	nop
    3b1b:	9b                   	fwait
    3b1c:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3b1f:	9e                   	sahf
    3b20:	76 4e                	jbe    0x3b70
    3b22:	6a 00                	push   0x0
    3b24:	6a 00                	push   0x0
    3b26:	6a 00                	push   0x0
    3b28:	6a 00                	push   0x0
    3b2a:	bf 07 31             	mov    di,0x3107
    3b2d:	0e                   	push   cs
    3b2e:	57                   	push   di
    3b2f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3b32:	06                   	push   es
    3b33:	57                   	push   di
    3b34:	9a 9b 3b 5f 3b       	call   0x3b5f:0x3b9b
    3b39:	89 c7                	mov    di,ax
    3b3b:	8e c2                	mov    es,dx
    3b3d:	06                   	push   es
    3b3e:	57                   	push   di
    3b3f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b42:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3b46:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3b49:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3b4c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3b4f:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3b52:	bf 19 31             	mov    di,0x3119
    3b55:	0e                   	push   cs
    3b56:	57                   	push   di
    3b57:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3b5a:	06                   	push   es
    3b5b:	57                   	push   di
    3b5c:	9a 9b 3b 8f 3b       	call   0x3b8f:0x3b9b
    3b61:	89 c7                	mov    di,ax
    3b63:	8e c2                	mov    es,dx
    3b65:	06                   	push   es
    3b66:	57                   	push   di
    3b67:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b6a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3b6e:	eb 52                	jmp    0x3bc2
    3b70:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    3b74:	9b d9 e0             	fchs
    3b77:	83 ec 08             	sub    sp,0x8
    3b7a:	89 e3                	mov    bx,sp
    3b7c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3b80:	90                   	nop
    3b81:	9b                   	fwait
    3b82:	bf 07 31             	mov    di,0x3107
    3b85:	0e                   	push   cs
    3b86:	57                   	push   di
    3b87:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3b8a:	06                   	push   es
    3b8b:	57                   	push   di
    3b8c:	9a 9b 3b b3 3b       	call   0x3bb3:0x3b9b
    3b91:	89 c7                	mov    di,ax
    3b93:	8e c2                	mov    es,dx
    3b95:	06                   	push   es
    3b96:	57                   	push   di
    3b97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b9a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3b9e:	6a 00                	push   0x0
    3ba0:	6a 00                	push   0x0
    3ba2:	6a 00                	push   0x0
    3ba4:	6a 00                	push   0x0
    3ba6:	bf 19 31             	mov    di,0x3119
    3ba9:	0e                   	push   cs
    3baa:	57                   	push   di
    3bab:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3bae:	06                   	push   es
    3baf:	57                   	push   di
    3bb0:	9a 9b 3b cf 3b       	call   0x3bcf:0x3b9b
    3bb5:	89 c7                	mov    di,ax
    3bb7:	8e c2                	mov    es,dx
    3bb9:	06                   	push   es
    3bba:	57                   	push   di
    3bbb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bbe:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3bc2:	bf 2b 31             	mov    di,0x312b
    3bc5:	0e                   	push   cs
    3bc6:	57                   	push   di
    3bc7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3bca:	06                   	push   es
    3bcb:	57                   	push   di
    3bcc:	9a 9b 3b f4 3b       	call   0x3bf4:0x3b9b
    3bd1:	89 c7                	mov    di,ax
    3bd3:	8e c2                	mov    es,dx
    3bd5:	06                   	push   es
    3bd6:	57                   	push   di
    3bd7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bda:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3bde:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3be2:	bf 2b 31             	mov    di,0x312b
    3be5:	0e                   	push   cs
    3be6:	57                   	push   di
    3be7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bea:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3bef:	06                   	push   es
    3bf0:	57                   	push   di
    3bf1:	9a 9b 3b 4f 3c       	call   0x3c4f:0x3b9b
    3bf6:	89 c7                	mov    di,ax
    3bf8:	8e c2                	mov    es,dx
    3bfa:	06                   	push   es
    3bfb:	57                   	push   di
    3bfc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bff:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3c03:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3c07:	9b de e1             	fsubrp st(1),st
    3c0a:	83 ec 08             	sub    sp,0x8
    3c0d:	89 e3                	mov    bx,sp
    3c0f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3c13:	90                   	nop
    3c14:	9b                   	fwait
    3c15:	9a a6 2f 2c 3d       	call   0x3d2c:0x2fa6
    3c1a:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3c1e:	90                   	nop
    3c1f:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    3c24:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    3c2a:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3c2e:	90                   	nop
    3c2f:	9b                   	fwait
    3c30:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3c33:	9e                   	sahf
    3c34:	76 4e                	jbe    0x3c84
    3c36:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3c39:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3c3c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3c3f:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3c42:	bf 33 31             	mov    di,0x3133
    3c45:	0e                   	push   cs
    3c46:	57                   	push   di
    3c47:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3c4a:	06                   	push   es
    3c4b:	57                   	push   di
    3c4c:	9a 9b 3b 73 3c       	call   0x3c73:0x3b9b
    3c51:	89 c7                	mov    di,ax
    3c53:	8e c2                	mov    es,dx
    3c55:	06                   	push   es
    3c56:	57                   	push   di
    3c57:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c5a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3c5e:	6a 00                	push   0x0
    3c60:	6a 00                	push   0x0
    3c62:	6a 00                	push   0x0
    3c64:	6a 00                	push   0x0
    3c66:	bf 47 31             	mov    di,0x3147
    3c69:	0e                   	push   cs
    3c6a:	57                   	push   di
    3c6b:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3c6e:	06                   	push   es
    3c6f:	57                   	push   di
    3c70:	9a 9b 3b 99 3c       	call   0x3c99:0x3b9b
    3c75:	89 c7                	mov    di,ax
    3c77:	8e c2                	mov    es,dx
    3c79:	06                   	push   es
    3c7a:	57                   	push   di
    3c7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c7e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3c82:	eb 52                	jmp    0x3cd6
    3c84:	6a 00                	push   0x0
    3c86:	6a 00                	push   0x0
    3c88:	6a 00                	push   0x0
    3c8a:	6a 00                	push   0x0
    3c8c:	bf 33 31             	mov    di,0x3133
    3c8f:	0e                   	push   cs
    3c90:	57                   	push   di
    3c91:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3c94:	06                   	push   es
    3c95:	57                   	push   di
    3c96:	9a 9b 3b c7 3c       	call   0x3cc7:0x3b9b
    3c9b:	89 c7                	mov    di,ax
    3c9d:	8e c2                	mov    es,dx
    3c9f:	06                   	push   es
    3ca0:	57                   	push   di
    3ca1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ca4:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3ca8:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    3cac:	9b d9 e0             	fchs
    3caf:	83 ec 08             	sub    sp,0x8
    3cb2:	89 e3                	mov    bx,sp
    3cb4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3cb8:	90                   	nop
    3cb9:	9b                   	fwait
    3cba:	bf 47 31             	mov    di,0x3147
    3cbd:	0e                   	push   cs
    3cbe:	57                   	push   di
    3cbf:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3cc2:	06                   	push   es
    3cc3:	57                   	push   di
    3cc4:	9a 9b 3b e3 3c       	call   0x3ce3:0x3b9b
    3cc9:	89 c7                	mov    di,ax
    3ccb:	8e c2                	mov    es,dx
    3ccd:	06                   	push   es
    3cce:	57                   	push   di
    3ccf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cd2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3cd6:	bf 5b 31             	mov    di,0x315b
    3cd9:	0e                   	push   cs
    3cda:	57                   	push   di
    3cdb:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3cde:	06                   	push   es
    3cdf:	57                   	push   di
    3ce0:	9a 9b 3b 08 3d       	call   0x3d08:0x3b9b
    3ce5:	89 c7                	mov    di,ax
    3ce7:	8e c2                	mov    es,dx
    3ce9:	06                   	push   es
    3cea:	57                   	push   di
    3ceb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cee:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3cf2:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3cf6:	bf 5b 31             	mov    di,0x315b
    3cf9:	0e                   	push   cs
    3cfa:	57                   	push   di
    3cfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cfe:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3d03:	06                   	push   es
    3d04:	57                   	push   di
    3d05:	9a 9b 3b 5f 3d       	call   0x3d5f:0x3b9b
    3d0a:	89 c7                	mov    di,ax
    3d0c:	8e c2                	mov    es,dx
    3d0e:	06                   	push   es
    3d0f:	57                   	push   di
    3d10:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d13:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3d17:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3d1b:	9b de e1             	fsubrp st(1),st
    3d1e:	83 ec 08             	sub    sp,0x8
    3d21:	89 e3                	mov    bx,sp
    3d23:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3d27:	90                   	nop
    3d28:	9b                   	fwait
    3d29:	9a a6 2f b0 3e       	call   0x3eb0:0x2fa6
    3d2e:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3d32:	90                   	nop
    3d33:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    3d38:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    3d3e:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3d42:	90                   	nop
    3d43:	9b                   	fwait
    3d44:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3d47:	9e                   	sahf
    3d48:	76 4e                	jbe    0x3d98
    3d4a:	6a 00                	push   0x0
    3d4c:	6a 00                	push   0x0
    3d4e:	6a 00                	push   0x0
    3d50:	6a 00                	push   0x0
    3d52:	bf 61 31             	mov    di,0x3161
    3d55:	0e                   	push   cs
    3d56:	57                   	push   di
    3d57:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3d5a:	06                   	push   es
    3d5b:	57                   	push   di
    3d5c:	9a 9b 3b 87 3d       	call   0x3d87:0x3b9b
    3d61:	89 c7                	mov    di,ax
    3d63:	8e c2                	mov    es,dx
    3d65:	06                   	push   es
    3d66:	57                   	push   di
    3d67:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d6a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d6e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3d71:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3d74:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3d77:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3d7a:	bf 73 31             	mov    di,0x3173
    3d7d:	0e                   	push   cs
    3d7e:	57                   	push   di
    3d7f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3d82:	06                   	push   es
    3d83:	57                   	push   di
    3d84:	9a 9b 3b b7 3d       	call   0x3db7:0x3b9b
    3d89:	89 c7                	mov    di,ax
    3d8b:	8e c2                	mov    es,dx
    3d8d:	06                   	push   es
    3d8e:	57                   	push   di
    3d8f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d92:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d96:	eb 52                	jmp    0x3dea
    3d98:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    3d9c:	9b d9 e0             	fchs
    3d9f:	83 ec 08             	sub    sp,0x8
    3da2:	89 e3                	mov    bx,sp
    3da4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3da8:	90                   	nop
    3da9:	9b                   	fwait
    3daa:	bf 61 31             	mov    di,0x3161
    3dad:	0e                   	push   cs
    3dae:	57                   	push   di
    3daf:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3db2:	06                   	push   es
    3db3:	57                   	push   di
    3db4:	9a 9b 3b db 3d       	call   0x3ddb:0x3b9b
    3db9:	89 c7                	mov    di,ax
    3dbb:	8e c2                	mov    es,dx
    3dbd:	06                   	push   es
    3dbe:	57                   	push   di
    3dbf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3dc2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3dc6:	6a 00                	push   0x0
    3dc8:	6a 00                	push   0x0
    3dca:	6a 00                	push   0x0
    3dcc:	6a 00                	push   0x0
    3dce:	bf 73 31             	mov    di,0x3173
    3dd1:	0e                   	push   cs
    3dd2:	57                   	push   di
    3dd3:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3dd6:	06                   	push   es
    3dd7:	57                   	push   di
    3dd8:	9a 9b 3b f7 3d       	call   0x3df7:0x3b9b
    3ddd:	89 c7                	mov    di,ax
    3ddf:	8e c2                	mov    es,dx
    3de1:	06                   	push   es
    3de2:	57                   	push   di
    3de3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3de6:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3dea:	bf ac 30             	mov    di,0x30ac
    3ded:	0e                   	push   cs
    3dee:	57                   	push   di
    3def:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3df2:	06                   	push   es
    3df3:	57                   	push   di
    3df4:	9a 9b 3b 17 3e       	call   0x3e17:0x3b9b
    3df9:	89 c7                	mov    di,ax
    3dfb:	8e c2                	mov    es,dx
    3dfd:	06                   	push   es
    3dfe:	57                   	push   di
    3dff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e02:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e06:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3e0a:	bf d3 30             	mov    di,0x30d3
    3e0d:	0e                   	push   cs
    3e0e:	57                   	push   di
    3e0f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3e12:	06                   	push   es
    3e13:	57                   	push   di
    3e14:	9a 9b 3b 3e 3e       	call   0x3e3e:0x3b9b
    3e19:	89 c7                	mov    di,ax
    3e1b:	8e c2                	mov    es,dx
    3e1d:	06                   	push   es
    3e1e:	57                   	push   di
    3e1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e22:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e26:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3e2a:	9b de c1             	faddp  st(1),st
    3e2d:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    3e31:	bf 07 31             	mov    di,0x3107
    3e34:	0e                   	push   cs
    3e35:	57                   	push   di
    3e36:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3e39:	06                   	push   es
    3e3a:	57                   	push   di
    3e3b:	9a 9b 3b 65 3e       	call   0x3e65:0x3b9b
    3e40:	89 c7                	mov    di,ax
    3e42:	8e c2                	mov    es,dx
    3e44:	06                   	push   es
    3e45:	57                   	push   di
    3e46:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e49:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e4d:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    3e51:	9b de c1             	faddp  st(1),st
    3e54:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    3e58:	bf 33 31             	mov    di,0x3133
    3e5b:	0e                   	push   cs
    3e5c:	57                   	push   di
    3e5d:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3e60:	06                   	push   es
    3e61:	57                   	push   di
    3e62:	9a 9b 3b 8c 3e       	call   0x3e8c:0x3b9b
    3e67:	89 c7                	mov    di,ax
    3e69:	8e c2                	mov    es,dx
    3e6b:	06                   	push   es
    3e6c:	57                   	push   di
    3e6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e70:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e74:	9b db 6e b6          	fld    TBYTE PTR [bp-0x4a]
    3e78:	9b de c1             	faddp  st(1),st
    3e7b:	9b db 7e ac          	fstp   TBYTE PTR [bp-0x54]
    3e7f:	bf 61 31             	mov    di,0x3161
    3e82:	0e                   	push   cs
    3e83:	57                   	push   di
    3e84:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3e87:	06                   	push   es
    3e88:	57                   	push   di
    3e89:	9a 9b 3b c5 3e       	call   0x3ec5:0x3b9b
    3e8e:	89 c7                	mov    di,ax
    3e90:	8e c2                	mov    es,dx
    3e92:	06                   	push   es
    3e93:	57                   	push   di
    3e94:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e97:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e9b:	9b db 6e ac          	fld    TBYTE PTR [bp-0x54]
    3e9f:	9b de c1             	faddp  st(1),st
    3ea2:	83 ec 08             	sub    sp,0x8
    3ea5:	89 e3                	mov    bx,sp
    3ea7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3eab:	90                   	nop
    3eac:	9b                   	fwait
    3ead:	9a a6 2f 7e 3f       	call   0x3f7e:0x2fa6
    3eb2:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    3eb6:	90                   	nop
    3eb7:	9b                   	fwait
    3eb8:	bf be 30             	mov    di,0x30be
    3ebb:	0e                   	push   cs
    3ebc:	57                   	push   di
    3ebd:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3ec0:	06                   	push   es
    3ec1:	57                   	push   di
    3ec2:	9a 9b 3b e5 3e       	call   0x3ee5:0x3b9b
    3ec7:	89 c7                	mov    di,ax
    3ec9:	8e c2                	mov    es,dx
    3ecb:	06                   	push   es
    3ecc:	57                   	push   di
    3ecd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ed0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ed4:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    3ed8:	bf e5 30             	mov    di,0x30e5
    3edb:	0e                   	push   cs
    3edc:	57                   	push   di
    3edd:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3ee0:	06                   	push   es
    3ee1:	57                   	push   di
    3ee2:	9a 9b 3b 0c 3f       	call   0x3f0c:0x3b9b
    3ee7:	89 c7                	mov    di,ax
    3ee9:	8e c2                	mov    es,dx
    3eeb:	06                   	push   es
    3eec:	57                   	push   di
    3eed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ef0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ef4:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    3ef8:	9b de c1             	faddp  st(1),st
    3efb:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    3eff:	bf 19 31             	mov    di,0x3119
    3f02:	0e                   	push   cs
    3f03:	57                   	push   di
    3f04:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3f07:	06                   	push   es
    3f08:	57                   	push   di
    3f09:	9a 9b 3b 33 3f       	call   0x3f33:0x3b9b
    3f0e:	89 c7                	mov    di,ax
    3f10:	8e c2                	mov    es,dx
    3f12:	06                   	push   es
    3f13:	57                   	push   di
    3f14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f17:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f1b:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    3f1f:	9b de c1             	faddp  st(1),st
    3f22:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    3f26:	bf 47 31             	mov    di,0x3147
    3f29:	0e                   	push   cs
    3f2a:	57                   	push   di
    3f2b:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3f2e:	06                   	push   es
    3f2f:	57                   	push   di
    3f30:	9a 9b 3b 5a 3f       	call   0x3f5a:0x3b9b
    3f35:	89 c7                	mov    di,ax
    3f37:	8e c2                	mov    es,dx
    3f39:	06                   	push   es
    3f3a:	57                   	push   di
    3f3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f3e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f42:	9b db 6e b6          	fld    TBYTE PTR [bp-0x4a]
    3f46:	9b de c1             	faddp  st(1),st
    3f49:	9b db 7e ac          	fstp   TBYTE PTR [bp-0x54]
    3f4d:	bf 73 31             	mov    di,0x3173
    3f50:	0e                   	push   cs
    3f51:	57                   	push   di
    3f52:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3f55:	06                   	push   es
    3f56:	57                   	push   di
    3f57:	9a 9b 3b c7 3f       	call   0x3fc7:0x3b9b
    3f5c:	89 c7                	mov    di,ax
    3f5e:	8e c2                	mov    es,dx
    3f60:	06                   	push   es
    3f61:	57                   	push   di
    3f62:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f65:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f69:	9b db 6e ac          	fld    TBYTE PTR [bp-0x54]
    3f6d:	9b de c1             	faddp  st(1),st
    3f70:	83 ec 08             	sub    sp,0x8
    3f73:	89 e3                	mov    bx,sp
    3f75:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f79:	90                   	nop
    3f7a:	9b                   	fwait
    3f7b:	9a a6 2f 3b 41       	call   0x413b:0x2fa6
    3f80:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    3f84:	90                   	nop
    3f85:	9b 9b dd 46 e8       	fld    QWORD PTR [bp-0x18]
    3f8a:	9b dc 66 e0          	fsub   QWORD PTR [bp-0x20]
    3f8e:	9b dc 66 f0          	fsub   QWORD PTR [bp-0x10]
    3f92:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    3f96:	90                   	nop
    3f97:	9b 9b dd 46 d8       	fld    QWORD PTR [bp-0x28]
    3f9c:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    3fa2:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    3fa6:	90                   	nop
    3fa7:	9b                   	fwait
    3fa8:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    3fab:	9e                   	sahf
    3fac:	76 4e                	jbe    0x3ffc
    3fae:	ff 76 de             	push   WORD PTR [bp-0x22]
    3fb1:	ff 76 dc             	push   WORD PTR [bp-0x24]
    3fb4:	ff 76 da             	push   WORD PTR [bp-0x26]
    3fb7:	ff 76 d8             	push   WORD PTR [bp-0x28]
    3fba:	bf 85 31             	mov    di,0x3185
    3fbd:	0e                   	push   cs
    3fbe:	57                   	push   di
    3fbf:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3fc2:	06                   	push   es
    3fc3:	57                   	push   di
    3fc4:	9a 9b 3b eb 3f       	call   0x3feb:0x3b9b
    3fc9:	89 c7                	mov    di,ax
    3fcb:	8e c2                	mov    es,dx
    3fcd:	06                   	push   es
    3fce:	57                   	push   di
    3fcf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fd2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3fd6:	6a 00                	push   0x0
    3fd8:	6a 00                	push   0x0
    3fda:	6a 00                	push   0x0
    3fdc:	6a 00                	push   0x0
    3fde:	bf 97 31             	mov    di,0x3197
    3fe1:	0e                   	push   cs
    3fe2:	57                   	push   di
    3fe3:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3fe6:	06                   	push   es
    3fe7:	57                   	push   di
    3fe8:	9a 9b 3b 11 40       	call   0x4011:0x3b9b
    3fed:	89 c7                	mov    di,ax
    3fef:	8e c2                	mov    es,dx
    3ff1:	06                   	push   es
    3ff2:	57                   	push   di
    3ff3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ff6:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3ffa:	eb 52                	jmp    0x404e
    3ffc:	6a 00                	push   0x0
    3ffe:	6a 00                	push   0x0
    4000:	6a 00                	push   0x0
    4002:	6a 00                	push   0x0
    4004:	bf 85 31             	mov    di,0x3185
    4007:	0e                   	push   cs
    4008:	57                   	push   di
    4009:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    400c:	06                   	push   es
    400d:	57                   	push   di
    400e:	9a 9b 3b 3f 40       	call   0x403f:0x3b9b
    4013:	89 c7                	mov    di,ax
    4015:	8e c2                	mov    es,dx
    4017:	06                   	push   es
    4018:	57                   	push   di
    4019:	26 c4 3d             	les    di,DWORD PTR es:[di]
    401c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4020:	9b dd 46 d8          	fld    QWORD PTR [bp-0x28]
    4024:	9b d9 e0             	fchs
    4027:	83 ec 08             	sub    sp,0x8
    402a:	89 e3                	mov    bx,sp
    402c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4030:	90                   	nop
    4031:	9b                   	fwait
    4032:	bf 97 31             	mov    di,0x3197
    4035:	0e                   	push   cs
    4036:	57                   	push   di
    4037:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    403a:	06                   	push   es
    403b:	57                   	push   di
    403c:	9a 9b 3b 5b 40       	call   0x405b:0x3b9b
    4041:	89 c7                	mov    di,ax
    4043:	8e c2                	mov    es,dx
    4045:	06                   	push   es
    4046:	57                   	push   di
    4047:	26 c4 3d             	les    di,DWORD PTR es:[di]
    404a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    404e:	bf ac 30             	mov    di,0x30ac
    4051:	0e                   	push   cs
    4052:	57                   	push   di
    4053:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4056:	06                   	push   es
    4057:	57                   	push   di
    4058:	9a 9b 3b 7b 40       	call   0x407b:0x3b9b
    405d:	89 c7                	mov    di,ax
    405f:	8e c2                	mov    es,dx
    4061:	06                   	push   es
    4062:	57                   	push   di
    4063:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4066:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    406a:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    406e:	bf d3 30             	mov    di,0x30d3
    4071:	0e                   	push   cs
    4072:	57                   	push   di
    4073:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4076:	06                   	push   es
    4077:	57                   	push   di
    4078:	9a 9b 3b a2 40       	call   0x40a2:0x3b9b
    407d:	89 c7                	mov    di,ax
    407f:	8e c2                	mov    es,dx
    4081:	06                   	push   es
    4082:	57                   	push   di
    4083:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4086:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    408a:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    408e:	9b de c1             	faddp  st(1),st
    4091:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    4095:	bf 07 31             	mov    di,0x3107
    4098:	0e                   	push   cs
    4099:	57                   	push   di
    409a:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    409d:	06                   	push   es
    409e:	57                   	push   di
    409f:	9a 9b 3b c9 40       	call   0x40c9:0x3b9b
    40a4:	89 c7                	mov    di,ax
    40a6:	8e c2                	mov    es,dx
    40a8:	06                   	push   es
    40a9:	57                   	push   di
    40aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40ad:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40b1:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    40b5:	9b de c1             	faddp  st(1),st
    40b8:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    40bc:	bf 33 31             	mov    di,0x3133
    40bf:	0e                   	push   cs
    40c0:	57                   	push   di
    40c1:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    40c4:	06                   	push   es
    40c5:	57                   	push   di
    40c6:	9a 9b 3b f0 40       	call   0x40f0:0x3b9b
    40cb:	89 c7                	mov    di,ax
    40cd:	8e c2                	mov    es,dx
    40cf:	06                   	push   es
    40d0:	57                   	push   di
    40d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40d4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40d8:	9b db 6e b6          	fld    TBYTE PTR [bp-0x4a]
    40dc:	9b de c1             	faddp  st(1),st
    40df:	9b db 7e ac          	fstp   TBYTE PTR [bp-0x54]
    40e3:	bf 61 31             	mov    di,0x3161
    40e6:	0e                   	push   cs
    40e7:	57                   	push   di
    40e8:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    40eb:	06                   	push   es
    40ec:	57                   	push   di
    40ed:	9a 9b 3b 17 41       	call   0x4117:0x3b9b
    40f2:	89 c7                	mov    di,ax
    40f4:	8e c2                	mov    es,dx
    40f6:	06                   	push   es
    40f7:	57                   	push   di
    40f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40fb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40ff:	9b db 6e ac          	fld    TBYTE PTR [bp-0x54]
    4103:	9b de c1             	faddp  st(1),st
    4106:	9b db 7e a2          	fstp   TBYTE PTR [bp-0x5e]
    410a:	bf 85 31             	mov    di,0x3185
    410d:	0e                   	push   cs
    410e:	57                   	push   di
    410f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4112:	06                   	push   es
    4113:	57                   	push   di
    4114:	9a 9b 3b 55 41       	call   0x4155:0x3b9b
    4119:	89 c7                	mov    di,ax
    411b:	8e c2                	mov    es,dx
    411d:	06                   	push   es
    411e:	57                   	push   di
    411f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4122:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4126:	9b db 6e a2          	fld    TBYTE PTR [bp-0x5e]
    412a:	9b de c1             	faddp  st(1),st
    412d:	83 ec 08             	sub    sp,0x8
    4130:	89 e3                	mov    bx,sp
    4132:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4136:	90                   	nop
    4137:	9b                   	fwait
    4138:	9a a6 2f 51 42       	call   0x4251:0x2fa6
    413d:	83 ec 08             	sub    sp,0x8
    4140:	89 e3                	mov    bx,sp
    4142:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4146:	90                   	nop
    4147:	9b                   	fwait
    4148:	bf a9 31             	mov    di,0x31a9
    414b:	0e                   	push   cs
    414c:	57                   	push   di
    414d:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4150:	06                   	push   es
    4151:	57                   	push   di
    4152:	9a 9b 3b 71 41       	call   0x4171:0x3b9b
    4157:	89 c7                	mov    di,ax
    4159:	8e c2                	mov    es,dx
    415b:	06                   	push   es
    415c:	57                   	push   di
    415d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4160:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4164:	bf be 30             	mov    di,0x30be
    4167:	0e                   	push   cs
    4168:	57                   	push   di
    4169:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    416c:	06                   	push   es
    416d:	57                   	push   di
    416e:	9a 9b 3b 91 41       	call   0x4191:0x3b9b
    4173:	89 c7                	mov    di,ax
    4175:	8e c2                	mov    es,dx
    4177:	06                   	push   es
    4178:	57                   	push   di
    4179:	26 c4 3d             	les    di,DWORD PTR es:[di]
    417c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4180:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    4184:	bf e5 30             	mov    di,0x30e5
    4187:	0e                   	push   cs
    4188:	57                   	push   di
    4189:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    418c:	06                   	push   es
    418d:	57                   	push   di
    418e:	9a 9b 3b b8 41       	call   0x41b8:0x3b9b
    4193:	89 c7                	mov    di,ax
    4195:	8e c2                	mov    es,dx
    4197:	06                   	push   es
    4198:	57                   	push   di
    4199:	26 c4 3d             	les    di,DWORD PTR es:[di]
    419c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41a0:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    41a4:	9b de c1             	faddp  st(1),st
    41a7:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    41ab:	bf 19 31             	mov    di,0x3119
    41ae:	0e                   	push   cs
    41af:	57                   	push   di
    41b0:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    41b3:	06                   	push   es
    41b4:	57                   	push   di
    41b5:	9a 9b 3b df 41       	call   0x41df:0x3b9b
    41ba:	89 c7                	mov    di,ax
    41bc:	8e c2                	mov    es,dx
    41be:	06                   	push   es
    41bf:	57                   	push   di
    41c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41c3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41c7:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    41cb:	9b de c1             	faddp  st(1),st
    41ce:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    41d2:	bf 47 31             	mov    di,0x3147
    41d5:	0e                   	push   cs
    41d6:	57                   	push   di
    41d7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    41da:	06                   	push   es
    41db:	57                   	push   di
    41dc:	9a 9b 3b 06 42       	call   0x4206:0x3b9b
    41e1:	89 c7                	mov    di,ax
    41e3:	8e c2                	mov    es,dx
    41e5:	06                   	push   es
    41e6:	57                   	push   di
    41e7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41ea:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41ee:	9b db 6e b6          	fld    TBYTE PTR [bp-0x4a]
    41f2:	9b de c1             	faddp  st(1),st
    41f5:	9b db 7e ac          	fstp   TBYTE PTR [bp-0x54]
    41f9:	bf 73 31             	mov    di,0x3173
    41fc:	0e                   	push   cs
    41fd:	57                   	push   di
    41fe:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4201:	06                   	push   es
    4202:	57                   	push   di
    4203:	9a 9b 3b 2d 42       	call   0x422d:0x3b9b
    4208:	89 c7                	mov    di,ax
    420a:	8e c2                	mov    es,dx
    420c:	06                   	push   es
    420d:	57                   	push   di
    420e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4211:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4215:	9b db 6e ac          	fld    TBYTE PTR [bp-0x54]
    4219:	9b de c1             	faddp  st(1),st
    421c:	9b db 7e a2          	fstp   TBYTE PTR [bp-0x5e]
    4220:	bf 97 31             	mov    di,0x3197
    4223:	0e                   	push   cs
    4224:	57                   	push   di
    4225:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4228:	06                   	push   es
    4229:	57                   	push   di
    422a:	9a 9b 3b 6b 42       	call   0x426b:0x3b9b
    422f:	89 c7                	mov    di,ax
    4231:	8e c2                	mov    es,dx
    4233:	06                   	push   es
    4234:	57                   	push   di
    4235:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4238:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    423c:	9b db 6e a2          	fld    TBYTE PTR [bp-0x5e]
    4240:	9b de c1             	faddp  st(1),st
    4243:	83 ec 08             	sub    sp,0x8
    4246:	89 e3                	mov    bx,sp
    4248:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    424c:	90                   	nop
    424d:	9b                   	fwait
    424e:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    4253:	83 ec 08             	sub    sp,0x8
    4256:	89 e3                	mov    bx,sp
    4258:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    425c:	90                   	nop
    425d:	9b                   	fwait
    425e:	bf b6 31             	mov    di,0x31b6
    4261:	0e                   	push   cs
    4262:	57                   	push   di
    4263:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4266:	06                   	push   es
    4267:	57                   	push   di
    4268:	9a 9b 3b 87 42       	call   0x4287:0x3b9b
    426d:	89 c7                	mov    di,ax
    426f:	8e c2                	mov    es,dx
    4271:	06                   	push   es
    4272:	57                   	push   di
    4273:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4276:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    427a:	bf a9 31             	mov    di,0x31a9
    427d:	0e                   	push   cs
    427e:	57                   	push   di
    427f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4282:	06                   	push   es
    4283:	57                   	push   di
    4284:	9a 9b 3b a7 42       	call   0x42a7:0x3b9b
    4289:	89 c7                	mov    di,ax
    428b:	8e c2                	mov    es,dx
    428d:	06                   	push   es
    428e:	57                   	push   di
    428f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4292:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4296:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    429a:	bf b6 31             	mov    di,0x31b6
    429d:	0e                   	push   cs
    429e:	57                   	push   di
    429f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    42a2:	06                   	push   es
    42a3:	57                   	push   di
    42a4:	9a 9b 3b f2 42       	call   0x42f2:0x3b9b
    42a9:	89 c7                	mov    di,ax
    42ab:	8e c2                	mov    es,dx
    42ad:	06                   	push   es
    42ae:	57                   	push   di
    42af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42b2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42b6:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    42ba:	9b de e1             	fsubrp st(1),st
    42bd:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    42c1:	90                   	nop
    42c2:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    42c7:	9b 2e d8 1e b8 2f    	fcomp  DWORD PTR cs:0x2fb8
    42cd:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    42d1:	90                   	nop
    42d2:	9b                   	fwait
    42d3:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    42d6:	9e                   	sahf
    42d7:	72 4e                	jb     0x4327
    42d9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    42dc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    42df:	ff 76 fa             	push   WORD PTR [bp-0x6]
    42e2:	ff 76 f8             	push   WORD PTR [bp-0x8]
    42e5:	bf c6 31             	mov    di,0x31c6
    42e8:	0e                   	push   cs
    42e9:	57                   	push   di
    42ea:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    42ed:	06                   	push   es
    42ee:	57                   	push   di
    42ef:	9a 9b 3b 16 43       	call   0x4316:0x3b9b
    42f4:	89 c7                	mov    di,ax
    42f6:	8e c2                	mov    es,dx
    42f8:	06                   	push   es
    42f9:	57                   	push   di
    42fa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42fd:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4301:	6a 00                	push   0x0
    4303:	6a 00                	push   0x0
    4305:	6a 00                	push   0x0
    4307:	6a 00                	push   0x0
    4309:	bf d3 31             	mov    di,0x31d3
    430c:	0e                   	push   cs
    430d:	57                   	push   di
    430e:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4311:	06                   	push   es
    4312:	57                   	push   di
    4313:	9a 9b 3b 3c 43       	call   0x433c:0x3b9b
    4318:	89 c7                	mov    di,ax
    431a:	8e c2                	mov    es,dx
    431c:	06                   	push   es
    431d:	57                   	push   di
    431e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4321:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4325:	eb 52                	jmp    0x4379
    4327:	6a 00                	push   0x0
    4329:	6a 00                	push   0x0
    432b:	6a 00                	push   0x0
    432d:	6a 00                	push   0x0
    432f:	bf c6 31             	mov    di,0x31c6
    4332:	0e                   	push   cs
    4333:	57                   	push   di
    4334:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4337:	06                   	push   es
    4338:	57                   	push   di
    4339:	9a 9b 3b 6a 43       	call   0x436a:0x3b9b
    433e:	89 c7                	mov    di,ax
    4340:	8e c2                	mov    es,dx
    4342:	06                   	push   es
    4343:	57                   	push   di
    4344:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4347:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    434b:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    434f:	9b d9 e0             	fchs
    4352:	83 ec 08             	sub    sp,0x8
    4355:	89 e3                	mov    bx,sp
    4357:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    435b:	90                   	nop
    435c:	9b                   	fwait
    435d:	bf d3 31             	mov    di,0x31d3
    4360:	0e                   	push   cs
    4361:	57                   	push   di
    4362:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4365:	06                   	push   es
    4366:	57                   	push   di
    4367:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    436c:	89 c7                	mov    di,ax
    436e:	8e c2                	mov    es,dx
    4370:	06                   	push   es
    4371:	57                   	push   di
    4372:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4375:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4379:	c9                   	leave
    437a:	ca 08 00             	retf   0x8
    437d:	62 44 3d             	bound  ax,DWORD PTR [si+0x3d]
    4380:	44                   	inc    sp
    4381:	ee                   	out    dx,al
    4382:	43                   	inc    bx
    4383:	df 43 8b             	fild   WORD PTR [bp+di-0x75]
    4386:	44                   	inc    sp
    4387:	1e                   	push   ds
    4388:	44                   	inc    sp
    4389:	8b 44 ff             	mov    ax,WORD PTR [si-0x1]
    438c:	43                   	inc    bx
    438d:	00 00                	add    BYTE PTR [bx+si],al
    438f:	00 00                	add    BYTE PTR [bx+si],al
    4391:	ff 00                	inc    WORD PTR [bx+si]
    4393:	00 00                	add    BYTE PTR [bx+si],al
    4395:	55                   	push   bp
    4396:	89 e5                	mov    bp,sp
    4398:	b8 04 00             	mov    ax,0x4
    439b:	9a 44 04 0f 44       	call   0x440f:0x444
    43a0:	83 ec 04             	sub    sp,0x4
    43a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43a6:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    43ab:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    43ae:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    43b1:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    43b5:	b0 00                	mov    al,0x0
    43b7:	74 01                	je     0x43ba
    43b9:	40                   	inc    ax
    43ba:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    43be:	08 c0                	or     al,al
    43c0:	75 03                	jne    0x43c5
    43c2:	e9 ee 00             	jmp    0x44b3
    43c5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    43c8:	26 8b 05             	mov    ax,WORD PTR es:[di]
    43cb:	2d 21 00             	sub    ax,0x21
    43ce:	3d 07 00             	cmp    ax,0x7
    43d1:	76 03                	jbe    0x43d6
    43d3:	e9 b5 00             	jmp    0x448b
    43d6:	89 c3                	mov    bx,ax
    43d8:	d1 e3                	shl    bx,1
    43da:	2e ff a7 7d 43       	jmp    WORD PTR cs:[bx+0x437d]
    43df:	6a 00                	push   0x0
    43e1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    43e4:	06                   	push   es
    43e5:	57                   	push   di
    43e6:	9a d0 1c fa 43       	call   0x43fa:0x1cd0
    43eb:	e9 9d 00             	jmp    0x448b
    43ee:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    43f1:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    43f5:	06                   	push   es
    43f6:	57                   	push   di
    43f7:	9a d0 1c 1a 44       	call   0x441a:0x1cd0
    43fc:	e9 8c 00             	jmp    0x448b
    43ff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4402:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4406:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    440a:	71 05                	jno    0x4411
    440c:	9a 3e 04 2e 44       	call   0x442e:0x43e
    4411:	50                   	push   ax
    4412:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4415:	06                   	push   es
    4416:	57                   	push   di
    4417:	9a d0 1c 39 44       	call   0x4439:0x1cd0
    441c:	eb 6d                	jmp    0x448b
    441e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4421:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4425:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    4429:	71 05                	jno    0x4430
    442b:	9a 3e 04 53 44       	call   0x4453:0x43e
    4430:	50                   	push   ax
    4431:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4434:	06                   	push   es
    4435:	57                   	push   di
    4436:	9a d0 1c 5e 44       	call   0x445e:0x1cd0
    443b:	eb 4e                	jmp    0x448b
    443d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4440:	06                   	push   es
    4441:	57                   	push   di
    4442:	9a f4 18 6a 44       	call   0x446a:0x18f4
    4447:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    444a:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    444e:	71 05                	jno    0x4455
    4450:	9a 3e 04 7c 44       	call   0x447c:0x43e
    4455:	50                   	push   ax
    4456:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4459:	06                   	push   es
    445a:	57                   	push   di
    445b:	9a d0 1c 87 44       	call   0x4487:0x1cd0
    4460:	eb 29                	jmp    0x448b
    4462:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4465:	06                   	push   es
    4466:	57                   	push   di
    4467:	9a f4 18 a4 46       	call   0x46a4:0x18f4
    446c:	8b d0                	mov    dx,ax
    446e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4471:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4475:	2b c2                	sub    ax,dx
    4477:	71 05                	jno    0x447e
    4479:	9a 3e 04 99 44       	call   0x4499:0x43e
    447e:	50                   	push   ax
    447f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4482:	06                   	push   es
    4483:	57                   	push   di
    4484:	9a d0 1c f8 44       	call   0x44f8:0x1cd0
    4489:	eb 00                	jmp    0x448b
    448b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    448e:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4491:	31 d2                	xor    dx,dx
    4493:	bf 8d 43             	mov    di,0x438d
    4496:	9a 16 04 ed 44       	call   0x44ed:0x416
    449b:	3c 21                	cmp    al,0x21
    449d:	72 14                	jb     0x44b3
    449f:	3c 24                	cmp    al,0x24
    44a1:	76 08                	jbe    0x44ab
    44a3:	3c 26                	cmp    al,0x26
    44a5:	74 04                	je     0x44ab
    44a7:	3c 28                	cmp    al,0x28
    44a9:	75 08                	jne    0x44b3
    44ab:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    44ae:	31 c0                	xor    ax,ax
    44b0:	26 89 05             	mov    WORD PTR es:[di],ax
    44b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44b6:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    44bb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    44be:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    44c1:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    44c5:	b0 00                	mov    al,0x0
    44c7:	74 01                	je     0x44ca
    44c9:	40                   	inc    ax
    44ca:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    44ce:	08 c0                	or     al,al
    44d0:	74 6e                	je     0x4540
    44d2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    44d5:	26 8b 05             	mov    ax,WORD PTR es:[di]
    44d8:	3d 27 00             	cmp    ax,0x27
    44db:	75 1f                	jne    0x44fc
    44dd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    44e0:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    44e4:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    44e8:	71 05                	jno    0x44ef
    44ea:	9a 3e 04 11 45       	call   0x4511:0x43e
    44ef:	50                   	push   ax
    44f0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    44f3:	06                   	push   es
    44f4:	57                   	push   di
    44f5:	9a d0 1c 1c 45       	call   0x451c:0x1cd0
    44fa:	eb 24                	jmp    0x4520
    44fc:	3d 25 00             	cmp    ax,0x25
    44ff:	75 1f                	jne    0x4520
    4501:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4504:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4508:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    450c:	71 05                	jno    0x4513
    450e:	9a 3e 04 2e 45       	call   0x452e:0x43e
    4513:	50                   	push   ax
    4514:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4517:	06                   	push   es
    4518:	57                   	push   di
    4519:	9a d0 1c 5b 45       	call   0x455b:0x1cd0
    451e:	eb 00                	jmp    0x4520
    4520:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4523:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4526:	31 d2                	xor    dx,dx
    4528:	bf 8d 43             	mov    di,0x438d
    452b:	9a 16 04 69 45       	call   0x4569:0x416
    4530:	3c 25                	cmp    al,0x25
    4532:	74 04                	je     0x4538
    4534:	3c 27                	cmp    al,0x27
    4536:	75 08                	jne    0x4540
    4538:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    453b:	31 c0                	xor    ax,ax
    453d:	26 89 05             	mov    WORD PTR es:[di],ax
    4540:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4543:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    4547:	74 14                	je     0x455d
    4549:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    454c:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    4551:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    4556:	06                   	push   es
    4557:	57                   	push   di
    4558:	9a 30 22 86 45       	call   0x4586:0x2230
    455d:	c9                   	leave
    455e:	ca 0e 00             	retf   0xe
    4561:	55                   	push   bp
    4562:	89 e5                	mov    bp,sp
    4564:	31 c0                	xor    ax,ax
    4566:	9a 44 04 94 45       	call   0x4594:0x444
    456b:	6a 01                	push   0x1
    456d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4570:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    4575:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    4579:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    457d:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4581:	06                   	push   es
    4582:	57                   	push   di
    4583:	9a b2 77 a5 45       	call   0x45a5:0x77b2
    4588:	c9                   	leave
    4589:	ca 08 00             	retf   0x8
    458c:	55                   	push   bp
    458d:	89 e5                	mov    bp,sp
    458f:	31 c0                	xor    ax,ax
    4591:	9a 44 04 b3 45       	call   0x45b3:0x444
    4596:	6a 03                	push   0x3
    4598:	6a 00                	push   0x0
    459a:	6a 00                	push   0x0
    459c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    45a0:	06                   	push   es
    45a1:	57                   	push   di
    45a2:	9a b2 77 c6 45       	call   0x45c6:0x77b2
    45a7:	c9                   	leave
    45a8:	ca 08 00             	retf   0x8
    45ab:	55                   	push   bp
    45ac:	89 e5                	mov    bp,sp
    45ae:	31 c0                	xor    ax,ax
    45b0:	9a 44 04 d4 45       	call   0x45d4:0x444
    45b5:	68 05 01             	push   0x105
    45b8:	bf fe 01             	mov    di,0x1fe
    45bb:	1e                   	push   ds
    45bc:	57                   	push   di
    45bd:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    45c1:	06                   	push   es
    45c2:	57                   	push   di
    45c3:	9a b2 77 e5 45       	call   0x45e5:0x77b2
    45c8:	c9                   	leave
    45c9:	ca 08 00             	retf   0x8
    45cc:	55                   	push   bp
    45cd:	89 e5                	mov    bp,sp
    45cf:	31 c0                	xor    ax,ax
    45d1:	9a 44 04 f4 45       	call   0x45f4:0x444
    45d6:	6a 04                	push   0x4
    45d8:	6a 00                	push   0x0
    45da:	6a 00                	push   0x0
    45dc:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    45e0:	06                   	push   es
    45e1:	57                   	push   di
    45e2:	9a b2 77 02 46       	call   0x4602:0x77b2
    45e7:	c9                   	leave
    45e8:	ca 08 00             	retf   0x8
    45eb:	55                   	push   bp
    45ec:	89 e5                	mov    bp,sp
    45ee:	b8 04 00             	mov    ax,0x4
    45f1:	9a 44 04 11 46       	call   0x4611:0x444
    45f6:	83 ec 04             	sub    sp,0x4
    45f9:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    45fd:	06                   	push   es
    45fe:	57                   	push   di
    45ff:	9a 45 5d 7d 46       	call   0x467d:0x5d45
    4604:	c9                   	leave
    4605:	ca 08 00             	retf   0x8
    4608:	55                   	push   bp
    4609:	89 e5                	mov    bp,sp
    460b:	b8 04 00             	mov    ax,0x4
    460e:	9a 44 04 8c 46       	call   0x468c:0x444
    4613:	83 ec 04             	sub    sp,0x4
    4616:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4619:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    461e:	b0 00                	mov    al,0x0
    4620:	75 01                	jne    0x4623
    4622:	40                   	inc    ax
    4623:	8a c8                	mov    cl,al
    4625:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    462b:	b0 00                	mov    al,0x0
    462d:	77 01                	ja     0x4630
    462f:	40                   	inc    ax
    4630:	8a d0                	mov    dl,al
    4632:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    4638:	b0 00                	mov    al,0x0
    463a:	76 01                	jbe    0x463d
    463c:	40                   	inc    ax
    463d:	22 c2                	and    al,dl
    463f:	0a c1                	or     al,cl
    4641:	08 c0                	or     al,al
    4643:	74 3a                	je     0x467f
    4645:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4649:	31 c0                	xor    ax,ax
    464b:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    464f:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    4653:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    4657:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    465b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    465e:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    4662:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4665:	06                   	push   es
    4666:	57                   	push   di
    4667:	26 c4 3d             	les    di,DWORD PTR es:[di]
    466a:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    466e:	6a 02                	push   0x2
    4670:	6a 00                	push   0x0
    4672:	6a 00                	push   0x0
    4674:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4678:	06                   	push   es
    4679:	57                   	push   di
    467a:	9a b2 77 0c 47       	call   0x470c:0x77b2
    467f:	c9                   	leave
    4680:	ca 0c 00             	retf   0xc
    4683:	55                   	push   bp
    4684:	89 e5                	mov    bp,sp
    4686:	b8 04 00             	mov    ax,0x4
    4689:	9a 44 04 ab 46       	call   0x46ab:0x444
    468e:	83 ec 04             	sub    sp,0x4
    4691:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    4695:	74 03                	je     0x469a
    4697:	e9 9c 00             	jmp    0x4736
    469a:	ff 76 14             	push   WORD PTR [bp+0x14]
    469d:	ff 76 12             	push   WORD PTR [bp+0x12]
    46a0:	bf c1 05             	mov    di,0x5c1
    46a3:	b8 be 46             	mov    ax,0x46be
    46a6:	50                   	push   ax
    46a7:	57                   	push   di
    46a8:	9a 55 22 c5 46       	call   0x46c5:0x2255
    46ad:	08 c0                	or     al,al
    46af:	75 03                	jne    0x46b4
    46b1:	e9 82 00             	jmp    0x4736
    46b4:	ff 76 14             	push   WORD PTR [bp+0x14]
    46b7:	ff 76 12             	push   WORD PTR [bp+0x12]
    46ba:	bf c1 05             	mov    di,0x5c1
    46bd:	b8 ed 46             	mov    ax,0x46ed
    46c0:	50                   	push   ax
    46c1:	57                   	push   di
    46c2:	9a 73 22 f4 46       	call   0x46f4:0x2273
    46c7:	89 c7                	mov    di,ax
    46c9:	8e c2                	mov    es,dx
    46cb:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    46d0:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    46d5:	74 5f                	je     0x4736
    46d7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    46db:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    46de:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    46e1:	6a 08                	push   0x8
    46e3:	ff 76 14             	push   WORD PTR [bp+0x14]
    46e6:	ff 76 12             	push   WORD PTR [bp+0x12]
    46e9:	bf c1 05             	mov    di,0x5c1
    46ec:	b8 58 47             	mov    ax,0x4758
    46ef:	50                   	push   ax
    46f0:	57                   	push   di
    46f1:	9a 73 22 43 47       	call   0x4743:0x2273
    46f6:	89 c7                	mov    di,ax
    46f8:	8e c2                	mov    es,dx
    46fa:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    46ff:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    4704:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4707:	06                   	push   es
    4708:	57                   	push   di
    4709:	9a b2 77 16 47       	call   0x4716:0x77b2
    470e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4711:	06                   	push   es
    4712:	57                   	push   di
    4713:	9a 03 73 9d 47       	call   0x479d:0x7303
    4718:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    471b:	06                   	push   es
    471c:	57                   	push   di
    471d:	b8 08 46             	mov    ax,0x4608
    4720:	ba c8 47             	mov    dx,0x47c8
    4723:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4726:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    472a:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    472e:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    4732:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    4736:	c9                   	leave
    4737:	ca 10 00             	retf   0x10
    473a:	55                   	push   bp
    473b:	89 e5                	mov    bp,sp
    473d:	b8 04 00             	mov    ax,0x4
    4740:	9a 44 04 5f 47       	call   0x475f:0x444
    4745:	83 ec 04             	sub    sp,0x4
    4748:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    474c:	75 51                	jne    0x479f
    474e:	ff 76 14             	push   WORD PTR [bp+0x14]
    4751:	ff 76 12             	push   WORD PTR [bp+0x12]
    4754:	bf c1 05             	mov    di,0x5c1
    4757:	b8 6f 47             	mov    ax,0x476f
    475a:	50                   	push   ax
    475b:	57                   	push   di
    475c:	9a 55 22 76 47       	call   0x4776:0x2255
    4761:	08 c0                	or     al,al
    4763:	74 3a                	je     0x479f
    4765:	ff 76 14             	push   WORD PTR [bp+0x14]
    4768:	ff 76 12             	push   WORD PTR [bp+0x12]
    476b:	bf c1 05             	mov    di,0x5c1
    476e:	b8 8d 4a             	mov    ax,0x4a8d
    4771:	50                   	push   ax
    4772:	57                   	push   di
    4773:	9a 73 22 ab 47       	call   0x47ab:0x2273
    4778:	89 c7                	mov    di,ax
    477a:	8e c2                	mov    es,dx
    477c:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    4781:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    4786:	74 17                	je     0x479f
    4788:	6a 08                	push   0x8
    478a:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    478f:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    4794:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4798:	06                   	push   es
    4799:	57                   	push   di
    479a:	9a b2 77 94 5c       	call   0x5c94:0x77b2
    479f:	c9                   	leave
    47a0:	ca 10 00             	retf   0x10
    47a3:	55                   	push   bp
    47a4:	89 e5                	mov    bp,sp
    47a6:	31 c0                	xor    ax,ax
    47a8:	9a 44 04 df 47       	call   0x47df:0x444
    47ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47b0:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    47b5:	06                   	push   es
    47b6:	57                   	push   di
    47b7:	9a 17 2f ff ff       	call   0xffff:0x2f17
    47bc:	08 c0                	or     al,al
    47be:	74 0a                	je     0x47ca
    47c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47c3:	06                   	push   es
    47c4:	57                   	push   di
    47c5:	9a 32 48 30 48       	call   0x4830:0x4832
    47ca:	c9                   	leave
    47cb:	ca 08 00             	retf   0x8
    47ce:	00 00                	add    BYTE PTR [bx+si],al
    47d0:	00 00                	add    BYTE PTR [bx+si],al
    47d2:	ff                   	(bad)
    47d3:	ff 00                	inc    WORD PTR [bx+si]
    47d5:	00 55 89             	add    BYTE PTR [di-0x77],dl
    47d8:	e5 b8                	in     ax,0xb8
    47da:	22 00                	and    al,BYTE PTR [bx+si]
    47dc:	9a 44 04 0f 48       	call   0x480f:0x444
    47e1:	83 ec 22             	sub    sp,0x22
    47e4:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    47e8:	06                   	push   es
    47e9:	57                   	push   di
    47ea:	9a 04 2a 56 48       	call   0x4856:0x2a04
    47ef:	89 c7                	mov    di,ax
    47f1:	8e c2                	mov    es,dx
    47f3:	06                   	push   es
    47f4:	57                   	push   di
    47f5:	9a d2 21 a7 48       	call   0x48a7:0x21d2
    47fa:	50                   	push   ax
    47fb:	8d 7e de             	lea    di,[bp-0x22]
    47fe:	16                   	push   ss
    47ff:	57                   	push   di
    4800:	9a ff ff 00 00       	call   0x0:0xffff
    4805:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    4808:	99                   	cwd
    4809:	bf ce 47             	mov    di,0x47ce
    480c:	9a 16 04 3b 48       	call   0x483b:0x416
    4811:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4814:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4817:	c9                   	leave
    4818:	ca 02 00             	retf   0x2
    481b:	00 01                	add    BYTE PTR [bx+di],al
    481d:	09 01                	or     WORD PTR [bx+di],ax
    481f:	20 03                	and    BYTE PTR [bp+di],al
    4821:	20 20                	and    BYTE PTR [bx+si],ah
    4823:	20 00                	and    BYTE PTR [bx+si],al
    4825:	80 ff ff             	cmp    bh,0xff
    4828:	ff                   	(bad)
    4829:	7f 00                	jg     0x482b
    482b:	00 00                	add    BYTE PTR [bx+si],al
    482d:	00 6a 4c             	add    BYTE PTR [bp+si+0x4c],ch
    4830:	4b                   	dec    bx
    4831:	48                   	dec    ax
    4832:	55                   	push   bp
    4833:	89 e5                	mov    bp,sp
    4835:	b8 0e 04             	mov    ax,0x40e
    4838:	9a 44 04 61 48       	call   0x4861:0x444
    483d:	81 ec 0e 04          	sub    sp,0x40e
    4841:	6a 01                	push   0x1
    4843:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4846:	06                   	push   es
    4847:	57                   	push   di
    4848:	9a d6 4f 50 4a       	call   0x4a50:0x4fd6
    484d:	8d be fc fe          	lea    di,[bp-0x104]
    4851:	16                   	push   ss
    4852:	57                   	push   di
    4853:	9a 4e 20 7f 48       	call   0x487f:0x204e
    4858:	8d be fc fe          	lea    di,[bp-0x104]
    485c:	16                   	push   ss
    485d:	57                   	push   di
    485e:	9a f5 09 66 48       	call   0x4866:0x9f5
    4863:	9a 08 04 fb 48       	call   0x48fb:0x408
    4868:	b8 2c 48             	mov    ax,0x482c
    486b:	0e                   	push   cs
    486c:	50                   	push   ax
    486d:	55                   	push   bp
    486e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4872:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4876:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    487a:	06                   	push   es
    487b:	57                   	push   di
    487c:	9a 04 2a b4 48       	call   0x48b4:0x2a04
    4881:	89 c7                	mov    di,ax
    4883:	8e c2                	mov    es,dx
    4885:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    4889:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    488d:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    4891:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    4896:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    489a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    489e:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    48a2:	06                   	push   es
    48a3:	57                   	push   di
    48a4:	9a 99 20 c3 48       	call   0x48c3:0x2099
    48a9:	6a 08                	push   0x8
    48ab:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    48af:	06                   	push   es
    48b0:	57                   	push   di
    48b1:	9a 04 2a d0 48       	call   0x48d0:0x2a04
    48b6:	89 c7                	mov    di,ax
    48b8:	8e c2                	mov    es,dx
    48ba:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    48be:	06                   	push   es
    48bf:	57                   	push   di
    48c0:	9a f5 11 df 48       	call   0x48df:0x11f5
    48c5:	6a 02                	push   0x2
    48c7:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    48cb:	06                   	push   es
    48cc:	57                   	push   di
    48cd:	9a 04 2a 1f 4a       	call   0x4a1f:0x2a04
    48d2:	89 c7                	mov    di,ax
    48d4:	8e c2                	mov    es,dx
    48d6:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    48da:	06                   	push   es
    48db:	57                   	push   di
    48dc:	9a 78 12 2e 4a       	call   0x4a2e:0x1278
    48e1:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    48e6:	eb 03                	jmp    0x48eb
    48e8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    48eb:	8d be fc fe          	lea    di,[bp-0x104]
    48ef:	16                   	push   ss
    48f0:	57                   	push   di
    48f1:	bf 1b 48             	mov    di,0x481b
    48f4:	0e                   	push   cs
    48f5:	57                   	push   di
    48f6:	6a 00                	push   0x0
    48f8:	9a b5 0d 00 49       	call   0x4900:0xdb5
    48fd:	9a 78 0c 05 49       	call   0x4905:0xc78
    4902:	9a 08 04 33 49       	call   0x4933:0x408
    4907:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    490b:	75 db                	jne    0x48e8
    490d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4910:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    4915:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    4919:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    491d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4922:	06                   	push   es
    4923:	57                   	push   di
    4924:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4927:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    492b:	2d 01 00             	sub    ax,0x1
    492e:	71 05                	jno    0x4935
    4930:	9a 3e 04 73 49       	call   0x4973:0x43e
    4935:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    4939:	31 c0                	xor    ax,ax
    493b:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    493f:	7e 03                	jle    0x4944
    4941:	e9 c8 00             	jmp    0x4a0c
    4944:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4947:	eb 03                	jmp    0x494c
    4949:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    494c:	8d be f0 fc          	lea    di,[bp-0x310]
    4950:	16                   	push   ss
    4951:	57                   	push   di
    4952:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4955:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4959:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    495e:	06                   	push   es
    495f:	57                   	push   di
    4960:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4963:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    4967:	8d be fc fd          	lea    di,[bp-0x204]
    496b:	16                   	push   ss
    496c:	57                   	push   di
    496d:	68 ff 00             	push   0xff
    4970:	9a e7 17 83 49       	call   0x4983:0x17e7
    4975:	bf 1c 48             	mov    di,0x481c
    4978:	0e                   	push   cs
    4979:	57                   	push   di
    497a:	8d be fc fd          	lea    di,[bp-0x204]
    497e:	16                   	push   ss
    497f:	57                   	push   di
    4980:	9a 78 18 9c 49       	call   0x499c:0x1878
    4985:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4988:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    498c:	7e 26                	jle    0x49b4
    498e:	8d be fc fd          	lea    di,[bp-0x204]
    4992:	16                   	push   ss
    4993:	57                   	push   di
    4994:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4997:	6a 01                	push   0x1
    4999:	9a 75 19 b2 49       	call   0x49b2:0x1975
    499e:	bf 1e 48             	mov    di,0x481e
    49a1:	0e                   	push   cs
    49a2:	57                   	push   di
    49a3:	8d be fc fd          	lea    di,[bp-0x204]
    49a7:	16                   	push   ss
    49a8:	57                   	push   di
    49a9:	68 ff 00             	push   0xff
    49ac:	ff 76 fc             	push   WORD PTR [bp-0x4]
    49af:	9a 16 19 c8 49       	call   0x49c8:0x1916
    49b4:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    49b8:	75 bb                	jne    0x4975
    49ba:	8d be f0 fc          	lea    di,[bp-0x310]
    49be:	16                   	push   ss
    49bf:	57                   	push   di
    49c0:	bf 20 48             	mov    di,0x4820
    49c3:	0e                   	push   cs
    49c4:	57                   	push   di
    49c5:	9a cd 17 d3 49       	call   0x49d3:0x17cd
    49ca:	8d be fc fd          	lea    di,[bp-0x204]
    49ce:	16                   	push   ss
    49cf:	57                   	push   di
    49d0:	9a 4c 18 e1 49       	call   0x49e1:0x184c
    49d5:	8d be fc fd          	lea    di,[bp-0x204]
    49d9:	16                   	push   ss
    49da:	57                   	push   di
    49db:	68 ff 00             	push   0xff
    49de:	9a e7 17 f4 49       	call   0x49f4:0x17e7
    49e3:	8d be fc fe          	lea    di,[bp-0x104]
    49e7:	16                   	push   ss
    49e8:	57                   	push   di
    49e9:	8d be fc fd          	lea    di,[bp-0x204]
    49ed:	16                   	push   ss
    49ee:	57                   	push   di
    49ef:	6a 00                	push   0x0
    49f1:	9a b5 0d f9 49       	call   0x49f9:0xdb5
    49f6:	9a 78 0c fe 49       	call   0x49fe:0xc78
    49fb:	9a 08 04 5a 4a       	call   0x4a5a:0x408
    4a00:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a03:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    4a07:	74 03                	je     0x4a0c
    4a09:	e9 3d ff             	jmp    0x4949
    4a0c:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    4a10:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    4a14:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    4a18:	6a 06                	push   0x6
    4a1a:	06                   	push   es
    4a1b:	57                   	push   di
    4a1c:	9a 04 2a 3b 4a       	call   0x4a3b:0x2a04
    4a21:	89 c7                	mov    di,ax
    4a23:	8e c2                	mov    es,dx
    4a25:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4a29:	06                   	push   es
    4a2a:	57                   	push   di
    4a2b:	9a f5 11 4a 4a       	call   0x4a4a:0x11f5
    4a30:	6a 00                	push   0x0
    4a32:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4a36:	06                   	push   es
    4a37:	57                   	push   di
    4a38:	9a 04 2a be 4a       	call   0x4abe:0x2a04
    4a3d:	89 c7                	mov    di,ax
    4a3f:	8e c2                	mov    es,dx
    4a41:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4a45:	06                   	push   es
    4a46:	57                   	push   di
    4a47:	9a 78 12 e5 4a       	call   0x4ae5:0x1278
    4a4c:	55                   	push   bp
    4a4d:	9a d6 47 a6 4c       	call   0x4ca6:0x47d6
    4a52:	05 02 00             	add    ax,0x2
    4a55:	73 05                	jae    0x4a5c
    4a57:	9a 3e 04 64 4a       	call   0x4a64:0x43e
    4a5c:	31 d2                	xor    dx,dx
    4a5e:	bf 24 48             	mov    di,0x4824
    4a61:	9a 16 04 78 4a       	call   0x4a78:0x416
    4a66:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    4a6a:	8d be f2 fb          	lea    di,[bp-0x40e]
    4a6e:	16                   	push   ss
    4a6f:	57                   	push   di
    4a70:	bf 20 48             	mov    di,0x4820
    4a73:	0e                   	push   cs
    4a74:	57                   	push   di
    4a75:	9a cd 17 92 4a       	call   0x4a92:0x17cd
    4a7a:	8d be f2 fc          	lea    di,[bp-0x30e]
    4a7e:	16                   	push   ss
    4a7f:	57                   	push   di
    4a80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a83:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    4a88:	06                   	push   es
    4a89:	57                   	push   di
    4a8a:	9a 53 1d 0a 4b       	call   0x4b0a:0x1d53
    4a8f:	9a 4c 18 a0 4a       	call   0x4aa0:0x184c
    4a94:	8d be fc fd          	lea    di,[bp-0x204]
    4a98:	16                   	push   ss
    4a99:	57                   	push   di
    4a9a:	68 ff 00             	push   0xff
    4a9d:	9a e7 17 b2 4a       	call   0x4ab2:0x17e7
    4aa2:	6a 00                	push   0x0
    4aa4:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    4aa8:	b9 05 00             	mov    cx,0x5
    4aab:	f7 e9                	imul   cx
    4aad:	71 05                	jno    0x4ab4
    4aaf:	9a 3e 04 c8 4a       	call   0x4ac8:0x43e
    4ab4:	50                   	push   ax
    4ab5:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4ab9:	06                   	push   es
    4aba:	57                   	push   di
    4abb:	9a 72 2a da 4a       	call   0x4ada:0x2a72
    4ac0:	5a                   	pop    dx
    4ac1:	2b c2                	sub    ax,dx
    4ac3:	71 05                	jno    0x4aca
    4ac5:	9a 3e 04 f5 4a       	call   0x4af5:0x43e
    4aca:	50                   	push   ax
    4acb:	8d be fc fd          	lea    di,[bp-0x204]
    4acf:	16                   	push   ss
    4ad0:	57                   	push   di
    4ad1:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4ad5:	06                   	push   es
    4ad6:	57                   	push   di
    4ad7:	9a 04 2a 3b 4b       	call   0x4b3b:0x2a04
    4adc:	89 c7                	mov    di,ax
    4ade:	8e c2                	mov    es,dx
    4ae0:	06                   	push   es
    4ae1:	57                   	push   di
    4ae2:	9a 09 1f 62 4b       	call   0x4b62:0x1f09
    4ae7:	8d be f2 fb          	lea    di,[bp-0x40e]
    4aeb:	16                   	push   ss
    4aec:	57                   	push   di
    4aed:	bf 20 48             	mov    di,0x4820
    4af0:	0e                   	push   cs
    4af1:	57                   	push   di
    4af2:	9a cd 17 0f 4b       	call   0x4b0f:0x17cd
    4af7:	8d be f2 fc          	lea    di,[bp-0x30e]
    4afb:	16                   	push   ss
    4afc:	57                   	push   di
    4afd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b00:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    4b05:	06                   	push   es
    4b06:	57                   	push   di
    4b07:	9a 53 1d 87 4b       	call   0x4b87:0x1d53
    4b0c:	9a 4c 18 1d 4b       	call   0x4b1d:0x184c
    4b11:	8d be fc fd          	lea    di,[bp-0x204]
    4b15:	16                   	push   ss
    4b16:	57                   	push   di
    4b17:	68 ff 00             	push   0xff
    4b1a:	9a e7 17 2f 4b       	call   0x4b2f:0x17e7
    4b1f:	6a 00                	push   0x0
    4b21:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    4b25:	b9 04 00             	mov    cx,0x4
    4b28:	f7 e9                	imul   cx
    4b2a:	71 05                	jno    0x4b31
    4b2c:	9a 3e 04 45 4b       	call   0x4b45:0x43e
    4b31:	50                   	push   ax
    4b32:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4b36:	06                   	push   es
    4b37:	57                   	push   di
    4b38:	9a 72 2a 57 4b       	call   0x4b57:0x2a72
    4b3d:	5a                   	pop    dx
    4b3e:	2b c2                	sub    ax,dx
    4b40:	71 05                	jno    0x4b47
    4b42:	9a 3e 04 72 4b       	call   0x4b72:0x43e
    4b47:	50                   	push   ax
    4b48:	8d be fc fd          	lea    di,[bp-0x204]
    4b4c:	16                   	push   ss
    4b4d:	57                   	push   di
    4b4e:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4b52:	06                   	push   es
    4b53:	57                   	push   di
    4b54:	9a 04 2a b8 4b       	call   0x4bb8:0x2a04
    4b59:	89 c7                	mov    di,ax
    4b5b:	8e c2                	mov    es,dx
    4b5d:	06                   	push   es
    4b5e:	57                   	push   di
    4b5f:	9a 09 1f df 4b       	call   0x4bdf:0x1f09
    4b64:	8d be f2 fb          	lea    di,[bp-0x40e]
    4b68:	16                   	push   ss
    4b69:	57                   	push   di
    4b6a:	bf 20 48             	mov    di,0x4820
    4b6d:	0e                   	push   cs
    4b6e:	57                   	push   di
    4b6f:	9a cd 17 8c 4b       	call   0x4b8c:0x17cd
    4b74:	8d be f2 fc          	lea    di,[bp-0x30e]
    4b78:	16                   	push   ss
    4b79:	57                   	push   di
    4b7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b7d:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
    4b82:	06                   	push   es
    4b83:	57                   	push   di
    4b84:	9a 53 1d 04 4c       	call   0x4c04:0x1d53
    4b89:	9a 4c 18 9a 4b       	call   0x4b9a:0x184c
    4b8e:	8d be fc fd          	lea    di,[bp-0x204]
    4b92:	16                   	push   ss
    4b93:	57                   	push   di
    4b94:	68 ff 00             	push   0xff
    4b97:	9a e7 17 ac 4b       	call   0x4bac:0x17e7
    4b9c:	6a 00                	push   0x0
    4b9e:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    4ba2:	b9 03 00             	mov    cx,0x3
    4ba5:	f7 e9                	imul   cx
    4ba7:	71 05                	jno    0x4bae
    4ba9:	9a 3e 04 c2 4b       	call   0x4bc2:0x43e
    4bae:	50                   	push   ax
    4baf:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4bb3:	06                   	push   es
    4bb4:	57                   	push   di
    4bb5:	9a 72 2a d4 4b       	call   0x4bd4:0x2a72
    4bba:	5a                   	pop    dx
    4bbb:	2b c2                	sub    ax,dx
    4bbd:	71 05                	jno    0x4bc4
    4bbf:	9a 3e 04 ef 4b       	call   0x4bef:0x43e
    4bc4:	50                   	push   ax
    4bc5:	8d be fc fd          	lea    di,[bp-0x204]
    4bc9:	16                   	push   ss
    4bca:	57                   	push   di
    4bcb:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4bcf:	06                   	push   es
    4bd0:	57                   	push   di
    4bd1:	9a 04 2a 35 4c       	call   0x4c35:0x2a04
    4bd6:	89 c7                	mov    di,ax
    4bd8:	8e c2                	mov    es,dx
    4bda:	06                   	push   es
    4bdb:	57                   	push   di
    4bdc:	9a 09 1f 5c 4c       	call   0x4c5c:0x1f09
    4be1:	8d be f2 fb          	lea    di,[bp-0x40e]
    4be5:	16                   	push   ss
    4be6:	57                   	push   di
    4be7:	bf 20 48             	mov    di,0x4820
    4bea:	0e                   	push   cs
    4beb:	57                   	push   di
    4bec:	9a cd 17 09 4c       	call   0x4c09:0x17cd
    4bf1:	8d be f2 fc          	lea    di,[bp-0x30e]
    4bf5:	16                   	push   ss
    4bf6:	57                   	push   di
    4bf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bfa:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    4bff:	06                   	push   es
    4c00:	57                   	push   di
    4c01:	9a 53 1d c6 4d       	call   0x4dc6:0x1d53
    4c06:	9a 4c 18 17 4c       	call   0x4c17:0x184c
    4c0b:	8d be fc fd          	lea    di,[bp-0x204]
    4c0f:	16                   	push   ss
    4c10:	57                   	push   di
    4c11:	68 ff 00             	push   0xff
    4c14:	9a e7 17 29 4c       	call   0x4c29:0x17e7
    4c19:	6a 00                	push   0x0
    4c1b:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    4c1f:	b9 02 00             	mov    cx,0x2
    4c22:	f7 e9                	imul   cx
    4c24:	71 05                	jno    0x4c2b
    4c26:	9a 3e 04 3f 4c       	call   0x4c3f:0x43e
    4c2b:	50                   	push   ax
    4c2c:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4c30:	06                   	push   es
    4c31:	57                   	push   di
    4c32:	9a 72 2a 51 4c       	call   0x4c51:0x2a72
    4c37:	5a                   	pop    dx
    4c38:	2b c2                	sub    ax,dx
    4c3a:	71 05                	jno    0x4c41
    4c3c:	9a 3e 04 73 4c       	call   0x4c73:0x43e
    4c41:	50                   	push   ax
    4c42:	8d be fc fd          	lea    di,[bp-0x204]
    4c46:	16                   	push   ss
    4c47:	57                   	push   di
    4c48:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4c4c:	06                   	push   es
    4c4d:	57                   	push   di
    4c4e:	9a 04 2a ff ff       	call   0xffff:0x2a04
    4c53:	89 c7                	mov    di,ax
    4c55:	8e c2                	mov    es,dx
    4c57:	06                   	push   es
    4c58:	57                   	push   di
    4c59:	9a 09 1f ff ff       	call   0xffff:0x1f09
    4c5e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4c62:	83 c4 06             	add    sp,0x6
    4c65:	b8 8a 4c             	mov    ax,0x4c8a
    4c68:	0e                   	push   cs
    4c69:	50                   	push   ax
    4c6a:	8d be fc fe          	lea    di,[bp-0x104]
    4c6e:	16                   	push   ss
    4c6f:	57                   	push   di
    4c70:	9a 4f 0a 78 4c       	call   0x4c78:0xa4f
    4c75:	9a 08 04 97 4c       	call   0x4c97:0x408
    4c7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c7d:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    4c82:	06                   	push   es
    4c83:	57                   	push   di
    4c84:	9a e3 49 bb 4c       	call   0x4cbb:0x49e3
    4c89:	cb                   	retf
    4c8a:	c9                   	leave
    4c8b:	ca 04 00             	retf   0x4
    4c8e:	55                   	push   bp
    4c8f:	89 e5                	mov    bp,sp
    4c91:	b8 04 00             	mov    ax,0x4
    4c94:	9a 44 04 e2 4c       	call   0x4ce2:0x444
    4c99:	83 ec 04             	sub    sp,0x4
    4c9c:	6a 00                	push   0x0
    4c9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ca1:	06                   	push   es
    4ca2:	57                   	push   di
    4ca3:	9a d6 4f 1d 50       	call   0x501d:0x4fd6
    4ca8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cab:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    4cb0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4cb3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4cb6:	06                   	push   es
    4cb7:	57                   	push   di
    4cb8:	9a 3f 4a c5 4c       	call   0x4cc5:0x4a3f
    4cbd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4cc0:	06                   	push   es
    4cc1:	57                   	push   di
    4cc2:	9a ff 49 cf 4c       	call   0x4ccf:0x49ff
    4cc7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4cca:	06                   	push   es
    4ccb:	57                   	push   di
    4ccc:	9a e3 49 8b 4d       	call   0x4d8b:0x49e3
    4cd1:	c9                   	leave
    4cd2:	ca 08 00             	retf   0x8
    4cd5:	01 09                	add    WORD PTR [bx+di],cx
    4cd7:	01 20                	add    WORD PTR [bx+si],sp
    4cd9:	55                   	push   bp
    4cda:	89 e5                	mov    bp,sp
    4cdc:	b8 06 02             	mov    ax,0x206
    4cdf:	9a 44 04 1d 4d       	call   0x4d1d:0x444
    4ce4:	81 ec 06 02          	sub    sp,0x206
    4ce8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ceb:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4cf0:	75 03                	jne    0x4cf5
    4cf2:	e9 d8 02             	jmp    0x4fcd
    4cf5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4cfa:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    4cfd:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    4d01:	3d 00 00             	cmp    ax,0x0
    4d04:	75 32                	jne    0x4d38
    4d06:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4d09:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    4d0d:	76 27                	jbe    0x4d36
    4d0f:	8d be fe fd          	lea    di,[bp-0x202]
    4d13:	16                   	push   ss
    4d14:	57                   	push   di
    4d15:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4d18:	06                   	push   es
    4d19:	57                   	push   di
    4d1a:	9a cd 17 27 4d       	call   0x4d27:0x17cd
    4d1f:	bf d5 4c             	mov    di,0x4cd5
    4d22:	0e                   	push   cs
    4d23:	57                   	push   di
    4d24:	9a 4c 18 34 4d       	call   0x4d34:0x184c
    4d29:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4d2c:	06                   	push   es
    4d2d:	57                   	push   di
    4d2e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4d31:	9a e7 17 64 4d       	call   0x4d64:0x17e7
    4d36:	eb 49                	jmp    0x4d81
    4d38:	3d 01 00             	cmp    ax,0x1
    4d3b:	75 44                	jne    0x4d81
    4d3d:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4d40:	26 8a 05             	mov    al,BYTE PTR es:[di]
    4d43:	30 e4                	xor    ah,ah
    4d45:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    4d49:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    4d4d:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    4d50:	7d 2d                	jge    0x4d7f
    4d52:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    4d56:	8d be fe fd          	lea    di,[bp-0x202]
    4d5a:	16                   	push   ss
    4d5b:	57                   	push   di
    4d5c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4d5f:	06                   	push   es
    4d60:	57                   	push   di
    4d61:	9a cd 17 6e 4d       	call   0x4d6e:0x17cd
    4d66:	bf d7 4c             	mov    di,0x4cd7
    4d69:	0e                   	push   cs
    4d6a:	57                   	push   di
    4d6b:	9a 4c 18 7b 4d       	call   0x4d7b:0x184c
    4d70:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4d73:	06                   	push   es
    4d74:	57                   	push   di
    4d75:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4d78:	9a e7 17 92 4d       	call   0x4d92:0x17e7
    4d7d:	eb ca                	jmp    0x4d49
    4d7f:	eb 00                	jmp    0x4d81
    4d81:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d84:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d87:	bf 0c 01             	mov    di,0x10c
    4d8a:	b8 a2 4d             	mov    ax,0x4da2
    4d8d:	50                   	push   ax
    4d8e:	57                   	push   di
    4d8f:	9a 55 22 a9 4d       	call   0x4da9:0x2255
    4d94:	08 c0                	or     al,al
    4d96:	74 6b                	je     0x4e03
    4d98:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d9b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d9e:	bf 0c 01             	mov    di,0x10c
    4da1:	b8 8f 4e             	mov    ax,0x4e8f
    4da4:	50                   	push   ax
    4da5:	57                   	push   di
    4da6:	9a 73 22 d4 4d       	call   0x4dd4:0x2273
    4dab:	89 c7                	mov    di,ax
    4dad:	8e c2                	mov    es,dx
    4daf:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    4db3:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    4db7:	8d be fa fd          	lea    di,[bp-0x206]
    4dbb:	16                   	push   ss
    4dbc:	57                   	push   di
    4dbd:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    4dc1:	06                   	push   es
    4dc2:	57                   	push   di
    4dc3:	9a 53 1d 48 4e       	call   0x4e48:0x1d53
    4dc8:	8d be 00 ff          	lea    di,[bp-0x100]
    4dcc:	16                   	push   ss
    4dcd:	57                   	push   di
    4dce:	68 ff 00             	push   0xff
    4dd1:	9a e7 17 ff 4d       	call   0x4dff:0x17e7
    4dd6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4ddb:	b0 00                	mov    al,0x0
    4ddd:	76 01                	jbe    0x4de0
    4ddf:	40                   	inc    ax
    4de0:	8a d0                	mov    dl,al
    4de2:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    4de7:	b0 00                	mov    al,0x0
    4de9:	75 01                	jne    0x4dec
    4deb:	40                   	inc    ax
    4dec:	22 c2                	and    al,dl
    4dee:	08 c0                	or     al,al
    4df0:	74 11                	je     0x4e03
    4df2:	8d be 00 ff          	lea    di,[bp-0x100]
    4df6:	16                   	push   ss
    4df7:	57                   	push   di
    4df8:	6a 01                	push   0x1
    4dfa:	6a 01                	push   0x1
    4dfc:	9a 75 19 14 4e       	call   0x4e14:0x1975
    4e01:	eb d3                	jmp    0x4dd6
    4e03:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e06:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e09:	bf ad 0d             	mov    di,0xdad
    4e0c:	b8 24 4e             	mov    ax,0x4e24
    4e0f:	50                   	push   ax
    4e10:	57                   	push   di
    4e11:	9a 55 22 2b 4e       	call   0x4e2b:0x2255
    4e16:	08 c0                	or     al,al
    4e18:	74 6b                	je     0x4e85
    4e1a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e1d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e20:	bf ad 0d             	mov    di,0xdad
    4e23:	b8 ff ff             	mov    ax,0xffff
    4e26:	50                   	push   ax
    4e27:	57                   	push   di
    4e28:	9a 73 22 56 4e       	call   0x4e56:0x2273
    4e2d:	89 c7                	mov    di,ax
    4e2f:	8e c2                	mov    es,dx
    4e31:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    4e35:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    4e39:	8d be fa fd          	lea    di,[bp-0x206]
    4e3d:	16                   	push   ss
    4e3e:	57                   	push   di
    4e3f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    4e43:	06                   	push   es
    4e44:	57                   	push   di
    4e45:	9a 53 1d ca 4e       	call   0x4eca:0x1d53
    4e4a:	8d be 00 ff          	lea    di,[bp-0x100]
    4e4e:	16                   	push   ss
    4e4f:	57                   	push   di
    4e50:	68 ff 00             	push   0xff
    4e53:	9a e7 17 81 4e       	call   0x4e81:0x17e7
    4e58:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4e5d:	b0 00                	mov    al,0x0
    4e5f:	76 01                	jbe    0x4e62
    4e61:	40                   	inc    ax
    4e62:	8a d0                	mov    dl,al
    4e64:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    4e69:	b0 00                	mov    al,0x0
    4e6b:	75 01                	jne    0x4e6e
    4e6d:	40                   	inc    ax
    4e6e:	22 c2                	and    al,dl
    4e70:	08 c0                	or     al,al
    4e72:	74 11                	je     0x4e85
    4e74:	8d be 00 ff          	lea    di,[bp-0x100]
    4e78:	16                   	push   ss
    4e79:	57                   	push   di
    4e7a:	6a 01                	push   0x1
    4e7c:	6a 01                	push   0x1
    4e7e:	9a 75 19 96 4e       	call   0x4e96:0x1975
    4e83:	eb d3                	jmp    0x4e58
    4e85:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e88:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e8b:	bf 17 06             	mov    di,0x617
    4e8e:	b8 a6 4e             	mov    ax,0x4ea6
    4e91:	50                   	push   ax
    4e92:	57                   	push   di
    4e93:	9a 55 22 ad 4e       	call   0x4ead:0x2255
    4e98:	08 c0                	or     al,al
    4e9a:	74 6b                	je     0x4f07
    4e9c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e9f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ea2:	bf 17 06             	mov    di,0x617
    4ea5:	b8 fa 4f             	mov    ax,0x4ffa
    4ea8:	50                   	push   ax
    4ea9:	57                   	push   di
    4eaa:	9a 73 22 d8 4e       	call   0x4ed8:0x2273
    4eaf:	89 c7                	mov    di,ax
    4eb1:	8e c2                	mov    es,dx
    4eb3:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    4eb7:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    4ebb:	8d be fa fd          	lea    di,[bp-0x206]
    4ebf:	16                   	push   ss
    4ec0:	57                   	push   di
    4ec1:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    4ec5:	06                   	push   es
    4ec6:	57                   	push   di
    4ec7:	9a 53 1d 4d 50       	call   0x504d:0x1d53
    4ecc:	8d be 00 ff          	lea    di,[bp-0x100]
    4ed0:	16                   	push   ss
    4ed1:	57                   	push   di
    4ed2:	68 ff 00             	push   0xff
    4ed5:	9a e7 17 03 4f       	call   0x4f03:0x17e7
    4eda:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4edf:	b0 00                	mov    al,0x0
    4ee1:	76 01                	jbe    0x4ee4
    4ee3:	40                   	inc    ax
    4ee4:	8a d0                	mov    dl,al
    4ee6:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    4eeb:	b0 00                	mov    al,0x0
    4eed:	75 01                	jne    0x4ef0
    4eef:	40                   	inc    ax
    4ef0:	22 c2                	and    al,dl
    4ef2:	08 c0                	or     al,al
    4ef4:	74 11                	je     0x4f07
    4ef6:	8d be 00 ff          	lea    di,[bp-0x100]
    4efa:	16                   	push   ss
    4efb:	57                   	push   di
    4efc:	6a 01                	push   0x1
    4efe:	6a 01                	push   0x1
    4f00:	9a 75 19 18 4f       	call   0x4f18:0x1975
    4f05:	eb d3                	jmp    0x4eda
    4f07:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f0a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f0d:	bf 22 00             	mov    di,0x22
    4f10:	b8 2b 4f             	mov    ax,0x4f2b
    4f13:	50                   	push   ax
    4f14:	57                   	push   di
    4f15:	9a 55 22 32 4f       	call   0x4f32:0x2255
    4f1a:	08 c0                	or     al,al
    4f1c:	75 03                	jne    0x4f21
    4f1e:	e9 84 00             	jmp    0x4fa5
    4f21:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f24:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f27:	bf 22 00             	mov    di,0x22
    4f2a:	b8 ff ff             	mov    ax,0xffff
    4f2d:	50                   	push   ax
    4f2e:	57                   	push   di
    4f2f:	9a 73 22 5d 4f       	call   0x4f5d:0x2273
    4f34:	89 c7                	mov    di,ax
    4f36:	8e c2                	mov    es,dx
    4f38:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    4f3c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    4f40:	8d be fa fd          	lea    di,[bp-0x206]
    4f44:	16                   	push   ss
    4f45:	57                   	push   di
    4f46:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    4f4a:	06                   	push   es
    4f4b:	57                   	push   di
    4f4c:	9a 24 15 ff ff       	call   0xffff:0x1524
    4f51:	8d be 00 ff          	lea    di,[bp-0x100]
    4f55:	16                   	push   ss
    4f56:	57                   	push   di
    4f57:	68 ff 00             	push   0xff
    4f5a:	9a e7 17 88 4f       	call   0x4f88:0x17e7
    4f5f:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    4f63:	7e 40                	jle    0x4fa5
    4f65:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    4f69:	30 e4                	xor    ah,ah
    4f6b:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    4f6f:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    4f74:	7d 2f                	jge    0x4fa5
    4f76:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    4f7a:	8d be fa fd          	lea    di,[bp-0x206]
    4f7e:	16                   	push   ss
    4f7f:	57                   	push   di
    4f80:	bf d7 4c             	mov    di,0x4cd7
    4f83:	0e                   	push   cs
    4f84:	57                   	push   di
    4f85:	9a cd 17 93 4f       	call   0x4f93:0x17cd
    4f8a:	8d be 00 ff          	lea    di,[bp-0x100]
    4f8e:	16                   	push   ss
    4f8f:	57                   	push   di
    4f90:	9a 4c 18 a1 4f       	call   0x4fa1:0x184c
    4f95:	8d be 00 ff          	lea    di,[bp-0x100]
    4f99:	16                   	push   ss
    4f9a:	57                   	push   di
    4f9b:	68 ff 00             	push   0xff
    4f9e:	9a e7 17 b3 4f       	call   0x4fb3:0x17e7
    4fa3:	eb ca                	jmp    0x4f6f
    4fa5:	8d be fe fd          	lea    di,[bp-0x202]
    4fa9:	16                   	push   ss
    4faa:	57                   	push   di
    4fab:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4fae:	06                   	push   es
    4faf:	57                   	push   di
    4fb0:	9a cd 17 be 4f       	call   0x4fbe:0x17cd
    4fb5:	8d be 00 ff          	lea    di,[bp-0x100]
    4fb9:	16                   	push   ss
    4fba:	57                   	push   di
    4fbb:	9a 4c 18 cb 4f       	call   0x4fcb:0x184c
    4fc0:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4fc3:	06                   	push   es
    4fc4:	57                   	push   di
    4fc5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4fc8:	9a e7 17 df 4f       	call   0x4fdf:0x17e7
    4fcd:	c9                   	leave
    4fce:	ca 0e 00             	retf   0xe
    4fd1:	01 09                	add    WORD PTR [bx+di],cx
    4fd3:	00 01                	add    BYTE PTR [bx+di],al
    4fd5:	20 55 89             	and    BYTE PTR [di-0x77],dl
    4fd8:	e5 b8                	in     ax,0xb8
    4fda:	04 03                	add    al,0x3
    4fdc:	9a 44 04 2e 50       	call   0x502e:0x444
    4fe1:	81 ec 04 03          	sub    sp,0x304
    4fe5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fe8:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    4fed:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4ff1:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4ff5:	06                   	push   es
    4ff6:	57                   	push   di
    4ff7:	9a e3 49 ff ff       	call   0xffff:0x49e3
    4ffc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5001:	8d be 00 ff          	lea    di,[bp-0x100]
    5005:	16                   	push   ss
    5006:	57                   	push   di
    5007:	68 ff 00             	push   0xff
    500a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    500d:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    5012:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    5017:	6a 00                	push   0x0
    5019:	55                   	push   bp
    501a:	9a d9 4c b8 50       	call   0x50b8:0x4cd9
    501f:	8d be fc fd          	lea    di,[bp-0x204]
    5023:	16                   	push   ss
    5024:	57                   	push   di
    5025:	8d be 00 ff          	lea    di,[bp-0x100]
    5029:	16                   	push   ss
    502a:	57                   	push   di
    502b:	9a cd 17 38 50       	call   0x5038:0x17cd
    5030:	bf d1 4f             	mov    di,0x4fd1
    5033:	0e                   	push   cs
    5034:	57                   	push   di
    5035:	9a 4c 18 52 50       	call   0x5052:0x184c
    503a:	8d be fc fc          	lea    di,[bp-0x304]
    503e:	16                   	push   ss
    503f:	57                   	push   di
    5040:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5043:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    5048:	06                   	push   es
    5049:	57                   	push   di
    504a:	9a 53 1d e8 50       	call   0x50e8:0x1d53
    504f:	9a 4c 18 60 50       	call   0x5060:0x184c
    5054:	8d be 00 ff          	lea    di,[bp-0x100]
    5058:	16                   	push   ss
    5059:	57                   	push   di
    505a:	68 ff 00             	push   0xff
    505d:	9a e7 17 c9 50       	call   0x50c9:0x17e7
    5062:	8d be 00 ff          	lea    di,[bp-0x100]
    5066:	16                   	push   ss
    5067:	57                   	push   di
    5068:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    506c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5071:	06                   	push   es
    5072:	57                   	push   di
    5073:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5076:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    507a:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    507e:	75 17                	jne    0x5097
    5080:	bf d3 4f             	mov    di,0x4fd3
    5083:	0e                   	push   cs
    5084:	57                   	push   di
    5085:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5089:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    508e:	06                   	push   es
    508f:	57                   	push   di
    5090:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5093:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5097:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    509c:	8d be 00 ff          	lea    di,[bp-0x100]
    50a0:	16                   	push   ss
    50a1:	57                   	push   di
    50a2:	68 ff 00             	push   0xff
    50a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50a8:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    50ad:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    50b2:	6a 0a                	push   0xa
    50b4:	55                   	push   bp
    50b5:	9a d9 4c 19 51       	call   0x5119:0x4cd9
    50ba:	8d be fc fd          	lea    di,[bp-0x204]
    50be:	16                   	push   ss
    50bf:	57                   	push   di
    50c0:	8d be 00 ff          	lea    di,[bp-0x100]
    50c4:	16                   	push   ss
    50c5:	57                   	push   di
    50c6:	9a cd 17 d3 50       	call   0x50d3:0x17cd
    50cb:	bf d4 4f             	mov    di,0x4fd4
    50ce:	0e                   	push   cs
    50cf:	57                   	push   di
    50d0:	9a 4c 18 ed 50       	call   0x50ed:0x184c
    50d5:	8d be fc fc          	lea    di,[bp-0x304]
    50d9:	16                   	push   ss
    50da:	57                   	push   di
    50db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50de:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    50e3:	06                   	push   es
    50e4:	57                   	push   di
    50e5:	9a 53 1d 67 51       	call   0x5167:0x1d53
    50ea:	9a 4c 18 fb 50       	call   0x50fb:0x184c
    50ef:	8d be 00 ff          	lea    di,[bp-0x100]
    50f3:	16                   	push   ss
    50f4:	57                   	push   di
    50f5:	68 ff 00             	push   0xff
    50f8:	9a e7 17 48 51       	call   0x5148:0x17e7
    50fd:	8d be 00 ff          	lea    di,[bp-0x100]
    5101:	16                   	push   ss
    5102:	57                   	push   di
    5103:	68 ff 00             	push   0xff
    5106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5109:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    510e:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    5113:	6a 25                	push   0x25
    5115:	55                   	push   bp
    5116:	9a d9 4c 37 51       	call   0x5137:0x4cd9
    511b:	8d be 00 ff          	lea    di,[bp-0x100]
    511f:	16                   	push   ss
    5120:	57                   	push   di
    5121:	68 ff 00             	push   0xff
    5124:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5127:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    512c:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    5131:	6a 46                	push   0x46
    5133:	55                   	push   bp
    5134:	9a d9 4c d4 51       	call   0x51d4:0x4cd9
    5139:	8d be fc fd          	lea    di,[bp-0x204]
    513d:	16                   	push   ss
    513e:	57                   	push   di
    513f:	8d be 00 ff          	lea    di,[bp-0x100]
    5143:	16                   	push   ss
    5144:	57                   	push   di
    5145:	9a cd 17 52 51       	call   0x5152:0x17cd
    514a:	bf d4 4f             	mov    di,0x4fd4
    514d:	0e                   	push   cs
    514e:	57                   	push   di
    514f:	9a 4c 18 6c 51       	call   0x516c:0x184c
    5154:	8d be fc fc          	lea    di,[bp-0x304]
    5158:	16                   	push   ss
    5159:	57                   	push   di
    515a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    515d:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5162:	06                   	push   es
    5163:	57                   	push   di
    5164:	9a 53 1d ff ff       	call   0xffff:0x1d53
    5169:	9a 4c 18 7a 51       	call   0x517a:0x184c
    516e:	8d be 00 ff          	lea    di,[bp-0x100]
    5172:	16                   	push   ss
    5173:	57                   	push   di
    5174:	68 ff 00             	push   0xff
    5177:	9a e7 17 29 52       	call   0x5229:0x17e7
    517c:	8d be 00 ff          	lea    di,[bp-0x100]
    5180:	16                   	push   ss
    5181:	57                   	push   di
    5182:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5186:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    518b:	06                   	push   es
    518c:	57                   	push   di
    518d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5190:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5194:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5198:	75 17                	jne    0x51b1
    519a:	bf d3 4f             	mov    di,0x4fd3
    519d:	0e                   	push   cs
    519e:	57                   	push   di
    519f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    51a3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    51a8:	06                   	push   es
    51a9:	57                   	push   di
    51aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51ad:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    51b1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    51b6:	8d be 00 ff          	lea    di,[bp-0x100]
    51ba:	16                   	push   ss
    51bb:	57                   	push   di
    51bc:	68 ff 00             	push   0xff
    51bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51c2:	26 ff b5 a2 03       	push   WORD PTR es:[di+0x3a2]
    51c7:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    51cc:	ff 36 02 02          	push   WORD PTR ds:0x202
    51d0:	55                   	push   bp
    51d1:	9a d9 4c 18 52       	call   0x5218:0x4cd9
    51d6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    51db:	76 18                	jbe    0x51f5
    51dd:	8d be 00 ff          	lea    di,[bp-0x100]
    51e1:	16                   	push   ss
    51e2:	57                   	push   di
    51e3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    51e7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    51ec:	06                   	push   es
    51ed:	57                   	push   di
    51ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51f1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    51f5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    51fa:	8d be 00 ff          	lea    di,[bp-0x100]
    51fe:	16                   	push   ss
    51ff:	57                   	push   di
    5200:	68 ff 00             	push   0xff
    5203:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5206:	26 ff b5 a6 03       	push   WORD PTR es:[di+0x3a6]
    520b:	26 ff b5 a4 03       	push   WORD PTR es:[di+0x3a4]
    5210:	ff 36 04 02          	push   WORD PTR ds:0x204
    5214:	55                   	push   bp
    5215:	9a d9 4c 61 52       	call   0x5261:0x4cd9
    521a:	8d be fc fd          	lea    di,[bp-0x204]
    521e:	16                   	push   ss
    521f:	57                   	push   di
    5220:	8d be 00 ff          	lea    di,[bp-0x100]
    5224:	16                   	push   ss
    5225:	57                   	push   di
    5226:	9a cd 17 33 52       	call   0x5233:0x17cd
    522b:	bf d1 4f             	mov    di,0x4fd1
    522e:	0e                   	push   cs
    522f:	57                   	push   di
    5230:	9a 4c 18 41 52       	call   0x5241:0x184c
    5235:	8d be 00 ff          	lea    di,[bp-0x100]
    5239:	16                   	push   ss
    523a:	57                   	push   di
    523b:	68 ff 00             	push   0xff
    523e:	9a e7 17 ef 56       	call   0x56ef:0x17e7
    5243:	8d be 00 ff          	lea    di,[bp-0x100]
    5247:	16                   	push   ss
    5248:	57                   	push   di
    5249:	68 ff 00             	push   0xff
    524c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    524f:	26 ff b5 d2 03       	push   WORD PTR es:[di+0x3d2]
    5254:	26 ff b5 d0 03       	push   WORD PTR es:[di+0x3d0]
    5259:	ff 36 08 02          	push   WORD PTR ds:0x208
    525d:	55                   	push   bp
    525e:	9a d9 4c a5 52       	call   0x52a5:0x4cd9
    5263:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5268:	76 18                	jbe    0x5282
    526a:	8d be 00 ff          	lea    di,[bp-0x100]
    526e:	16                   	push   ss
    526f:	57                   	push   di
    5270:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5274:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5279:	06                   	push   es
    527a:	57                   	push   di
    527b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    527e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5282:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5287:	8d be 00 ff          	lea    di,[bp-0x100]
    528b:	16                   	push   ss
    528c:	57                   	push   di
    528d:	68 ff 00             	push   0xff
    5290:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5293:	26 ff b5 b2 04       	push   WORD PTR es:[di+0x4b2]
    5298:	26 ff b5 b0 04       	push   WORD PTR es:[di+0x4b0]
    529d:	ff 36 04 02          	push   WORD PTR ds:0x204
    52a1:	55                   	push   bp
    52a2:	9a d9 4c c5 52       	call   0x52c5:0x4cd9
    52a7:	8d be 00 ff          	lea    di,[bp-0x100]
    52ab:	16                   	push   ss
    52ac:	57                   	push   di
    52ad:	68 ff 00             	push   0xff
    52b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52b3:	26 ff b5 b6 04       	push   WORD PTR es:[di+0x4b6]
    52b8:	26 ff b5 b4 04       	push   WORD PTR es:[di+0x4b4]
    52bd:	ff 36 06 02          	push   WORD PTR ds:0x206
    52c1:	55                   	push   bp
    52c2:	9a d9 4c e5 52       	call   0x52e5:0x4cd9
    52c7:	8d be 00 ff          	lea    di,[bp-0x100]
    52cb:	16                   	push   ss
    52cc:	57                   	push   di
    52cd:	68 ff 00             	push   0xff
    52d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52d3:	26 ff b5 de 03       	push   WORD PTR es:[di+0x3de]
    52d8:	26 ff b5 dc 03       	push   WORD PTR es:[di+0x3dc]
    52dd:	ff 36 08 02          	push   WORD PTR ds:0x208
    52e1:	55                   	push   bp
    52e2:	9a d9 4c 05 53       	call   0x5305:0x4cd9
    52e7:	8d be 00 ff          	lea    di,[bp-0x100]
    52eb:	16                   	push   ss
    52ec:	57                   	push   di
    52ed:	68 ff 00             	push   0xff
    52f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52f3:	26 ff b5 ee 03       	push   WORD PTR es:[di+0x3ee]
    52f8:	26 ff b5 ec 03       	push   WORD PTR es:[di+0x3ec]
    52fd:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5301:	55                   	push   bp
    5302:	9a d9 4c 49 53       	call   0x5349:0x4cd9
    5307:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    530c:	76 18                	jbe    0x5326
    530e:	8d be 00 ff          	lea    di,[bp-0x100]
    5312:	16                   	push   ss
    5313:	57                   	push   di
    5314:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5318:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    531d:	06                   	push   es
    531e:	57                   	push   di
    531f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5322:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5326:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    532b:	8d be 00 ff          	lea    di,[bp-0x100]
    532f:	16                   	push   ss
    5330:	57                   	push   di
    5331:	68 ff 00             	push   0xff
    5334:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5337:	26 ff b5 b2 03       	push   WORD PTR es:[di+0x3b2]
    533c:	26 ff b5 b0 03       	push   WORD PTR es:[di+0x3b0]
    5341:	ff 36 04 02          	push   WORD PTR ds:0x204
    5345:	55                   	push   bp
    5346:	9a d9 4c 69 53       	call   0x5369:0x4cd9
    534b:	8d be 00 ff          	lea    di,[bp-0x100]
    534f:	16                   	push   ss
    5350:	57                   	push   di
    5351:	68 ff 00             	push   0xff
    5354:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5357:	26 ff b5 be 03       	push   WORD PTR es:[di+0x3be]
    535c:	26 ff b5 bc 03       	push   WORD PTR es:[di+0x3bc]
    5361:	ff 36 06 02          	push   WORD PTR ds:0x206
    5365:	55                   	push   bp
    5366:	9a d9 4c 89 53       	call   0x5389:0x4cd9
    536b:	8d be 00 ff          	lea    di,[bp-0x100]
    536f:	16                   	push   ss
    5370:	57                   	push   di
    5371:	68 ff 00             	push   0xff
    5374:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5377:	26 ff b5 e2 03       	push   WORD PTR es:[di+0x3e2]
    537c:	26 ff b5 e0 03       	push   WORD PTR es:[di+0x3e0]
    5381:	ff 36 08 02          	push   WORD PTR ds:0x208
    5385:	55                   	push   bp
    5386:	9a d9 4c a9 53       	call   0x53a9:0x4cd9
    538b:	8d be 00 ff          	lea    di,[bp-0x100]
    538f:	16                   	push   ss
    5390:	57                   	push   di
    5391:	68 ff 00             	push   0xff
    5394:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5397:	26 ff b5 f2 03       	push   WORD PTR es:[di+0x3f2]
    539c:	26 ff b5 f0 03       	push   WORD PTR es:[di+0x3f0]
    53a1:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    53a5:	55                   	push   bp
    53a6:	9a d9 4c ed 53       	call   0x53ed:0x4cd9
    53ab:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    53b0:	76 18                	jbe    0x53ca
    53b2:	8d be 00 ff          	lea    di,[bp-0x100]
    53b6:	16                   	push   ss
    53b7:	57                   	push   di
    53b8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    53bc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    53c1:	06                   	push   es
    53c2:	57                   	push   di
    53c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53c6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    53ca:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    53cf:	8d be 00 ff          	lea    di,[bp-0x100]
    53d3:	16                   	push   ss
    53d4:	57                   	push   di
    53d5:	68 ff 00             	push   0xff
    53d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53db:	26 ff b5 b6 03       	push   WORD PTR es:[di+0x3b6]
    53e0:	26 ff b5 b4 03       	push   WORD PTR es:[di+0x3b4]
    53e5:	ff 36 04 02          	push   WORD PTR ds:0x204
    53e9:	55                   	push   bp
    53ea:	9a d9 4c 0d 54       	call   0x540d:0x4cd9
    53ef:	8d be 00 ff          	lea    di,[bp-0x100]
    53f3:	16                   	push   ss
    53f4:	57                   	push   di
    53f5:	68 ff 00             	push   0xff
    53f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53fb:	26 ff b5 c2 03       	push   WORD PTR es:[di+0x3c2]
    5400:	26 ff b5 c0 03       	push   WORD PTR es:[di+0x3c0]
    5405:	ff 36 06 02          	push   WORD PTR ds:0x206
    5409:	55                   	push   bp
    540a:	9a d9 4c 2d 54       	call   0x542d:0x4cd9
    540f:	8d be 00 ff          	lea    di,[bp-0x100]
    5413:	16                   	push   ss
    5414:	57                   	push   di
    5415:	68 ff 00             	push   0xff
    5418:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    541b:	26 ff b5 e6 03       	push   WORD PTR es:[di+0x3e6]
    5420:	26 ff b5 e4 03       	push   WORD PTR es:[di+0x3e4]
    5425:	ff 36 08 02          	push   WORD PTR ds:0x208
    5429:	55                   	push   bp
    542a:	9a d9 4c 4d 54       	call   0x544d:0x4cd9
    542f:	8d be 00 ff          	lea    di,[bp-0x100]
    5433:	16                   	push   ss
    5434:	57                   	push   di
    5435:	68 ff 00             	push   0xff
    5438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    543b:	26 ff b5 f6 03       	push   WORD PTR es:[di+0x3f6]
    5440:	26 ff b5 f4 03       	push   WORD PTR es:[di+0x3f4]
    5445:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5449:	55                   	push   bp
    544a:	9a d9 4c 91 54       	call   0x5491:0x4cd9
    544f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5454:	76 18                	jbe    0x546e
    5456:	8d be 00 ff          	lea    di,[bp-0x100]
    545a:	16                   	push   ss
    545b:	57                   	push   di
    545c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5460:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5465:	06                   	push   es
    5466:	57                   	push   di
    5467:	26 c4 3d             	les    di,DWORD PTR es:[di]
    546a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    546e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5473:	8d be 00 ff          	lea    di,[bp-0x100]
    5477:	16                   	push   ss
    5478:	57                   	push   di
    5479:	68 ff 00             	push   0xff
    547c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    547f:	26 ff b5 ba 03       	push   WORD PTR es:[di+0x3ba]
    5484:	26 ff b5 b8 03       	push   WORD PTR es:[di+0x3b8]
    5489:	ff 36 04 02          	push   WORD PTR ds:0x204
    548d:	55                   	push   bp
    548e:	9a d9 4c b1 54       	call   0x54b1:0x4cd9
    5493:	8d be 00 ff          	lea    di,[bp-0x100]
    5497:	16                   	push   ss
    5498:	57                   	push   di
    5499:	68 ff 00             	push   0xff
    549c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    549f:	26 ff b5 c6 03       	push   WORD PTR es:[di+0x3c6]
    54a4:	26 ff b5 c4 03       	push   WORD PTR es:[di+0x3c4]
    54a9:	ff 36 06 02          	push   WORD PTR ds:0x206
    54ad:	55                   	push   bp
    54ae:	9a d9 4c d1 54       	call   0x54d1:0x4cd9
    54b3:	8d be 00 ff          	lea    di,[bp-0x100]
    54b7:	16                   	push   ss
    54b8:	57                   	push   di
    54b9:	68 ff 00             	push   0xff
    54bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54bf:	26 ff b5 ea 03       	push   WORD PTR es:[di+0x3ea]
    54c4:	26 ff b5 e8 03       	push   WORD PTR es:[di+0x3e8]
    54c9:	ff 36 08 02          	push   WORD PTR ds:0x208
    54cd:	55                   	push   bp
    54ce:	9a d9 4c f1 54       	call   0x54f1:0x4cd9
    54d3:	8d be 00 ff          	lea    di,[bp-0x100]
    54d7:	16                   	push   ss
    54d8:	57                   	push   di
    54d9:	68 ff 00             	push   0xff
    54dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54df:	26 ff b5 fa 03       	push   WORD PTR es:[di+0x3fa]
    54e4:	26 ff b5 f8 03       	push   WORD PTR es:[di+0x3f8]
    54e9:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    54ed:	55                   	push   bp
    54ee:	9a d9 4c 35 55       	call   0x5535:0x4cd9
    54f3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    54f8:	76 18                	jbe    0x5512
    54fa:	8d be 00 ff          	lea    di,[bp-0x100]
    54fe:	16                   	push   ss
    54ff:	57                   	push   di
    5500:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5504:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5509:	06                   	push   es
    550a:	57                   	push   di
    550b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    550e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5512:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5517:	8d be 00 ff          	lea    di,[bp-0x100]
    551b:	16                   	push   ss
    551c:	57                   	push   di
    551d:	68 ff 00             	push   0xff
    5520:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5523:	26 ff b5 ca 03       	push   WORD PTR es:[di+0x3ca]
    5528:	26 ff b5 c8 03       	push   WORD PTR es:[di+0x3c8]
    552d:	ff 36 04 02          	push   WORD PTR ds:0x204
    5531:	55                   	push   bp
    5532:	9a d9 4c 55 55       	call   0x5555:0x4cd9
    5537:	8d be 00 ff          	lea    di,[bp-0x100]
    553b:	16                   	push   ss
    553c:	57                   	push   di
    553d:	68 ff 00             	push   0xff
    5540:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5543:	26 ff b5 ce 03       	push   WORD PTR es:[di+0x3ce]
    5548:	26 ff b5 cc 03       	push   WORD PTR es:[di+0x3cc]
    554d:	ff 36 06 02          	push   WORD PTR ds:0x206
    5551:	55                   	push   bp
    5552:	9a d9 4c 75 55       	call   0x5575:0x4cd9
    5557:	8d be 00 ff          	lea    di,[bp-0x100]
    555b:	16                   	push   ss
    555c:	57                   	push   di
    555d:	68 ff 00             	push   0xff
    5560:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5563:	26 ff b5 fe 03       	push   WORD PTR es:[di+0x3fe]
    5568:	26 ff b5 fc 03       	push   WORD PTR es:[di+0x3fc]
    556d:	ff 36 08 02          	push   WORD PTR ds:0x208
    5571:	55                   	push   bp
    5572:	9a d9 4c 95 55       	call   0x5595:0x4cd9
    5577:	8d be 00 ff          	lea    di,[bp-0x100]
    557b:	16                   	push   ss
    557c:	57                   	push   di
    557d:	68 ff 00             	push   0xff
    5580:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5583:	26 ff b5 02 04       	push   WORD PTR es:[di+0x402]
    5588:	26 ff b5 00 04       	push   WORD PTR es:[di+0x400]
    558d:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5591:	55                   	push   bp
    5592:	9a d9 4c d9 55       	call   0x55d9:0x4cd9
    5597:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    559c:	76 18                	jbe    0x55b6
    559e:	8d be 00 ff          	lea    di,[bp-0x100]
    55a2:	16                   	push   ss
    55a3:	57                   	push   di
    55a4:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    55a8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    55ad:	06                   	push   es
    55ae:	57                   	push   di
    55af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55b2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    55b6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    55bb:	8d be 00 ff          	lea    di,[bp-0x100]
    55bf:	16                   	push   ss
    55c0:	57                   	push   di
    55c1:	68 ff 00             	push   0xff
    55c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55c7:	26 ff b5 06 04       	push   WORD PTR es:[di+0x406]
    55cc:	26 ff b5 04 04       	push   WORD PTR es:[di+0x404]
    55d1:	ff 36 04 02          	push   WORD PTR ds:0x204
    55d5:	55                   	push   bp
    55d6:	9a d9 4c f9 55       	call   0x55f9:0x4cd9
    55db:	8d be 00 ff          	lea    di,[bp-0x100]
    55df:	16                   	push   ss
    55e0:	57                   	push   di
    55e1:	68 ff 00             	push   0xff
    55e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55e7:	26 ff b5 0a 04       	push   WORD PTR es:[di+0x40a]
    55ec:	26 ff b5 08 04       	push   WORD PTR es:[di+0x408]
    55f1:	ff 36 06 02          	push   WORD PTR ds:0x206
    55f5:	55                   	push   bp
    55f6:	9a d9 4c 19 56       	call   0x5619:0x4cd9
    55fb:	8d be 00 ff          	lea    di,[bp-0x100]
    55ff:	16                   	push   ss
    5600:	57                   	push   di
    5601:	68 ff 00             	push   0xff
    5604:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5607:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    560c:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    5611:	ff 36 08 02          	push   WORD PTR ds:0x208
    5615:	55                   	push   bp
    5616:	9a d9 4c 39 56       	call   0x5639:0x4cd9
    561b:	8d be 00 ff          	lea    di,[bp-0x100]
    561f:	16                   	push   ss
    5620:	57                   	push   di
    5621:	68 ff 00             	push   0xff
    5624:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5627:	26 ff b5 12 04       	push   WORD PTR es:[di+0x412]
    562c:	26 ff b5 10 04       	push   WORD PTR es:[di+0x410]
    5631:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5635:	55                   	push   bp
    5636:	9a d9 4c 9a 56       	call   0x569a:0x4cd9
    563b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5640:	76 18                	jbe    0x565a
    5642:	8d be 00 ff          	lea    di,[bp-0x100]
    5646:	16                   	push   ss
    5647:	57                   	push   di
    5648:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    564c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5651:	06                   	push   es
    5652:	57                   	push   di
    5653:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5656:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    565a:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    565e:	75 17                	jne    0x5677
    5660:	bf d3 4f             	mov    di,0x4fd3
    5663:	0e                   	push   cs
    5664:	57                   	push   di
    5665:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5669:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    566e:	06                   	push   es
    566f:	57                   	push   di
    5670:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5673:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5677:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    567c:	8d be 00 ff          	lea    di,[bp-0x100]
    5680:	16                   	push   ss
    5681:	57                   	push   di
    5682:	68 ff 00             	push   0xff
    5685:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5688:	26 ff b5 16 04       	push   WORD PTR es:[di+0x416]
    568d:	26 ff b5 14 04       	push   WORD PTR es:[di+0x414]
    5692:	ff 36 02 02          	push   WORD PTR ds:0x202
    5696:	55                   	push   bp
    5697:	9a d9 4c de 56       	call   0x56de:0x4cd9
    569c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    56a1:	76 18                	jbe    0x56bb
    56a3:	8d be 00 ff          	lea    di,[bp-0x100]
    56a7:	16                   	push   ss
    56a8:	57                   	push   di
    56a9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    56ad:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    56b2:	06                   	push   es
    56b3:	57                   	push   di
    56b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56b7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    56bb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    56c0:	8d be 00 ff          	lea    di,[bp-0x100]
    56c4:	16                   	push   ss
    56c5:	57                   	push   di
    56c6:	68 ff 00             	push   0xff
    56c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56cc:	26 ff b5 1a 04       	push   WORD PTR es:[di+0x41a]
    56d1:	26 ff b5 18 04       	push   WORD PTR es:[di+0x418]
    56d6:	ff 36 04 02          	push   WORD PTR ds:0x204
    56da:	55                   	push   bp
    56db:	9a d9 4c 27 57       	call   0x5727:0x4cd9
    56e0:	8d be fc fd          	lea    di,[bp-0x204]
    56e4:	16                   	push   ss
    56e5:	57                   	push   di
    56e6:	8d be 00 ff          	lea    di,[bp-0x100]
    56ea:	16                   	push   ss
    56eb:	57                   	push   di
    56ec:	9a cd 17 f9 56       	call   0x56f9:0x17cd
    56f1:	bf d1 4f             	mov    di,0x4fd1
    56f4:	0e                   	push   cs
    56f5:	57                   	push   di
    56f6:	9a 4c 18 07 57       	call   0x5707:0x184c
    56fb:	8d be 00 ff          	lea    di,[bp-0x100]
    56ff:	16                   	push   ss
    5700:	57                   	push   di
    5701:	68 ff 00             	push   0xff
    5704:	9a e7 17 74 5c       	call   0x5c74:0x17e7
    5709:	8d be 00 ff          	lea    di,[bp-0x100]
    570d:	16                   	push   ss
    570e:	57                   	push   di
    570f:	68 ff 00             	push   0xff
    5712:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5715:	26 ff b5 5e 04       	push   WORD PTR es:[di+0x45e]
    571a:	26 ff b5 5c 04       	push   WORD PTR es:[di+0x45c]
    571f:	ff 36 08 02          	push   WORD PTR ds:0x208
    5723:	55                   	push   bp
    5724:	9a d9 4c 6b 57       	call   0x576b:0x4cd9
    5729:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    572e:	76 18                	jbe    0x5748
    5730:	8d be 00 ff          	lea    di,[bp-0x100]
    5734:	16                   	push   ss
    5735:	57                   	push   di
    5736:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    573a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    573f:	06                   	push   es
    5740:	57                   	push   di
    5741:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5744:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5748:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    574d:	8d be 00 ff          	lea    di,[bp-0x100]
    5751:	16                   	push   ss
    5752:	57                   	push   di
    5753:	68 ff 00             	push   0xff
    5756:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5759:	26 ff b5 26 04       	push   WORD PTR es:[di+0x426]
    575e:	26 ff b5 24 04       	push   WORD PTR es:[di+0x424]
    5763:	ff 36 04 02          	push   WORD PTR ds:0x204
    5767:	55                   	push   bp
    5768:	9a d9 4c 8b 57       	call   0x578b:0x4cd9
    576d:	8d be 00 ff          	lea    di,[bp-0x100]
    5771:	16                   	push   ss
    5772:	57                   	push   di
    5773:	68 ff 00             	push   0xff
    5776:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5779:	26 ff b5 36 04       	push   WORD PTR es:[di+0x436]
    577e:	26 ff b5 34 04       	push   WORD PTR es:[di+0x434]
    5783:	ff 36 06 02          	push   WORD PTR ds:0x206
    5787:	55                   	push   bp
    5788:	9a d9 4c ab 57       	call   0x57ab:0x4cd9
    578d:	8d be 00 ff          	lea    di,[bp-0x100]
    5791:	16                   	push   ss
    5792:	57                   	push   di
    5793:	68 ff 00             	push   0xff
    5796:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5799:	26 ff b5 6a 04       	push   WORD PTR es:[di+0x46a]
    579e:	26 ff b5 68 04       	push   WORD PTR es:[di+0x468]
    57a3:	ff 36 08 02          	push   WORD PTR ds:0x208
    57a7:	55                   	push   bp
    57a8:	9a d9 4c cb 57       	call   0x57cb:0x4cd9
    57ad:	8d be 00 ff          	lea    di,[bp-0x100]
    57b1:	16                   	push   ss
    57b2:	57                   	push   di
    57b3:	68 ff 00             	push   0xff
    57b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57b9:	26 ff b5 7a 04       	push   WORD PTR es:[di+0x47a]
    57be:	26 ff b5 78 04       	push   WORD PTR es:[di+0x478]
    57c3:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    57c7:	55                   	push   bp
    57c8:	9a d9 4c 0f 58       	call   0x580f:0x4cd9
    57cd:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    57d2:	76 18                	jbe    0x57ec
    57d4:	8d be 00 ff          	lea    di,[bp-0x100]
    57d8:	16                   	push   ss
    57d9:	57                   	push   di
    57da:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    57de:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    57e3:	06                   	push   es
    57e4:	57                   	push   di
    57e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57e8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    57ec:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    57f1:	8d be 00 ff          	lea    di,[bp-0x100]
    57f5:	16                   	push   ss
    57f6:	57                   	push   di
    57f7:	68 ff 00             	push   0xff
    57fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57fd:	26 ff b5 2a 04       	push   WORD PTR es:[di+0x42a]
    5802:	26 ff b5 28 04       	push   WORD PTR es:[di+0x428]
    5807:	ff 36 04 02          	push   WORD PTR ds:0x204
    580b:	55                   	push   bp
    580c:	9a d9 4c 2f 58       	call   0x582f:0x4cd9
    5811:	8d be 00 ff          	lea    di,[bp-0x100]
    5815:	16                   	push   ss
    5816:	57                   	push   di
    5817:	68 ff 00             	push   0xff
    581a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    581d:	26 ff b5 3a 04       	push   WORD PTR es:[di+0x43a]
    5822:	26 ff b5 38 04       	push   WORD PTR es:[di+0x438]
    5827:	ff 36 06 02          	push   WORD PTR ds:0x206
    582b:	55                   	push   bp
    582c:	9a d9 4c 4f 58       	call   0x584f:0x4cd9
    5831:	8d be 00 ff          	lea    di,[bp-0x100]
    5835:	16                   	push   ss
    5836:	57                   	push   di
    5837:	68 ff 00             	push   0xff
    583a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    583d:	26 ff b5 6e 04       	push   WORD PTR es:[di+0x46e]
    5842:	26 ff b5 6c 04       	push   WORD PTR es:[di+0x46c]
    5847:	ff 36 08 02          	push   WORD PTR ds:0x208
    584b:	55                   	push   bp
    584c:	9a d9 4c 6f 58       	call   0x586f:0x4cd9
    5851:	8d be 00 ff          	lea    di,[bp-0x100]
    5855:	16                   	push   ss
    5856:	57                   	push   di
    5857:	68 ff 00             	push   0xff
    585a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    585d:	26 ff b5 7e 04       	push   WORD PTR es:[di+0x47e]
    5862:	26 ff b5 7c 04       	push   WORD PTR es:[di+0x47c]
    5867:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    586b:	55                   	push   bp
    586c:	9a d9 4c b3 58       	call   0x58b3:0x4cd9
    5871:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5876:	76 18                	jbe    0x5890
    5878:	8d be 00 ff          	lea    di,[bp-0x100]
    587c:	16                   	push   ss
    587d:	57                   	push   di
    587e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5882:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5887:	06                   	push   es
    5888:	57                   	push   di
    5889:	26 c4 3d             	les    di,DWORD PTR es:[di]
    588c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5890:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5895:	8d be 00 ff          	lea    di,[bp-0x100]
    5899:	16                   	push   ss
    589a:	57                   	push   di
    589b:	68 ff 00             	push   0xff
    589e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58a1:	26 ff b5 2e 04       	push   WORD PTR es:[di+0x42e]
    58a6:	26 ff b5 2c 04       	push   WORD PTR es:[di+0x42c]
    58ab:	ff 36 04 02          	push   WORD PTR ds:0x204
    58af:	55                   	push   bp
    58b0:	9a d9 4c d3 58       	call   0x58d3:0x4cd9
    58b5:	8d be 00 ff          	lea    di,[bp-0x100]
    58b9:	16                   	push   ss
    58ba:	57                   	push   di
    58bb:	68 ff 00             	push   0xff
    58be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58c1:	26 ff b5 3e 04       	push   WORD PTR es:[di+0x43e]
    58c6:	26 ff b5 3c 04       	push   WORD PTR es:[di+0x43c]
    58cb:	ff 36 06 02          	push   WORD PTR ds:0x206
    58cf:	55                   	push   bp
    58d0:	9a d9 4c f3 58       	call   0x58f3:0x4cd9
    58d5:	8d be 00 ff          	lea    di,[bp-0x100]
    58d9:	16                   	push   ss
    58da:	57                   	push   di
    58db:	68 ff 00             	push   0xff
    58de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58e1:	26 ff b5 72 04       	push   WORD PTR es:[di+0x472]
    58e6:	26 ff b5 70 04       	push   WORD PTR es:[di+0x470]
    58eb:	ff 36 08 02          	push   WORD PTR ds:0x208
    58ef:	55                   	push   bp
    58f0:	9a d9 4c 13 59       	call   0x5913:0x4cd9
    58f5:	8d be 00 ff          	lea    di,[bp-0x100]
    58f9:	16                   	push   ss
    58fa:	57                   	push   di
    58fb:	68 ff 00             	push   0xff
    58fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5901:	26 ff b5 82 04       	push   WORD PTR es:[di+0x482]
    5906:	26 ff b5 80 04       	push   WORD PTR es:[di+0x480]
    590b:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    590f:	55                   	push   bp
    5910:	9a d9 4c 57 59       	call   0x5957:0x4cd9
    5915:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    591a:	76 18                	jbe    0x5934
    591c:	8d be 00 ff          	lea    di,[bp-0x100]
    5920:	16                   	push   ss
    5921:	57                   	push   di
    5922:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5926:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    592b:	06                   	push   es
    592c:	57                   	push   di
    592d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5930:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5934:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5939:	8d be 00 ff          	lea    di,[bp-0x100]
    593d:	16                   	push   ss
    593e:	57                   	push   di
    593f:	68 ff 00             	push   0xff
    5942:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5945:	26 ff b5 32 04       	push   WORD PTR es:[di+0x432]
    594a:	26 ff b5 30 04       	push   WORD PTR es:[di+0x430]
    594f:	ff 36 04 02          	push   WORD PTR ds:0x204
    5953:	55                   	push   bp
    5954:	9a d9 4c 77 59       	call   0x5977:0x4cd9
    5959:	8d be 00 ff          	lea    di,[bp-0x100]
    595d:	16                   	push   ss
    595e:	57                   	push   di
    595f:	68 ff 00             	push   0xff
    5962:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5965:	26 ff b5 42 04       	push   WORD PTR es:[di+0x442]
    596a:	26 ff b5 40 04       	push   WORD PTR es:[di+0x440]
    596f:	ff 36 06 02          	push   WORD PTR ds:0x206
    5973:	55                   	push   bp
    5974:	9a d9 4c 97 59       	call   0x5997:0x4cd9
    5979:	8d be 00 ff          	lea    di,[bp-0x100]
    597d:	16                   	push   ss
    597e:	57                   	push   di
    597f:	68 ff 00             	push   0xff
    5982:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5985:	26 ff b5 76 04       	push   WORD PTR es:[di+0x476]
    598a:	26 ff b5 74 04       	push   WORD PTR es:[di+0x474]
    598f:	ff 36 08 02          	push   WORD PTR ds:0x208
    5993:	55                   	push   bp
    5994:	9a d9 4c b7 59       	call   0x59b7:0x4cd9
    5999:	8d be 00 ff          	lea    di,[bp-0x100]
    599d:	16                   	push   ss
    599e:	57                   	push   di
    599f:	68 ff 00             	push   0xff
    59a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59a5:	26 ff b5 86 04       	push   WORD PTR es:[di+0x486]
    59aa:	26 ff b5 84 04       	push   WORD PTR es:[di+0x484]
    59af:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    59b3:	55                   	push   bp
    59b4:	9a d9 4c fb 59       	call   0x59fb:0x4cd9
    59b9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    59be:	76 18                	jbe    0x59d8
    59c0:	8d be 00 ff          	lea    di,[bp-0x100]
    59c4:	16                   	push   ss
    59c5:	57                   	push   di
    59c6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    59ca:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    59cf:	06                   	push   es
    59d0:	57                   	push   di
    59d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    59d4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    59d8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    59dd:	8d be 00 ff          	lea    di,[bp-0x100]
    59e1:	16                   	push   ss
    59e2:	57                   	push   di
    59e3:	68 ff 00             	push   0xff
    59e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59e9:	26 ff b5 4e 04       	push   WORD PTR es:[di+0x44e]
    59ee:	26 ff b5 4c 04       	push   WORD PTR es:[di+0x44c]
    59f3:	ff 36 04 02          	push   WORD PTR ds:0x204
    59f7:	55                   	push   bp
    59f8:	9a d9 4c 1b 5a       	call   0x5a1b:0x4cd9
    59fd:	8d be 00 ff          	lea    di,[bp-0x100]
    5a01:	16                   	push   ss
    5a02:	57                   	push   di
    5a03:	68 ff 00             	push   0xff
    5a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a09:	26 ff b5 52 04       	push   WORD PTR es:[di+0x452]
    5a0e:	26 ff b5 50 04       	push   WORD PTR es:[di+0x450]
    5a13:	ff 36 06 02          	push   WORD PTR ds:0x206
    5a17:	55                   	push   bp
    5a18:	9a d9 4c 3b 5a       	call   0x5a3b:0x4cd9
    5a1d:	8d be 00 ff          	lea    di,[bp-0x100]
    5a21:	16                   	push   ss
    5a22:	57                   	push   di
    5a23:	68 ff 00             	push   0xff
    5a26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a29:	26 ff b5 92 04       	push   WORD PTR es:[di+0x492]
    5a2e:	26 ff b5 90 04       	push   WORD PTR es:[di+0x490]
    5a33:	ff 36 08 02          	push   WORD PTR ds:0x208
    5a37:	55                   	push   bp
    5a38:	9a d9 4c 5b 5a       	call   0x5a5b:0x4cd9
    5a3d:	8d be 00 ff          	lea    di,[bp-0x100]
    5a41:	16                   	push   ss
    5a42:	57                   	push   di
    5a43:	68 ff 00             	push   0xff
    5a46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a49:	26 ff b5 96 04       	push   WORD PTR es:[di+0x496]
    5a4e:	26 ff b5 94 04       	push   WORD PTR es:[di+0x494]
    5a53:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5a57:	55                   	push   bp
    5a58:	9a d9 4c 9f 5a       	call   0x5a9f:0x4cd9
    5a5d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5a62:	76 18                	jbe    0x5a7c
    5a64:	8d be 00 ff          	lea    di,[bp-0x100]
    5a68:	16                   	push   ss
    5a69:	57                   	push   di
    5a6a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5a6e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5a73:	06                   	push   es
    5a74:	57                   	push   di
    5a75:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a78:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a7c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5a81:	8d be 00 ff          	lea    di,[bp-0x100]
    5a85:	16                   	push   ss
    5a86:	57                   	push   di
    5a87:	68 ff 00             	push   0xff
    5a8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a8d:	26 ff b5 56 04       	push   WORD PTR es:[di+0x456]
    5a92:	26 ff b5 54 04       	push   WORD PTR es:[di+0x454]
    5a97:	ff 36 04 02          	push   WORD PTR ds:0x204
    5a9b:	55                   	push   bp
    5a9c:	9a d9 4c bf 5a       	call   0x5abf:0x4cd9
    5aa1:	8d be 00 ff          	lea    di,[bp-0x100]
    5aa5:	16                   	push   ss
    5aa6:	57                   	push   di
    5aa7:	68 ff 00             	push   0xff
    5aaa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5aad:	26 ff b5 5a 04       	push   WORD PTR es:[di+0x45a]
    5ab2:	26 ff b5 58 04       	push   WORD PTR es:[di+0x458]
    5ab7:	ff 36 06 02          	push   WORD PTR ds:0x206
    5abb:	55                   	push   bp
    5abc:	9a d9 4c df 5a       	call   0x5adf:0x4cd9
    5ac1:	8d be 00 ff          	lea    di,[bp-0x100]
    5ac5:	16                   	push   ss
    5ac6:	57                   	push   di
    5ac7:	68 ff 00             	push   0xff
    5aca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5acd:	26 ff b5 9a 04       	push   WORD PTR es:[di+0x49a]
    5ad2:	26 ff b5 98 04       	push   WORD PTR es:[di+0x498]
    5ad7:	ff 36 08 02          	push   WORD PTR ds:0x208
    5adb:	55                   	push   bp
    5adc:	9a d9 4c ff 5a       	call   0x5aff:0x4cd9
    5ae1:	8d be 00 ff          	lea    di,[bp-0x100]
    5ae5:	16                   	push   ss
    5ae6:	57                   	push   di
    5ae7:	68 ff 00             	push   0xff
    5aea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5aed:	26 ff b5 9e 04       	push   WORD PTR es:[di+0x49e]
    5af2:	26 ff b5 9c 04       	push   WORD PTR es:[di+0x49c]
    5af7:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5afb:	55                   	push   bp
    5afc:	9a d9 4c 43 5b       	call   0x5b43:0x4cd9
    5b01:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5b06:	76 18                	jbe    0x5b20
    5b08:	8d be 00 ff          	lea    di,[bp-0x100]
    5b0c:	16                   	push   ss
    5b0d:	57                   	push   di
    5b0e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5b12:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b17:	06                   	push   es
    5b18:	57                   	push   di
    5b19:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b1c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5b20:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5b25:	8d be 00 ff          	lea    di,[bp-0x100]
    5b29:	16                   	push   ss
    5b2a:	57                   	push   di
    5b2b:	68 ff 00             	push   0xff
    5b2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b31:	26 ff b5 46 04       	push   WORD PTR es:[di+0x446]
    5b36:	26 ff b5 44 04       	push   WORD PTR es:[di+0x444]
    5b3b:	ff 36 04 02          	push   WORD PTR ds:0x204
    5b3f:	55                   	push   bp
    5b40:	9a d9 4c 63 5b       	call   0x5b63:0x4cd9
    5b45:	8d be 00 ff          	lea    di,[bp-0x100]
    5b49:	16                   	push   ss
    5b4a:	57                   	push   di
    5b4b:	68 ff 00             	push   0xff
    5b4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b51:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    5b56:	26 ff b5 48 04       	push   WORD PTR es:[di+0x448]
    5b5b:	ff 36 06 02          	push   WORD PTR ds:0x206
    5b5f:	55                   	push   bp
    5b60:	9a d9 4c 83 5b       	call   0x5b83:0x4cd9
    5b65:	8d be 00 ff          	lea    di,[bp-0x100]
    5b69:	16                   	push   ss
    5b6a:	57                   	push   di
    5b6b:	68 ff 00             	push   0xff
    5b6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b71:	26 ff b5 8a 04       	push   WORD PTR es:[di+0x48a]
    5b76:	26 ff b5 88 04       	push   WORD PTR es:[di+0x488]
    5b7b:	ff 36 08 02          	push   WORD PTR ds:0x208
    5b7f:	55                   	push   bp
    5b80:	9a d9 4c a3 5b       	call   0x5ba3:0x4cd9
    5b85:	8d be 00 ff          	lea    di,[bp-0x100]
    5b89:	16                   	push   ss
    5b8a:	57                   	push   di
    5b8b:	68 ff 00             	push   0xff
    5b8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b91:	26 ff b5 8e 04       	push   WORD PTR es:[di+0x48e]
    5b96:	26 ff b5 8c 04       	push   WORD PTR es:[di+0x48c]
    5b9b:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5b9f:	55                   	push   bp
    5ba0:	9a d9 4c e7 5b       	call   0x5be7:0x4cd9
    5ba5:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5baa:	76 18                	jbe    0x5bc4
    5bac:	8d be 00 ff          	lea    di,[bp-0x100]
    5bb0:	16                   	push   ss
    5bb1:	57                   	push   di
    5bb2:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5bb6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5bbb:	06                   	push   es
    5bbc:	57                   	push   di
    5bbd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5bc0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5bc4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5bc9:	8d be 00 ff          	lea    di,[bp-0x100]
    5bcd:	16                   	push   ss
    5bce:	57                   	push   di
    5bcf:	68 ff 00             	push   0xff
    5bd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bd5:	26 ff b5 a2 04       	push   WORD PTR es:[di+0x4a2]
    5bda:	26 ff b5 a0 04       	push   WORD PTR es:[di+0x4a0]
    5bdf:	ff 36 04 02          	push   WORD PTR ds:0x204
    5be3:	55                   	push   bp
    5be4:	9a d9 4c 07 5c       	call   0x5c07:0x4cd9
    5be9:	8d be 00 ff          	lea    di,[bp-0x100]
    5bed:	16                   	push   ss
    5bee:	57                   	push   di
    5bef:	68 ff 00             	push   0xff
    5bf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bf5:	26 ff b5 a6 04       	push   WORD PTR es:[di+0x4a6]
    5bfa:	26 ff b5 a4 04       	push   WORD PTR es:[di+0x4a4]
    5bff:	ff 36 06 02          	push   WORD PTR ds:0x206
    5c03:	55                   	push   bp
    5c04:	9a d9 4c 27 5c       	call   0x5c27:0x4cd9
    5c09:	8d be 00 ff          	lea    di,[bp-0x100]
    5c0d:	16                   	push   ss
    5c0e:	57                   	push   di
    5c0f:	68 ff 00             	push   0xff
    5c12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c15:	26 ff b5 aa 04       	push   WORD PTR es:[di+0x4aa]
    5c1a:	26 ff b5 a8 04       	push   WORD PTR es:[di+0x4a8]
    5c1f:	ff 36 08 02          	push   WORD PTR ds:0x208
    5c23:	55                   	push   bp
    5c24:	9a d9 4c 47 5c       	call   0x5c47:0x4cd9
    5c29:	8d be 00 ff          	lea    di,[bp-0x100]
    5c2d:	16                   	push   ss
    5c2e:	57                   	push   di
    5c2f:	68 ff 00             	push   0xff
    5c32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c35:	26 ff b5 ae 04       	push   WORD PTR es:[di+0x4ae]
    5c3a:	26 ff b5 ac 04       	push   WORD PTR es:[di+0x4ac]
    5c3f:	ff 36 0a 02          	push   WORD PTR ds:0x20a
    5c43:	55                   	push   bp
    5c44:	9a d9 4c ff ff       	call   0xffff:0x4cd9
    5c49:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5c4e:	76 18                	jbe    0x5c68
    5c50:	8d be 00 ff          	lea    di,[bp-0x100]
    5c54:	16                   	push   ss
    5c55:	57                   	push   di
    5c56:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5c5a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5c5f:	06                   	push   es
    5c60:	57                   	push   di
    5c61:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c64:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5c68:	c9                   	leave
    5c69:	ca 06 00             	retf   0x6
    5c6c:	55                   	push   bp
    5c6d:	89 e5                	mov    bp,sp
    5c6f:	31 c0                	xor    ax,ax
    5c71:	9a 44 04 a2 5c       	call   0x5ca2:0x444
    5c76:	c7 06 44 01 15 00    	mov    WORD PTR ds:0x144,0x15
    5c7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c7f:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    5c84:	a3 46 01             	mov    ds:0x146,ax
    5c87:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    5c8c:	a3 48 01             	mov    ds:0x148,ax
    5c8f:	06                   	push   es
    5c90:	57                   	push   di
    5c91:	9a 56 55 c2 5c       	call   0x5cc2:0x5556
    5c96:	c9                   	leave
    5c97:	ca 08 00             	retf   0x8
    5c9a:	55                   	push   bp
    5c9b:	89 e5                	mov    bp,sp
    5c9d:	31 c0                	xor    ax,ax
    5c9f:	9a 44 04 d0 5c       	call   0x5cd0:0x444
    5ca4:	c7 06 44 01 16 00    	mov    WORD PTR ds:0x144,0x16
    5caa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cad:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    5cb2:	a3 46 01             	mov    ds:0x146,ax
    5cb5:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    5cba:	a3 48 01             	mov    ds:0x148,ax
    5cbd:	06                   	push   es
    5cbe:	57                   	push   di
    5cbf:	9a 56 55 f0 5c       	call   0x5cf0:0x5556
    5cc4:	c9                   	leave
    5cc5:	ca 08 00             	retf   0x8
    5cc8:	55                   	push   bp
    5cc9:	89 e5                	mov    bp,sp
    5ccb:	31 c0                	xor    ax,ax
    5ccd:	9a 44 04 fe 5c       	call   0x5cfe:0x444
    5cd2:	c7 06 44 01 17 00    	mov    WORD PTR ds:0x144,0x17
    5cd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cdb:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    5ce0:	a3 46 01             	mov    ds:0x146,ax
    5ce3:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    5ce8:	a3 48 01             	mov    ds:0x148,ax
    5ceb:	06                   	push   es
    5cec:	57                   	push   di
    5ced:	9a 56 55 1e 5d       	call   0x5d1e:0x5556
    5cf2:	c9                   	leave
    5cf3:	ca 08 00             	retf   0x8
    5cf6:	55                   	push   bp
    5cf7:	89 e5                	mov    bp,sp
    5cf9:	31 c0                	xor    ax,ax
    5cfb:	9a 44 04 2c 5d       	call   0x5d2c:0x444
    5d00:	c7 06 44 01 18 00    	mov    WORD PTR ds:0x144,0x18
    5d06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d09:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    5d0e:	a3 46 01             	mov    ds:0x146,ax
    5d11:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    5d16:	a3 48 01             	mov    ds:0x148,ax
    5d19:	06                   	push   es
    5d1a:	57                   	push   di
    5d1b:	9a 56 55 4c 5d       	call   0x5d4c:0x5556
    5d20:	c9                   	leave
    5d21:	ca 08 00             	retf   0x8
    5d24:	55                   	push   bp
    5d25:	89 e5                	mov    bp,sp
    5d27:	31 c0                	xor    ax,ax
    5d29:	9a 44 04 5a 5d       	call   0x5d5a:0x444
    5d2e:	c7 06 44 01 19 00    	mov    WORD PTR ds:0x144,0x19
    5d34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d37:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    5d3c:	a3 46 01             	mov    ds:0x146,ax
    5d3f:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    5d44:	a3 48 01             	mov    ds:0x148,ax
    5d47:	06                   	push   es
    5d48:	57                   	push   di
    5d49:	9a 56 55 7a 5d       	call   0x5d7a:0x5556
    5d4e:	c9                   	leave
    5d4f:	ca 08 00             	retf   0x8
    5d52:	55                   	push   bp
    5d53:	89 e5                	mov    bp,sp
    5d55:	31 c0                	xor    ax,ax
    5d57:	9a 44 04 88 5d       	call   0x5d88:0x444
    5d5c:	c7 06 44 01 1a 00    	mov    WORD PTR ds:0x144,0x1a
    5d62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d65:	26 8b 85 30 05       	mov    ax,WORD PTR es:[di+0x530]
    5d6a:	a3 46 01             	mov    ds:0x146,ax
    5d6d:	26 8b 85 2e 05       	mov    ax,WORD PTR es:[di+0x52e]
    5d72:	a3 48 01             	mov    ds:0x148,ax
    5d75:	06                   	push   es
    5d76:	57                   	push   di
    5d77:	9a 56 55 ff ff       	call   0xffff:0x5556
    5d7c:	c9                   	leave
    5d7d:	ca 08 00             	retf   0x8
    5d80:	55                   	push   bp
    5d81:	89 e5                	mov    bp,sp
    5d83:	31 c0                	xor    ax,ax
    5d85:	9a 44 04 ff ff       	call   0xffff:0x444
    5d8a:	ff 36 50 01          	push   WORD PTR ds:0x150
    5d8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d91:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    5d96:	26 ff b5 30 05       	push   WORD PTR es:[di+0x530]
    5d9b:	9a a1 0c ff ff       	call   0xffff:0xca1
    5da0:	c9                   	leave
    5da1:	ca                   	.byte 0xca
    5da2:	08                   	.byte 0x8
