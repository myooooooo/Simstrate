; ================================================================
; seg35_CODE  (12225 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	23 00                	and    ax,WORD PTR [bx+si]
       2:	03 0d                	add    cx,WORD PTR [di]
       4:	54                   	push   sp
       5:	42                   	inc    dx
       6:	75 74                	jne    0x7c
       8:	74 6f                	je     0x79
       a:	6e                   	outs   dx,BYTE PTR ds:[si]
       b:	4c                   	dec    sp
       c:	61                   	popa
       d:	79 6f                	jns    0x7e
       f:	75 74                	jne    0x85
      11:	00 00                	add    BYTE PTR [bx+si],al
      13:	00 00                	add    BYTE PTR [bx+si],al
      15:	00 03                	add    BYTE PTR [bp+di],al
      17:	00 00                	add    BYTE PTR [bx+si],al
      19:	00 02                	add    BYTE PTR [bp+si],al
      1b:	00 69 00             	add    BYTE PTR [bx+di+0x0],ch
      1e:	0b 62 6c             	or     sp,WORD PTR [bp+si+0x6c]
      21:	47                   	inc    di
      22:	6c                   	ins    BYTE PTR es:[di],dx
      23:	79 70                	jns    0x95
      25:	68 4c 65             	push   0x654c
      28:	66 74 0c             	data32 je 0x37
      2b:	62 6c 47             	bound  bp,DWORD PTR [si+0x47]
      2e:	6c                   	ins    BYTE PTR es:[di],dx
      2f:	79 70                	jns    0xa1
      31:	68 52 69             	push   0x6952
      34:	67 68 74 0a          	addr32 push 0xa74
      38:	62 6c 47             	bound  bp,DWORD PTR [si+0x47]
      3b:	6c                   	ins    BYTE PTR es:[di],dx
      3c:	79 70                	jns    0xae
      3e:	68 54 6f             	push   0x6f54
      41:	70 0d                	jo     0x50
      43:	62 6c 47             	bound  bp,DWORD PTR [si+0x47]
      46:	6c                   	ins    BYTE PTR es:[di],dx
      47:	79 70                	jns    0xb9
      49:	68 42 6f             	push   0x6f42
      4c:	74 74                	je     0xc2
      4e:	6f                   	outs   dx,WORD PTR ds:[si]
      4f:	6d                   	ins    WORD PTR es:[di],dx
      50:	03 0c                	add    cx,WORD PTR [si]
      52:	54                   	push   sp
      53:	42                   	inc    dx
      54:	75 74                	jne    0xca
      56:	74 6f                	je     0xc7
      58:	6e                   	outs   dx,BYTE PTR ds:[si]
      59:	53                   	push   bx
      5a:	74 79                	je     0xd5
      5c:	6c                   	ins    BYTE PTR es:[di],dx
      5d:	65 00 00             	add    BYTE PTR gs:[bx+si],al
      60:	00 00                	add    BYTE PTR [bx+si],al
      62:	00 02                	add    BYTE PTR [bp+si],al
      64:	00 00                	add    BYTE PTR [bx+si],al
      66:	00 50 00             	add    BYTE PTR [bx+si+0x0],dl
      69:	11 01                	adc    WORD PTR [bx+di],ax
      6b:	0c 62                	or     al,0x62
      6d:	73 41                	jae    0xb0
      6f:	75 74                	jne    0xe5
      71:	6f                   	outs   dx,WORD PTR ds:[si]
      72:	44                   	inc    sp
      73:	65 74 65             	gs je  0xdb
      76:	63 74 07             	arpl   WORD PTR [si+0x7],si
      79:	62 73 57             	bound  si,DWORD PTR [bp+di+0x57]
      7c:	69 6e 33 31 05       	imul   bp,WORD PTR [bp+0x33],0x531
      81:	62 73 4e             	bound  si,DWORD PTR [bp+di+0x4e]
      84:	65 77 01             	gs ja  0x88
      87:	0a 54 4e             	or     dl,BYTE PTR [si+0x4e]
      8a:	75 6d                	jne    0xf9
      8c:	47                   	inc    di
      8d:	6c                   	ins    BYTE PTR es:[di],dx
      8e:	79 70                	jns    0x100
      90:	68 73 00             	push   0x73
      93:	01 00                	add    WORD PTR [bx+si],ax
      95:	00 00                	add    BYTE PTR [bx+si],al
      97:	04 00                	add    al,0x0
      99:	00 00                	add    BYTE PTR [bx+si],al
      9b:	6a 01                	push   0x1
      9d:	00 00                	add    BYTE PTR [bx+si],al
      9f:	00 00                	add    BYTE PTR [bx+si],al
      a1:	20 01                	and    BYTE PTR [bx+di],al
      a3:	13 01                	adc    ax,WORD PTR [bx+di]
      a5:	9d                   	popf
      a6:	00 3d                	add    BYTE PTR [di],bh
      a8:	08 7e 01             	or     BYTE PTR [bp+0x1],bh
      ab:	10 26 c1 00          	adc    BYTE PTR ds:0xc1,ah
      af:	9a 1f 8e 01 cb       	call   0xcb01:0x8e1f
      b4:	1f                   	pop    ds
      b5:	b1 00                	mov    cl,0x0
      b7:	e0 1f                	loopne 0xd8
      b9:	3c 01                	cmp    al,0x1
      bb:	cd 11                	int    0x11
      bd:	c5 00                	lds    ax,DWORD PTR [bx+si]
      bf:	3a 27                	cmp    ah,BYTE PTR [bx]
      c1:	ed                   	in     ax,dx
      c2:	00 fa                	add    dl,bh
      c4:	10 77 03             	adc    BYTE PTR [bx+0x3],dh
      c7:	d6                   	(bad)
      c8:	14 d1                	adc    al,0xd1
      ca:	00 f4                	add    ah,dh
      cc:	4f                   	dec    di
      cd:	dd 00                	fld    QWORD PTR [bx+si]
      cf:	32 16 d5 00          	xor    dl,BYTE PTR ds:0xd5
      d3:	98                   	cbw
      d4:	15 f9 00             	adc    ax,0xf9
      d7:	51                   	push   cx
      d8:	1b fd                	sbb    di,bp
      da:	00 38                	add    BYTE PTR [bx+si],bh
      dc:	50                   	push   ax
      dd:	e1 00                	loope  0xdf
      df:	1a 50 e5             	sbb    dl,BYTE PTR [bx+si-0x1b]
      e2:	00 21                	add    BYTE PTR [bx+di],ah
      e4:	50                   	push   ax
      e5:	bd 00 27             	mov    bp,0x2700
      e8:	1f                   	pop    ds
      e9:	b9 00 3f             	mov    cx,0x3f00
      ec:	19 f1                	sbb    cx,si
      ee:	00 78 18             	add    BYTE PTR [bx+si+0x18],bh
      f1:	f5                   	cmc
      f2:	00 02                	add    BYTE PTR [bp+si],al
      f4:	21 c9                	and    cx,cx
      f6:	00 3a                	add    BYTE PTR [bp+si],bh
      f8:	1c d9                	sbb    al,0xd9
      fa:	00 15                	add    BYTE PTR [di],dl
      fc:	25 01 01             	and    ax,0x101
      ff:	37                   	aaa
     100:	22 05                	and    al,BYTE PTR [di]
     102:	01 df                	add    di,bx
     104:	22 09                	and    cl,BYTE PTR [bx+di]
     106:	01 f8                	add    ax,di
     108:	16                   	push   ss
     109:	0d 01 a5             	or     ax,0xa501
     10c:	22 a9 00 2c          	and    ch,BYTE PTR [bx+di+0x2c00]
     110:	20 e9                	and    cl,ch
     112:	00 0c                	add    BYTE PTR [si],cl
     114:	54                   	push   sp
     115:	53                   	push   bx
     116:	70 65                	jo     0x17d
     118:	65 64 42             	gs fs inc dx
     11b:	75 74                	jne    0x191
     11d:	74 6f                	je     0x18e
     11f:	6e                   	outs   dx,BYTE PTR ds:[si]
     120:	0c 00                	or     al,0x0
     122:	03 02                	add    ax,WORD PTR [bp+si]
     124:	0c 0f                	or     al,0xf
     126:	18 0f                	sbb    BYTE PTR [bx],cl
     128:	06                   	push   es
     129:	0f 0e                	femms
     12b:	0f 12 0f             	movlps xmm1,QWORD PTR [bx]
     12e:	24 0f                	and    al,0xf
     130:	fb                   	sti
     131:	ff                   	(bad)
     132:	fa                   	cli
     133:	ff                   	(bad)
     134:	f9                   	stc
     135:	ff                   	(bad)
     136:	f8                   	clc
     137:	ff                   	(bad)
     138:	fe                   	(bad)
     139:	ff 9f 25 40          	call   DWORD PTR [bx+0x4025]
     13d:	01 cb                	add    bx,cx
     13f:	25 44 01             	and    ax,0x144
     142:	de 25                	fisub  WORD PTR [di]
     144:	48                   	dec    ax
     145:	01 5d 26             	add    WORD PTR [di+0x26],bx
     148:	4c                   	dec    sp
     149:	01 c2                	add    dx,ax
     14b:	26 50                	es push ax
     14d:	01 d5                	add    bp,dx
     14f:	26 54                	es push sp
     151:	01 e8                	add    ax,bp
     153:	26 58                	es pop ax
     155:	01 36 23 5c          	add    WORD PTR ds:0x5c23,si
     159:	01 72 21             	add    WORD PTR [bp+si+0x21],si
     15c:	60                   	pusha
     15d:	01 c1                	add    cx,ax
     15f:	21 64 01             	and    WORD PTR [si+0x1],sp
     162:	57                   	push   di
     163:	22 68 01             	and    ch,BYTE PTR [bx+si+0x1]
     166:	25 23 7a             	and    ax,0x7a23
     169:	01 07                	add    WORD PTR [bx],ax
     16b:	0c 54                	or     al,0x54
     16d:	53                   	push   bx
     16e:	70 65                	jo     0x1d5
     170:	65 64 42             	gs fs inc dx
     173:	75 74                	jne    0x1e9
     175:	74 6f                	je     0x1e6
     177:	6e                   	outs   dx,BYTE PTR ds:[si]
     178:	bb 00 96             	mov    bx,0x9600
     17b:	01 ad 08 f1          	add    WORD PTR [di-0xef8],bp
     17f:	01 1c                	add    WORD PTR [si],bx
     181:	00 07                	add    BYTE PTR [bx],al
     183:	42                   	inc    dx
     184:	75 74                	jne    0x1fa
     186:	74 6f                	je     0x1f7
     188:	6e                   	outs   dx,BYTE PTR ds:[si]
     189:	73 14                	jae    0x19f
     18b:	00 07                	add    BYTE PTR [bx],al
     18d:	23 b1 01 96          	and    si,WORD PTR [bx+di-0x69ff]
     191:	00 ff                	add    bh,bh
     193:	ff                   	(bad)
     194:	7c 25                	jl     0x1bb
     196:	b9 01 01             	mov    cx,0x101
     199:	00 00                	add    BYTE PTR [bx+si],al
     19b:	00 00                	add    BYTE PTR [bx+si],al
     19d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1a0:	00 00                	add    BYTE PTR [bx+si],al
     1a2:	08 00                	or     BYTE PTR [bx+si],al
     1a4:	0a 41 6c             	or     al,BYTE PTR [bx+di+0x6c]
     1a7:	6c                   	ins    BYTE PTR es:[di],dx
     1a8:	6f                   	outs   dx,WORD PTR ds:[si]
     1a9:	77 41                	ja     0x1ec
     1ab:	6c                   	ins    BYTE PTR es:[di],dx
     1ac:	6c                   	ins    BYTE PTR es:[di],dx
     1ad:	55                   	push   bp
     1ae:	70 d4                	jo     0x184
     1b0:	22 d4                	and    dl,ah
     1b2:	01 8e 00 ff          	add    WORD PTR [bp-0x100],cx
     1b6:	ff e4                	jmp    sp
     1b8:	24 dc                	and    al,0xdc
     1ba:	01 01                	add    WORD PTR [bx+di],ax
     1bc:	00 00                	add    BYTE PTR [bx+si],al
     1be:	00 00                	add    BYTE PTR [bx+si],al
     1c0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1c3:	00 00                	add    BYTE PTR [bx+si],al
     1c5:	09 00                	or     WORD PTR [bx+si],ax
     1c7:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     1ca:	6f                   	outs   dx,WORD PTR ds:[si]
     1cb:	75 70                	jne    0x23d
     1cd:	49                   	dec    cx
     1ce:	6e                   	outs   dx,BYTE PTR ds:[si]
     1cf:	64 65 78 07          	fs gs js 0x1da
     1d3:	23 11                	and    dx,WORD PTR [bx+di]
     1d5:	02 94 00 ff          	add    dl,BYTE PTR [si-0x100]
     1d9:	ff 70 24             	push   WORD PTR [bx+si+0x24]
     1dc:	52                   	push   dx
     1dd:	02 01                	add    al,BYTE PTR [bx+di]
     1df:	00 00                	add    BYTE PTR [bx+si],al
     1e1:	00 00                	add    BYTE PTR [bx+si],al
     1e3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1e6:	00 00                	add    BYTE PTR [bx+si],al
     1e8:	0a 00                	or     al,BYTE PTR [bx+si]
     1ea:	04 44                	add    al,0x44
     1ec:	6f                   	outs   dx,WORD PTR ds:[si]
     1ed:	77 6e                	ja     0x25d
     1ef:	66 01 f5             	add    ebp,esi
     1f2:	01 53 1d             	add    WORD PTR [bp+di+0x1d],dx
     1f5:	f9                   	stc
     1f6:	01 8c 1d 19          	add    WORD PTR [si+0x191d],cx
     1fa:	02 01                	add    al,BYTE PTR [bx+di]
     1fc:	00 00                	add    BYTE PTR [bx+si],al
     1fe:	00 00                	add    BYTE PTR [bx+si],al
     200:	80 00 00             	add    BYTE PTR [bx+si],0x0
     203:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     207:	07                   	pop    es
     208:	43                   	inc    bx
     209:	61                   	popa
     20a:	70 74                	jo     0x280
     20c:	69 6f 6e 07 23       	imul   bp,WORD PTR [bx+0x6e],0x2307
     211:	8b 02                	mov    ax,WORD PTR [bp+si]
     213:	2a 00                	sub    al,BYTE PTR [bx+si]
     215:	ff                   	(bad)
     216:	ff                   	(bad)
     217:	b8 1c 39             	mov    ax,0x391c
     21a:	02 01                	add    al,BYTE PTR [bx+di]
     21c:	00 00                	add    BYTE PTR [bx+si],al
     21e:	00 00                	add    BYTE PTR [bx+si],al
     220:	80 01 00             	add    BYTE PTR [bx+di],0x0
     223:	00 00                	add    BYTE PTR [bx+si],al
     225:	0c 00                	or     al,0x0
     227:	07                   	pop    es
     228:	45                   	inc    bp
     229:	6e                   	outs   dx,BYTE PTR ds:[si]
     22a:	61                   	popa
     22b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     22e:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     231:	4e                   	dec    si
     232:	02 34                	add    dh,BYTE PTR [si]
     234:	00 ff                	add    bh,bh
     236:	ff                   	jmp    (bad)
     237:	eb 1d                	jmp    0x256
     239:	3d 02 08             	cmp    ax,0x802
     23c:	1e                   	push   ds
     23d:	d4 02                	aam    0x2
     23f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     243:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     247:	04 46                	add    al,0x46
     249:	6f                   	outs   dx,WORD PTR ds:[si]
     24a:	6e                   	outs   dx,BYTE PTR ds:[si]
     24b:	74 8f                	je     0x1dc
     24d:	08 fe                	or     dh,bh
     24f:	05 59 23             	add    ax,0x2359
     252:	56                   	push   si
     253:	02 7d 23             	add    bh,BYTE PTR [di+0x23]
     256:	6c                   	ins    BYTE PTR es:[di],dx
     257:	02 01                	add    al,BYTE PTR [bx+di]
     259:	00 00                	add    BYTE PTR [bx+si],al
     25b:	00 00                	add    BYTE PTR [bx+si],al
     25d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     260:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     264:	05 47 6c             	add    ax,0x6c47
     267:	79 70                	jns    0x2d9
     269:	68 02 00             	push   0x2
     26c:	74 02                	je     0x270
     26e:	97                   	xchg   di,ax
     26f:	00 ff                	add    bh,bh
     271:	ff 07                	inc    WORD PTR [bx]
     273:	25 93 02             	and    ax,0x293
     276:	01 00                	add    WORD PTR [bx+si],ax
     278:	00 00                	add    BYTE PTR [bx+si],al
     27a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     27e:	00 00                	add    BYTE PTR [bx+si],al
     280:	0f 00 06 4c 61       	sldt   WORD PTR ds:0x614c
     285:	79 6f                	jns    0x2f6
     287:	75 74                	jne    0x2fd
     289:	d4 22                	aam    0x22
     28b:	cc                   	int3
     28c:	02 9a 00 ff          	add    bl,BYTE PTR [bp+si-0x100]
     290:	ff 2c                	jmp    DWORD PTR [si]
     292:	25 aa 02             	and    ax,0x2aa
     295:	01 00                	add    WORD PTR [bx+si],ax
     297:	00 00                	add    BYTE PTR [bx+si],al
     299:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     29d:	ff                   	(bad)
     29e:	ff 10                	call   WORD PTR [bx+si]
     2a0:	00 06 4d 61          	add    BYTE PTR ds:0x614d,al
     2a4:	72 67                	jb     0x30d
     2a6:	69 6e 86 00 ae       	imul   bp,WORD PTR [bp-0x7a],0xae00
     2ab:	02 a5 23 b2          	add    ah,BYTE PTR [di-0x4ddd]
     2af:	02 bf 23 3f          	add    bh,BYTE PTR [bx+0x3f23]
     2b3:	03 01                	add    ax,WORD PTR [bx+di]
     2b5:	00 00                	add    BYTE PTR [bx+si],al
     2b7:	00 00                	add    BYTE PTR [bx+si],al
     2b9:	80 01 00             	add    BYTE PTR [bx+di],0x0
     2bc:	00 00                	add    BYTE PTR [bx+si],al
     2be:	11 00                	adc    WORD PTR [bx+si],ax
     2c0:	09 4e 75             	or     WORD PTR [bp+0x75],cx
     2c3:	6d                   	ins    WORD PTR es:[di],dx
     2c4:	47                   	inc    di
     2c5:	6c                   	ins    BYTE PTR es:[di],dx
     2c6:	79 70                	jns    0x338
     2c8:	68 73 07             	push   0x773
     2cb:	23 ef                	and    bp,di
     2cd:	02 2b                	add    ch,BYTE PTR [bp+di]
     2cf:	00 ff                	add    bh,bh
     2d1:	ff                   	(bad)
     2d2:	3e 1e                	ds push ds
     2d4:	f7 02 01 00          	test   WORD PTR [bp+si],0x1
     2d8:	00 00                	add    BYTE PTR [bx+si],al
     2da:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     2de:	00 00                	add    BYTE PTR [bx+si],al
     2e0:	12 00                	adc    al,BYTE PTR [bx+si]
     2e2:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     2e5:	72 65                	jb     0x34c
     2e7:	6e                   	outs   dx,BYTE PTR ds:[si]
     2e8:	74 46                	je     0x330
     2ea:	6f                   	outs   dx,WORD PTR ds:[si]
     2eb:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ec:	74 07                	je     0x2f5
     2ee:	23 16 03 49          	and    dx,WORD PTR ds:0x4903
     2f2:	00 ff                	add    bh,bh
     2f4:	ff a1 1e 1e          	jmp    WORD PTR [bx+di+0x1e1e]
     2f8:	03 01                	add    ax,WORD PTR [bx+di]
     2fa:	00 00                	add    BYTE PTR [bx+si],al
     2fc:	00 00                	add    BYTE PTR [bx+si],al
     2fe:	80 01 00             	add    BYTE PTR [bx+di],0x0
     301:	00 00                	add    BYTE PTR [bx+si],al
     303:	13 00                	adc    ax,WORD PTR [bx+si]
     305:	0e                   	push   cs
     306:	50                   	push   ax
     307:	61                   	popa
     308:	72 65                	jb     0x36f
     30a:	6e                   	outs   dx,BYTE PTR ds:[si]
     30b:	74 53                	je     0x360
     30d:	68 6f 77             	push   0x776f
     310:	48                   	dec    ax
     311:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     316:	37                   	aaa
     317:	03 48 00             	add    cx,WORD PTR [bx+si+0x0]
     31a:	ff                   	(bad)
     31b:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     31e:	22 03                	and    al,BYTE PTR [bp+di]
     320:	23 1e 5f 03          	and    bx,WORD PTR ds:0x35f
     324:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     328:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     32c:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     32f:	6f                   	outs   dx,WORD PTR ds:[si]
     330:	77 48                	ja     0x37a
     332:	69 6e 74 d4 22       	imul   bp,WORD PTR [bp+0x74],0x22d4
     337:	57                   	push   di
     338:	03 98 00 ff          	add    bx,WORD PTR [bx+si-0x100]
     33c:	ff 57 25             	call   WORD PTR [bx+0x25]
     33f:	3a 04                	cmp    al,BYTE PTR [si]
     341:	01 00                	add    WORD PTR [bx+si],ax
     343:	00 00                	add    BYTE PTR [bx+si],al
     345:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     349:	00 00                	add    BYTE PTR [bx+si],al
     34b:	15 00 07             	adc    ax,0x700
     34e:	53                   	push   bx
     34f:	70 61                	jo     0x3b2
     351:	63 69 6e             	arpl   WORD PTR [bx+di+0x6e],bp
     354:	67 07                	addr32 pop es
     356:	23 a6 04 29          	and    sp,WORD PTR [bp+0x2904]
     35a:	00 ff                	add    bh,bh
     35c:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     35f:	ba 03 01             	mov    dx,0x103
     362:	00 00                	add    BYTE PTR [bx+si],al
     364:	00 00                	add    BYTE PTR [bx+si],al
     366:	80 01 00             	add    BYTE PTR [bx+di],0x0
     369:	00 00                	add    BYTE PTR [bx+si],al
     36b:	16                   	push   ss
     36c:	00 07                	add    BYTE PTR [bx],al
     36e:	56                   	push   si
     36f:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     374:	65 71 00             	gs jno 0x377
     377:	97                   	xchg   di,ax
     378:	03 7a 00             	add    di,WORD PTR [bp+si+0x0]
     37b:	ff                   	(bad)
     37c:	ff                   	(bad)
     37d:	7a 00                	jp     0x37f
     37f:	ff                   	(bad)
     380:	ff 01                	inc    WORD PTR [bx+di]
     382:	00 00                	add    BYTE PTR [bx+si],al
     384:	00 00                	add    BYTE PTR [bx+si],al
     386:	80 00 00             	add    BYTE PTR [bx+si],0x0
     389:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     38d:	07                   	pop    es
     38e:	4f                   	dec    di
     38f:	6e                   	outs   dx,BYTE PTR ds:[si]
     390:	43                   	inc    bx
     391:	6c                   	ins    BYTE PTR es:[di],dx
     392:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     397:	be 04 82             	mov    si,0x8204
     39a:	00 ff                	add    bh,bh
     39c:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     3a0:	ff 01                	inc    WORD PTR [bx+di]
     3a2:	00 00                	add    BYTE PTR [bx+si],al
     3a4:	00 00                	add    BYTE PTR [bx+si],al
     3a6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3a9:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     3ad:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     3b0:	44                   	inc    sp
     3b1:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     3b4:	6c                   	ins    BYTE PTR es:[di],dx
     3b5:	69 63 6b 71 01       	imul   sp,WORD PTR [bp+di+0x6b],0x171
     3ba:	de 03                	fiadd  WORD PTR [bp+di]
     3bc:	4a                   	dec    dx
     3bd:	00 ff                	add    bh,bh
     3bf:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     3c2:	ff                   	(bad)
     3c3:	ff 01                	inc    WORD PTR [bx+di]
     3c5:	00 00                	add    BYTE PTR [bx+si],al
     3c7:	00 00                	add    BYTE PTR [bx+si],al
     3c9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3cc:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     3d0:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     3d3:	4d                   	dec    bp
     3d4:	6f                   	outs   dx,WORD PTR ds:[si]
     3d5:	75 73                	jne    0x44a
     3d7:	65 44                	gs inc sp
     3d9:	6f                   	outs   dx,WORD PTR ds:[si]
     3da:	77 6e                	ja     0x44a
     3dc:	ce                   	into
     3dd:	01 02                	add    WORD PTR [bp+si],ax
     3df:	04 52                	add    al,0x52
     3e1:	00 ff                	add    bh,bh
     3e3:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     3e6:	ff                   	(bad)
     3e7:	ff 01                	inc    WORD PTR [bx+di]
     3e9:	00 00                	add    BYTE PTR [bx+si],al
     3eb:	00 00                	add    BYTE PTR [bx+si],al
     3ed:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3f0:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     3f4:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     3f7:	4d                   	dec    bp
     3f8:	6f                   	outs   dx,WORD PTR ds:[si]
     3f9:	75 73                	jne    0x46e
     3fb:	65 4d                	gs dec bp
     3fd:	6f                   	outs   dx,WORD PTR ds:[si]
     3fe:	76 65                	jbe    0x465
     400:	71 01                	jno    0x403
     402:	02 05                	add    al,BYTE PTR [di]
     404:	5a                   	pop    dx
     405:	00 ff                	add    bh,bh
     407:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     40a:	ff                   	(bad)
     40b:	ff 01                	inc    WORD PTR [bx+di]
     40d:	00 00                	add    BYTE PTR [bx+si],al
     40f:	00 00                	add    BYTE PTR [bx+si],al
     411:	80 00 00             	add    BYTE PTR [bx+si],0x0
     414:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     418:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     41b:	4d                   	dec    bp
     41c:	6f                   	outs   dx,WORD PTR ds:[si]
     41d:	75 73                	jne    0x492
     41f:	65 55                	gs push bp
     421:	70 03                	jo     0x426
     423:	0b 54 42             	or     dx,WORD PTR [si+0x42]
     426:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     42b:	4b                   	dec    bx
     42c:	69 6e 64 00 00       	imul   bp,WORD PTR [bp+0x64],0x0
     431:	00 00                	add    BYTE PTR [bx+si],al
     433:	00 0a                	add    BYTE PTR [bp+si],cl
     435:	00 00                	add    BYTE PTR [bx+si],al
     437:	00 22                	add    BYTE PTR [bp+si],ah
     439:	04 06                	add    al,0x6
     43b:	05 08 62             	add    ax,0x6208
     43e:	6b 43 75 73          	imul   ax,WORD PTR [bp+di+0x75],0x73
     442:	74 6f                	je     0x4b3
     444:	6d                   	ins    WORD PTR es:[di],dx
     445:	04 62                	add    al,0x62
     447:	6b 4f 4b 08          	imul   cx,WORD PTR [bx+0x4b],0x8
     44b:	62 6b 43             	bound  bp,DWORD PTR [bp+di+0x43]
     44e:	61                   	popa
     44f:	6e                   	outs   dx,BYTE PTR ds:[si]
     450:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     453:	06                   	push   es
     454:	62 6b 48             	bound  bp,DWORD PTR [bp+di+0x48]
     457:	65 6c                	gs ins BYTE PTR es:[di],dx
     459:	70 05                	jo     0x460
     45b:	62 6b 59             	bound  bp,DWORD PTR [bp+di+0x59]
     45e:	65 73 04             	gs jae 0x465
     461:	62 6b 4e             	bound  bp,DWORD PTR [bp+di+0x4e]
     464:	6f                   	outs   dx,WORD PTR ds:[si]
     465:	07                   	pop    es
     466:	62 6b 43             	bound  bp,DWORD PTR [bp+di+0x43]
     469:	6c                   	ins    BYTE PTR es:[di],dx
     46a:	6f                   	outs   dx,WORD PTR ds:[si]
     46b:	73 65                	jae    0x4d2
     46d:	07                   	pop    es
     46e:	62 6b 41             	bound  bp,DWORD PTR [bp+di+0x41]
     471:	62 6f 72             	bound  bp,DWORD PTR [bx+0x72]
     474:	74 07                	je     0x47d
     476:	62 6b 52             	bound  bp,DWORD PTR [bp+di+0x52]
     479:	65 74 72             	gs je  0x4ee
     47c:	79 08                	jns    0x486
     47e:	62 6b 49             	bound  bp,DWORD PTR [bp+di+0x49]
     481:	67 6e                	outs   dx,BYTE PTR ds:[esi]
     483:	6f                   	outs   dx,WORD PTR ds:[si]
     484:	72 65                	jb     0x4eb
     486:	05 62 6b             	add    ax,0x6b62
     489:	41                   	inc    cx
     48a:	6c                   	ins    BYTE PTR es:[di],dx
     48b:	6c                   	ins    BYTE PTR es:[di],dx
     48c:	60                   	pusha
     48d:	05 00 00             	add    ax,0x0
     490:	00 00                	add    BYTE PTR [bx+si],al
     492:	34 05                	xor    al,0x5
     494:	2c 05                	sub    al,0x5
     496:	f1                   	int1
     497:	00 68 21             	add    BYTE PTR [bx+si+0x21],ch
     49a:	6f                   	outs   dx,WORD PTR ds:[si]
     49b:	05 fa 45             	add    ax,0x45fa
     49e:	12 05                	adc    al,BYTE PTR [di]
     4a0:	9a 1f 7f 05 cb       	call   0xcb05:0x7f1f
     4a5:	1f                   	pop    ds
     4a6:	a2 04 b0             	mov    ds:0xb004,al
     4a9:	27                   	daa
     4aa:	46                   	inc    si
     4ab:	05 cd 11             	add    ax,0x11cd
     4ae:	b6 04                	mov    dh,0x4
     4b0:	3a 27                	cmp    ah,BYTE PTR [bx]
     4b2:	ba 04 fa             	mov    dx,0xfa04
     4b5:	10 a4 07 d6          	adc    BYTE PTR [si-0x29f9],ah
     4b9:	14 c2                	adc    al,0xc2
     4bb:	04 f4                	add    al,0xf4
     4bd:	4f                   	dec    di
     4be:	ce                   	into
     4bf:	04 32                	add    al,0x32
     4c1:	16                   	push   ss
     4c2:	ea 04 ec 30 22       	jmp    0x2230:0xec04
     4c7:	05 51 1b             	add    ax,0x1b51
     4ca:	9e                   	sahf
     4cb:	05 38 50             	add    ax,0x5038
     4ce:	d6                   	(bad)
     4cf:	04 63                	add    al,0x63
     4d1:	31 f2                	xor    dx,si
     4d3:	04 21                	add    al,0x21
     4d5:	50                   	push   ax
     4d6:	ae                   	scas   al,BYTE PTR es:[di]
     4d7:	04 fe                	add    al,0xfe
     4d9:	26 aa                	es stos BYTE PTR es:[di],al
     4db:	04 d9                	add    al,0xd9
     4dd:	62 e2 04 06 63       	(bad)
     4e2:	e6 04                	out    0x4,al
     4e4:	8f                   	(bad)
     4e5:	60                   	pusha
     4e6:	1e                   	push   ds
     4e7:	05 3a 1c             	add    ax,0x1c3a
     4ea:	ca 04 35             	retf   0x3504
     4ed:	69 9a 04 08 61 f6    	imul   bx,WORD PTR [bp+si+0x804],0xf661
     4f3:	04 5c                	add    al,0x5c
     4f5:	61                   	popa
     4f6:	fa                   	cli
     4f7:	04 62                	add    al,0x62
     4f9:	5c                   	pop    sp
     4fa:	26 05 3a 61          	es add ax,0x613a
     4fe:	b2 04                	mov    dl,0x4
     500:	72 3f                	jb     0x541
     502:	0a 05                	or     al,BYTE PTR [di]
     504:	ed                   	in     ax,dx
     505:	27                   	daa
     506:	2a 05                	sub    al,BYTE PTR [di]
     508:	17                   	pop    ss
     509:	3e 9e                	ds sahf
     50b:	04 5c                	add    al,0x5c
     50d:	6b ee 04             	imul   bp,si,0x4
     510:	ed                   	in     ax,dx
     511:	3e 16                	ds push ss
     513:	05 77 3e             	add    ax,0x3e77
     516:	1a 05                	sbb    al,BYTE PTR [di]
     518:	c2 35 de             	ret    0xde35
     51b:	04 1c                	add    al,0x1c
     51d:	48                   	dec    ax
     51e:	c6 04 ae             	mov    BYTE PTR [si],0xae
     521:	5f                   	pop    di
     522:	d2 04                	rol    BYTE PTR [si],cl
     524:	35 62 fe             	xor    ax,0xfe62
     527:	04 1e                	add    al,0x1e
     529:	28 da                	sub    dl,bl
     52b:	04 07                	add    al,0x7
     52d:	54                   	push   sp
     52e:	42                   	inc    dx
     52f:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     534:	07                   	pop    es
     535:	00 2c                	add    BYTE PTR [si],ch
     537:	20 2b                	and    BYTE PTR [bp+di],ch
     539:	20 0e 0f 0c          	and    BYTE PTR ds:0xc0f,cl
     53d:	0f 03 02             	lsl    ax,WORD PTR [bp+si]
     540:	fb                   	sti
     541:	ff                   	(bad)
     542:	fe                   	(bad)
     543:	ff                   	(bad)
     544:	f8                   	clc
     545:	28 4a 05             	sub    BYTE PTR [bp+si+0x5],cl
     548:	29 29                	sub    WORD PTR [bx+di],bp
     54a:	4e                   	dec    si
     54b:	05 8c 2b             	add    ax,0x2b8c
     54e:	52                   	push   dx
     54f:	05 af 2b             	add    ax,0x2baf
     552:	56                   	push   si
     553:	05 d2 2b             	add    ax,0x2bd2
     556:	5a                   	pop    dx
     557:	05 f5 2b             	add    ax,0x2bf5
     55a:	5e                   	pop    si
     55b:	05 41 28             	add    ax,0x2841
     55e:	6b 05 07             	imul   ax,WORD PTR [di],0x7
     561:	07                   	pop    es
     562:	54                   	push   sp
     563:	42                   	inc    dx
     564:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     569:	ac                   	lods   al,BYTE PTR ds:[si]
     56a:	04 8b                	add    al,0x8b
     56c:	05 10 22             	add    ax,0x2210
     56f:	c6 05 2b             	mov    BYTE PTR [di],0x2b
     572:	00 07                	add    BYTE PTR [bx],al
     574:	42                   	inc    dx
     575:	75 74                	jne    0x5eb
     577:	74 6f                	je     0x5e8
     579:	6e                   	outs   dx,BYTE PTR ds:[si]
     57a:	73 13                	jae    0x58f
     57c:	00 07                	add    BYTE PTR [bx],al
     57e:	23 be 05 db          	and    di,WORD PTR [bp-0x24fb]
     582:	00 ff                	add    bh,bh
     584:	ff                   	call   (bad)
     585:	db 00                	fild   DWORD PTR [bx+si]
     587:	ff                   	(bad)
     588:	ff 8c 2c aa          	dec    WORD PTR [si-0x55d4]
     58c:	05 00 80             	add    ax,0x8000
     58f:	00 00                	add    BYTE PTR [bx+si],al
     591:	00 00                	add    BYTE PTR [bx+si],al
     593:	09 00                	or     WORD PTR [bx+si],ax
     595:	06                   	push   es
     596:	43                   	inc    bx
     597:	61                   	popa
     598:	6e                   	outs   dx,BYTE PTR ds:[si]
     599:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     59c:	66 01 a2 05 53       	add    DWORD PTR [bp+si+0x5305],esp
     5a1:	1d a6 05             	sbb    ax,0x5a6
     5a4:	8c 1d                	mov    WORD PTR [di],ds
     5a6:	e6 05                	out    0x5,al
     5a8:	d6                   	(bad)
     5a9:	2d ca 05             	sub    ax,0x5ca
     5ac:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     5b0:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     5b4:	07                   	pop    es
     5b5:	43                   	inc    bx
     5b6:	61                   	popa
     5b7:	70 74                	jo     0x62d
     5b9:	69 6f 6e 07 23       	imul   bp,WORD PTR [bx+0x6e],0x2307
     5be:	de 05                	fiadd  WORD PTR [di]
     5c0:	da 00                	fiadd  DWORD PTR [bx+si]
     5c2:	ff                   	(bad)
     5c3:	ff                   	(bad)
     5c4:	bc 6a 20             	mov    sp,0x206a
     5c7:	27                   	daa
     5c8:	8c 2c                	mov    WORD PTR [si],gs
     5ca:	02 06 00 80          	add    al,BYTE PTR ds:0x8000
     5ce:	00 00                	add    BYTE PTR [bx+si],al
     5d0:	00 00                	add    BYTE PTR [bx+si],al
     5d2:	0b 00                	or     ax,WORD PTR [bx+si]
     5d4:	07                   	pop    es
     5d5:	44                   	inc    sp
     5d6:	65 66 61             	gs popad
     5d9:	75 6c                	jne    0x647
     5db:	74 07                	je     0x5e4
     5dd:	23 58 06             	and    bx,WORD PTR [bx+si+0x6]
     5e0:	2a 00                	sub    al,BYTE PTR [bx+si]
     5e2:	ff                   	(bad)
     5e3:	ff                   	(bad)
     5e4:	b8 1c c5             	mov    ax,0xc51c
     5e7:	06                   	push   es
     5e8:	01 00                	add    WORD PTR [bx+si],ax
     5ea:	00 00                	add    BYTE PTR [bx+si],al
     5ec:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     5f0:	00 00                	add    BYTE PTR [bx+si],al
     5f2:	0e                   	push   cs
     5f3:	00 07                	add    BYTE PTR [bx],al
     5f5:	45                   	inc    bp
     5f6:	6e                   	outs   dx,BYTE PTR ds:[si]
     5f7:	61                   	popa
     5f8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5fb:	64 8f 08 31 08       	(bad)
     600:	55                   	push   bp
     601:	2c 06                	sub    al,0x6
     603:	06                   	push   es
     604:	18 2c                	sbb    BYTE PTR [si],ch
     606:	0a 06 8c 2c          	or     al,BYTE PTR ds:0x2c8c
     60a:	1c 06                	sbb    al,0x6
     60c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     610:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     614:	05 47 6c             	add    ax,0x6c47
     617:	79 70                	jns    0x689
     619:	68 22 04             	push   0x422
     61c:	20 06 1c 2e          	and    BYTE PTR ds:0x2e1c,al
     620:	24 06                	and    al,0x6
     622:	d0 2c                	shr    BYTE PTR [si],1
     624:	39 06 01 00          	cmp    WORD PTR ds:0x1,ax
     628:	00 00                	add    BYTE PTR [bx+si],al
     62a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     62e:	00 00                	add    BYTE PTR [bx+si],al
     630:	25 00 04             	and    ax,0x400
     633:	4b                   	dec    bx
     634:	69 6e 64 02 00       	imul   bp,WORD PTR [bp+0x64],0x2
     639:	41                   	inc    cx
     63a:	06                   	push   es
     63b:	ea 00 ff ff 9c       	jmp    0x9cff:0xff00
     640:	2e 60                	cs pusha
     642:	06                   	push   es
     643:	01 00                	add    WORD PTR [bx+si],ax
     645:	00 00                	add    BYTE PTR [bx+si],al
     647:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     64b:	00 00                	add    BYTE PTR [bx+si],al
     64d:	26 00 06 4c 61       	add    BYTE PTR es:0x614c,al
     652:	79 6f                	jns    0x6c3
     654:	75 74                	jne    0x6ca
     656:	d4 22                	aam    0x22
     658:	bd 06 ed             	mov    bp,0xed06
     65b:	00 ff                	add    bh,bh
     65d:	ff 4d 2f             	dec    WORD PTR [di+0x2f]
     660:	83 06 01 00 00       	add    WORD PTR ds:0x1,0x0
     665:	00 00                	add    BYTE PTR [bx+si],al
     667:	80 ff ff             	cmp    bh,0xff
     66a:	ff                   	(bad)
     66b:	ff 27                	jmp    WORD PTR [bx]
     66d:	00 06 4d 61          	add    BYTE PTR ds:0x614d,al
     671:	72 67                	jb     0x6da
     673:	69 6e 5a 04 81       	imul   bp,WORD PTR [bp+0x5a],0x8104
     678:	26 de 00             	fiadd  WORD PTR es:[bx+si]
     67b:	ff                   	(bad)
     67c:	ff                   	call   (bad)
     67d:	de 00                	fiadd  WORD PTR [bx+si]
     67f:	ff                   	(bad)
     680:	ff 8c 2c 9b          	dec    WORD PTR [si-0x64d4]
     684:	06                   	push   es
     685:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     689:	00 00                	add    BYTE PTR [bx+si],al
     68b:	10 00                	adc    BYTE PTR [bx+si],al
     68d:	0b 4d 6f             	or     cx,WORD PTR [di+0x6f]
     690:	64 61                	fs popa
     692:	6c                   	ins    BYTE PTR es:[di],dx
     693:	52                   	push   dx
     694:	65 73 75             	gs jae 0x70c
     697:	6c                   	ins    BYTE PTR es:[di],dx
     698:	74 86                	je     0x620
     69a:	00 9f 06 c1          	add    BYTE PTR [bx-0x3efa],bl
     69e:	2e a3 06 db          	mov    cs:0xdb06,ax
     6a2:	2e a7                	cmps   WORD PTR cs:[si],WORD PTR es:[di]
     6a4:	06                   	push   es
     6a5:	8c 2c                	mov    WORD PTR [si],gs
     6a7:	05 07 00             	add    ax,0x7
     6aa:	80 01 00             	add    BYTE PTR [bx+di],0x0
     6ad:	00 00                	add    BYTE PTR [bx+si],al
     6af:	28 00                	sub    BYTE PTR [bx+si],al
     6b1:	09 4e 75             	or     WORD PTR [bp+0x75],cx
     6b4:	6d                   	ins    WORD PTR es:[di],dx
     6b5:	47                   	inc    di
     6b6:	6c                   	ins    BYTE PTR es:[di],dx
     6b7:	79 70                	jns    0x729
     6b9:	68 73 07             	push   0x773
     6bc:	23 e4                	and    sp,sp
     6be:	06                   	push   es
     6bf:	49                   	dec    cx
     6c0:	00 ff                	add    bh,bh
     6c2:	ff a1 1e ec          	jmp    WORD PTR [bx+di-0x13e2]
     6c6:	06                   	push   es
     6c7:	01 00                	add    WORD PTR [bx+si],ax
     6c9:	00 00                	add    BYTE PTR [bx+si],al
     6cb:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6cf:	00 00                	add    BYTE PTR [bx+si],al
     6d1:	12 00                	adc    al,BYTE PTR [bx+si]
     6d3:	0e                   	push   cs
     6d4:	50                   	push   ax
     6d5:	61                   	popa
     6d6:	72 65                	jb     0x73d
     6d8:	6e                   	outs   dx,BYTE PTR ds:[si]
     6d9:	74 53                	je     0x72e
     6db:	68 6f 77             	push   0x776f
     6de:	48                   	dec    ax
     6df:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     6e4:	23 07                	and    ax,WORD PTR [bx]
     6e6:	48                   	dec    ax
     6e7:	00 ff                	add    bh,bh
     6e9:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     6ec:	f0 06                	lock push es
     6ee:	23 1e 43 07          	and    bx,WORD PTR ds:0x743
     6f2:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     6f6:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     6fa:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     6fd:	6f                   	outs   dx,WORD PTR ds:[si]
     6fe:	77 48                	ja     0x748
     700:	69 6e 74 50 00       	imul   bp,WORD PTR [bp+0x74],0x50
     705:	0d 07 e8             	or     ax,0xe807
     708:	00 ff                	add    bh,bh
     70a:	ff ab 2c 2b          	jmp    DWORD PTR [bp+di+0x2b2c]
     70e:	07                   	pop    es
     70f:	01 00                	add    WORD PTR [bx+si],ax
     711:	00 00                	add    BYTE PTR [bx+si],al
     713:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     717:	00 00                	add    BYTE PTR [bx+si],al
     719:	29 00                	sub    WORD PTR [bx+si],ax
     71b:	05 53 74             	add    ax,0x7453
     71e:	79 6c                	jns    0x78c
     720:	65 d4 22             	gs aam 0x22
     723:	64 07                	fs pop es
     725:	eb 00                	jmp    0x727
     727:	ff                   	(bad)
     728:	ff 28                	jmp    DWORD PTR [bx+si]
     72a:	2f                   	das
     72b:	19 0b                	sbb    WORD PTR [bp+di],cx
     72d:	01 00                	add    WORD PTR [bx+si],ax
     72f:	00 00                	add    BYTE PTR [bx+si],al
     731:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     735:	00 00                	add    BYTE PTR [bx+si],al
     737:	2a 00                	sub    al,BYTE PTR [bx+si]
     739:	07                   	pop    es
     73a:	53                   	push   bx
     73b:	70 61                	jo     0x79e
     73d:	63 69 6e             	arpl   WORD PTR [bx+di+0x6e],bp
     740:	67 52                	addr32 push dx
     742:	01 47 07             	add    WORD PTR [bx+0x7],ax
     745:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     746:	63 4b 07             	arpl   WORD PTR [bp+di+0x7],cx
     749:	60                   	pusha
     74a:	64 6c                	fs ins BYTE PTR es:[di],dx
     74c:	07                   	pop    es
     74d:	01 00                	add    WORD PTR [bx+si],ax
     74f:	00 00                	add    BYTE PTR [bx+si],al
     751:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     755:	ff                   	(bad)
     756:	ff 15                	call   WORD PTR [di]
     758:	00 08                	add    BYTE PTR [bx+si],cl
     75a:	54                   	push   sp
     75b:	61                   	popa
     75c:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     75f:	64 65 72 07          	fs gs jb 0x76a
     763:	23 84 07 a4          	and    ax,WORD PTR [si-0x5bf9]
     767:	00 ff                	add    bh,bh
     769:	ff 88 64 8c          	dec    WORD PTR [bx+si-0x739c]
     76d:	07                   	pop    es
     76e:	01 00                	add    WORD PTR [bx+si],ax
     770:	00 00                	add    BYTE PTR [bx+si],al
     772:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     776:	00 00                	add    BYTE PTR [bx+si],al
     778:	16                   	push   ss
     779:	00 07                	add    BYTE PTR [bx],al
     77b:	54                   	push   sp
     77c:	61                   	popa
     77d:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     780:	6f                   	outs   dx,WORD PTR ds:[si]
     781:	70 07                	jo     0x78a
     783:	23 10                	and    dx,WORD PTR [bx+si]
     785:	08 29                	or     BYTE PTR [bx+di],ch
     787:	00 ff                	add    bh,bh
     789:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     78c:	49                   	dec    cx
     78d:	1f                   	pop    ds
     78e:	01 00                	add    WORD PTR [bx+si],ax
     790:	00 00                	add    BYTE PTR [bx+si],al
     792:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     796:	00 00                	add    BYTE PTR [bx+si],al
     798:	17                   	pop    ss
     799:	00 07                	add    BYTE PTR [bx],al
     79b:	56                   	push   si
     79c:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     7a1:	65 71 00             	gs jno 0x7a4
     7a4:	c4 07                	les    ax,DWORD PTR [bx]
     7a6:	c8 00 ff ff          	enter  0xff00,0xff
     7aa:	c8 00 ff ff          	enter  0xff00,0xff
     7ae:	01 00                	add    WORD PTR [bx+si],ax
     7b0:	00 00                	add    BYTE PTR [bx+si],al
     7b2:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     7b6:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     7ba:	07                   	pop    es
     7bb:	4f                   	dec    di
     7bc:	6e                   	outs   dx,BYTE PTR ds:[si]
     7bd:	45                   	inc    bp
     7be:	6e                   	outs   dx,BYTE PTR ds:[si]
     7bf:	74 65                	je     0x826
     7c1:	72 71                	jb     0x834
     7c3:	00 f5                	add    ch,dh
     7c5:	09 d0                	or     ax,dx
     7c7:	00 ff                	add    bh,bh
     7c9:	ff d0                	call   ax
     7cb:	00 ff                	add    bh,bh
     7cd:	ff 01                	inc    WORD PTR [bx+di]
     7cf:	00 00                	add    BYTE PTR [bx+si],al
     7d1:	00 00                	add    BYTE PTR [bx+si],al
     7d3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7d6:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     7da:	06                   	push   es
     7db:	4f                   	dec    di
     7dc:	6e                   	outs   dx,BYTE PTR ds:[si]
     7dd:	45                   	inc    bp
     7de:	78 69                	js     0x849
     7e0:	74 c8                	je     0x7aa
     7e2:	1a 00                	sbb    al,BYTE PTR [bx+si]
     7e4:	00 80 7e 0c          	add    BYTE PTR [bx+si+0xc7e],al
     7e8:	00 75 07             	add    BYTE PTR [di+0x7],dh
     7eb:	80 3e 0c 2c 00       	cmp    BYTE PTR ds:0x2c0c,0x0
     7f0:	75 0a                	jne    0x7fc
     7f2:	80 7e 0c 02          	cmp    BYTE PTR [bp+0xc],0x2
     7f6:	74 04                	je     0x7fc
     7f8:	b0 00                	mov    al,0x0
     7fa:	eb 02                	jmp    0x7fe
     7fc:	b0 01                	mov    al,0x1
     7fe:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     801:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     804:	06                   	push   es
     805:	57                   	push   di
     806:	8d 7e f6             	lea    di,[bp-0xa]
     809:	16                   	push   ss
     80a:	57                   	push   di
     80b:	6a 08                	push   0x8
     80d:	9a 1b 16 3f 0a       	call   0xa3f:0x161b
     812:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     815:	89 7e f2             	mov    WORD PTR [bp-0xe],di
     818:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
     81b:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
     81f:	75 03                	jne    0x824
     821:	e9 a1 00             	jmp    0x8c5
     824:	6a ff                	push   0xffff
     826:	6a f0                	push   0xfff0
     828:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
     82c:	06                   	push   es
     82d:	57                   	push   di
     82e:	9a 84 16 41 08       	call   0x841:0x1684
     833:	6a 00                	push   0x0
     835:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     838:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
     83c:	06                   	push   es
     83d:	57                   	push   di
     83e:	9a 7c 17 50 08       	call   0x850:0x177c
     843:	8d 7e f6             	lea    di,[bp-0xa]
     846:	16                   	push   ss
     847:	57                   	push   di
     848:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     84b:	06                   	push   es
     84c:	57                   	push   di
     84d:	9a e5 1c d5 08       	call   0x8d5:0x1ce5
     852:	80 7e 08 00          	cmp    BYTE PTR [bp+0x8],0x0
     856:	74 36                	je     0x88e
     858:	ff 76 16             	push   WORD PTR [bp+0x16]
     85b:	ff 76 14             	push   WORD PTR [bp+0x14]
     85e:	8d 7e f6             	lea    di,[bp-0xa]
     861:	16                   	push   ss
     862:	57                   	push   di
     863:	6a ff                	push   0xffff
     865:	6a ef                	push   0xffef
     867:	6a ff                	push   0xffff
     869:	6a eb                	push   0xffeb
     86b:	6a 01                	push   0x1
     86d:	9a ea 18 8a 08       	call   0x88a:0x18ea
     872:	ff 76 16             	push   WORD PTR [bp+0x16]
     875:	ff 76 14             	push   WORD PTR [bp+0x14]
     878:	8d 7e f6             	lea    di,[bp-0xa]
     87b:	16                   	push   ss
     87c:	57                   	push   di
     87d:	6a ff                	push   0xffff
     87f:	6a f9                	push   0xfff9
     881:	6a ff                	push   0xffff
     883:	6a ef                	push   0xffef
     885:	6a 01                	push   0x1
     887:	9a ea 18 a6 08       	call   0x8a6:0x18ea
     88c:	eb 34                	jmp    0x8c2
     88e:	ff 76 16             	push   WORD PTR [bp+0x16]
     891:	ff 76 14             	push   WORD PTR [bp+0x14]
     894:	8d 7e f6             	lea    di,[bp-0xa]
     897:	16                   	push   ss
     898:	57                   	push   di
     899:	6a ff                	push   0xffff
     89b:	6a ef                	push   0xffef
     89d:	6a ff                	push   0xffff
     89f:	6a f9                	push   0xfff9
     8a1:	6a 01                	push   0x1
     8a3:	9a ea 18 c0 08       	call   0x8c0:0x18ea
     8a8:	ff 76 16             	push   WORD PTR [bp+0x16]
     8ab:	ff 76 14             	push   WORD PTR [bp+0x14]
     8ae:	8d 7e f6             	lea    di,[bp-0xa]
     8b1:	16                   	push   ss
     8b2:	57                   	push   di
     8b3:	6a ff                	push   0xffff
     8b5:	6a eb                	push   0xffeb
     8b7:	6a ff                	push   0xffff
     8b9:	6a ef                	push   0xffef
     8bb:	6a 01                	push   0x1
     8bd:	9a ea 18 d4 09       	call   0x9d4:0x18ea
     8c2:	e9 6b 01             	jmp    0xa30
     8c5:	6a ff                	push   0xffff
     8c7:	6a f9                	push   0xfff9
     8c9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     8cc:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
     8d0:	06                   	push   es
     8d1:	57                   	push   di
     8d2:	9a da 13 e7 08       	call   0x8e7:0x13da
     8d7:	6a ff                	push   0xffff
     8d9:	6a f0                	push   0xfff0
     8db:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     8de:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
     8e2:	06                   	push   es
     8e3:	57                   	push   di
     8e4:	9a 84 16 f7 08       	call   0x8f7:0x1684
     8e9:	6a 00                	push   0x0
     8eb:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     8ee:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
     8f2:	06                   	push   es
     8f3:	57                   	push   di
     8f4:	9a 7c 17 0d 09       	call   0x90d:0x177c
     8f9:	ff 76 f6             	push   WORD PTR [bp-0xa]
     8fc:	ff 76 f8             	push   WORD PTR [bp-0x8]
     8ff:	ff 76 fa             	push   WORD PTR [bp-0x6]
     902:	ff 76 fc             	push   WORD PTR [bp-0x4]
     905:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     908:	06                   	push   es
     909:	57                   	push   di
     90a:	9a 22 1e 27 09       	call   0x927:0x1e22
     90f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     913:	74 58                	je     0x96d
     915:	ff 76 f6             	push   WORD PTR [bp-0xa]
     918:	ff 76 f8             	push   WORD PTR [bp-0x8]
     91b:	6a ff                	push   0xffff
     91d:	6a f0                	push   0xfff0
     91f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     922:	06                   	push   es
     923:	57                   	push   di
     924:	9a 64 21 3d 09       	call   0x93d:0x2164
     929:	ff 76 f6             	push   WORD PTR [bp-0xa]
     92c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     92f:	48                   	dec    ax
     930:	50                   	push   ax
     931:	6a ff                	push   0xffff
     933:	6a f0                	push   0xfff0
     935:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     938:	06                   	push   es
     939:	57                   	push   di
     93a:	9a 64 21 53 09       	call   0x953:0x2164
     93f:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     942:	48                   	dec    ax
     943:	50                   	push   ax
     944:	ff 76 f8             	push   WORD PTR [bp-0x8]
     947:	6a ff                	push   0xffff
     949:	6a f0                	push   0xfff0
     94b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     94e:	06                   	push   es
     94f:	57                   	push   di
     950:	9a 64 21 6b 09       	call   0x96b:0x2164
     955:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     958:	48                   	dec    ax
     959:	50                   	push   ax
     95a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     95d:	48                   	dec    ax
     95e:	50                   	push   ax
     95f:	6a ff                	push   0xffff
     961:	6a f0                	push   0xfff0
     963:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     966:	06                   	push   es
     967:	57                   	push   di
     968:	9a 64 21 8f 09       	call   0x98f:0x2164
     96d:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     971:	74 34                	je     0x9a7
     973:	8d 7e f6             	lea    di,[bp-0xa]
     976:	16                   	push   ss
     977:	57                   	push   di
     978:	6a ff                	push   0xffff
     97a:	6a ff                	push   0xffff
     97c:	9a b1 09 00 00       	call   0x0:0x9b1
     981:	6a 01                	push   0x1
     983:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     986:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
     98a:	06                   	push   es
     98b:	57                   	push   di
     98c:	9a 7c 17 a5 09       	call   0x9a5:0x177c
     991:	ff 76 f6             	push   WORD PTR [bp-0xa]
     994:	ff 76 f8             	push   WORD PTR [bp-0x8]
     997:	ff 76 fa             	push   WORD PTR [bp-0x6]
     99a:	ff 76 fc             	push   WORD PTR [bp-0x4]
     99d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     9a0:	06                   	push   es
     9a1:	57                   	push   di
     9a2:	9a 22 1e e8 09       	call   0x9e8:0x1e22
     9a7:	8d 7e f6             	lea    di,[bp-0xa]
     9aa:	16                   	push   ss
     9ab:	57                   	push   di
     9ac:	6a ff                	push   0xffff
     9ae:	6a ff                	push   0xffff
     9b0:	9a 53 0a 00 00       	call   0x0:0xa53
     9b5:	80 7e 08 00          	cmp    BYTE PTR [bp+0x8],0x0
     9b9:	75 1d                	jne    0x9d8
     9bb:	ff 76 16             	push   WORD PTR [bp+0x16]
     9be:	ff 76 14             	push   WORD PTR [bp+0x14]
     9c1:	8d 7e f6             	lea    di,[bp-0xa]
     9c4:	16                   	push   ss
     9c5:	57                   	push   di
     9c6:	6a ff                	push   0xffff
     9c8:	6a eb                	push   0xffeb
     9ca:	6a ff                	push   0xffff
     9cc:	6a ef                	push   0xffef
     9ce:	ff 76 0e             	push   WORD PTR [bp+0xe]
     9d1:	9a ea 18 ff ff       	call   0xffff:0x18ea
     9d6:	eb 58                	jmp    0xa30
     9d8:	6a ff                	push   0xffff
     9da:	6a ef                	push   0xffef
     9dc:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     9df:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
     9e3:	06                   	push   es
     9e4:	57                   	push   di
     9e5:	9a da 13 2e 0a       	call   0xa2e:0x13da
     9ea:	ff 76 f6             	push   WORD PTR [bp-0xa]
     9ed:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     9f0:	48                   	dec    ax
     9f1:	50                   	push   ax
     9f2:	9a 6e 06 06 0a       	call   0xa06:0x66e
     9f7:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
     9fa:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
     9fd:	ff 76 f6             	push   WORD PTR [bp-0xa]
     a00:	ff 76 f8             	push   WORD PTR [bp-0x8]
     a03:	9a 6e 06 17 0a       	call   0xa17:0x66e
     a08:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     a0b:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
     a0e:	ff 76 fa             	push   WORD PTR [bp-0x6]
     a11:	ff 76 f8             	push   WORD PTR [bp-0x8]
     a14:	9a 6e 06 d4 0f       	call   0xfd4:0x66e
     a19:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
     a1c:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
     a1f:	8d 7e e6             	lea    di,[bp-0x1a]
     a22:	16                   	push   ss
     a23:	57                   	push   di
     a24:	6a 02                	push   0x2
     a26:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     a29:	06                   	push   es
     a2a:	57                   	push   di
     a2b:	9a e1 1d 8d 0a       	call   0xa8d:0x1de1
     a30:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     a33:	06                   	push   es
     a34:	57                   	push   di
     a35:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
     a38:	06                   	push   es
     a39:	57                   	push   di
     a3a:	6a 08                	push   0x8
     a3c:	9a 1b 16 15 0b       	call   0xb15:0x161b
     a41:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
     a44:	06                   	push   es
     a45:	57                   	push   di
     a46:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     a49:	f7 d8                	neg    ax
     a4b:	50                   	push   ax
     a4c:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     a4f:	f7 d8                	neg    ax
     a51:	50                   	push   ax
     a52:	9a 35 2b 00 00       	call   0x0:0x2b35
     a57:	80 7e 08 00          	cmp    BYTE PTR [bp+0x8],0x0
     a5b:	74 0e                	je     0xa6b
     a5d:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
     a60:	06                   	push   es
     a61:	57                   	push   di
     a62:	6a 01                	push   0x1
     a64:	6a 01                	push   0x1
     a66:	9a 9f 19 00 00       	call   0x0:0x199f
     a6b:	c9                   	leave
     a6c:	ca 12 00             	retf   0x12
     a6f:	c8 04 00 00          	enter  0x4,0x0
     a73:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     a76:	98                   	cbw
     a77:	8b f8                	mov    di,ax
     a79:	c1 e7 02             	shl    di,0x2
     a7c:	8b 85 e0 2a          	mov    ax,WORD PTR [di+0x2ae0]
     a80:	0b 85 e2 2a          	or     ax,WORD PTR [di+0x2ae2]
     a84:	75 54                	jne    0xada
     a86:	b0 01                	mov    al,0x1
     a88:	50                   	push   ax
     a89:	b8 3f 08             	mov    ax,0x83f
     a8c:	ba 94 0a             	mov    dx,0xa94
     a8f:	52                   	push   dx
     a90:	50                   	push   ax
     a91:	9a bd 56 d8 0a       	call   0xad8:0x56bd
     a96:	8b c8                	mov    cx,ax
     a98:	8b da                	mov    bx,dx
     a9a:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     a9d:	98                   	cbw
     a9e:	8b f8                	mov    di,ax
     aa0:	c1 e7 02             	shl    di,0x2
     aa3:	89 8d e0 2a          	mov    WORD PTR [di+0x2ae0],cx
     aa7:	89 9d e2 2a          	mov    WORD PTR [di+0x2ae2],bx
     aab:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     aaf:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     ab2:	98                   	cbw
     ab3:	8b f8                	mov    di,ax
     ab5:	c1 e7 02             	shl    di,0x2
     ab8:	ff b5 b2 0d          	push   WORD PTR [di+0xdb2]
     abc:	ff b5 b0 0d          	push   WORD PTR [di+0xdb0]
     ac0:	9a ff ff 00 00       	call   0x0:0xffff
     ac5:	50                   	push   ax
     ac6:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     ac9:	98                   	cbw
     aca:	8b f8                	mov    di,ax
     acc:	c1 e7 02             	shl    di,0x2
     acf:	c4 bd e0 2a          	les    di,DWORD PTR [di+0x2ae0]
     ad3:	06                   	push   es
     ad4:	57                   	push   di
     ad5:	9a 04 61 32 0b       	call   0xb32:0x6104
     ada:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     add:	98                   	cbw
     ade:	8b f8                	mov    di,ax
     ae0:	c1 e7 02             	shl    di,0x2
     ae3:	8b 85 e0 2a          	mov    ax,WORD PTR [di+0x2ae0]
     ae7:	8b 95 e2 2a          	mov    dx,WORD PTR [di+0x2ae2]
     aeb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     aee:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     af1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     af4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     af7:	c9                   	leave
     af8:	c2 02 00             	ret    0x2
	...
     b03:	1b 0b                	sbb    cx,WORD PTR [bp+di]
     b05:	0a 00                	or     al,BYTE PTR [bx+si]
     b07:	2c 1f                	sub    al,0x1f
     b09:	3e 0b 64 20          	or     sp,WORD PTR ds:[si+0x20]
     b0d:	09 0b                	or     WORD PTR [bp+di],cx
     b0f:	9a 1f 0d 0b cb       	call   0xcb0b:0xd1f
     b14:	1f                   	pop    ds
     b15:	11 0b                	adc    WORD PTR [bp+di],cx
     b17:	a8 0b                	test   al,0xb
     b19:	42                   	inc    dx
     b1a:	0b 08                	or     cx,WORD PTR [bx+si]
     b1c:	54                   	push   sp
     b1d:	42                   	inc    dx
     b1e:	69 74 50 6f 6f       	imul   si,WORD PTR [si+0x50],0x6f6f
     b23:	6c                   	ins    BYTE PTR es:[di],dx
	...
     b2c:	44                   	inc    sp
     b2d:	0b 20                	or     sp,WORD PTR [bx+si]
     b2f:	00 86 09 4e          	add    BYTE PTR [bp+0x4e09],al
     b33:	0e                   	push   cs
     b34:	64 20 69 0b          	and    BYTE PTR fs:[bx+di+0xb],ch
     b38:	9a 1f 36 0b cb       	call   0xcb0b:0x361f
     b3d:	1f                   	pop    ds
     b3e:	3a 0b                	cmp    cl,BYTE PTR [bp+di]
     b40:	82 0e 6d 0b 0a       	or     BYTE PTR ds:0xb6d,0xa
     b45:	54                   	push   sp
     b46:	47                   	inc    di
     b47:	6c                   	ins    BYTE PTR es:[di],dx
     b48:	79 70                	jns    0xbba
     b4a:	68 4c 69             	push   0x694c
     b4d:	73 74                	jae    0xbc3
	...
     b57:	6f                   	outs   dx,WORD PTR ds:[si]
     b58:	0b 08                	or     cx,WORD PTR [bx+si]
     b5a:	00 2c                	add    BYTE PTR [si],ch
     b5c:	1f                   	pop    ds
     b5d:	95                   	xchg   bp,ax
     b5e:	0b 64 20             	or     sp,WORD PTR [si+0x20]
     b61:	5d                   	pop    bp
     b62:	0b 9a 1f 61          	or     bx,WORD PTR [bp+si+0x611f]
     b66:	0b cb                	or     cx,bx
     b68:	1f                   	pop    ds
     b69:	65 0b ff             	gs or  di,di
     b6c:	0f 99 0b             	setns  BYTE PTR [bp+di]
     b6f:	0b 54 47             	or     dx,WORD PTR [si+0x47]
     b72:	6c                   	ins    BYTE PTR es:[di],dx
     b73:	79 70                	jns    0xbe5
     b75:	68 43 61             	push   0x6143
     b78:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
	...
     b83:	9b                   	fwait
     b84:	0b 21                	or     sp,WORD PTR [bx+di]
     b86:	00 2c                	add    BYTE PTR [si],ch
     b88:	1f                   	pop    ds
     b89:	c2 0b 64             	ret    0x640b
     b8c:	20 89 0b 9a          	and    BYTE PTR [bx+di-0x65f5],cl
     b90:	1f                   	pop    ds
     b91:	8d 0b                	lea    cx,[bp+di]
     b93:	cb                   	retf
     b94:	1f                   	pop    ds
     b95:	91                   	xchg   cx,ax
     b96:	0b cf                	or     cx,di
     b98:	11 b5 0b 0c          	adc    WORD PTR [di+0xc0b],si
     b9c:	54                   	push   sp
     b9d:	42                   	inc    dx
     b9e:	75 74                	jne    0xc14
     ba0:	74 6f                	je     0xc11
     ba2:	6e                   	outs   dx,BYTE PTR ds:[si]
     ba3:	47                   	inc    di
     ba4:	6c                   	ins    BYTE PTR es:[di],dx
     ba5:	79 70                	jns    0xc17
     ba7:	68 55 89             	push   0x8955
     baa:	e5 6a                	in     ax,0x6a
     bac:	00 c4                	add    ah,al
     bae:	7e 06                	jle    0xbb6
     bb0:	06                   	push   es
     bb1:	57                   	push   di
     bb2:	9a f2 0b 57 0e       	call   0xe57:0xbf2
     bb7:	31 c0                	xor    ax,ax
     bb9:	50                   	push   ax
     bba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bbd:	06                   	push   es
     bbe:	57                   	push   di
     bbf:	9a 66 1f cd 0b       	call   0xbcd:0x1f66
     bc4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     bc8:	74 05                	je     0xbcf
     bca:	9a 0f 20 49 0c       	call   0xc49:0x200f
     bcf:	c9                   	leave
     bd0:	ca 06 00             	retf   0x6
     bd3:	c8 02 00 00          	enter  0x2,0x0
     bd7:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     bda:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     bdd:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     be0:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     be3:	7e 06                	jle    0xbeb
     be5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     be8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     beb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     bee:	c9                   	leave
     bef:	c2 06 00             	ret    0x6
     bf2:	c8 08 00 00          	enter  0x8,0x0
     bf6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     bf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bfc:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
     c00:	75 03                	jne    0xc05
     c02:	e9 bf 00             	jmp    0xcc4
     c05:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     c08:	05 10 00             	add    ax,0x10
     c0b:	48                   	dec    ax
     c0c:	99                   	cwd
     c0d:	b9 10 00             	mov    cx,0x10
     c10:	f7 f9                	idiv   cx
     c12:	d1 e0                	shl    ax,1
     c14:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     c17:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     c1b:	05 10 00             	add    ax,0x10
     c1e:	48                   	dec    ax
     c1f:	99                   	cwd
     c20:	b9 10 00             	mov    cx,0x10
     c23:	f7 f9                	idiv   cx
     c25:	d1 e0                	shl    ax,1
     c27:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     c2a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     c2d:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     c30:	75 03                	jne    0xc35
     c32:	e9 85 00             	jmp    0xcba
     c35:	31 c0                	xor    ax,ax
     c37:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c3a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c3d:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     c41:	74 1f                	je     0xc62
     c43:	ff 76 fa             	push   WORD PTR [bp-0x6]
     c46:	9a 82 01 5e 0c       	call   0xc5e:0x182
     c4b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c4e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     c51:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     c54:	06                   	push   es
     c55:	57                   	push   di
     c56:	ff 76 fa             	push   WORD PTR [bp-0x6]
     c59:	6a 00                	push   0x0
     c5b:	9a e5 1e 94 0c       	call   0xc94:0x1ee5
     c60:	eb 08                	jmp    0xc6a
     c62:	31 c0                	xor    ax,ax
     c64:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c67:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c6a:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
     c6e:	74 39                	je     0xca9
     c70:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     c73:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
     c76:	74 1e                	je     0xc96
     c78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c7b:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     c7f:	06                   	push   es
     c80:	57                   	push   di
     c81:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     c84:	06                   	push   es
     c85:	57                   	push   di
     c86:	ff 76 f8             	push   WORD PTR [bp-0x8]
     c89:	ff 76 fa             	push   WORD PTR [bp-0x6]
     c8c:	55                   	push   bp
     c8d:	e8 43 ff             	call   0xbd3
     c90:	50                   	push   ax
     c91:	9a c1 1e a7 0c       	call   0xca7:0x1ec1
     c96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c99:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
     c9d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     ca1:	ff 76 f8             	push   WORD PTR [bp-0x8]
     ca4:	9a 9c 01 3b 0e       	call   0xe3b:0x19c
     ca9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     cac:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cb2:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
     cb6:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
     cba:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     cbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cc0:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     cc4:	c9                   	leave
     cc5:	ca 06 00             	retf   0x6
     cc8:	55                   	push   bp
     cc9:	89 e5                	mov    bp,sp
     ccb:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     ccf:	74 31                	je     0xd02
     cd1:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     cd4:	99                   	cwd
     cd5:	b9 10 00             	mov    cx,0x10
     cd8:	f7 f9                	idiv   cx
     cda:	92                   	xchg   dx,ax
     cdb:	8a c8                	mov    cl,al
     cdd:	80 f9 10             	cmp    cl,0x10
     ce0:	73 1e                	jae    0xd00
     ce2:	b8 01 00             	mov    ax,0x1
     ce5:	d3 c0                	rol    ax,cl
     ce7:	8b d8                	mov    bx,ax
     ce9:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     cec:	99                   	cwd
     ced:	b9 10 00             	mov    cx,0x10
     cf0:	f7 f9                	idiv   cx
     cf2:	d1 e0                	shl    ax,1
     cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cf7:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     cfb:	03 f8                	add    di,ax
     cfd:	26 09 1d             	or     WORD PTR es:[di],bx
     d00:	eb 2f                	jmp    0xd31
     d02:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     d05:	99                   	cwd
     d06:	b9 10 00             	mov    cx,0x10
     d09:	f7 f9                	idiv   cx
     d0b:	92                   	xchg   dx,ax
     d0c:	8a c8                	mov    cl,al
     d0e:	80 f9 10             	cmp    cl,0x10
     d11:	73 1e                	jae    0xd31
     d13:	b8 fe ff             	mov    ax,0xfffe
     d16:	d3 c0                	rol    ax,cl
     d18:	8b d8                	mov    bx,ax
     d1a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     d1d:	99                   	cwd
     d1e:	b9 10 00             	mov    cx,0x10
     d21:	f7 f9                	idiv   cx
     d23:	d1 e0                	shl    ax,1
     d25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d28:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     d2c:	03 f8                	add    di,ax
     d2e:	26 21 1d             	and    WORD PTR es:[di],bx
     d31:	c9                   	leave
     d32:	ca 08 00             	retf   0x8
     d35:	c8 02 00 00          	enter  0x2,0x0
     d39:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     d3c:	99                   	cwd
     d3d:	b9 10 00             	mov    cx,0x10
     d40:	f7 f9                	idiv   cx
     d42:	92                   	xchg   dx,ax
     d43:	8a c8                	mov    cl,al
     d45:	80 f9 10             	cmp    cl,0x10
     d48:	73 20                	jae    0xd6a
     d4a:	b8 01 00             	mov    ax,0x1
     d4d:	d3 c0                	rol    ax,cl
     d4f:	8b d8                	mov    bx,ax
     d51:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     d54:	99                   	cwd
     d55:	b9 10 00             	mov    cx,0x10
     d58:	f7 f9                	idiv   cx
     d5a:	d1 e0                	shl    ax,1
     d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d5f:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     d63:	03 f8                	add    di,ax
     d65:	26 85 1d             	test   WORD PTR es:[di],bx
     d68:	75 04                	jne    0xd6e
     d6a:	b0 00                	mov    al,0x0
     d6c:	eb 02                	jmp    0xd70
     d6e:	b0 01                	mov    al,0x1
     d70:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     d73:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     d76:	c9                   	leave
     d77:	ca 06 00             	retf   0x6
     d7a:	c8 0c 00 00          	enter  0xc,0x0
     d7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d81:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     d85:	05 10 00             	add    ax,0x10
     d88:	48                   	dec    ax
     d89:	99                   	cwd
     d8a:	b9 10 00             	mov    cx,0x10
     d8d:	f7 f9                	idiv   cx
     d8f:	48                   	dec    ax
     d90:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     d93:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     d96:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     d99:	31 c0                	xor    ax,ax
     d9b:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     d9e:	7e 03                	jle    0xda3
     da0:	e9 7d 00             	jmp    0xe20
     da3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     da6:	eb 03                	jmp    0xdab
     da8:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     dab:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     dae:	d1 e0                	shl    ax,1
     db0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     db3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     db7:	03 f8                	add    di,ax
     db9:	26 83 3d ff          	cmp    WORD PTR es:[di],0xffff
     dbd:	74 59                	je     0xe18
     dbf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     dc2:	d1 e0                	shl    ax,1
     dc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dc7:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     dcb:	03 f8                	add    di,ax
     dcd:	26 8b 05             	mov    ax,WORD PTR es:[di]
     dd0:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     dd3:	c6 46 f9 00          	mov    BYTE PTR [bp-0x7],0x0
     dd7:	eb 03                	jmp    0xddc
     dd9:	fe 46 f9             	inc    BYTE PTR [bp-0x7]
     ddc:	8a 4e f9             	mov    cl,BYTE PTR [bp-0x7]
     ddf:	80 f9 10             	cmp    cl,0x10
     de2:	73 0a                	jae    0xdee
     de4:	b8 01 00             	mov    ax,0x1
     de7:	d3 c0                	rol    ax,cl
     de9:	85 46 fa             	test   WORD PTR [bp-0x6],ax
     dec:	75 24                	jne    0xe12
     dee:	8a 46 f9             	mov    al,BYTE PTR [bp-0x7]
     df1:	98                   	cbw
     df2:	8b d0                	mov    dx,ax
     df4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     df7:	c1 e0 04             	shl    ax,0x4
     dfa:	03 c2                	add    ax,dx
     dfc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     dff:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e05:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
     e09:	7c 05                	jl     0xe10
     e0b:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
     e10:	eb 13                	jmp    0xe25
     e12:	80 7e f9 0f          	cmp    BYTE PTR [bp-0x7],0xf
     e16:	75 c1                	jne    0xdd9
     e18:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     e1b:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     e1e:	75 88                	jne    0xda8
     e20:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
     e25:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e28:	c9                   	leave
     e29:	ca 04 00             	retf   0x4
     e2c:	55                   	push   bp
     e2d:	89 e5                	mov    bp,sp
     e2f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     e33:	74 08                	je     0xe3d
     e35:	83 ec 08             	sub    sp,0x8
     e38:	9a e2 1f 5e 0e       	call   0xe5e:0x1fe2
     e3d:	ff 76 0e             	push   WORD PTR [bp+0xe]
     e40:	ff 76 0c             	push   WORD PTR [bp+0xc]
     e43:	31 c0                	xor    ax,ax
     e45:	50                   	push   ax
     e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e49:	06                   	push   es
     e4a:	57                   	push   di
     e4b:	9a 45 69 9e 0e       	call   0xe9e:0x6945
     e50:	b0 01                	mov    al,0x1
     e52:	50                   	push   ax
     e53:	b8 1b 0b             	mov    ax,0xb1b
     e56:	ba bf 0e             	mov    dx,0xebf
     e59:	52                   	push   dx
     e5a:	50                   	push   ax
     e5b:	9a 50 1f 91 0e       	call   0xe91:0x1f50
     e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e63:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
     e67:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
     e6b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     e6f:	74 07                	je     0xe78
     e71:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     e75:	83 c4 06             	add    sp,0x6
     e78:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     e7b:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     e7e:	c9                   	leave
     e7f:	ca 0a 00             	retf   0xa
     e82:	55                   	push   bp
     e83:	89 e5                	mov    bp,sp
     e85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e88:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     e8c:	06                   	push   es
     e8d:	57                   	push   di
     e8e:	9a 7f 1f a9 0e       	call   0xea9:0x1f7f
     e93:	31 c0                	xor    ax,ax
     e95:	50                   	push   ax
     e96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e99:	06                   	push   es
     e9a:	57                   	push   di
     e9b:	9a 01 6a da 0e       	call   0xeda:0x6a01
     ea0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     ea4:	74 05                	je     0xeab
     ea6:	9a 0f 20 be 0f       	call   0xfbe:0x200f
     eab:	c9                   	leave
     eac:	ca 06 00             	retf   0x6
     eaf:	c8 02 00 00          	enter  0x2,0x0
     eb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb6:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     eba:	06                   	push   es
     ebb:	57                   	push   di
     ebc:	9a 7a 0d f0 0e       	call   0xef0:0xd7a
     ec1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ec4:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
     ec8:	75 28                	jne    0xef2
     eca:	6a 00                	push   0x0
     ecc:	6a 00                	push   0x0
     ece:	6a 00                	push   0x0
     ed0:	6a 00                	push   0x0
     ed2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ed5:	06                   	push   es
     ed6:	57                   	push   di
     ed7:	9a 52 6b 34 0f       	call   0xf34:0x6b52
     edc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     edf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ee2:	40                   	inc    ax
     ee3:	50                   	push   ax
     ee4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ee7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     eeb:	06                   	push   es
     eec:	57                   	push   di
     eed:	9a f2 0b 03 0f       	call   0xf03:0xbf2
     ef2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ef5:	6a 01                	push   0x1
     ef7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     efa:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     efe:	06                   	push   es
     eff:	57                   	push   di
     f00:	9a c8 0c 18 0f       	call   0xf18:0xcc8
     f05:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f08:	c9                   	leave
     f09:	ca 04 00             	retf   0x4
     f0c:	c8 02 00 00          	enter  0x2,0x0
     f10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f13:	06                   	push   es
     f14:	57                   	push   di
     f15:	9a af 0e 50 0f       	call   0xf50:0xeaf
     f1a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     f1d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f20:	ff 76 10             	push   WORD PTR [bp+0x10]
     f23:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f26:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f29:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f2f:	06                   	push   es
     f30:	57                   	push   di
     f31:	9a e4 6b 6c 0f       	call   0xf6c:0x6be4
     f36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f39:	26 ff 45 1e          	inc    WORD PTR es:[di+0x1e]
     f3d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f40:	c9                   	leave
     f41:	ca 0c 00             	retf   0xc
     f44:	c8 02 00 00          	enter  0x2,0x0
     f48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f4b:	06                   	push   es
     f4c:	57                   	push   di
     f4d:	9a af 0e 8e 0f       	call   0xf8e:0xeaf
     f52:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     f55:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f58:	ff 76 10             	push   WORD PTR [bp+0x10]
     f5b:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f5e:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f61:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f67:	06                   	push   es
     f68:	57                   	push   di
     f69:	9a fa 6c 34 11       	call   0x1134:0x6cfa
     f6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f71:	26 ff 45 1e          	inc    WORD PTR es:[di+0x1e]
     f75:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f78:	c9                   	leave
     f79:	ca 0c 00             	retf   0xc
     f7c:	55                   	push   bp
     f7d:	89 e5                	mov    bp,sp
     f7f:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f85:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     f89:	06                   	push   es
     f8a:	57                   	push   di
     f8b:	9a 35 0d a9 0f       	call   0xfa9:0xd35
     f90:	08 c0                	or     al,al
     f92:	74 17                	je     0xfab
     f94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f97:	26 ff 4d 1e          	dec    WORD PTR es:[di+0x1e]
     f9b:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f9e:	6a 00                	push   0x0
     fa0:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     fa4:	06                   	push   es
     fa5:	57                   	push   di
     fa6:	9a c8 0c 89 10       	call   0x1089:0xcc8
     fab:	c9                   	leave
     fac:	ca 06 00             	retf   0x6
     faf:	55                   	push   bp
     fb0:	89 e5                	mov    bp,sp
     fb2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     fb6:	74 08                	je     0xfc0
     fb8:	83 ec 08             	sub    sp,0x8
     fbb:	9a e2 1f cb 0f       	call   0xfcb:0x1fe2
     fc0:	31 c0                	xor    ax,ax
     fc2:	50                   	push   ax
     fc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fc6:	06                   	push   es
     fc7:	57                   	push   di
     fc8:	9a 50 1f db 0f       	call   0xfdb:0x1f50
     fcd:	b0 01                	mov    al,0x1
     fcf:	50                   	push   ax
     fd0:	b8 a3 02             	mov    ax,0x2a3
     fd3:	ba 57 10             	mov    dx,0x1057
     fd6:	52                   	push   dx
     fd7:	50                   	push   ax
     fd8:	9a 50 1f 0e 10       	call   0x100e:0x1f50
     fdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe0:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     fe4:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     fe8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     fec:	74 07                	je     0xff5
     fee:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     ff2:	83 c4 06             	add    sp,0x6
     ff5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ff8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     ffb:	c9                   	leave
     ffc:	ca 06 00             	retf   0x6
     fff:	55                   	push   bp
    1000:	89 e5                	mov    bp,sp
    1002:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1005:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1009:	06                   	push   es
    100a:	57                   	push   di
    100b:	9a 7f 1f 1b 10       	call   0x101b:0x1f7f
    1010:	31 c0                	xor    ax,ax
    1012:	50                   	push   ax
    1013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1016:	06                   	push   es
    1017:	57                   	push   di
    1018:	9a 66 1f 26 10       	call   0x1026:0x1f66
    101d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1021:	74 05                	je     0x1028
    1023:	9a 0f 20 e9 10       	call   0x10e9:0x200f
    1028:	c9                   	leave
    1029:	ca 06 00             	retf   0x6
    102c:	c8 0a 00 00          	enter  0xa,0x0
    1030:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1033:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1037:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    103b:	48                   	dec    ax
    103c:	09 c0                	or     ax,ax
    103e:	7c 3c                	jl     0x107c
    1040:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1043:	eb 03                	jmp    0x1048
    1045:	ff 4e fa             	dec    WORD PTR [bp-0x6]
    1048:	ff 76 fa             	push   WORD PTR [bp-0x6]
    104b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    104e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1052:	06                   	push   es
    1053:	57                   	push   di
    1054:	9a d0 0d aa 10       	call   0x10aa:0xdd0
    1059:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    105c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    105f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1062:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1065:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    1069:	75 0b                	jne    0x1076
    106b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    106e:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    1072:	75 02                	jne    0x1076
    1074:	eb 36                	jmp    0x10ac
    1076:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    107a:	75 c9                	jne    0x1045
    107c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    107f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1082:	b0 01                	mov    al,0x1
    1084:	50                   	push   ax
    1085:	b8 44 0b             	mov    ax,0xb44
    1088:	ba 90 10             	mov    dx,0x1090
    108b:	52                   	push   dx
    108c:	50                   	push   ax
    108d:	9a 2c 0e 4e 11       	call   0x114e:0xe2c
    1092:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1095:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1098:	ff 76 fe             	push   WORD PTR [bp-0x2]
    109b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    109e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a1:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    10a5:	06                   	push   es
    10a6:	57                   	push   di
    10a7:	9a 2b 0c df 10       	call   0x10df:0xc2b
    10ac:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    10af:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    10b2:	c9                   	leave
    10b3:	ca 08 00             	retf   0x8
    10b6:	55                   	push   bp
    10b7:	89 e5                	mov    bp,sp
    10b9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10bc:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    10bf:	75 02                	jne    0x10c3
    10c1:	eb 28                	jmp    0x10eb
    10c3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    10c6:	26 83 7d 1e 00       	cmp    WORD PTR es:[di+0x1e],0x0
    10cb:	75 1e                	jne    0x10eb
    10cd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    10d0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10d6:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    10da:	06                   	push   es
    10db:	57                   	push   di
    10dc:	9a a7 0f e8 14       	call   0x14e8:0xfa7
    10e1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    10e4:	06                   	push   es
    10e5:	57                   	push   di
    10e6:	9a 7f 1f 1e 11       	call   0x111e:0x1f7f
    10eb:	c9                   	leave
    10ec:	ca 08 00             	retf   0x8
    10ef:	c8 02 00 00          	enter  0x2,0x0
    10f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10f6:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    10fa:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    10ff:	b0 00                	mov    al,0x0
    1101:	75 01                	jne    0x1104
    1103:	40                   	inc    ax
    1104:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1107:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    110a:	c9                   	leave
    110b:	ca 04 00             	retf   0x4
    110e:	c8 02 00 00          	enter  0x2,0x0
    1112:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1116:	74 08                	je     0x1120
    1118:	83 ec 08             	sub    sp,0x8
    111b:	9a e2 1f 2b 11       	call   0x112b:0x1fe2
    1120:	31 c0                	xor    ax,ax
    1122:	50                   	push   ax
    1123:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1126:	06                   	push   es
    1127:	57                   	push   di
    1128:	9a 50 1f de 11       	call   0x11de:0x1f50
    112d:	b0 01                	mov    al,0x1
    112f:	50                   	push   ax
    1130:	b8 3f 08             	mov    ax,0x83f
    1133:	ba 3b 11             	mov    dx,0x113b
    1136:	52                   	push   dx
    1137:	50                   	push   ax
    1138:	9a bd 56 ca 12       	call   0x12ca:0x56bd
    113d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1140:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1144:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1148:	06                   	push   es
    1149:	57                   	push   di
    114a:	b8 a9 12             	mov    ax,0x12a9
    114d:	ba a8 11             	mov    dx,0x11a8
    1150:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1154:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1158:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    115c:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    1160:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    1164:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1167:	26 c7 45 14 80 80    	mov    WORD PTR es:[di+0x14],0x8080
    116d:	26 c7 45 16 00 00    	mov    WORD PTR es:[di+0x16],0x0
    1173:	26 c6 45 18 01       	mov    BYTE PTR es:[di+0x18],0x1
    1178:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    117c:	eb 03                	jmp    0x1181
    117e:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    1181:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1184:	98                   	cbw
    1185:	d1 e0                	shl    ax,1
    1187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    118a:	03 f8                	add    di,ax
    118c:	26 c7 45 0c ff ff    	mov    WORD PTR es:[di+0xc],0xffff
    1192:	80 7e ff 03          	cmp    BYTE PTR [bp-0x1],0x3
    1196:	75 e6                	jne    0x117e
    1198:	a1 0c 2b             	mov    ax,ds:0x2b0c
    119b:	0b 06 0e 2b          	or     ax,WORD PTR ds:0x2b0e
    119f:	75 17                	jne    0x11b8
    11a1:	b0 01                	mov    al,0x1
    11a3:	50                   	push   ax
    11a4:	b8 6f 0b             	mov    ax,0xb6f
    11a7:	ba af 11             	mov    dx,0x11af
    11aa:	52                   	push   dx
    11ab:	50                   	push   ax
    11ac:	9a af 0f e8 11       	call   0x11e8:0xfaf
    11b1:	a3 0c 2b             	mov    ds:0x2b0c,ax
    11b4:	89 16 0e 2b          	mov    WORD PTR ds:0x2b0e,dx
    11b8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    11bc:	74 07                	je     0x11c5
    11be:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    11c2:	83 c4 06             	add    sp,0x6
    11c5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    11c8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    11cb:	c9                   	leave
    11cc:	ca 06 00             	retf   0x6
    11cf:	55                   	push   bp
    11d0:	89 e5                	mov    bp,sp
    11d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11d5:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    11d9:	06                   	push   es
    11da:	57                   	push   di
    11db:	9a 7f 1f 09 12       	call   0x1209:0x1f7f
    11e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e3:	06                   	push   es
    11e4:	57                   	push   di
    11e5:	9a 2f 12 fa 11       	call   0x11fa:0x122f
    11ea:	a1 0e 2b             	mov    ax,ds:0x2b0e
    11ed:	09 c0                	or     ax,ax
    11ef:	74 22                	je     0x1213
    11f1:	c4 3e 0c 2b          	les    di,DWORD PTR ds:0x2b0c
    11f5:	06                   	push   es
    11f6:	57                   	push   di
    11f7:	9a ef 10 69 12       	call   0x1269:0x10ef
    11fc:	08 c0                	or     al,al
    11fe:	74 13                	je     0x1213
    1200:	c4 3e 0c 2b          	les    di,DWORD PTR ds:0x2b0c
    1204:	06                   	push   es
    1205:	57                   	push   di
    1206:	9a 7f 1f 1e 12       	call   0x121e:0x1f7f
    120b:	31 c0                	xor    ax,ax
    120d:	a3 0c 2b             	mov    ds:0x2b0c,ax
    1210:	a3 0e 2b             	mov    ds:0x2b0e,ax
    1213:	31 c0                	xor    ax,ax
    1215:	50                   	push   ax
    1216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1219:	06                   	push   es
    121a:	57                   	push   di
    121b:	9a 66 1f 29 12       	call   0x1229:0x1f66
    1220:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1224:	74 05                	je     0x122b
    1226:	9a 0f 20 f4 14       	call   0x14f4:0x200f
    122b:	c9                   	leave
    122c:	ca 06 00             	retf   0x6
    122f:	c8 02 00 00          	enter  0x2,0x0
    1233:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1237:	eb 03                	jmp    0x123c
    1239:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    123c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    123f:	98                   	cbw
    1240:	d1 e0                	shl    ax,1
    1242:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1245:	03 f8                	add    di,ax
    1247:	26 83 7d 0c ff       	cmp    WORD PTR es:[di+0xc],0xffff
    124c:	74 1d                	je     0x126b
    124e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1251:	98                   	cbw
    1252:	d1 e0                	shl    ax,1
    1254:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1257:	03 f8                	add    di,ax
    1259:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    125d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1260:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1264:	06                   	push   es
    1265:	57                   	push   di
    1266:	9a 7c 0f 96 12       	call   0x1296:0xf7c
    126b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    126e:	98                   	cbw
    126f:	d1 e0                	shl    ax,1
    1271:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1274:	03 f8                	add    di,ax
    1276:	26 c7 45 0c ff ff    	mov    WORD PTR es:[di+0xc],0xffff
    127c:	80 7e ff 03          	cmp    BYTE PTR [bp-0x1],0x3
    1280:	75 b7                	jne    0x1239
    1282:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1285:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1289:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    128d:	c4 3e 0c 2b          	les    di,DWORD PTR ds:0x2b0c
    1291:	06                   	push   es
    1292:	57                   	push   di
    1293:	9a b6 10 dc 12       	call   0x12dc:0x10b6
    1298:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    129b:	31 c0                	xor    ax,ax
    129d:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    12a1:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    12a5:	c9                   	leave
    12a6:	ca 04 00             	retf   0x4
    12a9:	55                   	push   bp
    12aa:	89 e5                	mov    bp,sp
    12ac:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    12af:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    12b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b5:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
    12b9:	75 40                	jne    0x12fb
    12bb:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    12bf:	75 3a                	jne    0x12fb
    12c1:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    12c5:	06                   	push   es
    12c6:	57                   	push   di
    12c7:	9a 26 5b 46 13       	call   0x1346:0x5b26
    12cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12cf:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    12d3:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    12d7:	06                   	push   es
    12d8:	57                   	push   di
    12d9:	9a 2f 12 0b 13       	call   0x130b:0x122f
    12de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e1:	26 8b 45 1b          	mov    ax,WORD PTR es:[di+0x1b]
    12e5:	09 c0                	or     ax,ax
    12e7:	74 12                	je     0x12fb
    12e9:	ff 76 08             	push   WORD PTR [bp+0x8]
    12ec:	ff 76 06             	push   WORD PTR [bp+0x6]
    12ef:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    12f3:	26 ff 75 1d          	push   WORD PTR es:[di+0x1d]
    12f7:	26 ff 5d 19          	call   DWORD PTR es:[di+0x19]
    12fb:	c9                   	leave
    12fc:	ca 08 00             	retf   0x8
    12ff:	c8 02 00 00          	enter  0x2,0x0
    1303:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1306:	06                   	push   es
    1307:	57                   	push   di
    1308:	9a 2f 12 ac 13       	call   0x13ac:0x122f
    130d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1310:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1313:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1316:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    131a:	06                   	push   es
    131b:	57                   	push   di
    131c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    131f:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1323:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1326:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1329:	75 03                	jne    0x132e
    132b:	e9 80 00             	jmp    0x13ae
    132e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1331:	06                   	push   es
    1332:	57                   	push   di
    1333:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1336:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    133a:	09 c0                	or     ax,ax
    133c:	7e 70                	jle    0x13ae
    133e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1341:	06                   	push   es
    1342:	57                   	push   di
    1343:	9a 26 5b 9b 14       	call   0x149b:0x5b26
    1348:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    134b:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    134f:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    1353:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1356:	06                   	push   es
    1357:	57                   	push   di
    1358:	26 c4 3d             	les    di,DWORD PTR es:[di]
    135b:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    135f:	50                   	push   ax
    1360:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1363:	06                   	push   es
    1364:	57                   	push   di
    1365:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1368:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    136c:	59                   	pop    cx
    136d:	99                   	cwd
    136e:	f7 f9                	idiv   cx
    1370:	92                   	xchg   dx,ax
    1371:	09 c0                	or     ax,ax
    1373:	75 39                	jne    0x13ae
    1375:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1378:	06                   	push   es
    1379:	57                   	push   di
    137a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    137d:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1381:	50                   	push   ax
    1382:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1385:	06                   	push   es
    1386:	57                   	push   di
    1387:	26 c4 3d             	les    di,DWORD PTR es:[di]
    138a:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    138e:	59                   	pop    cx
    138f:	99                   	cwd
    1390:	f7 f9                	idiv   cx
    1392:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1395:	83 7e fe 04          	cmp    WORD PTR [bp-0x2],0x4
    1399:	7e 05                	jle    0x13a0
    139b:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    13a0:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    13a3:	50                   	push   ax
    13a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13a7:	06                   	push   es
    13a8:	57                   	push   di
    13a9:	9a b2 13 cc 13       	call   0x13cc:0x13b2
    13ae:	c9                   	leave
    13af:	ca 08 00             	retf   0x8
    13b2:	55                   	push   bp
    13b3:	89 e5                	mov    bp,sp
    13b5:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    13b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13bb:	26 3a 45 18          	cmp    al,BYTE PTR es:[di+0x18]
    13bf:	74 17                	je     0x13d8
    13c1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    13c5:	7e 11                	jle    0x13d8
    13c7:	06                   	push   es
    13c8:	57                   	push   di
    13c9:	9a 2f 12 e0 13       	call   0x13e0:0x122f
    13ce:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    13d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d4:	26 88 45 18          	mov    BYTE PTR es:[di+0x18],al
    13d8:	c9                   	leave
    13d9:	ca 06 00             	retf   0x6
    13dc:	00 00                	add    BYTE PTR [bx+si],al
    13de:	91                   	xchg   cx,ax
    13df:	18 e6                	sbb    dh,ah
    13e1:	13 00                	adc    ax,WORD PTR [bx+si]
    13e3:	00 a8 18 68          	add    BYTE PTR [bx+si+0x6818],ch
    13e7:	14 c8                	adc    al,0xc8
    13e9:	28 00                	sub    BYTE PTR [bx+si],al
    13eb:	00 80 7e 0a          	add    BYTE PTR [bx+si+0xa7e],al
    13ef:	02 75 0e             	add    dh,BYTE PTR [di+0xe]
    13f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13f5:	26 80 7d 18 03       	cmp    BYTE PTR es:[di+0x18],0x3
    13fa:	7d 04                	jge    0x1400
    13fc:	c6 46 0a 00          	mov    BYTE PTR [bp+0xa],0x0
    1400:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1403:	98                   	cbw
    1404:	d1 e0                	shl    ax,1
    1406:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1409:	03 f8                	add    di,ax
    140b:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    140f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1412:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    1416:	74 03                	je     0x141b
    1418:	e9 b8 04             	jmp    0x18d3
    141b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141e:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    1422:	98                   	cbw
    1423:	50                   	push   ax
    1424:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1428:	06                   	push   es
    1429:	57                   	push   di
    142a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    142d:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1431:	59                   	pop    cx
    1432:	99                   	cwd
    1433:	f7 f9                	idiv   cx
    1435:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    143b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    143f:	06                   	push   es
    1440:	57                   	push   di
    1441:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1444:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1448:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    144b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    144e:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1452:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    1456:	75 3c                	jne    0x1494
    1458:	a1 0c 2b             	mov    ax,ds:0x2b0c
    145b:	0b 06 0e 2b          	or     ax,WORD PTR ds:0x2b0e
    145f:	75 17                	jne    0x1478
    1461:	b0 01                	mov    al,0x1
    1463:	50                   	push   ax
    1464:	b8 6f 0b             	mov    ax,0xb6f
    1467:	ba 6f 14             	mov    dx,0x146f
    146a:	52                   	push   dx
    146b:	50                   	push   ax
    146c:	9a af 0f 87 14       	call   0x1487:0xfaf
    1471:	a3 0c 2b             	mov    ds:0x2b0c,ax
    1474:	89 16 0e 2b          	mov    WORD PTR ds:0x2b0e,dx
    1478:	ff 76 f4             	push   WORD PTR [bp-0xc]
    147b:	ff 76 f2             	push   WORD PTR [bp-0xe]
    147e:	c4 3e 0c 2b          	les    di,DWORD PTR ds:0x2b0c
    1482:	06                   	push   es
    1483:	57                   	push   di
    1484:	9a 2c 10 ab 15       	call   0x15ab:0x102c
    1489:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    148c:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1490:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    1494:	b0 01                	mov    al,0x1
    1496:	50                   	push   ax
    1497:	b8 3f 08             	mov    ax,0x83f
    149a:	ba a2 14             	mov    dx,0x14a2
    149d:	52                   	push   dx
    149e:	50                   	push   ax
    149f:	9a bd 56 02 15       	call   0x1502:0x56bd
    14a4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    14a7:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    14aa:	b8 e2 13             	mov    ax,0x13e2
    14ad:	0e                   	push   cs
    14ae:	50                   	push   ax
    14af:	55                   	push   bp
    14b0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    14b4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    14b8:	ff 76 f4             	push   WORD PTR [bp-0xc]
    14bb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    14be:	06                   	push   es
    14bf:	57                   	push   di
    14c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14c3:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    14c7:	ff 76 f2             	push   WORD PTR [bp-0xe]
    14ca:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    14cd:	06                   	push   es
    14ce:	57                   	push   di
    14cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14d2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    14d6:	8d 7e d8             	lea    di,[bp-0x28]
    14d9:	16                   	push   ss
    14da:	57                   	push   di
    14db:	6a 00                	push   0x0
    14dd:	6a 00                	push   0x0
    14df:	ff 76 f4             	push   WORD PTR [bp-0xc]
    14e2:	ff 76 f2             	push   WORD PTR [bp-0xe]
    14e5:	9a 88 06 47 15       	call   0x1547:0x688
    14ea:	8d 7e ea             	lea    di,[bp-0x16]
    14ed:	16                   	push   ss
    14ee:	57                   	push   di
    14ef:	6a 08                	push   0x8
    14f1:	9a 1b 16 53 15       	call   0x1553:0x161b
    14f6:	6a ff                	push   0xffff
    14f8:	6a f0                	push   0xfff0
    14fa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    14fd:	06                   	push   es
    14fe:	57                   	push   di
    14ff:	9a 0f 5a 11 15       	call   0x1511:0x5a0f
    1504:	89 c7                	mov    di,ax
    1506:	8e c2                	mov    es,dx
    1508:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    150c:	06                   	push   es
    150d:	57                   	push   di
    150e:	9a 84 16 88 15       	call   0x1588:0x1684
    1513:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1516:	88 46 e1             	mov    BYTE PTR [bp-0x1f],al
    1519:	8a 46 e1             	mov    al,BYTE PTR [bp-0x1f]
    151c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    151f:	26 3a 45 18          	cmp    al,BYTE PTR es:[di+0x18]
    1523:	7c 04                	jl     0x1529
    1525:	c6 46 e1 00          	mov    BYTE PTR [bp-0x1f],0x0
    1529:	8d 7e d8             	lea    di,[bp-0x28]
    152c:	16                   	push   ss
    152d:	57                   	push   di
    152e:	8a 46 e1             	mov    al,BYTE PTR [bp-0x1f]
    1531:	98                   	cbw
    1532:	f7 66 f4             	mul    WORD PTR [bp-0xc]
    1535:	50                   	push   ax
    1536:	6a 00                	push   0x0
    1538:	8a 46 e1             	mov    al,BYTE PTR [bp-0x1f]
    153b:	98                   	cbw
    153c:	40                   	inc    ax
    153d:	f7 66 f4             	mul    WORD PTR [bp-0xc]
    1540:	50                   	push   ax
    1541:	ff 76 f2             	push   WORD PTR [bp-0xe]
    1544:	9a 88 06 68 1a       	call   0x1a68:0x688
    1549:	8d 7e e2             	lea    di,[bp-0x1e]
    154c:	16                   	push   ss
    154d:	57                   	push   di
    154e:	6a 08                	push   0x8
    1550:	9a 1b 16 99 18       	call   0x1899:0x161b
    1555:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1558:	3c 00                	cmp    al,0x0
    155a:	74 04                	je     0x1560
    155c:	3c 02                	cmp    al,0x2
    155e:	75 61                	jne    0x15c1
    1560:	8d 7e ea             	lea    di,[bp-0x16]
    1563:	16                   	push   ss
    1564:	57                   	push   di
    1565:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1568:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    156c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1570:	8d 7e e2             	lea    di,[bp-0x1e]
    1573:	16                   	push   ss
    1574:	57                   	push   di
    1575:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1578:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    157c:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    1580:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1583:	06                   	push   es
    1584:	57                   	push   di
    1585:	9a 0f 5a 93 15       	call   0x1593:0x5a0f
    158a:	89 c7                	mov    di,ax
    158c:	8e c2                	mov    es,dx
    158e:	06                   	push   es
    158f:	57                   	push   di
    1590:	9a 23 19 d6 15       	call   0x15d6:0x1923
    1595:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1598:	ff 76 fa             	push   WORD PTR [bp-0x6]
    159b:	6a 00                	push   0x0
    159d:	6a 00                	push   0x0
    159f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15a2:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    15a6:	06                   	push   es
    15a7:	57                   	push   di
    15a8:	9a 0c 0f 0e 16       	call   0x160e:0xf0c
    15ad:	8b d0                	mov    dx,ax
    15af:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    15b2:	98                   	cbw
    15b3:	d1 e0                	shl    ax,1
    15b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15b8:	03 f8                	add    di,ax
    15ba:	26 89 55 0c          	mov    WORD PTR es:[di+0xc],dx
    15be:	e9 db 02             	jmp    0x189c
    15c1:	3c 03                	cmp    al,0x3
    15c3:	75 5f                	jne    0x1624
    15c5:	8d 7e ea             	lea    di,[bp-0x16]
    15c8:	16                   	push   ss
    15c9:	57                   	push   di
    15ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15cd:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    15d1:	06                   	push   es
    15d2:	57                   	push   di
    15d3:	9a 0f 5a e7 15       	call   0x15e7:0x5a0f
    15d8:	52                   	push   dx
    15d9:	50                   	push   ax
    15da:	8d 7e e2             	lea    di,[bp-0x1e]
    15dd:	16                   	push   ss
    15de:	57                   	push   di
    15df:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    15e2:	06                   	push   es
    15e3:	57                   	push   di
    15e4:	9a 0f 5a f2 15       	call   0x15f2:0x5a0f
    15e9:	89 c7                	mov    di,ax
    15eb:	8e c2                	mov    es,dx
    15ed:	06                   	push   es
    15ee:	57                   	push   di
    15ef:	9a 10 1b 5d 16       	call   0x165d:0x1b10
    15f4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    15f7:	ff 76 fa             	push   WORD PTR [bp-0x6]
    15fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15fd:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    1601:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    1605:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1609:	06                   	push   es
    160a:	57                   	push   di
    160b:	9a 44 0f 80 16       	call   0x1680:0xf44
    1610:	8b d0                	mov    dx,ax
    1612:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1615:	98                   	cbw
    1616:	d1 e0                	shl    ax,1
    1618:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    161b:	03 f8                	add    di,ax
    161d:	26 89 55 0c          	mov    WORD PTR es:[di+0xc],dx
    1621:	e9 78 02             	jmp    0x189c
    1624:	3c 01                	cmp    al,0x1
    1626:	74 03                	je     0x162b
    1628:	e9 71 02             	jmp    0x189c
    162b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    162e:	26 80 7d 18 01       	cmp    BYTE PTR es:[di+0x18],0x1
    1633:	7e 61                	jle    0x1696
    1635:	8d 7e ea             	lea    di,[bp-0x16]
    1638:	16                   	push   ss
    1639:	57                   	push   di
    163a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    163d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1641:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1645:	8d 7e e2             	lea    di,[bp-0x1e]
    1648:	16                   	push   ss
    1649:	57                   	push   di
    164a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    164d:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    1651:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    1655:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1658:	06                   	push   es
    1659:	57                   	push   di
    165a:	9a 0f 5a 68 16       	call   0x1668:0x5a0f
    165f:	89 c7                	mov    di,ax
    1661:	8e c2                	mov    es,dx
    1663:	06                   	push   es
    1664:	57                   	push   di
    1665:	9a 23 19 9d 16       	call   0x169d:0x1923
    166a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    166d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1670:	6a 00                	push   0x0
    1672:	6a 00                	push   0x0
    1674:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1677:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    167b:	06                   	push   es
    167c:	57                   	push   di
    167d:	9a 0c 0f 72 18       	call   0x1872:0xf0c
    1682:	8b d0                	mov    dx,ax
    1684:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1687:	98                   	cbw
    1688:	d1 e0                	shl    ax,1
    168a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    168d:	03 f8                	add    di,ax
    168f:	26 89 55 0c          	mov    WORD PTR es:[di+0xc],dx
    1693:	e9 06 02             	jmp    0x189c
    1696:	b0 01                	mov    al,0x1
    1698:	50                   	push   ax
    1699:	b8 3f 08             	mov    ax,0x83f
    169c:	ba a4 16             	mov    dx,0x16a4
    169f:	52                   	push   dx
    16a0:	50                   	push   ax
    16a1:	9a bd 56 e6 16       	call   0x16e6:0x56bd
    16a6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    16a9:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    16ac:	b8 dc 13             	mov    ax,0x13dc
    16af:	0e                   	push   cs
    16b0:	50                   	push   ax
    16b1:	55                   	push   bp
    16b2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    16b6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    16ba:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    16bd:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    16c0:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    16c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c6:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    16ca:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    16ce:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    16d1:	06                   	push   es
    16d2:	57                   	push   di
    16d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16d6:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    16da:	6a 00                	push   0x0
    16dc:	6a 00                	push   0x0
    16de:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    16e1:	06                   	push   es
    16e2:	57                   	push   di
    16e3:	9a 0f 5a f5 16       	call   0x16f5:0x5a0f
    16e8:	89 c7                	mov    di,ax
    16ea:	8e c2                	mov    es,dx
    16ec:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    16f0:	06                   	push   es
    16f1:	57                   	push   di
    16f2:	9a 84 16 0e 17       	call   0x170e:0x1684
    16f7:	ff 76 f4             	push   WORD PTR [bp-0xc]
    16fa:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    16fd:	06                   	push   es
    16fe:	57                   	push   di
    16ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1702:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1706:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1709:	06                   	push   es
    170a:	57                   	push   di
    170b:	9a f4 5a 21 17       	call   0x1721:0x5af4
    1710:	08 c0                	or     al,al
    1712:	74 48                	je     0x175c
    1714:	68 ff 00             	push   0xff
    1717:	6a ff                	push   0xffff
    1719:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    171c:	06                   	push   es
    171d:	57                   	push   di
    171e:	9a 0f 5a 30 17       	call   0x1730:0x5a0f
    1723:	89 c7                	mov    di,ax
    1725:	8e c2                	mov    es,dx
    1727:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    172b:	06                   	push   es
    172c:	57                   	push   di
    172d:	9a df 0f 3c 17       	call   0x173c:0xfdf
    1732:	6a 00                	push   0x0
    1734:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1737:	06                   	push   es
    1738:	57                   	push   di
    1739:	9a 26 62 4b 17       	call   0x174b:0x6226
    173e:	68 ff 00             	push   0xff
    1741:	6a ff                	push   0xffff
    1743:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1746:	06                   	push   es
    1747:	57                   	push   di
    1748:	9a 0f 5a 5a 17       	call   0x175a:0x5a0f
    174d:	89 c7                	mov    di,ax
    174f:	8e c2                	mov    es,dx
    1751:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1755:	06                   	push   es
    1756:	57                   	push   di
    1757:	9a 84 16 66 17       	call   0x1766:0x1684
    175c:	6a 01                	push   0x1
    175e:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1761:	06                   	push   es
    1762:	57                   	push   di
    1763:	9a 26 62 70 17       	call   0x1770:0x6226
    1768:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    176b:	06                   	push   es
    176c:	57                   	push   di
    176d:	9a 0f 5a 89 17       	call   0x1789:0x5a0f
    1772:	89 c7                	mov    di,ax
    1774:	8e c2                	mov    es,dx
    1776:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    1779:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    177c:	6a ff                	push   0xffff
    177e:	6a f0                	push   0xfff0
    1780:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1784:	06                   	push   es
    1785:	57                   	push   di
    1786:	9a 84 16 98 17       	call   0x1798:0x1684
    178b:	8d 7e ea             	lea    di,[bp-0x16]
    178e:	16                   	push   ss
    178f:	57                   	push   di
    1790:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1793:	06                   	push   es
    1794:	57                   	push   di
    1795:	9a e5 1c aa 17       	call   0x17aa:0x1ce5
    179a:	6a 00                	push   0x0
    179c:	6a 00                	push   0x0
    179e:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    17a1:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    17a5:	06                   	push   es
    17a6:	57                   	push   di
    17a7:	9a 84 16 bd 17       	call   0x17bd:0x1684
    17ac:	68 ff 00             	push   0xff
    17af:	6a ff                	push   0xffff
    17b1:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    17b4:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    17b8:	06                   	push   es
    17b9:	57                   	push   di
    17ba:	9a df 0f e3 17       	call   0x17e3:0xfdf
    17bf:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    17c2:	26 c7 45 17 26 02    	mov    WORD PTR es:[di+0x17],0x226
    17c8:	26 c7 45 19 bb 00    	mov    WORD PTR es:[di+0x19],0xbb
    17ce:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    17d1:	40                   	inc    ax
    17d2:	50                   	push   ax
    17d3:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    17d6:	40                   	inc    ax
    17d7:	50                   	push   ax
    17d8:	ff 76 f8             	push   WORD PTR [bp-0x8]
    17db:	ff 76 f6             	push   WORD PTR [bp-0xa]
    17de:	06                   	push   es
    17df:	57                   	push   di
    17e0:	9a 9b 1b 05 18       	call   0x1805:0x1b9b
    17e5:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    17e8:	26 c7 45 17 c6 00    	mov    WORD PTR es:[di+0x17],0xc6
    17ee:	26 c7 45 19 88 00    	mov    WORD PTR es:[di+0x19],0x88
    17f4:	ff 76 ea             	push   WORD PTR [bp-0x16]
    17f7:	ff 76 ec             	push   WORD PTR [bp-0x14]
    17fa:	ff 76 f8             	push   WORD PTR [bp-0x8]
    17fd:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1800:	06                   	push   es
    1801:	57                   	push   di
    1802:	9a 9b 1b 17 18       	call   0x1817:0x1b9b
    1807:	6a ff                	push   0xffff
    1809:	6a ef                	push   0xffef
    180b:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    180e:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1812:	06                   	push   es
    1813:	57                   	push   di
    1814:	9a 84 16 29 18       	call   0x1829:0x1684
    1819:	6a 00                	push   0x0
    181b:	6a 00                	push   0x0
    181d:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1820:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1824:	06                   	push   es
    1825:	57                   	push   di
    1826:	9a df 0f 4b 18       	call   0x184b:0xfdf
    182b:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    182e:	26 c7 45 17 86 00    	mov    WORD PTR es:[di+0x17],0x86
    1834:	26 c7 45 19 ee 00    	mov    WORD PTR es:[di+0x19],0xee
    183a:	ff 76 ea             	push   WORD PTR [bp-0x16]
    183d:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1840:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1843:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1846:	06                   	push   es
    1847:	57                   	push   di
    1848:	9a 9b 1b d1 18       	call   0x18d1:0x1b9b
    184d:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    1850:	26 c7 45 17 20 00    	mov    WORD PTR es:[di+0x17],0x20
    1856:	26 c7 45 19 cc 00    	mov    WORD PTR es:[di+0x19],0xcc
    185c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    185f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1862:	6a 00                	push   0x0
    1864:	6a 00                	push   0x0
    1866:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1869:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    186d:	06                   	push   es
    186e:	57                   	push   di
    186f:	9a 0c 0f 23 19       	call   0x1923:0xf0c
    1874:	8b d0                	mov    dx,ax
    1876:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1879:	98                   	cbw
    187a:	d1 e0                	shl    ax,1
    187c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187f:	03 f8                	add    di,ax
    1881:	26 89 55 0c          	mov    WORD PTR es:[di+0xc],dx
    1885:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1889:	83 c4 06             	add    sp,0x6
    188c:	b8 9c 18             	mov    ax,0x189c
    188f:	0e                   	push   cs
    1890:	50                   	push   ax
    1891:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1894:	06                   	push   es
    1895:	57                   	push   di
    1896:	9a 7f 1f b0 18       	call   0x18b0:0x1f7f
    189b:	cb                   	retf
    189c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    18a0:	83 c4 06             	add    sp,0x6
    18a3:	b8 b3 18             	mov    ax,0x18b3
    18a6:	0e                   	push   cs
    18a7:	50                   	push   ax
    18a8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    18ab:	06                   	push   es
    18ac:	57                   	push   di
    18ad:	9a 7f 1f f1 1a       	call   0x1af1:0x1f7f
    18b2:	cb                   	retf
    18b3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    18b6:	98                   	cbw
    18b7:	d1 e0                	shl    ax,1
    18b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18bc:	03 f8                	add    di,ax
    18be:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    18c2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    18c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c8:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    18cc:	06                   	push   es
    18cd:	57                   	push   di
    18ce:	9a bf 58 43 19       	call   0x1943:0x58bf
    18d3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    18d6:	c9                   	leave
    18d7:	ca 06 00             	retf   0x6
    18da:	c8 02 00 00          	enter  0x2,0x0
    18de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e1:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    18e5:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    18e9:	75 02                	jne    0x18ed
    18eb:	eb 58                	jmp    0x1945
    18ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18f0:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    18f4:	06                   	push   es
    18f5:	57                   	push   di
    18f6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18f9:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    18fd:	09 c0                	or     ax,ax
    18ff:	74 14                	je     0x1915
    1901:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1904:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1908:	06                   	push   es
    1909:	57                   	push   di
    190a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    190d:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1911:	09 c0                	or     ax,ax
    1913:	75 02                	jne    0x1917
    1915:	eb 2e                	jmp    0x1945
    1917:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    191a:	50                   	push   ax
    191b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    191e:	06                   	push   es
    191f:	57                   	push   di
    1920:	9a e8 13 e6 1d       	call   0x1de6:0x13e8
    1925:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1928:	ff 76 12             	push   WORD PTR [bp+0x12]
    192b:	ff 76 10             	push   WORD PTR [bp+0x10]
    192e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1931:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1934:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193a:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    193e:	06                   	push   es
    193f:	57                   	push   di
    1940:	9a 46 6e 7f 19       	call   0x197f:0x6e46
    1945:	c9                   	leave
    1946:	ca 0e 00             	retf   0xe
    1949:	c8 0c 01 00          	enter  0x10c,0x0
    194d:	8c d3                	mov    bx,ss
    194f:	8e c3                	mov    es,bx
    1951:	8c db                	mov    bx,ds
    1953:	fc                   	cld
    1954:	8d 7e f8             	lea    di,[bp-0x8]
    1957:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    195a:	b9 08 00             	mov    cx,0x8
    195d:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    195f:	8e db                	mov    ds,bx
    1961:	8d be f8 fe          	lea    di,[bp-0x108]
    1965:	16                   	push   ss
    1966:	57                   	push   di
    1967:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    196a:	06                   	push   es
    196b:	57                   	push   di
    196c:	9a 4c 0d 0c 1b       	call   0x1b0c:0xd4c
    1971:	6a 01                	push   0x1
    1973:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1976:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    197a:	06                   	push   es
    197b:	57                   	push   di
    197c:	9a 7c 17 b5 19       	call   0x19b5:0x177c
    1981:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    1985:	74 03                	je     0x198a
    1987:	e9 a0 00             	jmp    0x1a2a
    198a:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    198d:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1991:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1995:	8d 7e f8             	lea    di,[bp-0x8]
    1998:	16                   	push   ss
    1999:	57                   	push   di
    199a:	6a 01                	push   0x1
    199c:	6a 01                	push   0x1
    199e:	9a e8 19 00 00       	call   0x0:0x19e8
    19a3:	68 ff 00             	push   0xff
    19a6:	6a ff                	push   0xffff
    19a8:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    19ac:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    19b0:	06                   	push   es
    19b1:	57                   	push   di
    19b2:	9a df 0f c0 19       	call   0x19c0:0xfdf
    19b7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    19bb:	06                   	push   es
    19bc:	57                   	push   di
    19bd:	9a d2 21 ff 19       	call   0x19ff:0x21d2
    19c2:	50                   	push   ax
    19c3:	8d be f8 fe          	lea    di,[bp-0x108]
    19c7:	16                   	push   ss
    19c8:	57                   	push   di
    19c9:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    19cc:	26 8a 05             	mov    al,BYTE PTR es:[di]
    19cf:	30 e4                	xor    ah,ah
    19d1:	50                   	push   ax
    19d2:	8d 7e f8             	lea    di,[bp-0x8]
    19d5:	16                   	push   ss
    19d6:	57                   	push   di
    19d7:	6a 00                	push   0x0
    19d9:	9a 24 1a 00 00       	call   0x0:0x1a24
    19de:	8d 7e f8             	lea    di,[bp-0x8]
    19e1:	16                   	push   ss
    19e2:	57                   	push   di
    19e3:	6a ff                	push   0xffff
    19e5:	6a ff                	push   0xffff
    19e7:	9a ae 1d 00 00       	call   0x0:0x1dae
    19ec:	68 80 00             	push   0x80
    19ef:	68 80 80             	push   0x8080
    19f2:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    19f6:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    19fa:	06                   	push   es
    19fb:	57                   	push   di
    19fc:	9a df 0f 0a 1a       	call   0x1a0a:0xfdf
    1a01:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1a05:	06                   	push   es
    1a06:	57                   	push   di
    1a07:	9a d2 21 32 1a       	call   0x1a32:0x21d2
    1a0c:	50                   	push   ax
    1a0d:	8d be f8 fe          	lea    di,[bp-0x108]
    1a11:	16                   	push   ss
    1a12:	57                   	push   di
    1a13:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1a16:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1a19:	30 e4                	xor    ah,ah
    1a1b:	50                   	push   ax
    1a1c:	8d 7e f8             	lea    di,[bp-0x8]
    1a1f:	16                   	push   ss
    1a20:	57                   	push   di
    1a21:	6a 00                	push   0x0
    1a23:	9a 45 1a 00 00       	call   0x0:0x1a45
    1a28:	eb 1f                	jmp    0x1a49
    1a2a:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1a2d:	06                   	push   es
    1a2e:	57                   	push   di
    1a2f:	9a d2 21 fb 1a       	call   0x1afb:0x21d2
    1a34:	50                   	push   ax
    1a35:	8d be f8 fe          	lea    di,[bp-0x108]
    1a39:	16                   	push   ss
    1a3a:	57                   	push   di
    1a3b:	6a ff                	push   0xffff
    1a3d:	8d 7e f8             	lea    di,[bp-0x8]
    1a40:	16                   	push   ss
    1a41:	57                   	push   di
    1a42:	6a 25                	push   0x25
    1a44:	9a 1b 1b 00 00       	call   0x0:0x1b1b
    1a49:	c9                   	leave
    1a4a:	ca 12 00             	retf   0x12
    1a4d:	c8 1e 01 00          	enter  0x11e,0x0
    1a51:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    1a54:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1a58:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1a5b:	50                   	push   ax
    1a5c:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1a60:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1a64:	50                   	push   ax
    1a65:	9a 6e 06 a9 1a       	call   0x1aa9:0x66e
    1a6a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1a6d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1a70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a73:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1a77:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    1a7b:	74 36                	je     0x1ab3
    1a7d:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    1a81:	98                   	cbw
    1a82:	50                   	push   ax
    1a83:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a87:	06                   	push   es
    1a88:	57                   	push   di
    1a89:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a8c:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1a90:	59                   	pop    cx
    1a91:	99                   	cwd
    1a92:	f7 f9                	idiv   cx
    1a94:	50                   	push   ax
    1a95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a98:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a9c:	06                   	push   es
    1a9d:	57                   	push   di
    1a9e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1aa1:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1aa5:	50                   	push   ax
    1aa6:	9a 6e 06 ba 1a       	call   0x1aba:0x66e
    1aab:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1aae:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1ab1:	eb 0f                	jmp    0x1ac2
    1ab3:	6a 00                	push   0x0
    1ab5:	6a 00                	push   0x0
    1ab7:	9a 6e 06 e5 1a       	call   0x1ae5:0x66e
    1abc:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1abf:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1ac2:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
    1ac5:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1ac9:	76 56                	jbe    0x1b21
    1acb:	8d be e2 fe          	lea    di,[bp-0x11e]
    1acf:	16                   	push   ss
    1ad0:	57                   	push   di
    1ad1:	6a 00                	push   0x0
    1ad3:	6a 00                	push   0x0
    1ad5:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    1ad8:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1adc:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1adf:	50                   	push   ax
    1ae0:	6a 00                	push   0x0
    1ae2:	9a 88 06 32 1b       	call   0x1b32:0x688
    1ae7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1aea:	06                   	push   es
    1aeb:	57                   	push   di
    1aec:	6a 08                	push   0x8
    1aee:	9a 1b 16 3e 1b       	call   0x1b3e:0x161b
    1af3:	c4 7e 20             	les    di,DWORD PTR [bp+0x20]
    1af6:	06                   	push   es
    1af7:	57                   	push   di
    1af8:	9a d2 21 40 1e       	call   0x1e40:0x21d2
    1afd:	50                   	push   ax
    1afe:	8d be ec fe          	lea    di,[bp-0x114]
    1b02:	16                   	push   ss
    1b03:	57                   	push   di
    1b04:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
    1b07:	06                   	push   es
    1b08:	57                   	push   di
    1b09:	9a 4c 0d 71 2d       	call   0x2d71:0xd4c
    1b0e:	52                   	push   dx
    1b0f:	50                   	push   ax
    1b10:	6a ff                	push   0xffff
    1b12:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b15:	06                   	push   es
    1b16:	57                   	push   di
    1b17:	68 00 04             	push   0x400
    1b1a:	9a ff ff 00 00       	call   0x0:0xffff
    1b1f:	eb 1f                	jmp    0x1b40
    1b21:	8d be e2 fe          	lea    di,[bp-0x11e]
    1b25:	16                   	push   ss
    1b26:	57                   	push   di
    1b27:	6a 00                	push   0x0
    1b29:	6a 00                	push   0x0
    1b2b:	6a 00                	push   0x0
    1b2d:	6a 00                	push   0x0
    1b2f:	9a 88 06 57 1b       	call   0x1b57:0x688
    1b34:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b37:	06                   	push   es
    1b38:	57                   	push   di
    1b39:	6a 08                	push   0x8
    1b3b:	9a 1b 16 2f 1e       	call   0x1e2f:0x161b
    1b40:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b43:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1b47:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1b4a:	50                   	push   ax
    1b4b:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1b4f:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1b53:	50                   	push   ax
    1b54:	9a 6e 06 04 1c       	call   0x1c04:0x66e
    1b59:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1b5c:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    1b5f:	8a 46 16             	mov    al,BYTE PTR [bp+0x16]
    1b62:	3c 01                	cmp    al,0x1
    1b64:	77 38                	ja     0x1b9e
    1b66:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b69:	99                   	cwd
    1b6a:	b9 02 00             	mov    cx,0x2
    1b6d:	f7 f9                	idiv   cx
    1b6f:	8b d8                	mov    bx,ax
    1b71:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b74:	99                   	cwd
    1b75:	b9 02 00             	mov    cx,0x2
    1b78:	f7 f9                	idiv   cx
    1b7a:	2b c3                	sub    ax,bx
    1b7c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1b7f:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1b83:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1b86:	99                   	cwd
    1b87:	b9 02 00             	mov    cx,0x2
    1b8a:	f7 f9                	idiv   cx
    1b8c:	8b d8                	mov    bx,ax
    1b8e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b91:	99                   	cwd
    1b92:	b9 02 00             	mov    cx,0x2
    1b95:	f7 f9                	idiv   cx
    1b97:	2b c3                	sub    ax,bx
    1b99:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b9c:	eb 35                	jmp    0x1bd3
    1b9e:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1ba1:	99                   	cwd
    1ba2:	b9 02 00             	mov    cx,0x2
    1ba5:	f7 f9                	idiv   cx
    1ba7:	8b d8                	mov    bx,ax
    1ba9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1bac:	99                   	cwd
    1bad:	b9 02 00             	mov    cx,0x2
    1bb0:	f7 f9                	idiv   cx
    1bb2:	2b c3                	sub    ax,bx
    1bb4:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1bb7:	26 89 05             	mov    WORD PTR es:[di],ax
    1bba:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1bbd:	99                   	cwd
    1bbe:	b9 02 00             	mov    cx,0x2
    1bc1:	f7 f9                	idiv   cx
    1bc3:	8b d8                	mov    bx,ax
    1bc5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1bc8:	99                   	cwd
    1bc9:	b9 02 00             	mov    cx,0x2
    1bcc:	f7 f9                	idiv   cx
    1bce:	2b c3                	sub    ax,bx
    1bd0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1bd3:	83 7e f0 00          	cmp    WORD PTR [bp-0x10],0x0
    1bd7:	74 06                	je     0x1bdf
    1bd9:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    1bdd:	75 05                	jne    0x1be4
    1bdf:	31 c0                	xor    ax,ax
    1be1:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    1be4:	83 7e 14 ff          	cmp    WORD PTR [bp+0x14],0xffff
    1be8:	74 03                	je     0x1bed
    1bea:	e9 aa 00             	jmp    0x1c97
    1bed:	83 7e 12 ff          	cmp    WORD PTR [bp+0x12],0xffff
    1bf1:	75 48                	jne    0x1c3b
    1bf3:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1bf6:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    1bf9:	50                   	push   ax
    1bfa:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1bfd:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    1c00:	50                   	push   ax
    1c01:	9a 6e 06 52 1c       	call   0x1c52:0x66e
    1c06:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1c09:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    1c0c:	8a 46 16             	mov    al,BYTE PTR [bp+0x16]
    1c0f:	3c 01                	cmp    al,0x1
    1c11:	77 11                	ja     0x1c24
    1c13:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1c16:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    1c19:	99                   	cwd
    1c1a:	b9 03 00             	mov    cx,0x3
    1c1d:	f7 f9                	idiv   cx
    1c1f:	89 46 14             	mov    WORD PTR [bp+0x14],ax
    1c22:	eb 0f                	jmp    0x1c33
    1c24:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1c27:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    1c2a:	99                   	cwd
    1c2b:	b9 03 00             	mov    cx,0x3
    1c2e:	f7 f9                	idiv   cx
    1c30:	89 46 14             	mov    WORD PTR [bp+0x14],ax
    1c33:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    1c36:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    1c39:	eb 5a                	jmp    0x1c95
    1c3b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1c3e:	03 46 12             	add    ax,WORD PTR [bp+0x12]
    1c41:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    1c44:	50                   	push   ax
    1c45:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1c48:	03 46 12             	add    ax,WORD PTR [bp+0x12]
    1c4b:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    1c4e:	50                   	push   ax
    1c4f:	9a 6e 06 bc 1c       	call   0x1cbc:0x66e
    1c54:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1c57:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    1c5a:	8a 46 16             	mov    al,BYTE PTR [bp+0x16]
    1c5d:	3c 01                	cmp    al,0x1
    1c5f:	77 1b                	ja     0x1c7c
    1c61:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    1c64:	99                   	cwd
    1c65:	b9 02 00             	mov    cx,0x2
    1c68:	f7 f9                	idiv   cx
    1c6a:	8b d8                	mov    bx,ax
    1c6c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1c6f:	99                   	cwd
    1c70:	b9 02 00             	mov    cx,0x2
    1c73:	f7 f9                	idiv   cx
    1c75:	2b c3                	sub    ax,bx
    1c77:	89 46 14             	mov    WORD PTR [bp+0x14],ax
    1c7a:	eb 19                	jmp    0x1c95
    1c7c:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    1c7f:	99                   	cwd
    1c80:	b9 02 00             	mov    cx,0x2
    1c83:	f7 f9                	idiv   cx
    1c85:	8b d8                	mov    bx,ax
    1c87:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1c8a:	99                   	cwd
    1c8b:	b9 02 00             	mov    cx,0x2
    1c8e:	f7 f9                	idiv   cx
    1c90:	2b c3                	sub    ax,bx
    1c92:	89 46 14             	mov    WORD PTR [bp+0x14],ax
    1c95:	eb 68                	jmp    0x1cff
    1c97:	83 7e 12 ff          	cmp    WORD PTR [bp+0x12],0xffff
    1c9b:	75 62                	jne    0x1cff
    1c9d:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    1ca0:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    1ca3:	8b d0                	mov    dx,ax
    1ca5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1ca8:	2b c2                	sub    ax,dx
    1caa:	50                   	push   ax
    1cab:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    1cae:	03 46 f6             	add    ax,WORD PTR [bp-0xa]
    1cb1:	8b d0                	mov    dx,ax
    1cb3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1cb6:	2b c2                	sub    ax,dx
    1cb8:	50                   	push   ax
    1cb9:	9a 6e 06 ca 1e       	call   0x1eca:0x66e
    1cbe:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1cc1:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    1cc4:	8a 46 16             	mov    al,BYTE PTR [bp+0x16]
    1cc7:	3c 01                	cmp    al,0x1
    1cc9:	77 1b                	ja     0x1ce6
    1ccb:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1cce:	99                   	cwd
    1ccf:	b9 02 00             	mov    cx,0x2
    1cd2:	f7 f9                	idiv   cx
    1cd4:	8b d8                	mov    bx,ax
    1cd6:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    1cd9:	99                   	cwd
    1cda:	b9 02 00             	mov    cx,0x2
    1cdd:	f7 f9                	idiv   cx
    1cdf:	2b c3                	sub    ax,bx
    1ce1:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    1ce4:	eb 19                	jmp    0x1cff
    1ce6:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1ce9:	99                   	cwd
    1cea:	b9 02 00             	mov    cx,0x2
    1ced:	f7 f9                	idiv   cx
    1cef:	8b d8                	mov    bx,ax
    1cf1:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    1cf4:	99                   	cwd
    1cf5:	b9 02 00             	mov    cx,0x2
    1cf8:	f7 f9                	idiv   cx
    1cfa:	2b c3                	sub    ax,bx
    1cfc:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    1cff:	8a 46 16             	mov    al,BYTE PTR [bp+0x16]
    1d02:	3c 00                	cmp    al,0x0
    1d04:	75 17                	jne    0x1d1d
    1d06:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    1d09:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1d0c:	26 89 05             	mov    WORD PTR es:[di],ax
    1d0f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1d12:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    1d15:	03 46 12             	add    ax,WORD PTR [bp+0x12]
    1d18:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d1b:	eb 5f                	jmp    0x1d7c
    1d1d:	3c 01                	cmp    al,0x1
    1d1f:	75 1d                	jne    0x1d3e
    1d21:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1d24:	2b 46 14             	sub    ax,WORD PTR [bp+0x14]
    1d27:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    1d2a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1d2d:	26 89 05             	mov    WORD PTR es:[di],ax
    1d30:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1d33:	2b 46 12             	sub    ax,WORD PTR [bp+0x12]
    1d36:	2b 46 f0             	sub    ax,WORD PTR [bp-0x10]
    1d39:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d3c:	eb 3e                	jmp    0x1d7c
    1d3e:	3c 02                	cmp    al,0x2
    1d40:	75 19                	jne    0x1d5b
    1d42:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    1d45:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1d48:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1d4c:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1d50:	03 46 f6             	add    ax,WORD PTR [bp-0xa]
    1d53:	03 46 12             	add    ax,WORD PTR [bp+0x12]
    1d56:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d59:	eb 21                	jmp    0x1d7c
    1d5b:	3c 03                	cmp    al,0x3
    1d5d:	75 1d                	jne    0x1d7c
    1d5f:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1d62:	2b 46 14             	sub    ax,WORD PTR [bp+0x14]
    1d65:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    1d68:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1d6b:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1d6f:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1d73:	2b 46 12             	sub    ax,WORD PTR [bp+0x12]
    1d76:	2b 46 f2             	sub    ax,WORD PTR [bp-0xe]
    1d79:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d7c:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    1d7f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1d82:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1d85:	26 01 05             	add    WORD PTR es:[di],ax
    1d88:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    1d8b:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1d8f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1d92:	26 01 45 02          	add    WORD PTR es:[di+0x2],ax
    1d96:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d99:	06                   	push   es
    1d9a:	57                   	push   di
    1d9b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1d9e:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    1da1:	26 03 05             	add    ax,WORD PTR es:[di]
    1da4:	50                   	push   ax
    1da5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1da8:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    1dac:	50                   	push   ax
    1dad:	9a 49 2b 00 00       	call   0x0:0x2b49
    1db2:	c9                   	leave
    1db3:	ca 1e 00             	retf   0x1e
    1db6:	c8 0c 01 00          	enter  0x10c,0x0
    1dba:	ff 76 1c             	push   WORD PTR [bp+0x1c]
    1dbd:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    1dc0:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    1dc3:	06                   	push   es
    1dc4:	57                   	push   di
    1dc5:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1dc8:	06                   	push   es
    1dc9:	57                   	push   di
    1dca:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    1dcd:	50                   	push   ax
    1dce:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1dd1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1dd4:	8d 7e fc             	lea    di,[bp-0x4]
    1dd7:	16                   	push   ss
    1dd8:	57                   	push   di
    1dd9:	8d 7e f4             	lea    di,[bp-0xc]
    1ddc:	16                   	push   ss
    1ddd:	57                   	push   di
    1dde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1de1:	06                   	push   es
    1de2:	57                   	push   di
    1de3:	9a 4d 1a 00 1e       	call   0x1e00:0x1a4d
    1de8:	ff 76 1c             	push   WORD PTR [bp+0x1c]
    1deb:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    1dee:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1df1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1df4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1df7:	50                   	push   ax
    1df8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dfb:	06                   	push   es
    1dfc:	57                   	push   di
    1dfd:	9a da 18 1e 1e       	call   0x1e1e:0x18da
    1e02:	ff 76 1c             	push   WORD PTR [bp+0x1c]
    1e05:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    1e08:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1e0b:	06                   	push   es
    1e0c:	57                   	push   di
    1e0d:	8d 7e f4             	lea    di,[bp-0xc]
    1e10:	16                   	push   ss
    1e11:	57                   	push   di
    1e12:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1e15:	50                   	push   ax
    1e16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e19:	06                   	push   es
    1e1a:	57                   	push   di
    1e1b:	9a 49 19 6f 1f       	call   0x1f6f:0x1949
    1e20:	8d 7e f4             	lea    di,[bp-0xc]
    1e23:	16                   	push   ss
    1e24:	57                   	push   di
    1e25:	c4 7e 1e             	les    di,DWORD PTR [bp+0x1e]
    1e28:	06                   	push   es
    1e29:	57                   	push   di
    1e2a:	6a 08                	push   0x8
    1e2c:	9a 1b 16 36 1f       	call   0x1f36:0x161b
    1e31:	c9                   	leave
    1e32:	ca 18 00             	retf   0x18
    1e35:	c8 10 00 00          	enter  0x10,0x0
    1e39:	b0 01                	mov    al,0x1
    1e3b:	50                   	push   ax
    1e3c:	b8 3f 08             	mov    ax,0x83f
    1e3f:	ba 47 1e             	mov    dx,0x1e47
    1e42:	52                   	push   dx
    1e43:	50                   	push   ax
    1e44:	9a bd 56 77 1e       	call   0x1e77:0x56bd
    1e49:	a3 10 2b             	mov    ds:0x2b10,ax
    1e4c:	89 16 12 2b          	mov    WORD PTR ds:0x2b12,dx
    1e50:	6a 08                	push   0x8
    1e52:	c4 3e 10 2b          	les    di,DWORD PTR ds:0x2b10
    1e56:	06                   	push   es
    1e57:	57                   	push   di
    1e58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e5b:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1e5f:	6a 08                	push   0x8
    1e61:	c4 3e 10 2b          	les    di,DWORD PTR ds:0x2b10
    1e65:	06                   	push   es
    1e66:	57                   	push   di
    1e67:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e6a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1e6e:	c4 3e 10 2b          	les    di,DWORD PTR ds:0x2b10
    1e72:	06                   	push   es
    1e73:	57                   	push   di
    1e74:	9a 0f 5a 8e 1e       	call   0x1e8e:0x5a0f
    1e79:	89 c7                	mov    di,ax
    1e7b:	8e c2                	mov    es,dx
    1e7d:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1e80:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1e83:	6a 00                	push   0x0
    1e85:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1e89:	06                   	push   es
    1e8a:	57                   	push   di
    1e8b:	9a 7c 17 a0 1e       	call   0x1ea0:0x177c
    1e90:	6a ff                	push   0xffff
    1e92:	6a f0                	push   0xfff0
    1e94:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e97:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1e9b:	06                   	push   es
    1e9c:	57                   	push   di
    1e9d:	9a 84 16 d4 1e       	call   0x1ed4:0x1684
    1ea2:	8d 7e f0             	lea    di,[bp-0x10]
    1ea5:	16                   	push   ss
    1ea6:	57                   	push   di
    1ea7:	6a 00                	push   0x0
    1ea9:	6a 00                	push   0x0
    1eab:	c4 3e 10 2b          	les    di,DWORD PTR ds:0x2b10
    1eaf:	06                   	push   es
    1eb0:	57                   	push   di
    1eb1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1eb4:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1eb8:	50                   	push   ax
    1eb9:	c4 3e 10 2b          	les    di,DWORD PTR ds:0x2b10
    1ebd:	06                   	push   es
    1ebe:	57                   	push   di
    1ebf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ec2:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1ec6:	50                   	push   ax
    1ec7:	9a 88 06 a0 20       	call   0x20a0:0x688
    1ecc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ecf:	06                   	push   es
    1ed0:	57                   	push   di
    1ed1:	9a e5 1c 17 1f       	call   0x1f17:0x1ce5
    1ed6:	31 c0                	xor    ax,ax
    1ed8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1edb:	eb 03                	jmp    0x1ee0
    1edd:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1ee0:	31 c0                	xor    ax,ax
    1ee2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ee5:	eb 03                	jmp    0x1eea
    1ee7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1eea:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1eed:	99                   	cwd
    1eee:	b9 02 00             	mov    cx,0x2
    1ef1:	f7 f9                	idiv   cx
    1ef3:	92                   	xchg   dx,ax
    1ef4:	8b d8                	mov    bx,ax
    1ef6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ef9:	99                   	cwd
    1efa:	b9 02 00             	mov    cx,0x2
    1efd:	f7 f9                	idiv   cx
    1eff:	92                   	xchg   dx,ax
    1f00:	3b c3                	cmp    ax,bx
    1f02:	75 15                	jne    0x1f19
    1f04:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f07:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1f0a:	68 ff 00             	push   0xff
    1f0d:	6a ff                	push   0xffff
    1f0f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f12:	06                   	push   es
    1f13:	57                   	push   di
    1f14:	9a 64 21 75 20       	call   0x2075:0x2164
    1f19:	83 7e fe 07          	cmp    WORD PTR [bp-0x2],0x7
    1f1d:	75 c8                	jne    0x1ee7
    1f1f:	83 7e fc 07          	cmp    WORD PTR [bp-0x4],0x7
    1f23:	75 b8                	jne    0x1edd
    1f25:	c9                   	leave
    1f26:	c3                   	ret
    1f27:	55                   	push   bp
    1f28:	89 e5                	mov    bp,sp
    1f2a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1f2e:	74 08                	je     0x1f38
    1f30:	83 ec 08             	sub    sp,0x8
    1f33:	9a e2 1f f0 1f       	call   0x1ff0:0x1fe2
    1f38:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1f3b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f3e:	31 c0                	xor    ax,ax
    1f40:	50                   	push   ax
    1f41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f44:	06                   	push   es
    1f45:	57                   	push   di
    1f46:	9a 86 68 ac 1f       	call   0x1fac:0x6886
    1f4b:	6a 00                	push   0x0
    1f4d:	6a 00                	push   0x0
    1f4f:	6a 19                	push   0x19
    1f51:	6a 19                	push   0x19
    1f53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f56:	06                   	push   es
    1f57:	57                   	push   di
    1f58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f5b:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    1f5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f62:	26 c7 45 26 c2 00    	mov    WORD PTR es:[di+0x26],0xc2
    1f68:	b0 01                	mov    al,0x1
    1f6a:	50                   	push   ax
    1f6b:	b8 9b 0b             	mov    ax,0xb9b
    1f6e:	ba 76 1f             	mov    dx,0x1f76
    1f71:	52                   	push   dx
    1f72:	50                   	push   ax
    1f73:	9a 0e 11 8b 1f       	call   0x1f8b:0x110e
    1f78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7b:	26 89 85 90 00       	mov    WORD PTR es:[di+0x90],ax
    1f80:	26 89 95 92 00       	mov    WORD PTR es:[di+0x92],dx
    1f85:	06                   	push   es
    1f86:	57                   	push   di
    1f87:	b8 0c 24             	mov    ax,0x240c
    1f8a:	ba c4 20             	mov    dx,0x20c4
    1f8d:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    1f92:	26 89 45 19          	mov    WORD PTR es:[di+0x19],ax
    1f96:	26 89 55 1b          	mov    WORD PTR es:[di+0x1b],dx
    1f9a:	26 8f 45 1d          	pop    WORD PTR es:[di+0x1d]
    1f9e:	26 8f 45 1f          	pop    WORD PTR es:[di+0x1f]
    1fa2:	6a 01                	push   0x1
    1fa4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa7:	06                   	push   es
    1fa8:	57                   	push   di
    1fa9:	9a 3e 1e 1b 20       	call   0x201b:0x1e3e
    1fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb1:	26 c7 85 98 00 04 00 	mov    WORD PTR es:[di+0x98],0x4
    1fb8:	26 c7 85 9a 00 ff ff 	mov    WORD PTR es:[di+0x9a],0xffff
    1fbf:	26 c6 85 97 00 00    	mov    BYTE PTR es:[di+0x97],0x0
    1fc5:	ff 06 14 2b          	inc    WORD PTR ds:0x2b14
    1fc9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1fcd:	74 07                	je     0x1fd6
    1fcf:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1fd3:	83 c4 06             	add    sp,0x6
    1fd6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1fd9:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1fdc:	c9                   	leave
    1fdd:	ca 0a 00             	retf   0xa
    1fe0:	55                   	push   bp
    1fe1:	89 e5                	mov    bp,sp
    1fe3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe6:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    1feb:	06                   	push   es
    1fec:	57                   	push   di
    1fed:	9a 7f 1f 06 20       	call   0x2006:0x1f7f
    1ff2:	ff 0e 14 2b          	dec    WORD PTR ds:0x2b14
    1ff6:	83 3e 14 2b 00       	cmp    WORD PTR ds:0x2b14,0x0
    1ffb:	75 13                	jne    0x2010
    1ffd:	c4 3e 10 2b          	les    di,DWORD PTR ds:0x2b10
    2001:	06                   	push   es
    2002:	57                   	push   di
    2003:	9a 7f 1f 26 20       	call   0x2026:0x1f7f
    2008:	31 c0                	xor    ax,ax
    200a:	a3 10 2b             	mov    ds:0x2b10,ax
    200d:	a3 12 2b             	mov    ds:0x2b12,ax
    2010:	31 c0                	xor    ax,ax
    2012:	50                   	push   ax
    2013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2016:	06                   	push   es
    2017:	57                   	push   di
    2018:	9a f0 68 44 21       	call   0x2144:0x68f0
    201d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2021:	74 05                	je     0x2028
    2023:	9a 0f 20 d0 20       	call   0x20d0:0x200f
    2028:	c9                   	leave
    2029:	ca 06 00             	retf   0x6
    202c:	c8 18 01 00          	enter  0x118,0x0
    2030:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2033:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2038:	75 15                	jne    0x204f
    203a:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    203f:	75 0e                	jne    0x204f
    2041:	26 c6 85 9c 00 01    	mov    BYTE PTR es:[di+0x9c],0x1
    2047:	26 c6 85 95 00 00    	mov    BYTE PTR es:[di+0x95],0x0
    204d:	eb 11                	jmp    0x2060
    204f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2052:	26 80 bd 9c 00 01    	cmp    BYTE PTR es:[di+0x9c],0x1
    2058:	75 06                	jne    0x2060
    205a:	26 c6 85 9c 00 00    	mov    BYTE PTR es:[di+0x9c],0x0
    2060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2063:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2067:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    206b:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    2070:	06                   	push   es
    2071:	57                   	push   di
    2072:	9a 99 20 02 21       	call   0x2102:0x2099
    2077:	8d 7e e0             	lea    di,[bp-0x20]
    207a:	16                   	push   ss
    207b:	57                   	push   di
    207c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    207f:	26 ff b5 8c 00       	push   WORD PTR es:[di+0x8c]
    2084:	26 ff b5 8a 00       	push   WORD PTR es:[di+0x8a]
    2089:	8d 7e e8             	lea    di,[bp-0x18]
    208c:	16                   	push   ss
    208d:	57                   	push   di
    208e:	6a 00                	push   0x0
    2090:	6a 00                	push   0x0
    2092:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2095:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    2099:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    209d:	9a 88 06 ff ff       	call   0xffff:0x688
    20a2:	6a 01                	push   0x1
    20a4:	6a 01                	push   0x1
    20a6:	6a 00                	push   0x0
    20a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ab:	26 8a 85 9c 00       	mov    al,BYTE PTR es:[di+0x9c]
    20b0:	3c 02                	cmp    al,0x2
    20b2:	72 04                	jb     0x20b8
    20b4:	3c 03                	cmp    al,0x3
    20b6:	76 04                	jbe    0x20bc
    20b8:	b0 00                	mov    al,0x0
    20ba:	eb 02                	jmp    0x20be
    20bc:	b0 01                	mov    al,0x1
    20be:	50                   	push   ax
    20bf:	6a 00                	push   0x0
    20c1:	9a e1 07 69 21       	call   0x2169:0x7e1
    20c6:	8d 7e f8             	lea    di,[bp-0x8]
    20c9:	16                   	push   ss
    20ca:	57                   	push   di
    20cb:	6a 08                	push   0x8
    20cd:	9a 1b 16 1f 23       	call   0x231f:0x161b
    20d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20d5:	26 80 bd 9c 00 03    	cmp    BYTE PTR es:[di+0x9c],0x3
    20db:	75 41                	jne    0x211e
    20dd:	a1 10 2b             	mov    ax,ds:0x2b10
    20e0:	0b 06 12 2b          	or     ax,WORD PTR ds:0x2b12
    20e4:	75 03                	jne    0x20e9
    20e6:	e8 4c fd             	call   0x1e35
    20e9:	ff 36 12 2b          	push   WORD PTR ds:0x2b12
    20ed:	ff 36 10 2b          	push   WORD PTR ds:0x2b10
    20f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f4:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    20f9:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    20fd:	06                   	push   es
    20fe:	57                   	push   di
    20ff:	9a 2d 16 1c 21       	call   0x211c:0x162d
    2104:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    2107:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    210a:	8d 7e f8             	lea    di,[bp-0x8]
    210d:	16                   	push   ss
    210e:	57                   	push   di
    210f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2112:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    2117:	06                   	push   es
    2118:	57                   	push   di
    2119:	9a e5 1c 4d 23       	call   0x234d:0x1ce5
    211e:	8d be e8 fe          	lea    di,[bp-0x118]
    2122:	16                   	push   ss
    2123:	57                   	push   di
    2124:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2127:	26 ff b5 8c 00       	push   WORD PTR es:[di+0x8c]
    212c:	26 ff b5 8a 00       	push   WORD PTR es:[di+0x8a]
    2131:	8d 7e f8             	lea    di,[bp-0x8]
    2134:	16                   	push   ss
    2135:	57                   	push   di
    2136:	8d be f0 fe          	lea    di,[bp-0x110]
    213a:	16                   	push   ss
    213b:	57                   	push   di
    213c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213f:	06                   	push   es
    2140:	57                   	push   di
    2141:	9a 53 1d 8b 21       	call   0x218b:0x1d53
    2146:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2149:	26 8a 85 97 00       	mov    al,BYTE PTR es:[di+0x97]
    214e:	50                   	push   ax
    214f:	26 ff b5 9a 00       	push   WORD PTR es:[di+0x9a]
    2154:	26 ff b5 98 00       	push   WORD PTR es:[di+0x98]
    2159:	26 8a 85 9c 00       	mov    al,BYTE PTR es:[di+0x9c]
    215e:	50                   	push   ax
    215f:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    2164:	06                   	push   es
    2165:	57                   	push   di
    2166:	9a b6 1d ed 22       	call   0x22ed:0x1db6
    216b:	83 c4 04             	add    sp,0x4
    216e:	c9                   	leave
    216f:	ca 04 00             	retf   0x4
    2172:	55                   	push   bp
    2173:	89 e5                	mov    bp,sp
    2175:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    2178:	50                   	push   ax
    2179:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    217c:	50                   	push   ax
    217d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2180:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2183:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2186:	06                   	push   es
    2187:	57                   	push   di
    2188:	9a c0 27 d7 21       	call   0x21d7:0x27c0
    218d:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
    2191:	75 2a                	jne    0x21bd
    2193:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2196:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    219b:	74 20                	je     0x21bd
    219d:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    21a3:	75 0f                	jne    0x21b4
    21a5:	26 c6 85 9c 00 02    	mov    BYTE PTR es:[di+0x9c],0x2
    21ab:	06                   	push   es
    21ac:	57                   	push   di
    21ad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21b0:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    21b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b7:	26 c6 85 95 00 01    	mov    BYTE PTR es:[di+0x95],0x1
    21bd:	c9                   	leave
    21be:	ca 0c 00             	retf   0xc
    21c1:	c8 02 00 00          	enter  0x2,0x0
    21c5:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    21c8:	50                   	push   ax
    21c9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    21cc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    21cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d2:	06                   	push   es
    21d3:	57                   	push   di
    21d4:	9a f2 2a 04 22       	call   0x2204:0x2af2
    21d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21dc:	26 80 bd 95 00 00    	cmp    BYTE PTR es:[di+0x95],0x0
    21e2:	74 6f                	je     0x2253
    21e4:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    21ea:	75 06                	jne    0x21f2
    21ec:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    21f0:	eb 04                	jmp    0x21f6
    21f2:	c6 46 ff 03          	mov    BYTE PTR [bp-0x1],0x3
    21f6:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    21fa:	7c 39                	jl     0x2235
    21fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ff:	06                   	push   es
    2200:	57                   	push   di
    2201:	9a a9 18 19 22       	call   0x2219:0x18a9
    2206:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2209:	7e 2a                	jle    0x2235
    220b:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    220f:	7c 24                	jl     0x2235
    2211:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2214:	06                   	push   es
    2215:	57                   	push   di
    2216:	9a f4 18 71 22       	call   0x2271:0x18f4
    221b:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    221e:	7c 15                	jl     0x2235
    2220:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2223:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    2229:	74 06                	je     0x2231
    222b:	c6 46 ff 03          	mov    BYTE PTR [bp-0x1],0x3
    222f:	eb 04                	jmp    0x2235
    2231:	c6 46 ff 02          	mov    BYTE PTR [bp-0x1],0x2
    2235:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2238:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223b:	26 3a 85 9c 00       	cmp    al,BYTE PTR es:[di+0x9c]
    2240:	74 11                	je     0x2253
    2242:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2245:	26 88 85 9c 00       	mov    BYTE PTR es:[di+0x9c],al
    224a:	06                   	push   es
    224b:	57                   	push   di
    224c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    224f:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    2253:	c9                   	leave
    2254:	ca 0a 00             	retf   0xa
    2257:	c8 02 00 00          	enter  0x2,0x0
    225b:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    225e:	50                   	push   ax
    225f:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    2262:	50                   	push   ax
    2263:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2266:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2269:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    226c:	06                   	push   es
    226d:	57                   	push   di
    226e:	9a 65 2b 92 22       	call   0x2292:0x2b65
    2273:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2276:	26 80 bd 95 00 00    	cmp    BYTE PTR es:[di+0x95],0x0
    227c:	75 03                	jne    0x2281
    227e:	e9 a0 00             	jmp    0x2321
    2281:	26 c6 85 95 00 00    	mov    BYTE PTR es:[di+0x95],0x0
    2287:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    228b:	7c 21                	jl     0x22ae
    228d:	06                   	push   es
    228e:	57                   	push   di
    228f:	9a a9 18 a7 22       	call   0x22a7:0x18a9
    2294:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2297:	7e 15                	jle    0x22ae
    2299:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    229d:	7c 0f                	jl     0x22ae
    229f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a2:	06                   	push   es
    22a3:	57                   	push   di
    22a4:	9a f4 18 30 23       	call   0x2330:0x18f4
    22a9:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    22ac:	7d 04                	jge    0x22b2
    22ae:	b0 00                	mov    al,0x0
    22b0:	eb 02                	jmp    0x22b4
    22b2:	b0 01                	mov    al,0x1
    22b4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    22b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ba:	26 c6 85 9c 00 00    	mov    BYTE PTR es:[di+0x9c],0x0
    22c0:	26 83 bd 8e 00 00    	cmp    WORD PTR es:[di+0x8e],0x0
    22c6:	75 0b                	jne    0x22d3
    22c8:	06                   	push   es
    22c9:	57                   	push   di
    22ca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22cd:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    22d1:	eb 3b                	jmp    0x230e
    22d3:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    22d7:	74 18                	je     0x22f1
    22d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22dc:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    22e2:	b0 00                	mov    al,0x0
    22e4:	75 01                	jne    0x22e7
    22e6:	40                   	inc    ax
    22e7:	50                   	push   ax
    22e8:	06                   	push   es
    22e9:	57                   	push   di
    22ea:	9a 70 24 42 23       	call   0x2342:0x2470
    22ef:	eb 1d                	jmp    0x230e
    22f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f4:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    22fa:	74 06                	je     0x2302
    22fc:	26 c6 85 9c 00 03    	mov    BYTE PTR es:[di+0x9c],0x3
    2302:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2305:	06                   	push   es
    2306:	57                   	push   di
    2307:	26 c4 3d             	les    di,DWORD PTR es:[di]
    230a:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    230e:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2312:	74 0d                	je     0x2321
    2314:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2317:	06                   	push   es
    2318:	57                   	push   di
    2319:	b8 fe ff             	mov    ax,0xfffe
    231c:	9a 6a 20 c5 25       	call   0x25c5:0x206a
    2321:	c9                   	leave
    2322:	ca 0c 00             	retf   0xc
    2325:	55                   	push   bp
    2326:	89 e5                	mov    bp,sp
    2328:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    232b:	06                   	push   es
    232c:	57                   	push   di
    232d:	9a 73 27 6a 24       	call   0x246a:0x2773
    2332:	c9                   	leave
    2333:	ca 04 00             	retf   0x4
    2336:	c8 02 00 00          	enter  0x2,0x0
    233a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    233d:	06                   	push   es
    233e:	57                   	push   di
    233f:	9a 59 23 93 23       	call   0x2393:0x2359
    2344:	89 c7                	mov    di,ax
    2346:	8e c2                	mov    es,dx
    2348:	06                   	push   es
    2349:	57                   	push   di
    234a:	9a 0d 5b 63 27       	call   0x2763:0x5b0d
    234f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2352:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2355:	c9                   	leave
    2356:	ca 04 00             	retf   0x4
    2359:	c8 04 00 00          	enter  0x4,0x0
    235d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2360:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    2365:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2369:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    236d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2370:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2373:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2376:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2379:	c9                   	leave
    237a:	ca 04 00             	retf   0x4
    237d:	55                   	push   bp
    237e:	89 e5                	mov    bp,sp
    2380:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2383:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2386:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2389:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    238e:	06                   	push   es
    238f:	57                   	push   di
    2390:	9a ff 12 fa 23       	call   0x23fa:0x12ff
    2395:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2398:	06                   	push   es
    2399:	57                   	push   di
    239a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    239d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    23a1:	c9                   	leave
    23a2:	ca 08 00             	retf   0x8
    23a5:	c8 02 00 00          	enter  0x2,0x0
    23a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ac:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    23b1:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    23b5:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    23b8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    23bb:	c9                   	leave
    23bc:	ca 04 00             	retf   0x4
    23bf:	55                   	push   bp
    23c0:	89 e5                	mov    bp,sp
    23c2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    23c6:	7d 06                	jge    0x23ce
    23c8:	c6 46 0a 01          	mov    BYTE PTR [bp+0xa],0x1
    23cc:	eb 0a                	jmp    0x23d8
    23ce:	80 7e 0a 04          	cmp    BYTE PTR [bp+0xa],0x4
    23d2:	7e 04                	jle    0x23d8
    23d4:	c6 46 0a 04          	mov    BYTE PTR [bp+0xa],0x4
    23d8:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    23db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23de:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    23e3:	26 3a 45 18          	cmp    al,BYTE PTR es:[di+0x18]
    23e7:	74 1f                	je     0x2408
    23e9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    23ec:	50                   	push   ax
    23ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f0:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    23f5:	06                   	push   es
    23f6:	57                   	push   di
    23f7:	9a b2 13 de 24       	call   0x24de:0x13b2
    23fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ff:	06                   	push   es
    2400:	57                   	push   di
    2401:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2404:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2408:	c9                   	leave
    2409:	ca 06 00             	retf   0x6
    240c:	55                   	push   bp
    240d:	89 e5                	mov    bp,sp
    240f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2412:	06                   	push   es
    2413:	57                   	push   di
    2414:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2417:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    241b:	c9                   	leave
    241c:	ca 08 00             	retf   0x8
    241f:	c8 0c 00 00          	enter  0xc,0x0
    2423:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2426:	26 83 bd 8e 00 00    	cmp    WORD PTR es:[di+0x8e],0x0
    242c:	74 3e                	je     0x246c
    242e:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2432:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2436:	74 34                	je     0x246c
    2438:	c7 46 f4 18 0f       	mov    WORD PTR [bp-0xc],0xf18
    243d:	26 8b 85 8e 00       	mov    ax,WORD PTR es:[di+0x8e]
    2442:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2445:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2448:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    244b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    244e:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2451:	31 c0                	xor    ax,ax
    2453:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2456:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2459:	8d 7e f4             	lea    di,[bp-0xc]
    245c:	16                   	push   ss
    245d:	57                   	push   di
    245e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2461:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2465:	06                   	push   es
    2466:	57                   	push   di
    2467:	9a 43 3a b0 25       	call   0x25b0:0x3a43
    246c:	c9                   	leave
    246d:	ca 04 00             	retf   0x4
    2470:	c8 0c 00 00          	enter  0xc,0x0
    2474:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2477:	26 83 bd 8e 00 00    	cmp    WORD PTR es:[di+0x8e],0x0
    247d:	75 04                	jne    0x2483
    247f:	c6 46 0a 00          	mov    BYTE PTR [bp+0xa],0x0
    2483:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2486:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2489:	26 3a 85 94 00       	cmp    al,BYTE PTR es:[di+0x94]
    248e:	74 50                	je     0x24e0
    2490:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    2496:	74 0a                	je     0x24a2
    2498:	26 80 bd 96 00 00    	cmp    BYTE PTR es:[di+0x96],0x0
    249e:	75 02                	jne    0x24a2
    24a0:	eb 3e                	jmp    0x24e0
    24a2:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    24a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a8:	26 88 85 94 00       	mov    BYTE PTR es:[di+0x94],al
    24ad:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    24b1:	74 08                	je     0x24bb
    24b3:	26 c6 85 9c 00 03    	mov    BYTE PTR es:[di+0x9c],0x3
    24b9:	eb 09                	jmp    0x24c4
    24bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24be:	26 c6 85 9c 00 00    	mov    BYTE PTR es:[di+0x9c],0x0
    24c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c7:	06                   	push   es
    24c8:	57                   	push   di
    24c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24cc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    24d0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    24d4:	74 0a                	je     0x24e0
    24d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d9:	06                   	push   es
    24da:	57                   	push   di
    24db:	9a 1f 24 01 25       	call   0x2501:0x241f
    24e0:	c9                   	leave
    24e1:	ca 06 00             	retf   0x6
    24e4:	55                   	push   bp
    24e5:	89 e5                	mov    bp,sp
    24e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ea:	26 8b 85 8e 00       	mov    ax,WORD PTR es:[di+0x8e]
    24ef:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    24f2:	74 0f                	je     0x2503
    24f4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    24f7:	26 89 85 8e 00       	mov    WORD PTR es:[di+0x8e],ax
    24fc:	06                   	push   es
    24fd:	57                   	push   di
    24fe:	9a 1f 24 99 25       	call   0x2599:0x241f
    2503:	c9                   	leave
    2504:	ca 06 00             	retf   0x6
    2507:	55                   	push   bp
    2508:	89 e5                	mov    bp,sp
    250a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    250d:	26 8a 85 97 00       	mov    al,BYTE PTR es:[di+0x97]
    2512:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2515:	74 11                	je     0x2528
    2517:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    251a:	26 88 85 97 00       	mov    BYTE PTR es:[di+0x97],al
    251f:	06                   	push   es
    2520:	57                   	push   di
    2521:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2524:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2528:	c9                   	leave
    2529:	ca 06 00             	retf   0x6
    252c:	55                   	push   bp
    252d:	89 e5                	mov    bp,sp
    252f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2535:	26 3b 85 9a 00       	cmp    ax,WORD PTR es:[di+0x9a]
    253a:	74 17                	je     0x2553
    253c:	83 7e 0a ff          	cmp    WORD PTR [bp+0xa],0xffff
    2540:	7c 11                	jl     0x2553
    2542:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2545:	26 89 85 9a 00       	mov    WORD PTR es:[di+0x9a],ax
    254a:	06                   	push   es
    254b:	57                   	push   di
    254c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    254f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2553:	c9                   	leave
    2554:	ca 06 00             	retf   0x6
    2557:	55                   	push   bp
    2558:	89 e5                	mov    bp,sp
    255a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    255d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2560:	26 3b 85 98 00       	cmp    ax,WORD PTR es:[di+0x98]
    2565:	74 11                	je     0x2578
    2567:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    256a:	26 89 85 98 00       	mov    WORD PTR es:[di+0x98],ax
    256f:	06                   	push   es
    2570:	57                   	push   di
    2571:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2574:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2578:	c9                   	leave
    2579:	ca 06 00             	retf   0x6
    257c:	55                   	push   bp
    257d:	89 e5                	mov    bp,sp
    257f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2582:	26 8a 85 96 00       	mov    al,BYTE PTR es:[di+0x96]
    2587:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    258a:	74 0f                	je     0x259b
    258c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    258f:	26 88 85 96 00       	mov    BYTE PTR es:[di+0x96],al
    2594:	06                   	push   es
    2595:	57                   	push   di
    2596:	9a 1f 24 f8 26       	call   0x26f8:0x241f
    259b:	c9                   	leave
    259c:	ca 06 00             	retf   0x6
    259f:	55                   	push   bp
    25a0:	89 e5                	mov    bp,sp
    25a2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    25a5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    25a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ab:	06                   	push   es
    25ac:	57                   	push   di
    25ad:	9a 12 29 7c 26       	call   0x267c:0x2912
    25b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b5:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    25bb:	74 0a                	je     0x25c7
    25bd:	06                   	push   es
    25be:	57                   	push   di
    25bf:	b8 fd ff             	mov    ax,0xfffd
    25c2:	9a 6a 20 99 26       	call   0x2699:0x206a
    25c7:	c9                   	leave
    25c8:	ca 08 00             	retf   0x8
    25cb:	55                   	push   bp
    25cc:	89 e5                	mov    bp,sp
    25ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d1:	06                   	push   es
    25d2:	57                   	push   di
    25d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25d6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    25da:	c9                   	leave
    25db:	ca 08 00             	retf   0x8
    25de:	c8 04 00 00          	enter  0x4,0x0
    25e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e5:	26 8b 85 8e 00       	mov    ax,WORD PTR es:[di+0x8e]
    25ea:	99                   	cwd
    25eb:	8b c8                	mov    cx,ax
    25ed:	8b da                	mov    bx,dx
    25ef:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25f2:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    25f6:	31 d2                	xor    dx,dx
    25f8:	3b d3                	cmp    dx,bx
    25fa:	75 5d                	jne    0x2659
    25fc:	3b c1                	cmp    ax,cx
    25fe:	75 59                	jne    0x2659
    2600:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2604:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    2608:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    260b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    260e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2611:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2614:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    2617:	75 05                	jne    0x261e
    2619:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    261c:	74 3b                	je     0x2659
    261e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2621:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    2627:	74 20                	je     0x2649
    2629:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    262c:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    2632:	74 15                	je     0x2649
    2634:	26 c6 85 94 00 00    	mov    BYTE PTR es:[di+0x94],0x0
    263a:	26 c6 85 9c 00 00    	mov    BYTE PTR es:[di+0x9c],0x0
    2640:	06                   	push   es
    2641:	57                   	push   di
    2642:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2645:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2649:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    264c:	26 8a 85 96 00       	mov    al,BYTE PTR es:[di+0x96]
    2651:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2654:	26 88 85 96 00       	mov    BYTE PTR es:[di+0x96],al
    2659:	c9                   	leave
    265a:	ca 08 00             	retf   0x8
    265d:	c8 04 01 00          	enter  0x104,0x0
    2661:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2664:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2667:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    266a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    266e:	8d be fc fe          	lea    di,[bp-0x104]
    2672:	16                   	push   ss
    2673:	57                   	push   di
    2674:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2677:	06                   	push   es
    2678:	57                   	push   di
    2679:	9a 53 1d dc 27       	call   0x27dc:0x1d53
    267e:	9a 3f 17 5a 28       	call   0x285a:0x173f
    2683:	08 c0                	or     al,al
    2685:	74 25                	je     0x26ac
    2687:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    268a:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    268f:	74 1b                	je     0x26ac
    2691:	06                   	push   es
    2692:	57                   	push   di
    2693:	b8 fe ff             	mov    ax,0xfffe
    2696:	9a 6a 20 0d 27       	call   0x270d:0x206a
    269b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    269e:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    26a4:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    26aa:	eb 12                	jmp    0x26be
    26ac:	ff 76 0c             	push   WORD PTR [bp+0xc]
    26af:	ff 76 0a             	push   WORD PTR [bp+0xa]
    26b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b5:	06                   	push   es
    26b6:	57                   	push   di
    26b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26ba:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    26be:	c9                   	leave
    26bf:	ca 08 00             	retf   0x8
    26c2:	55                   	push   bp
    26c3:	89 e5                	mov    bp,sp
    26c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c8:	06                   	push   es
    26c9:	57                   	push   di
    26ca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26cd:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    26d1:	c9                   	leave
    26d2:	ca 08 00             	retf   0x8
    26d5:	55                   	push   bp
    26d6:	89 e5                	mov    bp,sp
    26d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26db:	06                   	push   es
    26dc:	57                   	push   di
    26dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26e0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    26e4:	c9                   	leave
    26e5:	ca 08 00             	retf   0x8
    26e8:	55                   	push   bp
    26e9:	89 e5                	mov    bp,sp
    26eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ee:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    26f3:	06                   	push   es
    26f4:	57                   	push   di
    26f5:	9a 2f 12 29 27       	call   0x2729:0x122f
    26fa:	c9                   	leave
    26fb:	ca 08 00             	retf   0x8
    26fe:	55                   	push   bp
    26ff:	89 e5                	mov    bp,sp
    2701:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2705:	74 08                	je     0x270f
    2707:	83 ec 08             	sub    sp,0x8
    270a:	9a e2 1f c0 27       	call   0x27c0:0x1fe2
    270f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2712:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2715:	31 c0                	xor    ax,ax
    2717:	50                   	push   ax
    2718:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    271b:	06                   	push   es
    271c:	57                   	push   di
    271d:	9a b0 69 fe 27       	call   0x27fe:0x69b0
    2722:	b0 01                	mov    al,0x1
    2724:	50                   	push   ax
    2725:	b8 9b 0b             	mov    ax,0xb9b
    2728:	ba 30 27             	mov    dx,0x2730
    272b:	52                   	push   dx
    272c:	50                   	push   ax
    272d:	9a 0e 11 45 27       	call   0x2745:0x110e
    2732:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2735:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    273a:	26 89 95 e6 00       	mov    WORD PTR es:[di+0xe6],dx
    273f:	06                   	push   es
    2740:	57                   	push   di
    2741:	b8 79 2c             	mov    ax,0x2c79
    2744:	ba 3d 29             	mov    dx,0x293d
    2747:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    274c:	26 89 45 19          	mov    WORD PTR es:[di+0x19],ax
    2750:	26 89 55 1b          	mov    WORD PTR es:[di+0x1b],dx
    2754:	26 8f 45 1d          	pop    WORD PTR es:[di+0x1d]
    2758:	26 8f 45 1f          	pop    WORD PTR es:[di+0x1f]
    275c:	b0 01                	mov    al,0x1
    275e:	50                   	push   ax
    275f:	b8 60 05             	mov    ax,0x560
    2762:	ba 6a 27             	mov    dx,0x276a
    2765:	52                   	push   dx
    2766:	50                   	push   ax
    2767:	9a b8 17 5b 29       	call   0x295b:0x17b8
    276c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    276f:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
    2774:	26 89 95 e2 00       	mov    WORD PTR es:[di+0xe2],dx
    2779:	26 c6 85 e8 00 00    	mov    BYTE PTR es:[di+0xe8],0x0
    277f:	26 c6 85 e9 00 00    	mov    BYTE PTR es:[di+0xe9],0x0
    2785:	26 c6 85 ea 00 00    	mov    BYTE PTR es:[di+0xea],0x0
    278b:	26 c7 85 eb 00 04 00 	mov    WORD PTR es:[di+0xeb],0x4
    2792:	26 c7 85 ed 00 ff ff 	mov    WORD PTR es:[di+0xed],0xffff
    2799:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    279d:	74 07                	je     0x27a6
    279f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    27a3:	83 c4 06             	add    sp,0x6
    27a6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    27a9:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    27ac:	c9                   	leave
    27ad:	ca 0a 00             	retf   0xa
    27b0:	55                   	push   bp
    27b1:	89 e5                	mov    bp,sp
    27b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b6:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    27bb:	06                   	push   es
    27bc:	57                   	push   di
    27bd:	9a 7f 1f cf 27       	call   0x27cf:0x1f7f
    27c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c5:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    27ca:	06                   	push   es
    27cb:	57                   	push   di
    27cc:	9a 7f 1f e7 27       	call   0x27e7:0x1f7f
    27d1:	31 c0                	xor    ax,ax
    27d3:	50                   	push   ax
    27d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d7:	06                   	push   es
    27d8:	57                   	push   di
    27d9:	9a fc 2e 3b 28       	call   0x283b:0x2efc
    27de:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    27e2:	74 05                	je     0x27e9
    27e4:	9a 0f 20 95 2a       	call   0x2a95:0x200f
    27e9:	c9                   	leave
    27ea:	ca 06 00             	retf   0x6
    27ed:	c8 04 00 00          	enter  0x4,0x0
    27f1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    27f4:	06                   	push   es
    27f5:	57                   	push   di
    27f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27f9:	06                   	push   es
    27fa:	57                   	push   di
    27fb:	9a ff 6a 7e 28       	call   0x287e:0x6aff
    2800:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2803:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2807:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    280b:	0d 0b 00             	or     ax,0xb
    280e:	81 ca 00 00          	or     dx,0x0
    2812:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2816:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    281a:	c9                   	leave
    281b:	ca 08 00             	retf   0x8
    281e:	55                   	push   bp
    281f:	89 e5                	mov    bp,sp
    2821:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2824:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2827:	26 3a 85 ef 00       	cmp    al,BYTE PTR es:[di+0xef]
    282c:	74 0f                	je     0x283d
    282e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2831:	26 88 85 ef 00       	mov    BYTE PTR es:[di+0xef],al
    2836:	06                   	push   es
    2837:	57                   	push   di
    2838:	9a c6 22 bd 2a       	call   0x2abd:0x22c6
    283d:	c9                   	leave
    283e:	ca 06 00             	retf   0x6
    2841:	c8 08 00 00          	enter  0x8,0x0
    2845:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2848:	26 8a 85 e9 00       	mov    al,BYTE PTR es:[di+0xe9]
    284d:	3c 06                	cmp    al,0x6
    284f:	75 31                	jne    0x2882
    2851:	ff 76 08             	push   WORD PTR [bp+0x8]
    2854:	ff 76 06             	push   WORD PTR [bp+0x6]
    2857:	9a a8 17 72 28       	call   0x2872:0x17a8
    285c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    285f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2862:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2865:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    2868:	74 0c                	je     0x2876
    286a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    286d:	06                   	push   es
    286e:	57                   	push   di
    286f:	9a 56 55 da 28       	call   0x28da:0x5556
    2874:	eb 0a                	jmp    0x2880
    2876:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2879:	06                   	push   es
    287a:	57                   	push   di
    287b:	9a 15 6a e6 28       	call   0x28e6:0x6a15
    2880:	eb 72                	jmp    0x28f4
    2882:	3c 03                	cmp    al,0x3
    2884:	75 64                	jne    0x28ea
    2886:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2889:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    288c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    288f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2892:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2895:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    2898:	74 22                	je     0x28bc
    289a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    289d:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    28a2:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    28a7:	75 13                	jne    0x28bc
    28a9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    28ac:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    28b0:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    28b4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    28b7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    28ba:	eb d6                	jmp    0x2892
    28bc:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    28bf:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    28c2:	74 1a                	je     0x28de
    28c4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    28c7:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    28cc:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    28d1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    28d5:	06                   	push   es
    28d6:	57                   	push   di
    28d7:	9a 92 77 ff ff       	call   0xffff:0x7792
    28dc:	eb 0a                	jmp    0x28e8
    28de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28e1:	06                   	push   es
    28e2:	57                   	push   di
    28e3:	9a 15 6a f2 28       	call   0x28f2:0x6a15
    28e8:	eb 0a                	jmp    0x28f4
    28ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ed:	06                   	push   es
    28ee:	57                   	push   di
    28ef:	9a 15 6a 07 2d       	call   0x2d07:0x6a15
    28f4:	c9                   	leave
    28f5:	ca 04 00             	retf   0x4
    28f8:	c8 04 00 00          	enter  0x4,0x0
    28fc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28ff:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2903:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2906:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2909:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2910:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2913:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    2917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    291a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    291e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2921:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2925:	c9                   	leave
    2926:	ca 08 00             	retf   0x8
    2929:	55                   	push   bp
    292a:	89 e5                	mov    bp,sp
    292c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    292f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2933:	06                   	push   es
    2934:	57                   	push   di
    2935:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2938:	06                   	push   es
    2939:	57                   	push   di
    293a:	9a 43 29 89 2a       	call   0x2a89:0x2943
    293f:	c9                   	leave
    2940:	ca 08 00             	retf   0x8
    2943:	c8 1e 01 00          	enter  0x11e,0x0
    2947:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    294a:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    294e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2951:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2956:	06                   	push   es
    2957:	57                   	push   di
    2958:	9a 5d 22 dd 29       	call   0x29dd:0x225d
    295d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2960:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2964:	25 01 00             	and    ax,0x1
    2967:	09 c0                	or     ax,ax
    2969:	b0 00                	mov    al,0x0
    296b:	74 01                	je     0x296e
    296d:	40                   	inc    ax
    296e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2971:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2975:	25 10 00             	and    ax,0x10
    2978:	09 c0                	or     ax,ax
    297a:	b0 00                	mov    al,0x0
    297c:	74 01                	je     0x297f
    297e:	40                   	inc    ax
    297f:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    2982:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2985:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    298a:	75 06                	jne    0x2992
    298c:	c6 46 fc 01          	mov    BYTE PTR [bp-0x4],0x1
    2990:	eb 10                	jmp    0x29a2
    2992:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2996:	74 06                	je     0x299e
    2998:	c6 46 fc 02          	mov    BYTE PTR [bp-0x4],0x2
    299c:	eb 04                	jmp    0x29a2
    299e:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
    29a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a5:	26 80 bd e8 00 00    	cmp    BYTE PTR es:[di+0xe8],0x0
    29ab:	75 07                	jne    0x29b4
    29ad:	80 3e 0c 2c 00       	cmp    BYTE PTR ds:0x2c0c,0x0
    29b2:	75 0f                	jne    0x29c3
    29b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b7:	26 80 bd e8 00 02    	cmp    BYTE PTR es:[di+0xe8],0x2
    29bd:	74 04                	je     0x29c3
    29bf:	b0 00                	mov    al,0x0
    29c1:	eb 02                	jmp    0x29c5
    29c3:	b0 01                	mov    al,0x1
    29c5:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    29c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29cb:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    29cf:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    29d3:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    29d8:	06                   	push   es
    29d9:	57                   	push   di
    29da:	9a 99 20 09 2a       	call   0x2a09:0x2099
    29df:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    29e3:	74 3d                	je     0x2a22
    29e5:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    29e9:	75 0b                	jne    0x29f6
    29eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ee:	26 80 bd ef 00 00    	cmp    BYTE PTR es:[di+0xef],0x0
    29f4:	74 17                	je     0x2a0d
    29f6:	6a 01                	push   0x1
    29f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29fb:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2a00:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2a04:	06                   	push   es
    2a05:	57                   	push   di
    2a06:	9a 33 12 20 2a       	call   0x2a20:0x1233
    2a0b:	eb 15                	jmp    0x2a22
    2a0d:	6a 00                	push   0x0
    2a0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a12:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2a17:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2a1b:	06                   	push   es
    2a1c:	57                   	push   di
    2a1d:	9a 33 12 0c 2b       	call   0x2b0c:0x1233
    2a22:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    2a26:	74 07                	je     0x2a2f
    2a28:	c7 46 ea 01 00       	mov    WORD PTR [bp-0x16],0x1
    2a2d:	eb 05                	jmp    0x2a34
    2a2f:	c7 46 ea 02 00       	mov    WORD PTR [bp-0x16],0x2
    2a34:	8d 7e da             	lea    di,[bp-0x26]
    2a37:	16                   	push   ss
    2a38:	57                   	push   di
    2a39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a3c:	26 ff b5 e2 00       	push   WORD PTR es:[di+0xe2]
    2a41:	26 ff b5 e0 00       	push   WORD PTR es:[di+0xe0]
    2a46:	8d 7e e2             	lea    di,[bp-0x1e]
    2a49:	16                   	push   ss
    2a4a:	57                   	push   di
    2a4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4e:	06                   	push   es
    2a4f:	57                   	push   di
    2a50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a53:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    2a57:	ff 76 ea             	push   WORD PTR [bp-0x16]
    2a5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a5d:	26 8a 85 e8 00       	mov    al,BYTE PTR es:[di+0xe8]
    2a62:	50                   	push   ax
    2a63:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    2a67:	b0 00                	mov    al,0x0
    2a69:	75 01                	jne    0x2a6c
    2a6b:	40                   	inc    ax
    2a6c:	50                   	push   ax
    2a6d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2a70:	50                   	push   ax
    2a71:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    2a75:	75 0c                	jne    0x2a83
    2a77:	26 80 bd ef 00 00    	cmp    BYTE PTR es:[di+0xef],0x0
    2a7d:	75 04                	jne    0x2a83
    2a7f:	b0 00                	mov    al,0x0
    2a81:	eb 02                	jmp    0x2a85
    2a83:	b0 01                	mov    al,0x1
    2a85:	50                   	push   ax
    2a86:	9a e1 07 e0 2a       	call   0x2ae0:0x7e1
    2a8b:	8d 7e f4             	lea    di,[bp-0xc]
    2a8e:	16                   	push   ss
    2a8f:	57                   	push   di
    2a90:	6a 08                	push   0x8
    2a92:	9a 1b 16 ec 2a       	call   0x2aec:0x161b
    2a97:	8d be e2 fe          	lea    di,[bp-0x11e]
    2a9b:	16                   	push   ss
    2a9c:	57                   	push   di
    2a9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa0:	26 ff b5 e2 00       	push   WORD PTR es:[di+0xe2]
    2aa5:	26 ff b5 e0 00       	push   WORD PTR es:[di+0xe0]
    2aaa:	8d 7e f4             	lea    di,[bp-0xc]
    2aad:	16                   	push   ss
    2aae:	57                   	push   di
    2aaf:	8d be ea fe          	lea    di,[bp-0x116]
    2ab3:	16                   	push   ss
    2ab4:	57                   	push   di
    2ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ab8:	06                   	push   es
    2ab9:	57                   	push   di
    2aba:	9a 53 1d 9d 2b       	call   0x2b9d:0x1d53
    2abf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac2:	26 8a 85 ea 00       	mov    al,BYTE PTR es:[di+0xea]
    2ac7:	50                   	push   ax
    2ac8:	26 ff b5 ed 00       	push   WORD PTR es:[di+0xed]
    2acd:	26 ff b5 eb 00       	push   WORD PTR es:[di+0xeb]
    2ad2:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    2ad5:	50                   	push   ax
    2ad6:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2adb:	06                   	push   es
    2adc:	57                   	push   di
    2add:	9a b6 1d 01 2c       	call   0x2c01:0x1db6
    2ae2:	8d 7e ec             	lea    di,[bp-0x14]
    2ae5:	16                   	push   ss
    2ae6:	57                   	push   di
    2ae7:	6a 08                	push   0x8
    2ae9:	9a 1b 16 23 2b       	call   0x2b23:0x161b
    2aee:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    2af2:	75 03                	jne    0x2af7
    2af4:	e9 80 00             	jmp    0x2b77
    2af7:	6a ff                	push   0xffff
    2af9:	6a f0                	push   0xfff0
    2afb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afe:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2b03:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2b07:	06                   	push   es
    2b08:	57                   	push   di
    2b09:	9a 84 16 6a 2b       	call   0x2b6a:0x1684
    2b0e:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    2b12:	74 11                	je     0x2b25
    2b14:	8d 7e f4             	lea    di,[bp-0xc]
    2b17:	16                   	push   ss
    2b18:	57                   	push   di
    2b19:	8d 7e ec             	lea    di,[bp-0x14]
    2b1c:	16                   	push   ss
    2b1d:	57                   	push   di
    2b1e:	6a 08                	push   0x8
    2b20:	9a 1b 16 2c 2c       	call   0x2c2c:0x161b
    2b25:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    2b29:	74 24                	je     0x2b4f
    2b2b:	8d 7e ec             	lea    di,[bp-0x14]
    2b2e:	16                   	push   ss
    2b2f:	57                   	push   di
    2b30:	6a fe                	push   0xfffe
    2b32:	6a fe                	push   0xfffe
    2b34:	9a 59 2b 00 00       	call   0x0:0x2b59
    2b39:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2b3d:	74 0e                	je     0x2b4d
    2b3f:	8d 7e ec             	lea    di,[bp-0x14]
    2b42:	16                   	push   ss
    2b43:	57                   	push   di
    2b44:	6a ff                	push   0xffff
    2b46:	6a ff                	push   0xffff
    2b48:	9a ff ff 00 00       	call   0x0:0xffff
    2b4d:	eb 0e                	jmp    0x2b5d
    2b4f:	8d 7e ec             	lea    di,[bp-0x14]
    2b52:	16                   	push   ss
    2b53:	57                   	push   di
    2b54:	6a 01                	push   0x1
    2b56:	6a 01                	push   0x1
    2b58:	9a ff ff 00 00       	call   0x0:0xffff
    2b5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b60:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2b65:	06                   	push   es
    2b66:	57                   	push   di
    2b67:	9a d2 21 86 2b       	call   0x2b86:0x21d2
    2b6c:	50                   	push   ax
    2b6d:	8d 7e ec             	lea    di,[bp-0x14]
    2b70:	16                   	push   ss
    2b71:	57                   	push   di
    2b72:	9a ff ff 00 00       	call   0x0:0xffff
    2b77:	6a 00                	push   0x0
    2b79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b7c:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2b81:	06                   	push   es
    2b82:	57                   	push   di
    2b83:	9a 5d 22 0c 2c       	call   0x2c0c:0x225d
    2b88:	c9                   	leave
    2b89:	ca 08 00             	retf   0x8
    2b8c:	55                   	push   bp
    2b8d:	89 e5                	mov    bp,sp
    2b8f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b92:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b98:	06                   	push   es
    2b99:	57                   	push   di
    2b9a:	9a 3a 57 c0 2b       	call   0x2bc0:0x573a
    2b9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ba2:	06                   	push   es
    2ba3:	57                   	push   di
    2ba4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ba7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2bab:	c9                   	leave
    2bac:	ca 08 00             	retf   0x8
    2baf:	55                   	push   bp
    2bb0:	89 e5                	mov    bp,sp
    2bb2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2bb5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2bb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bbb:	06                   	push   es
    2bbc:	57                   	push   di
    2bbd:	9a b3 56 ef 2b       	call   0x2bef:0x56b3
    2bc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc5:	06                   	push   es
    2bc6:	57                   	push   di
    2bc7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bca:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2bce:	c9                   	leave
    2bcf:	ca 08 00             	retf   0x8
    2bd2:	55                   	push   bp
    2bd3:	89 e5                	mov    bp,sp
    2bd5:	68 01 02             	push   0x201
    2bd8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2bdb:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2bdf:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2be3:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2be7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bea:	06                   	push   es
    2beb:	57                   	push   di
    2bec:	9a bb 24 37 2d       	call   0x2d37:0x24bb
    2bf1:	c9                   	leave
    2bf2:	ca 08 00             	retf   0x8
    2bf5:	c8 02 00 00          	enter  0x2,0x0
    2bf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bfc:	06                   	push   es
    2bfd:	57                   	push   di
    2bfe:	9a 55 2c 3d 2c       	call   0x2c3d:0x2c55
    2c03:	89 c7                	mov    di,ax
    2c05:	8e c2                	mov    es,dx
    2c07:	06                   	push   es
    2c08:	57                   	push   di
    2c09:	9a 0d 5b 25 2c       	call   0x2c25:0x5b0d
    2c0e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2c11:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c14:	c9                   	leave
    2c15:	ca 04 00             	retf   0x4
    2c18:	55                   	push   bp
    2c19:	89 e5                	mov    bp,sp
    2c1b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c1e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c21:	bf 3f 08             	mov    di,0x83f
    2c24:	b8 ff ff             	mov    ax,0xffff
    2c27:	50                   	push   ax
    2c28:	57                   	push   di
    2c29:	9a 73 22 97 2f       	call   0x2f97:0x2273
    2c2e:	52                   	push   dx
    2c2f:	50                   	push   ax
    2c30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c33:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2c38:	06                   	push   es
    2c39:	57                   	push   di
    2c3a:	9a ff 12 98 2c       	call   0x2c98:0x12ff
    2c3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c42:	26 c6 85 f0 00 01    	mov    BYTE PTR es:[di+0xf0],0x1
    2c48:	06                   	push   es
    2c49:	57                   	push   di
    2c4a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c4d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c51:	c9                   	leave
    2c52:	ca 08 00             	retf   0x8
    2c55:	c8 04 00 00          	enter  0x4,0x0
    2c59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c5c:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2c61:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2c65:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    2c69:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c6c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2c6f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c72:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2c75:	c9                   	leave
    2c76:	ca 04 00             	retf   0x4
    2c79:	55                   	push   bp
    2c7a:	89 e5                	mov    bp,sp
    2c7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c7f:	06                   	push   es
    2c80:	57                   	push   di
    2c81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c84:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c88:	c9                   	leave
    2c89:	ca 08 00             	retf   0x8
    2c8c:	c8 02 00 00          	enter  0x2,0x0
    2c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c93:	06                   	push   es
    2c94:	57                   	push   di
    2c95:	9a 1c 2e a7 2d       	call   0x2da7:0x2e1c
    2c9a:	08 c0                	or     al,al
    2c9c:	b0 00                	mov    al,0x0
    2c9e:	75 01                	jne    0x2ca1
    2ca0:	40                   	inc    ax
    2ca1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2ca4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2ca7:	c9                   	leave
    2ca8:	ca 04 00             	retf   0x4
    2cab:	55                   	push   bp
    2cac:	89 e5                	mov    bp,sp
    2cae:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2cb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb4:	26 3a 85 e8 00       	cmp    al,BYTE PTR es:[di+0xe8]
    2cb9:	74 11                	je     0x2ccc
    2cbb:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2cbe:	26 88 85 e8 00       	mov    BYTE PTR es:[di+0xe8],al
    2cc3:	06                   	push   es
    2cc4:	57                   	push   di
    2cc5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cc8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2ccc:	c9                   	leave
    2ccd:	ca 06 00             	retf   0x6
    2cd0:	c8 00 02 00          	enter  0x200,0x0
    2cd4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cda:	26 3a 85 e9 00       	cmp    al,BYTE PTR es:[di+0xe9]
    2cdf:	75 03                	jne    0x2ce4
    2ce1:	e9 ee 00             	jmp    0x2dd2
    2ce4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2ce8:	75 03                	jne    0x2ced
    2cea:	e9 d1 00             	jmp    0x2dbe
    2ced:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2cf0:	3c 01                	cmp    al,0x1
    2cf2:	74 08                	je     0x2cfc
    2cf4:	3c 04                	cmp    al,0x4
    2cf6:	74 04                	je     0x2cfc
    2cf8:	b0 00                	mov    al,0x0
    2cfa:	eb 02                	jmp    0x2cfe
    2cfc:	b0 01                	mov    al,0x1
    2cfe:	50                   	push   ax
    2cff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d02:	06                   	push   es
    2d03:	57                   	push   di
    2d04:	9a bc 6a ff ff       	call   0xffff:0x6abc
    2d09:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d0c:	3c 02                	cmp    al,0x2
    2d0e:	74 08                	je     0x2d18
    2d10:	3c 05                	cmp    al,0x5
    2d12:	74 04                	je     0x2d18
    2d14:	b0 00                	mov    al,0x0
    2d16:	eb 02                	jmp    0x2d1a
    2d18:	b0 01                	mov    al,0x1
    2d1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d1d:	26 88 85 db 00       	mov    BYTE PTR es:[di+0xdb],al
    2d22:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    2d27:	74 1a                	je     0x2d43
    2d29:	8d be 00 ff          	lea    di,[bp-0x100]
    2d2d:	16                   	push   ss
    2d2e:	57                   	push   di
    2d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d32:	06                   	push   es
    2d33:	57                   	push   di
    2d34:	9a 53 1d 7b 2d       	call   0x2d7b:0x1d53
    2d39:	83 c4 04             	add    sp,0x4
    2d3c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2d41:	74 0a                	je     0x2d4d
    2d43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d46:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    2d4b:	75 30                	jne    0x2d7d
    2d4d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d50:	98                   	cbw
    2d51:	8b f8                	mov    di,ax
    2d53:	d1 e7                	shl    di,1
    2d55:	83 bd 24 0e 00       	cmp    WORD PTR [di+0xe24],0x0
    2d5a:	76 21                	jbe    0x2d7d
    2d5c:	8d be 00 fe          	lea    di,[bp-0x200]
    2d60:	16                   	push   ss
    2d61:	57                   	push   di
    2d62:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d65:	98                   	cbw
    2d66:	8b f8                	mov    di,ax
    2d68:	d1 e7                	shl    di,1
    2d6a:	ff b5 24 0e          	push   WORD PTR [di+0xe24]
    2d6e:	9a 2b 09 04 2e       	call   0x2e04:0x92b
    2d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d76:	06                   	push   es
    2d77:	57                   	push   di
    2d78:	9a 8c 1d e8 2d       	call   0x2de8:0x1d8c
    2d7d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d80:	98                   	cbw
    2d81:	8b f8                	mov    di,ax
    2d83:	d1 e7                	shl    di,1
    2d85:	8b 85 3a 0e          	mov    ax,WORD PTR [di+0xe3a]
    2d89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d8c:	26 89 85 de 00       	mov    WORD PTR es:[di+0xde],ax
    2d91:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d94:	50                   	push   ax
    2d95:	e8 d7 dc             	call   0xa6f
    2d98:	52                   	push   dx
    2d99:	50                   	push   ax
    2d9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d9d:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2da2:	06                   	push   es
    2da3:	57                   	push   di
    2da4:	9a ff 12 b3 2d       	call   0x2db3:0x12ff
    2da9:	6a 02                	push   0x2
    2dab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dae:	06                   	push   es
    2daf:	57                   	push   di
    2db0:	9a db 2e 16 2f       	call   0x2f16:0x2edb
    2db5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db8:	26 c6 85 f0 00 00    	mov    BYTE PTR es:[di+0xf0],0x0
    2dbe:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2dc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dc4:	26 88 85 e9 00       	mov    BYTE PTR es:[di+0xe9],al
    2dc9:	06                   	push   es
    2dca:	57                   	push   di
    2dcb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dce:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2dd2:	c9                   	leave
    2dd3:	ca 06 00             	retf   0x6
    2dd6:	c8 02 02 00          	enter  0x202,0x0
    2dda:	8d be fe fe          	lea    di,[bp-0x102]
    2dde:	16                   	push   ss
    2ddf:	57                   	push   di
    2de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de3:	06                   	push   es
    2de4:	57                   	push   di
    2de5:	9a 53 1d ff ff       	call   0xffff:0x1d53
    2dea:	8d be fe fd          	lea    di,[bp-0x202]
    2dee:	16                   	push   ss
    2def:	57                   	push   di
    2df0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df3:	26 8a 85 e9 00       	mov    al,BYTE PTR es:[di+0xe9]
    2df8:	98                   	cbw
    2df9:	8b f8                	mov    di,ax
    2dfb:	d1 e7                	shl    di,1
    2dfd:	ff b5 24 0e          	push   WORD PTR [di+0xe24]
    2e01:	9a 2b 09 09 2e       	call   0x2e09:0x92b
    2e06:	9a 01 07 bd 2f       	call   0x2fbd:0x701
    2e0b:	09 c0                	or     ax,ax
    2e0d:	b0 00                	mov    al,0x0
    2e0f:	74 01                	je     0x2e12
    2e11:	40                   	inc    ax
    2e12:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2e15:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e18:	c9                   	leave
    2e19:	ca 04 00             	retf   0x4
    2e1c:	c8 02 00 00          	enter  0x2,0x0
    2e20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e23:	26 80 bd e9 00 00    	cmp    BYTE PTR es:[di+0xe9],0x0
    2e29:	74 5f                	je     0x2e8a
    2e2b:	26 8a 85 e9 00       	mov    al,BYTE PTR es:[di+0xe9]
    2e30:	3c 01                	cmp    al,0x1
    2e32:	74 04                	je     0x2e38
    2e34:	3c 04                	cmp    al,0x4
    2e36:	75 0b                	jne    0x2e43
    2e38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e3b:	26 80 bd da 00 00    	cmp    BYTE PTR es:[di+0xda],0x0
    2e41:	74 3e                	je     0x2e81
    2e43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e46:	26 8a 85 e9 00       	mov    al,BYTE PTR es:[di+0xe9]
    2e4b:	3c 02                	cmp    al,0x2
    2e4d:	74 04                	je     0x2e53
    2e4f:	3c 05                	cmp    al,0x5
    2e51:	75 0b                	jne    0x2e5e
    2e53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e56:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    2e5c:	74 23                	je     0x2e81
    2e5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e61:	26 8a 85 e9 00       	mov    al,BYTE PTR es:[di+0xe9]
    2e66:	98                   	cbw
    2e67:	8b f8                	mov    di,ax
    2e69:	d1 e7                	shl    di,1
    2e6b:	8b 85 3a 0e          	mov    ax,WORD PTR [di+0xe3a]
    2e6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e72:	26 3b 85 de 00       	cmp    ax,WORD PTR es:[di+0xde]
    2e77:	75 08                	jne    0x2e81
    2e79:	26 80 bd f0 00 00    	cmp    BYTE PTR es:[di+0xf0],0x0
    2e7f:	74 09                	je     0x2e8a
    2e81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e84:	26 c6 85 e9 00 00    	mov    BYTE PTR es:[di+0xe9],0x0
    2e8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e8d:	26 8a 85 e9 00       	mov    al,BYTE PTR es:[di+0xe9]
    2e92:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2e95:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e98:	c9                   	leave
    2e99:	ca 04 00             	retf   0x4
    2e9c:	55                   	push   bp
    2e9d:	89 e5                	mov    bp,sp
    2e9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea2:	26 8a 85 ea 00       	mov    al,BYTE PTR es:[di+0xea]
    2ea7:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2eaa:	74 11                	je     0x2ebd
    2eac:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2eaf:	26 88 85 ea 00       	mov    BYTE PTR es:[di+0xea],al
    2eb4:	06                   	push   es
    2eb5:	57                   	push   di
    2eb6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2eb9:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2ebd:	c9                   	leave
    2ebe:	ca 06 00             	retf   0x6
    2ec1:	c8 02 00 00          	enter  0x2,0x0
    2ec5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec8:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2ecd:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    2ed1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2ed4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2ed7:	c9                   	leave
    2ed8:	ca 04 00             	retf   0x4
    2edb:	55                   	push   bp
    2edc:	89 e5                	mov    bp,sp
    2ede:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2ee2:	7d 06                	jge    0x2eea
    2ee4:	c6 46 0a 01          	mov    BYTE PTR [bp+0xa],0x1
    2ee8:	eb 0a                	jmp    0x2ef4
    2eea:	80 7e 0a 04          	cmp    BYTE PTR [bp+0xa],0x4
    2eee:	7e 04                	jle    0x2ef4
    2ef0:	c6 46 0a 04          	mov    BYTE PTR [bp+0xa],0x4
    2ef4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ef7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2efa:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2eff:	26 3a 45 18          	cmp    al,BYTE PTR es:[di+0x18]
    2f03:	74 1f                	je     0x2f24
    2f05:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f08:	50                   	push   ax
    2f09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f0c:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    2f11:	06                   	push   es
    2f12:	57                   	push   di
    2f13:	9a b2 13 b6 2f       	call   0x2fb6:0x13b2
    2f18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f1b:	06                   	push   es
    2f1c:	57                   	push   di
    2f1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f20:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2f24:	c9                   	leave
    2f25:	ca 06 00             	retf   0x6
    2f28:	55                   	push   bp
    2f29:	89 e5                	mov    bp,sp
    2f2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f2e:	26 8b 85 eb 00       	mov    ax,WORD PTR es:[di+0xeb]
    2f33:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2f36:	74 11                	je     0x2f49
    2f38:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2f3b:	26 89 85 eb 00       	mov    WORD PTR es:[di+0xeb],ax
    2f40:	06                   	push   es
    2f41:	57                   	push   di
    2f42:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f45:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2f49:	c9                   	leave
    2f4a:	ca 06 00             	retf   0x6
    2f4d:	55                   	push   bp
    2f4e:	89 e5                	mov    bp,sp
    2f50:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2f53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f56:	26 3b 85 ed 00       	cmp    ax,WORD PTR es:[di+0xed]
    2f5b:	74 17                	je     0x2f74
    2f5d:	83 7e 0a ff          	cmp    WORD PTR [bp+0xa],0xffff
    2f61:	7c 11                	jl     0x2f74
    2f63:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2f66:	26 89 85 ed 00       	mov    WORD PTR es:[di+0xed],ax
    2f6b:	06                   	push   es
    2f6c:	57                   	push   di
    2f6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f70:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2f74:	c9                   	leave
    2f75:	ca 06 00             	retf   0x6
    2f78:	c8 02 00 00          	enter  0x2,0x0
    2f7c:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2f80:	eb 03                	jmp    0x2f85
    2f82:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    2f85:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2f88:	98                   	cbw
    2f89:	8b f8                	mov    di,ax
    2f8b:	c1 e7 02             	shl    di,0x2
    2f8e:	c4 bd e0 2a          	les    di,DWORD PTR [di+0x2ae0]
    2f92:	06                   	push   es
    2f93:	57                   	push   di
    2f94:	9a 7f 1f b0 2f       	call   0x2fb0:0x1f7f
    2f99:	80 7e ff 0a          	cmp    BYTE PTR [bp-0x1],0xa
    2f9d:	75 e3                	jne    0x2f82
    2f9f:	c9                   	leave
    2fa0:	cb                   	retf
    2fa1:	55                   	push   bp
    2fa2:	89 e5                	mov    bp,sp
    2fa4:	bf e0 2a             	mov    di,0x2ae0
    2fa7:	1e                   	push   ds
    2fa8:	57                   	push   di
    2fa9:	6a 2c                	push   0x2c
    2fab:	6a 00                	push   0x0
    2fad:	9a e5 1e ff ff       	call   0xffff:0x1ee5
    2fb2:	bf 78 2f             	mov    di,0x2f78
    2fb5:	b8 ff ff             	mov    ax,0xffff
    2fb8:	50                   	push   ax
    2fb9:	57                   	push   di
    2fba:	9a 74 05 ff ff       	call   0xffff:0x574
    2fbf:	c9                   	leave
    2fc0:	cb                   	retf
