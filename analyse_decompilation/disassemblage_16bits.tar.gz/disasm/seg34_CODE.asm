; ================================================================
; seg34_CODE  (14900 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	22 00                	and    al,BYTE PTR [bx+si]
       2:	64 00 00             	add    BYTE PTR fs:[bx+si],al
       5:	00 00                	add    BYTE PTR [bx+si],al
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 56 00             	add    BYTE PTR [bp+0x0],dl
       c:	1f                   	pop    ds
       d:	00 da                	add    dl,bl
       f:	05 79 00             	add    ax,0x79
      12:	64 20 89 00 9a       	and    BYTE PTR fs:[bx+di-0x6600],cl
      17:	1f                   	pop    ds
      18:	14 00                	adc    al,0x0
      1a:	cb                   	retf
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	2b 4c 24             	sub    cx,WORD PTR [si+0x24]
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 6e 4f             	add    BYTE PTR [bp+0x4f],ch
      28:	30 00                	xor    BYTE PTR [bx+si],al
      2a:	fa                   	cli
      2b:	10 10                	adc    BYTE PTR [bx+si],dl
      2d:	00 e5                	add    ch,ah
      2f:	4f                   	dec    di
      30:	34 00                	xor    al,0x0
      32:	f4                   	hlt
      33:	4f                   	dec    di
      34:	38 00                	cmp    BYTE PTR [bx+si],al
      36:	05 4f 3c             	add    ax,0x3c4f
      39:	00 03                	add    BYTE PTR [bp+di],al
      3b:	50                   	push   ax
      3c:	40                   	inc    ax
      3d:	00 46 51             	add    BYTE PTR [bp+0x51],al
      40:	44                   	inc    sp
      41:	00 38                	add    BYTE PTR [bx+si],bh
      43:	50                   	push   ax
      44:	48                   	dec    ax
      45:	00 1a                	add    BYTE PTR [bp+si],bl
      47:	50                   	push   ax
      48:	4c                   	dec    sp
      49:	00 21                	add    BYTE PTR [bx+di],ah
      4b:	50                   	push   ax
      4c:	20 00                	and    BYTE PTR [bx+si],al
      4e:	de 20                	fisub  WORD PTR [bx+si]
      50:	75 00                	jne    0x52
      52:	21 21                	and    WORD PTR [bx+di],sp
      54:	50                   	push   ax
      55:	00 0d                	add    BYTE PTR [di],cl
      57:	54                   	push   sp
      58:	43                   	inc    bx
      59:	6f                   	outs   dx,WORD PTR ds:[si]
      5a:	6d                   	ins    WORD PTR es:[di],dx
      5b:	6d                   	ins    WORD PTR es:[di],dx
      5c:	6f                   	outs   dx,WORD PTR ds:[si]
      5d:	6e                   	outs   dx,BYTE PTR ds:[si]
      5e:	44                   	inc    sp
      5f:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
      64:	07                   	pop    es
      65:	0d 54 43             	or     ax,0x4354
      68:	6f                   	outs   dx,WORD PTR ds:[si]
      69:	6d                   	ins    WORD PTR es:[di],dx
      6a:	6d                   	ins    WORD PTR es:[di],dx
      6b:	6f                   	outs   dx,WORD PTR ds:[si]
      6c:	6e                   	outs   dx,BYTE PTR ds:[si]
      6d:	44                   	inc    sp
      6e:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
      73:	22 00                	and    al,BYTE PTR [bx+si]
      75:	e1 00                	loope  0x77
      77:	15 06 a7             	adc    ax,0xa706
      7a:	00 04                	add    BYTE PTR [si],al
      7c:	00 07                	add    BYTE PTR [bx],al
      7e:	44                   	inc    sp
      7f:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
      84:	73 02                	jae    0x88
      86:	00 07                	add    BYTE PTR [bx],al
      88:	23 2e 02 1a          	and    bp,WORD PTR ds:0x1a02
      8c:	00 ff                	add    bh,bh
      8e:	ff 1a                	call   DWORD PTR [bp+si]
      90:	00 ff                	add    bh,bh
      92:	ff 01                	inc    WORD PTR [bx+di]
      94:	00 00                	add    BYTE PTR [bx+si],al
      96:	00 00                	add    BYTE PTR [bx+si],al
      98:	80 01 00             	add    BYTE PTR [bx+di],0x0
      9b:	00 00                	add    BYTE PTR [bx+si],al
      9d:	02 00                	add    al,BYTE PTR [bx+si]
      9f:	05 43 74             	add    ax,0x7443
      a2:	6c                   	ins    BYTE PTR es:[di],dx
      a3:	33 44 5a             	xor    ax,WORD PTR [si+0x5a]
      a6:	00 c7                	add    bh,al
      a8:	02 1b                	add    bl,BYTE PTR [bp+di]
      aa:	00 ff                	add    bh,bh
      ac:	ff 1b                	call   DWORD PTR [bp+di]
      ae:	00 ff                	add    bh,bh
      b0:	ff 01                	inc    WORD PTR [bx+di]
      b2:	00 00                	add    BYTE PTR [bx+si],al
      b4:	00 00                	add    BYTE PTR [bx+si],al
      b6:	80 00 00             	add    BYTE PTR [bx+si],0x0
      b9:	00 00                	add    BYTE PTR [bx+si],al
      bb:	03 00                	add    ax,WORD PTR [bx+si]
      bd:	0b 48 65             	or     cx,WORD PTR [bx+si+0x65]
      c0:	6c                   	ins    BYTE PTR es:[di],dx
      c1:	70 43                	jo     0x106
      c3:	6f                   	outs   dx,WORD PTR ds:[si]
      c4:	6e                   	outs   dx,BYTE PTR ds:[si]
      c5:	74 65                	je     0x12c
      c7:	78 74                	js     0x13d
      c9:	03 0b                	add    cx,WORD PTR [bp+di]
      cb:	54                   	push   sp
      cc:	4f                   	dec    di
      cd:	70 65                	jo     0x134
      cf:	6e                   	outs   dx,BYTE PTR ds:[si]
      d0:	4f                   	dec    di
      d1:	70 74                	jo     0x147
      d3:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
      d8:	00 00                	add    BYTE PTR [bx+si],al
      da:	00 0d                	add    BYTE PTR [di],cl
      dc:	00 00                	add    BYTE PTR [bx+si],al
      de:	00 c9                	add    cl,cl
      e0:	00 d0                	add    al,dl
      e2:	01 0a                	add    WORD PTR [bp+si],cx
      e4:	6f                   	outs   dx,WORD PTR ds:[si]
      e5:	66 52                	push   edx
      e7:	65 61                	gs popa
      e9:	64 4f                	fs dec di
      eb:	6e                   	outs   dx,BYTE PTR ds:[si]
      ec:	6c                   	ins    BYTE PTR es:[di],dx
      ed:	79 11                	jns    0x100
      ef:	6f                   	outs   dx,WORD PTR ds:[si]
      f0:	66 4f                	dec    edi
      f2:	76 65                	jbe    0x159
      f4:	72 77                	jb     0x16d
      f6:	72 69                	jb     0x161
      f8:	74 65                	je     0x15f
      fa:	50                   	push   ax
      fb:	72 6f                	jb     0x16c
      fd:	6d                   	ins    WORD PTR es:[di],dx
      fe:	70 74                	jo     0x174
     100:	0e                   	push   cs
     101:	6f                   	outs   dx,WORD PTR ds:[si]
     102:	66 48                	dec    eax
     104:	69 64 65 52 65       	imul   sp,WORD PTR [si+0x65],0x6552
     109:	61                   	popa
     10a:	64 4f                	fs dec di
     10c:	6e                   	outs   dx,BYTE PTR ds:[si]
     10d:	6c                   	ins    BYTE PTR es:[di],dx
     10e:	79 0d                	jns    0x11d
     110:	6f                   	outs   dx,WORD PTR ds:[si]
     111:	66 4e                	dec    esi
     113:	6f                   	outs   dx,WORD PTR ds:[si]
     114:	43                   	inc    bx
     115:	68 61 6e             	push   0x6e61
     118:	67 65 44             	addr32 gs inc sp
     11b:	69 72 0a 6f 66       	imul   si,WORD PTR [bp+si+0xa],0x666f
     120:	53                   	push   bx
     121:	68 6f 77             	push   0x776f
     124:	48                   	dec    ax
     125:	65 6c                	gs ins BYTE PTR es:[di],dx
     127:	70 0c                	jo     0x135
     129:	6f                   	outs   dx,WORD PTR ds:[si]
     12a:	66 4e                	dec    esi
     12c:	6f                   	outs   dx,WORD PTR ds:[si]
     12d:	56                   	push   si
     12e:	61                   	popa
     12f:	6c                   	ins    BYTE PTR es:[di],dx
     130:	69 64 61 74 65       	imul   sp,WORD PTR [si+0x61],0x6574
     135:	12 6f 66             	adc    ch,BYTE PTR [bx+0x66]
     138:	41                   	inc    cx
     139:	6c                   	ins    BYTE PTR es:[di],dx
     13a:	6c                   	ins    BYTE PTR es:[di],dx
     13b:	6f                   	outs   dx,WORD PTR ds:[si]
     13c:	77 4d                	ja     0x18b
     13e:	75 6c                	jne    0x1ac
     140:	74 69                	je     0x1ab
     142:	53                   	push   bx
     143:	65 6c                	gs ins BYTE PTR es:[di],dx
     145:	65 63 74 14          	arpl   WORD PTR gs:[si+0x14],si
     149:	6f                   	outs   dx,WORD PTR ds:[si]
     14a:	66 45                	inc    ebp
     14c:	78 74                	js     0x1c2
     14e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     150:	73 69                	jae    0x1bb
     152:	6f                   	outs   dx,WORD PTR ds:[si]
     153:	6e                   	outs   dx,BYTE PTR ds:[si]
     154:	44                   	inc    sp
     155:	69 66 66 65 72       	imul   sp,WORD PTR [bp+0x66],0x7265
     15a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     15c:	74 0f                	je     0x16d
     15e:	6f                   	outs   dx,WORD PTR ds:[si]
     15f:	66 50                	push   eax
     161:	61                   	popa
     162:	74 68                	je     0x1cc
     164:	4d                   	dec    bp
     165:	75 73                	jne    0x1da
     167:	74 45                	je     0x1ae
     169:	78 69                	js     0x1d4
     16b:	73 74                	jae    0x1e1
     16d:	0f 6f 66 46          	movq   mm4,QWORD PTR [bp+0x46]
     171:	69 6c 65 4d 75       	imul   bp,WORD PTR [si+0x65],0x754d
     176:	73 74                	jae    0x1ec
     178:	45                   	inc    bp
     179:	78 69                	js     0x1e4
     17b:	73 74                	jae    0x1f1
     17d:	0e                   	push   cs
     17e:	6f                   	outs   dx,WORD PTR ds:[si]
     17f:	66 43                	inc    ebx
     181:	72 65                	jb     0x1e8
     183:	61                   	popa
     184:	74 65                	je     0x1eb
     186:	50                   	push   ax
     187:	72 6f                	jb     0x1f8
     189:	6d                   	ins    WORD PTR es:[di],dx
     18a:	70 74                	jo     0x200
     18c:	0c 6f                	or     al,0x6f
     18e:	66 53                	push   ebx
     190:	68 61 72             	push   0x7261
     193:	65 41                	gs inc cx
     195:	77 61                	ja     0x1f8
     197:	72 65                	jb     0x1fe
     199:	12 6f 66             	adc    ch,BYTE PTR [bx+0x66]
     19c:	4e                   	dec    si
     19d:	6f                   	outs   dx,WORD PTR ds:[si]
     19e:	52                   	push   dx
     19f:	65 61                	gs popa
     1a1:	64 4f                	fs dec di
     1a3:	6e                   	outs   dx,BYTE PTR ds:[si]
     1a4:	6c                   	ins    BYTE PTR es:[di],dx
     1a5:	79 52                	jns    0x1f9
     1a7:	65 74 75             	gs je  0x21f
     1aa:	72 6e                	jb     0x21a
     1ac:	12 6f 66             	adc    ch,BYTE PTR [bx+0x66]
     1af:	4e                   	dec    si
     1b0:	6f                   	outs   dx,WORD PTR ds:[si]
     1b1:	54                   	push   sp
     1b2:	65 73 74             	gs jae 0x229
     1b5:	46                   	inc    si
     1b6:	69 6c 65 43 72       	imul   bp,WORD PTR [si+0x65],0x7243
     1bb:	65 61                	gs popa
     1bd:	74 65                	je     0x224
     1bf:	06                   	push   es
     1c0:	0c 54                	or     al,0x54
     1c2:	4f                   	dec    di
     1c3:	70 65                	jo     0x22a
     1c5:	6e                   	outs   dx,BYTE PTR ds:[si]
     1c6:	4f                   	dec    di
     1c7:	70 74                	jo     0x23d
     1c9:	69 6f 6e 73 03       	imul   bp,WORD PTR [bx+0x6e],0x373
     1ce:	c9                   	leave
     1cf:	00 f8                	add    al,bh
     1d1:	01 05                	add    WORD PTR [di],ax
     1d3:	08 54 46             	or     BYTE PTR [si+0x46],dl
     1d6:	69 6c 65 45 78       	imul   bp,WORD PTR [si+0x65],0x7845
     1db:	74 03                	je     0x1e0
     1dd:	03 0e 54 46          	add    cx,WORD PTR ds:0x4654
     1e1:	69 6c 65 45 64       	imul   bp,WORD PTR [si+0x65],0x6445
     1e6:	69 74 53 74 79       	imul   si,WORD PTR [si+0x53],0x7974
     1eb:	6c                   	ins    BYTE PTR es:[di],dx
     1ec:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     1ef:	00 00                	add    BYTE PTR [bx+si],al
     1f1:	00 01                	add    BYTE PTR [bx+di],al
     1f3:	00 00                	add    BYTE PTR [bx+si],al
     1f5:	00 dd                	add    ch,bl
     1f7:	01 2a                	add    WORD PTR [bp+si],bp
     1f9:	02 06 66 73          	add    al,BYTE PTR ds:0x7366
     1fd:	45                   	inc    bp
     1fe:	64 69 74 0a 66 73    	imul   si,WORD PTR fs:[si+0xa],0x7366
     204:	43                   	inc    bx
     205:	6f                   	outs   dx,WORD PTR ds:[si]
     206:	6d                   	ins    WORD PTR es:[di],dx
     207:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     20a:	6f                   	outs   dx,WORD PTR ds:[si]
     20b:	78 00                	js     0x20d
     20d:	00 00                	add    BYTE PTR [bx+si],al
     20f:	00 00                	add    BYTE PTR [bx+si],al
     211:	00 40 02             	add    BYTE PTR [bx+si+0x2],al
     214:	34 02                	xor    al,0x2
     216:	14 00                	adc    al,0x0
     218:	2c 1f                	sub    al,0x1f
     21a:	62 02                	bound  ax,DWORD PTR [bp+si]
     21c:	77 0d                	ja     0x22b
     21e:	32 02                	xor    al,BYTE PTR [bp+si]
     220:	9a 1f 1a 02 cb       	call   0xcb02:0x1a1f
     225:	1f                   	pop    ds
     226:	22 02                	and    al,BYTE PTR [bp+si]
     228:	48                   	dec    ax
     229:	0d 1e 02             	or     ax,0x21e
     22c:	64 20 26 02 6e       	and    BYTE PTR fs:0x6e02,ah
     231:	0e                   	push   cs
     232:	46                   	inc    si
     233:	02 0b                	add    cl,BYTE PTR [bp+di]
     235:	54                   	push   sp
     236:	44                   	inc    sp
     237:	6c                   	ins    BYTE PTR es:[di],dx
     238:	67 43                	addr32 inc bx
     23a:	6f                   	outs   dx,WORD PTR ds:[si]
     23b:	6e                   	outs   dx,BYTE PTR ds:[si]
     23c:	74 72                	je     0x2b0
     23e:	6f                   	outs   dx,WORD PTR ds:[si]
     23f:	6c                   	ins    BYTE PTR es:[di],dx
     240:	01 00                	add    WORD PTR [bx+si],ax
     242:	82 00 84             	add    BYTE PTR [bx+si],0x84
     245:	0e                   	push   cs
     246:	66 02 00             	data32 add al,BYTE PTR [bx+si]
     249:	00 00                	add    BYTE PTR [bx+si],al
     24b:	00 00                	add    BYTE PTR [bx+si],al
     24d:	00 75 02             	add    BYTE PTR [di+0x2],dh
     250:	68 02 2a             	push   0x2a02
     253:	00 2c                	add    BYTE PTR [si],ch
     255:	1f                   	pop    ds
     256:	bb 02 28             	mov    bx,0x2802
     259:	1d 87 02             	sbb    ax,0x287
     25c:	9a 1f 56 02 cb       	call   0xcb02:0x561f
     261:	1f                   	pop    ds
     262:	5e                   	pop    si
     263:	02 1f                	add    bl,BYTE PTR [bx]
     265:	12 5a 02             	adc    bl,BYTE PTR [bp+si+0x2]
     268:	0c 54                	or     al,0x54
     26a:	43                   	inc    bx
     26b:	6f                   	outs   dx,WORD PTR ds:[si]
     26c:	6d                   	ins    WORD PTR es:[di],dx
     26d:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     270:	75 74                	jne    0x2e6
     272:	74 6f                	je     0x2e3
     274:	6e                   	outs   dx,BYTE PTR ds:[si]
     275:	07                   	pop    es
     276:	00 11                	add    BYTE PTR [bx+di],dl
     278:	01 02                	add    WORD PTR [bp+si],ax
     27a:	00 82 00 0f          	add    BYTE PTR [bp+si+0xf00],al
     27e:	00 01                	add    BYTE PTR [bx+di],al
     280:	02 02                	add    al,BYTE PTR [bp+si]
     282:	02 00                	add    al,BYTE PTR [bx+si]
     284:	02 64 15             	add    ah,BYTE PTR [si+0x15]
     287:	8b 02                	mov    ax,WORD PTR [bp+si]
     289:	f1                   	int1
     28a:	15 8f 02             	adc    ax,0x28f
     28d:	28 16 93 02          	sub    BYTE PTR ds:0x293,dl
     291:	56                   	push   si
     292:	16                   	push   ss
     293:	97                   	xchg   di,ax
     294:	02 6d 18             	add    ch,BYTE PTR [di+0x18]
     297:	9b                   	fwait
     298:	02 e2                	add    ah,dl
     29a:	19 9f 02 ca          	sbb    WORD PTR [bx-0x35fe],bx
     29e:	18 ef                	sbb    bh,ch
     2a0:	02 05                	add    al,BYTE PTR [di]
     2a2:	03 00                	add    ax,WORD PTR [bx+si]
     2a4:	00 00                	add    BYTE PTR [bx+si],al
     2a6:	00 00                	add    BYTE PTR [bx+si],al
     2a8:	00 f9                	add    cl,bh
     2aa:	02 91 00 22          	add    dl,BYTE PTR [bx+di+0x2200]
     2ae:	00 14                	add    BYTE PTR [si],dl
     2b0:	03 64 20             	add    sp,WORD PTR [si+0x20]
     2b3:	92                   	xchg   dx,ax
     2b4:	03 9a 1f b3          	add    bx,WORD PTR [bp+si-0x4ce1]
     2b8:	02 cb                	add    cl,bl
     2ba:	1f                   	pop    ds
     2bb:	b7 02                	mov    bh,0x2
     2bd:	3f                   	aas
     2be:	22 f7                	and    dh,bh
     2c0:	02 cd                	add    cl,ch
     2c2:	11 cb                	adc    bx,cx
     2c4:	02 6e 4f             	add    ch,BYTE PTR [bp+0x4f]
     2c7:	cf                   	iret
     2c8:	02 fa                	add    bh,dl
     2ca:	10 f8                	adc    al,bh
     2cc:	03 e5                	add    sp,bp
     2ce:	4f                   	dec    di
     2cf:	d3 02                	rol    WORD PTR [bp+si],cl
     2d1:	f4                   	hlt
     2d2:	4f                   	dec    di
     2d3:	d7                   	xlat   BYTE PTR ds:[bx]
     2d4:	02 05                	add    al,BYTE PTR [di]
     2d6:	4f                   	dec    di
     2d7:	db 02                	fild   DWORD PTR [bp+si]
     2d9:	03 50 df             	add    dx,WORD PTR [bx+si-0x21]
     2dc:	02 46 51             	add    al,BYTE PTR [bp+0x51]
     2df:	e3 02                	jcxz   0x2e3
     2e1:	38 50 e7             	cmp    BYTE PTR [bx+si-0x19],dl
     2e4:	02 1a                	add    bl,BYTE PTR [bp+si]
     2e6:	50                   	push   ax
     2e7:	eb 02                	jmp    0x2eb
     2e9:	21 50 c3             	and    WORD PTR [bx+si-0x3d],dx
     2ec:	02 72 21             	add    dh,BYTE PTR [bp+si+0x21]
     2ef:	bf 02 21             	mov    di,0x2102
     2f2:	21 af 02 75          	and    WORD PTR [bx+0x7502],bp
     2f6:	28 f3                	sub    bl,dh
     2f8:	02 0b                	add    cl,BYTE PTR [bp+di]
     2fa:	54                   	push   sp
     2fb:	4f                   	dec    di
     2fc:	70 65                	jo     0x363
     2fe:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ff:	44                   	inc    sp
     300:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     305:	07                   	pop    es
     306:	0b 54 4f             	or     dx,WORD PTR [si+0x4f]
     309:	70 65                	jo     0x370
     30b:	6e                   	outs   dx,BYTE PTR ds:[si]
     30c:	44                   	inc    sp
     30d:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     312:	c1 02 18             	rol    WORD PTR [bp+si],0x18
     315:	03 64 00             	add    sp,WORD PTR [si+0x0]
     318:	28 03                	sub    BYTE PTR [bp+di],al
     31a:	0d 00 07             	or     ax,0x700
     31d:	44                   	inc    sp
     31e:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     323:	73 09                	jae    0x32e
     325:	00 d2                	add    dl,dl
     327:	01 4b 03             	add    WORD PTR [bp+di+0x3],cx
     32a:	37                   	aaa
     32b:	00 ff                	add    bh,bh
     32d:	ff 37                	push   WORD PTR [bx]
     32f:	00 ff                	add    bh,bh
     331:	ff 01                	inc    WORD PTR [bx+di]
     333:	00 00                	add    BYTE PTR [bx+si],al
     335:	00 00                	add    BYTE PTR [bx+si],al
     337:	80 00 00             	add    BYTE PTR [bx+si],0x0
     33a:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     33e:	0a 44 65             	or     al,BYTE PTR [si+0x65]
     341:	66 61                	popad
     343:	75 6c                	jne    0x3b1
     345:	74 45                	je     0x38c
     347:	78 74                	js     0x3bd
     349:	dd 01                	fld    QWORD PTR [bx+di]
     34b:	96                   	xchg   si,ax
     34c:	03 8f 00 ff          	add    cx,WORD PTR [bx-0x100]
     350:	ff 8f 00 ff          	dec    WORD PTR [bx-0x100]
     354:	ff 01                	inc    WORD PTR [bx+di]
     356:	00 00                	add    BYTE PTR [bx+si],al
     358:	00 00                	add    BYTE PTR [bx+si],al
     35a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     35d:	00 00                	add    BYTE PTR [bx+si],al
     35f:	05 00 0d             	add    ax,0xd00
     362:	46                   	inc    si
     363:	69 6c 65 45 64       	imul   bp,WORD PTR [si+0x65],0x6445
     368:	69 74 53 74 79       	imul   si,WORD PTR [si+0x53],0x7974
     36d:	6c                   	ins    BYTE PTR es:[di],dx
     36e:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
     371:	c7                   	(bad)
     372:	10 3b                	adc    BYTE PTR [bp+di],bh
     374:	00 ff                	add    bh,bh
     376:	ff                   	(bad)
     377:	3b 00                	cmp    ax,WORD PTR [bx+si]
     379:	ff                   	(bad)
     37a:	ff 01                	inc    WORD PTR [bx+di]
     37c:	00 00                	add    BYTE PTR [bx+si],al
     37e:	00 00                	add    BYTE PTR [bx+si],al
     380:	80 00 00             	add    BYTE PTR [bx+si],0x0
     383:	00 80 06 00          	add    BYTE PTR [bx+si+0x6],al
     387:	08 46 69             	or     BYTE PTR [bp+0x69],al
     38a:	6c                   	ins    BYTE PTR es:[di],dx
     38b:	65 4e                	gs dec si
     38d:	61                   	popa
     38e:	6d                   	ins    WORD PTR es:[di],dx
     38f:	65 62 23             	bound  sp,DWORD PTR gs:[bp+di]
     392:	b1 03                	mov    cl,0x3
     394:	30 27                	xor    BYTE PTR [bx],ah
     396:	9a 03 87 27 d9       	call   0xd927:0x8703
     39b:	03 01                	add    ax,WORD PTR [bx+di]
     39d:	00 00                	add    BYTE PTR [bx+si],al
     39f:	00 00                	add    BYTE PTR [bx+si],al
     3a1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3a4:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     3a8:	06                   	push   es
     3a9:	46                   	inc    si
     3aa:	69 6c 74 65 72       	imul   bp,WORD PTR [si+0x74],0x7265
     3af:	d4 22                	aam    0x22
     3b1:	d5 03                	aad    0x3
     3b3:	2d 00 ff             	sub    ax,0xff00
     3b6:	ff 2d                	jmp    DWORD PTR [di]
     3b8:	00 ff                	add    bh,bh
     3ba:	ff 01                	inc    WORD PTR [bx+di]
     3bc:	00 00                	add    BYTE PTR [bx+si],al
     3be:	00 00                	add    BYTE PTR [bx+si],al
     3c0:	80 01 00             	add    BYTE PTR [bx+di],0x0
     3c3:	00 00                	add    BYTE PTR [bx+si],al
     3c5:	08 00                	or     BYTE PTR [bx+si],al
     3c7:	0b 46 69             	or     ax,WORD PTR [bp+0x69]
     3ca:	6c                   	ins    BYTE PTR es:[di],dx
     3cb:	74 65                	je     0x432
     3cd:	72 49                	jb     0x418
     3cf:	6e                   	outs   dx,BYTE PTR ds:[si]
     3d0:	64 65 78 62          	fs gs js 0x436
     3d4:	23 3c                	and    di,WORD PTR [si]
     3d6:	04 4d                	add    al,0x4d
     3d8:	27                   	daa
     3d9:	dd 03                	fld    QWORD PTR [bp+di]
     3db:	19 28                	sbb    WORD PTR [bx+si],bp
     3dd:	00 04                	add    BYTE PTR [si],al
     3df:	01 00                	add    WORD PTR [bx+si],ax
     3e1:	00 00                	add    BYTE PTR [bx+si],al
     3e3:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     3e7:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     3eb:	0a 49 6e             	or     cl,BYTE PTR [bx+di+0x6e]
     3ee:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     3f3:	44                   	inc    sp
     3f4:	69 72 8b 03 e4       	imul   si,WORD PTR [bp+si-0x75],0xe403
     3f9:	05 1f 00             	add    ax,0x1f
     3fc:	ff                   	(bad)
     3fd:	ff                   	(bad)
     3fe:	3e 28 1c             	sub    BYTE PTR ds:[si],bl
     401:	04 01                	add    al,0x1
     403:	00 00                	add    BYTE PTR [bx+si],al
     405:	00 00                	add    BYTE PTR [bx+si],al
     407:	80 00 00             	add    BYTE PTR [bx+si],0x0
     40a:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     40e:	0b 48 69             	or     cx,WORD PTR [bx+si+0x69]
     411:	73 74                	jae    0x487
     413:	6f                   	outs   dx,WORD PTR ds:[si]
     414:	72 79                	jb     0x48f
     416:	4c                   	dec    sp
     417:	69 73 74 bf 01       	imul   si,WORD PTR [bp+di+0x74],0x1bf
     41c:	40                   	inc    ax
     41d:	04 27                	add    al,0x27
     41f:	00 ff                	add    bh,bh
     421:	ff 27                	jmp    WORD PTR [bx]
     423:	00 ff                	add    bh,bh
     425:	ff 01                	inc    WORD PTR [bx+di]
     427:	00 00                	add    BYTE PTR [bx+si],al
     429:	00 00                	add    BYTE PTR [bx+si],al
     42b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     42e:	00 00                	add    BYTE PTR [bx+si],al
     430:	0b 00                	or     ax,WORD PTR [bx+si]
     432:	07                   	pop    es
     433:	4f                   	dec    di
     434:	70 74                	jo     0x4aa
     436:	69 6f 6e 73 62       	imul   bp,WORD PTR [bx+0x6e],0x6273
     43b:	23 d8                	and    bx,ax
     43d:	05 6a 27             	add    ax,0x276a
     440:	44                   	inc    sp
     441:	04 5b                	add    al,0x5b
     443:	28 76 04             	sub    BYTE PTR [bp+0x4],dh
     446:	01 00                	add    WORD PTR [bx+si],ax
     448:	00 00                	add    BYTE PTR [bx+si],al
     44a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     44e:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     452:	05 54 69             	add    ax,0x6954
     455:	74 6c                	je     0x4c3
     457:	65 03 11             	add    dx,WORD PTR gs:[bx+di]
     45a:	54                   	push   sp
     45b:	46                   	inc    si
     45c:	6f                   	outs   dx,WORD PTR ds:[si]
     45d:	6e                   	outs   dx,BYTE PTR ds:[si]
     45e:	74 44                	je     0x4a4
     460:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     465:	4f                   	dec    di
     466:	70 74                	jo     0x4dc
     468:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
     46d:	00 00                	add    BYTE PTR [bx+si],al
     46f:	00 0e 00 00          	add    BYTE PTR ds:0x0,cl
     473:	00 58 04             	add    BYTE PTR [bx+si+0x4],bl
     476:	57                   	push   di
     477:	05 0a 66             	add    ax,0x660a
     47a:	64 41                	fs inc cx
     47c:	6e                   	outs   dx,BYTE PTR ds:[si]
     47d:	73 69                	jae    0x4e8
     47f:	4f                   	dec    di
     480:	6e                   	outs   dx,BYTE PTR ds:[si]
     481:	6c                   	ins    BYTE PTR es:[di],dx
     482:	79 0e                	jns    0x492
     484:	66 64 54             	fs push esp
     487:	72 75                	jb     0x4fe
     489:	65 54                	gs push sp
     48b:	79 70                	jns    0x4fd
     48d:	65 4f                	gs dec di
     48f:	6e                   	outs   dx,BYTE PTR ds:[si]
     490:	6c                   	ins    BYTE PTR es:[di],dx
     491:	79 09                	jns    0x49c
     493:	66 64 45             	fs inc ebp
     496:	66 66 65 63 74 73    	data32 arpl WORD PTR gs:[si+0x73],esi
     49c:	10 66 64             	adc    BYTE PTR [bp+0x64],ah
     49f:	46                   	inc    si
     4a0:	69 78 65 64 50       	imul   di,WORD PTR [bx+si+0x65],0x5064
     4a5:	69 74 63 68 4f       	imul   si,WORD PTR [si+0x63],0x4f68
     4aa:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ab:	6c                   	ins    BYTE PTR es:[di],dx
     4ac:	79 10                	jns    0x4be
     4ae:	66 64 46             	fs inc esi
     4b1:	6f                   	outs   dx,WORD PTR ds:[si]
     4b2:	72 63                	jb     0x517
     4b4:	65 46                	gs inc si
     4b6:	6f                   	outs   dx,WORD PTR ds:[si]
     4b7:	6e                   	outs   dx,BYTE PTR ds:[si]
     4b8:	74 45                	je     0x4ff
     4ba:	78 69                	js     0x525
     4bc:	73 74                	jae    0x532
     4be:	0b 66 64             	or     sp,WORD PTR [bp+0x64]
     4c1:	4e                   	dec    si
     4c2:	6f                   	outs   dx,WORD PTR ds:[si]
     4c3:	46                   	inc    si
     4c4:	61                   	popa
     4c5:	63 65 53             	arpl   WORD PTR [di+0x53],sp
     4c8:	65 6c                	gs ins BYTE PTR es:[di],dx
     4ca:	0c 66                	or     al,0x66
     4cc:	64 4e                	fs dec si
     4ce:	6f                   	outs   dx,WORD PTR ds:[si]
     4cf:	4f                   	dec    di
     4d0:	45                   	inc    bp
     4d1:	4d                   	dec    bp
     4d2:	46                   	inc    si
     4d3:	6f                   	outs   dx,WORD PTR ds:[si]
     4d4:	6e                   	outs   dx,BYTE PTR ds:[si]
     4d5:	74 73                	je     0x54a
     4d7:	0f 66 64 4e          	pcmpgtd mm4,QWORD PTR [si+0x4e]
     4db:	6f                   	outs   dx,WORD PTR ds:[si]
     4dc:	53                   	push   bx
     4dd:	69 6d 75 6c 61       	imul   bp,WORD PTR [di+0x75],0x616c
     4e2:	74 69                	je     0x54d
     4e4:	6f                   	outs   dx,WORD PTR ds:[si]
     4e5:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e6:	73 0b                	jae    0x4f3
     4e8:	66 64 4e             	fs dec esi
     4eb:	6f                   	outs   dx,WORD PTR ds:[si]
     4ec:	53                   	push   bx
     4ed:	69 7a 65 53 65       	imul   di,WORD PTR [bp+si+0x65],0x6553
     4f2:	6c                   	ins    BYTE PTR es:[di],dx
     4f3:	0c 66                	or     al,0x66
     4f5:	64 4e                	fs dec si
     4f7:	6f                   	outs   dx,WORD PTR ds:[si]
     4f8:	53                   	push   bx
     4f9:	74 79                	je     0x574
     4fb:	6c                   	ins    BYTE PTR es:[di],dx
     4fc:	65 53                	gs push bx
     4fe:	65 6c                	gs ins BYTE PTR es:[di],dx
     500:	0f 66 64 4e          	pcmpgtd mm4,QWORD PTR [si+0x4e]
     504:	6f                   	outs   dx,WORD PTR ds:[si]
     505:	56                   	push   si
     506:	65 63 74 6f          	arpl   WORD PTR gs:[si+0x6f],si
     50a:	72 46                	jb     0x552
     50c:	6f                   	outs   dx,WORD PTR ds:[si]
     50d:	6e                   	outs   dx,BYTE PTR ds:[si]
     50e:	74 73                	je     0x583
     510:	0a 66 64             	or     ah,BYTE PTR [bp+0x64]
     513:	53                   	push   bx
     514:	68 6f 77             	push   0x776f
     517:	48                   	dec    ax
     518:	65 6c                	gs ins BYTE PTR es:[di],dx
     51a:	70 09                	jo     0x525
     51c:	66 64 57             	fs push edi
     51f:	79 73                	jns    0x594
     521:	69 77 79 67 0b       	imul   si,WORD PTR [bx+0x79],0xb67
     526:	66 64 4c             	fs dec esp
     529:	69 6d 69 74 53       	imul   bp,WORD PTR [di+0x69],0x5374
     52e:	69 7a 65 0e 66       	imul   di,WORD PTR [bp+si+0x65],0x660e
     533:	64 53                	fs push bx
     535:	63 61 6c             	arpl   WORD PTR [bx+di+0x6c],sp
     538:	61                   	popa
     539:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     53c:	4f                   	dec    di
     53d:	6e                   	outs   dx,BYTE PTR ds:[si]
     53e:	6c                   	ins    BYTE PTR es:[di],dx
     53f:	79 06                	jns    0x547
     541:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
     544:	6f                   	outs   dx,WORD PTR ds:[si]
     545:	6e                   	outs   dx,BYTE PTR ds:[si]
     546:	74 44                	je     0x58c
     548:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     54d:	4f                   	dec    di
     54e:	70 74                	jo     0x5c4
     550:	69 6f 6e 73 03       	imul   bp,WORD PTR [bx+0x6e],0x373
     555:	58                   	pop    ax
     556:	04 77                	add    al,0x77
     558:	05 03 11             	add    ax,0x1103
     55b:	54                   	push   sp
     55c:	46                   	inc    si
     55d:	6f                   	outs   dx,WORD PTR ds:[si]
     55e:	6e                   	outs   dx,BYTE PTR ds:[si]
     55f:	74 44                	je     0x5a5
     561:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     566:	44                   	inc    sp
     567:	65 76 69             	gs jbe 0x5d3
     56a:	63 65 00             	arpl   WORD PTR [di+0x0],sp
     56d:	00 00                	add    BYTE PTR [bx+si],al
     56f:	00 00                	add    BYTE PTR [bx+si],al
     571:	02 00                	add    al,BYTE PTR [bx+si]
     573:	00 00                	add    BYTE PTR [bx+si],al
     575:	59                   	pop    cx
     576:	05 0c 06             	add    ax,0x60c
     579:	08 66 64             	or     BYTE PTR [bp+0x64],ah
     57c:	53                   	push   bx
     57d:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
     580:	65 6e                	outs   dx,BYTE PTR gs:[si]
     582:	09 66 64             	or     WORD PTR [bp+0x64],sp
     585:	50                   	push   ax
     586:	72 69                	jb     0x5f1
     588:	6e                   	outs   dx,BYTE PTR ds:[si]
     589:	74 65                	je     0x5f0
     58b:	72 06                	jb     0x593
     58d:	66 64 42             	fs inc edx
     590:	6f                   	outs   dx,WORD PTR ds:[si]
     591:	74 68                	je     0x5fb
     593:	08 0d                	or     BYTE PTR [di],cl
     595:	54                   	push   sp
     596:	46                   	inc    si
     597:	44                   	inc    sp
     598:	41                   	inc    cx
     599:	70 70                	jo     0x60b
     59b:	6c                   	ins    BYTE PTR es:[di],dx
     59c:	79 45                	jns    0x5e3
     59e:	76 65                	jbe    0x605
     5a0:	6e                   	outs   dx,BYTE PTR ds:[si]
     5a1:	74 00                	je     0x5a3
     5a3:	02 00                	add    al,BYTE PTR [bx+si]
     5a5:	06                   	push   es
     5a6:	53                   	push   bx
     5a7:	65 6e                	outs   dx,BYTE PTR gs:[si]
     5a9:	64 65 72 07          	fs gs jb 0x5b4
     5ad:	54                   	push   sp
     5ae:	4f                   	dec    di
     5af:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     5b2:	63 74 00             	arpl   WORD PTR [si+0x0],si
     5b5:	03 57 6e             	add    dx,WORD PTR [bx+0x6e]
     5b8:	64 04 57             	fs add al,0x57
     5bb:	6f                   	outs   dx,WORD PTR ds:[si]
     5bc:	72 64                	jb     0x622
     5be:	26 06                	es push es
     5c0:	00 00                	add    BYTE PTR [bx+si],al
     5c2:	00 00                	add    BYTE PTR [bx+si],al
     5c4:	1e                   	push   ds
     5c5:	06                   	push   es
     5c6:	12 06 32 00          	adc    al,BYTE PTR ds:0x32
     5ca:	22 00                	and    al,BYTE PTR [bx+si]
     5cc:	24 06                	and    al,0x6
     5ce:	64 20 85 06 9a       	and    BYTE PTR fs:[di-0x65fa],al
     5d3:	1f                   	pop    ds
     5d4:	d0 05                	rol    BYTE PTR [di],1
     5d6:	cb                   	retf
     5d7:	1f                   	pop    ds
     5d8:	d4 05                	aam    0x5
     5da:	f7 28                	imul   WORD PTR [bx+si]
     5dc:	10 06 cd 11          	adc    BYTE PTR ds:0x11cd,al
     5e0:	e8 05 6e             	call   0x73e8
     5e3:	4f                   	dec    di
     5e4:	ec                   	in     al,dx
     5e5:	05 fa 10             	add    ax,0x10fa
     5e8:	31 07                	xor    WORD PTR [bx],ax
     5ea:	e5 4f                	in     ax,0x4f
     5ec:	f0 05 f4 4f          	lock add ax,0x4ff4
     5f0:	f4                   	hlt
     5f1:	05 05 4f             	add    ax,0x4f05
     5f4:	f8                   	clc
     5f5:	05 03 50             	add    ax,0x5003
     5f8:	fc                   	cld
     5f9:	05 46 51             	add    ax,0x5146
     5fc:	00 06 38 50          	add    BYTE PTR ds:0x5038,al
     600:	04 06                	add    al,0x6
     602:	1a 50 08             	sbb    dl,BYTE PTR [bx+si+0x8]
     605:	06                   	push   es
     606:	21 50 e0             	and    WORD PTR [bx+si-0x20],dx
     609:	05 9b 28             	add    ax,0x289b
     60c:	dc 05                	fadd   QWORD PTR [di]
     60e:	21 21                	and    WORD PTR [bx+di],sp
     610:	cc                   	int3
     611:	05 0b 54             	add    ax,0x540b
     614:	46                   	inc    si
     615:	6f                   	outs   dx,WORD PTR ds:[si]
     616:	6e                   	outs   dx,BYTE PTR ds:[si]
     617:	74 44                	je     0x65d
     619:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     61e:	01 00                	add    WORD PTR [bx+si],ax
     620:	ff                   	(bad)
     621:	ff                   	(bad)
     622:	ba 29 35             	mov    dx,0x3529
     625:	06                   	push   es
     626:	07                   	pop    es
     627:	0b 54 46             	or     dx,WORD PTR [si+0x46]
     62a:	6f                   	outs   dx,WORD PTR ds:[si]
     62b:	6e                   	outs   dx,BYTE PTR ds:[si]
     62c:	74 44                	je     0x672
     62e:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     633:	de 05                	fiadd  WORD PTR [di]
     635:	39 06 64 00          	cmp    WORD PTR ds:0x64,ax
     639:	51                   	push   cx
     63a:	06                   	push   es
     63b:	0a 00                	or     al,BYTE PTR [bx+si]
     63d:	07                   	pop    es
     63e:	44                   	inc    sp
     63f:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     644:	73 06                	jae    0x64c
     646:	00 22                	add    BYTE PTR [bp+si],ah
     648:	03 5b 11             	add    bx,WORD PTR [bp+di+0x11]
     64b:	1f                   	pop    ds
     64c:	00 ff                	add    bh,bh
     64e:	ff 93 2a 66          	call   WORD PTR [bp+di+0x662a]
     652:	06                   	push   es
     653:	01 00                	add    WORD PTR [bx+si],ax
     655:	00 00                	add    BYTE PTR [bx+si],al
     657:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     65b:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     65f:	04 46                	add    al,0x46
     661:	6f                   	outs   dx,WORD PTR ds:[si]
     662:	6e                   	outs   dx,BYTE PTR ds:[si]
     663:	74 59                	je     0x6be
     665:	05 cd 06             	add    ax,0x6cd
     668:	23 00                	and    ax,WORD PTR [bx+si]
     66a:	ff                   	(bad)
     66b:	ff 23                	jmp    WORD PTR [bp+di]
     66d:	00 ff                	add    bh,bh
     66f:	ff 01                	inc    WORD PTR [bx+di]
     671:	00 00                	add    BYTE PTR [bx+si],al
     673:	00 00                	add    BYTE PTR [bx+si],al
     675:	80 00 00             	add    BYTE PTR [bx+si],0x0
     678:	00 00                	add    BYTE PTR [bx+si],al
     67a:	05 00 06             	add    ax,0x600
     67d:	44                   	inc    sp
     67e:	65 76 69             	gs jbe 0x6ea
     681:	63 65 d4             	arpl   WORD PTR [di-0x2c],sp
     684:	22 a9 06 2e          	and    ch,BYTE PTR [bx+di+0x2e06]
     688:	00 ff                	add    bh,bh
     68a:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     68e:	ff 01                	inc    WORD PTR [bx+di]
     690:	00 00                	add    BYTE PTR [bx+si],al
     692:	00 00                	add    BYTE PTR [bx+si],al
     694:	80 00 00             	add    BYTE PTR [bx+si],0x0
     697:	00 80 06 00          	add    BYTE PTR [bx+si+0x6],al
     69b:	0b 4d 69             	or     cx,WORD PTR [di+0x69]
     69e:	6e                   	outs   dx,BYTE PTR ds:[si]
     69f:	46                   	inc    si
     6a0:	6f                   	outs   dx,WORD PTR ds:[si]
     6a1:	6e                   	outs   dx,BYTE PTR ds:[si]
     6a2:	74 53                	je     0x6f7
     6a4:	69 7a 65 d4 22       	imul   di,WORD PTR [bp+si+0x65],0x22d4
     6a9:	25 07 30             	and    ax,0x3007
     6ac:	00 ff                	add    bh,bh
     6ae:	ff 30                	push   WORD PTR [bx+si]
     6b0:	00 ff                	add    bh,bh
     6b2:	ff 01                	inc    WORD PTR [bx+di]
     6b4:	00 00                	add    BYTE PTR [bx+si],al
     6b6:	00 00                	add    BYTE PTR [bx+si],al
     6b8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6bb:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     6bf:	0b 4d 61             	or     cx,WORD PTR [di+0x61]
     6c2:	78 46                	js     0x70a
     6c4:	6f                   	outs   dx,WORD PTR ds:[si]
     6c5:	6e                   	outs   dx,BYTE PTR ds:[si]
     6c6:	74 53                	je     0x71b
     6c8:	69 7a 65 40 05       	imul   di,WORD PTR [bp+si+0x65],0x540
     6cd:	ed                   	in     ax,dx
     6ce:	06                   	push   es
     6cf:	24 00                	and    al,0x0
     6d1:	ff                   	(bad)
     6d2:	ff 24                	jmp    WORD PTR [si]
     6d4:	00 ff                	add    bh,bh
     6d6:	ff 01                	inc    WORD PTR [bx+di]
     6d8:	00 00                	add    BYTE PTR [bx+si],al
     6da:	00 00                	add    BYTE PTR [bx+si],al
     6dc:	80 04 00             	add    BYTE PTR [si],0x0
     6df:	00 00                	add    BYTE PTR [bx+si],al
     6e1:	08 00                	or     BYTE PTR [bx+si],al
     6e3:	07                   	pop    es
     6e4:	4f                   	dec    di
     6e5:	70 74                	jo     0x75b
     6e7:	69 6f 6e 73 93       	imul   bp,WORD PTR [bx+0x6e],0x9373
     6ec:	05 5d 07             	add    ax,0x75d
     6ef:	26 00 ff             	es add bh,bh
     6f2:	ff 26 00 ff          	jmp    WORD PTR ds:0xff00
     6f6:	ff 01                	inc    WORD PTR [bx+di]
     6f8:	00 00                	add    BYTE PTR [bx+si],al
     6fa:	00 00                	add    BYTE PTR [bx+si],al
     6fc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6ff:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     703:	07                   	pop    es
     704:	4f                   	dec    di
     705:	6e                   	outs   dx,BYTE PTR ds:[si]
     706:	41                   	inc    cx
     707:	70 70                	jo     0x779
     709:	6c                   	ins    BYTE PTR es:[di],dx
     70a:	79 73                	jns    0x77f
     70c:	07                   	pop    es
     70d:	00 00                	add    BYTE PTR [bx+si],al
     70f:	00 00                	add    BYTE PTR [bx+si],al
     711:	00 00                	add    BYTE PTR [bx+si],al
     713:	5f                   	pop    di
     714:	07                   	pop    es
     715:	1f                   	pop    ds
     716:	00 22                	add    BYTE PTR [bp+si],ah
     718:	00 8a 07 64          	add    BYTE PTR [bp+si+0x6407],cl
     71c:	20 78 08             	and    BYTE PTR [bx+si+0x8],bh
     71f:	9a 1f 1d 07 cb       	call   0xcb07:0x1d1f
     724:	1f                   	pop    ds
     725:	21 07                	and    WORD PTR [bx],ax
     727:	2b 4c 2d             	sub    cx,WORD PTR [si+0x2d]
     72a:	07                   	pop    es
     72b:	cd 11                	int    0x11
     72d:	35 07 6e             	xor    ax,0x6e07
     730:	4f                   	dec    di
     731:	39 07                	cmp    WORD PTR [bx],ax
     733:	fa                   	cli
     734:	10 84 08 e5          	adc    BYTE PTR [si-0x1af8],al
     738:	4f                   	dec    di
     739:	3d 07 f4             	cmp    ax,0xf407
     73c:	4f                   	dec    di
     73d:	41                   	inc    cx
     73e:	07                   	pop    es
     73f:	05 4f 45             	add    ax,0x454f
     742:	07                   	pop    es
     743:	03 50 49             	add    dx,WORD PTR [bx+si+0x49]
     746:	07                   	pop    es
     747:	46                   	inc    si
     748:	51                   	push   cx
     749:	4d                   	dec    bp
     74a:	07                   	pop    es
     74b:	38 50 51             	cmp    BYTE PTR [bx+si+0x51],dl
     74e:	07                   	pop    es
     74f:	1a 50 55             	sbb    dl,BYTE PTR [bx+si+0x55]
     752:	07                   	pop    es
     753:	21 50 29             	and    WORD PTR [bx+si+0x29],dx
     756:	07                   	pop    es
     757:	de 20                	fisub  WORD PTR [bx+si]
     759:	19 07                	sbb    WORD PTR [bx],ax
     75b:	21 21                	and    WORD PTR [bx+di],sp
     75d:	59                   	pop    cx
     75e:	07                   	pop    es
     75f:	13 54 50             	adc    dx,WORD PTR [si+0x50]
     762:	72 69                	jb     0x7cd
     764:	6e                   	outs   dx,BYTE PTR ds:[si]
     765:	74 65                	je     0x7cc
     767:	72 53                	jb     0x7bc
     769:	65 74 75             	gs je  0x7e1
     76c:	70 44                	jo     0x7b2
     76e:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     773:	07                   	pop    es
     774:	13 54 50             	adc    dx,WORD PTR [si+0x50]
     777:	72 69                	jb     0x7e2
     779:	6e                   	outs   dx,BYTE PTR ds:[si]
     77a:	74 65                	je     0x7e1
     77c:	72 53                	jb     0x7d1
     77e:	65 74 75             	gs je  0x7f6
     781:	70 44                	jo     0x7c7
     783:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     788:	2b 07                	sub    ax,WORD PTR [bx]
     78a:	8e 07                	mov    es,WORD PTR [bx]
     78c:	64 00 b4 07 04       	add    BYTE PTR fs:[si+0x407],dh
     791:	00 07                	add    BYTE PTR [bx],al
     793:	44                   	inc    sp
     794:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     799:	73 00                	jae    0x79b
     79b:	00 03                	add    BYTE PTR [bp+di],al
     79d:	0b 54 50             	or     dx,WORD PTR [si+0x50]
     7a0:	72 69                	jb     0x80b
     7a2:	6e                   	outs   dx,BYTE PTR ds:[si]
     7a3:	74 52                	je     0x7f7
     7a5:	61                   	popa
     7a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     7a7:	67 65 00 00          	add    BYTE PTR gs:[eax],al
     7ab:	00 00                	add    BYTE PTR [bx+si],al
     7ad:	00 02                	add    BYTE PTR [bp+si],al
     7af:	00 00                	add    BYTE PTR [bx+si],al
     7b1:	00 9c 07 f7          	add    BYTE PTR [si-0x8f9],bl
     7b5:	07                   	pop    es
     7b6:	0a 70 72             	or     dh,BYTE PTR [bx+si+0x72]
     7b9:	41                   	inc    cx
     7ba:	6c                   	ins    BYTE PTR es:[di],dx
     7bb:	6c                   	ins    BYTE PTR es:[di],dx
     7bc:	50                   	push   ax
     7bd:	61                   	popa
     7be:	67 65 73 0b          	addr32 gs jae 0x7cd
     7c2:	70 72                	jo     0x836
     7c4:	53                   	push   bx
     7c5:	65 6c                	gs ins BYTE PTR es:[di],dx
     7c7:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
     7cb:	6f                   	outs   dx,WORD PTR ds:[si]
     7cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     7cd:	0a 70 72             	or     dh,BYTE PTR [bx+si+0x72]
     7d0:	50                   	push   ax
     7d1:	61                   	popa
     7d2:	67 65 4e             	addr32 gs dec si
     7d5:	75 6d                	jne    0x844
     7d7:	73 03                	jae    0x7dc
     7d9:	12 54 50             	adc    dl,BYTE PTR [si+0x50]
     7dc:	72 69                	jb     0x847
     7de:	6e                   	outs   dx,BYTE PTR ds:[si]
     7df:	74 44                	je     0x825
     7e1:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     7e6:	4f                   	dec    di
     7e7:	70 74                	jo     0x85d
     7e9:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
     7ee:	00 00                	add    BYTE PTR [bx+si],al
     7f0:	00 05                	add    BYTE PTR [di],al
     7f2:	00 00                	add    BYTE PTR [bx+si],al
     7f4:	00 d8                	add    al,bl
     7f6:	07                   	pop    es
     7f7:	5c                   	pop    sp
     7f8:	08 0d                	or     BYTE PTR [di],cl
     7fa:	70 6f                	jo     0x86b
     7fc:	50                   	push   ax
     7fd:	72 69                	jb     0x868
     7ff:	6e                   	outs   dx,BYTE PTR ds:[si]
     800:	74 54                	je     0x856
     802:	6f                   	outs   dx,WORD PTR ds:[si]
     803:	46                   	inc    si
     804:	69 6c 65 0a 70       	imul   bp,WORD PTR [si+0x65],0x700a
     809:	6f                   	outs   dx,WORD PTR ds:[si]
     80a:	50                   	push   ax
     80b:	61                   	popa
     80c:	67 65 4e             	addr32 gs dec si
     80f:	75 6d                	jne    0x87e
     811:	73 0b                	jae    0x81e
     813:	70 6f                	jo     0x884
     815:	53                   	push   bx
     816:	65 6c                	gs ins BYTE PTR es:[di],dx
     818:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
     81c:	6f                   	outs   dx,WORD PTR ds:[si]
     81d:	6e                   	outs   dx,BYTE PTR ds:[si]
     81e:	09 70 6f             	or     WORD PTR [bx+si+0x6f],si
     821:	57                   	push   di
     822:	61                   	popa
     823:	72 6e                	jb     0x893
     825:	69 6e 67 06 70       	imul   bp,WORD PTR [bp+0x67],0x7006
     82a:	6f                   	outs   dx,WORD PTR ds:[si]
     82b:	48                   	dec    ax
     82c:	65 6c                	gs ins BYTE PTR es:[di],dx
     82e:	70 14                	jo     0x844
     830:	70 6f                	jo     0x8a1
     832:	44                   	inc    sp
     833:	69 73 61 62 6c       	imul   si,WORD PTR [bp+di+0x61],0x6c62
     838:	65 50                	gs push ax
     83a:	72 69                	jb     0x8a5
     83c:	6e                   	outs   dx,BYTE PTR ds:[si]
     83d:	74 54                	je     0x893
     83f:	6f                   	outs   dx,WORD PTR ds:[si]
     840:	46                   	inc    si
     841:	69 6c 65 06 13       	imul   bp,WORD PTR [si+0x65],0x1306
     846:	54                   	push   sp
     847:	50                   	push   ax
     848:	72 69                	jb     0x8b3
     84a:	6e                   	outs   dx,BYTE PTR ds:[si]
     84b:	74 44                	je     0x891
     84d:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     852:	4f                   	dec    di
     853:	70 74                	jo     0x8c9
     855:	69 6f 6e 73 01       	imul   bp,WORD PTR [bx+0x6e],0x173
     85a:	d8 07                	fadd   DWORD PTR [bx]
     85c:	b0 08                	mov    al,0x8
     85e:	bf 08 00             	mov    di,0x8
     861:	00 00                	add    BYTE PTR [bx+si],al
     863:	00 00                	add    BYTE PTR [bx+si],al
     865:	00 b2 08 2d          	add    BYTE PTR [bp+si+0x2d08],dh
     869:	00 2b                	add    BYTE PTR [bp+di],ch
     86b:	07                   	pop    es
     86c:	cf                   	iret
     86d:	08 64 20             	or     BYTE PTR [si+0x20],ah
     870:	e3 08                	jcxz   0x87a
     872:	9a 1f 70 08 cb       	call   0xcb08:0x701f
     877:	1f                   	pop    ds
     878:	74 08                	je     0x882
     87a:	2b 4c 80             	sub    cx,WORD PTR [si-0x80]
     87d:	08 cd                	or     ch,cl
     87f:	11 88 08 6e          	adc    WORD PTR [bx+si+0x6e08],cx
     883:	4f                   	dec    di
     884:	8c 08                	mov    WORD PTR [bx+si],cs
     886:	fa                   	cli
     887:	10 ed                	adc    ch,ch
     889:	1d e5 4f             	sbb    ax,0x4fe5
     88c:	90                   	nop
     88d:	08 f4                	or     ah,dh
     88f:	4f                   	dec    di
     890:	94                   	xchg   sp,ax
     891:	08 05                	or     BYTE PTR [di],al
     893:	4f                   	dec    di
     894:	98                   	cbw
     895:	08 03                	or     BYTE PTR [bp+di],al
     897:	50                   	push   ax
     898:	9c                   	pushf
     899:	08 46 51             	or     BYTE PTR [bp+0x51],al
     89c:	a0 08 38             	mov    al,ds:0x3808
     89f:	50                   	push   ax
     8a0:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     8a1:	08 1a                	or     BYTE PTR [bp+si],bl
     8a3:	50                   	push   ax
     8a4:	a8 08                	test   al,0x8
     8a6:	21 50 7c             	and    WORD PTR [bx+si+0x7c],dx
     8a9:	08 de                	or     dh,bl
     8ab:	20 6c 08             	and    BYTE PTR [si+0x8],ch
     8ae:	21 21                	and    WORD PTR [bx+di],sp
     8b0:	ac                   	lods   al,BYTE PTR ds:[si]
     8b1:	08 0c                	or     BYTE PTR [si],cl
     8b3:	54                   	push   sp
     8b4:	50                   	push   ax
     8b5:	72 69                	jb     0x920
     8b7:	6e                   	outs   dx,BYTE PTR ds:[si]
     8b8:	74 44                	je     0x8fe
     8ba:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     8bf:	07                   	pop    es
     8c0:	0c 54                	or     al,0x54
     8c2:	50                   	push   ax
     8c3:	72 69                	jb     0x92e
     8c5:	6e                   	outs   dx,BYTE PTR ds:[si]
     8c6:	74 44                	je     0x90c
     8c8:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     8cd:	7e 08                	jle    0x8d7
     8cf:	d3 08                	ror    WORD PTR [bx+si],cl
     8d1:	73 07                	jae    0x8da
     8d3:	83 09 0d             	or     WORD PTR [bx+di],0xd
     8d6:	00 07                	add    BYTE PTR [bx],al
     8d8:	44                   	inc    sp
     8d9:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     8de:	73 09                	jae    0x8e9
     8e0:	00 07                	add    BYTE PTR [bx],al
     8e2:	23 03                	and    ax,WORD PTR [bp+di]
     8e4:	09 23                	or     WORD PTR [bp+di],sp
     8e6:	00 ff                	add    bh,bh
     8e8:	ff 23                	jmp    WORD PTR [bp+di]
     8ea:	00 ff                	add    bh,bh
     8ec:	ff 01                	inc    WORD PTR [bx+di]
     8ee:	00 00                	add    BYTE PTR [bx+si],al
     8f0:	00 00                	add    BYTE PTR [bx+si],al
     8f2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8f5:	00 00                	add    BYTE PTR [bx+si],al
     8f7:	04 00                	add    al,0x0
     8f9:	07                   	pop    es
     8fa:	43                   	inc    bx
     8fb:	6f                   	outs   dx,WORD PTR ds:[si]
     8fc:	6c                   	ins    BYTE PTR es:[di],dx
     8fd:	6c                   	ins    BYTE PTR es:[di],dx
     8fe:	61                   	popa
     8ff:	74 65                	je     0x966
     901:	d4 22                	aam    0x22
     903:	22 09                	and    cl,BYTE PTR [bx+di]
     905:	2b 00                	sub    ax,WORD PTR [bx+si]
     907:	ff                   	(bad)
     908:	ff 2b                	jmp    DWORD PTR [bp+di]
     90a:	00 ff                	add    bh,bh
     90c:	ff 01                	inc    WORD PTR [bx+di]
     90e:	00 00                	add    BYTE PTR [bx+si],al
     910:	00 00                	add    BYTE PTR [bx+si],al
     912:	80 00 00             	add    BYTE PTR [bx+si],0x0
     915:	00 00                	add    BYTE PTR [bx+si],al
     917:	05 00 06             	add    ax,0x600
     91a:	43                   	inc    bx
     91b:	6f                   	outs   dx,WORD PTR ds:[si]
     91c:	70 69                	jo     0x987
     91e:	65 73 d4             	gs jae 0x8f5
     921:	22 43 09             	and    al,BYTE PTR [bp+di+0x9]
     924:	1f                   	pop    ds
     925:	00 ff                	add    bh,bh
     927:	ff 1f                	call   DWORD PTR [bx]
     929:	00 ff                	add    bh,bh
     92b:	ff 01                	inc    WORD PTR [bx+di]
     92d:	00 00                	add    BYTE PTR [bx+si],al
     92f:	00 00                	add    BYTE PTR [bx+si],al
     931:	80 00 00             	add    BYTE PTR [bx+si],0x0
     934:	00 00                	add    BYTE PTR [bx+si],al
     936:	06                   	push   es
     937:	00 08                	add    BYTE PTR [bx+si],cl
     939:	46                   	inc    si
     93a:	72 6f                	jb     0x9ab
     93c:	6d                   	ins    WORD PTR es:[di],dx
     93d:	50                   	push   ax
     93e:	61                   	popa
     93f:	67 65 d4 22          	addr32 gs aam 0x22
     943:	63 09                	arpl   WORD PTR [bx+di],cx
     945:	27                   	daa
     946:	00 ff                	add    bh,bh
     948:	ff 27                	jmp    WORD PTR [bx]
     94a:	00 ff                	add    bh,bh
     94c:	ff 01                	inc    WORD PTR [bx+di]
     94e:	00 00                	add    BYTE PTR [bx+si],al
     950:	00 00                	add    BYTE PTR [bx+si],al
     952:	80 00 00             	add    BYTE PTR [bx+si],0x0
     955:	00 00                	add    BYTE PTR [bx+si],al
     957:	07                   	pop    es
     958:	00 07                	add    BYTE PTR [bx],al
     95a:	4d                   	dec    bp
     95b:	69 6e 50 61 67       	imul   bp,WORD PTR [bp+0x50],0x6761
     960:	65 d4 22             	gs aam 0x22
     963:	a3 09 29             	mov    ds:0x2909,ax
     966:	00 ff                	add    bh,bh
     968:	ff 29                	jmp    DWORD PTR [bx+di]
     96a:	00 ff                	add    bh,bh
     96c:	ff 01                	inc    WORD PTR [bx+di]
     96e:	00 00                	add    BYTE PTR [bx+si],al
     970:	00 00                	add    BYTE PTR [bx+si],al
     972:	80 00 00             	add    BYTE PTR [bx+si],0x0
     975:	00 00                	add    BYTE PTR [bx+si],al
     977:	08 00                	or     BYTE PTR [bx+si],al
     979:	07                   	pop    es
     97a:	4d                   	dec    bp
     97b:	61                   	popa
     97c:	78 50                	js     0x9ce
     97e:	61                   	popa
     97f:	67 65 44             	addr32 gs inc sp
     982:	08 c7                	or     bh,al
     984:	09 24                	or     WORD PTR [si],sp
     986:	00 ff                	add    bh,bh
     988:	ff 24                	jmp    WORD PTR [si]
     98a:	00 ff                	add    bh,bh
     98c:	ff 01                	inc    WORD PTR [bx+di]
     98e:	00 00                	add    BYTE PTR [bx+si],al
     990:	00 00                	add    BYTE PTR [bx+si],al
     992:	80 00 00             	add    BYTE PTR [bx+si],0x0
     995:	00 00                	add    BYTE PTR [bx+si],al
     997:	09 00                	or     WORD PTR [bx+si],ax
     999:	07                   	pop    es
     99a:	4f                   	dec    di
     99b:	70 74                	jo     0xa11
     99d:	69 6f 6e 73 07       	imul   bp,WORD PTR [bx+0x6e],0x773
     9a2:	23 ea                	and    bp,dx
     9a4:	09 25                	or     WORD PTR [di],sp
     9a6:	00 ff                	add    bh,bh
     9a8:	ff 25                	jmp    WORD PTR [di]
     9aa:	00 ff                	add    bh,bh
     9ac:	ff 01                	inc    WORD PTR [bx+di]
     9ae:	00 00                	add    BYTE PTR [bx+si],al
     9b0:	00 00                	add    BYTE PTR [bx+si],al
     9b2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9b5:	00 00                	add    BYTE PTR [bx+si],al
     9b7:	0a 00                	or     al,BYTE PTR [bx+si]
     9b9:	0b 50 72             	or     dx,WORD PTR [bx+si+0x72]
     9bc:	69 6e 74 54 6f       	imul   bp,WORD PTR [bp+0x74],0x6f54
     9c1:	46                   	inc    si
     9c2:	69 6c 65 9c 07       	imul   bp,WORD PTR [si+0x65],0x79c
     9c7:	29 0a                	sub    WORD PTR [bp+si],cx
     9c9:	26 00 ff             	es add bh,bh
     9cc:	ff 26 00 ff          	jmp    WORD PTR ds:0xff00
     9d0:	ff 01                	inc    WORD PTR [bx+di]
     9d2:	00 00                	add    BYTE PTR [bx+si],al
     9d4:	00 00                	add    BYTE PTR [bx+si],al
     9d6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9d9:	00 00                	add    BYTE PTR [bx+si],al
     9db:	0b 00                	or     ax,WORD PTR [bx+si]
     9dd:	0a 50 72             	or     dl,BYTE PTR [bx+si+0x72]
     9e0:	69 6e 74 52 61       	imul   bp,WORD PTR [bp+0x74],0x6152
     9e5:	6e                   	outs   dx,BYTE PTR ds:[si]
     9e6:	67 65 d4 22          	addr32 gs aam 0x22
     9ea:	21 0a                	and    WORD PTR [bp+si],cx
     9ec:	21 00                	and    WORD PTR [bx+si],ax
     9ee:	ff                   	(bad)
     9ef:	ff 21                	jmp    WORD PTR [bx+di]
     9f1:	00 ff                	add    bh,bh
     9f3:	ff 01                	inc    WORD PTR [bx+di]
     9f5:	00 00                	add    BYTE PTR [bx+si],al
     9f7:	00 00                	add    BYTE PTR [bx+si],al
     9f9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9fc:	00 00                	add    BYTE PTR [bx+si],al
     9fe:	0c 00                	or     al,0x0
     a00:	06                   	push   es
     a01:	54                   	push   sp
     a02:	6f                   	outs   dx,WORD PTR ds:[si]
     a03:	50                   	push   ax
     a04:	61                   	popa
     a05:	67 65 00 00          	add    BYTE PTR gs:[eax],al
     a09:	00 00                	add    BYTE PTR [bx+si],al
     a0b:	00 00                	add    BYTE PTR [bx+si],al
     a0d:	3c 0a                	cmp    al,0xa
     a0f:	2f                   	das
     a10:	0a 14                	or     dl,BYTE PTR [si]
     a12:	00 2c                	add    BYTE PTR [si],ch
     a14:	02 42 0a             	add    al,BYTE PTR [bp+si+0xa]
     a17:	77 0d                	ja     0xa26
     a19:	2d 0a 9a             	sub    ax,0x9a0a
     a1c:	1f                   	pop    ds
     a1d:	5e                   	pop    si
     a1e:	0a cb                	or     cl,bl
     a20:	1f                   	pop    ds
     a21:	1d 0a 48             	sbb    ax,0x480a
     a24:	0d 19 0a             	or     ax,0xa19
     a27:	31 10                	xor    WORD PTR [bx+si],dx
     a29:	25 0a 6e             	and    ax,0x6e0a
     a2c:	0e                   	push   cs
     a2d:	15 0a 0c             	adc    ax,0xc0a
     a30:	54                   	push   sp
     a31:	44                   	inc    sp
     a32:	72 6f                	jb     0xaa3
     a34:	70 4c                	jo     0xa82
     a36:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     a3b:	78 01                	js     0xa3e
     a3d:	00 02                	add    BYTE PTR [bp+si],al
     a3f:	02 e4                	add    ah,ah
     a41:	10 66 0a             	adc    BYTE PTR [bp+0xa],ah
     a44:	00 00                	add    BYTE PTR [bx+si],al
     a46:	00 00                	add    BYTE PTR [bx+si],al
     a48:	00 00                	add    BYTE PTR [bx+si],al
     a4a:	7c 0a                	jl     0xa56
     a4c:	6c                   	ins    BYTE PTR es:[di],dx
     a4d:	0a 14                	or     dl,BYTE PTR [si]
     a4f:	00 2c                	add    BYTE PTR [si],ch
     a51:	02 82 0a dd          	add    al,BYTE PTR [bp+si-0x22f6]
     a55:	0e                   	push   cs
     a56:	62 0a                	bound  cx,DWORD PTR [bp+si]
     a58:	9a 1f 9e 0a cb       	call   0xcb0a:0x9e1f
     a5d:	1f                   	pop    ds
     a5e:	5a                   	pop    dx
     a5f:	0a 48 0d             	or     cl,BYTE PTR [bx+si+0xd]
     a62:	6a 0a                	push   0xa
     a64:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     a65:	0e                   	push   cs
     a66:	56                   	push   si
     a67:	0a 6e 0e             	or     ch,BYTE PTR [bp+0xe]
     a6a:	52                   	push   dx
     a6b:	0a 0f                	or     cl,BYTE PTR [bx]
     a6d:	54                   	push   sp
     a6e:	44                   	inc    sp
     a6f:	6c                   	ins    BYTE PTR es:[di],dx
     a70:	67 45                	addr32 inc bp
     a72:	64 69 74 43 6f 6e    	imul   si,WORD PTR fs:[si+0x43],0x6e6f
     a78:	74 72                	je     0xaec
     a7a:	6f                   	outs   dx,WORD PTR ds:[si]
     a7b:	6c                   	ins    BYTE PTR es:[di],dx
     a7c:	01 00                	add    WORD PTR [bx+si],ax
     a7e:	08 00                	or     BYTE PTR [bx+si],al
     a80:	80 0f a6             	or     BYTE PTR [bx],0xa6
     a83:	0a 00                	or     al,BYTE PTR [bx+si]
     a85:	00 00                	add    BYTE PTR [bx+si],al
     a87:	00 00                	add    BYTE PTR [bx+si],al
     a89:	00 b7 0a ac          	add    BYTE PTR [bx-0x53f6],dh
     a8d:	0a 14                	or     dl,BYTE PTR [si]
     a8f:	00 2c                	add    BYTE PTR [si],ch
     a91:	02 bf 0a 77          	add    bh,BYTE PTR [bx+0x770a]
     a95:	0d aa 0a             	or     ax,0xaaa
     a98:	9a 1f 56 0c cb       	call   0xcb0c:0x561f
     a9d:	1f                   	pop    ds
     a9e:	9a 0a 48 0d 96       	call   0x960d:0x480a
     aa3:	0a a7 0f a2          	or     ah,BYTE PTR [bx-0x5df1]
     aa7:	0a 6e 0e             	or     ch,BYTE PTR [bp+0xe]
     aaa:	92                   	xchg   dx,ax
     aab:	0a 0a                	or     cl,BYTE PTR [bp+si]
     aad:	54                   	push   sp
     aae:	43                   	inc    bx
     aaf:	6f                   	outs   dx,WORD PTR ds:[si]
     ab0:	6d                   	ins    WORD PTR es:[di],dx
     ab1:	6d                   	ins    WORD PTR es:[di],dx
     ab2:	6f                   	outs   dx,WORD PTR ds:[si]
     ab3:	6e                   	outs   dx,BYTE PTR ds:[si]
     ab4:	44                   	inc    sp
     ab5:	6c                   	ins    BYTE PTR es:[di],dx
     ab6:	67 02 00             	add    al,BYTE PTR [eax]
     ab9:	01 02                	add    WORD PTR [bp+si],ax
     abb:	a1 00 e3             	mov    ax,ds:0xe300
     abe:	0f c3 0a             	movnti DWORD PTR [bp+si],ecx
     ac1:	0a 10                	or     dl,BYTE PTR [bx+si]
     ac3:	cd 0a                	int    0xa
     ac5:	01 00                	add    WORD PTR [bx+si],ax
     ac7:	00 00                	add    BYTE PTR [bx+si],al
     ac9:	00 00                	add    BYTE PTR [bx+si],al
     acb:	44                   	inc    sp
     acc:	0c 14                	or     al,0x14
     ace:	0b 8c d0 90          	or     cx,WORD PTR [si-0x6f30]
     ad2:	45                   	inc    bp
     ad3:	55                   	push   bp
     ad4:	89 e5                	mov    bp,sp
     ad6:	1e                   	push   ds
     ad7:	8e d8                	mov    ds,ax
     ad9:	83 ec 0c             	sub    sp,0xc
     adc:	56                   	push   si
     add:	57                   	push   di
     ade:	31 c0                	xor    ax,ax
     ae0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ae3:	b8 c5 0a             	mov    ax,0xac5
     ae6:	0e                   	push   cs
     ae7:	50                   	push   ax
     ae8:	55                   	push   bp
     ae9:	ff 36 58 18          	push   WORD PTR ds:0x1858
     aed:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     af1:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     af4:	3d 10 01             	cmp    ax,0x110
     af7:	74 03                	je     0xafc
     af9:	e9 8d 00             	jmp    0xb89
     afc:	a1 b6 0c             	mov    ax,ds:0xcb6
     aff:	0b 06 b8 0c          	or     ax,WORD PTR ds:0xcb8
     b03:	74 19                	je     0xb1e
     b05:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b08:	68 80 04             	push   0x480
     b0b:	c4 3e b6 0c          	les    di,DWORD PTR ds:0xcb6
     b0f:	06                   	push   es
     b10:	57                   	push   di
     b11:	9a 28 1a 6a 0c       	call   0xc6a:0x1a28
     b16:	31 c0                	xor    ax,ax
     b18:	a3 b6 0c             	mov    ds:0xcb6,ax
     b1b:	a3 b8 0c             	mov    ds:0xcb8,ax
     b1e:	80 3e b4 0c 00       	cmp    BYTE PTR ds:0xcb4,0x0
     b23:	74 11                	je     0xb36
     b25:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b28:	6a ff                	push   0xffff
     b2a:	9a ed 13 34 0b       	call   0xb34:0x13ed
     b2f:	6a 01                	push   0x1
     b31:	9a 0f 14 9a 0b       	call   0xb9a:0x140f
     b36:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b39:	8d 7e f2             	lea    di,[bp-0xe]
     b3c:	16                   	push   ss
     b3d:	57                   	push   di
     b3e:	9a 8a 13 00 00       	call   0x0:0x138a
     b43:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     b46:	2b 46 f2             	sub    ax,WORD PTR [bp-0xe]
     b49:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     b4c:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b4f:	6a 00                	push   0x0
     b51:	6a 00                	push   0x0
     b53:	9a 65 0b 00 00       	call   0x0:0xb65
     b58:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
     b5b:	99                   	cwd
     b5c:	b9 02 00             	mov    cx,0x2
     b5f:	f7 f9                	idiv   cx
     b61:	50                   	push   ax
     b62:	6a 01                	push   0x1
     b64:	9a 27 14 00 00       	call   0x0:0x1427
     b69:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
     b6c:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
     b6f:	99                   	cwd
     b70:	b9 03 00             	mov    cx,0x3
     b73:	f7 f9                	idiv   cx
     b75:	50                   	push   ax
     b76:	6a 00                	push   0x0
     b78:	6a 00                	push   0x0
     b7a:	6a 15                	push   0x15
     b7c:	9a 66 0e 00 00       	call   0x0:0xe66
     b81:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
     b86:	e9 b2 00             	jmp    0xc3b
     b89:	3d 02 00             	cmp    ax,0x2
     b8c:	75 11                	jne    0xb9f
     b8e:	80 3e b4 0c 00       	cmp    BYTE PTR ds:0xcb4,0x0
     b93:	74 07                	je     0xb9c
     b95:	6a 00                	push   0x0
     b97:	9a 0f 14 51 0c       	call   0xc51:0x140f
     b9c:	e9 9c 00             	jmp    0xc3b
     b9f:	3d 19 00             	cmp    ax,0x19
     ba2:	75 28                	jne    0xbcc
     ba4:	80 3e b4 0c 00       	cmp    BYTE PTR ds:0xcb4,0x0
     ba9:	74 1f                	je     0xbca
     bab:	a1 2a 15             	mov    ax,ds:0x152a
     bae:	0b 06 2c 15          	or     ax,WORD PTR ds:0x152c
     bb2:	74 16                	je     0xbca
     bb4:	ff 76 0e             	push   WORD PTR [bp+0xe]
     bb7:	ff 76 0c             	push   WORD PTR [bp+0xc]
     bba:	ff 76 0a             	push   WORD PTR [bp+0xa]
     bbd:	ff 76 08             	push   WORD PTR [bp+0x8]
     bc0:	ff 76 06             	push   WORD PTR [bp+0x6]
     bc3:	ff 1e 2a 15          	call   DWORD PTR ds:0x152a
     bc7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     bca:	eb 6f                	jmp    0xc3b
     bcc:	3d 86 00             	cmp    ax,0x86
     bcf:	74 0a                	je     0xbdb
     bd1:	3d 85 00             	cmp    ax,0x85
     bd4:	74 05                	je     0xbdb
     bd6:	3d 0c 00             	cmp    ax,0xc
     bd9:	75 60                	jne    0xc3b
     bdb:	80 3e b4 0c 00       	cmp    BYTE PTR ds:0xcb4,0x0
     be0:	74 59                	je     0xc3b
     be2:	a1 26 15             	mov    ax,ds:0x1526
     be5:	0b 06 28 15          	or     ax,WORD PTR ds:0x1528
     be9:	74 50                	je     0xc3b
     beb:	9a ff ff 00 00       	call   0x0:0xffff
     bf0:	25 00 40             	and    ax,0x4000
     bf3:	81 e2 00 00          	and    dx,0x0
     bf7:	09 d0                	or     ax,dx
     bf9:	74 1c                	je     0xc17
     bfb:	83 7e 0c 0c          	cmp    WORD PTR [bp+0xc],0xc
     bff:	75 16                	jne    0xc17
     c01:	a1 ba 0c             	mov    ax,ds:0xcba
     c04:	0b 06 bc 0c          	or     ax,WORD PTR ds:0xcbc
     c08:	74 0d                	je     0xc17
     c0a:	a1 ba 0c             	mov    ax,ds:0xcba
     c0d:	8b 16 bc 0c          	mov    dx,WORD PTR ds:0xcbc
     c11:	89 46 06             	mov    WORD PTR [bp+0x6],ax
     c14:	89 56 08             	mov    WORD PTR [bp+0x8],dx
     c17:	ff 76 0e             	push   WORD PTR [bp+0xe]
     c1a:	6a 00                	push   0x0
     c1c:	ff 76 0e             	push   WORD PTR [bp+0xe]
     c1f:	ff 76 0c             	push   WORD PTR [bp+0xc]
     c22:	ff 76 0a             	push   WORD PTR [bp+0xa]
     c25:	ff 76 08             	push   WORD PTR [bp+0x8]
     c28:	ff 76 06             	push   WORD PTR [bp+0x6]
     c2b:	ff 1e 26 15          	call   DWORD PTR ds:0x1526
     c2f:	52                   	push   dx
     c30:	50                   	push   ax
     c31:	9a ca 0e 00 00       	call   0x0:0xeca
     c36:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
     c3b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     c3f:	83 c4 06             	add    sp,0x6
     c42:	eb 14                	jmp    0xc58
     c44:	6a 00                	push   0x0
     c46:	6a 00                	push   0x0
     c48:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     c4c:	06                   	push   es
     c4d:	57                   	push   di
     c4e:	9a 51 75 7d 0c       	call   0xc7d:0x7551
     c53:	9a 34 14 f7 0c       	call   0xcf7:0x1434
     c58:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     c5b:	5f                   	pop    di
     c5c:	5e                   	pop    si
     c5d:	8d 66 fe             	lea    sp,[bp-0x2]
     c60:	1f                   	pop    ds
     c61:	5d                   	pop    bp
     c62:	4d                   	dec    bp
     c63:	ca 0a 00             	retf   0xa
     c66:	00 00                	add    BYTE PTR [bx+si],al
     c68:	aa                   	stos   BYTE PTR es:[di],al
     c69:	0c 0f                	or     al,0xf
     c6b:	0d c8 08             	or     ax,0x8c8
     c6e:	00 00                	add    BYTE PTR [bx+si],al
     c70:	9a ff ff 00 00       	call   0x0:0xffff
     c75:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c78:	6a 00                	push   0x0
     c7a:	9a e7 0e b3 0c       	call   0xcb3:0xee7
     c7f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     c82:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     c85:	b8 66 0c             	mov    ax,0xc66
     c88:	0e                   	push   cs
     c89:	50                   	push   ax
     c8a:	55                   	push   bp
     c8b:	ff 36 58 18          	push   WORD PTR ds:0x1858
     c8f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c93:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     c96:	06                   	push   es
     c97:	57                   	push   di
     c98:	ff 5e 08             	call   DWORD PTR [bp+0x8]
     c9b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c9e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     ca2:	83 c4 06             	add    sp,0x6
     ca5:	b8 be 0c             	mov    ax,0xcbe
     ca8:	0e                   	push   cs
     ca9:	50                   	push   ax
     caa:	ff 76 fa             	push   WORD PTR [bp-0x6]
     cad:	ff 76 f8             	push   WORD PTR [bp-0x8]
     cb0:	9a f0 0f 16 0d       	call   0xd16:0xff0
     cb5:	ff 76 fc             	push   WORD PTR [bp-0x4]
     cb8:	9a ff ff 00 00       	call   0x0:0xffff
     cbd:	cb                   	retf
     cbe:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     cc1:	c9                   	leave
     cc2:	c2 08 00             	ret    0x8
     cc5:	c8 04 00 00          	enter  0x4,0x0
     cc9:	31 c0                	xor    ax,ax
     ccb:	8b 56 04             	mov    dx,WORD PTR [bp+0x4]
     cce:	52                   	push   dx
     ccf:	50                   	push   ax
     cd0:	ff 76 fc             	push   WORD PTR [bp-0x4]
     cd3:	9a ff ff 00 00       	call   0x0:0xffff
     cd8:	f7 d8                	neg    ax
     cda:	18 c0                	sbb    al,al
     cdc:	f6 d8                	neg    al
     cde:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     ce1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     ce4:	c9                   	leave
     ce5:	c2 02 00             	ret    0x2
     ce8:	55                   	push   bp
     ce9:	89 e5                	mov    bp,sp
     ceb:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     cef:	74 08                	je     0xcf9
     cf1:	83 ec 08             	sub    sp,0x8
     cf4:	9a e2 1f 04 0d       	call   0xd04:0x1fe2
     cf9:	31 c0                	xor    ax,ax
     cfb:	50                   	push   ax
     cfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cff:	06                   	push   es
     d00:	57                   	push   di
     d01:	9a 50 1f 66 0d       	call   0xd66:0x1f50
     d06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d09:	06                   	push   es
     d0a:	57                   	push   di
     d0b:	bf d7 0d             	mov    di,0xdd7
     d0e:	b8 d5 0d             	mov    ax,0xdd5
     d11:	50                   	push   ax
     d12:	57                   	push   di
     d13:	9a 89 14 59 0d       	call   0xd59:0x1489
     d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d1b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     d1f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     d23:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     d26:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
     d29:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     d2d:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
     d31:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     d35:	74 07                	je     0xd3e
     d37:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     d3b:	83 c4 06             	add    sp,0x6
     d3e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     d41:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     d44:	c9                   	leave
     d45:	ca 0a 00             	retf   0xa
     d48:	55                   	push   bp
     d49:	89 e5                	mov    bp,sp
     d4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d4e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     d52:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     d56:	9a a5 15 11 0e       	call   0xe11:0x15a5
     d5b:	31 c0                	xor    ax,ax
     d5d:	50                   	push   ax
     d5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d61:	06                   	push   es
     d62:	57                   	push   di
     d63:	9a 66 1f 71 0d       	call   0xd71:0x1f66
     d68:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     d6c:	74 05                	je     0xd73
     d6e:	9a 0f 20 16 0e       	call   0xe16:0x200f
     d73:	c9                   	leave
     d74:	ca 06 00             	retf   0x6
     d77:	c8 04 00 00          	enter  0x4,0x0
     d7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d7e:	26 83 7d 10 00       	cmp    WORD PTR es:[di+0x10],0x0
     d83:	74 44                	je     0xdc9
     d85:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     d89:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
     d8d:	74 3a                	je     0xdc9
     d8f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d92:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     d95:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     d98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d9b:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
     d9f:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
     da3:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     da7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     daa:	26 ff 35             	push   WORD PTR es:[di]
     dad:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
     db1:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     db5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     db9:	9a b5 10 00 00       	call   0x0:0x10b5
     dbe:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dc1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     dc5:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     dc9:	c9                   	leave
     dca:	ca 08 00             	retf   0x8
     dcd:	01 00                	add    WORD PTR [bx+si],ax
     dcf:	00 00                	add    BYTE PTR [bx+si],al
     dd1:	00 00                	add    BYTE PTR [bx+si],al
     dd3:	02 0e 41 0f          	add    cl,BYTE PTR ds:0xf41
     dd7:	55                   	push   bp
     dd8:	89 e5                	mov    bp,sp
     dda:	b8 cd 0d             	mov    ax,0xdcd
     ddd:	0e                   	push   cs
     dde:	50                   	push   ax
     ddf:	55                   	push   bp
     de0:	ff 36 58 18          	push   WORD PTR ds:0x1858
     de4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     de8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     deb:	06                   	push   es
     dec:	57                   	push   di
     ded:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     df0:	06                   	push   es
     df1:	57                   	push   di
     df2:	26 c4 3d             	les    di,DWORD PTR es:[di]
     df5:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
     df9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     dfd:	83 c4 06             	add    sp,0x6
     e00:	eb 16                	jmp    0xe18
     e02:	ff 76 08             	push   WORD PTR [bp+0x8]
     e05:	ff 76 06             	push   WORD PTR [bp+0x6]
     e08:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     e0c:	06                   	push   es
     e0d:	57                   	push   di
     e0e:	9a 51 75 47 11       	call   0x1147:0x7551
     e13:	9a 34 14 7e 0e       	call   0xe7e:0x1434
     e18:	c9                   	leave
     e19:	ca 08 00             	retf   0x8
     e1c:	c8 02 00 00          	enter  0x2,0x0
     e20:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
     e23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e26:	26 3a 45 12          	cmp    al,BYTE PTR es:[di+0x12]
     e2a:	74 3e                	je     0xe6a
     e2c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
     e2f:	26 88 45 12          	mov    BYTE PTR es:[di+0x12],al
     e33:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
     e38:	74 07                	je     0xe41
     e3a:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
     e3f:	eb 05                	jmp    0xe46
     e41:	c7 46 fe fe ff       	mov    WORD PTR [bp-0x2],0xfffe
     e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e49:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     e4d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     e50:	6a 00                	push   0x0
     e52:	6a 00                	push   0x0
     e54:	6a 00                	push   0x0
     e56:	6a 00                	push   0x0
     e58:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
     e5c:	98                   	cbw
     e5d:	8b f8                	mov    di,ax
     e5f:	d1 e7                	shl    di,1
     e61:	ff b5 be 0c          	push   WORD PTR [di+0xcbe]
     e65:	9a ac 14 00 00       	call   0x0:0x14ac
     e6a:	c9                   	leave
     e6b:	ca 06 00             	retf   0x6
     e6e:	55                   	push   bp
     e6f:	89 e5                	mov    bp,sp
     e71:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     e74:	06                   	push   es
     e75:	57                   	push   di
     e76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e79:	06                   	push   es
     e7a:	57                   	push   di
     e7b:	9a 38 20 de 10       	call   0x10de:0x2038
     e80:	c9                   	leave
     e81:	ca 08 00             	retf   0x8
     e84:	55                   	push   bp
     e85:	89 e5                	mov    bp,sp
     e87:	ff 76 0c             	push   WORD PTR [bp+0xc]
     e8a:	ff 76 0a             	push   WORD PTR [bp+0xa]
     e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e90:	06                   	push   es
     e91:	57                   	push   di
     e92:	26 c4 3d             	les    di,DWORD PTR es:[di]
     e95:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
     e99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e9c:	31 c0                	xor    ax,ax
     e9e:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
     ea2:	c9                   	leave
     ea3:	ca 08 00             	retf   0x8
     ea6:	55                   	push   bp
     ea7:	89 e5                	mov    bp,sp
     ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eac:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     eb0:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb7:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
     ebb:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     ebf:	6a fc                	push   0xfffc
     ec1:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     ec5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     ec9:	9a d0 0f 00 00       	call   0x0:0xfd0
     ece:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ed1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     ed5:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     ed9:	c9                   	leave
     eda:	ca 04 00             	retf   0x4
     edd:	c8 04 00 00          	enter  0x4,0x0
     ee1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ee4:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     ee7:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     eea:	26 8b 05             	mov    ax,WORD PTR es:[di]
     eed:	3d 00 01             	cmp    ax,0x100
     ef0:	74 05                	je     0xef7
     ef2:	3d 04 01             	cmp    ax,0x104
     ef5:	75 76                	jne    0xf6d
     ef7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     efa:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
     efe:	3c 26                	cmp    al,0x26
     f00:	74 04                	je     0xf06
     f02:	3c 28                	cmp    al,0x28
     f04:	75 67                	jne    0xf6d
     f06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f09:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     f0d:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
     f11:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
     f16:	75 2d                	jne    0xf45
     f18:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     f1b:	26 83 7d 02 28       	cmp    WORD PTR es:[di+0x2],0x28
     f20:	75 23                	jne    0xf45
     f22:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     f26:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     f2a:	25 00 00             	and    ax,0x0
     f2d:	81 e2 00 20          	and    dx,0x2000
     f31:	09 d0                	or     ax,dx
     f33:	74 10                	je     0xf45
     f35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f38:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     f3c:	06                   	push   es
     f3d:	57                   	push   di
     f3e:	9a d4 14 7a 0f       	call   0xf7a:0x14d4
     f43:	eb 26                	jmp    0xf6b
     f45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f48:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     f4c:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
     f50:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     f54:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     f57:	26 ff 35             	push   WORD PTR es:[di]
     f5a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
     f5e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     f62:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     f66:	9a 0d 13 00 00       	call   0x0:0x130d
     f6b:	eb 0f                	jmp    0xf7c
     f6d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f70:	06                   	push   es
     f71:	57                   	push   di
     f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f75:	06                   	push   es
     f76:	57                   	push   di
     f77:	9a 77 0d 8f 0f       	call   0xf8f:0xd77
     f7c:	c9                   	leave
     f7d:	ca 08 00             	retf   0x8
     f80:	55                   	push   bp
     f81:	89 e5                	mov    bp,sp
     f83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f86:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     f8a:	06                   	push   es
     f8b:	57                   	push   di
     f8c:	9a 94 12 f2 0f       	call   0xff2:0x1294
     f91:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f94:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f9a:	06                   	push   es
     f9b:	57                   	push   di
     f9c:	26 c4 3d             	les    di,DWORD PTR es:[di]
     f9f:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
     fa3:	c9                   	leave
     fa4:	ca 08 00             	retf   0x8
     fa7:	55                   	push   bp
     fa8:	89 e5                	mov    bp,sp
     faa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fad:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     fb1:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     fb5:	9a 72 13 00 00       	call   0x0:0x1372
     fba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fbd:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
     fc1:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     fc5:	6a fc                	push   0xfffc
     fc7:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     fcb:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     fcf:	9a 83 10 00 00       	call   0x0:0x1083
     fd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd7:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     fdb:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     fdf:	c9                   	leave
     fe0:	ca 04 00             	retf   0x4
     fe3:	55                   	push   bp
     fe4:	89 e5                	mov    bp,sp
     fe6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe9:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     fed:	06                   	push   es
     fee:	57                   	push   di
     fef:	9a 94 12 19 10       	call   0x1019:0x1294
     ff4:	ff 76 0c             	push   WORD PTR [bp+0xc]
     ff7:	ff 76 0a             	push   WORD PTR [bp+0xa]
     ffa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ffd:	06                   	push   es
     ffe:	57                   	push   di
     fff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1002:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    1006:	c9                   	leave
    1007:	ca 08 00             	retf   0x8
    100a:	55                   	push   bp
    100b:	89 e5                	mov    bp,sp
    100d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1010:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1014:	06                   	push   es
    1015:	57                   	push   di
    1016:	9a 94 12 05 11       	call   0x1105:0x1294
    101b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    101e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1021:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1024:	06                   	push   es
    1025:	57                   	push   di
    1026:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1029:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    102d:	c9                   	leave
    102e:	ca 08 00             	retf   0x8
    1031:	c8 00 01 00          	enter  0x100,0x0
    1035:	bf c2 0c             	mov    di,0xcc2
    1038:	1e                   	push   ds
    1039:	57                   	push   di
    103a:	bf c9 0c             	mov    di,0xcc9
    103d:	1e                   	push   ds
    103e:	57                   	push   di
    103f:	68 a0 40             	push   0x40a0
    1042:	6a 41                	push   0x41
    1044:	6a 00                	push   0x0
    1046:	6a 00                	push   0x0
    1048:	6a 00                	push   0x0
    104a:	6a 00                	push   0x0
    104c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    104f:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1053:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1057:	6a ff                	push   0xffff
    1059:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    105d:	6a 00                	push   0x0
    105f:	6a 00                	push   0x0
    1061:	9a e7 1a 00 00       	call   0x0:0x1ae7
    1066:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1069:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    106d:	26 83 7d 10 00       	cmp    WORD PTR es:[di+0x10],0x0
    1072:	74 47                	je     0x10bb
    1074:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1078:	6a fc                	push   0xfffc
    107a:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    107e:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1082:	9a 0b 1b 00 00       	call   0x0:0x1b0b
    1087:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    108a:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    108e:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    1092:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1096:	6a 00                	push   0x0
    1098:	9a ff ff 00 00       	call   0x0:0xffff
    109d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a0:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    10a4:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    10a8:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    10ac:	6a 07                	push   0x7
    10ae:	6a 00                	push   0x0
    10b0:	6a 00                	push   0x0
    10b2:	6a 00                	push   0x0
    10b4:	9a 6b 1d 00 00       	call   0x0:0x1d6b
    10b9:	eb 25                	jmp    0x10e0
    10bb:	8d be 00 ff          	lea    di,[bp-0x100]
    10bf:	16                   	push   ss
    10c0:	57                   	push   di
    10c1:	68 28 f0             	push   0xf028
    10c4:	9a 2b 09 d7 10       	call   0x10d7:0x92b
    10c9:	b0 01                	mov    al,0x1
    10cb:	50                   	push   ax
    10cc:	b8 22 00             	mov    ax,0x22
    10cf:	ba fc 1b             	mov    dx,0x1bfc
    10d2:	52                   	push   dx
    10d3:	50                   	push   ax
    10d4:	9a e6 28 c4 12       	call   0x12c4:0x28e6
    10d9:	52                   	push   dx
    10da:	50                   	push   ax
    10db:	9a 99 13 1a 11       	call   0x111a:0x1399
    10e0:	c9                   	leave
    10e1:	ca 04 00             	retf   0x4
    10e4:	55                   	push   bp
    10e5:	89 e5                	mov    bp,sp
    10e7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    10ea:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10f0:	06                   	push   es
    10f1:	57                   	push   di
    10f2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10f5:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    10f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10fc:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1100:	06                   	push   es
    1101:	57                   	push   di
    1102:	9a 94 12 40 11       	call   0x1140:0x1294
    1107:	c9                   	leave
    1108:	ca 08 00             	retf   0x8
    110b:	55                   	push   bp
    110c:	89 e5                	mov    bp,sp
    110e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1112:	74 08                	je     0x111c
    1114:	83 ec 08             	sub    sp,0x8
    1117:	9a e2 1f 27 11       	call   0x1127:0x1fe2
    111c:	31 c0                	xor    ax,ax
    111e:	50                   	push   ax
    111f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1122:	06                   	push   es
    1123:	57                   	push   di
    1124:	9a 50 1f 3e 12       	call   0x123e:0x1f50
    1129:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    112c:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    112f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1132:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    1136:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    113a:	06                   	push   es
    113b:	57                   	push   di
    113c:	bf 88 1d             	mov    di,0x1d88
    113f:	b8 b2 11             	mov    ax,0x11b2
    1142:	50                   	push   ax
    1143:	57                   	push   di
    1144:	9a 89 14 30 12       	call   0x1230:0x1489
    1149:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    114c:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1150:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1154:	b0 01                	mov    al,0x1
    1156:	50                   	push   ax
    1157:	b8 60 05             	mov    ax,0x560
    115a:	ba 62 11             	mov    dx,0x1162
    115d:	52                   	push   dx
    115e:	50                   	push   ax
    115f:	9a b8 17 76 11       	call   0x1176:0x17b8
    1164:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1167:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    116b:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    116f:	b0 01                	mov    al,0x1
    1171:	50                   	push   ax
    1172:	b8 3f 08             	mov    ax,0x83f
    1175:	ba 7d 11             	mov    dx,0x117d
    1178:	52                   	push   dx
    1179:	50                   	push   ax
    117a:	9a bd 56 a3 11       	call   0x11a3:0x56bd
    117f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1182:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    1186:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    118a:	6a 00                	push   0x0
    118c:	6a 00                	push   0x0
    118e:	68 e2 7f             	push   0x7fe2
    1191:	9a ff ff 00 00       	call   0x0:0xffff
    1196:	50                   	push   ax
    1197:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    119a:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    119e:	06                   	push   es
    119f:	57                   	push   di
    11a0:	9a 04 61 9b 16       	call   0x169b:0x6104
    11a5:	ff 76 08             	push   WORD PTR [bp+0x8]
    11a8:	ff 76 06             	push   WORD PTR [bp+0x6]
    11ab:	b0 01                	mov    al,0x1
    11ad:	50                   	push   ax
    11ae:	b8 27 0a             	mov    ax,0xa27
    11b1:	ba b9 11             	mov    dx,0x11b9
    11b4:	52                   	push   dx
    11b5:	50                   	push   ax
    11b6:	9a e8 0c d3 11       	call   0x11d3:0xce8
    11bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11be:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    11c2:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
    11c6:	ff 76 08             	push   WORD PTR [bp+0x8]
    11c9:	ff 76 06             	push   WORD PTR [bp+0x6]
    11cc:	b0 01                	mov    al,0x1
    11ce:	50                   	push   ax
    11cf:	b8 64 0a             	mov    ax,0xa64
    11d2:	ba da 11             	mov    dx,0x11da
    11d5:	52                   	push   dx
    11d6:	50                   	push   ax
    11d7:	9a e8 0c f4 11       	call   0x11f4:0xce8
    11dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11df:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    11e3:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    11e7:	ff 76 08             	push   WORD PTR [bp+0x8]
    11ea:	ff 76 06             	push   WORD PTR [bp+0x6]
    11ed:	b0 01                	mov    al,0x1
    11ef:	50                   	push   ax
    11f0:	b8 a4 0a             	mov    ax,0xaa4
    11f3:	ba fb 11             	mov    dx,0x11fb
    11f6:	52                   	push   dx
    11f7:	50                   	push   ax
    11f8:	9a e8 0c a5 12       	call   0x12a5:0xce8
    11fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1200:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    1204:	26 89 55 28          	mov    WORD PTR es:[di+0x28],dx
    1208:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    120c:	74 07                	je     0x1215
    120e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1212:	83 c4 06             	add    sp,0x6
    1215:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1218:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    121b:	c9                   	leave
    121c:	ca 0a 00             	retf   0xa
    121f:	55                   	push   bp
    1220:	89 e5                	mov    bp,sp
    1222:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1225:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1229:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    122d:	9a a5 15 6d 14       	call   0x146d:0x15a5
    1232:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1235:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    1239:	06                   	push   es
    123a:	57                   	push   di
    123b:	9a 7f 1f 4c 12       	call   0x124c:0x1f7f
    1240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1243:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1247:	06                   	push   es
    1248:	57                   	push   di
    1249:	9a 7f 1f 5a 12       	call   0x125a:0x1f7f
    124e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1251:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1255:	06                   	push   es
    1256:	57                   	push   di
    1257:	9a 7f 1f 68 12       	call   0x1268:0x1f7f
    125c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    125f:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    1263:	06                   	push   es
    1264:	57                   	push   di
    1265:	9a 7f 1f 76 12       	call   0x1276:0x1f7f
    126a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    126d:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    1271:	06                   	push   es
    1272:	57                   	push   di
    1273:	9a 7f 1f 83 12       	call   0x1283:0x1f7f
    1278:	31 c0                	xor    ax,ax
    127a:	50                   	push   ax
    127b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    127e:	06                   	push   es
    127f:	57                   	push   di
    1280:	9a 66 1f 8e 12       	call   0x128e:0x1f66
    1285:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1289:	74 05                	je     0x1290
    128b:	9a 0f 20 0a 1c       	call   0x1c0a:0x200f
    1290:	c9                   	leave
    1291:	ca 06 00             	retf   0x6
    1294:	55                   	push   bp
    1295:	89 e5                	mov    bp,sp
    1297:	6a 00                	push   0x0
    1299:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    129c:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    12a0:	06                   	push   es
    12a1:	57                   	push   di
    12a2:	9a 1c 0e ee 12       	call   0x12ee:0xe1c
    12a7:	c9                   	leave
    12a8:	ca 04 00             	retf   0x4
    12ab:	c8 06 01 00          	enter  0x106,0x0
    12af:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    12b2:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    12b6:	8d be fe fe          	lea    di,[bp-0x102]
    12ba:	16                   	push   ss
    12bb:	57                   	push   di
    12bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12bf:	06                   	push   es
    12c0:	57                   	push   di
    12c1:	9a 4c 0d d3 1b       	call   0x1bd3:0xd4c
    12c6:	52                   	push   dx
    12c7:	50                   	push   ax
    12c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12cb:	26 8a 05             	mov    al,BYTE PTR es:[di]
    12ce:	30 e4                	xor    ah,ah
    12d0:	50                   	push   ax
    12d1:	8d be fa fe          	lea    di,[bp-0x106]
    12d5:	16                   	push   ss
    12d6:	57                   	push   di
    12d7:	9a ff ff 00 00       	call   0x0:0xffff
    12dc:	8b 86 fa fe          	mov    ax,WORD PTR [bp-0x106]
    12e0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    12e3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    12e6:	c9                   	leave
    12e7:	c2 06 00             	ret    0x6
    12ea:	00 00                	add    BYTE PTR [bx+si],al
    12ec:	bc 14 5e             	mov    sp,0x5e14
    12ef:	15 c8 48             	adc    ax,0x48c8
    12f2:	01 00                	add    WORD PTR [bx+si],ax
    12f4:	6a 00                	push   0x0
    12f6:	9a ff ff 00 00       	call   0x0:0xffff
    12fb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    12fe:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1301:	ff 76 06             	push   WORD PTR [bp+0x6]
    1304:	6a 31                	push   0x31
    1306:	6a 00                	push   0x0
    1308:	6a 00                	push   0x0
    130a:	6a 00                	push   0x0
    130c:	9a 2d 15 00 00       	call   0x0:0x152d
    1311:	50                   	push   ax
    1312:	9a c3 14 00 00       	call   0x0:0x14c3
    1317:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    131a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    131d:	8d 7e d2             	lea    di,[bp-0x2e]
    1320:	16                   	push   ss
    1321:	57                   	push   di
    1322:	9a ff ff 00 00       	call   0x0:0xffff
    1327:	b8 ea 12             	mov    ax,0x12ea
    132a:	0e                   	push   cs
    132b:	50                   	push   ax
    132c:	55                   	push   bp
    132d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1331:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1335:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1338:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    133c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1340:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    1344:	06                   	push   es
    1345:	57                   	push   di
    1346:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1349:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    134d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1350:	83 7e f6 01          	cmp    WORD PTR [bp-0xa],0x1
    1354:	7d 05                	jge    0x135b
    1356:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    135b:	83 7e f6 08          	cmp    WORD PTR [bp-0xa],0x8
    135f:	7e 05                	jle    0x1366
    1361:	c7 46 f6 08 00       	mov    WORD PTR [bp-0xa],0x8
    1366:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1369:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    136d:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1371:	9a 52 20 00 00       	call   0x0:0x2052
    1376:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    1379:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    137c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1380:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1384:	8d 7e ca             	lea    di,[bp-0x36]
    1387:	16                   	push   ss
    1388:	57                   	push   di
    1389:	9a 9f 13 00 00       	call   0x0:0x139f
    138e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1391:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1395:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1399:	8d 7e c2             	lea    di,[bp-0x3e]
    139c:	16                   	push   ss
    139d:	57                   	push   di
    139e:	9a 98 19 00 00       	call   0x0:0x1998
    13a3:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    13a6:	2b 46 ca             	sub    ax,WORD PTR [bp-0x36]
    13a9:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    13ac:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    13af:	d1 e0                	shl    ax,1
    13b1:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    13b4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    13b7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    13bb:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    13bf:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    13c3:	06                   	push   es
    13c4:	57                   	push   di
    13c5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13c8:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    13cc:	48                   	dec    ax
    13cd:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    13d0:	31 c0                	xor    ax,ax
    13d2:	3b 46 b8             	cmp    ax,WORD PTR [bp-0x48]
    13d5:	7f 75                	jg     0x144c
    13d7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    13da:	eb 03                	jmp    0x13df
    13dc:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    13df:	8d be b8 fe          	lea    di,[bp-0x148]
    13e3:	16                   	push   ss
    13e4:	57                   	push   di
    13e5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    13e8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    13eb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    13ef:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    13f3:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    13f7:	06                   	push   es
    13f8:	57                   	push   di
    13f9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13fc:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1400:	55                   	push   bp
    1401:	e8 a7 fe             	call   0x12ab
    1404:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1407:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    140a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    140e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1412:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    1416:	06                   	push   es
    1417:	57                   	push   di
    1418:	26 c4 3d             	les    di,DWORD PTR es:[di]
    141b:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    141f:	3d 08 00             	cmp    ax,0x8
    1422:	7e 0a                	jle    0x142e
    1424:	6a 02                	push   0x2
    1426:	9a ff ff 00 00       	call   0x0:0xffff
    142b:	01 46 f8             	add    WORD PTR [bp-0x8],ax
    142e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1431:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1434:	7e 0e                	jle    0x1444
    1436:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1439:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    143c:	7d 06                	jge    0x1444
    143e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1441:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1444:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1447:	3b 46 b8             	cmp    ax,WORD PTR [bp-0x48]
    144a:	75 90                	jne    0x13dc
    144c:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    144f:	f7 66 f6             	mul    WORD PTR [bp-0xa]
    1452:	40                   	inc    ax
    1453:	40                   	inc    ax
    1454:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    1457:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    145a:	2b 46 cc             	sub    ax,WORD PTR [bp-0x34]
    145d:	03 46 cc             	add    ax,WORD PTR [bp-0x34]
    1460:	48                   	dec    ax
    1461:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    1464:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    1468:	06                   	push   es
    1469:	57                   	push   di
    146a:	9a a5 60 c0 1d       	call   0x1dc0:0x60a5
    146f:	8b d0                	mov    dx,ax
    1471:	8b 46 ba             	mov    ax,WORD PTR [bp-0x46]
    1474:	03 46 bc             	add    ax,WORD PTR [bp-0x44]
    1477:	3b c2                	cmp    ax,dx
    1479:	7e 0a                	jle    0x1485
    147b:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    147e:	2b 46 bc             	sub    ax,WORD PTR [bp-0x44]
    1481:	40                   	inc    ax
    1482:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    1485:	83 7e ba 00          	cmp    WORD PTR [bp-0x46],0x0
    1489:	7d 0d                	jge    0x1498
    148b:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    148e:	2b 46 cc             	sub    ax,WORD PTR [bp-0x34]
    1491:	03 46 cc             	add    ax,WORD PTR [bp-0x34]
    1494:	48                   	dec    ax
    1495:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    1498:	ff 76 06             	push   WORD PTR [bp+0x6]
    149b:	6a 00                	push   0x0
    149d:	ff 76 ca             	push   WORD PTR [bp-0x36]
    14a0:	ff 76 ba             	push   WORD PTR [bp-0x46]
    14a3:	ff 76 f4             	push   WORD PTR [bp-0xc]
    14a6:	ff 76 bc             	push   WORD PTR [bp-0x44]
    14a9:	6a 10                	push   0x10
    14ab:	9a b3 1a 00 00       	call   0x0:0x1ab3
    14b0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    14b4:	83 c4 06             	add    sp,0x6
    14b7:	b8 d0 14             	mov    ax,0x14d0
    14ba:	0e                   	push   cs
    14bb:	50                   	push   ax
    14bc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14bf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    14c2:	9a ff ff 00 00       	call   0x0:0xffff
    14c7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14ca:	9a ff ff 00 00       	call   0x0:0xffff
    14cf:	cb                   	retf
    14d0:	c9                   	leave
    14d1:	c2 04 00             	ret    0x4
    14d4:	c8 02 01 00          	enter  0x102,0x0
    14d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14db:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    14df:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    14e4:	75 7a                	jne    0x1560
    14e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14e9:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    14ed:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    14f1:	55                   	push   bp
    14f2:	e8 fb fd             	call   0x12f0
    14f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f8:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    14fc:	9a ff ff 00 00       	call   0x0:0xffff
    1501:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1504:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1508:	8d be 00 ff          	lea    di,[bp-0x100]
    150c:	16                   	push   ss
    150d:	57                   	push   di
    150e:	68 00 01             	push   0x100
    1511:	9a ff ff 00 00       	call   0x0:0xffff
    1516:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1519:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    151d:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1521:	68 23 04             	push   0x423
    1524:	6a ff                	push   0xffff
    1526:	8d be 00 ff          	lea    di,[bp-0x100]
    152a:	16                   	push   ss
    152b:	57                   	push   di
    152c:	9a 4c 15 00 00       	call   0x0:0x154c
    1531:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1535:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1538:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    153c:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1540:	68 07 04             	push   0x407
    1543:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    1547:	6a 00                	push   0x0
    1549:	6a 00                	push   0x0
    154b:	9a 87 15 00 00       	call   0x0:0x1587
    1550:	6a 01                	push   0x1
    1552:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1555:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1559:	06                   	push   es
    155a:	57                   	push   di
    155b:	9a 1c 0e 4e 16       	call   0x164e:0xe1c
    1560:	c9                   	leave
    1561:	ca 04 00             	retf   0x4
    1564:	c8 06 01 00          	enter  0x106,0x0
    1568:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    156b:	26 83 7d 06 01       	cmp    WORD PTR es:[di+0x6],0x1
    1570:	75 69                	jne    0x15db
    1572:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1575:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1579:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    157d:	68 09 04             	push   0x409
    1580:	6a 00                	push   0x0
    1582:	6a 00                	push   0x0
    1584:	6a 00                	push   0x0
    1586:	9a ac 15 00 00       	call   0x0:0x15ac
    158b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    158e:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    1592:	74 47                	je     0x15db
    1594:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1597:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    159b:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    159f:	68 0a 04             	push   0x40a
    15a2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    15a5:	8d be fe fe          	lea    di,[bp-0x102]
    15a9:	16                   	push   ss
    15aa:	57                   	push   di
    15ab:	9a d7 15 00 00       	call   0x0:0x15d7
    15b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15b3:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    15b7:	8d be fe fe          	lea    di,[bp-0x102]
    15bb:	16                   	push   ss
    15bc:	57                   	push   di
    15bd:	9a ff ff 00 00       	call   0x0:0xffff
    15c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15c5:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    15c9:	68 01 04             	push   0x401
    15cc:	6a 00                	push   0x0
    15ce:	6a 00                	push   0x0
    15d0:	6a ff                	push   0xffff
    15d2:	5a                   	pop    dx
    15d3:	58                   	pop    ax
    15d4:	52                   	push   dx
    15d5:	50                   	push   ax
    15d6:	9a c1 19 00 00       	call   0x0:0x19c1
    15db:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15de:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15e4:	06                   	push   es
    15e5:	57                   	push   di
    15e6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15e9:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    15ed:	c9                   	leave
    15ee:	ca 08 00             	retf   0x8
    15f1:	55                   	push   bp
    15f2:	89 e5                	mov    bp,sp
    15f4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15f7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15fd:	06                   	push   es
    15fe:	57                   	push   di
    15ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1602:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    1606:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1609:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    160d:	26 83 7d 10 00       	cmp    WORD PTR es:[di+0x10],0x0
    1612:	74 10                	je     0x1624
    1614:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1617:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    161b:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    161f:	9a 3f 1c 00 00       	call   0x0:0x1c3f
    1624:	c9                   	leave
    1625:	ca 08 00             	retf   0x8
    1628:	55                   	push   bp
    1629:	89 e5                	mov    bp,sp
    162b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    162e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1631:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1634:	06                   	push   es
    1635:	57                   	push   di
    1636:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1639:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    163d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1640:	31 c0                	xor    ax,ax
    1642:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1646:	c9                   	leave
    1647:	ca 08 00             	retf   0x8
    164a:	00 00                	add    BYTE PTR [bx+si],al
    164c:	30 18                	xor    BYTE PTR [bx+si],bl
    164e:	54                   	push   sp
    164f:	16                   	push   ss
    1650:	00 00                	add    BYTE PTR [bx+si],al
    1652:	4d                   	dec    bp
    1653:	18 98 18 c8          	sbb    BYTE PTR [bx+si-0x37e8],bl
    1657:	36 00 00             	add    BYTE PTR ss:[bx+si],al
    165a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    165d:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1661:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1664:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1668:	75 14                	jne    0x167e
    166a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    166d:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1671:	8d 7e de             	lea    di,[bp-0x22]
    1674:	16                   	push   ss
    1675:	57                   	push   di
    1676:	9a ff ff 00 00       	call   0x0:0xffff
    167b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    167e:	b8 50 16             	mov    ax,0x1650
    1681:	0e                   	push   cs
    1682:	50                   	push   ax
    1683:	55                   	push   bp
    1684:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1688:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    168c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    168f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1692:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    1696:	06                   	push   es
    1697:	57                   	push   di
    1698:	9a 5d 22 e2 16       	call   0x16e2:0x225d
    169d:	b8 4a 16             	mov    ax,0x164a
    16a0:	0e                   	push   cs
    16a1:	50                   	push   ax
    16a2:	55                   	push   bp
    16a3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    16a7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    16ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ae:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    16b2:	8d 7e d2             	lea    di,[bp-0x2e]
    16b5:	16                   	push   ss
    16b6:	57                   	push   di
    16b7:	9a 03 19 00 00       	call   0x0:0x1903
    16bc:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    16bf:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    16c2:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    16c5:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    16c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16cb:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    16cf:	89 7e ca             	mov    WORD PTR [bp-0x36],di
    16d2:	8c 46 cc             	mov    WORD PTR [bp-0x34],es
    16d5:	6a ff                	push   0xffff
    16d7:	6a f9                	push   0xfff9
    16d9:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    16dd:	06                   	push   es
    16de:	57                   	push   di
    16df:	9a da 13 f4 16       	call   0x16f4:0x13da
    16e4:	6a ff                	push   0xffff
    16e6:	6a f0                	push   0xfff0
    16e8:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    16eb:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    16ef:	06                   	push   es
    16f0:	57                   	push   di
    16f1:	9a 84 16 08 17       	call   0x1708:0x1684
    16f6:	6a 00                	push   0x0
    16f8:	6a 00                	push   0x0
    16fa:	ff 76 d0             	push   WORD PTR [bp-0x30]
    16fd:	ff 76 ce             	push   WORD PTR [bp-0x32]
    1700:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    1703:	06                   	push   es
    1704:	57                   	push   di
    1705:	9a 22 1e 24 17       	call   0x1724:0x1e22
    170a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    170d:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    1712:	74 14                	je     0x1728
    1714:	6a ff                	push   0xffff
    1716:	6a ef                	push   0xffef
    1718:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    171b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    171f:	06                   	push   es
    1720:	57                   	push   di
    1721:	9a da 13 38 17       	call   0x1738:0x13da
    1726:	eb 12                	jmp    0x173a
    1728:	6a ff                	push   0xffff
    172a:	6a eb                	push   0xffeb
    172c:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    172f:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1733:	06                   	push   es
    1734:	57                   	push   di
    1735:	9a da 13 4a 17       	call   0x174a:0x13da
    173a:	6a 01                	push   0x1
    173c:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    173f:	48                   	dec    ax
    1740:	48                   	dec    ax
    1741:	50                   	push   ax
    1742:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    1745:	06                   	push   es
    1746:	57                   	push   di
    1747:	9a b8 1d 58 17       	call   0x1758:0x1db8
    174c:	6a 01                	push   0x1
    174e:	6a 01                	push   0x1
    1750:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    1753:	06                   	push   es
    1754:	57                   	push   di
    1755:	9a 7b 1d 69 17       	call   0x1769:0x1d7b
    175a:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    175d:	48                   	dec    ax
    175e:	50                   	push   ax
    175f:	6a 01                	push   0x1
    1761:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    1764:	06                   	push   es
    1765:	57                   	push   di
    1766:	9a 7b 1d cd 17       	call   0x17cd:0x1d7b
    176b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    176e:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1772:	06                   	push   es
    1773:	57                   	push   di
    1774:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1777:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    177b:	8b d0                	mov    dx,ax
    177d:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    1780:	2b c2                	sub    ax,dx
    1782:	99                   	cwd
    1783:	b9 02 00             	mov    cx,0x2
    1786:	f7 f9                	idiv   cx
    1788:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    178b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    178e:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1792:	06                   	push   es
    1793:	57                   	push   di
    1794:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1797:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    179b:	8b d0                	mov    dx,ax
    179d:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    17a0:	2b c2                	sub    ax,dx
    17a2:	99                   	cwd
    17a3:	b9 02 00             	mov    cx,0x2
    17a6:	f7 f9                	idiv   cx
    17a8:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    17ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17ae:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    17b3:	74 08                	je     0x17bd
    17b5:	ff 46 dc             	inc    WORD PTR [bp-0x24]
    17b8:	ff 46 da             	inc    WORD PTR [bp-0x26]
    17bb:	eb 4c                	jmp    0x1809
    17bd:	6a ff                	push   0xffff
    17bf:	6a ef                	push   0xffef
    17c1:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    17c4:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    17c8:	06                   	push   es
    17c9:	57                   	push   di
    17ca:	9a da 13 df 17       	call   0x17df:0x13da
    17cf:	6a 01                	push   0x1
    17d1:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    17d4:	48                   	dec    ax
    17d5:	48                   	dec    ax
    17d6:	50                   	push   ax
    17d7:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    17da:	06                   	push   es
    17db:	57                   	push   di
    17dc:	9a b8 1d f5 17       	call   0x17f5:0x1db8
    17e1:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    17e4:	48                   	dec    ax
    17e5:	48                   	dec    ax
    17e6:	50                   	push   ax
    17e7:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    17ea:	48                   	dec    ax
    17eb:	48                   	dec    ax
    17ec:	50                   	push   ax
    17ed:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    17f0:	06                   	push   es
    17f1:	57                   	push   di
    17f2:	9a 7b 1d 07 18       	call   0x1807:0x1d7b
    17f7:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    17fa:	48                   	dec    ax
    17fb:	48                   	dec    ax
    17fc:	50                   	push   ax
    17fd:	6a 00                	push   0x0
    17ff:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    1802:	06                   	push   es
    1803:	57                   	push   di
    1804:	9a 7b 1d 22 18       	call   0x1822:0x1d7b
    1809:	ff 76 dc             	push   WORD PTR [bp-0x24]
    180c:	ff 76 da             	push   WORD PTR [bp-0x26]
    180f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1812:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    1816:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    181a:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    181d:	06                   	push   es
    181e:	57                   	push   di
    181f:	9a 9b 1b 3e 18       	call   0x183e:0x1b9b
    1824:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1828:	83 c4 06             	add    sp,0x6
    182b:	b8 41 18             	mov    ax,0x1841
    182e:	0e                   	push   cs
    182f:	50                   	push   ax
    1830:	6a 00                	push   0x0
    1832:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1835:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    1839:	06                   	push   es
    183a:	57                   	push   di
    183b:	9a 5d 22 c6 28       	call   0x28c6:0x225d
    1840:	cb                   	retf
    1841:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1845:	83 c4 06             	add    sp,0x6
    1848:	b8 69 18             	mov    ax,0x1869
    184b:	0e                   	push   cs
    184c:	50                   	push   ax
    184d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1850:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    1855:	75 11                	jne    0x1868
    1857:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    185a:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    185e:	8d 7e de             	lea    di,[bp-0x22]
    1861:	16                   	push   ss
    1862:	57                   	push   di
    1863:	9a ff ff 00 00       	call   0x0:0xffff
    1868:	cb                   	retf
    1869:	c9                   	leave
    186a:	ca 08 00             	retf   0x8
    186d:	55                   	push   bp
    186e:	89 e5                	mov    bp,sp
    1870:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1873:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1876:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1879:	06                   	push   es
    187a:	57                   	push   di
    187b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    187e:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    1882:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1885:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1889:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    188e:	74 0c                	je     0x189c
    1890:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1893:	06                   	push   es
    1894:	57                   	push   di
    1895:	9a 94 12 a4 18       	call   0x18a4:0x1294
    189a:	eb 2a                	jmp    0x18c6
    189c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    189f:	06                   	push   es
    18a0:	57                   	push   di
    18a1:	9a d4 14 c4 18       	call   0x18c4:0x14d4
    18a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18a9:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    18ad:	9a ff ff 00 00       	call   0x0:0xffff
    18b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18b5:	26 c6 45 18 01       	mov    BYTE PTR es:[di+0x18],0x1
    18ba:	26 c6 45 19 01       	mov    BYTE PTR es:[di+0x19],0x1
    18bf:	06                   	push   es
    18c0:	57                   	push   di
    18c1:	9a 03 1d 4b 19       	call   0x194b:0x1d03
    18c6:	c9                   	leave
    18c7:	ca 08 00             	retf   0x8
    18ca:	c8 12 00 00          	enter  0x12,0x0
    18ce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    18d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    18d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d7:	06                   	push   es
    18d8:	57                   	push   di
    18d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18dc:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    18e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e3:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    18e8:	75 03                	jne    0x18ed
    18ea:	e9 f1 00             	jmp    0x19de
    18ed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18f0:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    18f3:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    18f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18f9:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    18fd:	8d 7e f2             	lea    di,[bp-0xe]
    1900:	16                   	push   ss
    1901:	57                   	push   di
    1902:	9a ff ff 00 00       	call   0x0:0xffff
    1907:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    190a:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    190f:	7c 19                	jl     0x192a
    1911:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    1916:	7c 12                	jl     0x192a
    1918:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    191c:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    191f:	7d 09                	jge    0x192a
    1921:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1925:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1928:	7c 04                	jl     0x192e
    192a:	b0 00                	mov    al,0x0
    192c:	eb 02                	jmp    0x1930
    192e:	b0 01                	mov    al,0x1
    1930:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1933:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1936:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    193a:	3a 46 ff             	cmp    al,BYTE PTR [bp-0x1]
    193d:	74 0e                	je     0x194d
    193f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1942:	26 88 45 18          	mov    BYTE PTR es:[di+0x18],al
    1946:	06                   	push   es
    1947:	57                   	push   di
    1948:	9a 03 1d 18 1a       	call   0x1a18:0x1d03
    194d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1950:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    1955:	74 03                	je     0x195a
    1957:	e9 84 00             	jmp    0x19de
    195a:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    195e:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    1963:	74 79                	je     0x19de
    1965:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1968:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    196c:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1970:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1973:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1979:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    197d:	8d 7e fa             	lea    di,[bp-0x6]
    1980:	16                   	push   ss
    1981:	57                   	push   di
    1982:	9a ff ff 00 00       	call   0x0:0xffff
    1987:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    198a:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    198e:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1992:	8d 7e f2             	lea    di,[bp-0xe]
    1995:	16                   	push   ss
    1996:	57                   	push   di
    1997:	9a 73 1a 00 00       	call   0x0:0x1a73
    199c:	8d 7e f2             	lea    di,[bp-0xe]
    199f:	16                   	push   ss
    19a0:	57                   	push   di
    19a1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19a4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    19a7:	9a ff ff 00 00       	call   0x0:0xffff
    19ac:	09 c0                	or     ax,ax
    19ae:	74 2e                	je     0x19de
    19b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19b3:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    19b7:	68 02 02             	push   0x202
    19ba:	6a 00                	push   0x0
    19bc:	6a 00                	push   0x0
    19be:	6a 00                	push   0x0
    19c0:	9a da 19 00 00       	call   0x0:0x19da
    19c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19c8:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    19cc:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    19d0:	68 01 02             	push   0x201
    19d3:	6a 00                	push   0x0
    19d5:	6a 00                	push   0x0
    19d7:	6a 00                	push   0x0
    19d9:	9a 41 1b 00 00       	call   0x0:0x1b41
    19de:	c9                   	leave
    19df:	ca 08 00             	retf   0x8
    19e2:	55                   	push   bp
    19e3:	89 e5                	mov    bp,sp
    19e5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19e8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    19eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19ee:	06                   	push   es
    19ef:	57                   	push   di
    19f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19f3:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    19f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19fa:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    19ff:	74 19                	je     0x1a1a
    1a01:	9a ff ff 00 00       	call   0x0:0xffff
    1a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a09:	26 c6 45 18 00       	mov    BYTE PTR es:[di+0x18],0x0
    1a0e:	26 c6 45 19 00       	mov    BYTE PTR es:[di+0x19],0x0
    1a13:	06                   	push   es
    1a14:	57                   	push   di
    1a15:	9a 03 1d 26 1a       	call   0x1a26:0x1d03
    1a1a:	c9                   	leave
    1a1b:	ca 08 00             	retf   0x8
    1a1e:	01 00                	add    WORD PTR [bx+si],ax
    1a20:	00 00                	add    BYTE PTR [bx+si],al
    1a22:	00 00                	add    BYTE PTR [bx+si],al
    1a24:	30 1c                	xor    BYTE PTR [si],bl
    1a26:	3d 1a c8             	cmp    ax,0xc81a
    1a29:	0e                   	push   cs
    1a2a:	02 00                	add    al,BYTE PTR [bx+si]
    1a2c:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    1a30:	75 03                	jne    0x1a35
    1a32:	e9 18 02             	jmp    0x1c4d
    1a35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a38:	06                   	push   es
    1a39:	57                   	push   di
    1a3a:	9a 60 1c 86 1d       	call   0x1d86:0x1c60
    1a3f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a42:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a45:	9a a6 20 00 00       	call   0x0:0x20a6
    1a4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a4d:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1a51:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    1a56:	75 03                	jne    0x1a5b
    1a58:	e9 f2 01             	jmp    0x1c4d
    1a5b:	b8 1e 1a             	mov    ax,0x1a1e
    1a5e:	0e                   	push   cs
    1a5f:	50                   	push   ax
    1a60:	55                   	push   bp
    1a61:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1a65:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1a69:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1a6d:	8d 7e f8             	lea    di,[bp-0x8]
    1a70:	16                   	push   ss
    1a71:	57                   	push   di
    1a72:	9a ff ff 00 00       	call   0x0:0xffff
    1a77:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a7a:	8d 7e f8             	lea    di,[bp-0x8]
    1a7d:	16                   	push   ss
    1a7e:	57                   	push   di
    1a7f:	9a 8d 1a 00 00       	call   0x0:0x1a8d
    1a84:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a87:	8d 7e fc             	lea    di,[bp-0x4]
    1a8a:	16                   	push   ss
    1a8b:	57                   	push   di
    1a8c:	9a ff ff 00 00       	call   0x0:0xffff
    1a91:	83 6e fc 19          	sub    WORD PTR [bp-0x4],0x19
    1a95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a98:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1a9c:	6a 00                	push   0x0
    1a9e:	6a 00                	push   0x0
    1aa0:	6a 00                	push   0x0
    1aa2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1aa5:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    1aa8:	50                   	push   ax
    1aa9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1aac:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1aaf:	50                   	push   ax
    1ab0:	6a 02                	push   0x2
    1ab2:	9a ff ff 00 00       	call   0x0:0xffff
    1ab7:	bf ca 0c             	mov    di,0xcca
    1aba:	1e                   	push   ds
    1abb:	57                   	push   di
    1abc:	bf d8 0c             	mov    di,0xcd8
    1abf:	1e                   	push   ds
    1ac0:	57                   	push   di
    1ac1:	68 00 50             	push   0x5000
    1ac4:	6a 00                	push   0x0
    1ac6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ac9:	05 08 00             	add    ax,0x8
    1acc:	50                   	push   ax
    1acd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1ad0:	6a 11                	push   0x11
    1ad2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ad5:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1ad8:	50                   	push   ax
    1ad9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1adc:	6a ff                	push   0xffff
    1ade:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1ae2:	6a 00                	push   0x0
    1ae4:	6a 00                	push   0x0
    1ae6:	9a ff ff 00 00       	call   0x0:0xffff
    1aeb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aee:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1af2:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    1af7:	75 03                	jne    0x1afc
    1af9:	e9 eb 00             	jmp    0x1be7
    1afc:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1b00:	6a fc                	push   0xfffc
    1b02:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1b06:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1b0a:	9a ff ff 00 00       	call   0x0:0xffff
    1b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b12:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1b16:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    1b1a:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1b1e:	06                   	push   es
    1b1f:	57                   	push   di
    1b20:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b23:	26 ff 1d             	call   DWORD PTR es:[di]
    1b26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b29:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    1b2d:	06                   	push   es
    1b2e:	57                   	push   di
    1b2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b32:	26 ff 1d             	call   DWORD PTR es:[di]
    1b35:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b38:	6a 31                	push   0x31
    1b3a:	6a 00                	push   0x0
    1b3c:	6a 00                	push   0x0
    1b3e:	6a 00                	push   0x0
    1b40:	9a 5f 1b 00 00       	call   0x0:0x1b5f
    1b45:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    1b49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b4c:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1b50:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1b54:	6a 30                	push   0x30
    1b56:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    1b5a:	6a 00                	push   0x0
    1b5c:	6a 00                	push   0x0
    1b5e:	9a d8 1b 00 00       	call   0x0:0x1bd8
    1b63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b66:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1b6a:	26 8b 45 1f          	mov    ax,WORD PTR es:[di+0x1f]
    1b6e:	26 0b 45 21          	or     ax,WORD PTR es:[di+0x21]
    1b72:	74 71                	je     0x1be5
    1b74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b77:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1b7b:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    1b7f:	06                   	push   es
    1b80:	57                   	push   di
    1b81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b84:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1b88:	48                   	dec    ax
    1b89:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1b8d:	31 c0                	xor    ax,ax
    1b8f:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    1b93:	7f 50                	jg     0x1be5
    1b95:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1b98:	eb 03                	jmp    0x1b9d
    1b9a:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    1b9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ba0:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    1ba4:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1ba8:	68 01 04             	push   0x401
    1bab:	6a 00                	push   0x0
    1bad:	8d be f6 fe          	lea    di,[bp-0x10a]
    1bb1:	16                   	push   ss
    1bb2:	57                   	push   di
    1bb3:	8d be f2 fd          	lea    di,[bp-0x20e]
    1bb7:	16                   	push   ss
    1bb8:	57                   	push   di
    1bb9:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1bbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bbf:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1bc3:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    1bc7:	06                   	push   es
    1bc8:	57                   	push   di
    1bc9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bcc:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1bd0:	9a 4c 0d f3 1b       	call   0x1bf3:0xd4c
    1bd5:	52                   	push   dx
    1bd6:	50                   	push   ax
    1bd7:	9a fd 29 00 00       	call   0x0:0x29fd
    1bdc:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1bdf:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    1be3:	75 b5                	jne    0x1b9a
    1be5:	eb 25                	jmp    0x1c0c
    1be7:	8d be f4 fd          	lea    di,[bp-0x20c]
    1beb:	16                   	push   ss
    1bec:	57                   	push   di
    1bed:	68 28 f0             	push   0xf028
    1bf0:	9a 2b 09 03 1c       	call   0x1c03:0x92b
    1bf5:	b0 01                	mov    al,0x1
    1bf7:	50                   	push   ax
    1bf8:	b8 22 00             	mov    ax,0x22
    1bfb:	ba ef 1c             	mov    dx,0x1cef
    1bfe:	52                   	push   dx
    1bff:	50                   	push   ax
    1c00:	9a e6 28 be 1c       	call   0x1cbe:0x28e6
    1c05:	52                   	push   dx
    1c06:	50                   	push   ax
    1c07:	9a 99 13 46 1c       	call   0x1c46:0x1399
    1c0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c0f:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    1c13:	06                   	push   es
    1c14:	57                   	push   di
    1c15:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c18:	26 ff 1d             	call   DWORD PTR es:[di]
    1c1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c1e:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1c22:	9a 20 1d 00 00       	call   0x0:0x1d20
    1c27:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1c2b:	83 c4 06             	add    sp,0x6
    1c2e:	eb 1d                	jmp    0x1c4d
    1c30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c33:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    1c38:	74 09                	je     0x1c43
    1c3a:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1c3e:	9a ff ff 00 00       	call   0x0:0xffff
    1c43:	ea 85 13 4b 1c       	jmp    0x1c4b:0x1385
    1c48:	9a 34 14 8a 1c       	call   0x1c8a:0x1434
    1c4d:	c9                   	leave
    1c4e:	ca 08 00             	retf   0x8
    1c51:	0e                   	push   cs
    1c52:	44                   	inc    sp
    1c53:	72 6f                	jb     0x1cc4
    1c55:	70 4c                	jo     0x1ca3
    1c57:	69 73 74 42 75       	imul   si,WORD PTR [bp+di+0x74],0x7542
    1c5c:	74 74                	je     0x1cd2
    1c5e:	6f                   	outs   dx,WORD PTR ds:[si]
    1c5f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c60:	c8 5a 01 00          	enter  0x15a,0x0
    1c64:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1c68:	bf da 0c             	mov    di,0xcda
    1c6b:	1e                   	push   ds
    1c6c:	57                   	push   di
    1c6d:	8d 7e e6             	lea    di,[bp-0x1a]
    1c70:	16                   	push   ss
    1c71:	57                   	push   di
    1c72:	9a ff ff 00 00       	call   0x0:0xffff
    1c77:	09 c0                	or     ax,ax
    1c79:	74 03                	je     0x1c7e
    1c7b:	e9 81 00             	jmp    0x1cff
    1c7e:	8d 7e e6             	lea    di,[bp-0x1a]
    1c81:	16                   	push   ss
    1c82:	57                   	push   di
    1c83:	6a 1a                	push   0x1a
    1c85:	6a 00                	push   0x0
    1c87:	9a e5 1e fd 1c       	call   0x1cfd:0x1ee5
    1c8c:	c7 46 e6 03 00       	mov    WORD PTR [bp-0x1a],0x3
    1c91:	b8 ff ff             	mov    ax,0xffff
    1c94:	ba ff ff             	mov    dx,0xffff
    1c97:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1c9a:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    1c9d:	6a 00                	push   0x0
    1c9f:	6a 00                	push   0x0
    1ca1:	68 00 7f             	push   0x7f00
    1ca4:	9a ff ff 00 00       	call   0x0:0xffff
    1ca9:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1cac:	c7 46 f6 06 00       	mov    WORD PTR [bp-0xa],0x6
    1cb1:	8d 7e a6             	lea    di,[bp-0x5a]
    1cb4:	16                   	push   ss
    1cb5:	57                   	push   di
    1cb6:	bf 51 1c             	mov    di,0x1c51
    1cb9:	0e                   	push   cs
    1cba:	57                   	push   di
    1cbb:	9a 4c 0d e6 1c       	call   0x1ce6:0xd4c
    1cc0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cc3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1cc6:	a1 8c 18             	mov    ax,ds:0x188c
    1cc9:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1ccc:	8d 7e e6             	lea    di,[bp-0x1a]
    1ccf:	16                   	push   ss
    1cd0:	57                   	push   di
    1cd1:	9a ff ff 00 00       	call   0x0:0xffff
    1cd6:	09 c0                	or     ax,ax
    1cd8:	75 25                	jne    0x1cff
    1cda:	8d be a6 fe          	lea    di,[bp-0x15a]
    1cde:	16                   	push   ss
    1cdf:	57                   	push   di
    1ce0:	68 27 f0             	push   0xf027
    1ce3:	9a 2b 09 f6 1c       	call   0x1cf6:0x92b
    1ce8:	b0 01                	mov    al,0x1
    1cea:	50                   	push   ax
    1ceb:	b8 22 00             	mov    ax,0x22
    1cee:	ba eb 31             	mov    dx,0x31eb
    1cf1:	52                   	push   dx
    1cf2:	50                   	push   ax
    1cf3:	9a e6 28 50 22       	call   0x2250:0x28e6
    1cf8:	52                   	push   dx
    1cf9:	50                   	push   ax
    1cfa:	9a 99 13 a6 1d       	call   0x1da6:0x1399
    1cff:	c9                   	leave
    1d00:	ca 04 00             	retf   0x4
    1d03:	55                   	push   bp
    1d04:	89 e5                	mov    bp,sp
    1d06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d09:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1d0d:	6a 00                	push   0x0
    1d0f:	6a 00                	push   0x0
    1d11:	6a 00                	push   0x0
    1d13:	9a ff ff 00 00       	call   0x0:0xffff
    1d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d1b:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1d1f:	9a ff ff 00 00       	call   0x0:0xffff
    1d24:	c9                   	leave
    1d25:	ca 04 00             	retf   0x4
    1d28:	c8 04 00 00          	enter  0x4,0x0
    1d2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d2f:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    1d34:	74 44                	je     0x1d7a
    1d36:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1d3a:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    1d3e:	74 3a                	je     0x1d7a
    1d40:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d43:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1d46:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1d49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d4c:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1d50:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    1d54:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1d58:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1d5b:	26 ff 35             	push   WORD PTR es:[di]
    1d5e:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1d62:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1d66:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1d6a:	9a ff ff 00 00       	call   0x0:0xffff
    1d6f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1d72:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1d76:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    1d7a:	c9                   	leave
    1d7b:	ca 08 00             	retf   0x8
    1d7e:	01 00                	add    WORD PTR [bx+si],ax
    1d80:	00 00                	add    BYTE PTR [bx+si],al
    1d82:	00 00                	add    BYTE PTR [bx+si],al
    1d84:	b1 1d                	mov    cl,0x1d
    1d86:	e9 1d 55             	jmp    0x72a6
    1d89:	89 e5                	mov    bp,sp
    1d8b:	b8 7e 1d             	mov    ax,0x1d7e
    1d8e:	0e                   	push   cs
    1d8f:	50                   	push   ax
    1d90:	55                   	push   bp
    1d91:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1d95:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1d99:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d9c:	06                   	push   es
    1d9d:	57                   	push   di
    1d9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da1:	06                   	push   es
    1da2:	57                   	push   di
    1da3:	9a 38 20 c5 1d       	call   0x1dc5:0x2038
    1da8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1dac:	83 c4 06             	add    sp,0x6
    1daf:	eb 16                	jmp    0x1dc7
    1db1:	ff 76 08             	push   WORD PTR [bp+0x8]
    1db4:	ff 76 06             	push   WORD PTR [bp+0x6]
    1db7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1dbb:	06                   	push   es
    1dbc:	57                   	push   di
    1dbd:	9a 51 75 9d 1e       	call   0x1e9d:0x7551
    1dc2:	9a 34 14 e5 1d       	call   0x1de5:0x1434
    1dc7:	c9                   	leave
    1dc8:	ca 08 00             	retf   0x8
	...
    1dd3:	f3 1d 10 00          	repz sbb ax,0x10
    1dd7:	a3 02 ea             	mov    ds:0xea02,ax
    1dda:	1e                   	push   ds
    1ddb:	64 20 a2 1e 9a       	and    BYTE PTR fs:[bp+si-0x65e2],ah
    1de0:	1f                   	pop    ds
    1de1:	dd 1d                	fstp   QWORD PTR [di]
    1de3:	cb                   	retf
    1de4:	1f                   	pop    ds
    1de5:	e1 1d                	loope  0x1e04
    1de7:	b5 1e                	mov    ch,0x1e
    1de9:	0d 1e fb             	or     ax,0xfb1e
    1dec:	0c f1                	or     al,0xf1
    1dee:	1d 17 0e             	sbb    ax,0xe17
    1df1:	d9 1d                	fstp   DWORD PTR [di]
    1df3:	11 54 43             	adc    WORD PTR [si+0x43],dx
    1df6:	6f                   	outs   dx,WORD PTR ds:[si]
    1df7:	6d                   	ins    WORD PTR es:[di],dx
    1df8:	6d                   	ins    WORD PTR es:[di],dx
    1df9:	6f                   	outs   dx,WORD PTR ds:[si]
    1dfa:	6e                   	outs   dx,BYTE PTR ds:[si]
    1dfb:	44                   	inc    sp
    1dfc:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
    1e01:	4c                   	dec    sp
    1e02:	69 73 74 01 00       	imul   si,WORD PTR [bp+di+0x74],0x1
    1e07:	00 00                	add    BYTE PTR [bx+si],al
    1e09:	00 00                	add    BYTE PTR [bx+si],al
    1e0b:	90                   	nop
    1e0c:	1e                   	push   ds
    1e0d:	54                   	push   sp
    1e0e:	1e                   	push   ds
    1e0f:	8c d0                	mov    ax,ss
    1e11:	90                   	nop
    1e12:	45                   	inc    bp
    1e13:	55                   	push   bp
    1e14:	89 e5                	mov    bp,sp
    1e16:	1e                   	push   ds
    1e17:	8e d8                	mov    ds,ax
    1e19:	83 ec 04             	sub    sp,0x4
    1e1c:	56                   	push   si
    1e1d:	57                   	push   di
    1e1e:	b8 05 1e             	mov    ax,0x1e05
    1e21:	0e                   	push   cs
    1e22:	50                   	push   ax
    1e23:	55                   	push   bp
    1e24:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1e28:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1e2c:	31 c0                	xor    ax,ax
    1e2e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e31:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e34:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    1e38:	7c 22                	jl     0x1e5c
    1e3a:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1e3e:	75 1c                	jne    0x1e5c
    1e40:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e43:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e49:	06                   	push   es
    1e4a:	57                   	push   di
    1e4b:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    1e4f:	06                   	push   es
    1e50:	57                   	push   di
    1e51:	9a 63 20 0e 1f       	call   0x1f0e:0x2063
    1e56:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e59:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1e5c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1e5f:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    1e62:	75 23                	jne    0x1e87
    1e64:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    1e68:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1e6c:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1e70:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e73:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e76:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e79:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e7c:	9a ff ff 00 00       	call   0x0:0xffff
    1e81:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e84:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1e87:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1e8b:	83 c4 06             	add    sp,0x6
    1e8e:	eb 14                	jmp    0x1ea4
    1e90:	6a 00                	push   0x0
    1e92:	6a 00                	push   0x0
    1e94:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1e98:	06                   	push   es
    1e99:	57                   	push   di
    1e9a:	9a 51 75 5d 1f       	call   0x1f5d:0x7551
    1e9f:	9a 34 14 f5 1e       	call   0x1ef5:0x1434
    1ea4:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1ea7:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1eaa:	5f                   	pop    di
    1eab:	5e                   	pop    si
    1eac:	8d 66 fe             	lea    sp,[bp-0x2]
    1eaf:	1f                   	pop    ds
    1eb0:	5d                   	pop    bp
    1eb1:	4d                   	dec    bp
    1eb2:	ca 08 00             	retf   0x8
    1eb5:	55                   	push   bp
    1eb6:	89 e5                	mov    bp,sp
    1eb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ebb:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1ebf:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    1ec3:	74 1a                	je     0x1edf
    1ec5:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1ec9:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1ecd:	9a b0 1f 00 00       	call   0x0:0x1fb0
    1ed2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ed5:	31 c0                	xor    ax,ax
    1ed7:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1edb:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1edf:	31 c0                	xor    ax,ax
    1ee1:	50                   	push   ax
    1ee2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ee5:	06                   	push   es
    1ee6:	57                   	push   di
    1ee7:	9a 0f 0c 40 1f       	call   0x1f40:0xc0f
    1eec:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ef0:	74 05                	je     0x1ef7
    1ef2:	9a 0f 20 ed 20       	call   0x20ed:0x200f
    1ef7:	c9                   	leave
    1ef8:	ca 06 00             	retf   0x6
    1efb:	55                   	push   bp
    1efc:	89 e5                	mov    bp,sp
    1efe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f01:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1f06:	75 2a                	jne    0x1f32
    1f08:	6a ff                	push   0xffff
    1f0a:	bf 0f 1e             	mov    di,0x1e0f
    1f0d:	b8 94 21             	mov    ax,0x2194
    1f10:	50                   	push   ax
    1f11:	57                   	push   di
    1f12:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1f16:	9a 52 3f ff ff       	call   0xffff:0x3f52
    1f1b:	50                   	push   ax
    1f1c:	9a ff ff 00 00       	call   0x0:0xffff
    1f21:	50                   	push   ax
    1f22:	9a ff ff 00 00       	call   0x0:0xffff
    1f27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2a:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1f2e:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1f32:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f35:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3b:	06                   	push   es
    1f3c:	57                   	push   di
    1f3d:	9a 2b 0c 74 1f       	call   0x1f74:0xc2b
    1f42:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f45:	06                   	push   es
    1f46:	57                   	push   di
    1f47:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f4a:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    1f4e:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    1f52:	52                   	push   dx
    1f53:	50                   	push   ax
    1f54:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1f58:	06                   	push   es
    1f59:	57                   	push   di
    1f5a:	9a 39 73 91 1f       	call   0x1f91:0x7339
    1f5f:	c9                   	leave
    1f60:	ca 08 00             	retf   0x8
    1f63:	55                   	push   bp
    1f64:	89 e5                	mov    bp,sp
    1f66:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f69:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6f:	06                   	push   es
    1f70:	57                   	push   di
    1f71:	9a a7 0f 00 21       	call   0x2100:0xfa7
    1f76:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f79:	06                   	push   es
    1f7a:	57                   	push   di
    1f7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f7e:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    1f82:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    1f86:	52                   	push   dx
    1f87:	50                   	push   ax
    1f88:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1f8c:	06                   	push   es
    1f8d:	57                   	push   di
    1f8e:	9a a7 73 5e 21       	call   0x215e:0x73a7
    1f93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f96:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1f9b:	75 24                	jne    0x1fc1
    1f9d:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1fa1:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    1fa5:	74 1a                	je     0x1fc1
    1fa7:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1fab:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1faf:	9a ff ff 00 00       	call   0x0:0xffff
    1fb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb7:	31 c0                	xor    ax,ax
    1fb9:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1fbd:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1fc1:	c9                   	leave
    1fc2:	ca 08 00             	retf   0x8
    1fc5:	c8 02 00 00          	enter  0x2,0x0
    1fc9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1fcc:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    1fd0:	26 83 7d 04 70       	cmp    WORD PTR es:[di+0x4],0x70
    1fd5:	75 29                	jne    0x2000
    1fd7:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1fdb:	26 8b 55 08          	mov    dx,WORD PTR es:[di+0x8]
    1fdf:	25 04 00             	and    ax,0x4
    1fe2:	81 e2 00 00          	and    dx,0x0
    1fe6:	09 d0                	or     ax,dx
    1fe8:	75 16                	jne    0x2000
    1fea:	6a 11                	push   0x11
    1fec:	9a f8 1f 00 00       	call   0x0:0x1ff8
    1ff1:	09 c0                	or     ax,ax
    1ff3:	7c 0b                	jl     0x2000
    1ff5:	6a 10                	push   0x10
    1ff7:	9a ff ff 00 00       	call   0x0:0xffff
    1ffc:	09 c0                	or     ax,ax
    1ffe:	7d 04                	jge    0x2004
    2000:	b0 00                	mov    al,0x0
    2002:	eb 02                	jmp    0x2006
    2004:	b0 01                	mov    al,0x1
    2006:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2009:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    200c:	c9                   	leave
    200d:	c2 02 00             	ret    0x2
    2010:	55                   	push   bp
    2011:	89 e5                	mov    bp,sp
    2013:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2016:	31 c0                	xor    ax,ax
    2018:	36 89 45 fa          	mov    WORD PTR ss:[di-0x6],ax
    201c:	31 c0                	xor    ax,ax
    201e:	36 89 45 f8          	mov    WORD PTR ss:[di-0x8],ax
    2022:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2025:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    2029:	26 8b 05             	mov    ax,WORD PTR es:[di]
    202c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    202f:	36 89 45 f6          	mov    WORD PTR ss:[di-0xa],ax
    2033:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2036:	36 83 7d f6 00       	cmp    WORD PTR ss:[di-0xa],0x0
    203b:	74 22                	je     0x205f
    203d:	36 8b 45 fa          	mov    ax,WORD PTR ss:[di-0x6]
    2041:	36 89 45 f8          	mov    WORD PTR ss:[di-0x8],ax
    2045:	36 8b 45 f6          	mov    ax,WORD PTR ss:[di-0xa]
    2049:	36 89 45 fa          	mov    WORD PTR ss:[di-0x6],ax
    204d:	36 ff 75 f6          	push   WORD PTR ss:[di-0xa]
    2051:	9a ff ff 00 00       	call   0x0:0xffff
    2056:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2059:	36 89 45 f6          	mov    WORD PTR ss:[di-0xa],ax
    205d:	eb d4                	jmp    0x2033
    205f:	c9                   	leave
    2060:	c2 02 00             	ret    0x2
    2063:	c8 0c 00 00          	enter  0xc,0x0
    2067:	31 c0                	xor    ax,ax
    2069:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    206c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    206f:	55                   	push   bp
    2070:	e8 9d ff             	call   0x2010
    2073:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    2077:	74 5b                	je     0x20d4
    2079:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    207c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2080:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
    2084:	75 4e                	jne    0x20d4
    2086:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    208a:	74 48                	je     0x20d4
    208c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    208f:	26 81 7d 02 00 01    	cmp    WORD PTR es:[di+0x2],0x100
    2095:	75 3d                	jne    0x20d4
    2097:	55                   	push   bp
    2098:	e8 2a ff             	call   0x1fc5
    209b:	08 c0                	or     al,al
    209d:	74 35                	je     0x20d4
    209f:	ff 76 f8             	push   WORD PTR [bp-0x8]
    20a2:	68 0e 04             	push   0x40e
    20a5:	9a ff ff 00 00       	call   0x0:0xffff
    20aa:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    20ad:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    20b1:	74 21                	je     0x20d4
    20b3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    20b6:	68 11 01             	push   0x111
    20b9:	68 0e 04             	push   0x40e
    20bc:	6a 00                	push   0x0
    20be:	ff 76 f4             	push   WORD PTR [bp-0xc]
    20c1:	5a                   	pop    dx
    20c2:	58                   	pop    ax
    20c3:	52                   	push   dx
    20c4:	50                   	push   ax
    20c5:	9a ff ff 00 00       	call   0x0:0xffff
    20ca:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    20cf:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    20d4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    20d7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    20da:	c9                   	leave
    20db:	ca 0c 00             	retf   0xc
    20de:	55                   	push   bp
    20df:	89 e5                	mov    bp,sp
    20e1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    20e5:	74 08                	je     0x20ef
    20e7:	83 ec 08             	sub    sp,0x8
    20ea:	9a e2 1f 81 21       	call   0x2181:0x1fe2
    20ef:	ff 76 0e             	push   WORD PTR [bp+0xe]
    20f2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20f5:	31 c0                	xor    ax,ax
    20f7:	50                   	push   ax
    20f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20fb:	06                   	push   es
    20fc:	57                   	push   di
    20fd:	9a d9 4b 9d 21       	call   0x219d:0x4bd9
    2102:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2105:	26 c6 45 1a 01       	mov    BYTE PTR es:[di+0x1a],0x1
    210a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    210e:	74 07                	je     0x2117
    2110:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2114:	83 c4 06             	add    sp,0x6
    2117:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    211a:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    211d:	c9                   	leave
    211e:	ca 0a 00             	retf   0xa
    2121:	8c d0                	mov    ax,ss
    2123:	90                   	nop
    2124:	45                   	inc    bp
    2125:	55                   	push   bp
    2126:	89 e5                	mov    bp,sp
    2128:	1e                   	push   ds
    2129:	8e d8                	mov    ds,ax
    212b:	83 ec 02             	sub    sp,0x2
    212e:	56                   	push   si
    212f:	57                   	push   di
    2130:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
    2134:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2137:	26 8b 05             	mov    ax,WORD PTR es:[di]
    213a:	3b 06 d4 2a          	cmp    ax,WORD PTR ds:0x2ad4
    213e:	75 24                	jne    0x2164
    2140:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2143:	26 8b 45 1b          	mov    ax,WORD PTR es:[di+0x1b]
    2147:	26 0b 45 1d          	or     ax,WORD PTR es:[di+0x1d]
    214b:	74 17                	je     0x2164
    214d:	26 ff 75 1d          	push   WORD PTR es:[di+0x1d]
    2151:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    2155:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2159:	06                   	push   es
    215a:	57                   	push   di
    215b:	9a 92 77 88 2a       	call   0x2a88:0x7792
    2160:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    2164:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    2167:	5f                   	pop    di
    2168:	5e                   	pop    si
    2169:	8d 66 fe             	lea    sp,[bp-0x2]
    216c:	1f                   	pop    ds
    216d:	5d                   	pop    bp
    216e:	4d                   	dec    bp
    216f:	ca 08 00             	retf   0x8
    2172:	55                   	push   bp
    2173:	89 e5                	mov    bp,sp
    2175:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2179:	74 08                	je     0x2183
    217b:	83 ec 08             	sub    sp,0x8
    217e:	9a e2 1f 7e 22       	call   0x227e:0x1fe2
    2183:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2186:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2189:	31 c0                	xor    ax,ax
    218b:	50                   	push   ax
    218c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    218f:	06                   	push   es
    2190:	57                   	push   di
    2191:	9a de 20 db 21       	call   0x21db:0x20de
    2196:	b0 01                	mov    al,0x1
    2198:	50                   	push   ax
    2199:	b8 c9 03             	mov    ax,0x3c9
    219c:	ba a4 21             	mov    dx,0x21a4
    219f:	52                   	push   dx
    21a0:	50                   	push   ax
    21a1:	9a 08 1d b8 21       	call   0x21b8:0x1d08
    21a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a9:	26 89 45 1f          	mov    WORD PTR es:[di+0x1f],ax
    21ad:	26 89 55 21          	mov    WORD PTR es:[di+0x21],dx
    21b1:	b0 01                	mov    al,0x1
    21b3:	50                   	push   ax
    21b4:	b8 c9 03             	mov    ax,0x3c9
    21b7:	ba bf 21             	mov    dx,0x21bf
    21ba:	52                   	push   dx
    21bb:	50                   	push   ax
    21bc:	9a 08 1d a8 22       	call   0x22a8:0x1d08
    21c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c4:	26 89 85 8b 00       	mov    WORD PTR es:[di+0x8b],ax
    21c9:	26 89 95 8d 00       	mov    WORD PTR es:[di+0x8d],dx
    21ce:	ff 76 08             	push   WORD PTR [bp+0x8]
    21d1:	ff 76 06             	push   WORD PTR [bp+0x6]
    21d4:	b0 01                	mov    al,0x1
    21d6:	50                   	push   ax
    21d7:	b8 68 02             	mov    ax,0x268
    21da:	ba e2 21             	mov    dx,0x21e2
    21dd:	52                   	push   dx
    21de:	50                   	push   ax
    21df:	9a 0b 11 65 24       	call   0x2465:0x110b
    21e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e7:	26 89 45 23          	mov    WORD PTR es:[di+0x23],ax
    21eb:	26 89 55 25          	mov    WORD PTR es:[di+0x25],dx
    21ef:	a1 16 17             	mov    ax,ds:0x1716
    21f2:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    21f6:	26 89 45 29          	mov    WORD PTR es:[di+0x29],ax
    21fa:	26 89 55 2b          	mov    WORD PTR es:[di+0x2b],dx
    21fe:	a1 16 17             	mov    ax,ds:0x1716
    2201:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    2205:	26 89 45 2f          	mov    WORD PTR es:[di+0x2f],ax
    2209:	26 89 55 31          	mov    WORD PTR es:[di+0x31],dx
    220d:	a1 16 17             	mov    ax,ds:0x1716
    2210:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    2214:	26 89 45 33          	mov    WORD PTR es:[di+0x33],ax
    2218:	26 89 55 35          	mov    WORD PTR es:[di+0x35],dx
    221c:	26 c7 45 2d 01 00    	mov    WORD PTR es:[di+0x2d],0x1
    2222:	26 c6 85 8f 00 00    	mov    BYTE PTR es:[di+0x8f],0x0
    2228:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    222c:	74 07                	je     0x2235
    222e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2232:	83 c4 06             	add    sp,0x6
    2235:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2238:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    223b:	c9                   	leave
    223c:	ca 0a 00             	retf   0xa
    223f:	55                   	push   bp
    2240:	89 e5                	mov    bp,sp
    2242:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2245:	26 ff 75 35          	push   WORD PTR es:[di+0x35]
    2249:	26 ff 75 33          	push   WORD PTR es:[di+0x33]
    224d:	9a 24 06 60 22       	call   0x2260:0x624
    2252:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2255:	26 ff 75 31          	push   WORD PTR es:[di+0x31]
    2259:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
    225d:	9a 24 06 70 22       	call   0x2270:0x624
    2262:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2265:	26 ff 75 2b          	push   WORD PTR es:[di+0x2b]
    2269:	26 ff 75 29          	push   WORD PTR es:[di+0x29]
    226d:	9a 24 06 d9 22       	call   0x22d9:0x624
    2272:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2275:	26 c4 7d 23          	les    di,DWORD PTR es:[di+0x23]
    2279:	06                   	push   es
    227a:	57                   	push   di
    227b:	9a 7f 1f 8c 22       	call   0x228c:0x1f7f
    2280:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2283:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2287:	06                   	push   es
    2288:	57                   	push   di
    2289:	9a 7f 1f 9b 22       	call   0x229b:0x1f7f
    228e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2291:	26 c4 bd 8b 00       	les    di,DWORD PTR es:[di+0x8b]
    2296:	06                   	push   es
    2297:	57                   	push   di
    2298:	9a 7f 1f b3 22       	call   0x22b3:0x1f7f
    229d:	31 c0                	xor    ax,ax
    229f:	50                   	push   ax
    22a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a3:	06                   	push   es
    22a4:	57                   	push   di
    22a5:	9a 2b 4c 13 29       	call   0x2913:0x4c2b
    22aa:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    22ae:	74 05                	je     0x22b5
    22b0:	9a 0f 20 b4 23       	call   0x23b4:0x200f
    22b5:	c9                   	leave
    22b6:	ca 06 00             	retf   0x6
    22b9:	c8 04 00 00          	enter  0x4,0x0
    22bd:	31 c0                	xor    ax,ax
    22bf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    22c2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    22c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c8:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    22cc:	74 3b                	je     0x2309
    22ce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22d4:	06                   	push   es
    22d5:	57                   	push   di
    22d6:	9a 4c 0d 2f 25       	call   0x252f:0xd4c
    22db:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    22de:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    22e1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    22e4:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    22e8:	74 15                	je     0x22ff
    22ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    22ed:	26 80 3d 7c          	cmp    BYTE PTR es:[di],0x7c
    22f1:	75 07                	jne    0x22fa
    22f3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    22f6:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    22fa:	ff 46 0a             	inc    WORD PTR [bp+0xa]
    22fd:	eb e2                	jmp    0x22e1
    22ff:	ff 46 0a             	inc    WORD PTR [bp+0xa]
    2302:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2305:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2309:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    230c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    230f:	c9                   	leave
    2310:	c2 0a 00             	ret    0xa
    2313:	c8 02 00 00          	enter  0x2,0x0
    2317:	31 c0                	xor    ax,ax
    2319:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    231c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    231f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2322:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2325:	03 f8                	add    di,ax
    2327:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    232b:	74 30                	je     0x235d
    232d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2330:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2333:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2336:	03 f8                	add    di,ax
    2338:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    233c:	74 1f                	je     0x235d
    233e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2341:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2344:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2347:	03 f8                	add    di,ax
    2349:	26 8a 15             	mov    dl,BYTE PTR es:[di]
    234c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    234f:	40                   	inc    ax
    2350:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2353:	03 f8                	add    di,ax
    2355:	26 88 15             	mov    BYTE PTR es:[di],dl
    2358:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    235b:	eb bf                	jmp    0x231c
    235d:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    2360:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2363:	26 88 05             	mov    BYTE PTR es:[di],al
    2366:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2369:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    236c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    236f:	03 f8                	add    di,ax
    2371:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2375:	75 0b                	jne    0x2382
    2377:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    237a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    237d:	26 01 05             	add    WORD PTR es:[di],ax
    2380:	eb 0a                	jmp    0x238c
    2382:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2385:	40                   	inc    ax
    2386:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2389:	26 01 05             	add    WORD PTR es:[di],ax
    238c:	c9                   	leave
    238d:	c2 06 00             	ret    0x6
    2390:	01 5c c8             	add    WORD PTR [si-0x38],bx
    2393:	00 03                	add    BYTE PTR [bp+di],al
    2395:	00 8d be 00          	add    BYTE PTR [di+0xbe],cl
    2399:	fd                   	std
    239a:	16                   	push   ss
    239b:	57                   	push   di
    239c:	8d 7e 06             	lea    di,[bp+0x6]
    239f:	16                   	push   ss
    23a0:	57                   	push   di
    23a1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    23a4:	57                   	push   di
    23a5:	e8 6b ff             	call   0x2313
    23a8:	8d be 00 ff          	lea    di,[bp-0x100]
    23ac:	16                   	push   ss
    23ad:	57                   	push   di
    23ae:	68 ff 00             	push   0xff
    23b1:	9a e7 17 de 23       	call   0x23de:0x17e7
    23b6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    23bb:	75 03                	jne    0x23c0
    23bd:	e9 9d 00             	jmp    0x245d
    23c0:	8d be 00 fd          	lea    di,[bp-0x300]
    23c4:	16                   	push   ss
    23c5:	57                   	push   di
    23c6:	8d 7e 06             	lea    di,[bp+0x6]
    23c9:	16                   	push   ss
    23ca:	57                   	push   di
    23cb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    23ce:	57                   	push   di
    23cf:	e8 41 ff             	call   0x2313
    23d2:	8d be 00 fe          	lea    di,[bp-0x200]
    23d6:	16                   	push   ss
    23d7:	57                   	push   di
    23d8:	68 ff 00             	push   0xff
    23db:	9a e7 17 f6 23       	call   0x23f6:0x17e7
    23e0:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    23e5:	74 3b                	je     0x2422
    23e7:	8d be 00 fd          	lea    di,[bp-0x300]
    23eb:	16                   	push   ss
    23ec:	57                   	push   di
    23ed:	8d be 00 ff          	lea    di,[bp-0x100]
    23f1:	16                   	push   ss
    23f2:	57                   	push   di
    23f3:	9a cd 17 00 24       	call   0x2400:0x17cd
    23f8:	bf 90 23             	mov    di,0x2390
    23fb:	0e                   	push   cs
    23fc:	57                   	push   di
    23fd:	9a 4c 18 0b 24       	call   0x240b:0x184c
    2402:	8d be 00 fe          	lea    di,[bp-0x200]
    2406:	16                   	push   ss
    2407:	57                   	push   di
    2408:	9a 4c 18 88 24       	call   0x2488:0x184c
    240d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2410:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2414:	26 c4 bd 8b 00       	les    di,DWORD PTR es:[di+0x8b]
    2419:	06                   	push   es
    241a:	57                   	push   di
    241b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    241e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2422:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    2427:	75 97                	jne    0x23c0
    2429:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    242c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2430:	26 c4 bd 8b 00       	les    di,DWORD PTR es:[di+0x8b]
    2435:	06                   	push   es
    2436:	57                   	push   di
    2437:	26 c4 3d             	les    di,DWORD PTR es:[di]
    243a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    243e:	09 c0                	or     ax,ax
    2440:	75 1b                	jne    0x245d
    2442:	8d be 00 ff          	lea    di,[bp-0x100]
    2446:	16                   	push   ss
    2447:	57                   	push   di
    2448:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    244b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    244f:	26 c4 bd 8b 00       	les    di,DWORD PTR es:[di+0x8b]
    2454:	06                   	push   es
    2455:	57                   	push   di
    2456:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2459:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    245d:	c9                   	leave
    245e:	c2 06 00             	ret    0x6
    2461:	00 00                	add    BYTE PTR [bx+si],al
    2463:	10 27                	adc    BYTE PTR [bx],ah
    2465:	ec                   	in     al,dx
    2466:	25 c8 f2             	and    ax,0xf2c8
    2469:	02 00                	add    al,BYTE PTR [bx+si]
    246b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246e:	26 c4 bd 8b 00       	les    di,DWORD PTR es:[di+0x8b]
    2473:	06                   	push   es
    2474:	57                   	push   di
    2475:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2478:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    247c:	8d 7e b4             	lea    di,[bp-0x4c]
    247f:	16                   	push   ss
    2480:	57                   	push   di
    2481:	6a 48                	push   0x48
    2483:	6a 00                	push   0x0
    2485:	9a e5 1e fc 24       	call   0x24fc:0x1ee5
    248a:	c7 46 b4 48 00       	mov    WORD PTR [bp-0x4c],0x48
    248f:	c7 46 b6 00 00       	mov    WORD PTR [bp-0x4a],0x0
    2494:	a1 8c 18             	mov    ax,ds:0x188c
    2497:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    249a:	8d be 0e fe          	lea    di,[bp-0x1f2]
    249e:	16                   	push   ss
    249f:	57                   	push   di
    24a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a3:	26 c4 7d 29          	les    di,DWORD PTR es:[di+0x29]
    24a7:	06                   	push   es
    24a8:	57                   	push   di
    24a9:	55                   	push   bp
    24aa:	e8 0c fe             	call   0x22b9
    24ad:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    24b0:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    24b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b6:	26 8b 45 2d          	mov    ax,WORD PTR es:[di+0x2d]
    24ba:	99                   	cwd
    24bb:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    24be:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
    24c1:	26 f6 45 27 40       	test   BYTE PTR es:[di+0x27],0x40
    24c6:	74 0c                	je     0x24d4
    24c8:	c7 46 d0 00 10       	mov    WORD PTR [bp-0x30],0x1000
    24cd:	c7 46 d2 00 00       	mov    WORD PTR [bp-0x2e],0x0
    24d2:	eb 0a                	jmp    0x24de
    24d4:	c7 46 d0 50 00       	mov    WORD PTR [bp-0x30],0x50
    24d9:	c7 46 d2 00 00       	mov    WORD PTR [bp-0x2e],0x0
    24de:	b8 61 24             	mov    ax,0x2461
    24e1:	0e                   	push   cs
    24e2:	50                   	push   ax
    24e3:	55                   	push   bp
    24e4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    24e8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    24ec:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    24ef:	8b 56 d2             	mov    dx,WORD PTR [bp-0x2e]
    24f2:	05 01 00             	add    ax,0x1
    24f5:	83 d2 00             	adc    dx,0x0
    24f8:	50                   	push   ax
    24f9:	9a 82 01 1b 25       	call   0x251b:0x182
    24fe:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    2501:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    2504:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    2507:	06                   	push   es
    2508:	57                   	push   di
    2509:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    250c:	8b 56 d2             	mov    dx,WORD PTR [bp-0x2e]
    250f:	05 01 00             	add    ax,0x1
    2512:	83 d2 00             	adc    dx,0x0
    2515:	50                   	push   ax
    2516:	6a 00                	push   0x0
    2518:	9a e5 1e a4 26       	call   0x26a4:0x1ee5
    251d:	ff 76 ce             	push   WORD PTR [bp-0x32]
    2520:	ff 76 cc             	push   WORD PTR [bp-0x34]
    2523:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2526:	81 c7 3b 00          	add    di,0x3b
    252a:	06                   	push   es
    252b:	57                   	push   di
    252c:	9a 4c 0d 45 25       	call   0x2545:0xd4c
    2531:	8d be 60 ff          	lea    di,[bp-0xa0]
    2535:	16                   	push   ss
    2536:	57                   	push   di
    2537:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    253a:	26 c4 7d 2f          	les    di,DWORD PTR es:[di+0x2f]
    253e:	06                   	push   es
    253f:	57                   	push   di
    2540:	6a 4f                	push   0x4f
    2542:	9a 6a 0d 61 25       	call   0x2561:0xd6a
    2547:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    254a:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    254d:	8d be 10 ff          	lea    di,[bp-0xf0]
    2551:	16                   	push   ss
    2552:	57                   	push   di
    2553:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2556:	26 c4 7d 33          	les    di,DWORD PTR es:[di+0x33]
    255a:	06                   	push   es
    255b:	57                   	push   di
    255c:	6a 4f                	push   0x4f
    255e:	9a 6a 0d e0 25       	call   0x25e0:0xd6a
    2563:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2566:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2569:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    256c:	26 c4 7d 33          	les    di,DWORD PTR es:[di+0x33]
    2570:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2574:	76 0d                	jbe    0x2583
    2576:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    2579:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    257c:	a3 ba 0c             	mov    ds:0xcba,ax
    257f:	89 16 bc 0c          	mov    WORD PTR ds:0xcbc,dx
    2583:	c7 46 e4 20 00       	mov    WORD PTR [bp-0x1c],0x20
    2588:	c7 46 e6 00 00       	mov    WORD PTR [bp-0x1a],0x0
    258d:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
    2591:	eb 03                	jmp    0x2596
    2593:	fe 46 fd             	inc    BYTE PTR [bp-0x3]
    2596:	8a 4e fd             	mov    cl,BYTE PTR [bp-0x3]
    2599:	80 f9 10             	cmp    cl,0x10
    259c:	73 2b                	jae    0x25c9
    259e:	b8 01 00             	mov    ax,0x1
    25a1:	d3 c0                	rol    ax,cl
    25a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a6:	26 85 45 27          	test   WORD PTR es:[di+0x27],ax
    25aa:	74 1d                	je     0x25c9
    25ac:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    25af:	98                   	cbw
    25b0:	8b f8                	mov    di,ax
    25b2:	c1 e7 02             	shl    di,0x2
    25b5:	8b 85 ea 0c          	mov    ax,WORD PTR [di+0xcea]
    25b9:	8b 95 ec 0c          	mov    dx,WORD PTR [di+0xcec]
    25bd:	0b 46 e4             	or     ax,WORD PTR [bp-0x1c]
    25c0:	0b 56 e6             	or     dx,WORD PTR [bp-0x1a]
    25c3:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    25c6:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    25c9:	80 7e fd 0d          	cmp    BYTE PTR [bp-0x3],0xd
    25cd:	75 c4                	jne    0x2593
    25cf:	8d 7e b0             	lea    di,[bp-0x50]
    25d2:	16                   	push   ss
    25d3:	57                   	push   di
    25d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d7:	81 c7 37 00          	add    di,0x37
    25db:	06                   	push   es
    25dc:	57                   	push   di
    25dd:	9a 4c 0d 9b 27       	call   0x279b:0xd4c
    25e2:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    25e5:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    25e8:	b8 cf 0a             	mov    ax,0xacf
    25eb:	ba 33 26             	mov    dx,0x2633
    25ee:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    25f1:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    25f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f7:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
    25fb:	a2 b4 0c             	mov    ds:0xcb4,al
    25fe:	c6 06 b5 0c 00       	mov    BYTE PTR ds:0xcb5,0x0
    2603:	26 80 bd 8f 00 01    	cmp    BYTE PTR es:[di+0x8f],0x1
    2609:	75 11                	jne    0x261c
    260b:	26 8b 45 23          	mov    ax,WORD PTR es:[di+0x23]
    260f:	26 8b 55 25          	mov    dx,WORD PTR es:[di+0x25]
    2613:	a3 b6 0c             	mov    ds:0xcb6,ax
    2616:	89 16 b8 0c          	mov    WORD PTR ds:0xcb8,dx
    261a:	eb 08                	jmp    0x2624
    261c:	31 c0                	xor    ax,ax
    261e:	a3 b6 0c             	mov    ds:0xcb6,ax
    2621:	a3 b8 0c             	mov    ds:0xcb8,ax
    2624:	ff 76 08             	push   WORD PTR [bp+0x8]
    2627:	ff 76 06             	push   WORD PTR [bp+0x6]
    262a:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    262e:	06                   	push   es
    262f:	57                   	push   di
    2630:	9a fb 1e 68 26       	call   0x2668:0x1efb
    2635:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2639:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    263d:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    2640:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2643:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2646:	8d 7e b4             	lea    di,[bp-0x4c]
    2649:	16                   	push   ss
    264a:	57                   	push   di
    264b:	e8 1e e6             	call   0xc6c
    264e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2651:	31 c0                	xor    ax,ax
    2653:	a3 ba 0c             	mov    ds:0xcba,ax
    2656:	a3 bc 0c             	mov    ds:0xcbc,ax
    2659:	ff 76 08             	push   WORD PTR [bp+0x8]
    265c:	ff 76 06             	push   WORD PTR [bp+0x6]
    265f:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    2663:	06                   	push   es
    2664:	57                   	push   di
    2665:	9a 63 1f 89 28       	call   0x2889:0x1f63
    266a:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    266e:	75 03                	jne    0x2673
    2670:	e9 91 00             	jmp    0x2704
    2673:	ff 76 ce             	push   WORD PTR [bp-0x32]
    2676:	ff 76 cc             	push   WORD PTR [bp-0x34]
    2679:	55                   	push   bp
    267a:	e8 15 fd             	call   0x2392
    267d:	8d be 0e fd          	lea    di,[bp-0x2f2]
    2681:	16                   	push   ss
    2682:	57                   	push   di
    2683:	6a 00                	push   0x0
    2685:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2688:	26 c4 bd 8b 00       	les    di,DWORD PTR es:[di+0x8b]
    268d:	06                   	push   es
    268e:	57                   	push   di
    268f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2692:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2696:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2699:	81 c7 3b 00          	add    di,0x3b
    269d:	06                   	push   es
    269e:	57                   	push   di
    269f:	6a 4f                	push   0x4f
    26a1:	9a e7 17 26 27       	call   0x2726:0x17e7
    26a6:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    26a9:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    26ac:	25 00 04             	and    ax,0x400
    26af:	81 e2 00 00          	and    dx,0x0
    26b3:	09 d0                	or     ax,dx
    26b5:	74 10                	je     0x26c7
    26b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ba:	26 8b 45 27          	mov    ax,WORD PTR es:[di+0x27]
    26be:	0d 80 00             	or     ax,0x80
    26c1:	26 89 45 27          	mov    WORD PTR es:[di+0x27],ax
    26c5:	eb 0e                	jmp    0x26d5
    26c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ca:	26 8b 45 27          	mov    ax,WORD PTR es:[di+0x27]
    26ce:	25 7f ff             	and    ax,0xff7f
    26d1:	26 89 45 27          	mov    WORD PTR es:[di+0x27],ax
    26d5:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    26d8:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    26db:	25 01 00             	and    ax,0x1
    26de:	81 e2 00 00          	and    dx,0x0
    26e2:	09 d0                	or     ax,dx
    26e4:	74 10                	je     0x26f6
    26e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e9:	26 8b 45 27          	mov    ax,WORD PTR es:[di+0x27]
    26ed:	0d 01 00             	or     ax,0x1
    26f0:	26 89 45 27          	mov    WORD PTR es:[di+0x27],ax
    26f4:	eb 0e                	jmp    0x2704
    26f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f9:	26 8b 45 27          	mov    ax,WORD PTR es:[di+0x27]
    26fd:	25 fe ff             	and    ax,0xfffe
    2700:	26 89 45 27          	mov    WORD PTR es:[di+0x27],ax
    2704:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2708:	83 c4 06             	add    sp,0x6
    270b:	b8 29 27             	mov    ax,0x2729
    270e:	0e                   	push   cs
    270f:	50                   	push   ax
    2710:	ff 76 ce             	push   WORD PTR [bp-0x32]
    2713:	ff 76 cc             	push   WORD PTR [bp-0x34]
    2716:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    2719:	8b 56 d2             	mov    dx,WORD PTR [bp-0x2e]
    271c:	05 01 00             	add    ax,0x1
    271f:	83 d2 00             	adc    dx,0x0
    2722:	50                   	push   ax
    2723:	9a 9c 01 47 27       	call   0x2747:0x19c
    2728:	cb                   	retf
    2729:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    272c:	c9                   	leave
    272d:	ca 08 00             	retf   0x8
    2730:	55                   	push   bp
    2731:	89 e5                	mov    bp,sp
    2733:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2736:	26 c4 7d 29          	les    di,DWORD PTR es:[di+0x29]
    273a:	06                   	push   es
    273b:	57                   	push   di
    273c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    273f:	06                   	push   es
    2740:	57                   	push   di
    2741:	68 ff 00             	push   0xff
    2744:	9a e7 17 64 27       	call   0x2764:0x17e7
    2749:	c9                   	leave
    274a:	ca 04 00             	retf   0x4
    274d:	55                   	push   bp
    274e:	89 e5                	mov    bp,sp
    2750:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2753:	26 c4 7d 2f          	les    di,DWORD PTR es:[di+0x2f]
    2757:	06                   	push   es
    2758:	57                   	push   di
    2759:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    275c:	06                   	push   es
    275d:	57                   	push   di
    275e:	68 ff 00             	push   0xff
    2761:	9a e7 17 81 27       	call   0x2781:0x17e7
    2766:	c9                   	leave
    2767:	ca 04 00             	retf   0x4
    276a:	55                   	push   bp
    276b:	89 e5                	mov    bp,sp
    276d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2770:	26 c4 7d 33          	les    di,DWORD PTR es:[di+0x33]
    2774:	06                   	push   es
    2775:	57                   	push   di
    2776:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2779:	06                   	push   es
    277a:	57                   	push   di
    277b:	68 ff 00             	push   0xff
    277e:	9a e7 17 db 27       	call   0x27db:0x17e7
    2783:	c9                   	leave
    2784:	ca 04 00             	retf   0x4
    2787:	55                   	push   bp
    2788:	89 e5                	mov    bp,sp
    278a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    278d:	81 c7 29 00          	add    di,0x29
    2791:	06                   	push   es
    2792:	57                   	push   di
    2793:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2796:	06                   	push   es
    2797:	57                   	push   di
    2798:	9a 51 06 38 28       	call   0x2838:0x651
    279d:	c9                   	leave
    279e:	ca 08 00             	retf   0x8
    27a1:	c8 00 01 00          	enter  0x100,0x0
    27a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a8:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    27ac:	74 1d                	je     0x27cb
    27ae:	26 80 3d 03          	cmp    BYTE PTR es:[di],0x3
    27b2:	75 07                	jne    0x27bb
    27b4:	26 80 7d 03 5c       	cmp    BYTE PTR es:[di+0x3],0x5c
    27b9:	74 10                	je     0x27cb
    27bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27be:	26 8a 05             	mov    al,BYTE PTR es:[di]
    27c1:	30 e4                	xor    ah,ah
    27c3:	03 f8                	add    di,ax
    27c5:	26 80 3d 5c          	cmp    BYTE PTR es:[di],0x5c
    27c9:	74 14                	je     0x27df
    27cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27ce:	06                   	push   es
    27cf:	57                   	push   di
    27d0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    27d3:	06                   	push   es
    27d4:	57                   	push   di
    27d5:	68 ff 00             	push   0xff
    27d8:	9a e7 17 06 28       	call   0x2806:0x17e7
    27dd:	eb 36                	jmp    0x2815
    27df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e2:	26 8a 05             	mov    al,BYTE PTR es:[di]
    27e5:	30 e4                	xor    ah,ah
    27e7:	03 f8                	add    di,ax
    27e9:	26 80 3d 5c          	cmp    BYTE PTR es:[di],0x5c
    27ed:	75 26                	jne    0x2815
    27ef:	8d be 00 ff          	lea    di,[bp-0x100]
    27f3:	16                   	push   ss
    27f4:	57                   	push   di
    27f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27f8:	06                   	push   es
    27f9:	57                   	push   di
    27fa:	6a 01                	push   0x1
    27fc:	26 8a 05             	mov    al,BYTE PTR es:[di]
    27ff:	30 e4                	xor    ah,ah
    2801:	48                   	dec    ax
    2802:	50                   	push   ax
    2803:	9a 0b 18 13 28       	call   0x2813:0x180b
    2808:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    280b:	06                   	push   es
    280c:	57                   	push   di
    280d:	68 ff 00             	push   0xff
    2810:	9a e7 17 aa 28       	call   0x28aa:0x17e7
    2815:	c9                   	leave
    2816:	c2 06 00             	ret    0x6
    2819:	c8 00 01 00          	enter  0x100,0x0
    281d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2820:	81 c7 2f 00          	add    di,0x2f
    2824:	06                   	push   es
    2825:	57                   	push   di
    2826:	8d be 00 ff          	lea    di,[bp-0x100]
    282a:	16                   	push   ss
    282b:	57                   	push   di
    282c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    282f:	06                   	push   es
    2830:	57                   	push   di
    2831:	55                   	push   bp
    2832:	e8 6c ff             	call   0x27a1
    2835:	9a 51 06 6f 28       	call   0x286f:0x651
    283a:	c9                   	leave
    283b:	ca 08 00             	retf   0x8
    283e:	55                   	push   bp
    283f:	89 e5                	mov    bp,sp
    2841:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2844:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2847:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284a:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    284e:	06                   	push   es
    284f:	57                   	push   di
    2850:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2853:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2857:	c9                   	leave
    2858:	ca 08 00             	retf   0x8
    285b:	55                   	push   bp
    285c:	89 e5                	mov    bp,sp
    285e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2861:	81 c7 33 00          	add    di,0x33
    2865:	06                   	push   es
    2866:	57                   	push   di
    2867:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    286a:	06                   	push   es
    286b:	57                   	push   di
    286c:	9a 51 06 3d 29       	call   0x293d:0x651
    2871:	c9                   	leave
    2872:	ca 08 00             	retf   0x8
    2875:	c8 02 00 00          	enter  0x2,0x0
    2879:	bf ff ff             	mov    di,0xffff
    287c:	b8 ff ff             	mov    ax,0xffff
    287f:	50                   	push   ax
    2880:	57                   	push   di
    2881:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2884:	06                   	push   es
    2885:	57                   	push   di
    2886:	9a 67 24 bd 28       	call   0x28bd:0x2467
    288b:	f7 d8                	neg    ax
    288d:	18 c0                	sbb    al,al
    288f:	f6 d8                	neg    al
    2891:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2894:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2897:	c9                   	leave
    2898:	ca 04 00             	retf   0x4
    289b:	55                   	push   bp
    289c:	89 e5                	mov    bp,sp
    289e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    28a2:	74 08                	je     0x28ac
    28a4:	83 ec 08             	sub    sp,0x8
    28a7:	9a e2 1f 06 29       	call   0x2906:0x1fe2
    28ac:	ff 76 0e             	push   WORD PTR [bp+0xe]
    28af:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28b2:	31 c0                	xor    ax,ax
    28b4:	50                   	push   ax
    28b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b8:	06                   	push   es
    28b9:	57                   	push   di
    28ba:	9a de 20 e9 29       	call   0x29e9:0x20de
    28bf:	b0 01                	mov    al,0x1
    28c1:	50                   	push   ax
    28c2:	b8 10 03             	mov    ax,0x310
    28c5:	ba cd 28             	mov    dx,0x28cd
    28c8:	52                   	push   dx
    28c9:	50                   	push   ax
    28ca:	9a 96 0e 4b 29       	call   0x294b:0xe96
    28cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d2:	26 89 45 1f          	mov    WORD PTR es:[di+0x1f],ax
    28d6:	26 89 55 21          	mov    WORD PTR es:[di+0x21],dx
    28da:	26 c7 45 24 04 00    	mov    WORD PTR es:[di+0x24],0x4
    28e0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    28e4:	74 07                	je     0x28ed
    28e6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    28ea:	83 c4 06             	add    sp,0x6
    28ed:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    28f0:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    28f3:	c9                   	leave
    28f4:	ca 0a 00             	retf   0xa
    28f7:	55                   	push   bp
    28f8:	89 e5                	mov    bp,sp
    28fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28fd:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2901:	06                   	push   es
    2902:	57                   	push   di
    2903:	9a 7f 1f 1e 29       	call   0x291e:0x1f7f
    2908:	31 c0                	xor    ax,ax
    290a:	50                   	push   ax
    290b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290e:	06                   	push   es
    290f:	57                   	push   di
    2910:	9a 2b 4c 44 32       	call   0x3244:0x4c2b
    2915:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2919:	74 05                	je     0x2920
    291b:	9a 0f 20 6e 2a       	call   0x2a6e:0x200f
    2920:	c9                   	leave
    2921:	ca 06 00             	retf   0x6
    2924:	c8 06 01 00          	enter  0x106,0x0
    2928:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    292b:	8d be fa fe          	lea    di,[bp-0x106]
    292f:	16                   	push   ss
    2930:	57                   	push   di
    2931:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2934:	81 c7 12 00          	add    di,0x12
    2938:	06                   	push   es
    2939:	57                   	push   di
    293a:	9a 6e 0e 1a 2d       	call   0x2d1a:0xe6e
    293f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2942:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2946:	06                   	push   es
    2947:	57                   	push   di
    2948:	9a 7e 11 5f 29       	call   0x295f:0x117e
    294d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2950:	26 ff 35             	push   WORD PTR es:[di]
    2953:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2956:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    295a:	06                   	push   es
    295b:	57                   	push   di
    295c:	9a 32 11 b4 29       	call   0x29b4:0x1132
    2961:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2965:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2968:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    296b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    296e:	26 81 7d 08 90 01    	cmp    WORD PTR es:[di+0x8],0x190
    2974:	7e 04                	jle    0x297a
    2976:	80 4e ff 01          	or     BYTE PTR [bp-0x1],0x1
    297a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    297d:	26 80 7d 0a 00       	cmp    BYTE PTR es:[di+0xa],0x0
    2982:	74 04                	je     0x2988
    2984:	80 4e ff 02          	or     BYTE PTR [bp-0x1],0x2
    2988:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    298b:	26 80 7d 0b 00       	cmp    BYTE PTR es:[di+0xb],0x0
    2990:	74 04                	je     0x2996
    2992:	80 4e ff 04          	or     BYTE PTR [bp-0x1],0x4
    2996:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2999:	26 80 7d 0c 00       	cmp    BYTE PTR es:[di+0xc],0x0
    299e:	74 04                	je     0x29a4
    29a0:	80 4e ff 08          	or     BYTE PTR [bp-0x1],0x8
    29a4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    29a7:	50                   	push   ax
    29a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ab:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    29af:	06                   	push   es
    29b0:	57                   	push   di
    29b1:	9a 33 12 50 2a       	call   0x2a50:0x1233
    29b6:	c9                   	leave
    29b7:	ca 08 00             	retf   0x8
    29ba:	55                   	push   bp
    29bb:	89 e5                	mov    bp,sp
    29bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c0:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    29c4:	09 c0                	or     ax,ax
    29c6:	74 15                	je     0x29dd
    29c8:	ff 76 08             	push   WORD PTR [bp+0x8]
    29cb:	ff 76 06             	push   WORD PTR [bp+0x6]
    29ce:	ff 76 0a             	push   WORD PTR [bp+0xa]
    29d1:	26 ff 75 2c          	push   WORD PTR es:[di+0x2c]
    29d5:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    29d9:	26 ff 5d 26          	call   DWORD PTR es:[di+0x26]
    29dd:	c9                   	leave
    29de:	ca 06 00             	retf   0x6
    29e1:	01 00                	add    WORD PTR [bx+si],ax
    29e3:	00 00                	add    BYTE PTR [bx+si],al
    29e5:	00 00                	add    BYTE PTR [bx+si],al
    29e7:	79 2a                	jns    0x2a13
    29e9:	0e                   	push   cs
    29ea:	2a c8                	sub    cl,al
    29ec:	34 00                	xor    al,0x0
    29ee:	00 ff                	add    bh,bh
    29f0:	76 0a                	jbe    0x29fc
    29f2:	68 01 04             	push   0x401
    29f5:	6a 00                	push   0x0
    29f7:	8d 7e cc             	lea    di,[bp-0x34]
    29fa:	16                   	push   ss
    29fb:	57                   	push   di
    29fc:	9a ff ff 00 00       	call   0x0:0xffff
    2a01:	8d 7e cc             	lea    di,[bp-0x34]
    2a04:	16                   	push   ss
    2a05:	57                   	push   di
    2a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a09:	06                   	push   es
    2a0a:	57                   	push   di
    2a0b:	9a 24 29 df 2a       	call   0x2adf:0x2924
    2a10:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a13:	68 73 04             	push   0x473
    2a16:	68 07 04             	push   0x407
    2a19:	6a 00                	push   0x0
    2a1b:	6a 00                	push   0x0
    2a1d:	6a 00                	push   0x0
    2a1f:	9a 3e 2a 00 00       	call   0x0:0x2a3e
    2a24:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a27:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    2a2b:	74 25                	je     0x2a52
    2a2d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a30:	68 73 04             	push   0x473
    2a33:	68 10 04             	push   0x410
    2a36:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a39:	6a 00                	push   0x0
    2a3b:	6a 00                	push   0x0
    2a3d:	9a ff ff 00 00       	call   0x0:0xffff
    2a42:	52                   	push   dx
    2a43:	50                   	push   ax
    2a44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a47:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2a4b:	06                   	push   es
    2a4c:	57                   	push   di
    2a4d:	9a df 0f 4f 2b       	call   0x2b4f:0xfdf
    2a52:	b8 e1 29             	mov    ax,0x29e1
    2a55:	0e                   	push   cs
    2a56:	50                   	push   ax
    2a57:	55                   	push   bp
    2a58:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2a5c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2a60:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a66:	06                   	push   es
    2a67:	57                   	push   di
    2a68:	b8 ff ff             	mov    ax,0xffff
    2a6b:	9a 6a 20 8d 2a       	call   0x2a8d:0x206a
    2a70:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2a74:	83 c4 06             	add    sp,0x6
    2a77:	eb 16                	jmp    0x2a8f
    2a79:	ff 76 08             	push   WORD PTR [bp+0x8]
    2a7c:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a7f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2a83:	06                   	push   es
    2a84:	57                   	push   di
    2a85:	9a 51 75 a3 31       	call   0x31a3:0x7551
    2a8a:	9a 34 14 51 2e       	call   0x2e51:0x1434
    2a8f:	c9                   	leave
    2a90:	ca 06 00             	retf   0x6
    2a93:	55                   	push   bp
    2a94:	89 e5                	mov    bp,sp
    2a96:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2a99:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9f:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2aa3:	06                   	push   es
    2aa4:	57                   	push   di
    2aa5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2aa8:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2aac:	c9                   	leave
    2aad:	ca 08 00             	retf   0x8
    2ab0:	8c d0                	mov    ax,ss
    2ab2:	90                   	nop
    2ab3:	45                   	inc    bp
    2ab4:	55                   	push   bp
    2ab5:	89 e5                	mov    bp,sp
    2ab7:	1e                   	push   ds
    2ab8:	8e d8                	mov    ds,ax
    2aba:	83 ec 02             	sub    sp,0x2
    2abd:	56                   	push   si
    2abe:	57                   	push   di
    2abf:	81 7e 0c 11 01       	cmp    WORD PTR [bp+0xc],0x111
    2ac4:	75 22                	jne    0x2ae8
    2ac6:	81 7e 0a 02 04       	cmp    WORD PTR [bp+0xa],0x402
    2acb:	75 1b                	jne    0x2ae8
    2acd:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    2ad1:	75 15                	jne    0x2ae8
    2ad3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2ad6:	c4 3e dc 2a          	les    di,DWORD PTR ds:0x2adc
    2ada:	06                   	push   es
    2adb:	57                   	push   di
    2adc:	9a eb 29 fa 2a       	call   0x2afa:0x29eb
    2ae1:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2ae6:	eb 17                	jmp    0x2aff
    2ae8:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2aeb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2aee:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2af1:	ff 76 08             	push   WORD PTR [bp+0x8]
    2af4:	ff 76 06             	push   WORD PTR [bp+0x6]
    2af7:	9a cf 0a 1b 2c       	call   0x2c1b:0xacf
    2afc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2aff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b02:	5f                   	pop    di
    2b03:	5e                   	pop    si
    2b04:	8d 66 fe             	lea    sp,[bp-0x2]
    2b07:	1f                   	pop    ds
    2b08:	5d                   	pop    bp
    2b09:	4d                   	dec    bp
    2b0a:	ca 0a 00             	retf   0xa
    2b0d:	c8 68 00 00          	enter  0x68,0x0
    2b11:	c7 46 d0 2e 00       	mov    WORD PTR [bp-0x30],0x2e
    2b16:	c7 46 d2 00 00       	mov    WORD PTR [bp-0x2e],0x0
    2b1b:	31 c0                	xor    ax,ax
    2b1d:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    2b20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b23:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    2b28:	74 0e                	je     0x2b38
    2b2a:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2b2e:	06                   	push   es
    2b2f:	57                   	push   di
    2b30:	9a 51 2a 01 2d       	call   0x2d01:0x2a51
    2b35:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    2b38:	8d 46 9e             	lea    ax,[bp-0x62]
    2b3b:	8c d2                	mov    dx,ss
    2b3d:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    2b40:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    2b43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b46:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2b4a:	06                   	push   es
    2b4b:	57                   	push   di
    2b4c:	9a 16 10 d5 2c       	call   0x2cd5:0x1016
    2b51:	50                   	push   ax
    2b52:	6a 32                	push   0x32
    2b54:	8d 7e 9e             	lea    di,[bp-0x62]
    2b57:	16                   	push   ss
    2b58:	57                   	push   di
    2b59:	9a ff ff 00 00       	call   0x0:0xffff
    2b5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b61:	26 8a 45 23          	mov    al,BYTE PTR es:[di+0x23]
    2b65:	98                   	cbw
    2b66:	8b f8                	mov    di,ax
    2b68:	c1 e7 02             	shl    di,0x2
    2b6b:	8b 85 5e 0d          	mov    ax,WORD PTR [di+0xd5e]
    2b6f:	8b 95 60 0d          	mov    dx,WORD PTR [di+0xd60]
    2b73:	0d 48 00             	or     ax,0x48
    2b76:	81 ca 00 00          	or     dx,0x0
    2b7a:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2b7d:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2b80:	c6 46 9d 00          	mov    BYTE PTR [bp-0x63],0x0
    2b84:	eb 03                	jmp    0x2b89
    2b86:	fe 46 9d             	inc    BYTE PTR [bp-0x63]
    2b89:	8a 4e 9d             	mov    cl,BYTE PTR [bp-0x63]
    2b8c:	80 f9 10             	cmp    cl,0x10
    2b8f:	73 2b                	jae    0x2bbc
    2b91:	b8 01 00             	mov    ax,0x1
    2b94:	d3 c0                	rol    ax,cl
    2b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b99:	26 85 45 24          	test   WORD PTR es:[di+0x24],ax
    2b9d:	74 1d                	je     0x2bbc
    2b9f:	8a 46 9d             	mov    al,BYTE PTR [bp-0x63]
    2ba2:	98                   	cbw
    2ba3:	8b f8                	mov    di,ax
    2ba5:	c1 e7 02             	shl    di,0x2
    2ba8:	8b 85 22 0d          	mov    ax,WORD PTR [di+0xd22]
    2bac:	8b 95 24 0d          	mov    dx,WORD PTR [di+0xd24]
    2bb0:	0b 46 de             	or     ax,WORD PTR [bp-0x22]
    2bb3:	0b 56 e0             	or     dx,WORD PTR [bp-0x20]
    2bb6:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2bb9:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2bbc:	80 7e 9d 0e          	cmp    BYTE PTR [bp-0x63],0xe
    2bc0:	75 c4                	jne    0x2b86
    2bc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc5:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    2bc9:	09 c0                	or     ax,ax
    2bcb:	74 13                	je     0x2be0
    2bcd:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    2bd0:	8b 56 e0             	mov    dx,WORD PTR [bp-0x20]
    2bd3:	0d 00 02             	or     ax,0x200
    2bd6:	81 ca 00 00          	or     dx,0x0
    2bda:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2bdd:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2be0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be3:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2be7:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2beb:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    2bef:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    2bf2:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    2bf5:	31 c0                	xor    ax,ax
    2bf7:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2bfa:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2bfd:	a1 dc 2a             	mov    ax,ds:0x2adc
    2c00:	8b 16 de 2a          	mov    dx,WORD PTR ds:0x2ade
    2c04:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    2c07:	89 56 9a             	mov    WORD PTR [bp-0x66],dx
    2c0a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2c0d:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2c10:	a3 dc 2a             	mov    ds:0x2adc,ax
    2c13:	89 16 de 2a          	mov    WORD PTR ds:0x2ade,dx
    2c17:	b8 b0 2a             	mov    ax,0x2ab0
    2c1a:	ba 6a 2c             	mov    dx,0x2c6a
    2c1d:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    2c20:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    2c23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c26:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
    2c2a:	a2 b4 0c             	mov    ds:0xcb4,al
    2c2d:	c6 06 b5 0c 00       	mov    BYTE PTR ds:0xcb5,0x0
    2c32:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    2c36:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2c39:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    2c3d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c40:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2c43:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2c46:	7e 13                	jle    0x2c5b
    2c48:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    2c4b:	8b 56 e0             	mov    dx,WORD PTR [bp-0x20]
    2c4e:	25 ff df             	and    ax,0xdfff
    2c51:	81 e2 ff ff          	and    dx,0xffff
    2c55:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2c58:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2c5b:	ff 76 08             	push   WORD PTR [bp+0x8]
    2c5e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2c61:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    2c65:	06                   	push   es
    2c66:	57                   	push   di
    2c67:	9a fb 1e ac 2c       	call   0x2cac:0x1efb
    2c6c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2c70:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2c74:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    2c77:	bf ff ff             	mov    di,0xffff
    2c7a:	b8 ff ff             	mov    ax,0xffff
    2c7d:	50                   	push   ax
    2c7e:	57                   	push   di
    2c7f:	8d 7e d0             	lea    di,[bp-0x30]
    2c82:	16                   	push   ss
    2c83:	57                   	push   di
    2c84:	e8 e5 df             	call   0xc6c
    2c87:	f7 d8                	neg    ax
    2c89:	18 c0                	sbb    al,al
    2c8b:	f6 d8                	neg    al
    2c8d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2c90:	8b 46 98             	mov    ax,WORD PTR [bp-0x68]
    2c93:	8b 56 9a             	mov    dx,WORD PTR [bp-0x66]
    2c96:	a3 dc 2a             	mov    ds:0x2adc,ax
    2c99:	89 16 de 2a          	mov    WORD PTR ds:0x2ade,dx
    2c9d:	ff 76 08             	push   WORD PTR [bp+0x8]
    2ca0:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ca3:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    2ca7:	06                   	push   es
    2ca8:	57                   	push   di
    2ca9:	9a 63 1f c1 2c       	call   0x2cc1:0x1f63
    2cae:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2cb2:	74 23                	je     0x2cd7
    2cb4:	8d 7e 9e             	lea    di,[bp-0x62]
    2cb7:	16                   	push   ss
    2cb8:	57                   	push   di
    2cb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbc:	06                   	push   es
    2cbd:	57                   	push   di
    2cbe:	9a 24 29 84 2e       	call   0x2e84:0x2924
    2cc3:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    2cc6:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    2cc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ccc:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    2cd0:	06                   	push   es
    2cd1:	57                   	push   di
    2cd2:	9a df 0f ff 31       	call   0x31ff:0xfdf
    2cd7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2cda:	c9                   	leave
    2cdb:	ca 04 00             	retf   0x4
    2cde:	c8 fc 00 00          	enter  0xfc,0x0
    2ce2:	8d 7e ac             	lea    di,[bp-0x54]
    2ce5:	16                   	push   ss
    2ce6:	57                   	push   di
    2ce7:	8d be 5c ff          	lea    di,[bp-0xa4]
    2ceb:	16                   	push   ss
    2cec:	57                   	push   di
    2ced:	8d be 0c ff          	lea    di,[bp-0xf4]
    2cf1:	16                   	push   ss
    2cf2:	57                   	push   di
    2cf3:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2cf6:	06                   	push   es
    2cf7:	57                   	push   di
    2cf8:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2cfc:	06                   	push   es
    2cfd:	57                   	push   di
    2cfe:	9a de 26 33 2e       	call   0x2e33:0x26de
    2d03:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2d06:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2d0a:	75 03                	jne    0x2d0f
    2d0c:	e9 d6 00             	jmp    0x2de5
    2d0f:	6a 42                	push   0x42
    2d11:	8d be 0c ff          	lea    di,[bp-0xf4]
    2d15:	16                   	push   ss
    2d16:	57                   	push   di
    2d17:	9a 8c 0c 2c 2d       	call   0x2d2c:0xc8c
    2d1c:	8b f0                	mov    si,ax
    2d1e:	d1 e0                	shl    ax,1
    2d20:	01 f0                	add    ax,si
    2d22:	50                   	push   ax
    2d23:	8d be 5c ff          	lea    di,[bp-0xa4]
    2d27:	16                   	push   ss
    2d28:	57                   	push   di
    2d29:	9a 8c 0c 37 2d       	call   0x2d37:0xc8c
    2d2e:	50                   	push   ax
    2d2f:	8d 7e ac             	lea    di,[bp-0x54]
    2d32:	16                   	push   ss
    2d33:	57                   	push   di
    2d34:	9a 8c 0c 90 2d       	call   0x2d90:0xc8c
    2d39:	05 08 00             	add    ax,0x8
    2d3c:	5a                   	pop    dx
    2d3d:	03 c2                	add    ax,dx
    2d3f:	5a                   	pop    dx
    2d40:	03 c2                	add    ax,dx
    2d42:	31 d2                	xor    dx,dx
    2d44:	52                   	push   dx
    2d45:	50                   	push   ax
    2d46:	9a ff ff 00 00       	call   0x0:0xffff
    2d4b:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2d4e:	26 89 05             	mov    WORD PTR es:[di],ax
    2d51:	31 c0                	xor    ax,ax
    2d53:	26 8b 15             	mov    dx,WORD PTR es:[di]
    2d56:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d59:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2d5c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d5f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2d62:	05 08 00             	add    ax,0x8
    2d65:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
    2d69:	89 96 0a ff          	mov    WORD PTR [bp-0xf6],dx
    2d6d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2d70:	89 be 04 ff          	mov    WORD PTR [bp-0xfc],di
    2d74:	8c 86 06 ff          	mov    WORD PTR [bp-0xfa],es
    2d78:	8b 86 08 ff          	mov    ax,WORD PTR [bp-0xf8]
    2d7c:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    2d80:	ff b6 0a ff          	push   WORD PTR [bp-0xf6]
    2d84:	ff b6 08 ff          	push   WORD PTR [bp-0xf8]
    2d88:	8d 7e ac             	lea    di,[bp-0x54]
    2d8b:	16                   	push   ss
    2d8c:	57                   	push   di
    2d8d:	9a 01 0d b9 2d       	call   0x2db9:0xd01
    2d92:	05 01 00             	add    ax,0x1
    2d95:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
    2d99:	89 96 0a ff          	mov    WORD PTR [bp-0xf6],dx
    2d9d:	8b 86 08 ff          	mov    ax,WORD PTR [bp-0xf8]
    2da1:	c4 be 04 ff          	les    di,DWORD PTR [bp-0xfc]
    2da5:	26 89 05             	mov    WORD PTR es:[di],ax
    2da8:	ff b6 0a ff          	push   WORD PTR [bp-0xf6]
    2dac:	ff b6 08 ff          	push   WORD PTR [bp-0xf8]
    2db0:	8d be 5c ff          	lea    di,[bp-0xa4]
    2db4:	16                   	push   ss
    2db5:	57                   	push   di
    2db6:	9a 01 0d e3 2d       	call   0x2de3:0xd01
    2dbb:	05 01 00             	add    ax,0x1
    2dbe:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
    2dc2:	89 96 0a ff          	mov    WORD PTR [bp-0xf6],dx
    2dc6:	8b 86 08 ff          	mov    ax,WORD PTR [bp-0xf8]
    2dca:	c4 be 04 ff          	les    di,DWORD PTR [bp-0xfc]
    2dce:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2dd2:	ff b6 0a ff          	push   WORD PTR [bp-0xf6]
    2dd6:	ff b6 08 ff          	push   WORD PTR [bp-0xf8]
    2dda:	8d be 0c ff          	lea    di,[bp-0xf4]
    2dde:	16                   	push   ss
    2ddf:	57                   	push   di
    2de0:	9a df 0c 77 32       	call   0x3277:0xcdf
    2de5:	c9                   	leave
    2de6:	c2 08 00             	ret    0x8
    2de9:	c8 08 00 00          	enter  0x8,0x0
    2ded:	31 c0                	xor    ax,ax
    2def:	8b 56 04             	mov    dx,WORD PTR [bp+0x4]
    2df2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2df5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2df8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2dfb:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2dfe:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2e01:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    2e05:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e08:	03 f8                	add    di,ax
    2e0a:	06                   	push   es
    2e0b:	57                   	push   di
    2e0c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e0f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2e12:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e15:	03 f8                	add    di,ax
    2e17:	06                   	push   es
    2e18:	57                   	push   di
    2e19:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e1c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2e20:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e23:	03 f8                	add    di,ax
    2e25:	06                   	push   es
    2e26:	57                   	push   di
    2e27:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e2a:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2e2e:	06                   	push   es
    2e2f:	57                   	push   di
    2e30:	9a 67 27 ff ff       	call   0xffff:0x2767
    2e35:	ff 76 04             	push   WORD PTR [bp+0x4]
    2e38:	9a ec 2e 00 00       	call   0x0:0x2eec
    2e3d:	c9                   	leave
    2e3e:	c2 04 00             	ret    0x4
    2e41:	c8 36 00 00          	enter  0x36,0x0
    2e45:	8d 7e cc             	lea    di,[bp-0x34]
    2e48:	16                   	push   ss
    2e49:	57                   	push   di
    2e4a:	6a 34                	push   0x34
    2e4c:	6a 00                	push   0x0
    2e4e:	9a e5 1e 27 2f       	call   0x2f27:0x1ee5
    2e53:	c7 46 cc 34 00       	mov    WORD PTR [bp-0x34],0x34
    2e58:	c7 46 ce 00 00       	mov    WORD PTR [bp-0x32],0x0
    2e5d:	a1 8c 18             	mov    ax,ds:0x188c
    2e60:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2e63:	8d 7e d2             	lea    di,[bp-0x2e]
    2e66:	16                   	push   ss
    2e67:	57                   	push   di
    2e68:	8d 7e d4             	lea    di,[bp-0x2c]
    2e6b:	16                   	push   ss
    2e6c:	57                   	push   di
    2e6d:	e8 6e fe             	call   0x2cde
    2e70:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    2e73:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    2e76:	c7 46 d8 40 20       	mov    WORD PTR [bp-0x28],0x2040
    2e7b:	c7 46 da 00 00       	mov    WORD PTR [bp-0x26],0x0
    2e80:	b8 cf 0a             	mov    ax,0xacf
    2e83:	ba aa 2e             	mov    dx,0x2eaa
    2e86:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2e89:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    2e8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e8f:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
    2e93:	a2 b4 0c             	mov    ds:0xcb4,al
    2e96:	c6 06 b5 0c 00       	mov    BYTE PTR ds:0xcb5,0x0
    2e9b:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e9e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ea1:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    2ea5:	06                   	push   es
    2ea6:	57                   	push   di
    2ea7:	9a fb 1e 11 2f       	call   0x2f11:0x1efb
    2eac:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2eb0:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2eb4:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    2eb7:	bf 65 30             	mov    di,0x3065
    2eba:	b8 68 30             	mov    ax,0x3068
    2ebd:	50                   	push   ax
    2ebe:	57                   	push   di
    2ebf:	8d 7e cc             	lea    di,[bp-0x34]
    2ec2:	16                   	push   ss
    2ec3:	57                   	push   di
    2ec4:	e8 a5 dd             	call   0xc6c
    2ec7:	09 c0                	or     ax,ax
    2ec9:	74 0b                	je     0x2ed6
    2ecb:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    2ece:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    2ed1:	e8 15 ff             	call   0x2de9
    2ed4:	eb 2c                	jmp    0x2f02
    2ed6:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    2ed9:	3b 46 d2             	cmp    ax,WORD PTR [bp-0x2e]
    2edc:	74 12                	je     0x2ef0
    2ede:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    2ee1:	e8 e1 dd             	call   0xcc5
    2ee4:	08 c0                	or     al,al
    2ee6:	74 08                	je     0x2ef0
    2ee8:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    2eeb:	9a fe 2e 00 00       	call   0x0:0x2efe
    2ef0:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    2ef3:	e8 cf dd             	call   0xcc5
    2ef6:	08 c0                	or     al,al
    2ef8:	74 08                	je     0x2f02
    2efa:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    2efd:	9a 42 31 00 00       	call   0x0:0x3142
    2f02:	ff 76 08             	push   WORD PTR [bp+0x8]
    2f05:	ff 76 06             	push   WORD PTR [bp+0x6]
    2f08:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    2f0c:	06                   	push   es
    2f0d:	57                   	push   di
    2f0e:	9a 63 1f 1b 30       	call   0x301b:0x1f63
    2f13:	c9                   	leave
    2f14:	ca 04 00             	retf   0x4
    2f17:	c8 3a 00 00          	enter  0x3a,0x0
    2f1b:	8d 7e ca             	lea    di,[bp-0x36]
    2f1e:	16                   	push   ss
    2f1f:	57                   	push   di
    2f20:	6a 34                	push   0x34
    2f22:	6a 00                	push   0x0
    2f24:	9a e5 1e 50 32       	call   0x3250:0x1ee5
    2f29:	c7 46 ca 34 00       	mov    WORD PTR [bp-0x36],0x34
    2f2e:	c7 46 cc 00 00       	mov    WORD PTR [bp-0x34],0x0
    2f33:	a1 8c 18             	mov    ax,ds:0x188c
    2f36:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2f39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f3c:	26 8a 45 26          	mov    al,BYTE PTR es:[di+0x26]
    2f40:	98                   	cbw
    2f41:	8b f8                	mov    di,ax
    2f43:	d1 e7                	shl    di,1
    2f45:	8b 85 6a 0d          	mov    ax,WORD PTR [di+0xd6a]
    2f49:	0d 00 30             	or     ax,0x3000
    2f4c:	99                   	cwd
    2f4d:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    2f50:	89 56 c8             	mov    WORD PTR [bp-0x38],dx
    2f53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f56:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    2f5b:	74 08                	je     0x2f65
    2f5d:	83 46 c6 10          	add    WORD PTR [bp-0x3a],0x10
    2f61:	83 56 c8 00          	adc    WORD PTR [bp-0x38],0x0
    2f65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f68:	26 f6 45 24 01       	test   BYTE PTR es:[di+0x24],0x1
    2f6d:	75 08                	jne    0x2f77
    2f6f:	83 46 c6 00          	add    WORD PTR [bp-0x3a],0x0
    2f73:	83 56 c8 10          	adc    WORD PTR [bp-0x38],0x10
    2f77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f7a:	26 f6 45 24 02       	test   BYTE PTR es:[di+0x24],0x2
    2f7f:	75 08                	jne    0x2f89
    2f81:	83 46 c6 08          	add    WORD PTR [bp-0x3a],0x8
    2f85:	83 56 c8 00          	adc    WORD PTR [bp-0x38],0x0
    2f89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f8c:	26 f6 45 24 04       	test   BYTE PTR es:[di+0x24],0x4
    2f91:	75 08                	jne    0x2f9b
    2f93:	83 46 c6 04          	add    WORD PTR [bp-0x3a],0x4
    2f97:	83 56 c8 00          	adc    WORD PTR [bp-0x38],0x0
    2f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f9e:	26 f6 45 24 20       	test   BYTE PTR es:[di+0x24],0x20
    2fa3:	74 08                	je     0x2fad
    2fa5:	83 46 c6 00          	add    WORD PTR [bp-0x3a],0x0
    2fa9:	83 56 c8 08          	adc    WORD PTR [bp-0x38],0x8
    2fad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb0:	26 80 7d 25 00       	cmp    BYTE PTR es:[di+0x25],0x0
    2fb5:	74 08                	je     0x2fbf
    2fb7:	83 46 c6 20          	add    WORD PTR [bp-0x3a],0x20
    2fbb:	83 56 c8 00          	adc    WORD PTR [bp-0x38],0x0
    2fbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc2:	26 f6 45 24 10       	test   BYTE PTR es:[di+0x24],0x10
    2fc7:	74 09                	je     0x2fd2
    2fc9:	81 46 c6 00 08       	add    WORD PTR [bp-0x3a],0x800
    2fce:	83 56 c8 00          	adc    WORD PTR [bp-0x38],0x0
    2fd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd5:	26 f6 45 24 08       	test   BYTE PTR es:[di+0x24],0x8
    2fda:	75 09                	jne    0x2fe5
    2fdc:	81 46 c6 80 00       	add    WORD PTR [bp-0x3a],0x80
    2fe1:	83 56 c8 00          	adc    WORD PTR [bp-0x38],0x0
    2fe5:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    2fe8:	8b 56 c8             	mov    dx,WORD PTR [bp-0x38]
    2feb:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    2fee:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    2ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff4:	26 8b 45 1f          	mov    ax,WORD PTR es:[di+0x1f]
    2ff8:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    2ffb:	26 8b 45 21          	mov    ax,WORD PTR es:[di+0x21]
    2fff:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    3002:	26 8b 45 27          	mov    ax,WORD PTR es:[di+0x27]
    3006:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    3009:	26 8b 45 29          	mov    ax,WORD PTR es:[di+0x29]
    300d:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    3010:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    3014:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    3017:	b8 cf 0a             	mov    ax,0xacf
    301a:	ba 27 30             	mov    dx,0x3027
    301d:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3020:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    3023:	b8 cf 0a             	mov    ax,0xacf
    3026:	ba 57 30             	mov    dx,0x3057
    3029:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    302c:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    302f:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
    3033:	a2 b4 0c             	mov    ds:0xcb4,al
    3036:	c6 06 b5 0c 00       	mov    BYTE PTR ds:0xcb5,0x0
    303b:	8d 7e d0             	lea    di,[bp-0x30]
    303e:	16                   	push   ss
    303f:	57                   	push   di
    3040:	8d 7e d2             	lea    di,[bp-0x2e]
    3043:	16                   	push   ss
    3044:	57                   	push   di
    3045:	e8 96 fc             	call   0x2cde
    3048:	ff 76 08             	push   WORD PTR [bp+0x8]
    304b:	ff 76 06             	push   WORD PTR [bp+0x6]
    304e:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    3052:	06                   	push   es
    3053:	57                   	push   di
    3054:	9a fb 1e 8c 30       	call   0x308c:0x1efb
    3059:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    305d:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3061:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    3064:	bf ff ff             	mov    di,0xffff
    3067:	b8 ff ff             	mov    ax,0xffff
    306a:	50                   	push   ax
    306b:	57                   	push   di
    306c:	8d 7e ca             	lea    di,[bp-0x36]
    306f:	16                   	push   ss
    3070:	57                   	push   di
    3071:	e8 f8 db             	call   0xc6c
    3074:	f7 d8                	neg    ax
    3076:	18 c0                	sbb    al,al
    3078:	f6 d8                	neg    al
    307a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    307d:	ff 76 08             	push   WORD PTR [bp+0x8]
    3080:	ff 76 06             	push   WORD PTR [bp+0x6]
    3083:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    3087:	06                   	push   es
    3088:	57                   	push   di
    3089:	9a 63 1f 8e 31       	call   0x318e:0x1f63
    308e:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3092:	75 03                	jne    0x3097
    3094:	e9 9d 00             	jmp    0x3134
    3097:	ff 76 d0             	push   WORD PTR [bp-0x30]
    309a:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    309d:	e8 49 fd             	call   0x2de9
    30a0:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    30a3:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    30a6:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    30a9:	89 56 c8             	mov    WORD PTR [bp-0x38],dx
    30ac:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    30af:	8b 56 c8             	mov    dx,WORD PTR [bp-0x38]
    30b2:	25 10 00             	and    ax,0x10
    30b5:	81 e2 00 00          	and    dx,0x0
    30b9:	09 d0                	or     ax,dx
    30bb:	b0 00                	mov    al,0x0
    30bd:	74 01                	je     0x30c0
    30bf:	40                   	inc    ax
    30c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c3:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    30c7:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    30ca:	8b 56 c8             	mov    dx,WORD PTR [bp-0x38]
    30cd:	25 20 00             	and    ax,0x20
    30d0:	81 e2 00 00          	and    dx,0x0
    30d4:	09 d0                	or     ax,dx
    30d6:	b0 00                	mov    al,0x0
    30d8:	74 01                	je     0x30db
    30da:	40                   	inc    ax
    30db:	26 88 45 25          	mov    BYTE PTR es:[di+0x25],al
    30df:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    30e2:	8b 56 c8             	mov    dx,WORD PTR [bp-0x38]
    30e5:	25 01 00             	and    ax,0x1
    30e8:	81 e2 00 00          	and    dx,0x0
    30ec:	09 d0                	or     ax,dx
    30ee:	74 07                	je     0x30f7
    30f0:	26 c6 45 26 01       	mov    BYTE PTR es:[di+0x26],0x1
    30f5:	eb 23                	jmp    0x311a
    30f7:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    30fa:	8b 56 c8             	mov    dx,WORD PTR [bp-0x38]
    30fd:	25 02 00             	and    ax,0x2
    3100:	81 e2 00 00          	and    dx,0x0
    3104:	09 d0                	or     ax,dx
    3106:	74 0a                	je     0x3112
    3108:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    310b:	26 c6 45 26 02       	mov    BYTE PTR es:[di+0x26],0x2
    3110:	eb 08                	jmp    0x311a
    3112:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3115:	26 c6 45 26 00       	mov    BYTE PTR es:[di+0x26],0x0
    311a:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    311d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3120:	26 89 45 1f          	mov    WORD PTR es:[di+0x1f],ax
    3124:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    3127:	26 89 45 21          	mov    WORD PTR es:[di+0x21],ax
    312b:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    312e:	26 89 45 2b          	mov    WORD PTR es:[di+0x2b],ax
    3132:	eb 12                	jmp    0x3146
    3134:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    3137:	e8 8b db             	call   0xcc5
    313a:	08 c0                	or     al,al
    313c:	74 08                	je     0x3146
    313e:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    3141:	9a ff ff 00 00       	call   0x0:0xffff
    3146:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3149:	c9                   	leave
    314a:	ca 04 00             	retf   0x4
    314d:	c8 02 00 00          	enter  0x2,0x0
    3151:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3154:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    3157:	7e 08                	jle    0x3161
    3159:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    315c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    315f:	eb 06                	jmp    0x3167
    3161:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    3164:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3167:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    316a:	c9                   	leave
    316b:	c2 06 00             	ret    0x6
    316e:	0d 4d 53             	or     ax,0x534d
    3171:	20 53 61             	and    BYTE PTR [bp+di+0x61],dl
    3174:	6e                   	outs   dx,BYTE PTR ds:[si]
    3175:	73 20                	jae    0x3197
    3177:	53                   	push   bx
    3178:	65 72 69             	gs jb  0x31e4
    317b:	66 07                	popd   es
    317d:	4d                   	dec    bp
    317e:	65 73 73             	gs jae 0x31f4
    3181:	61                   	popa
    3182:	67 65 05 49 6d       	addr32 gs add ax,0x6d49
    3187:	61                   	popa
    3188:	67 65 00 00          	add    BYTE PTR gs:[eax],al
    318c:	e3 33                	jcxz   0x31c1
    318e:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    318f:	38 c8                	cmp    al,cl
    3191:	50                   	push   ax
    3192:	03 00                	add    ax,WORD PTR [bx+si]
    3194:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3198:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    319c:	b0 01                	mov    al,0x1
    319e:	50                   	push   ax
    319f:	b8 fb 04             	mov    ax,0x4fb
    31a2:	ba aa 31             	mov    dx,0x31aa
    31a5:	52                   	push   dx
    31a6:	50                   	push   ax
    31a7:	9a 5b 26 c4 31       	call   0x31c4:0x265b
    31ac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    31af:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    31b2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31b5:	89 be b0 fe          	mov    WORD PTR [bp-0x150],di
    31b9:	8c 86 b2 fe          	mov    WORD PTR [bp-0x14e],es
    31bd:	6a 60                	push   0x60
    31bf:	06                   	push   es
    31c0:	57                   	push   di
    31c1:	9a 38 38 d1 31       	call   0x31d1:0x3838
    31c6:	6a 03                	push   0x3
    31c8:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    31cc:	06                   	push   es
    31cd:	57                   	push   di
    31ce:	9a 6e 32 de 31       	call   0x31de:0x326e
    31d3:	6a 01                	push   0x1
    31d5:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    31d9:	06                   	push   es
    31da:	57                   	push   di
    31db:	9a 44 32 36 32       	call   0x3236:0x3244
    31e0:	6a 01                	push   0x1
    31e2:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    31e6:	06                   	push   es
    31e7:	57                   	push   di
    31e8:	9a 22 63 e2 32       	call   0x32e2:0x6322
    31ed:	bf 6e 31             	mov    di,0x316e
    31f0:	0e                   	push   cs
    31f1:	57                   	push   di
    31f2:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    31f6:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    31fa:	06                   	push   es
    31fb:	57                   	push   di
    31fc:	9a 7e 11 10 32       	call   0x3210:0x117e
    3201:	6a f5                	push   0xfff5
    3203:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    3207:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    320b:	06                   	push   es
    320c:	57                   	push   di
    320d:	9a 32 11 21 32       	call   0x3221:0x1132
    3212:	6a 01                	push   0x1
    3214:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    3218:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    321c:	06                   	push   es
    321d:	57                   	push   di
    321e:	9a 33 12 66 32       	call   0x3266:0x1233
    3223:	8d be a8 fe          	lea    di,[bp-0x158]
    3227:	16                   	push   ss
    3228:	57                   	push   di
    3229:	6a 00                	push   0x0
    322b:	6a 00                	push   0x0
    322d:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3231:	06                   	push   es
    3232:	57                   	push   di
    3233:	9a ba 60 5b 32       	call   0x325b:0x60ba
    3238:	99                   	cwd
    3239:	b9 02 00             	mov    cx,0x2
    323c:	f7 f9                	idiv   cx
    323e:	50                   	push   ax
    323f:	6a 00                	push   0x0
    3241:	9a 88 06 cb 33       	call   0x33cb:0x688
    3246:	8d 7e b8             	lea    di,[bp-0x48]
    3249:	16                   	push   ss
    324a:	57                   	push   di
    324b:	6a 08                	push   0x8
    324d:	9a 1b 16 eb 33       	call   0x33eb:0x161b
    3252:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    3256:	06                   	push   es
    3257:	57                   	push   di
    3258:	9a d5 33 2d 36       	call   0x362d:0x33d5
    325d:	89 c7                	mov    di,ax
    325f:	8e c2                	mov    es,dx
    3261:	06                   	push   es
    3262:	57                   	push   di
    3263:	9a d2 21 4f 33       	call   0x334f:0x21d2
    3268:	50                   	push   ax
    3269:	8d be b8 fe          	lea    di,[bp-0x148]
    326d:	16                   	push   ss
    326e:	57                   	push   di
    326f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3272:	06                   	push   es
    3273:	57                   	push   di
    3274:	9a 4c 0d 62 35       	call   0x3562:0xd4c
    3279:	52                   	push   dx
    327a:	50                   	push   ax
    327b:	6a ff                	push   0xffff
    327d:	8d 7e b8             	lea    di,[bp-0x48]
    3280:	16                   	push   ss
    3281:	57                   	push   di
    3282:	68 10 04             	push   0x410
    3285:	9a ff ff 00 00       	call   0x0:0xffff
    328a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    328d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3290:	b0 01                	mov    al,0x1
    3292:	50                   	push   ax
    3293:	b8 17 06             	mov    ax,0x617
    3296:	ba 9e 32             	mov    dx,0x329e
    3299:	52                   	push   dx
    329a:	50                   	push   ax
    329b:	9a 59 42 d3 32       	call   0x32d3:0x4259
    32a0:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    32a3:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    32a6:	bf 7c 31             	mov    di,0x317c
    32a9:	0e                   	push   cs
    32aa:	57                   	push   di
    32ab:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    32ae:	06                   	push   es
    32af:	57                   	push   di
    32b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32b3:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    32b7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    32ba:	ff 76 fc             	push   WORD PTR [bp-0x4]
    32bd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    32c0:	06                   	push   es
    32c1:	57                   	push   di
    32c2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32c5:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    32c9:	6a 01                	push   0x1
    32cb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    32ce:	06                   	push   es
    32cf:	57                   	push   di
    32d0:	9a e7 45 ff ff       	call   0xffff:0x45e7
    32d5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    32d8:	06                   	push   es
    32d9:	57                   	push   di
    32da:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    32dd:	06                   	push   es
    32de:	57                   	push   di
    32df:	9a 8c 1d f1 32       	call   0x32f1:0x1d8c
    32e4:	8d 7e b8             	lea    di,[bp-0x48]
    32e7:	16                   	push   ss
    32e8:	57                   	push   di
    32e9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    32ec:	06                   	push   es
    32ed:	57                   	push   di
    32ee:	9a 49 18 d5 33       	call   0x33d5:0x1849
    32f3:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    32f6:	98                   	cbw
    32f7:	8b f8                	mov    di,ax
    32f9:	c1 e7 02             	shl    di,0x2
    32fc:	8b 85 32 0c          	mov    ax,WORD PTR [di+0xc32]
    3300:	0b 85 34 0c          	or     ax,WORD PTR [di+0xc34]
    3304:	75 03                	jne    0x3309
    3306:	e9 e7 00             	jmp    0x33f0
    3309:	ff 76 fe             	push   WORD PTR [bp-0x2]
    330c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    330f:	b0 01                	mov    al,0x1
    3311:	50                   	push   ax
    3312:	b8 65 06             	mov    ax,0x665
    3315:	ba 1d 33             	mov    dx,0x331d
    3318:	52                   	push   dx
    3319:	50                   	push   ax
    331a:	9a 28 1d ff ff       	call   0xffff:0x1d28
    331f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3322:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3325:	bf 84 31             	mov    di,0x3184
    3328:	0e                   	push   cs
    3329:	57                   	push   di
    332a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    332d:	06                   	push   es
    332e:	57                   	push   di
    332f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3332:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3336:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3339:	ff 76 fc             	push   WORD PTR [bp-0x4]
    333c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    333f:	06                   	push   es
    3340:	57                   	push   di
    3341:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3344:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    3348:	b0 01                	mov    al,0x1
    334a:	50                   	push   ax
    334b:	b8 fc 08             	mov    ax,0x8fc
    334e:	ba 56 33             	mov    dx,0x3356
    3351:	52                   	push   dx
    3352:	50                   	push   ax
    3353:	9a 0e 64 8d 33       	call   0x338d:0x640e
    3358:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    335b:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    335e:	b8 8a 31             	mov    ax,0x318a
    3361:	0e                   	push   cs
    3362:	50                   	push   ax
    3363:	55                   	push   bp
    3364:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3368:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    336c:	6a 00                	push   0x0
    336e:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    3371:	98                   	cbw
    3372:	8b f8                	mov    di,ax
    3374:	c1 e7 02             	shl    di,0x2
    3377:	ff b5 34 0c          	push   WORD PTR [di+0xc34]
    337b:	ff b5 32 0c          	push   WORD PTR [di+0xc32]
    337f:	9a ff ff 00 00       	call   0x0:0xffff
    3384:	50                   	push   ax
    3385:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    3388:	06                   	push   es
    3389:	57                   	push   di
    338a:	9a b7 68 a2 33       	call   0x33a2:0x68b7
    338f:	ff 76 f2             	push   WORD PTR [bp-0xe]
    3392:	ff 76 f0             	push   WORD PTR [bp-0x10]
    3395:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3398:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    339d:	06                   	push   es
    339e:	57                   	push   di
    339f:	9a f9 42 ff ff       	call   0xffff:0x42f9
    33a4:	8d be a8 fe          	lea    di,[bp-0x158]
    33a8:	16                   	push   ss
    33a9:	57                   	push   di
    33aa:	6a 0a                	push   0xa
    33ac:	6a 00                	push   0x0
    33ae:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    33b1:	06                   	push   es
    33b2:	57                   	push   di
    33b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33b6:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    33ba:	50                   	push   ax
    33bb:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    33be:	06                   	push   es
    33bf:	57                   	push   di
    33c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33c3:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    33c7:	50                   	push   ax
    33c8:	9a ae 06 ff ff       	call   0xffff:0x6ae
    33cd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    33d0:	06                   	push   es
    33d1:	57                   	push   di
    33d2:	9a 49 18 6d 35       	call   0x356d:0x1849
    33d7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    33db:	83 c4 06             	add    sp,0x6
    33de:	b8 ee 33             	mov    ax,0x33ee
    33e1:	0e                   	push   cs
    33e2:	50                   	push   ax
    33e3:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    33e6:	06                   	push   es
    33e7:	57                   	push   di
    33e8:	9a 7f 1f 14 38       	call   0x3814:0x1f7f
    33ed:	cb                   	retf
    33ee:	eb 08                	jmp    0x33f8
    33f0:	31 c0                	xor    ax,ax
    33f2:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    33f5:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    33f8:	8b 46 bc             	mov    ax,WORD PTR [bp-0x44]
    33fb:	2b 46 b8             	sub    ax,WORD PTR [bp-0x48]
    33fe:	05 0a 00             	add    ax,0xa
    3401:	05 0a 00             	add    ax,0xa
    3404:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    3407:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    340a:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    340d:	74 1b                	je     0x342a
    340f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3412:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    3417:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    341b:	06                   	push   es
    341c:	57                   	push   di
    341d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3420:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3424:	05 0a 00             	add    ax,0xa
    3427:	01 46 c0             	add    WORD PTR [bp-0x40],ax
    342a:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    342d:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    3430:	74 2c                	je     0x345e
    3432:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3435:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    343a:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    343e:	06                   	push   es
    343f:	57                   	push   di
    3440:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3443:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3447:	05 0a 00             	add    ax,0xa
    344a:	50                   	push   ax
    344b:	8b 46 be             	mov    ax,WORD PTR [bp-0x42]
    344e:	2b 46 ba             	sub    ax,WORD PTR [bp-0x46]
    3451:	05 0a 00             	add    ax,0xa
    3454:	50                   	push   ax
    3455:	55                   	push   bp
    3456:	e8 f4 fc             	call   0x314d
    3459:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    345c:	eb 0c                	jmp    0x346a
    345e:	8b 46 be             	mov    ax,WORD PTR [bp-0x42]
    3461:	2b 46 ba             	sub    ax,WORD PTR [bp-0x46]
    3464:	05 0a 00             	add    ax,0xa
    3467:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    346a:	31 c0                	xor    ax,ax
    346c:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    346f:	c6 46 cb 00          	mov    BYTE PTR [bp-0x35],0x0
    3473:	eb 03                	jmp    0x3478
    3475:	fe 46 cb             	inc    BYTE PTR [bp-0x35]
    3478:	8a 4e cb             	mov    cl,BYTE PTR [bp-0x35]
    347b:	80 f9 10             	cmp    cl,0x10
    347e:	72 03                	jb     0x3483
    3480:	e9 26 01             	jmp    0x35a9
    3483:	b8 01 00             	mov    ax,0x1
    3486:	d3 c0                	rol    ax,cl
    3488:	85 46 06             	test   WORD PTR [bp+0x6],ax
    348b:	75 03                	jne    0x3490
    348d:	e9 19 01             	jmp    0x35a9
    3490:	ff 46 c8             	inc    WORD PTR [bp-0x38]
    3493:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3496:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3499:	b0 01                	mov    al,0x1
    349b:	50                   	push   ax
    349c:	b8 ac 04             	mov    ax,0x4ac
    349f:	ba a7 34             	mov    dx,0x34a7
    34a2:	52                   	push   dx
    34a3:	50                   	push   ax
    34a4:	9a fe 26 0c 35       	call   0x350c:0x26fe
    34a9:	8b c8                	mov    cx,ax
    34ab:	8b da                	mov    bx,dx
    34ad:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    34b0:	98                   	cbw
    34b1:	8b f8                	mov    di,ax
    34b3:	c1 e7 02             	shl    di,0x2
    34b6:	89 4b cc             	mov    WORD PTR [bp+di-0x34],cx
    34b9:	89 5b ce             	mov    WORD PTR [bp+di-0x32],bx
    34bc:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    34bf:	98                   	cbw
    34c0:	8b f8                	mov    di,ax
    34c2:	c1 e7 02             	shl    di,0x2
    34c5:	c4 7b cc             	les    di,DWORD PTR [bp+di-0x34]
    34c8:	89 be ac fe          	mov    WORD PTR [bp-0x154],di
    34cc:	8c 86 ae fe          	mov    WORD PTR [bp-0x152],es
    34d0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    34d3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    34d6:	06                   	push   es
    34d7:	57                   	push   di
    34d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34db:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    34df:	6a 00                	push   0x0
    34e1:	6a 00                	push   0x0
    34e3:	ff 36 20 0c          	push   WORD PTR ds:0xc20
    34e7:	ff 36 22 0c          	push   WORD PTR ds:0xc22
    34eb:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    34ef:	06                   	push   es
    34f0:	57                   	push   di
    34f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34f4:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    34f8:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    34fb:	98                   	cbw
    34fc:	8b f8                	mov    di,ax
    34fe:	8a 85 46 0c          	mov    al,BYTE PTR [di+0xc46]
    3502:	50                   	push   ax
    3503:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    3507:	06                   	push   es
    3508:	57                   	push   di
    3509:	9a d0 2c 22 35       	call   0x3522:0x2cd0
    350e:	80 3e 1f 0c 00       	cmp    BYTE PTR ds:0xc1f,0x0
    3513:	75 1e                	jne    0x3533
    3515:	6a 00                	push   0x0
    3517:	6a 00                	push   0x0
    3519:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    351d:	06                   	push   es
    351e:	57                   	push   di
    351f:	9a 18 2c 2f 35       	call   0x352f:0x2c18
    3524:	6a ff                	push   0xffff
    3526:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    352a:	06                   	push   es
    352b:	57                   	push   di
    352c:	9a 4d 2f 3e 35       	call   0x353e:0x2f4d
    3531:	eb 0d                	jmp    0x3540
    3533:	6a 02                	push   0x2
    3535:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    3539:	06                   	push   es
    353a:	57                   	push   di
    353b:	9a 4d 2f 4b 35       	call   0x354b:0x2f4d
    3540:	6a ff                	push   0xffff
    3542:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    3546:	06                   	push   es
    3547:	57                   	push   di
    3548:	9a 28 2f a5 35       	call   0x35a5:0x2f28
    354d:	8d be ac fd          	lea    di,[bp-0x254]
    3551:	16                   	push   ss
    3552:	57                   	push   di
    3553:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    3556:	98                   	cbw
    3557:	8b f8                	mov    di,ax
    3559:	d1 e7                	shl    di,1
    355b:	ff b5 50 0c          	push   WORD PTR [di+0xc50]
    355f:	9a 2b 09 89 35       	call   0x3589:0x92b
    3564:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    3568:	06                   	push   es
    3569:	57                   	push   di
    356a:	9a 8c 1d 69 36       	call   0x3669:0x1d8c
    356f:	8d be ac fd          	lea    di,[bp-0x254]
    3573:	16                   	push   ss
    3574:	57                   	push   di
    3575:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    3578:	98                   	cbw
    3579:	8b f8                	mov    di,ax
    357b:	c1 e7 02             	shl    di,0x2
    357e:	ff b5 64 0c          	push   WORD PTR [di+0xc64]
    3582:	ff b5 62 0c          	push   WORD PTR [di+0xc62]
    3586:	9a 6e 0e f4 37       	call   0x37f4:0xe6e
    358b:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    358f:	06                   	push   es
    3590:	57                   	push   di
    3591:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3594:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3598:	a0 1e 0c             	mov    al,ds:0xc1e
    359b:	50                   	push   ax
    359c:	c4 be ac fe          	les    di,DWORD PTR [bp-0x154]
    35a0:	06                   	push   es
    35a1:	57                   	push   di
    35a2:	9a ab 2c ff ff       	call   0xffff:0x2cab
    35a7:	eb 11                	jmp    0x35ba
    35a9:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    35ac:	98                   	cbw
    35ad:	8b f8                	mov    di,ax
    35af:	c1 e7 02             	shl    di,0x2
    35b2:	31 c0                	xor    ax,ax
    35b4:	89 43 cc             	mov    WORD PTR [bp+di-0x34],ax
    35b7:	89 43 ce             	mov    WORD PTR [bp+di-0x32],ax
    35ba:	80 7e cb 08          	cmp    BYTE PTR [bp-0x35],0x8
    35be:	74 03                	je     0x35c3
    35c0:	e9 b2 fe             	jmp    0x3475
    35c3:	f6 46 06 02          	test   BYTE PTR [bp+0x6],0x2
    35c7:	74 0f                	je     0x35d8
    35c9:	f6 46 06 08          	test   BYTE PTR [bp+0x6],0x8
    35cd:	74 09                	je     0x35d8
    35cf:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    35d2:	26 c6 85 db 00 00    	mov    BYTE PTR es:[di+0xdb],0x0
    35d8:	f6 46 06 04          	test   BYTE PTR [bp+0x6],0x4
    35dc:	74 0f                	je     0x35ed
    35de:	f6 46 06 08          	test   BYTE PTR [bp+0x6],0x8
    35e2:	75 09                	jne    0x35ed
    35e4:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    35e7:	26 c6 85 db 00 01    	mov    BYTE PTR es:[di+0xdb],0x1
    35ed:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    35f0:	48                   	dec    ax
    35f1:	c1 e0 03             	shl    ax,0x3
    35f4:	8b c8                	mov    cx,ax
    35f6:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    35f9:	f7 26 20 0c          	mul    WORD PTR ds:0xc20
    35fd:	03 c1                	add    ax,cx
    35ff:	05 1e 00             	add    ax,0x1e
    3602:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    3605:	a1 22 0c             	mov    ax,ds:0xc22
    3608:	05 0a 00             	add    ax,0xa
    360b:	05 08 00             	add    ax,0x8
    360e:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    3611:	68 96 00             	push   0x96
    3614:	ff 76 c0             	push   WORD PTR [bp-0x40]
    3617:	ff 76 c4             	push   WORD PTR [bp-0x3c]
    361a:	55                   	push   bp
    361b:	e8 2f fb             	call   0x314d
    361e:	50                   	push   ax
    361f:	55                   	push   bp
    3620:	e8 2a fb             	call   0x314d
    3623:	50                   	push   ax
    3624:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    3628:	06                   	push   es
    3629:	57                   	push   di
    362a:	9a c9 2e 46 36       	call   0x3646:0x2ec9
    362f:	6a 37                	push   0x37
    3631:	8b 46 c2             	mov    ax,WORD PTR [bp-0x3e]
    3634:	03 46 c6             	add    ax,WORD PTR [bp-0x3a]
    3637:	50                   	push   ax
    3638:	55                   	push   bp
    3639:	e8 11 fb             	call   0x314d
    363c:	50                   	push   ax
    363d:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    3641:	06                   	push   es
    3642:	57                   	push   di
    3643:	9a f1 2e 3d 38       	call   0x383d:0x2ef1
    3648:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    364b:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    364e:	74 6c                	je     0x36bc
    3650:	8b 46 be             	mov    ax,WORD PTR [bp-0x42]
    3653:	2b 46 ba             	sub    ax,WORD PTR [bp-0x46]
    3656:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3659:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    365d:	7d 5d                	jge    0x36bc
    365f:	6a 0a                	push   0xa
    3661:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3664:	06                   	push   es
    3665:	57                   	push   di
    3666:	9a 9d 17 a6 36       	call   0x36a6:0x179d
    366b:	8b 46 be             	mov    ax,WORD PTR [bp-0x42]
    366e:	2b 46 ba             	sub    ax,WORD PTR [bp-0x46]
    3671:	99                   	cwd
    3672:	b9 02 00             	mov    cx,0x2
    3675:	f7 f9                	idiv   cx
    3677:	50                   	push   ax
    3678:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    367b:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    3680:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    3684:	06                   	push   es
    3685:	57                   	push   di
    3686:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3689:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    368d:	99                   	cwd
    368e:	b9 02 00             	mov    cx,0x2
    3691:	f7 f9                	idiv   cx
    3693:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3696:	26 03 45 20          	add    ax,WORD PTR es:[di+0x20]
    369a:	5a                   	pop    dx
    369b:	2b c2                	sub    ax,dx
    369d:	50                   	push   ax
    369e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36a1:	06                   	push   es
    36a2:	57                   	push   di
    36a3:	9a 9d 17 c6 36       	call   0x36c6:0x179d
    36a8:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    36ab:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    36af:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    36b2:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    36b6:	89 86 b4 fe          	mov    WORD PTR [bp-0x14c],ax
    36ba:	eb 55                	jmp    0x3711
    36bc:	6a 0a                	push   0xa
    36be:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36c1:	06                   	push   es
    36c2:	57                   	push   di
    36c3:	9a 9d 17 fd 36       	call   0x36fd:0x179d
    36c8:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    36cb:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    36ce:	74 2f                	je     0x36ff
    36d0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    36d3:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    36d7:	99                   	cwd
    36d8:	b9 02 00             	mov    cx,0x2
    36db:	f7 f9                	idiv   cx
    36dd:	8b d8                	mov    bx,ax
    36df:	8b 46 be             	mov    ax,WORD PTR [bp-0x42]
    36e2:	2b 46 ba             	sub    ax,WORD PTR [bp-0x46]
    36e5:	99                   	cwd
    36e6:	b9 02 00             	mov    cx,0x2
    36e9:	f7 f9                	idiv   cx
    36eb:	2b c3                	sub    ax,bx
    36ed:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36f0:	26 03 45 20          	add    ax,WORD PTR es:[di+0x20]
    36f4:	50                   	push   ax
    36f5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    36f8:	06                   	push   es
    36f9:	57                   	push   di
    36fa:	9a 9d 17 33 37       	call   0x3733:0x179d
    36ff:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3702:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    3706:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3709:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    370d:	89 86 b4 fe          	mov    WORD PTR [bp-0x14c],ax
    3711:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    3714:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    3717:	74 1e                	je     0x3737
    3719:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    371c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3720:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3723:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    3727:	05 0a 00             	add    ax,0xa
    372a:	50                   	push   ax
    372b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    372e:	06                   	push   es
    372f:	57                   	push   di
    3730:	9a 7b 17 41 37       	call   0x3741:0x177b
    3735:	eb 0c                	jmp    0x3743
    3737:	6a 0a                	push   0xa
    3739:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    373c:	06                   	push   es
    373d:	57                   	push   di
    373e:	9a 7b 17 55 37       	call   0x3755:0x177b
    3743:	8b 46 c4             	mov    ax,WORD PTR [bp-0x3c]
    3746:	99                   	cwd
    3747:	b9 02 00             	mov    cx,0x2
    374a:	f7 f9                	idiv   cx
    374c:	50                   	push   ax
    374d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3750:	06                   	push   es
    3751:	57                   	push   di
    3752:	9a a9 18 96 37       	call   0x3796:0x18a9
    3757:	99                   	cwd
    3758:	b9 02 00             	mov    cx,0x2
    375b:	f7 f9                	idiv   cx
    375d:	5a                   	pop    dx
    375e:	2b c2                	sub    ax,dx
    3760:	05 0f 00             	add    ax,0xf
    3763:	89 86 b6 fe          	mov    WORD PTR [bp-0x14a],ax
    3767:	c6 46 cb 00          	mov    BYTE PTR [bp-0x35],0x0
    376b:	eb 03                	jmp    0x3770
    376d:	fe 46 cb             	inc    BYTE PTR [bp-0x35]
    3770:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    3773:	98                   	cbw
    3774:	8b f8                	mov    di,ax
    3776:	c1 e7 02             	shl    di,0x2
    3779:	8b 43 cc             	mov    ax,WORD PTR [bp+di-0x34]
    377c:	0b 43 ce             	or     ax,WORD PTR [bp+di-0x32]
    377f:	74 49                	je     0x37ca
    3781:	ff b6 b6 fe          	push   WORD PTR [bp-0x14a]
    3785:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    3788:	98                   	cbw
    3789:	8b f8                	mov    di,ax
    378b:	c1 e7 02             	shl    di,0x2
    378e:	c4 7b cc             	les    di,DWORD PTR [bp+di-0x34]
    3791:	06                   	push   es
    3792:	57                   	push   di
    3793:	9a 7b 17 b1 37       	call   0x37b1:0x177b
    3798:	8b 86 b4 fe          	mov    ax,WORD PTR [bp-0x14c]
    379c:	05 0a 00             	add    ax,0xa
    379f:	50                   	push   ax
    37a0:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    37a3:	98                   	cbw
    37a4:	8b f8                	mov    di,ax
    37a6:	c1 e7 02             	shl    di,0x2
    37a9:	c4 7b cc             	les    di,DWORD PTR [bp+di-0x34]
    37ac:	06                   	push   es
    37ad:	57                   	push   di
    37ae:	9a 9d 17 ff 37       	call   0x37ff:0x179d
    37b3:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    37b6:	98                   	cbw
    37b7:	8b f8                	mov    di,ax
    37b9:	c1 e7 02             	shl    di,0x2
    37bc:	c4 7b cc             	les    di,DWORD PTR [bp+di-0x34]
    37bf:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    37c3:	05 08 00             	add    ax,0x8
    37c6:	01 86 b6 fe          	add    WORD PTR [bp-0x14a],ax
    37ca:	80 7e cb 08          	cmp    BYTE PTR [bp-0x35],0x8
    37ce:	75 9d                	jne    0x376d
    37d0:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    37d3:	98                   	cbw
    37d4:	8b f8                	mov    di,ax
    37d6:	d1 e7                	shl    di,1
    37d8:	83 bd 28 0c 00       	cmp    WORD PTR [di+0xc28],0x0
    37dd:	76 24                	jbe    0x3803
    37df:	8d be b0 fd          	lea    di,[bp-0x250]
    37e3:	16                   	push   ss
    37e4:	57                   	push   di
    37e5:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    37e8:	98                   	cbw
    37e9:	8b f8                	mov    di,ax
    37eb:	d1 e7                	shl    di,1
    37ed:	ff b5 28 0c          	push   WORD PTR [di+0xc28]
    37f1:	9a 2b 09 19 38       	call   0x3819:0x92b
    37f6:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    37fa:	06                   	push   es
    37fb:	57                   	push   di
    37fc:	9a 8c 1d 24 38       	call   0x3824:0x1d8c
    3801:	eb 23                	jmp    0x3826
    3803:	8d be b0 fc          	lea    di,[bp-0x350]
    3807:	16                   	push   ss
    3808:	57                   	push   di
    3809:	8d be b0 fd          	lea    di,[bp-0x250]
    380d:	16                   	push   ss
    380e:	57                   	push   di
    380f:	6a 00                	push   0x0
    3811:	9a e6 0d 55 39       	call   0x3955:0xde6
    3816:	9a c1 0b e2 39       	call   0x39e2:0xbc1
    381b:	c4 be b0 fe          	les    di,DWORD PTR [bp-0x150]
    381f:	06                   	push   es
    3820:	57                   	push   di
    3821:	9a 8c 1d 51 38       	call   0x3851:0x1d8c
    3826:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3829:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    382d:	99                   	cwd
    382e:	b9 02 00             	mov    cx,0x2
    3831:	f7 f9                	idiv   cx
    3833:	50                   	push   ax
    3834:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3838:	06                   	push   es
    3839:	57                   	push   di
    383a:	9a ba 60 6a 38       	call   0x386a:0x60ba
    383f:	99                   	cwd
    3840:	b9 02 00             	mov    cx,0x2
    3843:	f7 f9                	idiv   cx
    3845:	5a                   	pop    dx
    3846:	2b c2                	sub    ax,dx
    3848:	50                   	push   ax
    3849:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    384c:	06                   	push   es
    384d:	57                   	push   di
    384e:	9a 7b 17 7e 38       	call   0x387e:0x177b
    3853:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3856:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    385a:	99                   	cwd
    385b:	b9 02 00             	mov    cx,0x2
    385e:	f7 f9                	idiv   cx
    3860:	50                   	push   ax
    3861:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3865:	06                   	push   es
    3866:	57                   	push   di
    3867:	9a a5 60 3c 39       	call   0x393c:0x60a5
    386c:	99                   	cwd
    386d:	b9 02 00             	mov    cx,0x2
    3870:	f7 f9                	idiv   cx
    3872:	5a                   	pop    dx
    3873:	2b c2                	sub    ax,dx
    3875:	50                   	push   ax
    3876:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3879:	06                   	push   es
    387a:	57                   	push   di
    387b:	9a 9d 17 0b 39       	call   0x390b:0x179d
    3880:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3883:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3886:	c9                   	leave
    3887:	ca 08 00             	retf   0x8
    388a:	c8 02 00 00          	enter  0x2,0x0
    388e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3891:	06                   	push   es
    3892:	57                   	push   di
    3893:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    3896:	50                   	push   ax
    3897:	ff 76 0a             	push   WORD PTR [bp+0xa]
    389a:	ff 76 08             	push   WORD PTR [bp+0x8]
    389d:	ff 76 06             	push   WORD PTR [bp+0x6]
    38a0:	6a ff                	push   0xffff
    38a2:	6a ff                	push   0xffff
    38a4:	9a b9 38 b7 38       	call   0x38b7:0x38b9
    38a9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    38ac:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    38af:	c9                   	leave
    38b0:	ca 0c 00             	retf   0xc
    38b3:	00 00                	add    BYTE PTR [bx+si],al
    38b5:	4d                   	dec    bp
    38b6:	39 d1                	cmp    cx,dx
    38b8:	38 c8                	cmp    al,cl
    38ba:	06                   	push   es
    38bb:	00 00                	add    BYTE PTR [bx+si],al
    38bd:	31 c0                	xor    ax,ax
    38bf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    38c2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    38c5:	06                   	push   es
    38c6:	57                   	push   di
    38c7:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    38ca:	50                   	push   ax
    38cb:	ff 76 0e             	push   WORD PTR [bp+0xe]
    38ce:	9a 90 31 af 39       	call   0x39af:0x3190
    38d3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    38d6:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    38d9:	b8 b3 38             	mov    ax,0x38b3
    38dc:	0e                   	push   cs
    38dd:	50                   	push   ax
    38de:	55                   	push   bp
    38df:	ff 36 58 18          	push   WORD PTR ds:0x1858
    38e3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    38e7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    38ea:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    38ed:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    38f0:	26 89 85 ac 00       	mov    WORD PTR es:[di+0xac],ax
    38f5:	26 89 95 ae 00       	mov    WORD PTR es:[di+0xae],dx
    38fa:	83 7e 08 ff          	cmp    WORD PTR [bp+0x8],0xffff
    38fe:	7e 0d                	jle    0x390d
    3900:	ff 76 08             	push   WORD PTR [bp+0x8]
    3903:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3906:	06                   	push   es
    3907:	57                   	push   di
    3908:	9a 7b 17 1e 39       	call   0x391e:0x177b
    390d:	83 7e 06 ff          	cmp    WORD PTR [bp+0x6],0xffff
    3911:	7e 0d                	jle    0x3920
    3913:	ff 76 06             	push   WORD PTR [bp+0x6]
    3916:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3919:	06                   	push   es
    391a:	57                   	push   di
    391b:	9a 9d 17 32 39       	call   0x3932:0x179d
    3920:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3924:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    3928:	6a 60                	push   0x60
    392a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    392d:	06                   	push   es
    392e:	57                   	push   di
    392f:	9a f4 5d ff ff       	call   0xffff:0x5df4
    3934:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3937:	06                   	push   es
    3938:	57                   	push   di
    3939:	9a 45 5d ff ff       	call   0xffff:0x5d45
    393e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3941:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3945:	83 c4 06             	add    sp,0x6
    3948:	b8 58 39             	mov    ax,0x3958
    394b:	0e                   	push   cs
    394c:	50                   	push   ax
    394d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3950:	06                   	push   es
    3951:	57                   	push   di
    3952:	9a 7f 1f 74 39       	call   0x3974:0x1f7f
    3957:	cb                   	retf
    3958:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    395b:	c9                   	leave
    395c:	ca 10 00             	retf   0x10
    395f:	55                   	push   bp
    3960:	89 e5                	mov    bp,sp
    3962:	a1 d8 2a             	mov    ax,ds:0x2ad8
    3965:	0b 06 da 2a          	or     ax,WORD PTR ds:0x2ada
    3969:	74 0b                	je     0x3976
    396b:	c4 3e d8 2a          	les    di,DWORD PTR ds:0x2ad8
    396f:	06                   	push   es
    3970:	57                   	push   di
    3971:	9a 7f 1f b6 39       	call   0x39b6:0x1f7f
    3976:	ff 36 26 0c          	push   WORD PTR ds:0xc26
    397a:	9a 84 39 00 00       	call   0x0:0x3984
    397f:	ff 36 24 0c          	push   WORD PTR ds:0xc24
    3983:	9a ff ff 00 00       	call   0x0:0xffff
    3988:	c9                   	leave
    3989:	cb                   	retf
    398a:	c8 18 00 00          	enter  0x18,0x0
    398e:	bf 70 0d             	mov    di,0xd70
    3991:	1e                   	push   ds
    3992:	57                   	push   di
    3993:	9a a1 39 00 00       	call   0x0:0x39a1
    3998:	a3 d4 2a             	mov    ds:0x2ad4,ax
    399b:	bf 7d 0d             	mov    di,0xd7d
    399e:	1e                   	push   ds
    399f:	57                   	push   di
    39a0:	9a ff ff 00 00       	call   0x0:0xffff
    39a5:	a3 d6 2a             	mov    ds:0x2ad6,ax
    39a8:	b0 01                	mov    al,0x1
    39aa:	50                   	push   ax
    39ab:	b8 eb 1d             	mov    ax,0x1deb
    39ae:	ba 21 3a             	mov    dx,0x3a21
    39b1:	52                   	push   dx
    39b2:	50                   	push   ax
    39b3:	9a 50 1f ff ff       	call   0xffff:0x1f50
    39b8:	a3 d8 2a             	mov    ds:0x2ad8,ax
    39bb:	89 16 da 2a          	mov    WORD PTR ds:0x2ada,dx
    39bf:	8d 7e f0             	lea    di,[bp-0x10]
    39c2:	16                   	push   ss
    39c3:	57                   	push   di
    39c4:	bf 91 0d             	mov    di,0xd91
    39c7:	1e                   	push   ds
    39c8:	57                   	push   di
    39c9:	a1 8c 18             	mov    ax,ds:0x188c
    39cc:	31 d2                	xor    dx,dx
    39ce:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    39d1:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    39d4:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    39d8:	8d 7e e8             	lea    di,[bp-0x18]
    39db:	16                   	push   ss
    39dc:	57                   	push   di
    39dd:	6a 00                	push   0x0
    39df:	9a a3 0f 11 3a       	call   0x3a11:0xfa3
    39e4:	52                   	push   dx
    39e5:	50                   	push   ax
    39e6:	9a 16 3a 00 00       	call   0x0:0x3a16
    39eb:	a3 26 0c             	mov    ds:0xc26,ax
    39ee:	8d 7e f0             	lea    di,[bp-0x10]
    39f1:	16                   	push   ss
    39f2:	57                   	push   di
    39f3:	bf a0 0d             	mov    di,0xda0
    39f6:	1e                   	push   ds
    39f7:	57                   	push   di
    39f8:	a1 8c 18             	mov    ax,ds:0x188c
    39fb:	31 d2                	xor    dx,dx
    39fd:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3a00:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3a03:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    3a07:	8d 7e e8             	lea    di,[bp-0x18]
    3a0a:	16                   	push   ss
    3a0b:	57                   	push   di
    3a0c:	6a 00                	push   0x0
    3a0e:	9a a3 0f 28 3a       	call   0x3a28:0xfa3
    3a13:	52                   	push   dx
    3a14:	50                   	push   ax
    3a15:	9a ff ff 00 00       	call   0x0:0xffff
    3a1a:	a3 24 0c             	mov    ds:0xc24,ax
    3a1d:	bf 5f 39             	mov    di,0x395f
    3a20:	b8 ff ff             	mov    ax,0xffff
    3a23:	50                   	push   ax
    3a24:	57                   	push   di
    3a25:	9a 74 05 ff ff       	call   0xffff:0x574
    3a2a:	c9                   	leave
    3a2b:	c3                   	ret
    3a2c:	55                   	push   bp
    3a2d:	89 e5                	mov    bp,sp
    3a2f:	e8 58 ff             	call   0x398a
    3a32:	c9                   	leave
    3a33:	cb                   	retf
