; ================================================================
; seg40_CODE  (28416 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	28 00                	sub    BYTE PTR [bx+si],al
	...
       a:	22 00                	and    al,BYTE PTR [bx+si]
       c:	0c 00                	or     al,0x0
       e:	7f 00                	jg     0x10
      10:	50                   	push   ax
      11:	00 64 20             	add    BYTE PTR [si+0x20],ah
      14:	4c                   	dec    sp
      15:	00 9a 1f 14          	add    BYTE PTR [bp+si+0x141f],bl
      19:	00 2f                	add    BYTE PTR [bx],ch
      1b:	2a 10                	sub    dl,BYTE PTR [bx+si]
      1d:	00 1d                	add    BYTE PTR [di],bl
      1f:	2a 1c                	sub    bl,BYTE PTR [si]
      21:	00 0f                	add    BYTE PTR [bx],cl
      23:	45                   	inc    bp
      24:	4f                   	dec    di
      25:	75 74                	jne    0x9b
      27:	4f                   	dec    di
      28:	66 52                	push   edx
      2a:	65 73 6f             	gs jae 0x9c
      2d:	75 72                	jne    0xa1
      2f:	63 65 73             	arpl   WORD PTR [di+0x73],sp
	...
      3a:	52                   	push   dx
      3b:	00 0c                	add    BYTE PTR [si],cl
      3d:	00 2e 00 1d          	add    BYTE PTR ds:0x1d00,ch
      41:	0c 64                	or     al,0x64
      43:	20 90 00 9a          	and    BYTE PTR [bx+si-0x6600],dl
      47:	1f                   	pop    ds
      48:	44                   	inc    sp
      49:	00 cb                	add    bl,cl
      4b:	1f                   	pop    ds
      4c:	48                   	dec    ax
      4d:	00 c4                	add    ah,al
      4f:	29 40 00             	sub    WORD PTR [bx+si+0x0],ax
      52:	11 45 49             	adc    WORD PTR [di+0x49],ax
      55:	6e                   	outs   dx,BYTE PTR ds:[si]
      56:	76 61                	jbe    0xb9
      58:	6c                   	ins    BYTE PTR es:[di],dx
      59:	69 64 4f 70 65       	imul   sp,WORD PTR [si+0x4f],0x6570
      5e:	72 61                	jb     0xc1
      60:	74 69                	je     0xcb
      62:	6f                   	outs   dx,WORD PTR ds:[si]
      63:	6e                   	outs   dx,BYTE PTR ds:[si]
      64:	01 07                	add    WORD PTR [bx],ax
      66:	54                   	push   sp
      67:	43                   	inc    bx
      68:	75 72                	jne    0xdc
      6a:	73 6f                	jae    0xdb
      6c:	72 02                	jb     0x70
      6e:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
      72:	ff                   	(bad)
      73:	7f 00                	jg     0x75
      75:	00 bd 00 00          	add    BYTE PTR [di+0x0],bh
      79:	00 00                	add    BYTE PTR [bx+si],al
      7b:	00 00                	add    BYTE PTR [bx+si],al
      7d:	00 ae 00 33          	add    BYTE PTR [bp+0x3300],ch
      81:	00 60 05             	add    BYTE PTR [bx+si+0x5],ah
      84:	d3 00                	rol    WORD PTR [bx+si],cl
      86:	64 20 93 03 9a       	and    BYTE PTR fs:[bp+di-0x65fd],dl
      8b:	1f                   	pop    ds
      8c:	88 00                	mov    BYTE PTR [bx+si],al
      8e:	cb                   	retf
      8f:	1f                   	pop    ds
      90:	8c 00                	mov    WORD PTR [bx+si],es
      92:	7c 12                	jl     0xa6
      94:	cf                   	iret
      95:	00 cd                	add    ch,cl
      97:	11 9c 00 e4          	adc    WORD PTR [si-0x1c00],bx
      9b:	11 a0 00 fa          	adc    WORD PTR [bx+si-0x600],sp
      9f:	10 ab 03 7f          	adc    BYTE PTR [bp+di+0x7f03],ch
      a3:	23 a8 00 5b          	and    bp,WORD PTR [bx+si+0x5b00]
      a7:	23 84 00 a5          	and    ax,WORD PTR [si-0x5b00]
      ab:	12 94 00 0e          	adc    dl,BYTE PTR [si+0xe00]
      af:	54                   	push   sp
      b0:	43                   	inc    bx
      b1:	6f                   	outs   dx,WORD PTR ds:[si]
      b2:	6e                   	outs   dx,BYTE PTR ds:[si]
      b3:	74 72                	je     0x127
      b5:	6f                   	outs   dx,WORD PTR ds:[si]
      b6:	6c                   	ins    BYTE PTR es:[di],dx
      b7:	43                   	inc    bx
      b8:	61                   	popa
      b9:	6e                   	outs   dx,BYTE PTR ds:[si]
      ba:	76 61                	jbe    0x11d
      bc:	73 07                	jae    0xc5
      be:	0e                   	push   cs
      bf:	54                   	push   sp
      c0:	43                   	inc    bx
      c1:	6f                   	outs   dx,WORD PTR ds:[si]
      c2:	6e                   	outs   dx,BYTE PTR ds:[si]
      c3:	74 72                	je     0x137
      c5:	6f                   	outs   dx,WORD PTR ds:[si]
      c6:	6c                   	ins    BYTE PTR es:[di],dx
      c7:	43                   	inc    bx
      c8:	61                   	popa
      c9:	6e                   	outs   dx,BYTE PTR ds:[si]
      ca:	76 61                	jbe    0x12d
      cc:	73 96                	jae    0x64
      ce:	00 f5                	add    ch,dh
      d0:	00 80 05 94          	add    BYTE PTR [bx+si-0x6bfb],al
      d4:	12 04                	adc    al,BYTE PTR [si]
      d6:	00 08                	add    BYTE PTR [bx+si],cl
      d8:	43                   	inc    bx
      d9:	6f                   	outs   dx,WORD PTR ds:[si]
      da:	6e                   	outs   dx,BYTE PTR ds:[si]
      db:	74 72                	je     0x14f
      dd:	6f                   	outs   dx,WORD PTR ds:[si]
      de:	6c                   	ins    BYTE PTR es:[di],dx
      df:	73 00                	jae    0xe1
      e1:	00 03                	add    BYTE PTR [bp+di],al
      e3:	06                   	push   es
      e4:	54                   	push   sp
      e5:	41                   	inc    cx
      e6:	6c                   	ins    BYTE PTR es:[di],dx
      e7:	69 67 6e 00 00       	imul   sp,WORD PTR [bx+0x6e],0x0
      ec:	00 00                	add    BYTE PTR [bx+si],al
      ee:	00 05                	add    BYTE PTR [di],al
      f0:	00 00                	add    BYTE PTR [bx+si],al
      f2:	00 e2                	add    dl,ah
      f4:	00 3b                	add    BYTE PTR [bp+di],bh
      f6:	01 06 61 6c          	add    WORD PTR ds:0x6c61,ax
      fa:	4e                   	dec    si
      fb:	6f                   	outs   dx,WORD PTR ds:[si]
      fc:	6e                   	outs   dx,BYTE PTR ds:[si]
      fd:	65 05 61 6c          	gs add ax,0x6c61
     101:	54                   	push   sp
     102:	6f                   	outs   dx,WORD PTR ds:[si]
     103:	70 08                	jo     0x10d
     105:	61                   	popa
     106:	6c                   	ins    BYTE PTR es:[di],dx
     107:	42                   	inc    dx
     108:	6f                   	outs   dx,WORD PTR ds:[si]
     109:	74 74                	je     0x17f
     10b:	6f                   	outs   dx,WORD PTR ds:[si]
     10c:	6d                   	ins    WORD PTR es:[di],dx
     10d:	06                   	push   es
     10e:	61                   	popa
     10f:	6c                   	ins    BYTE PTR es:[di],dx
     110:	4c                   	dec    sp
     111:	65 66 74 07          	gs data32 je 0x11c
     115:	61                   	popa
     116:	6c                   	ins    BYTE PTR es:[di],dx
     117:	52                   	push   dx
     118:	69 67 68 74 08       	imul   sp,WORD PTR [bx+0x68],0x874
     11d:	61                   	popa
     11e:	6c                   	ins    BYTE PTR es:[di],dx
     11f:	43                   	inc    bx
     120:	6c                   	ins    BYTE PTR es:[di],dx
     121:	69 65 6e 74 03       	imul   sp,WORD PTR [di+0x6e],0x374
     126:	09 54 44             	or     WORD PTR [si+0x44],dx
     129:	72 61                	jb     0x18c
     12b:	67 4d                	addr32 dec bp
     12d:	6f                   	outs   dx,WORD PTR ds:[si]
     12e:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
     132:	00 00                	add    BYTE PTR [bx+si],al
     134:	00 01                	add    BYTE PTR [bx+di],al
     136:	00 00                	add    BYTE PTR [bx+si],al
     138:	00 25                	add    BYTE PTR [di],ah
     13a:	01 8b 03 08          	add    WORD PTR [bp+di+0x803],cx
     13e:	64 6d                	fs ins WORD PTR es:[di],dx
     140:	4d                   	dec    bp
     141:	61                   	popa
     142:	6e                   	outs   dx,BYTE PTR ds:[si]
     143:	75 61                	jne    0x1a6
     145:	6c                   	ins    BYTE PTR es:[di],dx
     146:	0b 64 6d             	or     sp,WORD PTR [si+0x6d]
     149:	41                   	inc    cx
     14a:	75 74                	jne    0x1c0
     14c:	6f                   	outs   dx,WORD PTR ds:[si]
     14d:	6d                   	ins    WORD PTR es:[di],dx
     14e:	61                   	popa
     14f:	74 69                	je     0x1ba
     151:	63 01                	arpl   WORD PTR [bx+di],ax
     153:	09 54 54             	or     WORD PTR [si+0x54],dx
     156:	61                   	popa
     157:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     15a:	64 65 72 02          	fs gs jb 0x160
     15e:	ff                   	(bad)
     15f:	ff                   	(bad)
     160:	ff                   	(bad)
     161:	ff                   	(bad)
     162:	ff                   	(bad)
     163:	7f 00                	jg     0x165
     165:	00 05                	add    BYTE PTR [di],al
     167:	08 54 43             	or     BYTE PTR [si+0x43],dl
     16a:	61                   	popa
     16b:	70 74                	jo     0x1e1
     16d:	69 6f 6e ff 08       	imul   bp,WORD PTR [bx+0x6e],0x8ff
     172:	0b 54 4d             	or     dx,WORD PTR [si+0x4d]
     175:	6f                   	outs   dx,WORD PTR ds:[si]
     176:	75 73                	jne    0x1eb
     178:	65 45                	gs inc bp
     17a:	76 65                	jbe    0x1e1
     17c:	6e                   	outs   dx,BYTE PTR ds:[si]
     17d:	74 00                	je     0x17f
     17f:	05 00 06             	add    ax,0x600
     182:	53                   	push   bx
     183:	65 6e                	outs   dx,BYTE PTR gs:[si]
     185:	64 65 72 07          	fs gs jb 0x190
     189:	54                   	push   sp
     18a:	4f                   	dec    di
     18b:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     18e:	63 74 00             	arpl   WORD PTR [si+0x0],si
     191:	06                   	push   es
     192:	42                   	inc    dx
     193:	75 74                	jne    0x209
     195:	74 6f                	je     0x206
     197:	6e                   	outs   dx,BYTE PTR ds:[si]
     198:	0c 54                	or     al,0x54
     19a:	4d                   	dec    bp
     19b:	6f                   	outs   dx,WORD PTR ds:[si]
     19c:	75 73                	jne    0x211
     19e:	65 42                	gs inc dx
     1a0:	75 74                	jne    0x216
     1a2:	74 6f                	je     0x213
     1a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     1a5:	00 05                	add    BYTE PTR [di],al
     1a7:	53                   	push   bx
     1a8:	68 69 66             	push   0x6669
     1ab:	74 0b                	je     0x1b8
     1ad:	54                   	push   sp
     1ae:	53                   	push   bx
     1af:	68 69 66             	push   0x6669
     1b2:	74 53                	je     0x207
     1b4:	74 61                	je     0x217
     1b6:	74 65                	je     0x21d
     1b8:	00 01                	add    BYTE PTR [bx+di],al
     1ba:	58                   	pop    ax
     1bb:	07                   	pop    es
     1bc:	49                   	dec    cx
     1bd:	6e                   	outs   dx,BYTE PTR ds:[si]
     1be:	74 65                	je     0x225
     1c0:	67 65 72 00          	addr32 gs jb 0x1c4
     1c4:	01 59 07             	add    WORD PTR [bx+di+0x7],bx
     1c7:	49                   	dec    cx
     1c8:	6e                   	outs   dx,BYTE PTR ds:[si]
     1c9:	74 65                	je     0x230
     1cb:	67 65 72 08          	addr32 gs jb 0x1d7
     1cf:	0f 54 4d 6f          	andps  xmm1,XMMWORD PTR [di+0x6f]
     1d3:	75 73                	jne    0x248
     1d5:	65 4d                	gs dec bp
     1d7:	6f                   	outs   dx,WORD PTR ds:[si]
     1d8:	76 65                	jbe    0x23f
     1da:	45                   	inc    bp
     1db:	76 65                	jbe    0x242
     1dd:	6e                   	outs   dx,BYTE PTR ds:[si]
     1de:	74 00                	je     0x1e0
     1e0:	04 00                	add    al,0x0
     1e2:	06                   	push   es
     1e3:	53                   	push   bx
     1e4:	65 6e                	outs   dx,BYTE PTR gs:[si]
     1e6:	64 65 72 07          	fs gs jb 0x1f1
     1ea:	54                   	push   sp
     1eb:	4f                   	dec    di
     1ec:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     1ef:	63 74 00             	arpl   WORD PTR [si+0x0],si
     1f2:	05 53 68             	add    ax,0x6853
     1f5:	69 66 74 0b 54       	imul   sp,WORD PTR [bp+0x74],0x540b
     1fa:	53                   	push   bx
     1fb:	68 69 66             	push   0x6669
     1fe:	74 53                	je     0x253
     200:	74 61                	je     0x263
     202:	74 65                	je     0x269
     204:	00 01                	add    BYTE PTR [bx+di],al
     206:	58                   	pop    ax
     207:	07                   	pop    es
     208:	49                   	dec    cx
     209:	6e                   	outs   dx,BYTE PTR ds:[si]
     20a:	74 65                	je     0x271
     20c:	67 65 72 00          	addr32 gs jb 0x210
     210:	01 59 07             	add    WORD PTR [bx+di+0x7],bx
     213:	49                   	dec    cx
     214:	6e                   	outs   dx,BYTE PTR ds:[si]
     215:	74 65                	je     0x27c
     217:	67 65 72 08          	addr32 gs jb 0x223
     21b:	09 54 4b             	or     WORD PTR [si+0x4b],dx
     21e:	65 79 45             	gs jns 0x266
     221:	76 65                	jbe    0x288
     223:	6e                   	outs   dx,BYTE PTR ds:[si]
     224:	74 00                	je     0x226
     226:	03 00                	add    ax,WORD PTR [bx+si]
     228:	06                   	push   es
     229:	53                   	push   bx
     22a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     22c:	64 65 72 07          	fs gs jb 0x237
     230:	54                   	push   sp
     231:	4f                   	dec    di
     232:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     235:	63 74 01             	arpl   WORD PTR [si+0x1],si
     238:	03 4b 65             	add    cx,WORD PTR [bp+di+0x65]
     23b:	79 04                	jns    0x241
     23d:	57                   	push   di
     23e:	6f                   	outs   dx,WORD PTR ds:[si]
     23f:	72 64                	jb     0x2a5
     241:	00 05                	add    BYTE PTR [di],al
     243:	53                   	push   bx
     244:	68 69 66             	push   0x6669
     247:	74 0b                	je     0x254
     249:	54                   	push   sp
     24a:	53                   	push   bx
     24b:	68 69 66             	push   0x6669
     24e:	74 53                	je     0x2a3
     250:	74 61                	je     0x2b3
     252:	74 65                	je     0x2b9
     254:	08 0e 54 4b          	or     BYTE PTR ds:0x4b54,cl
     258:	65 79 50             	gs jns 0x2ab
     25b:	72 65                	jb     0x2c2
     25d:	73 73                	jae    0x2d2
     25f:	45                   	inc    bp
     260:	76 65                	jbe    0x2c7
     262:	6e                   	outs   dx,BYTE PTR ds:[si]
     263:	74 00                	je     0x265
     265:	02 00                	add    al,BYTE PTR [bx+si]
     267:	06                   	push   es
     268:	53                   	push   bx
     269:	65 6e                	outs   dx,BYTE PTR gs:[si]
     26b:	64 65 72 07          	fs gs jb 0x276
     26f:	54                   	push   sp
     270:	4f                   	dec    di
     271:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     274:	63 74 01             	arpl   WORD PTR [si+0x1],si
     277:	03 4b 65             	add    cx,WORD PTR [bp+di+0x65]
     27a:	79 04                	jns    0x280
     27c:	43                   	inc    bx
     27d:	68 61 72             	push   0x7261
     280:	08 0e 54 44          	or     BYTE PTR ds:0x4454,cl
     284:	72 61                	jb     0x2e7
     286:	67 4f                	addr32 dec di
     288:	76 65                	jbe    0x2ef
     28a:	72 45                	jb     0x2d1
     28c:	76 65                	jbe    0x2f3
     28e:	6e                   	outs   dx,BYTE PTR ds:[si]
     28f:	74 00                	je     0x291
     291:	06                   	push   es
     292:	00 06 53 65          	add    BYTE PTR ds:0x6553,al
     296:	6e                   	outs   dx,BYTE PTR ds:[si]
     297:	64 65 72 07          	fs gs jb 0x2a2
     29b:	54                   	push   sp
     29c:	4f                   	dec    di
     29d:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     2a0:	63 74 00             	arpl   WORD PTR [si+0x0],si
     2a3:	06                   	push   es
     2a4:	53                   	push   bx
     2a5:	6f                   	outs   dx,WORD PTR ds:[si]
     2a6:	75 72                	jne    0x31a
     2a8:	63 65 07             	arpl   WORD PTR [di+0x7],sp
     2ab:	54                   	push   sp
     2ac:	4f                   	dec    di
     2ad:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     2b0:	63 74 00             	arpl   WORD PTR [si+0x0],si
     2b3:	01 58 07             	add    WORD PTR [bx+si+0x7],bx
     2b6:	49                   	dec    cx
     2b7:	6e                   	outs   dx,BYTE PTR ds:[si]
     2b8:	74 65                	je     0x31f
     2ba:	67 65 72 00          	addr32 gs jb 0x2be
     2be:	01 59 07             	add    WORD PTR [bx+di+0x7],bx
     2c1:	49                   	dec    cx
     2c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     2c3:	74 65                	je     0x32a
     2c5:	67 65 72 00          	addr32 gs jb 0x2c9
     2c9:	05 53 74             	add    ax,0x7453
     2cc:	61                   	popa
     2cd:	74 65                	je     0x334
     2cf:	0a 54 44             	or     dl,BYTE PTR [si+0x44]
     2d2:	72 61                	jb     0x335
     2d4:	67 53                	addr32 push bx
     2d6:	74 61                	je     0x339
     2d8:	74 65                	je     0x33f
     2da:	01 06 41 63          	add    WORD PTR ds:0x6341,ax
     2de:	63 65 70             	arpl   WORD PTR [di+0x70],sp
     2e1:	74 07                	je     0x2ea
     2e3:	42                   	inc    dx
     2e4:	6f                   	outs   dx,WORD PTR ds:[si]
     2e5:	6f                   	outs   dx,WORD PTR ds:[si]
     2e6:	6c                   	ins    BYTE PTR es:[di],dx
     2e7:	65 61                	gs popa
     2e9:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ea:	08 0e 54 44          	or     BYTE PTR ds:0x4454,cl
     2ee:	72 61                	jb     0x351
     2f0:	67 44                	addr32 inc sp
     2f2:	72 6f                	jb     0x363
     2f4:	70 45                	jo     0x33b
     2f6:	76 65                	jbe    0x35d
     2f8:	6e                   	outs   dx,BYTE PTR ds:[si]
     2f9:	74 00                	je     0x2fb
     2fb:	04 00                	add    al,0x0
     2fd:	06                   	push   es
     2fe:	53                   	push   bx
     2ff:	65 6e                	outs   dx,BYTE PTR gs:[si]
     301:	64 65 72 07          	fs gs jb 0x30c
     305:	54                   	push   sp
     306:	4f                   	dec    di
     307:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     30a:	63 74 00             	arpl   WORD PTR [si+0x0],si
     30d:	06                   	push   es
     30e:	53                   	push   bx
     30f:	6f                   	outs   dx,WORD PTR ds:[si]
     310:	75 72                	jne    0x384
     312:	63 65 07             	arpl   WORD PTR [di+0x7],sp
     315:	54                   	push   sp
     316:	4f                   	dec    di
     317:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     31a:	63 74 00             	arpl   WORD PTR [si+0x0],si
     31d:	01 58 07             	add    WORD PTR [bx+si+0x7],bx
     320:	49                   	dec    cx
     321:	6e                   	outs   dx,BYTE PTR ds:[si]
     322:	74 65                	je     0x389
     324:	67 65 72 00          	addr32 gs jb 0x328
     328:	01 59 07             	add    WORD PTR [bx+di+0x7],bx
     32b:	49                   	dec    cx
     32c:	6e                   	outs   dx,BYTE PTR ds:[si]
     32d:	74 65                	je     0x394
     32f:	67 65 72 08          	addr32 gs jb 0x33b
     333:	0d 54 45             	or     ax,0x4554
     336:	6e                   	outs   dx,BYTE PTR ds:[si]
     337:	64 44                	fs inc sp
     339:	72 61                	jb     0x39c
     33b:	67 45                	addr32 inc bp
     33d:	76 65                	jbe    0x3a4
     33f:	6e                   	outs   dx,BYTE PTR ds:[si]
     340:	74 00                	je     0x342
     342:	04 00                	add    al,0x0
     344:	06                   	push   es
     345:	53                   	push   bx
     346:	65 6e                	outs   dx,BYTE PTR gs:[si]
     348:	64 65 72 07          	fs gs jb 0x353
     34c:	54                   	push   sp
     34d:	4f                   	dec    di
     34e:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     351:	63 74 00             	arpl   WORD PTR [si+0x0],si
     354:	06                   	push   es
     355:	54                   	push   sp
     356:	61                   	popa
     357:	72 67                	jb     0x3c0
     359:	65 74 07             	gs je  0x363
     35c:	54                   	push   sp
     35d:	4f                   	dec    di
     35e:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     361:	63 74 00             	arpl   WORD PTR [si+0x0],si
     364:	01 58 07             	add    WORD PTR [bx+si+0x7],bx
     367:	49                   	dec    cx
     368:	6e                   	outs   dx,BYTE PTR ds:[si]
     369:	74 65                	je     0x3d0
     36b:	67 65 72 00          	addr32 gs jb 0x36f
     36f:	01 59 07             	add    WORD PTR [bx+di+0x7],bx
     372:	49                   	dec    cx
     373:	6e                   	outs   dx,BYTE PTR ds:[si]
     374:	74 65                	je     0x3db
     376:	67 65 72 d0          	addr32 gs jb 0x34a
     37a:	04 00                	add    al,0x0
     37c:	00 00                	add    BYTE PTR [bx+si],al
     37e:	00 f6                	add    dh,dh
     380:	03 ed                	add    bp,bp
     382:	03 8a 00 da          	add    cx,WORD PTR [bp+si-0x2600]
     386:	05 e0 04             	add    ax,0x4e0
     389:	10 26 9f 03          	adc    BYTE PTR ds:0x39f,ah
     38d:	9a 1f f1 04 cb       	call   0xcb04:0xf11f
     392:	1f                   	pop    ds
     393:	8f 03                	pop    WORD PTR [bp+di]
     395:	58                   	pop    ax
     396:	14 df                	adc    al,0xdf
     398:	03 cd                	add    cx,bp
     39a:	11 a3 03 3a          	adc    WORD PTR [bp+di+0x3a03],sp
     39e:	27                   	daa
     39f:	cb                   	retf
     3a0:	03 fa                	add    di,dx
     3a2:	10 87 03 d6          	adc    BYTE PTR [bx-0x29fd],al
     3a6:	14 af                	adc    al,0xaf
     3a8:	03 f4                	add    si,sp
     3aa:	4f                   	dec    di
     3ab:	bb 03 32             	mov    bx,0x3203
     3ae:	16                   	push   ss
     3af:	b3 03                	mov    bl,0x3
     3b1:	98                   	cbw
     3b2:	15 d7 03             	adc    ax,0x3d7
     3b5:	51                   	push   cx
     3b6:	1b db                	sbb    bx,bx
     3b8:	03 38                	add    di,WORD PTR [bx+si]
     3ba:	50                   	push   ax
     3bb:	bf 03 1a             	mov    di,0x1a03
     3be:	50                   	push   ax
     3bf:	c3                   	ret
     3c0:	03 21                	add    sp,WORD PTR [bx+di]
     3c2:	50                   	push   ax
     3c3:	9b                   	fwait
     3c4:	03 9b 13 97          	add    bx,WORD PTR [bp+di-0x68ed]
     3c8:	03 3f                	add    di,WORD PTR [bx]
     3ca:	19 cf                	sbb    di,cx
     3cc:	03 78 18             	add    di,WORD PTR [bx+si+0x18]
     3cf:	d3 03                	rol    WORD PTR [bp+di],cl
     3d1:	02 21                	add    ah,BYTE PTR [bx+di]
     3d3:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     3d4:	03 3a                	add    di,WORD PTR [bp+si]
     3d6:	1c b7                	sbb    al,0xb7
     3d8:	03 15                	add    dx,WORD PTR [di]
     3da:	25 c7 03             	and    ax,0x3c7
     3dd:	37                   	aaa
     3de:	22 e3                	and    ah,bl
     3e0:	03 df                	add    bx,di
     3e2:	22 e7                	and    ah,bh
     3e4:	03 f8                	add    di,ax
     3e6:	16                   	push   ss
     3e7:	eb 03                	jmp    0x3ec
     3e9:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     3ea:	22 42 04             	and    al,BYTE PTR [bp+si+0x4]
     3ed:	08 54 43             	or     BYTE PTR [si+0x43],dl
     3f0:	6f                   	outs   dx,WORD PTR ds:[si]
     3f1:	6e                   	outs   dx,BYTE PTR ds:[si]
     3f2:	74 72                	je     0x466
     3f4:	6f                   	outs   dx,WORD PTR ds:[si]
     3f5:	6c                   	ins    BYTE PTR es:[di],dx
     3f6:	24 00                	and    al,0x0
     3f8:	01 02                	add    WORD PTR [bp+si],ax
     3fa:	a1 00 a4             	mov    ax,ds:0xa400
     3fd:	00 04                	add    BYTE PTR [si],al
     3ff:	02 07                	add    al,BYTE PTR [bx]
     401:	02 03                	add    al,BYTE PTR [bp+di]
     403:	02 06 02 09          	add    al,BYTE PTR ds:0x902
     407:	02 00                	add    al,BYTE PTR [bx+si]
     409:	02 02                	add    al,BYTE PTR [bp+si]
     40b:	02 05                	add    al,BYTE PTR [di]
     40d:	02 08                	add    cl,BYTE PTR [bx+si]
     40f:	02 1f                	add    bl,BYTE PTR [bx]
     411:	00 0b                	add    BYTE PTR [bp+di],cl
     413:	0f 0c                	(bad)
     415:	0f 0e                	femms
     417:	0f 0d 0f             	prefetchw BYTE PTR [bx]
     41a:	08 0f                	or     BYTE PTR [bx],cl
     41c:	09 0f                	or     WORD PTR [bx],cx
     41e:	23 0f                	and    cx,WORD PTR [bx]
     420:	0a 0f                	or     cl,BYTE PTR [bx]
     422:	13 0f                	adc    cx,WORD PTR [bx]
     424:	14 0f                	adc    al,0xf
     426:	1c 0f                	sbb    al,0xf
     428:	ff                   	(bad)
     429:	ff                   	(bad)
     42a:	fe                   	(bad)
     42b:	ff                   	(bad)
     42c:	fd                   	std
     42d:	ff                   	(bad)
     42e:	fc                   	cld
     42f:	ff                   	(bad)
     430:	fb                   	sti
     431:	ff                   	(bad)
     432:	fa                   	cli
     433:	ff                   	(bad)
     434:	f9                   	stc
     435:	ff                   	(bad)
     436:	f8                   	clc
     437:	ff f7                	push   di
     439:	ff f6                	push   si
     43b:	ff f5                	push   bp
     43d:	ff f4                	push   sp
     43f:	ff 2c                	jmp    DWORD PTR [si]
     441:	28 46 04             	sub    BYTE PTR [bp+0x4],al
     444:	ba 28 4a             	mov    dx,0x4a28
     447:	04 e3                	add    al,0xe3
     449:	28 4e 04             	sub    BYTE PTR [bp+0x4],cl
     44c:	12 2a                	adc    ch,BYTE PTR [bp+si]
     44e:	52                   	push   dx
     44f:	04 9a                	add    al,0x9a
     451:	2a 56 04             	sub    dl,BYTE PTR [bp+0x4]
     454:	12 29                	adc    ch,BYTE PTR [bx+di]
     456:	5a                   	pop    dx
     457:	04 6e                	add    al,0x6e
     459:	2a 5e 04             	sub    bl,BYTE PTR [bp+0x4]
     45c:	c6                   	(bad)
     45d:	2a 62 04             	sub    ah,BYTE PTR [bp+si+0x4]
     460:	20 2b                	and    BYTE PTR [bp+di],ch
     462:	66 04 ce             	data32 add al,0xce
     465:	2b 6a 04             	sub    bp,WORD PTR [bp+si+0x4]
     468:	4d                   	dec    bp
     469:	2c 6e                	sub    al,0x6e
     46b:	04 77                	add    al,0x77
     46d:	2c 72                	sub    al,0x72
     46f:	04 a1                	add    al,0xa1
     471:	2c 76                	sub    al,0x76
     473:	04 ee                	add    al,0xee
     475:	2c 7a                	sub    al,0x7a
     477:	04 20                	add    al,0x20
     479:	2d 7e 04             	sub    ax,0x47e
     47c:	33 2d                	xor    bp,WORD PTR [di]
     47e:	82 04 46             	add    BYTE PTR [si],0x46
     481:	2d 86 04             	sub    ax,0x486
     484:	b4 2d                	mov    ah,0x2d
     486:	8a 04                	mov    al,BYTE PTR [si]
     488:	59                   	pop    cx
     489:	2d 8e 04             	sub    ax,0x48e
     48c:	88 2d                	mov    BYTE PTR [di],ch
     48e:	92                   	xchg   dx,ax
     48f:	04 e3                	add    al,0xe3
     491:	2d 96 04             	sub    ax,0x496
     494:	f9                   	stc
     495:	2d 9a 04             	sub    ax,0x49a
     498:	23 2e 9e 04          	and    bp,WORD PTR ds:0x49e
     49c:	4d                   	dec    bp
     49d:	2e a2 04 69          	mov    cs:0x6904,al
     4a1:	1a a6 04 73          	sbb    ah,BYTE PTR [bp+0x7304]
     4a5:	27                   	daa
     4a6:	aa                   	stos   BYTE PTR es:[di],al
     4a7:	04 98                	add    al,0x98
     4a9:	27                   	daa
     4aa:	ae                   	scas   al,BYTE PTR es:[di]
     4ab:	04 8f                	add    al,0x8f
     4ad:	24 b2                	and    al,0xb2
     4af:	04 c6                	add    al,0xc6
     4b1:	14 b6                	adc    al,0xb6
     4b3:	04 c0                	add    al,0xc0
     4b5:	27                   	daa
     4b6:	ba 04 f2             	mov    dx,0xf204
     4b9:	2a be 04 65          	sub    bh,BYTE PTR [bp+0x6504]
     4bd:	2b c2                	sub    ax,dx
     4bf:	04 e5                	add    al,0xe5
     4c1:	14 c6                	adc    al,0xc6
     4c3:	04 32                	add    al,0x32
     4c5:	20 ca                	and    dl,cl
     4c7:	04 0e                	add    al,0xe
     4c9:	25 ce 04             	and    ax,0x4ce
     4cc:	5f                   	pop    di
     4cd:	24 dc                	and    al,0xdc
     4cf:	04 07                	add    al,0x7
     4d1:	08 54 43             	or     BYTE PTR [si+0x43],dl
     4d4:	6f                   	outs   dx,WORD PTR ds:[si]
     4d5:	6e                   	outs   dx,BYTE PTR ds:[si]
     4d6:	74 72                	je     0x54a
     4d8:	6f                   	outs   dx,WORD PTR ds:[si]
     4d9:	6c                   	ins    BYTE PTR es:[di],dx
     4da:	99                   	cwd
     4db:	03 f9                	add    di,cx
     4dd:	04 15                	add    al,0x15
     4df:	06                   	push   es
     4e0:	d3 05                	rol    WORD PTR [di],cl
     4e2:	08 00                	or     BYTE PTR [bx+si],al
     4e4:	08 43 6f             	or     BYTE PTR [bp+di+0x6f],al
     4e7:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e8:	74 72                	je     0x55c
     4ea:	6f                   	outs   dx,WORD PTR ds:[si]
     4eb:	6c                   	ins    BYTE PTR es:[di],dx
     4ec:	73 06                	jae    0x4f4
     4ee:	00 d4                	add    ah,dl
     4f0:	22 0e 05 1e          	and    cl,BYTE PTR ds:0x1e05
     4f4:	00 ff                	add    bh,bh
     4f6:	ff                   	(bad)
     4f7:	7b 17                	jnp    0x510
     4f9:	16                   	push   ss
     4fa:	05 01 00             	add    ax,0x1
     4fd:	00 00                	add    BYTE PTR [bx+si],al
     4ff:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     503:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     507:	04 4c                	add    al,0x4c
     509:	65 66 74 d4          	gs data32 je 0x4e1
     50d:	22 2a                	and    ch,BYTE PTR [bp+si]
     50f:	05 20 00             	add    ax,0x20
     512:	ff                   	(bad)
     513:	ff 9d 17 32          	call   DWORD PTR [di+0x3217]
     517:	05 01 00             	add    ax,0x1
     51a:	00 00                	add    BYTE PTR [bx+si],al
     51c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     520:	00 80 03 00          	add    BYTE PTR [bx+si+0x3],al
     524:	03 54 6f             	add    dx,WORD PTR [si+0x6f]
     527:	70 d4                	jo     0x4fd
     529:	22 48 05             	and    cl,BYTE PTR [bx+si+0x5]
     52c:	22 00                	and    al,BYTE PTR [bx+si]
     52e:	ff                   	(bad)
     52f:	ff                   	(bad)
     530:	bf 17 50             	mov    di,0x5017
     533:	05 01 00             	add    ax,0x1
     536:	00 00                	add    BYTE PTR [bx+si],al
     538:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     53c:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     540:	05 57 69             	add    ax,0x6957
     543:	64 74 68             	fs je  0x5ae
     546:	d4 22                	aam    0x22
     548:	86 05                	xchg   BYTE PTR [di],al
     54a:	24 00                	and    al,0x0
     54c:	ff                   	(bad)
     54d:	ff e1                	jmp    cx
     54f:	17                   	pop    ss
     550:	67 05 01 00          	addr32 add ax,0x1
     554:	00 00                	add    BYTE PTR [bx+si],al
     556:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     55a:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     55e:	06                   	push   es
     55f:	48                   	dec    ax
     560:	65 69 67 68 74 64    	imul   sp,WORD PTR gs:[bx+0x68],0x6474
     566:	00 6f 05             	add    BYTE PTR [bx+0x5],ch
     569:	3c 00                	cmp    al,0x0
     56b:	ff                   	(bad)
     56c:	ff 66 1f             	jmp    WORD PTR [bp+0x1f]
     56f:	8a 05                	mov    al,BYTE PTR [di]
     571:	01 00                	add    WORD PTR [bx+si],ax
     573:	00 00                	add    BYTE PTR [bx+si],al
     575:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     579:	00 00                	add    BYTE PTR [bx+si],al
     57b:	06                   	push   es
     57c:	00 06 43 75          	add    BYTE PTR ds:0x7543,al
     580:	72 73                	jb     0x5f5
     582:	6f                   	outs   dx,WORD PTR ds:[si]
     583:	72 62                	jb     0x5e7
     585:	23 bb 05 e5          	and    di,WORD PTR [bp+di-0x1afb]
     589:	1f                   	pop    ds
     58a:	8e 05                	mov    es,WORD PTR [di]
     58c:	02 20                	add    ah,BYTE PTR [bx+si]
     58e:	17                   	pop    ss
     58f:	06                   	push   es
     590:	01 00                	add    WORD PTR [bx+si],ax
     592:	00 00                	add    BYTE PTR [bx+si],al
     594:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     598:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     59c:	04 48                	add    al,0x48
     59e:	69 6e 74 d7 07       	imul   bp,WORD PTR [bp+0x74],0x7d7
     5a3:	00 00                	add    BYTE PTR [bx+si],al
     5a5:	00 00                	add    BYTE PTR [bx+si],al
     5a7:	49                   	dec    cx
     5a8:	06                   	push   es
     5a9:	3d 06 d8             	cmp    ax,0xd806
     5ac:	00 99 03 d1          	add    BYTE PTR [bx+di-0x2efd],bl
     5b0:	06                   	push   es
     5b1:	fa                   	cli
     5b2:	45                   	inc    bp
     5b3:	27                   	daa
     5b4:	06                   	push   es
     5b5:	9a 1f 37 08 cb       	call   0xcb08:0x371f
     5ba:	1f                   	pop    ds
     5bb:	b7 05                	mov    bh,0x5
     5bd:	fc                   	cld
     5be:	2e 07                	cs pop es
     5c0:	06                   	push   es
     5c1:	cd 11                	int    0x11
     5c3:	cb                   	retf
     5c4:	05 3a 27             	add    ax,0x273a
     5c7:	cf                   	iret
     5c8:	05 fa 10             	add    ax,0x10fa
     5cb:	fb                   	sti
     5cc:	07                   	pop    es
     5cd:	d6                   	(bad)
     5ce:	14 d7                	adc    al,0xd7
     5d0:	05 f4 4f             	add    ax,0x4ff4
     5d3:	e3 05                	jcxz   0x5da
     5d5:	32 16 ff 05          	xor    dl,BYTE PTR ds:0x5ff
     5d9:	ec                   	in     al,dx
     5da:	30 37                	xor    BYTE PTR [bx],dh
     5dc:	06                   	push   es
     5dd:	51                   	push   cx
     5de:	1b af 05 38          	sbb    bp,WORD PTR [bx+0x3805]
     5e2:	50                   	push   ax
     5e3:	eb 05                	jmp    0x5ea
     5e5:	63 31                	arpl   WORD PTR [bx+di],si
     5e7:	ef                   	out    dx,ax
     5e8:	05 21 50             	add    ax,0x5021
     5eb:	c3                   	ret
     5ec:	05 61 2e             	add    ax,0x2e61
     5ef:	bf 05 d9             	mov    di,0xd905
     5f2:	62 f7 05 06 63       	(bad)
     5f7:	fb                   	sti
     5f8:	05 8f 60             	add    ax,0x608f
     5fb:	33 06 3a 1c          	xor    ax,WORD PTR ds:0x1c3a
     5ff:	df 05                	fild   WORD PTR [di]
     601:	46                   	inc    si
     602:	44                   	inc    sp
     603:	e7 05                	out    0x5,ax
     605:	08 61 0b             	or     BYTE PTR [bx+di+0xb],ah
     608:	06                   	push   es
     609:	5c                   	pop    sp
     60a:	61                   	popa
     60b:	0f 06                	clts
     60d:	62 5c 3b             	bound  bx,DWORD PTR [si+0x3b]
     610:	06                   	push   es
     611:	3a 61 c7             	cmp    ah,BYTE PTR [bx+di-0x39]
     614:	05 72 3f             	add    ax,0x3f72
     617:	1b 06 29 3b          	sbb    ax,WORD PTR ds:0x3b29
     61b:	1f                   	pop    ds
     61c:	06                   	push   es
     61d:	17                   	pop    ss
     61e:	3e 23 06 88 3c       	and    ax,WORD PTR ds:0x3c88
     623:	b3 05                	mov    bl,0x5
     625:	ed                   	in     ax,dx
     626:	3e 2b 06 77 3e       	sub    ax,WORD PTR ds:0x3e77
     62b:	2f                   	das
     62c:	06                   	push   es
     62d:	c2 35 f3             	ret    0xf335
     630:	05 1c 48             	add    ax,0x481c
     633:	db 05                	fild   DWORD PTR [di]
     635:	ae                   	scas   al,BYTE PTR es:[di]
     636:	5f                   	pop    di
     637:	03 06 35 62          	add    ax,WORD PTR ds:0x6235
     63b:	13 06 0b 54          	adc    ax,WORD PTR ds:0x540b
     63f:	57                   	push   di
     640:	69 6e 43 6f 6e       	imul   bp,WORD PTR [bp+0x43],0x6e6f
     645:	74 72                	je     0x6b9
     647:	6f                   	outs   dx,WORD PTR ds:[si]
     648:	6c                   	ins    BYTE PTR es:[di],dx
     649:	42                   	inc    dx
     64a:	00 0f                	add    BYTE PTR [bx],cl
     64c:	00 11                	add    BYTE PTR [bx+di],dl
     64e:	01 15                	add    WORD PTR [di],dx
     650:	00 19                	add    BYTE PTR [bx+di],bl
     652:	00 14                	add    BYTE PTR [si],dl
     654:	01 15                	add    WORD PTR [di],dx
     656:	01 39                	add    WORD PTR [bx+di],di
     658:	00 2d                	add    BYTE PTR [di],ch
     65a:	00 2b                	add    BYTE PTR [bp+di],ch
     65c:	00 2c                	add    BYTE PTR [si],ch
     65e:	00 14                	add    BYTE PTR [si],dl
     660:	00 47 00             	add    BYTE PTR [bx+0x0],al
     663:	05 00 03             	add    ax,0x300
     666:	00 20                	add    BYTE PTR [bx+si],ah
     668:	00 00                	add    BYTE PTR [bx+si],al
     66a:	01 04                	add    WORD PTR [si],ax
     66c:	01 01                	add    WORD PTR [bx+di],ax
     66e:	01 05                	add    WORD PTR [di],ax
     670:	01 02                	add    WORD PTR [bp+si],ax
     672:	01 12                	add    WORD PTR [bp+si],dx
     674:	01 2f                	add    WORD PTR [bx],bp
     676:	00 10                	add    BYTE PTR [bx+si],dl
     678:	02 2e 00 02          	add    ch,BYTE PTR ds:0x200
     67c:	00 82 00 84          	add    BYTE PTR [bp+si-0x7c00],al
     680:	00 60 03             	add    BYTE PTR [bx+si+0x3],ah
     683:	0f 03 11             	lsl    dx,WORD PTR [bx+di]
     686:	03 1a                	add    bx,WORD PTR [bp+si]
     688:	00 1d                	add    BYTE PTR [di],bl
     68a:	00 1e 00 05          	add    BYTE PTR ds:0x500,bl
     68e:	0f 06                	clts
     690:	0f 07                	sysret
     692:	0f 0b                	ud2
     694:	0f 0c                	(bad)
     696:	0f 0d 0f             	prefetchw BYTE PTR [bx]
     699:	0e                   	push   cs
     69a:	0f                   	(bad)
     69b:	0f                   	(bad)
     69c:	0f 10 0f             	movups xmm1,XMMWORD PTR [bx]
     69f:	11 0f                	adc    WORD PTR [bx],cx
     6a1:	19 0f                	sbb    WORD PTR [bx],cx
     6a3:	22 0f                	and    cl,BYTE PTR [bx]
     6a5:	1a 0f                	sbb    cl,BYTE PTR [bx]
     6a7:	1b 0f                	sbb    cx,WORD PTR [bx]
     6a9:	1c 0f                	sbb    al,0xf
     6ab:	24 0f                	and    al,0xf
     6ad:	25 0f 26             	and    ax,0x260f
     6b0:	0f 27                	(bad)
     6b2:	0f 19 20             	nop    WORD PTR [bx+si]
     6b5:	00 21                	add    BYTE PTR [bx+di],ah
     6b7:	01 21                	add    WORD PTR [bx+di],sp
     6b9:	02 21                	add    ah,BYTE PTR [bx+di]
     6bb:	04 21                	add    al,0x21
     6bd:	06                   	push   es
     6be:	21 ff                	and    di,di
     6c0:	ff f3                	push   bx
     6c2:	ff f2                	push   dx
     6c4:	ff f1                	push   cx
     6c6:	ff f0                	push   ax
     6c8:	ff                   	jmp    (bad)
     6c9:	ef                   	out    dx,ax
     6ca:	ff f7                	push   di
     6cc:	ff f6                	push   si
     6ce:	ff 8c 4a d5          	dec    WORD PTR [si-0x2ab6]
     6d2:	06                   	push   es
     6d3:	c4 4a d9             	les    cx,DWORD PTR [bp+si-0x27]
     6d6:	06                   	push   es
     6d7:	ed                   	in     ax,dx
     6d8:	4a                   	dec    dx
     6d9:	dd 06 63 4b          	fld    QWORD PTR ds:0x4b63
     6dd:	e1 06                	loope  0x6e5
     6df:	8c 4b e5             	mov    WORD PTR [bp+di-0x1b],cs
     6e2:	06                   	push   es
     6e3:	b5 4b                	mov    ch,0x4b
     6e5:	e9 06 de             	jmp    0xe4ee
     6e8:	4b                   	dec    bx
     6e9:	ed                   	in     ax,dx
     6ea:	06                   	push   es
     6eb:	0e                   	push   cs
     6ec:	4c                   	dec    sp
     6ed:	f1                   	int1
     6ee:	06                   	push   es
     6ef:	3e 4c                	ds dec sp
     6f1:	f5                   	cmc
     6f2:	06                   	push   es
     6f3:	6e                   	outs   dx,BYTE PTR ds:[si]
     6f4:	4c                   	dec    sp
     6f5:	f9                   	stc
     6f6:	06                   	push   es
     6f7:	9e                   	sahf
     6f8:	4c                   	dec    sp
     6f9:	fd                   	std
     6fa:	06                   	push   es
     6fb:	e2 4c                	loop   0x749
     6fd:	01 07                	add    WORD PTR [bx],ax
     6ff:	a8 4d                	test   al,0x4d
     701:	05 07 d5             	add    ax,0xd507
     704:	4d                   	dec    bp
     705:	09 07                	or     WORD PTR [bx],ax
     707:	f8                   	clc
     708:	4d                   	dec    bp
     709:	0d 07 a6             	or     ax,0xa607
     70c:	50                   	push   ax
     70d:	11 07                	adc    WORD PTR [bx],ax
     70f:	d2 50 15             	rcl    BYTE PTR [bx+si+0x15],cl
     712:	07                   	pop    es
     713:	c7                   	(bad)
     714:	51                   	push   cx
     715:	19 07                	sbb    WORD PTR [bx],ax
     717:	f3 51                	repz push cx
     719:	1d 07 d3             	sbb    ax,0xd307
     71c:	52                   	push   dx
     71d:	21 07                	and    WORD PTR [bx],ax
     71f:	ff 52 25             	call   WORD PTR [bp+si+0x25]
     722:	07                   	pop    es
     723:	95                   	xchg   bp,ax
     724:	53                   	push   bx
     725:	29 07                	sub    WORD PTR [bx],ax
     727:	be 53 2d             	mov    si,0x2d53
     72a:	07                   	pop    es
     72b:	f9                   	stc
     72c:	53                   	push   bx
     72d:	31 07                	xor    WORD PTR [bx],ax
     72f:	22 54 35             	and    dl,BYTE PTR [si+0x35]
     732:	07                   	pop    es
     733:	63 54 39             	arpl   WORD PTR [si+0x39],dx
     736:	07                   	pop    es
     737:	8c 54 3d             	mov    WORD PTR [si+0x3d],ss
     73a:	07                   	pop    es
     73b:	55                   	push   bp
     73c:	58                   	pop    ax
     73d:	41                   	inc    cx
     73e:	07                   	pop    es
     73f:	4d                   	dec    bp
     740:	55                   	push   bp
     741:	45                   	inc    bp
     742:	07                   	pop    es
     743:	75 55                	jne    0x79a
     745:	49                   	dec    cx
     746:	07                   	pop    es
     747:	0c 4b                	or     al,0x4b
     749:	4d                   	dec    bp
     74a:	07                   	pop    es
     74b:	2f                   	das
     74c:	4b                   	dec    bx
     74d:	51                   	push   cx
     74e:	07                   	pop    es
     74f:	49                   	dec    cx
     750:	4b                   	dec    bx
     751:	55                   	push   bp
     752:	07                   	pop    es
     753:	10 56 59             	adc    BYTE PTR [bp+0x59],dl
     756:	07                   	pop    es
     757:	26 56                	es push si
     759:	5d                   	pop    bp
     75a:	07                   	pop    es
     75b:	3c 56                	cmp    al,0x56
     75d:	61                   	popa
     75e:	07                   	pop    es
     75f:	52                   	push   dx
     760:	56                   	push   si
     761:	65 07                	gs pop es
     763:	b3 56                	mov    bl,0x56
     765:	69 07 ff 56          	imul   ax,WORD PTR [bx],0x56ff
     769:	6d                   	ins    WORD PTR es:[di],dx
     76a:	07                   	pop    es
     76b:	3a 57 71             	cmp    dl,BYTE PTR [bx+0x71]
     76e:	07                   	pop    es
     76f:	8b 57 75             	mov    dx,WORD PTR [bx+0x75]
     772:	07                   	pop    es
     773:	d8 57 79             	fcom   DWORD PTR [bx+0x79]
     776:	07                   	pop    es
     777:	26 58                	es pop ax
     779:	7d 07                	jge    0x782
     77b:	87 56 81             	xchg   WORD PTR [bp-0x7f],dx
     77e:	07                   	pop    es
     77f:	98                   	cbw
     780:	55                   	push   bp
     781:	85 07                	test   WORD PTR [bx],ax
     783:	be 55 89             	mov    si,0x8955
     786:	07                   	pop    es
     787:	d2 55 8d             	rcl    BYTE PTR [di-0x73],cl
     78a:	07                   	pop    es
     78b:	e6 55                	out    0x55,al
     78d:	91                   	xchg   cx,ax
     78e:	07                   	pop    es
     78f:	72 58                	jb     0x7e9
     791:	95                   	xchg   bp,ax
     792:	07                   	pop    es
     793:	88 58 99             	mov    BYTE PTR [bx+si-0x67],bl
     796:	07                   	pop    es
     797:	9e                   	sahf
     798:	58                   	pop    ax
     799:	9d                   	popf
     79a:	07                   	pop    es
     79b:	b4 58                	mov    ah,0x58
     79d:	a1 07 ca             	mov    ax,ds:0xca07
     7a0:	58                   	pop    ax
     7a1:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     7a2:	07                   	pop    es
     7a3:	04 5a                	add    al,0x5a
     7a5:	a9 07 04             	test   ax,0x407
     7a8:	5b                   	pop    bx
     7a9:	ad                   	lods   ax,WORD PTR ds:[si]
     7aa:	07                   	pop    es
     7ab:	73 5b                	jae    0x808
     7ad:	b1 07                	mov    cl,0x7
     7af:	e7 5b                	out    0x5b,ax
     7b1:	b5 07                	mov    ch,0x7
     7b3:	10 5c b9             	adc    BYTE PTR [si-0x47],bl
     7b6:	07                   	pop    es
     7b7:	9e                   	sahf
     7b8:	5d                   	pop    bp
     7b9:	bd 07 1a             	mov    bp,0x1a07
     7bc:	4f                   	dec    di
     7bd:	c1 07 42             	rol    WORD PTR [bx],0x42
     7c0:	4f                   	dec    di
     7c1:	c5 07                	lds    ax,DWORD PTR [bx]
     7c3:	6a 4f                	push   0x4f
     7c5:	c9                   	leave
     7c6:	07                   	pop    es
     7c7:	fe                   	(bad)
     7c8:	50                   	push   ax
     7c9:	cd 07                	int    0x7
     7cb:	1f                   	pop    ds
     7cc:	52                   	push   dx
     7cd:	d1 07                	rol    WORD PTR [bx],1
     7cf:	d4 54                	aam    0x54
     7d1:	d5 07                	aad    0x7
     7d3:	d5 5f                	aad    0x5f
     7d5:	e6 07                	out    0x7,al
     7d7:	07                   	pop    es
     7d8:	0b 54 57             	or     dx,WORD PTR [si+0x57]
     7db:	69 6e 43 6f 6e       	imul   bp,WORD PTR [bp+0x43],0x6e6f
     7e0:	74 72                	je     0x854
     7e2:	6f                   	outs   dx,WORD PTR ds:[si]
     7e3:	6c                   	ins    BYTE PTR es:[di],dx
     7e4:	c1 05 ea             	rol    WORD PTR [di],0xea
     7e7:	07                   	pop    es
     7e8:	d0 04                	rol    BYTE PTR [si],1
     7ea:	93                   	xchg   bx,ax
     7eb:	08 09                	or     BYTE PTR [bx+di],cl
     7ed:	00 08                	add    BYTE PTR [bx+si],cl
     7ef:	43                   	inc    bx
     7f0:	6f                   	outs   dx,WORD PTR ds:[si]
     7f1:	6e                   	outs   dx,BYTE PTR ds:[si]
     7f2:	74 72                	je     0x866
     7f4:	6f                   	outs   dx,WORD PTR ds:[si]
     7f5:	6c                   	ins    BYTE PTR es:[di],dx
     7f6:	73 01                	jae    0x7f9
     7f8:	00 5a 00             	add    BYTE PTR [bp+si+0x0],bl
     7fb:	4f                   	dec    di
     7fc:	08 ac 00 ff          	or     BYTE PTR [si-0x100],ch
     800:	ff ac 00 ff          	jmp    DWORD PTR [si-0x100]
     804:	ff 01                	inc    WORD PTR [bx+di]
     806:	00 00                	add    BYTE PTR [bx+si],al
     808:	00 00                	add    BYTE PTR [bx+si],al
     80a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     80d:	00 00                	add    BYTE PTR [bx+si],al
     80f:	08 00                	or     BYTE PTR [bx+si],al
     811:	0b 48 65             	or     cx,WORD PTR [bx+si+0x65]
     814:	6c                   	ins    BYTE PTR es:[di],dx
     815:	70 43                	jo     0x85a
     817:	6f                   	outs   dx,WORD PTR ds:[si]
     818:	6e                   	outs   dx,BYTE PTR ds:[si]
     819:	74 65                	je     0x880
     81b:	78 74                	js     0x891
     81d:	ad                   	lods   ax,WORD PTR ds:[si]
     81e:	08 00                	or     BYTE PTR [bx+si],al
     820:	00 00                	add    BYTE PTR [bx+si],al
     822:	00 a5 08 95          	add    BYTE PTR [di-0x6af8],ah
     826:	08 8e 00 99          	or     BYTE PTR [bp-0x6700],cl
     82a:	03 ab 08 10          	add    bp,WORD PTR [bp+di+0x1008]
     82e:	26 43                	es inc bx
     830:	08 9a 1f ed          	or     BYTE PTR [bp+si-0x12e1],bl
     834:	08 cb                	or     bl,cl
     836:	1f                   	pop    ds
     837:	33 08                	xor    cx,WORD PTR [bx+si]
     839:	f0 68 2f 08          	lock push 0x82f
     83d:	cd 11                	int    0x11
     83f:	47                   	inc    di
     840:	08 3a                	or     BYTE PTR [bp+si],bh
     842:	27                   	daa
     843:	6f                   	outs   dx,WORD PTR ds:[si]
     844:	08 fa                	or     dl,bh
     846:	10 05                	adc    BYTE PTR [di],al
     848:	09 d6                	or     si,dx
     84a:	14 53                	adc    al,0x53
     84c:	08 f4                	or     ah,dh
     84e:	4f                   	dec    di
     84f:	5f                   	pop    di
     850:	08 32                	or     BYTE PTR [bp+si],dh
     852:	16                   	push   ss
     853:	57                   	push   di
     854:	08 98 15 7b          	or     BYTE PTR [bx+si+0x7b15],bl
     858:	08 51 1b             	or     BYTE PTR [bx+di+0x1b],dl
     85b:	7f 08                	jg     0x865
     85d:	38 50 63             	cmp    BYTE PTR [bx+si+0x63],dl
     860:	08 1a                	or     BYTE PTR [bp+si],bl
     862:	50                   	push   ax
     863:	67 08 21             	or     BYTE PTR [ecx],ah
     866:	50                   	push   ax
     867:	3f                   	aas
     868:	08 86 68 3b          	or     BYTE PTR [bp+0x3b68],al
     86c:	08 3f                	or     BYTE PTR [bx],bh
     86e:	19 73 08             	sbb    WORD PTR [bp+di+0x8],si
     871:	78 18                	js     0x88b
     873:	77 08                	ja     0x87d
     875:	02 21                	add    ah,BYTE PTR [bx+di]
     877:	4b                   	dec    bx
     878:	08 3a                	or     BYTE PTR [bp+si],bh
     87a:	1c 5b                	sbb    al,0x5b
     87c:	08 15                	or     BYTE PTR [di],dl
     87e:	25 83 08             	and    ax,0x883
     881:	37                   	aaa
     882:	22 87 08 df          	and    al,BYTE PTR [bx-0x20f8]
     886:	22 8b 08 f8          	and    cl,BYTE PTR [bp+di-0x7f8]
     88a:	16                   	push   ss
     88b:	8f 08 a5 22          	(bad)
     88f:	2b 08                	sub    cx,WORD PTR [bx+si]
     891:	80 69 6b 08          	sub    BYTE PTR [bx+di+0x6b],0x8
     895:	0f 54 47 72          	andps  xmm0,XMMWORD PTR [bx+0x72]
     899:	61                   	popa
     89a:	70 68                	jo     0x904
     89c:	69 63 43 6f 6e       	imul   sp,WORD PTR [bp+di+0x43],0x6e6f
     8a1:	74 72                	je     0x915
     8a3:	6f                   	outs   dx,WORD PTR ds:[si]
     8a4:	6c                   	ins    BYTE PTR es:[di],dx
     8a5:	01 00                	add    WORD PTR [bx+si],ax
     8a7:	0f 00 24             	verr   WORD PTR [si]
     8aa:	69 c0 08 07          	imul   ax,ax,0x708
     8ae:	0f 54 47 72          	andps  xmm0,XMMWORD PTR [bx+0x72]
     8b2:	61                   	popa
     8b3:	70 68                	jo     0x91d
     8b5:	69 63 43 6f 6e       	imul   sp,WORD PTR [bp+di+0x43],0x6e6f
     8ba:	74 72                	je     0x92e
     8bc:	6f                   	outs   dx,WORD PTR ds:[si]
     8bd:	6c                   	ins    BYTE PTR es:[di],dx
     8be:	3d 08 c4             	cmp    ax,0xc408
     8c1:	08 d0                	or     al,dl
     8c3:	04 71                	add    al,0x71
     8c5:	09 08                	or     WORD PTR [bx+si],cx
     8c7:	00 08                	add    BYTE PTR [bx+si],cl
     8c9:	43                   	inc    bx
     8ca:	6f                   	outs   dx,WORD PTR ds:[si]
     8cb:	6e                   	outs   dx,BYTE PTR ds:[si]
     8cc:	74 72                	je     0x940
     8ce:	6f                   	outs   dx,WORD PTR ds:[si]
     8cf:	6c                   	ins    BYTE PTR es:[di],dx
     8d0:	73 00                	jae    0x8d2
     8d2:	00 8a 09 00          	add    BYTE PTR [bp+si+0x9],cl
     8d6:	00 00                	add    BYTE PTR [bx+si],al
     8d8:	00 82 09 73          	add    BYTE PTR [bp+si+0x7309],al
     8dc:	09 dc                	or     sp,bx
     8de:	00 c1                	add    cl,al
     8e0:	05 88 09             	add    ax,0x988
     8e3:	fa                   	cli
     8e4:	45                   	inc    bp
     8e5:	59                   	pop    cx
     8e6:	09 9a 1f c9          	or     WORD PTR [bp+si-0x36e1],bx
     8ea:	09 cb                	or     bx,cx
     8ec:	1f                   	pop    ds
     8ed:	e9 08 dc             	jmp    0xe4f8
     8f0:	6c                   	ins    BYTE PTR es:[di],dx
     8f1:	49                   	dec    cx
     8f2:	09 cd                	or     bp,cx
     8f4:	11 fd                	adc    bp,di
     8f6:	08 3a                	or     BYTE PTR [bp+si],bh
     8f8:	27                   	daa
     8f9:	01 09                	add    WORD PTR [bx+di],cx
     8fb:	fa                   	cli
     8fc:	10 e1                	adc    cl,ah
     8fe:	09 d6                	or     si,dx
     900:	14 09                	adc    al,0x9
     902:	09 f4                	or     sp,si
     904:	4f                   	dec    di
     905:	15 09 32             	adc    ax,0x3209
     908:	16                   	push   ss
     909:	31 09                	xor    WORD PTR [bx+di],cx
     90b:	ec                   	in     al,dx
     90c:	30 69 09             	xor    BYTE PTR [bx+di+0x9],ch
     90f:	51                   	push   cx
     910:	1b e1                	sbb    sp,cx
     912:	08 38                	or     BYTE PTR [bx+si],bh
     914:	50                   	push   ax
     915:	1d 09 63             	sbb    ax,0x6309
     918:	31 39                	xor    WORD PTR [bx+di],di
     91a:	09 21                	or     WORD PTR [bx+di],sp
     91c:	50                   	push   ax
     91d:	f5                   	cmc
     91e:	08 72 6c             	or     BYTE PTR [bp+si+0x6c],dh
     921:	f1                   	int1
     922:	08 d9                	or     cl,bl
     924:	62 29                	bound  bp,DWORD PTR [bx+di]
     926:	09 06 63 2d          	or     WORD PTR ds:0x2d63,ax
     92a:	09 8f 60 0d          	or     WORD PTR [bx+0xd60],cx
     92e:	09 3a                	or     WORD PTR [bp+si],di
     930:	1c 11                	sbb    al,0x11
     932:	09 46 44             	or     WORD PTR [bp+0x44],ax
     935:	19 09                	sbb    WORD PTR [bx+di],cx
     937:	08 61 3d             	or     BYTE PTR [bx+di+0x3d],ah
     93a:	09 5c 61             	or     WORD PTR [si+0x61],bx
     93d:	41                   	inc    cx
     93e:	09 62 5c             	or     WORD PTR [bp+si+0x5c],sp
     941:	6d                   	ins    WORD PTR es:[di],dx
     942:	09 3a                	or     WORD PTR [bp+si],di
     944:	61                   	popa
     945:	f9                   	stc
     946:	08 72 3f             	or     BYTE PTR [bp+si+0x3f],dh
     949:	4d                   	dec    bp
     94a:	09 29                	or     WORD PTR [bx+di],bp
     94c:	3b 51 09             	cmp    dx,WORD PTR [bx+di+0x9]
     94f:	17                   	pop    ss
     950:	3e 55                	ds push bp
     952:	09 88 3c e5          	or     WORD PTR [bx+si-0x1ac4],cx
     956:	08 ed                	or     ch,ch
     958:	3e 5d                	ds pop bp
     95a:	09 77 3e             	or     WORD PTR [bx+0x3e],si
     95d:	61                   	popa
     95e:	09 c2                	or     dx,ax
     960:	35 25 09             	xor    ax,0x925
     963:	26 6d                	es ins WORD PTR es:[di],dx
     965:	21 09                	and    WORD PTR [bx+di],cx
     967:	ae                   	scas   al,BYTE PTR es:[di]
     968:	5f                   	pop    di
     969:	35 09 35             	xor    ax,0x3509
     96c:	62 45 09             	bound  ax,DWORD PTR [di+0x9]
     96f:	77 6d                	ja     0x9de
     971:	65 09 0e 54 43       	or     WORD PTR gs:0x4354,cx
     976:	75 73                	jne    0x9eb
     978:	74 6f                	je     0x9e9
     97a:	6d                   	ins    WORD PTR es:[di],dx
     97b:	43                   	inc    bx
     97c:	6f                   	outs   dx,WORD PTR ds:[si]
     97d:	6e                   	outs   dx,BYTE PTR ds:[si]
     97e:	74 72                	je     0x9f2
     980:	6f                   	outs   dx,WORD PTR ds:[si]
     981:	6c                   	ins    BYTE PTR es:[di],dx
     982:	01 00                	add    WORD PTR [bx+si],ax
     984:	0f 00 0a             	str    WORD PTR [bp+si]
     987:	6d                   	ins    WORD PTR es:[di],dx
     988:	9c                   	pushf
     989:	09 07                	or     WORD PTR [bx],ax
     98b:	0e                   	push   cs
     98c:	54                   	push   sp
     98d:	43                   	inc    bx
     98e:	75 73                	jne    0xa03
     990:	74 6f                	je     0xa01
     992:	6d                   	ins    WORD PTR es:[di],dx
     993:	43                   	inc    bx
     994:	6f                   	outs   dx,WORD PTR ds:[si]
     995:	6e                   	outs   dx,BYTE PTR ds:[si]
     996:	74 72                	je     0xa0a
     998:	6f                   	outs   dx,WORD PTR ds:[si]
     999:	6c                   	ins    BYTE PTR es:[di],dx
     99a:	f3 08 a0 09 d7       	repz or BYTE PTR [bx+si-0x28f7],ah
     99f:	07                   	pop    es
     9a0:	29 0a                	sub    WORD PTR [bp+si],cx
     9a2:	09 00                	or     WORD PTR [bx+si],ax
     9a4:	08 43 6f             	or     BYTE PTR [bp+di+0x6f],al
     9a7:	6e                   	outs   dx,BYTE PTR ds:[si]
     9a8:	74 72                	je     0xa1c
     9aa:	6f                   	outs   dx,WORD PTR ds:[si]
     9ab:	6c                   	ins    BYTE PTR es:[di],dx
     9ac:	73 00                	jae    0x9ae
     9ae:	00 6b 0a             	add    BYTE PTR [bp+di+0xa],ch
     9b1:	00 00                	add    BYTE PTR [bx+si],al
     9b3:	00 00                	add    BYTE PTR [bx+si],al
     9b5:	63 0a                	arpl   WORD PTR [bp+si],cx
     9b7:	57                   	push   di
     9b8:	0a dc                	or     bl,ah
     9ba:	00 f3                	add    bl,dh
     9bc:	08 69 0a             	or     BYTE PTR [bx+di+0xa],ch
     9bf:	fa                   	cli
     9c0:	45                   	inc    bp
     9c1:	35 0a 9a             	xor    ax,0x9a0a
     9c4:	1f                   	pop    ds
     9c5:	2a 0c                	sub    cl,BYTE PTR [si]
     9c7:	cb                   	retf
     9c8:	1f                   	pop    ds
     9c9:	c5 09                	lds    cx,DWORD PTR [bx+di]
     9cb:	dc 6c 25             	fsubr  QWORD PTR [si+0x25]
     9ce:	0a cd                	or     cl,ch
     9d0:	11 d9                	adc    cx,bx
     9d2:	09 3a                	or     WORD PTR [bp+si],di
     9d4:	27                   	daa
     9d5:	dd 09                	fisttp QWORD PTR [bx+di]
     9d7:	fa                   	cli
     9d8:	10 e0                	adc    al,ah
     9da:	11 d6                	adc    si,dx
     9dc:	14 e5                	adc    al,0xe5
     9de:	09 f4                	or     sp,si
     9e0:	4f                   	dec    di
     9e1:	f1                   	int1
     9e2:	09 32                	or     WORD PTR [bp+si],si
     9e4:	16                   	push   ss
     9e5:	0d 0a ec             	or     ax,0xec0a
     9e8:	30 45 0a             	xor    BYTE PTR [di+0xa],al
     9eb:	51                   	push   cx
     9ec:	1b bd 09 38          	sbb    di,WORD PTR [di+0x3809]
     9f0:	50                   	push   ax
     9f1:	f9                   	stc
     9f2:	09 63 31             	or     WORD PTR [bp+di+0x31],sp
     9f5:	15 0a 21             	adc    ax,0x210a
     9f8:	50                   	push   ax
     9f9:	d1 09                	ror    WORD PTR [bx+di],1
     9fb:	95                   	xchg   bp,ax
     9fc:	69 51 0a d9 62       	imul   dx,WORD PTR [bx+di+0xa],0x62d9
     a01:	05 0a 06             	add    ax,0x60a
     a04:	63 09                	arpl   WORD PTR [bx+di],cx
     a06:	0a 8f 60 e9          	or     cl,BYTE PTR [bx-0x16a0]
     a0a:	09 3a                	or     WORD PTR [bp+si],di
     a0c:	1c ed                	sbb    al,0xed
     a0e:	09 46 44             	or     WORD PTR [bp+0x44],ax
     a11:	f5                   	cmc
     a12:	09 08                	or     WORD PTR [bx+si],cx
     a14:	61                   	popa
     a15:	19 0a                	sbb    WORD PTR [bp+si],cx
     a17:	5c                   	pop    sp
     a18:	61                   	popa
     a19:	1d 0a 62             	sbb    ax,0x620a
     a1c:	5c                   	pop    sp
     a1d:	49                   	dec    cx
     a1e:	0a 3a                	or     bh,BYTE PTR [bp+si]
     a20:	61                   	popa
     a21:	d5 09                	aad    0x9
     a23:	72 3f                	jb     0xa64
     a25:	2d 0a 21             	sub    ax,0x210a
     a28:	6a 4d                	push   0x4d
     a2a:	0a 17                	or     dl,BYTE PTR [bx]
     a2c:	3e 31 0a             	xor    WORD PTR ds:[bp+si],cx
     a2f:	88 3c                	mov    BYTE PTR [si],bh
     a31:	c1 09 ed             	ror    WORD PTR [bx+di],0xed
     a34:	3e 39 0a             	cmp    WORD PTR ds:[bp+si],cx
     a37:	77 3e                	ja     0xa77
     a39:	3d 0a c2             	cmp    ax,0xc20a
     a3c:	35 01 0a             	xor    ax,0xa01
     a3f:	26 6d                	es ins WORD PTR es:[di],dx
     a41:	cd 09                	int    0x9
     a43:	ae                   	scas   al,BYTE PTR es:[di]
     a44:	5f                   	pop    di
     a45:	11 0a                	adc    WORD PTR [bp+si],cx
     a47:	35 62 21             	xor    ax,0x2162
     a4a:	0a 52 6a             	or     dl,BYTE PTR [bp+si+0x6a]
     a4d:	fd                   	std
     a4e:	09 a4 6b 55          	or     WORD PTR [si+0x556b],sp
     a52:	0a b7 6a 41          	or     dh,BYTE PTR [bx+0x416a]
     a56:	0a 0b                	or     cl,BYTE PTR [bp+di]
     a58:	54                   	push   sp
     a59:	48                   	dec    ax
     a5a:	69 6e 74 57 69       	imul   bp,WORD PTR [bp+0x74],0x6957
     a5f:	6e                   	outs   dx,BYTE PTR ds:[si]
     a60:	64 6f                	outs   dx,WORD PTR fs:[si]
     a62:	77 01                	ja     0xa65
     a64:	00 12                	add    BYTE PTR [bp+si],dl
     a66:	0f 30                	wrmsr
     a68:	6b 7a 0a 07          	imul   di,WORD PTR [bp+si+0xa],0x7
     a6c:	0b 54 48             	or     dx,WORD PTR [si+0x48]
     a6f:	69 6e 74 57 69       	imul   bp,WORD PTR [bp+0x74],0x6957
     a74:	6e                   	outs   dx,BYTE PTR ds:[si]
     a75:	64 6f                	outs   dx,WORD PTR fs:[si]
     a77:	77 cf                	ja     0xa48
     a79:	09 7e 0a             	or     WORD PTR [bp+0xa],di
     a7c:	8a 09                	mov    cl,BYTE PTR [bx+di]
     a7e:	6e                   	outs   dx,BYTE PTR ds:[si]
     a7f:	0d 09 00             	or     ax,0x9
     a82:	08 43 6f             	or     BYTE PTR [bp+di+0x6f],al
     a85:	6e                   	outs   dx,BYTE PTR ds:[si]
     a86:	74 72                	je     0xafa
     a88:	6f                   	outs   dx,WORD PTR ds:[si]
     a89:	6c                   	ins    BYTE PTR es:[di],dx
     a8a:	73 00                	jae    0xa8c
     a8c:	00 8c d0 90          	add    BYTE PTR [si-0x6f30],cl
     a90:	45                   	inc    bp
     a91:	55                   	push   bp
     a92:	89 e5                	mov    bp,sp
     a94:	1e                   	push   ds
     a95:	8e d8                	mov    ds,ax
     a97:	83 ec 04             	sub    sp,0x4
     a9a:	56                   	push   si
     a9b:	57                   	push   di
     a9c:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     a9f:	c4 3e e4 13          	les    di,DWORD PTR ds:0x13e4
     aa3:	26 89 85 a2 00       	mov    WORD PTR es:[di+0xa2],ax
     aa8:	ff 76 0e             	push   WORD PTR [bp+0xe]
     aab:	6a fc                	push   0xfffc
     aad:	c4 3e e4 13          	les    di,DWORD PTR ds:0x13e4
     ab1:	26 ff b5 8c 00       	push   WORD PTR es:[di+0x8c]
     ab6:	26 ff b5 8a 00       	push   WORD PTR es:[di+0x8a]
     abb:	9a f2 64 00 00       	call   0x0:0x64f2
     ac0:	ff 76 0e             	push   WORD PTR [bp+0xe]
     ac3:	6a f0                	push   0xfff0
     ac5:	9a b7 64 00 00       	call   0x0:0x64b7
     aca:	25 00 00             	and    ax,0x0
     acd:	81 e2 00 40          	and    dx,0x4000
     ad1:	09 d0                	or     ax,dx
     ad3:	74 1b                	je     0xaf0
     ad5:	ff 76 0e             	push   WORD PTR [bp+0xe]
     ad8:	6a f4                	push   0xfff4
     ada:	9a ff ff 00 00       	call   0x0:0xffff
     adf:	09 c0                	or     ax,ax
     ae1:	75 0d                	jne    0xaf0
     ae3:	ff 76 0e             	push   WORD PTR [bp+0xe]
     ae6:	6a f4                	push   0xfff4
     ae8:	ff 76 0e             	push   WORD PTR [bp+0xe]
     aeb:	9a ff ff 00 00       	call   0x0:0xffff
     af0:	ff 76 0e             	push   WORD PTR [bp+0xe]
     af3:	a1 0e 2c             	mov    ax,ds:0x2c0e
     af6:	31 d2                	xor    dx,dx
     af8:	52                   	push   dx
     af9:	50                   	push   ax
     afa:	ff 36 e4 13          	push   WORD PTR ds:0x13e4
     afe:	9a 12 0b 00 00       	call   0x0:0xb12
     b03:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b06:	a1 10 2c             	mov    ax,ds:0x2c10
     b09:	31 d2                	xor    dx,dx
     b0b:	52                   	push   dx
     b0c:	50                   	push   ax
     b0d:	ff 36 e6 13          	push   WORD PTR ds:0x13e6
     b11:	9a 9c 3f 00 00       	call   0x0:0x3f9c
     b16:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b19:	ff 76 0c             	push   WORD PTR [bp+0xc]
     b1c:	ff 76 0a             	push   WORD PTR [bp+0xa]
     b1f:	ff 76 08             	push   WORD PTR [bp+0x8]
     b22:	ff 76 06             	push   WORD PTR [bp+0x6]
     b25:	c4 3e e4 13          	les    di,DWORD PTR ds:0x13e4
     b29:	31 c0                	xor    ax,ax
     b2b:	a3 e4 13             	mov    ds:0x13e4,ax
     b2e:	a3 e6 13             	mov    ds:0x13e6,ax
     b31:	8c d8                	mov    ax,ds
     b33:	26 ff 9d 8a 00       	call   DWORD PTR es:[di+0x8a]
     b38:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     b3b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     b3e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     b41:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
     b44:	5f                   	pop    di
     b45:	5e                   	pop    si
     b46:	8d 66 fe             	lea    sp,[bp-0x2]
     b49:	1f                   	pop    ds
     b4a:	5d                   	pop    bp
     b4b:	4d                   	dec    bp
     b4c:	ca 0a 00             	retf   0xa
     b4f:	c8 04 00 00          	enter  0x4,0x0
     b53:	31 c0                	xor    ax,ax
     b55:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b58:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     b5b:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     b5f:	74 24                	je     0xb85
     b61:	ff 76 06             	push   WORD PTR [bp+0x6]
     b64:	a1 0e 2c             	mov    ax,ds:0x2c0e
     b67:	31 d2                	xor    dx,dx
     b69:	52                   	push   dx
     b6a:	50                   	push   ax
     b6b:	9a 7e 0b 00 00       	call   0x0:0xb7e
     b70:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b73:	ff 76 06             	push   WORD PTR [bp+0x6]
     b76:	a1 10 2c             	mov    ax,ds:0x2c10
     b79:	31 d2                	xor    dx,dx
     b7b:	52                   	push   dx
     b7c:	50                   	push   ax
     b7d:	9a ff ff 00 00       	call   0x0:0xffff
     b82:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     b85:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b88:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     b8b:	c9                   	leave
     b8c:	ca 02 00             	retf   0x2
     b8f:	c8 04 00 00          	enter  0x4,0x0
     b93:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     b97:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
     b9c:	74 21                	je     0xbbf
     b9e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     ba2:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     ba6:	ff 76 0a             	push   WORD PTR [bp+0xa]
     ba9:	ff 76 08             	push   WORD PTR [bp+0x8]
     bac:	ff 76 06             	push   WORD PTR [bp+0x6]
     baf:	ff 76 04             	push   WORD PTR [bp+0x4]
     bb2:	9a ff ff 00 00       	call   0x0:0xffff
     bb7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     bba:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     bbd:	eb 08                	jmp    0xbc7
     bbf:	31 c0                	xor    ax,ax
     bc1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     bc4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     bc7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     bca:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     bcd:	c9                   	leave
     bce:	c2 08 00             	ret    0x8
     bd1:	c8 04 01 00          	enter  0x104,0x0
     bd5:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     bd9:	31 c0                	xor    ax,ax
     bdb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     bde:	eb 03                	jmp    0xbe3
     be0:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     be3:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     be6:	d1 e7                	shl    di,1
     be8:	8b f7                	mov    si,di
     bea:	d1 e7                	shl    di,1
     bec:	01 f7                	add    di,si
     bee:	8b 85 ee 13          	mov    ax,WORD PTR [di+0x13ee]
     bf2:	99                   	cwd
     bf3:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
     bf6:	75 36                	jne    0xc2e
     bf8:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
     bfb:	75 31                	jne    0xc2e
     bfd:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     c01:	8d be fc fe          	lea    di,[bp-0x104]
     c05:	16                   	push   ss
     c06:	57                   	push   di
     c07:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     c0a:	d1 e7                	shl    di,1
     c0c:	8b f7                	mov    si,di
     c0e:	d1 e7                	shl    di,1
     c10:	01 f7                	add    di,si
     c12:	ff b5 f2 13          	push   WORD PTR [di+0x13f2]
     c16:	ff b5 f0 13          	push   WORD PTR [di+0x13f0]
     c1a:	9a 6e 0e 52 0c       	call   0xc52:0xe6e
     c1f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     c22:	06                   	push   es
     c23:	57                   	push   di
     c24:	ff 76 06             	push   WORD PTR [bp+0x6]
     c27:	9a e7 17 bf 0c       	call   0xcbf:0x17e7
     c2c:	eb 06                	jmp    0xc34
     c2e:	83 7e fc 10          	cmp    WORD PTR [bp-0x4],0x10
     c32:	75 ac                	jne    0xbe0
     c34:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     c37:	c9                   	leave
     c38:	ca 0a 00             	retf   0xa
     c3b:	c8 44 00 00          	enter  0x44,0x0
     c3f:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     c43:	8d 7e bc             	lea    di,[bp-0x44]
     c46:	16                   	push   ss
     c47:	57                   	push   di
     c48:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c4b:	06                   	push   es
     c4c:	57                   	push   di
     c4d:	6a 3f                	push   0x3f
     c4f:	9a 6a 0d 79 0c       	call   0xc79:0xd6a
     c54:	31 c0                	xor    ax,ax
     c56:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c59:	eb 03                	jmp    0xc5e
     c5b:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     c5e:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     c61:	d1 e7                	shl    di,1
     c63:	8b f7                	mov    si,di
     c65:	d1 e7                	shl    di,1
     c67:	01 f7                	add    di,si
     c69:	ff b5 f2 13          	push   WORD PTR [di+0x13f2]
     c6d:	ff b5 f0 13          	push   WORD PTR [di+0x13f0]
     c71:	8d 7e bc             	lea    di,[bp-0x44]
     c74:	16                   	push   ss
     c75:	57                   	push   di
     c76:	9a db 0d 88 14       	call   0x1488:0xddb
     c7b:	09 c0                	or     ax,ax
     c7d:	75 20                	jne    0xc9f
     c7f:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     c83:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     c86:	d1 e7                	shl    di,1
     c88:	8b f7                	mov    si,di
     c8a:	d1 e7                	shl    di,1
     c8c:	01 f7                	add    di,si
     c8e:	8b 85 ee 13          	mov    ax,WORD PTR [di+0x13ee]
     c92:	99                   	cwd
     c93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c96:	26 89 05             	mov    WORD PTR es:[di],ax
     c99:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     c9d:	eb 06                	jmp    0xca5
     c9f:	83 7e fc 10          	cmp    WORD PTR [bp-0x4],0x10
     ca3:	75 b6                	jne    0xc5b
     ca5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     ca8:	c9                   	leave
     ca9:	ca 08 00             	retf   0x8
     cac:	01 7c c8             	add    WORD PTR [si-0x38],di
     caf:	02 01                	add    al,BYTE PTR [bx+di]
     cb1:	00 bf ac 0c          	add    BYTE PTR [bx+0xcac],bh
     cb5:	0e                   	push   cs
     cb6:	57                   	push   di
     cb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cba:	06                   	push   es
     cbb:	57                   	push   di
     cbc:	9a 78 18 da 0c       	call   0xcda:0x1878
     cc1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     cc4:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     cc8:	75 14                	jne    0xcde
     cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ccd:	06                   	push   es
     cce:	57                   	push   di
     ccf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     cd2:	06                   	push   es
     cd3:	57                   	push   di
     cd4:	68 ff 00             	push   0xff
     cd7:	9a e7 17 f3 0c       	call   0xcf3:0x17e7
     cdc:	eb 24                	jmp    0xd02
     cde:	8d be fe fe          	lea    di,[bp-0x102]
     ce2:	16                   	push   ss
     ce3:	57                   	push   di
     ce4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce7:	06                   	push   es
     ce8:	57                   	push   di
     ce9:	6a 01                	push   0x1
     ceb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     cee:	48                   	dec    ax
     cef:	50                   	push   ax
     cf0:	9a 0b 18 00 0d       	call   0xd00:0x180b
     cf5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     cf8:	06                   	push   es
     cf9:	57                   	push   di
     cfa:	68 ff 00             	push   0xff
     cfd:	9a e7 17 19 0d       	call   0xd19:0x17e7
     d02:	c9                   	leave
     d03:	ca 04 00             	retf   0x4
     d06:	01 7c c8             	add    WORD PTR [si-0x38],di
     d09:	02 01                	add    al,BYTE PTR [bx+di]
     d0b:	00 bf 06 0d          	add    BYTE PTR [bx+0xd06],bh
     d0f:	0e                   	push   cs
     d10:	57                   	push   di
     d11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d14:	06                   	push   es
     d15:	57                   	push   di
     d16:	9a 78 18 34 0d       	call   0xd34:0x1878
     d1b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     d1e:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     d22:	75 14                	jne    0xd38
     d24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d27:	06                   	push   es
     d28:	57                   	push   di
     d29:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d2c:	06                   	push   es
     d2d:	57                   	push   di
     d2e:	68 ff 00             	push   0xff
     d31:	9a e7 17 4e 0d       	call   0xd4e:0x17e7
     d36:	eb 25                	jmp    0xd5d
     d38:	8d be fe fe          	lea    di,[bp-0x102]
     d3c:	16                   	push   ss
     d3d:	57                   	push   di
     d3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d41:	06                   	push   es
     d42:	57                   	push   di
     d43:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d46:	40                   	inc    ax
     d47:	50                   	push   ax
     d48:	68 ff 00             	push   0xff
     d4b:	9a 0b 18 5b 0d       	call   0xd5b:0x180b
     d50:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d53:	06                   	push   es
     d54:	57                   	push   di
     d55:	68 ff 00             	push   0xff
     d58:	9a e7 17 db 0d       	call   0xddb:0x17e7
     d5d:	c9                   	leave
     d5e:	ca 04 00             	retf   0x4
     d61:	c8 04 00 00          	enter  0x4,0x0
     d65:	9a 97 43 00 00       	call   0x0:0x4397
     d6a:	50                   	push   ax
     d6b:	9a 4f 0b d4 0d       	call   0xdd4:0xb4f
     d70:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d73:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     d76:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     d79:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
     d7c:	74 2c                	je     0xdaa
     d7e:	a1 f4 14             	mov    ax,ds:0x14f4
     d81:	0b 06 f6 14          	or     ax,WORD PTR ds:0x14f6
     d85:	74 23                	je     0xdaa
     d87:	c4 3e f4 14          	les    di,DWORD PTR ds:0x14f4
     d8b:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     d8f:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
     d93:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
     d96:	75 12                	jne    0xdaa
     d98:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     d9b:	75 0d                	jne    0xdaa
     d9d:	a1 f4 14             	mov    ax,ds:0x14f4
     da0:	8b 16 f6 14          	mov    dx,WORD PTR ds:0x14f6
     da4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     da7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     daa:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     dad:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     db0:	c9                   	leave
     db1:	cb                   	retf
     db2:	55                   	push   bp
     db3:	89 e5                	mov    bp,sp
     db5:	9a ff ff 00 00       	call   0x0:0xffff
     dba:	31 c0                	xor    ax,ax
     dbc:	a3 f4 14             	mov    ds:0x14f4,ax
     dbf:	a3 f6 14             	mov    ds:0x14f6,ax
     dc2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     dc5:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
     dc8:	74 54                	je     0xe1e
     dca:	ff 76 08             	push   WORD PTR [bp+0x8]
     dcd:	ff 76 06             	push   WORD PTR [bp+0x6]
     dd0:	bf c1 05             	mov    di,0x5c1
     dd3:	b8 16 0e             	mov    ax,0xe16
     dd6:	50                   	push   ax
     dd7:	57                   	push   di
     dd8:	9a 55 22 00 11       	call   0x1100:0x2255
     ddd:	08 c0                	or     al,al
     ddf:	75 2d                	jne    0xe0e
     de1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de4:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     de8:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
     dec:	75 02                	jne    0xdf0
     dee:	eb 2e                	jmp    0xe1e
     df0:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     df3:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     df6:	a3 f4 14             	mov    ds:0x14f4,ax
     df9:	89 16 f6 14          	mov    WORD PTR ds:0x14f6,dx
     dfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e00:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     e04:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
     e08:	89 46 06             	mov    WORD PTR [bp+0x6],ax
     e0b:	89 56 08             	mov    WORD PTR [bp+0x8],dx
     e0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e11:	06                   	push   es
     e12:	57                   	push   di
     e13:	9a b9 62 54 0e       	call   0xe54:0x62b9
     e18:	50                   	push   ax
     e19:	9a ff ff 00 00       	call   0x0:0xffff
     e1e:	c9                   	leave
     e1f:	ca 04 00             	retf   0x4
     e22:	c8 06 00 00          	enter  0x6,0x0
     e26:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     e2a:	a1 16 2c             	mov    ax,ds:0x2c16
     e2d:	0b 06 18 2c          	or     ax,WORD PTR ds:0x2c18
     e31:	74 58                	je     0xe8b
     e33:	c4 3e 16 2c          	les    di,DWORD PTR ds:0x2c16
     e37:	26 8b 45 6c          	mov    ax,WORD PTR es:[di+0x6c]
     e3b:	09 c0                	or     ax,ax
     e3d:	74 4c                	je     0xe8b
     e3f:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     e43:	ff 36 20 2c          	push   WORD PTR ds:0x2c20
     e47:	ff 36 1e 2c          	push   WORD PTR ds:0x2c1e
     e4b:	c4 3e 16 2c          	les    di,DWORD PTR ds:0x2c16
     e4f:	06                   	push   es
     e50:	57                   	push   di
     e51:	9a 06 1a c8 0e       	call   0xec8:0x1a06
     e56:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     e59:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     e5c:	ff 36 18 2c          	push   WORD PTR ds:0x2c18
     e60:	ff 36 16 2c          	push   WORD PTR ds:0x2c16
     e64:	ff 36 14 2c          	push   WORD PTR ds:0x2c14
     e68:	ff 36 12 2c          	push   WORD PTR ds:0x2c12
     e6c:	ff 76 fa             	push   WORD PTR [bp-0x6]
     e6f:	ff 76 fc             	push   WORD PTR [bp-0x4]
     e72:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     e75:	50                   	push   ax
     e76:	8d 7e ff             	lea    di,[bp-0x1]
     e79:	16                   	push   ss
     e7a:	57                   	push   di
     e7b:	c4 3e 16 2c          	les    di,DWORD PTR ds:0x2c16
     e7f:	26 ff 75 70          	push   WORD PTR es:[di+0x70]
     e83:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
     e87:	26 ff 5d 6a          	call   DWORD PTR es:[di+0x6a]
     e8b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     e8e:	c9                   	leave
     e8f:	c2 02 00             	ret    0x2
     e92:	c8 0e 00 00          	enter  0xe,0x0
     e96:	31 c0                	xor    ax,ax
     e98:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e9b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     e9e:	ff 76 0a             	push   WORD PTR [bp+0xa]
     ea1:	ff 76 08             	push   WORD PTR [bp+0x8]
     ea4:	9a ff ff 00 00       	call   0x0:0xffff
     ea9:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     eac:	31 c0                	xor    ax,ax
     eae:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     eb1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     eb4:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
     eb8:	74 2b                	je     0xee5
     eba:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ebd:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
     ec0:	75 23                	jne    0xee5
     ec2:	ff 76 f2             	push   WORD PTR [bp-0xe]
     ec5:	9a 4f 0b 07 0f       	call   0xf07:0xb4f
     eca:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     ecd:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     ed0:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ed3:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
     ed6:	75 0b                	jne    0xee3
     ed8:	ff 76 f2             	push   WORD PTR [bp-0xe]
     edb:	9a ff ff 00 00       	call   0x0:0xffff
     ee0:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     ee3:	eb cf                	jmp    0xeb4
     ee5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ee8:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
     eeb:	74 46                	je     0xf33
     eed:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ef0:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     ef3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ef6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ef9:	ff 76 0a             	push   WORD PTR [bp+0xa]
     efc:	ff 76 08             	push   WORD PTR [bp+0x8]
     eff:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     f02:	06                   	push   es
     f03:	57                   	push   di
     f04:	9a 06 1a 17 0f       	call   0xf17:0x1a06
     f09:	52                   	push   dx
     f0a:	50                   	push   ax
     f0b:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     f0e:	50                   	push   ax
     f0f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     f12:	06                   	push   es
     f13:	57                   	push   di
     f14:	9a a8 42 7b 0f       	call   0xf7b:0x42a8
     f19:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     f1c:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     f1f:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     f22:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
     f25:	74 0c                	je     0xf33
     f27:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     f2a:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     f2d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f30:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f33:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f36:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     f39:	c9                   	leave
     f3a:	ca 06 00             	retf   0x6
     f3d:	c8 06 00 00          	enter  0x6,0x0
     f41:	80 3e 24 2c 00       	cmp    BYTE PTR ds:0x2c24,0x0
     f46:	75 23                	jne    0xf6b
     f48:	a1 1a 2c             	mov    ax,ds:0x2c1a
     f4b:	2b 46 04             	sub    ax,WORD PTR [bp+0x4]
     f4e:	99                   	cwd
     f4f:	31 d0                	xor    ax,dx
     f51:	29 d0                	sub    ax,dx
     f53:	3d 05 00             	cmp    ax,0x5
     f56:	7d 13                	jge    0xf6b
     f58:	a1 1c 2c             	mov    ax,ds:0x2c1c
     f5b:	2b 46 06             	sub    ax,WORD PTR [bp+0x6]
     f5e:	99                   	cwd
     f5f:	31 d0                	xor    ax,dx
     f61:	29 d0                	sub    ax,dx
     f63:	3d 05 00             	cmp    ax,0x5
     f66:	7d 03                	jge    0xf6b
     f68:	e9 88 00             	jmp    0xff3
     f6b:	c6 06 24 2c 01       	mov    BYTE PTR ds:0x2c24,0x1
     f70:	ff 76 06             	push   WORD PTR [bp+0x6]
     f73:	ff 76 04             	push   WORD PTR [bp+0x4]
     f76:	6a 00                	push   0x0
     f78:	9a 92 0e 32 10       	call   0x1032:0xe92
     f7d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     f80:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     f83:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     f86:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
     f89:	3b 16 18 2c          	cmp    dx,WORD PTR ds:0x2c18
     f8d:	75 06                	jne    0xf95
     f8f:	3b 06 16 2c          	cmp    ax,WORD PTR ds:0x2c16
     f93:	74 24                	je     0xfb9
     f95:	6a 01                	push   0x1
     f97:	e8 88 fe             	call   0xe22
     f9a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     f9d:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
     fa0:	a3 16 2c             	mov    ds:0x2c16,ax
     fa3:	89 16 18 2c          	mov    WORD PTR ds:0x2c18,dx
     fa7:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     faa:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
     fad:	a3 1e 2c             	mov    ds:0x2c1e,ax
     fb0:	89 16 20 2c          	mov    WORD PTR ds:0x2c20,dx
     fb4:	6a 00                	push   0x0
     fb6:	e8 69 fe             	call   0xe22
     fb9:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     fbc:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
     fbf:	a3 1e 2c             	mov    ds:0x2c1e,ax
     fc2:	89 16 20 2c          	mov    WORD PTR ds:0x2c20,dx
     fc6:	c7 46 fe f3 ff       	mov    WORD PTR [bp-0x2],0xfff3
     fcb:	6a 02                	push   0x2
     fcd:	e8 52 fe             	call   0xe22
     fd0:	08 c0                	or     al,al
     fd2:	74 0b                	je     0xfdf
     fd4:	c4 3e 12 2c          	les    di,DWORD PTR ds:0x2c12
     fd8:	26 8b 45 3e          	mov    ax,WORD PTR es:[di+0x3e]
     fdc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     fdf:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fe2:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     fe6:	06                   	push   es
     fe7:	57                   	push   di
     fe8:	9a 3e 63 6a 14       	call   0x146a:0x633e
     fed:	50                   	push   ax
     fee:	9a 66 10 00 00       	call   0x0:0x1066
     ff3:	c9                   	leave
     ff4:	c2 04 00             	ret    0x4
     ff7:	55                   	push   bp
     ff8:	89 e5                	mov    bp,sp
     ffa:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ffd:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1000:	a3 12 2c             	mov    ds:0x2c12,ax
    1003:	89 16 14 2c          	mov    WORD PTR ds:0x2c14,dx
    1007:	31 c0                	xor    ax,ax
    1009:	a3 16 2c             	mov    ds:0x2c16,ax
    100c:	a3 18 2c             	mov    ds:0x2c18,ax
    100f:	bf 1a 2c             	mov    di,0x2c1a
    1012:	1e                   	push   ds
    1013:	57                   	push   di
    1014:	9a 1f 24 00 00       	call   0x0:0x241f
    1019:	9a ff ff 00 00       	call   0x0:0xffff
    101e:	a3 22 2c             	mov    ds:0x2c22,ax
    1021:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    1024:	a2 24 2c             	mov    ds:0x2c24,al
    1027:	6a 01                	push   0x1
    1029:	c4 3e 12 2c          	les    di,DWORD PTR ds:0x2c12
    102d:	06                   	push   es
    102e:	57                   	push   di
    102f:	9a b3 1f 4e 10       	call   0x104e:0x1fb3
    1034:	80 3e 24 2c 00       	cmp    BYTE PTR ds:0x2c24,0x0
    1039:	74 0b                	je     0x1046
    103b:	ff 36 1c 2c          	push   WORD PTR ds:0x2c1c
    103f:	ff 36 1a 2c          	push   WORD PTR ds:0x2c1a
    1043:	e8 f7 fe             	call   0xf3d
    1046:	c9                   	leave
    1047:	c2 06 00             	ret    0x6
    104a:	00 00                	add    BYTE PTR [bx+si],al
    104c:	20 11                	and    BYTE PTR [bx+di],dl
    104e:	5f                   	pop    di
    104f:	10 c8                	adc    al,cl
    1051:	08 00                	or     BYTE PTR [bx+si],al
    1053:	00 6a 00             	add    BYTE PTR [bp+si+0x0],ch
    1056:	c4 3e 12 2c          	les    di,DWORD PTR ds:0x2c12
    105a:	06                   	push   es
    105b:	57                   	push   di
    105c:	9a b3 1f ac 10       	call   0x10ac:0x1fb3
    1061:	ff 36 22 2c          	push   WORD PTR ds:0x2c22
    1065:	9a ad 4e 00 00       	call   0x0:0x4ead
    106a:	a1 12 2c             	mov    ax,ds:0x2c12
    106d:	8b 16 14 2c          	mov    dx,WORD PTR ds:0x2c14
    1071:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1074:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1077:	b8 4a 10             	mov    ax,0x104a
    107a:	0e                   	push   cs
    107b:	50                   	push   ax
    107c:	55                   	push   bp
    107d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1081:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1085:	80 3e 24 2c 00       	cmp    BYTE PTR ds:0x2c24,0x0
    108a:	74 62                	je     0x10ee
    108c:	6a 01                	push   0x1
    108e:	e8 91 fd             	call   0xe22
    1091:	08 c0                	or     al,al
    1093:	74 59                	je     0x10ee
    1095:	80 7e 04 00          	cmp    BYTE PTR [bp+0x4],0x0
    1099:	74 53                	je     0x10ee
    109b:	ff 36 20 2c          	push   WORD PTR ds:0x2c20
    109f:	ff 36 1e 2c          	push   WORD PTR ds:0x2c1e
    10a3:	c4 3e 16 2c          	les    di,DWORD PTR ds:0x2c16
    10a7:	06                   	push   es
    10a8:	57                   	push   di
    10a9:	9a 06 1a 63 11       	call   0x1163:0x1a06
    10ae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    10b1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    10b4:	31 c0                	xor    ax,ax
    10b6:	a3 12 2c             	mov    ds:0x2c12,ax
    10b9:	a3 14 2c             	mov    ds:0x2c14,ax
    10bc:	c4 3e 16 2c          	les    di,DWORD PTR ds:0x2c16
    10c0:	26 8b 45 64          	mov    ax,WORD PTR es:[di+0x64]
    10c4:	09 c0                	or     ax,ax
    10c6:	74 24                	je     0x10ec
    10c8:	ff 36 18 2c          	push   WORD PTR ds:0x2c18
    10cc:	ff 36 16 2c          	push   WORD PTR ds:0x2c16
    10d0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    10d3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    10d6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    10d9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10dc:	c4 3e 16 2c          	les    di,DWORD PTR ds:0x2c16
    10e0:	26 ff 75 68          	push   WORD PTR es:[di+0x68]
    10e4:	26 ff 75 66          	push   WORD PTR es:[di+0x66]
    10e8:	26 ff 5d 62          	call   DWORD PTR es:[di+0x62]
    10ec:	eb 26                	jmp    0x1114
    10ee:	80 3e 24 2c 00       	cmp    BYTE PTR ds:0x2c24,0x0
    10f3:	75 0d                	jne    0x1102
    10f5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    10f8:	06                   	push   es
    10f9:	57                   	push   di
    10fa:	b8 fc ff             	mov    ax,0xfffc
    10fd:	9a 6a 20 bf 11       	call   0x11bf:0x206a
    1102:	31 c0                	xor    ax,ax
    1104:	a3 16 2c             	mov    ds:0x2c16,ax
    1107:	a3 18 2c             	mov    ds:0x2c18,ax
    110a:	31 c0                	xor    ax,ax
    110c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    110f:	31 c0                	xor    ax,ax
    1111:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1114:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1118:	83 c4 06             	add    sp,0x6
    111b:	b8 29 11             	mov    ax,0x1129
    111e:	0e                   	push   cs
    111f:	50                   	push   ax
    1120:	31 c0                	xor    ax,ax
    1122:	a3 12 2c             	mov    ds:0x2c12,ax
    1125:	a3 14 2c             	mov    ds:0x2c14,ax
    1128:	cb                   	retf
    1129:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    112c:	26 8b 45 74          	mov    ax,WORD PTR es:[di+0x74]
    1130:	09 c0                	or     ax,ax
    1132:	74 23                	je     0x1157
    1134:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1137:	ff 76 f8             	push   WORD PTR [bp-0x8]
    113a:	ff 36 18 2c          	push   WORD PTR ds:0x2c18
    113e:	ff 36 16 2c          	push   WORD PTR ds:0x2c16
    1142:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1145:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1148:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    114b:	26 ff 75 78          	push   WORD PTR es:[di+0x78]
    114f:	26 ff 75 76          	push   WORD PTR es:[di+0x76]
    1153:	26 ff 5d 72          	call   DWORD PTR es:[di+0x72]
    1157:	c9                   	leave
    1158:	c2 02 00             	ret    0x2
    115b:	01 00                	add    WORD PTR [bx+si],ax
    115d:	00 00                	add    BYTE PTR [bx+si],al
    115f:	00 00                	add    BYTE PTR [bx+si],al
    1161:	ae                   	scas   al,BYTE PTR es:[di]
    1162:	11 92 11 55          	adc    WORD PTR [bp+si+0x5511],dx
    1166:	89 e5                	mov    bp,sp
    1168:	b8 5b 11             	mov    ax,0x115b
    116b:	0e                   	push   cs
    116c:	50                   	push   ax
    116d:	55                   	push   bp
    116e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1172:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1179:	26 8b 05             	mov    ax,WORD PTR es:[di]
    117c:	3d 00 02             	cmp    ax,0x200
    117f:	75 1a                	jne    0x119b
    1181:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1185:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1189:	c4 3e 12 2c          	les    di,DWORD PTR ds:0x2c12
    118d:	06                   	push   es
    118e:	57                   	push   di
    118f:	9a d4 19 63 12       	call   0x1263:0x19d4
    1194:	52                   	push   dx
    1195:	50                   	push   ax
    1196:	e8 a4 fd             	call   0xf3d
    1199:	eb 0a                	jmp    0x11a5
    119b:	3d 02 02             	cmp    ax,0x202
    119e:	75 05                	jne    0x11a5
    11a0:	6a 01                	push   0x1
    11a2:	e8 ab fe             	call   0x1050
    11a5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    11a9:	83 c4 06             	add    sp,0x6
    11ac:	eb 18                	jmp    0x11c6
    11ae:	a1 12 2c             	mov    ax,ds:0x2c12
    11b1:	0b 06 14 2c          	or     ax,WORD PTR ds:0x2c14
    11b5:	74 05                	je     0x11bc
    11b7:	6a 00                	push   0x0
    11b9:	e8 94 fe             	call   0x1050
    11bc:	ea 85 13 c4 11       	jmp    0x11c4:0x1385
    11c1:	9a 34 14 e7 11       	call   0x11e7:0x1434
    11c6:	c9                   	leave
    11c7:	ca 04 00             	retf   0x4
    11ca:	55                   	push   bp
    11cb:	89 e5                	mov    bp,sp
    11cd:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    11d0:	26 8b 05             	mov    ax,WORD PTR es:[di]
    11d3:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    11d7:	75 1a                	jne    0x11f3
    11d9:	b0 01                	mov    al,0x1
    11db:	50                   	push   ax
    11dc:	b8 a3 02             	mov    ax,0x2a3
    11df:	ba 04 12             	mov    dx,0x1204
    11e2:	52                   	push   dx
    11e3:	50                   	push   ax
    11e4:	9a 50 1f 38 12       	call   0x1238:0x1f50
    11e9:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    11ec:	26 89 05             	mov    WORD PTR es:[di],ax
    11ef:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    11f3:	ff 76 06             	push   WORD PTR [bp+0x6]
    11f6:	ff 76 04             	push   WORD PTR [bp+0x4]
    11f9:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    11fc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    11ff:	06                   	push   es
    1200:	57                   	push   di
    1201:	9a 2b 0c 1e 12       	call   0x121e:0xc2b
    1206:	c9                   	leave
    1207:	c2 08 00             	ret    0x8
    120a:	55                   	push   bp
    120b:	89 e5                	mov    bp,sp
    120d:	ff 76 06             	push   WORD PTR [bp+0x6]
    1210:	ff 76 04             	push   WORD PTR [bp+0x4]
    1213:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1216:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1219:	06                   	push   es
    121a:	57                   	push   di
    121b:	9a a7 0f 58 12       	call   0x1258:0xfa7
    1220:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1223:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1226:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    122b:	75 19                	jne    0x1246
    122d:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1230:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1233:	06                   	push   es
    1234:	57                   	push   di
    1235:	9a 7f 1f 9f 12       	call   0x129f:0x1f7f
    123a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    123d:	31 c0                	xor    ax,ax
    123f:	26 89 05             	mov    WORD PTR es:[di],ax
    1242:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1246:	c9                   	leave
    1247:	c2 08 00             	ret    0x8
    124a:	55                   	push   bp
    124b:	89 e5                	mov    bp,sp
    124d:	6a 00                	push   0x0
    124f:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    1253:	06                   	push   es
    1254:	57                   	push   di
    1255:	9a d0 0d 0c 13       	call   0x130c:0xdd0
    125a:	89 c7                	mov    di,ax
    125c:	8e c2                	mov    es,dx
    125e:	06                   	push   es
    125f:	57                   	push   di
    1260:	9a 20 13 87 12       	call   0x1287:0x1320
    1265:	c9                   	leave
    1266:	c3                   	ret
    1267:	55                   	push   bp
    1268:	89 e5                	mov    bp,sp
    126a:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    126e:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1273:	7e 05                	jle    0x127a
    1275:	e8 d2 ff             	call   0x124a
    1278:	eb f0                	jmp    0x126a
    127a:	c9                   	leave
    127b:	c3                   	ret
    127c:	55                   	push   bp
    127d:	89 e5                	mov    bp,sp
    127f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1282:	06                   	push   es
    1283:	57                   	push   di
    1284:	9a 20 13 84 13       	call   0x1384:0x1320
    1289:	31 c0                	xor    ax,ax
    128b:	50                   	push   ax
    128c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    128f:	06                   	push   es
    1290:	57                   	push   di
    1291:	9a b7 18 ba 12       	call   0x12ba:0x18b7
    1296:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    129a:	74 05                	je     0x12a1
    129c:	9a 0f 20 aa 13       	call   0x13aa:0x200f
    12a1:	c9                   	leave
    12a2:	ca 06 00             	retf   0x6
    12a5:	55                   	push   bp
    12a6:	89 e5                	mov    bp,sp
    12a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12ab:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    12af:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    12b3:	75 09                	jne    0x12be
    12b5:	06                   	push   es
    12b6:	57                   	push   di
    12b7:	9a 56 22 1a 13       	call   0x131a:0x2256
    12bc:	eb 5e                	jmp    0x131c
    12be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c1:	26 83 7d 2f 00       	cmp    WORD PTR es:[di+0x2f],0x0
    12c6:	75 46                	jne    0x130e
    12c8:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    12cc:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    12d0:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    12d4:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
    12d8:	75 03                	jne    0x12dd
    12da:	e8 6d ff             	call   0x124a
    12dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e0:	81 c7 31 00          	add    di,0x31
    12e4:	06                   	push   es
    12e5:	57                   	push   di
    12e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e9:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    12ed:	06                   	push   es
    12ee:	57                   	push   di
    12ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    12f2:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    12f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12f9:	26 89 45 2f          	mov    WORD PTR es:[di+0x2f],ax
    12fd:	ff 76 08             	push   WORD PTR [bp+0x8]
    1300:	ff 76 06             	push   WORD PTR [bp+0x6]
    1303:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    1307:	06                   	push   es
    1308:	57                   	push   di
    1309:	9a 2b 0c 45 13       	call   0x1345:0xc2b
    130e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1311:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
    1315:	06                   	push   es
    1316:	57                   	push   di
    1317:	9a 5d 22 34 13       	call   0x1334:0x225d
    131c:	c9                   	leave
    131d:	ca 04 00             	retf   0x4
    1320:	55                   	push   bp
    1321:	89 e5                	mov    bp,sp
    1323:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1326:	26 83 7d 2f 00       	cmp    WORD PTR es:[di+0x2f],0x0
    132b:	74 33                	je     0x1360
    132d:	6a 00                	push   0x0
    132f:	06                   	push   es
    1330:	57                   	push   di
    1331:	9a 5d 22 cf 13       	call   0x13cf:0x225d
    1336:	ff 76 08             	push   WORD PTR [bp+0x8]
    1339:	ff 76 06             	push   WORD PTR [bp+0x6]
    133c:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    1340:	06                   	push   es
    1341:	57                   	push   di
    1342:	9a a7 0f bd 13       	call   0x13bd:0xfa7
    1347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    134a:	26 ff 75 31          	push   WORD PTR es:[di+0x31]
    134e:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
    1352:	9a 64 15 00 00       	call   0x0:0x1564
    1357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    135a:	31 c0                	xor    ax,ax
    135c:	26 89 45 2f          	mov    WORD PTR es:[di+0x2f],ax
    1360:	c9                   	leave
    1361:	ca 04 00             	retf   0x4
    1364:	55                   	push   bp
    1365:	89 e5                	mov    bp,sp
    1367:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    136a:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    136e:	26 8b 55 2d          	mov    dx,WORD PTR es:[di+0x2d]
    1372:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    1375:	75 05                	jne    0x137c
    1377:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    137a:	74 1b                	je     0x1397
    137c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    137f:	06                   	push   es
    1380:	57                   	push   di
    1381:	9a 20 13 e9 13       	call   0x13e9:0x1320
    1386:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1389:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    138c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    138f:	26 89 45 2b          	mov    WORD PTR es:[di+0x2b],ax
    1393:	26 89 55 2d          	mov    WORD PTR es:[di+0x2d],dx
    1397:	c9                   	leave
    1398:	ca 08 00             	retf   0x8
    139b:	55                   	push   bp
    139c:	89 e5                	mov    bp,sp
    139e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    13a2:	74 08                	je     0x13ac
    13a4:	83 ec 08             	sub    sp,0x8
    13a7:	9a e2 1f 78 14       	call   0x1478:0x1fe2
    13ac:	ff 76 0e             	push   WORD PTR [bp+0xe]
    13af:	ff 76 0c             	push   WORD PTR [bp+0xc]
    13b2:	31 c0                	xor    ax,ax
    13b4:	50                   	push   ax
    13b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13b8:	06                   	push   es
    13b9:	57                   	push   di
    13ba:	9a d9 4b b5 14       	call   0x14b5:0x4bd9
    13bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13c2:	26 c7 45 26 aa 00    	mov    WORD PTR es:[di+0x26],0xaa
    13c8:	b0 01                	mov    al,0x1
    13ca:	50                   	push   ax
    13cb:	b8 10 03             	mov    ax,0x310
    13ce:	ba d6 13             	mov    dx,0x13d6
    13d1:	52                   	push   dx
    13d2:	50                   	push   ax
    13d3:	9a 96 0e 30 1b       	call   0x1b30:0xe96
    13d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13db:	26 89 45 34          	mov    WORD PTR es:[di+0x34],ax
    13df:	26 89 55 36          	mov    WORD PTR es:[di+0x36],dx
    13e3:	06                   	push   es
    13e4:	57                   	push   di
    13e5:	b8 cc 1d             	mov    ax,0x1dcc
    13e8:	ba 92 15             	mov    dx,0x1592
    13eb:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    13ef:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    13f3:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    13f7:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    13fb:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    13ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1402:	26 c7 45 38 fa ff    	mov    WORD PTR es:[di+0x38],0xfffa
    1408:	26 c7 45 3a ff ff    	mov    WORD PTR es:[di+0x3a],0xffff
    140e:	26 c6 45 29 01       	mov    BYTE PTR es:[di+0x29],0x1
    1413:	26 c6 45 2a 01       	mov    BYTE PTR es:[di+0x2a],0x1
    1418:	26 c6 45 2b 01       	mov    BYTE PTR es:[di+0x2b],0x1
    141d:	26 c6 45 2c 01       	mov    BYTE PTR es:[di+0x2c],0x1
    1422:	26 c6 45 49 01       	mov    BYTE PTR es:[di+0x49],0x1
    1427:	26 c6 45 2f 00       	mov    BYTE PTR es:[di+0x2f],0x0
    142c:	26 c7 45 3e f4 ff    	mov    WORD PTR es:[di+0x3e],0xfff4
    1432:	a1 16 17             	mov    ax,ds:0x1716
    1435:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    1439:	26 89 45 44          	mov    WORD PTR es:[di+0x44],ax
    143d:	26 89 55 46          	mov    WORD PTR es:[di+0x46],dx
    1441:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1445:	74 07                	je     0x144e
    1447:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    144b:	83 c4 06             	add    sp,0x6
    144e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1451:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1454:	c9                   	leave
    1455:	ca 0a 00             	retf   0xa
    1458:	55                   	push   bp
    1459:	89 e5                	mov    bp,sp
    145b:	ff 76 08             	push   WORD PTR [bp+0x8]
    145e:	ff 76 06             	push   WORD PTR [bp+0x6]
    1461:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1465:	06                   	push   es
    1466:	57                   	push   di
    1467:	9a 5a 67 45 1a       	call   0x1a45:0x675a
    146c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    146f:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1473:	06                   	push   es
    1474:	57                   	push   di
    1475:	9a 7f 1f c0 14       	call   0x14c0:0x1f7f
    147a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    147d:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    1481:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    1485:	9a 23 0f 98 14       	call   0x1498:0xf23
    148a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    148d:	26 ff 75 46          	push   WORD PTR es:[di+0x46]
    1491:	26 ff 75 44          	push   WORD PTR es:[di+0x44]
    1495:	9a 24 06 8a 19       	call   0x198a:0x624
    149a:	6a 00                	push   0x0
    149c:	6a 00                	push   0x0
    149e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14a1:	06                   	push   es
    14a2:	57                   	push   di
    14a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14a6:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    14aa:	31 c0                	xor    ax,ax
    14ac:	50                   	push   ax
    14ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14b0:	06                   	push   es
    14b1:	57                   	push   di
    14b2:	9a 2b 4c e4 15       	call   0x15e4:0x4c2b
    14b7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    14bb:	74 05                	je     0x14c2
    14bd:	9a 0f 20 f8 14       	call   0x14f8:0x200f
    14c2:	c9                   	leave
    14c3:	ca 06 00             	retf   0x6
    14c6:	c8 02 00 00          	enter  0x2,0x0
    14ca:	31 c0                	xor    ax,ax
    14cc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    14cf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    14d2:	c9                   	leave
    14d3:	ca 04 00             	retf   0x4
    14d6:	c8 02 00 00          	enter  0x2,0x0
    14da:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    14de:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    14e1:	c9                   	leave
    14e2:	ca 04 00             	retf   0x4
    14e5:	c8 0a 00 00          	enter  0xa,0x0
    14e9:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    14ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f0:	06                   	push   es
    14f1:	57                   	push   di
    14f2:	b8 fb ff             	mov    ax,0xfffb
    14f5:	9a 6a 20 b9 15       	call   0x15b9:0x206a
    14fa:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    14fd:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    1501:	74 69                	je     0x156c
    1503:	8d 7e f8             	lea    di,[bp-0x8]
    1506:	16                   	push   ss
    1507:	57                   	push   di
    1508:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    150b:	06                   	push   es
    150c:	57                   	push   di
    150d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1510:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    1514:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1517:	ff 76 f6             	push   WORD PTR [bp-0xa]
    151a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    151d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1521:	b0 00                	mov    al,0x0
    1523:	75 01                	jne    0x1526
    1525:	40                   	inc    ax
    1526:	98                   	cbw
    1527:	50                   	push   ax
    1528:	9a 51 15 00 00       	call   0x0:0x1551
    152d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1530:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1533:	9a 59 15 00 00       	call   0x0:0x1559
    1538:	09 c0                	or     ax,ax
    153a:	74 0c                	je     0x1548
    153c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    153f:	06                   	push   es
    1540:	57                   	push   di
    1541:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1544:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1548:	ff 76 f6             	push   WORD PTR [bp-0xa]
    154b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    154e:	6a 01                	push   0x1
    1550:	9a ff ff 00 00       	call   0x0:0xffff
    1555:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1558:	9a ff ff 00 00       	call   0x0:0xffff
    155d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1560:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1563:	9a a3 23 00 00       	call   0x0:0x23a3
    1568:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    156c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    156f:	c9                   	leave
    1570:	ca 06 00             	retf   0x6
    1573:	55                   	push   bp
    1574:	89 e5                	mov    bp,sp
    1576:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1579:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    157d:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    1581:	74 11                	je     0x1594
    1583:	ff 76 08             	push   WORD PTR [bp+0x8]
    1586:	ff 76 06             	push   WORD PTR [bp+0x6]
    1589:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    158d:	06                   	push   es
    158e:	57                   	push   di
    158f:	9a 33 36 b2 15       	call   0x15b2:0x3633
    1594:	c9                   	leave
    1595:	ca 04 00             	retf   0x4
    1598:	55                   	push   bp
    1599:	89 e5                	mov    bp,sp
    159b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    159e:	26 80 4d 28 08       	or     BYTE PTR es:[di+0x28],0x8
    15a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15a6:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    15aa:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    15ae:	bf c1 05             	mov    di,0x5c1
    15b1:	b8 06 16             	mov    ax,0x1606
    15b4:	50                   	push   ax
    15b5:	57                   	push   di
    15b6:	9a 55 22 a1 19       	call   0x19a1:0x2255
    15bb:	08 c0                	or     al,al
    15bd:	74 17                	je     0x15d6
    15bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15c2:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    15c6:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    15ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15cd:	06                   	push   es
    15ce:	57                   	push   di
    15cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15d2:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    15d6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15d9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15df:	06                   	push   es
    15e0:	57                   	push   di
    15e1:	9a 03 50 47 16       	call   0x1647:0x5003
    15e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15e9:	26 80 65 28 f7       	and    BYTE PTR es:[di+0x28],0xf7
    15ee:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    15f2:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    15f6:	74 36                	je     0x162e
    15f8:	68 09 0f             	push   0xf09
    15fb:	6a 00                	push   0x0
    15fd:	6a 00                	push   0x0
    15ff:	6a 00                	push   0x0
    1601:	06                   	push   es
    1602:	57                   	push   di
    1603:	9a bb 24 19 16       	call   0x1619:0x24bb
    1608:	68 08 0f             	push   0xf08
    160b:	6a 00                	push   0x0
    160d:	6a 00                	push   0x0
    160f:	6a 00                	push   0x0
    1611:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1614:	06                   	push   es
    1615:	57                   	push   di
    1616:	9a bb 24 2c 16       	call   0x162c:0x24bb
    161b:	68 23 0f             	push   0xf23
    161e:	6a 00                	push   0x0
    1620:	6a 00                	push   0x0
    1622:	6a 00                	push   0x0
    1624:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1627:	06                   	push   es
    1628:	57                   	push   di
    1629:	9a bb 24 f2 16       	call   0x16f2:0x24bb
    162e:	c9                   	leave
    162f:	ca 08 00             	retf   0x8
    1632:	55                   	push   bp
    1633:	89 e5                	mov    bp,sp
    1635:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1638:	ff 76 0c             	push   WORD PTR [bp+0xc]
    163b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    163e:	50                   	push   ax
    163f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1642:	06                   	push   es
    1643:	57                   	push   di
    1644:	9a 05 4f e2 18       	call   0x18e2:0x4f05
    1649:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    164c:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    164f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1652:	26 3b 55 42          	cmp    dx,WORD PTR es:[di+0x42]
    1656:	75 16                	jne    0x166e
    1658:	26 3b 45 40          	cmp    ax,WORD PTR es:[di+0x40]
    165c:	75 10                	jne    0x166e
    165e:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    1662:	75 0a                	jne    0x166e
    1664:	31 c0                	xor    ax,ax
    1666:	26 89 45 40          	mov    WORD PTR es:[di+0x40],ax
    166a:	26 89 45 42          	mov    WORD PTR es:[di+0x42],ax
    166e:	c9                   	leave
    166f:	ca 0a 00             	retf   0xa
    1672:	c8 02 00 00          	enter  0x2,0x0
    1676:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1679:	26 8a 45 2d          	mov    al,BYTE PTR es:[di+0x2d]
    167d:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1680:	74 68                	je     0x16ea
    1682:	26 8a 45 2d          	mov    al,BYTE PTR es:[di+0x2d]
    1686:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1689:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    168c:	26 88 45 2d          	mov    BYTE PTR es:[di+0x2d],al
    1690:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1693:	3c 03                	cmp    al,0x3
    1695:	72 04                	jb     0x169b
    1697:	3c 04                	cmp    al,0x4
    1699:	76 04                	jbe    0x169f
    169b:	b0 00                	mov    al,0x0
    169d:	eb 02                	jmp    0x16a1
    169f:	b0 01                	mov    al,0x1
    16a1:	8a d0                	mov    dl,al
    16a3:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    16a6:	3c 01                	cmp    al,0x1
    16a8:	72 04                	jb     0x16ae
    16aa:	3c 02                	cmp    al,0x2
    16ac:	76 04                	jbe    0x16b2
    16ae:	b0 00                	mov    al,0x0
    16b0:	eb 02                	jmp    0x16b4
    16b2:	b0 01                	mov    al,0x1
    16b4:	3a c2                	cmp    al,dl
    16b6:	75 32                	jne    0x16ea
    16b8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    16bb:	3c 00                	cmp    al,0x0
    16bd:	74 2b                	je     0x16ea
    16bf:	3c 05                	cmp    al,0x5
    16c1:	74 27                	je     0x16ea
    16c3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    16c6:	3c 00                	cmp    al,0x0
    16c8:	74 20                	je     0x16ea
    16ca:	3c 05                	cmp    al,0x5
    16cc:	74 1c                	je     0x16ea
    16ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16d1:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    16d5:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    16d9:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    16dd:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    16e1:	06                   	push   es
    16e2:	57                   	push   di
    16e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16e6:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    16ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ed:	06                   	push   es
    16ee:	57                   	push   di
    16ef:	9a 73 15 31 17       	call   0x1731:0x1573
    16f4:	c9                   	leave
    16f5:	ca 06 00             	retf   0x6
    16f8:	55                   	push   bp
    16f9:	89 e5                	mov    bp,sp
    16fb:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    16fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1701:	26 3b 45 1e          	cmp    ax,WORD PTR es:[di+0x1e]
    1705:	75 1b                	jne    0x1722
    1707:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    170a:	26 3b 45 20          	cmp    ax,WORD PTR es:[di+0x20]
    170e:	75 12                	jne    0x1722
    1710:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1713:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    1717:	75 09                	jne    0x1722
    1719:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    171c:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    1720:	74 55                	je     0x1777
    1722:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1725:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    1729:	50                   	push   ax
    172a:	6a 00                	push   0x0
    172c:	06                   	push   es
    172d:	57                   	push   di
    172e:	9a b3 21 6b 17       	call   0x176b:0x21b3
    1733:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    1736:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1739:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    173d:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1740:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    1744:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1747:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    174b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    174e:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    1752:	06                   	push   es
    1753:	57                   	push   di
    1754:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1757:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    175b:	6a 47                	push   0x47
    175d:	6a 00                	push   0x0
    175f:	6a 00                	push   0x0
    1761:	6a 00                	push   0x0
    1763:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1766:	06                   	push   es
    1767:	57                   	push   di
    1768:	9a bb 24 75 17       	call   0x1775:0x24bb
    176d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1770:	06                   	push   es
    1771:	57                   	push   di
    1772:	9a 73 15 dc 18       	call   0x18dc:0x1573
    1777:	c9                   	leave
    1778:	ca 0c 00             	retf   0xc
    177b:	55                   	push   bp
    177c:	89 e5                	mov    bp,sp
    177e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1781:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1784:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1788:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    178c:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1790:	06                   	push   es
    1791:	57                   	push   di
    1792:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1795:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    1799:	c9                   	leave
    179a:	ca 06 00             	retf   0x6
    179d:	55                   	push   bp
    179e:	89 e5                	mov    bp,sp
    17a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17a3:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    17a7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    17aa:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    17ae:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    17b2:	06                   	push   es
    17b3:	57                   	push   di
    17b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17b7:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    17bb:	c9                   	leave
    17bc:	ca 06 00             	retf   0x6
    17bf:	55                   	push   bp
    17c0:	89 e5                	mov    bp,sp
    17c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17c5:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    17c9:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    17cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    17d0:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    17d4:	06                   	push   es
    17d5:	57                   	push   di
    17d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17d9:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    17dd:	c9                   	leave
    17de:	ca 06 00             	retf   0x6
    17e1:	55                   	push   bp
    17e2:	89 e5                	mov    bp,sp
    17e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e7:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    17eb:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    17ef:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    17f3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    17f6:	06                   	push   es
    17f7:	57                   	push   di
    17f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17fb:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    17ff:	c9                   	leave
    1800:	ca 06 00             	retf   0x6
    1803:	55                   	push   bp
    1804:	89 e5                	mov    bp,sp
    1806:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1809:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    180d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1810:	26 89 05             	mov    WORD PTR es:[di],ax
    1813:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1816:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    181a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    181d:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1821:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1824:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    1828:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    182c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    182f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1833:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1836:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    183a:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    183e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1841:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    1845:	c9                   	leave
    1846:	ca 04 00             	retf   0x4
    1849:	c8 04 00 00          	enter  0x4,0x0
    184d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1850:	26 ff 35             	push   WORD PTR es:[di]
    1853:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1857:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    185b:	26 2b 05             	sub    ax,WORD PTR es:[di]
    185e:	50                   	push   ax
    185f:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1863:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1867:	50                   	push   ax
    1868:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    186b:	06                   	push   es
    186c:	57                   	push   di
    186d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1870:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    1874:	c9                   	leave
    1875:	ca 08 00             	retf   0x8
    1878:	55                   	push   bp
    1879:	89 e5                	mov    bp,sp
    187b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    187e:	31 c0                	xor    ax,ax
    1880:	26 89 05             	mov    WORD PTR es:[di],ax
    1883:	31 c0                	xor    ax,ax
    1885:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    188c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1890:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1893:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1897:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    189a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    189e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18a1:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    18a5:	c9                   	leave
    18a6:	ca 04 00             	retf   0x4
    18a9:	c8 0a 00 00          	enter  0xa,0x0
    18ad:	8d 7e f6             	lea    di,[bp-0xa]
    18b0:	16                   	push   ss
    18b1:	57                   	push   di
    18b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18b5:	06                   	push   es
    18b6:	57                   	push   di
    18b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18ba:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    18be:	83 c4 04             	add    sp,0x4
    18c1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    18c4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    18c7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    18ca:	c9                   	leave
    18cb:	ca 04 00             	retf   0x4
    18ce:	55                   	push   bp
    18cf:	89 e5                	mov    bp,sp
    18d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    18d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d7:	06                   	push   es
    18d8:	57                   	push   di
    18d9:	9a f4 18 ee 18       	call   0x18ee:0x18f4
    18de:	50                   	push   ax
    18df:	9a 6e 06 2d 19       	call   0x192d:0x66e
    18e4:	52                   	push   dx
    18e5:	50                   	push   ax
    18e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e9:	06                   	push   es
    18ea:	57                   	push   di
    18eb:	9a eb 1b 24 19       	call   0x1924:0x1beb
    18f0:	c9                   	leave
    18f1:	ca 06 00             	retf   0x6
    18f4:	c8 0a 00 00          	enter  0xa,0x0
    18f8:	8d 7e f6             	lea    di,[bp-0xa]
    18fb:	16                   	push   ss
    18fc:	57                   	push   di
    18fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1900:	06                   	push   es
    1901:	57                   	push   di
    1902:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1905:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1909:	83 c4 04             	add    sp,0x4
    190c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    190f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1912:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1915:	c9                   	leave
    1916:	ca 04 00             	retf   0x4
    1919:	55                   	push   bp
    191a:	89 e5                	mov    bp,sp
    191c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    191f:	06                   	push   es
    1920:	57                   	push   di
    1921:	9a a9 18 39 19       	call   0x1939:0x18a9
    1926:	50                   	push   ax
    1927:	ff 76 0a             	push   WORD PTR [bp+0xa]
    192a:	9a 6e 06 67 19       	call   0x1967:0x66e
    192f:	52                   	push   dx
    1930:	50                   	push   ax
    1931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1934:	06                   	push   es
    1935:	57                   	push   di
    1936:	9a eb 1b 93 19       	call   0x1993:0x1beb
    193b:	c9                   	leave
    193c:	ca 06 00             	retf   0x6
    193f:	c8 0c 02 00          	enter  0x20c,0x0
    1943:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1946:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    194a:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    194e:	75 53                	jne    0x19a3
    1950:	8d be f4 fd          	lea    di,[bp-0x20c]
    1954:	16                   	push   ss
    1955:	57                   	push   di
    1956:	68 2a f0             	push   0xf02a
    1959:	8d be fc fe          	lea    di,[bp-0x104]
    195d:	16                   	push   ss
    195e:	57                   	push   di
    195f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1962:	06                   	push   es
    1963:	57                   	push   di
    1964:	9a 2a 51 6d 1b       	call   0x1b6d:0x512a
    1969:	83 c4 04             	add    sp,0x4
    196c:	8d 86 fc fe          	lea    ax,[bp-0x104]
    1970:	8c d2                	mov    dx,ss
    1972:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    1976:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    197a:	c6 86 f8 fe 04       	mov    BYTE PTR [bp-0x108],0x4
    197f:	8d be f4 fe          	lea    di,[bp-0x10c]
    1983:	16                   	push   ss
    1984:	57                   	push   di
    1985:	6a 00                	push   0x0
    1987:	9a 50 09 9a 19       	call   0x199a:0x950
    198c:	b0 01                	mov    al,0x1
    198e:	50                   	push   ax
    198f:	b8 52 00             	mov    ax,0x52
    1992:	ba 7d 1b             	mov    dx,0x1b7d
    1995:	52                   	push   dx
    1996:	50                   	push   ax
    1997:	9a e6 28 ba 1d       	call   0x1dba:0x28e6
    199c:	52                   	push   dx
    199d:	50                   	push   ax
    199e:	9a 99 13 82 1b       	call   0x1b82:0x1399
    19a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a6:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    19aa:	06                   	push   es
    19ab:	57                   	push   di
    19ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19af:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    19b3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19b6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    19b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19bc:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    19c0:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    19c3:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    19c7:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    19ca:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19cd:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    19d0:	c9                   	leave
    19d1:	ca 04 00             	retf   0x4
    19d4:	c8 08 00 00          	enter  0x8,0x0
    19d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19db:	06                   	push   es
    19dc:	57                   	push   di
    19dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19e0:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    19e4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    19e7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    19ea:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    19ed:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    19f0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19f3:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    19f6:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    19f9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    19fc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19ff:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1a02:	c9                   	leave
    1a03:	ca 08 00             	retf   0x8
    1a06:	c8 08 00 00          	enter  0x8,0x0
    1a0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a0d:	06                   	push   es
    1a0e:	57                   	push   di
    1a0f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a12:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1a16:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1a19:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1a1c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1a1f:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    1a22:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a25:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1a28:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1a2b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a2e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a31:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1a34:	c9                   	leave
    1a35:	ca 08 00             	retf   0x8
    1a38:	c8 04 00 00          	enter  0x4,0x0
    1a3c:	ff 76 08             	push   WORD PTR [bp+0x8]
    1a3f:	ff 76 06             	push   WORD PTR [bp+0x6]
    1a42:	9a a8 17 63 1a       	call   0x1a63:0x17a8
    1a47:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a4a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1a4d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a50:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    1a53:	74 10                	je     0x1a65
    1a55:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a58:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a5b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1a5e:	06                   	push   es
    1a5f:	57                   	push   di
    1a60:	9a 79 44 dd 20       	call   0x20dd:0x4479
    1a65:	c9                   	leave
    1a66:	ca 08 00             	retf   0x8
    1a69:	c8 08 00 00          	enter  0x8,0x0
    1a6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a70:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1a74:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a77:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a7a:	9a 90 1a 00 00       	call   0x0:0x1a90
    1a7f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a85:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1a89:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a8c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a8f:	9a c4 1a 00 00       	call   0x0:0x1ac4
    1a94:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a9a:	26 f6 45 27 01       	test   BYTE PTR es:[di+0x27],0x1
    1a9f:	74 10                	je     0x1ab1
    1aa1:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    1aa6:	75 09                	jne    0x1ab1
    1aa8:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1aac:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1aaf:	eb 1d                	jmp    0x1ace
    1ab1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ab4:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    1ab8:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    1abc:	50                   	push   ax
    1abd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ac0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ac3:	9a fb 1a 00 00       	call   0x0:0x1afb
    1ac8:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    1acb:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1ace:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad1:	26 f6 45 27 02       	test   BYTE PTR es:[di+0x27],0x2
    1ad6:	74 10                	je     0x1ae8
    1ad8:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    1add:	75 09                	jne    0x1ae8
    1adf:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1ae3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1ae6:	eb 1d                	jmp    0x1b05
    1ae8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aeb:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1aef:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    1af3:	50                   	push   ax
    1af4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1af7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1afa:	9a 3a 1b 00 00       	call   0x0:0x1b3a
    1aff:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1b02:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1b05:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b08:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b0b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1b0e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1b11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b14:	06                   	push   es
    1b15:	57                   	push   di
    1b16:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b19:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    1b1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b20:	26 80 7d 2b 00       	cmp    BYTE PTR es:[di+0x2b],0x0
    1b25:	75 26                	jne    0x1b4d
    1b27:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1b2b:	06                   	push   es
    1b2c:	57                   	push   di
    1b2d:	9a cc 11 4b 1b       	call   0x1b4b:0x11cc
    1b32:	50                   	push   ax
    1b33:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b36:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1b39:	9a ff ff 00 00       	call   0x0:0xffff
    1b3e:	50                   	push   ax
    1b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b42:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1b46:	06                   	push   es
    1b47:	57                   	push   di
    1b48:	9a f5 11 ab 2e       	call   0x2eab:0x11f5
    1b4d:	c9                   	leave
    1b4e:	ca 08 00             	retf   0x8
    1b51:	c8 02 02 00          	enter  0x202,0x0
    1b55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b58:	26 f6 45 26 20       	test   BYTE PTR es:[di+0x26],0x20
    1b5d:	74 5b                	je     0x1bba
    1b5f:	8d be fe fe          	lea    di,[bp-0x102]
    1b63:	16                   	push   ss
    1b64:	57                   	push   di
    1b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b68:	06                   	push   es
    1b69:	57                   	push   di
    1b6a:	9a 2a 51 d0 1b       	call   0x1bd0:0x512a
    1b6f:	8d be fe fd          	lea    di,[bp-0x202]
    1b73:	16                   	push   ss
    1b74:	57                   	push   di
    1b75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b78:	06                   	push   es
    1b79:	57                   	push   di
    1b7a:	9a 53 1d 9f 1b       	call   0x1b9f:0x1d53
    1b7f:	9a be 18 a6 1b       	call   0x1ba6:0x18be
    1b84:	75 34                	jne    0x1bba
    1b86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b89:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1b8d:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    1b91:	74 2b                	je     0x1bbe
    1b93:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1b97:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1b9b:	bf 99 03             	mov    di,0x399
    1b9e:	b8 e5 1b             	mov    ax,0x1be5
    1ba1:	50                   	push   ax
    1ba2:	57                   	push   di
    1ba3:	9a 55 22 0a 1c       	call   0x1c0a:0x2255
    1ba8:	08 c0                	or     al,al
    1baa:	74 12                	je     0x1bbe
    1bac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1baf:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1bb3:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    1bb8:	74 04                	je     0x1bbe
    1bba:	b0 00                	mov    al,0x0
    1bbc:	eb 02                	jmp    0x1bc0
    1bbe:	b0 01                	mov    al,0x1
    1bc0:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1bc3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1bc6:	06                   	push   es
    1bc7:	57                   	push   di
    1bc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bcb:	06                   	push   es
    1bcc:	57                   	push   di
    1bcd:	9a 46 51 5a 20       	call   0x205a:0x5146
    1bd2:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1bd6:	74 0f                	je     0x1be7
    1bd8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1bdb:	06                   	push   es
    1bdc:	57                   	push   di
    1bdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1be0:	06                   	push   es
    1be1:	57                   	push   di
    1be2:	9a 8c 1d 59 1c       	call   0x1c59:0x1d8c
    1be7:	c9                   	leave
    1be8:	ca 08 00             	retf   0x8
    1beb:	c8 10 00 00          	enter  0x10,0x0
    1bef:	8d 7e f0             	lea    di,[bp-0x10]
    1bf2:	16                   	push   ss
    1bf3:	57                   	push   di
    1bf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf7:	06                   	push   es
    1bf8:	57                   	push   di
    1bf9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bfc:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1c00:	8d 7e f8             	lea    di,[bp-0x8]
    1c03:	16                   	push   ss
    1c04:	57                   	push   di
    1c05:	6a 08                	push   0x8
    1c07:	9a 1b 16 8e 1c       	call   0x1c8e:0x161b
    1c0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c0f:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1c13:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1c17:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1c1b:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1c1e:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    1c21:	50                   	push   ax
    1c22:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1c26:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    1c29:	03 46 0c             	add    ax,WORD PTR [bp+0xc]
    1c2c:	50                   	push   ax
    1c2d:	06                   	push   es
    1c2e:	57                   	push   di
    1c2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c32:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    1c36:	c9                   	leave
    1c37:	ca 08 00             	retf   0x8
    1c3a:	55                   	push   bp
    1c3b:	89 e5                	mov    bp,sp
    1c3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c40:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    1c44:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    1c48:	74 11                	je     0x1c5b
    1c4a:	ff 76 08             	push   WORD PTR [bp+0x8]
    1c4d:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c50:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1c54:	06                   	push   es
    1c55:	57                   	push   di
    1c56:	9a 16 39 71 1c       	call   0x1c71:0x3916
    1c5b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1c5e:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1c61:	74 10                	je     0x1c73
    1c63:	ff 76 08             	push   WORD PTR [bp+0x8]
    1c66:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c69:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c6c:	06                   	push   es
    1c6d:	57                   	push   di
    1c6e:	9a 59 38 a8 1c       	call   0x1ca8:0x3859
    1c73:	c9                   	leave
    1c74:	ca 08 00             	retf   0x8
    1c77:	55                   	push   bp
    1c78:	89 e5                	mov    bp,sp
    1c7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c7d:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    1c81:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1c84:	74 2e                	je     0x1cb4
    1c86:	06                   	push   es
    1c87:	57                   	push   di
    1c88:	b8 f5 ff             	mov    ax,0xfff5
    1c8b:	9a 6a 20 7d 1d       	call   0x1d7d:0x206a
    1c90:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1c93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c96:	26 88 45 29          	mov    BYTE PTR es:[di+0x29],al
    1c9a:	68 0b 0f             	push   0xf0b
    1c9d:	6a 00                	push   0x0
    1c9f:	6a 00                	push   0x0
    1ca1:	6a 00                	push   0x0
    1ca3:	06                   	push   es
    1ca4:	57                   	push   di
    1ca5:	9a bb 24 b2 1c       	call   0x1cb2:0x24bb
    1caa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cad:	06                   	push   es
    1cae:	57                   	push   di
    1caf:	9a 73 15 dc 1c       	call   0x1cdc:0x1573
    1cb4:	c9                   	leave
    1cb5:	ca 06 00             	retf   0x6
    1cb8:	55                   	push   bp
    1cb9:	89 e5                	mov    bp,sp
    1cbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cbe:	26 8a 45 2a          	mov    al,BYTE PTR es:[di+0x2a]
    1cc2:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1cc5:	74 17                	je     0x1cde
    1cc7:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1cca:	26 88 45 2a          	mov    BYTE PTR es:[di+0x2a],al
    1cce:	68 0c 0f             	push   0xf0c
    1cd1:	6a 00                	push   0x0
    1cd3:	6a 00                	push   0x0
    1cd5:	6a 00                	push   0x0
    1cd7:	06                   	push   es
    1cd8:	57                   	push   di
    1cd9:	9a bb 24 f6 1c       	call   0x1cf6:0x24bb
    1cde:	c9                   	leave
    1cdf:	ca 06 00             	retf   0x6
    1ce2:	c8 02 00 00          	enter  0x2,0x0
    1ce6:	6a 0e                	push   0xe
    1ce8:	6a 00                	push   0x0
    1cea:	6a 00                	push   0x0
    1cec:	6a 00                	push   0x0
    1cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf1:	06                   	push   es
    1cf2:	57                   	push   di
    1cf3:	9a bb 24 19 1d       	call   0x1d19:0x24bb
    1cf8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1cfb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1cfe:	c9                   	leave
    1cff:	ca 04 00             	retf   0x4
    1d02:	c8 02 00 00          	enter  0x2,0x0
    1d06:	6a 0d                	push   0xd
    1d08:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d0b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1d0e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d14:	06                   	push   es
    1d15:	57                   	push   di
    1d16:	9a bb 24 3a 1d       	call   0x1d3a:0x24bb
    1d1b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d1e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d21:	c9                   	leave
    1d22:	ca 0a 00             	retf   0xa
    1d25:	55                   	push   bp
    1d26:	89 e5                	mov    bp,sp
    1d28:	6a 0c                	push   0xc
    1d2a:	6a 00                	push   0x0
    1d2c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d2f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d35:	06                   	push   es
    1d36:	57                   	push   di
    1d37:	9a bb 24 4d 1d       	call   0x1d4d:0x24bb
    1d3c:	68 12 0f             	push   0xf12
    1d3f:	6a 00                	push   0x0
    1d41:	6a 00                	push   0x0
    1d43:	6a 00                	push   0x0
    1d45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d48:	06                   	push   es
    1d49:	57                   	push   di
    1d4a:	9a bb 24 67 1d       	call   0x1d67:0x24bb
    1d4f:	c9                   	leave
    1d50:	ca 08 00             	retf   0x8
    1d53:	c8 02 00 00          	enter  0x2,0x0
    1d57:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d5a:	06                   	push   es
    1d5b:	57                   	push   di
    1d5c:	68 00 01             	push   0x100
    1d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d62:	06                   	push   es
    1d63:	57                   	push   di
    1d64:	9a 02 1d 9e 1d       	call   0x1d9e:0x1d02
    1d69:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d6c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d6f:	06                   	push   es
    1d70:	57                   	push   di
    1d71:	81 c7 01 00          	add    di,0x1
    1d75:	06                   	push   es
    1d76:	57                   	push   di
    1d77:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1d7a:	9a c1 1e a8 1d       	call   0x1da8:0x1ec1
    1d7f:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    1d82:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d85:	26 88 05             	mov    BYTE PTR es:[di],al
    1d88:	c9                   	leave
    1d89:	ca 04 00             	retf   0x4
    1d8c:	c8 00 02 00          	enter  0x200,0x0
    1d90:	8d be 00 fe          	lea    di,[bp-0x200]
    1d94:	16                   	push   ss
    1d95:	57                   	push   di
    1d96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d99:	06                   	push   es
    1d9a:	57                   	push   di
    1d9b:	9a 53 1d c6 1d       	call   0x1dc6:0x1d53
    1da0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1da3:	06                   	push   es
    1da4:	57                   	push   di
    1da5:	9a be 18 fc 1f       	call   0x1ffc:0x18be
    1daa:	74 1c                	je     0x1dc8
    1dac:	8d be 00 ff          	lea    di,[bp-0x100]
    1db0:	16                   	push   ss
    1db1:	57                   	push   di
    1db2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1db5:	06                   	push   es
    1db6:	57                   	push   di
    1db7:	9a 4c 0d 16 20       	call   0x2016:0xd4c
    1dbc:	52                   	push   dx
    1dbd:	50                   	push   ax
    1dbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dc1:	06                   	push   es
    1dc2:	57                   	push   di
    1dc3:	9a 25 1d e5 1d       	call   0x1de5:0x1d25
    1dc8:	c9                   	leave
    1dc9:	ca 08 00             	retf   0x8
    1dcc:	55                   	push   bp
    1dcd:	89 e5                	mov    bp,sp
    1dcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd2:	26 c6 45 2b 00       	mov    BYTE PTR es:[di+0x2b],0x0
    1dd7:	68 0e 0f             	push   0xf0e
    1dda:	6a 00                	push   0x0
    1ddc:	6a 00                	push   0x0
    1dde:	6a 00                	push   0x0
    1de0:	06                   	push   es
    1de1:	57                   	push   di
    1de2:	9a bb 24 6c 1e       	call   0x1e6c:0x24bb
    1de7:	c9                   	leave
    1de8:	ca 08 00             	retf   0x8
    1deb:	55                   	push   bp
    1dec:	89 e5                	mov    bp,sp
    1dee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1df1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1df4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df7:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1dfb:	06                   	push   es
    1dfc:	57                   	push   di
    1dfd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e00:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1e04:	c9                   	leave
    1e05:	ca 08 00             	retf   0x8
    1e08:	c8 02 00 00          	enter  0x2,0x0
    1e0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0f:	26 80 7d 2b 00       	cmp    BYTE PTR es:[di+0x2b],0x0
    1e14:	b0 00                	mov    al,0x0
    1e16:	75 01                	jne    0x1e19
    1e18:	40                   	inc    ax
    1e19:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1e1c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e1f:	c9                   	leave
    1e20:	ca 04 00             	retf   0x4
    1e23:	c8 02 00 00          	enter  0x2,0x0
    1e27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2a:	26 80 7d 49 00       	cmp    BYTE PTR es:[di+0x49],0x0
    1e2f:	b0 00                	mov    al,0x0
    1e31:	75 01                	jne    0x1e34
    1e33:	40                   	inc    ax
    1e34:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1e37:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e3a:	c9                   	leave
    1e3b:	ca 04 00             	retf   0x4
    1e3e:	55                   	push   bp
    1e3f:	89 e5                	mov    bp,sp
    1e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e44:	26 8a 45 2b          	mov    al,BYTE PTR es:[di+0x2b]
    1e48:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1e4b:	74 21                	je     0x1e6e
    1e4d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1e50:	26 88 45 2b          	mov    BYTE PTR es:[di+0x2b],al
    1e54:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    1e58:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    1e5c:	74 10                	je     0x1e6e
    1e5e:	68 08 0f             	push   0xf08
    1e61:	6a 00                	push   0x0
    1e63:	6a 00                	push   0x0
    1e65:	6a 00                	push   0x0
    1e67:	06                   	push   es
    1e68:	57                   	push   di
    1e69:	9a bb 24 9b 1e       	call   0x1e9b:0x24bb
    1e6e:	c9                   	leave
    1e6f:	ca 06 00             	retf   0x6
    1e72:	55                   	push   bp
    1e73:	89 e5                	mov    bp,sp
    1e75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e78:	26 8a 45 48          	mov    al,BYTE PTR es:[di+0x48]
    1e7c:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1e7f:	74 1c                	je     0x1e9d
    1e81:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1e84:	26 88 45 48          	mov    BYTE PTR es:[di+0x48],al
    1e88:	26 c6 45 49 00       	mov    BYTE PTR es:[di+0x49],0x0
    1e8d:	68 22 0f             	push   0xf22
    1e90:	6a 00                	push   0x0
    1e92:	6a 00                	push   0x0
    1e94:	6a 00                	push   0x0
    1e96:	06                   	push   es
    1e97:	57                   	push   di
    1e98:	9a bb 24 cf 1e       	call   0x1ecf:0x24bb
    1e9d:	c9                   	leave
    1e9e:	ca 06 00             	retf   0x6
    1ea1:	55                   	push   bp
    1ea2:	89 e5                	mov    bp,sp
    1ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ea7:	26 8a 45 49          	mov    al,BYTE PTR es:[di+0x49]
    1eab:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1eae:	74 21                	je     0x1ed1
    1eb0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1eb3:	26 88 45 49          	mov    BYTE PTR es:[di+0x49],al
    1eb7:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    1ebb:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    1ebf:	74 10                	je     0x1ed1
    1ec1:	68 23 0f             	push   0xf23
    1ec4:	6a 00                	push   0x0
    1ec6:	6a 00                	push   0x0
    1ec8:	6a 00                	push   0x0
    1eca:	06                   	push   es
    1ecb:	57                   	push   di
    1ecc:	9a bb 24 11 1f       	call   0x1f11:0x24bb
    1ed1:	c9                   	leave
    1ed2:	ca 06 00             	retf   0x6
    1ed5:	55                   	push   bp
    1ed6:	89 e5                	mov    bp,sp
    1ed8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1edb:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    1edf:	26 8b 55 3a          	mov    dx,WORD PTR es:[di+0x3a]
    1ee3:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    1ee6:	75 05                	jne    0x1eed
    1ee8:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    1eeb:	74 26                	je     0x1f13
    1eed:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ef0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1ef3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ef6:	26 89 45 38          	mov    WORD PTR es:[di+0x38],ax
    1efa:	26 89 55 3a          	mov    WORD PTR es:[di+0x3a],dx
    1efe:	26 c6 45 2c 00       	mov    BYTE PTR es:[di+0x2c],0x0
    1f03:	68 0d 0f             	push   0xf0d
    1f06:	6a 00                	push   0x0
    1f08:	6a 00                	push   0x0
    1f0a:	6a 00                	push   0x0
    1f0c:	06                   	push   es
    1f0d:	57                   	push   di
    1f0e:	9a bb 24 60 1f       	call   0x1f60:0x24bb
    1f13:	c9                   	leave
    1f14:	ca 08 00             	retf   0x8
    1f17:	c8 02 00 00          	enter  0x2,0x0
    1f1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f1e:	26 80 7d 2c 00       	cmp    BYTE PTR es:[di+0x2c],0x0
    1f23:	b0 00                	mov    al,0x0
    1f25:	75 01                	jne    0x1f28
    1f27:	40                   	inc    ax
    1f28:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1f2b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1f2e:	c9                   	leave
    1f2f:	ca 04 00             	retf   0x4
    1f32:	55                   	push   bp
    1f33:	89 e5                	mov    bp,sp
    1f35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f38:	26 8a 45 2c          	mov    al,BYTE PTR es:[di+0x2c]
    1f3c:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1f3f:	74 21                	je     0x1f62
    1f41:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1f44:	26 88 45 2c          	mov    BYTE PTR es:[di+0x2c],al
    1f48:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    1f4c:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    1f50:	74 10                	je     0x1f62
    1f52:	68 09 0f             	push   0xf09
    1f55:	6a 00                	push   0x0
    1f57:	6a 00                	push   0x0
    1f59:	6a 00                	push   0x0
    1f5b:	06                   	push   es
    1f5c:	57                   	push   di
    1f5d:	9a bb 24 8a 1f       	call   0x1f8a:0x24bb
    1f62:	c9                   	leave
    1f63:	ca 06 00             	retf   0x6
    1f66:	55                   	push   bp
    1f67:	89 e5                	mov    bp,sp
    1f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6c:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    1f70:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    1f73:	74 17                	je     0x1f8c
    1f75:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1f78:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    1f7c:	68 0f 0f             	push   0xf0f
    1f7f:	6a 00                	push   0x0
    1f81:	6a 00                	push   0x0
    1f83:	6a 00                	push   0x0
    1f85:	06                   	push   es
    1f86:	57                   	push   di
    1f87:	9a bb 24 97 1f       	call   0x1f97:0x24bb
    1f8c:	c9                   	leave
    1f8d:	ca 06 00             	retf   0x6
    1f90:	c8 02 00 00          	enter  0x2,0x0
    1f94:	9a 61 0d be 1f       	call   0x1fbe:0xd61
    1f99:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    1f9c:	75 05                	jne    0x1fa3
    1f9e:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    1fa1:	74 04                	je     0x1fa7
    1fa3:	b0 00                	mov    al,0x0
    1fa5:	eb 02                	jmp    0x1fa9
    1fa7:	b0 01                	mov    al,0x1
    1fa9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1fac:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1faf:	c9                   	leave
    1fb0:	ca 04 00             	retf   0x4
    1fb3:	55                   	push   bp
    1fb4:	89 e5                	mov    bp,sp
    1fb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb9:	06                   	push   es
    1fba:	57                   	push   di
    1fbb:	9a 90 1f d4 1f       	call   0x1fd4:0x1f90
    1fc0:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1fc3:	74 1c                	je     0x1fe1
    1fc5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1fc9:	74 0d                	je     0x1fd8
    1fcb:	ff 76 08             	push   WORD PTR [bp+0x8]
    1fce:	ff 76 06             	push   WORD PTR [bp+0x6]
    1fd1:	9a b2 0d df 1f       	call   0x1fdf:0xdb2
    1fd6:	eb 09                	jmp    0x1fe1
    1fd8:	6a 00                	push   0x0
    1fda:	6a 00                	push   0x0
    1fdc:	9a b2 0d d2 20       	call   0x20d2:0xdb2
    1fe1:	c9                   	leave
    1fe2:	ca 06 00             	retf   0x6
    1fe5:	55                   	push   bp
    1fe6:	89 e5                	mov    bp,sp
    1fe8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1feb:	26 c4 7d 44          	les    di,DWORD PTR es:[di+0x44]
    1fef:	06                   	push   es
    1ff0:	57                   	push   di
    1ff1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ff4:	06                   	push   es
    1ff5:	57                   	push   di
    1ff6:	68 ff 00             	push   0xff
    1ff9:	9a e7 17 2c 20       	call   0x202c:0x17e7
    1ffe:	c9                   	leave
    1fff:	ca 04 00             	retf   0x4
    2002:	55                   	push   bp
    2003:	89 e5                	mov    bp,sp
    2005:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2008:	81 c7 44 00          	add    di,0x44
    200c:	06                   	push   es
    200d:	57                   	push   di
    200e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2011:	06                   	push   es
    2012:	57                   	push   di
    2013:	9a 51 06 4d 21       	call   0x214d:0x651
    2018:	c9                   	leave
    2019:	ca 08 00             	retf   0x8
    201c:	55                   	push   bp
    201d:	89 e5                	mov    bp,sp
    201f:	6a 01                	push   0x1
    2021:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2024:	06                   	push   es
    2025:	57                   	push   di
    2026:	b8 f6 ff             	mov    ax,0xfff6
    2029:	9a 6a 20 fc 20       	call   0x20fc:0x206a
    202e:	c9                   	leave
    202f:	ca 04 00             	retf   0x4
    2032:	c8 08 00 00          	enter  0x8,0x0
    2036:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2039:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    203d:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2041:	75 03                	jne    0x2046
    2043:	e9 b8 00             	jmp    0x20fe
    2046:	ff 76 08             	push   WORD PTR [bp+0x8]
    2049:	ff 76 06             	push   WORD PTR [bp+0x6]
    204c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2050:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    2055:	06                   	push   es
    2056:	57                   	push   di
    2057:	9a 58 0e a5 20       	call   0x20a5:0xe58
    205c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    205f:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2063:	7d 03                	jge    0x2068
    2065:	e9 96 00             	jmp    0x20fe
    2068:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    206c:	74 16                	je     0x2084
    206e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2071:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2075:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    207a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    207e:	48                   	dec    ax
    207f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2082:	eb 05                	jmp    0x2089
    2084:	31 c0                	xor    ax,ax
    2086:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2089:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    208c:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    208f:	74 6d                	je     0x20fe
    2091:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2094:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2097:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    209b:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    20a0:	06                   	push   es
    20a1:	57                   	push   di
    20a2:	9a 94 0c c1 20       	call   0x20c1:0xc94
    20a7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20aa:	ff 76 08             	push   WORD PTR [bp+0x8]
    20ad:	ff 76 06             	push   WORD PTR [bp+0x6]
    20b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b3:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    20b7:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    20bc:	06                   	push   es
    20bd:	57                   	push   di
    20be:	9a a7 0e 2a 21       	call   0x212a:0xea7
    20c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20c6:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    20ca:	50                   	push   ax
    20cb:	6a 01                	push   0x1
    20cd:	06                   	push   es
    20ce:	57                   	push   di
    20cf:	9a b3 21 56 21       	call   0x2156:0x21b3
    20d4:	ff 76 08             	push   WORD PTR [bp+0x8]
    20d7:	ff 76 06             	push   WORD PTR [bp+0x6]
    20da:	9a 01 18 d4 23       	call   0x23d4:0x1801
    20df:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    20e2:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    20e5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20e8:	26 f6 45 28 04       	test   BYTE PTR es:[di+0x28],0x4
    20ed:	74 0f                	je     0x20fe
    20ef:	6a 01                	push   0x1
    20f1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20f4:	06                   	push   es
    20f5:	57                   	push   di
    20f6:	b8 f7 ff             	mov    ax,0xfff7
    20f9:	9a 6a 20 64 21       	call   0x2164:0x206a
    20fe:	c9                   	leave
    20ff:	ca 06 00             	retf   0x6
    2102:	c8 0a 02 00          	enter  0x20a,0x0
    2106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2109:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    210d:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2111:	75 53                	jne    0x2166
    2113:	8d be f6 fd          	lea    di,[bp-0x20a]
    2117:	16                   	push   ss
    2118:	57                   	push   di
    2119:	68 2a f0             	push   0xf02a
    211c:	8d be fe fe          	lea    di,[bp-0x102]
    2120:	16                   	push   ss
    2121:	57                   	push   di
    2122:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2125:	06                   	push   es
    2126:	57                   	push   di
    2127:	9a 2a 51 0a 27       	call   0x270a:0x512a
    212c:	83 c4 04             	add    sp,0x4
    212f:	8d 86 fe fe          	lea    ax,[bp-0x102]
    2133:	8c d2                	mov    dx,ss
    2135:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    2139:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    213d:	c6 86 fa fe 04       	mov    BYTE PTR [bp-0x106],0x4
    2142:	8d be f6 fe          	lea    di,[bp-0x10a]
    2146:	16                   	push   ss
    2147:	57                   	push   di
    2148:	6a 00                	push   0x0
    214a:	9a 50 09 5d 21       	call   0x215d:0x950
    214f:	b0 01                	mov    al,0x1
    2151:	50                   	push   ax
    2152:	b8 52 00             	mov    ax,0x52
    2155:	ba dd 21             	mov    dx,0x21dd
    2158:	52                   	push   dx
    2159:	50                   	push   ax
    215a:	9a e6 28 ed 23       	call   0x23ed:0x28e6
    215f:	52                   	push   dx
    2160:	50                   	push   ax
    2161:	9a 99 13 fc 21       	call   0x21fc:0x1399
    2166:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2169:	06                   	push   es
    216a:	57                   	push   di
    216b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    216e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2172:	06                   	push   es
    2173:	57                   	push   di
    2174:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2177:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    217b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    217e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2181:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2184:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    2188:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    218c:	6a 00                	push   0x0
    218e:	6a 00                	push   0x0
    2190:	9a 2b 49 00 00       	call   0x0:0x492b
    2195:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2198:	6a 00                	push   0x0
    219a:	6a 00                	push   0x0
    219c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    219f:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    21a3:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    21a7:	9a 69 23 00 00       	call   0x0:0x2369
    21ac:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    21af:	c9                   	leave
    21b0:	ca 08 00             	retf   0x8
    21b3:	c8 10 00 00          	enter  0x10,0x0
    21b7:	80 7e 0c 00          	cmp    BYTE PTR [bp+0xc],0x0
    21bb:	75 0a                	jne    0x21c7
    21bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c0:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    21c5:	74 6c                	je     0x2233
    21c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ca:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    21ce:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    21d2:	74 5f                	je     0x2233
    21d4:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    21d8:	06                   	push   es
    21d9:	57                   	push   di
    21da:	9a fa 64 f0 21       	call   0x21f0:0x64fa
    21df:	08 c0                	or     al,al
    21e1:	74 50                	je     0x2233
    21e3:	8d 7e f0             	lea    di,[bp-0x10]
    21e6:	16                   	push   ss
    21e7:	57                   	push   di
    21e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21eb:	06                   	push   es
    21ec:	57                   	push   di
    21ed:	9a 03 18 0a 22       	call   0x220a:0x1803
    21f2:	8d 7e f8             	lea    di,[bp-0x8]
    21f5:	16                   	push   ss
    21f6:	57                   	push   di
    21f7:	6a 08                	push   0x8
    21f9:	9a 1b 16 db 23       	call   0x23db:0x161b
    21fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2201:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2205:	06                   	push   es
    2206:	57                   	push   di
    2207:	9a b9 62 52 22       	call   0x2252:0x62b9
    220c:	50                   	push   ax
    220d:	8d 7e f8             	lea    di,[bp-0x8]
    2210:	16                   	push   ss
    2211:	57                   	push   di
    2212:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2216:	75 0e                	jne    0x2226
    2218:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    221b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    221f:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    2224:	74 04                	je     0x222a
    2226:	b0 00                	mov    al,0x0
    2228:	eb 02                	jmp    0x222c
    222a:	b0 01                	mov    al,0x1
    222c:	98                   	cbw
    222d:	50                   	push   ax
    222e:	9a 32 61 00 00       	call   0x0:0x6132
    2233:	c9                   	leave
    2234:	ca 08 00             	retf   0x8
    2237:	55                   	push   bp
    2238:	89 e5                	mov    bp,sp
    223a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223d:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    2241:	50                   	push   ax
    2242:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    2247:	b0 00                	mov    al,0x0
    2249:	74 01                	je     0x224c
    224b:	40                   	inc    ax
    224c:	50                   	push   ax
    224d:	06                   	push   es
    224e:	57                   	push   di
    224f:	9a b3 21 65 22       	call   0x2265:0x21b3
    2254:	c9                   	leave
    2255:	ca 04 00             	retf   0x4
    2258:	55                   	push   bp
    2259:	89 e5                	mov    bp,sp
    225b:	6a 00                	push   0x0
    225d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2260:	06                   	push   es
    2261:	57                   	push   di
    2262:	9a 77 1c 9f 22       	call   0x229f:0x1c77
    2267:	c9                   	leave
    2268:	ca 04 00             	retf   0x4
    226b:	55                   	push   bp
    226c:	89 e5                	mov    bp,sp
    226e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2271:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2275:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2279:	74 13                	je     0x228e
    227b:	ff 76 08             	push   WORD PTR [bp+0x8]
    227e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2281:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2285:	06                   	push   es
    2286:	57                   	push   di
    2287:	26 c4 3d             	les    di,DWORD PTR es:[di]
    228a:	26 ff 5d 74          	call   DWORD PTR es:[di+0x74]
    228e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2291:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2296:	75 09                	jne    0x22a1
    2298:	6a 01                	push   0x1
    229a:	06                   	push   es
    229b:	57                   	push   di
    229c:	9a 77 1c dd 22       	call   0x22dd:0x1c77
    22a1:	c9                   	leave
    22a2:	ca 04 00             	retf   0x4
    22a5:	55                   	push   bp
    22a6:	89 e5                	mov    bp,sp
    22a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ab:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    22af:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    22b3:	74 0d                	je     0x22c2
    22b5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    22b9:	06                   	push   es
    22ba:	57                   	push   di
    22bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22be:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    22c2:	c9                   	leave
    22c3:	ca 04 00             	retf   0x4
    22c6:	55                   	push   bp
    22c7:	89 e5                	mov    bp,sp
    22c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22cc:	06                   	push   es
    22cd:	57                   	push   di
    22ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22d1:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    22d5:	c9                   	leave
    22d6:	ca 04 00             	retf   0x4
    22d9:	00 00                	add    BYTE PTR [bx+si],al
    22db:	90                   	nop
    22dc:	23 10                	and    dx,WORD PTR [bx+si]
    22de:	23 c8                	and    cx,ax
    22e0:	02 00                	add    al,BYTE PTR [bx+si]
    22e2:	00 c4                	add    ah,al
    22e4:	7e 06                	jle    0x22ec
    22e6:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    22eb:	75 0a                	jne    0x22f7
    22ed:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    22f2:	75 03                	jne    0x22f7
    22f4:	e9 cb 00             	jmp    0x23c2
    22f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fa:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    22fe:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2302:	75 03                	jne    0x2307
    2304:	e9 bb 00             	jmp    0x23c2
    2307:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    230b:	06                   	push   es
    230c:	57                   	push   di
    230d:	9a fa 64 2f 23       	call   0x232f:0x64fa
    2312:	08 c0                	or     al,al
    2314:	75 03                	jne    0x2319
    2316:	e9 a9 00             	jmp    0x23c2
    2319:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    231c:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    2321:	75 03                	jne    0x2326
    2323:	e9 84 00             	jmp    0x23aa
    2326:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    232a:	06                   	push   es
    232b:	57                   	push   di
    232c:	9a b9 62 82 23       	call   0x2382:0x62b9
    2331:	50                   	push   ax
    2332:	9a c1 60 00 00       	call   0x0:0x60c1
    2337:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    233a:	b8 d9 22             	mov    ax,0x22d9
    233d:	0e                   	push   cs
    233e:	50                   	push   ax
    233f:	55                   	push   bp
    2340:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2344:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2348:	ff 76 fe             	push   WORD PTR [bp-0x2]
    234b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234e:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    2352:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    2356:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    235a:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    235e:	50                   	push   ax
    235f:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2363:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    2367:	50                   	push   ax
    2368:	9a 42 49 00 00       	call   0x0:0x4942
    236d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2370:	ff 76 08             	push   WORD PTR [bp+0x8]
    2373:	ff 76 06             	push   WORD PTR [bp+0x6]
    2376:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2379:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    237d:	06                   	push   es
    237e:	57                   	push   di
    237f:	9a 50 48 9c 23       	call   0x239c:0x4850
    2384:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2388:	83 c4 06             	add    sp,0x6
    238b:	b8 a8 23             	mov    ax,0x23a8
    238e:	0e                   	push   cs
    238f:	50                   	push   ax
    2390:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2393:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2397:	06                   	push   es
    2398:	57                   	push   di
    2399:	9a b9 62 f6 23       	call   0x23f6:0x62b9
    239e:	50                   	push   ax
    239f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    23a2:	9a ff ff 00 00       	call   0x0:0xffff
    23a7:	cb                   	retf
    23a8:	eb 18                	jmp    0x23c2
    23aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ad:	06                   	push   es
    23ae:	57                   	push   di
    23af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23b2:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    23b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b9:	06                   	push   es
    23ba:	57                   	push   di
    23bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23be:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    23c2:	c9                   	leave
    23c3:	ca 04 00             	retf   0x4
    23c6:	c8 04 01 00          	enter  0x104,0x0
    23ca:	ff 76 08             	push   WORD PTR [bp+0x8]
    23cd:	ff 76 06             	push   WORD PTR [bp+0x6]
    23d0:	bf fb 04             	mov    di,0x4fb
    23d3:	b8 2c 25             	mov    ax,0x252c
    23d6:	50                   	push   ax
    23d7:	57                   	push   di
    23d8:	9a 55 22 04 24       	call   0x2404:0x2255
    23dd:	08 c0                	or     al,al
    23df:	74 25                	je     0x2406
    23e1:	8d be fc fe          	lea    di,[bp-0x104]
    23e5:	16                   	push   ss
    23e6:	57                   	push   di
    23e7:	68 46 f0             	push   0xf046
    23ea:	9a 2b 09 fd 23       	call   0x23fd:0x92b
    23ef:	b0 01                	mov    al,0x1
    23f1:	50                   	push   ax
    23f2:	b8 52 00             	mov    ax,0x52
    23f5:	ba 31 24             	mov    dx,0x2431
    23f8:	52                   	push   dx
    23f9:	50                   	push   ax
    23fa:	9a e6 28 67 26       	call   0x2667:0x28e6
    23ff:	52                   	push   dx
    2400:	50                   	push   ax
    2401:	9a 99 13 0a 26       	call   0x260a:0x1399
    2406:	a1 12 2c             	mov    ax,ds:0x2c12
    2409:	0b 06 14 2c          	or     ax,WORD PTR ds:0x2c14
    240d:	75 4c                	jne    0x245b
    240f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2412:	26 f6 45 28 01       	test   BYTE PTR es:[di+0x28],0x1
    2417:	74 35                	je     0x244e
    2419:	8d 7e fc             	lea    di,[bp-0x4]
    241c:	16                   	push   ss
    241d:	57                   	push   di
    241e:	9a 4d 4e 00 00       	call   0x0:0x4e4d
    2423:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2426:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2429:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242c:	06                   	push   es
    242d:	57                   	push   di
    242e:	9a 06 1a 4c 24       	call   0x244c:0x1a06
    2433:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2436:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2439:	68 02 02             	push   0x202
    243c:	6a 00                	push   0x0
    243e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2441:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2444:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2447:	06                   	push   es
    2448:	57                   	push   di
    2449:	9a bb 24 89 25       	call   0x2589:0x24bb
    244e:	ff 76 08             	push   WORD PTR [bp+0x8]
    2451:	ff 76 06             	push   WORD PTR [bp+0x6]
    2454:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2457:	50                   	push   ax
    2458:	e8 9c eb             	call   0xff7
    245b:	c9                   	leave
    245c:	ca 06 00             	retf   0x6
    245f:	55                   	push   bp
    2460:	89 e5                	mov    bp,sp
    2462:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2465:	26 8b 45 64          	mov    ax,WORD PTR es:[di+0x64]
    2469:	09 c0                	or     ax,ax
    246b:	74 1e                	je     0x248b
    246d:	ff 76 08             	push   WORD PTR [bp+0x8]
    2470:	ff 76 06             	push   WORD PTR [bp+0x6]
    2473:	ff 76 10             	push   WORD PTR [bp+0x10]
    2476:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2479:	ff 76 0c             	push   WORD PTR [bp+0xc]
    247c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    247f:	26 ff 75 68          	push   WORD PTR es:[di+0x68]
    2483:	26 ff 75 66          	push   WORD PTR es:[di+0x66]
    2487:	26 ff 5d 62          	call   DWORD PTR es:[di+0x62]
    248b:	c9                   	leave
    248c:	ca 0c 00             	retf   0xc
    248f:	55                   	push   bp
    2490:	89 e5                	mov    bp,sp
    2492:	c9                   	leave
    2493:	ca 04 00             	retf   0x4
    2496:	c8 02 00 00          	enter  0x2,0x0
    249a:	a1 12 2c             	mov    ax,ds:0x2c12
    249d:	8b 16 14 2c          	mov    dx,WORD PTR ds:0x2c14
    24a1:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    24a4:	75 05                	jne    0x24ab
    24a6:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    24a9:	74 04                	je     0x24af
    24ab:	b0 00                	mov    al,0x0
    24ad:	eb 02                	jmp    0x24b1
    24af:	b0 01                	mov    al,0x1
    24b1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    24b4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    24b7:	c9                   	leave
    24b8:	ca 04 00             	retf   0x4
    24bb:	c8 10 00 00          	enter  0x10,0x0
    24bf:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    24c2:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    24c5:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    24c8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    24cb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    24ce:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    24d1:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    24d4:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    24d7:	31 c0                	xor    ax,ax
    24d9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    24dc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    24df:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    24e2:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    24e5:	74 11                	je     0x24f8
    24e7:	8d 7e f0             	lea    di,[bp-0x10]
    24ea:	16                   	push   ss
    24eb:	57                   	push   di
    24ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ef:	06                   	push   es
    24f0:	57                   	push   di
    24f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24f4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    24f8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    24fb:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    24fe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2501:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2504:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2507:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    250a:	c9                   	leave
    250b:	ca 0c 00             	retf   0xc
    250e:	55                   	push   bp
    250f:	89 e5                	mov    bp,sp
    2511:	c9                   	leave
    2512:	ca 04 00             	retf   0x4
    2515:	c8 04 00 00          	enter  0x4,0x0
    2519:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    251c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2521:	74 4a                	je     0x256d
    2523:	ff 76 08             	push   WORD PTR [bp+0x8]
    2526:	ff 76 06             	push   WORD PTR [bp+0x6]
    2529:	9a a8 17 0a 28       	call   0x280a:0x17a8
    252e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2531:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2534:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2537:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    253a:	74 31                	je     0x256d
    253c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    253f:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    2544:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    2549:	74 22                	je     0x256d
    254b:	ff 76 08             	push   WORD PTR [bp+0x8]
    254e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2551:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2554:	06                   	push   es
    2555:	57                   	push   di
    2556:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2559:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    255e:	06                   	push   es
    255f:	57                   	push   di
    2560:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2563:	26 ff 1d             	call   DWORD PTR es:[di]
    2566:	08 c0                	or     al,al
    2568:	74 03                	je     0x256d
    256a:	e9 9f 00             	jmp    0x260c
    256d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2570:	26 81 3d 00 02       	cmp    WORD PTR es:[di],0x200
    2575:	73 03                	jae    0x257a
    2577:	e9 83 00             	jmp    0x25fd
    257a:	26 81 3d 09 02       	cmp    WORD PTR es:[di],0x209
    257f:	77 7c                	ja     0x25fd
    2581:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2584:	06                   	push   es
    2585:	57                   	push   di
    2586:	9a 96 24 97 25       	call   0x2597:0x2496
    258b:	08 c0                	or     al,al
    258d:	74 0c                	je     0x259b
    258f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2592:	06                   	push   es
    2593:	57                   	push   di
    2594:	9a 65 11 e2 25       	call   0x25e2:0x1165
    2599:	eb 62                	jmp    0x25fd
    259b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259e:	26 f6 45 26 80       	test   BYTE PTR es:[di+0x26],0x80
    25a3:	75 1c                	jne    0x25c1
    25a5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25a8:	26 8b 05             	mov    ax,WORD PTR es:[di]
    25ab:	3d 03 02             	cmp    ax,0x203
    25ae:	74 0a                	je     0x25ba
    25b0:	3d 06 02             	cmp    ax,0x206
    25b3:	74 05                	je     0x25ba
    25b5:	3d 09 02             	cmp    ax,0x209
    25b8:	75 07                	jne    0x25c1
    25ba:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25bd:	26 83 2d 02          	sub    WORD PTR es:[di],0x2
    25c1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25c4:	26 8b 05             	mov    ax,WORD PTR es:[di]
    25c7:	3d 01 02             	cmp    ax,0x201
    25ca:	74 05                	je     0x25d1
    25cc:	3d 03 02             	cmp    ax,0x203
    25cf:	75 1f                	jne    0x25f0
    25d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d4:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    25d9:	75 0b                	jne    0x25e6
    25db:	6a 01                	push   0x1
    25dd:	06                   	push   es
    25de:	57                   	push   di
    25df:	9a c6 23 4b 27       	call   0x274b:0x23c6
    25e4:	eb 26                	jmp    0x260c
    25e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e9:	26 80 4d 28 01       	or     BYTE PTR es:[di+0x28],0x1
    25ee:	eb 0d                	jmp    0x25fd
    25f0:	3d 02 02             	cmp    ax,0x202
    25f3:	75 08                	jne    0x25fd
    25f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f8:	26 80 65 28 fe       	and    BYTE PTR es:[di+0x28],0xfe
    25fd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2600:	06                   	push   es
    2601:	57                   	push   di
    2602:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2605:	06                   	push   es
    2606:	57                   	push   di
    2607:	9a 38 20 26 28       	call   0x2826:0x2038
    260c:	c9                   	leave
    260d:	ca 08 00             	retf   0x8
    2610:	c8 08 00 00          	enter  0x8,0x0
    2614:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2617:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    261a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    261d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2620:	3d 0d 00             	cmp    ax,0xd
    2623:	75 5a                	jne    0x267f
    2625:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2628:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    262c:	26 0b 45 32          	or     ax,WORD PTR es:[di+0x32]
    2630:	74 10                	je     0x2642
    2632:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    2636:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    263a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    263d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2640:	eb 0b                	jmp    0x264d
    2642:	b8 f8 14             	mov    ax,0x14f8
    2645:	8c da                	mov    dx,ds
    2647:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    264a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    264d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2650:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2654:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2658:	ff 76 fe             	push   WORD PTR [bp-0x2]
    265b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    265e:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    2662:	48                   	dec    ax
    2663:	50                   	push   ax
    2664:	9a 24 0d 6e 26       	call   0x266e:0xd24
    2669:	52                   	push   dx
    266a:	50                   	push   ax
    266b:	9a 8c 0c ae 26       	call   0x26ae:0xc8c
    2670:	31 d2                	xor    dx,dx
    2672:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2675:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2679:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    267d:	eb 7c                	jmp    0x26fb
    267f:	3d 0e 00             	cmp    ax,0xe
    2682:	75 3b                	jne    0x26bf
    2684:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2687:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    268b:	26 0b 45 32          	or     ax,WORD PTR es:[di+0x32]
    268f:	75 0f                	jne    0x26a0
    2691:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2694:	31 c0                	xor    ax,ax
    2696:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    269a:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    269e:	eb 1d                	jmp    0x26bd
    26a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a3:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    26a7:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    26ab:	9a 8c 0c d2 26       	call   0x26d2:0xc8c
    26b0:	31 d2                	xor    dx,dx
    26b2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    26b5:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    26b9:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    26bd:	eb 3c                	jmp    0x26fb
    26bf:	3d 0c 00             	cmp    ax,0xc
    26c2:	75 37                	jne    0x26fb
    26c4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    26c7:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    26cb:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    26cf:	9a d6 0e e8 26       	call   0x26e8:0xed6
    26d4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26d7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    26da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26dd:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    26e1:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    26e5:	9a 23 0f 82 3c       	call   0x3c82:0xf23
    26ea:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26ed:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    26f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f3:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    26f7:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    26fb:	c9                   	leave
    26fc:	ca 08 00             	retf   0x8
    26ff:	55                   	push   bp
    2700:	89 e5                	mov    bp,sp
    2702:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2705:	06                   	push   es
    2706:	57                   	push   di
    2707:	9a 93 31 2a 27       	call   0x272a:0x3193
    270c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    270f:	26 88 45 2f          	mov    BYTE PTR es:[di+0x2f],al
    2713:	c9                   	leave
    2714:	ca 08 00             	retf   0x8
    2717:	55                   	push   bp
    2718:	89 e5                	mov    bp,sp
    271a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    271d:	26 8a 45 2f          	mov    al,BYTE PTR es:[di+0x2f]
    2721:	50                   	push   ax
    2722:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2725:	06                   	push   es
    2726:	57                   	push   di
    2727:	9a e2 42 08 2f       	call   0x2f08:0x42e2
    272c:	c9                   	leave
    272d:	ca 08 00             	retf   0x8
    2730:	09 49 73             	or     WORD PTR [bx+di+0x73],cx
    2733:	43                   	inc    bx
    2734:	6f                   	outs   dx,WORD PTR ds:[si]
    2735:	6e                   	outs   dx,BYTE PTR ds:[si]
    2736:	74 72                	je     0x27aa
    2738:	6f                   	outs   dx,WORD PTR ds:[si]
    2739:	6c                   	ins    BYTE PTR es:[di],dx
    273a:	55                   	push   bp
    273b:	89 e5                	mov    bp,sp
    273d:	bf 30 27             	mov    di,0x2730
    2740:	0e                   	push   cs
    2741:	57                   	push   di
    2742:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2745:	06                   	push   es
    2746:	57                   	push   di
    2747:	bf ff 26             	mov    di,0x26ff
    274a:	b8 58 27             	mov    ax,0x2758
    274d:	50                   	push   ax
    274e:	57                   	push   di
    274f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2752:	06                   	push   es
    2753:	57                   	push   di
    2754:	bf 17 27             	mov    di,0x2717
    2757:	b8 3e 28             	mov    ax,0x283e
    275a:	50                   	push   ax
    275b:	57                   	push   di
    275c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    275f:	26 8a 45 2f          	mov    al,BYTE PTR es:[di+0x2f]
    2763:	50                   	push   ax
    2764:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2767:	06                   	push   es
    2768:	57                   	push   di
    2769:	26 c4 3d             	les    di,DWORD PTR es:[di]
    276c:	26 ff 1d             	call   DWORD PTR es:[di]
    276f:	c9                   	leave
    2770:	ca 08 00             	retf   0x8
    2773:	55                   	push   bp
    2774:	89 e5                	mov    bp,sp
    2776:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2779:	26 8b 45 7c          	mov    ax,WORD PTR es:[di+0x7c]
    277d:	09 c0                	or     ax,ax
    277f:	74 13                	je     0x2794
    2781:	ff 76 08             	push   WORD PTR [bp+0x8]
    2784:	ff 76 06             	push   WORD PTR [bp+0x6]
    2787:	26 ff b5 80 00       	push   WORD PTR es:[di+0x80]
    278c:	26 ff 75 7e          	push   WORD PTR es:[di+0x7e]
    2790:	26 ff 5d 7a          	call   DWORD PTR es:[di+0x7a]
    2794:	c9                   	leave
    2795:	ca 04 00             	retf   0x4
    2798:	55                   	push   bp
    2799:	89 e5                	mov    bp,sp
    279b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279e:	26 8b 85 84 00       	mov    ax,WORD PTR es:[di+0x84]
    27a3:	09 c0                	or     ax,ax
    27a5:	74 15                	je     0x27bc
    27a7:	ff 76 08             	push   WORD PTR [bp+0x8]
    27aa:	ff 76 06             	push   WORD PTR [bp+0x6]
    27ad:	26 ff b5 88 00       	push   WORD PTR es:[di+0x88]
    27b2:	26 ff b5 86 00       	push   WORD PTR es:[di+0x86]
    27b7:	26 ff 9d 82 00       	call   DWORD PTR es:[di+0x82]
    27bc:	c9                   	leave
    27bd:	ca 04 00             	retf   0x4
    27c0:	55                   	push   bp
    27c1:	89 e5                	mov    bp,sp
    27c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c6:	26 8b 45 4c          	mov    ax,WORD PTR es:[di+0x4c]
    27ca:	09 c0                	or     ax,ax
    27cc:	74 20                	je     0x27ee
    27ce:	ff 76 08             	push   WORD PTR [bp+0x8]
    27d1:	ff 76 06             	push   WORD PTR [bp+0x6]
    27d4:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    27d7:	50                   	push   ax
    27d8:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    27db:	50                   	push   ax
    27dc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    27df:	ff 76 0a             	push   WORD PTR [bp+0xa]
    27e2:	26 ff 75 50          	push   WORD PTR es:[di+0x50]
    27e6:	26 ff 75 4e          	push   WORD PTR es:[di+0x4e]
    27ea:	26 ff 5d 4a          	call   DWORD PTR es:[di+0x4a]
    27ee:	c9                   	leave
    27ef:	ca 0c 00             	retf   0xc
    27f2:	c8 04 00 00          	enter  0x4,0x0
    27f6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    27f9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    27fc:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    27ff:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    2802:	50                   	push   ax
    2803:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2807:	9a 97 16 7d 28       	call   0x287d:0x1697
    280c:	0a 46 0a             	or     al,BYTE PTR [bp+0xa]
    280f:	50                   	push   ax
    2810:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2813:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2817:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    281b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    281e:	06                   	push   es
    281f:	57                   	push   di
    2820:	b8 fa ff             	mov    ax,0xfffa
    2823:	9a 6a 20 5c 29       	call   0x295c:0x206a
    2828:	c9                   	leave
    2829:	ca 0c 00             	retf   0xc
    282c:	c8 04 00 00          	enter  0x4,0x0
    2830:	ff 76 08             	push   WORD PTR [bp+0x8]
    2833:	ff 76 06             	push   WORD PTR [bp+0x6]
    2836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2839:	06                   	push   es
    283a:	57                   	push   di
    283b:	9a 38 1a 63 28       	call   0x2863:0x1a38
    2840:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2843:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2846:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2849:	06                   	push   es
    284a:	57                   	push   di
    284b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    284e:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2852:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2855:	26 f6 45 26 02       	test   BYTE PTR es:[di+0x26],0x2
    285a:	74 09                	je     0x2865
    285c:	6a 01                	push   0x1
    285e:	06                   	push   es
    285f:	57                   	push   di
    2860:	9a b3 1f b4 28       	call   0x28b4:0x1fb3
    2865:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2868:	26 f6 45 26 08       	test   BYTE PTR es:[di+0x26],0x8
    286d:	74 05                	je     0x2874
    286f:	26 80 4d 28 02       	or     BYTE PTR es:[di+0x28],0x2
    2874:	ff 76 08             	push   WORD PTR [bp+0x8]
    2877:	ff 76 06             	push   WORD PTR [bp+0x6]
    287a:	9a 01 18 46 2b       	call   0x2b46:0x1801
    287f:	89 c7                	mov    di,ax
    2881:	8e c2                	mov    es,dx
    2883:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    2888:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    288d:	74 14                	je     0x28a3
    288f:	ff 76 08             	push   WORD PTR [bp+0x8]
    2892:	ff 76 06             	push   WORD PTR [bp+0x6]
    2895:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    289a:	06                   	push   es
    289b:	57                   	push   di
    289c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    289f:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    28a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28a6:	06                   	push   es
    28a7:	57                   	push   di
    28a8:	6a 00                	push   0x0
    28aa:	6a 00                	push   0x0
    28ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28af:	06                   	push   es
    28b0:	57                   	push   di
    28b1:	9a f2 27 cb 28       	call   0x28cb:0x27f2
    28b6:	c9                   	leave
    28b7:	ca 08 00             	retf   0x8
    28ba:	55                   	push   bp
    28bb:	89 e5                	mov    bp,sp
    28bd:	ff 76 08             	push   WORD PTR [bp+0x8]
    28c0:	ff 76 06             	push   WORD PTR [bp+0x6]
    28c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c6:	06                   	push   es
    28c7:	57                   	push   di
    28c8:	9a 38 1a 0c 29       	call   0x290c:0x1a38
    28cd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28d0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d6:	06                   	push   es
    28d7:	57                   	push   di
    28d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28db:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    28df:	c9                   	leave
    28e0:	ca 08 00             	retf   0x8
    28e3:	c8 04 00 00          	enter  0x4,0x0
    28e7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28ea:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f0:	06                   	push   es
    28f1:	57                   	push   di
    28f2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28f5:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    28f9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28fc:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2900:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2907:	06                   	push   es
    2908:	57                   	push   di
    2909:	9a 75 29 23 29       	call   0x2923:0x2975
    290e:	c9                   	leave
    290f:	ca 08 00             	retf   0x8
    2912:	55                   	push   bp
    2913:	89 e5                	mov    bp,sp
    2915:	ff 76 08             	push   WORD PTR [bp+0x8]
    2918:	ff 76 06             	push   WORD PTR [bp+0x6]
    291b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    291e:	06                   	push   es
    291f:	57                   	push   di
    2920:	9a 38 1a 48 29       	call   0x2948:0x1a38
    2925:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2928:	ff 76 0a             	push   WORD PTR [bp+0xa]
    292b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    292e:	06                   	push   es
    292f:	57                   	push   di
    2930:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2933:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    293a:	26 f6 45 26 02       	test   BYTE PTR es:[di+0x26],0x2
    293f:	74 09                	je     0x294a
    2941:	6a 01                	push   0x1
    2943:	06                   	push   es
    2944:	57                   	push   di
    2945:	9a b3 1f 6f 29       	call   0x296f:0x1fb3
    294a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294d:	26 f6 45 26 08       	test   BYTE PTR es:[di+0x26],0x8
    2952:	74 0a                	je     0x295e
    2954:	06                   	push   es
    2955:	57                   	push   di
    2956:	b8 fd ff             	mov    ax,0xfffd
    2959:	9a 6a 20 5f 2b       	call   0x2b5f:0x206a
    295e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2961:	06                   	push   es
    2962:	57                   	push   di
    2963:	6a 00                	push   0x0
    2965:	6a 40                	push   0x40
    2967:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    296a:	06                   	push   es
    296b:	57                   	push   di
    296c:	9a f2 27 c5 29       	call   0x29c5:0x27f2
    2971:	c9                   	leave
    2972:	ca 08 00             	retf   0x8
    2975:	c8 06 00 00          	enter  0x6,0x0
    2979:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    297d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2980:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2985:	74 03                	je     0x298a
    2987:	e9 81 00             	jmp    0x2a0b
    298a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    298d:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2990:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2993:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2996:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2999:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    299c:	74 6d                	je     0x2a0b
    299e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    29a1:	26 8b 45 40          	mov    ax,WORD PTR es:[di+0x40]
    29a5:	26 0b 45 42          	or     ax,WORD PTR es:[di+0x42]
    29a9:	74 4d                	je     0x29f8
    29ab:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    29ae:	26 c4 7d 40          	les    di,DWORD PTR es:[di+0x40]
    29b2:	26 80 7d 25 00       	cmp    BYTE PTR es:[di+0x25],0x0
    29b7:	74 3f                	je     0x29f8
    29b9:	6a 00                	push   0x0
    29bb:	6a 00                	push   0x0
    29bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c0:	06                   	push   es
    29c1:	57                   	push   di
    29c2:	9a 38 1a 3b 2a       	call   0x2a3b:0x1a38
    29c7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    29ca:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    29cd:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    29d0:	26 c4 7d 40          	les    di,DWORD PTR es:[di+0x40]
    29d4:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    29d8:	26 89 55 28          	mov    WORD PTR es:[di+0x28],dx
    29dc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    29df:	ff 76 0a             	push   WORD PTR [bp+0xa]
    29e2:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    29e5:	26 c4 7d 40          	les    di,DWORD PTR es:[di+0x40]
    29e9:	06                   	push   es
    29ea:	57                   	push   di
    29eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29ee:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    29f2:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    29f6:	eb 13                	jmp    0x2a0b
    29f8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    29fb:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    29ff:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    2a03:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2a06:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2a09:	eb 8b                	jmp    0x2996
    2a0b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2a0e:	c9                   	leave
    2a0f:	ca 08 00             	retf   0x8
    2a12:	c8 08 00 00          	enter  0x8,0x0
    2a16:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2a19:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a1f:	06                   	push   es
    2a20:	57                   	push   di
    2a21:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a24:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2a28:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a2b:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2a2f:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2a33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a36:	06                   	push   es
    2a37:	57                   	push   di
    2a38:	9a d4 19 51 2a       	call   0x2a51:0x19d4
    2a3d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2a40:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2a43:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2a46:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2a49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4c:	06                   	push   es
    2a4d:	57                   	push   di
    2a4e:	9a 75 29 68 2a       	call   0x2a68:0x2975
    2a53:	08 c0                	or     al,al
    2a55:	75 13                	jne    0x2a6a
    2a57:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a5a:	06                   	push   es
    2a5b:	57                   	push   di
    2a5c:	6a 01                	push   0x1
    2a5e:	6a 00                	push   0x0
    2a60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a63:	06                   	push   es
    2a64:	57                   	push   di
    2a65:	9a f2 27 94 2a       	call   0x2a94:0x27f2
    2a6a:	c9                   	leave
    2a6b:	ca 08 00             	retf   0x8
    2a6e:	55                   	push   bp
    2a6f:	89 e5                	mov    bp,sp
    2a71:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2a74:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7a:	06                   	push   es
    2a7b:	57                   	push   di
    2a7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a7f:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2a83:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a86:	06                   	push   es
    2a87:	57                   	push   di
    2a88:	6a 01                	push   0x1
    2a8a:	6a 40                	push   0x40
    2a8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a8f:	06                   	push   es
    2a90:	57                   	push   di
    2a91:	9a f2 27 c0 2a       	call   0x2ac0:0x27f2
    2a96:	c9                   	leave
    2a97:	ca 08 00             	retf   0x8
    2a9a:	55                   	push   bp
    2a9b:	89 e5                	mov    bp,sp
    2a9d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2aa0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2aa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa6:	06                   	push   es
    2aa7:	57                   	push   di
    2aa8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2aab:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2aaf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ab2:	06                   	push   es
    2ab3:	57                   	push   di
    2ab4:	6a 02                	push   0x2
    2ab6:	6a 00                	push   0x0
    2ab8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2abb:	06                   	push   es
    2abc:	57                   	push   di
    2abd:	9a f2 27 ec 2a       	call   0x2aec:0x27f2
    2ac2:	c9                   	leave
    2ac3:	ca 08 00             	retf   0x8
    2ac6:	55                   	push   bp
    2ac7:	89 e5                	mov    bp,sp
    2ac9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2acc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2acf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad2:	06                   	push   es
    2ad3:	57                   	push   di
    2ad4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ad7:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2adb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ade:	06                   	push   es
    2adf:	57                   	push   di
    2ae0:	6a 02                	push   0x2
    2ae2:	6a 40                	push   0x40
    2ae4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae7:	06                   	push   es
    2ae8:	57                   	push   di
    2ae9:	9a f2 27 f5 2b       	call   0x2bf5:0x27f2
    2aee:	c9                   	leave
    2aef:	ca 08 00             	retf   0x8
    2af2:	55                   	push   bp
    2af3:	89 e5                	mov    bp,sp
    2af5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2af8:	26 8b 45 54          	mov    ax,WORD PTR es:[di+0x54]
    2afc:	09 c0                	or     ax,ax
    2afe:	74 1c                	je     0x2b1c
    2b00:	ff 76 08             	push   WORD PTR [bp+0x8]
    2b03:	ff 76 06             	push   WORD PTR [bp+0x6]
    2b06:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    2b09:	50                   	push   ax
    2b0a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b0d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b10:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    2b14:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    2b18:	26 ff 5d 52          	call   DWORD PTR es:[di+0x52]
    2b1c:	c9                   	leave
    2b1d:	ca 0a 00             	retf   0xa
    2b20:	c8 04 00 00          	enter  0x4,0x0
    2b24:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b27:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b2d:	06                   	push   es
    2b2e:	57                   	push   di
    2b2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b32:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2b36:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b39:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b3c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b3f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2b43:	9a 97 16 af 2b       	call   0x2baf:0x1697
    2b48:	50                   	push   ax
    2b49:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b4c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2b50:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2b54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b57:	06                   	push   es
    2b58:	57                   	push   di
    2b59:	b8 f9 ff             	mov    ax,0xfff9
    2b5c:	9a 6a 20 c8 2b       	call   0x2bc8:0x206a
    2b61:	c9                   	leave
    2b62:	ca 08 00             	retf   0x8
    2b65:	55                   	push   bp
    2b66:	89 e5                	mov    bp,sp
    2b68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b6b:	26 8b 45 5c          	mov    ax,WORD PTR es:[di+0x5c]
    2b6f:	09 c0                	or     ax,ax
    2b71:	74 20                	je     0x2b93
    2b73:	ff 76 08             	push   WORD PTR [bp+0x8]
    2b76:	ff 76 06             	push   WORD PTR [bp+0x6]
    2b79:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    2b7c:	50                   	push   ax
    2b7d:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    2b80:	50                   	push   ax
    2b81:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b84:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b87:	26 ff 75 60          	push   WORD PTR es:[di+0x60]
    2b8b:	26 ff 75 5e          	push   WORD PTR es:[di+0x5e]
    2b8f:	26 ff 5d 5a          	call   DWORD PTR es:[di+0x5a]
    2b93:	c9                   	leave
    2b94:	ca 0c 00             	retf   0xc
    2b97:	c8 04 00 00          	enter  0x4,0x0
    2b9b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b9e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2ba1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2ba4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ba7:	50                   	push   ax
    2ba8:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2bac:	9a 97 16 95 2e       	call   0x2e95:0x1697
    2bb1:	50                   	push   ax
    2bb2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2bb5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2bb9:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2bbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc0:	06                   	push   es
    2bc1:	57                   	push   di
    2bc2:	b8 f8 ff             	mov    ax,0xfff8
    2bc5:	9a 6a 20 36 2c       	call   0x2c36:0x206a
    2bca:	c9                   	leave
    2bcb:	ca 0a 00             	retf   0xa
    2bce:	c8 08 00 00          	enter  0x8,0x0
    2bd2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2bd5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2bd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bdb:	06                   	push   es
    2bdc:	57                   	push   di
    2bdd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2be0:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2be4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be7:	26 f6 45 26 02       	test   BYTE PTR es:[di+0x26],0x2
    2bec:	74 09                	je     0x2bf7
    2bee:	6a 00                	push   0x0
    2bf0:	06                   	push   es
    2bf1:	57                   	push   di
    2bf2:	9a b3 1f 47 2c       	call   0x2c47:0x1fb3
    2bf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bfa:	26 f6 45 28 02       	test   BYTE PTR es:[di+0x28],0x2
    2bff:	74 37                	je     0x2c38
    2c01:	26 80 65 28 fd       	and    BYTE PTR es:[di+0x28],0xfd
    2c06:	8d 7e f8             	lea    di,[bp-0x8]
    2c09:	16                   	push   ss
    2c0a:	57                   	push   di
    2c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c0e:	06                   	push   es
    2c0f:	57                   	push   di
    2c10:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c13:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    2c17:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c1a:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2c1e:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2c22:	9a 2b 43 00 00       	call   0x0:0x432b
    2c27:	09 c0                	or     ax,ax
    2c29:	74 0d                	je     0x2c38
    2c2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c2e:	06                   	push   es
    2c2f:	57                   	push   di
    2c30:	b8 fe ff             	mov    ax,0xfffe
    2c33:	9a 6a 20 70 2e       	call   0x2e70:0x206a
    2c38:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c3b:	06                   	push   es
    2c3c:	57                   	push   di
    2c3d:	6a 00                	push   0x0
    2c3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c42:	06                   	push   es
    2c43:	57                   	push   di
    2c44:	9a 97 2b 71 2c       	call   0x2c71:0x2b97
    2c49:	c9                   	leave
    2c4a:	ca 08 00             	retf   0x8
    2c4d:	55                   	push   bp
    2c4e:	89 e5                	mov    bp,sp
    2c50:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c53:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c59:	06                   	push   es
    2c5a:	57                   	push   di
    2c5b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c5e:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2c62:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c65:	06                   	push   es
    2c66:	57                   	push   di
    2c67:	6a 01                	push   0x1
    2c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c6c:	06                   	push   es
    2c6d:	57                   	push   di
    2c6e:	9a 97 2b 9b 2c       	call   0x2c9b:0x2b97
    2c73:	c9                   	leave
    2c74:	ca 08 00             	retf   0x8
    2c77:	55                   	push   bp
    2c78:	89 e5                	mov    bp,sp
    2c7a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c7d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c83:	06                   	push   es
    2c84:	57                   	push   di
    2c85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c88:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2c8c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c8f:	06                   	push   es
    2c90:	57                   	push   di
    2c91:	6a 02                	push   0x2
    2c93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c96:	06                   	push   es
    2c97:	57                   	push   di
    2c98:	9a 97 2b be 2c       	call   0x2cbe:0x2b97
    2c9d:	c9                   	leave
    2c9e:	ca 08 00             	retf   0x8
    2ca1:	55                   	push   bp
    2ca2:	89 e5                	mov    bp,sp
    2ca4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ca7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2caa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cad:	06                   	push   es
    2cae:	57                   	push   di
    2caf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cb2:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2cb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb9:	06                   	push   es
    2cba:	57                   	push   di
    2cbb:	9a 90 1f ce 2c       	call   0x2cce:0x1f90
    2cc0:	08 c0                	or     al,al
    2cc2:	74 26                	je     0x2cea
    2cc4:	6a 00                	push   0x0
    2cc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc9:	06                   	push   es
    2cca:	57                   	push   di
    2ccb:	9a b3 1f e8 2c       	call   0x2ce8:0x1fb3
    2cd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cd3:	26 f6 45 28 01       	test   BYTE PTR es:[di+0x28],0x1
    2cd8:	74 10                	je     0x2cea
    2cda:	68 02 02             	push   0x202
    2cdd:	6a 00                	push   0x0
    2cdf:	6a ff                	push   0xffff
    2ce1:	6a ff                	push   0xffff
    2ce3:	06                   	push   es
    2ce4:	57                   	push   di
    2ce5:	9a bb 24 1a 2d       	call   0x2d1a:0x24bb
    2cea:	c9                   	leave
    2ceb:	ca 08 00             	retf   0x8
    2cee:	55                   	push   bp
    2cef:	89 e5                	mov    bp,sp
    2cf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cf4:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2cf9:	75 21                	jne    0x2d1c
    2cfb:	6a 01                	push   0x1
    2cfd:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2d02:	74 07                	je     0x2d0b
    2d04:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    2d09:	75 04                	jne    0x2d0f
    2d0b:	b0 00                	mov    al,0x0
    2d0d:	eb 02                	jmp    0x2d11
    2d0f:	b0 01                	mov    al,0x1
    2d11:	50                   	push   ax
    2d12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d15:	06                   	push   es
    2d16:	57                   	push   di
    2d17:	9a b3 21 7a 2d       	call   0x2d7a:0x21b3
    2d1c:	c9                   	leave
    2d1d:	ca 08 00             	retf   0x8
    2d20:	55                   	push   bp
    2d21:	89 e5                	mov    bp,sp
    2d23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d26:	06                   	push   es
    2d27:	57                   	push   di
    2d28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d2b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2d2f:	c9                   	leave
    2d30:	ca 08 00             	retf   0x8
    2d33:	55                   	push   bp
    2d34:	89 e5                	mov    bp,sp
    2d36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d39:	06                   	push   es
    2d3a:	57                   	push   di
    2d3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d3e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2d42:	c9                   	leave
    2d43:	ca 08 00             	retf   0x8
    2d46:	55                   	push   bp
    2d47:	89 e5                	mov    bp,sp
    2d49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d4c:	06                   	push   es
    2d4d:	57                   	push   di
    2d4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d51:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2d55:	c9                   	leave
    2d56:	ca 08 00             	retf   0x8
    2d59:	55                   	push   bp
    2d5a:	89 e5                	mov    bp,sp
    2d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d5f:	26 80 7d 2c 00       	cmp    BYTE PTR es:[di+0x2c],0x0
    2d64:	74 1e                	je     0x2d84
    2d66:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2d6a:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2d6e:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    2d72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d75:	06                   	push   es
    2d76:	57                   	push   di
    2d77:	9a d5 1e a6 2d       	call   0x2da6:0x1ed5
    2d7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7f:	26 c6 45 2c 01       	mov    BYTE PTR es:[di+0x2c],0x1
    2d84:	c9                   	leave
    2d85:	ca 08 00             	retf   0x8
    2d88:	55                   	push   bp
    2d89:	89 e5                	mov    bp,sp
    2d8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d8e:	26 80 7d 49 00       	cmp    BYTE PTR es:[di+0x49],0x0
    2d93:	74 1b                	je     0x2db0
    2d95:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2d99:	26 8a 45 48          	mov    al,BYTE PTR es:[di+0x48]
    2d9d:	50                   	push   ax
    2d9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da1:	06                   	push   es
    2da2:	57                   	push   di
    2da3:	9a 72 1e d5 2d       	call   0x2dd5:0x1e72
    2da8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dab:	26 c6 45 49 01       	mov    BYTE PTR es:[di+0x49],0x1
    2db0:	c9                   	leave
    2db1:	ca 08 00             	retf   0x8
    2db4:	55                   	push   bp
    2db5:	89 e5                	mov    bp,sp
    2db7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dba:	26 80 7d 2b 00       	cmp    BYTE PTR es:[di+0x2b],0x0
    2dbf:	74 1e                	je     0x2ddf
    2dc1:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2dc5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2dc9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd0:	06                   	push   es
    2dd1:	57                   	push   di
    2dd2:	9a eb 1d 1d 2e       	call   0x2e1d:0x1deb
    2dd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dda:	26 c6 45 2b 01       	mov    BYTE PTR es:[di+0x2b],0x1
    2ddf:	c9                   	leave
    2de0:	ca 08 00             	retf   0x8
    2de3:	55                   	push   bp
    2de4:	89 e5                	mov    bp,sp
    2de6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2de9:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    2def:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    2df5:	c9                   	leave
    2df6:	ca 08 00             	retf   0x8
    2df9:	55                   	push   bp
    2dfa:	89 e5                	mov    bp,sp
    2dfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dff:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2e03:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2e07:	74 16                	je     0x2e1f
    2e09:	68 13 0f             	push   0xf13
    2e0c:	6a 00                	push   0x0
    2e0e:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e11:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e14:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2e18:	06                   	push   es
    2e19:	57                   	push   di
    2e1a:	9a bb 24 47 2e       	call   0x2e47:0x24bb
    2e1f:	c9                   	leave
    2e20:	ca 08 00             	retf   0x8
    2e23:	55                   	push   bp
    2e24:	89 e5                	mov    bp,sp
    2e26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e29:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2e2d:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2e31:	74 16                	je     0x2e49
    2e33:	68 14 0f             	push   0xf14
    2e36:	6a 00                	push   0x0
    2e38:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e3b:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e3e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2e42:	06                   	push   es
    2e43:	57                   	push   di
    2e44:	9a bb 24 83 2e       	call   0x2e83:0x24bb
    2e49:	c9                   	leave
    2e4a:	ca 08 00             	retf   0x8
    2e4d:	55                   	push   bp
    2e4e:	89 e5                	mov    bp,sp
    2e50:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e53:	31 c0                	xor    ax,ax
    2e55:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2e59:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    2e5d:	c9                   	leave
    2e5e:	ca 08 00             	retf   0x8
    2e61:	55                   	push   bp
    2e62:	89 e5                	mov    bp,sp
    2e64:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2e68:	74 08                	je     0x2e72
    2e6a:	83 ec 08             	sub    sp,0x8
    2e6d:	9a e2 1f 8b 2f       	call   0x2f8b:0x1fe2
    2e72:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2e75:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e78:	31 c0                	xor    ax,ax
    2e7a:	50                   	push   ax
    2e7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e7e:	06                   	push   es
    2e7f:	57                   	push   di
    2e80:	9a 9b 13 8e 2e       	call   0x2e8e:0x139b
    2e85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e88:	06                   	push   es
    2e89:	57                   	push   di
    2e8a:	bf 1c 42             	mov    di,0x421c
    2e8d:	b8 1e 2f             	mov    ax,0x2f1e
    2e90:	50                   	push   ax
    2e91:	57                   	push   di
    2e92:	9a 89 14 a9 2f       	call   0x2fa9:0x1489
    2e97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9a:	26 89 85 8a 00       	mov    WORD PTR es:[di+0x8a],ax
    2e9f:	26 89 95 8c 00       	mov    WORD PTR es:[di+0x8c],dx
    2ea4:	b0 01                	mov    al,0x1
    2ea6:	50                   	push   ax
    2ea7:	b8 d4 04             	mov    ax,0x4d4
    2eaa:	ba b2 2e             	mov    dx,0x2eb2
    2ead:	52                   	push   dx
    2eae:	50                   	push   ax
    2eaf:	9a 27 15 d3 2e       	call   0x2ed3:0x1527
    2eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb7:	26 89 85 9e 00       	mov    WORD PTR es:[di+0x9e],ax
    2ebc:	26 89 95 a0 00       	mov    WORD PTR es:[di+0xa0],dx
    2ec1:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2ec5:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    2ec9:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    2ece:	06                   	push   es
    2ecf:	57                   	push   di
    2ed0:	9a 84 16 02 3e       	call   0x3e02:0x1684
    2ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed8:	26 c6 85 a6 00 01    	mov    BYTE PTR es:[di+0xa6],0x1
    2ede:	26 c7 85 a8 00 ff ff 	mov    WORD PTR es:[di+0xa8],0xffff
    2ee5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2ee9:	74 07                	je     0x2ef2
    2eeb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2eef:	83 c4 06             	add    sp,0x6
    2ef2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2ef5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2ef8:	c9                   	leave
    2ef9:	ca 0a 00             	retf   0xa
    2efc:	c8 06 00 00          	enter  0x6,0x0
    2f00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f03:	06                   	push   es
    2f04:	57                   	push   di
    2f05:	9a a5 4e ea 2f       	call   0x2fea:0x4ea5
    2f0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f0d:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2f11:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    2f15:	74 09                	je     0x2f20
    2f17:	6a 01                	push   0x1
    2f19:	06                   	push   es
    2f1a:	57                   	push   di
    2f1b:	9a 52 37 3c 2f       	call   0x2f3c:0x3752
    2f20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f23:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    2f29:	74 09                	je     0x2f34
    2f2b:	06                   	push   es
    2f2c:	57                   	push   di
    2f2d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f30:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    2f34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f37:	06                   	push   es
    2f38:	57                   	push   di
    2f39:	9a fd 39 55 2f       	call   0x2f55:0x39fd
    2f3e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f41:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2f45:	74 37                	je     0x2f7e
    2f47:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    2f4a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f50:	06                   	push   es
    2f51:	57                   	push   di
    2f52:	9a 8f 39 6b 2f       	call   0x2f6b:0x398f
    2f57:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2f5a:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2f5d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2f60:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2f63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f66:	06                   	push   es
    2f67:	57                   	push   di
    2f68:	9a f6 37 b6 2f       	call   0x2fb6:0x37f6
    2f6d:	b0 01                	mov    al,0x1
    2f6f:	50                   	push   ax
    2f70:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2f73:	06                   	push   es
    2f74:	57                   	push   di
    2f75:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f78:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    2f7c:	eb c3                	jmp    0x2f41
    2f7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f81:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    2f86:	06                   	push   es
    2f87:	57                   	push   di
    2f88:	9a 7f 1f c1 2f       	call   0x2fc1:0x1f7f
    2f8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f90:	26 8b 85 8a 00       	mov    ax,WORD PTR es:[di+0x8a]
    2f95:	26 0b 85 8c 00       	or     ax,WORD PTR es:[di+0x8c]
    2f9a:	74 0f                	je     0x2fab
    2f9c:	26 ff b5 8c 00       	push   WORD PTR es:[di+0x8c]
    2fa1:	26 ff b5 8a 00       	push   WORD PTR es:[di+0x8a]
    2fa6:	9a a5 15 5f 37       	call   0x375f:0x15a5
    2fab:	31 c0                	xor    ax,ax
    2fad:	50                   	push   ax
    2fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb1:	06                   	push   es
    2fb2:	57                   	push   di
    2fb3:	9a 58 14 cb 2f       	call   0x2fcb:0x1458
    2fb8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2fbc:	74 05                	je     0x2fc3
    2fbe:	9a 0f 20 f1 2f       	call   0x2ff1:0x200f
    2fc3:	c9                   	leave
    2fc4:	ca 06 00             	retf   0x6
    2fc7:	00 00                	add    BYTE PTR [bx+si],al
    2fc9:	d7                   	xlat   BYTE PTR ds:[bx]
    2fca:	30 c1                	xor    cl,al
    2fcc:	30 c8                	xor    al,cl
    2fce:	10 00                	adc    BYTE PTR [bx+si],al
    2fd0:	00 c4                	add    ah,al
    2fd2:	7e 06                	jle    0x2fda
    2fd4:	26 8b 85 96 00       	mov    ax,WORD PTR es:[di+0x96]
    2fd9:	26 0b 85 98 00       	or     ax,WORD PTR es:[di+0x98]
    2fde:	75 03                	jne    0x2fe3
    2fe0:	e9 ff 00             	jmp    0x30e2
    2fe3:	b0 01                	mov    al,0x1
    2fe5:	50                   	push   ax
    2fe6:	b8 a3 02             	mov    ax,0x2a3
    2fe9:	ba 21 30             	mov    dx,0x3021
    2fec:	52                   	push   dx
    2fed:	50                   	push   ax
    2fee:	9a 50 1f df 30       	call   0x30df:0x1f50
    2ff3:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2ff6:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2ff9:	b8 c7 2f             	mov    ax,0x2fc7
    2ffc:	0e                   	push   cs
    2ffd:	50                   	push   ax
    2ffe:	55                   	push   bp
    2fff:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3003:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300a:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    300f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3013:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3016:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3019:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    301c:	06                   	push   es
    301d:	57                   	push   di
    301e:	9a 8b 10 49 30       	call   0x3049:0x108b
    3023:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3026:	48                   	dec    ax
    3027:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    302a:	31 c0                	xor    ax,ax
    302c:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    302f:	7f 54                	jg     0x3085
    3031:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3034:	eb 03                	jmp    0x3039
    3036:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3039:	ff 76 fc             	push   WORD PTR [bp-0x4]
    303c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303f:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    3044:	06                   	push   es
    3045:	57                   	push   di
    3046:	9a d0 0d 7b 30       	call   0x307b:0xdd0
    304b:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    304e:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3051:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3054:	26 8b 85 a8 00       	mov    ax,WORD PTR es:[di+0xa8]
    3059:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    305c:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    3060:	7c 1b                	jl     0x307d
    3062:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3065:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    3068:	7d 13                	jge    0x307d
    306a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    306d:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3070:	ff 76 f2             	push   WORD PTR [bp-0xe]
    3073:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3076:	06                   	push   es
    3077:	57                   	push   di
    3078:	9a 67 0f a6 30       	call   0x30a6:0xf67
    307d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3080:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    3083:	75 b1                	jne    0x3036
    3085:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3088:	48                   	dec    ax
    3089:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    308c:	31 c0                	xor    ax,ax
    308e:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    3091:	7f 38                	jg     0x30cb
    3093:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3096:	eb 03                	jmp    0x309b
    3098:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    309b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    309e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    30a1:	06                   	push   es
    30a2:	57                   	push   di
    30a3:	9a d0 0d bf 31       	call   0x31bf:0xdd0
    30a8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    30ab:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    30ae:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    30b1:	0b 46 f4             	or     ax,WORD PTR [bp-0xc]
    30b4:	74 0d                	je     0x30c3
    30b6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    30b9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    30bc:	06                   	push   es
    30bd:	57                   	push   di
    30be:	9a de 63 ea 30       	call   0x30ea:0x63de
    30c3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    30c6:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    30c9:	75 cd                	jne    0x3098
    30cb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    30cf:	83 c4 06             	add    sp,0x6
    30d2:	b8 e2 30             	mov    ax,0x30e2
    30d5:	0e                   	push   cs
    30d6:	50                   	push   ax
    30d7:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    30da:	06                   	push   es
    30db:	57                   	push   di
    30dc:	9a 7f 1f de 35       	call   0x35de:0x1f7f
    30e1:	cb                   	retf
    30e2:	c9                   	leave
    30e3:	ca 04 00             	retf   0x4
    30e6:	00 00                	add    BYTE PTR [bx+si],al
    30e8:	23 31                	and    si,WORD PTR [bx+di]
    30ea:	f7 30                	div    WORD PTR [bx+si]
    30ec:	55                   	push   bp
    30ed:	89 e5                	mov    bp,sp
    30ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f2:	06                   	push   es
    30f3:	57                   	push   di
    30f4:	9a c5 36 15 31       	call   0x3115:0x36c5
    30f9:	b8 e6 30             	mov    ax,0x30e6
    30fc:	0e                   	push   cs
    30fd:	50                   	push   ax
    30fe:	55                   	push   bp
    30ff:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3103:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3107:	ff 76 0c             	push   WORD PTR [bp+0xc]
    310a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    310d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3110:	06                   	push   es
    3111:	57                   	push   di
    3112:	9a 98 15 2b 31       	call   0x312b:0x1598
    3117:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    311b:	83 c4 06             	add    sp,0x6
    311e:	b8 2e 31             	mov    ax,0x312e
    3121:	0e                   	push   cs
    3122:	50                   	push   ax
    3123:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3126:	06                   	push   es
    3127:	57                   	push   di
    3128:	9a d4 36 36 31       	call   0x3136:0x36d4
    312d:	cb                   	retf
    312e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3131:	06                   	push   es
    3132:	57                   	push   di
    3133:	9a cd 2f 53 31       	call   0x3153:0x2fcd
    3138:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    313b:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    313f:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    3143:	74 10                	je     0x3155
    3145:	68 11 0f             	push   0xf11
    3148:	6a 00                	push   0x0
    314a:	6a 00                	push   0x0
    314c:	6a 00                	push   0x0
    314e:	06                   	push   es
    314f:	57                   	push   di
    3150:	9a bb 24 5d 31       	call   0x315d:0x24bb
    3155:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3158:	06                   	push   es
    3159:	57                   	push   di
    315a:	9a a5 41 6f 31       	call   0x316f:0x41a5
    315f:	c9                   	leave
    3160:	ca 08 00             	retf   0x8
    3163:	c8 08 00 00          	enter  0x8,0x0
    3167:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    316a:	06                   	push   es
    316b:	57                   	push   di
    316c:	9a fd 39 8f 31       	call   0x318f:0x39fd
    3171:	48                   	dec    ax
    3172:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3175:	31 c0                	xor    ax,ax
    3177:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    317a:	7f 4d                	jg     0x31c9
    317c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    317f:	eb 03                	jmp    0x3184
    3181:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3184:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    318a:	06                   	push   es
    318b:	57                   	push   di
    318c:	9a 8f 39 e1 33       	call   0x33e1:0x398f
    3191:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3194:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3197:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    319a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    319e:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    31a2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31a5:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    31a9:	75 16                	jne    0x31c1
    31ab:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    31af:	75 10                	jne    0x31c1
    31b1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    31b4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    31b7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31ba:	06                   	push   es
    31bb:	57                   	push   di
    31bc:	9a 2a 43 f7 33       	call   0x33f7:0x432a
    31c1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    31c4:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    31c7:	75 b8                	jne    0x3181
    31c9:	c9                   	leave
    31ca:	ca 08 00             	retf   0x8
    31cd:	c8 02 00 00          	enter  0x2,0x0
    31d1:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    31d5:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    31d8:	3c 01                	cmp    al,0x1
    31da:	75 18                	jne    0x31f4
    31dc:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    31df:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    31e3:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    31e6:	26 3b 45 20          	cmp    ax,WORD PTR es:[di+0x20]
    31ea:	b0 00                	mov    al,0x0
    31ec:	7d 01                	jge    0x31ef
    31ee:	40                   	inc    ax
    31ef:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    31f2:	eb 76                	jmp    0x326a
    31f4:	3c 02                	cmp    al,0x2
    31f6:	75 2a                	jne    0x3222
    31f8:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    31fb:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    31ff:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3202:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3206:	8b d0                	mov    dx,ax
    3208:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    320b:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    320f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3212:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3216:	3b c2                	cmp    ax,dx
    3218:	b0 00                	mov    al,0x0
    321a:	7e 01                	jle    0x321d
    321c:	40                   	inc    ax
    321d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3220:	eb 48                	jmp    0x326a
    3222:	3c 03                	cmp    al,0x3
    3224:	75 18                	jne    0x323e
    3226:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3229:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    322d:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3230:	26 3b 45 1e          	cmp    ax,WORD PTR es:[di+0x1e]
    3234:	b0 00                	mov    al,0x0
    3236:	7d 01                	jge    0x3239
    3238:	40                   	inc    ax
    3239:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    323c:	eb 2c                	jmp    0x326a
    323e:	3c 04                	cmp    al,0x4
    3240:	75 28                	jne    0x326a
    3242:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3245:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3249:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    324c:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    3250:	8b d0                	mov    dx,ax
    3252:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3255:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3259:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    325c:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    3260:	3b c2                	cmp    ax,dx
    3262:	b0 00                	mov    al,0x0
    3264:	7e 01                	jle    0x3267
    3266:	40                   	inc    ax
    3267:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    326a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    326d:	c9                   	leave
    326e:	c2 0c 00             	ret    0xc
    3271:	14 33                	adc    al,0x33
    3273:	47                   	inc    di
    3274:	33 6e 33             	xor    bp,WORD PTR [bp+0x33]
    3277:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    3278:	33 d0                	xor    dx,ax
    327a:	33 c8                	xor    cx,ax
    327c:	04 00                	add    al,0x0
    327e:	00 8b 7e 04          	add    BYTE PTR [bp+di+0x47e],cl
    3282:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    3286:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3289:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    328c:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    328f:	3c 01                	cmp    al,0x1
    3291:	75 10                	jne    0x32a3
    3293:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3296:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    329a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    329d:	26 01 45 02          	add    WORD PTR es:[di+0x2],ax
    32a1:	eb 39                	jmp    0x32dc
    32a3:	3c 02                	cmp    al,0x2
    32a5:	75 10                	jne    0x32b7
    32a7:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    32aa:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    32ae:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32b1:	26 29 45 06          	sub    WORD PTR es:[di+0x6],ax
    32b5:	eb 25                	jmp    0x32dc
    32b7:	3c 03                	cmp    al,0x3
    32b9:	75 0f                	jne    0x32ca
    32bb:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    32be:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    32c2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32c5:	26 01 05             	add    WORD PTR es:[di],ax
    32c8:	eb 12                	jmp    0x32dc
    32ca:	3c 04                	cmp    al,0x4
    32cc:	75 0e                	jne    0x32dc
    32ce:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    32d1:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    32d5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32d8:	26 29 45 04          	sub    WORD PTR es:[di+0x4],ax
    32dc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    32df:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    32e3:	06                   	push   es
    32e4:	57                   	push   di
    32e5:	9a ff ff 00 00       	call   0x0:0xffff
    32ea:	09 c0                	or     ax,ax
    32ec:	74 03                	je     0x32f1
    32ee:	e9 f2 00             	jmp    0x33e3
    32f1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    32f4:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    32f8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    32fb:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    32fe:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    3301:	2c 01                	sub    al,0x1
    3303:	3c 04                	cmp    al,0x4
    3305:	76 03                	jbe    0x330a
    3307:	e9 d9 00             	jmp    0x33e3
    330a:	98                   	cbw
    330b:	89 c3                	mov    bx,ax
    330d:	d1 e3                	shl    bx,1
    330f:	2e ff a7 71 32       	jmp    WORD PTR cs:[bx+0x3271]
    3314:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3317:	26 ff 35             	push   WORD PTR es:[di]
    331a:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    331e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3321:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    3325:	50                   	push   ax
    3326:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3329:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    332d:	26 2b 05             	sub    ax,WORD PTR es:[di]
    3330:	50                   	push   ax
    3331:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3334:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    3338:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    333b:	06                   	push   es
    333c:	57                   	push   di
    333d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3340:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    3344:	e9 9c 00             	jmp    0x33e3
    3347:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    334a:	26 ff 35             	push   WORD PTR es:[di]
    334d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3351:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3355:	26 2b 05             	sub    ax,WORD PTR es:[di]
    3358:	50                   	push   ax
    3359:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    335c:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    3360:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3363:	06                   	push   es
    3364:	57                   	push   di
    3365:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3368:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    336c:	eb 75                	jmp    0x33e3
    336e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3371:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3374:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3377:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    337b:	50                   	push   ax
    337c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    337f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3383:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3386:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    338a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    338d:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    3391:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    3395:	50                   	push   ax
    3396:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3399:	06                   	push   es
    339a:	57                   	push   di
    339b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    339e:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    33a2:	eb 3f                	jmp    0x33e3
    33a4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33a7:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    33ab:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    33af:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    33b2:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    33b6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33b9:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    33bd:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    33c1:	50                   	push   ax
    33c2:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    33c5:	06                   	push   es
    33c6:	57                   	push   di
    33c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33ca:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    33ce:	eb 13                	jmp    0x33e3
    33d0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    33d3:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    33d7:	06                   	push   es
    33d8:	57                   	push   di
    33d9:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    33dc:	06                   	push   es
    33dd:	57                   	push   di
    33de:	9a 49 18 51 34       	call   0x3451:0x1849
    33e3:	c9                   	leave
    33e4:	c2 08 00             	ret    0x8
    33e7:	c8 0a 00 00          	enter  0xa,0x0
    33eb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    33ee:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    33f2:	06                   	push   es
    33f3:	57                   	push   di
    33f4:	9a 75 0c 43 34       	call   0x3443:0xc75
    33f9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    33fc:	36 8b 45 0e          	mov    ax,WORD PTR ss:[di+0xe]
    3400:	36 0b 45 10          	or     ax,WORD PTR ss:[di+0x10]
    3404:	74 3f                	je     0x3445
    3406:	36 c4 7d 0e          	les    di,DWORD PTR ss:[di+0xe]
    340a:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    340f:	75 0e                	jne    0x341f
    3411:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3414:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3418:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    341d:	74 26                	je     0x3445
    341f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3422:	36 c4 7d 0e          	les    di,DWORD PTR ss:[di+0xe]
    3426:	26 8a 45 2d          	mov    al,BYTE PTR es:[di+0x2d]
    342a:	3a 46 06             	cmp    al,BYTE PTR [bp+0x6]
    342d:	75 16                	jne    0x3445
    342f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3432:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    3436:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    343a:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    343e:	06                   	push   es
    343f:	57                   	push   di
    3440:	9a 2b 0c e8 34       	call   0x34e8:0xc2b
    3445:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3448:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    344c:	06                   	push   es
    344d:	57                   	push   di
    344e:	9a fd 39 78 34       	call   0x3478:0x39fd
    3453:	48                   	dec    ax
    3454:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3457:	31 c0                	xor    ax,ax
    3459:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    345c:	7e 03                	jle    0x3461
    345e:	e9 c1 00             	jmp    0x3522
    3461:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3464:	eb 03                	jmp    0x3469
    3466:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3469:	ff 76 fe             	push   WORD PTR [bp-0x2]
    346c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    346f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3473:	06                   	push   es
    3474:	57                   	push   di
    3475:	9a 8f 39 7e 35       	call   0x357e:0x398f
    347a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    347d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3480:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3483:	26 8a 45 2d          	mov    al,BYTE PTR es:[di+0x2d]
    3487:	3a 46 06             	cmp    al,BYTE PTR [bp+0x6]
    348a:	74 03                	je     0x348f
    348c:	e9 88 00             	jmp    0x3517
    348f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3492:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3497:	75 0e                	jne    0x34a7
    3499:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    349c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    34a0:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    34a5:	74 70                	je     0x3517
    34a7:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    34aa:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    34ad:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    34b0:	36 3b 55 10          	cmp    dx,WORD PTR ss:[di+0x10]
    34b4:	75 08                	jne    0x34be
    34b6:	36 3b 45 0e          	cmp    ax,WORD PTR ss:[di+0xe]
    34ba:	75 02                	jne    0x34be
    34bc:	eb 59                	jmp    0x3517
    34be:	31 c0                	xor    ax,ax
    34c0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34c3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    34c6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    34c9:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    34cd:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    34d1:	7d 2d                	jge    0x3500
    34d3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    34d6:	ff 76 f8             	push   WORD PTR [bp-0x8]
    34d9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    34dc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    34df:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    34e3:	06                   	push   es
    34e4:	57                   	push   di
    34e5:	9a d0 0d 15 35       	call   0x3515:0xdd0
    34ea:	52                   	push   dx
    34eb:	50                   	push   ax
    34ec:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    34ef:	50                   	push   ax
    34f0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    34f3:	57                   	push   di
    34f4:	e8 d6 fc             	call   0x31cd
    34f7:	08 c0                	or     al,al
    34f9:	75 05                	jne    0x3500
    34fb:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    34fe:	eb c3                	jmp    0x34c3
    3500:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3503:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3506:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3509:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    350c:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    3510:	06                   	push   es
    3511:	57                   	push   di
    3512:	9a a7 0e 4f 35       	call   0x354f:0xea7
    3517:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    351a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    351d:	74 03                	je     0x3522
    351f:	e9 44 ff             	jmp    0x3466
    3522:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3525:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    3529:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    352d:	48                   	dec    ax
    352e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3531:	31 c0                	xor    ax,ax
    3533:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    3536:	7f 2e                	jg     0x3566
    3538:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    353b:	eb 03                	jmp    0x3540
    353d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3540:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3543:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3546:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    354a:	06                   	push   es
    354b:	57                   	push   di
    354c:	9a d0 0d d7 35       	call   0x35d7:0xdd0
    3551:	52                   	push   dx
    3552:	50                   	push   ax
    3553:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    3556:	50                   	push   ax
    3557:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    355a:	57                   	push   di
    355b:	e8 1d fd             	call   0x327b
    355e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3561:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    3564:	75 d7                	jne    0x353d
    3566:	c9                   	leave
    3567:	c2 04 00             	ret    0x4
    356a:	c8 04 00 00          	enter  0x4,0x0
    356e:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    3572:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3575:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3579:	06                   	push   es
    357a:	57                   	push   di
    357b:	9a fd 39 9c 35       	call   0x359c:0x39fd
    3580:	48                   	dec    ax
    3581:	09 c0                	or     ax,ax
    3583:	7c 2c                	jl     0x35b1
    3585:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3588:	eb 03                	jmp    0x358d
    358a:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    358d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3590:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3593:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3597:	06                   	push   es
    3598:	57                   	push   di
    3599:	9a 8f 39 c0 35       	call   0x35c0:0x398f
    359e:	89 c7                	mov    di,ax
    35a0:	8e c2                	mov    es,dx
    35a2:	26 80 7d 2d 00       	cmp    BYTE PTR es:[di+0x2d],0x0
    35a7:	74 02                	je     0x35ab
    35a9:	eb 0a                	jmp    0x35b5
    35ab:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    35af:	75 d9                	jne    0x358a
    35b1:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    35b5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    35b8:	c9                   	leave
    35b9:	c2 02 00             	ret    0x2
    35bc:	00 00                	add    BYTE PTR [bx+si],al
    35be:	1e                   	push   ds
    35bf:	36 31 36 c8 04       	xor    WORD PTR ss:0x4c8,si
    35c4:	00 00                	add    BYTE PTR [bx+si],al
    35c6:	55                   	push   bp
    35c7:	e8 a0 ff             	call   0x356a
    35ca:	08 c0                	or     al,al
    35cc:	75 02                	jne    0x35d0
    35ce:	eb 59                	jmp    0x3629
    35d0:	b0 01                	mov    al,0x1
    35d2:	50                   	push   ax
    35d3:	b8 a3 02             	mov    ax,0x2a3
    35d6:	ba cd 39             	mov    dx,0x39cd
    35d9:	52                   	push   dx
    35da:	50                   	push   ax
    35db:	9a 50 1f 26 36       	call   0x3626:0x1f50
    35e0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    35e3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    35e6:	b8 bc 35             	mov    ax,0x35bc
    35e9:	0e                   	push   cs
    35ea:	50                   	push   ax
    35eb:	55                   	push   bp
    35ec:	ff 36 58 18          	push   WORD PTR ds:0x1858
    35f0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    35f4:	6a 01                	push   0x1
    35f6:	55                   	push   bp
    35f7:	e8 ed fd             	call   0x33e7
    35fa:	6a 02                	push   0x2
    35fc:	55                   	push   bp
    35fd:	e8 e7 fd             	call   0x33e7
    3600:	6a 03                	push   0x3
    3602:	55                   	push   bp
    3603:	e8 e1 fd             	call   0x33e7
    3606:	6a 04                	push   0x4
    3608:	55                   	push   bp
    3609:	e8 db fd             	call   0x33e7
    360c:	6a 05                	push   0x5
    360e:	55                   	push   bp
    360f:	e8 d5 fd             	call   0x33e7
    3612:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3616:	83 c4 06             	add    sp,0x6
    3619:	b8 29 36             	mov    ax,0x3629
    361c:	0e                   	push   cs
    361d:	50                   	push   ax
    361e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3621:	06                   	push   es
    3622:	57                   	push   di
    3623:	9a 7f 1f 8c 36       	call   0x368c:0x1f7f
    3628:	cb                   	retf
    3629:	c9                   	leave
    362a:	ca 0c 00             	retf   0xc
    362d:	00 00                	add    BYTE PTR [bx+si],al
    362f:	b1 36                	mov    cl,0x36
    3631:	3f                   	aas
    3632:	36 c8 10 00 00       	ss enter 0x10,0x0
    3637:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    363a:	06                   	push   es
    363b:	57                   	push   di
    363c:	9a fa 64 61 36       	call   0x3661:0x64fa
    3641:	08 c0                	or     al,al
    3643:	75 02                	jne    0x3647
    3645:	eb 7a                	jmp    0x36c1
    3647:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    364a:	26 83 bd aa 00 00    	cmp    WORD PTR es:[di+0xaa],0x0
    3650:	74 07                	je     0x3659
    3652:	26 80 4d 28 10       	or     BYTE PTR es:[di+0x28],0x10
    3657:	eb 68                	jmp    0x36c1
    3659:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    365c:	06                   	push   es
    365d:	57                   	push   di
    365e:	9a c5 36 be 36       	call   0x36be:0x36c5
    3663:	b8 2d 36             	mov    ax,0x362d
    3666:	0e                   	push   cs
    3667:	50                   	push   ax
    3668:	55                   	push   bp
    3669:	ff 36 58 18          	push   WORD PTR ds:0x1858
    366d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3671:	8d 7e f0             	lea    di,[bp-0x10]
    3674:	16                   	push   ss
    3675:	57                   	push   di
    3676:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3679:	06                   	push   es
    367a:	57                   	push   di
    367b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    367e:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    3682:	8d 7e f8             	lea    di,[bp-0x8]
    3685:	16                   	push   ss
    3686:	57                   	push   di
    3687:	6a 08                	push   0x8
    3689:	9a 1b 16 a3 37       	call   0x37a3:0x161b
    368e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3691:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3694:	8d 7e f8             	lea    di,[bp-0x8]
    3697:	16                   	push   ss
    3698:	57                   	push   di
    3699:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    369c:	06                   	push   es
    369d:	57                   	push   di
    369e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36a1:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    36a5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    36a9:	83 c4 06             	add    sp,0x6
    36ac:	b8 c1 36             	mov    ax,0x36c1
    36af:	0e                   	push   cs
    36b0:	50                   	push   ax
    36b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b4:	26 80 65 28 ef       	and    BYTE PTR es:[di+0x28],0xef
    36b9:	06                   	push   es
    36ba:	57                   	push   di
    36bb:	9a d4 36 f3 36       	call   0x36f3:0x36d4
    36c0:	cb                   	retf
    36c1:	c9                   	leave
    36c2:	ca 08 00             	retf   0x8
    36c5:	55                   	push   bp
    36c6:	89 e5                	mov    bp,sp
    36c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36cb:	26 ff 85 aa 00       	inc    WORD PTR es:[di+0xaa]
    36d0:	c9                   	leave
    36d1:	ca 04 00             	retf   0x4
    36d4:	55                   	push   bp
    36d5:	89 e5                	mov    bp,sp
    36d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36da:	26 ff 8d aa 00       	dec    WORD PTR es:[di+0xaa]
    36df:	26 83 bd aa 00 00    	cmp    WORD PTR es:[di+0xaa],0x0
    36e5:	75 0e                	jne    0x36f5
    36e7:	26 f6 45 28 10       	test   BYTE PTR es:[di+0x28],0x10
    36ec:	74 07                	je     0x36f5
    36ee:	06                   	push   es
    36ef:	57                   	push   di
    36f0:	9a f9 36 08 37       	call   0x3708:0x36f9
    36f5:	c9                   	leave
    36f6:	ca 04 00             	retf   0x4
    36f9:	55                   	push   bp
    36fa:	89 e5                	mov    bp,sp
    36fc:	6a 00                	push   0x0
    36fe:	6a 00                	push   0x0
    3700:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3703:	06                   	push   es
    3704:	57                   	push   di
    3705:	9a 33 36 9c 37       	call   0x379c:0x3633
    370a:	c9                   	leave
    370b:	ca 04 00             	retf   0x4
    370e:	c8 02 00 00          	enter  0x2,0x0
    3712:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3715:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3718:	74 23                	je     0x373d
    371a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    371d:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3720:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    3723:	75 05                	jne    0x372a
    3725:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    3728:	74 13                	je     0x373d
    372a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    372d:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3731:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    3735:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    3738:	89 56 0c             	mov    WORD PTR [bp+0xc],dx
    373b:	eb d5                	jmp    0x3712
    373d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3740:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3743:	b0 00                	mov    al,0x0
    3745:	74 01                	je     0x3748
    3747:	40                   	inc    ax
    3748:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    374b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    374e:	c9                   	leave
    374f:	ca 08 00             	retf   0x8
    3752:	c8 04 00 00          	enter  0x4,0x0
    3756:	ff 76 08             	push   WORD PTR [bp+0x8]
    3759:	ff 76 06             	push   WORD PTR [bp+0x6]
    375c:	9a a8 17 81 37       	call   0x3781:0x17a8
    3761:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3764:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3767:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    376a:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    376d:	74 14                	je     0x3783
    376f:	ff 76 08             	push   WORD PTR [bp+0x8]
    3772:	ff 76 06             	push   WORD PTR [bp+0x6]
    3775:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3778:	50                   	push   ax
    3779:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    377c:	06                   	push   es
    377d:	57                   	push   di
    377e:	9a 81 40 b2 41       	call   0x41b2:0x4081
    3783:	c9                   	leave
    3784:	ca 06 00             	retf   0x6
    3787:	55                   	push   bp
    3788:	89 e5                	mov    bp,sp
    378a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    378d:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3790:	74 60                	je     0x37f2
    3792:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3795:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3798:	bf c1 05             	mov    di,0x5c1
    379b:	b8 03 38             	mov    ax,0x3803
    379e:	50                   	push   ax
    379f:	57                   	push   di
    37a0:	9a 55 22 0a 38       	call   0x380a:0x2255
    37a5:	08 c0                	or     al,al
    37a7:	74 26                	je     0x37cf
    37a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37ac:	81 c7 96 00          	add    di,0x96
    37b0:	06                   	push   es
    37b1:	57                   	push   di
    37b2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37b5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37b8:	e8 0f da             	call   0x11ca
    37bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37be:	81 c7 9a 00          	add    di,0x9a
    37c2:	06                   	push   es
    37c3:	57                   	push   di
    37c4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37c7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37ca:	e8 fd d9             	call   0x11ca
    37cd:	eb 12                	jmp    0x37e1
    37cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d2:	81 c7 92 00          	add    di,0x92
    37d6:	06                   	push   es
    37d7:	57                   	push   di
    37d8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37db:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37de:	e8 e9 d9             	call   0x11ca
    37e1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    37e4:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    37e7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37ea:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    37ee:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    37f2:	c9                   	leave
    37f3:	ca 08 00             	retf   0x8
    37f6:	55                   	push   bp
    37f7:	89 e5                	mov    bp,sp
    37f9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37fc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37ff:	bf c1 05             	mov    di,0x5c1
    3802:	b8 6a 38             	mov    ax,0x386a
    3805:	50                   	push   ax
    3806:	57                   	push   di
    3807:	9a 55 22 c3 38       	call   0x38c3:0x2255
    380c:	08 c0                	or     al,al
    380e:	74 26                	je     0x3836
    3810:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3813:	81 c7 9a 00          	add    di,0x9a
    3817:	06                   	push   es
    3818:	57                   	push   di
    3819:	ff 76 0c             	push   WORD PTR [bp+0xc]
    381c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    381f:	e8 e8 d9             	call   0x120a
    3822:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3825:	81 c7 96 00          	add    di,0x96
    3829:	06                   	push   es
    382a:	57                   	push   di
    382b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    382e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3831:	e8 d6 d9             	call   0x120a
    3834:	eb 12                	jmp    0x3848
    3836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3839:	81 c7 92 00          	add    di,0x92
    383d:	06                   	push   es
    383e:	57                   	push   di
    383f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3842:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3845:	e8 c2 d9             	call   0x120a
    3848:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    384b:	31 c0                	xor    ax,ax
    384d:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3851:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    3855:	c9                   	leave
    3856:	ca 08 00             	retf   0x8
    3859:	55                   	push   bp
    385a:	89 e5                	mov    bp,sp
    385c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    385f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3862:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3865:	06                   	push   es
    3866:	57                   	push   di
    3867:	9a 87 37 8a 38       	call   0x388a:0x3787
    386c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    386f:	26 f6 45 28 08       	test   BYTE PTR es:[di+0x28],0x8
    3874:	74 03                	je     0x3879
    3876:	e9 99 00             	jmp    0x3912
    3879:	68 09 0f             	push   0xf09
    387c:	6a 00                	push   0x0
    387e:	6a 00                	push   0x0
    3880:	6a 00                	push   0x0
    3882:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3885:	06                   	push   es
    3886:	57                   	push   di
    3887:	9a bb 24 9d 38       	call   0x389d:0x24bb
    388c:	68 08 0f             	push   0xf08
    388f:	6a 00                	push   0x0
    3891:	6a 00                	push   0x0
    3893:	6a 00                	push   0x0
    3895:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3898:	06                   	push   es
    3899:	57                   	push   di
    389a:	9a bb 24 b0 38       	call   0x38b0:0x24bb
    389f:	68 23 0f             	push   0xf23
    38a2:	6a 00                	push   0x0
    38a4:	6a 00                	push   0x0
    38a6:	6a 00                	push   0x0
    38a8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    38ab:	06                   	push   es
    38ac:	57                   	push   di
    38ad:	9a bb 24 bc 38       	call   0x38bc:0x24bb
    38b2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    38b5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    38b8:	bf c1 05             	mov    di,0x5c1
    38bb:	b8 da 38             	mov    ax,0x38da
    38be:	50                   	push   ax
    38bf:	57                   	push   di
    38c0:	9a 55 22 2b 39       	call   0x392b:0x2255
    38c5:	08 c0                	or     al,al
    38c7:	74 1f                	je     0x38e8
    38c9:	68 11 0f             	push   0xf11
    38cc:	6a 00                	push   0x0
    38ce:	6a 00                	push   0x0
    38d0:	6a 00                	push   0x0
    38d2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    38d5:	06                   	push   es
    38d6:	57                   	push   di
    38d7:	9a bb 24 e4 38       	call   0x38e4:0x24bb
    38dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38df:	06                   	push   es
    38e0:	57                   	push   di
    38e1:	9a a5 41 f0 38       	call   0x38f0:0x41a5
    38e6:	eb 1a                	jmp    0x3902
    38e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38eb:	06                   	push   es
    38ec:	57                   	push   di
    38ed:	9a fa 64 10 39       	call   0x3910:0x64fa
    38f2:	08 c0                	or     al,al
    38f4:	74 0c                	je     0x3902
    38f6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    38f9:	06                   	push   es
    38fa:	57                   	push   di
    38fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38fe:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3902:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3905:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3908:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    390b:	06                   	push   es
    390c:	57                   	push   di
    390d:	9a 33 36 24 39       	call   0x3924:0x3633
    3912:	c9                   	leave
    3913:	ca 08 00             	retf   0x8
    3916:	c8 04 00 00          	enter  0x4,0x0
    391a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    391d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3920:	bf c1 05             	mov    di,0x5c1
    3923:	b8 41 39             	mov    ax,0x3941
    3926:	50                   	push   ax
    3927:	57                   	push   di
    3928:	9a 55 22 39 3b       	call   0x3b39:0x2255
    392d:	08 c0                	or     al,al
    392f:	74 1e                	je     0x394f
    3931:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3934:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3937:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    393a:	6a 01                	push   0x1
    393c:	06                   	push   es
    393d:	57                   	push   di
    393e:	9a 52 37 4b 39       	call   0x394b:0x3752
    3943:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3946:	06                   	push   es
    3947:	57                   	push   di
    3948:	9a ee 3f 57 39       	call   0x3957:0x3fee
    394d:	eb 22                	jmp    0x3971
    394f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3952:	06                   	push   es
    3953:	57                   	push   di
    3954:	9a fa 64 6f 39       	call   0x396f:0x64fa
    3959:	08 c0                	or     al,al
    395b:	74 14                	je     0x3971
    395d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3960:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    3964:	50                   	push   ax
    3965:	6a 00                	push   0x0
    3967:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    396a:	06                   	push   es
    396b:	57                   	push   di
    396c:	9a b3 21 7f 39       	call   0x397f:0x21b3
    3971:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3974:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3977:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    397a:	06                   	push   es
    397b:	57                   	push   di
    397c:	9a f6 37 89 39       	call   0x3989:0x37f6
    3981:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3984:	06                   	push   es
    3985:	57                   	push   di
    3986:	9a f9 36 4f 3a       	call   0x3a4f:0x36f9
    398b:	c9                   	leave
    398c:	ca 08 00             	retf   0x8
    398f:	c8 06 00 00          	enter  0x6,0x0
    3993:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3996:	26 8b 85 92 00       	mov    ax,WORD PTR es:[di+0x92]
    399b:	26 0b 85 94 00       	or     ax,WORD PTR es:[di+0x94]
    39a0:	74 0e                	je     0x39b0
    39a2:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    39a7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    39ab:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    39ae:	eb 05                	jmp    0x39b5
    39b0:	31 c0                	xor    ax,ax
    39b2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    39b5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    39b8:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    39bb:	7d 1a                	jge    0x39d7
    39bd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    39c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c3:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    39c8:	06                   	push   es
    39c9:	57                   	push   di
    39ca:	9a d0 0d eb 39       	call   0x39eb:0xdd0
    39cf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    39d2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    39d5:	eb 1c                	jmp    0x39f3
    39d7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    39da:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    39dd:	50                   	push   ax
    39de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39e1:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    39e6:	06                   	push   es
    39e7:	57                   	push   di
    39e8:	9a d0 0d cb 3c       	call   0x3ccb:0xdd0
    39ed:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    39f0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    39f3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    39f6:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    39f9:	c9                   	leave
    39fa:	ca 06 00             	retf   0x6
    39fd:	c8 02 00 00          	enter  0x2,0x0
    3a01:	31 c0                	xor    ax,ax
    3a03:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a09:	26 8b 85 92 00       	mov    ax,WORD PTR es:[di+0x92]
    3a0e:	26 0b 85 94 00       	or     ax,WORD PTR es:[di+0x94]
    3a13:	74 0c                	je     0x3a21
    3a15:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    3a1a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3a1e:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    3a21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a24:	26 8b 85 96 00       	mov    ax,WORD PTR es:[di+0x96]
    3a29:	26 0b 85 98 00       	or     ax,WORD PTR es:[di+0x98]
    3a2e:	74 0c                	je     0x3a3c
    3a30:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    3a35:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3a39:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    3a3c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a3f:	c9                   	leave
    3a40:	ca 04 00             	retf   0x4
    3a43:	c8 04 00 00          	enter  0x4,0x0
    3a47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a4a:	06                   	push   es
    3a4b:	57                   	push   di
    3a4c:	9a fd 39 74 3a       	call   0x3a74:0x39fd
    3a51:	48                   	dec    ax
    3a52:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a55:	31 c0                	xor    ax,ax
    3a57:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3a5a:	7f 3e                	jg     0x3a9a
    3a5c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3a5f:	eb 03                	jmp    0x3a64
    3a61:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3a64:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a67:	06                   	push   es
    3a68:	57                   	push   di
    3a69:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3a6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a6f:	06                   	push   es
    3a70:	57                   	push   di
    3a71:	9a 8f 39 ca 3a       	call   0x3aca:0x398f
    3a76:	89 c7                	mov    di,ax
    3a78:	8e c2                	mov    es,dx
    3a7a:	06                   	push   es
    3a7b:	57                   	push   di
    3a7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a7f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3a83:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a86:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3a8a:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    3a8e:	74 02                	je     0x3a92
    3a90:	eb 08                	jmp    0x3a9a
    3a92:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a95:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3a98:	75 c7                	jne    0x3a61
    3a9a:	c9                   	leave
    3a9b:	ca 08 00             	retf   0x8
    3a9e:	c8 0c 00 00          	enter  0xc,0x0
    3aa2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3aa5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3aa8:	31 c0                	xor    ax,ax
    3aaa:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3aad:	31 c0                	xor    ax,ax
    3aaf:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3ab2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3ab5:	31 c0                	xor    ax,ax
    3ab7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3aba:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3abd:	8d 7e f4             	lea    di,[bp-0xc]
    3ac0:	16                   	push   ss
    3ac1:	57                   	push   di
    3ac2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ac5:	06                   	push   es
    3ac6:	57                   	push   di
    3ac7:	9a 43 3a 2d 3c       	call   0x3c2d:0x3a43
    3acc:	c9                   	leave
    3acd:	ca 06 00             	retf   0x6
    3ad0:	c8 04 00 00          	enter  0x4,0x0
    3ad4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3ad7:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3ada:	74 49                	je     0x3b25
    3adc:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3adf:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3ae2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3ae5:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    3ae9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3aec:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3aef:	81 c7 1a 00          	add    di,0x1a
    3af3:	06                   	push   es
    3af4:	57                   	push   di
    3af5:	9a 10 3b 00 00       	call   0x0:0x3b10
    3afa:	09 c0                	or     ax,ax
    3afc:	75 16                	jne    0x3b14
    3afe:	6a 00                	push   0x0
    3b00:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b03:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b06:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b09:	81 c7 1a 00          	add    di,0x1a
    3b0d:	06                   	push   es
    3b0e:	57                   	push   di
    3b0f:	9a 2a 3d 00 00       	call   0x0:0x3d2a
    3b14:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b17:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3b1b:	25 1f bf             	and    ax,0xbf1f
    3b1e:	0d 03 00             	or     ax,0x3
    3b21:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3b25:	c9                   	leave
    3b26:	ca 0c 00             	retf   0xc
    3b29:	c8 04 01 00          	enter  0x104,0x0
    3b2d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3b30:	06                   	push   es
    3b31:	57                   	push   di
    3b32:	6a 74                	push   0x74
    3b34:	6a 00                	push   0x0
    3b36:	9a e5 1e 7d 3c       	call   0x3c7d:0x1ee5
    3b3b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3b3e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3b41:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3b44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b47:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    3b4b:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    3b4f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b52:	26 89 05             	mov    WORD PTR es:[di],ax
    3b55:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3b59:	26 c7 45 04 00 00    	mov    WORD PTR es:[di+0x4],0x0
    3b5f:	26 c7 45 06 00 44    	mov    WORD PTR es:[di+0x6],0x4400
    3b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b68:	26 f6 45 26 01       	test   BYTE PTR es:[di+0x26],0x1
    3b6d:	74 1a                	je     0x3b89
    3b6f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b72:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3b76:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3b7a:	0d 00 00             	or     ax,0x0
    3b7d:	81 ca 00 02          	or     dx,0x200
    3b81:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3b85:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3b89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b8c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3b91:	75 21                	jne    0x3bb4
    3b93:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3b98:	75 1a                	jne    0x3bb4
    3b9a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b9d:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3ba1:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3ba5:	0d 00 00             	or     ax,0x0
    3ba8:	81 ca 00 08          	or     dx,0x800
    3bac:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3bb0:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3bb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb7:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
    3bbd:	74 1a                	je     0x3bd9
    3bbf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3bc2:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3bc6:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3bca:	0d 00 00             	or     ax,0x0
    3bcd:	81 ca 01 00          	or     dx,0x1
    3bd1:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3bd5:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3bd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bdc:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3be0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3be3:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    3be7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bea:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    3bee:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3bf1:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    3bf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bf8:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3bfc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3bff:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    3c03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c06:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    3c0a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c0d:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    3c11:	31 c0                	xor    ax,ax
    3c13:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3c17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c1a:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3c1e:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    3c22:	74 12                	je     0x3c36
    3c24:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3c28:	06                   	push   es
    3c29:	57                   	push   di
    3c2a:	9a b9 62 f7 3c       	call   0x3cf7:0x62b9
    3c2f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c32:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3c36:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c39:	26 c7 45 1a 0b 00    	mov    WORD PTR es:[di+0x1a],0xb
    3c3f:	b8 ff ff             	mov    ax,0xffff
    3c42:	ba ff ff             	mov    dx,0xffff
    3c45:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    3c49:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    3c4d:	6a 00                	push   0x0
    3c4f:	6a 00                	push   0x0
    3c51:	68 00 7f             	push   0x7f00
    3c54:	9a ff ff 00 00       	call   0x0:0xffff
    3c59:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c5c:	26 89 45 28          	mov    WORD PTR es:[di+0x28],ax
    3c60:	31 c0                	xor    ax,ax
    3c62:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    3c66:	81 c7 34 00          	add    di,0x34
    3c6a:	06                   	push   es
    3c6b:	57                   	push   di
    3c6c:	8d be fc fe          	lea    di,[bp-0x104]
    3c70:	16                   	push   ss
    3c71:	57                   	push   di
    3c72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c75:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c78:	06                   	push   es
    3c79:	57                   	push   di
    3c7a:	9a ed 20 05 3d       	call   0x3d05:0x20ed
    3c7f:	9a 4c 0d ee 3c       	call   0x3cee:0xd4c
    3c84:	c9                   	leave
    3c85:	ca 08 00             	retf   0x8
    3c88:	c8 96 02 00          	enter  0x296,0x0
    3c8c:	8d 7e 8c             	lea    di,[bp-0x74]
    3c8f:	16                   	push   ss
    3c90:	57                   	push   di
    3c91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c94:	06                   	push   es
    3c95:	57                   	push   di
    3c96:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c99:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    3c9d:	83 7e a0 00          	cmp    WORD PTR [bp-0x60],0x0
    3ca1:	75 64                	jne    0x3d07
    3ca3:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    3ca6:	8b 56 92             	mov    dx,WORD PTR [bp-0x6e]
    3ca9:	25 00 00             	and    ax,0x0
    3cac:	81 e2 00 40          	and    dx,0x4000
    3cb0:	09 d0                	or     ax,dx
    3cb2:	74 53                	je     0x3d07
    3cb4:	8d be 6a fd          	lea    di,[bp-0x296]
    3cb8:	16                   	push   ss
    3cb9:	57                   	push   di
    3cba:	68 2a f0             	push   0xf02a
    3cbd:	8d be 72 fe          	lea    di,[bp-0x18e]
    3cc1:	16                   	push   ss
    3cc2:	57                   	push   di
    3cc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cc6:	06                   	push   es
    3cc7:	57                   	push   di
    3cc8:	9a 2a 51 28 3f       	call   0x3f28:0x512a
    3ccd:	83 c4 04             	add    sp,0x4
    3cd0:	8d 86 72 fe          	lea    ax,[bp-0x18e]
    3cd4:	8c d2                	mov    dx,ss
    3cd6:	89 86 6a fe          	mov    WORD PTR [bp-0x196],ax
    3cda:	89 96 6c fe          	mov    WORD PTR [bp-0x194],dx
    3cde:	c6 86 6e fe 04       	mov    BYTE PTR [bp-0x192],0x4
    3ce3:	8d be 6a fe          	lea    di,[bp-0x196]
    3ce7:	16                   	push   ss
    3ce8:	57                   	push   di
    3ce9:	6a 00                	push   0x0
    3ceb:	9a 50 09 fe 3c       	call   0x3cfe:0x950
    3cf0:	b0 01                	mov    al,0x1
    3cf2:	50                   	push   ax
    3cf3:	b8 52 00             	mov    ax,0x52
    3cf6:	ba 36 3d             	mov    dx,0x3d36
    3cf9:	52                   	push   dx
    3cfa:	50                   	push   ax
    3cfb:	9a e6 28 69 3d       	call   0x3d69:0x28e6
    3d00:	52                   	push   dx
    3d01:	50                   	push   ax
    3d02:	9a 99 13 80 3d       	call   0x3d80:0x1399
    3d07:	8b 46 a8             	mov    ax,WORD PTR [bp-0x58]
    3d0a:	8b 56 aa             	mov    dx,WORD PTR [bp-0x56]
    3d0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d10:	26 89 85 8e 00       	mov    WORD PTR es:[di+0x8e],ax
    3d15:	26 89 95 90 00       	mov    WORD PTR es:[di+0x90],dx
    3d1a:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    3d1e:	8d 7e c0             	lea    di,[bp-0x40]
    3d21:	16                   	push   ss
    3d22:	57                   	push   di
    3d23:	8d be 72 ff          	lea    di,[bp-0x8e]
    3d27:	16                   	push   ss
    3d28:	57                   	push   di
    3d29:	9a ff ff 00 00       	call   0x0:0xffff
    3d2e:	09 c0                	or     ax,ax
    3d30:	75 50                	jne    0x3d82
    3d32:	b8 8d 0a             	mov    ax,0xa8d
    3d35:	ba 72 3d             	mov    dx,0x3d72
    3d38:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    3d3b:	89 56 aa             	mov    WORD PTR [bp-0x56],dx
    3d3e:	a1 8c 18             	mov    ax,ds:0x188c
    3d41:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    3d44:	8d 46 c0             	lea    ax,[bp-0x40]
    3d47:	8c d2                	mov    dx,ss
    3d49:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    3d4c:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    3d4f:	8d 7e a6             	lea    di,[bp-0x5a]
    3d52:	16                   	push   ss
    3d53:	57                   	push   di
    3d54:	9a ff ff 00 00       	call   0x0:0xffff
    3d59:	09 c0                	or     ax,ax
    3d5b:	75 25                	jne    0x3d82
    3d5d:	8d be 72 fe          	lea    di,[bp-0x18e]
    3d61:	16                   	push   ss
    3d62:	57                   	push   di
    3d63:	68 27 f0             	push   0xf027
    3d66:	9a 2b 09 79 3d       	call   0x3d79:0x92b
    3d6b:	b0 01                	mov    al,0x1
    3d6d:	50                   	push   ax
    3d6e:	b8 22 00             	mov    ax,0x22
    3d71:	ba c0 3d             	mov    dx,0x3dc0
    3d74:	52                   	push   dx
    3d75:	50                   	push   ax
    3d76:	9a e6 28 b7 3d       	call   0x3db7:0x28e6
    3d7b:	52                   	push   dx
    3d7c:	50                   	push   ax
    3d7d:	9a 99 13 ce 3d       	call   0x3dce:0x1399
    3d82:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3d85:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3d88:	a3 e4 13             	mov    ds:0x13e4,ax
    3d8b:	89 16 e6 13          	mov    WORD PTR ds:0x13e6,dx
    3d8f:	8d 7e 8c             	lea    di,[bp-0x74]
    3d92:	16                   	push   ss
    3d93:	57                   	push   di
    3d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d97:	06                   	push   es
    3d98:	57                   	push   di
    3d99:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d9c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da3:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    3da9:	75 25                	jne    0x3dd0
    3dab:	8d be 72 fe          	lea    di,[bp-0x18e]
    3daf:	16                   	push   ss
    3db0:	57                   	push   di
    3db1:	68 28 f0             	push   0xf028
    3db4:	9a 2b 09 c7 3d       	call   0x3dc7:0x92b
    3db9:	b0 01                	mov    al,0x1
    3dbb:	50                   	push   ax
    3dbc:	b8 22 00             	mov    ax,0x22
    3dbf:	ba f2 3d             	mov    dx,0x3df2
    3dc2:	52                   	push   dx
    3dc3:	50                   	push   ax
    3dc4:	9a e6 28 de 3d       	call   0x3dde:0x28e6
    3dc9:	52                   	push   dx
    3dca:	50                   	push   ax
    3dcb:	9a 99 13 9a 41       	call   0x419a:0x1399
    3dd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dd3:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    3dd7:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    3ddb:	9a 23 0f 96 3e       	call   0x3e96:0xf23
    3de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3de3:	31 c0                	xor    ax,ax
    3de5:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    3de9:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    3ded:	06                   	push   es
    3dee:	57                   	push   di
    3def:	9a 16 65 11 3e       	call   0x3e11:0x6516
    3df4:	6a 30                	push   0x30
    3df6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3df9:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3dfd:	06                   	push   es
    3dfe:	57                   	push   di
    3dff:	9a 16 10 82 42       	call   0x4282:0x1016
    3e04:	50                   	push   ax
    3e05:	6a 00                	push   0x0
    3e07:	6a 01                	push   0x1
    3e09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e0c:	06                   	push   es
    3e0d:	57                   	push   di
    3e0e:	9a bb 24 83 3e       	call   0x3e83:0x24bb
    3e13:	c9                   	leave
    3e14:	ca 04 00             	retf   0x4
    3e17:	c8 04 00 00          	enter  0x4,0x0
    3e1b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e1e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3e21:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3e24:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    3e28:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    3e2c:	81 c7 34 00          	add    di,0x34
    3e30:	06                   	push   es
    3e31:	57                   	push   di
    3e32:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3e35:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3e39:	26 ff 35             	push   WORD PTR es:[di]
    3e3c:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3e40:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3e44:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    3e48:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    3e4c:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    3e50:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    3e54:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    3e58:	6a 00                	push   0x0
    3e5a:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    3e5e:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    3e62:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    3e66:	9a ff ff 00 00       	call   0x0:0xffff
    3e6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e6e:	26 89 85 a2 00       	mov    WORD PTR es:[di+0xa2],ax
    3e73:	c9                   	leave
    3e74:	ca 08 00             	retf   0x8
    3e77:	c8 02 00 00          	enter  0x2,0x0
    3e7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e7e:	06                   	push   es
    3e7f:	57                   	push   di
    3e80:	9a e2 1c d8 3e       	call   0x3ed8:0x1ce2
    3e85:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3e88:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    3e8c:	7d 17                	jge    0x3ea5
    3e8e:	bf fa 14             	mov    di,0x14fa
    3e91:	1e                   	push   ds
    3e92:	57                   	push   di
    3e93:	9a d6 0e ad 3e       	call   0x3ead:0xed6
    3e98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e9b:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    3e9f:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    3ea3:	eb 35                	jmp    0x3eda
    3ea5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ea8:	40                   	inc    ax
    3ea9:	50                   	push   ax
    3eaa:	9a 8f 0e cd 3e       	call   0x3ecd:0xe8f
    3eaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3eb2:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    3eb6:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    3eba:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    3ebe:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    3ec2:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    3ec6:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    3eca:	9a bc 0e da 60       	call   0x60da:0xebc
    3ecf:	50                   	push   ax
    3ed0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed3:	06                   	push   es
    3ed4:	57                   	push   di
    3ed5:	9a 02 1d d8 3f       	call   0x3fd8:0x1d02
    3eda:	e8 8a d3             	call   0x1267
    3edd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ee0:	06                   	push   es
    3ee1:	57                   	push   di
    3ee2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ee5:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    3ee9:	c9                   	leave
    3eea:	ca 04 00             	retf   0x4
    3eed:	55                   	push   bp
    3eee:	89 e5                	mov    bp,sp
    3ef0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef3:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    3ef8:	9a ff ff 00 00       	call   0x0:0xffff
    3efd:	c9                   	leave
    3efe:	ca 04 00             	retf   0x4
    3f01:	c8 06 00 00          	enter  0x6,0x0
    3f05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f08:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    3f0d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3f11:	48                   	dec    ax
    3f12:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3f15:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3f18:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3f1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f1e:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    3f23:	06                   	push   es
    3f24:	57                   	push   di
    3f25:	9a 58 0e 48 3f       	call   0x3f48:0xe58
    3f2a:	40                   	inc    ax
    3f2b:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3f2e:	7f 36                	jg     0x3f66
    3f30:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3f33:	eb 03                	jmp    0x3f38
    3f35:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3f38:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3f3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f3e:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    3f43:	06                   	push   es
    3f44:	57                   	push   di
    3f45:	9a d0 0d 35 40       	call   0x4035:0xdd0
    3f4a:	89 c7                	mov    di,ax
    3f4c:	8e c2                	mov    es,dx
    3f4e:	26 8b 85 a2 00       	mov    ax,WORD PTR es:[di+0xa2]
    3f53:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f56:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3f5a:	74 02                	je     0x3f5e
    3f5c:	eb 0d                	jmp    0x3f6b
    3f5e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3f61:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3f64:	75 cf                	jne    0x3f35
    3f66:	31 c0                	xor    ax,ax
    3f68:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f6b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f6e:	c9                   	leave
    3f6f:	ca 08 00             	retf   0x8
    3f72:	55                   	push   bp
    3f73:	89 e5                	mov    bp,sp
    3f75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f78:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    3f7e:	75 6a                	jne    0x3fea
    3f80:	06                   	push   es
    3f81:	57                   	push   di
    3f82:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f85:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3f89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f8c:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    3f91:	a1 0e 2c             	mov    ax,ds:0x2c0e
    3f94:	31 d2                	xor    dx,dx
    3f96:	52                   	push   dx
    3f97:	50                   	push   ax
    3f98:	ff 76 06             	push   WORD PTR [bp+0x6]
    3f9b:	9a b3 3f 00 00       	call   0x0:0x3fb3
    3fa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fa3:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    3fa8:	a1 10 2c             	mov    ax,ds:0x2c10
    3fab:	31 d2                	xor    dx,dx
    3fad:	52                   	push   dx
    3fae:	50                   	push   ax
    3faf:	ff 76 08             	push   WORD PTR [bp+0x8]
    3fb2:	9a ff ff 00 00       	call   0x0:0xffff
    3fb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fba:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3fbe:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    3fc2:	74 26                	je     0x3fea
    3fc4:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    3fc9:	ff 76 08             	push   WORD PTR [bp+0x8]
    3fcc:	ff 76 06             	push   WORD PTR [bp+0x6]
    3fcf:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3fd3:	06                   	push   es
    3fd4:	57                   	push   di
    3fd5:	9a 01 3f 40 40       	call   0x4040:0x3f01
    3fda:	50                   	push   ax
    3fdb:	6a 00                	push   0x0
    3fdd:	6a 00                	push   0x0
    3fdf:	6a 00                	push   0x0
    3fe1:	6a 00                	push   0x0
    3fe3:	6a 13                	push   0x13
    3fe5:	9a ab 56 00 00       	call   0x0:0x56ab
    3fea:	c9                   	leave
    3feb:	ca 04 00             	retf   0x4
    3fee:	c8 04 00 00          	enter  0x4,0x0
    3ff2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ff5:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    3ffb:	74 59                	je     0x4056
    3ffd:	26 8b 85 96 00       	mov    ax,WORD PTR es:[di+0x96]
    4002:	26 0b 85 98 00       	or     ax,WORD PTR es:[di+0x98]
    4007:	74 41                	je     0x404a
    4009:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    400e:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4012:	48                   	dec    ax
    4013:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4016:	31 c0                	xor    ax,ax
    4018:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    401b:	7f 2d                	jg     0x404a
    401d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4020:	eb 03                	jmp    0x4025
    4022:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4025:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    402b:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    4030:	06                   	push   es
    4031:	57                   	push   di
    4032:	9a d0 0d 2d 41       	call   0x412d:0xdd0
    4037:	89 c7                	mov    di,ax
    4039:	8e c2                	mov    es,dx
    403b:	06                   	push   es
    403c:	57                   	push   di
    403d:	9a ee 3f 6e 40       	call   0x406e:0x3fee
    4042:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4045:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4048:	75 d8                	jne    0x4022
    404a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    404d:	06                   	push   es
    404e:	57                   	push   di
    404f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4052:	26 ff 5d 68          	call   DWORD PTR es:[di+0x68]
    4056:	c9                   	leave
    4057:	ca 04 00             	retf   0x4
    405a:	c8 02 00 00          	enter  0x2,0x0
    405e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4061:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    4067:	74 39                	je     0x40a2
    4069:	06                   	push   es
    406a:	57                   	push   di
    406b:	9a 58 62 7b 40       	call   0x407b:0x6258
    4070:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4076:	06                   	push   es
    4077:	57                   	push   di
    4078:	9a ee 3f 85 40       	call   0x4085:0x3fee
    407d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4080:	06                   	push   es
    4081:	57                   	push   di
    4082:	9a a5 41 ae 40       	call   0x40ae:0x41a5
    4087:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    408b:	74 15                	je     0x40a2
    408d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4090:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    4096:	74 0a                	je     0x40a2
    4098:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    409d:	9a ff ff 00 00       	call   0x0:0xffff
    40a2:	c9                   	leave
    40a3:	ca 04 00             	retf   0x4
    40a6:	01 00                	add    WORD PTR [bx+si],ax
    40a8:	00 00                	add    BYTE PTR [bx+si],al
    40aa:	00 00                	add    BYTE PTR [bx+si],al
    40ac:	86 41 38             	xchg   BYTE PTR [bx+di+0x38],al
    40af:	41                   	inc    cx
    40b0:	c8 06 00 00          	enter  0x6,0x0
    40b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b7:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    40bc:	75 07                	jne    0x40c5
    40be:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    40c3:	74 0a                	je     0x40cf
    40c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40c8:	26 f6 45 28 08       	test   BYTE PTR es:[di+0x28],0x8
    40cd:	74 04                	je     0x40d3
    40cf:	b0 00                	mov    al,0x0
    40d1:	eb 02                	jmp    0x40d5
    40d3:	b0 01                	mov    al,0x1
    40d5:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    40d8:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    40dc:	74 64                	je     0x4142
    40de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e1:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    40e7:	75 09                	jne    0x40f2
    40e9:	06                   	push   es
    40ea:	57                   	push   di
    40eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40ee:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    40f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40f5:	26 8b 85 96 00       	mov    ax,WORD PTR es:[di+0x96]
    40fa:	26 0b 85 98 00       	or     ax,WORD PTR es:[di+0x98]
    40ff:	74 41                	je     0x4142
    4101:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    4106:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    410a:	48                   	dec    ax
    410b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    410e:	31 c0                	xor    ax,ax
    4110:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    4113:	7f 2d                	jg     0x4142
    4115:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4118:	eb 03                	jmp    0x411d
    411a:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    411d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4120:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4123:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    4128:	06                   	push   es
    4129:	57                   	push   di
    412a:	9a d0 0d e7 42       	call   0x42e7:0xdd0
    412f:	89 c7                	mov    di,ax
    4131:	8e c2                	mov    es,dx
    4133:	06                   	push   es
    4134:	57                   	push   di
    4135:	9a b0 40 7b 41       	call   0x417b:0x40b0
    413a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    413d:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    4140:	75 d8                	jne    0x411a
    4142:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4145:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    414b:	74 54                	je     0x41a1
    414d:	26 8a 85 a7 00       	mov    al,BYTE PTR es:[di+0xa7]
    4152:	3a 46 ff             	cmp    al,BYTE PTR [bp-0x1]
    4155:	74 4a                	je     0x41a1
    4157:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    415a:	26 88 85 a7 00       	mov    BYTE PTR es:[di+0xa7],al
    415f:	b8 a6 40             	mov    ax,0x40a6
    4162:	0e                   	push   cs
    4163:	50                   	push   ax
    4164:	55                   	push   bp
    4165:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4169:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    416d:	68 19 0f             	push   0xf19
    4170:	6a 00                	push   0x0
    4172:	6a 00                	push   0x0
    4174:	6a 00                	push   0x0
    4176:	06                   	push   es
    4177:	57                   	push   di
    4178:	9a bb 24 06 42       	call   0x4206:0x24bb
    417d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4181:	83 c4 06             	add    sp,0x6
    4184:	eb 1b                	jmp    0x41a1
    4186:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    418a:	b0 00                	mov    al,0x0
    418c:	75 01                	jne    0x418f
    418e:	40                   	inc    ax
    418f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4192:	26 88 85 a7 00       	mov    BYTE PTR es:[di+0xa7],al
    4197:	ea 85 13 9f 41       	jmp    0x419f:0x1385
    419c:	9a 34 14 a2 42       	call   0x42a2:0x1434
    41a1:	c9                   	leave
    41a2:	ca 04 00             	retf   0x4
    41a5:	c8 08 00 00          	enter  0x8,0x0
    41a9:	ff 76 08             	push   WORD PTR [bp+0x8]
    41ac:	ff 76 06             	push   WORD PTR [bp+0x6]
    41af:	9a a8 17 9d 42       	call   0x429d:0x17a8
    41b4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    41b7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    41ba:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    41bd:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    41c0:	74 46                	je     0x4208
    41c2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    41c5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    41c8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    41cb:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    41ce:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    41d1:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    41d4:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    41d7:	75 05                	jne    0x41de
    41d9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    41dc:	74 20                	je     0x41fe
    41de:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    41e1:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    41e5:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    41e9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    41ec:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    41ef:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    41f2:	26 80 bd a7 00 00    	cmp    BYTE PTR es:[di+0xa7],0x0
    41f8:	75 02                	jne    0x41fc
    41fa:	eb 0c                	jmp    0x4208
    41fc:	eb d0                	jmp    0x41ce
    41fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4201:	06                   	push   es
    4202:	57                   	push   di
    4203:	9a b0 40 10 42       	call   0x4210:0x40b0
    4208:	c9                   	leave
    4209:	ca 04 00             	retf   0x4
    420c:	00 00                	add    BYTE PTR [bx+si],al
    420e:	7c 42                	jl     0x4252
    4210:	1a 42 01             	sbb    al,BYTE PTR [bp+si+0x1]
    4213:	00 00                	add    BYTE PTR [bx+si],al
    4215:	00 00                	add    BYTE PTR [bx+si],al
    4217:	00 8e 42 64          	add    BYTE PTR [bp+0x6442],cl
    421b:	43                   	inc    bx
    421c:	c8 04 00 00          	enter  0x4,0x0
    4220:	b8 12 42             	mov    ax,0x4212
    4223:	0e                   	push   cs
    4224:	50                   	push   ax
    4225:	55                   	push   bp
    4226:	ff 36 58 18          	push   WORD PTR ds:0x1858
    422a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    422e:	b8 0c 42             	mov    ax,0x420c
    4231:	0e                   	push   cs
    4232:	50                   	push   ax
    4233:	55                   	push   bp
    4234:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4238:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    423c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    423f:	26 83 3d 0f          	cmp    WORD PTR es:[di],0xf
    4243:	75 1a                	jne    0x425f
    4245:	26 81 7d 06 fe de    	cmp    WORD PTR es:[di+0x6],0xdefe
    424b:	75 12                	jne    0x425f
    424d:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4251:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    4255:	31 c0                	xor    ax,ax
    4257:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    425b:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    425f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4262:	06                   	push   es
    4263:	57                   	push   di
    4264:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4267:	06                   	push   es
    4268:	57                   	push   di
    4269:	26 c4 3d             	les    di,DWORD PTR es:[di]
    426c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4270:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4274:	83 c4 06             	add    sp,0x6
    4277:	b8 85 42             	mov    ax,0x4285
    427a:	0e                   	push   cs
    427b:	50                   	push   ax
    427c:	e8 e8 cf             	call   0x1267
    427f:	9a d8 50 e4 49       	call   0x49e4:0x50d8
    4284:	cb                   	retf
    4285:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4289:	83 c4 06             	add    sp,0x6
    428c:	eb 16                	jmp    0x42a4
    428e:	ff 76 08             	push   WORD PTR [bp+0x8]
    4291:	ff 76 06             	push   WORD PTR [bp+0x6]
    4294:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4298:	06                   	push   es
    4299:	57                   	push   di
    429a:	9a 51 75 64 44       	call   0x4464:0x7551
    429f:	9a 34 14 21 50       	call   0x5021:0x1434
    42a4:	c9                   	leave
    42a5:	ca 08 00             	retf   0x8
    42a8:	c8 16 00 00          	enter  0x16,0x0
    42ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42af:	26 8b 85 92 00       	mov    ax,WORD PTR es:[di+0x92]
    42b4:	26 0b 85 94 00       	or     ax,WORD PTR es:[di+0x94]
    42b9:	75 03                	jne    0x42be
    42bb:	e9 b7 00             	jmp    0x4375
    42be:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    42c3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    42c7:	48                   	dec    ax
    42c8:	09 c0                	or     ax,ax
    42ca:	7d 03                	jge    0x42cf
    42cc:	e9 a6 00             	jmp    0x4375
    42cf:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    42d2:	eb 03                	jmp    0x42d7
    42d4:	ff 4e fa             	dec    WORD PTR [bp-0x6]
    42d7:	ff 76 fa             	push   WORD PTR [bp-0x6]
    42da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42dd:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    42e2:	06                   	push   es
    42e3:	57                   	push   di
    42e4:	9a d0 0d 0b 43       	call   0x430b:0xdd0
    42e9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    42ec:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    42ef:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    42f2:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    42f5:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    42f8:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    42fb:	26 2b 45 1e          	sub    ax,WORD PTR es:[di+0x1e]
    42ff:	50                   	push   ax
    4300:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    4303:	26 2b 45 20          	sub    ax,WORD PTR es:[di+0x20]
    4307:	50                   	push   ax
    4308:	9a 6e 06 62 47       	call   0x4762:0x66e
    430d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4310:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4313:	8d 7e ea             	lea    di,[bp-0x16]
    4316:	16                   	push   ss
    4317:	57                   	push   di
    4318:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    431b:	06                   	push   es
    431c:	57                   	push   di
    431d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4320:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    4324:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4327:	ff 76 f6             	push   WORD PTR [bp-0xa]
    432a:	9a ff ff 00 00       	call   0x0:0xffff
    432f:	09 c0                	or     ax,ax
    4331:	74 39                	je     0x436c
    4333:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4336:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    433b:	75 2d                	jne    0x436a
    433d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4342:	74 28                	je     0x436c
    4344:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    4349:	75 06                	jne    0x4351
    434b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    434f:	74 1b                	je     0x436c
    4351:	68 0a 0f             	push   0xf0a
    4354:	6a 00                	push   0x0
    4356:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4359:	ff 76 f6             	push   WORD PTR [bp-0xa]
    435c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    435f:	06                   	push   es
    4360:	57                   	push   di
    4361:	9a bb 24 93 43       	call   0x4393:0x24bb
    4366:	09 d0                	or     ax,dx
    4368:	74 02                	je     0x436c
    436a:	eb 11                	jmp    0x437d
    436c:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    4370:	74 03                	je     0x4375
    4372:	e9 5f ff             	jmp    0x42d4
    4375:	31 c0                	xor    ax,ax
    4377:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    437a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    437d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4380:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4383:	c9                   	leave
    4384:	ca 0a 00             	retf   0xa
    4387:	c8 0a 00 00          	enter  0xa,0x0
    438b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    438e:	06                   	push   es
    438f:	57                   	push   di
    4390:	9a b9 62 eb 43       	call   0x43eb:0x62b9
    4395:	50                   	push   ax
    4396:	9a 40 45 00 00       	call   0x0:0x4540
    439b:	5a                   	pop    dx
    439c:	3b c2                	cmp    ax,dx
    439e:	75 36                	jne    0x43d6
    43a0:	31 c0                	xor    ax,ax
    43a2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    43a5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    43a8:	a1 f4 14             	mov    ax,ds:0x14f4
    43ab:	0b 06 f6 14          	or     ax,WORD PTR ds:0x14f6
    43af:	74 23                	je     0x43d4
    43b1:	c4 3e f4 14          	les    di,DWORD PTR ds:0x14f4
    43b5:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    43b9:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    43bd:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    43c0:	75 12                	jne    0x43d4
    43c2:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    43c5:	75 0d                	jne    0x43d4
    43c7:	a1 f4 14             	mov    ax,ds:0x14f4
    43ca:	8b 16 f6 14          	mov    dx,WORD PTR ds:0x14f6
    43ce:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    43d1:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    43d4:	eb 1d                	jmp    0x43f3
    43d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    43d9:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    43dd:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    43e1:	6a 00                	push   0x0
    43e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43e6:	06                   	push   es
    43e7:	57                   	push   di
    43e8:	9a a8 42 39 44       	call   0x4439:0x42a8
    43ed:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    43f0:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    43f3:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    43f7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    43fa:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    43fd:	74 40                	je     0x443f
    43ff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4402:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4406:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4409:	26 2b 45 1e          	sub    ax,WORD PTR es:[di+0x1e]
    440d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4410:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4413:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    4417:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    441a:	26 2b 45 20          	sub    ax,WORD PTR es:[di+0x20]
    441e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4421:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4424:	26 ff 35             	push   WORD PTR es:[di]
    4427:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    442b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    442e:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4431:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4434:	06                   	push   es
    4435:	57                   	push   di
    4436:	9a bb 24 a2 44       	call   0x44a2:0x24bb
    443b:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    443f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4442:	c9                   	leave
    4443:	ca 08 00             	retf   0x8
    4446:	c8 04 00 00          	enter  0x4,0x0
    444a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    444d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4450:	3d 07 00             	cmp    ax,0x7
    4453:	75 26                	jne    0x447b
    4455:	ff 76 08             	push   WORD PTR [bp+0x8]
    4458:	ff 76 06             	push   WORD PTR [bp+0x6]
    445b:	ff 76 08             	push   WORD PTR [bp+0x8]
    445e:	ff 76 06             	push   WORD PTR [bp+0x6]
    4461:	9a a8 17 6f 44       	call   0x446f:0x17a8
    4466:	89 c7                	mov    di,ax
    4468:	8e c2                	mov    es,dx
    446a:	06                   	push   es
    446b:	57                   	push   di
    446c:	9a 22 41 a3 45       	call   0x45a3:0x4122
    4471:	08 c0                	or     al,al
    4473:	75 03                	jne    0x4478
    4475:	e9 5a 01             	jmp    0x45d2
    4478:	e9 48 01             	jmp    0x45c3
    447b:	3d 08 00             	cmp    ax,0x8
    447e:	75 10                	jne    0x4490
    4480:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4483:	26 f6 45 28 20       	test   BYTE PTR es:[di+0x28],0x20
    4488:	74 03                	je     0x448d
    448a:	e9 45 01             	jmp    0x45d2
    448d:	e9 33 01             	jmp    0x45c3
    4490:	3d 84 00             	cmp    ax,0x84
    4493:	75 59                	jne    0x44ee
    4495:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4498:	06                   	push   es
    4499:	57                   	push   di
    449a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    449d:	06                   	push   es
    449e:	57                   	push   di
    449f:	9a 15 25 c5 44       	call   0x44c5:0x2515
    44a4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    44a7:	26 83 7d 0a ff       	cmp    WORD PTR es:[di+0xa],0xffff
    44ac:	75 3a                	jne    0x44e8
    44ae:	26 83 7d 08 ff       	cmp    WORD PTR es:[di+0x8],0xffff
    44b3:	75 33                	jne    0x44e8
    44b5:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    44b9:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    44bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c0:	06                   	push   es
    44c1:	57                   	push   di
    44c2:	9a 06 1a d3 44       	call   0x44d3:0x1a06
    44c7:	52                   	push   dx
    44c8:	50                   	push   ax
    44c9:	6a 00                	push   0x0
    44cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ce:	06                   	push   es
    44cf:	57                   	push   di
    44d0:	9a a8 42 05 45       	call   0x4505:0x42a8
    44d5:	09 d0                	or     ax,dx
    44d7:	74 0f                	je     0x44e8
    44d9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    44dc:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    44e2:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    44e8:	e9 e7 00             	jmp    0x45d2
    44eb:	e9 d5 00             	jmp    0x45c3
    44ee:	3d 00 02             	cmp    ax,0x200
    44f1:	72 1e                	jb     0x4511
    44f3:	3d 09 02             	cmp    ax,0x209
    44f6:	77 19                	ja     0x4511
    44f8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    44fb:	06                   	push   es
    44fc:	57                   	push   di
    44fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4500:	06                   	push   es
    4501:	57                   	push   di
    4502:	9a 87 43 23 45       	call   0x4523:0x4387
    4507:	08 c0                	or     al,al
    4509:	74 03                	je     0x450e
    450b:	e9 c4 00             	jmp    0x45d2
    450e:	e9 b2 00             	jmp    0x45c3
    4511:	3d 00 01             	cmp    ax,0x100
    4514:	72 19                	jb     0x452f
    4516:	3d 08 01             	cmp    ax,0x108
    4519:	77 14                	ja     0x452f
    451b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    451e:	06                   	push   es
    451f:	57                   	push   di
    4520:	9a 96 24 3c 45       	call   0x453c:0x2496
    4525:	08 c0                	or     al,al
    4527:	74 03                	je     0x452c
    4529:	e9 a6 00             	jmp    0x45d2
    452c:	e9 94 00             	jmp    0x45c3
    452f:	3d 1f 00             	cmp    ax,0x1f
    4532:	75 49                	jne    0x457d
    4534:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4537:	06                   	push   es
    4538:	57                   	push   di
    4539:	9a b9 62 79 45       	call   0x4579:0x62b9
    453e:	50                   	push   ax
    453f:	9a 38 53 00 00       	call   0x0:0x5338
    4544:	5a                   	pop    dx
    4545:	3b c2                	cmp    ax,dx
    4547:	75 32                	jne    0x457b
    4549:	a1 f4 14             	mov    ax,ds:0x14f4
    454c:	0b 06 f6 14          	or     ax,WORD PTR ds:0x14f6
    4550:	74 29                	je     0x457b
    4552:	c4 3e f4 14          	les    di,DWORD PTR ds:0x14f4
    4556:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    455a:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    455e:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    4561:	75 18                	jne    0x457b
    4563:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    4566:	75 13                	jne    0x457b
    4568:	6a 1f                	push   0x1f
    456a:	6a 00                	push   0x0
    456c:	6a 00                	push   0x0
    456e:	6a 00                	push   0x0
    4570:	c4 3e f4 14          	les    di,DWORD PTR ds:0x14f4
    4574:	06                   	push   es
    4575:	57                   	push   di
    4576:	9a bb 24 d0 45       	call   0x45d0:0x24bb
    457b:	eb 46                	jmp    0x45c3
    457d:	83 3e ec 13 ff       	cmp    WORD PTR ds:0x13ec,0xffff
    4582:	74 3f                	je     0x45c3
    4584:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4587:	26 8b 05             	mov    ax,WORD PTR es:[di]
    458a:	3b 06 ec 13          	cmp    ax,WORD PTR ds:0x13ec
    458e:	75 33                	jne    0x45c3
    4590:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4593:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    4598:	75 29                	jne    0x45c3
    459a:	ff 76 08             	push   WORD PTR [bp+0x8]
    459d:	ff 76 06             	push   WORD PTR [bp+0x6]
    45a0:	9a a8 17 a9 4e       	call   0x4ea9:0x17a8
    45a5:	89 c7                	mov    di,ax
    45a7:	8e c2                	mov    es,dx
    45a9:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    45ae:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    45b3:	74 0e                	je     0x45c3
    45b5:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    45ba:	06                   	push   es
    45bb:	57                   	push   di
    45bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45bf:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    45c3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    45c6:	06                   	push   es
    45c7:	57                   	push   di
    45c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45cb:	06                   	push   es
    45cc:	57                   	push   di
    45cd:	9a 15 25 65 46       	call   0x4665:0x2515
    45d2:	c9                   	leave
    45d3:	ca 08 00             	retf   0x8
    45d6:	c8 82 00 00          	enter  0x82,0x0
    45da:	31 c0                	xor    ax,ax
    45dc:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    45e0:	eb 04                	jmp    0x45e6
    45e2:	ff 86 7e ff          	inc    WORD PTR [bp-0x82]
    45e6:	8a 86 7e ff          	mov    al,BYTE PTR [bp-0x82]
    45ea:	8b be 7e ff          	mov    di,WORD PTR [bp-0x82]
    45ee:	88 43 80             	mov    BYTE PTR [bp+di-0x80],al
    45f1:	83 be 7e ff 7f       	cmp    WORD PTR [bp-0x82],0x7f
    45f6:	75 ea                	jne    0x45e2
    45f8:	c9                   	leave
    45f9:	c3                   	ret
    45fa:	c8 04 00 00          	enter  0x4,0x0
    45fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4601:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    4607:	74 4f                	je     0x4658
    4609:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    460c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    460f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4612:	26 83 3d 0f          	cmp    WORD PTR es:[di],0xf
    4616:	75 0a                	jne    0x4622
    4618:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    461d:	74 03                	je     0x4622
    461f:	e8 b4 ff             	call   0x45d6
    4622:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4625:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    462a:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    462f:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    4634:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4637:	26 ff 35             	push   WORD PTR es:[di]
    463a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    463e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4642:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    4646:	9a ff ff 00 00       	call   0x0:0xffff
    464b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    464e:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4652:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    4656:	eb 0f                	jmp    0x4667
    4658:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    465b:	06                   	push   es
    465c:	57                   	push   di
    465d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4660:	06                   	push   es
    4661:	57                   	push   di
    4662:	9a 10 26 79 46       	call   0x4679:0x2610
    4667:	c9                   	leave
    4668:	ca 08 00             	retf   0x8
    466b:	c8 0a 00 00          	enter  0xa,0x0
    466f:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    4673:	ff 76 08             	push   WORD PTR [bp+0x8]
    4676:	9a 4f 0b ad 46       	call   0x46ad:0xb4f
    467b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    467e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4681:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4684:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    4687:	74 35                	je     0x46be
    4689:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    468c:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    468f:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    4692:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4695:	05 00 20             	add    ax,0x2000
    4698:	50                   	push   ax
    4699:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    469d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    46a1:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    46a5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    46a8:	06                   	push   es
    46a9:	57                   	push   di
    46aa:	9a bb 24 c9 46       	call   0x46c9:0x24bb
    46af:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    46b2:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    46b6:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    46ba:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    46be:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    46c1:	c9                   	leave
    46c2:	c2 06 00             	ret    0x6
    46c5:	00 00                	add    BYTE PTR [bx+si],al
    46c7:	f8                   	clc
    46c8:	47                   	inc    di
    46c9:	e7 46                	out    0x46,ax
    46cb:	c8 2e 00 00          	enter  0x2e,0x0
    46cf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    46d2:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    46d6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    46d9:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    46dd:	75 18                	jne    0x46f7
    46df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46e2:	06                   	push   es
    46e3:	57                   	push   di
    46e4:	9a b9 62 ea 47       	call   0x47ea:0x62b9
    46e9:	50                   	push   ax
    46ea:	8d 7e d8             	lea    di,[bp-0x28]
    46ed:	16                   	push   ss
    46ee:	57                   	push   di
    46ef:	9a ff ff 00 00       	call   0x0:0xffff
    46f4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    46f7:	b8 c5 46             	mov    ax,0x46c5
    46fa:	0e                   	push   cs
    46fb:	50                   	push   ax
    46fc:	55                   	push   bp
    46fd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4701:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4705:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4708:	26 8b 85 92 00       	mov    ax,WORD PTR es:[di+0x92]
    470d:	26 0b 85 94 00       	or     ax,WORD PTR es:[di+0x94]
    4712:	75 0f                	jne    0x4723
    4714:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4717:	06                   	push   es
    4718:	57                   	push   di
    4719:	26 c4 3d             	les    di,DWORD PTR es:[di]
    471c:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    4720:	e9 b8 00             	jmp    0x47db
    4723:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4726:	9a 11 49 00 00       	call   0x0:0x4911
    472b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    472e:	c7 46 fc 02 00       	mov    WORD PTR [bp-0x4],0x2
    4733:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4736:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    473b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    473f:	48                   	dec    ax
    4740:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    4743:	31 c0                	xor    ax,ax
    4745:	3b 46 d6             	cmp    ax,WORD PTR [bp-0x2a]
    4748:	7f 71                	jg     0x47bb
    474a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    474d:	eb 03                	jmp    0x4752
    474f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4752:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4755:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4758:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    475d:	06                   	push   es
    475e:	57                   	push   di
    475f:	9a d0 0d 83 48       	call   0x4883:0xdd0
    4764:	89 c7                	mov    di,ax
    4766:	8e c2                	mov    es,dx
    4768:	89 7e d2             	mov    WORD PTR [bp-0x2e],di
    476b:	8c 46 d4             	mov    WORD PTR [bp-0x2c],es
    476e:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4773:	75 07                	jne    0x477c
    4775:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    477a:	74 37                	je     0x47b3
    477c:	c4 7e d2             	les    di,DWORD PTR [bp-0x2e]
    477f:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    4784:	74 2d                	je     0x47b3
    4786:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4789:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    478d:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    4791:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    4795:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    4799:	50                   	push   ax
    479a:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    479e:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    47a2:	50                   	push   ax
    47a3:	9a ff ff 00 00       	call   0x0:0xffff
    47a8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    47ab:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    47af:	75 02                	jne    0x47b3
    47b1:	eb 08                	jmp    0x47bb
    47b3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    47b6:	3b 46 d6             	cmp    ax,WORD PTR [bp-0x2a]
    47b9:	75 94                	jne    0x474f
    47bb:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    47bf:	74 0f                	je     0x47d0
    47c1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    47c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47c7:	06                   	push   es
    47c8:	57                   	push   di
    47c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47cc:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    47d0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    47d3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    47d6:	9a 60 49 00 00       	call   0x0:0x4960
    47db:	ff 76 f8             	push   WORD PTR [bp-0x8]
    47de:	6a 00                	push   0x0
    47e0:	6a 00                	push   0x0
    47e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47e5:	06                   	push   es
    47e6:	57                   	push   di
    47e7:	9a 50 48 0a 48       	call   0x480a:0x4850
    47ec:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    47f0:	83 c4 06             	add    sp,0x6
    47f3:	b8 18 48             	mov    ax,0x4818
    47f6:	0e                   	push   cs
    47f7:	50                   	push   ax
    47f8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    47fb:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    4800:	75 15                	jne    0x4817
    4802:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4805:	06                   	push   es
    4806:	57                   	push   di
    4807:	9a b9 62 57 49       	call   0x4957:0x62b9
    480c:	50                   	push   ax
    480d:	8d 7e d8             	lea    di,[bp-0x28]
    4810:	16                   	push   ss
    4811:	57                   	push   di
    4812:	9a ff ff 00 00       	call   0x0:0xffff
    4817:	cb                   	retf
    4818:	c9                   	leave
    4819:	ca 08 00             	retf   0x8
    481c:	c8 0c 00 00          	enter  0xc,0x0
    4820:	c7 46 f4 0f 00       	mov    WORD PTR [bp-0xc],0xf
    4825:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4828:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    482b:	31 c0                	xor    ax,ax
    482d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4830:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4833:	31 c0                	xor    ax,ax
    4835:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4838:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    483b:	8d 7e f4             	lea    di,[bp-0xc]
    483e:	16                   	push   ss
    483f:	57                   	push   di
    4840:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4843:	06                   	push   es
    4844:	57                   	push   di
    4845:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4848:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    484c:	c9                   	leave
    484d:	ca 06 00             	retf   0x6
    4850:	c8 16 00 00          	enter  0x16,0x0
    4854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4857:	26 8b 85 92 00       	mov    ax,WORD PTR es:[di+0x92]
    485c:	26 0b 85 94 00       	or     ax,WORD PTR es:[di+0x94]
    4861:	75 03                	jne    0x4866
    4863:	e9 04 01             	jmp    0x496a
    4866:	31 c0                	xor    ax,ax
    4868:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    486b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    486e:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    4871:	74 20                	je     0x4893
    4873:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4876:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4879:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    487e:	06                   	push   es
    487f:	57                   	push   di
    4880:	9a 58 0e bd 48       	call   0x48bd:0xe58
    4885:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4888:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    488c:	7d 05                	jge    0x4893
    488e:	31 c0                	xor    ax,ax
    4890:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4893:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4896:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    489b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    489f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    48a2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    48a5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    48a8:	7c 03                	jl     0x48ad
    48aa:	e9 bd 00             	jmp    0x496a
    48ad:	ff 76 fe             	push   WORD PTR [bp-0x2]
    48b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48b3:	26 c4 bd 92 00       	les    di,DWORD PTR es:[di+0x92]
    48b8:	06                   	push   es
    48b9:	57                   	push   di
    48ba:	9a d0 0d 02 49       	call   0x4902:0xdd0
    48bf:	89 c7                	mov    di,ax
    48c1:	8e c2                	mov    es,dx
    48c3:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    48c6:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    48c9:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    48ce:	75 0a                	jne    0x48da
    48d0:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    48d5:	75 03                	jne    0x48da
    48d7:	e9 8a 00             	jmp    0x4964
    48da:	ff 76 0e             	push   WORD PTR [bp+0xe]
    48dd:	8d 7e ec             	lea    di,[bp-0x14]
    48e0:	16                   	push   ss
    48e1:	57                   	push   di
    48e2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    48e5:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    48e9:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    48ed:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    48f1:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    48f5:	50                   	push   ax
    48f6:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    48fa:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    48fe:	50                   	push   ax
    48ff:	9a 88 06 ab 49       	call   0x49ab:0x688
    4904:	9a ff ff 00 00       	call   0x0:0xffff
    4909:	09 c0                	or     ax,ax
    490b:	74 57                	je     0x4964
    490d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4910:	9a ff ff 00 00       	call   0x0:0xffff
    4915:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4918:	ff 76 0e             	push   WORD PTR [bp+0xe]
    491b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    491e:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    4922:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    4926:	6a 00                	push   0x0
    4928:	6a 00                	push   0x0
    492a:	9a ff ff 00 00       	call   0x0:0xffff
    492f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4932:	6a 00                	push   0x0
    4934:	6a 00                	push   0x0
    4936:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4939:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    493d:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    4941:	9a ff ff 00 00       	call   0x0:0xffff
    4946:	6a 0f                	push   0xf
    4948:	ff 76 0e             	push   WORD PTR [bp+0xe]
    494b:	6a 00                	push   0x0
    494d:	6a 00                	push   0x0
    494f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4952:	06                   	push   es
    4953:	57                   	push   di
    4954:	9a bb 24 97 4a       	call   0x4a97:0x24bb
    4959:	ff 76 0e             	push   WORD PTR [bp+0xe]
    495c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    495f:	9a ff ff 00 00       	call   0x0:0xffff
    4964:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4967:	e9 38 ff             	jmp    0x48a2
    496a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    496d:	26 8b 85 96 00       	mov    ax,WORD PTR es:[di+0x96]
    4972:	26 0b 85 98 00       	or     ax,WORD PTR es:[di+0x98]
    4977:	75 03                	jne    0x497c
    4979:	e9 0c 01             	jmp    0x4a88
    497c:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    4981:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4985:	48                   	dec    ax
    4986:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4989:	31 c0                	xor    ax,ax
    498b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    498e:	7e 03                	jle    0x4993
    4990:	e9 f5 00             	jmp    0x4a88
    4993:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4996:	eb 03                	jmp    0x499b
    4998:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    499b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    499e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49a1:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    49a6:	06                   	push   es
    49a7:	57                   	push   di
    49a8:	9a d0 0d 1c 4a       	call   0x4a1c:0xdd0
    49ad:	89 c7                	mov    di,ax
    49af:	8e c2                	mov    es,dx
    49b1:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    49b4:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    49b7:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    49bd:	75 03                	jne    0x49c2
    49bf:	e9 bb 00             	jmp    0x4a7d
    49c2:	26 f6 45 26 10       	test   BYTE PTR es:[di+0x26],0x10
    49c7:	75 03                	jne    0x49cc
    49c9:	e9 b1 00             	jmp    0x4a7d
    49cc:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    49d1:	75 0a                	jne    0x49dd
    49d3:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    49d8:	75 03                	jne    0x49dd
    49da:	e9 a0 00             	jmp    0x4a7d
    49dd:	6a ff                	push   0xffff
    49df:	6a ef                	push   0xffef
    49e1:	9a a5 0c 35 4a       	call   0x4a35:0xca5
    49e6:	52                   	push   dx
    49e7:	50                   	push   ax
    49e8:	9a 3a 4a 00 00       	call   0x0:0x4a3a
    49ed:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    49f0:	ff 76 0e             	push   WORD PTR [bp+0xe]
    49f3:	8d 7e ea             	lea    di,[bp-0x16]
    49f6:	16                   	push   ss
    49f7:	57                   	push   di
    49f8:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    49fb:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    49ff:	48                   	dec    ax
    4a00:	50                   	push   ax
    4a01:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    4a05:	48                   	dec    ax
    4a06:	50                   	push   ax
    4a07:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    4a0b:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    4a0f:	50                   	push   ax
    4a10:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    4a14:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    4a18:	50                   	push   ax
    4a19:	9a 88 06 6b 4a       	call   0x4a6b:0x688
    4a1e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4a21:	9a 71 4a 00 00       	call   0x0:0x4a71
    4a26:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4a29:	9a 79 4a 00 00       	call   0x0:0x4a79
    4a2e:	6a ff                	push   0xffff
    4a30:	6a eb                	push   0xffeb
    4a32:	9a a5 0c f3 4a       	call   0x4af3:0xca5
    4a37:	52                   	push   dx
    4a38:	50                   	push   ax
    4a39:	9a ff ff 00 00       	call   0x0:0xffff
    4a3e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4a41:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4a44:	8d 7e ea             	lea    di,[bp-0x16]
    4a47:	16                   	push   ss
    4a48:	57                   	push   di
    4a49:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4a4c:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    4a50:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    4a54:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    4a58:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    4a5c:	40                   	inc    ax
    4a5d:	50                   	push   ax
    4a5e:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    4a62:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    4a66:	40                   	inc    ax
    4a67:	50                   	push   ax
    4a68:	9a 88 06 fa 5f       	call   0x5ffa:0x688
    4a6d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4a70:	9a ff ff 00 00       	call   0x0:0xffff
    4a75:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4a78:	9a ff ff 00 00       	call   0x0:0xffff
    4a7d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a80:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    4a83:	74 03                	je     0x4a88
    4a85:	e9 10 ff             	jmp    0x4998
    4a88:	c9                   	leave
    4a89:	ca 0a 00             	retf   0xa
    4a8c:	55                   	push   bp
    4a8d:	89 e5                	mov    bp,sp
    4a8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a92:	06                   	push   es
    4a93:	57                   	push   di
    4a94:	9a fd 39 be 4a       	call   0x4abe:0x39fd
    4a99:	09 c0                	or     ax,ax
    4a9b:	75 14                	jne    0x4ab1
    4a9d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4aa0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4aa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4aa6:	06                   	push   es
    4aa7:	57                   	push   di
    4aa8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4aab:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4aaf:	eb 0f                	jmp    0x4ac0
    4ab1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ab4:	06                   	push   es
    4ab5:	57                   	push   di
    4ab6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ab9:	06                   	push   es
    4aba:	57                   	push   di
    4abb:	9a cb 46 06 4b       	call   0x4b06:0x46cb
    4ac0:	c9                   	leave
    4ac1:	ca 08 00             	retf   0x8
    4ac4:	55                   	push   bp
    4ac5:	89 e5                	mov    bp,sp
    4ac7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4aca:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    4ace:	06                   	push   es
    4acf:	57                   	push   di
    4ad0:	e8 98 fb             	call   0x466b
    4ad3:	08 c0                	or     al,al
    4ad5:	75 12                	jne    0x4ae9
    4ad7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ada:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4add:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ae0:	06                   	push   es
    4ae1:	57                   	push   di
    4ae2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ae5:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4ae9:	c9                   	leave
    4aea:	ca 08 00             	retf   0x8
    4aed:	55                   	push   bp
    4aee:	89 e5                	mov    bp,sp
    4af0:	9a 43 0d c7 4c       	call   0x4cc7:0xd43
    4af5:	68 24 0f             	push   0xf24
    4af8:	6a 00                	push   0x0
    4afa:	6a 00                	push   0x0
    4afc:	6a 00                	push   0x0
    4afe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b01:	06                   	push   es
    4b02:	57                   	push   di
    4b03:	9a bb 24 29 4b       	call   0x4b29:0x24bb
    4b08:	c9                   	leave
    4b09:	ca 08 00             	retf   0x8
    4b0c:	55                   	push   bp
    4b0d:	89 e5                	mov    bp,sp
    4b0f:	68 25 0f             	push   0xf25
    4b12:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b15:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4b19:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4b1d:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    4b21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b24:	06                   	push   es
    4b25:	57                   	push   di
    4b26:	9a bb 24 43 4b       	call   0x4b43:0x24bb
    4b2b:	c9                   	leave
    4b2c:	ca 08 00             	retf   0x8
    4b2f:	55                   	push   bp
    4b30:	89 e5                	mov    bp,sp
    4b32:	68 26 0f             	push   0xf26
    4b35:	6a 00                	push   0x0
    4b37:	6a 00                	push   0x0
    4b39:	6a 00                	push   0x0
    4b3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b3e:	06                   	push   es
    4b3f:	57                   	push   di
    4b40:	9a bb 24 5d 4b       	call   0x4b5d:0x24bb
    4b45:	c9                   	leave
    4b46:	ca 08 00             	retf   0x8
    4b49:	55                   	push   bp
    4b4a:	89 e5                	mov    bp,sp
    4b4c:	68 27 0f             	push   0xf27
    4b4f:	6a 00                	push   0x0
    4b51:	6a 00                	push   0x0
    4b53:	6a 00                	push   0x0
    4b55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b58:	06                   	push   es
    4b59:	57                   	push   di
    4b5a:	9a bb 24 5e 4d       	call   0x4d5e:0x24bb
    4b5f:	c9                   	leave
    4b60:	ca 08 00             	retf   0x8
    4b63:	55                   	push   bp
    4b64:	89 e5                	mov    bp,sp
    4b66:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b69:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    4b6d:	06                   	push   es
    4b6e:	57                   	push   di
    4b6f:	e8 f9 fa             	call   0x466b
    4b72:	08 c0                	or     al,al
    4b74:	75 12                	jne    0x4b88
    4b76:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b79:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b7f:	06                   	push   es
    4b80:	57                   	push   di
    4b81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b84:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4b88:	c9                   	leave
    4b89:	ca 08 00             	retf   0x8
    4b8c:	55                   	push   bp
    4b8d:	89 e5                	mov    bp,sp
    4b8f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b92:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4b96:	06                   	push   es
    4b97:	57                   	push   di
    4b98:	e8 d0 fa             	call   0x466b
    4b9b:	08 c0                	or     al,al
    4b9d:	75 12                	jne    0x4bb1
    4b9f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ba2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ba5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ba8:	06                   	push   es
    4ba9:	57                   	push   di
    4baa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bad:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4bb1:	c9                   	leave
    4bb2:	ca 08 00             	retf   0x8
    4bb5:	55                   	push   bp
    4bb6:	89 e5                	mov    bp,sp
    4bb8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4bbb:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4bbf:	06                   	push   es
    4bc0:	57                   	push   di
    4bc1:	e8 a7 fa             	call   0x466b
    4bc4:	08 c0                	or     al,al
    4bc6:	75 12                	jne    0x4bda
    4bc8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bcb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bd1:	06                   	push   es
    4bd2:	57                   	push   di
    4bd3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bd6:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4bda:	c9                   	leave
    4bdb:	ca 08 00             	retf   0x8
    4bde:	55                   	push   bp
    4bdf:	89 e5                	mov    bp,sp
    4be1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4be4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4be8:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4bec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4bef:	06                   	push   es
    4bf0:	57                   	push   di
    4bf1:	e8 77 fa             	call   0x466b
    4bf4:	08 c0                	or     al,al
    4bf6:	75 12                	jne    0x4c0a
    4bf8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bfb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c01:	06                   	push   es
    4c02:	57                   	push   di
    4c03:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c06:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4c0a:	c9                   	leave
    4c0b:	ca 08 00             	retf   0x8
    4c0e:	55                   	push   bp
    4c0f:	89 e5                	mov    bp,sp
    4c11:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c14:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4c18:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4c1c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c1f:	06                   	push   es
    4c20:	57                   	push   di
    4c21:	e8 47 fa             	call   0x466b
    4c24:	08 c0                	or     al,al
    4c26:	75 12                	jne    0x4c3a
    4c28:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4c2b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c31:	06                   	push   es
    4c32:	57                   	push   di
    4c33:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c36:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4c3a:	c9                   	leave
    4c3b:	ca 08 00             	retf   0x8
    4c3e:	55                   	push   bp
    4c3f:	89 e5                	mov    bp,sp
    4c41:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c44:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4c48:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4c4c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c4f:	06                   	push   es
    4c50:	57                   	push   di
    4c51:	e8 17 fa             	call   0x466b
    4c54:	08 c0                	or     al,al
    4c56:	75 12                	jne    0x4c6a
    4c58:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4c5b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c61:	06                   	push   es
    4c62:	57                   	push   di
    4c63:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c66:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4c6a:	c9                   	leave
    4c6b:	ca 08 00             	retf   0x8
    4c6e:	55                   	push   bp
    4c6f:	89 e5                	mov    bp,sp
    4c71:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c74:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4c78:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4c7c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c7f:	06                   	push   es
    4c80:	57                   	push   di
    4c81:	e8 e7 f9             	call   0x466b
    4c84:	08 c0                	or     al,al
    4c86:	75 12                	jne    0x4c9a
    4c88:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4c8b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c91:	06                   	push   es
    4c92:	57                   	push   di
    4c93:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c96:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4c9a:	c9                   	leave
    4c9b:	ca 08 00             	retf   0x8
    4c9e:	c8 08 00 00          	enter  0x8,0x0
    4ca2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ca5:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4ca9:	8d 7e f8             	lea    di,[bp-0x8]
    4cac:	16                   	push   ss
    4cad:	57                   	push   di
    4cae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cb1:	06                   	push   es
    4cb2:	57                   	push   di
    4cb3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cb6:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    4cba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cbd:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    4cc2:	06                   	push   es
    4cc3:	57                   	push   di
    4cc4:	9a c0 16 27 57       	call   0x5727:0x16c0
    4cc9:	50                   	push   ax
    4cca:	9a ff ff 00 00       	call   0x0:0xffff
    4ccf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4cd2:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    4cd8:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    4cde:	c9                   	leave
    4cdf:	ca 08 00             	retf   0x8
    4ce2:	c8 02 00 00          	enter  0x2,0x0
    4ce6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ce9:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    4cef:	74 23                	je     0x4d14
    4cf1:	26 f6 45 26 10       	test   BYTE PTR es:[di+0x26],0x10
    4cf6:	74 1c                	je     0x4d14
    4cf8:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    4cfc:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    4d00:	74 12                	je     0x4d14
    4d02:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d05:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4d09:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4d0d:	25 08 00             	and    ax,0x8
    4d10:	09 c0                	or     ax,ax
    4d12:	74 04                	je     0x4d18
    4d14:	b0 00                	mov    al,0x0
    4d16:	eb 02                	jmp    0x4d1a
    4d18:	b0 01                	mov    al,0x1
    4d1a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4d1d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d20:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4d24:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4d28:	25 03 00             	and    ax,0x3
    4d2b:	3d 03 00             	cmp    ax,0x3
    4d2e:	74 11                	je     0x4d41
    4d30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d33:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    4d38:	9a 03 58 00 00       	call   0x0:0x5803
    4d3d:	09 c0                	or     ax,ax
    4d3f:	75 04                	jne    0x4d45
    4d41:	b0 00                	mov    al,0x0
    4d43:	eb 02                	jmp    0x4d47
    4d45:	b0 01                	mov    al,0x1
    4d47:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    4d4a:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    4d4e:	74 10                	je     0x4d60
    4d50:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    4d54:	74 0a                	je     0x4d60
    4d56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d59:	06                   	push   es
    4d5a:	57                   	push   di
    4d5b:	9a 7b 61 68 4d       	call   0x4d68:0x617b
    4d60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d63:	06                   	push   es
    4d64:	57                   	push   di
    4d65:	9a 16 65 a2 4d       	call   0x4da2:0x6516
    4d6a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d6d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d73:	06                   	push   es
    4d74:	57                   	push   di
    4d75:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d78:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4d7c:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    4d80:	74 22                	je     0x4da4
    4d82:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    4d86:	75 12                	jne    0x4d9a
    4d88:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d8b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4d8f:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4d93:	25 c0 00             	and    ax,0xc0
    4d96:	09 c0                	or     ax,ax
    4d98:	74 0a                	je     0x4da4
    4d9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d9d:	06                   	push   es
    4d9e:	57                   	push   di
    4d9f:	9a 7b 61 b3 4d       	call   0x4db3:0x617b
    4da4:	c9                   	leave
    4da5:	ca 08 00             	retf   0x8
    4da8:	55                   	push   bp
    4da9:	89 e5                	mov    bp,sp
    4dab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dae:	06                   	push   es
    4daf:	57                   	push   di
    4db0:	9a 16 65 cf 4d       	call   0x4dcf:0x6516
    4db5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4db8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4dbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dbe:	06                   	push   es
    4dbf:	57                   	push   di
    4dc0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dc3:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dca:	06                   	push   es
    4dcb:	57                   	push   di
    4dcc:	9a f9 36 f2 4d       	call   0x4df2:0x36f9
    4dd1:	c9                   	leave
    4dd2:	ca 08 00             	retf   0x8
    4dd5:	55                   	push   bp
    4dd6:	89 e5                	mov    bp,sp
    4dd8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ddb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4dde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4de1:	06                   	push   es
    4de2:	57                   	push   di
    4de3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4de6:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4dea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ded:	06                   	push   es
    4dee:	57                   	push   di
    4def:	9a 16 65 5f 4e       	call   0x4e5f:0x6516
    4df4:	c9                   	leave
    4df5:	ca 08 00             	retf   0x8
    4df8:	c8 0e 00 00          	enter  0xe,0x0
    4dfc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4dff:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    4e02:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    4e05:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    4e09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e0c:	26 3b 85 a2 00       	cmp    ax,WORD PTR es:[di+0xa2]
    4e11:	74 03                	je     0x4e16
    4e13:	e9 ee 00             	jmp    0x4f04
    4e16:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4e19:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4e1d:	3d 01 00             	cmp    ax,0x1
    4e20:	74 03                	je     0x4e25
    4e22:	e9 9f 00             	jmp    0x4ec4
    4e25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e28:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4e2d:	74 07                	je     0x4e36
    4e2f:	c7 46 fe fe ff       	mov    WORD PTR [bp-0x2],0xfffe
    4e34:	eb 61                	jmp    0x4e97
    4e36:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4e3a:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    4e3e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e41:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4e45:	75 50                	jne    0x4e97
    4e47:	8d 7e f6             	lea    di,[bp-0xa]
    4e4a:	16                   	push   ss
    4e4b:	57                   	push   di
    4e4c:	9a 9e 57 00 00       	call   0x0:0x579e
    4e51:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4e54:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4e57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5a:	06                   	push   es
    4e5b:	57                   	push   di
    4e5c:	9a 06 1a 6d 4e       	call   0x4e6d:0x1a06
    4e61:	52                   	push   dx
    4e62:	50                   	push   ax
    4e63:	6a 00                	push   0x0
    4e65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e68:	06                   	push   es
    4e69:	57                   	push   di
    4e6a:	9a a8 42 e7 4f       	call   0x4fe7:0x42a8
    4e6f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4e72:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4e75:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4e78:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    4e7b:	74 0a                	je     0x4e87
    4e7d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4e80:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    4e84:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e87:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4e8b:	75 0a                	jne    0x4e97
    4e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e90:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    4e94:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e97:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4e9b:	74 25                	je     0x4ec2
    4e9d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4ea0:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4ea4:	06                   	push   es
    4ea5:	57                   	push   di
    4ea6:	9a 3e 63 00 4f       	call   0x4f00:0x633e
    4eab:	50                   	push   ax
    4eac:	9a ff ff 00 00       	call   0x0:0xffff
    4eb1:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4eb4:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    4eba:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    4ec0:	eb 54                	jmp    0x4f16
    4ec2:	eb 40                	jmp    0x4f04
    4ec4:	3d fe ff             	cmp    ax,0xfffe
    4ec7:	75 3b                	jne    0x4f04
    4ec9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4ecc:	26 81 7d 06 01 02    	cmp    WORD PTR es:[di+0x6],0x201
    4ed2:	75 30                	jne    0x4f04
    4ed4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4ed8:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    4edd:	74 25                	je     0x4f04
    4edf:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4ee3:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    4ee7:	9a ff ff 00 00       	call   0x0:0xffff
    4eec:	50                   	push   ax
    4eed:	9a ff ff 00 00       	call   0x0:0xffff
    4ef2:	5a                   	pop    dx
    4ef3:	3b c2                	cmp    ax,dx
    4ef5:	74 0d                	je     0x4f04
    4ef7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4efb:	06                   	push   es
    4efc:	57                   	push   di
    4efd:	9a e8 6f af 4f       	call   0x4faf:0x6fe8
    4f02:	eb 12                	jmp    0x4f16
    4f04:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f07:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f0d:	06                   	push   es
    4f0e:	57                   	push   di
    4f0f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f12:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4f16:	c9                   	leave
    4f17:	ca 08 00             	retf   0x8
    4f1a:	55                   	push   bp
    4f1b:	89 e5                	mov    bp,sp
    4f1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f20:	26 8b 85 ca 00       	mov    ax,WORD PTR es:[di+0xca]
    4f25:	09 c0                	or     ax,ax
    4f27:	74 15                	je     0x4f3e
    4f29:	ff 76 08             	push   WORD PTR [bp+0x8]
    4f2c:	ff 76 06             	push   WORD PTR [bp+0x6]
    4f2f:	26 ff b5 ce 00       	push   WORD PTR es:[di+0xce]
    4f34:	26 ff b5 cc 00       	push   WORD PTR es:[di+0xcc]
    4f39:	26 ff 9d c8 00       	call   DWORD PTR es:[di+0xc8]
    4f3e:	c9                   	leave
    4f3f:	ca 04 00             	retf   0x4
    4f42:	55                   	push   bp
    4f43:	89 e5                	mov    bp,sp
    4f45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f48:	26 8b 85 d2 00       	mov    ax,WORD PTR es:[di+0xd2]
    4f4d:	09 c0                	or     ax,ax
    4f4f:	74 15                	je     0x4f66
    4f51:	ff 76 08             	push   WORD PTR [bp+0x8]
    4f54:	ff 76 06             	push   WORD PTR [bp+0x6]
    4f57:	26 ff b5 d6 00       	push   WORD PTR es:[di+0xd6]
    4f5c:	26 ff b5 d4 00       	push   WORD PTR es:[di+0xd4]
    4f61:	26 ff 9d d0 00       	call   DWORD PTR es:[di+0xd0]
    4f66:	c9                   	leave
    4f67:	ca 04 00             	retf   0x4
    4f6a:	55                   	push   bp
    4f6b:	89 e5                	mov    bp,sp
    4f6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f70:	26 8b 85 b2 00       	mov    ax,WORD PTR es:[di+0xb2]
    4f75:	09 c0                	or     ax,ax
    4f77:	74 21                	je     0x4f9a
    4f79:	ff 76 08             	push   WORD PTR [bp+0x8]
    4f7c:	ff 76 06             	push   WORD PTR [bp+0x6]
    4f7f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4f82:	06                   	push   es
    4f83:	57                   	push   di
    4f84:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4f87:	50                   	push   ax
    4f88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f8b:	26 ff b5 b6 00       	push   WORD PTR es:[di+0xb6]
    4f90:	26 ff b5 b4 00       	push   WORD PTR es:[di+0xb4]
    4f95:	26 ff 9d b0 00       	call   DWORD PTR es:[di+0xb0]
    4f9a:	c9                   	leave
    4f9b:	ca 0a 00             	retf   0xa
    4f9e:	c8 0e 00 00          	enter  0xe,0x0
    4fa2:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    4fa6:	ff 76 08             	push   WORD PTR [bp+0x8]
    4fa9:	ff 76 06             	push   WORD PTR [bp+0x6]
    4fac:	9a a8 17 04 50       	call   0x5004:0x17a8
    4fb1:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4fb4:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4fb7:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4fba:	0b 46 f8             	or     ax,WORD PTR [bp-0x8]
    4fbd:	74 31                	je     0x4ff0
    4fbf:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4fc2:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    4fc5:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    4fc8:	75 05                	jne    0x4fcf
    4fca:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    4fcd:	74 21                	je     0x4ff0
    4fcf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4fd2:	26 80 bd f0 00 00    	cmp    BYTE PTR es:[di+0xf0],0x0
    4fd8:	74 16                	je     0x4ff0
    4fda:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4fdd:	06                   	push   es
    4fde:	57                   	push   di
    4fdf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4fe2:	06                   	push   es
    4fe3:	57                   	push   di
    4fe4:	9a 9e 4f b6 50       	call   0x50b6:0x4f9e
    4fe9:	08 c0                	or     al,al
    4feb:	74 03                	je     0x4ff0
    4fed:	e9 af 00             	jmp    0x509f
    4ff0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ff3:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    4ff6:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    4ff9:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4ffd:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5001:	9a fb 16 93 50       	call   0x5093:0x16fb
    5006:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    5009:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    500c:	81 c7 02 00          	add    di,0x2
    5010:	06                   	push   es
    5011:	57                   	push   di
    5012:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    5015:	50                   	push   ax
    5016:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5019:	06                   	push   es
    501a:	57                   	push   di
    501b:	b8 f1 ff             	mov    ax,0xfff1
    501e:	9a 6a 20 ae 51       	call   0x51ae:0x206a
    5023:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5026:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    502b:	75 02                	jne    0x502f
    502d:	eb 70                	jmp    0x509f
    502f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5032:	26 83 7d 02 70       	cmp    WORD PTR es:[di+0x2],0x70
    5037:	75 62                	jne    0x509b
    5039:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    503d:	75 5c                	jne    0x509b
    503f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5042:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5045:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5048:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    504b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    504e:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    5051:	74 22                	je     0x5075
    5053:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5056:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    505b:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    5060:	75 13                	jne    0x5075
    5062:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5065:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    5069:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    506d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5070:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    5073:	eb d6                	jmp    0x504b
    5075:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5078:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    507b:	74 1e                	je     0x509b
    507d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5080:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    5085:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    508a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    508e:	06                   	push   es
    508f:	57                   	push   di
    5090:	9a 92 77 43 51       	call   0x5143:0x7792
    5095:	08 c0                	or     al,al
    5097:	74 02                	je     0x509b
    5099:	eb 04                	jmp    0x509f
    509b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    509f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    50a2:	c9                   	leave
    50a3:	ca 08 00             	retf   0x8
    50a6:	55                   	push   bp
    50a7:	89 e5                	mov    bp,sp
    50a9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    50ac:	06                   	push   es
    50ad:	57                   	push   di
    50ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50b1:	06                   	push   es
    50b2:	57                   	push   di
    50b3:	9a 9e 4f e2 50       	call   0x50e2:0x4f9e
    50b8:	08 c0                	or     al,al
    50ba:	75 12                	jne    0x50ce
    50bc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    50bf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    50c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50c5:	06                   	push   es
    50c6:	57                   	push   di
    50c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50ca:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    50ce:	c9                   	leave
    50cf:	ca 08 00             	retf   0x8
    50d2:	55                   	push   bp
    50d3:	89 e5                	mov    bp,sp
    50d5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    50d8:	06                   	push   es
    50d9:	57                   	push   di
    50da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50dd:	06                   	push   es
    50de:	57                   	push   di
    50df:	9a 9e 4f 7b 51       	call   0x517b:0x4f9e
    50e4:	08 c0                	or     al,al
    50e6:	75 12                	jne    0x50fa
    50e8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    50eb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    50ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50f1:	06                   	push   es
    50f2:	57                   	push   di
    50f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50f6:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    50fa:	c9                   	leave
    50fb:	ca 08 00             	retf   0x8
    50fe:	55                   	push   bp
    50ff:	89 e5                	mov    bp,sp
    5101:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5104:	26 8b 85 c2 00       	mov    ax,WORD PTR es:[di+0xc2]
    5109:	09 c0                	or     ax,ax
    510b:	74 21                	je     0x512e
    510d:	ff 76 08             	push   WORD PTR [bp+0x8]
    5110:	ff 76 06             	push   WORD PTR [bp+0x6]
    5113:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5116:	06                   	push   es
    5117:	57                   	push   di
    5118:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    511b:	50                   	push   ax
    511c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    511f:	26 ff b5 c6 00       	push   WORD PTR es:[di+0xc6]
    5124:	26 ff b5 c4 00       	push   WORD PTR es:[di+0xc4]
    5129:	26 ff 9d c0 00       	call   DWORD PTR es:[di+0xc0]
    512e:	c9                   	leave
    512f:	ca 0a 00             	retf   0xa
    5132:	c8 0a 00 00          	enter  0xa,0x0
    5136:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    513a:	ff 76 08             	push   WORD PTR [bp+0x8]
    513d:	ff 76 06             	push   WORD PTR [bp+0x6]
    5140:	9a a8 17 a0 51       	call   0x51a0:0x17a8
    5145:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5148:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    514b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    514e:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    5151:	74 30                	je     0x5183
    5153:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5156:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    5159:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    515c:	75 05                	jne    0x5163
    515e:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    5161:	74 20                	je     0x5183
    5163:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5166:	26 80 bd f0 00 00    	cmp    BYTE PTR es:[di+0xf0],0x0
    516c:	74 15                	je     0x5183
    516e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5171:	06                   	push   es
    5172:	57                   	push   di
    5173:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5176:	06                   	push   es
    5177:	57                   	push   di
    5178:	9a 32 51 d7 51       	call   0x51d7:0x5132
    517d:	08 c0                	or     al,al
    517f:	74 02                	je     0x5183
    5181:	eb 3d                	jmp    0x51c0
    5183:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5186:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    5189:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    518c:	81 c7 02 00          	add    di,0x2
    5190:	06                   	push   es
    5191:	57                   	push   di
    5192:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5195:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    5199:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    519d:	9a fb 16 60 52       	call   0x5260:0x16fb
    51a2:	50                   	push   ax
    51a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51a6:	06                   	push   es
    51a7:	57                   	push   di
    51a8:	b8 f0 ff             	mov    ax,0xfff0
    51ab:	9a 6a 20 ba 52       	call   0x52ba:0x206a
    51b0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    51b3:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    51b8:	75 02                	jne    0x51bc
    51ba:	eb 04                	jmp    0x51c0
    51bc:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    51c0:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    51c3:	c9                   	leave
    51c4:	ca 08 00             	retf   0x8
    51c7:	55                   	push   bp
    51c8:	89 e5                	mov    bp,sp
    51ca:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    51cd:	06                   	push   es
    51ce:	57                   	push   di
    51cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51d2:	06                   	push   es
    51d3:	57                   	push   di
    51d4:	9a 32 51 03 52       	call   0x5203:0x5132
    51d9:	08 c0                	or     al,al
    51db:	75 12                	jne    0x51ef
    51dd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    51e0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    51e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51e6:	06                   	push   es
    51e7:	57                   	push   di
    51e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51eb:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    51ef:	c9                   	leave
    51f0:	ca 08 00             	retf   0x8
    51f3:	55                   	push   bp
    51f4:	89 e5                	mov    bp,sp
    51f6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    51f9:	06                   	push   es
    51fa:	57                   	push   di
    51fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51fe:	06                   	push   es
    51ff:	57                   	push   di
    5200:	9a 32 51 98 52       	call   0x5298:0x5132
    5205:	08 c0                	or     al,al
    5207:	75 12                	jne    0x521b
    5209:	ff 76 0c             	push   WORD PTR [bp+0xc]
    520c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    520f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5212:	06                   	push   es
    5213:	57                   	push   di
    5214:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5217:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    521b:	c9                   	leave
    521c:	ca 08 00             	retf   0x8
    521f:	55                   	push   bp
    5220:	89 e5                	mov    bp,sp
    5222:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5225:	26 8b 85 ba 00       	mov    ax,WORD PTR es:[di+0xba]
    522a:	09 c0                	or     ax,ax
    522c:	74 1d                	je     0x524b
    522e:	ff 76 08             	push   WORD PTR [bp+0x8]
    5231:	ff 76 06             	push   WORD PTR [bp+0x6]
    5234:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5237:	06                   	push   es
    5238:	57                   	push   di
    5239:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    523c:	26 ff b5 be 00       	push   WORD PTR es:[di+0xbe]
    5241:	26 ff b5 bc 00       	push   WORD PTR es:[di+0xbc]
    5246:	26 ff 9d b8 00       	call   DWORD PTR es:[di+0xb8]
    524b:	c9                   	leave
    524c:	ca 08 00             	retf   0x8
    524f:	c8 0a 00 00          	enter  0xa,0x0
    5253:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    5257:	ff 76 08             	push   WORD PTR [bp+0x8]
    525a:	ff 76 06             	push   WORD PTR [bp+0x6]
    525d:	9a a8 17 a5 59       	call   0x59a5:0x17a8
    5262:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5265:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    5268:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    526b:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    526e:	74 30                	je     0x52a0
    5270:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5273:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    5276:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    5279:	75 05                	jne    0x5280
    527b:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    527e:	74 20                	je     0x52a0
    5280:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5283:	26 80 bd f0 00 00    	cmp    BYTE PTR es:[di+0xf0],0x0
    5289:	74 15                	je     0x52a0
    528b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    528e:	06                   	push   es
    528f:	57                   	push   di
    5290:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5293:	06                   	push   es
    5294:	57                   	push   di
    5295:	9a 4f 52 e3 52       	call   0x52e3:0x524f
    529a:	08 c0                	or     al,al
    529c:	74 02                	je     0x52a0
    529e:	eb 2c                	jmp    0x52cc
    52a0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    52a3:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    52a6:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    52a9:	81 c7 02 00          	add    di,0x2
    52ad:	06                   	push   es
    52ae:	57                   	push   di
    52af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52b2:	06                   	push   es
    52b3:	57                   	push   di
    52b4:	b8 ef ff             	mov    ax,0xffef
    52b7:	9a 6a 20 2b 55       	call   0x552b:0x206a
    52bc:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    52bf:	26 80 7d 02 00       	cmp    BYTE PTR es:[di+0x2],0x0
    52c4:	75 02                	jne    0x52c8
    52c6:	eb 04                	jmp    0x52cc
    52c8:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    52cc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    52cf:	c9                   	leave
    52d0:	ca 08 00             	retf   0x8
    52d3:	55                   	push   bp
    52d4:	89 e5                	mov    bp,sp
    52d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    52d9:	06                   	push   es
    52da:	57                   	push   di
    52db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52de:	06                   	push   es
    52df:	57                   	push   di
    52e0:	9a 4f 52 62 53       	call   0x5362:0x524f
    52e5:	08 c0                	or     al,al
    52e7:	75 12                	jne    0x52fb
    52e9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    52ec:	ff 76 0a             	push   WORD PTR [bp+0xa]
    52ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52f2:	06                   	push   es
    52f3:	57                   	push   di
    52f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52f7:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    52fb:	c9                   	leave
    52fc:	ca 08 00             	retf   0x8
    52ff:	c8 04 00 00          	enter  0x4,0x0
    5303:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5306:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5309:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    530c:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    5310:	25 f0 ff             	and    ax,0xfff0
    5313:	3d 00 f1             	cmp    ax,0xf100
    5316:	75 67                	jne    0x537f
    5318:	26 83 7d 04 20       	cmp    WORD PTR es:[di+0x4],0x20
    531d:	74 60                	je     0x537f
    531f:	26 83 7d 04 2d       	cmp    WORD PTR es:[di+0x4],0x2d
    5324:	74 59                	je     0x537f
    5326:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5329:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    532e:	9a a7 5c 00 00       	call   0x0:0x5ca7
    5333:	09 c0                	or     ax,ax
    5335:	75 48                	jne    0x537f
    5337:	9a 90 57 00 00       	call   0x0:0x5790
    533c:	09 c0                	or     ax,ax
    533e:	75 3f                	jne    0x537f
    5340:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5344:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    5348:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    534c:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    534f:	75 05                	jne    0x5356
    5351:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    5354:	74 29                	je     0x537f
    5356:	6a 00                	push   0x0
    5358:	6a 00                	push   0x0
    535a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    535d:	06                   	push   es
    535e:	57                   	push   di
    535f:	9a 38 1a e4 54       	call   0x54e4:0x1a38
    5364:	68 17 0f             	push   0xf17
    5367:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    536a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    536e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5372:	31 d2                	xor    dx,dx
    5374:	52                   	push   dx
    5375:	50                   	push   ax
    5376:	e8 16 b8             	call   0xb8f
    5379:	09 d0                	or     ax,dx
    537b:	74 02                	je     0x537f
    537d:	eb 12                	jmp    0x5391
    537f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5382:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5385:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5388:	06                   	push   es
    5389:	57                   	push   di
    538a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    538d:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    5391:	c9                   	leave
    5392:	ca 08 00             	retf   0x8
    5395:	55                   	push   bp
    5396:	89 e5                	mov    bp,sp
    5398:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    539b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    539f:	06                   	push   es
    53a0:	57                   	push   di
    53a1:	e8 c7 f2             	call   0x466b
    53a4:	08 c0                	or     al,al
    53a6:	75 12                	jne    0x53ba
    53a8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    53ab:	ff 76 0a             	push   WORD PTR [bp+0xa]
    53ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53b1:	06                   	push   es
    53b2:	57                   	push   di
    53b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53b6:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    53ba:	c9                   	leave
    53bb:	ca 08 00             	retf   0x8
    53be:	c8 04 00 00          	enter  0x4,0x0
    53c2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    53c5:	26 83 7d 02 01       	cmp    WORD PTR es:[di+0x2],0x1
    53ca:	74 07                	je     0x53d3
    53cc:	26 83 7d 02 02       	cmp    WORD PTR es:[di+0x2],0x2
    53d1:	75 10                	jne    0x53e3
    53d3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    53d6:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    53da:	06                   	push   es
    53db:	57                   	push   di
    53dc:	e8 8c f2             	call   0x466b
    53df:	08 c0                	or     al,al
    53e1:	75 12                	jne    0x53f5
    53e3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    53e6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    53e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53ec:	06                   	push   es
    53ed:	57                   	push   di
    53ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53f1:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    53f5:	c9                   	leave
    53f6:	ca 08 00             	retf   0x8
    53f9:	55                   	push   bp
    53fa:	89 e5                	mov    bp,sp
    53fc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    53ff:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5403:	06                   	push   es
    5404:	57                   	push   di
    5405:	e8 63 f2             	call   0x466b
    5408:	08 c0                	or     al,al
    540a:	75 12                	jne    0x541e
    540c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    540f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5412:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5415:	06                   	push   es
    5416:	57                   	push   di
    5417:	26 c4 3d             	les    di,DWORD PTR es:[di]
    541a:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    541e:	c9                   	leave
    541f:	ca 08 00             	retf   0x8
    5422:	55                   	push   bp
    5423:	89 e5                	mov    bp,sp
    5425:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5428:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    542d:	a1 0e 2c             	mov    ax,ds:0x2c0e
    5430:	31 d2                	xor    dx,dx
    5432:	52                   	push   dx
    5433:	50                   	push   ax
    5434:	9a 49 54 00 00       	call   0x0:0x5449
    5439:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    543c:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5441:	a1 10 2c             	mov    ax,ds:0x2c10
    5444:	31 d2                	xor    dx,dx
    5446:	52                   	push   dx
    5447:	50                   	push   ax
    5448:	9a ff ff 00 00       	call   0x0:0xffff
    544d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5450:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5453:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5456:	06                   	push   es
    5457:	57                   	push   di
    5458:	26 c4 3d             	les    di,DWORD PTR es:[di]
    545b:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    545f:	c9                   	leave
    5460:	ca 08 00             	retf   0x8
    5463:	55                   	push   bp
    5464:	89 e5                	mov    bp,sp
    5466:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5469:	ff 76 0a             	push   WORD PTR [bp+0xa]
    546c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    546f:	06                   	push   es
    5470:	57                   	push   di
    5471:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5474:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    5478:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    547b:	31 c0                	xor    ax,ax
    547d:	26 89 85 a2 00       	mov    WORD PTR es:[di+0xa2],ax
    5482:	26 c6 85 a7 00 00    	mov    BYTE PTR es:[di+0xa7],0x0
    5488:	c9                   	leave
    5489:	ca 08 00             	retf   0x8
    548c:	c8 04 00 00          	enter  0x4,0x0
    5490:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5493:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5496:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5499:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    549c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    54a1:	74 1b                	je     0x54be
    54a3:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    54a7:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    54ab:	74 11                	je     0x54be
    54ad:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    54b0:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    54b6:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    54bc:	eb 12                	jmp    0x54d0
    54be:	ff 76 0c             	push   WORD PTR [bp+0xc]
    54c1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    54c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54c7:	06                   	push   es
    54c8:	57                   	push   di
    54c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54cc:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    54d0:	c9                   	leave
    54d1:	ca 08 00             	retf   0x8
    54d4:	c8 04 00 00          	enter  0x4,0x0
    54d8:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    54db:	50                   	push   ax
    54dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54df:	06                   	push   es
    54e0:	57                   	push   di
    54e1:	9a e5 14 f1 54       	call   0x54f1:0x14e5
    54e6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    54e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54ec:	06                   	push   es
    54ed:	57                   	push   di
    54ee:	9a fd 39 1d 55       	call   0x551d:0x39fd
    54f3:	48                   	dec    ax
    54f4:	09 c0                	or     ax,ax
    54f6:	7c 4e                	jl     0x5546
    54f8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    54fb:	eb 03                	jmp    0x5500
    54fd:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    5500:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5504:	74 08                	je     0x550e
    5506:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    550a:	74 02                	je     0x550e
    550c:	eb 38                	jmp    0x5546
    550e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5511:	50                   	push   ax
    5512:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5515:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5518:	06                   	push   es
    5519:	57                   	push   di
    551a:	9a 8f 39 b8 55       	call   0x55b8:0x398f
    551f:	89 c7                	mov    di,ax
    5521:	8e c2                	mov    es,dx
    5523:	06                   	push   es
    5524:	57                   	push   di
    5525:	b8 f7 ff             	mov    ax,0xfff7
    5528:	9a 6a 20 62 55       	call   0x5562:0x206a
    552d:	08 c0                	or     al,al
    552f:	75 0a                	jne    0x553b
    5531:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5535:	75 04                	jne    0x553b
    5537:	b0 00                	mov    al,0x0
    5539:	eb 02                	jmp    0x553d
    553b:	b0 01                	mov    al,0x1
    553d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5540:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5544:	75 b7                	jne    0x54fd
    5546:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5549:	c9                   	leave
    554a:	ca 06 00             	retf   0x6
    554d:	55                   	push   bp
    554e:	89 e5                	mov    bp,sp
    5550:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5553:	26 80 4d 28 04       	or     BYTE PTR es:[di+0x28],0x4
    5558:	6a 01                	push   0x1
    555a:	06                   	push   es
    555b:	57                   	push   di
    555c:	b8 f7 ff             	mov    ax,0xfff7
    555f:	9a 6a 20 85 55       	call   0x5585:0x206a
    5564:	98                   	cbw
    5565:	99                   	cwd
    5566:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5569:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    556d:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5571:	c9                   	leave
    5572:	ca 08 00             	retf   0x8
    5575:	55                   	push   bp
    5576:	89 e5                	mov    bp,sp
    5578:	6a 00                	push   0x0
    557a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    557d:	06                   	push   es
    557e:	57                   	push   di
    557f:	b8 f7 ff             	mov    ax,0xfff7
    5582:	9a 6a 20 cc 55       	call   0x55cc:0x206a
    5587:	98                   	cbw
    5588:	99                   	cwd
    5589:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    558c:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    5590:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5594:	c9                   	leave
    5595:	ca 08 00             	retf   0x8
    5598:	55                   	push   bp
    5599:	89 e5                	mov    bp,sp
    559b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    559e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    55a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55a4:	06                   	push   es
    55a5:	57                   	push   di
    55a6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55a9:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    55ad:	68 23 0f             	push   0xf23
    55b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55b3:	06                   	push   es
    55b4:	57                   	push   di
    55b5:	9a 9e 3a f6 55       	call   0x55f6:0x3a9e
    55ba:	c9                   	leave
    55bb:	ca 08 00             	retf   0x8
    55be:	55                   	push   bp
    55bf:	89 e5                	mov    bp,sp
    55c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55c4:	06                   	push   es
    55c5:	57                   	push   di
    55c6:	b8 f3 ff             	mov    ax,0xfff3
    55c9:	9a 6a 20 e0 55       	call   0x55e0:0x206a
    55ce:	c9                   	leave
    55cf:	ca 08 00             	retf   0x8
    55d2:	55                   	push   bp
    55d3:	89 e5                	mov    bp,sp
    55d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55d8:	06                   	push   es
    55d9:	57                   	push   di
    55da:	b8 f2 ff             	mov    ax,0xfff2
    55dd:	9a 6a 20 28 5d       	call   0x5d28:0x206a
    55e2:	c9                   	leave
    55e3:	ca 08 00             	retf   0x8
    55e6:	55                   	push   bp
    55e7:	89 e5                	mov    bp,sp
    55e9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    55ec:	06                   	push   es
    55ed:	57                   	push   di
    55ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55f1:	06                   	push   es
    55f2:	57                   	push   di
    55f3:	9a 87 43 0a 56       	call   0x560a:0x4387
    55f8:	08 c0                	or     al,al
    55fa:	75 10                	jne    0x560c
    55fc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    55ff:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5602:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5605:	06                   	push   es
    5606:	57                   	push   di
    5607:	9a 4d 2e 20 56       	call   0x5620:0x2e4d
    560c:	c9                   	leave
    560d:	ca 08 00             	retf   0x8
    5610:	55                   	push   bp
    5611:	89 e5                	mov    bp,sp
    5613:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5616:	06                   	push   es
    5617:	57                   	push   di
    5618:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    561b:	06                   	push   es
    561c:	57                   	push   di
    561d:	9a 43 3a 36 56       	call   0x5636:0x3a43
    5622:	c9                   	leave
    5623:	ca 08 00             	retf   0x8
    5626:	55                   	push   bp
    5627:	89 e5                	mov    bp,sp
    5629:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    562c:	06                   	push   es
    562d:	57                   	push   di
    562e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5631:	06                   	push   es
    5632:	57                   	push   di
    5633:	9a 43 3a 4c 56       	call   0x564c:0x3a43
    5638:	c9                   	leave
    5639:	ca 08 00             	retf   0x8
    563c:	55                   	push   bp
    563d:	89 e5                	mov    bp,sp
    563f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5642:	06                   	push   es
    5643:	57                   	push   di
    5644:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5647:	06                   	push   es
    5648:	57                   	push   di
    5649:	9a 43 3a 70 56       	call   0x5670:0x3a43
    564e:	c9                   	leave
    564f:	ca 08 00             	retf   0x8
    5652:	55                   	push   bp
    5653:	89 e5                	mov    bp,sp
    5655:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5658:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    565d:	75 13                	jne    0x5672
    565f:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    5663:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    5667:	74 09                	je     0x5672
    5669:	6a 00                	push   0x0
    566b:	06                   	push   es
    566c:	57                   	push   di
    566d:	9a 52 37 81 56       	call   0x5681:0x3752
    5672:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5675:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    567a:	75 07                	jne    0x5683
    567c:	06                   	push   es
    567d:	57                   	push   di
    567e:	9a a5 41 d1 56       	call   0x56d1:0x41a5
    5683:	c9                   	leave
    5684:	ca 08 00             	retf   0x8
    5687:	55                   	push   bp
    5688:	89 e5                	mov    bp,sp
    568a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    568d:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5692:	6a 00                	push   0x0
    5694:	6a 00                	push   0x0
    5696:	6a 00                	push   0x0
    5698:	6a 00                	push   0x0
    569a:	6a 00                	push   0x0
    569c:	26 8a 85 a7 00       	mov    al,BYTE PTR es:[di+0xa7]
    56a1:	98                   	cbw
    56a2:	8b f8                	mov    di,ax
    56a4:	d1 e7                	shl    di,1
    56a6:	ff b5 fc 14          	push   WORD PTR [di+0x14fc]
    56aa:	9a c8 5c 00 00       	call   0x0:0x5cc8
    56af:	c9                   	leave
    56b0:	ca 08 00             	retf   0x8
    56b3:	55                   	push   bp
    56b4:	89 e5                	mov    bp,sp
    56b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56b9:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    56be:	75 13                	jne    0x56d3
    56c0:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    56c4:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    56c8:	74 09                	je     0x56d3
    56ca:	6a 00                	push   0x0
    56cc:	06                   	push   es
    56cd:	57                   	push   di
    56ce:	9a 52 37 db 56       	call   0x56db:0x3752
    56d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d6:	06                   	push   es
    56d7:	57                   	push   di
    56d8:	9a fa 64 10 57       	call   0x5710:0x64fa
    56dd:	08 c0                	or     al,al
    56df:	74 1a                	je     0x56fb
    56e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56e4:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    56e9:	75 10                	jne    0x56fb
    56eb:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    56f0:	26 8a 45 2a          	mov    al,BYTE PTR es:[di+0x2a]
    56f4:	98                   	cbw
    56f5:	50                   	push   ax
    56f6:	9a ff ff 00 00       	call   0x0:0xffff
    56fb:	c9                   	leave
    56fc:	ca 08 00             	retf   0x8
    56ff:	55                   	push   bp
    5700:	89 e5                	mov    bp,sp
    5702:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5705:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5708:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    570b:	06                   	push   es
    570c:	57                   	push   di
    570d:	9a 46 2d 34 57       	call   0x5734:0x2d46
    5712:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5715:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    5719:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    571d:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    5722:	06                   	push   es
    5723:	57                   	push   di
    5724:	9a 84 16 69 57       	call   0x5769:0x1684
    5729:	68 09 0f             	push   0xf09
    572c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    572f:	06                   	push   es
    5730:	57                   	push   di
    5731:	9a 9e 3a 4b 57       	call   0x574b:0x3a9e
    5736:	c9                   	leave
    5737:	ca 08 00             	retf   0x8
    573a:	55                   	push   bp
    573b:	89 e5                	mov    bp,sp
    573d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5740:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5743:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5746:	06                   	push   es
    5747:	57                   	push   di
    5748:	9a 33 2d 55 57       	call   0x5755:0x2d33
    574d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5750:	06                   	push   es
    5751:	57                   	push   di
    5752:	9a fa 64 78 57       	call   0x5778:0x64fa
    5757:	08 c0                	or     al,al
    5759:	74 1f                	je     0x577a
    575b:	6a 30                	push   0x30
    575d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5760:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    5764:	06                   	push   es
    5765:	57                   	push   di
    5766:	9a 16 10 ed 58       	call   0x58ed:0x1016
    576b:	50                   	push   ax
    576c:	6a 00                	push   0x0
    576e:	6a 00                	push   0x0
    5770:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5773:	06                   	push   es
    5774:	57                   	push   di
    5775:	9a bb 24 85 57       	call   0x5785:0x24bb
    577a:	68 08 0f             	push   0xf08
    577d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5780:	06                   	push   es
    5781:	57                   	push   di
    5782:	9a 9e 3a ad 57       	call   0x57ad:0x3a9e
    5787:	c9                   	leave
    5788:	ca 08 00             	retf   0x8
    578b:	c8 04 00 00          	enter  0x4,0x0
    578f:	9a ff ff 00 00       	call   0x0:0xffff
    5794:	09 c0                	or     ax,ax
    5796:	75 3c                	jne    0x57d4
    5798:	8d 7e fc             	lea    di,[bp-0x4]
    579b:	16                   	push   ss
    579c:	57                   	push   di
    579d:	9a ff ff 00 00       	call   0x0:0xffff
    57a2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    57a5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    57a8:	6a 00                	push   0x0
    57aa:	9a 92 0e c3 57       	call   0x57c3:0xe92
    57af:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    57b2:	75 20                	jne    0x57d4
    57b4:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    57b7:	75 1b                	jne    0x57d4
    57b9:	6a 20                	push   0x20
    57bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57be:	06                   	push   es
    57bf:	57                   	push   di
    57c0:	9a b9 62 d2 57       	call   0x57d2:0x62b9
    57c5:	50                   	push   ax
    57c6:	6a 00                	push   0x0
    57c8:	6a 01                	push   0x1
    57ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57cd:	06                   	push   es
    57ce:	57                   	push   di
    57cf:	9a bb 24 f4 57       	call   0x57f4:0x24bb
    57d4:	c9                   	leave
    57d5:	ca 08 00             	retf   0x8
    57d8:	55                   	push   bp
    57d9:	89 e5                	mov    bp,sp
    57db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57de:	26 f6 45 26 10       	test   BYTE PTR es:[di+0x26],0x10
    57e3:	74 30                	je     0x5815
    57e5:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    57e9:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    57ed:	74 26                	je     0x5815
    57ef:	06                   	push   es
    57f0:	57                   	push   di
    57f1:	9a fa 64 13 58       	call   0x5813:0x64fa
    57f6:	08 c0                	or     al,al
    57f8:	74 1b                	je     0x5815
    57fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57fd:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5802:	9a 12 5e 00 00       	call   0x0:0x5e12
    5807:	09 c0                	or     ax,ax
    5809:	74 0a                	je     0x5815
    580b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    580e:	06                   	push   es
    580f:	57                   	push   di
    5810:	9a 7b 61 20 58       	call   0x5820:0x617b
    5815:	68 11 0f             	push   0xf11
    5818:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    581b:	06                   	push   es
    581c:	57                   	push   di
    581d:	9a 9e 3a 46 58       	call   0x5846:0x3a9e
    5822:	c9                   	leave
    5823:	ca 08 00             	retf   0x8
    5826:	55                   	push   bp
    5827:	89 e5                	mov    bp,sp
    5829:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    582c:	26 80 bd a6 00 00    	cmp    BYTE PTR es:[di+0xa6],0x0
    5832:	74 1d                	je     0x5851
    5834:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5838:	26 8a 85 a5 00       	mov    al,BYTE PTR es:[di+0xa5]
    583d:	50                   	push   ax
    583e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5841:	06                   	push   es
    5842:	57                   	push   di
    5843:	9a 22 63 82 58       	call   0x5882:0x6322
    5848:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    584b:	26 c6 85 a6 00 01    	mov    BYTE PTR es:[di+0xa6],0x1
    5851:	c9                   	leave
    5852:	ca 08 00             	retf   0x8
    5855:	55                   	push   bp
    5856:	89 e5                	mov    bp,sp
    5858:	a1 ea 13             	mov    ax,ds:0x13ea
    585b:	09 c0                	or     ax,ax
    585d:	74 0f                	je     0x586e
    585f:	ff 76 08             	push   WORD PTR [bp+0x8]
    5862:	ff 76 06             	push   WORD PTR [bp+0x6]
    5865:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5868:	06                   	push   es
    5869:	57                   	push   di
    586a:	ff 1e e8 13          	call   DWORD PTR ds:0x13e8
    586e:	c9                   	leave
    586f:	ca 08 00             	retf   0x8
    5872:	55                   	push   bp
    5873:	89 e5                	mov    bp,sp
    5875:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5878:	06                   	push   es
    5879:	57                   	push   di
    587a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    587d:	06                   	push   es
    587e:	57                   	push   di
    587f:	9a 43 3a 98 58       	call   0x5898:0x3a43
    5884:	c9                   	leave
    5885:	ca 08 00             	retf   0x8
    5888:	55                   	push   bp
    5889:	89 e5                	mov    bp,sp
    588b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    588e:	06                   	push   es
    588f:	57                   	push   di
    5890:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5893:	06                   	push   es
    5894:	57                   	push   di
    5895:	9a 43 3a ae 58       	call   0x58ae:0x3a43
    589a:	c9                   	leave
    589b:	ca 08 00             	retf   0x8
    589e:	55                   	push   bp
    589f:	89 e5                	mov    bp,sp
    58a1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    58a4:	06                   	push   es
    58a5:	57                   	push   di
    58a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58a9:	06                   	push   es
    58aa:	57                   	push   di
    58ab:	9a 43 3a c4 58       	call   0x58c4:0x3a43
    58b0:	c9                   	leave
    58b1:	ca 08 00             	retf   0x8
    58b4:	55                   	push   bp
    58b5:	89 e5                	mov    bp,sp
    58b7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    58ba:	06                   	push   es
    58bb:	57                   	push   di
    58bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58bf:	06                   	push   es
    58c0:	57                   	push   di
    58c1:	9a 43 3a 15 5a       	call   0x5a15:0x3a43
    58c6:	c9                   	leave
    58c7:	ca 08 00             	retf   0x8
    58ca:	c8 04 00 00          	enter  0x4,0x0
    58ce:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    58d1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    58d4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    58d7:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    58db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58de:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    58e2:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    58e6:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    58ea:	9a a5 0c 0a 59       	call   0x590a:0xca5
    58ef:	52                   	push   dx
    58f0:	50                   	push   ax
    58f1:	9a ff ff 00 00       	call   0x0:0xffff
    58f6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    58f9:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    58fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5900:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    5905:	06                   	push   es
    5906:	57                   	push   di
    5907:	9a 61 16 11 59       	call   0x5911:0x1661
    590c:	52                   	push   dx
    590d:	50                   	push   ax
    590e:	9a a5 0c 27 59       	call   0x5927:0xca5
    5913:	52                   	push   dx
    5914:	50                   	push   ax
    5915:	9a ff ff 00 00       	call   0x0:0xffff
    591a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    591d:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    5922:	06                   	push   es
    5923:	57                   	push   di
    5924:	9a c0 16 b8 68       	call   0x68b8:0x16c0
    5929:	31 d2                	xor    dx,dx
    592b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    592e:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    5932:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5936:	c9                   	leave
    5937:	ca 08 00             	retf   0x8
    593a:	c8 0e 00 00          	enter  0xe,0x0
    593e:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    5942:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5945:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    594a:	74 03                	je     0x594f
    594c:	e9 8f 00             	jmp    0x59de
    594f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5952:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5955:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5958:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    595b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    595e:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    5961:	74 39                	je     0x599c
    5963:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5966:	26 8b 45 40          	mov    ax,WORD PTR es:[di+0x40]
    596a:	26 0b 45 42          	or     ax,WORD PTR es:[di+0x42]
    596e:	74 19                	je     0x5989
    5970:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5973:	06                   	push   es
    5974:	57                   	push   di
    5975:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5978:	26 c4 7d 40          	les    di,DWORD PTR es:[di+0x40]
    597c:	06                   	push   es
    597d:	57                   	push   di
    597e:	9a 2a 1b d6 59       	call   0x59d6:0x1b2a
    5983:	08 c0                	or     al,al
    5985:	74 02                	je     0x5989
    5987:	eb 74                	jmp    0x59fd
    5989:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    598c:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    5990:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    5994:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5997:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    599a:	eb bf                	jmp    0x595b
    599c:	ff 76 08             	push   WORD PTR [bp+0x8]
    599f:	ff 76 06             	push   WORD PTR [bp+0x6]
    59a2:	9a a8 17 e8 5a       	call   0x5ae8:0x17a8
    59a7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    59aa:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    59ad:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    59b0:	0b 46 f8             	or     ax,WORD PTR [bp-0x8]
    59b3:	74 29                	je     0x59de
    59b5:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    59b8:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    59bd:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    59c2:	74 1a                	je     0x59de
    59c4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    59c7:	06                   	push   es
    59c8:	57                   	push   di
    59c9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    59cc:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    59d1:	06                   	push   es
    59d2:	57                   	push   di
    59d3:	9a 2a 1b ff ff       	call   0xffff:0x1b2a
    59d8:	08 c0                	or     al,al
    59da:	74 02                	je     0x59de
    59dc:	eb 1f                	jmp    0x59fd
    59de:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    59e1:	68 16 0f             	push   0xf16
    59e4:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    59e8:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    59ec:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    59f0:	e8 9c b1             	call   0xb8f
    59f3:	09 d0                	or     ax,dx
    59f5:	74 02                	je     0x59f9
    59f7:	eb 04                	jmp    0x59fd
    59f9:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    59fd:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5a00:	c9                   	leave
    5a01:	ca 08 00             	retf   0x8
    5a04:	c8 06 00 00          	enter  0x6,0x0
    5a08:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5a0b:	06                   	push   es
    5a0c:	57                   	push   di
    5a0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a10:	06                   	push   es
    5a11:	57                   	push   di
    5a12:	9a 3a 59 a1 5a       	call   0x5aa1:0x593a
    5a17:	08 c0                	or     al,al
    5a19:	74 12                	je     0x5a2d
    5a1b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5a1e:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    5a24:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    5a2a:	e9 d3 00             	jmp    0x5b00
    5a2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a30:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    5a35:	74 03                	je     0x5a3a
    5a37:	e9 c6 00             	jmp    0x5b00
    5a3a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5a3d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5a40:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5a43:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    5a47:	3d 09 00             	cmp    ax,0x9
    5a4a:	75 07                	jne    0x5a53
    5a4c:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    5a51:	eb 38                	jmp    0x5a8b
    5a53:	3d 25 00             	cmp    ax,0x25
    5a56:	74 0f                	je     0x5a67
    5a58:	3d 27 00             	cmp    ax,0x27
    5a5b:	74 0a                	je     0x5a67
    5a5d:	3d 26 00             	cmp    ax,0x26
    5a60:	74 05                	je     0x5a67
    5a62:	3d 28 00             	cmp    ax,0x28
    5a65:	75 07                	jne    0x5a6e
    5a67:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    5a6c:	eb 1d                	jmp    0x5a8b
    5a6e:	3d 0d 00             	cmp    ax,0xd
    5a71:	74 0f                	je     0x5a82
    5a73:	3d 2b 00             	cmp    ax,0x2b
    5a76:	74 0a                	je     0x5a82
    5a78:	3d 1b 00             	cmp    ax,0x1b
    5a7b:	74 05                	je     0x5a82
    5a7d:	3d 03 00             	cmp    ax,0x3
    5a80:	75 07                	jne    0x5a89
    5a82:	c7 46 fe 04 00       	mov    WORD PTR [bp-0x2],0x4
    5a87:	eb 02                	jmp    0x5a8b
    5a89:	eb 75                	jmp    0x5b00
    5a8b:	68 1e 0f             	push   0xf1e
    5a8e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5a91:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5a95:	6a 00                	push   0x0
    5a97:	6a 00                	push   0x0
    5a99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a9c:	06                   	push   es
    5a9d:	57                   	push   di
    5a9e:	9a bb 24 b8 5a       	call   0x5ab8:0x24bb
    5aa3:	09 d0                	or     ax,dx
    5aa5:	75 59                	jne    0x5b00
    5aa7:	68 87 00             	push   0x87
    5aaa:	6a 00                	push   0x0
    5aac:	6a 00                	push   0x0
    5aae:	6a 00                	push   0x0
    5ab0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ab3:	06                   	push   es
    5ab4:	57                   	push   di
    5ab5:	9a bb 24 f3 5a       	call   0x5af3:0x24bb
    5aba:	23 46 fe             	and    ax,WORD PTR [bp-0x2]
    5abd:	09 c0                	or     ax,ax
    5abf:	75 3f                	jne    0x5b00
    5ac1:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5ac4:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    5aca:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    5ad0:	68 05 0f             	push   0xf05
    5ad3:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5ad7:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    5adb:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5adf:	ff 76 08             	push   WORD PTR [bp+0x8]
    5ae2:	ff 76 06             	push   WORD PTR [bp+0x6]
    5ae5:	9a a8 17 cb 5b       	call   0x5bcb:0x17a8
    5aea:	89 c7                	mov    di,ax
    5aec:	8e c2                	mov    es,dx
    5aee:	06                   	push   es
    5aef:	57                   	push   di
    5af0:	9a bb 24 62 5b       	call   0x5b62:0x24bb
    5af5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5af8:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    5afc:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5b00:	c9                   	leave
    5b01:	ca 08 00             	retf   0x8
    5b04:	c8 04 00 00          	enter  0x4,0x0
    5b08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b0b:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    5b10:	75 5d                	jne    0x5b6f
    5b12:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5b15:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5b18:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5b1b:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    5b1f:	3d 09 00             	cmp    ax,0x9
    5b22:	74 28                	je     0x5b4c
    5b24:	3d 25 00             	cmp    ax,0x25
    5b27:	74 23                	je     0x5b4c
    5b29:	3d 27 00             	cmp    ax,0x27
    5b2c:	74 1e                	je     0x5b4c
    5b2e:	3d 26 00             	cmp    ax,0x26
    5b31:	74 19                	je     0x5b4c
    5b33:	3d 28 00             	cmp    ax,0x28
    5b36:	74 14                	je     0x5b4c
    5b38:	3d 0d 00             	cmp    ax,0xd
    5b3b:	74 0f                	je     0x5b4c
    5b3d:	3d 2b 00             	cmp    ax,0x2b
    5b40:	74 0a                	je     0x5b4c
    5b42:	3d 1b 00             	cmp    ax,0x1b
    5b45:	74 05                	je     0x5b4c
    5b47:	3d 03 00             	cmp    ax,0x3
    5b4a:	75 23                	jne    0x5b6f
    5b4c:	68 1e 0f             	push   0xf1e
    5b4f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5b52:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5b56:	6a 00                	push   0x0
    5b58:	6a 00                	push   0x0
    5b5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b5d:	06                   	push   es
    5b5e:	57                   	push   di
    5b5f:	9a bb 24 9b 5b       	call   0x5b9b:0x24bb
    5b64:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5b67:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    5b6b:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5b6f:	c9                   	leave
    5b70:	ca 08 00             	retf   0x8
    5b73:	c8 04 00 00          	enter  0x4,0x0
    5b77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b7a:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    5b7f:	75 62                	jne    0x5be3
    5b81:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5b84:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5b87:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5b8a:	68 87 00             	push   0x87
    5b8d:	6a 00                	push   0x0
    5b8f:	6a 00                	push   0x0
    5b91:	6a 00                	push   0x0
    5b93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b96:	06                   	push   es
    5b97:	57                   	push   di
    5b98:	9a bb 24 d6 5b       	call   0x5bd6:0x24bb
    5b9d:	25 80 00             	and    ax,0x80
    5ba0:	09 c0                	or     ax,ax
    5ba2:	75 3f                	jne    0x5be3
    5ba4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ba7:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    5bad:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    5bb3:	68 06 0f             	push   0xf06
    5bb6:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5bba:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    5bbe:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5bc2:	ff 76 08             	push   WORD PTR [bp+0x8]
    5bc5:	ff 76 06             	push   WORD PTR [bp+0x6]
    5bc8:	9a a8 17 46 5c       	call   0x5c46:0x17a8
    5bcd:	89 c7                	mov    di,ax
    5bcf:	8e c2                	mov    es,dx
    5bd1:	06                   	push   es
    5bd2:	57                   	push   di
    5bd3:	9a bb 24 f7 5b       	call   0x5bf7:0x24bb
    5bd8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5bdb:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    5bdf:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5be3:	c9                   	leave
    5be4:	ca 08 00             	retf   0x8
    5be7:	55                   	push   bp
    5be8:	89 e5                	mov    bp,sp
    5bea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5bed:	06                   	push   es
    5bee:	57                   	push   di
    5bef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bf2:	06                   	push   es
    5bf3:	57                   	push   di
    5bf4:	9a 3a 59 51 5c       	call   0x5c51:0x593a
    5bf9:	08 c0                	or     al,al
    5bfb:	74 0f                	je     0x5c0c
    5bfd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5c00:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    5c06:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    5c0c:	c9                   	leave
    5c0d:	ca 08 00             	retf   0x8
    5c10:	c8 04 00 00          	enter  0x4,0x0
    5c14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c17:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    5c1c:	75 40                	jne    0x5c5e
    5c1e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5c21:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5c24:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5c27:	26 83 7d 02 20       	cmp    WORD PTR es:[di+0x2],0x20
    5c2c:	74 30                	je     0x5c5e
    5c2e:	68 06 0f             	push   0xf06
    5c31:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5c35:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    5c39:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5c3d:	ff 76 08             	push   WORD PTR [bp+0x8]
    5c40:	ff 76 06             	push   WORD PTR [bp+0x6]
    5c43:	9a a8 17 d5 61       	call   0x61d5:0x17a8
    5c48:	89 c7                	mov    di,ax
    5c4a:	8e c2                	mov    es,dx
    5c4c:	06                   	push   es
    5c4d:	57                   	push   di
    5c4e:	9a bb 24 98 5c       	call   0x5c98:0x24bb
    5c53:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5c56:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    5c5a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    5c5e:	c9                   	leave
    5c5f:	ca 08 00             	retf   0x8
    5c62:	c8 1e 00 00          	enter  0x1e,0x0
    5c66:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    5c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c6c:	26 3b 45 1e          	cmp    ax,WORD PTR es:[di+0x1e]
    5c70:	75 1e                	jne    0x5c90
    5c72:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    5c75:	26 3b 45 20          	cmp    ax,WORD PTR es:[di+0x20]
    5c79:	75 15                	jne    0x5c90
    5c7b:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    5c7e:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    5c82:	75 0c                	jne    0x5c90
    5c84:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5c87:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    5c8b:	75 03                	jne    0x5c90
    5c8d:	e9 b6 00             	jmp    0x5d46
    5c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c93:	06                   	push   es
    5c94:	57                   	push   di
    5c95:	9a fa 64 f2 5c       	call   0x5cf2:0x64fa
    5c9a:	08 c0                	or     al,al
    5c9c:	74 30                	je     0x5cce
    5c9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ca1:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5ca6:	9a 23 65 00 00       	call   0x0:0x6523
    5cab:	09 c0                	or     ax,ax
    5cad:	75 1f                	jne    0x5cce
    5caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cb2:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5cb7:	6a 00                	push   0x0
    5cb9:	ff 76 10             	push   WORD PTR [bp+0x10]
    5cbc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5cbf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5cc2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5cc5:	6a 14                	push   0x14
    5cc7:	9a 42 5e 00 00       	call   0x0:0x5e42
    5ccc:	eb 6e                	jmp    0x5d3c
    5cce:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    5cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cd4:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    5cd8:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    5cdb:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    5cdf:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    5ce2:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    5ce6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5ce9:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    5ced:	06                   	push   es
    5cee:	57                   	push   di
    5cef:	9a fa 64 1c 5d       	call   0x5d1c:0x64fa
    5cf4:	08 c0                	or     al,al
    5cf6:	74 44                	je     0x5d3c
    5cf8:	c7 46 ea 16 00       	mov    WORD PTR [bp-0x16],0x16
    5cfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d00:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5d05:	8d 7e ea             	lea    di,[bp-0x16]
    5d08:	16                   	push   ss
    5d09:	57                   	push   di
    5d0a:	9a 3e 65 00 00       	call   0x0:0x653e
    5d0f:	8d 7e e2             	lea    di,[bp-0x1e]
    5d12:	16                   	push   ss
    5d13:	57                   	push   di
    5d14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d17:	06                   	push   es
    5d18:	57                   	push   di
    5d19:	9a 03 18 44 5d       	call   0x5d44:0x1803
    5d1e:	8d 7e f8             	lea    di,[bp-0x8]
    5d21:	16                   	push   ss
    5d22:	57                   	push   di
    5d23:	6a 08                	push   0x8
    5d25:	9a 1b 16 8a 5d       	call   0x5d8a:0x161b
    5d2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d2d:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5d32:	8d 7e ea             	lea    di,[bp-0x16]
    5d35:	16                   	push   ss
    5d36:	57                   	push   di
    5d37:	9a ff ff 00 00       	call   0x0:0xffff
    5d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d3f:	06                   	push   es
    5d40:	57                   	push   di
    5d41:	9a 73 15 56 5d       	call   0x5d56:0x1573
    5d46:	c9                   	leave
    5d47:	ca 0c 00             	retf   0xc
    5d4a:	c8 04 00 00          	enter  0x4,0x0
    5d4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d51:	06                   	push   es
    5d52:	57                   	push   di
    5d53:	9a fd 39 7c 5d       	call   0x5d7c:0x39fd
    5d58:	48                   	dec    ax
    5d59:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5d5c:	31 c0                	xor    ax,ax
    5d5e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5d61:	7f 31                	jg     0x5d94
    5d63:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5d66:	eb 03                	jmp    0x5d6b
    5d68:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5d6b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5d6e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d71:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5d74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d77:	06                   	push   es
    5d78:	57                   	push   di
    5d79:	9a 8f 39 9c 5d       	call   0x5d9c:0x398f
    5d7e:	89 c7                	mov    di,ax
    5d80:	8e c2                	mov    es,dx
    5d82:	06                   	push   es
    5d83:	57                   	push   di
    5d84:	b8 ff ff             	mov    ax,0xffff
    5d87:	9a 6a 20 5f 5e       	call   0x5e5f:0x206a
    5d8c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5d8f:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5d92:	75 d4                	jne    0x5d68
    5d94:	c9                   	leave
    5d95:	ca 08 00             	retf   0x8
    5d98:	00 00                	add    BYTE PTR [bx+si],al
    5d9a:	e5 5d                	in     ax,0x5d
    5d9c:	a9 5d 55             	test   ax,0x555d
    5d9f:	89 e5                	mov    bp,sp
    5da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5da4:	06                   	push   es
    5da5:	57                   	push   di
    5da6:	9a c5 36 c7 5d       	call   0x5dc7:0x36c5
    5dab:	b8 98 5d             	mov    ax,0x5d98
    5dae:	0e                   	push   cs
    5daf:	50                   	push   ax
    5db0:	55                   	push   bp
    5db1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5db5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5db9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5dbc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5dbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dc2:	06                   	push   es
    5dc3:	57                   	push   di
    5dc4:	9a 4a 5d d7 5d       	call   0x5dd7:0x5d4a
    5dc9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5dcc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5dcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dd2:	06                   	push   es
    5dd3:	57                   	push   di
    5dd4:	9a 69 1a ed 5d       	call   0x5ded:0x1a69
    5dd9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ddd:	83 c4 06             	add    sp,0x6
    5de0:	b8 f0 5d             	mov    ax,0x5df0
    5de3:	0e                   	push   cs
    5de4:	50                   	push   ax
    5de5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5de8:	06                   	push   es
    5de9:	57                   	push   di
    5dea:	9a d4 36 00 5e       	call   0x5e00:0x36d4
    5def:	cb                   	retf
    5df0:	c9                   	leave
    5df1:	ca 08 00             	retf   0x8
    5df4:	c8 12 00 00          	enter  0x12,0x0
    5df8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dfb:	06                   	push   es
    5dfc:	57                   	push   di
    5dfd:	9a fa 64 0e 5e       	call   0x5e0e:0x64fa
    5e02:	08 c0                	or     al,al
    5e04:	74 14                	je     0x5e1a
    5e06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e09:	06                   	push   es
    5e0a:	57                   	push   di
    5e0b:	9a b9 62 31 5e       	call   0x5e31:0x62b9
    5e10:	50                   	push   ax
    5e11:	9a c9 5e 00 00       	call   0x0:0x5ec9
    5e16:	09 c0                	or     ax,ax
    5e18:	75 04                	jne    0x5e1e
    5e1a:	b0 00                	mov    al,0x0
    5e1c:	eb 02                	jmp    0x5e20
    5e1e:	b0 01                	mov    al,0x1
    5e20:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5e23:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5e27:	74 1d                	je     0x5e46
    5e29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e2c:	06                   	push   es
    5e2d:	57                   	push   di
    5e2e:	9a b9 62 53 5e       	call   0x5e53:0x62b9
    5e33:	50                   	push   ax
    5e34:	6a 00                	push   0x0
    5e36:	6a 00                	push   0x0
    5e38:	6a 00                	push   0x0
    5e3a:	6a 00                	push   0x0
    5e3c:	6a 00                	push   0x0
    5e3e:	68 97 00             	push   0x97
    5e41:	9a ac 5e 00 00       	call   0x0:0x5eac
    5e46:	8d 7e ee             	lea    di,[bp-0x12]
    5e49:	16                   	push   ss
    5e4a:	57                   	push   di
    5e4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e4e:	06                   	push   es
    5e4f:	57                   	push   di
    5e50:	9a 03 18 9c 5e       	call   0x5e9c:0x1803
    5e55:	8d 7e f6             	lea    di,[bp-0xa]
    5e58:	16                   	push   ss
    5e59:	57                   	push   di
    5e5a:	6a 08                	push   0x8
    5e5c:	9a 1b 16 72 5e       	call   0x5e72:0x161b
    5e61:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5e64:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5e67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e6a:	06                   	push   es
    5e6b:	57                   	push   di
    5e6c:	b8 ff ff             	mov    ax,0xffff
    5e6f:	9a 6a 20 3f 5f       	call   0x5f3f:0x206a
    5e74:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5e77:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5e7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e7d:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    5e81:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    5e85:	06                   	push   es
    5e86:	57                   	push   di
    5e87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e8a:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    5e8e:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5e92:	74 1c                	je     0x5eb0
    5e94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e97:	06                   	push   es
    5e98:	57                   	push   di
    5e99:	9a b9 62 03 5f       	call   0x5f03:0x62b9
    5e9e:	50                   	push   ax
    5e9f:	6a 00                	push   0x0
    5ea1:	6a 00                	push   0x0
    5ea3:	6a 00                	push   0x0
    5ea5:	6a 00                	push   0x0
    5ea7:	6a 00                	push   0x0
    5ea9:	6a 57                	push   0x57
    5eab:	9a 91 5f 00 00       	call   0x0:0x5f91
    5eb0:	c9                   	leave
    5eb1:	ca 08 00             	retf   0x8
    5eb4:	c8 0e 00 00          	enter  0xe,0x0
    5eb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ebb:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    5ec1:	74 0e                	je     0x5ed1
    5ec3:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5ec8:	9a ff ff 00 00       	call   0x0:0xffff
    5ecd:	09 c0                	or     ax,ax
    5ecf:	75 04                	jne    0x5ed5
    5ed1:	b0 00                	mov    al,0x0
    5ed3:	eb 02                	jmp    0x5ed7
    5ed5:	b0 01                	mov    al,0x1
    5ed7:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5eda:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5ede:	74 1b                	je     0x5efb
    5ee0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ee3:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5ee8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5eeb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5eee:	6a 00                	push   0x0
    5ef0:	6a 00                	push   0x0
    5ef2:	6a 00                	push   0x0
    5ef4:	6a 00                	push   0x0
    5ef6:	9a ff ff 00 00       	call   0x0:0xffff
    5efb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5efe:	06                   	push   es
    5eff:	57                   	push   di
    5f00:	9a fd 39 26 5f       	call   0x5f26:0x39fd
    5f05:	48                   	dec    ax
    5f06:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    5f09:	31 c0                	xor    ax,ax
    5f0b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    5f0e:	7e 03                	jle    0x5f13
    5f10:	e9 8d 00             	jmp    0x5fa0
    5f13:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5f16:	eb 03                	jmp    0x5f1b
    5f18:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    5f1b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5f1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f21:	06                   	push   es
    5f22:	57                   	push   di
    5f23:	9a 8f 39 38 5f       	call   0x5f38:0x398f
    5f28:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5f2b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5f2e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5f31:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5f34:	bf c1 05             	mov    di,0x5c1
    5f37:	b8 a8 5f             	mov    ax,0x5fa8
    5f3a:	50                   	push   ax
    5f3b:	57                   	push   di
    5f3c:	9a 55 22 f1 60       	call   0x60f1:0x2255
    5f41:	08 c0                	or     al,al
    5f43:	74 0b                	je     0x5f50
    5f45:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5f48:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    5f4e:	75 16                	jne    0x5f66
    5f50:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    5f53:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5f56:	26 01 45 1e          	add    WORD PTR es:[di+0x1e],ax
    5f5a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5f5d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5f60:	26 01 45 20          	add    WORD PTR es:[di+0x20],ax
    5f64:	eb 2f                	jmp    0x5f95
    5f66:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5f6a:	75 29                	jne    0x5f95
    5f6c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5f6f:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    5f74:	6a 00                	push   0x0
    5f76:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    5f7a:	03 46 0c             	add    ax,WORD PTR [bp+0xc]
    5f7d:	50                   	push   ax
    5f7e:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    5f82:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    5f85:	50                   	push   ax
    5f86:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    5f8a:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    5f8e:	6a 14                	push   0x14
    5f90:	9a 87 60 00 00       	call   0x0:0x6087
    5f95:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5f98:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    5f9b:	74 03                	je     0x5fa0
    5f9d:	e9 78 ff             	jmp    0x5f18
    5fa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fa3:	06                   	push   es
    5fa4:	57                   	push   di
    5fa5:	9a f9 36 a2 60       	call   0x60a2:0x36f9
    5faa:	c9                   	leave
    5fab:	ca 08 00             	retf   0x8
    5fae:	55                   	push   bp
    5faf:	89 e5                	mov    bp,sp
    5fb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fb4:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    5fb8:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    5fbc:	74 13                	je     0x5fd1
    5fbe:	ff 76 08             	push   WORD PTR [bp+0x8]
    5fc1:	ff 76 06             	push   WORD PTR [bp+0x6]
    5fc4:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5fc8:	06                   	push   es
    5fc9:	57                   	push   di
    5fca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5fcd:	26 ff 5d 74          	call   DWORD PTR es:[di+0x74]
    5fd1:	c9                   	leave
    5fd2:	ca 08 00             	retf   0x8
    5fd5:	c8 04 00 00          	enter  0x4,0x0
    5fd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fdc:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    5fe0:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    5fe4:	74 7a                	je     0x6060
    5fe6:	ff 76 08             	push   WORD PTR [bp+0x8]
    5fe9:	ff 76 06             	push   WORD PTR [bp+0x6]
    5fec:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5ff0:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    5ff5:	06                   	push   es
    5ff6:	57                   	push   di
    5ff7:	9a 58 0e 42 60       	call   0x6042:0xe58
    5ffc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5fff:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    6003:	7c 5b                	jl     0x6060
    6005:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6009:	74 16                	je     0x6021
    600b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    600e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6012:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    6017:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    601b:	48                   	dec    ax
    601c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    601f:	eb 05                	jmp    0x6026
    6021:	31 c0                	xor    ax,ax
    6023:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6026:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6029:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    602c:	74 32                	je     0x6060
    602e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6034:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6038:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    603d:	06                   	push   es
    603e:	57                   	push   di
    603f:	9a 94 0c 5e 60       	call   0x605e:0xc94
    6044:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6047:	ff 76 08             	push   WORD PTR [bp+0x8]
    604a:	ff 76 06             	push   WORD PTR [bp+0x6]
    604d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6050:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6054:	26 c4 bd 96 00       	les    di,DWORD PTR es:[di+0x96]
    6059:	06                   	push   es
    605a:	57                   	push   di
    605b:	9a a7 0e cb 63       	call   0x63cb:0xea7
    6060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6063:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    6069:	74 20                	je     0x608b
    606b:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    6070:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6073:	98                   	cbw
    6074:	8b f8                	mov    di,ax
    6076:	d1 e7                	shl    di,1
    6078:	ff b5 00 15          	push   WORD PTR [di+0x1500]
    607c:	6a 00                	push   0x0
    607e:	6a 00                	push   0x0
    6080:	6a 00                	push   0x0
    6082:	6a 00                	push   0x0
    6084:	6a 03                	push   0x3
    6086:	9a 6a 6c 00 00       	call   0x0:0x6c6a
    608b:	c9                   	leave
    608c:	ca 06 00             	retf   0x6
    608f:	c8 02 01 00          	enter  0x102,0x0
    6093:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6096:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    609b:	74 18                	je     0x60b5
    609d:	06                   	push   es
    609e:	57                   	push   di
    609f:	9a b9 62 bd 60       	call   0x60bd:0x62b9
    60a4:	50                   	push   ax
    60a5:	6a 00                	push   0x0
    60a7:	6a 00                	push   0x0
    60a9:	6a 12                	push   0x12
    60ab:	9a ff ff 00 00       	call   0x0:0xffff
    60b0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    60b3:	eb 13                	jmp    0x60c8
    60b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60b8:	06                   	push   es
    60b9:	57                   	push   di
    60ba:	9a b9 62 e3 60       	call   0x60e3:0x62b9
    60bf:	50                   	push   ax
    60c0:	9a ff ff 00 00       	call   0x0:0xffff
    60c5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    60c8:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    60cc:	75 25                	jne    0x60f3
    60ce:	8d be fe fe          	lea    di,[bp-0x102]
    60d2:	16                   	push   ss
    60d3:	57                   	push   di
    60d4:	68 25 f0             	push   0xf025
    60d7:	9a 2b 09 ea 60       	call   0x60ea:0x92b
    60dc:	b0 01                	mov    al,0x1
    60de:	50                   	push   ax
    60df:	b8 22 00             	mov    ax,0x22
    60e2:	ba 13 61             	mov    dx,0x6113
    60e5:	52                   	push   dx
    60e6:	50                   	push   ax
    60e7:	9a e6 28 a0 6a       	call   0x6aa0:0x28e6
    60ec:	52                   	push   dx
    60ed:	50                   	push   ax
    60ee:	9a 99 13 98 61       	call   0x6198:0x1399
    60f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60f6:	26 8b 85 a2 00       	mov    ax,WORD PTR es:[di+0xa2]
    60fb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    60fe:	26 89 05             	mov    WORD PTR es:[di],ax
    6101:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6104:	c9                   	leave
    6105:	ca 08 00             	retf   0x8
    6108:	55                   	push   bp
    6109:	89 e5                	mov    bp,sp
    610b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    610e:	06                   	push   es
    610f:	57                   	push   di
    6110:	9a fa 64 45 61       	call   0x6145:0x64fa
    6115:	08 c0                	or     al,al
    6117:	74 1d                	je     0x6136
    6119:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    611c:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    6121:	6a 00                	push   0x0
    6123:	6a 00                	push   0x0
    6125:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    612a:	b0 00                	mov    al,0x0
    612c:	75 01                	jne    0x612f
    612e:	40                   	inc    ax
    612f:	98                   	cbw
    6130:	50                   	push   ax
    6131:	9a bc 61 00 00       	call   0x0:0x61bc
    6136:	c9                   	leave
    6137:	ca 04 00             	retf   0x4
    613a:	55                   	push   bp
    613b:	89 e5                	mov    bp,sp
    613d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6140:	06                   	push   es
    6141:	57                   	push   di
    6142:	9a fa 64 8c 61       	call   0x618c:0x64fa
    6147:	08 c0                	or     al,al
    6149:	74 0d                	je     0x6158
    614b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    614e:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    6153:	9a ff ff 00 00       	call   0x0:0xffff
    6158:	c9                   	leave
    6159:	ca 04 00             	retf   0x4
    615c:	55                   	push   bp
    615d:	89 e5                	mov    bp,sp
    615f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6162:	06                   	push   es
    6163:	57                   	push   di
    6164:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6167:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    616b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616e:	06                   	push   es
    616f:	57                   	push   di
    6170:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6173:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    6177:	c9                   	leave
    6178:	ca 04 00             	retf   0x4
    617b:	c8 10 00 00          	enter  0x10,0x0
    617f:	8d 7e f0             	lea    di,[bp-0x10]
    6182:	16                   	push   ss
    6183:	57                   	push   di
    6184:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6187:	06                   	push   es
    6188:	57                   	push   di
    6189:	9a 03 18 a7 62       	call   0x62a7:0x1803
    618e:	8d 7e f8             	lea    di,[bp-0x8]
    6191:	16                   	push   ss
    6192:	57                   	push   di
    6193:	6a 08                	push   0x8
    6195:	9a 1b 16 51 65       	call   0x6551:0x161b
    619a:	8d 7e f8             	lea    di,[bp-0x8]
    619d:	16                   	push   ss
    619e:	57                   	push   di
    619f:	6a 01                	push   0x1
    61a1:	6a 01                	push   0x1
    61a3:	9a ff ff 00 00       	call   0x0:0xffff
    61a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61ab:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    61af:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    61b4:	8d 7e f8             	lea    di,[bp-0x8]
    61b7:	16                   	push   ss
    61b8:	57                   	push   di
    61b9:	6a 01                	push   0x1
    61bb:	9a ff ff 00 00       	call   0x0:0xffff
    61c0:	c9                   	leave
    61c1:	ca 04 00             	retf   0x4
    61c4:	c8 0a 00 00          	enter  0xa,0x0
    61c8:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    61cc:	ff 76 08             	push   WORD PTR [bp+0x8]
    61cf:	ff 76 06             	push   WORD PTR [bp+0x6]
    61d2:	9a a8 17 47 62       	call   0x6247:0x17a8
    61d7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    61da:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    61dd:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    61e0:	0b 46 f8             	or     ax,WORD PTR [bp-0x8]
    61e3:	74 49                	je     0x622e
    61e5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    61e8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    61eb:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    61ee:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    61f1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    61f4:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    61f7:	3b 56 f8             	cmp    dx,WORD PTR [bp-0x8]
    61fa:	75 05                	jne    0x6201
    61fc:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    61ff:	74 29                	je     0x622a
    6201:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6204:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    6209:	74 0a                	je     0x6215
    620b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    620e:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    6213:	75 02                	jne    0x6217
    6215:	eb 17                	jmp    0x622e
    6217:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    621a:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    621e:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    6222:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6225:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    6228:	eb c7                	jmp    0x61f1
    622a:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    622e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6231:	c9                   	leave
    6232:	ca 04 00             	retf   0x4
    6235:	55                   	push   bp
    6236:	89 e5                	mov    bp,sp
    6238:	ff 76 08             	push   WORD PTR [bp+0x8]
    623b:	ff 76 06             	push   WORD PTR [bp+0x6]
    623e:	ff 76 08             	push   WORD PTR [bp+0x8]
    6241:	ff 76 06             	push   WORD PTR [bp+0x6]
    6244:	9a 01 18 52 62       	call   0x6252:0x1801
    6249:	89 c7                	mov    di,ax
    624b:	8e c2                	mov    es,dx
    624d:	06                   	push   es
    624e:	57                   	push   di
    624f:	9a ea 40 91 65       	call   0x6591:0x40ea
    6254:	c9                   	leave
    6255:	ca 04 00             	retf   0x4
    6258:	c8 02 00 00          	enter  0x2,0x0
    625c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    625f:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    6265:	74 0f                	je     0x6276
    6267:	9a ff ff 00 00       	call   0x0:0xffff
    626c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    626f:	26 3b 85 a2 00       	cmp    ax,WORD PTR es:[di+0xa2]
    6274:	74 04                	je     0x627a
    6276:	b0 00                	mov    al,0x0
    6278:	eb 02                	jmp    0x627c
    627a:	b0 01                	mov    al,0x1
    627c:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    627f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6282:	c9                   	leave
    6283:	ca 04 00             	retf   0x4
    6286:	55                   	push   bp
    6287:	89 e5                	mov    bp,sp
    6289:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    628c:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    6292:	75 21                	jne    0x62b5
    6294:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6298:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    629c:	74 0b                	je     0x62a9
    629e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    62a2:	06                   	push   es
    62a3:	57                   	push   di
    62a4:	9a 86 62 c5 62       	call   0x62c5:0x6286
    62a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ac:	06                   	push   es
    62ad:	57                   	push   di
    62ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62b1:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    62b5:	c9                   	leave
    62b6:	ca 04 00             	retf   0x4
    62b9:	c8 02 00 00          	enter  0x2,0x0
    62bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62c0:	06                   	push   es
    62c1:	57                   	push   di
    62c2:	9a 86 62 ef 62       	call   0x62ef:0x6286
    62c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ca:	26 8b 85 a2 00       	mov    ax,WORD PTR es:[di+0xa2]
    62cf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    62d2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    62d5:	c9                   	leave
    62d6:	ca 04 00             	retf   0x4
    62d9:	c8 04 00 00          	enter  0x4,0x0
    62dd:	31 c0                	xor    ax,ax
    62df:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    62e2:	31 c0                	xor    ax,ax
    62e4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    62e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ea:	06                   	push   es
    62eb:	57                   	push   di
    62ec:	9a b9 62 11 63       	call   0x6311:0x62b9
    62f1:	50                   	push   ax
    62f2:	8d 7e fc             	lea    di,[bp-0x4]
    62f5:	16                   	push   ss
    62f6:	57                   	push   di
    62f7:	9a ff ff 00 00       	call   0x0:0xffff
    62fc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    62ff:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6302:	c9                   	leave
    6303:	ca 04 00             	retf   0x4
    6306:	55                   	push   bp
    6307:	89 e5                	mov    bp,sp
    6309:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    630c:	06                   	push   es
    630d:	57                   	push   di
    630e:	9a b9 62 4e 63       	call   0x634e:0x62b9
    6313:	50                   	push   ax
    6314:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6317:	06                   	push   es
    6318:	57                   	push   di
    6319:	9a ff ff 00 00       	call   0x0:0xffff
    631e:	c9                   	leave
    631f:	ca 04 00             	retf   0x4
    6322:	55                   	push   bp
    6323:	89 e5                	mov    bp,sp
    6325:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6328:	26 8a 85 a5 00       	mov    al,BYTE PTR es:[di+0xa5]
    632d:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6330:	74 1e                	je     0x6350
    6332:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6335:	26 88 85 a5 00       	mov    BYTE PTR es:[di+0xa5],al
    633a:	26 c6 85 a6 00 00    	mov    BYTE PTR es:[di+0xa6],0x0
    6340:	68 10 0f             	push   0xf10
    6343:	6a 00                	push   0x0
    6345:	6a 00                	push   0x0
    6347:	6a 00                	push   0x0
    6349:	06                   	push   es
    634a:	57                   	push   di
    634b:	9a bb 24 a0 63       	call   0x63a0:0x24bb
    6350:	c9                   	leave
    6351:	ca 06 00             	retf   0x6
    6354:	c8 02 00 00          	enter  0x2,0x0
    6358:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    635b:	26 80 bd a6 00 00    	cmp    BYTE PTR es:[di+0xa6],0x0
    6361:	b0 00                	mov    al,0x0
    6363:	75 01                	jne    0x6366
    6365:	40                   	inc    ax
    6366:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6369:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    636c:	c9                   	leave
    636d:	ca 04 00             	retf   0x4
    6370:	55                   	push   bp
    6371:	89 e5                	mov    bp,sp
    6373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6376:	26 8a 85 a6 00       	mov    al,BYTE PTR es:[di+0xa6]
    637b:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    637e:	74 22                	je     0x63a2
    6380:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6383:	26 88 85 a6 00       	mov    BYTE PTR es:[di+0xa6],al
    6388:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    638c:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6390:	74 10                	je     0x63a2
    6392:	68 11 0f             	push   0xf11
    6395:	6a 00                	push   0x0
    6397:	6a 00                	push   0x0
    6399:	6a 00                	push   0x0
    639b:	06                   	push   es
    639c:	57                   	push   di
    639d:	9a bb 24 ea 63       	call   0x63ea:0x24bb
    63a2:	c9                   	leave
    63a3:	ca 06 00             	retf   0x6
    63a6:	c8 02 00 00          	enter  0x2,0x0
    63aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63ad:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    63b1:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    63b5:	74 1b                	je     0x63d2
    63b7:	ff 76 08             	push   WORD PTR [bp+0x8]
    63ba:	ff 76 06             	push   WORD PTR [bp+0x6]
    63bd:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    63c1:	26 c4 bd 9a 00       	les    di,DWORD PTR es:[di+0x9a]
    63c6:	06                   	push   es
    63c7:	57                   	push   di
    63c8:	9a 58 0e 3e 64       	call   0x643e:0xe58
    63cd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    63d0:	eb 05                	jmp    0x63d7
    63d2:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    63d7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    63da:	c9                   	leave
    63db:	ca 04 00             	retf   0x4
    63de:	c8 04 00 00          	enter  0x4,0x0
    63e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63e5:	06                   	push   es
    63e6:	57                   	push   di
    63e7:	9a a6 63 82 64       	call   0x6482:0x63a6
    63ec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    63ef:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    63f3:	7c 67                	jl     0x645c
    63f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63f8:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    63fc:	26 c4 bd 9a 00       	les    di,DWORD PTR es:[di+0x9a]
    6401:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6405:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6408:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    640c:	7d 05                	jge    0x6413
    640e:	31 c0                	xor    ax,ax
    6410:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    6413:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6416:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    6419:	7c 07                	jl     0x6422
    641b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    641e:	48                   	dec    ax
    641f:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    6422:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6425:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    6428:	74 32                	je     0x645c
    642a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    642d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6430:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6434:	26 c4 bd 9a 00       	les    di,DWORD PTR es:[di+0x9a]
    6439:	06                   	push   es
    643a:	57                   	push   di
    643b:	9a 94 0c 5a 64       	call   0x645a:0xc94
    6440:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6443:	ff 76 08             	push   WORD PTR [bp+0x8]
    6446:	ff 76 06             	push   WORD PTR [bp+0x6]
    6449:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    644c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6450:	26 c4 bd 9a 00       	les    di,DWORD PTR es:[di+0x9a]
    6455:	06                   	push   es
    6456:	57                   	push   di
    6457:	9a a7 0e 4f 66       	call   0x664f:0xea7
    645c:	c9                   	leave
    645d:	ca 06 00             	retf   0x6
    6460:	55                   	push   bp
    6461:	89 e5                	mov    bp,sp
    6463:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6466:	26 f6 45 28 08       	test   BYTE PTR es:[di+0x28],0x8
    646b:	74 0a                	je     0x6477
    646d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6470:	26 89 85 a8 00       	mov    WORD PTR es:[di+0xa8],ax
    6475:	eb 0d                	jmp    0x6484
    6477:	ff 76 0a             	push   WORD PTR [bp+0xa]
    647a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    647d:	06                   	push   es
    647e:	57                   	push   di
    647f:	9a de 63 a6 64       	call   0x64a6:0x63de
    6484:	c9                   	leave
    6485:	ca 06 00             	retf   0x6
    6488:	c8 04 00 00          	enter  0x4,0x0
    648c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    648f:	26 8a 85 a4 00       	mov    al,BYTE PTR es:[di+0xa4]
    6494:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6497:	74 5d                	je     0x64f6
    6499:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    649c:	26 88 85 a4 00       	mov    BYTE PTR es:[di+0xa4],al
    64a1:	06                   	push   es
    64a2:	57                   	push   di
    64a3:	9a fa 64 75 66       	call   0x6675:0x64fa
    64a8:	08 c0                	or     al,al
    64aa:	74 4a                	je     0x64f6
    64ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64af:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    64b4:	6a f0                	push   0xfff0
    64b6:	9a ff ff 00 00       	call   0x0:0xffff
    64bb:	25 ff ff             	and    ax,0xffff
    64be:	81 e2 fe ff          	and    dx,0xfffe
    64c2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    64c5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    64c8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    64cc:	74 13                	je     0x64e1
    64ce:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    64d1:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    64d4:	0d 00 00             	or     ax,0x0
    64d7:	81 ca 01 00          	or     dx,0x1
    64db:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    64de:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    64e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64e4:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    64e9:	6a f0                	push   0xfff0
    64eb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    64ee:	ff 76 fc             	push   WORD PTR [bp-0x4]
    64f1:	9a ff ff 00 00       	call   0x0:0xffff
    64f6:	c9                   	leave
    64f7:	ca 06 00             	retf   0x6
    64fa:	c8 02 00 00          	enter  0x2,0x0
    64fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6501:	26 83 bd a2 00 00    	cmp    WORD PTR es:[di+0xa2],0x0
    6507:	b0 00                	mov    al,0x0
    6509:	74 01                	je     0x650c
    650b:	40                   	inc    ax
    650c:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    650f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6512:	c9                   	leave
    6513:	ca 04 00             	retf   0x4
    6516:	c8 20 00 00          	enter  0x20,0x0
    651a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    651d:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    6522:	9a ff ff 00 00       	call   0x0:0xffff
    6527:	09 c0                	or     ax,ax
    6529:	74 2a                	je     0x6555
    652b:	c7 46 e0 16 00       	mov    WORD PTR [bp-0x20],0x16
    6530:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6533:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    6538:	8d 7e e0             	lea    di,[bp-0x20]
    653b:	16                   	push   ss
    653c:	57                   	push   di
    653d:	9a ff ff 00 00       	call   0x0:0xffff
    6542:	8d 7e ee             	lea    di,[bp-0x12]
    6545:	16                   	push   ss
    6546:	57                   	push   di
    6547:	8d 7e f6             	lea    di,[bp-0xa]
    654a:	16                   	push   ss
    654b:	57                   	push   di
    654c:	6a 08                	push   0x8
    654e:	9a 1b 16 98 65       	call   0x6598:0x161b
    6553:	eb 12                	jmp    0x6567
    6555:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6558:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    655d:	8d 7e f6             	lea    di,[bp-0xa]
    6560:	16                   	push   ss
    6561:	57                   	push   di
    6562:	9a ff ff 00 00       	call   0x0:0xffff
    6567:	31 c0                	xor    ax,ax
    6569:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    656c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    656f:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6573:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6577:	74 0e                	je     0x6587
    6579:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    657d:	26 8b 85 a2 00       	mov    ax,WORD PTR es:[di+0xa2]
    6582:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6585:	eb 40                	jmp    0x65c7
    6587:	ff 76 08             	push   WORD PTR [bp+0x8]
    658a:	ff 76 06             	push   WORD PTR [bp+0x6]
    658d:	bf fb 04             	mov    di,0x4fb
    6590:	b8 1e 68             	mov    ax,0x681e
    6593:	50                   	push   ax
    6594:	57                   	push   di
    6595:	9a 55 22 a3 66       	call   0x66a3:0x2255
    659a:	08 c0                	or     al,al
    659c:	74 29                	je     0x65c7
    659e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a1:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    65a7:	75 1e                	jne    0x65c7
    65a9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    65ad:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    65b1:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    65b5:	74 10                	je     0x65c7
    65b7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    65bb:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    65bf:	26 8b 85 0e 01       	mov    ax,WORD PTR es:[di+0x10e]
    65c4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    65c7:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    65cb:	74 1a                	je     0x65e7
    65cd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    65d0:	8d 7e f6             	lea    di,[bp-0xa]
    65d3:	16                   	push   ss
    65d4:	57                   	push   di
    65d5:	9a e3 65 00 00       	call   0x0:0x65e3
    65da:	ff 76 fe             	push   WORD PTR [bp-0x2]
    65dd:	8d 7e fa             	lea    di,[bp-0x6]
    65e0:	16                   	push   ss
    65e1:	57                   	push   di
    65e2:	9a ff ff 00 00       	call   0x0:0xffff
    65e7:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    65ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65ed:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    65f1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    65f4:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    65f8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    65fb:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    65fe:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    6602:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6605:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    6608:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    660c:	c9                   	leave
    660d:	ca 04 00             	retf   0x4
    6610:	c8 08 00 00          	enter  0x8,0x0
    6614:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6617:	26 8b 85 9a 00       	mov    ax,WORD PTR es:[di+0x9a]
    661c:	26 0b 85 9c 00       	or     ax,WORD PTR es:[di+0x9c]
    6621:	74 5c                	je     0x667f
    6623:	26 c4 bd 9a 00       	les    di,DWORD PTR es:[di+0x9a]
    6628:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    662c:	48                   	dec    ax
    662d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6630:	31 c0                	xor    ax,ax
    6632:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6635:	7f 48                	jg     0x667f
    6637:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    663a:	eb 03                	jmp    0x663f
    663c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    663f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6642:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6645:	26 c4 bd 9a 00       	les    di,DWORD PTR es:[di+0x9a]
    664a:	06                   	push   es
    664b:	57                   	push   di
    664c:	9a d0 0d 65 66       	call   0x6665:0xdd0
    6651:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6654:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    6657:	ff 76 fc             	push   WORD PTR [bp-0x4]
    665a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    665d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6660:	06                   	push   es
    6661:	57                   	push   di
    6662:	9a 2b 0c 9c 66       	call   0x669c:0xc2b
    6667:	ff 76 0c             	push   WORD PTR [bp+0xc]
    666a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    666d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6670:	06                   	push   es
    6671:	57                   	push   di
    6672:	9a 10 66 87 66       	call   0x6687:0x6610
    6677:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    667a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    667d:	75 bd                	jne    0x663c
    667f:	c9                   	leave
    6680:	ca 08 00             	retf   0x8
    6683:	00 00                	add    BYTE PTR [bx+si],al
    6685:	b4 67                	mov    ah,0x67
    6687:	c7                   	(bad)
    6688:	66 c8 0c 00 00       	enterd 0xc,0x0
    668d:	31 c0                	xor    ax,ax
    668f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6692:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6695:	b0 01                	mov    al,0x1
    6697:	50                   	push   ax
    6698:	b8 a3 02             	mov    ax,0x2a3
    669b:	ba e4 66             	mov    dx,0x66e4
    669e:	52                   	push   dx
    669f:	50                   	push   ax
    66a0:	9a 50 1f 95 68       	call   0x6895:0x1f50
    66a5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    66a8:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    66ab:	b8 83 66             	mov    ax,0x6683
    66ae:	0e                   	push   cs
    66af:	50                   	push   ax
    66b0:	55                   	push   bp
    66b1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    66b5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    66b9:	ff 76 f6             	push   WORD PTR [bp-0xa]
    66bc:	ff 76 f4             	push   WORD PTR [bp-0xc]
    66bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66c2:	06                   	push   es
    66c3:	57                   	push   di
    66c4:	9a 10 66 57 67       	call   0x6757:0x6610
    66c9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    66cc:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    66d1:	7f 03                	jg     0x66d6
    66d3:	e9 d2 00             	jmp    0x67a8
    66d6:	ff 76 12             	push   WORD PTR [bp+0x12]
    66d9:	ff 76 10             	push   WORD PTR [bp+0x10]
    66dc:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    66df:	06                   	push   es
    66e0:	57                   	push   di
    66e1:	9a 58 0e 47 67       	call   0x6747:0xe58
    66e6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    66e9:	83 7e f8 ff          	cmp    WORD PTR [bp-0x8],0xffff
    66ed:	75 18                	jne    0x6707
    66ef:	80 7e 0e 00          	cmp    BYTE PTR [bp+0xe],0x0
    66f3:	74 0d                	je     0x6702
    66f5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    66f8:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    66fc:	48                   	dec    ax
    66fd:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6700:	eb 05                	jmp    0x6707
    6702:	31 c0                	xor    ax,ax
    6704:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6707:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    670a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    670d:	80 7e 0e 00          	cmp    BYTE PTR [bp+0xe],0x0
    6711:	74 16                	je     0x6729
    6713:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    6716:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    6719:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    671c:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    6720:	75 05                	jne    0x6727
    6722:	31 c0                	xor    ax,ax
    6724:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6727:	eb 13                	jmp    0x673c
    6729:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    672d:	75 0a                	jne    0x6739
    672f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6732:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6736:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6739:	ff 4e fa             	dec    WORD PTR [bp-0x6]
    673c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    673f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6742:	06                   	push   es
    6743:	57                   	push   di
    6744:	9a d0 0d 57 6e       	call   0x6e57:0xdd0
    6749:	89 46 10             	mov    WORD PTR [bp+0x10],ax
    674c:	89 56 12             	mov    WORD PTR [bp+0x12],dx
    674f:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    6752:	06                   	push   es
    6753:	57                   	push   di
    6754:	9a c4 61 f1 67       	call   0x67f1:0x61c4
    6759:	08 c0                	or     al,al
    675b:	74 38                	je     0x6795
    675d:	80 7e 0c 00          	cmp    BYTE PTR [bp+0xc],0x0
    6761:	74 0b                	je     0x676e
    6763:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    6766:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
    676c:	74 27                	je     0x6795
    676e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6772:	74 15                	je     0x6789
    6774:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    6777:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    677b:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    677f:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    6782:	75 11                	jne    0x6795
    6784:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    6787:	75 0c                	jne    0x6795
    6789:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    678c:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    678f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6792:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6795:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6798:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    679b:	75 0b                	jne    0x67a8
    679d:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    67a0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    67a3:	74 03                	je     0x67a8
    67a5:	e9 65 ff             	jmp    0x670d
    67a8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    67ac:	83 c4 06             	add    sp,0x6
    67af:	b8 c4 67             	mov    ax,0x67c4
    67b2:	0e                   	push   cs
    67b3:	50                   	push   ax
    67b4:	b0 01                	mov    al,0x1
    67b6:	50                   	push   ax
    67b7:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    67ba:	06                   	push   es
    67bb:	57                   	push   di
    67bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    67bf:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    67c3:	cb                   	retf
    67c4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    67c7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    67ca:	c9                   	leave
    67cb:	ca 0e 00             	retf   0xe
    67ce:	55                   	push   bp
    67cf:	89 e5                	mov    bp,sp
    67d1:	ff 76 10             	push   WORD PTR [bp+0x10]
    67d4:	ff 76 0e             	push   WORD PTR [bp+0xe]
    67d7:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    67da:	50                   	push   ax
    67db:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    67de:	50                   	push   ax
    67df:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    67e3:	b0 00                	mov    al,0x0
    67e5:	75 01                	jne    0x67e8
    67e7:	40                   	inc    ax
    67e8:	50                   	push   ax
    67e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67ec:	06                   	push   es
    67ed:	57                   	push   di
    67ee:	9a 89 66 40 68       	call   0x6840:0x6689
    67f3:	89 46 0e             	mov    WORD PTR [bp+0xe],ax
    67f6:	89 56 10             	mov    WORD PTR [bp+0x10],dx
    67f9:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    67fc:	0b 46 10             	or     ax,WORD PTR [bp+0x10]
    67ff:	74 0c                	je     0x680d
    6801:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6804:	06                   	push   es
    6805:	57                   	push   di
    6806:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6809:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    680d:	c9                   	leave
    680e:	ca 0c 00             	retf   0xc
    6811:	c8 08 00 00          	enter  0x8,0x0
    6815:	ff 76 08             	push   WORD PTR [bp+0x8]
    6818:	ff 76 06             	push   WORD PTR [bp+0x6]
    681b:	9a a8 17 80 68       	call   0x6880:0x17a8
    6820:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6823:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6826:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6829:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    682c:	74 54                	je     0x6882
    682e:	6a 00                	push   0x0
    6830:	6a 00                	push   0x0
    6832:	6a 01                	push   0x1
    6834:	6a 01                	push   0x1
    6836:	6a 00                	push   0x0
    6838:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    683b:	06                   	push   es
    683c:	57                   	push   di
    683d:	9a 89 66 62 68       	call   0x6862:0x6689
    6842:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6845:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6848:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    684b:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    684e:	75 1a                	jne    0x686a
    6850:	6a 00                	push   0x0
    6852:	6a 00                	push   0x0
    6854:	6a 01                	push   0x1
    6856:	6a 00                	push   0x0
    6858:	6a 00                	push   0x0
    685a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    685d:	06                   	push   es
    685e:	57                   	push   di
    685f:	9a 89 66 a8 68       	call   0x68a8:0x6689
    6864:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6867:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    686a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    686d:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    6870:	74 10                	je     0x6882
    6872:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6875:	ff 76 f8             	push   WORD PTR [bp-0x8]
    6878:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    687b:	06                   	push   es
    687c:	57                   	push   di
    687d:	9a d0 3f e3 6b       	call   0x6be3:0x3fd0
    6882:	c9                   	leave
    6883:	ca 04 00             	retf   0x4
    6886:	55                   	push   bp
    6887:	89 e5                	mov    bp,sp
    6889:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    688d:	74 08                	je     0x6897
    688f:	83 ec 08             	sub    sp,0x8
    6892:	9a e2 1f 00 69       	call   0x6900:0x1fe2
    6897:	ff 76 0e             	push   WORD PTR [bp+0xe]
    689a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    689d:	31 c0                	xor    ax,ax
    689f:	50                   	push   ax
    68a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68a3:	06                   	push   es
    68a4:	57                   	push   di
    68a5:	9a 9b 13 b1 68       	call   0x68b1:0x139b
    68aa:	b0 01                	mov    al,0x1
    68ac:	50                   	push   ax
    68ad:	b8 96 00             	mov    ax,0x96
    68b0:	ba d7 68             	mov    dx,0x68d7
    68b3:	52                   	push   dx
    68b4:	50                   	push   ax
    68b5:	9a b8 17 42 69       	call   0x6942:0x17b8
    68ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68bd:	26 89 85 8a 00       	mov    WORD PTR es:[di+0x8a],ax
    68c2:	26 89 95 8c 00       	mov    WORD PTR es:[di+0x8c],dx
    68c7:	ff 76 08             	push   WORD PTR [bp+0x8]
    68ca:	ff 76 06             	push   WORD PTR [bp+0x6]
    68cd:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    68d2:	06                   	push   es
    68d3:	57                   	push   di
    68d4:	9a 64 13 0d 69       	call   0x690d:0x1364
    68d9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    68dd:	74 07                	je     0x68e6
    68df:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    68e3:	83 c4 06             	add    sp,0x6
    68e6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    68e9:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    68ec:	c9                   	leave
    68ed:	ca 0a 00             	retf   0xa
    68f0:	55                   	push   bp
    68f1:	89 e5                	mov    bp,sp
    68f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68f6:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    68fb:	06                   	push   es
    68fc:	57                   	push   di
    68fd:	9a 7f 1f 18 69       	call   0x6918:0x1f7f
    6902:	31 c0                	xor    ax,ax
    6904:	50                   	push   ax
    6905:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6908:	06                   	push   es
    6909:	57                   	push   di
    690a:	9a 58 14 22 69       	call   0x6922:0x1458
    690f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6913:	74 05                	je     0x691a
    6915:	9a 0f 20 a5 69       	call   0x69a5:0x200f
    691a:	c9                   	leave
    691b:	ca 06 00             	retf   0x6
    691e:	00 00                	add    BYTE PTR [bx+si],al
    6920:	6a 69                	push   0x69
    6922:	b8 69 55             	mov    ax,0x5569
    6925:	89 e5                	mov    bp,sp
    6927:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    692a:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    692f:	74 4b                	je     0x697c
    6931:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6935:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6938:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    693d:	06                   	push   es
    693e:	57                   	push   di
    693f:	9a 5d 22 79 69       	call   0x6979:0x225d
    6944:	b8 1e 69             	mov    ax,0x691e
    6947:	0e                   	push   cs
    6948:	50                   	push   ax
    6949:	55                   	push   bp
    694a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    694e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6952:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6955:	06                   	push   es
    6956:	57                   	push   di
    6957:	26 c4 3d             	les    di,DWORD PTR es:[di]
    695a:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    695e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6962:	83 c4 06             	add    sp,0x6
    6965:	b8 7c 69             	mov    ax,0x697c
    6968:	0e                   	push   cs
    6969:	50                   	push   ax
    696a:	6a 00                	push   0x0
    696c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    696f:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    6974:	06                   	push   es
    6975:	57                   	push   di
    6976:	9a 5d 22 e8 69       	call   0x69e8:0x225d
    697b:	cb                   	retf
    697c:	c9                   	leave
    697d:	ca 08 00             	retf   0x8
    6980:	55                   	push   bp
    6981:	89 e5                	mov    bp,sp
    6983:	c9                   	leave
    6984:	ca 04 00             	retf   0x4
    6987:	0d 4d 53             	or     ax,0x534d
    698a:	20 53 61             	and    BYTE PTR [bp+di+0x61],dl
    698d:	6e                   	outs   dx,BYTE PTR ds:[si]
    698e:	73 20                	jae    0x69b0
    6990:	53                   	push   bx
    6991:	65 72 69             	gs jb  0x69fd
    6994:	66 c8 04 00 00       	enterd 0x4,0x0
    6999:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    699d:	74 08                	je     0x69a7
    699f:	83 ec 08             	sub    sp,0x8
    69a2:	9a e2 1f 72 6a       	call   0x6a72:0x1fe2
    69a7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    69aa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    69ad:	31 c0                	xor    ax,ax
    69af:	50                   	push   ax
    69b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69b3:	06                   	push   es
    69b4:	57                   	push   di
    69b5:	9a 72 6c c7 69       	call   0x69c7:0x6c72
    69ba:	68 80 00             	push   0x80
    69bd:	6a ff                	push   0xffff
    69bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c2:	06                   	push   es
    69c3:	57                   	push   di
    69c4:	9a d5 1e 32 6a       	call   0x6a32:0x1ed5
    69c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69cc:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    69d1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    69d4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    69d7:	bf 87 69             	mov    di,0x6987
    69da:	0e                   	push   cs
    69db:	57                   	push   di
    69dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    69df:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    69e3:	06                   	push   es
    69e4:	57                   	push   di
    69e5:	9a 7e 11 f8 69       	call   0x69f8:0x117e
    69ea:	6a 08                	push   0x8
    69ec:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    69ef:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    69f3:	06                   	push   es
    69f4:	57                   	push   di
    69f5:	9a f5 11 08 6a       	call   0x6a08:0x11f5
    69fa:	6a 01                	push   0x1
    69fc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    69ff:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    6a03:	06                   	push   es
    6a04:	57                   	push   di
    6a05:	9a 7c 17 84 6a       	call   0x6a84:0x177c
    6a0a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6a0e:	74 07                	je     0x6a17
    6a10:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6a14:	83 c4 06             	add    sp,0x6
    6a17:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6a1a:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6a1d:	c9                   	leave
    6a1e:	ca 0a 00             	retf   0xa
    6a21:	c8 04 00 00          	enter  0x4,0x0
    6a25:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6a28:	06                   	push   es
    6a29:	57                   	push   di
    6a2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a2d:	06                   	push   es
    6a2e:	57                   	push   di
    6a2f:	9a 29 3b 9b 6a       	call   0x6a9b:0x3b29
    6a34:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6a37:	26 c7 45 04 00 00    	mov    WORD PTR es:[di+0x4],0x0
    6a3d:	26 c7 45 06 80 88    	mov    WORD PTR es:[di+0x6],0x8880
    6a43:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6a47:	0d 00 08             	or     ax,0x800
    6a4a:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    6a4e:	c9                   	leave
    6a4f:	ca 08 00             	retf   0x8
    6a52:	c8 08 02 00          	enter  0x208,0x0
    6a56:	8d be f0 fe          	lea    di,[bp-0x110]
    6a5a:	16                   	push   ss
    6a5b:	57                   	push   di
    6a5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a5f:	06                   	push   es
    6a60:	57                   	push   di
    6a61:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a64:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    6a68:	8d 7e f8             	lea    di,[bp-0x8]
    6a6b:	16                   	push   ss
    6a6c:	57                   	push   di
    6a6d:	6a 08                	push   0x8
    6a6f:	9a 1b 16 81 6c       	call   0x6c81:0x161b
    6a74:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    6a77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a7a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6a7f:	06                   	push   es
    6a80:	57                   	push   di
    6a81:	9a d2 21 63 6b       	call   0x6b63:0x21d2
    6a86:	50                   	push   ax
    6a87:	8d be f8 fe          	lea    di,[bp-0x108]
    6a8b:	16                   	push   ss
    6a8c:	57                   	push   di
    6a8d:	8d be f8 fd          	lea    di,[bp-0x208]
    6a91:	16                   	push   ss
    6a92:	57                   	push   di
    6a93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a96:	06                   	push   es
    6a97:	57                   	push   di
    6a98:	9a 53 1d 2a 6b       	call   0x6b2a:0x1d53
    6a9d:	9a 4c 0d 15 6e       	call   0x6e15:0xd4c
    6aa2:	52                   	push   dx
    6aa3:	50                   	push   ax
    6aa4:	6a ff                	push   0xffff
    6aa6:	8d 7e f8             	lea    di,[bp-0x8]
    6aa9:	16                   	push   ss
    6aaa:	57                   	push   di
    6aab:	68 10 08             	push   0x810
    6aae:	9a ff ff 00 00       	call   0x0:0xffff
    6ab3:	c9                   	leave
    6ab4:	ca 04 00             	retf   0x4
    6ab7:	c8 06 00 00          	enter  0x6,0x0
    6abb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6abe:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6ac1:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6ac4:	26 81 7d 02 00 01    	cmp    WORD PTR es:[di+0x2],0x100
    6aca:	72 08                	jb     0x6ad4
    6acc:	26 81 7d 02 08 01    	cmp    WORD PTR es:[di+0x2],0x108
    6ad2:	76 3f                	jbe    0x6b13
    6ad4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6ad7:	26 81 7d 02 00 0f    	cmp    WORD PTR es:[di+0x2],0xf00
    6add:	74 34                	je     0x6b13
    6adf:	26 81 7d 02 01 0f    	cmp    WORD PTR es:[di+0x2],0xf01
    6ae5:	74 2c                	je     0x6b13
    6ae7:	26 81 7d 02 16 0f    	cmp    WORD PTR es:[di+0x2],0xf16
    6aed:	74 24                	je     0x6b13
    6aef:	26 81 7d 02 17 0f    	cmp    WORD PTR es:[di+0x2],0xf17
    6af5:	74 1c                	je     0x6b13
    6af7:	26 81 7d 02 11 01    	cmp    WORD PTR es:[di+0x2],0x111
    6afd:	74 14                	je     0x6b13
    6aff:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    6b05:	76 08                	jbe    0x6b0f
    6b07:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    6b0d:	76 04                	jbe    0x6b13
    6b0f:	b0 00                	mov    al,0x0
    6b11:	eb 02                	jmp    0x6b15
    6b13:	b0 01                	mov    al,0x1
    6b15:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6b18:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6b1b:	c9                   	leave
    6b1c:	ca 08 00             	retf   0x8
    6b1f:	55                   	push   bp
    6b20:	89 e5                	mov    bp,sp
    6b22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b25:	06                   	push   es
    6b26:	57                   	push   di
    6b27:	9a ee 3f 54 6b       	call   0x6b54:0x3fee
    6b2c:	c9                   	leave
    6b2d:	ca 04 00             	retf   0x4
    6b30:	c8 00 01 00          	enter  0x100,0x0
    6b34:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6b37:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6b3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b3d:	06                   	push   es
    6b3e:	57                   	push   di
    6b3f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b42:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    6b46:	8d be 00 ff          	lea    di,[bp-0x100]
    6b4a:	16                   	push   ss
    6b4b:	57                   	push   di
    6b4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b4f:	06                   	push   es
    6b50:	57                   	push   di
    6b51:	9a 53 1d 71 6b       	call   0x6b71:0x1d53
    6b56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b59:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6b5e:	06                   	push   es
    6b5f:	57                   	push   di
    6b60:	9a 03 20 90 6b       	call   0x6b90:0x2003
    6b65:	05 06 00             	add    ax,0x6
    6b68:	50                   	push   ax
    6b69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b6c:	06                   	push   es
    6b6d:	57                   	push   di
    6b6e:	9a bf 17 81 6b       	call   0x6b81:0x17bf
    6b73:	8d be 00 ff          	lea    di,[bp-0x100]
    6b77:	16                   	push   ss
    6b78:	57                   	push   di
    6b79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b7c:	06                   	push   es
    6b7d:	57                   	push   di
    6b7e:	9a 53 1d 9e 6b       	call   0x6b9e:0x1d53
    6b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b86:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6b8b:	06                   	push   es
    6b8c:	57                   	push   di
    6b8d:	9a 4e 20 a4 6c       	call   0x6ca4:0x204e
    6b92:	05 04 00             	add    ax,0x4
    6b95:	50                   	push   ax
    6b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b99:	06                   	push   es
    6b9a:	57                   	push   di
    6b9b:	9a e1 17 c9 6b       	call   0x6bc9:0x17e1
    6ba0:	c9                   	leave
    6ba1:	ca 08 00             	retf   0x8
    6ba4:	c8 08 00 00          	enter  0x8,0x0
    6ba8:	8c d3                	mov    bx,ss
    6baa:	8e c3                	mov    es,bx
    6bac:	8c db                	mov    bx,ds
    6bae:	fc                   	cld
    6baf:	8d 7e f8             	lea    di,[bp-0x8]
    6bb2:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    6bb5:	b9 08 00             	mov    cx,0x8
    6bb8:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    6bba:	8e db                	mov    ds,bx
    6bbc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6bbf:	06                   	push   es
    6bc0:	57                   	push   di
    6bc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bc4:	06                   	push   es
    6bc5:	57                   	push   di
    6bc6:	9a 8c 1d d8 6b       	call   0x6bd8:0x1d8c
    6bcb:	8d 7e f8             	lea    di,[bp-0x8]
    6bce:	16                   	push   ss
    6bcf:	57                   	push   di
    6bd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bd3:	06                   	push   es
    6bd4:	57                   	push   di
    6bd5:	9a 49 18 58 6c       	call   0x6c58:0x1849
    6bda:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6bde:	06                   	push   es
    6bdf:	57                   	push   di
    6be0:	9a a5 60 fe 6b       	call   0x6bfe:0x60a5
    6be5:	8b d0                	mov    dx,ax
    6be7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    6bea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bed:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    6bf1:	3b c2                	cmp    ax,dx
    6bf3:	7e 15                	jle    0x6c0a
    6bf5:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6bf9:	06                   	push   es
    6bfa:	57                   	push   di
    6bfb:	9a a5 60 13 6c       	call   0x6c13:0x60a5
    6c00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c03:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    6c07:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6c0a:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6c0e:	06                   	push   es
    6c0f:	57                   	push   di
    6c10:	9a ba 60 2e 6c       	call   0x6c2e:0x60ba
    6c15:	8b d0                	mov    dx,ax
    6c17:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6c1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c1d:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    6c21:	3b c2                	cmp    ax,dx
    6c23:	7e 15                	jle    0x6c3a
    6c25:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6c29:	06                   	push   es
    6c2a:	57                   	push   di
    6c2b:	9a ba 60 7f 6e       	call   0x6e7f:0x60ba
    6c30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c33:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    6c37:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6c3a:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    6c3e:	7d 05                	jge    0x6c45
    6c40:	31 c0                	xor    ax,ax
    6c42:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6c45:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    6c49:	7d 05                	jge    0x6c50
    6c4b:	31 c0                	xor    ax,ax
    6c4d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6c50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c53:	06                   	push   es
    6c54:	57                   	push   di
    6c55:	9a b9 62 94 6c       	call   0x6c94:0x62b9
    6c5a:	50                   	push   ax
    6c5b:	6a ff                	push   0xffff
    6c5d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    6c60:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6c63:	6a 00                	push   0x0
    6c65:	6a 00                	push   0x0
    6c67:	6a 51                	push   0x51
    6c69:	9a ff ff 00 00       	call   0x0:0xffff
    6c6e:	c9                   	leave
    6c6f:	ca 0c 00             	retf   0xc
    6c72:	55                   	push   bp
    6c73:	89 e5                	mov    bp,sp
    6c75:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6c79:	74 08                	je     0x6c83
    6c7b:	83 ec 08             	sub    sp,0x8
    6c7e:	9a e2 1f ec 6c       	call   0x6cec:0x1fe2
    6c83:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6c86:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6c89:	31 c0                	xor    ax,ax
    6c8b:	50                   	push   ax
    6c8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c8f:	06                   	push   es
    6c90:	57                   	push   di
    6c91:	9a 61 2e 9d 6c       	call   0x6c9d:0x2e61
    6c96:	b0 01                	mov    al,0x1
    6c98:	50                   	push   ax
    6c99:	b8 96 00             	mov    ax,0x96
    6c9c:	ba c3 6c             	mov    dx,0x6cc3
    6c9f:	52                   	push   dx
    6ca0:	50                   	push   ax
    6ca1:	9a b8 17 39 6d       	call   0x6d39:0x17b8
    6ca6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ca9:	26 89 85 d8 00       	mov    WORD PTR es:[di+0xd8],ax
    6cae:	26 89 95 da 00       	mov    WORD PTR es:[di+0xda],dx
    6cb3:	ff 76 08             	push   WORD PTR [bp+0x8]
    6cb6:	ff 76 06             	push   WORD PTR [bp+0x6]
    6cb9:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6cbe:	06                   	push   es
    6cbf:	57                   	push   di
    6cc0:	9a 64 13 f9 6c       	call   0x6cf9:0x1364
    6cc5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6cc9:	74 07                	je     0x6cd2
    6ccb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6ccf:	83 c4 06             	add    sp,0x6
    6cd2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6cd5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6cd8:	c9                   	leave
    6cd9:	ca 0a 00             	retf   0xa
    6cdc:	55                   	push   bp
    6cdd:	89 e5                	mov    bp,sp
    6cdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ce2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6ce7:	06                   	push   es
    6ce8:	57                   	push   di
    6ce9:	9a 7f 1f 04 6d       	call   0x6d04:0x1f7f
    6cee:	31 c0                	xor    ax,ax
    6cf0:	50                   	push   ax
    6cf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cf4:	06                   	push   es
    6cf5:	57                   	push   di
    6cf6:	9a fc 2e 1a 6d       	call   0x6d1a:0x2efc
    6cfb:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6cff:	74 05                	je     0x6d06
    6d01:	9a 0f 20 8a 6d       	call   0x6d8a:0x200f
    6d06:	c9                   	leave
    6d07:	ca 06 00             	retf   0x6
    6d0a:	55                   	push   bp
    6d0b:	89 e5                	mov    bp,sp
    6d0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6d10:	06                   	push   es
    6d11:	57                   	push   di
    6d12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d15:	06                   	push   es
    6d16:	57                   	push   di
    6d17:	9a cb 46 24 6d       	call   0x6d24:0x46cb
    6d1c:	c9                   	leave
    6d1d:	ca 08 00             	retf   0x8
    6d20:	00 00                	add    BYTE PTR [bx+si],al
    6d22:	61                   	popa
    6d23:	6d                   	ins    WORD PTR es:[di],dx
    6d24:	bb 6e 55             	mov    bx,0x556e
    6d27:	89 e5                	mov    bp,sp
    6d29:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6d2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d2f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6d34:	06                   	push   es
    6d35:	57                   	push   di
    6d36:	9a 5d 22 70 6d       	call   0x6d70:0x225d
    6d3b:	b8 20 6d             	mov    ax,0x6d20
    6d3e:	0e                   	push   cs
    6d3f:	50                   	push   ax
    6d40:	55                   	push   bp
    6d41:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6d45:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6d49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d4c:	06                   	push   es
    6d4d:	57                   	push   di
    6d4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d51:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    6d55:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6d59:	83 c4 06             	add    sp,0x6
    6d5c:	b8 73 6d             	mov    ax,0x6d73
    6d5f:	0e                   	push   cs
    6d60:	50                   	push   ax
    6d61:	6a 00                	push   0x0
    6d63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d66:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6d6b:	06                   	push   es
    6d6c:	57                   	push   di
    6d6d:	9a 5d 22 e9 6e       	call   0x6ee9:0x225d
    6d72:	cb                   	retf
    6d73:	c9                   	leave
    6d74:	ca 06 00             	retf   0x6
    6d77:	55                   	push   bp
    6d78:	89 e5                	mov    bp,sp
    6d7a:	c9                   	leave
    6d7b:	ca 04 00             	retf   0x4
    6d7e:	55                   	push   bp
    6d7f:	89 e5                	mov    bp,sp
    6d81:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6d85:	06                   	push   es
    6d86:	57                   	push   di
    6d87:	9a 7f 1f 95 6d       	call   0x6d95:0x1f7f
    6d8c:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6d90:	06                   	push   es
    6d91:	57                   	push   di
    6d92:	9a 7f 1f 5e 6e       	call   0x6e5e:0x1f7f
    6d97:	ff 36 0e 2c          	push   WORD PTR ds:0x2c0e
    6d9b:	9a a5 6d 00 00       	call   0x0:0x6da5
    6da0:	ff 36 10 2c          	push   WORD PTR ds:0x2c10
    6da4:	9a ff ff 00 00       	call   0x0:0xffff
    6da9:	c9                   	leave
    6daa:	cb                   	retf
    6dab:	c8 1c 00 00          	enter  0x1c,0x0
    6daf:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    6db4:	74 3c                	je     0x6df2
    6db6:	6a 60                	push   0x60
    6db8:	9a ff ff 00 00       	call   0x0:0xffff
    6dbd:	68 ff 00             	push   0xff
    6dc0:	9a ff ff 00 00       	call   0x0:0xffff
    6dc5:	8c d0                	mov    ax,ss
    6dc7:	8b d0                	mov    dx,ax
    6dc9:	b8 28 00             	mov    ax,0x28
    6dcc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6dcf:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6dd2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6dd5:	26 c7 05 43 43       	mov    WORD PTR es:[di],0x4343
    6dda:	26 c7 45 02 50 54    	mov    WORD PTR es:[di+0x2],0x5450
    6de0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6de3:	31 c0                	xor    ax,ax
    6de5:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    6de9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6dec:	31 c0                	xor    ax,ax
    6dee:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    6df2:	8d 7e ec             	lea    di,[bp-0x14]
    6df5:	16                   	push   ss
    6df6:	57                   	push   di
    6df7:	bf 04 15             	mov    di,0x1504
    6dfa:	1e                   	push   ds
    6dfb:	57                   	push   di
    6dfc:	a1 8c 18             	mov    ax,ds:0x188c
    6dff:	31 d2                	xor    dx,dx
    6e01:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    6e04:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    6e07:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    6e0b:	8d 7e e4             	lea    di,[bp-0x1c]
    6e0e:	16                   	push   ss
    6e0f:	57                   	push   di
    6e10:	6a 00                	push   0x0
    6e12:	9a a3 0f 44 6e       	call   0x6e44:0xfa3
    6e17:	52                   	push   dx
    6e18:	50                   	push   ax
    6e19:	9a 49 6e 00 00       	call   0x0:0x6e49
    6e1e:	a3 0e 2c             	mov    ds:0x2c0e,ax
    6e21:	8d 7e ec             	lea    di,[bp-0x14]
    6e24:	16                   	push   ss
    6e25:	57                   	push   di
    6e26:	bf 13 15             	mov    di,0x1513
    6e29:	1e                   	push   ds
    6e2a:	57                   	push   di
    6e2b:	a1 8c 18             	mov    ax,ds:0x188c
    6e2e:	31 d2                	xor    dx,dx
    6e30:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    6e33:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    6e36:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    6e3a:	8d 7e e4             	lea    di,[bp-0x1c]
    6e3d:	16                   	push   ss
    6e3e:	57                   	push   di
    6e3f:	6a 00                	push   0x0
    6e41:	9a a3 0f c2 6e       	call   0x6ec2:0xfa3
    6e46:	52                   	push   dx
    6e47:	50                   	push   ax
    6e48:	9a ff ff 00 00       	call   0x0:0xffff
    6e4d:	a3 10 2c             	mov    ds:0x2c10,ax
    6e50:	b0 01                	mov    al,0x1
    6e52:	50                   	push   ax
    6e53:	b8 a3 02             	mov    ax,0x2a3
    6e56:	ba 72 6e             	mov    dx,0x6e72
    6e59:	52                   	push   dx
    6e5a:	50                   	push   ax
    6e5b:	9a 50 1f ff ff       	call   0xffff:0x1f50
    6e60:	a3 26 2c             	mov    ds:0x2c26,ax
    6e63:	89 16 28 2c          	mov    WORD PTR ds:0x2c28,dx
    6e67:	6a 04                	push   0x4
    6e69:	c4 3e 26 2c          	les    di,DWORD PTR ds:0x2c26
    6e6d:	06                   	push   es
    6e6e:	57                   	push   di
    6e6f:	9a d8 0f df 6e       	call   0x6edf:0xfd8
    6e74:	6a 00                	push   0x0
    6e76:	6a 00                	push   0x0
    6e78:	b0 01                	mov    al,0x1
    6e7a:	50                   	push   ax
    6e7b:	b8 30 0d             	mov    ax,0xd30
    6e7e:	ba 86 6e             	mov    dx,0x6e86
    6e81:	52                   	push   dx
    6e82:	50                   	push   ax
    6e83:	9a 80 5f 9a 6e       	call   0x6e9a:0x5f80
    6e88:	a3 2e 2c             	mov    ds:0x2c2e,ax
    6e8b:	89 16 30 2c          	mov    WORD PTR ds:0x2c30,dx
    6e8f:	6a 00                	push   0x0
    6e91:	6a 00                	push   0x0
    6e93:	b0 01                	mov    al,0x1
    6e95:	50                   	push   ax
    6e96:	b8 a3 0d             	mov    ax,0xda3
    6e99:	ba a1 6e             	mov    dx,0x6ea1
    6e9c:	52                   	push   dx
    6e9d:	50                   	push   ax
    6e9e:	9a 55 64 b5 6e       	call   0x6eb5:0x6455
    6ea3:	a3 2a 2c             	mov    ds:0x2c2a,ax
    6ea6:	89 16 2c 2c          	mov    WORD PTR ds:0x2c2c,dx
    6eaa:	6a 01                	push   0x1
    6eac:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6eb0:	06                   	push   es
    6eb1:	57                   	push   di
    6eb2:	9a a2 78 ff ff       	call   0xffff:0x78a2
    6eb7:	bf 7e 6d             	mov    di,0x6d7e
    6eba:	b8 c8 6e             	mov    ax,0x6ec8
    6ebd:	50                   	push   ax
    6ebe:	57                   	push   di
    6ebf:	9a 74 05 ff ff       	call   0xffff:0x574
    6ec4:	bf 64 00             	mov    di,0x64
    6ec7:	b8 d0 6e             	mov    ax,0x6ed0
    6eca:	50                   	push   ax
    6ecb:	57                   	push   di
    6ecc:	bf 3b 0c             	mov    di,0xc3b
    6ecf:	b8 d8 6e             	mov    ax,0x6ed8
    6ed2:	50                   	push   ax
    6ed3:	57                   	push   di
    6ed4:	bf d1 0b             	mov    di,0xbd1
    6ed7:	b8 ff ff             	mov    ax,0xffff
    6eda:	50                   	push   ax
    6edb:	57                   	push   di
    6edc:	9a 36 0a ff ff       	call   0xffff:0xa36
    6ee1:	c9                   	leave
    6ee2:	c3                   	ret
    6ee3:	55                   	push   bp
    6ee4:	89 e5                	mov    bp,sp
    6ee6:	9a d9 6f ff ff       	call   0xffff:0x6fd9
    6eeb:	e8 bd fe             	call   0x6dab
    6eee:	9a ff ff 00 00       	call   0x0:0xffff
    6ef3:	3d 03 5f             	cmp    ax,0x5f03
    6ef6:	b0 00                	mov    al,0x0
    6ef8:	72 01                	jb     0x6efb
    6efa:	40                   	inc    ax
    6efb:	a2 0c 2c             	mov    ds:0x2c0c,al
    6efe:	c9                   	leave
    6eff:	cb                   	retf
