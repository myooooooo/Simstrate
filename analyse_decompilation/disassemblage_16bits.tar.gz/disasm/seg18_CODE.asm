; ================================================================
; seg18_CODE  (32463 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	12 00                	adc    al,BYTE PTR [bx+si]
       2:	22 0d                	and    cl,BYTE PTR [di]
       4:	f2 02 b2 00 00       	repnz add dh,BYTE PTR [bp+si+0x0]
       9:	00 9e 00 92          	add    BYTE PTR [bp-0x6e00],bl
       d:	04 fb                	add    al,0xfb
       f:	04 3d                	add    al,0x3d
      11:	0d 39 3f             	or     ax,0x3f39
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 50 0d cb       	call   0xcb0d:0x501f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 28                	adc    BYTE PTR [bx+si],ch
      2d:	10 d6                	adc    dh,dl
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c a9                	sbb    al,0xa9
      61:	0e                   	push   cs
      62:	e2 2f                	loop   0x93
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	13 54 46             	adc    dx,WORD PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	41                   	inc    cx
      a6:	44                   	inc    sp
      a7:	44                   	inc    sp
      a8:	5f                   	pop    di
      a9:	44                   	inc    sp
      aa:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
      ae:	69 6f 6e 73 1f       	imul   bp,WORD PTR [bx+0x6e],0x1f73
      b3:	00 e9                	add    cl,ch
      b5:	60                   	pusha
      b6:	c7 00 0c 48          	mov    WORD PTR [bx+si],0x480c
      ba:	65 6c                	gs ins BYTE PTR es:[di],dx
      bc:	70 42                	jo     0x100
      be:	74 6e                	je     0x12e
      c0:	43                   	inc    bx
      c1:	6c                   	ins    BYTE PTR es:[di],dx
      c2:	69 63 6b 92 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2d92
      c7:	d9 00                	fld    DWORD PTR [bx+si]
      c9:	0d 50 72             	or     ax,0x7250
      cc:	69 6e 74 42 74       	imul   bp,WORD PTR [bp+0x74],0x7442
      d1:	6e                   	outs   dx,BYTE PTR ds:[si]
      d2:	43                   	inc    bx
      d3:	6c                   	ins    BYTE PTR es:[di],dx
      d4:	69 63 6b 68 12       	imul   sp,WORD PTR [bp+di+0x6b],0x1268
      d9:	e7 00                	out    0x0,ax
      db:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
      de:	72 6d                	jb     0x14d
      e0:	43                   	inc    bx
      e1:	6c                   	ins    BYTE PTR es:[di],dx
      e2:	6f                   	outs   dx,WORD PTR ds:[si]
      e3:	73 65                	jae    0x14a
      e5:	9b                   	fwait
      e6:	7b f8                	jnp    0xe0
      e8:	00 0c                	add    BYTE PTR [si],cl
      ea:	54                   	push   sp
      eb:	65 73 74             	gs jae 0x162
      ee:	42                   	inc    dx
      ef:	74 6e                	je     0x15f
      f1:	43                   	inc    bx
      f2:	6c                   	ins    BYTE PTR es:[di],dx
      f3:	69 63 6b 28 0f       	imul   sp,WORD PTR [bp+di+0x6b],0xf28
      f8:	07                   	pop    es
      f9:	01 0a                	add    WORD PTR [bp+si],cx
      fb:	46                   	inc    si
      fc:	6f                   	outs   dx,WORD PTR ds:[si]
      fd:	72 6d                	jb     0x16c
      ff:	43                   	inc    bx
     100:	72 65                	jb     0x167
     102:	61                   	popa
     103:	74 65                	je     0x16a
     105:	ef                   	out    dx,ax
     106:	12 1a                	adc    bl,BYTE PTR [bp+si]
     108:	01 0e 46 6f          	add    WORD PTR ds:0x6f46,cx
     10c:	72 6d                	jb     0x17b
     10e:	43                   	inc    bx
     10f:	6c                   	ins    BYTE PTR es:[di],dx
     110:	6f                   	outs   dx,WORD PTR ds:[si]
     111:	73 65                	jae    0x178
     113:	51                   	push   cx
     114:	75 65                	jne    0x17b
     116:	72 79                	jb     0x191
     118:	7a 30                	jp     0x14a
     11a:	32 01                	xor    al,BYTE PTR [bx+di]
     11c:	13 45 6e             	adc    ax,WORD PTR [di+0x6e]
     11f:	72 65                	jb     0x186
     121:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
     127:	72 42                	jb     0x16b
     129:	74 6e                	je     0x199
     12b:	43                   	inc    bx
     12c:	6c                   	ins    BYTE PTR es:[di],dx
     12d:	69 63 6b 94 2e       	imul   sp,WORD PTR [bp+di+0x6b],0x2e94
     132:	41                   	inc    cx
     133:	01 0a                	add    WORD PTR [bp+si],cx
     135:	4f                   	dec    di
     136:	4b                   	dec    bx
     137:	42                   	inc    dx
     138:	74 6e                	je     0x1a8
     13a:	43                   	inc    bx
     13b:	6c                   	ins    BYTE PTR es:[di],dx
     13c:	69 63 6b c8 2e       	imul   sp,WORD PTR [bp+di+0x6b],0x2ec8
     141:	55                   	push   bp
     142:	01 0f                	add    WORD PTR [bx],cx
     144:	42                   	inc    dx
     145:	61                   	popa
     146:	73 63                	jae    0x1ab
     148:	75 6c                	jne    0x1b6
     14a:	65 42                	gs inc dx
     14c:	74 6e                	je     0x1bc
     14e:	43                   	inc    bx
     14f:	6c                   	ins    BYTE PTR es:[di],dx
     150:	69 63 6b 62 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3062
     155:	6a 01                	push   0x1
     157:	10 56 65             	adc    BYTE PTR [bp+0x65],dl
     15a:	72 69                	jb     0x1c5
     15c:	66 69 65 72 42 74 6e 	imul   esp,DWORD PTR [di+0x72],0x436e7442
     163:	43 
     164:	6c                   	ins    BYTE PTR es:[di],dx
     165:	69 63 6b a5 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30a5
     16a:	7d 01                	jge    0x16d
     16c:	0e                   	push   cs
     16d:	44                   	inc    sp
     16e:	65 66 61             	gs popad
     171:	75 74                	jne    0x1e7
     173:	42                   	inc    dx
     174:	74 6e                	je     0x1e4
     176:	43                   	inc    bx
     177:	6c                   	ins    BYTE PTR es:[di],dx
     178:	69 63 6b c1 16       	imul   sp,WORD PTR [bp+di+0x6b],0x16c1
     17d:	92                   	xchg   dx,ax
     17e:	01 10                	add    WORD PTR [bx+si],dx
     180:	53                   	push   bx
     181:	70 69                	jo     0x1ec
     183:	6e                   	outs   dx,BYTE PTR ds:[si]
     184:	45                   	inc    bp
     185:	64 69 74 50 31 43    	imul   si,WORD PTR fs:[si+0x50],0x4331
     18b:	68 61 6e             	push   0x6e61
     18e:	67 65 cb             	addr32 gs retf
     191:	1b a3 01 0c          	sbb    sp,WORD PTR [bp+di+0xc01]
     195:	44                   	inc    sp
     196:	42                   	inc    dx
     197:	45                   	inc    bp
     198:	64 69 74 31 45 6e    	imul   si,WORD PTR fs:[si+0x31],0x6e45
     19e:	74 65                	je     0x205
     1a0:	72 5e                	jb     0x200
     1a2:	1f                   	pop    ds
     1a3:	b3 01                	mov    bl,0x1
     1a5:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     1a8:	45                   	inc    bp
     1a9:	64 69 74 31 45 78    	imul   si,WORD PTR fs:[si+0x31],0x7845
     1af:	69 74 7a 23 c4       	imul   si,WORD PTR [si+0x7a],0xc423
     1b4:	01 0c                	add    WORD PTR [si],cx
     1b6:	44                   	inc    sp
     1b7:	42                   	inc    dx
     1b8:	45                   	inc    bp
     1b9:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1bf:	79 55                	jns    0x216
     1c1:	70 23                	jo     0x1e6
     1c3:	24 d7                	and    al,0xd7
     1c5:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     1c9:	45                   	inc    bp
     1ca:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1d0:	79 44                	jns    0x216
     1d2:	6f                   	outs   dx,WORD PTR ds:[si]
     1d3:	77 6e                	ja     0x243
     1d5:	bd 30 eb             	mov    bp,0xeb30
     1d8:	01 0f                	add    WORD PTR [bx],cx
     1da:	49                   	dec    cx
     1db:	6e                   	outs   dx,BYTE PTR ds:[si]
     1dc:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     1e1:	42                   	inc    dx
     1e2:	74 6e                	je     0x252
     1e4:	43                   	inc    bx
     1e5:	6c                   	ins    BYTE PTR es:[di],dx
     1e6:	69 63 6b 8f 60       	imul   sp,WORD PTR [bp+di+0x6b],0x608f
     1eb:	fc                   	cld
     1ec:	01 0c                	add    WORD PTR [si],cx
     1ee:	46                   	inc    si
     1ef:	6f                   	outs   dx,WORD PTR ds:[si]
     1f0:	72 6d                	jb     0x25f
     1f2:	4b                   	dec    bx
     1f3:	65 79 50             	gs jns 0x246
     1f6:	72 65                	jb     0x25d
     1f8:	73 73                	jae    0x26d
     1fa:	b0 5f                	mov    al,0x5f
     1fc:	0c 02                	or     al,0x2
     1fe:	0b 54 69             	or     dx,WORD PTR [si+0x69]
     201:	6d                   	ins    WORD PTR es:[di],dx
     202:	65 72 31             	gs jb  0x236
     205:	54                   	push   sp
     206:	69 6d 65 72 aa       	imul   bp,WORD PTR [di+0x65],0xaa72
     20b:	60                   	pusha
     20c:	1c 02                	sbb    al,0x2
     20e:	0b 46 6f             	or     ax,WORD PTR [bp+0x6f]
     211:	72 6d                	jb     0x280
     213:	4b                   	dec    bx
     214:	65 79 44             	gs jns 0x25b
     217:	6f                   	outs   dx,WORD PTR ds:[si]
     218:	77 6e                	ja     0x288
     21a:	91                   	xchg   cx,ax
     21b:	61                   	popa
     21c:	31 02                	xor    WORD PTR [bp+si],ax
     21e:	10 44 42             	adc    BYTE PTR [si+0x42],al
     221:	45                   	inc    bp
     222:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     228:	75 73                	jne    0x29d
     22a:	65 44                	gs inc sp
     22c:	6f                   	outs   dx,WORD PTR ds:[si]
     22d:	77 6e                	ja     0x29d
     22f:	6d                   	ins    WORD PTR es:[di],dx
     230:	66 44                	inc    esp
     232:	02 0e 43 6f          	add    cl,BYTE PTR ds:0x6f43
     236:	70 69                	jo     0x2a1
     238:	65 72 42             	gs jb  0x27d
     23b:	74 6e                	je     0x2ab
     23d:	43                   	inc    bx
     23e:	6c                   	ins    BYTE PTR es:[di],dx
     23f:	69 63 6b 15 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c15
     244:	54                   	push   sp
     245:	02 0b                	add    cl,BYTE PTR [bp+di]
     247:	50                   	push   ax
     248:	72 69                	jb     0x2b3
     24a:	6e                   	outs   dx,BYTE PTR ds:[si]
     24b:	74 31                	je     0x27e
     24d:	43                   	inc    bx
     24e:	6c                   	ins    BYTE PTR es:[di],dx
     24f:	69 63 6b 58 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c58
     254:	63 02                	arpl   WORD PTR [bp+si],ax
     256:	0a 43 6f             	or     al,BYTE PTR [bp+di+0x6f]
     259:	70 79                	jo     0x2d4
     25b:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     25e:	69 63 6b aa 7d       	imul   sp,WORD PTR [bp+di+0x6b],0x7daa
     263:	79 02                	jns    0x267
     265:	11 52 61             	adc    WORD PTR [bp+si+0x61],dx
     268:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
     26e:	74 6f                	je     0x2df
     270:	6e                   	outs   dx,BYTE PTR ds:[si]
     271:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     274:	69 63 6b 02 7e       	imul   sp,WORD PTR [bp+di+0x6b],0x7e02
     279:	8f 02                	pop    WORD PTR [bp+si]
     27b:	11 52 61             	adc    WORD PTR [bp+si+0x61],dx
     27e:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
     284:	74 6f                	je     0x2f5
     286:	6e                   	outs   dx,BYTE PTR ds:[si]
     287:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     28a:	69 63 6b 5a 7e       	imul   sp,WORD PTR [bp+di+0x6b],0x7e5a
     28f:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     290:	02 11                	add    dl,BYTE PTR [bx+di]
     292:	52                   	push   dx
     293:	61                   	popa
     294:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
     29a:	74 6f                	je     0x30b
     29c:	6e                   	outs   dx,BYTE PTR ds:[si]
     29d:	33 43 6c             	xor    ax,WORD PTR [bp+di+0x6c]
     2a0:	69 63 6b b2 7e       	imul   sp,WORD PTR [bp+di+0x6b],0x7eb2
     2a5:	b9 02 0f             	mov    cx,0xf02
     2a8:	53                   	push   bx
     2a9:	70 69                	jo     0x314
     2ab:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ac:	45                   	inc    bp
     2ad:	64 69 74 31 43 68    	imul   si,WORD PTR fs:[si+0x31],0x6843
     2b3:	61                   	popa
     2b4:	6e                   	outs   dx,BYTE PTR ds:[si]
     2b5:	67 65 1f             	addr32 gs pop ds
     2b8:	62 ce 02             	(bad)  {rn-bad}
     2bb:	10 50 61             	adc    BYTE PTR [bx+si+0x61],dl
     2be:	6e                   	outs   dx,BYTE PTR ds:[si]
     2bf:	65 6c                	gs ins BYTE PTR es:[di],dx
     2c1:	32 35                	xor    dh,BYTE PTR [di]
     2c3:	4d                   	dec    bp
     2c4:	6f                   	outs   dx,WORD PTR ds:[si]
     2c5:	75 73                	jne    0x33a
     2c7:	65 44                	gs inc sp
     2c9:	6f                   	outs   dx,WORD PTR ds:[si]
     2ca:	77 6e                	ja     0x33a
     2cc:	4d                   	dec    bp
     2cd:	12 db                	adc    bl,bl
     2cf:	02 08                	add    cl,BYTE PTR [bx+si]
     2d1:	46                   	inc    si
     2d2:	6f                   	outs   dx,WORD PTR ds:[si]
     2d3:	72 6d                	jb     0x342
     2d5:	53                   	push   bx
     2d6:	68 6f 77             	push   0x776f
     2d9:	4f                   	dec    di
     2da:	2e 39 0d             	cmp    WORD PTR cs:[di],cx
     2dd:	14 50                	adc    al,0x50
     2df:	72 69                	jb     0x34a
     2e1:	6e                   	outs   dx,BYTE PTR ds:[si]
     2e2:	74 52                	je     0x336
     2e4:	61                   	popa
     2e5:	70 69                	jo     0x350
     2e7:	64 65 42             	fs gs inc dx
     2ea:	74 6e                	je     0x35a
     2ec:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2ef:	69 63 6b c3 00       	imul   sp,WORD PTR [bp+di+0x6b],0xc3
     2f4:	d4 0c                	aam    0xc
     2f6:	7c 01                	jl     0x2f9
     2f8:	00 00                	add    BYTE PTR [bx+si],al
     2fa:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     2fe:	62 65 64             	bound  sp,DWORD PTR [di+0x64]
     301:	4e                   	dec    si
     302:	6f                   	outs   dx,WORD PTR ds:[si]
     303:	74 65                	je     0x36a
     305:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     308:	6b 31 80             	imul   si,WORD PTR [bx+di],0xff80
     30b:	01 04                	add    WORD PTR [si],ax
     30d:	00 09                	add    BYTE PTR [bx+di],cl
     30f:	47                   	inc    di
     310:	72 6f                	jb     0x381
     312:	75 70                	jne    0x384
     314:	42                   	inc    dx
     315:	6f                   	outs   dx,WORD PTR ds:[si]
     316:	78 31                	js     0x349
     318:	84 01                	test   BYTE PTR [bx+di],al
     31a:	04 00                	add    al,0x0
     31c:	09 47 72             	or     WORD PTR [bx+0x72],ax
     31f:	6f                   	outs   dx,WORD PTR ds:[si]
     320:	75 70                	jne    0x392
     322:	42                   	inc    dx
     323:	6f                   	outs   dx,WORD PTR ds:[si]
     324:	78 32                	js     0x358
     326:	88 01                	mov    BYTE PTR [bx+di],al
     328:	04 00                	add    al,0x0
     32a:	09 47 72             	or     WORD PTR [bx+0x72],ax
     32d:	6f                   	outs   dx,WORD PTR ds:[si]
     32e:	75 70                	jne    0x3a0
     330:	42                   	inc    dx
     331:	6f                   	outs   dx,WORD PTR ds:[si]
     332:	78 34                	js     0x368
     334:	8c 01                	mov    WORD PTR [bx+di],es
     336:	04 00                	add    al,0x0
     338:	09 47 72             	or     WORD PTR [bx+0x72],ax
     33b:	6f                   	outs   dx,WORD PTR ds:[si]
     33c:	75 70                	jne    0x3ae
     33e:	42                   	inc    dx
     33f:	6f                   	outs   dx,WORD PTR ds:[si]
     340:	78 35                	js     0x377
     342:	90                   	nop
     343:	01 08                	add    WORD PTR [bx+si],cx
     345:	00 07                	add    BYTE PTR [bx],al
     347:	54                   	push   sp
     348:	61                   	popa
     349:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     34c:	44                   	inc    sp
     34d:	47                   	inc    di
     34e:	94                   	xchg   sp,ax
     34f:	01 0c                	add    WORD PTR [si],cx
     351:	00 0c                	add    BYTE PTR [si],cl
     353:	44                   	inc    sp
     354:	61                   	popa
     355:	74 61                	je     0x3b8
     357:	53                   	push   bx
     358:	6f                   	outs   dx,WORD PTR ds:[si]
     359:	75 72                	jne    0x3cd
     35b:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     35e:	47                   	inc    di
     35f:	98                   	cbw
     360:	01 0c                	add    WORD PTR [si],cx
     362:	00 0d                	add    BYTE PTR [di],cl
     364:	44                   	inc    sp
     365:	61                   	popa
     366:	74 61                	je     0x3c9
     368:	53                   	push   bx
     369:	6f                   	outs   dx,WORD PTR ds:[si]
     36a:	75 72                	jne    0x3de
     36c:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     36f:	50                   	push   ax
     370:	31 9c 01 0c          	xor    WORD PTR [si+0xc01],bx
     374:	00 0d                	add    BYTE PTR [di],cl
     376:	44                   	inc    sp
     377:	61                   	popa
     378:	74 61                	je     0x3db
     37a:	53                   	push   bx
     37b:	6f                   	outs   dx,WORD PTR ds:[si]
     37c:	75 72                	jne    0x3f0
     37e:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     381:	50                   	push   ax
     382:	32 a0 01 10          	xor    ah,BYTE PTR [bx+si+0x1001]
     386:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     38a:	6e                   	outs   dx,BYTE PTR ds:[si]
     38b:	65 6c                	gs ins BYTE PTR es:[di],dx
     38d:	32 a4 01 14          	xor    ah,BYTE PTR [si+0x1401]
     391:	00 07                	add    BYTE PTR [bx],al
     393:	4c                   	dec    sp
     394:	61                   	popa
     395:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     398:	50                   	push   ax
     399:	31 a8 01 14          	xor    WORD PTR [bx+si+0x1401],bp
     39d:	00 07                	add    BYTE PTR [bx],al
     39f:	4c                   	dec    sp
     3a0:	61                   	popa
     3a1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3a4:	32 38                	xor    bh,BYTE PTR [bx+si]
     3a6:	ac                   	lods   al,BYTE PTR ds:[si]
     3a7:	01 18                	add    WORD PTR [bx+si],bx
     3a9:	00 07                	add    BYTE PTR [bx],al
     3ab:	54                   	push   sp
     3ac:	65 73 74             	gs jae 0x423
     3af:	42                   	inc    dx
     3b0:	74 6e                	je     0x420
     3b2:	b0 01                	mov    al,0x1
     3b4:	1c 00                	sbb    al,0x0
     3b6:	0c 50                	or     al,0x50
     3b8:	72 69                	jb     0x423
     3ba:	6e                   	outs   dx,BYTE PTR ds:[si]
     3bb:	74 44                	je     0x401
     3bd:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     3c2:	31 b4 01 08          	xor    WORD PTR [si+0x801],si
     3c6:	00 0a                	add    BYTE PTR [bp+si],cl
     3c8:	54                   	push   sp
     3c9:	61                   	popa
     3ca:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3cd:	44                   	inc    sp
     3ce:	47                   	inc    di
     3cf:	42                   	inc    dx
     3d0:	69 73 b8 01 08       	imul   si,WORD PTR [bp+di-0x48],0x801
     3d5:	00 0a                	add    BYTE PTR [bp+si],cl
     3d7:	54                   	push   sp
     3d8:	61                   	popa
     3d9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3dc:	44                   	inc    sp
     3dd:	50                   	push   ax
     3de:	42                   	inc    dx
     3df:	69 73 bc 01 08       	imul   si,WORD PTR [bp+di-0x44],0x801
     3e4:	00 08                	add    BYTE PTR [bx+si],cl
     3e6:	54                   	push   sp
     3e7:	61                   	popa
     3e8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3eb:	44                   	inc    sp
     3ec:	50                   	push   ax
     3ed:	31 c0                	xor    ax,ax
     3ef:	01 08                	add    WORD PTR [bx+si],cx
     3f1:	00 08                	add    BYTE PTR [bx+si],cl
     3f3:	54                   	push   sp
     3f4:	61                   	popa
     3f5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3f8:	44                   	inc    sp
     3f9:	50                   	push   ax
     3fa:	32 c4                	xor    al,ah
     3fc:	01 04                	add    WORD PTR [si],ax
     3fe:	00 09                	add    BYTE PTR [bx+di],cl
     400:	47                   	inc    di
     401:	72 6f                	jb     0x472
     403:	75 70                	jne    0x475
     405:	42                   	inc    dx
     406:	6f                   	outs   dx,WORD PTR ds:[si]
     407:	78 37                	js     0x440
     409:	c8 01 10 00          	enter  0x1001,0x0
     40d:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     410:	6e                   	outs   dx,BYTE PTR ds:[si]
     411:	65 6c                	gs ins BYTE PTR es:[di],dx
     413:	4c                   	dec    sp
     414:	4f                   	dec    di
     415:	55                   	push   bp
     416:	50                   	push   ax
     417:	45                   	inc    bp
     418:	cc                   	int3
     419:	01 08                	add    WORD PTR [bx+si],cx
     41b:	00 08                	add    BYTE PTR [bx+si],cl
     41d:	54                   	push   sp
     41e:	61                   	popa
     41f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     422:	45                   	inc    bp
     423:	44                   	inc    sp
     424:	47                   	inc    di
     425:	d0 01                	rol    BYTE PTR [bx+di],1
     427:	20 00                	and    BYTE PTR [bx+si],al
     429:	06                   	push   es
     42a:	54                   	push   sp
     42b:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     430:	d4 01                	aam    0x1
     432:	04 00                	add    al,0x0
     434:	09 47 72             	or     WORD PTR [bx+0x72],ax
     437:	6f                   	outs   dx,WORD PTR ds:[si]
     438:	75 70                	jne    0x4aa
     43a:	42                   	inc    dx
     43b:	6f                   	outs   dx,WORD PTR ds:[si]
     43c:	78 36                	js     0x474
     43e:	d8 01                	fadd   DWORD PTR [bx+di]
     440:	04 00                	add    al,0x0
     442:	09 47 72             	or     WORD PTR [bx+0x72],ax
     445:	6f                   	outs   dx,WORD PTR ds:[si]
     446:	75 70                	jne    0x4b8
     448:	42                   	inc    dx
     449:	6f                   	outs   dx,WORD PTR ds:[si]
     44a:	78 38                	js     0x484
     44c:	dc 01                	fadd   QWORD PTR [bx+di]
     44e:	04 00                	add    al,0x0
     450:	09 47 72             	or     WORD PTR [bx+0x72],ax
     453:	6f                   	outs   dx,WORD PTR ds:[si]
     454:	75 70                	jne    0x4c6
     456:	42                   	inc    dx
     457:	6f                   	outs   dx,WORD PTR ds:[si]
     458:	78 39                	js     0x493
     45a:	e0 01                	loopne 0x45d
     45c:	04 00                	add    al,0x0
     45e:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     461:	6f                   	outs   dx,WORD PTR ds:[si]
     462:	75 70                	jne    0x4d4
     464:	42                   	inc    dx
     465:	6f                   	outs   dx,WORD PTR ds:[si]
     466:	78 31                	js     0x499
     468:	31 e4                	xor    sp,sp
     46a:	01 04                	add    WORD PTR [si],ax
     46c:	00 0a                	add    BYTE PTR [bp+si],cl
     46e:	47                   	inc    di
     46f:	72 6f                	jb     0x4e0
     471:	75 70                	jne    0x4e3
     473:	42                   	inc    dx
     474:	6f                   	outs   dx,WORD PTR ds:[si]
     475:	78 31                	js     0x4a8
     477:	32 e8                	xor    ch,al
     479:	01 10                	add    WORD PTR [bx+si],dx
     47b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     47f:	6e                   	outs   dx,BYTE PTR ds:[si]
     480:	65 6c                	gs ins BYTE PTR es:[di],dx
     482:	31 ec                	xor    sp,bp
     484:	01 14                	add    WORD PTR [si],dx
     486:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     48a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     48d:	35 f0 01             	xor    ax,0x1f0
     490:	24 00                	and    al,0x0
     492:	07                   	pop    es
     493:	44                   	inc    sp
     494:	42                   	inc    dx
     495:	45                   	inc    bp
     496:	64 69 74 35 f4 01    	imul   si,WORD PTR fs:[si+0x35],0x1f4
     49c:	24 00                	and    al,0x0
     49e:	07                   	pop    es
     49f:	44                   	inc    sp
     4a0:	42                   	inc    dx
     4a1:	45                   	inc    bp
     4a2:	64 69 74 37 f8 01    	imul   si,WORD PTR fs:[si+0x37],0x1f8
     4a8:	24 00                	and    al,0x0
     4aa:	07                   	pop    es
     4ab:	44                   	inc    sp
     4ac:	42                   	inc    dx
     4ad:	45                   	inc    bp
     4ae:	64 69 74 39 fc 01    	imul   si,WORD PTR fs:[si+0x39],0x1fc
     4b4:	10 00                	adc    BYTE PTR [bx+si],al
     4b6:	06                   	push   es
     4b7:	50                   	push   ax
     4b8:	61                   	popa
     4b9:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ba:	65 6c                	gs ins BYTE PTR es:[di],dx
     4bc:	35 00 02             	xor    ax,0x200
     4bf:	14 00                	adc    al,0x0
     4c1:	06                   	push   es
     4c2:	4c                   	dec    sp
     4c3:	61                   	popa
     4c4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4c7:	36 04 02             	ss add al,0x2
     4ca:	24 00                	and    al,0x0
     4cc:	07                   	pop    es
     4cd:	44                   	inc    sp
     4ce:	42                   	inc    dx
     4cf:	45                   	inc    bp
     4d0:	64 69 74 36 08 02    	imul   si,WORD PTR fs:[si+0x36],0x208
     4d6:	24 00                	and    al,0x0
     4d8:	07                   	pop    es
     4d9:	44                   	inc    sp
     4da:	42                   	inc    dx
     4db:	45                   	inc    bp
     4dc:	64 69 74 38 0c 02    	imul   si,WORD PTR fs:[si+0x38],0x20c
     4e2:	24 00                	and    al,0x0
     4e4:	08 44 42             	or     BYTE PTR [si+0x42],al
     4e7:	45                   	inc    bp
     4e8:	64 69 74 31 30 10    	imul   si,WORD PTR fs:[si+0x31],0x1030
     4ee:	02 10                	add    dl,BYTE PTR [bx+si]
     4f0:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     4f4:	6e                   	outs   dx,BYTE PTR ds:[si]
     4f5:	65 6c                	gs ins BYTE PTR es:[di],dx
     4f7:	36 14 02             	ss adc al,0x2
     4fa:	14 00                	adc    al,0x0
     4fc:	07                   	pop    es
     4fd:	4c                   	dec    sp
     4fe:	61                   	popa
     4ff:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     502:	31 37                	xor    WORD PTR [bx],si
     504:	18 02                	sbb    BYTE PTR [bp+si],al
     506:	24 00                	and    al,0x0
     508:	08 44 42             	or     BYTE PTR [si+0x42],al
     50b:	45                   	inc    bp
     50c:	64 69 74 31 37 1c    	imul   si,WORD PTR fs:[si+0x31],0x1c37
     512:	02 10                	add    dl,BYTE PTR [bx+si]
     514:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     518:	6e                   	outs   dx,BYTE PTR ds:[si]
     519:	65 6c                	gs ins BYTE PTR es:[di],dx
     51b:	37                   	aaa
     51c:	20 02                	and    BYTE PTR [bp+si],al
     51e:	14 00                	adc    al,0x0
     520:	07                   	pop    es
     521:	4c                   	dec    sp
     522:	61                   	popa
     523:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     526:	31 38                	xor    WORD PTR [bx+si],di
     528:	24 02                	and    al,0x2
     52a:	24 00                	and    al,0x0
     52c:	08 44 42             	or     BYTE PTR [si+0x42],al
     52f:	45                   	inc    bp
     530:	64 69 74 31 39 28    	imul   si,WORD PTR fs:[si+0x31],0x2839
     536:	02 10                	add    dl,BYTE PTR [bx+si]
     538:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     53c:	6e                   	outs   dx,BYTE PTR ds:[si]
     53d:	65 6c                	gs ins BYTE PTR es:[di],dx
     53f:	38 2c                	cmp    BYTE PTR [si],ch
     541:	02 14                	add    dl,BYTE PTR [si]
     543:	00 07                	add    BYTE PTR [bx],al
     545:	4c                   	dec    sp
     546:	61                   	popa
     547:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     54a:	32 36 30 02          	xor    dh,BYTE PTR ds:0x230
     54e:	24 00                	and    al,0x0
     550:	08 44 42             	or     BYTE PTR [si+0x42],al
     553:	45                   	inc    bp
     554:	64 69 74 32 31 34    	imul   si,WORD PTR fs:[si+0x32],0x3431
     55a:	02 24                	add    ah,BYTE PTR [si]
     55c:	00 08                	add    BYTE PTR [bx+si],cl
     55e:	44                   	inc    sp
     55f:	42                   	inc    dx
     560:	45                   	inc    bp
     561:	64 69 74 32 32 38    	imul   si,WORD PTR fs:[si+0x32],0x3832
     567:	02 24                	add    ah,BYTE PTR [si]
     569:	00 08                	add    BYTE PTR [bx+si],cl
     56b:	44                   	inc    sp
     56c:	42                   	inc    dx
     56d:	45                   	inc    bp
     56e:	64 69 74 32 33 3c    	imul   si,WORD PTR fs:[si+0x32],0x3c33
     574:	02 24                	add    ah,BYTE PTR [si]
     576:	00 08                	add    BYTE PTR [bx+si],cl
     578:	44                   	inc    sp
     579:	42                   	inc    dx
     57a:	45                   	inc    bp
     57b:	64 69 74 34 31 40    	imul   si,WORD PTR fs:[si+0x34],0x4031
     581:	02 10                	add    dl,BYTE PTR [bx+si]
     583:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     587:	6e                   	outs   dx,BYTE PTR ds:[si]
     588:	65 6c                	gs ins BYTE PTR es:[di],dx
     58a:	39 44 02             	cmp    WORD PTR [si+0x2],ax
     58d:	14 00                	adc    al,0x0
     58f:	07                   	pop    es
     590:	4c                   	dec    sp
     591:	61                   	popa
     592:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     595:	32 37                	xor    dh,BYTE PTR [bx]
     597:	48                   	dec    ax
     598:	02 24                	add    ah,BYTE PTR [si]
     59a:	00 08                	add    BYTE PTR [bx+si],cl
     59c:	44                   	inc    sp
     59d:	42                   	inc    dx
     59e:	45                   	inc    bp
     59f:	64 69 74 32 36 4c    	imul   si,WORD PTR fs:[si+0x32],0x4c36
     5a5:	02 24                	add    ah,BYTE PTR [si]
     5a7:	00 08                	add    BYTE PTR [bx+si],cl
     5a9:	44                   	inc    sp
     5aa:	42                   	inc    dx
     5ab:	45                   	inc    bp
     5ac:	64 69 74 32 37 50    	imul   si,WORD PTR fs:[si+0x32],0x5037
     5b2:	02 24                	add    ah,BYTE PTR [si]
     5b4:	00 08                	add    BYTE PTR [bx+si],cl
     5b6:	44                   	inc    sp
     5b7:	42                   	inc    dx
     5b8:	45                   	inc    bp
     5b9:	64 69 74 32 38 54    	imul   si,WORD PTR fs:[si+0x32],0x5438
     5bf:	02 24                	add    ah,BYTE PTR [si]
     5c1:	00 08                	add    BYTE PTR [bx+si],cl
     5c3:	44                   	inc    sp
     5c4:	42                   	inc    dx
     5c5:	45                   	inc    bp
     5c6:	64 69 74 34 32 58    	imul   si,WORD PTR fs:[si+0x34],0x5832
     5cc:	02 10                	add    dl,BYTE PTR [bx+si]
     5ce:	00 07                	add    BYTE PTR [bx],al
     5d0:	50                   	push   ax
     5d1:	61                   	popa
     5d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d3:	65 6c                	gs ins BYTE PTR es:[di],dx
     5d5:	31 30                	xor    WORD PTR [bx+si],si
     5d7:	5c                   	pop    sp
     5d8:	02 14                	add    dl,BYTE PTR [si]
     5da:	00 07                	add    BYTE PTR [bx],al
     5dc:	4c                   	dec    sp
     5dd:	61                   	popa
     5de:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5e1:	34 32                	xor    al,0x32
     5e3:	60                   	pusha
     5e4:	02 24                	add    ah,BYTE PTR [si]
     5e6:	00 08                	add    BYTE PTR [bx+si],cl
     5e8:	44                   	inc    sp
     5e9:	42                   	inc    dx
     5ea:	45                   	inc    bp
     5eb:	64 69 74 34 35 64    	imul   si,WORD PTR fs:[si+0x34],0x6435
     5f1:	02 24                	add    ah,BYTE PTR [si]
     5f3:	00 08                	add    BYTE PTR [bx+si],cl
     5f5:	44                   	inc    sp
     5f6:	42                   	inc    dx
     5f7:	45                   	inc    bp
     5f8:	64 69 74 34 37 68    	imul   si,WORD PTR fs:[si+0x34],0x6837
     5fe:	02 10                	add    dl,BYTE PTR [bx+si]
     600:	00 07                	add    BYTE PTR [bx],al
     602:	50                   	push   ax
     603:	61                   	popa
     604:	6e                   	outs   dx,BYTE PTR ds:[si]
     605:	65 6c                	gs ins BYTE PTR es:[di],dx
     607:	31 31                	xor    WORD PTR [bx+di],si
     609:	6c                   	ins    BYTE PTR es:[di],dx
     60a:	02 14                	add    dl,BYTE PTR [si]
     60c:	00 07                	add    BYTE PTR [bx],al
     60e:	4c                   	dec    sp
     60f:	61                   	popa
     610:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     613:	34 33                	xor    al,0x33
     615:	70 02                	jo     0x619
     617:	24 00                	and    al,0x0
     619:	08 44 42             	or     BYTE PTR [si+0x42],al
     61c:	45                   	inc    bp
     61d:	64 69 74 34 36 74    	imul   si,WORD PTR fs:[si+0x34],0x7436
     623:	02 24                	add    ah,BYTE PTR [si]
     625:	00 08                	add    BYTE PTR [bx+si],cl
     627:	44                   	inc    sp
     628:	42                   	inc    dx
     629:	45                   	inc    bp
     62a:	64 69 74 34 38 78    	imul   si,WORD PTR fs:[si+0x34],0x7838
     630:	02 24                	add    ah,BYTE PTR [si]
     632:	00 08                	add    BYTE PTR [bx+si],cl
     634:	44                   	inc    sp
     635:	42                   	inc    dx
     636:	45                   	inc    bp
     637:	64 69 74 32 34 7c    	imul   si,WORD PTR fs:[si+0x32],0x7c34
     63d:	02 24                	add    ah,BYTE PTR [si]
     63f:	00 08                	add    BYTE PTR [bx+si],cl
     641:	44                   	inc    sp
     642:	42                   	inc    dx
     643:	45                   	inc    bp
     644:	64 69 74 32 39 80    	imul   si,WORD PTR fs:[si+0x32],0x8039
     64a:	02 04                	add    al,BYTE PTR [si]
     64c:	00 0a                	add    BYTE PTR [bp+si],cl
     64e:	47                   	inc    di
     64f:	72 6f                	jb     0x6c0
     651:	75 70                	jne    0x6c3
     653:	42                   	inc    dx
     654:	6f                   	outs   dx,WORD PTR ds:[si]
     655:	78 31                	js     0x688
     657:	34 84                	xor    al,0x84
     659:	02 04                	add    al,BYTE PTR [si]
     65b:	00 0a                	add    BYTE PTR [bp+si],cl
     65d:	47                   	inc    di
     65e:	72 6f                	jb     0x6cf
     660:	75 70                	jne    0x6d2
     662:	42                   	inc    dx
     663:	6f                   	outs   dx,WORD PTR ds:[si]
     664:	78 31                	js     0x697
     666:	33 88 02 28          	xor    cx,WORD PTR [bx+si+0x2802]
     66a:	00 05                	add    BYTE PTR [di],al
     66c:	4d                   	dec    bp
     66d:	65 6d                	gs ins WORD PTR es:[di],dx
     66f:	6f                   	outs   dx,WORD PTR ds:[si]
     670:	31 8c 02 2c          	xor    WORD PTR [si+0x2c02],cx
     674:	00 0a                	add    BYTE PTR [bp+si],cl
     676:	50                   	push   ax
     677:	6f                   	outs   dx,WORD PTR ds:[si]
     678:	70 75                	jo     0x6ef
     67a:	70 4d                	jo     0x6c9
     67c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     67e:	75 31                	jne    0x6b1
     680:	90                   	nop
     681:	02 30                	add    dh,BYTE PTR [bx+si]
     683:	00 06 50 72          	add    BYTE PTR ds:0x7250,al
     687:	69 6e 74 31 94       	imul   bp,WORD PTR [bp+0x74],0x9431
     68c:	02 30                	add    dh,BYTE PTR [bx+si]
     68e:	00 05                	add    BYTE PTR [di],al
     690:	43                   	inc    bx
     691:	6f                   	outs   dx,WORD PTR ds:[si]
     692:	70 79                	jo     0x70d
     694:	31 98 02 34          	xor    WORD PTR [bx+si+0x3402],bx
     698:	00 06 49 6d          	add    BYTE PTR ds:0x6d49,al
     69c:	61                   	popa
     69d:	67 65 31 9c 02 04 00 	xor    WORD PTR gs:[edx+eax*1+0x470a0004],bx
     6a4:	0a 47 
     6a6:	72 6f                	jb     0x717
     6a8:	75 70                	jne    0x71a
     6aa:	42                   	inc    dx
     6ab:	6f                   	outs   dx,WORD PTR ds:[si]
     6ac:	78 31                	js     0x6df
     6ae:	30 a0 02 04          	xor    BYTE PTR [bx+si+0x402],ah
     6b2:	00 09                	add    BYTE PTR [bx+di],cl
     6b4:	47                   	inc    di
     6b5:	72 6f                	jb     0x726
     6b7:	75 70                	jne    0x729
     6b9:	42                   	inc    dx
     6ba:	6f                   	outs   dx,WORD PTR ds:[si]
     6bb:	78 33                	js     0x6f0
     6bd:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     6be:	02 04                	add    al,BYTE PTR [si]
     6c0:	00 0a                	add    BYTE PTR [bp+si],cl
     6c2:	47                   	inc    di
     6c3:	72 6f                	jb     0x734
     6c5:	75 70                	jne    0x737
     6c7:	42                   	inc    dx
     6c8:	6f                   	outs   dx,WORD PTR ds:[si]
     6c9:	78 31                	js     0x6fc
     6cb:	35 a8 02             	xor    ax,0x2a8
     6ce:	38 00                	cmp    BYTE PTR [bx+si],al
     6d0:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     6d3:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     6d8:	74 31                	je     0x70b
     6da:	ac                   	lods   al,BYTE PTR ds:[si]
     6db:	02 38                	add    bh,BYTE PTR [bx+si]
     6dd:	00 09                	add    BYTE PTR [bx+di],cl
     6df:	53                   	push   bx
     6e0:	70 69                	jo     0x74b
     6e2:	6e                   	outs   dx,BYTE PTR ds:[si]
     6e3:	45                   	inc    bp
     6e4:	64 69 74 32 b0 02    	imul   si,WORD PTR fs:[si+0x32],0x2b0
     6ea:	10 00                	adc    BYTE PTR [bx+si],al
     6ec:	07                   	pop    es
     6ed:	50                   	push   ax
     6ee:	61                   	popa
     6ef:	6e                   	outs   dx,BYTE PTR ds:[si]
     6f0:	65 6c                	gs ins BYTE PTR es:[di],dx
     6f2:	31 32                	xor    WORD PTR [bp+si],si
     6f4:	b4 02                	mov    ah,0x2
     6f6:	04 00                	add    al,0x0
     6f8:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     6fb:	6f                   	outs   dx,WORD PTR ds:[si]
     6fc:	75 70                	jne    0x76e
     6fe:	42                   	inc    dx
     6ff:	6f                   	outs   dx,WORD PTR ds:[si]
     700:	78 31                	js     0x733
     702:	37                   	aaa
     703:	b8 02 10             	mov    ax,0x1002
     706:	00 07                	add    BYTE PTR [bx],al
     708:	50                   	push   ax
     709:	61                   	popa
     70a:	6e                   	outs   dx,BYTE PTR ds:[si]
     70b:	65 6c                	gs ins BYTE PTR es:[di],dx
     70d:	31 33                	xor    WORD PTR [bp+di],si
     70f:	bc 02 38             	mov    sp,0x3802
     712:	00 09                	add    BYTE PTR [bx+di],cl
     714:	53                   	push   bx
     715:	70 69                	jo     0x780
     717:	6e                   	outs   dx,BYTE PTR ds:[si]
     718:	45                   	inc    bp
     719:	64 69 74 33 c0 02    	imul   si,WORD PTR fs:[si+0x33],0x2c0
     71f:	10 00                	adc    BYTE PTR [bx+si],al
     721:	07                   	pop    es
     722:	50                   	push   ax
     723:	61                   	popa
     724:	6e                   	outs   dx,BYTE PTR ds:[si]
     725:	65 6c                	gs ins BYTE PTR es:[di],dx
     727:	31 34                	xor    WORD PTR [si],si
     729:	c4 02                	les    ax,DWORD PTR [bp+si]
     72b:	38 00                	cmp    BYTE PTR [bx+si],al
     72d:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     730:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     735:	74 34                	je     0x76b
     737:	c8 02 04 00          	enter  0x402,0x0
     73b:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     73e:	6f                   	outs   dx,WORD PTR ds:[si]
     73f:	75 70                	jne    0x7b1
     741:	42                   	inc    dx
     742:	6f                   	outs   dx,WORD PTR ds:[si]
     743:	78 31                	js     0x776
     745:	38 cc                	cmp    ah,cl
     747:	02 10                	add    dl,BYTE PTR [bx+si]
     749:	00 07                	add    BYTE PTR [bx],al
     74b:	50                   	push   ax
     74c:	61                   	popa
     74d:	6e                   	outs   dx,BYTE PTR ds:[si]
     74e:	65 6c                	gs ins BYTE PTR es:[di],dx
     750:	31 35                	xor    WORD PTR [di],si
     752:	d0 02                	rol    BYTE PTR [bp+si],1
     754:	38 00                	cmp    BYTE PTR [bx+si],al
     756:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     759:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     75e:	74 35                	je     0x795
     760:	d4 02                	aam    0x2
     762:	10 00                	adc    BYTE PTR [bx+si],al
     764:	07                   	pop    es
     765:	50                   	push   ax
     766:	61                   	popa
     767:	6e                   	outs   dx,BYTE PTR ds:[si]
     768:	65 6c                	gs ins BYTE PTR es:[di],dx
     76a:	31 36 d8 02          	xor    WORD PTR ds:0x2d8,si
     76e:	38 00                	cmp    BYTE PTR [bx+si],al
     770:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     773:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     778:	74 36                	je     0x7b0
     77a:	dc 02                	fadd   QWORD PTR [bp+si]
     77c:	10 00                	adc    BYTE PTR [bx+si],al
     77e:	07                   	pop    es
     77f:	50                   	push   ax
     780:	61                   	popa
     781:	6e                   	outs   dx,BYTE PTR ds:[si]
     782:	65 6c                	gs ins BYTE PTR es:[di],dx
     784:	31 37                	xor    WORD PTR [bx],si
     786:	e0 02                	loopne 0x78a
     788:	38 00                	cmp    BYTE PTR [bx+si],al
     78a:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     78d:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     792:	74 37                	je     0x7cb
     794:	e4 02                	in     al,0x2
     796:	10 00                	adc    BYTE PTR [bx+si],al
     798:	07                   	pop    es
     799:	50                   	push   ax
     79a:	61                   	popa
     79b:	6e                   	outs   dx,BYTE PTR ds:[si]
     79c:	65 6c                	gs ins BYTE PTR es:[di],dx
     79e:	31 38                	xor    WORD PTR [bx+si],di
     7a0:	e8 02 38             	call   0x3fa5
     7a3:	00 09                	add    BYTE PTR [bx+di],cl
     7a5:	53                   	push   bx
     7a6:	70 69                	jo     0x811
     7a8:	6e                   	outs   dx,BYTE PTR ds:[si]
     7a9:	45                   	inc    bp
     7aa:	64 69 74 38 ec 02    	imul   si,WORD PTR fs:[si+0x38],0x2ec
     7b0:	10 00                	adc    BYTE PTR [bx+si],al
     7b2:	07                   	pop    es
     7b3:	50                   	push   ax
     7b4:	61                   	popa
     7b5:	6e                   	outs   dx,BYTE PTR ds:[si]
     7b6:	65 6c                	gs ins BYTE PTR es:[di],dx
     7b8:	31 39                	xor    WORD PTR [bx+di],di
     7ba:	f0 02 38             	lock add bh,BYTE PTR [bx+si]
     7bd:	00 09                	add    BYTE PTR [bx+di],cl
     7bf:	53                   	push   bx
     7c0:	70 69                	jo     0x82b
     7c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     7c3:	45                   	inc    bp
     7c4:	64 69 74 39 f4 02    	imul   si,WORD PTR fs:[si+0x39],0x2f4
     7ca:	10 00                	adc    BYTE PTR [bx+si],al
     7cc:	07                   	pop    es
     7cd:	50                   	push   ax
     7ce:	61                   	popa
     7cf:	6e                   	outs   dx,BYTE PTR ds:[si]
     7d0:	65 6c                	gs ins BYTE PTR es:[di],dx
     7d2:	32 30                	xor    dh,BYTE PTR [bx+si]
     7d4:	f8                   	clc
     7d5:	02 38                	add    bh,BYTE PTR [bx+si]
     7d7:	00 0a                	add    BYTE PTR [bp+si],cl
     7d9:	53                   	push   bx
     7da:	70 69                	jo     0x845
     7dc:	6e                   	outs   dx,BYTE PTR ds:[si]
     7dd:	45                   	inc    bp
     7de:	64 69 74 31 30 fc    	imul   si,WORD PTR fs:[si+0x31],0xfc30
     7e4:	02 10                	add    dl,BYTE PTR [bx+si]
     7e6:	00 07                	add    BYTE PTR [bx],al
     7e8:	50                   	push   ax
     7e9:	61                   	popa
     7ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     7eb:	65 6c                	gs ins BYTE PTR es:[di],dx
     7ed:	32 31                	xor    dh,BYTE PTR [bx+di]
     7ef:	00 03                	add    BYTE PTR [bp+di],al
     7f1:	38 00                	cmp    BYTE PTR [bx+si],al
     7f3:	0a 53 70             	or     dl,BYTE PTR [bp+di+0x70]
     7f6:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     7fb:	74 31                	je     0x82e
     7fd:	31 04                	xor    WORD PTR [si],ax
     7ff:	03 10                	add    dx,WORD PTR [bx+si]
     801:	00 07                	add    BYTE PTR [bx],al
     803:	50                   	push   ax
     804:	61                   	popa
     805:	6e                   	outs   dx,BYTE PTR ds:[si]
     806:	65 6c                	gs ins BYTE PTR es:[di],dx
     808:	32 32                	xor    dh,BYTE PTR [bp+si]
     80a:	08 03                	or     BYTE PTR [bp+di],al
     80c:	38 00                	cmp    BYTE PTR [bx+si],al
     80e:	0a 53 70             	or     dl,BYTE PTR [bp+di+0x70]
     811:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     816:	74 31                	je     0x849
     818:	32 0c                	xor    cl,BYTE PTR [si]
     81a:	03 10                	add    dx,WORD PTR [bx+si]
     81c:	00 07                	add    BYTE PTR [bx],al
     81e:	50                   	push   ax
     81f:	61                   	popa
     820:	6e                   	outs   dx,BYTE PTR ds:[si]
     821:	65 6c                	gs ins BYTE PTR es:[di],dx
     823:	32 33                	xor    dh,BYTE PTR [bp+di]
     825:	10 03                	adc    BYTE PTR [bp+di],al
     827:	3c 00                	cmp    al,0x0
     829:	0c 52                	or     al,0x52
     82b:	61                   	popa
     82c:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
     832:	74 6f                	je     0x8a3
     834:	6e                   	outs   dx,BYTE PTR ds:[si]
     835:	31 14                	xor    WORD PTR [si],dx
     837:	03 3c                	add    di,WORD PTR [si]
     839:	00 0c                	add    BYTE PTR [si],cl
     83b:	52                   	push   dx
     83c:	61                   	popa
     83d:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
     843:	74 6f                	je     0x8b4
     845:	6e                   	outs   dx,BYTE PTR ds:[si]
     846:	32 18                	xor    bl,BYTE PTR [bx+si]
     848:	03 3c                	add    di,WORD PTR [si]
     84a:	00 0c                	add    BYTE PTR [si],cl
     84c:	52                   	push   dx
     84d:	61                   	popa
     84e:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
     854:	74 6f                	je     0x8c5
     856:	6e                   	outs   dx,BYTE PTR ds:[si]
     857:	33 1c                	xor    bx,WORD PTR [si]
     859:	03 14                	add    dx,WORD PTR [si]
     85b:	00 07                	add    BYTE PTR [bx],al
     85d:	4c                   	dec    sp
     85e:	61                   	popa
     85f:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     862:	35 31 20             	xor    ax,0x2031
     865:	03 10                	add    dx,WORD PTR [bx+si]
     867:	00 07                	add    BYTE PTR [bx],al
     869:	50                   	push   ax
     86a:	61                   	popa
     86b:	6e                   	outs   dx,BYTE PTR ds:[si]
     86c:	65 6c                	gs ins BYTE PTR es:[di],dx
     86e:	32 35                	xor    dh,BYTE PTR [di]
     870:	24 03                	and    al,0x3
     872:	24 00                	and    al,0x0
     874:	07                   	pop    es
     875:	44                   	inc    sp
     876:	42                   	inc    dx
     877:	45                   	inc    bp
     878:	64 69 74 31 28 03    	imul   si,WORD PTR fs:[si+0x31],0x328
     87e:	10 00                	adc    BYTE PTR [bx+si],al
     880:	07                   	pop    es
     881:	50                   	push   ax
     882:	61                   	popa
     883:	6e                   	outs   dx,BYTE PTR ds:[si]
     884:	65 6c                	gs ins BYTE PTR es:[di],dx
     886:	32 36 2c 03          	xor    dh,BYTE PTR ds:0x32c
     88a:	24 00                	and    al,0x0
     88c:	08 44 42             	or     BYTE PTR [si+0x42],al
     88f:	45                   	inc    bp
     890:	64 69 74 33 31 30    	imul   si,WORD PTR fs:[si+0x33],0x3031
     896:	03 10                	add    dx,WORD PTR [bx+si]
     898:	00 07                	add    BYTE PTR [bx],al
     89a:	50                   	push   ax
     89b:	61                   	popa
     89c:	6e                   	outs   dx,BYTE PTR ds:[si]
     89d:	65 6c                	gs ins BYTE PTR es:[di],dx
     89f:	32 37                	xor    dh,BYTE PTR [bx]
     8a1:	34 03                	xor    al,0x3
     8a3:	24 00                	and    al,0x0
     8a5:	07                   	pop    es
     8a6:	44                   	inc    sp
     8a7:	42                   	inc    dx
     8a8:	45                   	inc    bp
     8a9:	64 69 74 33 38 03    	imul   si,WORD PTR fs:[si+0x33],0x338
     8af:	10 00                	adc    BYTE PTR [bx+si],al
     8b1:	07                   	pop    es
     8b2:	50                   	push   ax
     8b3:	61                   	popa
     8b4:	6e                   	outs   dx,BYTE PTR ds:[si]
     8b5:	65 6c                	gs ins BYTE PTR es:[di],dx
     8b7:	32 38                	xor    bh,BYTE PTR [bx+si]
     8b9:	3c 03                	cmp    al,0x3
     8bb:	24 00                	and    al,0x0
     8bd:	07                   	pop    es
     8be:	44                   	inc    sp
     8bf:	42                   	inc    dx
     8c0:	45                   	inc    bp
     8c1:	64 69 74 32 40 03    	imul   si,WORD PTR fs:[si+0x32],0x340
     8c7:	10 00                	adc    BYTE PTR [bx+si],al
     8c9:	07                   	pop    es
     8ca:	50                   	push   ax
     8cb:	61                   	popa
     8cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     8cd:	65 6c                	gs ins BYTE PTR es:[di],dx
     8cf:	32 39                	xor    bh,BYTE PTR [bx+di]
     8d1:	44                   	inc    sp
     8d2:	03 24                	add    sp,WORD PTR [si]
     8d4:	00 08                	add    BYTE PTR [bx+si],cl
     8d6:	44                   	inc    sp
     8d7:	42                   	inc    dx
     8d8:	45                   	inc    bp
     8d9:	64 69 74 31 32 48    	imul   si,WORD PTR fs:[si+0x31],0x4832
     8df:	03 10                	add    dx,WORD PTR [bx+si]
     8e1:	00 07                	add    BYTE PTR [bx],al
     8e3:	50                   	push   ax
     8e4:	61                   	popa
     8e5:	6e                   	outs   dx,BYTE PTR ds:[si]
     8e6:	65 6c                	gs ins BYTE PTR es:[di],dx
     8e8:	33 30                	xor    si,WORD PTR [bx+si]
     8ea:	4c                   	dec    sp
     8eb:	03 24                	add    sp,WORD PTR [si]
     8ed:	00 07                	add    BYTE PTR [bx],al
     8ef:	44                   	inc    sp
     8f0:	42                   	inc    dx
     8f1:	45                   	inc    bp
     8f2:	64 69 74 34 50 03    	imul   si,WORD PTR fs:[si+0x34],0x350
     8f8:	10 00                	adc    BYTE PTR [bx+si],al
     8fa:	07                   	pop    es
     8fb:	50                   	push   ax
     8fc:	61                   	popa
     8fd:	6e                   	outs   dx,BYTE PTR ds:[si]
     8fe:	65 6c                	gs ins BYTE PTR es:[di],dx
     900:	33 31                	xor    si,WORD PTR [bx+di]
     902:	54                   	push   sp
     903:	03 24                	add    sp,WORD PTR [si]
     905:	00 08                	add    BYTE PTR [bx+si],cl
     907:	44                   	inc    sp
     908:	42                   	inc    dx
     909:	45                   	inc    bp
     90a:	64 69 74 33 32 58    	imul   si,WORD PTR fs:[si+0x33],0x5832
     910:	03 10                	add    dx,WORD PTR [bx+si]
     912:	00 07                	add    BYTE PTR [bx],al
     914:	50                   	push   ax
     915:	61                   	popa
     916:	6e                   	outs   dx,BYTE PTR ds:[si]
     917:	65 6c                	gs ins BYTE PTR es:[di],dx
     919:	33 32                	xor    si,WORD PTR [bp+si]
     91b:	5c                   	pop    sp
     91c:	03 24                	add    sp,WORD PTR [si]
     91e:	00 08                	add    BYTE PTR [bx+si],cl
     920:	44                   	inc    sp
     921:	42                   	inc    dx
     922:	45                   	inc    bp
     923:	64 69 74 31 36 60    	imul   si,WORD PTR fs:[si+0x31],0x6036
     929:	03 10                	add    dx,WORD PTR [bx+si]
     92b:	00 07                	add    BYTE PTR [bx],al
     92d:	50                   	push   ax
     92e:	61                   	popa
     92f:	6e                   	outs   dx,BYTE PTR ds:[si]
     930:	65 6c                	gs ins BYTE PTR es:[di],dx
     932:	33 33                	xor    si,WORD PTR [bp+di]
     934:	64 03 24             	add    sp,WORD PTR fs:[si]
     937:	00 08                	add    BYTE PTR [bx+si],cl
     939:	44                   	inc    sp
     93a:	42                   	inc    dx
     93b:	45                   	inc    bp
     93c:	64 69 74 33 33 68    	imul   si,WORD PTR fs:[si+0x33],0x6833
     942:	03 10                	add    dx,WORD PTR [bx+si]
     944:	00 07                	add    BYTE PTR [bx],al
     946:	50                   	push   ax
     947:	61                   	popa
     948:	6e                   	outs   dx,BYTE PTR ds:[si]
     949:	65 6c                	gs ins BYTE PTR es:[di],dx
     94b:	33 34                	xor    si,WORD PTR [si]
     94d:	6c                   	ins    BYTE PTR es:[di],dx
     94e:	03 10                	add    dx,WORD PTR [bx+si]
     950:	00 07                	add    BYTE PTR [bx],al
     952:	50                   	push   ax
     953:	61                   	popa
     954:	6e                   	outs   dx,BYTE PTR ds:[si]
     955:	65 6c                	gs ins BYTE PTR es:[di],dx
     957:	33 35                	xor    si,WORD PTR [di]
     959:	70 03                	jo     0x95e
     95b:	10 00                	adc    BYTE PTR [bx+si],al
     95d:	07                   	pop    es
     95e:	50                   	push   ax
     95f:	61                   	popa
     960:	6e                   	outs   dx,BYTE PTR ds:[si]
     961:	65 6c                	gs ins BYTE PTR es:[di],dx
     963:	33 36 74 03          	xor    si,WORD PTR ds:0x374
     967:	10 00                	adc    BYTE PTR [bx+si],al
     969:	07                   	pop    es
     96a:	50                   	push   ax
     96b:	61                   	popa
     96c:	6e                   	outs   dx,BYTE PTR ds:[si]
     96d:	65 6c                	gs ins BYTE PTR es:[di],dx
     96f:	33 37                	xor    si,WORD PTR [bx]
     971:	78 03                	js     0x976
     973:	24 00                	and    al,0x0
     975:	08 44 42             	or     BYTE PTR [si+0x42],al
     978:	45                   	inc    bp
     979:	64 69 74 31 35 7c    	imul   si,WORD PTR fs:[si+0x31],0x7c35
     97f:	03 10                	add    dx,WORD PTR [bx+si]
     981:	00 07                	add    BYTE PTR [bx],al
     983:	50                   	push   ax
     984:	61                   	popa
     985:	6e                   	outs   dx,BYTE PTR ds:[si]
     986:	65 6c                	gs ins BYTE PTR es:[di],dx
     988:	33 38                	xor    di,WORD PTR [bx+si]
     98a:	80 03 24             	add    BYTE PTR [bp+di],0x24
     98d:	00 08                	add    BYTE PTR [bx+si],cl
     98f:	44                   	inc    sp
     990:	42                   	inc    dx
     991:	45                   	inc    bp
     992:	64 69 74 34 39 84    	imul   si,WORD PTR fs:[si+0x34],0x8439
     998:	03 10                	add    dx,WORD PTR [bx+si]
     99a:	00 07                	add    BYTE PTR [bx],al
     99c:	50                   	push   ax
     99d:	61                   	popa
     99e:	6e                   	outs   dx,BYTE PTR ds:[si]
     99f:	65 6c                	gs ins BYTE PTR es:[di],dx
     9a1:	33 39                	xor    di,WORD PTR [bx+di]
     9a3:	88 03                	mov    BYTE PTR [bp+di],al
     9a5:	24 00                	and    al,0x0
     9a7:	08 44 42             	or     BYTE PTR [si+0x42],al
     9aa:	45                   	inc    bp
     9ab:	64 69 74 31 34 8c    	imul   si,WORD PTR fs:[si+0x31],0x8c34
     9b1:	03 10                	add    dx,WORD PTR [bx+si]
     9b3:	00 07                	add    BYTE PTR [bx],al
     9b5:	50                   	push   ax
     9b6:	61                   	popa
     9b7:	6e                   	outs   dx,BYTE PTR ds:[si]
     9b8:	65 6c                	gs ins BYTE PTR es:[di],dx
     9ba:	34 30                	xor    al,0x30
     9bc:	90                   	nop
     9bd:	03 10                	add    dx,WORD PTR [bx+si]
     9bf:	00 07                	add    BYTE PTR [bx],al
     9c1:	50                   	push   ax
     9c2:	61                   	popa
     9c3:	6e                   	outs   dx,BYTE PTR ds:[si]
     9c4:	65 6c                	gs ins BYTE PTR es:[di],dx
     9c6:	34 31                	xor    al,0x31
     9c8:	94                   	xchg   sp,ax
     9c9:	03 10                	add    dx,WORD PTR [bx+si]
     9cb:	00 07                	add    BYTE PTR [bx],al
     9cd:	50                   	push   ax
     9ce:	61                   	popa
     9cf:	6e                   	outs   dx,BYTE PTR ds:[si]
     9d0:	65 6c                	gs ins BYTE PTR es:[di],dx
     9d2:	34 32                	xor    al,0x32
     9d4:	98                   	cbw
     9d5:	03 10                	add    dx,WORD PTR [bx+si]
     9d7:	00 07                	add    BYTE PTR [bx],al
     9d9:	50                   	push   ax
     9da:	61                   	popa
     9db:	6e                   	outs   dx,BYTE PTR ds:[si]
     9dc:	65 6c                	gs ins BYTE PTR es:[di],dx
     9de:	34 33                	xor    al,0x33
     9e0:	9c                   	pushf
     9e1:	03 24                	add    sp,WORD PTR [si]
     9e3:	00 08                	add    BYTE PTR [bx+si],cl
     9e5:	44                   	inc    sp
     9e6:	42                   	inc    dx
     9e7:	45                   	inc    bp
     9e8:	64 69 74 31 31 a0    	imul   si,WORD PTR fs:[si+0x31],0xa031
     9ee:	03 24                	add    sp,WORD PTR [si]
     9f0:	00 08                	add    BYTE PTR [bx+si],cl
     9f2:	44                   	inc    sp
     9f3:	42                   	inc    dx
     9f4:	45                   	inc    bp
     9f5:	64 69 74 33 34 a4    	imul   si,WORD PTR fs:[si+0x33],0xa434
     9fb:	03 24                	add    sp,WORD PTR [si]
     9fd:	00 08                	add    BYTE PTR [bx+si],cl
     9ff:	44                   	inc    sp
     a00:	42                   	inc    dx
     a01:	45                   	inc    bp
     a02:	64 69 74 33 35 a8    	imul   si,WORD PTR fs:[si+0x33],0xa835
     a08:	03 10                	add    dx,WORD PTR [bx+si]
     a0a:	00 07                	add    BYTE PTR [bx],al
     a0c:	50                   	push   ax
     a0d:	61                   	popa
     a0e:	6e                   	outs   dx,BYTE PTR ds:[si]
     a0f:	65 6c                	gs ins BYTE PTR es:[di],dx
     a11:	34 34                	xor    al,0x34
     a13:	ac                   	lods   al,BYTE PTR ds:[si]
     a14:	03 24                	add    sp,WORD PTR [si]
     a16:	00 08                	add    BYTE PTR [bx+si],cl
     a18:	44                   	inc    sp
     a19:	42                   	inc    dx
     a1a:	45                   	inc    bp
     a1b:	64 69 74 33 36 b0    	imul   si,WORD PTR fs:[si+0x33],0xb036
     a21:	03 10                	add    dx,WORD PTR [bx+si]
     a23:	00 07                	add    BYTE PTR [bx],al
     a25:	50                   	push   ax
     a26:	61                   	popa
     a27:	6e                   	outs   dx,BYTE PTR ds:[si]
     a28:	65 6c                	gs ins BYTE PTR es:[di],dx
     a2a:	34 35                	xor    al,0x35
     a2c:	b4 03                	mov    ah,0x3
     a2e:	24 00                	and    al,0x0
     a30:	08 44 42             	or     BYTE PTR [si+0x42],al
     a33:	45                   	inc    bp
     a34:	64 69 74 31 33 b8    	imul   si,WORD PTR fs:[si+0x31],0xb833
     a3a:	03 10                	add    dx,WORD PTR [bx+si]
     a3c:	00 07                	add    BYTE PTR [bx],al
     a3e:	50                   	push   ax
     a3f:	61                   	popa
     a40:	6e                   	outs   dx,BYTE PTR ds:[si]
     a41:	65 6c                	gs ins BYTE PTR es:[di],dx
     a43:	34 36                	xor    al,0x36
     a45:	bc 03 24             	mov    sp,0x2403
     a48:	00 08                	add    BYTE PTR [bx+si],cl
     a4a:	44                   	inc    sp
     a4b:	42                   	inc    dx
     a4c:	45                   	inc    bp
     a4d:	64 69 74 33 37 c0    	imul   si,WORD PTR fs:[si+0x33],0xc037
     a53:	03 10                	add    dx,WORD PTR [bx+si]
     a55:	00 07                	add    BYTE PTR [bx],al
     a57:	50                   	push   ax
     a58:	61                   	popa
     a59:	6e                   	outs   dx,BYTE PTR ds:[si]
     a5a:	65 6c                	gs ins BYTE PTR es:[di],dx
     a5c:	34 37                	xor    al,0x37
     a5e:	c4 03                	les    ax,DWORD PTR [bp+di]
     a60:	24 00                	and    al,0x0
     a62:	08 44 42             	or     BYTE PTR [si+0x42],al
     a65:	45                   	inc    bp
     a66:	64 69 74 34 30 c8    	imul   si,WORD PTR fs:[si+0x34],0xc830
     a6c:	03 10                	add    dx,WORD PTR [bx+si]
     a6e:	00 07                	add    BYTE PTR [bx],al
     a70:	50                   	push   ax
     a71:	61                   	popa
     a72:	6e                   	outs   dx,BYTE PTR ds:[si]
     a73:	65 6c                	gs ins BYTE PTR es:[di],dx
     a75:	34 38                	xor    al,0x38
     a77:	cc                   	int3
     a78:	03 24                	add    sp,WORD PTR [si]
     a7a:	00 08                	add    BYTE PTR [bx+si],cl
     a7c:	44                   	inc    sp
     a7d:	42                   	inc    dx
     a7e:	45                   	inc    bp
     a7f:	64 69 74 33 39 d0    	imul   si,WORD PTR fs:[si+0x33],0xd039
     a85:	03 10                	add    dx,WORD PTR [bx+si]
     a87:	00 07                	add    BYTE PTR [bx],al
     a89:	50                   	push   ax
     a8a:	61                   	popa
     a8b:	6e                   	outs   dx,BYTE PTR ds:[si]
     a8c:	65 6c                	gs ins BYTE PTR es:[di],dx
     a8e:	34 39                	xor    al,0x39
     a90:	d4 03                	aam    0x3
     a92:	24 00                	and    al,0x0
     a94:	08 44 42             	or     BYTE PTR [si+0x42],al
     a97:	45                   	inc    bp
     a98:	64 69 74 31 38 d8    	imul   si,WORD PTR fs:[si+0x31],0xd838
     a9e:	03 10                	add    dx,WORD PTR [bx+si]
     aa0:	00 07                	add    BYTE PTR [bx],al
     aa2:	50                   	push   ax
     aa3:	61                   	popa
     aa4:	6e                   	outs   dx,BYTE PTR ds:[si]
     aa5:	65 6c                	gs ins BYTE PTR es:[di],dx
     aa7:	35 30 dc             	xor    ax,0xdc30
     aaa:	03 24                	add    sp,WORD PTR [si]
     aac:	00 08                	add    BYTE PTR [bx+si],cl
     aae:	44                   	inc    sp
     aaf:	42                   	inc    dx
     ab0:	45                   	inc    bp
     ab1:	64 69 74 32 30 e0    	imul   si,WORD PTR fs:[si+0x32],0xe030
     ab7:	03 10                	add    dx,WORD PTR [bx+si]
     ab9:	00 07                	add    BYTE PTR [bx],al
     abb:	50                   	push   ax
     abc:	61                   	popa
     abd:	6e                   	outs   dx,BYTE PTR ds:[si]
     abe:	65 6c                	gs ins BYTE PTR es:[di],dx
     ac0:	35 31 e4             	xor    ax,0xe431
     ac3:	03 24                	add    sp,WORD PTR [si]
     ac5:	00 08                	add    BYTE PTR [bx+si],cl
     ac7:	44                   	inc    sp
     ac8:	42                   	inc    dx
     ac9:	45                   	inc    bp
     aca:	64 69 74 33 38 e8    	imul   si,WORD PTR fs:[si+0x33],0xe838
     ad0:	03 10                	add    dx,WORD PTR [bx+si]
     ad2:	00 07                	add    BYTE PTR [bx],al
     ad4:	50                   	push   ax
     ad5:	61                   	popa
     ad6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ad7:	65 6c                	gs ins BYTE PTR es:[di],dx
     ad9:	35 32 ec             	xor    ax,0xec32
     adc:	03 24                	add    sp,WORD PTR [si]
     ade:	00 08                	add    BYTE PTR [bx+si],cl
     ae0:	44                   	inc    sp
     ae1:	42                   	inc    dx
     ae2:	45                   	inc    bp
     ae3:	64 69 74 32 35 f0    	imul   si,WORD PTR fs:[si+0x32],0xf035
     ae9:	03 10                	add    dx,WORD PTR [bx+si]
     aeb:	00 07                	add    BYTE PTR [bx],al
     aed:	50                   	push   ax
     aee:	61                   	popa
     aef:	6e                   	outs   dx,BYTE PTR ds:[si]
     af0:	65 6c                	gs ins BYTE PTR es:[di],dx
     af2:	35 33 f4             	xor    ax,0xf433
     af5:	03 24                	add    sp,WORD PTR [si]
     af7:	00 08                	add    BYTE PTR [bx+si],cl
     af9:	44                   	inc    sp
     afa:	42                   	inc    dx
     afb:	45                   	inc    bp
     afc:	64 69 74 33 30 f8    	imul   si,WORD PTR fs:[si+0x33],0xf830
     b02:	03 10                	add    dx,WORD PTR [bx+si]
     b04:	00 07                	add    BYTE PTR [bx],al
     b06:	50                   	push   ax
     b07:	61                   	popa
     b08:	6e                   	outs   dx,BYTE PTR ds:[si]
     b09:	65 6c                	gs ins BYTE PTR es:[di],dx
     b0b:	35 34 fc             	xor    ax,0xfc34
     b0e:	03 24                	add    sp,WORD PTR [si]
     b10:	00 08                	add    BYTE PTR [bx+si],cl
     b12:	44                   	inc    sp
     b13:	42                   	inc    dx
     b14:	45                   	inc    bp
     b15:	64 69 74 34 34 00    	imul   si,WORD PTR fs:[si+0x34],0x34
     b1b:	04 10                	add    al,0x10
     b1d:	00 07                	add    BYTE PTR [bx],al
     b1f:	50                   	push   ax
     b20:	61                   	popa
     b21:	6e                   	outs   dx,BYTE PTR ds:[si]
     b22:	65 6c                	gs ins BYTE PTR es:[di],dx
     b24:	35 35 04             	xor    ax,0x435
     b27:	04 10                	add    al,0x10
     b29:	00 07                	add    BYTE PTR [bx],al
     b2b:	50                   	push   ax
     b2c:	61                   	popa
     b2d:	6e                   	outs   dx,BYTE PTR ds:[si]
     b2e:	65 6c                	gs ins BYTE PTR es:[di],dx
     b30:	35 36 08             	xor    ax,0x836
     b33:	04 10                	add    al,0x10
     b35:	00 07                	add    BYTE PTR [bx],al
     b37:	50                   	push   ax
     b38:	61                   	popa
     b39:	6e                   	outs   dx,BYTE PTR ds:[si]
     b3a:	65 6c                	gs ins BYTE PTR es:[di],dx
     b3c:	35 37 0c             	xor    ax,0xc37
     b3f:	04 10                	add    al,0x10
     b41:	00 07                	add    BYTE PTR [bx],al
     b43:	50                   	push   ax
     b44:	61                   	popa
     b45:	6e                   	outs   dx,BYTE PTR ds:[si]
     b46:	65 6c                	gs ins BYTE PTR es:[di],dx
     b48:	35 38 10             	xor    ax,0x1038
     b4b:	04 10                	add    al,0x10
     b4d:	00 07                	add    BYTE PTR [bx],al
     b4f:	50                   	push   ax
     b50:	61                   	popa
     b51:	6e                   	outs   dx,BYTE PTR ds:[si]
     b52:	65 6c                	gs ins BYTE PTR es:[di],dx
     b54:	35 39 14             	xor    ax,0x1439
     b57:	04 10                	add    al,0x10
     b59:	00 07                	add    BYTE PTR [bx],al
     b5b:	50                   	push   ax
     b5c:	61                   	popa
     b5d:	6e                   	outs   dx,BYTE PTR ds:[si]
     b5e:	65 6c                	gs ins BYTE PTR es:[di],dx
     b60:	36 30 18             	xor    BYTE PTR ss:[bx+si],bl
     b63:	04 40                	add    al,0x40
     b65:	00 0b                	add    BYTE PTR [bp+di],cl
     b67:	44                   	inc    sp
     b68:	42                   	inc    dx
     b69:	43                   	inc    bx
     b6a:	68 65 63             	push   0x6365
     b6d:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     b71:	31 1c                	xor    WORD PTR [si],bx
     b73:	04 10                	add    al,0x10
     b75:	00 07                	add    BYTE PTR [bx],al
     b77:	50                   	push   ax
     b78:	61                   	popa
     b79:	6e                   	outs   dx,BYTE PTR ds:[si]
     b7a:	65 6c                	gs ins BYTE PTR es:[di],dx
     b7c:	36 31 20             	xor    WORD PTR ss:[bx+si],sp
     b7f:	04 24                	add    al,0x24
     b81:	00 08                	add    BYTE PTR [bx+si],cl
     b83:	44                   	inc    sp
     b84:	42                   	inc    dx
     b85:	45                   	inc    bp
     b86:	64 69 74 34 33 24    	imul   si,WORD PTR fs:[si+0x34],0x2433
     b8c:	04 10                	add    al,0x10
     b8e:	00 07                	add    BYTE PTR [bx],al
     b90:	50                   	push   ax
     b91:	61                   	popa
     b92:	6e                   	outs   dx,BYTE PTR ds:[si]
     b93:	65 6c                	gs ins BYTE PTR es:[di],dx
     b95:	36 32 28             	xor    ch,BYTE PTR ss:[bx+si]
     b98:	04 10                	add    al,0x10
     b9a:	00 07                	add    BYTE PTR [bx],al
     b9c:	50                   	push   ax
     b9d:	61                   	popa
     b9e:	6e                   	outs   dx,BYTE PTR ds:[si]
     b9f:	65 6c                	gs ins BYTE PTR es:[di],dx
     ba1:	36 33 2c             	xor    bp,WORD PTR ss:[si]
     ba4:	04 10                	add    al,0x10
     ba6:	00 07                	add    BYTE PTR [bx],al
     ba8:	50                   	push   ax
     ba9:	61                   	popa
     baa:	6e                   	outs   dx,BYTE PTR ds:[si]
     bab:	65 6c                	gs ins BYTE PTR es:[di],dx
     bad:	36 34 30             	ss xor al,0x30
     bb0:	04 10                	add    al,0x10
     bb2:	00 07                	add    BYTE PTR [bx],al
     bb4:	50                   	push   ax
     bb5:	61                   	popa
     bb6:	6e                   	outs   dx,BYTE PTR ds:[si]
     bb7:	65 6c                	gs ins BYTE PTR es:[di],dx
     bb9:	36 35 34 04          	ss xor ax,0x434
     bbd:	10 00                	adc    BYTE PTR [bx+si],al
     bbf:	07                   	pop    es
     bc0:	50                   	push   ax
     bc1:	61                   	popa
     bc2:	6e                   	outs   dx,BYTE PTR ds:[si]
     bc3:	65 6c                	gs ins BYTE PTR es:[di],dx
     bc5:	32 34                	xor    dh,BYTE PTR [si]
     bc7:	38 04                	cmp    BYTE PTR [si],al
     bc9:	44                   	inc    sp
     bca:	00 05                	add    BYTE PTR [di],al
     bcc:	45                   	inc    bp
     bcd:	64 69 74 31 3c 04    	imul   si,WORD PTR fs:[si+0x31],0x43c
     bd3:	10 00                	adc    BYTE PTR [bx+si],al
     bd5:	07                   	pop    es
     bd6:	50                   	push   ax
     bd7:	61                   	popa
     bd8:	6e                   	outs   dx,BYTE PTR ds:[si]
     bd9:	65 6c                	gs ins BYTE PTR es:[di],dx
     bdb:	36 36 40             	ss ss inc ax
     bde:	04 10                	add    al,0x10
     be0:	00 07                	add    BYTE PTR [bx],al
     be2:	50                   	push   ax
     be3:	61                   	popa
     be4:	6e                   	outs   dx,BYTE PTR ds:[si]
     be5:	65 6c                	gs ins BYTE PTR es:[di],dx
     be7:	36 37                	ss aaa
     be9:	44                   	inc    sp
     bea:	04 10                	add    al,0x10
     bec:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     bf0:	6e                   	outs   dx,BYTE PTR ds:[si]
     bf1:	65 6c                	gs ins BYTE PTR es:[di],dx
     bf3:	33 48 04             	xor    cx,WORD PTR [bx+si+0x4]
     bf6:	18 00                	sbb    BYTE PTR [bx+si],al
     bf8:	0e                   	push   cs
     bf9:	45                   	inc    bp
     bfa:	6e                   	outs   dx,BYTE PTR ds:[si]
     bfb:	72 65                	jb     0xc62
     bfd:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
     c03:	72 42                	jb     0xc47
     c05:	74 6e                	je     0xc75
     c07:	4c                   	dec    sp
     c08:	04 18                	add    al,0x18
     c0a:	00 09                	add    BYTE PTR [bx+di],cl
     c0c:	44                   	inc    sp
     c0d:	65 66 61             	gs popad
     c10:	75 74                	jne    0xc86
     c12:	42                   	inc    dx
     c13:	74 6e                	je     0xc83
     c15:	50                   	push   ax
     c16:	04 18                	add    al,0x18
     c18:	00 0a                	add    BYTE PTR [bp+si],cl
     c1a:	49                   	dec    cx
     c1b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c1c:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     c21:	42                   	inc    dx
     c22:	74 6e                	je     0xc92
     c24:	54                   	push   sp
     c25:	04 18                	add    al,0x18
     c27:	00 0a                	add    BYTE PTR [bp+si],cl
     c29:	42                   	inc    dx
     c2a:	61                   	popa
     c2b:	73 63                	jae    0xc90
     c2d:	75 6c                	jne    0xc9b
     c2f:	65 42                	gs inc dx
     c31:	74 6e                	je     0xca1
     c33:	58                   	pop    ax
     c34:	04 10                	add    al,0x10
     c36:	00 07                	add    BYTE PTR [bx],al
     c38:	50                   	push   ax
     c39:	61                   	popa
     c3a:	6e                   	outs   dx,BYTE PTR ds:[si]
     c3b:	65 6c                	gs ins BYTE PTR es:[di],dx
     c3d:	36 38 5c 04          	cmp    BYTE PTR ss:[si+0x4],bl
     c41:	18 00                	sbb    BYTE PTR [bx+si],al
     c43:	0b 56 65             	or     dx,WORD PTR [bp+0x65]
     c46:	72 69                	jb     0xcb1
     c48:	66 69 65 72 42 74 6e 	imul   esp,DWORD PTR [di+0x72],0x606e7442
     c4f:	60 
     c50:	04 10                	add    al,0x10
     c52:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     c56:	6e                   	outs   dx,BYTE PTR ds:[si]
     c57:	65 6c                	gs ins BYTE PTR es:[di],dx
     c59:	34 64                	xor    al,0x64
     c5b:	04 48                	add    al,0x48
     c5d:	00 0a                	add    BYTE PTR [bp+si],cl
     c5f:	43                   	inc    bx
     c60:	68 65 63             	push   0x6365
     c63:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     c67:	56                   	push   si
     c68:	31 68 04             	xor    WORD PTR [bx+si+0x4],bp
     c6b:	18 00                	sbb    BYTE PTR [bx+si],al
     c6d:	05 4f 4b             	add    ax,0x4b4f
     c70:	42                   	inc    dx
     c71:	74 6e                	je     0xce1
     c73:	6c                   	ins    BYTE PTR es:[di],dx
     c74:	04 18                	add    al,0x18
     c76:	00 07                	add    BYTE PTR [bx],al
     c78:	48                   	dec    ax
     c79:	65 6c                	gs ins BYTE PTR es:[di],dx
     c7b:	70 42                	jo     0xcbf
     c7d:	74 6e                	je     0xced
     c7f:	70 04                	jo     0xc85
     c81:	18 00                	sbb    BYTE PTR [bx+si],al
     c83:	08 50 72             	or     BYTE PTR [bx+si+0x72],dl
     c86:	69 6e 74 42 74       	imul   bp,WORD PTR [bp+0x74],0x7442
     c8b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c8c:	74 04                	je     0xc92
     c8e:	18 00                	sbb    BYTE PTR [bx+si],al
     c90:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     c93:	70 69                	jo     0xcfe
     c95:	65 72 42             	gs jb  0xcda
     c98:	74 6e                	je     0xd08
     c9a:	78 04                	js     0xca0
     c9c:	18 00                	sbb    BYTE PTR [bx+si],al
     c9e:	0f                   	movmskps esi,(bad)
     c9f:	50                   	push   ax
     ca0:	72 69                	jb     0xd0b
     ca2:	6e                   	outs   dx,BYTE PTR ds:[si]
     ca3:	74 52                	je     0xcf7
     ca5:	61                   	popa
     ca6:	70 69                	jo     0xd11
     ca8:	64 65 42             	fs gs inc dx
     cab:	74 6e                	je     0xd1b
     cad:	31 7c 04             	xor    WORD PTR [si+0x4],di
     cb0:	10 00                	adc    BYTE PTR [bx+si],al
     cb2:	07                   	pop    es
     cb3:	50                   	push   ax
     cb4:	61                   	popa
     cb5:	6e                   	outs   dx,BYTE PTR ds:[si]
     cb6:	65 6c                	gs ins BYTE PTR es:[di],dx
     cb8:	36 39 80 04 38       	cmp    WORD PTR ss:[bx+si+0x3804],ax
     cbd:	00 0a                	add    BYTE PTR [bp+si],cl
     cbf:	53                   	push   bx
     cc0:	70 69                	jo     0xd2b
     cc2:	6e                   	outs   dx,BYTE PTR ds:[si]
     cc3:	45                   	inc    bp
     cc4:	64 69 74 50 31 84    	imul   si,WORD PTR fs:[si+0x50],0x8431
     cca:	04 44                	add    al,0x44
     ccc:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
     cd0:	69 74 50 31 13       	imul   si,WORD PTR [si+0x50],0x1331
     cd5:	00 ed                	add    ch,ch
     cd7:	01 a6 0f 0c          	add    WORD PTR [bp+0xc0f],sp
     cdb:	01 ec                	add    sp,bp
     cdd:	0c 38                	or     al,0x38
     cdf:	01 de                	add    si,bx
     ce1:	11 c8                	adc    ax,cx
     ce3:	08 c3                	or     bl,al
     ce5:	17                   	pop    ss
     ce6:	ad                   	lods   ax,WORD PTR ds:[si]
     ce7:	0d f8 0c             	or     ax,0xcf8
     cea:	17                   	pop    ss
     ceb:	06                   	push   es
     cec:	00 0d                	add    BYTE PTR [di],cl
     cee:	ac                   	lods   al,BYTE PTR ds:[si]
     cef:	04 b3                	add    al,0xb3
     cf1:	7b 7e                	jnp    0xd71
     cf3:	08 c3                	or     bl,al
     cf5:	2d 8b 0b             	sub    ax,0xb8b
     cf8:	0c 0d                	or     al,0xd
     cfa:	22 00                	and    al,BYTE PTR [bx+si]
     cfc:	18 0d                	sbb    BYTE PTR [di],cl
     cfe:	91                   	xchg   cx,ax
     cff:	12 14                	adc    dl,BYTE PTR [si]
     d01:	0d c6 03             	or     ax,0x3c6
     d04:	08 0d                	or     BYTE PTR [di],cl
     d06:	94                   	xchg   sp,ax
     d07:	00 ff                	add    bh,bh
     d09:	ff 65 06             	jmp    WORD PTR [di+0x6]
     d0c:	4e                   	dec    si
     d0d:	63 eb                	arpl   bx,bp
     d0f:	03 a9 16 19          	add    bp,WORD PTR [bx+di+0x1916]
     d13:	2c 1c                	sub    al,0x1c
     d15:	0d 26 06             	or     ax,0x626
     d18:	a9 17 90             	test   ax,0x9017
     d1b:	0b 20                	or     sp,WORD PTR [bx+si]
     d1d:	0d 22 27             	or     ax,0x2722
     d20:	8e 14                	mov    ss,WORD PTR [si]
     d22:	07                   	pop    es
     d23:	13 54 46             	adc    dx,WORD PTR [si+0x46]
     d26:	6f                   	outs   dx,WORD PTR ds:[si]
     d27:	72 6d                	jb     0xd96
     d29:	53                   	push   bx
     d2a:	41                   	inc    cx
     d2b:	44                   	inc    sp
     d2c:	44                   	inc    sp
     d2d:	5f                   	pop    di
     d2e:	44                   	inc    sp
     d2f:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     d33:	69 6f 6e 73 22       	imul   bp,WORD PTR [bx+0x6e],0x2273
     d38:	00 62 0d             	add    BYTE PTR [bp+si+0xd],ah
     d3b:	7b 06                	jnp    0xd43
     d3d:	8c 0d                	mov    WORD PTR [di],cs
     d3f:	38 00                	cmp    BYTE PTR [bx+si],al
     d41:	04 53                	add    al,0x53
     d43:	61                   	popa
     d44:	64 64 00 00          	fs add BYTE PTR fs:[bx+si],al
     d48:	55                   	push   bp
     d49:	89 e5                	mov    bp,sp
     d4b:	31 c0                	xor    ax,ax
     d4d:	9a 44 04 9f 0d       	call   0xd9f:0x444
     d52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d55:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
     d5b:	75 09                	jne    0xd66
     d5d:	06                   	push   es
     d5e:	57                   	push   di
     d5f:	9a 97 0d b5 0d       	call   0xdb5:0xd97
     d64:	eb 2d                	jmp    0xd93
     d66:	c6 06 7a 03 01       	mov    BYTE PTR ds:0x37a,0x1
     d6b:	6a 01                	push   0x1
     d6d:	9a c2 38 a6 0d       	call   0xda6:0x38c2
     d72:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     d76:	06                   	push   es
     d77:	57                   	push   di
     d78:	9a c7 28 ff ff       	call   0xffff:0x28c7
     d7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d80:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     d87:	06                   	push   es
     d88:	57                   	push   di
     d89:	9a 56 55 db 0d       	call   0xddb:0x5556
     d8e:	9a c3 28 ab 0d       	call   0xdab:0x28c3
     d93:	c9                   	leave
     d94:	ca 04 00             	retf   0x4
     d97:	55                   	push   bp
     d98:	89 e5                	mov    bp,sp
     d9a:	31 c0                	xor    ax,ax
     d9c:	9a 44 04 c0 0d       	call   0xdc0:0x444
     da1:	6a 00                	push   0x0
     da3:	9a c2 38 3b 13       	call   0x133b:0x38c2
     da8:	9a c3 28 77 16       	call   0x1677:0x28c3
     dad:	c9                   	leave
     dae:	ca 04 00             	retf   0x4
     db1:	00 00                	add    BYTE PTR [bx+si],al
     db3:	31 0e d4 0d          	xor    WORD PTR ds:0xdd4,cx
     db7:	55                   	push   bp
     db8:	89 e5                	mov    bp,sp
     dba:	b8 08 00             	mov    ax,0x8
     dbd:	9a 44 04 4d 0e       	call   0xe4d:0x444
     dc2:	83 ec 08             	sub    sp,0x8
     dc5:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     dc9:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     dcd:	b0 01                	mov    al,0x1
     dcf:	50                   	push   ax
     dd0:	b8 22 00             	mov    ax,0x22
     dd3:	ba 01 0e             	mov    dx,0xe01
     dd6:	52                   	push   dx
     dd7:	50                   	push   ax
     dd8:	9a 53 25 23 0e       	call   0xe23:0x2553
     ddd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     de0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     de3:	b8 b1 0d             	mov    ax,0xdb1
     de6:	0e                   	push   cs
     de7:	50                   	push   ax
     de8:	55                   	push   bp
     de9:	ff 36 58 18          	push   WORD PTR ds:0x1858
     ded:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     df1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     df4:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     df7:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     dfa:	6a 01                	push   0x1
     dfc:	06                   	push   es
     dfd:	57                   	push   di
     dfe:	9a 83 13 0b 0e       	call   0xe0b:0x1383
     e03:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e06:	06                   	push   es
     e07:	57                   	push   di
     e08:	9a 50 32 19 0e       	call   0xe19:0x3250
     e0d:	ff 36 4c 01          	push   WORD PTR ds:0x14c
     e11:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e14:	06                   	push   es
     e15:	57                   	push   di
     e16:	9a 3e 16 42 0e       	call   0xe42:0x163e
     e1b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e1e:	06                   	push   es
     e1f:	57                   	push   di
     e20:	9a 45 5d 39 0e       	call   0xe39:0x5d45
     e25:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     e29:	83 c4 06             	add    sp,0x6
     e2c:	b8 3c 0e             	mov    ax,0xe3c
     e2f:	0e                   	push   cs
     e30:	50                   	push   ax
     e31:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e34:	06                   	push   es
     e35:	57                   	push   di
     e36:	9a 1d 5f 68 0e       	call   0xe68:0x5f1d
     e3b:	cb                   	retf
     e3c:	c9                   	leave
     e3d:	cb                   	retf
     e3e:	00 00                	add    BYTE PTR [bx+si],al
     e40:	09 0f                	or     WORD PTR [bx],cx
     e42:	61                   	popa
     e43:	0e                   	push   cs
     e44:	55                   	push   bp
     e45:	89 e5                	mov    bp,sp
     e47:	b8 08 00             	mov    ax,0x8
     e4a:	9a 44 04 e6 0e       	call   0xee6:0x444
     e4f:	83 ec 08             	sub    sp,0x8
     e52:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     e56:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     e5a:	b0 01                	mov    al,0x1
     e5c:	50                   	push   ax
     e5d:	b8 22 00             	mov    ax,0x22
     e60:	ba 8e 0e             	mov    dx,0xe8e
     e63:	52                   	push   dx
     e64:	50                   	push   ax
     e65:	9a 53 25 fb 0e       	call   0xefb:0x2553
     e6a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e6d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     e70:	b8 3e 0e             	mov    ax,0xe3e
     e73:	0e                   	push   cs
     e74:	50                   	push   ax
     e75:	55                   	push   bp
     e76:	ff 36 58 18          	push   WORD PTR ds:0x1858
     e7a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     e7e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e81:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     e84:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     e87:	6a 00                	push   0x0
     e89:	06                   	push   es
     e8a:	57                   	push   di
     e8b:	9a 83 13 98 0e       	call   0xe98:0x1383
     e90:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e93:	06                   	push   es
     e94:	57                   	push   di
     e95:	9a 50 32 b6 0e       	call   0xeb6:0x3250
     e9a:	6a 01                	push   0x1
     e9c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e9f:	26 c4 bd 74 04       	les    di,DWORD PTR es:[di+0x474]
     ea4:	06                   	push   es
     ea5:	57                   	push   di
     ea6:	9a 77 1c 52 0f       	call   0xf52:0x1c77
     eab:	ff 76 06             	push   WORD PTR [bp+0x6]
     eae:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     eb1:	06                   	push   es
     eb2:	57                   	push   di
     eb3:	9a 3e 16 f1 0e       	call   0xef1:0x163e
     eb8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     ebb:	26 80 bd 90 04 00    	cmp    BYTE PTR es:[di+0x490],0x0
     ec1:	b0 00                	mov    al,0x0
     ec3:	75 01                	jne    0xec6
     ec5:	40                   	inc    ax
     ec6:	8a d0                	mov    dl,al
     ec8:	26 83 bd 8e 04 01    	cmp    WORD PTR es:[di+0x48e],0x1
     ece:	b0 00                	mov    al,0x0
     ed0:	7e 01                	jle    0xed3
     ed2:	40                   	inc    ax
     ed3:	22 c2                	and    al,dl
     ed5:	08 c0                	or     al,al
     ed7:	74 1a                	je     0xef3
     ed9:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
     ede:	2d 01 00             	sub    ax,0x1
     ee1:	71 05                	jno    0xee8
     ee3:	9a 3e 04 31 0f       	call   0xf31:0x43e
     ee8:	50                   	push   ax
     ee9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     eec:	06                   	push   es
     eed:	57                   	push   di
     eee:	9a 3e 16 ab 12       	call   0x12ab:0x163e
     ef3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     ef6:	06                   	push   es
     ef7:	57                   	push   di
     ef8:	9a 45 5d 11 0f       	call   0xf11:0x5d45
     efd:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     f01:	83 c4 06             	add    sp,0x6
     f04:	b8 14 0f             	mov    ax,0xf14
     f07:	0e                   	push   cs
     f08:	50                   	push   ax
     f09:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     f0c:	06                   	push   es
     f0d:	57                   	push   di
     f0e:	9a 1d 5f 62 12       	call   0x1262:0x5f1d
     f13:	cb                   	retf
     f14:	c9                   	leave
     f15:	ca 02 00             	retf   0x2
     f18:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     f1b:	6d                   	ins    WORD PTR es:[di],dx
     f1c:	73 74                	jae    0xf92
     f1e:	72 61                	jb     0xf81
     f20:	74 20                	je     0xf42
     f22:	2d 20 03             	sub    ax,0x320
     f25:	20 2d                	and    BYTE PTR [di],ch
     f27:	20 55 89             	and    BYTE PTR [di-0x77],dl
     f2a:	e5 b8                	in     ax,0xb8
     f2c:	02 02                	add    al,BYTE PTR [bp+si]
     f2e:	9a 44 04 62 0f       	call   0xf62:0x444
     f33:	81 ec 02 02          	sub    sp,0x202
     f37:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     f3b:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
     f40:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
     f44:	50                   	push   ax
     f45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f48:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
     f4d:	06                   	push   es
     f4e:	57                   	push   di
     f4f:	9a 77 1c 86 0f       	call   0xf86:0x1c77
     f54:	8d be fe fe          	lea    di,[bp-0x102]
     f58:	16                   	push   ss
     f59:	57                   	push   di
     f5a:	bf 18 0f             	mov    di,0xf18
     f5d:	0e                   	push   cs
     f5e:	57                   	push   di
     f5f:	9a cd 17 6c 0f       	call   0xf6c:0x17cd
     f64:	bf fa 1d             	mov    di,0x1dfa
     f67:	1e                   	push   ds
     f68:	57                   	push   di
     f69:	9a 4c 18 76 0f       	call   0xf76:0x184c
     f6e:	bf 24 0f             	mov    di,0xf24
     f71:	0e                   	push   cs
     f72:	57                   	push   di
     f73:	9a 4c 18 8b 0f       	call   0xf8b:0x184c
     f78:	8d be fe fd          	lea    di,[bp-0x202]
     f7c:	16                   	push   ss
     f7d:	57                   	push   di
     f7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f81:	06                   	push   es
     f82:	57                   	push   di
     f83:	9a 53 1d 95 0f       	call   0xf95:0x1d53
     f88:	9a 4c 18 32 10       	call   0x1032:0x184c
     f8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f90:	06                   	push   es
     f91:	57                   	push   di
     f92:	9a 8c 1d fc 0f       	call   0xffc:0x1d8c
     f97:	6a 00                	push   0x0
     f99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f9c:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     fa1:	06                   	push   es
     fa2:	57                   	push   di
     fa3:	9a 6f 24 0c 30       	call   0x300c:0x246f
     fa8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fab:	26 c6 85 88 04 00    	mov    BYTE PTR es:[di+0x488],0x0
     fb1:	26 c4 bd 80 04       	les    di,DWORD PTR es:[di+0x480]
     fb6:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     fb9:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     fbc:	26 c7 85 ec 00 01 00 	mov    WORD PTR es:[di+0xec],0x1
     fc3:	26 c7 85 ee 00 00 00 	mov    WORD PTR es:[di+0xee],0x0
     fca:	a1 4c 01             	mov    ax,ds:0x14c
     fcd:	99                   	cwd
     fce:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
     fd3:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
     fd8:	26 8b 85 f0 00       	mov    ax,WORD PTR es:[di+0xf0]
     fdd:	26 8b 95 f2 00       	mov    dx,WORD PTR es:[di+0xf2]
     fe2:	26 3b 95 ee 00       	cmp    dx,WORD PTR es:[di+0xee]
     fe7:	7c 09                	jl     0xff2
     fe9:	7f 13                	jg     0xffe
     feb:	26 3b 85 ec 00       	cmp    ax,WORD PTR es:[di+0xec]
     ff0:	77 0c                	ja     0xffe
     ff2:	6a 00                	push   0x0
     ff4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     ff7:	06                   	push   es
     ff8:	57                   	push   di
     ff9:	9a b8 1c 0d 10       	call   0x100d:0x1cb8
     ffe:	6a 00                	push   0x0
    1000:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1003:	26 c4 bd 60 04       	les    di,DWORD PTR es:[di+0x460]
    1008:	06                   	push   es
    1009:	57                   	push   di
    100a:	9a b8 1c 1e 10       	call   0x101e:0x1cb8
    100f:	6a 00                	push   0x0
    1011:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1014:	26 c4 bd 74 04       	les    di,DWORD PTR es:[di+0x474]
    1019:	06                   	push   es
    101a:	57                   	push   di
    101b:	9a 77 1c 5c 10       	call   0x105c:0x1c77
    1020:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1023:	06                   	push   es
    1024:	57                   	push   di
    1025:	9a 7d 52 54 10       	call   0x1054:0x527d
    102a:	2d 01 00             	sub    ax,0x1
    102d:	71 05                	jno    0x1034
    102f:	9a 3e 04 63 10       	call   0x1063:0x43e
    1034:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1037:	31 c0                	xor    ax,ax
    1039:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    103c:	7e 03                	jle    0x1041
    103e:	e9 a0 00             	jmp    0x10e1
    1041:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1044:	eb 03                	jmp    0x1049
    1046:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1049:	ff 76 fe             	push   WORD PTR [bp-0x2]
    104c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    104f:	06                   	push   es
    1050:	57                   	push   di
    1051:	9a 46 52 74 10       	call   0x1074:0x5246
    1056:	52                   	push   dx
    1057:	50                   	push   ax
    1058:	bf 99 03             	mov    di,0x399
    105b:	b8 7c 10             	mov    ax,0x107c
    105e:	50                   	push   ax
    105f:	57                   	push   di
    1060:	9a 55 22 83 10       	call   0x1083:0x2255
    1065:	08 c0                	or     al,al
    1067:	74 6d                	je     0x10d6
    1069:	ff 76 fe             	push   WORD PTR [bp-0x2]
    106c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    106f:	06                   	push   es
    1070:	57                   	push   di
    1071:	9a 46 52 7f 1e       	call   0x1e7f:0x5246
    1076:	52                   	push   dx
    1077:	50                   	push   ax
    1078:	bf 99 03             	mov    di,0x399
    107b:	b8 d4 10             	mov    ax,0x10d4
    107e:	50                   	push   ax
    107f:	57                   	push   di
    1080:	9a 73 22 b9 10       	call   0x10b9:0x2273
    1085:	89 c7                	mov    di,ax
    1087:	8e c2                	mov    es,dx
    1089:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    108c:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    108f:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1093:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    1097:	74 3d                	je     0x10d6
    1099:	a1 06 1e             	mov    ax,ds:0x1e06
    109c:	99                   	cwd
    109d:	8b c8                	mov    cx,ax
    109f:	8b da                	mov    bx,dx
    10a1:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    10a5:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    10a9:	09 d2                	or     dx,dx
    10ab:	79 07                	jns    0x10b4
    10ad:	f7 d2                	not    dx
    10af:	f7 d8                	neg    ax
    10b1:	83 da ff             	sbb    dx,0xffff
    10b4:	71 05                	jno    0x10bb
    10b6:	9a 3e 04 55 12       	call   0x1255:0x43e
    10bb:	3b d3                	cmp    dx,bx
    10bd:	7c 0a                	jl     0x10c9
    10bf:	7f 04                	jg     0x10c5
    10c1:	3b c1                	cmp    ax,cx
    10c3:	76 04                	jbe    0x10c9
    10c5:	b0 00                	mov    al,0x0
    10c7:	eb 02                	jmp    0x10cb
    10c9:	b0 01                	mov    al,0x1
    10cb:	50                   	push   ax
    10cc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    10cf:	06                   	push   es
    10d0:	57                   	push   di
    10d1:	9a 77 1c fa 10       	call   0x10fa:0x1c77
    10d6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    10d9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    10dc:	74 03                	je     0x10e1
    10de:	e9 65 ff             	jmp    0x1046
    10e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10e4:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    10e9:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    10ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10f0:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    10f5:	06                   	push   es
    10f6:	57                   	push   di
    10f7:	9a 9d 17 14 11       	call   0x1114:0x179d
    10fc:	83 3e 4e 01 00       	cmp    WORD PTR ds:0x14e,0x0
    1101:	b0 00                	mov    al,0x0
    1103:	7e 01                	jle    0x1106
    1105:	40                   	inc    ax
    1106:	50                   	push   ax
    1107:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    110a:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    110f:	06                   	push   es
    1110:	57                   	push   di
    1111:	9a 77 1c 2e 11       	call   0x112e:0x1c77
    1116:	83 3e 4e 01 01       	cmp    WORD PTR ds:0x14e,0x1
    111b:	b0 00                	mov    al,0x0
    111d:	7e 01                	jle    0x1120
    111f:	40                   	inc    ax
    1120:	50                   	push   ax
    1121:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1124:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    1129:	06                   	push   es
    112a:	57                   	push   di
    112b:	9a 77 1c 48 11       	call   0x1148:0x1c77
    1130:	83 3e 4e 01 02       	cmp    WORD PTR ds:0x14e,0x2
    1135:	b0 00                	mov    al,0x0
    1137:	7e 01                	jle    0x113a
    1139:	40                   	inc    ax
    113a:	50                   	push   ax
    113b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    113e:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    1143:	06                   	push   es
    1144:	57                   	push   di
    1145:	9a 77 1c 62 11       	call   0x1162:0x1c77
    114a:	83 3e 4e 01 03       	cmp    WORD PTR ds:0x14e,0x3
    114f:	b0 00                	mov    al,0x0
    1151:	7e 01                	jle    0x1154
    1153:	40                   	inc    ax
    1154:	50                   	push   ax
    1155:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1158:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    115d:	06                   	push   es
    115e:	57                   	push   di
    115f:	9a 77 1c 7c 11       	call   0x117c:0x1c77
    1164:	83 3e 4e 01 04       	cmp    WORD PTR ds:0x14e,0x4
    1169:	b0 00                	mov    al,0x0
    116b:	7e 01                	jle    0x116e
    116d:	40                   	inc    ax
    116e:	50                   	push   ax
    116f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1172:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
    1177:	06                   	push   es
    1178:	57                   	push   di
    1179:	9a 77 1c 96 11       	call   0x1196:0x1c77
    117e:	83 3e 4e 01 05       	cmp    WORD PTR ds:0x14e,0x5
    1183:	b0 00                	mov    al,0x0
    1185:	7e 01                	jle    0x1188
    1187:	40                   	inc    ax
    1188:	50                   	push   ax
    1189:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    118c:	26 c4 bd f4 02       	les    di,DWORD PTR es:[di+0x2f4]
    1191:	06                   	push   es
    1192:	57                   	push   di
    1193:	9a 77 1c b0 11       	call   0x11b0:0x1c77
    1198:	83 3e 4e 01 06       	cmp    WORD PTR ds:0x14e,0x6
    119d:	b0 00                	mov    al,0x0
    119f:	7e 01                	jle    0x11a2
    11a1:	40                   	inc    ax
    11a2:	50                   	push   ax
    11a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a6:	26 c4 bd fc 02       	les    di,DWORD PTR es:[di+0x2fc]
    11ab:	06                   	push   es
    11ac:	57                   	push   di
    11ad:	9a 77 1c ca 11       	call   0x11ca:0x1c77
    11b2:	83 3e 4e 01 06       	cmp    WORD PTR ds:0x14e,0x6
    11b7:	b0 00                	mov    al,0x0
    11b9:	7e 01                	jle    0x11bc
    11bb:	40                   	inc    ax
    11bc:	50                   	push   ax
    11bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11c0:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
    11c5:	06                   	push   es
    11c6:	57                   	push   di
    11c7:	9a 77 1c bb 13       	call   0x13bb:0x1c77
    11cc:	bf 32 1e             	mov    di,0x1e32
    11cf:	1e                   	push   ds
    11d0:	57                   	push   di
    11d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11d4:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    11d9:	06                   	push   es
    11da:	57                   	push   di
    11db:	9a 17 30 f2 11       	call   0x11f2:0x3017
    11e0:	bf 40 1e             	mov    di,0x1e40
    11e3:	1e                   	push   ds
    11e4:	57                   	push   di
    11e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e8:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    11ed:	06                   	push   es
    11ee:	57                   	push   di
    11ef:	9a 17 30 06 12       	call   0x1206:0x3017
    11f4:	bf 40 1e             	mov    di,0x1e40
    11f7:	1e                   	push   ds
    11f8:	57                   	push   di
    11f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11fc:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1201:	06                   	push   es
    1202:	57                   	push   di
    1203:	9a 17 30 1a 12       	call   0x121a:0x3017
    1208:	bf 32 1e             	mov    di,0x1e32
    120b:	1e                   	push   ds
    120c:	57                   	push   di
    120d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1210:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    1215:	06                   	push   es
    1216:	57                   	push   di
    1217:	9a 17 30 2e 12       	call   0x122e:0x3017
    121c:	bf 40 1e             	mov    di,0x1e40
    121f:	1e                   	push   ds
    1220:	57                   	push   di
    1221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1224:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    1229:	06                   	push   es
    122a:	57                   	push   di
    122b:	9a 17 30 42 12       	call   0x1242:0x3017
    1230:	bf 4e 1e             	mov    di,0x1e4e
    1233:	1e                   	push   ds
    1234:	57                   	push   di
    1235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1238:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    123d:	06                   	push   es
    123e:	57                   	push   di
    123f:	9a 17 30 d5 17       	call   0x17d5:0x3017
    1244:	c6 06 7a 03 00       	mov    BYTE PTR ds:0x37a,0x0
    1249:	c9                   	leave
    124a:	ca 08 00             	retf   0x8
    124d:	55                   	push   bp
    124e:	89 e5                	mov    bp,sp
    1250:	31 c0                	xor    ax,ax
    1252:	9a 44 04 71 12       	call   0x1271:0x444
    1257:	6a fe                	push   0xfffe
    1259:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    125d:	06                   	push   es
    125e:	57                   	push   di
    125f:	9a a9 63 8b 12       	call   0x128b:0x63a9
    1264:	c9                   	leave
    1265:	ca 08 00             	retf   0x8
    1268:	55                   	push   bp
    1269:	89 e5                	mov    bp,sp
    126b:	b8 04 00             	mov    ax,0x4
    126e:	9a 44 04 b2 12       	call   0x12b2:0x444
    1273:	83 ec 04             	sub    sp,0x4
    1276:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1279:	26 80 bd 88 04 00    	cmp    BYTE PTR es:[di+0x488],0x0
    127f:	74 1b                	je     0x129c
    1281:	26 c4 bd 89 04       	les    di,DWORD PTR es:[di+0x489]
    1286:	06                   	push   es
    1287:	57                   	push   di
    1288:	9a 56 55 9a 12       	call   0x129a:0x5556
    128d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1290:	26 c4 bd 89 04       	les    di,DWORD PTR es:[di+0x489]
    1295:	06                   	push   es
    1296:	57                   	push   di
    1297:	9a 1d 5f 56 16       	call   0x1656:0x5f1d
    129c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    129f:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    12a3:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    12a7:	bf 22 00             	mov    di,0x22
    12aa:	b8 c7 12             	mov    ax,0x12c7
    12ad:	50                   	push   ax
    12ae:	57                   	push   di
    12af:	9a 55 22 ce 12       	call   0x12ce:0x2255
    12b4:	08 c0                	or     al,al
    12b6:	74 22                	je     0x12da
    12b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12bb:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    12bf:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    12c3:	bf 22 00             	mov    di,0x22
    12c6:	b8 e2 12             	mov    ax,0x12e2
    12c9:	50                   	push   ax
    12ca:	57                   	push   di
    12cb:	9a 73 22 f8 12       	call   0x12f8:0x2273
    12d0:	89 c7                	mov    di,ax
    12d2:	8e c2                	mov    es,dx
    12d4:	26 c6 85 88 04 00    	mov    BYTE PTR es:[di+0x488],0x0
    12da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12dd:	06                   	push   es
    12de:	57                   	push   di
    12df:	9a 82 31 20 13       	call   0x1320:0x3182
    12e4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    12e7:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    12eb:	c9                   	leave
    12ec:	ca 0c 00             	retf   0xc
    12ef:	55                   	push   bp
    12f0:	89 e5                	mov    bp,sp
    12f2:	b8 00 02             	mov    ax,0x200
    12f5:	9a 44 04 8c 13       	call   0x138c:0x444
    12fa:	81 ec 00 02          	sub    sp,0x200
    12fe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1301:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1305:	80 3e 7a 03 00       	cmp    BYTE PTR ds:0x37a,0x0
    130a:	b0 00                	mov    al,0x0
    130c:	75 01                	jne    0x130f
    130e:	40                   	inc    ax
    130f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1312:	26 22 85 8d 04       	and    al,BYTE PTR es:[di+0x48d]
    1317:	08 c0                	or     al,al
    1319:	74 60                	je     0x137b
    131b:	06                   	push   es
    131c:	57                   	push   di
    131d:	9a f5 3e 4a 13       	call   0x134a:0x3ef5
    1322:	8a d0                	mov    dl,al
    1324:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1327:	26 80 bd 90 04 00    	cmp    BYTE PTR es:[di+0x490],0x0
    132d:	b0 00                	mov    al,0x0
    132f:	75 01                	jne    0x1332
    1331:	40                   	inc    ax
    1332:	0a c2                	or     al,dl
    1334:	08 c0                	or     al,al
    1336:	74 33                	je     0x136b
    1338:	9a 3a 3b b1 2d       	call   0x2db1:0x3b3a
    133d:	3d 06 00             	cmp    ax,0x6
    1340:	75 12                	jne    0x1354
    1342:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1345:	06                   	push   es
    1346:	57                   	push   di
    1347:	9a 2b 42 73 13       	call   0x1373:0x422b
    134c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    134f:	26 88 05             	mov    BYTE PTR es:[di],al
    1352:	eb 15                	jmp    0x1369
    1354:	3d 07 00             	cmp    ax,0x7
    1357:	75 02                	jne    0x135b
    1359:	eb 0e                	jmp    0x1369
    135b:	3d 02 00             	cmp    ax,0x2
    135e:	75 09                	jne    0x1369
    1360:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1363:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1367:	eb 00                	jmp    0x1369
    1369:	eb 10                	jmp    0x137b
    136b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    136e:	06                   	push   es
    136f:	57                   	push   di
    1370:	9a 86 4c 42 14       	call   0x1442:0x4c86
    1375:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1378:	26 88 05             	mov    BYTE PTR es:[di],al
    137b:	c9                   	leave
    137c:	ca 0c 00             	retf   0xc
    137f:	03 20                	add    sp,WORD PTR [bx+si]
    1381:	2d 20 55             	sub    ax,0x5520
    1384:	89 e5                	mov    bp,sp
    1386:	b8 00 02             	mov    ax,0x200
    1389:	9a 44 04 c9 13       	call   0x13c9:0x444
    138e:	81 ec 00 02          	sub    sp,0x200
    1392:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1395:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1398:	26 88 85 8d 04       	mov    BYTE PTR es:[di+0x48d],al
    139d:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    13a3:	74 03                	je     0x13a8
    13a5:	e9 8b 00             	jmp    0x1433
    13a8:	8d be 00 fe          	lea    di,[bp-0x200]
    13ac:	16                   	push   ss
    13ad:	57                   	push   di
    13ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13b1:	26 c4 bd 54 04       	les    di,DWORD PTR es:[di+0x454]
    13b6:	06                   	push   es
    13b7:	57                   	push   di
    13b8:	9a 53 1d de 13       	call   0x13de:0x1d53
    13bd:	8d be 00 ff          	lea    di,[bp-0x100]
    13c1:	16                   	push   ss
    13c2:	57                   	push   di
    13c3:	68 ff 00             	push   0xff
    13c6:	9a e7 17 1c 14       	call   0x141c:0x17e7
    13cb:	8d be 00 fe          	lea    di,[bp-0x200]
    13cf:	16                   	push   ss
    13d0:	57                   	push   di
    13d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d4:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    13d9:	06                   	push   es
    13da:	57                   	push   di
    13db:	9a 53 1d ed 13       	call   0x13ed:0x1d53
    13e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e3:	26 c4 bd 54 04       	les    di,DWORD PTR es:[di+0x454]
    13e8:	06                   	push   es
    13e9:	57                   	push   di
    13ea:	9a 8c 1d 02 14       	call   0x1402:0x1d8c
    13ef:	8d be 00 ff          	lea    di,[bp-0x100]
    13f3:	16                   	push   ss
    13f4:	57                   	push   di
    13f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13f8:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    13fd:	06                   	push   es
    13fe:	57                   	push   di
    13ff:	9a 8c 1d 12 14       	call   0x1412:0x1d8c
    1404:	8d be 00 fe          	lea    di,[bp-0x200]
    1408:	16                   	push   ss
    1409:	57                   	push   di
    140a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    140d:	06                   	push   es
    140e:	57                   	push   di
    140f:	9a 53 1d 31 14       	call   0x1431:0x1d53
    1414:	bf 7f 13             	mov    di,0x137f
    1417:	0e                   	push   cs
    1418:	57                   	push   di
    1419:	9a 4c 18 27 14       	call   0x1427:0x184c
    141e:	8d be 00 ff          	lea    di,[bp-0x100]
    1422:	16                   	push   ss
    1423:	57                   	push   di
    1424:	9a 4c 18 49 14       	call   0x1449:0x184c
    1429:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    142c:	06                   	push   es
    142d:	57                   	push   di
    142e:	9a 8c 1d 5e 14       	call   0x145e:0x1d8c
    1433:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1436:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    143a:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    143e:	bf 22 00             	mov    di,0x22
    1441:	b8 12 16             	mov    ax,0x1612
    1444:	50                   	push   ax
    1445:	57                   	push   di
    1446:	9a 55 22 21 16       	call   0x1621:0x2255
    144b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    144e:	26 0a 85 8d 04       	or     al,BYTE PTR es:[di+0x48d]
    1453:	50                   	push   ax
    1454:	26 c4 bd 54 04       	les    di,DWORD PTR es:[di+0x454]
    1459:	06                   	push   es
    145a:	57                   	push   di
    145b:	9a 77 1c 73 14       	call   0x1473:0x1c77
    1460:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1463:	26 8a 85 8d 04       	mov    al,BYTE PTR es:[di+0x48d]
    1468:	50                   	push   ax
    1469:	26 c4 bd 44 04       	les    di,DWORD PTR es:[di+0x444]
    146e:	06                   	push   es
    146f:	57                   	push   di
    1470:	9a 77 1c cc 15       	call   0x15cc:0x1c77
    1475:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1478:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    147e:	b0 00                	mov    al,0x0
    1480:	75 01                	jne    0x1483
    1482:	40                   	inc    ax
    1483:	50                   	push   ax
    1484:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    1489:	06                   	push   es
    148a:	57                   	push   di
    148b:	9a 79 49 a9 14       	call   0x14a9:0x4979
    1490:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1493:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1499:	b0 00                	mov    al,0x0
    149b:	75 01                	jne    0x149e
    149d:	40                   	inc    ax
    149e:	50                   	push   ax
    149f:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
    14a4:	06                   	push   es
    14a5:	57                   	push   di
    14a6:	9a 79 49 c4 14       	call   0x14c4:0x4979
    14ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ae:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    14b4:	b0 00                	mov    al,0x0
    14b6:	75 01                	jne    0x14b9
    14b8:	40                   	inc    ax
    14b9:	50                   	push   ax
    14ba:	26 c4 bd bc 02       	les    di,DWORD PTR es:[di+0x2bc]
    14bf:	06                   	push   es
    14c0:	57                   	push   di
    14c1:	9a 79 49 df 14       	call   0x14df:0x4979
    14c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14c9:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    14cf:	b0 00                	mov    al,0x0
    14d1:	75 01                	jne    0x14d4
    14d3:	40                   	inc    ax
    14d4:	50                   	push   ax
    14d5:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
    14da:	06                   	push   es
    14db:	57                   	push   di
    14dc:	9a 79 49 fa 14       	call   0x14fa:0x4979
    14e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14e4:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    14ea:	b0 00                	mov    al,0x0
    14ec:	75 01                	jne    0x14ef
    14ee:	40                   	inc    ax
    14ef:	50                   	push   ax
    14f0:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    14f5:	06                   	push   es
    14f6:	57                   	push   di
    14f7:	9a 79 49 15 15       	call   0x1515:0x4979
    14fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ff:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1505:	b0 00                	mov    al,0x0
    1507:	75 01                	jne    0x150a
    1509:	40                   	inc    ax
    150a:	50                   	push   ax
    150b:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    1510:	06                   	push   es
    1511:	57                   	push   di
    1512:	9a 79 49 30 15       	call   0x1530:0x4979
    1517:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    151a:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1520:	b0 00                	mov    al,0x0
    1522:	75 01                	jne    0x1525
    1524:	40                   	inc    ax
    1525:	50                   	push   ax
    1526:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    152b:	06                   	push   es
    152c:	57                   	push   di
    152d:	9a 79 49 4b 15       	call   0x154b:0x4979
    1532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1535:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    153b:	b0 00                	mov    al,0x0
    153d:	75 01                	jne    0x1540
    153f:	40                   	inc    ax
    1540:	50                   	push   ax
    1541:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    1546:	06                   	push   es
    1547:	57                   	push   di
    1548:	9a 79 49 66 15       	call   0x1566:0x4979
    154d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1550:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1556:	b0 00                	mov    al,0x0
    1558:	75 01                	jne    0x155b
    155a:	40                   	inc    ax
    155b:	50                   	push   ax
    155c:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    1561:	06                   	push   es
    1562:	57                   	push   di
    1563:	9a 79 49 81 15       	call   0x1581:0x4979
    1568:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    156b:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1571:	b0 00                	mov    al,0x0
    1573:	75 01                	jne    0x1576
    1575:	40                   	inc    ax
    1576:	50                   	push   ax
    1577:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    157c:	06                   	push   es
    157d:	57                   	push   di
    157e:	9a 79 49 9c 15       	call   0x159c:0x4979
    1583:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1586:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    158c:	b0 00                	mov    al,0x0
    158e:	75 01                	jne    0x1591
    1590:	40                   	inc    ax
    1591:	50                   	push   ax
    1592:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    1597:	06                   	push   es
    1598:	57                   	push   di
    1599:	9a 79 49 b7 15       	call   0x15b7:0x4979
    159e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15a1:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    15a7:	b0 00                	mov    al,0x0
    15a9:	75 01                	jne    0x15ac
    15ab:	40                   	inc    ax
    15ac:	50                   	push   ax
    15ad:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    15b2:	06                   	push   es
    15b3:	57                   	push   di
    15b4:	9a 79 49 0c 1f       	call   0x1f0c:0x4979
    15b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15bc:	26 8a 85 8d 04       	mov    al,BYTE PTR es:[di+0x48d]
    15c1:	50                   	push   ax
    15c2:	26 c4 bd 0c 03       	les    di,DWORD PTR es:[di+0x30c]
    15c7:	06                   	push   es
    15c8:	57                   	push   di
    15c9:	9a 77 1c e1 15       	call   0x15e1:0x1c77
    15ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15d1:	26 8a 85 8d 04       	mov    al,BYTE PTR es:[di+0x48d]
    15d6:	50                   	push   ax
    15d7:	26 c4 bd 84 04       	les    di,DWORD PTR es:[di+0x484]
    15dc:	06                   	push   es
    15dd:	57                   	push   di
    15de:	9a 77 1c fc 15       	call   0x15fc:0x1c77
    15e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15e6:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    15ec:	b0 00                	mov    al,0x0
    15ee:	75 01                	jne    0x15f1
    15f0:	40                   	inc    ax
    15f1:	50                   	push   ax
    15f2:	26 c4 bd 80 04       	les    di,DWORD PTR es:[di+0x480]
    15f7:	06                   	push   es
    15f8:	57                   	push   di
    15f9:	9a 77 1c 86 16       	call   0x1686:0x1c77
    15fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1601:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1607:	b0 00                	mov    al,0x0
    1609:	75 01                	jne    0x160c
    160b:	40                   	inc    ax
    160c:	50                   	push   ax
    160d:	06                   	push   es
    160e:	57                   	push   di
    160f:	9a 43 2c b3 16       	call   0x16b3:0x2c43
    1614:	c9                   	leave
    1615:	ca 06 00             	retf   0x6
    1618:	55                   	push   bp
    1619:	89 e5                	mov    bp,sp
    161b:	b8 02 00             	mov    ax,0x2
    161e:	9a 44 04 47 16       	call   0x1647:0x444
    1623:	83 ec 02             	sub    sp,0x2
    1626:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1629:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    162f:	b0 00                	mov    al,0x0
    1631:	75 01                	jne    0x1634
    1633:	40                   	inc    ax
    1634:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1637:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    163a:	c9                   	leave
    163b:	ca 04 00             	retf   0x4
    163e:	55                   	push   bp
    163f:	89 e5                	mov    bp,sp
    1641:	b8 00 01             	mov    ax,0x100
    1644:	9a 44 04 ca 16       	call   0x16ca:0x444
    1649:	81 ec 00 01          	sub    sp,0x100
    164d:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1651:	06                   	push   es
    1652:	57                   	push   di
    1653:	9a 03 73 63 17       	call   0x1763:0x7303
    1658:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    165b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    165e:	26 89 85 8e 04       	mov    WORD PTR es:[di+0x48e],ax
    1663:	8d be 00 ff          	lea    di,[bp-0x100]
    1667:	16                   	push   ss
    1668:	57                   	push   di
    1669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    166c:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    1671:	99                   	cwd
    1672:	52                   	push   dx
    1673:	50                   	push   ax
    1674:	9a a9 08 3e 18       	call   0x183e:0x8a9
    1679:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    167c:	26 c4 bd 84 04       	les    di,DWORD PTR es:[di+0x484]
    1681:	06                   	push   es
    1682:	57                   	push   di
    1683:	9a 8c 1d a8 1c       	call   0x1ca8:0x1d8c
    1688:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    168b:	26 c4 bd 80 04       	les    di,DWORD PTR es:[di+0x480]
    1690:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1693:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1696:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1699:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    169e:	99                   	cwd
    169f:	52                   	push   dx
    16a0:	50                   	push   ax
    16a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16a4:	06                   	push   es
    16a5:	57                   	push   di
    16a6:	9a 8b 17 d9 16       	call   0x16d9:0x178b
    16ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ae:	06                   	push   es
    16af:	57                   	push   di
    16b0:	9a 31 3c 15 17       	call   0x1715:0x3c31
    16b5:	c9                   	leave
    16b6:	ca 06 00             	retf   0x6
    16b9:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    16bd:	ff                   	(bad)
    16be:	7f 00                	jg     0x16c0
    16c0:	00 55 89             	add    BYTE PTR [di-0x77],dl
    16c3:	e5 b8                	in     ax,0xb8
    16c5:	04 00                	add    al,0x0
    16c7:	9a 44 04 e0 16       	call   0x16e0:0x444
    16cc:	83 ec 04             	sub    sp,0x4
    16cf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16d2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16d5:	bf eb 03             	mov    di,0x3eb
    16d8:	b8 f0 16             	mov    ax,0x16f0
    16db:	50                   	push   ax
    16dc:	57                   	push   di
    16dd:	9a 55 22 f7 16       	call   0x16f7:0x2255
    16e2:	08 c0                	or     al,al
    16e4:	74 31                	je     0x1717
    16e6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16e9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16ec:	bf eb 03             	mov    di,0x3eb
    16ef:	b8 02 17             	mov    ax,0x1702
    16f2:	50                   	push   ax
    16f3:	57                   	push   di
    16f4:	9a 73 22 0a 17       	call   0x170a:0x2273
    16f9:	89 c7                	mov    di,ax
    16fb:	8e c2                	mov    es,dx
    16fd:	06                   	push   es
    16fe:	57                   	push   di
    16ff:	9a 33 17 27 23       	call   0x2327:0x1733
    1704:	bf b9 16             	mov    di,0x16b9
    1707:	9a 16 04 4a 17       	call   0x174a:0x416
    170c:	50                   	push   ax
    170d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1710:	06                   	push   es
    1711:	57                   	push   di
    1712:	9a 3e 16 83 21       	call   0x2183:0x163e
    1717:	c9                   	leave
    1718:	ca 08 00             	retf   0x8
    171b:	0a 23                	or     ah,BYTE PTR [bp+di]
    171d:	2c 23                	sub    al,0x23
    171f:	23 30                	and    si,WORD PTR [bx+si]
    1721:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1724:	23 23                	and    sp,WORD PTR [bp+di]
    1726:	07                   	pop    es
    1727:	23 30                	and    si,WORD PTR [bx+si]
    1729:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    172c:	23 23                	and    sp,WORD PTR [bp+di]
    172e:	07                   	pop    es
    172f:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    1733:	2b 30                	sub    si,WORD PTR [bx+si]
    1735:	30 01                	xor    BYTE PTR [bx+di],al
    1737:	30 05                	xor    BYTE PTR [di],al
    1739:	23 2c                	and    bp,WORD PTR [si]
    173b:	23 23                	and    sp,WORD PTR [bp+di]
    173d:	30 02                	xor    BYTE PTR [bp+si],al
    173f:	23 30                	and    si,WORD PTR [bx+si]
    1741:	55                   	push   bp
    1742:	89 e5                	mov    bp,sp
    1744:	b8 14 03             	mov    ax,0x314
    1747:	9a 44 04 dc 17       	call   0x17dc:0x444
    174c:	81 ec 14 03          	sub    sp,0x314
    1750:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1753:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    1757:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    175b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    175e:	06                   	push   es
    175f:	57                   	push   di
    1760:	9a d5 33 8d 17       	call   0x178d:0x33d5
    1765:	89 c7                	mov    di,ax
    1767:	8e c2                	mov    es,dx
    1769:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    176d:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    1771:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    1775:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    1779:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    177d:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1781:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1785:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1788:	06                   	push   es
    1789:	57                   	push   di
    178a:	9a d5 33 5c 18       	call   0x185c:0x33d5
    178f:	89 c7                	mov    di,ax
    1791:	8e c2                	mov    es,dx
    1793:	06                   	push   es
    1794:	57                   	push   di
    1795:	9a 99 20 67 18       	call   0x1867:0x2099
    179a:	8d be f4 fc          	lea    di,[bp-0x30c]
    179e:	16                   	push   ss
    179f:	57                   	push   di
    17a0:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17a4:	06                   	push   es
    17a5:	57                   	push   di
    17a6:	9a 9f 1a b4 17       	call   0x17b4:0x1a9f
    17ab:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17af:	06                   	push   es
    17b0:	57                   	push   di
    17b1:	9a 5f 1a e4 1b       	call   0x1be4:0x1a5f
    17b6:	89 c7                	mov    di,ax
    17b8:	8e c2                	mov    es,dx
    17ba:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    17be:	06                   	push   es
    17bf:	57                   	push   di
    17c0:	9a 9b 3b 38 1c       	call   0x1c38:0x3b9b
    17c5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17c8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    17cb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17ce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17d1:	bf 58 0a             	mov    di,0xa58
    17d4:	b8 ef 17             	mov    ax,0x17ef
    17d7:	50                   	push   ax
    17d8:	57                   	push   di
    17d9:	9a 55 22 f6 17       	call   0x17f6:0x2255
    17de:	08 c0                	or     al,al
    17e0:	75 03                	jne    0x17e5
    17e2:	e9 bb 01             	jmp    0x19a0
    17e5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17e8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17eb:	bf 58 0a             	mov    di,0xa58
    17ee:	b8 9b 19             	mov    ax,0x199b
    17f1:	50                   	push   ax
    17f2:	57                   	push   di
    17f3:	9a 73 22 15 18       	call   0x1815:0x2273
    17f8:	89 c7                	mov    di,ax
    17fa:	8e c2                	mov    es,dx
    17fc:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1800:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1804:	bf 1b 17             	mov    di,0x171b
    1807:	0e                   	push   cs
    1808:	57                   	push   di
    1809:	8d be fc fd          	lea    di,[bp-0x204]
    180d:	16                   	push   ss
    180e:	57                   	push   di
    180f:	68 ff 00             	push   0xff
    1812:	9a e7 17 4c 18       	call   0x184c:0x17e7
    1817:	8d be f0 fc          	lea    di,[bp-0x310]
    181b:	16                   	push   ss
    181c:	57                   	push   di
    181d:	8d be fc fd          	lea    di,[bp-0x204]
    1821:	16                   	push   ss
    1822:	57                   	push   di
    1823:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1827:	06                   	push   es
    1828:	57                   	push   di
    1829:	26 c4 3d             	les    di,DWORD PTR es:[di]
    182c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1830:	83 ec 0a             	sub    sp,0xa
    1833:	89 e3                	mov    bx,sp
    1835:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1839:	90                   	nop
    183a:	9b                   	fwait
    183b:	9a d4 10 be 18       	call   0x18be:0x10d4
    1840:	8d be fc fe          	lea    di,[bp-0x104]
    1844:	16                   	push   ss
    1845:	57                   	push   di
    1846:	68 ff 00             	push   0xff
    1849:	9a e7 17 7b 18       	call   0x187b:0x17e7
    184e:	8d be fc fe          	lea    di,[bp-0x104]
    1852:	16                   	push   ss
    1853:	57                   	push   di
    1854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1857:	06                   	push   es
    1858:	57                   	push   di
    1859:	9a d5 33 dc 18       	call   0x18dc:0x33d5
    185e:	89 c7                	mov    di,ax
    1860:	8e c2                	mov    es,dx
    1862:	06                   	push   es
    1863:	57                   	push   di
    1864:	9a 03 20 e7 18       	call   0x18e7:0x2003
    1869:	8b d0                	mov    dx,ax
    186b:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    186f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1873:	2d 05 00             	sub    ax,0x5
    1876:	71 05                	jno    0x187d
    1878:	9a 3e 04 95 18       	call   0x1895:0x43e
    187d:	3b c2                	cmp    ax,dx
    187f:	7e 03                	jle    0x1884
    1881:	e9 08 01             	jmp    0x198c
    1884:	bf 26 17             	mov    di,0x1726
    1887:	0e                   	push   cs
    1888:	57                   	push   di
    1889:	8d be fc fd          	lea    di,[bp-0x204]
    188d:	16                   	push   ss
    188e:	57                   	push   di
    188f:	68 ff 00             	push   0xff
    1892:	9a e7 17 cc 18       	call   0x18cc:0x17e7
    1897:	8d be f0 fc          	lea    di,[bp-0x310]
    189b:	16                   	push   ss
    189c:	57                   	push   di
    189d:	8d be fc fd          	lea    di,[bp-0x204]
    18a1:	16                   	push   ss
    18a2:	57                   	push   di
    18a3:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    18a7:	06                   	push   es
    18a8:	57                   	push   di
    18a9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18ac:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    18b0:	83 ec 0a             	sub    sp,0xa
    18b3:	89 e3                	mov    bx,sp
    18b5:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    18b9:	90                   	nop
    18ba:	9b                   	fwait
    18bb:	9a d4 10 20 1a       	call   0x1a20:0x10d4
    18c0:	8d be fc fe          	lea    di,[bp-0x104]
    18c4:	16                   	push   ss
    18c5:	57                   	push   di
    18c6:	68 ff 00             	push   0xff
    18c9:	9a e7 17 fb 18       	call   0x18fb:0x17e7
    18ce:	8d be fc fe          	lea    di,[bp-0x104]
    18d2:	16                   	push   ss
    18d3:	57                   	push   di
    18d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d7:	06                   	push   es
    18d8:	57                   	push   di
    18d9:	9a d5 33 25 19       	call   0x1925:0x33d5
    18de:	89 c7                	mov    di,ax
    18e0:	8e c2                	mov    es,dx
    18e2:	06                   	push   es
    18e3:	57                   	push   di
    18e4:	9a 03 20 30 19       	call   0x1930:0x2003
    18e9:	8b d0                	mov    dx,ax
    18eb:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    18ef:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    18f3:	2d 05 00             	sub    ax,0x5
    18f6:	71 05                	jno    0x18fd
    18f8:	9a 3e 04 15 19       	call   0x1915:0x43e
    18fd:	3b c2                	cmp    ax,dx
    18ff:	7e 03                	jle    0x1904
    1901:	e9 88 00             	jmp    0x198c
    1904:	bf 2e 17             	mov    di,0x172e
    1907:	0e                   	push   cs
    1908:	57                   	push   di
    1909:	8d be fc fd          	lea    di,[bp-0x204]
    190d:	16                   	push   ss
    190e:	57                   	push   di
    190f:	68 ff 00             	push   0xff
    1912:	9a e7 17 44 19       	call   0x1944:0x17e7
    1917:	8d be fc fd          	lea    di,[bp-0x204]
    191b:	16                   	push   ss
    191c:	57                   	push   di
    191d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1920:	06                   	push   es
    1921:	57                   	push   di
    1922:	9a d5 33 3e 1a       	call   0x1a3e:0x33d5
    1927:	89 c7                	mov    di,ax
    1929:	8e c2                	mov    es,dx
    192b:	06                   	push   es
    192c:	57                   	push   di
    192d:	9a 03 20 49 1a       	call   0x1a49:0x2003
    1932:	8b d0                	mov    dx,ax
    1934:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1938:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    193c:	2d 05 00             	sub    ax,0x5
    193f:	71 05                	jno    0x1946
    1941:	9a 3e 04 72 19       	call   0x1972:0x43e
    1946:	3b c2                	cmp    ax,dx
    1948:	b0 00                	mov    al,0x0
    194a:	7e 01                	jle    0x194d
    194c:	40                   	inc    ax
    194d:	8a d0                	mov    dl,al
    194f:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1954:	b0 00                	mov    al,0x0
    1956:	73 01                	jae    0x1959
    1958:	40                   	inc    ax
    1959:	22 c2                	and    al,dl
    195b:	08 c0                	or     al,al
    195d:	74 17                	je     0x1976
    195f:	bf 36 17             	mov    di,0x1736
    1962:	0e                   	push   cs
    1963:	57                   	push   di
    1964:	8d be fc fd          	lea    di,[bp-0x204]
    1968:	16                   	push   ss
    1969:	57                   	push   di
    196a:	68 ff 00             	push   0xff
    196d:	6a 03                	push   0x3
    196f:	9a 16 19 8a 19       	call   0x198a:0x1916
    1974:	eb a1                	jmp    0x1917
    1976:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    197b:	76 0f                	jbe    0x198c
    197d:	8d be fc fd          	lea    di,[bp-0x204]
    1981:	16                   	push   ss
    1982:	57                   	push   di
    1983:	6a 03                	push   0x3
    1985:	6a 01                	push   0x1
    1987:	9a 75 19 b1 19       	call   0x19b1:0x1975
    198c:	8d be fc fd          	lea    di,[bp-0x204]
    1990:	16                   	push   ss
    1991:	57                   	push   di
    1992:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1996:	06                   	push   es
    1997:	57                   	push   di
    1998:	9a f9 60 aa 19       	call   0x19aa:0x60f9
    199d:	e9 ec 01             	jmp    0x1b8c
    19a0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19a3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19a6:	bf c8 07             	mov    di,0x7c8
    19a9:	b8 c4 19             	mov    ax,0x19c4
    19ac:	50                   	push   ax
    19ad:	57                   	push   di
    19ae:	9a 55 22 cb 19       	call   0x19cb:0x2255
    19b3:	08 c0                	or     al,al
    19b5:	75 03                	jne    0x19ba
    19b7:	e9 d2 01             	jmp    0x1b8c
    19ba:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19bd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19c0:	bf c8 07             	mov    di,0x7c8
    19c3:	b8 8a 1b             	mov    ax,0x1b8a
    19c6:	50                   	push   ax
    19c7:	57                   	push   di
    19c8:	9a 73 22 ea 19       	call   0x19ea:0x2273
    19cd:	89 c7                	mov    di,ax
    19cf:	8e c2                	mov    es,dx
    19d1:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    19d5:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    19d9:	bf 38 17             	mov    di,0x1738
    19dc:	0e                   	push   cs
    19dd:	57                   	push   di
    19de:	8d be fc fd          	lea    di,[bp-0x204]
    19e2:	16                   	push   ss
    19e3:	57                   	push   di
    19e4:	68 ff 00             	push   0xff
    19e7:	9a e7 17 2e 1a       	call   0x1a2e:0x17e7
    19ec:	8d be ec fc          	lea    di,[bp-0x314]
    19f0:	16                   	push   ss
    19f1:	57                   	push   di
    19f2:	8d be fc fd          	lea    di,[bp-0x204]
    19f6:	16                   	push   ss
    19f7:	57                   	push   di
    19f8:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    19fc:	06                   	push   es
    19fd:	57                   	push   di
    19fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a01:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a05:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1a09:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1a0d:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1a12:	83 ec 0a             	sub    sp,0xa
    1a15:	89 e3                	mov    bx,sp
    1a17:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1a1b:	90                   	nop
    1a1c:	9b                   	fwait
    1a1d:	9a d4 10 ad 1a       	call   0x1aad:0x10d4
    1a22:	8d be fc fe          	lea    di,[bp-0x104]
    1a26:	16                   	push   ss
    1a27:	57                   	push   di
    1a28:	68 ff 00             	push   0xff
    1a2b:	9a e7 17 5d 1a       	call   0x1a5d:0x17e7
    1a30:	8d be fc fe          	lea    di,[bp-0x104]
    1a34:	16                   	push   ss
    1a35:	57                   	push   di
    1a36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a39:	06                   	push   es
    1a3a:	57                   	push   di
    1a3b:	9a d5 33 cb 1a       	call   0x1acb:0x33d5
    1a40:	89 c7                	mov    di,ax
    1a42:	8e c2                	mov    es,dx
    1a44:	06                   	push   es
    1a45:	57                   	push   di
    1a46:	9a 03 20 d6 1a       	call   0x1ad6:0x2003
    1a4b:	8b d0                	mov    dx,ax
    1a4d:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a51:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1a55:	2d 05 00             	sub    ax,0x5
    1a58:	71 05                	jno    0x1a5f
    1a5a:	9a 3e 04 77 1a       	call   0x1a77:0x43e
    1a5f:	3b c2                	cmp    ax,dx
    1a61:	7e 03                	jle    0x1a66
    1a63:	e9 15 01             	jmp    0x1b7b
    1a66:	bf 3e 17             	mov    di,0x173e
    1a69:	0e                   	push   cs
    1a6a:	57                   	push   di
    1a6b:	8d be fc fd          	lea    di,[bp-0x204]
    1a6f:	16                   	push   ss
    1a70:	57                   	push   di
    1a71:	68 ff 00             	push   0xff
    1a74:	9a e7 17 bb 1a       	call   0x1abb:0x17e7
    1a79:	8d be ec fc          	lea    di,[bp-0x314]
    1a7d:	16                   	push   ss
    1a7e:	57                   	push   di
    1a7f:	8d be fc fd          	lea    di,[bp-0x204]
    1a83:	16                   	push   ss
    1a84:	57                   	push   di
    1a85:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1a89:	06                   	push   es
    1a8a:	57                   	push   di
    1a8b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a8e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a92:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1a96:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1a9a:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1a9f:	83 ec 0a             	sub    sp,0xa
    1aa2:	89 e3                	mov    bx,sp
    1aa4:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1aa8:	90                   	nop
    1aa9:	9b                   	fwait
    1aaa:	9a d4 10 99 1c       	call   0x1c99:0x10d4
    1aaf:	8d be fc fe          	lea    di,[bp-0x104]
    1ab3:	16                   	push   ss
    1ab4:	57                   	push   di
    1ab5:	68 ff 00             	push   0xff
    1ab8:	9a e7 17 ea 1a       	call   0x1aea:0x17e7
    1abd:	8d be fc fe          	lea    di,[bp-0x104]
    1ac1:	16                   	push   ss
    1ac2:	57                   	push   di
    1ac3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac6:	06                   	push   es
    1ac7:	57                   	push   di
    1ac8:	9a d5 33 14 1b       	call   0x1b14:0x33d5
    1acd:	89 c7                	mov    di,ax
    1acf:	8e c2                	mov    es,dx
    1ad1:	06                   	push   es
    1ad2:	57                   	push   di
    1ad3:	9a 03 20 1f 1b       	call   0x1b1f:0x2003
    1ad8:	8b d0                	mov    dx,ax
    1ada:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1ade:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1ae2:	2d 05 00             	sub    ax,0x5
    1ae5:	71 05                	jno    0x1aec
    1ae7:	9a 3e 04 04 1b       	call   0x1b04:0x43e
    1aec:	3b c2                	cmp    ax,dx
    1aee:	7e 03                	jle    0x1af3
    1af0:	e9 88 00             	jmp    0x1b7b
    1af3:	bf 2e 17             	mov    di,0x172e
    1af6:	0e                   	push   cs
    1af7:	57                   	push   di
    1af8:	8d be fc fd          	lea    di,[bp-0x204]
    1afc:	16                   	push   ss
    1afd:	57                   	push   di
    1afe:	68 ff 00             	push   0xff
    1b01:	9a e7 17 33 1b       	call   0x1b33:0x17e7
    1b06:	8d be fc fd          	lea    di,[bp-0x204]
    1b0a:	16                   	push   ss
    1b0b:	57                   	push   di
    1b0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b0f:	06                   	push   es
    1b10:	57                   	push   di
    1b11:	9a d5 33 a0 1b       	call   0x1ba0:0x33d5
    1b16:	89 c7                	mov    di,ax
    1b18:	8e c2                	mov    es,dx
    1b1a:	06                   	push   es
    1b1b:	57                   	push   di
    1b1c:	9a 03 20 ab 1b       	call   0x1bab:0x2003
    1b21:	8b d0                	mov    dx,ax
    1b23:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b27:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b2b:	2d 05 00             	sub    ax,0x5
    1b2e:	71 05                	jno    0x1b35
    1b30:	9a 3e 04 61 1b       	call   0x1b61:0x43e
    1b35:	3b c2                	cmp    ax,dx
    1b37:	b0 00                	mov    al,0x0
    1b39:	7e 01                	jle    0x1b3c
    1b3b:	40                   	inc    ax
    1b3c:	8a d0                	mov    dl,al
    1b3e:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1b43:	b0 00                	mov    al,0x0
    1b45:	73 01                	jae    0x1b48
    1b47:	40                   	inc    ax
    1b48:	22 c2                	and    al,dl
    1b4a:	08 c0                	or     al,al
    1b4c:	74 17                	je     0x1b65
    1b4e:	bf 36 17             	mov    di,0x1736
    1b51:	0e                   	push   cs
    1b52:	57                   	push   di
    1b53:	8d be fc fd          	lea    di,[bp-0x204]
    1b57:	16                   	push   ss
    1b58:	57                   	push   di
    1b59:	68 ff 00             	push   0xff
    1b5c:	6a 03                	push   0x3
    1b5e:	9a 16 19 79 1b       	call   0x1b79:0x1916
    1b63:	eb a1                	jmp    0x1b06
    1b65:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1b6a:	76 0f                	jbe    0x1b7b
    1b6c:	8d be fc fd          	lea    di,[bp-0x204]
    1b70:	16                   	push   ss
    1b71:	57                   	push   di
    1b72:	6a 03                	push   0x3
    1b74:	6a 01                	push   0x1
    1b76:	9a 75 19 d4 1b       	call   0x1bd4:0x1975
    1b7b:	8d be fc fd          	lea    di,[bp-0x204]
    1b7f:	16                   	push   ss
    1b80:	57                   	push   di
    1b81:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1b85:	06                   	push   es
    1b86:	57                   	push   di
    1b87:	9a f9 60 4a 1c       	call   0x1c4a:0x60f9
    1b8c:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b90:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1b94:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1b98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b9b:	06                   	push   es
    1b9c:	57                   	push   di
    1b9d:	9a d5 33 86 24       	call   0x2486:0x33d5
    1ba2:	89 c7                	mov    di,ax
    1ba4:	8e c2                	mov    es,dx
    1ba6:	06                   	push   es
    1ba7:	57                   	push   di
    1ba8:	9a 99 20 0f 28       	call   0x280f:0x2099
    1bad:	c9                   	leave
    1bae:	ca 08 00             	retf   0x8
    1bb1:	0a 23                	or     ah,BYTE PTR [bp+di]
    1bb3:	2c 23                	sub    al,0x23
    1bb5:	23 30                	and    si,WORD PTR [bx+si]
    1bb7:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1bba:	23 23                	and    sp,WORD PTR [bp+di]
    1bbc:	05 23 2c             	add    ax,0x2c23
    1bbf:	23 23                	and    sp,WORD PTR [bp+di]
    1bc1:	30 05                	xor    BYTE PTR [di],al
    1bc3:	23 30                	and    si,WORD PTR [bx+si]
    1bc5:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1bc8:	02 23                	add    ah,BYTE PTR [bp+di]
    1bca:	30 55 89             	xor    BYTE PTR [di-0x77],dl
    1bcd:	e5 b8                	in     ax,0xb8
    1bcf:	10 01                	adc    BYTE PTR [bx+di],al
    1bd1:	9a 44 04 eb 1b       	call   0x1beb:0x444
    1bd6:	81 ec 10 01          	sub    sp,0x110
    1bda:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bdd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1be0:	bf 22 00             	mov    di,0x22
    1be3:	b8 fe 1b             	mov    ax,0x1bfe
    1be6:	50                   	push   ax
    1be7:	57                   	push   di
    1be8:	9a 55 22 05 1c       	call   0x1c05:0x2255
    1bed:	08 c0                	or     al,al
    1bef:	75 03                	jne    0x1bf4
    1bf1:	e9 4e 01             	jmp    0x1d42
    1bf4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bf7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bfa:	bf 22 00             	mov    di,0x22
    1bfd:	b8 1f 1c             	mov    ax,0x1c1f
    1c00:	50                   	push   ax
    1c01:	57                   	push   di
    1c02:	9a 73 22 51 1c       	call   0x1c51:0x2273
    1c07:	89 c7                	mov    di,ax
    1c09:	8e c2                	mov    es,dx
    1c0b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1c0e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1c11:	8d be f8 fe          	lea    di,[bp-0x108]
    1c15:	16                   	push   ss
    1c16:	57                   	push   di
    1c17:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c1a:	06                   	push   es
    1c1b:	57                   	push   di
    1c1c:	9a 9f 1a 29 1c       	call   0x1c29:0x1a9f
    1c21:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c24:	06                   	push   es
    1c25:	57                   	push   di
    1c26:	9a 5f 1a 4c 1d       	call   0x1d4c:0x1a5f
    1c2b:	89 c7                	mov    di,ax
    1c2d:	8e c2                	mov    es,dx
    1c2f:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1c33:	06                   	push   es
    1c34:	57                   	push   di
    1c35:	9a 9b 3b a0 1d       	call   0x1da0:0x3b9b
    1c3a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c3d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c40:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c43:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c46:	bf 58 0a             	mov    di,0xa58
    1c49:	b8 61 1c             	mov    ax,0x1c61
    1c4c:	50                   	push   ax
    1c4d:	57                   	push   di
    1c4e:	9a 55 22 68 1c       	call   0x1c68:0x2255
    1c53:	08 c0                	or     al,al
    1c55:	74 56                	je     0x1cad
    1c57:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c5a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c5d:	bf 58 0a             	mov    di,0xa58
    1c60:	b8 b7 1c             	mov    ax,0x1cb7
    1c63:	50                   	push   ax
    1c64:	57                   	push   di
    1c65:	9a 73 22 be 1c       	call   0x1cbe:0x2273
    1c6a:	89 c7                	mov    di,ax
    1c6c:	8e c2                	mov    es,dx
    1c6e:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1c71:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1c74:	8d be f4 fe          	lea    di,[bp-0x10c]
    1c78:	16                   	push   ss
    1c79:	57                   	push   di
    1c7a:	bf b1 1b             	mov    di,0x1bb1
    1c7d:	0e                   	push   cs
    1c7e:	57                   	push   di
    1c7f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1c82:	06                   	push   es
    1c83:	57                   	push   di
    1c84:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c87:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1c8b:	83 ec 0a             	sub    sp,0xa
    1c8e:	89 e3                	mov    bx,sp
    1c90:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1c94:	90                   	nop
    1c95:	9b                   	fwait
    1c96:	9a d4 10 10 1d       	call   0x1d10:0x10d4
    1c9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c9e:	26 c4 bd 38 04       	les    di,DWORD PTR es:[di+0x438]
    1ca3:	06                   	push   es
    1ca4:	57                   	push   di
    1ca5:	9a 8c 1d 1f 1d       	call   0x1d1f:0x1d8c
    1caa:	e9 95 00             	jmp    0x1d42
    1cad:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1cb0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1cb3:	bf c8 07             	mov    di,0x7c8
    1cb6:	b8 ce 1c             	mov    ax,0x1cce
    1cb9:	50                   	push   ax
    1cba:	57                   	push   di
    1cbb:	9a 55 22 d5 1c       	call   0x1cd5:0x2255
    1cc0:	08 c0                	or     al,al
    1cc2:	74 5f                	je     0x1d23
    1cc4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1cc7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1cca:	bf c8 07             	mov    di,0x7c8
    1ccd:	b8 b2 1d             	mov    ax,0x1db2
    1cd0:	50                   	push   ax
    1cd1:	57                   	push   di
    1cd2:	9a 73 22 53 1d       	call   0x1d53:0x2273
    1cd7:	89 c7                	mov    di,ax
    1cd9:	8e c2                	mov    es,dx
    1cdb:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1cde:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1ce1:	8d be f0 fe          	lea    di,[bp-0x110]
    1ce5:	16                   	push   ss
    1ce6:	57                   	push   di
    1ce7:	bf bc 1b             	mov    di,0x1bbc
    1cea:	0e                   	push   cs
    1ceb:	57                   	push   di
    1cec:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1cef:	06                   	push   es
    1cf0:	57                   	push   di
    1cf1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1cf4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1cf8:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1cfb:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    1cfe:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    1d02:	83 ec 0a             	sub    sp,0xa
    1d05:	89 e3                	mov    bx,sp
    1d07:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1d0b:	90                   	nop
    1d0c:	9b                   	fwait
    1d0d:	9a d4 10 77 25       	call   0x2577:0x10d4
    1d12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d15:	26 c4 bd 38 04       	les    di,DWORD PTR es:[di+0x438]
    1d1a:	06                   	push   es
    1d1b:	57                   	push   di
    1d1c:	9a 8c 1d 40 1d       	call   0x1d40:0x1d8c
    1d21:	eb 1f                	jmp    0x1d42
    1d23:	8d be f8 fe          	lea    di,[bp-0x108]
    1d27:	16                   	push   ss
    1d28:	57                   	push   di
    1d29:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d2c:	06                   	push   es
    1d2d:	57                   	push   di
    1d2e:	9a 24 15 21 20       	call   0x2021:0x1524
    1d33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d36:	26 c4 bd 38 04       	les    di,DWORD PTR es:[di+0x438]
    1d3b:	06                   	push   es
    1d3c:	57                   	push   di
    1d3d:	9a 8c 1d 02 1f       	call   0x1f02:0x1d8c
    1d42:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d45:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d48:	bf 22 00             	mov    di,0x22
    1d4b:	b8 66 1d             	mov    ax,0x1d66
    1d4e:	50                   	push   ax
    1d4f:	57                   	push   di
    1d50:	9a 55 22 6d 1d       	call   0x1d6d:0x2255
    1d55:	08 c0                	or     al,al
    1d57:	75 03                	jne    0x1d5c
    1d59:	e9 d4 00             	jmp    0x1e30
    1d5c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d5f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d62:	bf 22 00             	mov    di,0x22
    1d65:	b8 87 1d             	mov    ax,0x1d87
    1d68:	50                   	push   ax
    1d69:	57                   	push   di
    1d6a:	9a 73 22 b9 1d       	call   0x1db9:0x2273
    1d6f:	89 c7                	mov    di,ax
    1d71:	8e c2                	mov    es,dx
    1d73:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1d76:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1d79:	8d be f8 fe          	lea    di,[bp-0x108]
    1d7d:	16                   	push   ss
    1d7e:	57                   	push   di
    1d7f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d82:	06                   	push   es
    1d83:	57                   	push   di
    1d84:	9a 9f 1a 91 1d       	call   0x1d91:0x1a9f
    1d89:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d8c:	06                   	push   es
    1d8d:	57                   	push   di
    1d8e:	9a 5f 1a 3a 1e       	call   0x1e3a:0x1a5f
    1d93:	89 c7                	mov    di,ax
    1d95:	8e c2                	mov    es,dx
    1d97:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1d9b:	06                   	push   es
    1d9c:	57                   	push   di
    1d9d:	9a 9b 3b 57 20       	call   0x2057:0x3b9b
    1da2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1da5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1da8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1dab:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1dae:	bf 58 0a             	mov    di,0xa58
    1db1:	b8 c9 1d             	mov    ax,0x1dc9
    1db4:	50                   	push   ax
    1db5:	57                   	push   di
    1db6:	9a 55 22 d0 1d       	call   0x1dd0:0x2255
    1dbb:	08 c0                	or     al,al
    1dbd:	74 2e                	je     0x1ded
    1dbf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1dc2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1dc5:	bf 58 0a             	mov    di,0xa58
    1dc8:	b8 e9 1d             	mov    ax,0x1de9
    1dcb:	50                   	push   ax
    1dcc:	57                   	push   di
    1dcd:	9a 73 22 fe 1d       	call   0x1dfe:0x2273
    1dd2:	89 c7                	mov    di,ax
    1dd4:	8e c2                	mov    es,dx
    1dd6:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1dd9:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1ddc:	bf c2 1b             	mov    di,0x1bc2
    1ddf:	0e                   	push   cs
    1de0:	57                   	push   di
    1de1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1de4:	06                   	push   es
    1de5:	57                   	push   di
    1de6:	9a f9 60 f7 1d       	call   0x1df7:0x60f9
    1deb:	eb 43                	jmp    0x1e30
    1ded:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1df0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1df3:	bf c8 07             	mov    di,0x7c8
    1df6:	b8 0e 1e             	mov    ax,0x1e0e
    1df9:	50                   	push   ax
    1dfa:	57                   	push   di
    1dfb:	9a 55 22 15 1e       	call   0x1e15:0x2255
    1e00:	08 c0                	or     al,al
    1e02:	74 2c                	je     0x1e30
    1e04:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e07:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1e0a:	bf c8 07             	mov    di,0x7c8
    1e0d:	b8 2e 1e             	mov    ax,0x1e2e
    1e10:	50                   	push   ax
    1e11:	57                   	push   di
    1e12:	9a 73 22 41 1e       	call   0x1e41:0x2273
    1e17:	89 c7                	mov    di,ax
    1e19:	8e c2                	mov    es,dx
    1e1b:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1e1e:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1e21:	bf c8 1b             	mov    di,0x1bc8
    1e24:	0e                   	push   cs
    1e25:	57                   	push   di
    1e26:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1e29:	06                   	push   es
    1e2a:	57                   	push   di
    1e2b:	9a f9 60 69 20       	call   0x2069:0x60f9
    1e30:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e33:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e36:	bf 26 06             	mov    di,0x626
    1e39:	b8 4e 1e             	mov    ax,0x1e4e
    1e3c:	50                   	push   ax
    1e3d:	57                   	push   di
    1e3e:	9a 55 22 55 1e       	call   0x1e55:0x2255
    1e43:	50                   	push   ax
    1e44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e47:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e4a:	bf a2 0b             	mov    di,0xba2
    1e4d:	b8 62 1e             	mov    ax,0x1e62
    1e50:	50                   	push   ax
    1e51:	57                   	push   di
    1e52:	9a 55 22 69 1e       	call   0x1e69:0x2255
    1e57:	50                   	push   ax
    1e58:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e5b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e5e:	bf 22 00             	mov    di,0x22
    1e61:	b8 cf 1e             	mov    ax,0x1ecf
    1e64:	50                   	push   ax
    1e65:	57                   	push   di
    1e66:	9a 55 22 86 1e       	call   0x1e86:0x2255
    1e6b:	5a                   	pop    dx
    1e6c:	0a c2                	or     al,dl
    1e6e:	5a                   	pop    dx
    1e6f:	0a c2                	or     al,dl
    1e71:	08 c0                	or     al,al
    1e73:	74 50                	je     0x1ec5
    1e75:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e78:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e7b:	bf da 05             	mov    di,0x5da
    1e7e:	b8 7a 29             	mov    ax,0x297a
    1e81:	50                   	push   ax
    1e82:	57                   	push   di
    1e83:	9a 73 22 aa 1e       	call   0x1eaa:0x2273
    1e88:	89 c7                	mov    di,ax
    1e8a:	8e c2                	mov    es,dx
    1e8c:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1e8f:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1e92:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1e96:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    1e9a:	09 d2                	or     dx,dx
    1e9c:	79 07                	jns    0x1ea5
    1e9e:	f7 d2                	not    dx
    1ea0:	f7 d8                	neg    ax
    1ea2:	83 da ff             	sbb    dx,0xffff
    1ea5:	71 05                	jno    0x1eac
    1ea7:	9a 3e 04 b8 1e       	call   0x1eb8:0x43e
    1eac:	f7 d2                	not    dx
    1eae:	f7 d8                	neg    ax
    1eb0:	83 da ff             	sbb    dx,0xffff
    1eb3:	71 05                	jno    0x1eba
    1eb5:	9a 3e 04 d6 1e       	call   0x1ed6:0x43e
    1eba:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ebd:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1ec1:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1ec5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ec8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ecb:	bf 22 00             	mov    di,0x22
    1ece:	b8 e6 1e             	mov    ax,0x1ee6
    1ed1:	50                   	push   ax
    1ed2:	57                   	push   di
    1ed3:	9a 55 22 ed 1e       	call   0x1eed:0x2255
    1ed8:	08 c0                	or     al,al
    1eda:	74 34                	je     0x1f10
    1edc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1edf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ee2:	bf 22 00             	mov    di,0x22
    1ee5:	b8 1a 1f             	mov    ax,0x1f1a
    1ee8:	50                   	push   ax
    1ee9:	57                   	push   di
    1eea:	9a 73 22 21 1f       	call   0x1f21:0x2273
    1eef:	89 c7                	mov    di,ax
    1ef1:	8e c2                	mov    es,dx
    1ef3:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1ef6:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1ef9:	6a ff                	push   0xffff
    1efb:	6a fa                	push   0xfffa
    1efd:	06                   	push   es
    1efe:	57                   	push   di
    1eff:	9a d5 1e 4d 1f       	call   0x1f4d:0x1ed5
    1f04:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f07:	06                   	push   es
    1f08:	57                   	push   di
    1f09:	9a 3f 4a 57 1f       	call   0x1f57:0x4a3f
    1f0e:	eb 49                	jmp    0x1f59
    1f10:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f13:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f16:	bf a2 0b             	mov    di,0xba2
    1f19:	b8 31 1f             	mov    ax,0x1f31
    1f1c:	50                   	push   ax
    1f1d:	57                   	push   di
    1f1e:	9a 55 22 38 1f       	call   0x1f38:0x2255
    1f23:	08 c0                	or     al,al
    1f25:	74 32                	je     0x1f59
    1f27:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f2a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f2d:	bf a2 0b             	mov    di,0xba2
    1f30:	b8 77 1f             	mov    ax,0x1f77
    1f33:	50                   	push   ax
    1f34:	57                   	push   di
    1f35:	9a 73 22 67 1f       	call   0x1f67:0x2273
    1f3a:	89 c7                	mov    di,ax
    1f3c:	8e c2                	mov    es,dx
    1f3e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1f41:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1f44:	6a ff                	push   0xffff
    1f46:	6a fa                	push   0xfffa
    1f48:	06                   	push   es
    1f49:	57                   	push   di
    1f4a:	9a d5 1e aa 1f       	call   0x1faa:0x1ed5
    1f4f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f52:	06                   	push   es
    1f53:	57                   	push   di
    1f54:	9a e7 5b ed 34       	call   0x34ed:0x5be7
    1f59:	c9                   	leave
    1f5a:	ca 08 00             	retf   0x8
    1f5d:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1f60:	e5 b8                	in     ax,0xb8
    1f62:	08 02                	or     BYTE PTR [bp+si],al
    1f64:	9a 44 04 7e 1f       	call   0x1f7e:0x444
    1f69:	81 ec 08 02          	sub    sp,0x208
    1f6d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f70:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f73:	bf a2 0b             	mov    di,0xba2
    1f76:	b8 8b 1f             	mov    ax,0x1f8b
    1f79:	50                   	push   ax
    1f7a:	57                   	push   di
    1f7b:	9a 55 22 92 1f       	call   0x1f92:0x2255
    1f80:	50                   	push   ax
    1f81:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f84:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f87:	bf 22 00             	mov    di,0x22
    1f8a:	b8 d8 1f             	mov    ax,0x1fd8
    1f8d:	50                   	push   ax
    1f8e:	57                   	push   di
    1f8f:	9a 55 22 df 1f       	call   0x1fdf:0x2255
    1f94:	5a                   	pop    dx
    1f95:	0a c2                	or     al,dl
    1f97:	08 c0                	or     al,al
    1f99:	74 11                	je     0x1fac
    1f9b:	6a 00                	push   0x0
    1f9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa0:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    1fa5:	06                   	push   es
    1fa6:	57                   	push   di
    1fa7:	9a 77 1c be 1f       	call   0x1fbe:0x1c77
    1fac:	bf 5d 1f             	mov    di,0x1f5d
    1faf:	0e                   	push   cs
    1fb0:	57                   	push   di
    1fb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb4:	26 c4 bd 38 04       	les    di,DWORD PTR es:[di+0x438]
    1fb9:	06                   	push   es
    1fba:	57                   	push   di
    1fbb:	9a 8c 1d d8 21       	call   0x21d8:0x1d8c
    1fc0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fc3:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    1fc9:	75 03                	jne    0x1fce
    1fcb:	e9 9e 03             	jmp    0x236c
    1fce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1fd1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fd4:	bf 22 00             	mov    di,0x22
    1fd7:	b8 f2 1f             	mov    ax,0x1ff2
    1fda:	50                   	push   ax
    1fdb:	57                   	push   di
    1fdc:	9a 55 22 f9 1f       	call   0x1ff9:0x2255
    1fe1:	08 c0                	or     al,al
    1fe3:	75 03                	jne    0x1fe8
    1fe5:	e9 9d 01             	jmp    0x2185
    1fe8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1feb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fee:	bf 22 00             	mov    di,0x22
    1ff1:	b8 0a 20             	mov    ax,0x200a
    1ff4:	50                   	push   ax
    1ff5:	57                   	push   di
    1ff6:	9a 73 22 70 20       	call   0x2070:0x2273
    1ffb:	89 c7                	mov    di,ax
    1ffd:	8e c2                	mov    es,dx
    1fff:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2002:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2005:	06                   	push   es
    2006:	57                   	push   di
    2007:	9a e4 1a 3e 20       	call   0x203e:0x1ae4
    200c:	08 c0                	or     al,al
    200e:	74 03                	je     0x2013
    2010:	e9 72 01             	jmp    0x2185
    2013:	8d be f8 fe          	lea    di,[bp-0x108]
    2017:	16                   	push   ss
    2018:	57                   	push   di
    2019:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    201c:	06                   	push   es
    201d:	57                   	push   di
    201e:	9a d8 14 fb 23       	call   0x23fb:0x14d8
    2023:	83 c4 04             	add    sp,0x4
    2026:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    202b:	74 03                	je     0x2030
    202d:	e9 36 01             	jmp    0x2166
    2030:	8d be f8 fd          	lea    di,[bp-0x208]
    2034:	16                   	push   ss
    2035:	57                   	push   di
    2036:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2039:	06                   	push   es
    203a:	57                   	push   di
    203b:	9a 9f 1a 48 20       	call   0x2048:0x1a9f
    2040:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2043:	06                   	push   es
    2044:	57                   	push   di
    2045:	9a 5f 1a a9 20       	call   0x20a9:0x1a5f
    204a:	89 c7                	mov    di,ax
    204c:	8e c2                	mov    es,dx
    204e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2052:	06                   	push   es
    2053:	57                   	push   di
    2054:	9a 9b 3b 0e 22       	call   0x220e:0x3b9b
    2059:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    205c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    205f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2062:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2065:	bf 58 0a             	mov    di,0xa58
    2068:	b8 80 20             	mov    ax,0x2080
    206b:	50                   	push   ax
    206c:	57                   	push   di
    206d:	9a 55 22 87 20       	call   0x2087:0x2255
    2072:	08 c0                	or     al,al
    2074:	74 45                	je     0x20bb
    2076:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2079:	ff 76 fc             	push   WORD PTR [bp-0x4]
    207c:	bf 58 0a             	mov    di,0xa58
    207f:	b8 c5 20             	mov    ax,0x20c5
    2082:	50                   	push   ax
    2083:	57                   	push   di
    2084:	9a 73 22 cc 20       	call   0x20cc:0x2273
    2089:	89 c7                	mov    di,ax
    208b:	8e c2                	mov    es,dx
    208d:	06                   	push   es
    208e:	57                   	push   di
    208f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2092:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2096:	83 ec 08             	sub    sp,0x8
    2099:	89 e3                	mov    bx,sp
    209b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    209f:	90                   	nop
    20a0:	9b                   	fwait
    20a1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20a4:	06                   	push   es
    20a5:	57                   	push   di
    20a6:	9a 18 1b 05 21       	call   0x2105:0x1b18
    20ab:	89 c7                	mov    di,ax
    20ad:	8e c2                	mov    es,dx
    20af:	06                   	push   es
    20b0:	57                   	push   di
    20b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20b4:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    20b8:	e9 ab 00             	jmp    0x2166
    20bb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20be:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20c1:	bf 67 0c             	mov    di,0xc67
    20c4:	b8 dc 20             	mov    ax,0x20dc
    20c7:	50                   	push   ax
    20c8:	57                   	push   di
    20c9:	9a 55 22 e3 20       	call   0x20e3:0x2255
    20ce:	08 c0                	or     al,al
    20d0:	74 44                	je     0x2116
    20d2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20d5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20d8:	bf 67 0c             	mov    di,0xc67
    20db:	b8 20 21             	mov    ax,0x2120
    20de:	50                   	push   ax
    20df:	57                   	push   di
    20e0:	9a 73 22 27 21       	call   0x2127:0x2273
    20e5:	89 c7                	mov    di,ax
    20e7:	8e c2                	mov    es,dx
    20e9:	06                   	push   es
    20ea:	57                   	push   di
    20eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20ee:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    20f2:	83 ec 08             	sub    sp,0x8
    20f5:	89 e3                	mov    bx,sp
    20f7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    20fb:	90                   	nop
    20fc:	9b                   	fwait
    20fd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2100:	06                   	push   es
    2101:	57                   	push   di
    2102:	9a 18 1b 57 21       	call   0x2157:0x1b18
    2107:	89 c7                	mov    di,ax
    2109:	8e c2                	mov    es,dx
    210b:	06                   	push   es
    210c:	57                   	push   di
    210d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2110:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2114:	eb 50                	jmp    0x2166
    2116:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2119:	ff 76 fc             	push   WORD PTR [bp-0x4]
    211c:	bf c8 07             	mov    di,0x7c8
    211f:	b8 37 21             	mov    ax,0x2137
    2122:	50                   	push   ax
    2123:	57                   	push   di
    2124:	9a 55 22 3e 21       	call   0x213e:0x2255
    2129:	08 c0                	or     al,al
    212b:	74 39                	je     0x2166
    212d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2130:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2133:	bf c8 07             	mov    di,0x7c8
    2136:	b8 20 22             	mov    ax,0x2220
    2139:	50                   	push   ax
    213a:	57                   	push   di
    213b:	9a 73 22 77 21       	call   0x2177:0x2273
    2140:	89 c7                	mov    di,ax
    2142:	8e c2                	mov    es,dx
    2144:	06                   	push   es
    2145:	57                   	push   di
    2146:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2149:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    214d:	52                   	push   dx
    214e:	50                   	push   ax
    214f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2152:	06                   	push   es
    2153:	57                   	push   di
    2154:	9a 18 1b 70 21       	call   0x2170:0x1b18
    2159:	89 c7                	mov    di,ax
    215b:	8e c2                	mov    es,dx
    215d:	06                   	push   es
    215e:	57                   	push   di
    215f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2162:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    2166:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2169:	ff 76 0a             	push   WORD PTR [bp+0xa]
    216c:	bf 22 00             	mov    di,0x22
    216f:	b8 8f 21             	mov    ax,0x218f
    2172:	50                   	push   ax
    2173:	57                   	push   di
    2174:	9a 73 22 96 21       	call   0x2196:0x2273
    2179:	52                   	push   dx
    217a:	50                   	push   ax
    217b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    217e:	06                   	push   es
    217f:	57                   	push   di
    2180:	9a 41 17 74 23       	call   0x2374:0x1741
    2185:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2188:	ff 76 0a             	push   WORD PTR [bp+0xa]
    218b:	bf a2 0b             	mov    di,0xba2
    218e:	b8 a9 21             	mov    ax,0x21a9
    2191:	50                   	push   ax
    2192:	57                   	push   di
    2193:	9a 55 22 b0 21       	call   0x21b0:0x2255
    2198:	08 c0                	or     al,al
    219a:	75 03                	jne    0x219f
    219c:	e9 7e 01             	jmp    0x231d
    219f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    21a2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    21a5:	bf a2 0b             	mov    di,0xba2
    21a8:	b8 c1 21             	mov    ax,0x21c1
    21ab:	50                   	push   ax
    21ac:	57                   	push   di
    21ad:	9a 73 22 27 22       	call   0x2227:0x2273
    21b2:	89 c7                	mov    di,ax
    21b4:	8e c2                	mov    es,dx
    21b6:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    21b9:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    21bc:	06                   	push   es
    21bd:	57                   	push   di
    21be:	9a d7 2a f5 21       	call   0x21f5:0x2ad7
    21c3:	08 c0                	or     al,al
    21c5:	74 03                	je     0x21ca
    21c7:	e9 53 01             	jmp    0x231d
    21ca:	8d be f8 fe          	lea    di,[bp-0x108]
    21ce:	16                   	push   ss
    21cf:	57                   	push   di
    21d0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    21d3:	06                   	push   es
    21d4:	57                   	push   di
    21d5:	9a 53 1d a1 23       	call   0x23a1:0x1d53
    21da:	83 c4 04             	add    sp,0x4
    21dd:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    21e2:	74 03                	je     0x21e7
    21e4:	e9 36 01             	jmp    0x231d
    21e7:	8d be f8 fd          	lea    di,[bp-0x208]
    21eb:	16                   	push   ss
    21ec:	57                   	push   di
    21ed:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    21f0:	06                   	push   es
    21f1:	57                   	push   di
    21f2:	9a 92 2a ff 21       	call   0x21ff:0x2a92
    21f7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    21fa:	06                   	push   es
    21fb:	57                   	push   di
    21fc:	9a 52 2a 60 22       	call   0x2260:0x2a52
    2201:	89 c7                	mov    di,ax
    2203:	8e c2                	mov    es,dx
    2205:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2209:	06                   	push   es
    220a:	57                   	push   di
    220b:	9a 9b 3b 0d 25       	call   0x250d:0x3b9b
    2210:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2213:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2216:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2219:	ff 76 fc             	push   WORD PTR [bp-0x4]
    221c:	bf 58 0a             	mov    di,0xa58
    221f:	b8 37 22             	mov    ax,0x2237
    2222:	50                   	push   ax
    2223:	57                   	push   di
    2224:	9a 55 22 3e 22       	call   0x223e:0x2255
    2229:	08 c0                	or     al,al
    222b:	74 45                	je     0x2272
    222d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2230:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2233:	bf 58 0a             	mov    di,0xa58
    2236:	b8 7c 22             	mov    ax,0x227c
    2239:	50                   	push   ax
    223a:	57                   	push   di
    223b:	9a 73 22 83 22       	call   0x2283:0x2273
    2240:	89 c7                	mov    di,ax
    2242:	8e c2                	mov    es,dx
    2244:	06                   	push   es
    2245:	57                   	push   di
    2246:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2249:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    224d:	83 ec 08             	sub    sp,0x8
    2250:	89 e3                	mov    bx,sp
    2252:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2256:	90                   	nop
    2257:	9b                   	fwait
    2258:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    225b:	06                   	push   es
    225c:	57                   	push   di
    225d:	9a 0b 2b bc 22       	call   0x22bc:0x2b0b
    2262:	89 c7                	mov    di,ax
    2264:	8e c2                	mov    es,dx
    2266:	06                   	push   es
    2267:	57                   	push   di
    2268:	26 c4 3d             	les    di,DWORD PTR es:[di]
    226b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    226f:	e9 ab 00             	jmp    0x231d
    2272:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2275:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2278:	bf 67 0c             	mov    di,0xc67
    227b:	b8 93 22             	mov    ax,0x2293
    227e:	50                   	push   ax
    227f:	57                   	push   di
    2280:	9a 55 22 9a 22       	call   0x229a:0x2255
    2285:	08 c0                	or     al,al
    2287:	74 44                	je     0x22cd
    2289:	ff 76 fe             	push   WORD PTR [bp-0x2]
    228c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    228f:	bf 67 0c             	mov    di,0xc67
    2292:	b8 d7 22             	mov    ax,0x22d7
    2295:	50                   	push   ax
    2296:	57                   	push   di
    2297:	9a 73 22 de 22       	call   0x22de:0x2273
    229c:	89 c7                	mov    di,ax
    229e:	8e c2                	mov    es,dx
    22a0:	06                   	push   es
    22a1:	57                   	push   di
    22a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22a5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    22a9:	83 ec 08             	sub    sp,0x8
    22ac:	89 e3                	mov    bx,sp
    22ae:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    22b2:	90                   	nop
    22b3:	9b                   	fwait
    22b4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22b7:	06                   	push   es
    22b8:	57                   	push   di
    22b9:	9a 0b 2b 0e 23       	call   0x230e:0x2b0b
    22be:	89 c7                	mov    di,ax
    22c0:	8e c2                	mov    es,dx
    22c2:	06                   	push   es
    22c3:	57                   	push   di
    22c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22c7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    22cb:	eb 50                	jmp    0x231d
    22cd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22d0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22d3:	bf c8 07             	mov    di,0x7c8
    22d6:	b8 ee 22             	mov    ax,0x22ee
    22d9:	50                   	push   ax
    22da:	57                   	push   di
    22db:	9a 55 22 f5 22       	call   0x22f5:0x2255
    22e0:	08 c0                	or     al,al
    22e2:	74 39                	je     0x231d
    22e4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22e7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22ea:	bf c8 07             	mov    di,0x7c8
    22ed:	b8 23 25             	mov    ax,0x2523
    22f0:	50                   	push   ax
    22f1:	57                   	push   di
    22f2:	9a 73 22 2e 23       	call   0x232e:0x2273
    22f7:	89 c7                	mov    di,ax
    22f9:	8e c2                	mov    es,dx
    22fb:	06                   	push   es
    22fc:	57                   	push   di
    22fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2300:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2304:	52                   	push   dx
    2305:	50                   	push   ax
    2306:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2309:	06                   	push   es
    230a:	57                   	push   di
    230b:	9a 0b 2b b8 23       	call   0x23b8:0x2b0b
    2310:	89 c7                	mov    di,ax
    2312:	8e c2                	mov    es,dx
    2314:	06                   	push   es
    2315:	57                   	push   di
    2316:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2319:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    231d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2320:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2323:	bf eb 03             	mov    di,0x3eb
    2326:	b8 3e 23             	mov    ax,0x233e
    2329:	50                   	push   ax
    232a:	57                   	push   di
    232b:	9a 55 22 45 23       	call   0x2345:0x2255
    2330:	08 c0                	or     al,al
    2332:	74 38                	je     0x236c
    2334:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2337:	ff 76 0a             	push   WORD PTR [bp+0xa]
    233a:	bf eb 03             	mov    di,0x3eb
    233d:	b8 5e 23             	mov    ax,0x235e
    2340:	50                   	push   ax
    2341:	57                   	push   di
    2342:	9a 73 22 83 23       	call   0x2383:0x2273
    2347:	89 c7                	mov    di,ax
    2349:	8e c2                	mov    es,dx
    234b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    234e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2351:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    2357:	75 13                	jne    0x236c
    2359:	06                   	push   es
    235a:	57                   	push   di
    235b:	9a 33 17 6a 23       	call   0x236a:0x1733
    2360:	52                   	push   dx
    2361:	50                   	push   ax
    2362:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2365:	06                   	push   es
    2366:	57                   	push   di
    2367:	9a 8b 17 0c 27       	call   0x270c:0x178b
    236c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    236f:	06                   	push   es
    2370:	57                   	push   di
    2371:	9a f5 3e 35 2c       	call   0x2c35:0x3ef5
    2376:	c9                   	leave
    2377:	ca 08 00             	retf   0x8
    237a:	55                   	push   bp
    237b:	89 e5                	mov    bp,sp
    237d:	b8 04 01             	mov    ax,0x104
    2380:	9a 44 04 bf 23       	call   0x23bf:0x444
    2385:	81 ec 04 01          	sub    sp,0x104
    2389:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    238c:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    2390:	75 13                	jne    0x23a5
    2392:	6a 00                	push   0x0
    2394:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2397:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    239c:	06                   	push   es
    239d:	57                   	push   di
    239e:	9a 77 1c 0a 24       	call   0x240a:0x1c77
    23a3:	eb 67                	jmp    0x240c
    23a5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    23a8:	26 83 3d 09          	cmp    WORD PTR es:[di],0x9
    23ac:	74 5e                	je     0x240c
    23ae:	ff 76 12             	push   WORD PTR [bp+0x12]
    23b1:	ff 76 10             	push   WORD PTR [bp+0x10]
    23b4:	bf 22 00             	mov    di,0x22
    23b7:	b8 cf 23             	mov    ax,0x23cf
    23ba:	50                   	push   ax
    23bb:	57                   	push   di
    23bc:	9a 55 22 d6 23       	call   0x23d6:0x2255
    23c1:	08 c0                	or     al,al
    23c3:	74 47                	je     0x240c
    23c5:	ff 76 12             	push   WORD PTR [bp+0x12]
    23c8:	ff 76 10             	push   WORD PTR [bp+0x10]
    23cb:	bf 22 00             	mov    di,0x22
    23ce:	b8 e7 23             	mov    ax,0x23e7
    23d1:	50                   	push   ax
    23d2:	57                   	push   di
    23d3:	9a 73 22 2c 24       	call   0x242c:0x2273
    23d8:	89 c7                	mov    di,ax
    23da:	8e c2                	mov    es,dx
    23dc:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    23df:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    23e2:	06                   	push   es
    23e3:	57                   	push   di
    23e4:	9a e4 1a b5 24       	call   0x24b5:0x1ae4
    23e9:	08 c0                	or     al,al
    23eb:	75 1f                	jne    0x240c
    23ed:	8d be fc fe          	lea    di,[bp-0x104]
    23f1:	16                   	push   ss
    23f2:	57                   	push   di
    23f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23f6:	06                   	push   es
    23f7:	57                   	push   di
    23f8:	9a 24 15 18 26       	call   0x2618:0x1524
    23fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2400:	26 c4 bd 38 04       	les    di,DWORD PTR es:[di+0x438]
    2405:	06                   	push   es
    2406:	57                   	push   di
    2407:	9a 8c 1d 45 24       	call   0x2445:0x1d8c
    240c:	c9                   	leave
    240d:	ca 0e 00             	retf   0xe
    2410:	0a 23                	or     ah,BYTE PTR [bp+di]
    2412:	2c 23                	sub    al,0x23
    2414:	23 30                	and    si,WORD PTR [bx+si]
    2416:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    2419:	23 23                	and    sp,WORD PTR [bp+di]
    241b:	05 23 2c             	add    ax,0x2c23
    241e:	23 23                	and    sp,WORD PTR [bp+di]
    2420:	30 01                	xor    BYTE PTR [bx+di],al
    2422:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2425:	e5 b8                	in     ax,0xb8
    2427:	14 02                	adc    al,0x2
    2429:	9a 44 04 4c 24       	call   0x244c:0x444
    242e:	81 ec 14 02          	sub    sp,0x214
    2432:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2435:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    2439:	75 4d                	jne    0x2488
    243b:	ff 76 12             	push   WORD PTR [bp+0x12]
    243e:	ff 76 10             	push   WORD PTR [bp+0x10]
    2441:	bf c1 05             	mov    di,0x5c1
    2444:	b8 66 24             	mov    ax,0x2466
    2447:	50                   	push   ax
    2448:	57                   	push   di
    2449:	9a 55 22 6d 24       	call   0x246d:0x2255
    244e:	08 c0                	or     al,al
    2450:	74 36                	je     0x2488
    2452:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2455:	31 c0                	xor    ax,ax
    2457:	26 89 05             	mov    WORD PTR es:[di],ax
    245a:	6a 08                	push   0x8
    245c:	ff 76 12             	push   WORD PTR [bp+0x12]
    245f:	ff 76 10             	push   WORD PTR [bp+0x10]
    2462:	bf c1 05             	mov    di,0x5c1
    2465:	b8 61 26             	mov    ax,0x2661
    2468:	50                   	push   ax
    2469:	57                   	push   di
    246a:	9a 73 22 bc 24       	call   0x24bc:0x2273
    246f:	89 c7                	mov    di,ax
    2471:	8e c2                	mov    es,dx
    2473:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    2478:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    247d:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2481:	06                   	push   es
    2482:	57                   	push   di
    2483:	9a b2 77 e8 27       	call   0x27e8:0x77b2
    2488:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    248b:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    248f:	74 03                	je     0x2494
    2491:	e9 c4 04             	jmp    0x2958
    2494:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2497:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    249c:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    24a1:	74 03                	je     0x24a6
    24a3:	e9 b2 04             	jmp    0x2958
    24a6:	c6 86 fc fe 00       	mov    BYTE PTR [bp-0x104],0x0
    24ab:	ff 76 12             	push   WORD PTR [bp+0x12]
    24ae:	ff 76 10             	push   WORD PTR [bp+0x10]
    24b1:	bf 22 00             	mov    di,0x22
    24b4:	b8 cf 24             	mov    ax,0x24cf
    24b7:	50                   	push   ax
    24b8:	57                   	push   di
    24b9:	9a 55 22 d6 24       	call   0x24d6:0x2255
    24be:	08 c0                	or     al,al
    24c0:	75 03                	jne    0x24c5
    24c2:	e9 a4 01             	jmp    0x2669
    24c5:	ff 76 12             	push   WORD PTR [bp+0x12]
    24c8:	ff 76 10             	push   WORD PTR [bp+0x10]
    24cb:	bf 22 00             	mov    di,0x22
    24ce:	b8 f3 24             	mov    ax,0x24f3
    24d1:	50                   	push   ax
    24d2:	57                   	push   di
    24d3:	9a 73 22 2a 25       	call   0x252a:0x2273
    24d8:	89 c7                	mov    di,ax
    24da:	8e c2                	mov    es,dx
    24dc:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    24e0:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    24e4:	8d be f4 fd          	lea    di,[bp-0x20c]
    24e8:	16                   	push   ss
    24e9:	57                   	push   di
    24ea:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24ee:	06                   	push   es
    24ef:	57                   	push   di
    24f0:	9a 9f 1a fe 24       	call   0x24fe:0x1a9f
    24f5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24f9:	06                   	push   es
    24fa:	57                   	push   di
    24fb:	9a 5f 1a 73 26       	call   0x2673:0x1a5f
    2500:	89 c7                	mov    di,ax
    2502:	8e c2                	mov    es,dx
    2504:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2508:	06                   	push   es
    2509:	57                   	push   di
    250a:	9a 9b 3b e6 30       	call   0x30e6:0x3b9b
    250f:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    2513:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    2517:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    251b:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    251f:	bf 58 0a             	mov    di,0xa58
    2522:	b8 3c 25             	mov    ax,0x253c
    2525:	50                   	push   ax
    2526:	57                   	push   di
    2527:	9a 55 22 43 25       	call   0x2543:0x2255
    252c:	08 c0                	or     al,al
    252e:	74 5a                	je     0x258a
    2530:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    2534:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    2538:	bf 58 0a             	mov    di,0xa58
    253b:	b8 96 25             	mov    ax,0x2596
    253e:	50                   	push   ax
    253f:	57                   	push   di
    2540:	9a 73 22 85 25       	call   0x2585:0x2273
    2545:	89 c7                	mov    di,ax
    2547:	8e c2                	mov    es,dx
    2549:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    254d:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    2551:	8d be f0 fd          	lea    di,[bp-0x210]
    2555:	16                   	push   ss
    2556:	57                   	push   di
    2557:	bf 10 24             	mov    di,0x2410
    255a:	0e                   	push   cs
    255b:	57                   	push   di
    255c:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    2560:	06                   	push   es
    2561:	57                   	push   di
    2562:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2565:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2569:	83 ec 0a             	sub    sp,0xa
    256c:	89 e3                	mov    bx,sp
    256e:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2572:	90                   	nop
    2573:	9b                   	fwait
    2574:	9a d4 10 f7 25       	call   0x25f7:0x10d4
    2579:	8d be fc fe          	lea    di,[bp-0x104]
    257d:	16                   	push   ss
    257e:	57                   	push   di
    257f:	68 ff 00             	push   0xff
    2582:	9a e7 17 9d 25       	call   0x259d:0x17e7
    2587:	e9 9e 00             	jmp    0x2628
    258a:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    258e:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    2592:	bf c8 07             	mov    di,0x7c8
    2595:	b8 af 25             	mov    ax,0x25af
    2598:	50                   	push   ax
    2599:	57                   	push   di
    259a:	9a 55 22 b6 25       	call   0x25b6:0x2255
    259f:	08 c0                	or     al,al
    25a1:	74 66                	je     0x2609
    25a3:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    25a7:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    25ab:	bf c8 07             	mov    di,0x7c8
    25ae:	b8 bd 31             	mov    ax,0x31bd
    25b1:	50                   	push   ax
    25b2:	57                   	push   di
    25b3:	9a 73 22 05 26       	call   0x2605:0x2273
    25b8:	89 c7                	mov    di,ax
    25ba:	8e c2                	mov    es,dx
    25bc:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    25c0:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    25c4:	8d be ec fd          	lea    di,[bp-0x214]
    25c8:	16                   	push   ss
    25c9:	57                   	push   di
    25ca:	bf 1b 24             	mov    di,0x241b
    25cd:	0e                   	push   cs
    25ce:	57                   	push   di
    25cf:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    25d3:	06                   	push   es
    25d4:	57                   	push   di
    25d5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25d8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    25dc:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    25e0:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    25e4:	9b db 86 ec fe       	fild   DWORD PTR [bp-0x114]
    25e9:	83 ec 0a             	sub    sp,0xa
    25ec:	89 e3                	mov    bx,sp
    25ee:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    25f2:	90                   	nop
    25f3:	9b                   	fwait
    25f4:	9a d4 10 51 27       	call   0x2751:0x10d4
    25f9:	8d be fc fe          	lea    di,[bp-0x104]
    25fd:	16                   	push   ss
    25fe:	57                   	push   di
    25ff:	68 ff 00             	push   0xff
    2602:	9a e7 17 26 26       	call   0x2626:0x17e7
    2607:	eb 1f                	jmp    0x2628
    2609:	8d be f4 fd          	lea    di,[bp-0x20c]
    260d:	16                   	push   ss
    260e:	57                   	push   di
    260f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2613:	06                   	push   es
    2614:	57                   	push   di
    2615:	9a 24 15 ff ff       	call   0xffff:0x1524
    261a:	8d be fc fe          	lea    di,[bp-0x104]
    261e:	16                   	push   ss
    261f:	57                   	push   di
    2620:	68 ff 00             	push   0xff
    2623:	9a e7 17 38 26       	call   0x2638:0x17e7
    2628:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    262c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2630:	2d 04 00             	sub    ax,0x4
    2633:	71 05                	jno    0x263a
    2635:	9a 3e 04 4d 26       	call   0x264d:0x43e
    263a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    263d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2641:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2645:	2d 04 00             	sub    ax,0x4
    2648:	71 05                	jno    0x264f
    264a:	9a 3e 04 7a 26       	call   0x267a:0x43e
    264f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2652:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2655:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2658:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    265c:	06                   	push   es
    265d:	57                   	push   di
    265e:	9a d4 19 b1 26       	call   0x26b1:0x19d4
    2663:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2666:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2669:	ff 76 12             	push   WORD PTR [bp+0x12]
    266c:	ff 76 10             	push   WORD PTR [bp+0x10]
    266f:	bf a2 0b             	mov    di,0xba2
    2672:	b8 8d 26             	mov    ax,0x268d
    2675:	50                   	push   ax
    2676:	57                   	push   di
    2677:	9a 55 22 94 26       	call   0x2694:0x2255
    267c:	08 c0                	or     al,al
    267e:	75 03                	jne    0x2683
    2680:	e9 7f 00             	jmp    0x2702
    2683:	ff 76 12             	push   WORD PTR [bp+0x12]
    2686:	ff 76 10             	push   WORD PTR [bp+0x10]
    2689:	bf a2 0b             	mov    di,0xba2
    268c:	b8 ae 29             	mov    ax,0x29ae
    268f:	50                   	push   ax
    2690:	57                   	push   di
    2691:	9a 73 22 bf 26       	call   0x26bf:0x2273
    2696:	89 c7                	mov    di,ax
    2698:	8e c2                	mov    es,dx
    269a:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    269e:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    26a2:	8d be f4 fd          	lea    di,[bp-0x20c]
    26a6:	16                   	push   ss
    26a7:	57                   	push   di
    26a8:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26ac:	06                   	push   es
    26ad:	57                   	push   di
    26ae:	9a 53 1d fa 26       	call   0x26fa:0x1d53
    26b3:	8d be fc fe          	lea    di,[bp-0x104]
    26b7:	16                   	push   ss
    26b8:	57                   	push   di
    26b9:	68 ff 00             	push   0xff
    26bc:	9a e7 17 d1 26       	call   0x26d1:0x17e7
    26c1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26c5:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    26c9:	2d 04 00             	sub    ax,0x4
    26cc:	71 05                	jno    0x26d3
    26ce:	9a 3e 04 e6 26       	call   0x26e6:0x43e
    26d3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26d6:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26da:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    26de:	2d 04 00             	sub    ax,0x4
    26e1:	71 05                	jno    0x26e8
    26e3:	9a 3e 04 13 27       	call   0x2713:0x43e
    26e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26eb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26ee:	ff 76 fc             	push   WORD PTR [bp-0x4]
    26f1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26f5:	06                   	push   es
    26f6:	57                   	push   di
    26f7:	9a d4 19 9a 27       	call   0x279a:0x19d4
    26fc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26ff:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2702:	ff 76 12             	push   WORD PTR [bp+0x12]
    2705:	ff 76 10             	push   WORD PTR [bp+0x10]
    2708:	bf eb 03             	mov    di,0x3eb
    270b:	b8 26 27             	mov    ax,0x2726
    270e:	50                   	push   ax
    270f:	57                   	push   di
    2710:	9a 55 22 2d 27       	call   0x272d:0x2255
    2715:	08 c0                	or     al,al
    2717:	75 03                	jne    0x271c
    2719:	e9 86 00             	jmp    0x27a2
    271c:	ff 76 12             	push   WORD PTR [bp+0x12]
    271f:	ff 76 10             	push   WORD PTR [bp+0x10]
    2722:	bf eb 03             	mov    di,0x3eb
    2725:	b8 4a 27             	mov    ax,0x274a
    2728:	50                   	push   ax
    2729:	57                   	push   di
    272a:	9a 73 22 5f 27       	call   0x275f:0x2273
    272f:	89 c7                	mov    di,ax
    2731:	8e c2                	mov    es,dx
    2733:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2737:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    273b:	8d be f4 fd          	lea    di,[bp-0x20c]
    273f:	16                   	push   ss
    2740:	57                   	push   di
    2741:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2745:	06                   	push   es
    2746:	57                   	push   di
    2747:	9a 33 17 2c 34       	call   0x342c:0x1733
    274c:	52                   	push   dx
    274d:	50                   	push   ax
    274e:	9a a9 08 23 3c       	call   0x3c23:0x8a9
    2753:	8d be fc fe          	lea    di,[bp-0x104]
    2757:	16                   	push   ss
    2758:	57                   	push   di
    2759:	68 ff 00             	push   0xff
    275c:	9a e7 17 71 27       	call   0x2771:0x17e7
    2761:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2765:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2769:	2d 04 00             	sub    ax,0x4
    276c:	71 05                	jno    0x2773
    276e:	9a 3e 04 86 27       	call   0x2786:0x43e
    2773:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2776:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    277a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    277e:	2d 04 00             	sub    ax,0x4
    2781:	71 05                	jno    0x2788
    2783:	9a 3e 04 ba 27       	call   0x27ba:0x43e
    2788:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    278b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    278e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2791:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2795:	06                   	push   es
    2796:	57                   	push   di
    2797:	9a d4 19 de 27       	call   0x27de:0x19d4
    279c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    279f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    27a2:	80 be fc fe 00       	cmp    BYTE PTR [bp-0x104],0x0
    27a7:	77 03                	ja     0x27ac
    27a9:	e9 ac 01             	jmp    0x2958
    27ac:	8d be f8 fd          	lea    di,[bp-0x208]
    27b0:	16                   	push   ss
    27b1:	57                   	push   di
    27b2:	bf 21 24             	mov    di,0x2421
    27b5:	0e                   	push   cs
    27b6:	57                   	push   di
    27b7:	9a cd 17 c5 27       	call   0x27c5:0x17cd
    27bc:	8d be fc fe          	lea    di,[bp-0x104]
    27c0:	16                   	push   ss
    27c1:	57                   	push   di
    27c2:	9a 4c 18 cf 27       	call   0x27cf:0x184c
    27c7:	bf 21 24             	mov    di,0x2421
    27ca:	0e                   	push   cs
    27cb:	57                   	push   di
    27cc:	9a 4c 18 6b 28       	call   0x286b:0x184c
    27d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d4:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    27d9:	06                   	push   es
    27da:	57                   	push   di
    27db:	9a 8c 1d 24 28       	call   0x2824:0x1d8c
    27e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e3:	06                   	push   es
    27e4:	57                   	push   di
    27e5:	9a d5 33 e0 2d       	call   0x2de0:0x33d5
    27ea:	89 c7                	mov    di,ax
    27ec:	8e c2                	mov    es,dx
    27ee:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    27f2:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    27f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27f9:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    27fe:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2802:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2806:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    280a:	06                   	push   es
    280b:	57                   	push   di
    280c:	9a 99 20 2f 28       	call   0x282f:0x2099
    2811:	8d be f4 fd          	lea    di,[bp-0x20c]
    2815:	16                   	push   ss
    2816:	57                   	push   di
    2817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    281a:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    281f:	06                   	push   es
    2820:	57                   	push   di
    2821:	9a 53 1d 3f 28       	call   0x283f:0x1d53
    2826:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    282a:	06                   	push   es
    282b:	57                   	push   di
    282c:	9a 03 20 5f 28       	call   0x285f:0x2003
    2831:	50                   	push   ax
    2832:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2835:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    283a:	06                   	push   es
    283b:	57                   	push   di
    283c:	9a bf 17 54 28       	call   0x2854:0x17bf
    2841:	8d be f4 fd          	lea    di,[bp-0x20c]
    2845:	16                   	push   ss
    2846:	57                   	push   di
    2847:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284a:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    284f:	06                   	push   es
    2850:	57                   	push   di
    2851:	9a 53 1d 81 28       	call   0x2881:0x1d53
    2856:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    285a:	06                   	push   es
    285b:	57                   	push   di
    285c:	9a 4e 20 dc 5f       	call   0x5fdc:0x204e
    2861:	b9 03 00             	mov    cx,0x3
    2864:	f7 e9                	imul   cx
    2866:	71 05                	jno    0x286d
    2868:	9a 3e 04 de 28       	call   0x28de:0x43e
    286d:	99                   	cwd
    286e:	b9 02 00             	mov    cx,0x2
    2871:	f7 f9                	idiv   cx
    2873:	50                   	push   ax
    2874:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2877:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    287c:	06                   	push   es
    287d:	57                   	push   di
    287e:	9a e1 17 91 28       	call   0x2891:0x17e1
    2883:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2886:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    288c:	06                   	push   es
    288d:	57                   	push   di
    288e:	9a 06 1a b1 28       	call   0x28b1:0x1a06
    2893:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2896:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2899:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289c:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    28a1:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    28a5:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    28a9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    28ac:	06                   	push   es
    28ad:	57                   	push   di
    28ae:	9a 7b 17 bf 28       	call   0x28bf:0x177b
    28b3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28b6:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28ba:	06                   	push   es
    28bb:	57                   	push   di
    28bc:	9a 9d 17 c9 28       	call   0x28c9:0x179d
    28c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c4:	06                   	push   es
    28c5:	57                   	push   di
    28c6:	9a a9 18 00 29       	call   0x2900:0x18a9
    28cb:	8b d0                	mov    dx,ax
    28cd:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28d1:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    28d5:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    28d9:	71 05                	jno    0x28e0
    28db:	9a 3e 04 f4 28       	call   0x28f4:0x43e
    28e0:	3b c2                	cmp    ax,dx
    28e2:	7e 20                	jle    0x2904
    28e4:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28e8:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    28ec:	2d 08 00             	sub    ax,0x8
    28ef:	71 05                	jno    0x28f6
    28f1:	9a 3e 04 21 29       	call   0x2921:0x43e
    28f6:	50                   	push   ax
    28f7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28fb:	06                   	push   es
    28fc:	57                   	push   di
    28fd:	9a 7b 17 0c 29       	call   0x290c:0x177b
    2902:	eb bd                	jmp    0x28c1
    2904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2907:	06                   	push   es
    2908:	57                   	push   di
    2909:	9a f4 18 43 29       	call   0x2943:0x18f4
    290e:	8b d0                	mov    dx,ax
    2910:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2914:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2918:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    291c:	71 05                	jno    0x2923
    291e:	9a 3e 04 37 29       	call   0x2937:0x43e
    2923:	3b c2                	cmp    ax,dx
    2925:	7e 20                	jle    0x2947
    2927:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    292b:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    292f:	2d 08 00             	sub    ax,0x8
    2932:	71 05                	jno    0x2939
    2934:	9a 3e 04 6d 29       	call   0x296d:0x43e
    2939:	50                   	push   ax
    293a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    293e:	06                   	push   es
    293f:	57                   	push   di
    2940:	9a 9d 17 56 29       	call   0x2956:0x179d
    2945:	eb bd                	jmp    0x2904
    2947:	6a 01                	push   0x1
    2949:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294c:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    2951:	06                   	push   es
    2952:	57                   	push   di
    2953:	9a 77 1c f9 29       	call   0x29f9:0x1c77
    2958:	c9                   	leave
    2959:	ca 0e 00             	retf   0xe
    295c:	eb ff                	jmp    0x295d
    295e:	ff                   	(bad)
    295f:	ff                   	(bad)
    2960:	ff                   	(bad)
    2961:	ff                   	(bad)
    2962:	ff 02                	inc    WORD PTR [bp+si]
    2964:	55                   	push   bp
    2965:	89 e5                	mov    bp,sp
    2967:	b8 08 00             	mov    ax,0x8
    296a:	9a 44 04 84 29       	call   0x2984:0x444
    296f:	83 ec 08             	sub    sp,0x8
    2972:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2975:	06                   	push   es
    2976:	57                   	push   di
    2977:	9a 7d 52 a6 29       	call   0x29a6:0x527d
    297c:	2d 01 00             	sub    ax,0x1
    297f:	71 05                	jno    0x2986
    2981:	9a 3e 04 b5 29       	call   0x29b5:0x43e
    2986:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2989:	31 c0                	xor    ax,ax
    298b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    298e:	7e 03                	jle    0x2993
    2990:	e9 d5 00             	jmp    0x2a68
    2993:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2996:	eb 03                	jmp    0x299b
    2998:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    299b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    299e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a1:	06                   	push   es
    29a2:	57                   	push   di
    29a3:	9a 46 52 c6 29       	call   0x29c6:0x5246
    29a8:	52                   	push   dx
    29a9:	50                   	push   ax
    29aa:	bf 22 00             	mov    di,0x22
    29ad:	b8 ce 29             	mov    ax,0x29ce
    29b0:	50                   	push   ax
    29b1:	57                   	push   di
    29b2:	9a 55 22 d5 29       	call   0x29d5:0x2255
    29b7:	08 c0                	or     al,al
    29b9:	74 42                	je     0x29fd
    29bb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c1:	06                   	push   es
    29c2:	57                   	push   di
    29c3:	9a 46 52 08 2a       	call   0x2a08:0x5246
    29c8:	52                   	push   dx
    29c9:	50                   	push   ax
    29ca:	bf 22 00             	mov    di,0x22
    29cd:	b8 10 2a             	mov    ax,0x2a10
    29d0:	50                   	push   ax
    29d1:	57                   	push   di
    29d2:	9a 73 22 ed 29       	call   0x29ed:0x2273
    29d7:	89 c7                	mov    di,ax
    29d9:	8e c2                	mov    es,dx
    29db:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    29de:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    29e1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    29e4:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    29e7:	bf 5c 29             	mov    di,0x295c
    29ea:	9a 16 04 17 2a       	call   0x2a17:0x416
    29ef:	52                   	push   dx
    29f0:	50                   	push   ax
    29f1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    29f4:	06                   	push   es
    29f5:	57                   	push   di
    29f6:	9a d5 1e 5b 2a       	call   0x2a5b:0x1ed5
    29fb:	eb 60                	jmp    0x2a5d
    29fd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a03:	06                   	push   es
    2a04:	57                   	push   di
    2a05:	9a 46 52 28 2a       	call   0x2a28:0x5246
    2a0a:	52                   	push   dx
    2a0b:	50                   	push   ax
    2a0c:	bf a2 0b             	mov    di,0xba2
    2a0f:	b8 30 2a             	mov    ax,0x2a30
    2a12:	50                   	push   ax
    2a13:	57                   	push   di
    2a14:	9a 55 22 37 2a       	call   0x2a37:0x2255
    2a19:	08 c0                	or     al,al
    2a1b:	74 40                	je     0x2a5d
    2a1d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a23:	06                   	push   es
    2a24:	57                   	push   di
    2a25:	9a 46 52 82 2a       	call   0x2a82:0x5246
    2a2a:	52                   	push   dx
    2a2b:	50                   	push   ax
    2a2c:	bf a2 0b             	mov    di,0xba2
    2a2f:	b8 b6 2a             	mov    ax,0x2ab6
    2a32:	50                   	push   ax
    2a33:	57                   	push   di
    2a34:	9a 73 22 4f 2a       	call   0x2a4f:0x2273
    2a39:	89 c7                	mov    di,ax
    2a3b:	8e c2                	mov    es,dx
    2a3d:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2a40:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2a43:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2a46:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2a49:	bf 5c 29             	mov    di,0x295c
    2a4c:	9a 16 04 75 2a       	call   0x2a75:0x416
    2a51:	52                   	push   dx
    2a52:	50                   	push   ax
    2a53:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2a56:	06                   	push   es
    2a57:	57                   	push   di
    2a58:	9a d5 1e 72 2f       	call   0x2f72:0x1ed5
    2a5d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a60:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2a63:	74 03                	je     0x2a68
    2a65:	e9 30 ff             	jmp    0x2998
    2a68:	c9                   	leave
    2a69:	ca 08 00             	retf   0x8
    2a6c:	55                   	push   bp
    2a6d:	89 e5                	mov    bp,sp
    2a6f:	b8 04 00             	mov    ax,0x4
    2a72:	9a 44 04 8c 2a       	call   0x2a8c:0x444
    2a77:	83 ec 04             	sub    sp,0x4
    2a7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7d:	06                   	push   es
    2a7e:	57                   	push   di
    2a7f:	9a 7d 52 ae 2a       	call   0x2aae:0x527d
    2a84:	2d 01 00             	sub    ax,0x1
    2a87:	71 05                	jno    0x2a8e
    2a89:	9a 3e 04 bd 2a       	call   0x2abd:0x43e
    2a8e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a91:	31 c0                	xor    ax,ax
    2a93:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2a96:	7e 03                	jle    0x2a9b
    2a98:	e9 1c 01             	jmp    0x2bb7
    2a9b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a9e:	eb 03                	jmp    0x2aa3
    2aa0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2aa3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2aa6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa9:	06                   	push   es
    2aaa:	57                   	push   di
    2aab:	9a 46 52 cb 2a       	call   0x2acb:0x5246
    2ab0:	52                   	push   dx
    2ab1:	50                   	push   ax
    2ab2:	bf 26 06             	mov    di,0x626
    2ab5:	b8 d3 2a             	mov    ax,0x2ad3
    2ab8:	50                   	push   ax
    2ab9:	57                   	push   di
    2aba:	9a 55 22 da 2a       	call   0x2ada:0x2255
    2abf:	50                   	push   ax
    2ac0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ac3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac6:	06                   	push   es
    2ac7:	57                   	push   di
    2ac8:	9a 46 52 e8 2a       	call   0x2ae8:0x5246
    2acd:	52                   	push   dx
    2ace:	50                   	push   ax
    2acf:	bf a2 0b             	mov    di,0xba2
    2ad2:	b8 f0 2a             	mov    ax,0x2af0
    2ad5:	50                   	push   ax
    2ad6:	57                   	push   di
    2ad7:	9a 55 22 f7 2a       	call   0x2af7:0x2255
    2adc:	50                   	push   ax
    2add:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ae0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae3:	06                   	push   es
    2ae4:	57                   	push   di
    2ae5:	9a 46 52 17 2b       	call   0x2b17:0x5246
    2aea:	52                   	push   dx
    2aeb:	50                   	push   ax
    2aec:	bf 22 00             	mov    di,0x22
    2aef:	b8 02 2c             	mov    ax,0x2c02
    2af2:	50                   	push   ax
    2af3:	57                   	push   di
    2af4:	9a 55 22 35 2b       	call   0x2b35:0x2255
    2af9:	5a                   	pop    dx
    2afa:	0a c2                	or     al,dl
    2afc:	5a                   	pop    dx
    2afd:	0a c2                	or     al,dl
    2aff:	08 c0                	or     al,al
    2b01:	75 03                	jne    0x2b06
    2b03:	e9 a6 00             	jmp    0x2bac
    2b06:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2b0a:	74 58                	je     0x2b64
    2b0c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b12:	06                   	push   es
    2b13:	57                   	push   di
    2b14:	9a 46 52 52 2b       	call   0x2b52:0x5246
    2b19:	89 c7                	mov    di,ax
    2b1b:	8e c2                	mov    es,dx
    2b1d:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2b21:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2b25:	09 d2                	or     dx,dx
    2b27:	79 07                	jns    0x2b30
    2b29:	f7 d2                	not    dx
    2b2b:	f7 d8                	neg    ax
    2b2d:	83 da ff             	sbb    dx,0xffff
    2b30:	71 05                	jno    0x2b37
    2b32:	9a 3e 04 43 2b       	call   0x2b43:0x43e
    2b37:	f7 d2                	not    dx
    2b39:	f7 d8                	neg    ax
    2b3b:	83 da ff             	sbb    dx,0xffff
    2b3e:	71 05                	jno    0x2b45
    2b40:	9a 3e 04 8d 2b       	call   0x2b8d:0x43e
    2b45:	52                   	push   dx
    2b46:	50                   	push   ax
    2b47:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b4d:	06                   	push   es
    2b4e:	57                   	push   di
    2b4f:	9a 46 52 6f 2b       	call   0x2b6f:0x5246
    2b54:	89 c7                	mov    di,ax
    2b56:	8e c2                	mov    es,dx
    2b58:	58                   	pop    ax
    2b59:	5a                   	pop    dx
    2b5a:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2b5e:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2b62:	eb 48                	jmp    0x2bac
    2b64:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b6a:	06                   	push   es
    2b6b:	57                   	push   di
    2b6c:	9a 46 52 9c 2b       	call   0x2b9c:0x5246
    2b71:	89 c7                	mov    di,ax
    2b73:	8e c2                	mov    es,dx
    2b75:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2b79:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2b7d:	09 d2                	or     dx,dx
    2b7f:	79 07                	jns    0x2b88
    2b81:	f7 d2                	not    dx
    2b83:	f7 d8                	neg    ax
    2b85:	83 da ff             	sbb    dx,0xffff
    2b88:	71 05                	jno    0x2b8f
    2b8a:	9a 3e 04 c4 2b       	call   0x2bc4:0x43e
    2b8f:	52                   	push   dx
    2b90:	50                   	push   ax
    2b91:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b97:	06                   	push   es
    2b98:	57                   	push   di
    2b99:	9a 46 52 d1 2b       	call   0x2bd1:0x5246
    2b9e:	89 c7                	mov    di,ax
    2ba0:	8e c2                	mov    es,dx
    2ba2:	58                   	pop    ax
    2ba3:	5a                   	pop    dx
    2ba4:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2ba8:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2bac:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2baf:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2bb2:	74 03                	je     0x2bb7
    2bb4:	e9 e9 fe             	jmp    0x2aa0
    2bb7:	c9                   	leave
    2bb8:	ca 06 00             	retf   0x6
    2bbb:	55                   	push   bp
    2bbc:	89 e5                	mov    bp,sp
    2bbe:	b8 04 00             	mov    ax,0x4
    2bc1:	9a 44 04 db 2b       	call   0x2bdb:0x444
    2bc6:	83 ec 04             	sub    sp,0x4
    2bc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bcc:	06                   	push   es
    2bcd:	57                   	push   di
    2bce:	9a 7d 52 fa 2b       	call   0x2bfa:0x527d
    2bd3:	2d 01 00             	sub    ax,0x1
    2bd6:	71 05                	jno    0x2bdd
    2bd8:	9a 3e 04 09 2c       	call   0x2c09:0x43e
    2bdd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2be0:	31 c0                	xor    ax,ax
    2be2:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2be5:	7f 58                	jg     0x2c3f
    2be7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2bea:	eb 03                	jmp    0x2bef
    2bec:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2bef:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2bf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf5:	06                   	push   es
    2bf6:	57                   	push   di
    2bf7:	9a 46 52 1a 2c       	call   0x2c1a:0x5246
    2bfc:	52                   	push   dx
    2bfd:	50                   	push   ax
    2bfe:	bf 22 00             	mov    di,0x22
    2c01:	b8 22 2c             	mov    ax,0x2c22
    2c04:	50                   	push   ax
    2c05:	57                   	push   di
    2c06:	9a 55 22 29 2c       	call   0x2c29:0x2255
    2c0b:	08 c0                	or     al,al
    2c0d:	74 28                	je     0x2c37
    2c0f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c15:	06                   	push   es
    2c16:	57                   	push   di
    2c17:	9a 46 52 59 2c       	call   0x2c59:0x5246
    2c1c:	52                   	push   dx
    2c1d:	50                   	push   ax
    2c1e:	bf 22 00             	mov    di,0x22
    2c21:	b8 8d 2c             	mov    ax,0x2c8d
    2c24:	50                   	push   ax
    2c25:	57                   	push   di
    2c26:	9a 73 22 4c 2c       	call   0x2c4c:0x2273
    2c2b:	52                   	push   dx
    2c2c:	50                   	push   ax
    2c2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c30:	06                   	push   es
    2c31:	57                   	push   di
    2c32:	9a 41 17 90 2d       	call   0x2d90:0x1741
    2c37:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c3a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2c3d:	75 ad                	jne    0x2bec
    2c3f:	c9                   	leave
    2c40:	ca 04 00             	retf   0x4
    2c43:	55                   	push   bp
    2c44:	89 e5                	mov    bp,sp
    2c46:	b8 08 00             	mov    ax,0x8
    2c49:	9a 44 04 63 2c       	call   0x2c63:0x444
    2c4e:	83 ec 08             	sub    sp,0x8
    2c51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c54:	06                   	push   es
    2c55:	57                   	push   di
    2c56:	9a 7d 52 85 2c       	call   0x2c85:0x527d
    2c5b:	2d 01 00             	sub    ax,0x1
    2c5e:	71 05                	jno    0x2c65
    2c60:	9a 3e 04 94 2c       	call   0x2c94:0x43e
    2c65:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c68:	31 c0                	xor    ax,ax
    2c6a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2c6d:	7e 03                	jle    0x2c72
    2c6f:	e9 f9 00             	jmp    0x2d6b
    2c72:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2c75:	eb 03                	jmp    0x2c7a
    2c77:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2c7a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c80:	06                   	push   es
    2c81:	57                   	push   di
    2c82:	9a 46 52 a5 2c       	call   0x2ca5:0x5246
    2c87:	52                   	push   dx
    2c88:	50                   	push   ax
    2c89:	bf 22 00             	mov    di,0x22
    2c8c:	b8 ad 2c             	mov    ax,0x2cad
    2c8f:	50                   	push   ax
    2c90:	57                   	push   di
    2c91:	9a 55 22 b4 2c       	call   0x2cb4:0x2255
    2c96:	08 c0                	or     al,al
    2c98:	74 2e                	je     0x2cc8
    2c9a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ca0:	06                   	push   es
    2ca1:	57                   	push   di
    2ca2:	9a 46 52 d3 2c       	call   0x2cd3:0x5246
    2ca7:	52                   	push   dx
    2ca8:	50                   	push   ax
    2ca9:	bf 22 00             	mov    di,0x22
    2cac:	b8 c3 2c             	mov    ax,0x2cc3
    2caf:	50                   	push   ax
    2cb0:	57                   	push   di
    2cb1:	9a 73 22 e2 2c       	call   0x2ce2:0x2273
    2cb6:	89 c7                	mov    di,ax
    2cb8:	8e c2                	mov    es,dx
    2cba:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2cbd:	50                   	push   ax
    2cbe:	06                   	push   es
    2cbf:	57                   	push   di
    2cc0:	9a fe 1a db 2c       	call   0x2cdb:0x1afe
    2cc5:	e9 98 00             	jmp    0x2d60
    2cc8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cce:	06                   	push   es
    2ccf:	57                   	push   di
    2cd0:	9a 46 52 f3 2c       	call   0x2cf3:0x5246
    2cd5:	52                   	push   dx
    2cd6:	50                   	push   ax
    2cd7:	bf a2 0b             	mov    di,0xba2
    2cda:	b8 fb 2c             	mov    ax,0x2cfb
    2cdd:	50                   	push   ax
    2cde:	57                   	push   di
    2cdf:	9a 55 22 02 2d       	call   0x2d02:0x2255
    2ce4:	08 c0                	or     al,al
    2ce6:	74 2d                	je     0x2d15
    2ce8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ceb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cee:	06                   	push   es
    2cef:	57                   	push   di
    2cf0:	9a 46 52 20 2d       	call   0x2d20:0x5246
    2cf5:	52                   	push   dx
    2cf6:	50                   	push   ax
    2cf7:	bf a2 0b             	mov    di,0xba2
    2cfa:	b8 11 2d             	mov    ax,0x2d11
    2cfd:	50                   	push   ax
    2cfe:	57                   	push   di
    2cff:	9a 73 22 2f 2d       	call   0x2d2f:0x2273
    2d04:	89 c7                	mov    di,ax
    2d06:	8e c2                	mov    es,dx
    2d08:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d0b:	50                   	push   ax
    2d0c:	06                   	push   es
    2d0d:	57                   	push   di
    2d0e:	9a f1 2a 28 2d       	call   0x2d28:0x2af1
    2d13:	eb 4b                	jmp    0x2d60
    2d15:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d1b:	06                   	push   es
    2d1c:	57                   	push   di
    2d1d:	9a 46 52 40 2d       	call   0x2d40:0x5246
    2d22:	52                   	push   dx
    2d23:	50                   	push   ax
    2d24:	bf 26 06             	mov    di,0x626
    2d27:	b8 48 2d             	mov    ax,0x2d48
    2d2a:	50                   	push   ax
    2d2b:	57                   	push   di
    2d2c:	9a 55 22 4f 2d       	call   0x2d4f:0x2255
    2d31:	08 c0                	or     al,al
    2d33:	74 2b                	je     0x2d60
    2d35:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d3b:	06                   	push   es
    2d3c:	57                   	push   di
    2d3d:	9a 46 52 1a 5d       	call   0x5d1a:0x5246
    2d42:	52                   	push   dx
    2d43:	50                   	push   ax
    2d44:	bf 26 06             	mov    di,0x626
    2d47:	b8 5e 2d             	mov    ax,0x2d5e
    2d4a:	50                   	push   ax
    2d4b:	57                   	push   di
    2d4c:	9a 73 22 77 2d       	call   0x2d77:0x2273
    2d51:	89 c7                	mov    di,ax
    2d53:	8e c2                	mov    es,dx
    2d55:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d58:	50                   	push   ax
    2d59:	06                   	push   es
    2d5a:	57                   	push   di
    2d5b:	9a 70 25 db 5d       	call   0x5ddb:0x2570
    2d60:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d63:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2d66:	74 03                	je     0x2d6b
    2d68:	e9 0c ff             	jmp    0x2c77
    2d6b:	c9                   	leave
    2d6c:	ca 06 00             	retf   0x6
    2d6f:	55                   	push   bp
    2d70:	89 e5                	mov    bp,sp
    2d72:	31 c0                	xor    ax,ax
    2d74:	9a 44 04 9b 2d       	call   0x2d9b:0x444
    2d79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7c:	26 ff b5 8e 04       	push   WORD PTR es:[di+0x48e]
    2d81:	6a 00                	push   0x0
    2d83:	9a b6 13 8e 2e       	call   0x2e8e:0x13b6
    2d88:	c9                   	leave
    2d89:	ca 08 00             	retf   0x8
    2d8c:	00 00                	add    BYTE PTR [bx+si],al
    2d8e:	3f                   	aas
    2d8f:	2e a8 2d             	cs test al,0x2d
    2d92:	55                   	push   bp
    2d93:	89 e5                	mov    bp,sp
    2d95:	b8 04 00             	mov    ax,0x4
    2d98:	9a 44 04 57 2e       	call   0x2e57:0x444
    2d9d:	83 ec 04             	sub    sp,0x4
    2da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da3:	06                   	push   es
    2da4:	57                   	push   di
    2da5:	9a f5 3e 13 2e       	call   0x2e13:0x3ef5
    2daa:	08 c0                	or     al,al
    2dac:	74 08                	je     0x2db6
    2dae:	9a d1 37 d9 2d       	call   0x2dd9:0x37d1
    2db3:	e9 95 00             	jmp    0x2e4b
    2db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db9:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    2dbe:	06                   	push   es
    2dbf:	57                   	push   di
    2dc0:	9a 17 2f 7b 2e       	call   0x2e7b:0x2f17
    2dc5:	08 c0                	or     al,al
    2dc7:	75 03                	jne    0x2dcc
    2dc9:	e9 7f 00             	jmp    0x2e4b
    2dcc:	ff 76 08             	push   WORD PTR [bp+0x8]
    2dcf:	ff 76 06             	push   WORD PTR [bp+0x6]
    2dd2:	b0 01                	mov    al,0x1
    2dd4:	50                   	push   ax
    2dd5:	b8 b4 25             	mov    ax,0x25b4
    2dd8:	ba 08 2e             	mov    dx,0x2e08
    2ddb:	52                   	push   dx
    2ddc:	50                   	push   ax
    2ddd:	9a 53 25 31 2e       	call   0x2e31:0x2553
    2de2:	a3 04 20             	mov    ds:0x2004,ax
    2de5:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    2de9:	b8 8c 2d             	mov    ax,0x2d8c
    2dec:	0e                   	push   cs
    2ded:	50                   	push   ax
    2dee:	55                   	push   bp
    2def:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2df3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2df7:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    2dfb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2dfe:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2e01:	6a 01                	push   0x1
    2e03:	06                   	push   es
    2e04:	57                   	push   di
    2e05:	9a 8d 2f 6a 2e       	call   0x2e6a:0x2f8d
    2e0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e0d:	06                   	push   es
    2e0e:	57                   	push   di
    2e0f:	b8 6f 2d             	mov    ax,0x2d6f
    2e12:	ba 61 2e             	mov    dx,0x2e61
    2e15:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e18:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    2e1d:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    2e22:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    2e27:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    2e2c:	06                   	push   es
    2e2d:	57                   	push   di
    2e2e:	9a 45 5d 48 2e       	call   0x2e48:0x5d45
    2e33:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e37:	83 c4 06             	add    sp,0x6
    2e3a:	b8 4b 2e             	mov    ax,0x2e4b
    2e3d:	0e                   	push   cs
    2e3e:	50                   	push   ax
    2e3f:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    2e43:	06                   	push   es
    2e44:	57                   	push   di
    2e45:	9a 1d 5f c2 2e       	call   0x2ec2:0x5f1d
    2e4a:	cb                   	retf
    2e4b:	c9                   	leave
    2e4c:	ca 08 00             	retf   0x8
    2e4f:	55                   	push   bp
    2e50:	89 e5                	mov    bp,sp
    2e52:	31 c0                	xor    ax,ax
    2e54:	9a 44 04 9c 2e       	call   0x2e9c:0x444
    2e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e5c:	06                   	push   es
    2e5d:	57                   	push   di
    2e5e:	9a f5 3e ad 2e       	call   0x2ead:0x3ef5
    2e63:	08 c0                	or     al,al
    2e65:	74 07                	je     0x2e6e
    2e67:	9a d1 37 90 30       	call   0x3090:0x37d1
    2e6c:	eb 22                	jmp    0x2e90
    2e6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e71:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    2e76:	06                   	push   es
    2e77:	57                   	push   di
    2e78:	9a 17 2f ff ff       	call   0xffff:0x2f17
    2e7d:	08 c0                	or     al,al
    2e7f:	74 0f                	je     0x2e90
    2e81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e84:	26 ff b5 8e 04       	push   WORD PTR es:[di+0x48e]
    2e89:	6a 01                	push   0x1
    2e8b:	9a b6 13 ff ff       	call   0xffff:0x13b6
    2e90:	c9                   	leave
    2e91:	ca 08 00             	retf   0x8
    2e94:	55                   	push   bp
    2e95:	89 e5                	mov    bp,sp
    2e97:	31 c0                	xor    ax,ax
    2e99:	9a 44 04 b4 2e       	call   0x2eb4:0x444
    2e9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea1:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2ea5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2ea9:	bf 22 00             	mov    di,0x22
    2eac:	b8 fc 2e             	mov    ax,0x2efc
    2eaf:	50                   	push   ax
    2eb0:	57                   	push   di
    2eb1:	9a 55 22 d1 2e       	call   0x2ed1:0x2255
    2eb6:	08 c0                	or     al,al
    2eb8:	74 0a                	je     0x2ec4
    2eba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ebd:	06                   	push   es
    2ebe:	57                   	push   di
    2ebf:	9a 56 55 03 2f       	call   0x2f03:0x5556
    2ec4:	c9                   	leave
    2ec5:	ca 08 00             	retf   0x8
    2ec8:	55                   	push   bp
    2ec9:	89 e5                	mov    bp,sp
    2ecb:	b8 08 00             	mov    ax,0x8
    2ece:	9a 44 04 52 2f       	call   0x2f52:0x444
    2ed3:	83 ec 08             	sub    sp,0x8
    2ed6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed9:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    2edf:	75 03                	jne    0x2ee4
    2ee1:	e9 3b 01             	jmp    0x301f
    2ee4:	26 80 bd 88 04 00    	cmp    BYTE PTR es:[di+0x488],0x0
    2eea:	74 03                	je     0x2eef
    2eec:	e9 fe 00             	jmp    0x2fed
    2eef:	ff 76 08             	push   WORD PTR [bp+0x8]
    2ef2:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ef5:	b0 01                	mov    al,0x1
    2ef7:	50                   	push   ax
    2ef8:	b8 22 00             	mov    ax,0x22
    2efb:	ba 24 2f             	mov    dx,0x2f24
    2efe:	52                   	push   dx
    2eff:	50                   	push   ax
    2f00:	9a 53 25 3a 2f       	call   0x2f3a:0x2553
    2f05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f08:	26 89 85 89 04       	mov    WORD PTR es:[di+0x489],ax
    2f0d:	26 89 95 8b 04       	mov    WORD PTR es:[di+0x48b],dx
    2f12:	26 c4 bd 89 04       	les    di,DWORD PTR es:[di+0x489]
    2f17:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2f1a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2f1d:	6a 00                	push   0x0
    2f1f:	06                   	push   es
    2f20:	57                   	push   di
    2f21:	9a 83 13 2e 2f       	call   0x2f2e:0x1383
    2f26:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f29:	06                   	push   es
    2f2a:	57                   	push   di
    2f2b:	9a 50 32 c6 2f       	call   0x2fc6:0x3250
    2f30:	6a 00                	push   0x0
    2f32:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f35:	06                   	push   es
    2f36:	57                   	push   di
    2f37:	9a 65 38 4b 2f       	call   0x2f4b:0x3865
    2f3c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f3f:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2f43:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2f47:	bf fb 04             	mov    di,0x4fb
    2f4a:	b8 83 2f             	mov    ax,0x2f83
    2f4d:	50                   	push   ax
    2f4e:	57                   	push   di
    2f4f:	9a 73 22 8a 2f       	call   0x2f8a:0x2273
    2f54:	89 c7                	mov    di,ax
    2f56:	8e c2                	mov    es,dx
    2f58:	06                   	push   es
    2f59:	57                   	push   di
    2f5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f5d:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    2f61:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2f64:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2f67:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2f6a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f6d:	06                   	push   es
    2f6e:	57                   	push   di
    2f6f:	9a 9d 17 b5 2f       	call   0x2fb5:0x179d
    2f74:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f77:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2f7b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2f7f:	bf fb 04             	mov    di,0x4fb
    2f82:	b8 1b 30             	mov    ax,0x301b
    2f85:	50                   	push   ax
    2f86:	57                   	push   di
    2f87:	9a 73 22 aa 2f       	call   0x2faa:0x2273
    2f8c:	89 c7                	mov    di,ax
    2f8e:	8e c2                	mov    es,dx
    2f90:	06                   	push   es
    2f91:	57                   	push   di
    2f92:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f95:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    2f99:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2f9c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2f9f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2fa2:	05 1e 00             	add    ax,0x1e
    2fa5:	71 05                	jno    0x2fac
    2fa7:	9a 3e 04 cd 2f       	call   0x2fcd:0x43e
    2fac:	50                   	push   ax
    2fad:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2fb0:	06                   	push   es
    2fb1:	57                   	push   di
    2fb2:	9a 7b 17 7d 3f       	call   0x3f7d:0x177b
    2fb7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2fba:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2fbe:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2fc2:	bf 22 00             	mov    di,0x22
    2fc5:	b8 eb 2f             	mov    ax,0x2feb
    2fc8:	50                   	push   ax
    2fc9:	57                   	push   di
    2fca:	9a 73 22 35 30       	call   0x3035:0x2273
    2fcf:	89 c7                	mov    di,ax
    2fd1:	8e c2                	mov    es,dx
    2fd3:	26 c6 85 88 04 01    	mov    BYTE PTR es:[di+0x488],0x1
    2fd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fdc:	26 ff b5 8e 04       	push   WORD PTR es:[di+0x48e]
    2fe1:	26 c4 bd 89 04       	les    di,DWORD PTR es:[di+0x489]
    2fe6:	06                   	push   es
    2fe7:	57                   	push   di
    2fe8:	9a 3e 16 2e 30       	call   0x302e:0x163e
    2fed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff0:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2ff5:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    2ffa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ffd:	26 c4 bd 89 04       	les    di,DWORD PTR es:[di+0x489]
    3002:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3007:	06                   	push   es
    3008:	57                   	push   di
    3009:	9a 6f 24 ff ff       	call   0xffff:0x246f
    300e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3011:	26 c4 bd 89 04       	les    di,DWORD PTR es:[di+0x489]
    3016:	06                   	push   es
    3017:	57                   	push   di
    3018:	9a cc 5c 5c 30       	call   0x305c:0x5ccc
    301d:	eb 3f                	jmp    0x305e
    301f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3022:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3026:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    302a:	bf 22 00             	mov    di,0x22
    302d:	b8 4a 30             	mov    ax,0x304a
    3030:	50                   	push   ax
    3031:	57                   	push   di
    3032:	9a 55 22 51 30       	call   0x3051:0x2255
    3037:	08 c0                	or     al,al
    3039:	74 23                	je     0x305e
    303b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3042:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3046:	bf 22 00             	mov    di,0x22
    3049:	b8 74 30             	mov    ax,0x3074
    304c:	50                   	push   ax
    304d:	57                   	push   di
    304e:	9a 73 22 6a 30       	call   0x306a:0x2273
    3053:	89 c7                	mov    di,ax
    3055:	8e c2                	mov    es,dx
    3057:	06                   	push   es
    3058:	57                   	push   di
    3059:	9a cc 5c da 3e       	call   0x3eda:0x5ccc
    305e:	c9                   	leave
    305f:	ca 08 00             	retf   0x8
    3062:	55                   	push   bp
    3063:	89 e5                	mov    bp,sp
    3065:	31 c0                	xor    ax,ax
    3067:	9a 44 04 82 30       	call   0x3082:0x444
    306c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    306f:	06                   	push   es
    3070:	57                   	push   di
    3071:	9a 86 4c 9f 30       	call   0x309f:0x4c86
    3076:	c9                   	leave
    3077:	ca 08 00             	retf   0x8
    307a:	55                   	push   bp
    307b:	89 e5                	mov    bp,sp
    307d:	31 c0                	xor    ax,ax
    307f:	9a 44 04 ad 30       	call   0x30ad:0x444
    3084:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3087:	26 8a 85 90 04       	mov    al,BYTE PTR es:[di+0x490]
    308c:	50                   	push   ax
    308d:	9a da 3b 94 5f       	call   0x5f94:0x3bda
    3092:	3d 06 00             	cmp    ax,0x6
    3095:	75 0a                	jne    0x30a1
    3097:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    309a:	06                   	push   es
    309b:	57                   	push   di
    309c:	9a 7b 40 b7 30       	call   0x30b7:0x407b
    30a1:	c9                   	leave
    30a2:	ca 08 00             	retf   0x8
    30a5:	55                   	push   bp
    30a6:	89 e5                	mov    bp,sp
    30a8:	31 c0                	xor    ax,ax
    30aa:	9a 44 04 c6 30       	call   0x30c6:0x444
    30af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b2:	06                   	push   es
    30b3:	57                   	push   di
    30b4:	9a 06 43 48 31       	call   0x3148:0x4306
    30b9:	c9                   	leave
    30ba:	ca 08 00             	retf   0x8
    30bd:	55                   	push   bp
    30be:	89 e5                	mov    bp,sp
    30c0:	b8 04 00             	mov    ax,0x4
    30c3:	9a 44 04 8b 31       	call   0x318b:0x444
    30c8:	83 ec 04             	sub    sp,0x4
    30cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30ce:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    30d3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    30d6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    30d9:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    30df:	75 11                	jne    0x30f2
    30e1:	06                   	push   es
    30e2:	57                   	push   di
    30e3:	9a 8b 55 f0 30       	call   0x30f0:0x558b
    30e8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30eb:	06                   	push   es
    30ec:	57                   	push   di
    30ed:	9a 3c 53 0d 31       	call   0x310d:0x533c
    30f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f5:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    30fa:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    30fd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3100:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3106:	75 11                	jne    0x3119
    3108:	06                   	push   es
    3109:	57                   	push   di
    310a:	9a 8b 55 17 31       	call   0x3117:0x558b
    310f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3112:	06                   	push   es
    3113:	57                   	push   di
    3114:	9a 3c 53 34 31       	call   0x3134:0x533c
    3119:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    311c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3121:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3124:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3127:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    312d:	75 11                	jne    0x3140
    312f:	06                   	push   es
    3130:	57                   	push   di
    3131:	9a 8b 55 3e 31       	call   0x313e:0x558b
    3136:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3139:	06                   	push   es
    313a:	57                   	push   di
    313b:	9a 3c 53 a3 31       	call   0x31a3:0x533c
    3140:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3143:	06                   	push   es
    3144:	57                   	push   di
    3145:	9a e4 35 58 31       	call   0x3158:0x35e4
    314a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    314d:	26 c6 85 91 04 00    	mov    BYTE PTR es:[di+0x491],0x0
    3153:	06                   	push   es
    3154:	57                   	push   di
    3155:	9a bb 2b 66 31       	call   0x3166:0x2bbb
    315a:	6a ff                	push   0xffff
    315c:	6a fa                	push   0xfffa
    315e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3161:	06                   	push   es
    3162:	57                   	push   di
    3163:	9a 64 29 72 31       	call   0x3172:0x2964
    3168:	6a 00                	push   0x0
    316a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    316d:	06                   	push   es
    316e:	57                   	push   di
    316f:	9a 6c 2a 7c 31       	call   0x317c:0x2a6c
    3174:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3177:	06                   	push   es
    3178:	57                   	push   di
    3179:	9a f5 3e ae 32       	call   0x32ae:0x3ef5
    317e:	c9                   	leave
    317f:	ca 08 00             	retf   0x8
    3182:	55                   	push   bp
    3183:	89 e5                	mov    bp,sp
    3185:	b8 04 00             	mov    ax,0x4
    3188:	9a 44 04 59 32       	call   0x3259:0x444
    318d:	83 ec 04             	sub    sp,0x4
    3190:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3193:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3198:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    319b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    319e:	06                   	push   es
    319f:	57                   	push   di
    31a0:	9a 02 32 b1 31       	call   0x31b1:0x3202
    31a5:	08 c0                	or     al,al
    31a7:	74 16                	je     0x31bf
    31a9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31ac:	06                   	push   es
    31ad:	57                   	push   di
    31ae:	9a d2 31 d2 31       	call   0x31d2:0x31d2
    31b3:	6a 00                	push   0x0
    31b5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31b8:	06                   	push   es
    31b9:	57                   	push   di
    31ba:	9a d2 2e ec 31       	call   0x31ec:0x2ed2
    31bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31c2:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    31c7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    31ca:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    31cd:	06                   	push   es
    31ce:	57                   	push   di
    31cf:	9a 02 32 e0 31       	call   0x31e0:0x3202
    31d4:	08 c0                	or     al,al
    31d6:	74 16                	je     0x31ee
    31d8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31db:	06                   	push   es
    31dc:	57                   	push   di
    31dd:	9a d2 31 01 32       	call   0x3201:0x31d2
    31e2:	6a 00                	push   0x0
    31e4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31e7:	06                   	push   es
    31e8:	57                   	push   di
    31e9:	9a d2 2e 1b 32       	call   0x321b:0x2ed2
    31ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f1:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    31f6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    31f9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    31fc:	06                   	push   es
    31fd:	57                   	push   di
    31fe:	9a 02 32 0f 32       	call   0x320f:0x3202
    3203:	08 c0                	or     al,al
    3205:	74 16                	je     0x321d
    3207:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    320a:	06                   	push   es
    320b:	57                   	push   di
    320c:	9a d2 31 30 32       	call   0x3230:0x31d2
    3211:	6a 00                	push   0x0
    3213:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3216:	06                   	push   es
    3217:	57                   	push   di
    3218:	9a d2 2e 4a 32       	call   0x324a:0x2ed2
    321d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3220:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    3225:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3228:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    322b:	06                   	push   es
    322c:	57                   	push   di
    322d:	9a 02 32 3e 32       	call   0x323e:0x3202
    3232:	08 c0                	or     al,al
    3234:	74 16                	je     0x324c
    3236:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3239:	06                   	push   es
    323a:	57                   	push   di
    323b:	9a d2 31 a4 32       	call   0x32a4:0x31d2
    3240:	6a 00                	push   0x0
    3242:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3245:	06                   	push   es
    3246:	57                   	push   di
    3247:	9a d2 2e b9 32       	call   0x32b9:0x2ed2
    324c:	c9                   	leave
    324d:	ca 04 00             	retf   0x4
    3250:	55                   	push   bp
    3251:	89 e5                	mov    bp,sp
    3253:	b8 04 00             	mov    ax,0x4
    3256:	9a 44 04 0e 34       	call   0x340e:0x444
    325b:	83 ec 04             	sub    sp,0x4
    325e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3261:	26 8a 85 8d 04       	mov    al,BYTE PTR es:[di+0x48d]
    3266:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    326b:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    326f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3272:	26 8a 85 8d 04       	mov    al,BYTE PTR es:[di+0x48d]
    3277:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    327c:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    3280:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3283:	26 8a 85 8d 04       	mov    al,BYTE PTR es:[di+0x48d]
    3288:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    328d:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    3291:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3294:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3299:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    329c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    329f:	06                   	push   es
    32a0:	57                   	push   di
    32a1:	9a d2 31 eb 32       	call   0x32eb:0x31d2
    32a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32a9:	06                   	push   es
    32aa:	57                   	push   di
    32ab:	9a 18 16 c3 32       	call   0x32c3:0x1618
    32b0:	50                   	push   ax
    32b1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32b4:	06                   	push   es
    32b5:	57                   	push   di
    32b6:	9a fb 2f d3 32       	call   0x32d3:0x2ffb
    32bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32be:	06                   	push   es
    32bf:	57                   	push   di
    32c0:	9a 18 16 0a 33       	call   0x330a:0x1618
    32c5:	08 c0                	or     al,al
    32c7:	75 0e                	jne    0x32d7
    32c9:	6a 01                	push   0x1
    32cb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32ce:	06                   	push   es
    32cf:	57                   	push   di
    32d0:	9a d2 2e e1 32       	call   0x32e1:0x2ed2
    32d5:	eb 0c                	jmp    0x32e3
    32d7:	6a 00                	push   0x0
    32d9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32dc:	06                   	push   es
    32dd:	57                   	push   di
    32de:	9a d2 2e 15 33       	call   0x3315:0x2ed2
    32e3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32e6:	06                   	push   es
    32e7:	57                   	push   di
    32e8:	9a bf 31 00 33       	call   0x3300:0x31bf
    32ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f0:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    32f5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    32f8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    32fb:	06                   	push   es
    32fc:	57                   	push   di
    32fd:	9a d2 31 47 33       	call   0x3347:0x31d2
    3302:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3305:	06                   	push   es
    3306:	57                   	push   di
    3307:	9a 18 16 1f 33       	call   0x331f:0x1618
    330c:	50                   	push   ax
    330d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3310:	06                   	push   es
    3311:	57                   	push   di
    3312:	9a fb 2f 2f 33       	call   0x332f:0x2ffb
    3317:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    331a:	06                   	push   es
    331b:	57                   	push   di
    331c:	9a 18 16 66 33       	call   0x3366:0x1618
    3321:	08 c0                	or     al,al
    3323:	75 0e                	jne    0x3333
    3325:	6a 01                	push   0x1
    3327:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    332a:	06                   	push   es
    332b:	57                   	push   di
    332c:	9a d2 2e 3d 33       	call   0x333d:0x2ed2
    3331:	eb 0c                	jmp    0x333f
    3333:	6a 00                	push   0x0
    3335:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3338:	06                   	push   es
    3339:	57                   	push   di
    333a:	9a d2 2e 71 33       	call   0x3371:0x2ed2
    333f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3342:	06                   	push   es
    3343:	57                   	push   di
    3344:	9a bf 31 5c 33       	call   0x335c:0x31bf
    3349:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    334c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3351:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3354:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3357:	06                   	push   es
    3358:	57                   	push   di
    3359:	9a d2 31 a3 33       	call   0x33a3:0x31d2
    335e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3361:	06                   	push   es
    3362:	57                   	push   di
    3363:	9a 18 16 7b 33       	call   0x337b:0x1618
    3368:	50                   	push   ax
    3369:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    336c:	06                   	push   es
    336d:	57                   	push   di
    336e:	9a fb 2f 8b 33       	call   0x338b:0x2ffb
    3373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3376:	06                   	push   es
    3377:	57                   	push   di
    3378:	9a 18 16 c2 33       	call   0x33c2:0x1618
    337d:	08 c0                	or     al,al
    337f:	75 0e                	jne    0x338f
    3381:	6a 01                	push   0x1
    3383:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3386:	06                   	push   es
    3387:	57                   	push   di
    3388:	9a d2 2e 99 33       	call   0x3399:0x2ed2
    338d:	eb 0c                	jmp    0x339b
    338f:	6a 00                	push   0x0
    3391:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3394:	06                   	push   es
    3395:	57                   	push   di
    3396:	9a d2 2e cd 33       	call   0x33cd:0x2ed2
    339b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    339e:	06                   	push   es
    339f:	57                   	push   di
    33a0:	9a bf 31 b8 33       	call   0x33b8:0x31bf
    33a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a8:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    33ad:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    33b0:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    33b3:	06                   	push   es
    33b4:	57                   	push   di
    33b5:	9a d2 31 ff 33       	call   0x33ff:0x31d2
    33ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33bd:	06                   	push   es
    33be:	57                   	push   di
    33bf:	9a 18 16 d7 33       	call   0x33d7:0x1618
    33c4:	50                   	push   ax
    33c5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33c8:	06                   	push   es
    33c9:	57                   	push   di
    33ca:	9a fb 2f e7 33       	call   0x33e7:0x2ffb
    33cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d2:	06                   	push   es
    33d3:	57                   	push   di
    33d4:	9a 18 16 1f 35       	call   0x351f:0x1618
    33d9:	08 c0                	or     al,al
    33db:	75 0e                	jne    0x33eb
    33dd:	6a 01                	push   0x1
    33df:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33e2:	06                   	push   es
    33e3:	57                   	push   di
    33e4:	9a d2 2e f5 33       	call   0x33f5:0x2ed2
    33e9:	eb 0c                	jmp    0x33f7
    33eb:	6a 00                	push   0x0
    33ed:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33f0:	06                   	push   es
    33f1:	57                   	push   di
    33f2:	9a d2 2e 8b 3c       	call   0x3c8b:0x2ed2
    33f7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33fa:	06                   	push   es
    33fb:	57                   	push   di
    33fc:	9a bf 31 0d 36       	call   0x360d:0x31bf
    3401:	c9                   	leave
    3402:	ca 04 00             	retf   0x4
    3405:	55                   	push   bp
    3406:	89 e5                	mov    bp,sp
    3408:	b8 06 00             	mov    ax,0x6
    340b:	9a 44 04 ed 35       	call   0x35ed:0x444
    3410:	83 ec 06             	sub    sp,0x6
    3413:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3416:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    341b:	6a 00                	push   0x0
    341d:	6a 00                	push   0x0
    341f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3422:	26 c4 bd bc 02       	les    di,DWORD PTR es:[di+0x2bc]
    3427:	06                   	push   es
    3428:	57                   	push   di
    3429:	9a 8b 17 3f 34       	call   0x343f:0x178b
    342e:	6a 00                	push   0x0
    3430:	6a 00                	push   0x0
    3432:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3435:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
    343a:	06                   	push   es
    343b:	57                   	push   di
    343c:	9a 8b 17 52 34       	call   0x3452:0x178b
    3441:	6a 00                	push   0x0
    3443:	6a 00                	push   0x0
    3445:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3448:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    344d:	06                   	push   es
    344e:	57                   	push   di
    344f:	9a 8b 17 65 34       	call   0x3465:0x178b
    3454:	6a 00                	push   0x0
    3456:	6a 00                	push   0x0
    3458:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    345b:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    3460:	06                   	push   es
    3461:	57                   	push   di
    3462:	9a 8b 17 78 34       	call   0x3478:0x178b
    3467:	6a 00                	push   0x0
    3469:	6a 00                	push   0x0
    346b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    346e:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    3473:	06                   	push   es
    3474:	57                   	push   di
    3475:	9a 8b 17 8b 34       	call   0x348b:0x178b
    347a:	6a 00                	push   0x0
    347c:	6a 00                	push   0x0
    347e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3481:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    3486:	06                   	push   es
    3487:	57                   	push   di
    3488:	9a 8b 17 9e 34       	call   0x349e:0x178b
    348d:	6a 00                	push   0x0
    348f:	6a 00                	push   0x0
    3491:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3494:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    3499:	06                   	push   es
    349a:	57                   	push   di
    349b:	9a 8b 17 b1 34       	call   0x34b1:0x178b
    34a0:	6a 00                	push   0x0
    34a2:	6a 00                	push   0x0
    34a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34a7:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    34ac:	06                   	push   es
    34ad:	57                   	push   di
    34ae:	9a 8b 17 c4 34       	call   0x34c4:0x178b
    34b3:	6a 00                	push   0x0
    34b5:	6a 00                	push   0x0
    34b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ba:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    34bf:	06                   	push   es
    34c0:	57                   	push   di
    34c1:	9a 8b 17 d7 34       	call   0x34d7:0x178b
    34c6:	6a 00                	push   0x0
    34c8:	6a 00                	push   0x0
    34ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34cd:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    34d2:	06                   	push   es
    34d3:	57                   	push   di
    34d4:	9a 8b 17 2b 36       	call   0x362b:0x178b
    34d9:	31 c0                	xor    ax,ax
    34db:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    34de:	6a 01                	push   0x1
    34e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34e3:	26 c4 bd 10 03       	les    di,DWORD PTR es:[di+0x310]
    34e8:	06                   	push   es
    34e9:	57                   	push   di
    34ea:	9a 4c 71 fe 34       	call   0x34fe:0x714c
    34ef:	6a 00                	push   0x0
    34f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34f4:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    34f9:	06                   	push   es
    34fa:	57                   	push   di
    34fb:	9a 4c 71 0f 35       	call   0x350f:0x714c
    3500:	6a 00                	push   0x0
    3502:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3505:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    350a:	06                   	push   es
    350b:	57                   	push   di
    350c:	9a 4c 71 6f 38       	call   0x386f:0x714c
    3511:	ff 76 08             	push   WORD PTR [bp+0x8]
    3514:	ff 76 06             	push   WORD PTR [bp+0x6]
    3517:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    351a:	06                   	push   es
    351b:	57                   	push   di
    351c:	9a aa 7d 6a 36       	call   0x366a:0x7daa
    3521:	c9                   	leave
    3522:	ca 04 00             	retf   0x4
    3525:	08 47 72             	or     BYTE PTR [bx+0x72],al
    3528:	65 76 65             	gs jbe 0x3590
    352b:	73 50                	jae    0x357d
    352d:	63 08                	arpl   WORD PTR [bx+si],cx
    352f:	50                   	push   ax
    3530:	61                   	popa
    3531:	6e                   	outs   dx,BYTE PTR ds:[si]
    3532:	6e                   	outs   dx,BYTE PTR ds:[si]
    3533:	65 73 50             	gs jae 0x3586
    3536:	63 0e 43 61          	arpl   WORD PTR ds:0x6143,cx
    353a:	74 61                	je     0x359d
    353c:	44                   	inc    sp
    353d:	65 73 74             	gs jae 0x35b4
    3540:	72 4d                	jb     0x358f
    3542:	6f                   	outs   dx,WORD PTR ds:[si]
    3543:	79 50                	jns    0x3595
    3545:	63 0b                	arpl   WORD PTR [bp+di],cx
    3547:	43                   	inc    bx
    3548:	61                   	popa
    3549:	74 61                	je     0x35ac
    354b:	50                   	push   ax
    354c:	72 6f                	jb     0x35bd
    354e:	62 61 50             	bound  sp,DWORD PTR [bx+di+0x50]
    3551:	63 0f                	arpl   WORD PTR [bx],cx
    3553:	43                   	inc    bx
    3554:	61                   	popa
    3555:	74 61                	je     0x35b8
    3557:	44                   	inc    sp
    3558:	65 73 74             	gs jae 0x35cf
    355b:	72 45                	jb     0x35a2
    355d:	6e                   	outs   dx,BYTE PTR ds:[si]
    355e:	74 31                	je     0x3591
    3560:	50                   	push   ax
    3561:	63 0f                	arpl   WORD PTR [bx],cx
    3563:	43                   	inc    bx
    3564:	61                   	popa
    3565:	74 61                	je     0x35c8
    3567:	44                   	inc    sp
    3568:	65 73 74             	gs jae 0x35df
    356b:	72 45                	jb     0x35b2
    356d:	6e                   	outs   dx,BYTE PTR ds:[si]
    356e:	74 32                	je     0x35a2
    3570:	50                   	push   ax
    3571:	63 0f                	arpl   WORD PTR [bx],cx
    3573:	43                   	inc    bx
    3574:	61                   	popa
    3575:	74 61                	je     0x35d8
    3577:	44                   	inc    sp
    3578:	65 73 74             	gs jae 0x35ef
    357b:	72 45                	jb     0x35c2
    357d:	6e                   	outs   dx,BYTE PTR ds:[si]
    357e:	74 33                	je     0x35b3
    3580:	50                   	push   ax
    3581:	63 0f                	arpl   WORD PTR [bx],cx
    3583:	43                   	inc    bx
    3584:	61                   	popa
    3585:	74 61                	je     0x35e8
    3587:	44                   	inc    sp
    3588:	65 73 74             	gs jae 0x35ff
    358b:	72 45                	jb     0x35d2
    358d:	6e                   	outs   dx,BYTE PTR ds:[si]
    358e:	74 34                	je     0x35c4
    3590:	50                   	push   ax
    3591:	63 0f                	arpl   WORD PTR [bx],cx
    3593:	43                   	inc    bx
    3594:	61                   	popa
    3595:	74 61                	je     0x35f8
    3597:	44                   	inc    sp
    3598:	65 73 74             	gs jae 0x360f
    359b:	72 45                	jb     0x35e2
    359d:	6e                   	outs   dx,BYTE PTR ds:[si]
    359e:	74 35                	je     0x35d5
    35a0:	50                   	push   ax
    35a1:	63 0f                	arpl   WORD PTR [bx],cx
    35a3:	43                   	inc    bx
    35a4:	61                   	popa
    35a5:	74 61                	je     0x3608
    35a7:	44                   	inc    sp
    35a8:	65 73 74             	gs jae 0x361f
    35ab:	72 45                	jb     0x35f2
    35ad:	6e                   	outs   dx,BYTE PTR ds:[si]
    35ae:	74 36                	je     0x35e6
    35b0:	50                   	push   ax
    35b1:	63 0f                	arpl   WORD PTR [bx],cx
    35b3:	43                   	inc    bx
    35b4:	61                   	popa
    35b5:	74 61                	je     0x3618
    35b7:	44                   	inc    sp
    35b8:	65 73 74             	gs jae 0x362f
    35bb:	72 45                	jb     0x3602
    35bd:	6e                   	outs   dx,BYTE PTR ds:[si]
    35be:	74 37                	je     0x35f7
    35c0:	50                   	push   ax
    35c1:	63 0f                	arpl   WORD PTR [bx],cx
    35c3:	43                   	inc    bx
    35c4:	61                   	popa
    35c5:	74 61                	je     0x3628
    35c7:	44                   	inc    sp
    35c8:	65 73 74             	gs jae 0x363f
    35cb:	72 45                	jb     0x3612
    35cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    35ce:	74 38                	je     0x3608
    35d0:	50                   	push   ax
    35d1:	63 09                	arpl   WORD PTR [bx+di],cx
    35d3:	43                   	inc    bx
    35d4:	61                   	popa
    35d5:	74 61                	je     0x3638
    35d7:	53                   	push   bx
    35d8:	74 79                	je     0x3653
    35da:	6c                   	ins    BYTE PTR es:[di],dx
    35db:	65 00 80 ff ff       	add    BYTE PTR gs:[bx+si-0x1],al
    35e0:	ff                   	(bad)
    35e1:	7f 00                	jg     0x35e3
    35e3:	00 55 89             	add    BYTE PTR [di-0x77],dl
    35e6:	e5 b8                	in     ax,0xb8
    35e8:	06                   	push   es
    35e9:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    35ed:	53                   	push   bx
    35ee:	38 83 ec 06          	cmp    BYTE PTR [bp+di+0x6ec],al
    35f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35f5:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    35fa:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    35fd:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3600:	bf 25 35             	mov    di,0x3525
    3603:	0e                   	push   cs
    3604:	57                   	push   di
    3605:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3608:	06                   	push   es
    3609:	57                   	push   di
    360a:	9a 9b 3b 3a 36       	call   0x363a:0x3b9b
    360f:	89 c7                	mov    di,ax
    3611:	8e c2                	mov    es,dx
    3613:	06                   	push   es
    3614:	57                   	push   di
    3615:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3618:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    361c:	52                   	push   dx
    361d:	50                   	push   ax
    361e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3621:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    3626:	06                   	push   es
    3627:	57                   	push   di
    3628:	9a 8b 17 58 36       	call   0x3658:0x178b
    362d:	bf 2e 35             	mov    di,0x352e
    3630:	0e                   	push   cs
    3631:	57                   	push   di
    3632:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3635:	06                   	push   es
    3636:	57                   	push   di
    3637:	9a 9b 3b 7c 36       	call   0x367c:0x3b9b
    363c:	89 c7                	mov    di,ax
    363e:	8e c2                	mov    es,dx
    3640:	06                   	push   es
    3641:	57                   	push   di
    3642:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3645:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3649:	52                   	push   dx
    364a:	50                   	push   ax
    364b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    364e:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
    3653:	06                   	push   es
    3654:	57                   	push   di
    3655:	9a 8b 17 9a 36       	call   0x369a:0x178b
    365a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    365d:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    3663:	74 0a                	je     0x366f
    3665:	06                   	push   es
    3666:	57                   	push   di
    3667:	9a 05 34 b1 38       	call   0x38b1:0x3405
    366c:	e9 44 02             	jmp    0x38b3
    366f:	bf 37 35             	mov    di,0x3537
    3672:	0e                   	push   cs
    3673:	57                   	push   di
    3674:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3677:	06                   	push   es
    3678:	57                   	push   di
    3679:	9a 9b 3b a9 36       	call   0x36a9:0x3b9b
    367e:	89 c7                	mov    di,ax
    3680:	8e c2                	mov    es,dx
    3682:	06                   	push   es
    3683:	57                   	push   di
    3684:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3687:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    368b:	52                   	push   dx
    368c:	50                   	push   ax
    368d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3690:	26 c4 bd bc 02       	les    di,DWORD PTR es:[di+0x2bc]
    3695:	06                   	push   es
    3696:	57                   	push   di
    3697:	9a 8b 17 c7 36       	call   0x36c7:0x178b
    369c:	bf 46 35             	mov    di,0x3546
    369f:	0e                   	push   cs
    36a0:	57                   	push   di
    36a1:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    36a4:	06                   	push   es
    36a5:	57                   	push   di
    36a6:	9a 9b 3b d6 36       	call   0x36d6:0x3b9b
    36ab:	89 c7                	mov    di,ax
    36ad:	8e c2                	mov    es,dx
    36af:	06                   	push   es
    36b0:	57                   	push   di
    36b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36b4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    36b8:	52                   	push   dx
    36b9:	50                   	push   ax
    36ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36bd:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
    36c2:	06                   	push   es
    36c3:	57                   	push   di
    36c4:	9a 8b 17 f4 36       	call   0x36f4:0x178b
    36c9:	bf 52 35             	mov    di,0x3552
    36cc:	0e                   	push   cs
    36cd:	57                   	push   di
    36ce:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    36d1:	06                   	push   es
    36d2:	57                   	push   di
    36d3:	9a 9b 3b 03 37       	call   0x3703:0x3b9b
    36d8:	89 c7                	mov    di,ax
    36da:	8e c2                	mov    es,dx
    36dc:	06                   	push   es
    36dd:	57                   	push   di
    36de:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36e1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    36e5:	52                   	push   dx
    36e6:	50                   	push   ax
    36e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ea:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    36ef:	06                   	push   es
    36f0:	57                   	push   di
    36f1:	9a 8b 17 21 37       	call   0x3721:0x178b
    36f6:	bf 62 35             	mov    di,0x3562
    36f9:	0e                   	push   cs
    36fa:	57                   	push   di
    36fb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    36fe:	06                   	push   es
    36ff:	57                   	push   di
    3700:	9a 9b 3b 30 37       	call   0x3730:0x3b9b
    3705:	89 c7                	mov    di,ax
    3707:	8e c2                	mov    es,dx
    3709:	06                   	push   es
    370a:	57                   	push   di
    370b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    370e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3712:	52                   	push   dx
    3713:	50                   	push   ax
    3714:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3717:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    371c:	06                   	push   es
    371d:	57                   	push   di
    371e:	9a 8b 17 4e 37       	call   0x374e:0x178b
    3723:	bf 72 35             	mov    di,0x3572
    3726:	0e                   	push   cs
    3727:	57                   	push   di
    3728:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    372b:	06                   	push   es
    372c:	57                   	push   di
    372d:	9a 9b 3b 5d 37       	call   0x375d:0x3b9b
    3732:	89 c7                	mov    di,ax
    3734:	8e c2                	mov    es,dx
    3736:	06                   	push   es
    3737:	57                   	push   di
    3738:	26 c4 3d             	les    di,DWORD PTR es:[di]
    373b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    373f:	52                   	push   dx
    3740:	50                   	push   ax
    3741:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3744:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    3749:	06                   	push   es
    374a:	57                   	push   di
    374b:	9a 8b 17 7b 37       	call   0x377b:0x178b
    3750:	bf 82 35             	mov    di,0x3582
    3753:	0e                   	push   cs
    3754:	57                   	push   di
    3755:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3758:	06                   	push   es
    3759:	57                   	push   di
    375a:	9a 9b 3b 8a 37       	call   0x378a:0x3b9b
    375f:	89 c7                	mov    di,ax
    3761:	8e c2                	mov    es,dx
    3763:	06                   	push   es
    3764:	57                   	push   di
    3765:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3768:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    376c:	52                   	push   dx
    376d:	50                   	push   ax
    376e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3771:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    3776:	06                   	push   es
    3777:	57                   	push   di
    3778:	9a 8b 17 a8 37       	call   0x37a8:0x178b
    377d:	bf 92 35             	mov    di,0x3592
    3780:	0e                   	push   cs
    3781:	57                   	push   di
    3782:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3785:	06                   	push   es
    3786:	57                   	push   di
    3787:	9a 9b 3b b7 37       	call   0x37b7:0x3b9b
    378c:	89 c7                	mov    di,ax
    378e:	8e c2                	mov    es,dx
    3790:	06                   	push   es
    3791:	57                   	push   di
    3792:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3795:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3799:	52                   	push   dx
    379a:	50                   	push   ax
    379b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    379e:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    37a3:	06                   	push   es
    37a4:	57                   	push   di
    37a5:	9a 8b 17 d5 37       	call   0x37d5:0x178b
    37aa:	bf a2 35             	mov    di,0x35a2
    37ad:	0e                   	push   cs
    37ae:	57                   	push   di
    37af:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    37b2:	06                   	push   es
    37b3:	57                   	push   di
    37b4:	9a 9b 3b e4 37       	call   0x37e4:0x3b9b
    37b9:	89 c7                	mov    di,ax
    37bb:	8e c2                	mov    es,dx
    37bd:	06                   	push   es
    37be:	57                   	push   di
    37bf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37c2:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    37c6:	52                   	push   dx
    37c7:	50                   	push   ax
    37c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37cb:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    37d0:	06                   	push   es
    37d1:	57                   	push   di
    37d2:	9a 8b 17 02 38       	call   0x3802:0x178b
    37d7:	bf b2 35             	mov    di,0x35b2
    37da:	0e                   	push   cs
    37db:	57                   	push   di
    37dc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    37df:	06                   	push   es
    37e0:	57                   	push   di
    37e1:	9a 9b 3b 11 38       	call   0x3811:0x3b9b
    37e6:	89 c7                	mov    di,ax
    37e8:	8e c2                	mov    es,dx
    37ea:	06                   	push   es
    37eb:	57                   	push   di
    37ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37ef:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    37f3:	52                   	push   dx
    37f4:	50                   	push   ax
    37f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f8:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    37fd:	06                   	push   es
    37fe:	57                   	push   di
    37ff:	9a 8b 17 2f 38       	call   0x382f:0x178b
    3804:	bf c2 35             	mov    di,0x35c2
    3807:	0e                   	push   cs
    3808:	57                   	push   di
    3809:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    380c:	06                   	push   es
    380d:	57                   	push   di
    380e:	9a 9b 3b 3e 38       	call   0x383e:0x3b9b
    3813:	89 c7                	mov    di,ax
    3815:	8e c2                	mov    es,dx
    3817:	06                   	push   es
    3818:	57                   	push   di
    3819:	26 c4 3d             	les    di,DWORD PTR es:[di]
    381c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3820:	52                   	push   dx
    3821:	50                   	push   ax
    3822:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3825:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    382a:	06                   	push   es
    382b:	57                   	push   di
    382c:	9a 8b 17 a1 39       	call   0x39a1:0x178b
    3831:	bf d2 35             	mov    di,0x35d2
    3834:	0e                   	push   cs
    3835:	57                   	push   di
    3836:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3839:	06                   	push   es
    383a:	57                   	push   di
    383b:	9a 9b 3b b2 39       	call   0x39b2:0x3b9b
    3840:	89 c7                	mov    di,ax
    3842:	8e c2                	mov    es,dx
    3844:	06                   	push   es
    3845:	57                   	push   di
    3846:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3849:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    384d:	bf dc 35             	mov    di,0x35dc
    3850:	9a 16 04 77 39       	call   0x3977:0x416
    3855:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3858:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    385c:	b0 00                	mov    al,0x0
    385e:	75 01                	jne    0x3861
    3860:	40                   	inc    ax
    3861:	50                   	push   ax
    3862:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3865:	26 c4 bd 10 03       	les    di,DWORD PTR es:[di+0x310]
    386a:	06                   	push   es
    386b:	57                   	push   di
    386c:	9a 4c 71 88 38       	call   0x3888:0x714c
    3871:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    3875:	b0 00                	mov    al,0x0
    3877:	75 01                	jne    0x387a
    3879:	40                   	inc    ax
    387a:	50                   	push   ax
    387b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    387e:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    3883:	06                   	push   es
    3884:	57                   	push   di
    3885:	9a 4c 71 a1 38       	call   0x38a1:0x714c
    388a:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
    388e:	b0 00                	mov    al,0x0
    3890:	75 01                	jne    0x3893
    3892:	40                   	inc    ax
    3893:	50                   	push   ax
    3894:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3897:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    389c:	06                   	push   es
    389d:	57                   	push   di
    389e:	9a 4c 71 98 3f       	call   0x3f98:0x714c
    38a3:	ff 76 08             	push   WORD PTR [bp+0x8]
    38a6:	ff 76 06             	push   WORD PTR [bp+0x6]
    38a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ac:	06                   	push   es
    38ad:	57                   	push   di
    38ae:	9a aa 7d 1d 3c       	call   0x3c1d:0x7daa
    38b3:	c9                   	leave
    38b4:	ca 04 00             	retf   0x4
    38b7:	08 47 72             	or     BYTE PTR [bx+0x72],al
    38ba:	65 76 65             	gs jbe 0x3922
    38bd:	73 50                	jae    0x390f
    38bf:	63 08                	arpl   WORD PTR [bx+si],cx
    38c1:	50                   	push   ax
    38c2:	61                   	popa
    38c3:	6e                   	outs   dx,BYTE PTR ds:[si]
    38c4:	6e                   	outs   dx,BYTE PTR ds:[si]
    38c5:	65 73 50             	gs jae 0x3918
    38c8:	63 0e 43 61          	arpl   WORD PTR ds:0x6143,cx
    38cc:	74 61                	je     0x392f
    38ce:	44                   	inc    sp
    38cf:	65 73 74             	gs jae 0x3946
    38d2:	72 4d                	jb     0x3921
    38d4:	6f                   	outs   dx,WORD PTR ds:[si]
    38d5:	79 50                	jns    0x3927
    38d7:	63 0b                	arpl   WORD PTR [bp+di],cx
    38d9:	43                   	inc    bx
    38da:	61                   	popa
    38db:	74 61                	je     0x393e
    38dd:	50                   	push   ax
    38de:	72 6f                	jb     0x394f
    38e0:	62 61 50             	bound  sp,DWORD PTR [bx+di+0x50]
    38e3:	63 0f                	arpl   WORD PTR [bx],cx
    38e5:	43                   	inc    bx
    38e6:	61                   	popa
    38e7:	74 61                	je     0x394a
    38e9:	44                   	inc    sp
    38ea:	65 73 74             	gs jae 0x3961
    38ed:	72 45                	jb     0x3934
    38ef:	6e                   	outs   dx,BYTE PTR ds:[si]
    38f0:	74 31                	je     0x3923
    38f2:	50                   	push   ax
    38f3:	63 0f                	arpl   WORD PTR [bx],cx
    38f5:	43                   	inc    bx
    38f6:	61                   	popa
    38f7:	74 61                	je     0x395a
    38f9:	44                   	inc    sp
    38fa:	65 73 74             	gs jae 0x3971
    38fd:	72 45                	jb     0x3944
    38ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    3900:	74 32                	je     0x3934
    3902:	50                   	push   ax
    3903:	63 0f                	arpl   WORD PTR [bx],cx
    3905:	43                   	inc    bx
    3906:	61                   	popa
    3907:	74 61                	je     0x396a
    3909:	44                   	inc    sp
    390a:	65 73 74             	gs jae 0x3981
    390d:	72 45                	jb     0x3954
    390f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3910:	74 33                	je     0x3945
    3912:	50                   	push   ax
    3913:	63 0f                	arpl   WORD PTR [bx],cx
    3915:	43                   	inc    bx
    3916:	61                   	popa
    3917:	74 61                	je     0x397a
    3919:	44                   	inc    sp
    391a:	65 73 74             	gs jae 0x3991
    391d:	72 45                	jb     0x3964
    391f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3920:	74 34                	je     0x3956
    3922:	50                   	push   ax
    3923:	63 0f                	arpl   WORD PTR [bx],cx
    3925:	43                   	inc    bx
    3926:	61                   	popa
    3927:	74 61                	je     0x398a
    3929:	44                   	inc    sp
    392a:	65 73 74             	gs jae 0x39a1
    392d:	72 45                	jb     0x3974
    392f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3930:	74 35                	je     0x3967
    3932:	50                   	push   ax
    3933:	63 0f                	arpl   WORD PTR [bx],cx
    3935:	43                   	inc    bx
    3936:	61                   	popa
    3937:	74 61                	je     0x399a
    3939:	44                   	inc    sp
    393a:	65 73 74             	gs jae 0x39b1
    393d:	72 45                	jb     0x3984
    393f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3940:	74 36                	je     0x3978
    3942:	50                   	push   ax
    3943:	63 0f                	arpl   WORD PTR [bx],cx
    3945:	43                   	inc    bx
    3946:	61                   	popa
    3947:	74 61                	je     0x39aa
    3949:	44                   	inc    sp
    394a:	65 73 74             	gs jae 0x39c1
    394d:	72 45                	jb     0x3994
    394f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3950:	74 37                	je     0x3989
    3952:	50                   	push   ax
    3953:	63 0f                	arpl   WORD PTR [bx],cx
    3955:	43                   	inc    bx
    3956:	61                   	popa
    3957:	74 61                	je     0x39ba
    3959:	44                   	inc    sp
    395a:	65 73 74             	gs jae 0x39d1
    395d:	72 45                	jb     0x39a4
    395f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3960:	74 38                	je     0x399a
    3962:	50                   	push   ax
    3963:	63 09                	arpl   WORD PTR [bx+di],cx
    3965:	43                   	inc    bx
    3966:	61                   	popa
    3967:	74 61                	je     0x39ca
    3969:	53                   	push   bx
    396a:	74 79                	je     0x39e5
    396c:	6c                   	ins    BYTE PTR es:[di],dx
    396d:	65 55                	gs push bp
    396f:	89 e5                	mov    bp,sp
    3971:	b8 06 00             	mov    ax,0x6
    3974:	9a 44 04 3a 3c       	call   0x3c3a:0x444
    3979:	83 ec 06             	sub    sp,0x6
    397c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    397f:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3984:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3987:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    398a:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    398f:	75 03                	jne    0x3994
    3991:	e9 7d 02             	jmp    0x3c11
    3994:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3997:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    399c:	06                   	push   es
    399d:	57                   	push   di
    399e:	9a 33 17 ce 39       	call   0x39ce:0x1733
    39a3:	52                   	push   dx
    39a4:	50                   	push   ax
    39a5:	bf b7 38             	mov    di,0x38b7
    39a8:	0e                   	push   cs
    39a9:	57                   	push   di
    39aa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    39ad:	06                   	push   es
    39ae:	57                   	push   di
    39af:	9a 9b 3b df 39       	call   0x39df:0x3b9b
    39b4:	89 c7                	mov    di,ax
    39b6:	8e c2                	mov    es,dx
    39b8:	06                   	push   es
    39b9:	57                   	push   di
    39ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39bd:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    39c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c4:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
    39c9:	06                   	push   es
    39ca:	57                   	push   di
    39cb:	9a 33 17 fb 39       	call   0x39fb:0x1733
    39d0:	52                   	push   dx
    39d1:	50                   	push   ax
    39d2:	bf c0 38             	mov    di,0x38c0
    39d5:	0e                   	push   cs
    39d6:	57                   	push   di
    39d7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    39da:	06                   	push   es
    39db:	57                   	push   di
    39dc:	9a 9b 3b 0c 3a       	call   0x3a0c:0x3b9b
    39e1:	89 c7                	mov    di,ax
    39e3:	8e c2                	mov    es,dx
    39e5:	06                   	push   es
    39e6:	57                   	push   di
    39e7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39ea:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    39ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39f1:	26 c4 bd bc 02       	les    di,DWORD PTR es:[di+0x2bc]
    39f6:	06                   	push   es
    39f7:	57                   	push   di
    39f8:	9a 33 17 28 3a       	call   0x3a28:0x1733
    39fd:	52                   	push   dx
    39fe:	50                   	push   ax
    39ff:	bf c9 38             	mov    di,0x38c9
    3a02:	0e                   	push   cs
    3a03:	57                   	push   di
    3a04:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3a07:	06                   	push   es
    3a08:	57                   	push   di
    3a09:	9a 9b 3b 39 3a       	call   0x3a39:0x3b9b
    3a0e:	89 c7                	mov    di,ax
    3a10:	8e c2                	mov    es,dx
    3a12:	06                   	push   es
    3a13:	57                   	push   di
    3a14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a17:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3a1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a1e:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
    3a23:	06                   	push   es
    3a24:	57                   	push   di
    3a25:	9a 33 17 55 3a       	call   0x3a55:0x1733
    3a2a:	52                   	push   dx
    3a2b:	50                   	push   ax
    3a2c:	bf d8 38             	mov    di,0x38d8
    3a2f:	0e                   	push   cs
    3a30:	57                   	push   di
    3a31:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3a34:	06                   	push   es
    3a35:	57                   	push   di
    3a36:	9a 9b 3b 66 3a       	call   0x3a66:0x3b9b
    3a3b:	89 c7                	mov    di,ax
    3a3d:	8e c2                	mov    es,dx
    3a3f:	06                   	push   es
    3a40:	57                   	push   di
    3a41:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a44:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3a48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a4b:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    3a50:	06                   	push   es
    3a51:	57                   	push   di
    3a52:	9a 33 17 82 3a       	call   0x3a82:0x1733
    3a57:	52                   	push   dx
    3a58:	50                   	push   ax
    3a59:	bf e4 38             	mov    di,0x38e4
    3a5c:	0e                   	push   cs
    3a5d:	57                   	push   di
    3a5e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3a61:	06                   	push   es
    3a62:	57                   	push   di
    3a63:	9a 9b 3b 93 3a       	call   0x3a93:0x3b9b
    3a68:	89 c7                	mov    di,ax
    3a6a:	8e c2                	mov    es,dx
    3a6c:	06                   	push   es
    3a6d:	57                   	push   di
    3a6e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a71:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3a75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a78:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    3a7d:	06                   	push   es
    3a7e:	57                   	push   di
    3a7f:	9a 33 17 af 3a       	call   0x3aaf:0x1733
    3a84:	52                   	push   dx
    3a85:	50                   	push   ax
    3a86:	bf f4 38             	mov    di,0x38f4
    3a89:	0e                   	push   cs
    3a8a:	57                   	push   di
    3a8b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3a8e:	06                   	push   es
    3a8f:	57                   	push   di
    3a90:	9a 9b 3b c0 3a       	call   0x3ac0:0x3b9b
    3a95:	89 c7                	mov    di,ax
    3a97:	8e c2                	mov    es,dx
    3a99:	06                   	push   es
    3a9a:	57                   	push   di
    3a9b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a9e:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3aa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aa5:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    3aaa:	06                   	push   es
    3aab:	57                   	push   di
    3aac:	9a 33 17 dc 3a       	call   0x3adc:0x1733
    3ab1:	52                   	push   dx
    3ab2:	50                   	push   ax
    3ab3:	bf 04 39             	mov    di,0x3904
    3ab6:	0e                   	push   cs
    3ab7:	57                   	push   di
    3ab8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3abb:	06                   	push   es
    3abc:	57                   	push   di
    3abd:	9a 9b 3b ed 3a       	call   0x3aed:0x3b9b
    3ac2:	89 c7                	mov    di,ax
    3ac4:	8e c2                	mov    es,dx
    3ac6:	06                   	push   es
    3ac7:	57                   	push   di
    3ac8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3acb:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3acf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad2:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    3ad7:	06                   	push   es
    3ad8:	57                   	push   di
    3ad9:	9a 33 17 09 3b       	call   0x3b09:0x1733
    3ade:	52                   	push   dx
    3adf:	50                   	push   ax
    3ae0:	bf 14 39             	mov    di,0x3914
    3ae3:	0e                   	push   cs
    3ae4:	57                   	push   di
    3ae5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ae8:	06                   	push   es
    3ae9:	57                   	push   di
    3aea:	9a 9b 3b 1a 3b       	call   0x3b1a:0x3b9b
    3aef:	89 c7                	mov    di,ax
    3af1:	8e c2                	mov    es,dx
    3af3:	06                   	push   es
    3af4:	57                   	push   di
    3af5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3af8:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3afc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aff:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    3b04:	06                   	push   es
    3b05:	57                   	push   di
    3b06:	9a 33 17 36 3b       	call   0x3b36:0x1733
    3b0b:	52                   	push   dx
    3b0c:	50                   	push   ax
    3b0d:	bf 24 39             	mov    di,0x3924
    3b10:	0e                   	push   cs
    3b11:	57                   	push   di
    3b12:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b15:	06                   	push   es
    3b16:	57                   	push   di
    3b17:	9a 9b 3b 47 3b       	call   0x3b47:0x3b9b
    3b1c:	89 c7                	mov    di,ax
    3b1e:	8e c2                	mov    es,dx
    3b20:	06                   	push   es
    3b21:	57                   	push   di
    3b22:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b25:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3b29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b2c:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    3b31:	06                   	push   es
    3b32:	57                   	push   di
    3b33:	9a 33 17 63 3b       	call   0x3b63:0x1733
    3b38:	52                   	push   dx
    3b39:	50                   	push   ax
    3b3a:	bf 34 39             	mov    di,0x3934
    3b3d:	0e                   	push   cs
    3b3e:	57                   	push   di
    3b3f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b42:	06                   	push   es
    3b43:	57                   	push   di
    3b44:	9a 9b 3b 74 3b       	call   0x3b74:0x3b9b
    3b49:	89 c7                	mov    di,ax
    3b4b:	8e c2                	mov    es,dx
    3b4d:	06                   	push   es
    3b4e:	57                   	push   di
    3b4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b52:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3b56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b59:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    3b5e:	06                   	push   es
    3b5f:	57                   	push   di
    3b60:	9a 33 17 90 3b       	call   0x3b90:0x1733
    3b65:	52                   	push   dx
    3b66:	50                   	push   ax
    3b67:	bf 44 39             	mov    di,0x3944
    3b6a:	0e                   	push   cs
    3b6b:	57                   	push   di
    3b6c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b6f:	06                   	push   es
    3b70:	57                   	push   di
    3b71:	9a 9b 3b a1 3b       	call   0x3ba1:0x3b9b
    3b76:	89 c7                	mov    di,ax
    3b78:	8e c2                	mov    es,dx
    3b7a:	06                   	push   es
    3b7b:	57                   	push   di
    3b7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b7f:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b86:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    3b8b:	06                   	push   es
    3b8c:	57                   	push   di
    3b8d:	9a 33 17 25 46       	call   0x4625:0x1733
    3b92:	52                   	push   dx
    3b93:	50                   	push   ax
    3b94:	bf 54 39             	mov    di,0x3954
    3b97:	0e                   	push   cs
    3b98:	57                   	push   di
    3b99:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b9c:	06                   	push   es
    3b9d:	57                   	push   di
    3b9e:	9a 9b 3b 02 3c       	call   0x3c02:0x3b9b
    3ba3:	89 c7                	mov    di,ax
    3ba5:	8e c2                	mov    es,dx
    3ba7:	06                   	push   es
    3ba8:	57                   	push   di
    3ba9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bac:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3bb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb3:	26 c4 bd 10 03       	les    di,DWORD PTR es:[di+0x310]
    3bb8:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    3bbe:	74 05                	je     0x3bc5
    3bc0:	31 c0                	xor    ax,ax
    3bc2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3bc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bc8:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    3bcd:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    3bd3:	74 05                	je     0x3bda
    3bd5:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    3bda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bdd:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    3be2:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    3be8:	74 05                	je     0x3bef
    3bea:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    3bef:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3bf2:	99                   	cwd
    3bf3:	52                   	push   dx
    3bf4:	50                   	push   ax
    3bf5:	bf 64 39             	mov    di,0x3964
    3bf8:	0e                   	push   cs
    3bf9:	57                   	push   di
    3bfa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3bfd:	06                   	push   es
    3bfe:	57                   	push   di
    3bff:	9a 9b 3b 19 3c       	call   0x3c19:0x3b9b
    3c04:	89 c7                	mov    di,ax
    3c06:	8e c2                	mov    es,dx
    3c08:	06                   	push   es
    3c09:	57                   	push   di
    3c0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c0d:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3c11:	c9                   	leave
    3c12:	ca 04 00             	retf   0x4
    3c15:	01 00                	add    WORD PTR [bx+si],ax
    3c17:	2f                   	das
    3c18:	00 ac 3d 9a          	add    BYTE PTR [si-0x65c3],ch
    3c1c:	3e 27                	ds daa
    3c1e:	3c 02                	cmp    al,0x2
    3c20:	00 d8                	add    al,bl
    3c22:	00 df                	add    bh,bl
    3c24:	3e be 3e 2f          	ds mov si,0x2f3e
    3c28:	3c 00                	cmp    al,0x0
    3c2a:	00 00                	add    BYTE PTR [bx+si],al
    3c2c:	00 c6                	add    dh,al
    3c2e:	3e 99                	ds cwd
    3c30:	3c 55                	cmp    al,0x55
    3c32:	89 e5                	mov    bp,sp
    3c34:	b8 14 00             	mov    ax,0x14
    3c37:	9a 44 04 ae 3e       	call   0x3eae:0x444
    3c3c:	83 ec 14             	sub    sp,0x14
    3c3f:	b8 1f 3c             	mov    ax,0x3c1f
    3c42:	0e                   	push   cs
    3c43:	50                   	push   ax
    3c44:	55                   	push   bp
    3c45:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c49:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c4d:	b8 15 3c             	mov    ax,0x3c15
    3c50:	0e                   	push   cs
    3c51:	50                   	push   ax
    3c52:	55                   	push   bp
    3c53:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c57:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c5e:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3c63:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3c66:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c6c:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    3c71:	99                   	cwd
    3c72:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3c75:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3c78:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    3c7c:	8d 7e f4             	lea    di,[bp-0xc]
    3c7f:	16                   	push   ss
    3c80:	57                   	push   di
    3c81:	6a 00                	push   0x0
    3c83:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c86:	06                   	push   es
    3c87:	57                   	push   di
    3c88:	9a 95 28 e3 3c       	call   0x3ce3:0x2895
    3c8d:	08 c0                	or     al,al
    3c8f:	75 0a                	jne    0x3c9b
    3c91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c94:	06                   	push   es
    3c95:	57                   	push   di
    3c96:	9a 48 0d a3 3c       	call   0x3ca3:0xd48
    3c9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c9e:	06                   	push   es
    3c9f:	57                   	push   di
    3ca0:	9a e4 35 f1 3c       	call   0x3cf1:0x35e4
    3ca5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca8:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3cad:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3cb0:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3cb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cb6:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    3cbb:	99                   	cwd
    3cbc:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3cbf:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3cc2:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    3cc6:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    3ccb:	c7 46 f6 00 00       	mov    WORD PTR [bp-0xa],0x0
    3cd0:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    3cd4:	8d 7e ec             	lea    di,[bp-0x14]
    3cd7:	16                   	push   ss
    3cd8:	57                   	push   di
    3cd9:	6a 01                	push   0x1
    3cdb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3cde:	06                   	push   es
    3cdf:	57                   	push   di
    3ce0:	9a 95 28 31 3d       	call   0x3d31:0x2895
    3ce5:	08 c0                	or     al,al
    3ce7:	75 0a                	jne    0x3cf3
    3ce9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cec:	06                   	push   es
    3ced:	57                   	push   di
    3cee:	9a 48 0d 3f 3d       	call   0x3d3f:0xd48
    3cf3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf6:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3cfb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3cfe:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3d01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d04:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    3d09:	99                   	cwd
    3d0a:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3d0d:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3d10:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    3d14:	c7 46 f4 02 00       	mov    WORD PTR [bp-0xc],0x2
    3d19:	c7 46 f6 00 00       	mov    WORD PTR [bp-0xa],0x0
    3d1e:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    3d22:	8d 7e ec             	lea    di,[bp-0x14]
    3d25:	16                   	push   ss
    3d26:	57                   	push   di
    3d27:	6a 01                	push   0x1
    3d29:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d2c:	06                   	push   es
    3d2d:	57                   	push   di
    3d2e:	9a 95 28 7f 3d       	call   0x3d7f:0x2895
    3d33:	08 c0                	or     al,al
    3d35:	75 0a                	jne    0x3d41
    3d37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d3a:	06                   	push   es
    3d3b:	57                   	push   di
    3d3c:	9a 48 0d 8d 3d       	call   0x3d8d:0xd48
    3d41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d44:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    3d49:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3d4c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3d4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d52:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    3d57:	99                   	cwd
    3d58:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3d5b:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3d5e:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    3d62:	c7 46 f4 02 00       	mov    WORD PTR [bp-0xc],0x2
    3d67:	c7 46 f6 00 00       	mov    WORD PTR [bp-0xa],0x0
    3d6c:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    3d70:	8d 7e ec             	lea    di,[bp-0x14]
    3d73:	16                   	push   ss
    3d74:	57                   	push   di
    3d75:	6a 01                	push   0x1
    3d77:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d7a:	06                   	push   es
    3d7b:	57                   	push   di
    3d7c:	9a 95 28 80 41       	call   0x4180:0x2895
    3d81:	08 c0                	or     al,al
    3d83:	75 0a                	jne    0x3d8f
    3d85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d88:	06                   	push   es
    3d89:	57                   	push   di
    3d8a:	9a 48 0d 5b 3e       	call   0x3e5b:0xd48
    3d8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d92:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    3d98:	74 44                	je     0x3dde
    3d9a:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3d9f:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3da5:	75 07                	jne    0x3dae
    3da7:	06                   	push   es
    3da8:	57                   	push   di
    3da9:	9a 3c 53 c3 3d       	call   0x3dc3:0x533c
    3dae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db1:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3db6:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3dbc:	75 07                	jne    0x3dc5
    3dbe:	06                   	push   es
    3dbf:	57                   	push   di
    3dc0:	9a 3c 53 da 3d       	call   0x3dda:0x533c
    3dc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dc8:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3dcd:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3dd3:	75 07                	jne    0x3ddc
    3dd5:	06                   	push   es
    3dd6:	57                   	push   di
    3dd7:	9a 3c 53 f9 3d       	call   0x3df9:0x533c
    3ddc:	eb 75                	jmp    0x3e53
    3dde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3de1:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3de6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3de9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3dec:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3df2:	75 11                	jne    0x3e05
    3df4:	06                   	push   es
    3df5:	57                   	push   di
    3df6:	9a 3c 53 03 3e       	call   0x3e03:0x533c
    3dfb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3dfe:	06                   	push   es
    3dff:	57                   	push   di
    3e00:	9a 8b 55 20 3e       	call   0x3e20:0x558b
    3e05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e08:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3e0d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3e10:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3e13:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3e19:	75 11                	jne    0x3e2c
    3e1b:	06                   	push   es
    3e1c:	57                   	push   di
    3e1d:	9a 3c 53 2a 3e       	call   0x3e2a:0x533c
    3e22:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3e25:	06                   	push   es
    3e26:	57                   	push   di
    3e27:	9a 8b 55 47 3e       	call   0x3e47:0x558b
    3e2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e2f:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3e34:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3e37:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3e3a:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3e40:	75 11                	jne    0x3e53
    3e42:	06                   	push   es
    3e43:	57                   	push   di
    3e44:	9a 3c 53 51 3e       	call   0x3e51:0x533c
    3e49:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3e4c:	06                   	push   es
    3e4d:	57                   	push   di
    3e4e:	9a 8b 55 15 3f       	call   0x3f15:0x558b
    3e53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e56:	06                   	push   es
    3e57:	57                   	push   di
    3e58:	9a e4 35 6b 3e       	call   0x3e6b:0x35e4
    3e5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e60:	26 c6 85 91 04 00    	mov    BYTE PTR es:[di+0x491],0x0
    3e66:	06                   	push   es
    3e67:	57                   	push   di
    3e68:	9a bb 2b 79 3e       	call   0x3e79:0x2bbb
    3e6d:	6a ff                	push   0xffff
    3e6f:	6a fa                	push   0xfffa
    3e71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e74:	06                   	push   es
    3e75:	57                   	push   di
    3e76:	9a 64 29 85 3e       	call   0x3e85:0x2964
    3e7b:	6a 00                	push   0x0
    3e7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e80:	06                   	push   es
    3e81:	57                   	push   di
    3e82:	9a 6c 2a 8f 3e       	call   0x3e8f:0x2a6c
    3e87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e8a:	06                   	push   es
    3e8b:	57                   	push   di
    3e8c:	9a f5 3e 2c 40       	call   0x402c:0x3ef5
    3e91:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3e95:	83 c4 06             	add    sp,0x6
    3e98:	eb 1b                	jmp    0x3eb5
    3e9a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3e9d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ea0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3ea3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3ea6:	9a 2d 34 13 42       	call   0x4213:0x342d
    3eab:	ea 85 13 b3 3e       	jmp    0x3eb3:0x1385
    3eb0:	9a 34 14 e4 3e       	call   0x3ee4:0x1434
    3eb5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3eb9:	83 c4 06             	add    sp,0x6
    3ebc:	eb 28                	jmp    0x3ee6
    3ebe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ec1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ec4:	eb 1b                	jmp    0x3ee1
    3ec6:	c6 06 7a 03 01       	mov    BYTE PTR ds:0x37a,0x1
    3ecb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ece:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    3ed5:	06                   	push   es
    3ed6:	57                   	push   di
    3ed7:	9a 56 55 10 61       	call   0x6110:0x5556
    3edc:	9a c3 28 de 49       	call   0x49de:0x28c3
    3ee1:	9a 34 14 fe 3e       	call   0x3efe:0x1434
    3ee6:	c9                   	leave
    3ee7:	ca 04 00             	retf   0x4
    3eea:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    3eed:	6c                   	ins    BYTE PTR es:[di],dx
    3eee:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    3ef3:	6f                   	outs   dx,WORD PTR ds:[si]
    3ef4:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ef5:	55                   	push   bp
    3ef6:	89 e5                	mov    bp,sp
    3ef8:	b8 02 00             	mov    ax,0x2
    3efb:	9a 44 04 aa 3f       	call   0x3faa:0x444
    3f00:	83 ec 02             	sub    sp,0x2
    3f03:	bf ea 3e             	mov    di,0x3eea
    3f06:	0e                   	push   cs
    3f07:	57                   	push   di
    3f08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f0b:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3f10:	06                   	push   es
    3f11:	57                   	push   di
    3f12:	9a 9b 3b ca 3f       	call   0x3fca:0x3b9b
    3f17:	89 c7                	mov    di,ax
    3f19:	8e c2                	mov    es,dx
    3f1b:	06                   	push   es
    3f1c:	57                   	push   di
    3f1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f20:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    3f24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f27:	26 88 85 90 04       	mov    BYTE PTR es:[di+0x490],al
    3f2c:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    3f32:	74 4d                	je     0x3f81
    3f34:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3f39:	26 8a 45 3e          	mov    al,BYTE PTR es:[di+0x3e]
    3f3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f40:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3f45:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    3f49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f4c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3f51:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    3f55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f58:	26 0a 85 91 04       	or     al,BYTE PTR es:[di+0x491]
    3f5d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3f60:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3f64:	74 06                	je     0x3f6c
    3f66:	26 c6 85 90 04 00    	mov    BYTE PTR es:[di+0x490],0x0
    3f6c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3f6f:	50                   	push   ax
    3f70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f73:	26 c4 bd 50 04       	les    di,DWORD PTR es:[di+0x450]
    3f78:	06                   	push   es
    3f79:	57                   	push   di
    3f7a:	9a 77 1c 76 5d       	call   0x5d76:0x1c77
    3f7f:	eb 04                	jmp    0x3f85
    3f81:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3f85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f88:	26 8a 85 90 04       	mov    al,BYTE PTR es:[di+0x490]
    3f8d:	50                   	push   ax
    3f8e:	26 c4 bd 64 04       	les    di,DWORD PTR es:[di+0x464]
    3f93:	06                   	push   es
    3f94:	57                   	push   di
    3f95:	9a 11 6e 89 5f       	call   0x5f89:0x6e11
    3f9a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3f9d:	c9                   	leave
    3f9e:	ca 04 00             	retf   0x4
    3fa1:	55                   	push   bp
    3fa2:	89 e5                	mov    bp,sp
    3fa4:	b8 04 00             	mov    ax,0x4
    3fa7:	9a 44 04 84 40       	call   0x4084:0x444
    3fac:	83 ec 04             	sub    sp,0x4
    3faf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fb2:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3fb7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3fba:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3fbd:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3fc3:	75 11                	jne    0x3fd6
    3fc5:	06                   	push   es
    3fc6:	57                   	push   di
    3fc7:	9a 3c 53 d4 3f       	call   0x3fd4:0x533c
    3fcc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3fcf:	06                   	push   es
    3fd0:	57                   	push   di
    3fd1:	9a 8b 55 f1 3f       	call   0x3ff1:0x558b
    3fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fd9:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3fde:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3fe1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3fe4:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3fea:	75 11                	jne    0x3ffd
    3fec:	06                   	push   es
    3fed:	57                   	push   di
    3fee:	9a 3c 53 fb 3f       	call   0x3ffb:0x533c
    3ff3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3ff6:	06                   	push   es
    3ff7:	57                   	push   di
    3ff8:	9a 8b 55 18 40       	call   0x4018:0x558b
    3ffd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4000:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4005:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4008:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    400b:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    4011:	75 11                	jne    0x4024
    4013:	06                   	push   es
    4014:	57                   	push   di
    4015:	9a 3c 53 22 40       	call   0x4022:0x533c
    401a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    401d:	06                   	push   es
    401e:	57                   	push   di
    401f:	9a 8b 55 75 40       	call   0x4075:0x558b
    4024:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4027:	06                   	push   es
    4028:	57                   	push   di
    4029:	9a e4 35 3c 40       	call   0x403c:0x35e4
    402e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4031:	26 c6 85 91 04 00    	mov    BYTE PTR es:[di+0x491],0x0
    4037:	06                   	push   es
    4038:	57                   	push   di
    4039:	9a bb 2b 4a 40       	call   0x404a:0x2bbb
    403e:	6a ff                	push   0xffff
    4040:	6a fa                	push   0xfffa
    4042:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4045:	06                   	push   es
    4046:	57                   	push   di
    4047:	9a 64 29 56 40       	call   0x4056:0x2964
    404c:	6a 00                	push   0x0
    404e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4051:	06                   	push   es
    4052:	57                   	push   di
    4053:	9a 6c 2a 60 40       	call   0x4060:0x2a6c
    4058:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    405b:	06                   	push   es
    405c:	57                   	push   di
    405d:	9a f5 3e 79 40       	call   0x4079:0x3ef5
    4062:	c9                   	leave
    4063:	ca 04 00             	retf   0x4
    4066:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    4069:	6c                   	ins    BYTE PTR es:[di],dx
    406a:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    406f:	6f                   	outs   dx,WORD PTR ds:[si]
    4070:	6e                   	outs   dx,BYTE PTR ds:[si]
    4071:	01 00                	add    WORD PTR [bx+si],ax
    4073:	2f                   	das
    4074:	00 a8 40 04          	add    BYTE PTR [bx+si+0x440],ch
    4078:	42                   	inc    dx
    4079:	d0 40 55             	rol    BYTE PTR [bx+si+0x55],1
    407c:	89 e5                	mov    bp,sp
    407e:	b8 1a 00             	mov    ax,0x1a
    4081:	9a 44 04 18 42       	call   0x4218:0x444
    4086:	83 ec 1a             	sub    sp,0x1a
    4089:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    408d:	b8 71 40             	mov    ax,0x4071
    4090:	0e                   	push   cs
    4091:	50                   	push   ax
    4092:	55                   	push   bp
    4093:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4097:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    409b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    409e:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    40a3:	06                   	push   es
    40a4:	57                   	push   di
    40a5:	9a 3c 53 b7 40       	call   0x40b7:0x533c
    40aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40ad:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    40b2:	06                   	push   es
    40b3:	57                   	push   di
    40b4:	9a 3c 53 c6 40       	call   0x40c6:0x533c
    40b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40bc:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    40c1:	06                   	push   es
    40c2:	57                   	push   di
    40c3:	9a 3c 53 ed 40       	call   0x40ed:0x533c
    40c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40cb:	06                   	push   es
    40cc:	57                   	push   di
    40cd:	9a 6e 39 8e 41       	call   0x418e:0x396e
    40d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40d5:	26 8a 85 90 04       	mov    al,BYTE PTR es:[di+0x490]
    40da:	50                   	push   ax
    40db:	bf 66 40             	mov    di,0x4066
    40de:	0e                   	push   cs
    40df:	57                   	push   di
    40e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    40e8:	06                   	push   es
    40e9:	57                   	push   di
    40ea:	9a 9b 3b 09 41       	call   0x4109:0x3b9b
    40ef:	89 c7                	mov    di,ax
    40f1:	8e c2                	mov    es,dx
    40f3:	06                   	push   es
    40f4:	57                   	push   di
    40f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40f8:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    40fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40ff:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    4104:	06                   	push   es
    4105:	57                   	push   di
    4106:	9a a0 54 18 41       	call   0x4118:0x54a0
    410b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    410e:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4113:	06                   	push   es
    4114:	57                   	push   di
    4115:	9a a0 54 27 41       	call   0x4127:0x54a0
    411a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    411d:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4122:	06                   	push   es
    4123:	57                   	push   di
    4124:	9a a0 54 98 41       	call   0x4198:0x54a0
    4129:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    412c:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    4131:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    4134:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    4137:	a1 4e 01             	mov    ax,ds:0x14e
    413a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    413d:	b8 01 00             	mov    ax,0x1
    4140:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    4143:	7e 03                	jle    0x4148
    4145:	e9 82 00             	jmp    0x41ca
    4148:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    414b:	eb 03                	jmp    0x4150
    414d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4150:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4153:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    4158:	99                   	cwd
    4159:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    415c:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    415f:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    4163:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4166:	99                   	cwd
    4167:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    416a:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    416d:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    4171:	8d 7e e6             	lea    di,[bp-0x1a]
    4174:	16                   	push   ss
    4175:	57                   	push   di
    4176:	6a 01                	push   0x1
    4178:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    417b:	06                   	push   es
    417c:	57                   	push   di
    417d:	9a 95 28 5d 43       	call   0x435d:0x2895
    4182:	08 c0                	or     al,al
    4184:	75 0a                	jne    0x4190
    4186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4189:	06                   	push   es
    418a:	57                   	push   di
    418b:	9a 48 0d 22 42       	call   0x4222:0xd48
    4190:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4193:	06                   	push   es
    4194:	57                   	push   di
    4195:	9a 3c 53 a9 41       	call   0x41a9:0x533c
    419a:	6a 00                	push   0x0
    419c:	bf 66 40             	mov    di,0x4066
    419f:	0e                   	push   cs
    41a0:	57                   	push   di
    41a1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    41a4:	06                   	push   es
    41a5:	57                   	push   di
    41a6:	9a 9b 3b c0 41       	call   0x41c0:0x3b9b
    41ab:	89 c7                	mov    di,ax
    41ad:	8e c2                	mov    es,dx
    41af:	06                   	push   es
    41b0:	57                   	push   di
    41b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41b4:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    41b8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    41bb:	06                   	push   es
    41bc:	57                   	push   di
    41bd:	9a a0 54 d7 41       	call   0x41d7:0x54a0
    41c2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    41c5:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    41c8:	75 83                	jne    0x414d
    41ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41cd:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    41d2:	06                   	push   es
    41d3:	57                   	push   di
    41d4:	9a 3c 53 e6 41       	call   0x41e6:0x533c
    41d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41dc:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    41e1:	06                   	push   es
    41e2:	57                   	push   di
    41e3:	9a 3c 53 f5 41       	call   0x41f5:0x533c
    41e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41eb:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    41f0:	06                   	push   es
    41f1:	57                   	push   di
    41f2:	9a 3c 53 f0 42       	call   0x42f0:0x533c
    41f7:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    41fb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    41ff:	83 c4 06             	add    sp,0x6
    4202:	eb 16                	jmp    0x421a
    4204:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4207:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    420a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    420d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4210:	9a 2d 34 92 44       	call   0x4492:0x342d
    4215:	9a 34 14 34 42       	call   0x4234:0x1434
    421a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    421d:	06                   	push   es
    421e:	57                   	push   di
    421f:	9a f5 3e 45 42       	call   0x4245:0x3ef5
    4224:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4227:	c9                   	leave
    4228:	ca 04 00             	retf   0x4
    422b:	55                   	push   bp
    422c:	89 e5                	mov    bp,sp
    422e:	b8 02 00             	mov    ax,0x2
    4231:	9a 44 04 0f 43       	call   0x430f:0x444
    4236:	83 ec 02             	sub    sp,0x2
    4239:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    423d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4240:	06                   	push   es
    4241:	57                   	push   di
    4242:	9a 86 4c 53 42       	call   0x4253:0x4c86
    4247:	08 c0                	or     al,al
    4249:	74 0d                	je     0x4258
    424b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    424e:	06                   	push   es
    424f:	57                   	push   di
    4250:	9a 7b 40 f4 42       	call   0x42f4:0x407b
    4255:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4258:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    425b:	c9                   	leave
    425c:	ca 04 00             	retf   0x4
    425f:	0a 49 6e             	or     cl,BYTE PTR [bx+di+0x6e]
    4262:	64 69 63 65 50 72    	imul   sp,WORD PTR fs:[bp+di+0x65],0x7250
    4268:	69 78 00 00 c8       	imul   di,WORD PTR [bx+si+0x0],0xc800
    426d:	42                   	inc    dx
    426e:	10 43 6f             	adc    BYTE PTR [bp+di+0x6f],al
    4271:	75 74                	jne    0x42e7
    4273:	55                   	push   bp
    4274:	6e                   	outs   dx,BYTE PTR ds:[si]
    4275:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
    427a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    427d:	6e                   	outs   dx,BYTE PTR ds:[si]
    427e:	65 0e                	gs push cs
    4280:	43                   	inc    bx
    4281:	6f                   	outs   dx,WORD PTR ds:[si]
    4282:	75 74                	jne    0x42f8
    4284:	55                   	push   bp
    4285:	6e                   	outs   dx,BYTE PTR ds:[si]
    4286:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    428b:	6f                   	outs   dx,WORD PTR ds:[si]
    428c:	63 6b 08             	arpl   WORD PTR [bp+di+0x8],bp
    428f:	43                   	inc    bx
    4290:	6f                   	outs   dx,WORD PTR ds:[si]
    4291:	75 74                	jne    0x4307
    4293:	46                   	inc    si
    4294:	69 78 65 11 53       	imul   di,WORD PTR [bx+si+0x65],0x5311
    4299:	75 70                	jne    0x430b
    429b:	70 6c                	jo     0x4309
    429d:	65 6d                	gs ins WORD PTR es:[di],dx
    429f:	65 6e                	outs   dx,BYTE PTR gs:[si]
    42a1:	74 54                	je     0x42f7
    42a3:	72 61                	jb     0x4306
    42a5:	6e                   	outs   dx,BYTE PTR ds:[si]
    42a6:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    42a9:	08 47 72             	or     BYTE PTR [bx+0x72],al
    42ac:	65 76 65             	gs jbe 0x4314
    42af:	73 50                	jae    0x4301
    42b1:	63 08                	arpl   WORD PTR [bx+si],cx
    42b3:	50                   	push   ax
    42b4:	61                   	popa
    42b5:	6e                   	outs   dx,BYTE PTR ds:[si]
    42b6:	6e                   	outs   dx,BYTE PTR ds:[si]
    42b7:	65 73 50             	gs jae 0x430a
    42ba:	63 0b                	arpl   WORD PTR [bp+di],cx
    42bc:	43                   	inc    bx
    42bd:	6f                   	outs   dx,WORD PTR ds:[si]
    42be:	75 74                	jne    0x4334
    42c0:	4d                   	dec    bp
    42c1:	61                   	popa
    42c2:	74 69                	je     0x432d
    42c4:	65 72 65             	gs jb  0x432c
    42c7:	12 41 70             	adc    al,BYTE PTR [bx+di+0x70]
    42ca:	70 65                	jo     0x4331
    42cc:	6c                   	ins    BYTE PTR es:[di],dx
    42cd:	4f                   	dec    di
    42ce:	66 66 72 65          	data32 data32 jb 0x4337
    42d2:	51                   	push   cx
    42d3:	75 61                	jne    0x4336
    42d5:	6e                   	outs   dx,BYTE PTR ds:[si]
    42d6:	74 69                	je     0x4341
    42d8:	74 65                	je     0x433f
    42da:	11 41 70             	adc    WORD PTR [bx+di+0x70],ax
    42dd:	70 65                	jo     0x4344
    42df:	6c                   	ins    BYTE PTR es:[di],dx
    42e0:	4f                   	dec    di
    42e1:	66 66 72 65          	data32 data32 jb 0x434a
    42e5:	50                   	push   ax
    42e6:	72 69                	jb     0x4351
    42e8:	78 4d                	js     0x4337
    42ea:	61                   	popa
    42eb:	78 01                	js     0x42ee
    42ed:	00 2f                	add    BYTE PTR [bx],ch
    42ef:	00 51 43             	add    BYTE PTR [bx+di+0x43],dl
    42f2:	ca 49 fe             	retf   0xfe49
    42f5:	42                   	inc    dx
    42f6:	01 00                	add    WORD PTR [bx+si],ax
    42f8:	00 00                	add    BYTE PTR [bx+si],al
    42fa:	00 00                	add    BYTE PTR [bx+si],al
    42fc:	ee                   	out    dx,al
    42fd:	49                   	dec    cx
    42fe:	04 43                	add    al,0x43
    4300:	00 00                	add    BYTE PTR [bx+si],al
    4302:	09 4a af             	or     WORD PTR [bp+si-0x51],cx
    4305:	43                   	inc    bx
    4306:	55                   	push   bp
    4307:	89 e5                	mov    bp,sp
    4309:	b8 2e 00             	mov    ax,0x2e
    430c:	9a 44 04 85 43       	call   0x4385:0x444
    4311:	83 ec 2e             	sub    sp,0x2e
    4314:	b8 00 43             	mov    ax,0x4300
    4317:	0e                   	push   cs
    4318:	50                   	push   ax
    4319:	55                   	push   bp
    431a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    431e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4322:	b8 f6 42             	mov    ax,0x42f6
    4325:	0e                   	push   cs
    4326:	50                   	push   ax
    4327:	55                   	push   bp
    4328:	ff 36 58 18          	push   WORD PTR ds:0x1858
    432c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4330:	b8 ec 42             	mov    ax,0x42ec
    4333:	0e                   	push   cs
    4334:	50                   	push   ax
    4335:	55                   	push   bp
    4336:	ff 36 58 18          	push   WORD PTR ds:0x1858
    433a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    433e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4341:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    4346:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4349:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    434c:	06                   	push   es
    434d:	57                   	push   di
    434e:	9a d2 31 73 43       	call   0x4373:0x31d2
    4353:	6a 01                	push   0x1
    4355:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4358:	06                   	push   es
    4359:	57                   	push   di
    435a:	9a fb 2f 69 43       	call   0x4369:0x2ffb
    435f:	6a 00                	push   0x0
    4361:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4364:	06                   	push   es
    4365:	57                   	push   di
    4366:	9a d2 2e a1 43       	call   0x43a1:0x2ed2
    436b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    436e:	06                   	push   es
    436f:	57                   	push   di
    4370:	9a bf 31 c4 43       	call   0x43c4:0x31bf
    4375:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4378:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    437d:	2d 01 00             	sub    ax,0x1
    4380:	71 05                	jno    0x4387
    4382:	9a 3e 04 d8 43       	call   0x43d8:0x43e
    4387:	99                   	cwd
    4388:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    438b:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    438e:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    4392:	8d 7e da             	lea    di,[bp-0x26]
    4395:	16                   	push   ss
    4396:	57                   	push   di
    4397:	6a 00                	push   0x0
    4399:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    439c:	06                   	push   es
    439d:	57                   	push   di
    439e:	9a 95 28 87 46       	call   0x4687:0x2895
    43a3:	08 c0                	or     al,al
    43a5:	75 0a                	jne    0x43b1
    43a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43aa:	06                   	push   es
    43ab:	57                   	push   di
    43ac:	9a 97 0d 5c 46       	call   0x465c:0xd97
    43b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43b4:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    43b9:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    43bc:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    43bf:	06                   	push   es
    43c0:	57                   	push   di
    43c1:	9a 3c 53 ce 43       	call   0x43ce:0x533c
    43c6:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    43c9:	06                   	push   es
    43ca:	57                   	push   di
    43cb:	9a 32 3b e5 43       	call   0x43e5:0x3b32
    43d0:	2d 01 00             	sub    ax,0x1
    43d3:	71 05                	jno    0x43da
    43d5:	9a 3e 04 52 44       	call   0x4452:0x43e
    43da:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    43dd:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    43e0:	06                   	push   es
    43e1:	57                   	push   di
    43e2:	9a af 3d 07 44       	call   0x4407:0x3daf
    43e7:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    43ea:	7f 31                	jg     0x441d
    43ec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    43ef:	eb 03                	jmp    0x43f4
    43f1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    43f4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    43f7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    43fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43fd:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    4402:	06                   	push   es
    4403:	57                   	push   di
    4404:	9a 4b 3b 13 44       	call   0x4413:0x3b4b
    4409:	52                   	push   dx
    440a:	50                   	push   ax
    440b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    440e:	06                   	push   es
    440f:	57                   	push   di
    4410:	9a 70 3b 2a 44       	call   0x442a:0x3b70
    4415:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4418:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    441b:	75 d4                	jne    0x43f1
    441d:	bf 5f 42             	mov    di,0x425f
    4420:	0e                   	push   cs
    4421:	57                   	push   di
    4422:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4425:	06                   	push   es
    4426:	57                   	push   di
    4427:	9a 9b 3b 67 44       	call   0x4467:0x3b9b
    442c:	89 c7                	mov    di,ax
    442e:	8e c2                	mov    es,dx
    4430:	06                   	push   es
    4431:	57                   	push   di
    4432:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4435:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4439:	9b dd 5e ee          	fstp   QWORD PTR [bp-0x12]
    443d:	90                   	nop
    443e:	9b                   	fwait
    443f:	9b 2e d9 06 6a 42    	fld    DWORD PTR cs:0x426a
    4445:	9b dc 46 ee          	fadd   QWORD PTR [bp-0x12]
    4449:	9b 2e d9 06 6a 42    	fld    DWORD PTR cs:0x426a
    444f:	9a b2 04 bd 46       	call   0x46bd:0x4b2
    4454:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    4458:	90                   	nop
    4459:	9b                   	fwait
    445a:	bf 6e 42             	mov    di,0x426e
    445d:	0e                   	push   cs
    445e:	57                   	push   di
    445f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4462:	06                   	push   es
    4463:	57                   	push   di
    4464:	9a 9b 3b b3 44       	call   0x44b3:0x3b9b
    4469:	89 c7                	mov    di,ax
    446b:	8e c2                	mov    es,dx
    446d:	06                   	push   es
    446e:	57                   	push   di
    446f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4472:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4476:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    447a:	90                   	nop
    447b:	9b 9b dd 46 f6       	fld    QWORD PTR [bp-0xa]
    4480:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    4484:	83 ec 08             	sub    sp,0x8
    4487:	89 e3                	mov    bx,sp
    4489:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    448d:	90                   	nop
    448e:	9b                   	fwait
    448f:	9a a6 2f fa 44       	call   0x44fa:0x2fa6
    4494:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    4498:	90                   	nop
    4499:	9b                   	fwait
    449a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    449d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    44a0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    44a3:	ff 76 f6             	push   WORD PTR [bp-0xa]
    44a6:	bf 6e 42             	mov    di,0x426e
    44a9:	0e                   	push   cs
    44aa:	57                   	push   di
    44ab:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    44ae:	06                   	push   es
    44af:	57                   	push   di
    44b0:	9a 9b 3b cf 44       	call   0x44cf:0x3b9b
    44b5:	89 c7                	mov    di,ax
    44b7:	8e c2                	mov    es,dx
    44b9:	06                   	push   es
    44ba:	57                   	push   di
    44bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44be:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    44c2:	bf 7f 42             	mov    di,0x427f
    44c5:	0e                   	push   cs
    44c6:	57                   	push   di
    44c7:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    44ca:	06                   	push   es
    44cb:	57                   	push   di
    44cc:	9a 9b 3b 1b 45       	call   0x451b:0x3b9b
    44d1:	89 c7                	mov    di,ax
    44d3:	8e c2                	mov    es,dx
    44d5:	06                   	push   es
    44d6:	57                   	push   di
    44d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44da:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    44de:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    44e2:	90                   	nop
    44e3:	9b 9b dd 46 f6       	fld    QWORD PTR [bp-0xa]
    44e8:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    44ec:	83 ec 08             	sub    sp,0x8
    44ef:	89 e3                	mov    bx,sp
    44f1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    44f5:	90                   	nop
    44f6:	9b                   	fwait
    44f7:	9a a6 2f 62 45       	call   0x4562:0x2fa6
    44fc:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    4500:	90                   	nop
    4501:	9b                   	fwait
    4502:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4505:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4508:	ff 76 f8             	push   WORD PTR [bp-0x8]
    450b:	ff 76 f6             	push   WORD PTR [bp-0xa]
    450e:	bf 7f 42             	mov    di,0x427f
    4511:	0e                   	push   cs
    4512:	57                   	push   di
    4513:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4516:	06                   	push   es
    4517:	57                   	push   di
    4518:	9a 9b 3b 37 45       	call   0x4537:0x3b9b
    451d:	89 c7                	mov    di,ax
    451f:	8e c2                	mov    es,dx
    4521:	06                   	push   es
    4522:	57                   	push   di
    4523:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4526:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    452a:	bf 8e 42             	mov    di,0x428e
    452d:	0e                   	push   cs
    452e:	57                   	push   di
    452f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4532:	06                   	push   es
    4533:	57                   	push   di
    4534:	9a 9b 3b 83 45       	call   0x4583:0x3b9b
    4539:	89 c7                	mov    di,ax
    453b:	8e c2                	mov    es,dx
    453d:	06                   	push   es
    453e:	57                   	push   di
    453f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4542:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4546:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    454a:	90                   	nop
    454b:	9b 9b dd 46 f6       	fld    QWORD PTR [bp-0xa]
    4550:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    4554:	83 ec 08             	sub    sp,0x8
    4557:	89 e3                	mov    bx,sp
    4559:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    455d:	90                   	nop
    455e:	9b                   	fwait
    455f:	9a a6 2f ca 45       	call   0x45ca:0x2fa6
    4564:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    4568:	90                   	nop
    4569:	9b                   	fwait
    456a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    456d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4570:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4573:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4576:	bf 8e 42             	mov    di,0x428e
    4579:	0e                   	push   cs
    457a:	57                   	push   di
    457b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    457e:	06                   	push   es
    457f:	57                   	push   di
    4580:	9a 9b 3b 9f 45       	call   0x459f:0x3b9b
    4585:	89 c7                	mov    di,ax
    4587:	8e c2                	mov    es,dx
    4589:	06                   	push   es
    458a:	57                   	push   di
    458b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    458e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4592:	bf 97 42             	mov    di,0x4297
    4595:	0e                   	push   cs
    4596:	57                   	push   di
    4597:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    459a:	06                   	push   es
    459b:	57                   	push   di
    459c:	9a 9b 3b eb 45       	call   0x45eb:0x3b9b
    45a1:	89 c7                	mov    di,ax
    45a3:	8e c2                	mov    es,dx
    45a5:	06                   	push   es
    45a6:	57                   	push   di
    45a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45aa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45ae:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    45b2:	90                   	nop
    45b3:	9b 9b dd 46 f6       	fld    QWORD PTR [bp-0xa]
    45b8:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    45bc:	83 ec 08             	sub    sp,0x8
    45bf:	89 e3                	mov    bx,sp
    45c1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    45c5:	90                   	nop
    45c6:	9b                   	fwait
    45c7:	9a a6 2f 9b 47       	call   0x479b:0x2fa6
    45cc:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    45d0:	90                   	nop
    45d1:	9b                   	fwait
    45d2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    45d5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    45d8:	ff 76 f8             	push   WORD PTR [bp-0x8]
    45db:	ff 76 f6             	push   WORD PTR [bp-0xa]
    45de:	bf 97 42             	mov    di,0x4297
    45e1:	0e                   	push   cs
    45e2:	57                   	push   di
    45e3:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    45e6:	06                   	push   es
    45e7:	57                   	push   di
    45e8:	9a 9b 3b 07 46       	call   0x4607:0x3b9b
    45ed:	89 c7                	mov    di,ax
    45ef:	8e c2                	mov    es,dx
    45f1:	06                   	push   es
    45f2:	57                   	push   di
    45f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45f6:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    45fa:	bf a9 42             	mov    di,0x42a9
    45fd:	0e                   	push   cs
    45fe:	57                   	push   di
    45ff:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4602:	06                   	push   es
    4603:	57                   	push   di
    4604:	9a 9b 3b 34 46       	call   0x4634:0x3b9b
    4609:	89 c7                	mov    di,ax
    460b:	8e c2                	mov    es,dx
    460d:	06                   	push   es
    460e:	57                   	push   di
    460f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4612:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4616:	52                   	push   dx
    4617:	50                   	push   ax
    4618:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    461b:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    4620:	06                   	push   es
    4621:	57                   	push   di
    4622:	9a 8b 17 52 46       	call   0x4652:0x178b
    4627:	bf b2 42             	mov    di,0x42b2
    462a:	0e                   	push   cs
    462b:	57                   	push   di
    462c:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    462f:	06                   	push   es
    4630:	57                   	push   di
    4631:	9a 9b 3b 66 46       	call   0x4666:0x3b9b
    4636:	89 c7                	mov    di,ax
    4638:	8e c2                	mov    es,dx
    463a:	06                   	push   es
    463b:	57                   	push   di
    463c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    463f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4643:	52                   	push   dx
    4644:	50                   	push   ax
    4645:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4648:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
    464d:	06                   	push   es
    464e:	57                   	push   di
    464f:	9a 8b 17 01 66       	call   0x6601:0x178b
    4654:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4657:	06                   	push   es
    4658:	57                   	push   di
    4659:	9a 05 34 f5 46       	call   0x46f5:0x3405
    465e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4661:	06                   	push   es
    4662:	57                   	push   di
    4663:	9a be 44 7b 46       	call   0x467b:0x44be
    4668:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    466b:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4670:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4673:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4676:	06                   	push   es
    4677:	57                   	push   di
    4678:	9a d2 31 9d 46       	call   0x469d:0x31d2
    467d:	6a 01                	push   0x1
    467f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4682:	06                   	push   es
    4683:	57                   	push   di
    4684:	9a fb 2f 93 46       	call   0x4693:0x2ffb
    4689:	6a 00                	push   0x0
    468b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    468e:	06                   	push   es
    468f:	57                   	push   di
    4690:	9a d2 2e e7 46       	call   0x46e7:0x2ed2
    4695:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4698:	06                   	push   es
    4699:	57                   	push   di
    469a:	9a bf 31 0a 47       	call   0x470a:0x31bf
    469f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46a2:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    46a7:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    46aa:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    46ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46b0:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    46b5:	2d 01 00             	sub    ax,0x1
    46b8:	71 05                	jno    0x46bf
    46ba:	9a 3e 04 1e 47       	call   0x471e:0x43e
    46bf:	99                   	cwd
    46c0:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    46c3:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    46c6:	c6 46 d6 00          	mov    BYTE PTR [bp-0x2a],0x0
    46ca:	c7 46 da 01 00       	mov    WORD PTR [bp-0x26],0x1
    46cf:	c7 46 dc 00 00       	mov    WORD PTR [bp-0x24],0x0
    46d4:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    46d8:	8d 7e d2             	lea    di,[bp-0x2e]
    46db:	16                   	push   ss
    46dc:	57                   	push   di
    46dd:	6a 01                	push   0x1
    46df:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    46e2:	06                   	push   es
    46e3:	57                   	push   di
    46e4:	9a 95 28 61 48       	call   0x4861:0x2895
    46e9:	08 c0                	or     al,al
    46eb:	75 0a                	jne    0x46f7
    46ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46f0:	06                   	push   es
    46f1:	57                   	push   di
    46f2:	9a 97 0d 6f 48       	call   0x486f:0xd97
    46f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46fa:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    46ff:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4702:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4705:	06                   	push   es
    4706:	57                   	push   di
    4707:	9a 3c 53 14 47       	call   0x4714:0x533c
    470c:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    470f:	06                   	push   es
    4710:	57                   	push   di
    4711:	9a 32 3b 2b 47       	call   0x472b:0x3b32
    4716:	2d 01 00             	sub    ax,0x1
    4719:	71 05                	jno    0x4720
    471b:	9a 3e 04 37 48       	call   0x4837:0x43e
    4720:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4723:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4726:	06                   	push   es
    4727:	57                   	push   di
    4728:	9a af 3d 4d 47       	call   0x474d:0x3daf
    472d:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4730:	7f 31                	jg     0x4763
    4732:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4735:	eb 03                	jmp    0x473a
    4737:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    473a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    473d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4740:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4743:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4748:	06                   	push   es
    4749:	57                   	push   di
    474a:	9a 4b 3b 59 47       	call   0x4759:0x3b4b
    474f:	52                   	push   dx
    4750:	50                   	push   ax
    4751:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4754:	06                   	push   es
    4755:	57                   	push   di
    4756:	9a 70 3b 70 47       	call   0x4770:0x3b70
    475b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    475e:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4761:	75 d4                	jne    0x4737
    4763:	bf bb 42             	mov    di,0x42bb
    4766:	0e                   	push   cs
    4767:	57                   	push   di
    4768:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    476b:	06                   	push   es
    476c:	57                   	push   di
    476d:	9a 9b 3b bc 47       	call   0x47bc:0x3b9b
    4772:	89 c7                	mov    di,ax
    4774:	8e c2                	mov    es,dx
    4776:	06                   	push   es
    4777:	57                   	push   di
    4778:	26 c4 3d             	les    di,DWORD PTR es:[di]
    477b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    477f:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    4783:	90                   	nop
    4784:	9b 9b dd 46 f6       	fld    QWORD PTR [bp-0xa]
    4789:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    478d:	83 ec 08             	sub    sp,0x8
    4790:	89 e3                	mov    bx,sp
    4792:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4796:	90                   	nop
    4797:	9b                   	fwait
    4798:	9a a6 2f 15 49       	call   0x4915:0x2fa6
    479d:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    47a1:	90                   	nop
    47a2:	9b                   	fwait
    47a3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    47a6:	ff 76 fa             	push   WORD PTR [bp-0x6]
    47a9:	ff 76 f8             	push   WORD PTR [bp-0x8]
    47ac:	ff 76 f6             	push   WORD PTR [bp-0xa]
    47af:	bf bb 42             	mov    di,0x42bb
    47b2:	0e                   	push   cs
    47b3:	57                   	push   di
    47b4:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    47b7:	06                   	push   es
    47b8:	57                   	push   di
    47b9:	9a 9b 3b dc 47       	call   0x47dc:0x3b9b
    47be:	89 c7                	mov    di,ax
    47c0:	8e c2                	mov    es,dx
    47c2:	06                   	push   es
    47c3:	57                   	push   di
    47c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47c7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    47cb:	6a 00                	push   0x0
    47cd:	6a 00                	push   0x0
    47cf:	bf c7 42             	mov    di,0x42c7
    47d2:	0e                   	push   cs
    47d3:	57                   	push   di
    47d4:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    47d7:	06                   	push   es
    47d8:	57                   	push   di
    47d9:	9a 9b 3b 00 48       	call   0x4800:0x3b9b
    47de:	89 c7                	mov    di,ax
    47e0:	8e c2                	mov    es,dx
    47e2:	06                   	push   es
    47e3:	57                   	push   di
    47e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47e7:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    47eb:	6a 00                	push   0x0
    47ed:	6a 00                	push   0x0
    47ef:	6a 00                	push   0x0
    47f1:	6a 00                	push   0x0
    47f3:	bf da 42             	mov    di,0x42da
    47f6:	0e                   	push   cs
    47f7:	57                   	push   di
    47f8:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    47fb:	06                   	push   es
    47fc:	57                   	push   di
    47fd:	9a 9b 3b 17 48       	call   0x4817:0x3b9b
    4802:	89 c7                	mov    di,ax
    4804:	8e c2                	mov    es,dx
    4806:	06                   	push   es
    4807:	57                   	push   di
    4808:	26 c4 3d             	les    di,DWORD PTR es:[di]
    480b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    480f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4812:	06                   	push   es
    4813:	57                   	push   di
    4814:	9a be 44 84 48       	call   0x4884:0x44be
    4819:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    481c:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4821:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4824:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4827:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    482a:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    482f:	2d 01 00             	sub    ax,0x1
    4832:	71 05                	jno    0x4839
    4834:	9a 3e 04 98 48       	call   0x4898:0x43e
    4839:	99                   	cwd
    483a:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    483d:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    4840:	c6 46 d6 00          	mov    BYTE PTR [bp-0x2a],0x0
    4844:	c7 46 da 02 00       	mov    WORD PTR [bp-0x26],0x2
    4849:	c7 46 dc 00 00       	mov    WORD PTR [bp-0x24],0x0
    484e:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    4852:	8d 7e d2             	lea    di,[bp-0x2e]
    4855:	16                   	push   ss
    4856:	57                   	push   di
    4857:	6a 01                	push   0x1
    4859:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    485c:	06                   	push   es
    485d:	57                   	push   di
    485e:	9a 95 28 ff ff       	call   0xffff:0x2895
    4863:	08 c0                	or     al,al
    4865:	75 0a                	jne    0x4871
    4867:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    486a:	06                   	push   es
    486b:	57                   	push   di
    486c:	9a 97 0d 9b 49       	call   0x499b:0xd97
    4871:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4874:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4879:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    487c:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    487f:	06                   	push   es
    4880:	57                   	push   di
    4881:	9a 3c 53 8e 48       	call   0x488e:0x533c
    4886:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4889:	06                   	push   es
    488a:	57                   	push   di
    488b:	9a 32 3b a5 48       	call   0x48a5:0x3b32
    4890:	2d 01 00             	sub    ax,0x1
    4893:	71 05                	jno    0x489a
    4895:	9a 3e 04 e3 49       	call   0x49e3:0x43e
    489a:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    489d:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    48a0:	06                   	push   es
    48a1:	57                   	push   di
    48a2:	9a af 3d c7 48       	call   0x48c7:0x3daf
    48a7:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    48aa:	7f 31                	jg     0x48dd
    48ac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    48af:	eb 03                	jmp    0x48b4
    48b1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    48b4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    48b7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    48ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48bd:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    48c2:	06                   	push   es
    48c3:	57                   	push   di
    48c4:	9a 4b 3b d3 48       	call   0x48d3:0x3b4b
    48c9:	52                   	push   dx
    48ca:	50                   	push   ax
    48cb:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    48ce:	06                   	push   es
    48cf:	57                   	push   di
    48d0:	9a 70 3b ea 48       	call   0x48ea:0x3b70
    48d5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    48d8:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    48db:	75 d4                	jne    0x48b1
    48dd:	bf bb 42             	mov    di,0x42bb
    48e0:	0e                   	push   cs
    48e1:	57                   	push   di
    48e2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    48e5:	06                   	push   es
    48e6:	57                   	push   di
    48e7:	9a 9b 3b 36 49       	call   0x4936:0x3b9b
    48ec:	89 c7                	mov    di,ax
    48ee:	8e c2                	mov    es,dx
    48f0:	06                   	push   es
    48f1:	57                   	push   di
    48f2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48f5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48f9:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    48fd:	90                   	nop
    48fe:	9b 9b dd 46 f6       	fld    QWORD PTR [bp-0xa]
    4903:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    4907:	83 ec 08             	sub    sp,0x8
    490a:	89 e3                	mov    bx,sp
    490c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4910:	90                   	nop
    4911:	9b                   	fwait
    4912:	9a a6 2f d9 49       	call   0x49d9:0x2fa6
    4917:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    491b:	90                   	nop
    491c:	9b                   	fwait
    491d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4920:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4923:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4926:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4929:	bf bb 42             	mov    di,0x42bb
    492c:	0e                   	push   cs
    492d:	57                   	push   di
    492e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4931:	06                   	push   es
    4932:	57                   	push   di
    4933:	9a 9b 3b 56 49       	call   0x4956:0x3b9b
    4938:	89 c7                	mov    di,ax
    493a:	8e c2                	mov    es,dx
    493c:	06                   	push   es
    493d:	57                   	push   di
    493e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4941:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4945:	6a 00                	push   0x0
    4947:	6a 00                	push   0x0
    4949:	bf c7 42             	mov    di,0x42c7
    494c:	0e                   	push   cs
    494d:	57                   	push   di
    494e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4951:	06                   	push   es
    4952:	57                   	push   di
    4953:	9a 9b 3b 7a 49       	call   0x497a:0x3b9b
    4958:	89 c7                	mov    di,ax
    495a:	8e c2                	mov    es,dx
    495c:	06                   	push   es
    495d:	57                   	push   di
    495e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4961:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    4965:	6a 00                	push   0x0
    4967:	6a 00                	push   0x0
    4969:	6a 00                	push   0x0
    496b:	6a 00                	push   0x0
    496d:	bf da 42             	mov    di,0x42da
    4970:	0e                   	push   cs
    4971:	57                   	push   di
    4972:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4975:	06                   	push   es
    4976:	57                   	push   di
    4977:	9a 9b 3b 91 49       	call   0x4991:0x3b9b
    497c:	89 c7                	mov    di,ax
    497e:	8e c2                	mov    es,dx
    4980:	06                   	push   es
    4981:	57                   	push   di
    4982:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4985:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4989:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    498c:	06                   	push   es
    498d:	57                   	push   di
    498e:	9a be 44 16 4a       	call   0x4a16:0x44be
    4993:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4996:	06                   	push   es
    4997:	57                   	push   di
    4998:	9a bb 2b a9 49       	call   0x49a9:0x2bbb
    499d:	6a ff                	push   0xffff
    499f:	6a fa                	push   0xfffa
    49a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49a4:	06                   	push   es
    49a5:	57                   	push   di
    49a6:	9a 64 29 b5 49       	call   0x49b5:0x2964
    49ab:	6a 00                	push   0x0
    49ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49b0:	06                   	push   es
    49b1:	57                   	push   di
    49b2:	9a 6c 2a bf 49       	call   0x49bf:0x2a6c
    49b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49ba:	06                   	push   es
    49bb:	57                   	push   di
    49bc:	9a f5 3e f6 49       	call   0x49f6:0x3ef5
    49c1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    49c5:	83 c4 06             	add    sp,0x6
    49c8:	eb 1b                	jmp    0x49e5
    49ca:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    49cd:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    49d0:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    49d3:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    49d6:	9a 2d 34 ff ff       	call   0xffff:0x342d
    49db:	9a c3 28 59 60       	call   0x6059:0x28c3
    49e0:	9a 34 14 fb 49       	call   0x49fb:0x1434
    49e5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    49e9:	83 c4 06             	add    sp,0x6
    49ec:	eb 0f                	jmp    0x49fd
    49ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49f1:	06                   	push   es
    49f2:	57                   	push   di
    49f3:	9a a1 3f 06 62       	call   0x6206:0x3fa1
    49f8:	9a 34 14 8f 4c       	call   0x4c8f:0x1434
    49fd:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4a01:	83 c4 06             	add    sp,0x6
    4a04:	b8 28 4a             	mov    ax,0x4a28
    4a07:	0e                   	push   cs
    4a08:	50                   	push   ax
    4a09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a0c:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    4a11:	06                   	push   es
    4a12:	57                   	push   di
    4a13:	9a d2 31 25 4a       	call   0x4a25:0x31d2
    4a18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a1b:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4a20:	06                   	push   es
    4a21:	57                   	push   di
    4a22:	9a d2 31 e8 4c       	call   0x4ce8:0x31d2
    4a27:	cb                   	retf
    4a28:	c9                   	leave
    4a29:	ca 04 00             	retf   0x4
    4a2c:	0d 54 61             	or     ax,0x6154
    4a2f:	75 78                	jne    0x4aa9
    4a31:	50                   	push   ax
    4a32:	6c                   	ins    BYTE PTR es:[di],dx
    4a33:	61                   	popa
    4a34:	63 65 6d             	arpl   WORD PTR [di+0x6d],sp
    4a37:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4a39:	74 00                	je     0x4a3b
    4a3b:	00 00                	add    BYTE PTR [bx+si],al
    4a3d:	00 00                	add    BYTE PTR [bx+si],al
    4a3f:	00 c8                	add    al,cl
    4a41:	42                   	inc    dx
    4a42:	0b 54 61             	or     dx,WORD PTR [si+0x61]
    4a45:	75 78                	jne    0x4abf
    4a47:	45                   	inc    bp
    4a48:	6d                   	ins    WORD PTR es:[di],dx
    4a49:	70 72                	jo     0x4abd
    4a4b:	75 6e                	jne    0x4abb
    4a4d:	74 11                	je     0x4a60
    4a4f:	54                   	push   sp
    4a50:	61                   	popa
    4a51:	75 78                	jne    0x4acb
    4a53:	44                   	inc    sp
    4a54:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    4a58:	76 65                	jbe    0x4abf
    4a5a:	72 74                	jb     0x4ad0
    4a5c:	41                   	inc    cx
    4a5d:	75 74                	jne    0x4ad3
    4a5f:	6f                   	outs   dx,WORD PTR ds:[si]
    4a60:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    4a63:	75 78                	jne    0x4add
    4a65:	44                   	inc    sp
    4a66:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    4a6a:	76 65                	jbe    0x4ad1
    4a6c:	72 74                	jb     0x4ae2
    4a6e:	4e                   	dec    si
    4a6f:	41                   	inc    cx
    4a70:	75 74                	jne    0x4ae6
    4a72:	6f                   	outs   dx,WORD PTR ds:[si]
    4a73:	07                   	pop    es
    4a74:	54                   	push   sp
    4a75:	61                   	popa
    4a76:	75 78                	jne    0x4af0
    4a78:	54                   	push   sp
    4a79:	56                   	push   si
    4a7a:	41                   	inc    cx
    4a7b:	06                   	push   es
    4a7c:	54                   	push   sp
    4a7d:	61                   	popa
    4a7e:	75 78                	jne    0x4af8
    4a80:	49                   	dec    cx
    4a81:	53                   	push   bx
    4a82:	10 48 65             	adc    BYTE PTR [bx+si+0x65],cl
    4a85:	75 72                	jne    0x4af9
    4a87:	65 73 50             	gs jae 0x4ada
    4a8a:	61                   	popa
    4a8b:	72 4d                	jb     0x4ada
    4a8d:	61                   	popa
    4a8e:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4a91:	6e                   	outs   dx,BYTE PTR ds:[si]
    4a92:	65 12 48 65          	adc    cl,BYTE PTR gs:[bx+si+0x65]
    4a96:	75 72                	jne    0x4b0a
    4a98:	65 73 50             	gs jae 0x4aeb
    4a9b:	61                   	popa
    4a9c:	72 50                	jb     0x4aee
    4a9e:	72 6f                	jb     0x4b0f
    4aa0:	64 75 63             	fs jne 0x4b06
    4aa3:	74 69                	je     0x4b0e
    4aa5:	66 10 43 6f          	data32 adc BYTE PTR [bp+di+0x6f],al
    4aa9:	75 74                	jne    0x4b1f
    4aab:	55                   	push   bp
    4aac:	6e                   	outs   dx,BYTE PTR ds:[si]
    4aad:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
    4ab2:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4ab5:	6e                   	outs   dx,BYTE PTR ds:[si]
    4ab6:	65 13 43 6f          	adc    ax,WORD PTR gs:[bp+di+0x6f]
    4aba:	75 74                	jne    0x4b30
    4abc:	50                   	push   ax
    4abd:	6f                   	outs   dx,WORD PTR ds:[si]
    4abe:	69 6e 74 52 65       	imul   bp,WORD PTR [bp+0x74],0x6552
    4ac3:	70 61                	jo     0x4b26
    4ac5:	72 61                	jb     0x4b28
    4ac7:	74 69                	je     0x4b32
    4ac9:	6f                   	outs   dx,WORD PTR ds:[si]
    4aca:	6e                   	outs   dx,BYTE PTR ds:[si]
    4acb:	0e                   	push   cs
    4acc:	43                   	inc    bx
    4acd:	6f                   	outs   dx,WORD PTR ds:[si]
    4ace:	75 74                	jne    0x4b44
    4ad0:	55                   	push   bp
    4ad1:	6e                   	outs   dx,BYTE PTR ds:[si]
    4ad2:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    4ad7:	6f                   	outs   dx,WORD PTR ds:[si]
    4ad8:	63 6b 12             	arpl   WORD PTR [bp+di+0x12],bp
    4adb:	43                   	inc    bx
    4adc:	6f                   	outs   dx,WORD PTR ds:[si]
    4add:	75 74                	jne    0x4b53
    4adf:	55                   	push   bp
    4ae0:	6e                   	outs   dx,BYTE PTR ds:[si]
    4ae1:	69 74 65 50 72       	imul   si,WORD PTR [si+0x65],0x7250
    4ae6:	6f                   	outs   dx,WORD PTR ds:[si]
    4ae7:	64 75 63             	fs jne 0x4b4d
    4aea:	74 69                	je     0x4b55
    4aec:	66 10 43 6f          	data32 adc BYTE PTR [bp+di+0x6f],al
    4af0:	75 74                	jne    0x4b66
    4af2:	55                   	push   bp
    4af3:	6e                   	outs   dx,BYTE PTR ds:[si]
    4af4:	69 74 65 56 65       	imul   si,WORD PTR [si+0x65],0x6556
    4af9:	6e                   	outs   dx,BYTE PTR ds:[si]
    4afa:	64 65 75 72          	fs gs jne 0x4b70
    4afe:	0e                   	push   cs
    4aff:	43                   	inc    bx
    4b00:	6f                   	outs   dx,WORD PTR ds:[si]
    4b01:	75 74                	jne    0x4b77
    4b03:	55                   	push   bp
    4b04:	6e                   	outs   dx,BYTE PTR ds:[si]
    4b05:	69 74 65 43 61       	imul   si,WORD PTR [si+0x65],0x6143
    4b0a:	64 72 65             	fs jb  0x4b72
    4b0d:	0e                   	push   cs
    4b0e:	43                   	inc    bx
    4b0f:	6f                   	outs   dx,WORD PTR ds:[si]
    4b10:	75 74                	jne    0x4b86
    4b12:	45                   	inc    bp
    4b13:	6d                   	ins    WORD PTR es:[di],dx
    4b14:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    4b17:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    4b1a:	50                   	push   ax
    4b1b:	63 12                	arpl   WORD PTR [bp+si],dx
    4b1d:	43                   	inc    bx
    4b1e:	6f                   	outs   dx,WORD PTR ds:[si]
    4b1f:	75 74                	jne    0x4b95
    4b21:	4c                   	dec    sp
    4b22:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    4b27:	69 65 6d 65 6e       	imul   sp,WORD PTR [di+0x6d],0x6e65
    4b2c:	74 50                	je     0x4b7e
    4b2e:	63 0f                	arpl   WORD PTR [bx],cx
    4b30:	46                   	inc    si
    4b31:	6f                   	outs   dx,WORD PTR ds:[si]
    4b32:	72 6d                	jb     0x4ba1
    4b34:	61                   	popa
    4b35:	74 69                	je     0x4ba0
    4b37:	6f                   	outs   dx,WORD PTR ds:[si]
    4b38:	6e                   	outs   dx,BYTE PTR ds:[si]
    4b39:	4d                   	dec    bp
    4b3a:	69 6e 69 50 63       	imul   bp,WORD PTR [bp+0x69],0x6350
    4b3f:	08 43 6f             	or     BYTE PTR [bp+di+0x6f],al
    4b42:	75 74                	jne    0x4bb8
    4b44:	46                   	inc    si
    4b45:	69 78 65 0d 54       	imul   di,WORD PTR [bx+si+0x65],0x540d
    4b4a:	72 61                	jb     0x4bad
    4b4c:	6e                   	outs   dx,BYTE PTR ds:[si]
    4b4d:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    4b50:	73 49                	jae    0x4b9b
    4b52:	6d                   	ins    WORD PTR es:[di],dx
    4b53:	6d                   	ins    WORD PTR es:[di],dx
    4b54:	6f                   	outs   dx,WORD PTR ds:[si]
    4b55:	62 11                	bound  dx,DWORD PTR [bx+di]
    4b57:	53                   	push   bx
    4b58:	75 70                	jne    0x4bca
    4b5a:	70 6c                	jo     0x4bc8
    4b5c:	65 6d                	gs ins WORD PTR es:[di],dx
    4b5e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4b60:	74 54                	je     0x4bb6
    4b62:	72 61                	jb     0x4bc5
    4b64:	6e                   	outs   dx,BYTE PTR ds:[si]
    4b65:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    4b68:	12 50 72             	adc    dl,BYTE PTR [bx+si+0x72]
    4b6b:	6f                   	outs   dx,WORD PTR ds:[si]
    4b6c:	64 75 63             	fs jne 0x4bd2
    4b6f:	74 69                	je     0x4bda
    4b71:	66 73 50             	data32 jae 0x4bc4
    4b74:	61                   	popa
    4b75:	72 43                	jb     0x4bba
    4b77:	61                   	popa
    4b78:	64 72 65             	fs jb  0x4be0
    4b7b:	0b 41 73             	or     ax,WORD PTR [bx+di+0x73]
    4b7e:	73 75                	jae    0x4bf5
    4b80:	72 61                	jb     0x4be3
    4b82:	6e                   	outs   dx,BYTE PTR ds:[si]
    4b83:	63 65 50             	arpl   WORD PTR [di+0x50],sp
    4b86:	63 00                	arpl   WORD PTR [bx+si],ax
    4b88:	00 80 40 0f          	add    BYTE PTR [bx+si+0xf40],al
    4b8c:	44                   	inc    sp
    4b8d:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    4b91:	76 65                	jbe    0x4bf8
    4b93:	72 74                	jb     0x4c09
    4b95:	41                   	inc    cx
    4b96:	75 74                	jne    0x4c0c
    4b98:	6f                   	outs   dx,WORD PTR ds:[si]
    4b99:	50                   	push   ax
    4b9a:	63 0a                	arpl   WORD PTR [bp+si],cx
    4b9c:	49                   	dec    cx
    4b9d:	6e                   	outs   dx,BYTE PTR ds:[si]
    4b9e:	64 69 63 65 50 72    	imul   sp,WORD PTR fs:[bp+di+0x65],0x7250
    4ba4:	69 78 00 00 48       	imul   di,WORD PTR [bx+si+0x0],0x4800
    4ba9:	42                   	inc    dx
    4baa:	01 00                	add    WORD PTR [bx+si],ax
    4bac:	00 00                	add    BYTE PTR [bx+si],al
    4bae:	02 00                	add    al,BYTE PTR [bx+si]
    4bb0:	00 00                	add    BYTE PTR [bx+si],al
    4bb2:	0b 50 72             	or     dx,WORD PTR [bx+si+0x72]
    4bb5:	69 78 4d 69 6e       	imul   di,WORD PTR [bx+si+0x4d],0x6e69
    4bba:	69 6d 75 6d 0b       	imul   bp,WORD PTR [di+0x75],0xb6d
    4bbf:	50                   	push   ax
    4bc0:	72 69                	jb     0x4c2b
    4bc2:	78 4d                	js     0x4c11
    4bc4:	61                   	popa
    4bc5:	78 69                	js     0x4c30
    4bc7:	6d                   	ins    WORD PTR es:[di],dx
    4bc8:	75 6d                	jne    0x4c37
    4bca:	12 49 6e             	adc    cl,BYTE PTR [bx+di+0x6e]
    4bcd:	64 69 63 65 43 6f    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6f43
    4bd3:	6e                   	outs   dx,BYTE PTR ds:[si]
    4bd4:	6a 6f                	push   0x6f
    4bd6:	6e                   	outs   dx,BYTE PTR ds:[si]
    4bd7:	63 74 75             	arpl   WORD PTR [si+0x75],si
    4bda:	72 65                	jb     0x4c41
    4bdc:	6c                   	ins    BYTE PTR es:[di],dx
    4bdd:	00 00                	add    BYTE PTR [bx+si],al
    4bdf:	00 bf 00 00          	add    BYTE PTR [bx+0x0],bh
    4be3:	00 3f                	add    BYTE PTR [bx],bh
    4be5:	0b 43 6f             	or     ax,WORD PTR [bp+di+0x6f]
    4be8:	75 74                	jne    0x4c5e
    4bea:	4d                   	dec    bp
    4beb:	61                   	popa
    4bec:	74 69                	je     0x4c57
    4bee:	65 72 65             	gs jb  0x4c56
    4bf1:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    4bf4:	69 64 73 50 72       	imul   sp,WORD PTR [si+0x73],0x7250
    4bf9:	69 78 00 00 80       	imul   di,WORD PTR [bx+si+0x0],0x8000
    4bfe:	3f                   	aas
    4bff:	0e                   	push   cs
    4c00:	50                   	push   ax
    4c01:	6f                   	outs   dx,WORD PTR ds:[si]
    4c02:	69 64 73 50 75       	imul   sp,WORD PTR [si+0x73],0x7550
    4c07:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    4c0a:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    4c0d:	65 0f                	gs movmskps ebp,(bad)
    4c0f:	50                   	push   ax
    4c10:	6f                   	outs   dx,WORD PTR ds:[si]
    4c11:	69 64 73 46 6f       	imul   sp,WORD PTR [si+0x73],0x6f46
    4c16:	72 63                	jb     0x4c7b
    4c18:	65 56                	gs push si
    4c1a:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4c1c:	74 65                	je     0x4c83
    4c1e:	0b 50 6f             	or     dx,WORD PTR [bx+si+0x6f]
    4c21:	69 64 73 43 72       	imul   sp,WORD PTR [si+0x73],0x7243
    4c26:	65 64 69 74 0c 50 6f 	gs imul si,WORD PTR fs:[si+0xc],0x6f50
    4c2d:	69 64 73 51 75       	imul   sp,WORD PTR [si+0x73],0x7551
    4c32:	61                   	popa
    4c33:	6c                   	ins    BYTE PTR es:[di],dx
    4c34:	69 74 65 01 00       	imul   si,WORD PTR [si+0x65],0x1
    4c39:	00 00                	add    BYTE PTR [bx+si],al
    4c3b:	05 00 00             	add    ax,0x0
    4c3e:	00 00                	add    BYTE PTR [bx+si],al
    4c40:	80 ff ff             	cmp    bh,0xff
    4c43:	ff                   	(bad)
    4c44:	7f 00                	jg     0x4c46
    4c46:	00 11                	add    BYTE PTR [bx+di],dl
    4c48:	50                   	push   ax
    4c49:	6f                   	outs   dx,WORD PTR ds:[si]
    4c4a:	69 64 73 46 69       	imul   sp,WORD PTR [si+0x73],0x6946
    4c4f:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
    4c52:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    4c57:	6f                   	outs   dx,WORD PTR ds:[si]
    4c58:	6e                   	outs   dx,BYTE PTR ds:[si]
    4c59:	12 41 70             	adc    al,BYTE PTR [bx+di+0x70]
    4c5c:	70 65                	jo     0x4cc3
    4c5e:	6c                   	ins    BYTE PTR es:[di],dx
    4c5f:	4f                   	dec    di
    4c60:	66 66 72 65          	data32 data32 jb 0x4cc9
    4c64:	51                   	push   cx
    4c65:	75 61                	jne    0x4cc8
    4c67:	6e                   	outs   dx,BYTE PTR ds:[si]
    4c68:	74 69                	je     0x4cd3
    4c6a:	74 65                	je     0x4cd1
    4c6c:	11 41 70             	adc    WORD PTR [bx+di+0x70],ax
    4c6f:	70 65                	jo     0x4cd6
    4c71:	6c                   	ins    BYTE PTR es:[di],dx
    4c72:	4f                   	dec    di
    4c73:	66 66 72 65          	data32 data32 jb 0x4cdc
    4c77:	50                   	push   ax
    4c78:	72 69                	jb     0x4ce3
    4c7a:	78 4d                	js     0x4cc9
    4c7c:	61                   	popa
    4c7d:	78 eb                	js     0x4c6a
    4c7f:	ff                   	(bad)
    4c80:	ff                   	(bad)
    4c81:	ff                   	(bad)
    4c82:	ff                   	(bad)
    4c83:	ff                   	(bad)
    4c84:	ff 02                	inc    WORD PTR [bp+si]
    4c86:	55                   	push   bp
    4c87:	89 e5                	mov    bp,sp
    4c89:	b8 90 01             	mov    ax,0x190
    4c8c:	9a 44 04 f6 56       	call   0x56f6:0x444
    4c91:	81 ec 90 01          	sub    sp,0x190
    4c95:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    4c9a:	7c 08                	jl     0x4ca4
    4c9c:	c7 86 7c ff 02 00    	mov    WORD PTR [bp-0x84],0x2
    4ca2:	eb 06                	jmp    0x4caa
    4ca4:	c7 86 7c ff 01 00    	mov    WORD PTR [bp-0x84],0x1
    4caa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cad:	26 8b 85 bc 01       	mov    ax,WORD PTR es:[di+0x1bc]
    4cb2:	26 8b 95 be 01       	mov    dx,WORD PTR es:[di+0x1be]
    4cb7:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    4cba:	89 56 8a             	mov    WORD PTR [bp-0x76],dx
    4cbd:	26 8b 85 c0 01       	mov    ax,WORD PTR es:[di+0x1c0]
    4cc2:	26 8b 95 c2 01       	mov    dx,WORD PTR es:[di+0x1c2]
    4cc7:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
    4cca:	89 56 8e             	mov    WORD PTR [bp-0x72],dx
    4ccd:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    4cd2:	89 be 74 ff          	mov    WORD PTR [bp-0x8c],di
    4cd6:	8c 86 76 ff          	mov    WORD PTR [bp-0x8a],es
    4cda:	bf 2c 4a             	mov    di,0x4a2c
    4cdd:	0e                   	push   cs
    4cde:	57                   	push   di
    4cdf:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    4ce3:	06                   	push   es
    4ce4:	57                   	push   di
    4ce5:	9a 9b 3b 67 4d       	call   0x4d67:0x3b9b
    4cea:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    4ced:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    4cf0:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    4cf3:	06                   	push   es
    4cf4:	57                   	push   di
    4cf5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cf8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cfc:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    4d00:	90                   	nop
    4d01:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    4d06:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    4d0c:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    4d11:	90                   	nop
    4d12:	9b                   	fwait
    4d13:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    4d17:	9e                   	sahf
    4d18:	b0 00                	mov    al,0x0
    4d1a:	76 01                	jbe    0x4d1d
    4d1c:	40                   	inc    ax
    4d1d:	8a d0                	mov    dl,al
    4d1f:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4d23:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    4d29:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4d2e:	90                   	nop
    4d2f:	9b                   	fwait
    4d30:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4d34:	9e                   	sahf
    4d35:	b0 00                	mov    al,0x0
    4d37:	73 01                	jae    0x4d3a
    4d39:	40                   	inc    ax
    4d3a:	0a c2                	or     al,dl
    4d3c:	08 c0                	or     al,al
    4d3e:	74 0f                	je     0x4d4f
    4d40:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    4d43:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4d49:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4d4f:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4d53:	9b dd 5e a4          	fstp   QWORD PTR [bp-0x5c]
    4d57:	90                   	nop
    4d58:	9b                   	fwait
    4d59:	bf 42 4a             	mov    di,0x4a42
    4d5c:	0e                   	push   cs
    4d5d:	57                   	push   di
    4d5e:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    4d62:	06                   	push   es
    4d63:	57                   	push   di
    4d64:	9a 9b 3b e6 4d       	call   0x4de6:0x3b9b
    4d69:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    4d6c:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    4d6f:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    4d72:	06                   	push   es
    4d73:	57                   	push   di
    4d74:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d77:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d7b:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    4d7f:	90                   	nop
    4d80:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    4d85:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    4d8b:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    4d90:	90                   	nop
    4d91:	9b                   	fwait
    4d92:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    4d96:	9e                   	sahf
    4d97:	b0 00                	mov    al,0x0
    4d99:	76 01                	jbe    0x4d9c
    4d9b:	40                   	inc    ax
    4d9c:	8a d0                	mov    dl,al
    4d9e:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4da2:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    4da8:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4dad:	90                   	nop
    4dae:	9b                   	fwait
    4daf:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4db3:	9e                   	sahf
    4db4:	b0 00                	mov    al,0x0
    4db6:	73 01                	jae    0x4db9
    4db8:	40                   	inc    ax
    4db9:	0a c2                	or     al,dl
    4dbb:	08 c0                	or     al,al
    4dbd:	74 0f                	je     0x4dce
    4dbf:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    4dc2:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4dc8:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4dce:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4dd2:	9b dd 5e ac          	fstp   QWORD PTR [bp-0x54]
    4dd6:	90                   	nop
    4dd7:	9b                   	fwait
    4dd8:	bf 4e 4a             	mov    di,0x4a4e
    4ddb:	0e                   	push   cs
    4ddc:	57                   	push   di
    4ddd:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    4de1:	06                   	push   es
    4de2:	57                   	push   di
    4de3:	9a 9b 3b 65 4e       	call   0x4e65:0x3b9b
    4de8:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    4deb:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    4dee:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4df1:	06                   	push   es
    4df2:	57                   	push   di
    4df3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4df6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4dfa:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    4dfe:	90                   	nop
    4dff:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    4e04:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    4e0a:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    4e0f:	90                   	nop
    4e10:	9b                   	fwait
    4e11:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    4e15:	9e                   	sahf
    4e16:	b0 00                	mov    al,0x0
    4e18:	76 01                	jbe    0x4e1b
    4e1a:	40                   	inc    ax
    4e1b:	8a d0                	mov    dl,al
    4e1d:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4e21:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    4e27:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4e2c:	90                   	nop
    4e2d:	9b                   	fwait
    4e2e:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4e32:	9e                   	sahf
    4e33:	b0 00                	mov    al,0x0
    4e35:	73 01                	jae    0x4e38
    4e37:	40                   	inc    ax
    4e38:	0a c2                	or     al,dl
    4e3a:	08 c0                	or     al,al
    4e3c:	74 0f                	je     0x4e4d
    4e3e:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4e41:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4e47:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4e4d:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4e51:	9b dd 5e b4          	fstp   QWORD PTR [bp-0x4c]
    4e55:	90                   	nop
    4e56:	9b                   	fwait
    4e57:	bf 60 4a             	mov    di,0x4a60
    4e5a:	0e                   	push   cs
    4e5b:	57                   	push   di
    4e5c:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    4e60:	06                   	push   es
    4e61:	57                   	push   di
    4e62:	9a 9b 3b c4 4f       	call   0x4fc4:0x3b9b
    4e67:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4e6a:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    4e6d:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    4e70:	06                   	push   es
    4e71:	57                   	push   di
    4e72:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e75:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4e79:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    4e7d:	90                   	nop
    4e7e:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    4e83:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    4e89:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    4e8e:	90                   	nop
    4e8f:	9b                   	fwait
    4e90:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    4e94:	9e                   	sahf
    4e95:	b0 00                	mov    al,0x0
    4e97:	76 01                	jbe    0x4e9a
    4e99:	40                   	inc    ax
    4e9a:	8a d0                	mov    dl,al
    4e9c:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4ea0:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    4ea6:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4eab:	90                   	nop
    4eac:	9b                   	fwait
    4ead:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4eb1:	9e                   	sahf
    4eb2:	b0 00                	mov    al,0x0
    4eb4:	73 01                	jae    0x4eb7
    4eb6:	40                   	inc    ax
    4eb7:	0a c2                	or     al,dl
    4eb9:	08 c0                	or     al,al
    4ebb:	74 0f                	je     0x4ecc
    4ebd:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    4ec0:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4ec6:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4ecc:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4ed0:	9b dd 5e bc          	fstp   QWORD PTR [bp-0x44]
    4ed4:	90                   	nop
    4ed5:	9b                   	fwait
    4ed6:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    4edb:	7c 34                	jl     0x4f11
    4edd:	9b dd 46 a4          	fld    QWORD PTR [bp-0x5c]
    4ee1:	9b dc 5e ac          	fcomp  QWORD PTR [bp-0x54]
    4ee5:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4eea:	90                   	nop
    4eeb:	9b                   	fwait
    4eec:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4ef0:	9e                   	sahf
    4ef1:	76 1e                	jbe    0x4f11
    4ef3:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    4ef6:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4efc:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4f02:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    4f05:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4f0b:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4f11:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    4f16:	7c 6a                	jl     0x4f82
    4f18:	9b dd 46 ac          	fld    QWORD PTR [bp-0x54]
    4f1c:	9b dc 5e b4          	fcomp  QWORD PTR [bp-0x4c]
    4f20:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4f25:	90                   	nop
    4f26:	9b                   	fwait
    4f27:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4f2b:	9e                   	sahf
    4f2c:	76 1e                	jbe    0x4f4c
    4f2e:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    4f31:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4f37:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4f3d:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4f40:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4f46:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4f4c:	9b dd 46 b4          	fld    QWORD PTR [bp-0x4c]
    4f50:	9b dc 5e bc          	fcomp  QWORD PTR [bp-0x44]
    4f54:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4f59:	90                   	nop
    4f5a:	9b                   	fwait
    4f5b:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4f5f:	9e                   	sahf
    4f60:	76 1e                	jbe    0x4f80
    4f62:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4f65:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4f6b:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4f71:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    4f74:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4f7a:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4f80:	eb 34                	jmp    0x4fb6
    4f82:	9b dd 46 ac          	fld    QWORD PTR [bp-0x54]
    4f86:	9b dc 5e bc          	fcomp  QWORD PTR [bp-0x44]
    4f8a:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    4f8f:	90                   	nop
    4f90:	9b                   	fwait
    4f91:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    4f95:	9e                   	sahf
    4f96:	76 1e                	jbe    0x4fb6
    4f98:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    4f9b:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4fa1:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4fa7:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    4faa:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4fb0:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4fb6:	bf 73 4a             	mov    di,0x4a73
    4fb9:	0e                   	push   cs
    4fba:	57                   	push   di
    4fbb:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    4fbf:	06                   	push   es
    4fc0:	57                   	push   di
    4fc1:	9a 9b 3b 39 50       	call   0x5039:0x3b9b
    4fc6:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    4fc9:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    4fcc:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    4fcf:	06                   	push   es
    4fd0:	57                   	push   di
    4fd1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fd4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4fd8:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    4fdc:	90                   	nop
    4fdd:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    4fe2:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    4fe8:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    4fed:	90                   	nop
    4fee:	9b                   	fwait
    4fef:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    4ff3:	9e                   	sahf
    4ff4:	b0 00                	mov    al,0x0
    4ff6:	76 01                	jbe    0x4ff9
    4ff8:	40                   	inc    ax
    4ff9:	8a d0                	mov    dl,al
    4ffb:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    4fff:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5005:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    500a:	90                   	nop
    500b:	9b                   	fwait
    500c:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    5010:	9e                   	sahf
    5011:	b0 00                	mov    al,0x0
    5013:	73 01                	jae    0x5016
    5015:	40                   	inc    ax
    5016:	0a c2                	or     al,dl
    5018:	08 c0                	or     al,al
    501a:	74 0f                	je     0x502b
    501c:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    501f:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5025:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    502b:	bf 7b 4a             	mov    di,0x4a7b
    502e:	0e                   	push   cs
    502f:	57                   	push   di
    5030:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5034:	06                   	push   es
    5035:	57                   	push   di
    5036:	9a 9b 3b be 50       	call   0x50be:0x3b9b
    503b:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    503e:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5041:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5044:	06                   	push   es
    5045:	57                   	push   di
    5046:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5049:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    504d:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5051:	90                   	nop
    5052:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    5057:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    505d:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5062:	90                   	nop
    5063:	9b                   	fwait
    5064:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5068:	9e                   	sahf
    5069:	b0 00                	mov    al,0x0
    506b:	76 01                	jbe    0x506e
    506d:	40                   	inc    ax
    506e:	8a d0                	mov    dl,al
    5070:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5074:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    507a:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    507f:	90                   	nop
    5080:	9b                   	fwait
    5081:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    5085:	9e                   	sahf
    5086:	b0 00                	mov    al,0x0
    5088:	73 01                	jae    0x508b
    508a:	40                   	inc    ax
    508b:	0a c2                	or     al,dl
    508d:	08 c0                	or     al,al
    508f:	74 0f                	je     0x50a0
    5091:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5094:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    509a:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    50a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50a3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    50a8:	89 be 74 ff          	mov    WORD PTR [bp-0x8c],di
    50ac:	8c 86 76 ff          	mov    WORD PTR [bp-0x8a],es
    50b0:	bf 82 4a             	mov    di,0x4a82
    50b3:	0e                   	push   cs
    50b4:	57                   	push   di
    50b5:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    50b9:	06                   	push   es
    50ba:	57                   	push   di
    50bb:	9a 9b 3b 0d 51       	call   0x510d:0x3b9b
    50c0:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    50c3:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    50c6:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    50c9:	06                   	push   es
    50ca:	57                   	push   di
    50cb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50ce:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    50d2:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    50d6:	90                   	nop
    50d7:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    50dc:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    50e2:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    50e7:	90                   	nop
    50e8:	9b                   	fwait
    50e9:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    50ed:	9e                   	sahf
    50ee:	77 0f                	ja     0x50ff
    50f0:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    50f3:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    50f9:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    50ff:	bf 93 4a             	mov    di,0x4a93
    5102:	0e                   	push   cs
    5103:	57                   	push   di
    5104:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5108:	06                   	push   es
    5109:	57                   	push   di
    510a:	9a 9b 3b 5c 51       	call   0x515c:0x3b9b
    510f:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5112:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5115:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5118:	06                   	push   es
    5119:	57                   	push   di
    511a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    511d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5121:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5125:	90                   	nop
    5126:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    512b:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5131:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5136:	90                   	nop
    5137:	9b                   	fwait
    5138:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    513c:	9e                   	sahf
    513d:	77 0f                	ja     0x514e
    513f:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5142:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5148:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    514e:	bf a6 4a             	mov    di,0x4aa6
    5151:	0e                   	push   cs
    5152:	57                   	push   di
    5153:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5157:	06                   	push   es
    5158:	57                   	push   di
    5159:	9a 9b 3b ad 51       	call   0x51ad:0x3b9b
    515e:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5161:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5164:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5167:	06                   	push   es
    5168:	57                   	push   di
    5169:	26 c4 3d             	les    di,DWORD PTR es:[di]
    516c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5170:	9b dd 9e 7e ff       	fstp   QWORD PTR [bp-0x82]
    5175:	90                   	nop
    5176:	9b 9b dd 86 7e ff    	fld    QWORD PTR [bp-0x82]
    517c:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5182:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5187:	90                   	nop
    5188:	9b                   	fwait
    5189:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    518d:	9e                   	sahf
    518e:	77 0f                	ja     0x519f
    5190:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5193:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5199:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    519f:	bf b7 4a             	mov    di,0x4ab7
    51a2:	0e                   	push   cs
    51a3:	57                   	push   di
    51a4:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    51a8:	06                   	push   es
    51a9:	57                   	push   di
    51aa:	9a 9b 3b 21 52       	call   0x5221:0x3b9b
    51af:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    51b2:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    51b5:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    51b8:	06                   	push   es
    51b9:	57                   	push   di
    51ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51bd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    51c1:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    51c5:	90                   	nop
    51c6:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    51cb:	9b dc 9e 7e ff       	fcomp  QWORD PTR [bp-0x82]
    51d0:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    51d5:	90                   	nop
    51d6:	9b                   	fwait
    51d7:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    51db:	9e                   	sahf
    51dc:	b0 00                	mov    al,0x0
    51de:	76 01                	jbe    0x51e1
    51e0:	40                   	inc    ax
    51e1:	8a d0                	mov    dl,al
    51e3:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    51e7:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    51ed:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    51f2:	90                   	nop
    51f3:	9b                   	fwait
    51f4:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    51f8:	9e                   	sahf
    51f9:	b0 00                	mov    al,0x0
    51fb:	73 01                	jae    0x51fe
    51fd:	40                   	inc    ax
    51fe:	0a c2                	or     al,dl
    5200:	08 c0                	or     al,al
    5202:	74 0f                	je     0x5213
    5204:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5207:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    520d:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5213:	bf cb 4a             	mov    di,0x4acb
    5216:	0e                   	push   cs
    5217:	57                   	push   di
    5218:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    521c:	06                   	push   es
    521d:	57                   	push   di
    521e:	9a 9b 3b 70 52       	call   0x5270:0x3b9b
    5223:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5226:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5229:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    522c:	06                   	push   es
    522d:	57                   	push   di
    522e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5231:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5235:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5239:	90                   	nop
    523a:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    523f:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5245:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    524a:	90                   	nop
    524b:	9b                   	fwait
    524c:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    5250:	9e                   	sahf
    5251:	73 0f                	jae    0x5262
    5253:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5256:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    525c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5262:	bf da 4a             	mov    di,0x4ada
    5265:	0e                   	push   cs
    5266:	57                   	push   di
    5267:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    526b:	06                   	push   es
    526c:	57                   	push   di
    526d:	9a 9b 3b bf 52       	call   0x52bf:0x3b9b
    5272:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5275:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5278:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    527b:	06                   	push   es
    527c:	57                   	push   di
    527d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5280:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5284:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5288:	90                   	nop
    5289:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    528e:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5294:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5299:	90                   	nop
    529a:	9b                   	fwait
    529b:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    529f:	9e                   	sahf
    52a0:	77 0f                	ja     0x52b1
    52a2:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    52a5:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    52ab:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    52b1:	bf ed 4a             	mov    di,0x4aed
    52b4:	0e                   	push   cs
    52b5:	57                   	push   di
    52b6:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    52ba:	06                   	push   es
    52bb:	57                   	push   di
    52bc:	9a 9b 3b 0e 53       	call   0x530e:0x3b9b
    52c1:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    52c4:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    52c7:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    52ca:	06                   	push   es
    52cb:	57                   	push   di
    52cc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52cf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    52d3:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    52d7:	90                   	nop
    52d8:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    52dd:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    52e3:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    52e8:	90                   	nop
    52e9:	9b                   	fwait
    52ea:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    52ee:	9e                   	sahf
    52ef:	77 0f                	ja     0x5300
    52f1:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    52f4:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    52fa:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5300:	bf fe 4a             	mov    di,0x4afe
    5303:	0e                   	push   cs
    5304:	57                   	push   di
    5305:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5309:	06                   	push   es
    530a:	57                   	push   di
    530b:	9a 9b 3b 5d 53       	call   0x535d:0x3b9b
    5310:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5313:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5316:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5319:	06                   	push   es
    531a:	57                   	push   di
    531b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    531e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5322:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5326:	90                   	nop
    5327:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    532c:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5332:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5337:	90                   	nop
    5338:	9b                   	fwait
    5339:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    533d:	9e                   	sahf
    533e:	77 0f                	ja     0x534f
    5340:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5343:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5349:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    534f:	bf 0d 4b             	mov    di,0x4b0d
    5352:	0e                   	push   cs
    5353:	57                   	push   di
    5354:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5358:	06                   	push   es
    5359:	57                   	push   di
    535a:	9a 9b 3b ac 53       	call   0x53ac:0x3b9b
    535f:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5362:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5365:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5368:	06                   	push   es
    5369:	57                   	push   di
    536a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    536d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5371:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5375:	90                   	nop
    5376:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    537b:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5381:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5386:	90                   	nop
    5387:	9b                   	fwait
    5388:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    538c:	9e                   	sahf
    538d:	73 0f                	jae    0x539e
    538f:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5392:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5398:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    539e:	bf 1c 4b             	mov    di,0x4b1c
    53a1:	0e                   	push   cs
    53a2:	57                   	push   di
    53a3:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    53a7:	06                   	push   es
    53a8:	57                   	push   di
    53a9:	9a 9b 3b fb 53       	call   0x53fb:0x3b9b
    53ae:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    53b1:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    53b4:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    53b7:	06                   	push   es
    53b8:	57                   	push   di
    53b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53bc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    53c0:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    53c4:	90                   	nop
    53c5:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    53ca:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    53d0:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    53d5:	90                   	nop
    53d6:	9b                   	fwait
    53d7:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    53db:	9e                   	sahf
    53dc:	73 0f                	jae    0x53ed
    53de:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    53e1:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    53e7:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    53ed:	bf 2f 4b             	mov    di,0x4b2f
    53f0:	0e                   	push   cs
    53f1:	57                   	push   di
    53f2:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    53f6:	06                   	push   es
    53f7:	57                   	push   di
    53f8:	9a 9b 3b 70 54       	call   0x5470:0x3b9b
    53fd:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5400:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5403:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5406:	06                   	push   es
    5407:	57                   	push   di
    5408:	26 c4 3d             	les    di,DWORD PTR es:[di]
    540b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    540f:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5413:	90                   	nop
    5414:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    5419:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    541f:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5424:	90                   	nop
    5425:	9b                   	fwait
    5426:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    542a:	9e                   	sahf
    542b:	b0 00                	mov    al,0x0
    542d:	76 01                	jbe    0x5430
    542f:	40                   	inc    ax
    5430:	8a d0                	mov    dl,al
    5432:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5436:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    543c:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5441:	90                   	nop
    5442:	9b                   	fwait
    5443:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    5447:	9e                   	sahf
    5448:	b0 00                	mov    al,0x0
    544a:	73 01                	jae    0x544d
    544c:	40                   	inc    ax
    544d:	0a c2                	or     al,dl
    544f:	08 c0                	or     al,al
    5451:	74 0f                	je     0x5462
    5453:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5456:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    545c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5462:	bf 3f 4b             	mov    di,0x4b3f
    5465:	0e                   	push   cs
    5466:	57                   	push   di
    5467:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    546b:	06                   	push   es
    546c:	57                   	push   di
    546d:	9a 9b 3b bf 54       	call   0x54bf:0x3b9b
    5472:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5475:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5478:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    547b:	06                   	push   es
    547c:	57                   	push   di
    547d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5480:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5484:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5488:	90                   	nop
    5489:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    548e:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5494:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5499:	90                   	nop
    549a:	9b                   	fwait
    549b:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    549f:	9e                   	sahf
    54a0:	73 0f                	jae    0x54b1
    54a2:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    54a5:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    54ab:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    54b1:	bf 48 4b             	mov    di,0x4b48
    54b4:	0e                   	push   cs
    54b5:	57                   	push   di
    54b6:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    54ba:	06                   	push   es
    54bb:	57                   	push   di
    54bc:	9a 9b 3b 0e 55       	call   0x550e:0x3b9b
    54c1:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    54c4:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    54c7:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    54ca:	06                   	push   es
    54cb:	57                   	push   di
    54cc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54cf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    54d3:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    54d7:	90                   	nop
    54d8:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    54dd:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    54e3:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    54e8:	90                   	nop
    54e9:	9b                   	fwait
    54ea:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    54ee:	9e                   	sahf
    54ef:	73 0f                	jae    0x5500
    54f1:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    54f4:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    54fa:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5500:	bf 56 4b             	mov    di,0x4b56
    5503:	0e                   	push   cs
    5504:	57                   	push   di
    5505:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5509:	06                   	push   es
    550a:	57                   	push   di
    550b:	9a 9b 3b 5d 55       	call   0x555d:0x3b9b
    5510:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5513:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5516:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5519:	06                   	push   es
    551a:	57                   	push   di
    551b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    551e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5522:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5526:	90                   	nop
    5527:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    552c:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5532:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    5537:	90                   	nop
    5538:	9b                   	fwait
    5539:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    553d:	9e                   	sahf
    553e:	73 0f                	jae    0x554f
    5540:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5543:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5549:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    554f:	bf 68 4b             	mov    di,0x4b68
    5552:	0e                   	push   cs
    5553:	57                   	push   di
    5554:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5558:	06                   	push   es
    5559:	57                   	push   di
    555a:	9a 9b 3b a2 55       	call   0x55a2:0x3b9b
    555f:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5562:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5565:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5568:	06                   	push   es
    5569:	57                   	push   di
    556a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    556d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5571:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5574:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    5577:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    557b:	7c 08                	jl     0x5585
    557d:	7f 15                	jg     0x5594
    557f:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
    5583:	77 0f                	ja     0x5594
    5585:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5588:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    558e:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5594:	bf 7b 4b             	mov    di,0x4b7b
    5597:	0e                   	push   cs
    5598:	57                   	push   di
    5599:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    559d:	06                   	push   es
    559e:	57                   	push   di
    559f:	9a 9b 3b 17 56       	call   0x5617:0x3b9b
    55a4:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    55a7:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    55aa:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    55ad:	06                   	push   es
    55ae:	57                   	push   di
    55af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55b2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    55b6:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    55ba:	90                   	nop
    55bb:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    55c0:	9b 2e d8 1e 87 4b    	fcomp  DWORD PTR cs:0x4b87
    55c6:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    55cb:	90                   	nop
    55cc:	9b                   	fwait
    55cd:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    55d1:	9e                   	sahf
    55d2:	b0 00                	mov    al,0x0
    55d4:	76 01                	jbe    0x55d7
    55d6:	40                   	inc    ax
    55d7:	8a d0                	mov    dl,al
    55d9:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    55dd:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    55e3:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    55e8:	90                   	nop
    55e9:	9b                   	fwait
    55ea:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    55ee:	9e                   	sahf
    55ef:	b0 00                	mov    al,0x0
    55f1:	73 01                	jae    0x55f4
    55f3:	40                   	inc    ax
    55f4:	0a c2                	or     al,dl
    55f6:	08 c0                	or     al,al
    55f8:	74 0f                	je     0x5609
    55fa:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    55fd:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5603:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5609:	bf 8b 4b             	mov    di,0x4b8b
    560c:	0e                   	push   cs
    560d:	57                   	push   di
    560e:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5612:	06                   	push   es
    5613:	57                   	push   di
    5614:	9a 9b 3b 8c 56       	call   0x568c:0x3b9b
    5619:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    561c:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    561f:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5622:	06                   	push   es
    5623:	57                   	push   di
    5624:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5627:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    562b:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    562f:	90                   	nop
    5630:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    5635:	9b 2e d8 1e 3e 4a    	fcomp  DWORD PTR cs:0x4a3e
    563b:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5640:	90                   	nop
    5641:	9b                   	fwait
    5642:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5646:	9e                   	sahf
    5647:	b0 00                	mov    al,0x0
    5649:	76 01                	jbe    0x564c
    564b:	40                   	inc    ax
    564c:	8a d0                	mov    dl,al
    564e:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5652:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5658:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    565d:	90                   	nop
    565e:	9b                   	fwait
    565f:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    5663:	9e                   	sahf
    5664:	b0 00                	mov    al,0x0
    5666:	73 01                	jae    0x5669
    5668:	40                   	inc    ax
    5669:	0a c2                	or     al,dl
    566b:	08 c0                	or     al,al
    566d:	74 0f                	je     0x567e
    566f:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5672:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5678:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    567e:	bf 9b 4b             	mov    di,0x4b9b
    5681:	0e                   	push   cs
    5682:	57                   	push   di
    5683:	c4 be 74 ff          	les    di,DWORD PTR [bp-0x8c]
    5687:	06                   	push   es
    5688:	57                   	push   di
    5689:	9a 9b 3b 16 57       	call   0x5716:0x3b9b
    568e:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5691:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5694:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5697:	06                   	push   es
    5698:	57                   	push   di
    5699:	26 c4 3d             	les    di,DWORD PTR es:[di]
    569c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    56a0:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    56a4:	90                   	nop
    56a5:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    56aa:	9b d9 e1             	fabs
    56ad:	9b 2e d8 1e a6 4b    	fcomp  DWORD PTR cs:0x4ba6
    56b3:	9b dd be 72 ff       	fstsw  WORD PTR [bp-0x8e]
    56b8:	90                   	nop
    56b9:	9b                   	fwait
    56ba:	8a a6 73 ff          	mov    ah,BYTE PTR [bp-0x8d]
    56be:	9e                   	sahf
    56bf:	76 0f                	jbe    0x56d0
    56c1:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    56c4:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    56ca:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    56d0:	8b 86 7c ff          	mov    ax,WORD PTR [bp-0x84]
    56d4:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    56d8:	b8 01 00             	mov    ax,0x1
    56db:	3b 86 76 ff          	cmp    ax,WORD PTR [bp-0x8a]
    56df:	7e 03                	jle    0x56e4
    56e1:	e9 2a 06             	jmp    0x5d0e
    56e4:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    56e7:	eb 03                	jmp    0x56ec
    56e9:	ff 46 86             	inc    WORD PTR [bp-0x7a]
    56ec:	8b 46 86             	mov    ax,WORD PTR [bp-0x7a]
    56ef:	99                   	cwd
    56f0:	bf aa 4b             	mov    di,0x4baa
    56f3:	9a 16 04 13 5b       	call   0x5b13:0x416
    56f8:	8b f8                	mov    di,ax
    56fa:	c1 e7 02             	shl    di,0x2
    56fd:	c4 7b 84             	les    di,DWORD PTR [bp+di-0x7c]
    5700:	89 be 72 ff          	mov    WORD PTR [bp-0x8e],di
    5704:	8c 86 74 ff          	mov    WORD PTR [bp-0x8c],es
    5708:	bf b2 4b             	mov    di,0x4bb2
    570b:	0e                   	push   cs
    570c:	57                   	push   di
    570d:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5711:	06                   	push   es
    5712:	57                   	push   di
    5713:	9a 9b 3b 6f 57       	call   0x576f:0x3b9b
    5718:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    571b:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    571e:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5721:	06                   	push   es
    5722:	57                   	push   di
    5723:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5726:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    572a:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    572e:	90                   	nop
    572f:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    5734:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    573a:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    573f:	90                   	nop
    5740:	9b                   	fwait
    5741:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5745:	9e                   	sahf
    5746:	77 0f                	ja     0x5757
    5748:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    574b:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5751:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5757:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    575b:	9b dd 5e 9c          	fstp   QWORD PTR [bp-0x64]
    575f:	90                   	nop
    5760:	9b                   	fwait
    5761:	bf be 4b             	mov    di,0x4bbe
    5764:	0e                   	push   cs
    5765:	57                   	push   di
    5766:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    576a:	06                   	push   es
    576b:	57                   	push   di
    576c:	9a 9b 3b c6 57       	call   0x57c6:0x3b9b
    5771:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5774:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5777:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    577a:	06                   	push   es
    577b:	57                   	push   di
    577c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    577f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5783:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5787:	90                   	nop
    5788:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    578d:	9b dc 5e 9c          	fcomp  QWORD PTR [bp-0x64]
    5791:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5796:	90                   	nop
    5797:	9b                   	fwait
    5798:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    579c:	9e                   	sahf
    579d:	77 0f                	ja     0x57ae
    579f:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    57a2:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    57a8:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    57ae:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    57b2:	9b dd 5e 94          	fstp   QWORD PTR [bp-0x6c]
    57b6:	90                   	nop
    57b7:	9b                   	fwait
    57b8:	bf ca 4b             	mov    di,0x4bca
    57bb:	0e                   	push   cs
    57bc:	57                   	push   di
    57bd:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    57c1:	06                   	push   es
    57c2:	57                   	push   di
    57c3:	9a 9b 3b 3b 58       	call   0x583b:0x3b9b
    57c8:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    57cb:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    57ce:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    57d1:	06                   	push   es
    57d2:	57                   	push   di
    57d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57d6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    57da:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    57de:	90                   	nop
    57df:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    57e4:	9b 2e d8 1e e1 4b    	fcomp  DWORD PTR cs:0x4be1
    57ea:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    57ef:	90                   	nop
    57f0:	9b                   	fwait
    57f1:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    57f5:	9e                   	sahf
    57f6:	b0 00                	mov    al,0x0
    57f8:	76 01                	jbe    0x57fb
    57fa:	40                   	inc    ax
    57fb:	8a d0                	mov    dl,al
    57fd:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5801:	9b 2e d8 1e dd 4b    	fcomp  DWORD PTR cs:0x4bdd
    5807:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    580c:	90                   	nop
    580d:	9b                   	fwait
    580e:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5812:	9e                   	sahf
    5813:	b0 00                	mov    al,0x0
    5815:	73 01                	jae    0x5818
    5817:	40                   	inc    ax
    5818:	0a c2                	or     al,dl
    581a:	08 c0                	or     al,al
    581c:	74 0f                	je     0x582d
    581e:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5821:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5827:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    582d:	bf e5 4b             	mov    di,0x4be5
    5830:	0e                   	push   cs
    5831:	57                   	push   di
    5832:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5836:	06                   	push   es
    5837:	57                   	push   di
    5838:	9a 9b 3b 8f 58       	call   0x588f:0x3b9b
    583d:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5840:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5843:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5846:	06                   	push   es
    5847:	57                   	push   di
    5848:	26 c4 3d             	les    di,DWORD PTR es:[di]
    584b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    584f:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5853:	90                   	nop
    5854:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    5859:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    585f:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5864:	90                   	nop
    5865:	9b                   	fwait
    5866:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    586a:	9e                   	sahf
    586b:	77 0f                	ja     0x587c
    586d:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5870:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5876:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    587c:	c6 86 79 ff 00       	mov    BYTE PTR [bp-0x87],0x0
    5881:	bf f1 4b             	mov    di,0x4bf1
    5884:	0e                   	push   cs
    5885:	57                   	push   di
    5886:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    588a:	06                   	push   es
    588b:	57                   	push   di
    588c:	9a 9b 3b 09 59       	call   0x5909:0x3b9b
    5891:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    5894:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    5897:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    589a:	06                   	push   es
    589b:	57                   	push   di
    589c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    589f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    58a3:	9b dd 5e a4          	fstp   QWORD PTR [bp-0x5c]
    58a7:	90                   	nop
    58a8:	9b 9b dd 46 a4       	fld    QWORD PTR [bp-0x5c]
    58ad:	9b 2e d8 1e fb 4b    	fcomp  DWORD PTR cs:0x4bfb
    58b3:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    58b8:	90                   	nop
    58b9:	9b                   	fwait
    58ba:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    58be:	9e                   	sahf
    58bf:	b0 00                	mov    al,0x0
    58c1:	76 01                	jbe    0x58c4
    58c3:	40                   	inc    ax
    58c4:	8a d0                	mov    dl,al
    58c6:	9b dd 46 a4          	fld    QWORD PTR [bp-0x5c]
    58ca:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    58d0:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    58d5:	90                   	nop
    58d6:	9b                   	fwait
    58d7:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    58db:	9e                   	sahf
    58dc:	b0 00                	mov    al,0x0
    58de:	73 01                	jae    0x58e1
    58e0:	40                   	inc    ax
    58e1:	0a c2                	or     al,dl
    58e3:	08 c0                	or     al,al
    58e5:	74 14                	je     0x58fb
    58e7:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    58ea:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    58f0:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    58f6:	c6 86 79 ff 01       	mov    BYTE PTR [bp-0x87],0x1
    58fb:	bf ff 4b             	mov    di,0x4bff
    58fe:	0e                   	push   cs
    58ff:	57                   	push   di
    5900:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5904:	06                   	push   es
    5905:	57                   	push   di
    5906:	9a 9b 3b 83 59       	call   0x5983:0x3b9b
    590b:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    590e:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    5911:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    5914:	06                   	push   es
    5915:	57                   	push   di
    5916:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5919:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    591d:	9b dd 5e ac          	fstp   QWORD PTR [bp-0x54]
    5921:	90                   	nop
    5922:	9b 9b dd 46 ac       	fld    QWORD PTR [bp-0x54]
    5927:	9b 2e d8 1e fb 4b    	fcomp  DWORD PTR cs:0x4bfb
    592d:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    5932:	90                   	nop
    5933:	9b                   	fwait
    5934:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    5938:	9e                   	sahf
    5939:	b0 00                	mov    al,0x0
    593b:	76 01                	jbe    0x593e
    593d:	40                   	inc    ax
    593e:	8a d0                	mov    dl,al
    5940:	9b dd 46 ac          	fld    QWORD PTR [bp-0x54]
    5944:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    594a:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    594f:	90                   	nop
    5950:	9b                   	fwait
    5951:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5955:	9e                   	sahf
    5956:	b0 00                	mov    al,0x0
    5958:	73 01                	jae    0x595b
    595a:	40                   	inc    ax
    595b:	0a c2                	or     al,dl
    595d:	08 c0                	or     al,al
    595f:	74 14                	je     0x5975
    5961:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5964:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    596a:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5970:	c6 86 79 ff 01       	mov    BYTE PTR [bp-0x87],0x1
    5975:	bf 0e 4c             	mov    di,0x4c0e
    5978:	0e                   	push   cs
    5979:	57                   	push   di
    597a:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    597e:	06                   	push   es
    597f:	57                   	push   di
    5980:	9a 9b 3b fd 59       	call   0x59fd:0x3b9b
    5985:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    5988:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    598b:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    598e:	06                   	push   es
    598f:	57                   	push   di
    5990:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5993:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5997:	9b dd 5e b4          	fstp   QWORD PTR [bp-0x4c]
    599b:	90                   	nop
    599c:	9b 9b dd 46 b4       	fld    QWORD PTR [bp-0x4c]
    59a1:	9b 2e d8 1e fb 4b    	fcomp  DWORD PTR cs:0x4bfb
    59a7:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    59ac:	90                   	nop
    59ad:	9b                   	fwait
    59ae:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    59b2:	9e                   	sahf
    59b3:	b0 00                	mov    al,0x0
    59b5:	76 01                	jbe    0x59b8
    59b7:	40                   	inc    ax
    59b8:	8a d0                	mov    dl,al
    59ba:	9b dd 46 b4          	fld    QWORD PTR [bp-0x4c]
    59be:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    59c4:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    59c9:	90                   	nop
    59ca:	9b                   	fwait
    59cb:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    59cf:	9e                   	sahf
    59d0:	b0 00                	mov    al,0x0
    59d2:	73 01                	jae    0x59d5
    59d4:	40                   	inc    ax
    59d5:	0a c2                	or     al,dl
    59d7:	08 c0                	or     al,al
    59d9:	74 14                	je     0x59ef
    59db:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    59de:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    59e4:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    59ea:	c6 86 79 ff 01       	mov    BYTE PTR [bp-0x87],0x1
    59ef:	bf 1e 4c             	mov    di,0x4c1e
    59f2:	0e                   	push   cs
    59f3:	57                   	push   di
    59f4:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    59f8:	06                   	push   es
    59f9:	57                   	push   di
    59fa:	9a 9b 3b 77 5a       	call   0x5a77:0x3b9b
    59ff:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    5a02:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    5a05:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5a08:	06                   	push   es
    5a09:	57                   	push   di
    5a0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a0d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5a11:	9b dd 5e bc          	fstp   QWORD PTR [bp-0x44]
    5a15:	90                   	nop
    5a16:	9b 9b dd 46 bc       	fld    QWORD PTR [bp-0x44]
    5a1b:	9b 2e d8 1e fb 4b    	fcomp  DWORD PTR cs:0x4bfb
    5a21:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    5a26:	90                   	nop
    5a27:	9b                   	fwait
    5a28:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    5a2c:	9e                   	sahf
    5a2d:	b0 00                	mov    al,0x0
    5a2f:	76 01                	jbe    0x5a32
    5a31:	40                   	inc    ax
    5a32:	8a d0                	mov    dl,al
    5a34:	9b dd 46 bc          	fld    QWORD PTR [bp-0x44]
    5a38:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5a3e:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5a43:	90                   	nop
    5a44:	9b                   	fwait
    5a45:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5a49:	9e                   	sahf
    5a4a:	b0 00                	mov    al,0x0
    5a4c:	73 01                	jae    0x5a4f
    5a4e:	40                   	inc    ax
    5a4f:	0a c2                	or     al,dl
    5a51:	08 c0                	or     al,al
    5a53:	74 14                	je     0x5a69
    5a55:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5a58:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5a5e:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5a64:	c6 86 79 ff 01       	mov    BYTE PTR [bp-0x87],0x1
    5a69:	bf 2a 4c             	mov    di,0x4c2a
    5a6c:	0e                   	push   cs
    5a6d:	57                   	push   di
    5a6e:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5a72:	06                   	push   es
    5a73:	57                   	push   di
    5a74:	9a 9b 3b ac 5b       	call   0x5bac:0x3b9b
    5a79:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5a7c:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    5a7f:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    5a82:	06                   	push   es
    5a83:	57                   	push   di
    5a84:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a87:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5a8b:	9b dd 5e c4          	fstp   QWORD PTR [bp-0x3c]
    5a8f:	90                   	nop
    5a90:	9b 9b dd 46 c4       	fld    QWORD PTR [bp-0x3c]
    5a95:	9b 2e d8 1e fb 4b    	fcomp  DWORD PTR cs:0x4bfb
    5a9b:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    5aa0:	90                   	nop
    5aa1:	9b                   	fwait
    5aa2:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    5aa6:	9e                   	sahf
    5aa7:	b0 00                	mov    al,0x0
    5aa9:	76 01                	jbe    0x5aac
    5aab:	40                   	inc    ax
    5aac:	8a d0                	mov    dl,al
    5aae:	9b dd 46 c4          	fld    QWORD PTR [bp-0x3c]
    5ab2:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5ab8:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5abd:	90                   	nop
    5abe:	9b                   	fwait
    5abf:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5ac3:	9e                   	sahf
    5ac4:	b0 00                	mov    al,0x0
    5ac6:	73 01                	jae    0x5ac9
    5ac8:	40                   	inc    ax
    5ac9:	0a c2                	or     al,dl
    5acb:	08 c0                	or     al,al
    5acd:	74 14                	je     0x5ae3
    5acf:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5ad2:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5ad8:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5ade:	c6 86 79 ff 01       	mov    BYTE PTR [bp-0x87],0x1
    5ae3:	80 be 79 ff 00       	cmp    BYTE PTR [bp-0x87],0x0
    5ae8:	74 03                	je     0x5aed
    5aea:	e9 b1 00             	jmp    0x5b9e
    5aed:	31 c0                	xor    ax,ax
    5aef:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    5af3:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    5af8:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
    5afd:	eb 08                	jmp    0x5b07
    5aff:	83 46 f2 01          	add    WORD PTR [bp-0xe],0x1
    5b03:	83 56 f4 00          	adc    WORD PTR [bp-0xc],0x0
    5b07:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5b0a:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5b0d:	bf 37 4c             	mov    di,0x4c37
    5b10:	9a 16 04 27 5b       	call   0x5b27:0x416
    5b15:	8b f8                	mov    di,ax
    5b17:	c1 e7 03             	shl    di,0x3
    5b1a:	9b dd 43 9c          	fld    QWORD PTR [bp+di-0x64]
    5b1e:	9b 2e d8 0e 3e 4a    	fmul   DWORD PTR cs:0x4a3e
    5b24:	9a 2f 10 3b 5b       	call   0x5b3b:0x102f
    5b29:	8b c8                	mov    cx,ax
    5b2b:	8b da                	mov    bx,dx
    5b2d:	8b 86 7a ff          	mov    ax,WORD PTR [bp-0x86]
    5b31:	99                   	cwd
    5b32:	03 c1                	add    ax,cx
    5b34:	13 d3                	adc    dx,bx
    5b36:	71 05                	jno    0x5b3d
    5b38:	9a 3e 04 43 5b       	call   0x5b43:0x43e
    5b3d:	bf 3f 4c             	mov    di,0x4c3f
    5b40:	9a 16 04 7c 5b       	call   0x5b7c:0x416
    5b45:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    5b49:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    5b4d:	75 b0                	jne    0x5aff
    5b4f:	83 7e f2 05          	cmp    WORD PTR [bp-0xe],0x5
    5b53:	75 aa                	jne    0x5aff
    5b55:	83 be 7a ff 64       	cmp    WORD PTR [bp-0x86],0x64
    5b5a:	74 42                	je     0x5b9e
    5b5c:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    5b61:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
    5b66:	eb 08                	jmp    0x5b70
    5b68:	83 46 f2 01          	add    WORD PTR [bp-0xe],0x1
    5b6c:	83 56 f4 00          	adc    WORD PTR [bp-0xc],0x0
    5b70:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5b73:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5b76:	bf 37 4c             	mov    di,0x4c37
    5b79:	9a 16 04 24 5d       	call   0x5d24:0x416
    5b7e:	8b f8                	mov    di,ax
    5b80:	c1 e7 02             	shl    di,0x2
    5b83:	c4 7b c8             	les    di,DWORD PTR [bp+di-0x38]
    5b86:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5b8c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5b92:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    5b96:	75 d0                	jne    0x5b68
    5b98:	83 7e f2 05          	cmp    WORD PTR [bp-0xe],0x5
    5b9c:	75 ca                	jne    0x5b68
    5b9e:	bf 47 4c             	mov    di,0x4c47
    5ba1:	0e                   	push   cs
    5ba2:	57                   	push   di
    5ba3:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5ba7:	06                   	push   es
    5ba8:	57                   	push   di
    5ba9:	9a 9b 3b 21 5c       	call   0x5c21:0x3b9b
    5bae:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5bb1:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5bb4:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5bb7:	06                   	push   es
    5bb8:	57                   	push   di
    5bb9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5bbc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5bc0:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5bc4:	90                   	nop
    5bc5:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    5bca:	9b 2e d8 1e fb 4b    	fcomp  DWORD PTR cs:0x4bfb
    5bd0:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    5bd5:	90                   	nop
    5bd6:	9b                   	fwait
    5bd7:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    5bdb:	9e                   	sahf
    5bdc:	b0 00                	mov    al,0x0
    5bde:	76 01                	jbe    0x5be1
    5be0:	40                   	inc    ax
    5be1:	8a d0                	mov    dl,al
    5be3:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5be7:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5bed:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5bf2:	90                   	nop
    5bf3:	9b                   	fwait
    5bf4:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5bf8:	9e                   	sahf
    5bf9:	b0 00                	mov    al,0x0
    5bfb:	73 01                	jae    0x5bfe
    5bfd:	40                   	inc    ax
    5bfe:	0a c2                	or     al,dl
    5c00:	08 c0                	or     al,al
    5c02:	74 0f                	je     0x5c13
    5c04:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5c07:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5c0d:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5c13:	bf 59 4c             	mov    di,0x4c59
    5c16:	0e                   	push   cs
    5c17:	57                   	push   di
    5c18:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5c1c:	06                   	push   es
    5c1d:	57                   	push   di
    5c1e:	9a 9b 3b 66 5c       	call   0x5c66:0x3b9b
    5c23:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5c26:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5c29:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5c2c:	06                   	push   es
    5c2d:	57                   	push   di
    5c2e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c31:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5c35:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    5c38:	89 56 92             	mov    WORD PTR [bp-0x6e],dx
    5c3b:	83 7e 92 00          	cmp    WORD PTR [bp-0x6e],0x0
    5c3f:	7c 08                	jl     0x5c49
    5c41:	7f 15                	jg     0x5c58
    5c43:	83 7e 90 00          	cmp    WORD PTR [bp-0x70],0x0
    5c47:	73 0f                	jae    0x5c58
    5c49:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5c4c:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5c52:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5c58:	bf 6c 4c             	mov    di,0x4c6c
    5c5b:	0e                   	push   cs
    5c5c:	57                   	push   di
    5c5d:	c4 be 72 ff          	les    di,DWORD PTR [bp-0x8e]
    5c61:	06                   	push   es
    5c62:	57                   	push   di
    5c63:	9a 9b 3b 74 5e       	call   0x5e74:0x3b9b
    5c68:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5c6b:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5c6e:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5c71:	06                   	push   es
    5c72:	57                   	push   di
    5c73:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c76:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5c7a:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    5c7e:	90                   	nop
    5c7f:	9b                   	fwait
    5c80:	83 7e 92 00          	cmp    WORD PTR [bp-0x6e],0x0
    5c84:	7f 0c                	jg     0x5c92
    5c86:	7c 06                	jl     0x5c8e
    5c88:	83 7e 90 00          	cmp    WORD PTR [bp-0x70],0x0
    5c8c:	77 04                	ja     0x5c92
    5c8e:	b0 00                	mov    al,0x0
    5c90:	eb 02                	jmp    0x5c94
    5c92:	b0 01                	mov    al,0x1
    5c94:	8a d0                	mov    dl,al
    5c96:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5c9a:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5ca0:	9b dd be 6c ff       	fstsw  WORD PTR [bp-0x94]
    5ca5:	90                   	nop
    5ca6:	9b                   	fwait
    5ca7:	8a a6 6d ff          	mov    ah,BYTE PTR [bp-0x93]
    5cab:	9e                   	sahf
    5cac:	b0 00                	mov    al,0x0
    5cae:	75 01                	jne    0x5cb1
    5cb0:	40                   	inc    ax
    5cb1:	22 c2                	and    al,dl
    5cb3:	8a c8                	mov    cl,al
    5cb5:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5cb9:	9b dc 5e 94          	fcomp  QWORD PTR [bp-0x6c]
    5cbd:	9b dd be 6e ff       	fstsw  WORD PTR [bp-0x92]
    5cc2:	90                   	nop
    5cc3:	9b                   	fwait
    5cc4:	8a a6 6f ff          	mov    ah,BYTE PTR [bp-0x91]
    5cc8:	9e                   	sahf
    5cc9:	b0 00                	mov    al,0x0
    5ccb:	76 01                	jbe    0x5cce
    5ccd:	40                   	inc    ax
    5cce:	8a d0                	mov    dl,al
    5cd0:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    5cd4:	9b 2e d8 1e 3a 4a    	fcomp  DWORD PTR cs:0x4a3a
    5cda:	9b dd be 70 ff       	fstsw  WORD PTR [bp-0x90]
    5cdf:	90                   	nop
    5ce0:	9b                   	fwait
    5ce1:	8a a6 71 ff          	mov    ah,BYTE PTR [bp-0x8f]
    5ce5:	9e                   	sahf
    5ce6:	b0 00                	mov    al,0x0
    5ce8:	73 01                	jae    0x5ceb
    5cea:	40                   	inc    ax
    5ceb:	0a c2                	or     al,dl
    5ced:	0a c1                	or     al,cl
    5cef:	08 c0                	or     al,al
    5cf1:	74 0f                	je     0x5d02
    5cf3:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5cf6:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5cfc:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5d02:	8b 46 86             	mov    ax,WORD PTR [bp-0x7a]
    5d05:	3b 86 76 ff          	cmp    ax,WORD PTR [bp-0x8a]
    5d09:	74 03                	je     0x5d0e
    5d0b:	e9 db f9             	jmp    0x56e9
    5d0e:	c6 46 f1 00          	mov    BYTE PTR [bp-0xf],0x0
    5d12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d15:	06                   	push   es
    5d16:	57                   	push   di
    5d17:	9a 7d 52 6e 5d       	call   0x5d6e:0x527d
    5d1c:	2d 01 00             	sub    ax,0x1
    5d1f:	71 05                	jno    0x5d26
    5d21:	9a 3e 04 63 5d       	call   0x5d63:0x43e
    5d26:	99                   	cwd
    5d27:	89 86 74 ff          	mov    WORD PTR [bp-0x8c],ax
    5d2b:	89 96 76 ff          	mov    WORD PTR [bp-0x8a],dx
    5d2f:	31 c0                	xor    ax,ax
    5d31:	31 d2                	xor    dx,dx
    5d33:	3b 96 76 ff          	cmp    dx,WORD PTR [bp-0x8a]
    5d37:	7e 03                	jle    0x5d3c
    5d39:	e9 24 02             	jmp    0x5f60
    5d3c:	7c 09                	jl     0x5d47
    5d3e:	3b 86 74 ff          	cmp    ax,WORD PTR [bp-0x8c]
    5d42:	76 03                	jbe    0x5d47
    5d44:	e9 19 02             	jmp    0x5f60
    5d47:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5d4a:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    5d4d:	eb 08                	jmp    0x5d57
    5d4f:	83 46 f2 01          	add    WORD PTR [bp-0xe],0x1
    5d53:	83 56 f4 00          	adc    WORD PTR [bp-0xc],0x0
    5d57:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5d5a:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5d5d:	bf 3f 4c             	mov    di,0x4c3f
    5d60:	9a 16 04 7d 5d       	call   0x5d7d:0x416
    5d65:	50                   	push   ax
    5d66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d69:	06                   	push   es
    5d6a:	57                   	push   di
    5d6b:	9a 46 52 9d 5d       	call   0x5d9d:0x5246
    5d70:	52                   	push   dx
    5d71:	50                   	push   ax
    5d72:	bf 99 03             	mov    di,0x399
    5d75:	b8 a5 5d             	mov    ax,0x5da5
    5d78:	50                   	push   ax
    5d79:	57                   	push   di
    5d7a:	9a 55 22 92 5d       	call   0x5d92:0x2255
    5d7f:	08 c0                	or     al,al
    5d81:	75 03                	jne    0x5d86
    5d83:	e9 c2 01             	jmp    0x5f48
    5d86:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5d89:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5d8c:	bf 3f 4c             	mov    di,0x4c3f
    5d8f:	9a 16 04 ac 5d       	call   0x5dac:0x416
    5d94:	50                   	push   ax
    5d95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d98:	06                   	push   es
    5d99:	57                   	push   di
    5d9a:	9a 46 52 d3 5d       	call   0x5dd3:0x5246
    5d9f:	52                   	push   dx
    5da0:	50                   	push   ax
    5da1:	bf 99 03             	mov    di,0x399
    5da4:	b8 46 5f             	mov    ax,0x5f46
    5da7:	50                   	push   ax
    5da8:	57                   	push   di
    5da9:	9a 73 22 c8 5d       	call   0x5dc8:0x2273
    5dae:	89 c7                	mov    di,ax
    5db0:	8e c2                	mov    es,dx
    5db2:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5db7:	75 03                	jne    0x5dbc
    5db9:	e9 8c 01             	jmp    0x5f48
    5dbc:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5dbf:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5dc2:	bf 3f 4c             	mov    di,0x4c3f
    5dc5:	9a 16 04 e2 5d       	call   0x5de2:0x416
    5dca:	50                   	push   ax
    5dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dce:	06                   	push   es
    5dcf:	57                   	push   di
    5dd0:	9a 46 52 02 5e       	call   0x5e02:0x5246
    5dd5:	52                   	push   dx
    5dd6:	50                   	push   ax
    5dd7:	bf 22 00             	mov    di,0x22
    5dda:	b8 0a 5e             	mov    ax,0x5e0a
    5ddd:	50                   	push   ax
    5dde:	57                   	push   di
    5ddf:	9a 55 22 f7 5d       	call   0x5df7:0x2255
    5de4:	08 c0                	or     al,al
    5de6:	75 03                	jne    0x5deb
    5de8:	e9 5d 01             	jmp    0x5f48
    5deb:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5dee:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5df1:	bf 3f 4c             	mov    di,0x4c3f
    5df4:	9a 16 04 11 5e       	call   0x5e11:0x416
    5df9:	50                   	push   ax
    5dfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dfd:	06                   	push   es
    5dfe:	57                   	push   di
    5dff:	9a 46 52 2e 5e       	call   0x5e2e:0x5246
    5e04:	52                   	push   dx
    5e05:	50                   	push   ax
    5e06:	bf 22 00             	mov    di,0x22
    5e09:	b8 36 5e             	mov    ax,0x5e36
    5e0c:	50                   	push   ax
    5e0d:	57                   	push   di
    5e0e:	9a 55 22 23 5e       	call   0x5e23:0x2255
    5e13:	08 c0                	or     al,al
    5e15:	74 65                	je     0x5e7c
    5e17:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5e1a:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5e1d:	bf 3f 4c             	mov    di,0x4c3f
    5e20:	9a 16 04 3d 5e       	call   0x5e3d:0x416
    5e25:	50                   	push   ax
    5e26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e29:	06                   	push   es
    5e2a:	57                   	push   di
    5e2b:	9a 46 52 e4 5e       	call   0x5ee4:0x5246
    5e30:	52                   	push   dx
    5e31:	50                   	push   ax
    5e32:	bf 22 00             	mov    di,0x22
    5e35:	b8 5a 5e             	mov    ax,0x5e5a
    5e38:	50                   	push   ax
    5e39:	57                   	push   di
    5e3a:	9a 73 22 d9 5e       	call   0x5ed9:0x2273
    5e3f:	89 c7                	mov    di,ax
    5e41:	8e c2                	mov    es,dx
    5e43:	89 be 70 ff          	mov    WORD PTR [bp-0x90],di
    5e47:	8c 86 72 ff          	mov    WORD PTR [bp-0x8e],es
    5e4b:	8d be 70 fe          	lea    di,[bp-0x190]
    5e4f:	16                   	push   ss
    5e50:	57                   	push   di
    5e51:	c4 be 70 ff          	les    di,DWORD PTR [bp-0x90]
    5e55:	06                   	push   es
    5e56:	57                   	push   di
    5e57:	9a 9f 1a 65 5e       	call   0x5e65:0x1a9f
    5e5c:	c4 be 70 ff          	les    di,DWORD PTR [bp-0x90]
    5e60:	06                   	push   es
    5e61:	57                   	push   di
    5e62:	9a 5f 1a ec 5e       	call   0x5eec:0x1a5f
    5e67:	89 c7                	mov    di,ax
    5e69:	8e c2                	mov    es,dx
    5e6b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5e6f:	06                   	push   es
    5e70:	57                   	push   di
    5e71:	9a 9b 3b 4d 65       	call   0x654d:0x3b9b
    5e76:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5e79:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5e7c:	c7 46 ec fa ff       	mov    WORD PTR [bp-0x14],0xfffa
    5e81:	c7 46 ee ff ff       	mov    WORD PTR [bp-0x12],0xffff
    5e86:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5e89:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    5e8e:	75 15                	jne    0x5ea5
    5e90:	26 83 7d 0c 01       	cmp    WORD PTR es:[di+0xc],0x1
    5e95:	75 0e                	jne    0x5ea5
    5e97:	c7 46 ec ff 00       	mov    WORD PTR [bp-0x14],0xff
    5e9c:	c7 46 ee 00 00       	mov    WORD PTR [bp-0x12],0x0
    5ea1:	c6 46 f1 01          	mov    BYTE PTR [bp-0xf],0x1
    5ea5:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5ea8:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    5ead:	75 11                	jne    0x5ec0
    5eaf:	26 83 7d 0c 02       	cmp    WORD PTR es:[di+0xc],0x2
    5eb4:	75 0a                	jne    0x5ec0
    5eb6:	c7 46 ec 80 00       	mov    WORD PTR [bp-0x14],0x80
    5ebb:	c7 46 ee 00 00       	mov    WORD PTR [bp-0x12],0x0
    5ec0:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5ec3:	31 c0                	xor    ax,ax
    5ec5:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    5ec9:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    5ecd:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5ed0:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5ed3:	bf 3f 4c             	mov    di,0x4c3f
    5ed6:	9a 16 04 f3 5e       	call   0x5ef3:0x416
    5edb:	50                   	push   ax
    5edc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5edf:	06                   	push   es
    5ee0:	57                   	push   di
    5ee1:	9a 46 52 10 5f       	call   0x5f10:0x5246
    5ee6:	52                   	push   dx
    5ee7:	50                   	push   ax
    5ee8:	bf 22 00             	mov    di,0x22
    5eeb:	b8 18 5f             	mov    ax,0x5f18
    5eee:	50                   	push   ax
    5eef:	57                   	push   di
    5ef0:	9a 55 22 05 5f       	call   0x5f05:0x2255
    5ef5:	08 c0                	or     al,al
    5ef7:	74 4f                	je     0x5f48
    5ef9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5efc:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5eff:	bf 3f 4c             	mov    di,0x4c3f
    5f02:	9a 16 04 1f 5f       	call   0x5f1f:0x416
    5f07:	50                   	push   ax
    5f08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f0b:	06                   	push   es
    5f0c:	57                   	push   di
    5f0d:	9a 46 52 ff ff       	call   0xffff:0x5246
    5f12:	52                   	push   dx
    5f13:	50                   	push   ax
    5f14:	bf 22 00             	mov    di,0x22
    5f17:	b8 e6 64             	mov    ax,0x64e6
    5f1a:	50                   	push   ax
    5f1b:	57                   	push   di
    5f1c:	9a 73 22 39 5f       	call   0x5f39:0x2273
    5f21:	89 c7                	mov    di,ax
    5f23:	8e c2                	mov    es,dx
    5f25:	89 be 70 ff          	mov    WORD PTR [bp-0x90],di
    5f29:	8c 86 72 ff          	mov    WORD PTR [bp-0x8e],es
    5f2d:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    5f30:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
    5f33:	bf 7e 4c             	mov    di,0x4c7e
    5f36:	9a 16 04 b9 5f       	call   0x5fb9:0x416
    5f3b:	52                   	push   dx
    5f3c:	50                   	push   ax
    5f3d:	c4 be 70 ff          	les    di,DWORD PTR [bp-0x90]
    5f41:	06                   	push   es
    5f42:	57                   	push   di
    5f43:	9a d5 1e ef 5f       	call   0x5fef:0x1ed5
    5f48:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    5f4b:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    5f4e:	3b 96 76 ff          	cmp    dx,WORD PTR [bp-0x8a]
    5f52:	74 03                	je     0x5f57
    5f54:	e9 f8 fd             	jmp    0x5d4f
    5f57:	3b 86 74 ff          	cmp    ax,WORD PTR [bp-0x8c]
    5f5b:	74 03                	je     0x5f60
    5f5d:	e9 ef fd             	jmp    0x5d4f
    5f60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f63:	26 80 bd 8d 04 00    	cmp    BYTE PTR es:[di+0x48d],0x0
    5f69:	74 20                	je     0x5f8b
    5f6b:	80 7e f1 00          	cmp    BYTE PTR [bp-0xf],0x0
    5f6f:	b0 00                	mov    al,0x0
    5f71:	75 01                	jne    0x5f74
    5f73:	40                   	inc    ax
    5f74:	26 88 85 90 04       	mov    BYTE PTR es:[di+0x490],al
    5f79:	26 8a 85 90 04       	mov    al,BYTE PTR es:[di+0x490]
    5f7e:	50                   	push   ax
    5f7f:	26 c4 bd 64 04       	les    di,DWORD PTR es:[di+0x464]
    5f84:	06                   	push   es
    5f85:	57                   	push   di
    5f86:	9a 11 6e e8 62       	call   0x62e8:0x6e11
    5f8b:	80 7e f1 00          	cmp    BYTE PTR [bp-0xf],0x0
    5f8f:	74 07                	je     0x5f98
    5f91:	9a fb 36 9b 5f       	call   0x5f9b:0x36fb
    5f96:	eb 05                	jmp    0x5f9d
    5f98:	9a 75 36 22 7c       	call   0x7c22:0x3675
    5f9d:	80 7e f1 00          	cmp    BYTE PTR [bp-0xf],0x0
    5fa1:	b0 00                	mov    al,0x0
    5fa3:	75 01                	jne    0x5fa6
    5fa5:	40                   	inc    ax
    5fa6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5fa9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5fac:	c9                   	leave
    5fad:	ca 04 00             	retf   0x4
    5fb0:	55                   	push   bp
    5fb1:	89 e5                	mov    bp,sp
    5fb3:	b8 08 02             	mov    ax,0x208
    5fb6:	9a 44 04 3e 60       	call   0x603e:0x444
    5fbb:	81 ec 08 02          	sub    sp,0x208
    5fbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc2:	26 c4 bd 5c 04       	les    di,DWORD PTR es:[di+0x45c]
    5fc7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5fca:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5fcd:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    5fd1:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    5fd4:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    5fd7:	06                   	push   es
    5fd8:	57                   	push   di
    5fd9:	9a 1a 12 f9 5f       	call   0x5ff9:0x121a
    5fde:	a8 08                	test   al,0x8
    5fe0:	74 36                	je     0x6018
    5fe2:	bf 7c 03             	mov    di,0x37c
    5fe5:	1e                   	push   ds
    5fe6:	57                   	push   di
    5fe7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5fea:	06                   	push   es
    5feb:	57                   	push   di
    5fec:	9a 8c 1d 31 60       	call   0x6031:0x1d8c
    5ff1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5ff4:	06                   	push   es
    5ff5:	57                   	push   di
    5ff6:	9a 1a 12 06 60       	call   0x6006:0x121a
    5ffb:	24 f7                	and    al,0xf7
    5ffd:	50                   	push   ax
    5ffe:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6001:	06                   	push   es
    6002:	57                   	push   di
    6003:	9a 33 12 14 60       	call   0x6014:0x1233
    6008:	6a 00                	push   0x0
    600a:	6a 00                	push   0x0
    600c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    600f:	06                   	push   es
    6010:	57                   	push   di
    6011:	9a df 0f 6d 60       	call   0x606d:0xfdf
    6016:	eb 73                	jmp    0x608b
    6018:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    601b:	26 80 bd 90 04 00    	cmp    BYTE PTR es:[di+0x490],0x0
    6021:	75 68                	jne    0x608b
    6023:	8d be f8 fe          	lea    di,[bp-0x108]
    6027:	16                   	push   ss
    6028:	57                   	push   di
    6029:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    602c:	06                   	push   es
    602d:	57                   	push   di
    602e:	9a 53 1d 54 60       	call   0x6054:0x1d53
    6033:	bf 7c 03             	mov    di,0x37c
    6036:	1e                   	push   ds
    6037:	57                   	push   di
    6038:	68 ff 00             	push   0xff
    603b:	9a e7 17 97 60       	call   0x6097:0x17e7
    6040:	8d be f8 fd          	lea    di,[bp-0x208]
    6044:	16                   	push   ss
    6045:	57                   	push   di
    6046:	8d be f8 fe          	lea    di,[bp-0x108]
    604a:	16                   	push   ss
    604b:	57                   	push   di
    604c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    604f:	06                   	push   es
    6050:	57                   	push   di
    6051:	9a 53 1d 63 60       	call   0x6063:0x1d53
    6056:	9a 81 07 50 66       	call   0x6650:0x781
    605b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    605e:	06                   	push   es
    605f:	57                   	push   di
    6060:	9a 8c 1d af 61       	call   0x61af:0x1d8c
    6065:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6068:	06                   	push   es
    6069:	57                   	push   di
    606a:	9a 1a 12 7a 60       	call   0x607a:0x121a
    606f:	0c 08                	or     al,0x8
    6071:	50                   	push   ax
    6072:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6075:	06                   	push   es
    6076:	57                   	push   di
    6077:	9a 33 12 89 60       	call   0x6089:0x1233
    607c:	6a 00                	push   0x0
    607e:	68 ff 00             	push   0xff
    6081:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6084:	06                   	push   es
    6085:	57                   	push   di
    6086:	9a df 0f 74 7d       	call   0x7d74:0xfdf
    608b:	c9                   	leave
    608c:	ca 08 00             	retf   0x8
    608f:	55                   	push   bp
    6090:	89 e5                	mov    bp,sp
    6092:	31 c0                	xor    ax,ax
    6094:	9a 44 04 b2 60       	call   0x60b2:0x444
    6099:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    609c:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
    60a0:	75 04                	jne    0x60a6
    60a2:	26 c6 05 2c          	mov    BYTE PTR es:[di],0x2c
    60a6:	c9                   	leave
    60a7:	ca 0c 00             	retf   0xc
    60aa:	55                   	push   bp
    60ab:	89 e5                	mov    bp,sp
    60ad:	31 c0                	xor    ax,ax
    60af:	9a 44 04 f1 60       	call   0x60f1:0x444
    60b4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    60b8:	b0 00                	mov    al,0x0
    60ba:	75 01                	jne    0x60bd
    60bc:	40                   	inc    ax
    60bd:	8a d0                	mov    dl,al
    60bf:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    60c2:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    60c6:	b0 00                	mov    al,0x0
    60c8:	75 01                	jne    0x60cb
    60ca:	40                   	inc    ax
    60cb:	22 c2                	and    al,dl
    60cd:	08 c0                	or     al,al
    60cf:	74 14                	je     0x60e5
    60d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60d4:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    60d9:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    60de:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    60e3:	74 00                	je     0x60e5
    60e5:	c9                   	leave
    60e6:	ca 0e 00             	retf   0xe
    60e9:	55                   	push   bp
    60ea:	89 e5                	mov    bp,sp
    60ec:	31 c0                	xor    ax,ax
    60ee:	9a 44 04 1f 61       	call   0x611f:0x444
    60f3:	6a 01                	push   0x1
    60f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60f8:	26 c4 bd 6c 04       	les    di,DWORD PTR es:[di+0x46c]
    60fd:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    6102:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    6107:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    610b:	06                   	push   es
    610c:	57                   	push   di
    610d:	9a b2 77 8b 61       	call   0x618b:0x77b2
    6112:	c9                   	leave
    6113:	ca 08 00             	retf   0x8
    6116:	55                   	push   bp
    6117:	89 e5                	mov    bp,sp
    6119:	b8 04 00             	mov    ax,0x4
    611c:	9a 44 04 9a 61       	call   0x619a:0x444
    6121:	83 ec 04             	sub    sp,0x4
    6124:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6127:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    612c:	b0 00                	mov    al,0x0
    612e:	75 01                	jne    0x6131
    6130:	40                   	inc    ax
    6131:	8a c8                	mov    cl,al
    6133:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    6139:	b0 00                	mov    al,0x0
    613b:	77 01                	ja     0x613e
    613d:	40                   	inc    ax
    613e:	8a d0                	mov    dl,al
    6140:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    6146:	b0 00                	mov    al,0x0
    6148:	76 01                	jbe    0x614b
    614a:	40                   	inc    ax
    614b:	22 c2                	and    al,dl
    614d:	0a c1                	or     al,cl
    614f:	08 c0                	or     al,al
    6151:	74 3a                	je     0x618d
    6153:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6157:	31 c0                	xor    ax,ax
    6159:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    615d:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    6161:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    6165:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    6169:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    616c:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    6170:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6173:	06                   	push   es
    6174:	57                   	push   di
    6175:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6178:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    617c:	6a 02                	push   0x2
    617e:	6a 00                	push   0x0
    6180:	6a 00                	push   0x0
    6182:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6186:	06                   	push   es
    6187:	57                   	push   di
    6188:	9a b2 77 f1 61       	call   0x61f1:0x77b2
    618d:	c9                   	leave
    618e:	ca 0c 00             	retf   0xc
    6191:	55                   	push   bp
    6192:	89 e5                	mov    bp,sp
    6194:	b8 04 00             	mov    ax,0x4
    6197:	9a 44 04 b6 61       	call   0x61b6:0x444
    619c:	83 ec 04             	sub    sp,0x4
    619f:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    61a3:	75 76                	jne    0x621b
    61a5:	ff 76 14             	push   WORD PTR [bp+0x14]
    61a8:	ff 76 12             	push   WORD PTR [bp+0x12]
    61ab:	bf c1 05             	mov    di,0x5c1
    61ae:	b8 d2 61             	mov    ax,0x61d2
    61b1:	50                   	push   ax
    61b2:	57                   	push   di
    61b3:	9a 55 22 d9 61       	call   0x61d9:0x2255
    61b8:	08 c0                	or     al,al
    61ba:	74 5f                	je     0x621b
    61bc:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    61c0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    61c3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    61c6:	6a 08                	push   0x8
    61c8:	ff 76 14             	push   WORD PTR [bp+0x14]
    61cb:	ff 76 12             	push   WORD PTR [bp+0x12]
    61ce:	bf c1 05             	mov    di,0x5c1
    61d1:	b8 3d 62             	mov    ax,0x623d
    61d4:	50                   	push   ax
    61d5:	57                   	push   di
    61d6:	9a 73 22 28 62       	call   0x6228:0x2273
    61db:	89 c7                	mov    di,ax
    61dd:	8e c2                	mov    es,dx
    61df:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    61e4:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    61e9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    61ec:	06                   	push   es
    61ed:	57                   	push   di
    61ee:	9a b2 77 fb 61       	call   0x61fb:0x77b2
    61f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    61f6:	06                   	push   es
    61f7:	57                   	push   di
    61f8:	9a 03 73 82 62       	call   0x6282:0x7303
    61fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6200:	06                   	push   es
    6201:	57                   	push   di
    6202:	b8 16 61             	mov    ax,0x6116
    6205:	ba 86 67             	mov    dx,0x6786
    6208:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    620b:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    620f:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    6213:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    6217:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    621b:	c9                   	leave
    621c:	ca 10 00             	retf   0x10
    621f:	55                   	push   bp
    6220:	89 e5                	mov    bp,sp
    6222:	b8 04 00             	mov    ax,0x4
    6225:	9a 44 04 44 62       	call   0x6244:0x444
    622a:	83 ec 04             	sub    sp,0x4
    622d:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    6231:	75 51                	jne    0x6284
    6233:	ff 76 14             	push   WORD PTR [bp+0x14]
    6236:	ff 76 12             	push   WORD PTR [bp+0x12]
    6239:	bf c1 05             	mov    di,0x5c1
    623c:	b8 54 62             	mov    ax,0x6254
    623f:	50                   	push   ax
    6240:	57                   	push   di
    6241:	9a 55 22 5b 62       	call   0x625b:0x2255
    6246:	08 c0                	or     al,al
    6248:	74 3a                	je     0x6284
    624a:	ff 76 14             	push   WORD PTR [bp+0x14]
    624d:	ff 76 12             	push   WORD PTR [bp+0x12]
    6250:	bf c1 05             	mov    di,0x5c1
    6253:	b8 30 63             	mov    ax,0x6330
    6256:	50                   	push   ax
    6257:	57                   	push   di
    6258:	9a 73 22 9b 62       	call   0x629b:0x2273
    625d:	89 c7                	mov    di,ax
    625f:	8e c2                	mov    es,dx
    6261:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    6266:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    626b:	74 17                	je     0x6284
    626d:	6a 08                	push   0x8
    626f:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    6274:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    6279:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    627d:	06                   	push   es
    627e:	57                   	push   di
    627f:	9a b2 77 41 7c       	call   0x7c41:0x77b2
    6284:	c9                   	leave
    6285:	ca 10 00             	retf   0x10
    6288:	01 09                	add    WORD PTR [bx+di],cx
    628a:	03 6f 75             	add    bp,WORD PTR [bx+0x75]
    628d:	69 03 6e 6f          	imul   ax,WORD PTR [bp+di],0x6f6e
    6291:	6e                   	outs   dx,BYTE PTR ds:[si]
    6292:	55                   	push   bp
    6293:	89 e5                	mov    bp,sp
    6295:	b8 04 03             	mov    ax,0x304
    6298:	9a 44 04 b8 62       	call   0x62b8:0x444
    629d:	81 ec 04 03          	sub    sp,0x304
    62a1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    62a4:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    62a8:	76 27                	jbe    0x62d1
    62aa:	8d be 00 ff          	lea    di,[bp-0x100]
    62ae:	16                   	push   ss
    62af:	57                   	push   di
    62b0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    62b3:	06                   	push   es
    62b4:	57                   	push   di
    62b5:	9a cd 17 c2 62       	call   0x62c2:0x17cd
    62ba:	bf 88 62             	mov    di,0x6288
    62bd:	0e                   	push   cs
    62be:	57                   	push   di
    62bf:	9a 4c 18 cf 62       	call   0x62cf:0x184c
    62c4:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    62c7:	06                   	push   es
    62c8:	57                   	push   di
    62c9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    62cc:	9a e7 17 ef 62       	call   0x62ef:0x17e7
    62d1:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    62d4:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    62d9:	75 03                	jne    0x62de
    62db:	e9 86 03             	jmp    0x6664
    62de:	ff 76 0a             	push   WORD PTR [bp+0xa]
    62e1:	ff 76 08             	push   WORD PTR [bp+0x8]
    62e4:	bf 0c 01             	mov    di,0x10c
    62e7:	b8 ff 62             	mov    ax,0x62ff
    62ea:	50                   	push   ax
    62eb:	57                   	push   di
    62ec:	9a 55 22 06 63       	call   0x6306:0x2255
    62f1:	08 c0                	or     al,al
    62f3:	74 4f                	je     0x6344
    62f5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    62f8:	ff 76 08             	push   WORD PTR [bp+0x8]
    62fb:	bf 0c 01             	mov    di,0x10c
    62fe:	b8 b4 63             	mov    ax,0x63b4
    6301:	50                   	push   ax
    6302:	57                   	push   di
    6303:	9a 73 22 20 63       	call   0x6320:0x2273
    6308:	89 c7                	mov    di,ax
    630a:	8e c2                	mov    es,dx
    630c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    630f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6312:	8d be fc fd          	lea    di,[bp-0x204]
    6316:	16                   	push   ss
    6317:	57                   	push   di
    6318:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    631b:	06                   	push   es
    631c:	57                   	push   di
    631d:	9a cd 17 35 63       	call   0x6335:0x17cd
    6322:	8d be fc fe          	lea    di,[bp-0x104]
    6326:	16                   	push   ss
    6327:	57                   	push   di
    6328:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    632b:	06                   	push   es
    632c:	57                   	push   di
    632d:	9a 53 1d 96 63       	call   0x6396:0x1d53
    6332:	9a 4c 18 42 63       	call   0x6342:0x184c
    6337:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    633a:	06                   	push   es
    633b:	57                   	push   di
    633c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    633f:	9a e7 17 55 63       	call   0x6355:0x17e7
    6344:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6347:	ff 76 08             	push   WORD PTR [bp+0x8]
    634a:	bf ad 0d             	mov    di,0xdad
    634d:	b8 65 63             	mov    ax,0x6365
    6350:	50                   	push   ax
    6351:	57                   	push   di
    6352:	9a 55 22 6c 63       	call   0x636c:0x2255
    6357:	08 c0                	or     al,al
    6359:	74 4f                	je     0x63aa
    635b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    635e:	ff 76 08             	push   WORD PTR [bp+0x8]
    6361:	bf ad 0d             	mov    di,0xdad
    6364:	b8 69 7d             	mov    ax,0x7d69
    6367:	50                   	push   ax
    6368:	57                   	push   di
    6369:	9a 73 22 86 63       	call   0x6386:0x2273
    636e:	89 c7                	mov    di,ax
    6370:	8e c2                	mov    es,dx
    6372:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6375:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6378:	8d be fc fd          	lea    di,[bp-0x204]
    637c:	16                   	push   ss
    637d:	57                   	push   di
    637e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6381:	06                   	push   es
    6382:	57                   	push   di
    6383:	9a cd 17 9b 63       	call   0x639b:0x17cd
    6388:	8d be fc fe          	lea    di,[bp-0x104]
    638c:	16                   	push   ss
    638d:	57                   	push   di
    638e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6391:	06                   	push   es
    6392:	57                   	push   di
    6393:	9a 53 1d fc 63       	call   0x63fc:0x1d53
    6398:	9a 4c 18 a8 63       	call   0x63a8:0x184c
    639d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    63a0:	06                   	push   es
    63a1:	57                   	push   di
    63a2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    63a5:	9a e7 17 bb 63       	call   0x63bb:0x17e7
    63aa:	ff 76 0a             	push   WORD PTR [bp+0xa]
    63ad:	ff 76 08             	push   WORD PTR [bp+0x8]
    63b0:	bf 90 0b             	mov    di,0xb90
    63b3:	b8 cb 63             	mov    ax,0x63cb
    63b6:	50                   	push   ax
    63b7:	57                   	push   di
    63b8:	9a 55 22 d2 63       	call   0x63d2:0x2255
    63bd:	08 c0                	or     al,al
    63bf:	74 4f                	je     0x6410
    63c1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    63c4:	ff 76 08             	push   WORD PTR [bp+0x8]
    63c7:	bf 90 0b             	mov    di,0xb90
    63ca:	b8 1a 64             	mov    ax,0x641a
    63cd:	50                   	push   ax
    63ce:	57                   	push   di
    63cf:	9a 73 22 ec 63       	call   0x63ec:0x2273
    63d4:	89 c7                	mov    di,ax
    63d6:	8e c2                	mov    es,dx
    63d8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    63db:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    63de:	8d be fc fd          	lea    di,[bp-0x204]
    63e2:	16                   	push   ss
    63e3:	57                   	push   di
    63e4:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    63e7:	06                   	push   es
    63e8:	57                   	push   di
    63e9:	9a cd 17 01 64       	call   0x6401:0x17cd
    63ee:	8d be fc fe          	lea    di,[bp-0x104]
    63f2:	16                   	push   ss
    63f3:	57                   	push   di
    63f4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    63f7:	06                   	push   es
    63f8:	57                   	push   di
    63f9:	9a 53 1d 62 64       	call   0x6462:0x1d53
    63fe:	9a 4c 18 0e 64       	call   0x640e:0x184c
    6403:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6406:	06                   	push   es
    6407:	57                   	push   di
    6408:	ff 76 0c             	push   WORD PTR [bp+0xc]
    640b:	9a e7 17 21 64       	call   0x6421:0x17e7
    6410:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6413:	ff 76 08             	push   WORD PTR [bp+0x8]
    6416:	bf 17 06             	mov    di,0x617
    6419:	b8 31 64             	mov    ax,0x6431
    641c:	50                   	push   ax
    641d:	57                   	push   di
    641e:	9a 55 22 38 64       	call   0x6438:0x2255
    6423:	08 c0                	or     al,al
    6425:	74 4f                	je     0x6476
    6427:	ff 76 0a             	push   WORD PTR [bp+0xa]
    642a:	ff 76 08             	push   WORD PTR [bp+0x8]
    642d:	bf 17 06             	mov    di,0x617
    6430:	b8 80 64             	mov    ax,0x6480
    6433:	50                   	push   ax
    6434:	57                   	push   di
    6435:	9a 73 22 52 64       	call   0x6452:0x2273
    643a:	89 c7                	mov    di,ax
    643c:	8e c2                	mov    es,dx
    643e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6441:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6444:	8d be fc fd          	lea    di,[bp-0x204]
    6448:	16                   	push   ss
    6449:	57                   	push   di
    644a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    644d:	06                   	push   es
    644e:	57                   	push   di
    644f:	9a cd 17 67 64       	call   0x6467:0x17cd
    6454:	8d be fc fe          	lea    di,[bp-0x104]
    6458:	16                   	push   ss
    6459:	57                   	push   di
    645a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    645d:	06                   	push   es
    645e:	57                   	push   di
    645f:	9a 53 1d c8 64       	call   0x64c8:0x1d53
    6464:	9a 4c 18 74 64       	call   0x6474:0x184c
    6469:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    646c:	06                   	push   es
    646d:	57                   	push   di
    646e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6471:	9a e7 17 87 64       	call   0x6487:0x17e7
    6476:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6479:	ff 76 08             	push   WORD PTR [bp+0x8]
    647c:	bf 14 1b             	mov    di,0x1b14
    647f:	b8 97 64             	mov    ax,0x6497
    6482:	50                   	push   ax
    6483:	57                   	push   di
    6484:	9a 55 22 9e 64       	call   0x649e:0x2255
    6489:	08 c0                	or     al,al
    648b:	74 4f                	je     0x64dc
    648d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6490:	ff 76 08             	push   WORD PTR [bp+0x8]
    6493:	bf 14 1b             	mov    di,0x1b14
    6496:	b8 a1 65             	mov    ax,0x65a1
    6499:	50                   	push   ax
    649a:	57                   	push   di
    649b:	9a 73 22 b8 64       	call   0x64b8:0x2273
    64a0:	89 c7                	mov    di,ax
    64a2:	8e c2                	mov    es,dx
    64a4:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    64a7:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    64aa:	8d be fc fd          	lea    di,[bp-0x204]
    64ae:	16                   	push   ss
    64af:	57                   	push   di
    64b0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    64b3:	06                   	push   es
    64b4:	57                   	push   di
    64b5:	9a cd 17 cd 64       	call   0x64cd:0x17cd
    64ba:	8d be fc fe          	lea    di,[bp-0x104]
    64be:	16                   	push   ss
    64bf:	57                   	push   di
    64c0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    64c3:	06                   	push   es
    64c4:	57                   	push   di
    64c5:	9a 53 1d c0 66       	call   0x66c0:0x1d53
    64ca:	9a 4c 18 da 64       	call   0x64da:0x184c
    64cf:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    64d2:	06                   	push   es
    64d3:	57                   	push   di
    64d4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    64d7:	9a e7 17 ed 64       	call   0x64ed:0x17e7
    64dc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    64df:	ff 76 08             	push   WORD PTR [bp+0x8]
    64e2:	bf 22 00             	mov    di,0x22
    64e5:	b8 fd 64             	mov    ax,0x64fd
    64e8:	50                   	push   ax
    64e9:	57                   	push   di
    64ea:	9a 55 22 04 65       	call   0x6504:0x2255
    64ef:	08 c0                	or     al,al
    64f1:	74 7b                	je     0x656e
    64f3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    64f6:	ff 76 08             	push   WORD PTR [bp+0x8]
    64f9:	bf 22 00             	mov    di,0x22
    64fc:	b8 34 65             	mov    ax,0x6534
    64ff:	50                   	push   ax
    6500:	57                   	push   di
    6501:	9a 73 22 1e 65       	call   0x651e:0x2273
    6506:	89 c7                	mov    di,ax
    6508:	8e c2                	mov    es,dx
    650a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    650d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6510:	8d be fc fc          	lea    di,[bp-0x304]
    6514:	16                   	push   ss
    6515:	57                   	push   di
    6516:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6519:	06                   	push   es
    651a:	57                   	push   di
    651b:	9a cd 17 5f 65       	call   0x655f:0x17cd
    6520:	8d be fc fd          	lea    di,[bp-0x204]
    6524:	16                   	push   ss
    6525:	57                   	push   di
    6526:	8d be fc fe          	lea    di,[bp-0x104]
    652a:	16                   	push   ss
    652b:	57                   	push   di
    652c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    652f:	06                   	push   es
    6530:	57                   	push   di
    6531:	9a 9f 1a 3e 65       	call   0x653e:0x1a9f
    6536:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6539:	06                   	push   es
    653a:	57                   	push   di
    653b:	9a 5f 1a 78 65       	call   0x6578:0x1a5f
    6540:	89 c7                	mov    di,ax
    6542:	8e c2                	mov    es,dx
    6544:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6548:	06                   	push   es
    6549:	57                   	push   di
    654a:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    654f:	89 c7                	mov    di,ax
    6551:	8e c2                	mov    es,dx
    6553:	06                   	push   es
    6554:	57                   	push   di
    6555:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6558:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    655c:	9a 4c 18 6c 65       	call   0x656c:0x184c
    6561:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6564:	06                   	push   es
    6565:	57                   	push   di
    6566:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6569:	9a e7 17 7f 65       	call   0x657f:0x17e7
    656e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6571:	ff 76 08             	push   WORD PTR [bp+0x8]
    6574:	bf 26 06             	mov    di,0x626
    6577:	b8 8f 65             	mov    ax,0x658f
    657a:	50                   	push   ax
    657b:	57                   	push   di
    657c:	9a 55 22 96 65       	call   0x6596:0x2255
    6581:	08 c0                	or     al,al
    6583:	74 72                	je     0x65f7
    6585:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6588:	ff 76 08             	push   WORD PTR [bp+0x8]
    658b:	bf 26 06             	mov    di,0x626
    658e:	b8 ff ff             	mov    ax,0xffff
    6591:	50                   	push   ax
    6592:	57                   	push   di
    6593:	9a 73 22 b5 65       	call   0x65b5:0x2273
    6598:	89 c7                	mov    di,ax
    659a:	8e c2                	mov    es,dx
    659c:	06                   	push   es
    659d:	57                   	push   di
    659e:	9a d2 6d 91 66       	call   0x6691:0x6dd2
    65a3:	08 c0                	or     al,al
    65a5:	74 29                	je     0x65d0
    65a7:	8d be fc fe          	lea    di,[bp-0x104]
    65ab:	16                   	push   ss
    65ac:	57                   	push   di
    65ad:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    65b0:	06                   	push   es
    65b1:	57                   	push   di
    65b2:	9a cd 17 bf 65       	call   0x65bf:0x17cd
    65b7:	bf 8a 62             	mov    di,0x628a
    65ba:	0e                   	push   cs
    65bb:	57                   	push   di
    65bc:	9a 4c 18 cc 65       	call   0x65cc:0x184c
    65c1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    65c4:	06                   	push   es
    65c5:	57                   	push   di
    65c6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    65c9:	9a e7 17 de 65       	call   0x65de:0x17e7
    65ce:	eb 27                	jmp    0x65f7
    65d0:	8d be fc fe          	lea    di,[bp-0x104]
    65d4:	16                   	push   ss
    65d5:	57                   	push   di
    65d6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    65d9:	06                   	push   es
    65da:	57                   	push   di
    65db:	9a cd 17 e8 65       	call   0x65e8:0x17cd
    65e0:	bf 8e 62             	mov    di,0x628e
    65e3:	0e                   	push   cs
    65e4:	57                   	push   di
    65e5:	9a 4c 18 f5 65       	call   0x65f5:0x184c
    65ea:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    65ed:	06                   	push   es
    65ee:	57                   	push   di
    65ef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    65f2:	9a e7 17 08 66       	call   0x6608:0x17e7
    65f7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    65fa:	ff 76 08             	push   WORD PTR [bp+0x8]
    65fd:	bf eb 03             	mov    di,0x3eb
    6600:	b8 18 66             	mov    ax,0x6618
    6603:	50                   	push   ax
    6604:	57                   	push   di
    6605:	9a 55 22 1f 66       	call   0x661f:0x2255
    660a:	08 c0                	or     al,al
    660c:	74 56                	je     0x6664
    660e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6611:	ff 76 08             	push   WORD PTR [bp+0x8]
    6614:	bf eb 03             	mov    di,0x3eb
    6617:	b8 49 66             	mov    ax,0x6649
    661a:	50                   	push   ax
    661b:	57                   	push   di
    661c:	9a 73 22 39 66       	call   0x6639:0x2273
    6621:	89 c7                	mov    di,ax
    6623:	8e c2                	mov    es,dx
    6625:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6628:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    662b:	8d be fc fd          	lea    di,[bp-0x204]
    662f:	16                   	push   ss
    6630:	57                   	push   di
    6631:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6634:	06                   	push   es
    6635:	57                   	push   di
    6636:	9a cd 17 55 66       	call   0x6655:0x17cd
    663b:	8d be fc fe          	lea    di,[bp-0x104]
    663f:	16                   	push   ss
    6640:	57                   	push   di
    6641:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6644:	06                   	push   es
    6645:	57                   	push   di
    6646:	9a 33 17 ff ff       	call   0xffff:0x1733
    664b:	52                   	push   dx
    664c:	50                   	push   ax
    664d:	9a a9 08 db 66       	call   0x66db:0x8a9
    6652:	9a 4c 18 62 66       	call   0x6662:0x184c
    6657:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    665a:	06                   	push   es
    665b:	57                   	push   di
    665c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    665f:	9a e7 17 76 66       	call   0x6676:0x17e7
    6664:	c9                   	leave
    6665:	ca 0c 00             	retf   0xc
    6668:	01 09                	add    WORD PTR [bx+di],cx
    666a:	02 3a                	add    bh,BYTE PTR [bp+si]
    666c:	20 55 89             	and    BYTE PTR [di-0x77],dl
    666f:	e5 b8                	in     ax,0xb8
    6671:	04 04                	add    al,0x4
    6673:	9a 44 04 a1 66       	call   0x66a1:0x444
    6678:	81 ec 04 04          	sub    sp,0x404
    667c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    667f:	26 c4 bd 88 02       	les    di,DWORD PTR es:[di+0x288]
    6684:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    6688:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    668c:	06                   	push   es
    668d:	57                   	push   di
    668e:	9a e3 49 7f 7b       	call   0x7b7f:0x49e3
    6693:	8d be fc fd          	lea    di,[bp-0x204]
    6697:	16                   	push   ss
    6698:	57                   	push   di
    6699:	bf fa 1d             	mov    di,0x1dfa
    669c:	1e                   	push   ds
    669d:	57                   	push   di
    669e:	9a cd 17 ab 66       	call   0x66ab:0x17cd
    66a3:	bf 68 66             	mov    di,0x6668
    66a6:	0e                   	push   cs
    66a7:	57                   	push   di
    66a8:	9a 4c 18 c5 66       	call   0x66c5:0x184c
    66ad:	8d be fc fc          	lea    di,[bp-0x304]
    66b1:	16                   	push   ss
    66b2:	57                   	push   di
    66b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66b6:	26 c4 bd 7c 04       	les    di,DWORD PTR es:[di+0x47c]
    66bb:	06                   	push   es
    66bc:	57                   	push   di
    66bd:	9a 53 1d 1b 67       	call   0x671b:0x1d53
    66c2:	9a 4c 18 e0 66       	call   0x66e0:0x184c
    66c7:	8d be fc fb          	lea    di,[bp-0x404]
    66cb:	16                   	push   ss
    66cc:	57                   	push   di
    66cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66d0:	26 8b 85 8e 04       	mov    ax,WORD PTR es:[di+0x48e]
    66d5:	99                   	cwd
    66d6:	52                   	push   dx
    66d7:	50                   	push   ax
    66d8:	9a a9 08 ff ff       	call   0xffff:0x8a9
    66dd:	9a 4c 18 ee 66       	call   0x66ee:0x184c
    66e2:	8d be 00 ff          	lea    di,[bp-0x100]
    66e6:	16                   	push   ss
    66e7:	57                   	push   di
    66e8:	68 ff 00             	push   0xff
    66eb:	9a e7 17 25 67       	call   0x6725:0x17e7
    66f0:	8d be 00 ff          	lea    di,[bp-0x100]
    66f4:	16                   	push   ss
    66f5:	57                   	push   di
    66f6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    66fa:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    66ff:	06                   	push   es
    6700:	57                   	push   di
    6701:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6704:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6708:	8d be fc fd          	lea    di,[bp-0x204]
    670c:	16                   	push   ss
    670d:	57                   	push   di
    670e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6711:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    6716:	06                   	push   es
    6717:	57                   	push   di
    6718:	9a 53 1d 3a 67       	call   0x673a:0x1d53
    671d:	bf 68 66             	mov    di,0x6668
    6720:	0e                   	push   cs
    6721:	57                   	push   di
    6722:	9a 4c 18 3f 67       	call   0x673f:0x184c
    6727:	8d be fc fc          	lea    di,[bp-0x304]
    672b:	16                   	push   ss
    672c:	57                   	push   di
    672d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6730:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    6735:	06                   	push   es
    6736:	57                   	push   di
    6737:	9a 53 1d 8b 73       	call   0x738b:0x1d53
    673c:	9a 4c 18 4d 67       	call   0x674d:0x184c
    6741:	8d be 00 ff          	lea    di,[bp-0x100]
    6745:	16                   	push   ss
    6746:	57                   	push   di
    6747:	68 ff 00             	push   0xff
    674a:	9a e7 17 6c 73       	call   0x736c:0x17e7
    674f:	8d be 00 ff          	lea    di,[bp-0x100]
    6753:	16                   	push   ss
    6754:	57                   	push   di
    6755:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6759:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    675e:	06                   	push   es
    675f:	57                   	push   di
    6760:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6763:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6767:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    676c:	8d be 00 ff          	lea    di,[bp-0x100]
    6770:	16                   	push   ss
    6771:	57                   	push   di
    6772:	68 ff 00             	push   0xff
    6775:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6778:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    677d:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    6782:	55                   	push   bp
    6783:	9a 92 62 bf 67       	call   0x67bf:0x6292
    6788:	8d be 00 ff          	lea    di,[bp-0x100]
    678c:	16                   	push   ss
    678d:	57                   	push   di
    678e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6792:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6797:	06                   	push   es
    6798:	57                   	push   di
    6799:	26 c4 3d             	les    di,DWORD PTR es:[di]
    679c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    67a0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    67a5:	8d be 00 ff          	lea    di,[bp-0x100]
    67a9:	16                   	push   ss
    67aa:	57                   	push   di
    67ab:	68 ff 00             	push   0xff
    67ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67b1:	26 ff b5 22 03       	push   WORD PTR es:[di+0x322]
    67b6:	26 ff b5 20 03       	push   WORD PTR es:[di+0x320]
    67bb:	55                   	push   bp
    67bc:	9a 92 62 db 67       	call   0x67db:0x6292
    67c1:	8d be 00 ff          	lea    di,[bp-0x100]
    67c5:	16                   	push   ss
    67c6:	57                   	push   di
    67c7:	68 ff 00             	push   0xff
    67ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67cd:	26 ff b5 26 03       	push   WORD PTR es:[di+0x326]
    67d2:	26 ff b5 24 03       	push   WORD PTR es:[di+0x324]
    67d7:	55                   	push   bp
    67d8:	9a 92 62 1b 68       	call   0x681b:0x6292
    67dd:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    67e2:	76 18                	jbe    0x67fc
    67e4:	8d be 00 ff          	lea    di,[bp-0x100]
    67e8:	16                   	push   ss
    67e9:	57                   	push   di
    67ea:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    67ee:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    67f3:	06                   	push   es
    67f4:	57                   	push   di
    67f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    67f8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    67fc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6801:	8d be 00 ff          	lea    di,[bp-0x100]
    6805:	16                   	push   ss
    6806:	57                   	push   di
    6807:	68 ff 00             	push   0xff
    680a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    680d:	26 ff b5 2a 03       	push   WORD PTR es:[di+0x32a]
    6812:	26 ff b5 28 03       	push   WORD PTR es:[di+0x328]
    6817:	55                   	push   bp
    6818:	9a 92 62 37 68       	call   0x6837:0x6292
    681d:	8d be 00 ff          	lea    di,[bp-0x100]
    6821:	16                   	push   ss
    6822:	57                   	push   di
    6823:	68 ff 00             	push   0xff
    6826:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6829:	26 ff b5 2e 03       	push   WORD PTR es:[di+0x32e]
    682e:	26 ff b5 2c 03       	push   WORD PTR es:[di+0x32c]
    6833:	55                   	push   bp
    6834:	9a 92 62 77 68       	call   0x6877:0x6292
    6839:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    683e:	76 18                	jbe    0x6858
    6840:	8d be 00 ff          	lea    di,[bp-0x100]
    6844:	16                   	push   ss
    6845:	57                   	push   di
    6846:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    684a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    684f:	06                   	push   es
    6850:	57                   	push   di
    6851:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6854:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6858:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    685d:	8d be 00 ff          	lea    di,[bp-0x100]
    6861:	16                   	push   ss
    6862:	57                   	push   di
    6863:	68 ff 00             	push   0xff
    6866:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6869:	26 ff b5 32 03       	push   WORD PTR es:[di+0x332]
    686e:	26 ff b5 30 03       	push   WORD PTR es:[di+0x330]
    6873:	55                   	push   bp
    6874:	9a 92 62 93 68       	call   0x6893:0x6292
    6879:	8d be 00 ff          	lea    di,[bp-0x100]
    687d:	16                   	push   ss
    687e:	57                   	push   di
    687f:	68 ff 00             	push   0xff
    6882:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6885:	26 ff b5 36 03       	push   WORD PTR es:[di+0x336]
    688a:	26 ff b5 34 03       	push   WORD PTR es:[di+0x334]
    688f:	55                   	push   bp
    6890:	9a 92 62 d3 68       	call   0x68d3:0x6292
    6895:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    689a:	76 18                	jbe    0x68b4
    689c:	8d be 00 ff          	lea    di,[bp-0x100]
    68a0:	16                   	push   ss
    68a1:	57                   	push   di
    68a2:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    68a6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    68ab:	06                   	push   es
    68ac:	57                   	push   di
    68ad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    68b0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    68b4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    68b9:	8d be 00 ff          	lea    di,[bp-0x100]
    68bd:	16                   	push   ss
    68be:	57                   	push   di
    68bf:	68 ff 00             	push   0xff
    68c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68c5:	26 ff b5 3a 03       	push   WORD PTR es:[di+0x33a]
    68ca:	26 ff b5 38 03       	push   WORD PTR es:[di+0x338]
    68cf:	55                   	push   bp
    68d0:	9a 92 62 ef 68       	call   0x68ef:0x6292
    68d5:	8d be 00 ff          	lea    di,[bp-0x100]
    68d9:	16                   	push   ss
    68da:	57                   	push   di
    68db:	68 ff 00             	push   0xff
    68de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68e1:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    68e6:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    68eb:	55                   	push   bp
    68ec:	9a 92 62 2f 69       	call   0x692f:0x6292
    68f1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    68f6:	76 18                	jbe    0x6910
    68f8:	8d be 00 ff          	lea    di,[bp-0x100]
    68fc:	16                   	push   ss
    68fd:	57                   	push   di
    68fe:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6902:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6907:	06                   	push   es
    6908:	57                   	push   di
    6909:	26 c4 3d             	les    di,DWORD PTR es:[di]
    690c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6910:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6915:	8d be 00 ff          	lea    di,[bp-0x100]
    6919:	16                   	push   ss
    691a:	57                   	push   di
    691b:	68 ff 00             	push   0xff
    691e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6921:	26 ff b5 42 03       	push   WORD PTR es:[di+0x342]
    6926:	26 ff b5 40 03       	push   WORD PTR es:[di+0x340]
    692b:	55                   	push   bp
    692c:	9a 92 62 4b 69       	call   0x694b:0x6292
    6931:	8d be 00 ff          	lea    di,[bp-0x100]
    6935:	16                   	push   ss
    6936:	57                   	push   di
    6937:	68 ff 00             	push   0xff
    693a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    693d:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    6942:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    6947:	55                   	push   bp
    6948:	9a 92 62 8b 69       	call   0x698b:0x6292
    694d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6952:	76 18                	jbe    0x696c
    6954:	8d be 00 ff          	lea    di,[bp-0x100]
    6958:	16                   	push   ss
    6959:	57                   	push   di
    695a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    695e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6963:	06                   	push   es
    6964:	57                   	push   di
    6965:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6968:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    696c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6971:	8d be 00 ff          	lea    di,[bp-0x100]
    6975:	16                   	push   ss
    6976:	57                   	push   di
    6977:	68 ff 00             	push   0xff
    697a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    697d:	26 ff b5 4a 03       	push   WORD PTR es:[di+0x34a]
    6982:	26 ff b5 48 03       	push   WORD PTR es:[di+0x348]
    6987:	55                   	push   bp
    6988:	9a 92 62 a7 69       	call   0x69a7:0x6292
    698d:	8d be 00 ff          	lea    di,[bp-0x100]
    6991:	16                   	push   ss
    6992:	57                   	push   di
    6993:	68 ff 00             	push   0xff
    6996:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6999:	26 ff b5 4e 03       	push   WORD PTR es:[di+0x34e]
    699e:	26 ff b5 4c 03       	push   WORD PTR es:[di+0x34c]
    69a3:	55                   	push   bp
    69a4:	9a 92 62 e7 69       	call   0x69e7:0x6292
    69a9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    69ae:	76 18                	jbe    0x69c8
    69b0:	8d be 00 ff          	lea    di,[bp-0x100]
    69b4:	16                   	push   ss
    69b5:	57                   	push   di
    69b6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    69ba:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    69bf:	06                   	push   es
    69c0:	57                   	push   di
    69c1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    69c4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    69c8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    69cd:	8d be 00 ff          	lea    di,[bp-0x100]
    69d1:	16                   	push   ss
    69d2:	57                   	push   di
    69d3:	68 ff 00             	push   0xff
    69d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69d9:	26 ff b5 52 03       	push   WORD PTR es:[di+0x352]
    69de:	26 ff b5 50 03       	push   WORD PTR es:[di+0x350]
    69e3:	55                   	push   bp
    69e4:	9a 92 62 03 6a       	call   0x6a03:0x6292
    69e9:	8d be 00 ff          	lea    di,[bp-0x100]
    69ed:	16                   	push   ss
    69ee:	57                   	push   di
    69ef:	68 ff 00             	push   0xff
    69f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69f5:	26 ff b5 56 03       	push   WORD PTR es:[di+0x356]
    69fa:	26 ff b5 54 03       	push   WORD PTR es:[di+0x354]
    69ff:	55                   	push   bp
    6a00:	9a 92 62 43 6a       	call   0x6a43:0x6292
    6a05:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6a0a:	76 18                	jbe    0x6a24
    6a0c:	8d be 00 ff          	lea    di,[bp-0x100]
    6a10:	16                   	push   ss
    6a11:	57                   	push   di
    6a12:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6a16:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6a1b:	06                   	push   es
    6a1c:	57                   	push   di
    6a1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a20:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6a24:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6a29:	8d be 00 ff          	lea    di,[bp-0x100]
    6a2d:	16                   	push   ss
    6a2e:	57                   	push   di
    6a2f:	68 ff 00             	push   0xff
    6a32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a35:	26 ff b5 c6 01       	push   WORD PTR es:[di+0x1c6]
    6a3a:	26 ff b5 c4 01       	push   WORD PTR es:[di+0x1c4]
    6a3f:	55                   	push   bp
    6a40:	9a 92 62 7c 6a       	call   0x6a7c:0x6292
    6a45:	8d be 00 ff          	lea    di,[bp-0x100]
    6a49:	16                   	push   ss
    6a4a:	57                   	push   di
    6a4b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6a4f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6a54:	06                   	push   es
    6a55:	57                   	push   di
    6a56:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a59:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6a5d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6a62:	8d be 00 ff          	lea    di,[bp-0x100]
    6a66:	16                   	push   ss
    6a67:	57                   	push   di
    6a68:	68 ff 00             	push   0xff
    6a6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a6e:	26 ff b5 5a 03       	push   WORD PTR es:[di+0x35a]
    6a73:	26 ff b5 58 03       	push   WORD PTR es:[di+0x358]
    6a78:	55                   	push   bp
    6a79:	9a 92 62 98 6a       	call   0x6a98:0x6292
    6a7e:	8d be 00 ff          	lea    di,[bp-0x100]
    6a82:	16                   	push   ss
    6a83:	57                   	push   di
    6a84:	68 ff 00             	push   0xff
    6a87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a8a:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    6a8f:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    6a94:	55                   	push   bp
    6a95:	9a 92 62 d8 6a       	call   0x6ad8:0x6292
    6a9a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6a9f:	76 18                	jbe    0x6ab9
    6aa1:	8d be 00 ff          	lea    di,[bp-0x100]
    6aa5:	16                   	push   ss
    6aa6:	57                   	push   di
    6aa7:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6aab:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6ab0:	06                   	push   es
    6ab1:	57                   	push   di
    6ab2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6ab5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6ab9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6abe:	8d be 00 ff          	lea    di,[bp-0x100]
    6ac2:	16                   	push   ss
    6ac3:	57                   	push   di
    6ac4:	68 ff 00             	push   0xff
    6ac7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aca:	26 ff b5 62 03       	push   WORD PTR es:[di+0x362]
    6acf:	26 ff b5 60 03       	push   WORD PTR es:[di+0x360]
    6ad4:	55                   	push   bp
    6ad5:	9a 92 62 f4 6a       	call   0x6af4:0x6292
    6ada:	8d be 00 ff          	lea    di,[bp-0x100]
    6ade:	16                   	push   ss
    6adf:	57                   	push   di
    6ae0:	68 ff 00             	push   0xff
    6ae3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ae6:	26 ff b5 66 03       	push   WORD PTR es:[di+0x366]
    6aeb:	26 ff b5 64 03       	push   WORD PTR es:[di+0x364]
    6af0:	55                   	push   bp
    6af1:	9a 92 62 34 6b       	call   0x6b34:0x6292
    6af6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6afb:	76 18                	jbe    0x6b15
    6afd:	8d be 00 ff          	lea    di,[bp-0x100]
    6b01:	16                   	push   ss
    6b02:	57                   	push   di
    6b03:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b07:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b0c:	06                   	push   es
    6b0d:	57                   	push   di
    6b0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b11:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b15:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b1a:	8d be 00 ff          	lea    di,[bp-0x100]
    6b1e:	16                   	push   ss
    6b1f:	57                   	push   di
    6b20:	68 ff 00             	push   0xff
    6b23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b26:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    6b2b:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    6b30:	55                   	push   bp
    6b31:	9a 92 62 50 6b       	call   0x6b50:0x6292
    6b36:	8d be 00 ff          	lea    di,[bp-0x100]
    6b3a:	16                   	push   ss
    6b3b:	57                   	push   di
    6b3c:	68 ff 00             	push   0xff
    6b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b42:	26 ff b5 ee 01       	push   WORD PTR es:[di+0x1ee]
    6b47:	26 ff b5 ec 01       	push   WORD PTR es:[di+0x1ec]
    6b4c:	55                   	push   bp
    6b4d:	9a 92 62 6c 6b       	call   0x6b6c:0x6292
    6b52:	8d be 00 ff          	lea    di,[bp-0x100]
    6b56:	16                   	push   ss
    6b57:	57                   	push   di
    6b58:	68 ff 00             	push   0xff
    6b5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b5e:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    6b63:	26 ff b5 00 02       	push   WORD PTR es:[di+0x200]
    6b68:	55                   	push   bp
    6b69:	9a 92 62 ac 6b       	call   0x6bac:0x6292
    6b6e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6b73:	76 18                	jbe    0x6b8d
    6b75:	8d be 00 ff          	lea    di,[bp-0x100]
    6b79:	16                   	push   ss
    6b7a:	57                   	push   di
    6b7b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b7f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b84:	06                   	push   es
    6b85:	57                   	push   di
    6b86:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b89:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b8d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b92:	8d be 00 ff          	lea    di,[bp-0x100]
    6b96:	16                   	push   ss
    6b97:	57                   	push   di
    6b98:	68 ff 00             	push   0xff
    6b9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b9e:	26 ff b5 6a 03       	push   WORD PTR es:[di+0x36a]
    6ba3:	26 ff b5 68 03       	push   WORD PTR es:[di+0x368]
    6ba8:	55                   	push   bp
    6ba9:	9a 92 62 c8 6b       	call   0x6bc8:0x6292
    6bae:	8d be 00 ff          	lea    di,[bp-0x100]
    6bb2:	16                   	push   ss
    6bb3:	57                   	push   di
    6bb4:	68 ff 00             	push   0xff
    6bb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bba:	26 ff b5 f2 01       	push   WORD PTR es:[di+0x1f2]
    6bbf:	26 ff b5 f0 01       	push   WORD PTR es:[di+0x1f0]
    6bc4:	55                   	push   bp
    6bc5:	9a 92 62 e4 6b       	call   0x6be4:0x6292
    6bca:	8d be 00 ff          	lea    di,[bp-0x100]
    6bce:	16                   	push   ss
    6bcf:	57                   	push   di
    6bd0:	68 ff 00             	push   0xff
    6bd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bd6:	26 ff b5 06 02       	push   WORD PTR es:[di+0x206]
    6bdb:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    6be0:	55                   	push   bp
    6be1:	9a 92 62 24 6c       	call   0x6c24:0x6292
    6be6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6beb:	76 18                	jbe    0x6c05
    6bed:	8d be 00 ff          	lea    di,[bp-0x100]
    6bf1:	16                   	push   ss
    6bf2:	57                   	push   di
    6bf3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6bf7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6bfc:	06                   	push   es
    6bfd:	57                   	push   di
    6bfe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c01:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c05:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c0a:	8d be 00 ff          	lea    di,[bp-0x100]
    6c0e:	16                   	push   ss
    6c0f:	57                   	push   di
    6c10:	68 ff 00             	push   0xff
    6c13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c16:	26 ff b5 6e 03       	push   WORD PTR es:[di+0x36e]
    6c1b:	26 ff b5 6c 03       	push   WORD PTR es:[di+0x36c]
    6c20:	55                   	push   bp
    6c21:	9a 92 62 40 6c       	call   0x6c40:0x6292
    6c26:	8d be 00 ff          	lea    di,[bp-0x100]
    6c2a:	16                   	push   ss
    6c2b:	57                   	push   di
    6c2c:	68 ff 00             	push   0xff
    6c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c32:	26 ff b5 f6 01       	push   WORD PTR es:[di+0x1f6]
    6c37:	26 ff b5 f4 01       	push   WORD PTR es:[di+0x1f4]
    6c3c:	55                   	push   bp
    6c3d:	9a 92 62 5c 6c       	call   0x6c5c:0x6292
    6c42:	8d be 00 ff          	lea    di,[bp-0x100]
    6c46:	16                   	push   ss
    6c47:	57                   	push   di
    6c48:	68 ff 00             	push   0xff
    6c4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c4e:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    6c53:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    6c58:	55                   	push   bp
    6c59:	9a 92 62 9c 6c       	call   0x6c9c:0x6292
    6c5e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6c63:	76 18                	jbe    0x6c7d
    6c65:	8d be 00 ff          	lea    di,[bp-0x100]
    6c69:	16                   	push   ss
    6c6a:	57                   	push   di
    6c6b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c6f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c74:	06                   	push   es
    6c75:	57                   	push   di
    6c76:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c79:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c7d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c82:	8d be 00 ff          	lea    di,[bp-0x100]
    6c86:	16                   	push   ss
    6c87:	57                   	push   di
    6c88:	68 ff 00             	push   0xff
    6c8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c8e:	26 ff b5 72 03       	push   WORD PTR es:[di+0x372]
    6c93:	26 ff b5 70 03       	push   WORD PTR es:[di+0x370]
    6c98:	55                   	push   bp
    6c99:	9a 92 62 b8 6c       	call   0x6cb8:0x6292
    6c9e:	8d be 00 ff          	lea    di,[bp-0x100]
    6ca2:	16                   	push   ss
    6ca3:	57                   	push   di
    6ca4:	68 ff 00             	push   0xff
    6ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6caa:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    6caf:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    6cb4:	55                   	push   bp
    6cb5:	9a 92 62 d4 6c       	call   0x6cd4:0x6292
    6cba:	8d be 00 ff          	lea    di,[bp-0x100]
    6cbe:	16                   	push   ss
    6cbf:	57                   	push   di
    6cc0:	68 ff 00             	push   0xff
    6cc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cc6:	26 ff b5 0e 02       	push   WORD PTR es:[di+0x20e]
    6ccb:	26 ff b5 0c 02       	push   WORD PTR es:[di+0x20c]
    6cd0:	55                   	push   bp
    6cd1:	9a 92 62 14 6d       	call   0x6d14:0x6292
    6cd6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6cdb:	76 18                	jbe    0x6cf5
    6cdd:	8d be 00 ff          	lea    di,[bp-0x100]
    6ce1:	16                   	push   ss
    6ce2:	57                   	push   di
    6ce3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ce7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6cec:	06                   	push   es
    6ced:	57                   	push   di
    6cee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6cf1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6cf5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6cfa:	8d be 00 ff          	lea    di,[bp-0x100]
    6cfe:	16                   	push   ss
    6cff:	57                   	push   di
    6d00:	68 ff 00             	push   0xff
    6d03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d06:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    6d0b:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    6d10:	55                   	push   bp
    6d11:	9a 92 62 4d 6d       	call   0x6d4d:0x6292
    6d16:	8d be 00 ff          	lea    di,[bp-0x100]
    6d1a:	16                   	push   ss
    6d1b:	57                   	push   di
    6d1c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d20:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d25:	06                   	push   es
    6d26:	57                   	push   di
    6d27:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d2a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d2e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d33:	8d be 00 ff          	lea    di,[bp-0x100]
    6d37:	16                   	push   ss
    6d38:	57                   	push   di
    6d39:	68 ff 00             	push   0xff
    6d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d3f:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    6d44:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    6d49:	55                   	push   bp
    6d4a:	9a 92 62 69 6d       	call   0x6d69:0x6292
    6d4f:	8d be 00 ff          	lea    di,[bp-0x100]
    6d53:	16                   	push   ss
    6d54:	57                   	push   di
    6d55:	68 ff 00             	push   0xff
    6d58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d5b:	26 ff b5 7a 03       	push   WORD PTR es:[di+0x37a]
    6d60:	26 ff b5 78 03       	push   WORD PTR es:[di+0x378]
    6d65:	55                   	push   bp
    6d66:	9a 92 62 a9 6d       	call   0x6da9:0x6292
    6d6b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6d70:	76 18                	jbe    0x6d8a
    6d72:	8d be 00 ff          	lea    di,[bp-0x100]
    6d76:	16                   	push   ss
    6d77:	57                   	push   di
    6d78:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d7c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d81:	06                   	push   es
    6d82:	57                   	push   di
    6d83:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d86:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d8a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d8f:	8d be 00 ff          	lea    di,[bp-0x100]
    6d93:	16                   	push   ss
    6d94:	57                   	push   di
    6d95:	68 ff 00             	push   0xff
    6d98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d9b:	26 ff b5 86 03       	push   WORD PTR es:[di+0x386]
    6da0:	26 ff b5 84 03       	push   WORD PTR es:[di+0x384]
    6da5:	55                   	push   bp
    6da6:	9a 92 62 c5 6d       	call   0x6dc5:0x6292
    6dab:	8d be 00 ff          	lea    di,[bp-0x100]
    6daf:	16                   	push   ss
    6db0:	57                   	push   di
    6db1:	68 ff 00             	push   0xff
    6db4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6db7:	26 ff b5 8a 03       	push   WORD PTR es:[di+0x38a]
    6dbc:	26 ff b5 88 03       	push   WORD PTR es:[di+0x388]
    6dc1:	55                   	push   bp
    6dc2:	9a 92 62 05 6e       	call   0x6e05:0x6292
    6dc7:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6dcc:	76 18                	jbe    0x6de6
    6dce:	8d be 00 ff          	lea    di,[bp-0x100]
    6dd2:	16                   	push   ss
    6dd3:	57                   	push   di
    6dd4:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6dd8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6ddd:	06                   	push   es
    6dde:	57                   	push   di
    6ddf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6de2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6de6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6deb:	8d be 00 ff          	lea    di,[bp-0x100]
    6def:	16                   	push   ss
    6df0:	57                   	push   di
    6df1:	68 ff 00             	push   0xff
    6df4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6df7:	26 ff b5 7e 03       	push   WORD PTR es:[di+0x37e]
    6dfc:	26 ff b5 7c 03       	push   WORD PTR es:[di+0x37c]
    6e01:	55                   	push   bp
    6e02:	9a 92 62 21 6e       	call   0x6e21:0x6292
    6e07:	8d be 00 ff          	lea    di,[bp-0x100]
    6e0b:	16                   	push   ss
    6e0c:	57                   	push   di
    6e0d:	68 ff 00             	push   0xff
    6e10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e13:	26 ff b5 82 03       	push   WORD PTR es:[di+0x382]
    6e18:	26 ff b5 80 03       	push   WORD PTR es:[di+0x380]
    6e1d:	55                   	push   bp
    6e1e:	9a 92 62 61 6e       	call   0x6e61:0x6292
    6e23:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6e28:	76 18                	jbe    0x6e42
    6e2a:	8d be 00 ff          	lea    di,[bp-0x100]
    6e2e:	16                   	push   ss
    6e2f:	57                   	push   di
    6e30:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e34:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e39:	06                   	push   es
    6e3a:	57                   	push   di
    6e3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e3e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6e42:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6e47:	8d be 00 ff          	lea    di,[bp-0x100]
    6e4b:	16                   	push   ss
    6e4c:	57                   	push   di
    6e4d:	68 ff 00             	push   0xff
    6e50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e53:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    6e58:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    6e5d:	55                   	push   bp
    6e5e:	9a 92 62 7d 6e       	call   0x6e7d:0x6292
    6e63:	8d be 00 ff          	lea    di,[bp-0x100]
    6e67:	16                   	push   ss
    6e68:	57                   	push   di
    6e69:	68 ff 00             	push   0xff
    6e6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e6f:	26 ff b5 16 02       	push   WORD PTR es:[di+0x216]
    6e74:	26 ff b5 14 02       	push   WORD PTR es:[di+0x214]
    6e79:	55                   	push   bp
    6e7a:	9a 92 62 99 6e       	call   0x6e99:0x6292
    6e7f:	8d be 00 ff          	lea    di,[bp-0x100]
    6e83:	16                   	push   ss
    6e84:	57                   	push   di
    6e85:	68 ff 00             	push   0xff
    6e88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e8b:	26 ff b5 22 02       	push   WORD PTR es:[di+0x222]
    6e90:	26 ff b5 20 02       	push   WORD PTR es:[di+0x220]
    6e95:	55                   	push   bp
    6e96:	9a 92 62 d9 6e       	call   0x6ed9:0x6292
    6e9b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6ea0:	76 18                	jbe    0x6eba
    6ea2:	8d be 00 ff          	lea    di,[bp-0x100]
    6ea6:	16                   	push   ss
    6ea7:	57                   	push   di
    6ea8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6eac:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6eb1:	06                   	push   es
    6eb2:	57                   	push   di
    6eb3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6eb6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6eba:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ebf:	8d be 00 ff          	lea    di,[bp-0x100]
    6ec3:	16                   	push   ss
    6ec4:	57                   	push   di
    6ec5:	68 ff 00             	push   0xff
    6ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ecb:	26 ff b5 8e 03       	push   WORD PTR es:[di+0x38e]
    6ed0:	26 ff b5 8c 03       	push   WORD PTR es:[di+0x38c]
    6ed5:	55                   	push   bp
    6ed6:	9a 92 62 f5 6e       	call   0x6ef5:0x6292
    6edb:	8d be 00 ff          	lea    di,[bp-0x100]
    6edf:	16                   	push   ss
    6ee0:	57                   	push   di
    6ee1:	68 ff 00             	push   0xff
    6ee4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ee7:	26 ff b5 1a 02       	push   WORD PTR es:[di+0x21a]
    6eec:	26 ff b5 18 02       	push   WORD PTR es:[di+0x218]
    6ef1:	55                   	push   bp
    6ef2:	9a 92 62 11 6f       	call   0x6f11:0x6292
    6ef7:	8d be 00 ff          	lea    di,[bp-0x100]
    6efb:	16                   	push   ss
    6efc:	57                   	push   di
    6efd:	68 ff 00             	push   0xff
    6f00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f03:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    6f08:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    6f0d:	55                   	push   bp
    6f0e:	9a 92 62 51 6f       	call   0x6f51:0x6292
    6f13:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6f18:	76 18                	jbe    0x6f32
    6f1a:	8d be 00 ff          	lea    di,[bp-0x100]
    6f1e:	16                   	push   ss
    6f1f:	57                   	push   di
    6f20:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f24:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f29:	06                   	push   es
    6f2a:	57                   	push   di
    6f2b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f2e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f32:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6f37:	8d be 00 ff          	lea    di,[bp-0x100]
    6f3b:	16                   	push   ss
    6f3c:	57                   	push   di
    6f3d:	68 ff 00             	push   0xff
    6f40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f43:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    6f48:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    6f4d:	55                   	push   bp
    6f4e:	9a 92 62 8a 6f       	call   0x6f8a:0x6292
    6f53:	8d be 00 ff          	lea    di,[bp-0x100]
    6f57:	16                   	push   ss
    6f58:	57                   	push   di
    6f59:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f5d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f62:	06                   	push   es
    6f63:	57                   	push   di
    6f64:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f67:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f6b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6f70:	8d be 00 ff          	lea    di,[bp-0x100]
    6f74:	16                   	push   ss
    6f75:	57                   	push   di
    6f76:	68 ff 00             	push   0xff
    6f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f7c:	26 ff b5 92 03       	push   WORD PTR es:[di+0x392]
    6f81:	26 ff b5 90 03       	push   WORD PTR es:[di+0x390]
    6f86:	55                   	push   bp
    6f87:	9a 92 62 a6 6f       	call   0x6fa6:0x6292
    6f8c:	8d be 00 ff          	lea    di,[bp-0x100]
    6f90:	16                   	push   ss
    6f91:	57                   	push   di
    6f92:	68 ff 00             	push   0xff
    6f95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f98:	26 ff b5 9e 03       	push   WORD PTR es:[di+0x39e]
    6f9d:	26 ff b5 9c 03       	push   WORD PTR es:[di+0x39c]
    6fa2:	55                   	push   bp
    6fa3:	9a 92 62 e6 6f       	call   0x6fe6:0x6292
    6fa8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6fad:	76 18                	jbe    0x6fc7
    6faf:	8d be 00 ff          	lea    di,[bp-0x100]
    6fb3:	16                   	push   ss
    6fb4:	57                   	push   di
    6fb5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6fb9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6fbe:	06                   	push   es
    6fbf:	57                   	push   di
    6fc0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6fc3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6fc7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6fcc:	8d be 00 ff          	lea    di,[bp-0x100]
    6fd0:	16                   	push   ss
    6fd1:	57                   	push   di
    6fd2:	68 ff 00             	push   0xff
    6fd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fd8:	26 ff b5 96 03       	push   WORD PTR es:[di+0x396]
    6fdd:	26 ff b5 94 03       	push   WORD PTR es:[di+0x394]
    6fe2:	55                   	push   bp
    6fe3:	9a 92 62 02 70       	call   0x7002:0x6292
    6fe8:	8d be 00 ff          	lea    di,[bp-0x100]
    6fec:	16                   	push   ss
    6fed:	57                   	push   di
    6fee:	68 ff 00             	push   0xff
    6ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ff4:	26 ff b5 a2 03       	push   WORD PTR es:[di+0x3a2]
    6ff9:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    6ffe:	55                   	push   bp
    6fff:	9a 92 62 42 70       	call   0x7042:0x6292
    7004:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7009:	76 18                	jbe    0x7023
    700b:	8d be 00 ff          	lea    di,[bp-0x100]
    700f:	16                   	push   ss
    7010:	57                   	push   di
    7011:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7015:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    701a:	06                   	push   es
    701b:	57                   	push   di
    701c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    701f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7023:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7028:	8d be 00 ff          	lea    di,[bp-0x100]
    702c:	16                   	push   ss
    702d:	57                   	push   di
    702e:	68 ff 00             	push   0xff
    7031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7034:	26 ff b5 9a 03       	push   WORD PTR es:[di+0x39a]
    7039:	26 ff b5 98 03       	push   WORD PTR es:[di+0x398]
    703e:	55                   	push   bp
    703f:	9a 92 62 5e 70       	call   0x705e:0x6292
    7044:	8d be 00 ff          	lea    di,[bp-0x100]
    7048:	16                   	push   ss
    7049:	57                   	push   di
    704a:	68 ff 00             	push   0xff
    704d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7050:	26 ff b5 a6 03       	push   WORD PTR es:[di+0x3a6]
    7055:	26 ff b5 a4 03       	push   WORD PTR es:[di+0x3a4]
    705a:	55                   	push   bp
    705b:	9a 92 62 9e 70       	call   0x709e:0x6292
    7060:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7065:	76 18                	jbe    0x707f
    7067:	8d be 00 ff          	lea    di,[bp-0x100]
    706b:	16                   	push   ss
    706c:	57                   	push   di
    706d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7071:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7076:	06                   	push   es
    7077:	57                   	push   di
    7078:	26 c4 3d             	les    di,DWORD PTR es:[di]
    707b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    707f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7084:	8d be 00 ff          	lea    di,[bp-0x100]
    7088:	16                   	push   ss
    7089:	57                   	push   di
    708a:	68 ff 00             	push   0xff
    708d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7090:	26 ff b5 9e 02       	push   WORD PTR es:[di+0x29e]
    7095:	26 ff b5 9c 02       	push   WORD PTR es:[di+0x29c]
    709a:	55                   	push   bp
    709b:	9a 92 62 d7 70       	call   0x70d7:0x6292
    70a0:	8d be 00 ff          	lea    di,[bp-0x100]
    70a4:	16                   	push   ss
    70a5:	57                   	push   di
    70a6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    70aa:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    70af:	06                   	push   es
    70b0:	57                   	push   di
    70b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    70b4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    70b8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    70bd:	8d be 00 ff          	lea    di,[bp-0x100]
    70c1:	16                   	push   ss
    70c2:	57                   	push   di
    70c3:	68 ff 00             	push   0xff
    70c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70c9:	26 ff b5 aa 03       	push   WORD PTR es:[di+0x3aa]
    70ce:	26 ff b5 a8 03       	push   WORD PTR es:[di+0x3a8]
    70d3:	55                   	push   bp
    70d4:	9a 92 62 f3 70       	call   0x70f3:0x6292
    70d9:	8d be 00 ff          	lea    di,[bp-0x100]
    70dd:	16                   	push   ss
    70de:	57                   	push   di
    70df:	68 ff 00             	push   0xff
    70e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70e5:	26 ff b5 ae 03       	push   WORD PTR es:[di+0x3ae]
    70ea:	26 ff b5 ac 03       	push   WORD PTR es:[di+0x3ac]
    70ef:	55                   	push   bp
    70f0:	9a 92 62 33 71       	call   0x7133:0x6292
    70f5:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    70fa:	76 18                	jbe    0x7114
    70fc:	8d be 00 ff          	lea    di,[bp-0x100]
    7100:	16                   	push   ss
    7101:	57                   	push   di
    7102:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7106:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    710b:	06                   	push   es
    710c:	57                   	push   di
    710d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7110:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7114:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7119:	8d be 00 ff          	lea    di,[bp-0x100]
    711d:	16                   	push   ss
    711e:	57                   	push   di
    711f:	68 ff 00             	push   0xff
    7122:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7125:	26 ff b5 b2 03       	push   WORD PTR es:[di+0x3b2]
    712a:	26 ff b5 b0 03       	push   WORD PTR es:[di+0x3b0]
    712f:	55                   	push   bp
    7130:	9a 92 62 4f 71       	call   0x714f:0x6292
    7135:	8d be 00 ff          	lea    di,[bp-0x100]
    7139:	16                   	push   ss
    713a:	57                   	push   di
    713b:	68 ff 00             	push   0xff
    713e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7141:	26 ff b5 b6 03       	push   WORD PTR es:[di+0x3b6]
    7146:	26 ff b5 b4 03       	push   WORD PTR es:[di+0x3b4]
    714b:	55                   	push   bp
    714c:	9a 92 62 8f 71       	call   0x718f:0x6292
    7151:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7156:	76 18                	jbe    0x7170
    7158:	8d be 00 ff          	lea    di,[bp-0x100]
    715c:	16                   	push   ss
    715d:	57                   	push   di
    715e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7162:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7167:	06                   	push   es
    7168:	57                   	push   di
    7169:	26 c4 3d             	les    di,DWORD PTR es:[di]
    716c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7170:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7175:	8d be 00 ff          	lea    di,[bp-0x100]
    7179:	16                   	push   ss
    717a:	57                   	push   di
    717b:	68 ff 00             	push   0xff
    717e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7181:	26 ff b5 ba 03       	push   WORD PTR es:[di+0x3ba]
    7186:	26 ff b5 b8 03       	push   WORD PTR es:[di+0x3b8]
    718b:	55                   	push   bp
    718c:	9a 92 62 ab 71       	call   0x71ab:0x6292
    7191:	8d be 00 ff          	lea    di,[bp-0x100]
    7195:	16                   	push   ss
    7196:	57                   	push   di
    7197:	68 ff 00             	push   0xff
    719a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    719d:	26 ff b5 be 03       	push   WORD PTR es:[di+0x3be]
    71a2:	26 ff b5 bc 03       	push   WORD PTR es:[di+0x3bc]
    71a7:	55                   	push   bp
    71a8:	9a 92 62 eb 71       	call   0x71eb:0x6292
    71ad:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    71b2:	76 18                	jbe    0x71cc
    71b4:	8d be 00 ff          	lea    di,[bp-0x100]
    71b8:	16                   	push   ss
    71b9:	57                   	push   di
    71ba:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    71be:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    71c3:	06                   	push   es
    71c4:	57                   	push   di
    71c5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    71c8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    71cc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    71d1:	8d be 00 ff          	lea    di,[bp-0x100]
    71d5:	16                   	push   ss
    71d6:	57                   	push   di
    71d7:	68 ff 00             	push   0xff
    71da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71dd:	26 ff b5 c2 03       	push   WORD PTR es:[di+0x3c2]
    71e2:	26 ff b5 c0 03       	push   WORD PTR es:[di+0x3c0]
    71e7:	55                   	push   bp
    71e8:	9a 92 62 07 72       	call   0x7207:0x6292
    71ed:	8d be 00 ff          	lea    di,[bp-0x100]
    71f1:	16                   	push   ss
    71f2:	57                   	push   di
    71f3:	68 ff 00             	push   0xff
    71f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71f9:	26 ff b5 c6 03       	push   WORD PTR es:[di+0x3c6]
    71fe:	26 ff b5 c4 03       	push   WORD PTR es:[di+0x3c4]
    7203:	55                   	push   bp
    7204:	9a 92 62 47 72       	call   0x7247:0x6292
    7209:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    720e:	76 18                	jbe    0x7228
    7210:	8d be 00 ff          	lea    di,[bp-0x100]
    7214:	16                   	push   ss
    7215:	57                   	push   di
    7216:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    721a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    721f:	06                   	push   es
    7220:	57                   	push   di
    7221:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7224:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7228:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    722d:	8d be 00 ff          	lea    di,[bp-0x100]
    7231:	16                   	push   ss
    7232:	57                   	push   di
    7233:	68 ff 00             	push   0xff
    7236:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7239:	26 ff b5 ca 03       	push   WORD PTR es:[di+0x3ca]
    723e:	26 ff b5 c8 03       	push   WORD PTR es:[di+0x3c8]
    7243:	55                   	push   bp
    7244:	9a 92 62 63 72       	call   0x7263:0x6292
    7249:	8d be 00 ff          	lea    di,[bp-0x100]
    724d:	16                   	push   ss
    724e:	57                   	push   di
    724f:	68 ff 00             	push   0xff
    7252:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7255:	26 ff b5 ce 03       	push   WORD PTR es:[di+0x3ce]
    725a:	26 ff b5 cc 03       	push   WORD PTR es:[di+0x3cc]
    725f:	55                   	push   bp
    7260:	9a 92 62 a3 72       	call   0x72a3:0x6292
    7265:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    726a:	76 18                	jbe    0x7284
    726c:	8d be 00 ff          	lea    di,[bp-0x100]
    7270:	16                   	push   ss
    7271:	57                   	push   di
    7272:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7276:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    727b:	06                   	push   es
    727c:	57                   	push   di
    727d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7280:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7284:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7289:	8d be 00 ff          	lea    di,[bp-0x100]
    728d:	16                   	push   ss
    728e:	57                   	push   di
    728f:	68 ff 00             	push   0xff
    7292:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7295:	26 ff b5 d2 03       	push   WORD PTR es:[di+0x3d2]
    729a:	26 ff b5 d0 03       	push   WORD PTR es:[di+0x3d0]
    729f:	55                   	push   bp
    72a0:	9a 92 62 bf 72       	call   0x72bf:0x6292
    72a5:	8d be 00 ff          	lea    di,[bp-0x100]
    72a9:	16                   	push   ss
    72aa:	57                   	push   di
    72ab:	68 ff 00             	push   0xff
    72ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72b1:	26 ff b5 d6 03       	push   WORD PTR es:[di+0x3d6]
    72b6:	26 ff b5 d4 03       	push   WORD PTR es:[di+0x3d4]
    72bb:	55                   	push   bp
    72bc:	9a 92 62 ff 72       	call   0x72ff:0x6292
    72c1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    72c6:	76 18                	jbe    0x72e0
    72c8:	8d be 00 ff          	lea    di,[bp-0x100]
    72cc:	16                   	push   ss
    72cd:	57                   	push   di
    72ce:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    72d2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    72d7:	06                   	push   es
    72d8:	57                   	push   di
    72d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    72dc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    72e0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    72e5:	8d be 00 ff          	lea    di,[bp-0x100]
    72e9:	16                   	push   ss
    72ea:	57                   	push   di
    72eb:	68 ff 00             	push   0xff
    72ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72f1:	26 ff b5 da 03       	push   WORD PTR es:[di+0x3da]
    72f6:	26 ff b5 d8 03       	push   WORD PTR es:[di+0x3d8]
    72fb:	55                   	push   bp
    72fc:	9a 92 62 1b 73       	call   0x731b:0x6292
    7301:	8d be 00 ff          	lea    di,[bp-0x100]
    7305:	16                   	push   ss
    7306:	57                   	push   di
    7307:	68 ff 00             	push   0xff
    730a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    730d:	26 ff b5 de 03       	push   WORD PTR es:[di+0x3de]
    7312:	26 ff b5 dc 03       	push   WORD PTR es:[di+0x3dc]
    7317:	55                   	push   bp
    7318:	9a 92 62 5b 73       	call   0x735b:0x6292
    731d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7322:	76 18                	jbe    0x733c
    7324:	8d be 00 ff          	lea    di,[bp-0x100]
    7328:	16                   	push   ss
    7329:	57                   	push   di
    732a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    732e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7333:	06                   	push   es
    7334:	57                   	push   di
    7335:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7338:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    733c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7341:	8d be 00 ff          	lea    di,[bp-0x100]
    7345:	16                   	push   ss
    7346:	57                   	push   di
    7347:	68 ff 00             	push   0xff
    734a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    734d:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    7352:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    7357:	55                   	push   bp
    7358:	9a 92 62 ba 73       	call   0x73ba:0x6292
    735d:	8d be fc fd          	lea    di,[bp-0x204]
    7361:	16                   	push   ss
    7362:	57                   	push   di
    7363:	8d be 00 ff          	lea    di,[bp-0x100]
    7367:	16                   	push   ss
    7368:	57                   	push   di
    7369:	9a cd 17 76 73       	call   0x7376:0x17cd
    736e:	bf 6a 66             	mov    di,0x666a
    7371:	0e                   	push   cs
    7372:	57                   	push   di
    7373:	9a 4c 18 90 73       	call   0x7390:0x184c
    7378:	8d be fc fc          	lea    di,[bp-0x304]
    737c:	16                   	push   ss
    737d:	57                   	push   di
    737e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7381:	26 c4 bd e0 03       	les    di,DWORD PTR es:[di+0x3e0]
    7386:	06                   	push   es
    7387:	57                   	push   di
    7388:	9a 53 1d 2a 74       	call   0x742a:0x1d53
    738d:	9a 4c 18 9e 73       	call   0x739e:0x184c
    7392:	8d be 00 ff          	lea    di,[bp-0x100]
    7396:	16                   	push   ss
    7397:	57                   	push   di
    7398:	68 ff 00             	push   0xff
    739b:	9a e7 17 0b 74       	call   0x740b:0x17e7
    73a0:	8d be 00 ff          	lea    di,[bp-0x100]
    73a4:	16                   	push   ss
    73a5:	57                   	push   di
    73a6:	68 ff 00             	push   0xff
    73a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73ac:	26 ff b5 e6 03       	push   WORD PTR es:[di+0x3e6]
    73b1:	26 ff b5 e4 03       	push   WORD PTR es:[di+0x3e4]
    73b6:	55                   	push   bp
    73b7:	9a 92 62 fa 73       	call   0x73fa:0x6292
    73bc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    73c1:	76 18                	jbe    0x73db
    73c3:	8d be 00 ff          	lea    di,[bp-0x100]
    73c7:	16                   	push   ss
    73c8:	57                   	push   di
    73c9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    73cd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    73d2:	06                   	push   es
    73d3:	57                   	push   di
    73d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    73d7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    73db:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    73e0:	8d be 00 ff          	lea    di,[bp-0x100]
    73e4:	16                   	push   ss
    73e5:	57                   	push   di
    73e6:	68 ff 00             	push   0xff
    73e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73ec:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    73f1:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    73f6:	55                   	push   bp
    73f7:	9a 92 62 59 74       	call   0x7459:0x6292
    73fc:	8d be fc fd          	lea    di,[bp-0x204]
    7400:	16                   	push   ss
    7401:	57                   	push   di
    7402:	8d be 00 ff          	lea    di,[bp-0x100]
    7406:	16                   	push   ss
    7407:	57                   	push   di
    7408:	9a cd 17 15 74       	call   0x7415:0x17cd
    740d:	bf 6a 66             	mov    di,0x666a
    7410:	0e                   	push   cs
    7411:	57                   	push   di
    7412:	9a 4c 18 2f 74       	call   0x742f:0x184c
    7417:	8d be fc fc          	lea    di,[bp-0x304]
    741b:	16                   	push   ss
    741c:	57                   	push   di
    741d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7420:	26 c4 bd f8 03       	les    di,DWORD PTR es:[di+0x3f8]
    7425:	06                   	push   es
    7426:	57                   	push   di
    7427:	9a 53 1d 76 78       	call   0x7876:0x1d53
    742c:	9a 4c 18 3d 74       	call   0x743d:0x184c
    7431:	8d be 00 ff          	lea    di,[bp-0x100]
    7435:	16                   	push   ss
    7436:	57                   	push   di
    7437:	68 ff 00             	push   0xff
    743a:	9a e7 17 c5 74       	call   0x74c5:0x17e7
    743f:	8d be 00 ff          	lea    di,[bp-0x100]
    7443:	16                   	push   ss
    7444:	57                   	push   di
    7445:	68 ff 00             	push   0xff
    7448:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    744b:	26 ff b5 fe 03       	push   WORD PTR es:[di+0x3fe]
    7450:	26 ff b5 fc 03       	push   WORD PTR es:[di+0x3fc]
    7455:	55                   	push   bp
    7456:	9a 92 62 99 74       	call   0x7499:0x6292
    745b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7460:	76 18                	jbe    0x747a
    7462:	8d be 00 ff          	lea    di,[bp-0x100]
    7466:	16                   	push   ss
    7467:	57                   	push   di
    7468:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    746c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7471:	06                   	push   es
    7472:	57                   	push   di
    7473:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7476:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    747a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    747f:	8d be 00 ff          	lea    di,[bp-0x100]
    7483:	16                   	push   ss
    7484:	57                   	push   di
    7485:	68 ff 00             	push   0xff
    7488:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    748b:	26 ff b5 ea 03       	push   WORD PTR es:[di+0x3ea]
    7490:	26 ff b5 e8 03       	push   WORD PTR es:[di+0x3e8]
    7495:	55                   	push   bp
    7496:	9a 92 62 b5 74       	call   0x74b5:0x6292
    749b:	8d be 00 ff          	lea    di,[bp-0x100]
    749f:	16                   	push   ss
    74a0:	57                   	push   di
    74a1:	68 ff 00             	push   0xff
    74a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74a7:	26 ff b5 f2 03       	push   WORD PTR es:[di+0x3f2]
    74ac:	26 ff b5 f0 03       	push   WORD PTR es:[di+0x3f0]
    74b1:	55                   	push   bp
    74b2:	9a 92 62 1e 75       	call   0x751e:0x6292
    74b7:	8d be fc fd          	lea    di,[bp-0x204]
    74bb:	16                   	push   ss
    74bc:	57                   	push   di
    74bd:	bf 68 66             	mov    di,0x6668
    74c0:	0e                   	push   cs
    74c1:	57                   	push   di
    74c2:	9a cd 17 d0 74       	call   0x74d0:0x17cd
    74c7:	8d be 00 ff          	lea    di,[bp-0x100]
    74cb:	16                   	push   ss
    74cc:	57                   	push   di
    74cd:	9a 4c 18 de 74       	call   0x74de:0x184c
    74d2:	8d be 00 ff          	lea    di,[bp-0x100]
    74d6:	16                   	push   ss
    74d7:	57                   	push   di
    74d8:	68 ff 00             	push   0xff
    74db:	9a e7 17 84 78       	call   0x7884:0x17e7
    74e0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    74e5:	76 18                	jbe    0x74ff
    74e7:	8d be 00 ff          	lea    di,[bp-0x100]
    74eb:	16                   	push   ss
    74ec:	57                   	push   di
    74ed:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    74f1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    74f6:	06                   	push   es
    74f7:	57                   	push   di
    74f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    74fb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    74ff:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7504:	8d be 00 ff          	lea    di,[bp-0x100]
    7508:	16                   	push   ss
    7509:	57                   	push   di
    750a:	68 ff 00             	push   0xff
    750d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7510:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    7515:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    751a:	55                   	push   bp
    751b:	9a 92 62 3a 75       	call   0x753a:0x6292
    7520:	8d be 00 ff          	lea    di,[bp-0x100]
    7524:	16                   	push   ss
    7525:	57                   	push   di
    7526:	68 ff 00             	push   0xff
    7529:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    752c:	26 ff b5 ee 03       	push   WORD PTR es:[di+0x3ee]
    7531:	26 ff b5 ec 03       	push   WORD PTR es:[di+0x3ec]
    7536:	55                   	push   bp
    7537:	9a 92 62 56 75       	call   0x7556:0x6292
    753c:	8d be 00 ff          	lea    di,[bp-0x100]
    7540:	16                   	push   ss
    7541:	57                   	push   di
    7542:	68 ff 00             	push   0xff
    7545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7548:	26 ff b5 f6 03       	push   WORD PTR es:[di+0x3f6]
    754d:	26 ff b5 f4 03       	push   WORD PTR es:[di+0x3f4]
    7552:	55                   	push   bp
    7553:	9a 92 62 96 75       	call   0x7596:0x6292
    7558:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    755d:	76 18                	jbe    0x7577
    755f:	8d be 00 ff          	lea    di,[bp-0x100]
    7563:	16                   	push   ss
    7564:	57                   	push   di
    7565:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7569:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    756e:	06                   	push   es
    756f:	57                   	push   di
    7570:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7573:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7577:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    757c:	8d be 00 ff          	lea    di,[bp-0x100]
    7580:	16                   	push   ss
    7581:	57                   	push   di
    7582:	68 ff 00             	push   0xff
    7585:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7588:	26 ff b5 d6 01       	push   WORD PTR es:[di+0x1d6]
    758d:	26 ff b5 d4 01       	push   WORD PTR es:[di+0x1d4]
    7592:	55                   	push   bp
    7593:	9a 92 62 d6 75       	call   0x75d6:0x6292
    7598:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    759d:	76 18                	jbe    0x75b7
    759f:	8d be 00 ff          	lea    di,[bp-0x100]
    75a3:	16                   	push   ss
    75a4:	57                   	push   di
    75a5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    75a9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    75ae:	06                   	push   es
    75af:	57                   	push   di
    75b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    75b3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    75b7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    75bc:	8d be 00 ff          	lea    di,[bp-0x100]
    75c0:	16                   	push   ss
    75c1:	57                   	push   di
    75c2:	68 ff 00             	push   0xff
    75c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75c8:	26 ff b5 02 04       	push   WORD PTR es:[di+0x402]
    75cd:	26 ff b5 00 04       	push   WORD PTR es:[di+0x400]
    75d2:	55                   	push   bp
    75d3:	9a 92 62 f2 75       	call   0x75f2:0x6292
    75d8:	8d be 00 ff          	lea    di,[bp-0x100]
    75dc:	16                   	push   ss
    75dd:	57                   	push   di
    75de:	68 ff 00             	push   0xff
    75e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75e4:	26 ff b5 32 02       	push   WORD PTR es:[di+0x232]
    75e9:	26 ff b5 30 02       	push   WORD PTR es:[di+0x230]
    75ee:	55                   	push   bp
    75ef:	9a 92 62 0e 76       	call   0x760e:0x6292
    75f4:	8d be 00 ff          	lea    di,[bp-0x100]
    75f8:	16                   	push   ss
    75f9:	57                   	push   di
    75fa:	68 ff 00             	push   0xff
    75fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7600:	26 ff b5 4a 02       	push   WORD PTR es:[di+0x24a]
    7605:	26 ff b5 48 02       	push   WORD PTR es:[di+0x248]
    760a:	55                   	push   bp
    760b:	9a 92 62 4e 76       	call   0x764e:0x6292
    7610:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7615:	76 18                	jbe    0x762f
    7617:	8d be 00 ff          	lea    di,[bp-0x100]
    761b:	16                   	push   ss
    761c:	57                   	push   di
    761d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7621:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7626:	06                   	push   es
    7627:	57                   	push   di
    7628:	26 c4 3d             	les    di,DWORD PTR es:[di]
    762b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    762f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7634:	8d be 00 ff          	lea    di,[bp-0x100]
    7638:	16                   	push   ss
    7639:	57                   	push   di
    763a:	68 ff 00             	push   0xff
    763d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7640:	26 ff b5 06 04       	push   WORD PTR es:[di+0x406]
    7645:	26 ff b5 04 04       	push   WORD PTR es:[di+0x404]
    764a:	55                   	push   bp
    764b:	9a 92 62 6a 76       	call   0x766a:0x6292
    7650:	8d be 00 ff          	lea    di,[bp-0x100]
    7654:	16                   	push   ss
    7655:	57                   	push   di
    7656:	68 ff 00             	push   0xff
    7659:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    765c:	26 ff b5 36 02       	push   WORD PTR es:[di+0x236]
    7661:	26 ff b5 34 02       	push   WORD PTR es:[di+0x234]
    7666:	55                   	push   bp
    7667:	9a 92 62 86 76       	call   0x7686:0x6292
    766c:	8d be 00 ff          	lea    di,[bp-0x100]
    7670:	16                   	push   ss
    7671:	57                   	push   di
    7672:	68 ff 00             	push   0xff
    7675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7678:	26 ff b5 4e 02       	push   WORD PTR es:[di+0x24e]
    767d:	26 ff b5 4c 02       	push   WORD PTR es:[di+0x24c]
    7682:	55                   	push   bp
    7683:	9a 92 62 c6 76       	call   0x76c6:0x6292
    7688:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    768d:	76 18                	jbe    0x76a7
    768f:	8d be 00 ff          	lea    di,[bp-0x100]
    7693:	16                   	push   ss
    7694:	57                   	push   di
    7695:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7699:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    769e:	06                   	push   es
    769f:	57                   	push   di
    76a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    76a3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    76a7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    76ac:	8d be 00 ff          	lea    di,[bp-0x100]
    76b0:	16                   	push   ss
    76b1:	57                   	push   di
    76b2:	68 ff 00             	push   0xff
    76b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76b8:	26 ff b5 0a 04       	push   WORD PTR es:[di+0x40a]
    76bd:	26 ff b5 08 04       	push   WORD PTR es:[di+0x408]
    76c2:	55                   	push   bp
    76c3:	9a 92 62 e2 76       	call   0x76e2:0x6292
    76c8:	8d be 00 ff          	lea    di,[bp-0x100]
    76cc:	16                   	push   ss
    76cd:	57                   	push   di
    76ce:	68 ff 00             	push   0xff
    76d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76d4:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    76d9:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    76de:	55                   	push   bp
    76df:	9a 92 62 fe 76       	call   0x76fe:0x6292
    76e4:	8d be 00 ff          	lea    di,[bp-0x100]
    76e8:	16                   	push   ss
    76e9:	57                   	push   di
    76ea:	68 ff 00             	push   0xff
    76ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76f0:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    76f5:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    76fa:	55                   	push   bp
    76fb:	9a 92 62 3e 77       	call   0x773e:0x6292
    7700:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7705:	76 18                	jbe    0x771f
    7707:	8d be 00 ff          	lea    di,[bp-0x100]
    770b:	16                   	push   ss
    770c:	57                   	push   di
    770d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7711:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7716:	06                   	push   es
    7717:	57                   	push   di
    7718:	26 c4 3d             	les    di,DWORD PTR es:[di]
    771b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    771f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7724:	8d be 00 ff          	lea    di,[bp-0x100]
    7728:	16                   	push   ss
    7729:	57                   	push   di
    772a:	68 ff 00             	push   0xff
    772d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7730:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    7735:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    773a:	55                   	push   bp
    773b:	9a 92 62 5a 77       	call   0x775a:0x6292
    7740:	8d be 00 ff          	lea    di,[bp-0x100]
    7744:	16                   	push   ss
    7745:	57                   	push   di
    7746:	68 ff 00             	push   0xff
    7749:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    774c:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    7751:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    7756:	55                   	push   bp
    7757:	9a 92 62 76 77       	call   0x7776:0x6292
    775c:	8d be 00 ff          	lea    di,[bp-0x100]
    7760:	16                   	push   ss
    7761:	57                   	push   di
    7762:	68 ff 00             	push   0xff
    7765:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7768:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    776d:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    7772:	55                   	push   bp
    7773:	9a 92 62 b6 77       	call   0x77b6:0x6292
    7778:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    777d:	76 18                	jbe    0x7797
    777f:	8d be 00 ff          	lea    di,[bp-0x100]
    7783:	16                   	push   ss
    7784:	57                   	push   di
    7785:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7789:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    778e:	06                   	push   es
    778f:	57                   	push   di
    7790:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7793:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7797:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    779c:	8d be 00 ff          	lea    di,[bp-0x100]
    77a0:	16                   	push   ss
    77a1:	57                   	push   di
    77a2:	68 ff 00             	push   0xff
    77a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77a8:	26 ff b5 12 04       	push   WORD PTR es:[di+0x412]
    77ad:	26 ff b5 10 04       	push   WORD PTR es:[di+0x410]
    77b2:	55                   	push   bp
    77b3:	9a 92 62 d2 77       	call   0x77d2:0x6292
    77b8:	8d be 00 ff          	lea    di,[bp-0x100]
    77bc:	16                   	push   ss
    77bd:	57                   	push   di
    77be:	68 ff 00             	push   0xff
    77c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c4:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    77c9:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    77ce:	55                   	push   bp
    77cf:	9a 92 62 ee 77       	call   0x77ee:0x6292
    77d4:	8d be 00 ff          	lea    di,[bp-0x100]
    77d8:	16                   	push   ss
    77d9:	57                   	push   di
    77da:	68 ff 00             	push   0xff
    77dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77e0:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    77e5:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    77ea:	55                   	push   bp
    77eb:	9a 92 62 2e 78       	call   0x782e:0x6292
    77f0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    77f5:	76 18                	jbe    0x780f
    77f7:	8d be 00 ff          	lea    di,[bp-0x100]
    77fb:	16                   	push   ss
    77fc:	57                   	push   di
    77fd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7801:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7806:	06                   	push   es
    7807:	57                   	push   di
    7808:	26 c4 3d             	les    di,DWORD PTR es:[di]
    780b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    780f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7814:	8d be 00 ff          	lea    di,[bp-0x100]
    7818:	16                   	push   ss
    7819:	57                   	push   di
    781a:	68 ff 00             	push   0xff
    781d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7820:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    7825:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    782a:	55                   	push   bp
    782b:	9a 92 62 a0 78       	call   0x78a0:0x6292
    7830:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7835:	76 18                	jbe    0x784f
    7837:	8d be 00 ff          	lea    di,[bp-0x100]
    783b:	16                   	push   ss
    783c:	57                   	push   di
    783d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7841:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7846:	06                   	push   es
    7847:	57                   	push   di
    7848:	26 c4 3d             	les    di,DWORD PTR es:[di]
    784b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    784f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7857:	26 c4 bd 18 04       	les    di,DWORD PTR es:[di+0x418]
    785c:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    7861:	74 23                	je     0x7886
    7863:	8d be fc fd          	lea    di,[bp-0x204]
    7867:	16                   	push   ss
    7868:	57                   	push   di
    7869:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    786c:	26 c4 bd 18 04       	les    di,DWORD PTR es:[di+0x418]
    7871:	06                   	push   es
    7872:	57                   	push   di
    7873:	9a 53 1d e5 7b       	call   0x7be5:0x1d53
    7878:	8d be 00 ff          	lea    di,[bp-0x100]
    787c:	16                   	push   ss
    787d:	57                   	push   di
    787e:	68 ff 00             	push   0xff
    7881:	9a e7 17 a4 7b       	call   0x7ba4:0x17e7
    7886:	8d be 00 ff          	lea    di,[bp-0x100]
    788a:	16                   	push   ss
    788b:	57                   	push   di
    788c:	68 ff 00             	push   0xff
    788f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7892:	26 ff b5 1a 04       	push   WORD PTR es:[di+0x41a]
    7897:	26 ff b5 18 04       	push   WORD PTR es:[di+0x418]
    789c:	55                   	push   bp
    789d:	9a 92 62 e0 78       	call   0x78e0:0x6292
    78a2:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    78a7:	76 18                	jbe    0x78c1
    78a9:	8d be 00 ff          	lea    di,[bp-0x100]
    78ad:	16                   	push   ss
    78ae:	57                   	push   di
    78af:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    78b3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    78b8:	06                   	push   es
    78b9:	57                   	push   di
    78ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    78bd:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    78c1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    78c6:	8d be 00 ff          	lea    di,[bp-0x100]
    78ca:	16                   	push   ss
    78cb:	57                   	push   di
    78cc:	68 ff 00             	push   0xff
    78cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78d2:	26 ff b5 1e 04       	push   WORD PTR es:[di+0x41e]
    78d7:	26 ff b5 1c 04       	push   WORD PTR es:[di+0x41c]
    78dc:	55                   	push   bp
    78dd:	9a 92 62 fc 78       	call   0x78fc:0x6292
    78e2:	8d be 00 ff          	lea    di,[bp-0x100]
    78e6:	16                   	push   ss
    78e7:	57                   	push   di
    78e8:	68 ff 00             	push   0xff
    78eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78ee:	26 ff b5 22 04       	push   WORD PTR es:[di+0x422]
    78f3:	26 ff b5 20 04       	push   WORD PTR es:[di+0x420]
    78f8:	55                   	push   bp
    78f9:	9a 92 62 3c 79       	call   0x793c:0x6292
    78fe:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7903:	76 18                	jbe    0x791d
    7905:	8d be 00 ff          	lea    di,[bp-0x100]
    7909:	16                   	push   ss
    790a:	57                   	push   di
    790b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    790f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7914:	06                   	push   es
    7915:	57                   	push   di
    7916:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7919:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    791d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7922:	8d be 00 ff          	lea    di,[bp-0x100]
    7926:	16                   	push   ss
    7927:	57                   	push   di
    7928:	68 ff 00             	push   0xff
    792b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    792e:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    7933:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    7938:	55                   	push   bp
    7939:	9a 92 62 58 79       	call   0x7958:0x6292
    793e:	8d be 00 ff          	lea    di,[bp-0x100]
    7942:	16                   	push   ss
    7943:	57                   	push   di
    7944:	68 ff 00             	push   0xff
    7947:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    794a:	26 ff b5 5e 02       	push   WORD PTR es:[di+0x25e]
    794f:	26 ff b5 5c 02       	push   WORD PTR es:[di+0x25c]
    7954:	55                   	push   bp
    7955:	9a 92 62 74 79       	call   0x7974:0x6292
    795a:	8d be 00 ff          	lea    di,[bp-0x100]
    795e:	16                   	push   ss
    795f:	57                   	push   di
    7960:	68 ff 00             	push   0xff
    7963:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7966:	26 ff b5 6e 02       	push   WORD PTR es:[di+0x26e]
    796b:	26 ff b5 6c 02       	push   WORD PTR es:[di+0x26c]
    7970:	55                   	push   bp
    7971:	9a 92 62 b4 79       	call   0x79b4:0x6292
    7976:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    797b:	76 18                	jbe    0x7995
    797d:	8d be 00 ff          	lea    di,[bp-0x100]
    7981:	16                   	push   ss
    7982:	57                   	push   di
    7983:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7987:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    798c:	06                   	push   es
    798d:	57                   	push   di
    798e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7991:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7995:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    799a:	8d be 00 ff          	lea    di,[bp-0x100]
    799e:	16                   	push   ss
    799f:	57                   	push   di
    79a0:	68 ff 00             	push   0xff
    79a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79a6:	26 ff b5 26 04       	push   WORD PTR es:[di+0x426]
    79ab:	26 ff b5 24 04       	push   WORD PTR es:[di+0x424]
    79b0:	55                   	push   bp
    79b1:	9a 92 62 d0 79       	call   0x79d0:0x6292
    79b6:	8d be 00 ff          	lea    di,[bp-0x100]
    79ba:	16                   	push   ss
    79bb:	57                   	push   di
    79bc:	68 ff 00             	push   0xff
    79bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79c2:	26 ff b5 62 02       	push   WORD PTR es:[di+0x262]
    79c7:	26 ff b5 60 02       	push   WORD PTR es:[di+0x260]
    79cc:	55                   	push   bp
    79cd:	9a 92 62 ec 79       	call   0x79ec:0x6292
    79d2:	8d be 00 ff          	lea    di,[bp-0x100]
    79d6:	16                   	push   ss
    79d7:	57                   	push   di
    79d8:	68 ff 00             	push   0xff
    79db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79de:	26 ff b5 72 02       	push   WORD PTR es:[di+0x272]
    79e3:	26 ff b5 70 02       	push   WORD PTR es:[di+0x270]
    79e8:	55                   	push   bp
    79e9:	9a 92 62 2c 7a       	call   0x7a2c:0x6292
    79ee:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    79f3:	76 18                	jbe    0x7a0d
    79f5:	8d be 00 ff          	lea    di,[bp-0x100]
    79f9:	16                   	push   ss
    79fa:	57                   	push   di
    79fb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    79ff:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7a04:	06                   	push   es
    7a05:	57                   	push   di
    7a06:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a09:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7a0d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7a12:	8d be 00 ff          	lea    di,[bp-0x100]
    7a16:	16                   	push   ss
    7a17:	57                   	push   di
    7a18:	68 ff 00             	push   0xff
    7a1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a1e:	26 ff b5 2a 04       	push   WORD PTR es:[di+0x42a]
    7a23:	26 ff b5 28 04       	push   WORD PTR es:[di+0x428]
    7a28:	55                   	push   bp
    7a29:	9a 92 62 48 7a       	call   0x7a48:0x6292
    7a2e:	8d be 00 ff          	lea    di,[bp-0x100]
    7a32:	16                   	push   ss
    7a33:	57                   	push   di
    7a34:	68 ff 00             	push   0xff
    7a37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a3a:	26 ff b5 66 02       	push   WORD PTR es:[di+0x266]
    7a3f:	26 ff b5 64 02       	push   WORD PTR es:[di+0x264]
    7a44:	55                   	push   bp
    7a45:	9a 92 62 64 7a       	call   0x7a64:0x6292
    7a4a:	8d be 00 ff          	lea    di,[bp-0x100]
    7a4e:	16                   	push   ss
    7a4f:	57                   	push   di
    7a50:	68 ff 00             	push   0xff
    7a53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a56:	26 ff b5 76 02       	push   WORD PTR es:[di+0x276]
    7a5b:	26 ff b5 74 02       	push   WORD PTR es:[di+0x274]
    7a60:	55                   	push   bp
    7a61:	9a 92 62 a4 7a       	call   0x7aa4:0x6292
    7a66:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7a6b:	76 18                	jbe    0x7a85
    7a6d:	8d be 00 ff          	lea    di,[bp-0x100]
    7a71:	16                   	push   ss
    7a72:	57                   	push   di
    7a73:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7a77:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7a7c:	06                   	push   es
    7a7d:	57                   	push   di
    7a7e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a81:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7a85:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7a8a:	8d be 00 ff          	lea    di,[bp-0x100]
    7a8e:	16                   	push   ss
    7a8f:	57                   	push   di
    7a90:	68 ff 00             	push   0xff
    7a93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a96:	26 ff b5 a6 02       	push   WORD PTR es:[di+0x2a6]
    7a9b:	26 ff b5 a4 02       	push   WORD PTR es:[di+0x2a4]
    7aa0:	55                   	push   bp
    7aa1:	9a 92 62 dd 7a       	call   0x7add:0x6292
    7aa6:	8d be 00 ff          	lea    di,[bp-0x100]
    7aaa:	16                   	push   ss
    7aab:	57                   	push   di
    7aac:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7ab0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7ab5:	06                   	push   es
    7ab6:	57                   	push   di
    7ab7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7aba:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7abe:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7ac3:	8d be 00 ff          	lea    di,[bp-0x100]
    7ac7:	16                   	push   ss
    7ac8:	57                   	push   di
    7ac9:	68 ff 00             	push   0xff
    7acc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7acf:	26 ff b5 2e 04       	push   WORD PTR es:[di+0x42e]
    7ad4:	26 ff b5 2c 04       	push   WORD PTR es:[di+0x42c]
    7ad9:	55                   	push   bp
    7ada:	9a 92 62 f9 7a       	call   0x7af9:0x6292
    7adf:	8d be 00 ff          	lea    di,[bp-0x100]
    7ae3:	16                   	push   ss
    7ae4:	57                   	push   di
    7ae5:	68 ff 00             	push   0xff
    7ae8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7aeb:	26 ff b5 aa 02       	push   WORD PTR es:[di+0x2aa]
    7af0:	26 ff b5 a8 02       	push   WORD PTR es:[di+0x2a8]
    7af5:	55                   	push   bp
    7af6:	9a 92 62 39 7b       	call   0x7b39:0x6292
    7afb:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7b00:	76 18                	jbe    0x7b1a
    7b02:	8d be 00 ff          	lea    di,[bp-0x100]
    7b06:	16                   	push   ss
    7b07:	57                   	push   di
    7b08:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b0c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7b11:	06                   	push   es
    7b12:	57                   	push   di
    7b13:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b16:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7b1a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7b1f:	8d be 00 ff          	lea    di,[bp-0x100]
    7b23:	16                   	push   ss
    7b24:	57                   	push   di
    7b25:	68 ff 00             	push   0xff
    7b28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b2b:	26 ff b5 32 04       	push   WORD PTR es:[di+0x432]
    7b30:	26 ff b5 30 04       	push   WORD PTR es:[di+0x430]
    7b35:	55                   	push   bp
    7b36:	9a 92 62 55 7b       	call   0x7b55:0x6292
    7b3b:	8d be 00 ff          	lea    di,[bp-0x100]
    7b3f:	16                   	push   ss
    7b40:	57                   	push   di
    7b41:	68 ff 00             	push   0xff
    7b44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b47:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    7b4c:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    7b51:	55                   	push   bp
    7b52:	9a 92 62 fc 7d       	call   0x7dfc:0x6292
    7b57:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7b5c:	76 18                	jbe    0x7b76
    7b5e:	8d be 00 ff          	lea    di,[bp-0x100]
    7b62:	16                   	push   ss
    7b63:	57                   	push   di
    7b64:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b68:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7b6d:	06                   	push   es
    7b6e:	57                   	push   di
    7b6f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b72:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7b76:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b7a:	06                   	push   es
    7b7b:	57                   	push   di
    7b7c:	9a 3f 4a 8a 7b       	call   0x7b8a:0x4a3f
    7b81:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b85:	06                   	push   es
    7b86:	57                   	push   di
    7b87:	9a ff 49 95 7b       	call   0x7b95:0x49ff
    7b8c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b90:	06                   	push   es
    7b91:	57                   	push   di
    7b92:	9a e3 49 ff ff       	call   0xffff:0x49e3
    7b97:	c9                   	leave
    7b98:	ca 08 00             	retf   0x8
    7b9b:	55                   	push   bp
    7b9c:	89 e5                	mov    bp,sp
    7b9e:	b8 08 00             	mov    ax,0x8
    7ba1:	9a 44 04 ba 7b       	call   0x7bba:0x444
    7ba6:	83 ec 08             	sub    sp,0x8
    7ba9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7bac:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7baf:	bf ac 04             	mov    di,0x4ac
    7bb2:	b8 ff ff             	mov    ax,0xffff
    7bb5:	50                   	push   ax
    7bb6:	57                   	push   di
    7bb7:	9a 73 22 1d 7c       	call   0x7c1d:0x2273
    7bbc:	89 c7                	mov    di,ax
    7bbe:	8e c2                	mov    es,dx
    7bc0:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7bc4:	99                   	cwd
    7bc5:	b9 02 00             	mov    cx,0x2
    7bc8:	f7 f9                	idiv   cx
    7bca:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7bcd:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7bd1:	99                   	cwd
    7bd2:	b9 02 00             	mov    cx,0x2
    7bd5:	f7 f9                	idiv   cx
    7bd7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7bda:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7bdd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7be0:	06                   	push   es
    7be1:	57                   	push   di
    7be2:	9a d4 19 37 7c       	call   0x7c37:0x19d4
    7be7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7bea:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7bed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bf0:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    7bf5:	26 c6 45 25 00       	mov    BYTE PTR es:[di+0x25],0x0
    7bfa:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7bfd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7c00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c03:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    7c08:	06                   	push   es
    7c09:	57                   	push   di
    7c0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7c0d:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    7c11:	c9                   	leave
    7c12:	ca 08 00             	retf   0x8
    7c15:	55                   	push   bp
    7c16:	89 e5                	mov    bp,sp
    7c18:	31 c0                	xor    ax,ax
    7c1a:	9a 44 04 61 7c       	call   0x7c61:0x444
    7c1f:	9a c6 34 ff ff       	call   0xffff:0x34c6
    7c24:	08 c0                	or     al,al
    7c26:	74 2c                	je     0x7c54
    7c28:	6a 00                	push   0x0
    7c2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c2d:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    7c32:	06                   	push   es
    7c33:	57                   	push   di
    7c34:	9a 77 1c 52 7c       	call   0x7c52:0x1c77
    7c39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c3c:	06                   	push   es
    7c3d:	57                   	push   di
    7c3e:	9a 2d 5a 53 7d       	call   0x7d53:0x5a2d
    7c43:	6a 01                	push   0x1
    7c45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c48:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    7c4d:	06                   	push   es
    7c4e:	57                   	push   di
    7c4f:	9a 77 1c 75 7c       	call   0x7c75:0x1c77
    7c54:	c9                   	leave
    7c55:	ca 08 00             	retf   0x8
    7c58:	55                   	push   bp
    7c59:	89 e5                	mov    bp,sp
    7c5b:	b8 14 00             	mov    ax,0x14
    7c5e:	9a 44 04 cc 7c       	call   0x7ccc:0x444
    7c63:	83 ec 14             	sub    sp,0x14
    7c66:	6a 00                	push   0x0
    7c68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c6b:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    7c70:	06                   	push   es
    7c71:	57                   	push   di
    7c72:	9a 77 1c 88 7c       	call   0x7c88:0x1c77
    7c77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c7a:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    7c7e:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7c83:	06                   	push   es
    7c84:	57                   	push   di
    7c85:	9a bf 17 9b 7c       	call   0x7c9b:0x17bf
    7c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c8d:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    7c91:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7c96:	06                   	push   es
    7c97:	57                   	push   di
    7c98:	9a e1 17 b5 7c       	call   0x7cb5:0x17e1
    7c9d:	31 c0                	xor    ax,ax
    7c9f:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    7ca2:	31 c0                	xor    ax,ax
    7ca4:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    7ca7:	ff 76 ee             	push   WORD PTR [bp-0x12]
    7caa:	ff 76 ec             	push   WORD PTR [bp-0x14]
    7cad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cb0:	06                   	push   es
    7cb1:	57                   	push   di
    7cb2:	9a d4 19 44 7d       	call   0x7d44:0x19d4
    7cb7:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    7cba:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    7cbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cc0:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    7cc4:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    7cc7:	71 05                	jno    0x7cce
    7cc9:	9a 3e 04 e0 7c       	call   0x7ce0:0x43e
    7cce:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    7cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cd4:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    7cd8:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    7cdb:	71 05                	jno    0x7ce2
    7cdd:	9a 3e 04 f4 7c       	call   0x7cf4:0x43e
    7ce2:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    7ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ce8:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7cec:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    7cef:	71 05                	jno    0x7cf6
    7cf1:	9a 3e 04 08 7d       	call   0x7d08:0x43e
    7cf6:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    7cf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cfc:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7d00:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    7d03:	71 05                	jno    0x7d0a
    7d05:	9a 3e 04 b2 7d       	call   0x7db2:0x43e
    7d0a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    7d0d:	31 c0                	xor    ax,ax
    7d0f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7d12:	31 c0                	xor    ax,ax
    7d14:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7d17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d1a:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7d1f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7d23:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7d26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d29:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7d2e:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7d32:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7d35:	6a 00                	push   0x0
    7d37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d3a:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7d3f:	06                   	push   es
    7d40:	57                   	push   di
    7d41:	9a 77 1c a4 7d       	call   0x7da4:0x1c77
    7d46:	8d 7e f8             	lea    di,[bp-0x8]
    7d49:	16                   	push   ss
    7d4a:	57                   	push   di
    7d4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d4e:	06                   	push   es
    7d4f:	57                   	push   di
    7d50:	9a d5 33 ff ff       	call   0xffff:0x33d5
    7d55:	52                   	push   dx
    7d56:	50                   	push   ax
    7d57:	8d 7e f0             	lea    di,[bp-0x10]
    7d5a:	16                   	push   ss
    7d5b:	57                   	push   di
    7d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d5f:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7d64:	06                   	push   es
    7d65:	57                   	push   di
    7d66:	9a 94 1f ff ff       	call   0xffff:0x1f94
    7d6b:	89 c7                	mov    di,ax
    7d6d:	8e c2                	mov    es,dx
    7d6f:	06                   	push   es
    7d70:	57                   	push   di
    7d71:	9a 10 1b ff ff       	call   0xffff:0x1b10
    7d76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d79:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    7d7e:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    7d83:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    7d88:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    7d8c:	06                   	push   es
    7d8d:	57                   	push   di
    7d8e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7d91:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    7d95:	6a 01                	push   0x1
    7d97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d9a:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    7d9f:	06                   	push   es
    7da0:	57                   	push   di
    7da1:	9a 77 1c cf 7d       	call   0x7dcf:0x1c77
    7da6:	c9                   	leave
    7da7:	ca 08 00             	retf   0x8
    7daa:	55                   	push   bp
    7dab:	89 e5                	mov    bp,sp
    7dad:	31 c0                	xor    ax,ax
    7daf:	9a 44 04 0a 7e       	call   0x7e0a:0x444
    7db4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7db7:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    7dbc:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7dc1:	50                   	push   ax
    7dc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dc5:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    7dca:	06                   	push   es
    7dcb:	57                   	push   di
    7dcc:	9a 77 1c ec 7d       	call   0x7dec:0x1c77
    7dd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dd4:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    7dd9:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7dde:	50                   	push   ax
    7ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7de2:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    7de7:	06                   	push   es
    7de8:	57                   	push   di
    7de9:	9a 77 1c 27 7e       	call   0x7e27:0x1c77
    7dee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7df1:	26 c6 85 91 04 01    	mov    BYTE PTR es:[di+0x491],0x1
    7df7:	06                   	push   es
    7df8:	57                   	push   di
    7df9:	9a f5 3e 54 7e       	call   0x7e54:0x3ef5
    7dfe:	c9                   	leave
    7dff:	ca 08 00             	retf   0x8
    7e02:	55                   	push   bp
    7e03:	89 e5                	mov    bp,sp
    7e05:	31 c0                	xor    ax,ax
    7e07:	9a 44 04 62 7e       	call   0x7e62:0x444
    7e0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e0f:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    7e14:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7e19:	50                   	push   ax
    7e1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e1d:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    7e22:	06                   	push   es
    7e23:	57                   	push   di
    7e24:	9a 77 1c 44 7e       	call   0x7e44:0x1c77
    7e29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e2c:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    7e31:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7e36:	50                   	push   ax
    7e37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e3a:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    7e3f:	06                   	push   es
    7e40:	57                   	push   di
    7e41:	9a 77 1c 7f 7e       	call   0x7e7f:0x1c77
    7e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e49:	26 c6 85 91 04 01    	mov    BYTE PTR es:[di+0x491],0x1
    7e4f:	06                   	push   es
    7e50:	57                   	push   di
    7e51:	9a f5 3e ac 7e       	call   0x7eac:0x3ef5
    7e56:	c9                   	leave
    7e57:	ca 08 00             	retf   0x8
    7e5a:	55                   	push   bp
    7e5b:	89 e5                	mov    bp,sp
    7e5d:	31 c0                	xor    ax,ax
    7e5f:	9a 44 04 ba 7e       	call   0x7eba:0x444
    7e64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e67:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    7e6c:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7e71:	50                   	push   ax
    7e72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e75:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    7e7a:	06                   	push   es
    7e7b:	57                   	push   di
    7e7c:	9a 77 1c 9c 7e       	call   0x7e9c:0x1c77
    7e81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e84:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
    7e89:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7e8e:	50                   	push   ax
    7e8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e92:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    7e97:	06                   	push   es
    7e98:	57                   	push   di
    7e99:	9a 77 1c ff ff       	call   0xffff:0x1c77
    7e9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ea1:	26 c6 85 91 04 01    	mov    BYTE PTR es:[di+0x491],0x1
    7ea7:	06                   	push   es
    7ea8:	57                   	push   di
    7ea9:	9a f5 3e ca 7e       	call   0x7eca:0x3ef5
    7eae:	c9                   	leave
    7eaf:	ca 08 00             	retf   0x8
    7eb2:	55                   	push   bp
    7eb3:	89 e5                	mov    bp,sp
    7eb5:	31 c0                	xor    ax,ax
    7eb7:	9a 44 04 ff ff       	call   0xffff:0x444
    7ebc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ebf:	26 c6 85 91 04 01    	mov    BYTE PTR es:[di+0x491],0x1
    7ec5:	06                   	push   es
    7ec6:	57                   	push   di
    7ec7:	9a f5 3e ff ff       	call   0xffff:0x3ef5
    7ecc:	c9                   	leave
    7ecd:	ca                   	.byte 0xca
    7ece:	08                   	.byte 0x8
