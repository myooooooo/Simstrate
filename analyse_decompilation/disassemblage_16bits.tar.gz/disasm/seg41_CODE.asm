; ================================================================
; seg41_CODE  (33044 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	29 00                	sub    WORD PTR [bx+si],ax
       2:	03 0e 54 53          	add    cx,WORD PTR ds:0x5354
       6:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
       9:	6c                   	ins    BYTE PTR es:[di],dx
       a:	6c                   	ins    BYTE PTR es:[di],dx
       b:	42                   	inc    dx
       c:	61                   	popa
       d:	72 4b                	jb     0x5a
       f:	69 6e 64 00 00       	imul   bp,WORD PTR [bp+0x64],0x0
      14:	00 00                	add    BYTE PTR [bx+si],al
      16:	00 01                	add    BYTE PTR [bx+di],al
      18:	00 00                	add    BYTE PTR [bx+si],al
      1a:	00 02                	add    BYTE PTR [bp+si],al
      1c:	00 79 00             	add    BYTE PTR [bx+di+0x0],bh
      1f:	0c 73                	or     al,0x73
      21:	62 48 6f             	bound  cx,DWORD PTR [bx+si+0x6f]
      24:	72 69                	jb     0x8f
      26:	7a 6f                	jp     0x97
      28:	6e                   	outs   dx,BYTE PTR ds:[si]
      29:	74 61                	je     0x8c
      2b:	6c                   	ins    BYTE PTR es:[di],dx
      2c:	0a 73 62             	or     dh,BYTE PTR [bp+di+0x62]
      2f:	56                   	push   si
      30:	65 72 74             	gs jb  0xa7
      33:	69 63 61 6c 01       	imul   sp,WORD PTR [bp+di+0x61],0x16c
      38:	0d 54 53             	or     ax,0x5354
      3b:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
      3e:	6c                   	ins    BYTE PTR es:[di],dx
      3f:	6c                   	ins    BYTE PTR es:[di],dx
      40:	42                   	inc    dx
      41:	61                   	popa
      42:	72 49                	jb     0x8d
      44:	6e                   	outs   dx,BYTE PTR ds:[si]
      45:	63 02                	arpl   WORD PTR [bp+si],ax
      47:	01 00                	add    WORD PTR [bx+si],ax
      49:	00 00                	add    BYTE PTR [bx+si],al
      4b:	ff                   	(bad)
      4c:	7f 00                	jg     0x4e
      4e:	00 8d 00 00          	add    BYTE PTR [di+0x0],cl
      52:	00 00                	add    BYTE PTR [bx+si],al
      54:	00 00                	add    BYTE PTR [bx+si],al
      56:	00 7b 00             	add    BYTE PTR [bp+di+0x0],bh
      59:	15 00 d1             	adc    ax,0xd100
      5c:	02 a6 00 64          	add    ah,BYTE PTR [bp+0x6400]
      60:	20 b4 00 9a          	and    BYTE PTR [si-0x6600],dh
      64:	1f                   	pop    ds
      65:	61                   	popa
      66:	00 cb                	add    bl,cl
      68:	1f                   	pop    ds
      69:	65 00 66 1f          	add    BYTE PTR gs:[bp+0x1f],ah
      6d:	69 00 cd 11          	imul   ax,WORD PTR [bx+si],0x11cd
      71:	75 00                	jne    0x73
      73:	e4 11                	in     al,0x11
      75:	5d                   	pop    bp
      76:	00 d3                	add    bl,dl
      78:	18 a2 00 11          	sbb    BYTE PTR [bp+si+0x1100],ah
      7c:	54                   	push   sp
      7d:	43                   	inc    bx
      7e:	6f                   	outs   dx,WORD PTR ds:[si]
      7f:	6e                   	outs   dx,BYTE PTR ds:[si]
      80:	74 72                	je     0xf4
      82:	6f                   	outs   dx,WORD PTR ds:[si]
      83:	6c                   	ins    BYTE PTR es:[di],dx
      84:	53                   	push   bx
      85:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
      88:	6c                   	ins    BYTE PTR es:[di],dx
      89:	6c                   	ins    BYTE PTR es:[di],dx
      8a:	42                   	inc    dx
      8b:	61                   	popa
      8c:	72 07                	jb     0x95
      8e:	11 54 43             	adc    WORD PTR [si+0x43],dx
      91:	6f                   	outs   dx,WORD PTR ds:[si]
      92:	6e                   	outs   dx,BYTE PTR ds:[si]
      93:	74 72                	je     0x107
      95:	6f                   	outs   dx,WORD PTR ds:[si]
      96:	6c                   	ins    BYTE PTR es:[di],dx
      97:	53                   	push   bx
      98:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
      9b:	6c                   	ins    BYTE PTR es:[di],dx
      9c:	6c                   	ins    BYTE PTR es:[di],dx
      9d:	42                   	inc    dx
      9e:	61                   	popa
      9f:	72 6f                	jb     0x110
      a1:	00 d3                	add    bl,dl
      a3:	00 e9                	add    cl,ch
      a5:	02 84 01 05          	add    al,BYTE PTR [si+0x501]
      a9:	00 05                	add    BYTE PTR [di],al
      ab:	46                   	inc    si
      ac:	6f                   	outs   dx,WORD PTR ds:[si]
      ad:	72 6d                	jb     0x11c
      af:	73 05                	jae    0xb6
      b1:	00 e6                	add    dh,ah
      b3:	22 f5                	and    dh,ch
      b5:	00 11                	add    BYTE PTR [bx+di],dl
      b7:	00 ff                	add    bh,bh
      b9:	ff 11                	call   WORD PTR [bx+di]
      bb:	00 ff                	add    bh,bh
      bd:	ff 01                	inc    WORD PTR [bx+di]
      bf:	00 00                	add    BYTE PTR [bx+si],al
      c1:	00 00                	add    BYTE PTR [bx+si],al
      c3:	80 00 00             	add    BYTE PTR [bx+si],0x0
      c6:	00 00                	add    BYTE PTR [bx+si],al
      c8:	00 00                	add    BYTE PTR [bx+si],al
      ca:	06                   	push   es
      cb:	4d                   	dec    bp
      cc:	61                   	popa
      cd:	72 67                	jb     0x136
      cf:	69 6e 37 00 fd       	imul   bp,WORD PTR [bp+0x37],0xfd00
      d4:	00 08                	add    BYTE PTR [bx+si],cl
      d6:	00 ff                	add    bh,bh
      d8:	ff 08                	dec    WORD PTR [bx+si]
      da:	00 ff                	add    bh,bh
      dc:	ff 01                	inc    WORD PTR [bx+di]
      de:	00 00                	add    BYTE PTR [bx+si],al
      e0:	00 00                	add    BYTE PTR [bx+si],al
      e2:	80 08 00             	or     BYTE PTR [bx+si],0x0
      e5:	00 00                	add    BYTE PTR [bx+si],al
      e7:	01 00                	add    WORD PTR [bx+si],ax
      e9:	09 49 6e             	or     WORD PTR [bx+di+0x6e],cx
      ec:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
      ef:	6d                   	ins    WORD PTR es:[di],dx
      f0:	65 6e                	outs   dx,BYTE PTR gs:[si]
      f2:	74 d4                	je     0xc8
      f4:	22 13                	and    dl,BYTE PTR [bp+di]
      f6:	01 0c                	add    WORD PTR [si],cx
      f8:	00 ff                	add    bh,bh
      fa:	ff 21                	jmp    WORD PTR [bx+di]
      fc:	1e                   	push   ds
      fd:	01 01                	add    WORD PTR [bx+di],ax
      ff:	42                   	inc    dx
     100:	1e                   	push   ds
     101:	1b 01                	sbb    ax,WORD PTR [bx+di]
     103:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     107:	00 00                	add    BYTE PTR [bx+si],al
     109:	02 00                	add    al,BYTE PTR [bx+si]
     10b:	05 52 61             	add    ax,0x6152
     10e:	6e                   	outs   dx,BYTE PTR ds:[si]
     10f:	67 65 d4 22          	addr32 gs aam 0x22
     113:	34 01                	xor    al,0x1
     115:	0a 00                	or     al,BYTE PTR [bx+si]
     117:	ff                   	(bad)
     118:	ff d0                	call   ax
     11a:	1c 3c                	sbb    al,0x3c
     11c:	01 01                	add    WORD PTR [bx+di],ax
     11e:	00 00                	add    BYTE PTR [bx+si],al
     120:	00 00                	add    BYTE PTR [bx+si],al
     122:	80 00 00             	add    BYTE PTR [bx+si],0x0
     125:	00 00                	add    BYTE PTR [bx+si],al
     127:	03 00                	add    ax,WORD PTR [bx+si]
     129:	08 50 6f             	or     BYTE PTR [bx+si+0x6f],dl
     12c:	73 69                	jae    0x197
     12e:	74 69                	je     0x199
     130:	6f                   	outs   dx,WORD PTR ds:[si]
     131:	6e                   	outs   dx,BYTE PTR ds:[si]
     132:	07                   	pop    es
     133:	23 6c 01             	and    bp,WORD PTR [si+0x1]
     136:	13 00                	adc    ax,WORD PTR [bx+si]
     138:	ff                   	(bad)
     139:	ff 62 1e             	jmp    WORD PTR [bp+si+0x1e]
     13c:	d4 01                	aam    0x1
     13e:	01 00                	add    WORD PTR [bx+si],ax
     140:	00 00                	add    BYTE PTR [bx+si],al
     142:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     146:	00 00                	add    BYTE PTR [bx+si],al
     148:	04 00                	add    al,0x0
     14a:	07                   	pop    es
     14b:	56                   	push   si
     14c:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     151:	65 1d 02 00          	gs sbb ax,0x2
     155:	00 00                	add    BYTE PTR [bx+si],al
     157:	00 03                	add    BYTE PTR [bp+di],al
     159:	02 ee                	add    ch,dh
     15b:	01 e4                	add    sp,sp
     15d:	00 c1                	add    cl,al
     15f:	05 39 02             	add    ax,0x239
     162:	fa                   	cli
     163:	45                   	inc    bp
     164:	d8 01                	fadd   DWORD PTR [bx+di]
     166:	9a 1f f5 04 cb       	call   0xcb04:0xf51f
     16b:	1f                   	pop    ds
     16c:	68 01 90             	push   0x9001
     16f:	1f                   	pop    ds
     170:	0f 02 cd             	lar    cx,bp
     173:	11 7c 01             	adc    WORD PTR [si+0x1],di
     176:	3a 27                	cmp    ah,BYTE PTR [bx]
     178:	80 01 fa             	add    BYTE PTR [bx+di],0xfa
     17b:	10 0d                	adc    BYTE PTR [di],cl
     17d:	05 d6 14             	add    ax,0x14d6
     180:	88 01                	mov    BYTE PTR [bx+di],al
     182:	f4                   	hlt
     183:	4f                   	dec    di
     184:	94                   	xchg   sp,ax
     185:	01 32                	add    WORD PTR [bp+si],si
     187:	16                   	push   ss
     188:	b0 01                	mov    al,0x1
     18a:	ec                   	in     al,dx
     18b:	30 e8                	xor    al,ch
     18d:	01 51 1b             	add    WORD PTR [bx+di+0x1b],dx
     190:	60                   	pusha
     191:	01 38                	add    WORD PTR [bx+si],di
     193:	50                   	push   ax
     194:	9c                   	pushf
     195:	01 63 31             	add    WORD PTR [bp+di+0x31],sp
     198:	b8 01 21             	mov    ax,0x2101
     19b:	50                   	push   ax
     19c:	74 01                	je     0x19f
     19e:	05 1f 70             	add    ax,0x701f
     1a1:	01 d9                	add    cx,bx
     1a3:	62 a8 01 06          	bound  bp,DWORD PTR [bx+si+0x601]
     1a7:	63 ac 01 8f          	arpl   WORD PTR [si-0x70ff],bp
     1ab:	60                   	pusha
     1ac:	e4 01                	in     al,0x1
     1ae:	3a 1c                	cmp    bl,BYTE PTR [si]
     1b0:	90                   	nop
     1b1:	01 46 44             	add    WORD PTR [bp+0x44],ax
     1b4:	98                   	cbw
     1b5:	01 08                	add    WORD PTR [bx+si],cx
     1b7:	61                   	popa
     1b8:	bc 01 5c             	mov    sp,0x5c01
     1bb:	61                   	popa
     1bc:	c0 01 62             	rol    BYTE PTR [bx+di],0x62
     1bf:	5c                   	pop    sp
     1c0:	ec                   	in     al,dx
     1c1:	01 3a                	add    WORD PTR [bp+si],di
     1c3:	61                   	popa
     1c4:	78 01                	js     0x1c7
     1c6:	72 3f                	jb     0x207
     1c8:	cc                   	int3
     1c9:	01 29                	add    WORD PTR [bx+di],bp
     1cb:	3b d0                	cmp    dx,ax
     1cd:	01 17                	add    WORD PTR [bx],dx
     1cf:	3e 64 01 cd          	ds fs add bp,cx
     1d3:	1f                   	pop    ds
     1d4:	e0 01                	loopne 0x1d7
     1d6:	ed                   	in     ax,dx
     1d7:	3e dc 01             	fadd   QWORD PTR ds:[bx+di]
     1da:	77 3e                	ja     0x21a
     1dc:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     1dd:	01 e8                	add    ax,bp
     1df:	1f                   	pop    ds
     1e0:	a0 01 1c             	mov    al,ds:0x1c01
     1e3:	48                   	dec    ax
     1e4:	8c 01                	mov    WORD PTR [bx+di],es
     1e6:	ae                   	scas   al,BYTE PTR es:[di]
     1e7:	5f                   	pop    di
     1e8:	b4 01                	mov    ah,0x1
     1ea:	35 62 c4             	xor    ax,0xc462
     1ed:	01 14                	add    WORD PTR [si],dx
     1ef:	54                   	push   sp
     1f0:	53                   	push   bx
     1f1:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     1f4:	6c                   	ins    BYTE PTR es:[di],dx
     1f5:	6c                   	ins    BYTE PTR es:[di],dx
     1f6:	69 6e 67 57 69       	imul   bp,WORD PTR [bp+0x67],0x6957
     1fb:	6e                   	outs   dx,BYTE PTR ds:[si]
     1fc:	43                   	inc    bx
     1fd:	6f                   	outs   dx,WORD PTR ds:[si]
     1fe:	6e                   	outs   dx,BYTE PTR ds:[si]
     1ff:	74 72                	je     0x273
     201:	6f                   	outs   dx,WORD PTR ds:[si]
     202:	6c                   	ins    BYTE PTR es:[di],dx
     203:	04 00                	add    al,0x0
     205:	05 00 14             	add    ax,0x1400
     208:	01 15                	add    WORD PTR [di],dx
     20a:	01 ff                	add    di,di
     20c:	ff 90 24 13          	call   WORD PTR [bx+si+0x1324]
     210:	02 db                	add    bl,bl
     212:	24 17                	and    al,0x17
     214:	02 0f                	add    cl,BYTE PTR [bx]
     216:	25 1b 02             	and    ax,0x21b
     219:	63 24                	arpl   WORD PTR [si],sp
     21b:	35 02 07             	xor    ax,0x702
     21e:	14 54                	adc    al,0x54
     220:	53                   	push   bx
     221:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     224:	6c                   	ins    BYTE PTR es:[di],dx
     225:	6c                   	ins    BYTE PTR es:[di],dx
     226:	69 6e 67 57 69       	imul   bp,WORD PTR [bp+0x67],0x6957
     22b:	6e                   	outs   dx,BYTE PTR ds:[si]
     22c:	43                   	inc    bx
     22d:	6f                   	outs   dx,WORD PTR ds:[si]
     22e:	6e                   	outs   dx,BYTE PTR ds:[si]
     22f:	74 72                	je     0x2a3
     231:	6f                   	outs   dx,WORD PTR ds:[si]
     232:	6c                   	ins    BYTE PTR es:[di],dx
     233:	72 01                	jb     0x236
     235:	47                   	inc    di
     236:	02 d7                	add    dl,bh
     238:	07                   	pop    es
     239:	51                   	push   cx
     23a:	05 0b 00             	add    ax,0xb
     23d:	05 46 6f             	add    ax,0x6f46
     240:	72 6d                	jb     0x2af
     242:	73 02                	jae    0x246
     244:	00 8d 00 4f          	add    BYTE PTR [di+0x4f00],cl
     248:	02 d8                	add    bl,al
     24a:	00 ff                	add    bh,bh
     24c:	ff f3                	push   bx
     24e:	20 6d 02             	and    BYTE PTR [di+0x2],ch
     251:	01 00                	add    WORD PTR [bx+si],ax
     253:	00 00                	add    BYTE PTR [bx+si],al
     255:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     259:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     25d:	0d 48 6f             	or     ax,0x6f48
     260:	72 7a                	jb     0x2dc
     262:	53                   	push   bx
     263:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     266:	6c                   	ins    BYTE PTR es:[di],dx
     267:	6c                   	ins    BYTE PTR es:[di],dx
     268:	42                   	inc    dx
     269:	61                   	popa
     26a:	72 8d                	jb     0x1f9
     26c:	00 75 02             	add    BYTE PTR [di+0x2],dh
     26f:	dc 00                	fadd   QWORD PTR [bx+si]
     271:	ff                   	(bad)
     272:	ff f3                	push   bx
     274:	20 ae 02 01          	and    BYTE PTR [bp+0x102],ch
     278:	00 00                	add    BYTE PTR [bx+si],al
     27a:	00 00                	add    BYTE PTR [bx+si],al
     27c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     27f:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     283:	0d 56 65             	or     ax,0x6556
     286:	72 74                	jb     0x2fc
     288:	53                   	push   bx
     289:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     28c:	6c                   	ins    BYTE PTR es:[di],dx
     28d:	6c                   	ins    BYTE PTR es:[di],dx
     28e:	42                   	inc    dx
     28f:	61                   	popa
     290:	72 03                	jb     0x295
     292:	10 54 46             	adc    BYTE PTR [si+0x46],dl
     295:	6f                   	outs   dx,WORD PTR ds:[si]
     296:	72 6d                	jb     0x305
     298:	42                   	inc    dx
     299:	6f                   	outs   dx,WORD PTR ds:[si]
     29a:	72 64                	jb     0x300
     29c:	65 72 53             	gs jb  0x2f2
     29f:	74 79                	je     0x31a
     2a1:	6c                   	ins    BYTE PTR es:[di],dx
     2a2:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     2a5:	00 00                	add    BYTE PTR [bx+si],al
     2a7:	00 03                	add    BYTE PTR [bp+di],al
     2a9:	00 00                	add    BYTE PTR [bx+si],al
     2ab:	00 91 02 ed          	add    BYTE PTR [bx+di-0x12fe],dl
     2af:	02 06 62 73          	add    al,BYTE PTR ds:0x7362
     2b3:	4e                   	dec    si
     2b4:	6f                   	outs   dx,WORD PTR ds:[si]
     2b5:	6e                   	outs   dx,BYTE PTR ds:[si]
     2b6:	65 08 62 73          	or     BYTE PTR gs:[bp+si+0x73],ah
     2ba:	53                   	push   bx
     2bb:	69 6e 67 6c 65       	imul   bp,WORD PTR [bp+0x67],0x656c
     2c0:	0a 62 73             	or     ah,BYTE PTR [bp+si+0x73]
     2c3:	53                   	push   bx
     2c4:	69 7a 65 61 62       	imul   di,WORD PTR [bp+si+0x65],0x6261
     2c9:	6c                   	ins    BYTE PTR es:[di],dx
     2ca:	65 08 62 73          	or     BYTE PTR gs:[bp+si+0x73],ah
     2ce:	44                   	inc    sp
     2cf:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     2d4:	03 0c                	add    cx,WORD PTR [si]
     2d6:	54                   	push   sp
     2d7:	42                   	inc    dx
     2d8:	6f                   	outs   dx,WORD PTR ds:[si]
     2d9:	72 64                	jb     0x33f
     2db:	65 72 53             	gs jb  0x331
     2de:	74 79                	je     0x359
     2e0:	6c                   	ins    BYTE PTR es:[di],dx
     2e1:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     2e4:	00 00                	add    BYTE PTR [bx+si],al
     2e6:	00 01                	add    BYTE PTR [bx+di],al
     2e8:	00 00                	add    BYTE PTR [bx+si],al
     2ea:	00 91 02 08          	add    BYTE PTR [bx+di+0x802],dl
     2ee:	03 03                	add    ax,WORD PTR [bp+di]
     2f0:	0c 54                	or     al,0x54
     2f2:	57                   	push   di
     2f3:	69 6e 64 6f 77       	imul   bp,WORD PTR [bp+0x64],0x776f
     2f8:	53                   	push   bx
     2f9:	74 61                	je     0x35c
     2fb:	74 65                	je     0x362
     2fd:	00 00                	add    BYTE PTR [bx+si],al
     2ff:	00 00                	add    BYTE PTR [bx+si],al
     301:	00 02                	add    BYTE PTR [bp+si],al
     303:	00 00                	add    BYTE PTR [bx+si],al
     305:	00 ef                	add    bh,ch
     307:	02 42 03             	add    al,BYTE PTR [bp+si+0x3]
     30a:	08 77 73             	or     BYTE PTR [bx+0x73],dh
     30d:	4e                   	dec    si
     30e:	6f                   	outs   dx,WORD PTR ds:[si]
     30f:	72 6d                	jb     0x37e
     311:	61                   	popa
     312:	6c                   	ins    BYTE PTR es:[di],dx
     313:	0b 77 73             	or     si,WORD PTR [bx+0x73]
     316:	4d                   	dec    bp
     317:	69 6e 69 6d 69       	imul   bp,WORD PTR [bp+0x69],0x696d
     31c:	7a 65                	jp     0x383
     31e:	64 0b 77 73          	or     si,WORD PTR fs:[bx+0x73]
     322:	4d                   	dec    bp
     323:	61                   	popa
     324:	78 69                	js     0x38f
     326:	6d                   	ins    WORD PTR es:[di],dx
     327:	69 7a 65 64 03       	imul   di,WORD PTR [bp+si+0x65],0x364
     32c:	0a 54 46             	or     dl,BYTE PTR [si+0x46]
     32f:	6f                   	outs   dx,WORD PTR ds:[si]
     330:	72 6d                	jb     0x39f
     332:	53                   	push   bx
     333:	74 79                	je     0x3ae
     335:	6c                   	ins    BYTE PTR es:[di],dx
     336:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     339:	00 00                	add    BYTE PTR [bx+si],al
     33b:	00 03                	add    BYTE PTR [bp+di],al
     33d:	00 00                	add    BYTE PTR [bx+si],al
     33f:	00 2b                	add    BYTE PTR [bp+di],ch
     341:	03 86 03 08          	add    ax,WORD PTR [bp+0x803]
     345:	66 73 4e             	data32 jae 0x396
     348:	6f                   	outs   dx,WORD PTR ds:[si]
     349:	72 6d                	jb     0x3b8
     34b:	61                   	popa
     34c:	6c                   	ins    BYTE PTR es:[di],dx
     34d:	0a 66 73             	or     ah,BYTE PTR [bp+0x73]
     350:	4d                   	dec    bp
     351:	44                   	inc    sp
     352:	49                   	dec    cx
     353:	43                   	inc    bx
     354:	68 69 6c             	push   0x6c69
     357:	64 09 66 73          	or     WORD PTR fs:[bp+0x73],sp
     35b:	4d                   	dec    bp
     35c:	44                   	inc    sp
     35d:	49                   	dec    cx
     35e:	46                   	inc    si
     35f:	6f                   	outs   dx,WORD PTR ds:[si]
     360:	72 6d                	jb     0x3cf
     362:	0b 66 73             	or     sp,WORD PTR [bp+0x73]
     365:	53                   	push   bx
     366:	74 61                	je     0x3c9
     368:	79 4f                	jns    0x3b9
     36a:	6e                   	outs   dx,BYTE PTR ds:[si]
     36b:	54                   	push   sp
     36c:	6f                   	outs   dx,WORD PTR ds:[si]
     36d:	70 03                	jo     0x372
     36f:	0b 54 42             	or     dx,WORD PTR [si+0x42]
     372:	6f                   	outs   dx,WORD PTR ds:[si]
     373:	72 64                	jb     0x3d9
     375:	65 72 49             	gs jb  0x3c1
     378:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     37b:	00 00                	add    BYTE PTR [bx+si],al
     37d:	00 00                	add    BYTE PTR [bx+si],al
     37f:	00 02                	add    BYTE PTR [bp+si],al
     381:	00 00                	add    BYTE PTR [bx+si],al
     383:	00 6e 03             	add    BYTE PTR [bp+0x3],ch
     386:	bc 03 0c             	mov    sp,0xc03
     389:	62 69 53             	bound  bp,DWORD PTR [bx+di+0x53]
     38c:	79 73                	jns    0x401
     38e:	74 65                	je     0x3f5
     390:	6d                   	ins    WORD PTR es:[di],dx
     391:	4d                   	dec    bp
     392:	65 6e                	outs   dx,BYTE PTR gs:[si]
     394:	75 0a                	jne    0x3a0
     396:	62 69 4d             	bound  bp,DWORD PTR [bx+di+0x4d]
     399:	69 6e 69 6d 69       	imul   bp,WORD PTR [bp+0x69],0x696d
     39e:	7a 65                	jp     0x405
     3a0:	0a 62 69             	or     ah,BYTE PTR [bp+si+0x69]
     3a3:	4d                   	dec    bp
     3a4:	61                   	popa
     3a5:	78 69                	js     0x410
     3a7:	6d                   	ins    WORD PTR es:[di],dx
     3a8:	69 7a 65 06 0c       	imul   di,WORD PTR [bp+si+0x65],0xc06
     3ad:	54                   	push   sp
     3ae:	42                   	inc    dx
     3af:	6f                   	outs   dx,WORD PTR ds:[si]
     3b0:	72 64                	jb     0x416
     3b2:	65 72 49             	gs jb  0x3fe
     3b5:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     3b8:	73 01                	jae    0x3bb
     3ba:	6e                   	outs   dx,BYTE PTR ds:[si]
     3bb:	03 d4                	add    dx,sp
     3bd:	03 03                	add    ax,WORD PTR [bp+di]
     3bf:	09 54 50             	or     WORD PTR [si+0x50],dx
     3c2:	6f                   	outs   dx,WORD PTR ds:[si]
     3c3:	73 69                	jae    0x42e
     3c5:	74 69                	je     0x430
     3c7:	6f                   	outs   dx,WORD PTR ds:[si]
     3c8:	6e                   	outs   dx,BYTE PTR ds:[si]
     3c9:	00 00                	add    BYTE PTR [bx+si],al
     3cb:	00 00                	add    BYTE PTR [bx+si],al
     3cd:	00 04                	add    BYTE PTR [si],al
     3cf:	00 00                	add    BYTE PTR [bx+si],al
     3d1:	00 be 03 35          	add    BYTE PTR [bp+0x3503],bh
     3d5:	04 0a                	add    al,0xa
     3d7:	70 6f                	jo     0x448
     3d9:	44                   	inc    sp
     3da:	65 73 69             	gs jae 0x446
     3dd:	67 6e                	outs   dx,BYTE PTR ds:[esi]
     3df:	65 64 09 70 6f       	gs or  WORD PTR fs:[bx+si+0x6f],si
     3e4:	44                   	inc    sp
     3e5:	65 66 61             	gs popad
     3e8:	75 6c                	jne    0x456
     3ea:	74 10                	je     0x3fc
     3ec:	70 6f                	jo     0x45d
     3ee:	44                   	inc    sp
     3ef:	65 66 61             	gs popad
     3f2:	75 6c                	jne    0x460
     3f4:	74 50                	je     0x446
     3f6:	6f                   	outs   dx,WORD PTR ds:[si]
     3f7:	73 4f                	jae    0x448
     3f9:	6e                   	outs   dx,BYTE PTR ds:[si]
     3fa:	6c                   	ins    BYTE PTR es:[di],dx
     3fb:	79 11                	jns    0x40e
     3fd:	70 6f                	jo     0x46e
     3ff:	44                   	inc    sp
     400:	65 66 61             	gs popad
     403:	75 6c                	jne    0x471
     405:	74 53                	je     0x45a
     407:	69 7a 65 4f 6e       	imul   di,WORD PTR [bp+si+0x65],0x6e4f
     40c:	6c                   	ins    BYTE PTR es:[di],dx
     40d:	79 0e                	jns    0x41d
     40f:	70 6f                	jo     0x480
     411:	53                   	push   bx
     412:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
     415:	65 6e                	outs   dx,BYTE PTR gs:[si]
     417:	43                   	inc    bx
     418:	65 6e                	outs   dx,BYTE PTR gs:[si]
     41a:	74 65                	je     0x481
     41c:	72 03                	jb     0x421
     41e:	0b 54 50             	or     dx,WORD PTR [si+0x50]
     421:	72 69                	jb     0x48c
     423:	6e                   	outs   dx,BYTE PTR ds:[si]
     424:	74 53                	je     0x479
     426:	63 61 6c             	arpl   WORD PTR [bx+di+0x6c],sp
     429:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     42c:	00 00                	add    BYTE PTR [bx+si],al
     42e:	00 02                	add    BYTE PTR [bp+si],al
     430:	00 00                	add    BYTE PTR [bx+si],al
     432:	00 1d                	add    BYTE PTR [di],bl
     434:	04 69                	add    al,0x69
     436:	05 06 70             	add    ax,0x7006
     439:	6f                   	outs   dx,WORD PTR ds:[si]
     43a:	4e                   	dec    si
     43b:	6f                   	outs   dx,WORD PTR ds:[si]
     43c:	6e                   	outs   dx,BYTE PTR ds:[si]
     43d:	65 0e                	gs push cs
     43f:	70 6f                	jo     0x4b0
     441:	50                   	push   ax
     442:	72 6f                	jb     0x4b3
     444:	70 6f                	jo     0x4b5
     446:	72 74                	jb     0x4bc
     448:	69 6f 6e 61 6c       	imul   bp,WORD PTR [bx+0x6e],0x6c61
     44d:	0c 70                	or     al,0x70
     44f:	6f                   	outs   dx,WORD PTR ds:[si]
     450:	50                   	push   ax
     451:	72 69                	jb     0x4bc
     453:	6e                   	outs   dx,BYTE PTR ds:[si]
     454:	74 54                	je     0x4aa
     456:	6f                   	outs   dx,WORD PTR ds:[si]
     457:	46                   	inc    si
     458:	69 74 01 0c 54       	imul   si,WORD PTR [si+0x1],0x540c
     45d:	4d                   	dec    bp
     45e:	6f                   	outs   dx,WORD PTR ds:[si]
     45f:	64 61                	fs popa
     461:	6c                   	ins    BYTE PTR es:[di],dx
     462:	52                   	push   dx
     463:	65 73 75             	gs jae 0x4db
     466:	6c                   	ins    BYTE PTR es:[di],dx
     467:	74 02                	je     0x46b
     469:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     46d:	ff                   	(bad)
     46e:	7f 00                	jg     0x470
     470:	00 08                	add    BYTE PTR [bx+si],cl
     472:	0b 54 43             	or     dx,WORD PTR [si+0x43]
     475:	6c                   	ins    BYTE PTR es:[di],dx
     476:	6f                   	outs   dx,WORD PTR ds:[si]
     477:	73 65                	jae    0x4de
     479:	45                   	inc    bp
     47a:	76 65                	jbe    0x4e1
     47c:	6e                   	outs   dx,BYTE PTR ds:[si]
     47d:	74 00                	je     0x47f
     47f:	02 00                	add    al,BYTE PTR [bx+si]
     481:	06                   	push   es
     482:	53                   	push   bx
     483:	65 6e                	outs   dx,BYTE PTR gs:[si]
     485:	64 65 72 07          	fs gs jb 0x490
     489:	54                   	push   sp
     48a:	4f                   	dec    di
     48b:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     48e:	63 74 01             	arpl   WORD PTR [si+0x1],si
     491:	06                   	push   es
     492:	41                   	inc    cx
     493:	63 74 69             	arpl   WORD PTR [si+0x69],si
     496:	6f                   	outs   dx,WORD PTR ds:[si]
     497:	6e                   	outs   dx,BYTE PTR ds:[si]
     498:	0c 54                	or     al,0x54
     49a:	43                   	inc    bx
     49b:	6c                   	ins    BYTE PTR es:[di],dx
     49c:	6f                   	outs   dx,WORD PTR ds:[si]
     49d:	73 65                	jae    0x504
     49f:	41                   	inc    cx
     4a0:	63 74 69             	arpl   WORD PTR [si+0x69],si
     4a3:	6f                   	outs   dx,WORD PTR ds:[si]
     4a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a5:	08 10                	or     BYTE PTR [bx+si],dl
     4a7:	54                   	push   sp
     4a8:	43                   	inc    bx
     4a9:	6c                   	ins    BYTE PTR es:[di],dx
     4aa:	6f                   	outs   dx,WORD PTR ds:[si]
     4ab:	73 65                	jae    0x512
     4ad:	51                   	push   cx
     4ae:	75 65                	jne    0x515
     4b0:	72 79                	jb     0x52b
     4b2:	45                   	inc    bp
     4b3:	76 65                	jbe    0x51a
     4b5:	6e                   	outs   dx,BYTE PTR ds:[si]
     4b6:	74 00                	je     0x4b8
     4b8:	02 00                	add    al,BYTE PTR [bx+si]
     4ba:	06                   	push   es
     4bb:	53                   	push   bx
     4bc:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4be:	64 65 72 07          	fs gs jb 0x4c9
     4c2:	54                   	push   sp
     4c3:	4f                   	dec    di
     4c4:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     4c7:	63 74 01             	arpl   WORD PTR [si+0x1],si
     4ca:	08 43 61             	or     BYTE PTR [bp+di+0x61],al
     4cd:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ce:	43                   	inc    bx
     4cf:	6c                   	ins    BYTE PTR es:[di],dx
     4d0:	6f                   	outs   dx,WORD PTR ds:[si]
     4d1:	73 65                	jae    0x538
     4d3:	07                   	pop    es
     4d4:	42                   	inc    dx
     4d5:	6f                   	outs   dx,WORD PTR ds:[si]
     4d6:	6f                   	outs   dx,WORD PTR ds:[si]
     4d7:	6c                   	ins    BYTE PTR es:[di],dx
     4d8:	65 61                	gs popa
     4da:	6e                   	outs   dx,BYTE PTR ds:[si]
     4db:	7b 06                	jnp    0x4e3
     4dd:	00 00                	add    BYTE PTR [bx+si],al
     4df:	00 00                	add    BYTE PTR [bx+si],al
     4e1:	7d 05                	jge    0x4e8
     4e3:	77 05                	ja     0x4ea
     4e5:	7c 01                	jl     0x4e8
     4e7:	72 01                	jb     0x4ea
     4e9:	d5 05                	aad    0x5
     4eb:	39 3f                	cmp    WORD PTR [bx],di
     4ed:	01 05                	add    WORD PTR [di],ax
     4ef:	9a 1f 04 07 cb       	call   0xcb07:0x41f
     4f4:	1f                   	pop    ds
     4f5:	f1                   	int1
     4f6:	04 ad                	add    al,0xad
     4f8:	27                   	daa
     4f9:	75 05                	jne    0x500
     4fb:	cd 11                	int    0x11
     4fd:	05 05 f7             	add    ax,0xf705
     500:	2a 61 05             	sub    ah,BYTE PTR [bx+di+0x5]
     503:	fa                   	cli
     504:	10 6b 0a             	adc    BYTE PTR [bp+di+0xa],ch
     507:	d6                   	(bad)
     508:	14 39                	adc    al,0x39
     50a:	05 f4 4f             	add    ax,0x4ff4
     50d:	25 05 9a             	and    ax,0x9a05
     510:	28 6d 05             	sub    BYTE PTR [di+0x5],ch
     513:	85 29                	test   WORD PTR [bx+di],bp
     515:	19 05                	sbb    WORD PTR [di],ax
     517:	57                   	push   di
     518:	4d                   	dec    bp
     519:	1d 05 91             	sbb    ax,0x9105
     51c:	2f                   	das
     51d:	3d 05 63             	cmp    ax,0x6305
     520:	31 41 05             	xor    WORD PTR [bx+di+0x5],ax
     523:	21 50 fd             	and    WORD PTR [bx+si-0x3],dx
     526:	04 53                	add    al,0x53
     528:	25 f9 04             	and    ax,0x4f9
     52b:	d9 62 35             	fldenv [bp+si+0x35]
     52e:	05 55 2e             	add    ax,0x2e55
     531:	11 05                	adc    WORD PTR [di],ax
     533:	8f                   	(bad)
     534:	60                   	pusha
     535:	71 05                	jno    0x53c
     537:	3a 1c                	cmp    bl,BYTE PTR [si]
     539:	96                   	xchg   si,ax
     53a:	06                   	push   es
     53b:	e2 2f                	loop   0x56c
     53d:	29 05                	sub    WORD PTR [di],ax
     53f:	08 61 45             	or     BYTE PTR [bx+di+0x45],ah
     542:	05 5c 61             	add    ax,0x615c
     545:	49                   	dec    cx
     546:	05 62 5c             	add    ax,0x5c62
     549:	4d                   	dec    bp
     54a:	05 3a 61             	add    ax,0x613a
     54d:	09 05                	or     WORD PTR [di],ax
     54f:	72 3f                	jb     0x590
     551:	65 05 58 3a          	gs add ax,0x3a58
     555:	59                   	pop    cx
     556:	05 ec 3d             	add    ax,0x3dec
     559:	5d                   	pop    bp
     55a:	05 e4 3c             	add    ax,0x3ce4
     55d:	ed                   	in     ax,dx
     55e:	04 ed                	add    al,0xed
     560:	3e 31 05             	xor    WORD PTR ds:[di],ax
     563:	77 3e                	ja     0x5a3
     565:	2d 05 e6             	sub    ax,0xe605
     568:	31 55 05             	xor    WORD PTR [di+0x5],dx
     56b:	3c 47                	cmp    al,0x47
     56d:	15 05 ae             	adc    ax,0xae05
     570:	5f                   	pop    di
     571:	21 05                	and    WORD PTR [di],ax
     573:	e9 5c e9             	jmp    0xeed2
     576:	04 05                	add    al,0x5
     578:	54                   	push   sp
     579:	46                   	inc    si
     57a:	6f                   	outs   dx,WORD PTR ds:[si]
     57b:	72 6d                	jb     0x5ea
     57d:	2a 00                	sub    al,BYTE PTR [bx+si]
     57f:	0f 00 14             	lldt   WORD PTR [si]
     582:	00 27                	add    BYTE PTR [bx],ah
     584:	00 37                	add    BYTE PTR [bx],dh
     586:	00 81 00 02          	add    BYTE PTR [bx+di+0x200],al
     58a:	00 11                	add    BYTE PTR [bx+di],dl
     58c:	01 17                	add    WORD PTR [bx],dx
     58e:	01 1f                	add    WORD PTR [bx],bx
     590:	01 21                	add    WORD PTR [bx+di],sp
     592:	01 06 00 05          	add    WORD PTR ds:0x500,ax
     596:	00 10                	add    BYTE PTR [bx+si],dl
     598:	00 11                	add    BYTE PTR [bx+di],dl
     59a:	00 12                	add    BYTE PTR [bp+si],dl
     59c:	01 18                	add    WORD PTR [bx+si],bx
     59e:	00 22                	add    BYTE PTR [bp+si],ah
     5a0:	02 28                	add    ch,BYTE PTR [bx+si]
     5a2:	00 07                	add    BYTE PTR [bx],al
     5a4:	00 08                	add    BYTE PTR [bx+si],cl
     5a6:	00 10                	add    BYTE PTR [bx+si],dl
     5a8:	02 11                	add    dl,BYTE PTR [bx+di]
     5aa:	02 00                	add    al,BYTE PTR [bx+si]
     5ac:	0f 01 0f             	sidtw  [bx]
     5af:	05 0f 0d             	add    ax,0xd0f
     5b2:	0f 10 0f             	movups xmm1,XMMWORD PTR [bx]
     5b5:	0e                   	push   cs
     5b6:	0f 15 0f             	unpckhps xmm1,XMMWORD PTR [bx]
     5b9:	19 0f                	sbb    WORD PTR [bx],cx
     5bb:	1d 0f 21             	sbb    ax,0x210f
     5be:	0f 12 0f             	movlps xmm1,QWORD PTR [bx]
     5c1:	ee                   	out    dx,al
     5c2:	ff                   	jmp    (bad)
     5c3:	ed                   	in     ax,dx
     5c4:	ff                   	(bad)
     5c5:	ff                   	(bad)
     5c6:	ff                   	jmp    (bad)
     5c7:	ec                   	in     al,dx
     5c8:	ff                   	jmp    (bad)
     5c9:	eb ff                	jmp    0x5ca
     5cb:	ea ff e9 ff e8       	jmp    0xe8ff:0xe9ff
     5d0:	ff f5                	push   bp
     5d2:	ff ad 47 d9          	jmp    DWORD PTR [di-0x26b9]
     5d6:	05 7e 48             	add    ax,0x487e
     5d9:	dd 05                	fld    QWORD PTR [di]
     5db:	1e                   	push   ds
     5dc:	48                   	dec    ax
     5dd:	e1 05                	loope  0x5e4
     5df:	bf 48 e5             	mov    di,0xe548
     5e2:	05 c3 49             	add    ax,0x49c3
     5e5:	e9 05 fe             	jmp    0x3ed
     5e8:	49                   	dec    cx
     5e9:	ed                   	in     ax,dx
     5ea:	05 6b 4a             	add    ax,0x4a6b
     5ed:	f1                   	int1
     5ee:	05 bc 4a             	add    ax,0x4abc
     5f1:	f5                   	cmc
     5f2:	05 e9 4a             	add    ax,0x4ae9
     5f5:	f9                   	stc
     5f6:	05 b1 4b             	add    ax,0x4bb1
     5f9:	fd                   	std
     5fa:	05 20 4c             	add    ax,0x4c20
     5fd:	01 06 b5 4c          	add    WORD PTR ds:0x4cb5,ax
     601:	05 06 46             	add    ax,0x4606
     604:	4d                   	dec    bp
     605:	09 06 34 4e          	or     WORD PTR ds:0x4e34,ax
     609:	0d 06 52             	or     ax,0x5206
     60c:	4e                   	dec    si
     60d:	11 06 d8 4e          	adc    WORD PTR ds:0x4ed8,ax
     611:	15 06 92             	adc    ax,0x9206
     614:	4f                   	dec    di
     615:	19 06 ba 4f          	sbb    WORD PTR ds:0x4fba,ax
     619:	1d 06 8a             	sbb    ax,0x8a06
     61c:	4d                   	dec    bp
     61d:	21 06 c1 4d          	and    WORD PTR ds:0x4dc1,ax
     621:	25 06 f8             	and    ax,0xf806
     624:	4d                   	dec    bp
     625:	29 06 07 50          	sub    WORD PTR ds:0x5007,ax
     629:	2d 06 2e             	sub    ax,0x2e06
     62c:	50                   	push   ax
     62d:	31 06 42 50          	xor    WORD PTR ds:0x5042,ax
     631:	35 06 56             	xor    ax,0x5606
     634:	50                   	push   ax
     635:	39 06 e1 38          	cmp    WORD PTR ds:0x38e1,ax
     639:	3d 06 4c             	cmp    ax,0x4c06
     63c:	39 41 06             	cmp    WORD PTR [bx+di+0x6],ax
     63f:	b5 39                	mov    ch,0x39
     641:	45                   	inc    bp
     642:	06                   	push   es
     643:	ef                   	out    dx,ax
     644:	39 49 06             	cmp    WORD PTR [bx+di+0x6],cx
     647:	4b                   	dec    bx
     648:	51                   	push   cx
     649:	4d                   	dec    bp
     64a:	06                   	push   es
     64b:	c2 54 51             	ret    0x5154
     64e:	06                   	push   es
     64f:	e8 54 55             	call   0x5ba6
     652:	06                   	push   es
     653:	f9                   	stc
     654:	54                   	push   sp
     655:	59                   	pop    cx
     656:	06                   	push   es
     657:	4c                   	dec    sp
     658:	46                   	inc    si
     659:	5d                   	pop    bp
     65a:	06                   	push   es
     65b:	2c 44                	sub    al,0x44
     65d:	61                   	popa
     65e:	06                   	push   es
     65f:	9b                   	fwait
     660:	2b 65 06             	sub    sp,WORD PTR [di+0x6]
     663:	74 46                	je     0x6ab
     665:	69 06 34 2d 6d 06    	imul   ax,WORD PTR ds:0x2d34,0x66d
     66b:	5c                   	pop    sp
     66c:	2d 71 06             	sub    ax,0x671
     66f:	9c                   	pushf
     670:	46                   	inc    si
     671:	75 06                	jne    0x679
     673:	c4 46 79             	les    ax,DWORD PTR [bp+0x79]
     676:	06                   	push   es
     677:	52                   	push   dx
     678:	2f                   	das
     679:	84 06 07 05          	test   BYTE PTR ds:0x507,al
     67d:	54                   	push   sp
     67e:	46                   	inc    si
     67f:	6f                   	outs   dx,WORD PTR ds:[si]
     680:	72 6d                	jb     0x6ef
     682:	fb                   	sti
     683:	04 88                	add    al,0x88
     685:	06                   	push   es
     686:	1d 02 9e             	sbb    ax,0x9e02
     689:	06                   	push   es
     68a:	38 00                	cmp    BYTE PTR [bx+si],al
     68c:	05 46 6f             	add    ax,0x6f46
     68f:	72 6d                	jb     0x6fe
     691:	73 31                	jae    0x6c4
     693:	00 d7                	add    bh,dl
     695:	07                   	pop    es
     696:	27                   	daa
     697:	07                   	pop    es
     698:	e4 00                	in     al,0x0
     69a:	ff                   	(bad)
     69b:	ff d0                	call   ax
     69d:	3f                   	aas
     69e:	a2 06 95             	mov    ds:0x9506,al
     6a1:	34 bc                	xor    al,0xbc
     6a3:	06                   	push   es
     6a4:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     6a8:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     6ac:	0d 41 63             	or     ax,0x6341
     6af:	74 69                	je     0x71a
     6b1:	76 65                	jbe    0x718
     6b3:	43                   	inc    bx
     6b4:	6f                   	outs   dx,WORD PTR ds:[si]
     6b5:	6e                   	outs   dx,BYTE PTR ds:[si]
     6b6:	74 72                	je     0x72a
     6b8:	6f                   	outs   dx,WORD PTR ds:[si]
     6b9:	6c                   	ins    BYTE PTR es:[di],dx
     6ba:	ab                   	stos   WORD PTR es:[di],ax
     6bb:	03 c4                	add    ax,sp
     6bd:	06                   	push   es
     6be:	ec                   	in     al,dx
     6bf:	00 ff                	add    bh,bh
     6c1:	ff 44 32             	inc    WORD PTR [si+0x32]
     6c4:	c8 06 95 34          	enter  0x9506,0x34
     6c8:	e0 06                	loopne 0x6d0
     6ca:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     6ce:	00 00                	add    BYTE PTR [bx+si],al
     6d0:	0c 00                	or     al,0x0
     6d2:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
     6d5:	72 64                	jb     0x73b
     6d7:	65 72 49             	gs jb  0x723
     6da:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     6dd:	73 91                	jae    0x670
     6df:	02 e8                	add    ch,al
     6e1:	06                   	push   es
     6e2:	ed                   	in     ax,dx
     6e3:	00 ff                	add    bh,bh
     6e5:	ff 6e 32             	jmp    DWORD PTR [bp+0x32]
     6e8:	ec                   	in     al,dx
     6e9:	06                   	push   es
     6ea:	95                   	xchg   bp,ax
     6eb:	34 0c                	xor    al,0xc
     6ed:	07                   	pop    es
     6ee:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     6f2:	00 00                	add    BYTE PTR [bx+si],al
     6f4:	0d 00 0b             	or     ax,0xb00
     6f7:	42                   	inc    dx
     6f8:	6f                   	outs   dx,WORD PTR ds:[si]
     6f9:	72 64                	jb     0x75f
     6fb:	65 72 53             	gs jb  0x751
     6fe:	74 79                	je     0x779
     700:	6c                   	ins    BYTE PTR es:[di],dx
     701:	65 07                	gs pop es
     703:	23 47 07             	and    ax,WORD PTR [bx+0x7]
     706:	e0 00                	loopne 0x708
     708:	ff                   	(bad)
     709:	ff a6 20 10          	jmp    WORD PTR [bp+0x1020]
     70d:	07                   	pop    es
     70e:	fd                   	std
     70f:	2c 33                	sub    al,0x33
     711:	07                   	pop    es
     712:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     716:	00 00                	add    BYTE PTR [bx+si],al
     718:	0e                   	push   cs
     719:	00 0a                	add    BYTE PTR [bp+si],cl
     71b:	41                   	inc    cx
     71c:	75 74                	jne    0x792
     71e:	6f                   	outs   dx,WORD PTR ds:[si]
     71f:	53                   	push   bx
     720:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     723:	6c                   	ins    BYTE PTR es:[di],dx
     724:	6c                   	ins    BYTE PTR es:[di],dx
     725:	66 01 2b             	add    DWORD PTR [bp+di],ebp
     728:	07                   	pop    es
     729:	53                   	push   bx
     72a:	1d 2f 07             	sbb    ax,0x72f
     72d:	8c 1d                	mov    WORD PTR [di],ds
     72f:	4b                   	dec    bx
     730:	07                   	pop    es
     731:	95                   	xchg   bp,ax
     732:	34 4f                	xor    al,0x4f
     734:	07                   	pop    es
     735:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     739:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     73d:	07                   	pop    es
     73e:	43                   	inc    bx
     73f:	61                   	popa
     740:	70 74                	jo     0x7b6
     742:	69 6f 6e d4 22       	imul   bp,WORD PTR [bx+0x6e],0x22d4
     747:	6c                   	ins    BYTE PTR es:[di],dx
     748:	07                   	pop    es
     749:	f4                   	hlt
     74a:	18 70 07             	sbb    BYTE PTR [bx+si+0x7],dh
     74d:	f1                   	int1
     74e:	2e 53                	cs push bx
     750:	07                   	pop    es
     751:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     752:	2c 74                	sub    al,0x74
     754:	07                   	pop    es
     755:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     759:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     75d:	0c 43                	or     al,0x43
     75f:	6c                   	ins    BYTE PTR es:[di],dx
     760:	69 65 6e 74 48       	imul   sp,WORD PTR [di+0x6e],0x4874
     765:	65 69 67 68 74 d4    	imul   sp,WORD PTR gs:[bx+0x68],0xd474
     76b:	22 90 07 a9          	and    dl,BYTE PTR [bx+si-0x56f9]
     76f:	18 98 07 c9          	sbb    BYTE PTR [bx+si-0x36f9],bl
     773:	2e 78 07             	cs js  0x77d
     776:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     777:	2c ba                	sub    al,0xba
     779:	07                   	pop    es
     77a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     77e:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     782:	0b 43 6c             	or     ax,WORD PTR [bp+di+0x6c]
     785:	69 65 6e 74 57       	imul   sp,WORD PTR [di+0x6e],0x5774
     78a:	69 64 74 68 07       	imul   sp,WORD PTR [si+0x74],0x768
     78f:	23 cc                	and    cx,sp
     791:	07                   	pop    es
     792:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     793:	00 ff                	add    bh,bh
     795:	ff 22                	jmp    WORD PTR [bp+si]
     797:	63 9c 07 54          	arpl   WORD PTR [si+0x5407],bx
     79b:	63 b6 07 00          	arpl   WORD PTR [bp+0x7],si
     79f:	80 01 00             	add    BYTE PTR [bx+di],0x0
     7a2:	00 00                	add    BYTE PTR [bx+si],al
     7a4:	12 00                	adc    al,BYTE PTR [bx+si]
     7a6:	05 43 74             	add    ax,0x7443
     7a9:	6c                   	ins    BYTE PTR es:[di],dx
     7aa:	33 44 02             	xor    ax,WORD PTR [si+0x2]
     7ad:	00 ec                	add    ah,ch
     7af:	07                   	pop    es
     7b0:	38 00                	cmp    BYTE PTR [bx+si],al
     7b2:	ff                   	(bad)
     7b3:	ff d5                	call   bp
     7b5:	1e                   	push   ds
     7b6:	d4 07                	aam    0x7
     7b8:	4f                   	dec    di
     7b9:	34 09                	xor    al,0x9
     7bb:	08 00                	or     BYTE PTR [bx+si],al
     7bd:	80 fa ff             	cmp    dl,0xff
     7c0:	ff                   	(bad)
     7c1:	ff 13                	call   WORD PTR [bp+di]
     7c3:	00 05                	add    BYTE PTR [di],al
     7c5:	43                   	inc    bx
     7c6:	6f                   	outs   dx,WORD PTR ds:[si]
     7c7:	6c                   	ins    BYTE PTR es:[di],dx
     7c8:	6f                   	outs   dx,WORD PTR ds:[si]
     7c9:	72 07                	jb     0x7d2
     7cb:	23 2b                	and    bp,WORD PTR [bp+di]
     7cd:	08 2a                	or     BYTE PTR [bp+si],ch
     7cf:	00 ff                	add    bh,bh
     7d1:	ff                   	(bad)
     7d2:	b8 1c f4             	mov    ax,0xf41c
     7d5:	07                   	pop    es
     7d6:	01 00                	add    WORD PTR [bx+si],ax
     7d8:	00 00                	add    BYTE PTR [bx+si],al
     7da:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     7de:	00 00                	add    BYTE PTR [bx+si],al
     7e0:	14 00                	adc    al,0x0
     7e2:	07                   	pop    es
     7e3:	45                   	inc    bp
     7e4:	6e                   	outs   dx,BYTE PTR ds:[si]
     7e5:	61                   	popa
     7e6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7e9:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     7ec:	70 08                	jo     0x7f6
     7ee:	34 00                	xor    al,0x0
     7f0:	ff                   	(bad)
     7f1:	ff                   	jmp    (bad)
     7f2:	eb 1d                	jmp    0x811
     7f4:	f8                   	clc
     7f5:	07                   	pop    es
     7f6:	08 1e 33 08          	or     BYTE PTR ds:0x833,bl
     7fa:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     7fe:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     802:	04 46                	add    al,0x46
     804:	6f                   	outs   dx,WORD PTR ds:[si]
     805:	6e                   	outs   dx,BYTE PTR ds:[si]
     806:	74 2b                	je     0x833
     808:	03 11                	add    dx,WORD PTR [bx+di]
     80a:	08 f2                	or     dl,dh
     80c:	00 ff                	add    bh,bh
     80e:	ff e5                	jmp    bp
     810:	34 15                	xor    al,0x15
     812:	08 95 34 37          	or     BYTE PTR [di+0x3734],dl
     816:	08 00                	or     BYTE PTR [bx+si],al
     818:	80 00 00             	add    BYTE PTR [bx+si],0x0
     81b:	00 00                	add    BYTE PTR [bx+si],al
     81d:	16                   	push   ss
     81e:	00 09                	add    BYTE PTR [bx+di],cl
     820:	46                   	inc    si
     821:	6f                   	outs   dx,WORD PTR ds:[si]
     822:	72 6d                	jb     0x891
     824:	53                   	push   bx
     825:	74 79                	je     0x8a0
     827:	6c                   	ins    BYTE PTR es:[di],dx
     828:	65 d4 22             	gs aam 0x22
     82b:	8d 08                	lea    cx,[bx+si]
     82d:	24 00                	and    al,0x0
     82f:	ff                   	(bad)
     830:	ff e1                	jmp    cx
     832:	17                   	pop    ss
     833:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     834:	09 c3                	or     bx,ax
     836:	2c 4a                	sub    al,0x4a
     838:	08 00                	or     BYTE PTR [bx+si],al
     83a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     83d:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     841:	06                   	push   es
     842:	48                   	dec    ax
     843:	65 69 67 68 74 8d    	imul   sp,WORD PTR gs:[bx+0x68],0x8d74
     849:	00 52 08             	add    BYTE PTR [bp+si+0x8],dl
     84c:	d8 00                	fadd   DWORD PTR [bx+si]
     84e:	ff                   	(bad)
     84f:	ff f3                	push   bx
     851:	20 56 08             	and    BYTE PTR [bp+0x8],dl
     854:	95                   	xchg   bp,ax
     855:	34 78                	xor    al,0x78
     857:	08 00                	or     BYTE PTR [bx+si],al
     859:	80 00 00             	add    BYTE PTR [bx+si],0x0
     85c:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     860:	0d 48 6f             	or     ax,0x6f48
     863:	72 7a                	jb     0x8df
     865:	53                   	push   bx
     866:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     869:	6c                   	ins    BYTE PTR es:[di],dx
     86a:	6c                   	ins    BYTE PTR es:[di],dx
     86b:	42                   	inc    dx
     86c:	61                   	popa
     86d:	72 4a                	jb     0x8b9
     86f:	09 03                	or     WORD PTR [bp+di],ax
     871:	27                   	daa
     872:	fc                   	cld
     873:	00 ff                	add    bh,bh
     875:	ff f6                	push   si
     877:	33 7c 08             	xor    di,WORD PTR [si+0x8]
     87a:	b0 34                	mov    al,0x34
     87c:	99                   	cwd
     87d:	08 00                	or     BYTE PTR [bx+si],al
     87f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     882:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     886:	04 49                	add    al,0x49
     888:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     88b:	07                   	pop    es
     88c:	23 f4                	and    si,sp
     88e:	08 f0                	or     al,dh
     890:	00 ff                	add    bh,bh
     892:	ff f0                	push   ax
     894:	00 ff                	add    bh,bh
     896:	ff 95 34 b8          	call   WORD PTR [di-0x47cc]
     89a:	08 00                	or     BYTE PTR [bx+si],al
     89c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     89f:	00 00                	add    BYTE PTR [bx+si],al
     8a1:	18 00                	sbb    BYTE PTR [bx+si],al
     8a3:	0a 4b 65             	or     cl,BYTE PTR [bp+di+0x65]
     8a6:	79 50                	jns    0x8f8
     8a8:	72 65                	jb     0x90f
     8aa:	76 69                	jbe    0x915
     8ac:	65 77 31             	gs ja  0x8e0
     8af:	03 cd                	add    cx,bp
     8b1:	08 00                	or     BYTE PTR [bx+si],al
     8b3:	01 ff                	add    di,di
     8b5:	ff b2 36 bc          	push   WORD PTR [bp+si-0x43ca]
     8b9:	08 95 34 d5          	or     BYTE PTR [di-0x2acc],dl
     8bd:	08 00                	or     BYTE PTR [bx+si],al
     8bf:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8c2:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     8c6:	04 4d                	add    al,0x4d
     8c8:	65 6e                	outs   dx,BYTE PTR gs:[si]
     8ca:	75 da                	jne    0x8a6
     8cc:	00 1a                	add    BYTE PTR [bp+si],bl
     8ce:	09 16 01 ff          	or     WORD PTR ds:0xff01,dx
     8d2:	ff 4c 36             	dec    WORD PTR [si+0x36]
     8d5:	d9 08                	(bad)  [bx+si]
     8d7:	95                   	xchg   bp,ax
     8d8:	34 f8                	xor    al,0xf8
     8da:	08 00                	or     BYTE PTR [bx+si],al
     8dc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8df:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     8e3:	0e                   	push   cs
     8e4:	4f                   	dec    di
     8e5:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     8e8:	63 74 4d             	arpl   WORD PTR [si+0x4d],si
     8eb:	65 6e                	outs   dx,BYTE PTR gs:[si]
     8ed:	75 49                	jne    0x938
     8ef:	74 65                	je     0x956
     8f1:	6d                   	ins    WORD PTR es:[di],dx
     8f2:	d4 22                	aam    0x22
     8f4:	80 09 11             	or     BYTE PTR [bx+di],0x11
     8f7:	38 fc                	cmp    ah,bh
     8f9:	08 38                	or     BYTE PTR [bx+si],bh
     8fb:	38 00                	cmp    BYTE PTR [bx+si],al
     8fd:	09 95 34 26          	or     WORD PTR [di+0x2634],dx
     901:	09 00                	or     WORD PTR [bx+si],ax
     903:	80 00 00             	add    BYTE PTR [bx+si],0x0
     906:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     90a:	0d 50 69             	or     ax,0x6950
     90d:	78 65                	js     0x974
     90f:	6c                   	ins    BYTE PTR es:[di],dx
     910:	73 50                	jae    0x962
     912:	65 72 49             	gs jb  0x95e
     915:	6e                   	outs   dx,BYTE PTR ds:[si]
     916:	63 68 0d             	arpl   WORD PTR [bx+si+0xd],bp
     919:	04 48                	add    al,0x48
     91b:	0a 40 00             	or     al,BYTE PTR [bx+si+0x0]
     91e:	ff                   	(bad)
     91f:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     922:	ff                   	(bad)
     923:	ff 95 34 3c          	call   WORD PTR [di+0x3c34]
     927:	09 00                	or     WORD PTR [bx+si],ax
     929:	80 00 00             	add    BYTE PTR [bx+si],0x0
     92c:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     930:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     933:	70 75                	jo     0x9aa
     935:	70 4d                	jo     0x984
     937:	65 6e                	outs   dx,BYTE PTR gs:[si]
     939:	75 be                	jne    0x8f9
     93b:	03 44 09             	add    ax,WORD PTR [si+0x9]
     93e:	f3 00 ff             	repz add bh,bh
     941:	ff 65 38             	jmp    WORD PTR [di+0x38]
     944:	48                   	dec    ax
     945:	09 95 34 5d          	or     WORD PTR [di+0x5d34],dx
     949:	09 00                	or     WORD PTR [bx+si],ax
     94b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     94e:	00 00                	add    BYTE PTR [bx+si],al
     950:	1d 00 08             	sbb    ax,0x800
     953:	50                   	push   ax
     954:	6f                   	outs   dx,WORD PTR ds:[si]
     955:	73 69                	jae    0x9c0
     957:	74 69                	je     0x9c2
     959:	6f                   	outs   dx,WORD PTR ds:[si]
     95a:	6e                   	outs   dx,BYTE PTR ds:[si]
     95b:	1d 04 69             	sbb    ax,0x6904
     95e:	09 f7                	or     di,si
     960:	00 ff                	add    bh,bh
     962:	ff f7                	push   di
     964:	00 ff                	add    bh,bh
     966:	ff 95 34 84          	call   WORD PTR [di-0x7bcc]
     96a:	09 00                	or     WORD PTR [bx+si],ax
     96c:	80 01 00             	add    BYTE PTR [bx+di],0x0
     96f:	00 00                	add    BYTE PTR [bx+si],al
     971:	1e                   	push   ds
     972:	00 0a                	add    BYTE PTR [bp+si],cl
     974:	50                   	push   ax
     975:	72 69                	jb     0x9e0
     977:	6e                   	outs   dx,BYTE PTR ds:[si]
     978:	74 53                	je     0x9cd
     97a:	63 61 6c             	arpl   WORD PTR [bx+di+0x6c],sp
     97d:	65 07                	gs pop es
     97f:	23 9f 09 8f          	and    bx,WORD PTR [bx-0x70f7]
     983:	38 88 09 ab          	cmp    BYTE PTR [bx+si-0x54f7],cl
     987:	38 8c 09 95          	cmp    BYTE PTR [si-0x6af7],cl
     98b:	34 c0                	xor    al,0xc0
     98d:	09 00                	or     WORD PTR [bx+si],ax
     98f:	80 01 00             	add    BYTE PTR [bx+di],0x0
     992:	00 00                	add    BYTE PTR [bx+si],al
     994:	1f                   	pop    ds
     995:	00 06 53 63          	add    BYTE PTR ds:0x6353,al
     999:	61                   	popa
     99a:	6c                   	ins    BYTE PTR es:[di],dx
     99b:	65 64 07             	gs fs pop es
     99e:	23 e6                	and    sp,si
     9a0:	09 48 00             	or     WORD PTR [bx+si+0x0],cx
     9a3:	ff                   	(bad)
     9a4:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     9a7:	ab                   	stos   WORD PTR es:[di],ax
     9a8:	09 23                	or     WORD PTR [bp+di],sp
     9aa:	1e                   	push   ds
     9ab:	0e                   	push   cs
     9ac:	0a 00                	or     al,BYTE PTR [bx+si]
     9ae:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9b1:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     9b5:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     9b8:	6f                   	outs   dx,WORD PTR ds:[si]
     9b9:	77 48                	ja     0xa03
     9bb:	69 6e 74 8d 00       	imul   bp,WORD PTR [bp+0x74],0x8d
     9c0:	c8 09 dc 00          	enter  0xdc09,0x0
     9c4:	ff                   	(bad)
     9c5:	ff f3                	push   bx
     9c7:	20 cc                	and    ah,cl
     9c9:	09 95 34 ee          	or     WORD PTR [di-0x11cc],dx
     9cd:	09 00                	or     WORD PTR [bx+si],ax
     9cf:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9d2:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     9d6:	0d 56 65             	or     ax,0x6556
     9d9:	72 74                	jb     0xa4f
     9db:	53                   	push   bx
     9dc:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     9df:	6c                   	ins    BYTE PTR es:[di],dx
     9e0:	6c                   	ins    BYTE PTR es:[di],dx
     9e1:	42                   	inc    dx
     9e2:	61                   	popa
     9e3:	72 07                	jb     0x9ec
     9e5:	23 06 0a 29          	and    ax,WORD PTR ds:0x290a
     9e9:	00 ff                	add    bh,bh
     9eb:	ff 19                	call   DWORD PTR [bx+di]
     9ed:	2f                   	das
     9ee:	12 0a                	adc    cl,BYTE PTR [bp+si]
     9f0:	01 00                	add    WORD PTR [bx+si],ax
     9f2:	00 00                	add    BYTE PTR [bx+si],al
     9f4:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     9f8:	00 00                	add    BYTE PTR [bx+si],al
     9fa:	21 00                	and    WORD PTR [bx+si],ax
     9fc:	07                   	pop    es
     9fd:	56                   	push   si
     9fe:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     a03:	65 d4 22             	gs aam 0x22
     a06:	2a 0d                	sub    cl,BYTE PTR [di]
     a08:	22 00                	and    al,BYTE PTR [bx+si]
     a0a:	ff                   	(bad)
     a0b:	ff                   	(bad)
     a0c:	bf 17 7e             	mov    di,0x7e17
     a0f:	0b c3                	or     ax,bx
     a11:	2c 24                	sub    al,0x24
     a13:	0a 00                	or     al,BYTE PTR [bx+si]
     a15:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a18:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     a1c:	05 57 69             	add    ax,0x6957
     a1f:	64 74 68             	fs je  0xa8a
     a22:	ef                   	out    dx,ax
     a23:	02 2c                	add    ch,BYTE PTR [si]
     a25:	0a ee                	or     ch,dh
     a27:	00 ff                	add    bh,bh
     a29:	ff 14                	call   WORD PTR [si]
     a2b:	3a 30                	cmp    dh,BYTE PTR [bx+si]
     a2d:	0a 95 34 50          	or     dl,BYTE PTR [di+0x5034]
     a31:	0a 00                	or     al,BYTE PTR [bx+si]
     a33:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a36:	00 00                	add    BYTE PTR [bx+si],al
     a38:	22 00                	and    al,BYTE PTR [bx+si]
     a3a:	0b 57 69             	or     dx,WORD PTR [bx+0x69]
     a3d:	6e                   	outs   dx,BYTE PTR ds:[si]
     a3e:	64 6f                	outs   dx,WORD PTR fs:[si]
     a40:	77 53                	ja     0xa95
     a42:	74 61                	je     0xaa5
     a44:	74 65                	je     0xaab
     a46:	da 00                	fiadd  DWORD PTR [bx+si]
     a48:	ed                   	in     ax,dx
     a49:	28 10                	sub    BYTE PTR [bx+si],dl
     a4b:	01 ff                	add    di,di
     a4d:	ff                   	(bad)
     a4e:	7a 36                	jp     0xa86
     a50:	54                   	push   sp
     a51:	0a 95 34 77          	or     dl,BYTE PTR [di+0x7734]
     a55:	0a 00                	or     al,BYTE PTR [bx+si]
     a57:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a5a:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     a5e:	0a 57 69             	or     dl,BYTE PTR [bx+0x69]
     a61:	6e                   	outs   dx,BYTE PTR ds:[si]
     a62:	64 6f                	outs   dx,WORD PTR fs:[si]
     a64:	77 4d                	ja     0xab3
     a66:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a68:	75 71                	jne    0xadb
     a6a:	00 8e 0a 2c          	add    BYTE PTR [bp+0x2c0a],cl
     a6e:	01 ff                	add    di,di
     a70:	ff 2c                	jmp    DWORD PTR [si]
     a72:	01 ff                	add    di,di
     a74:	ff 95 34 9a          	call   WORD PTR [di-0x65cc]
     a78:	0a 00                	or     al,BYTE PTR [bx+si]
     a7a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a7d:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     a81:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     a84:	41                   	inc    cx
     a85:	63 74 69             	arpl   WORD PTR [si+0x69],si
     a88:	76 61                	jbe    0xaeb
     a8a:	74 65                	je     0xaf1
     a8c:	71 00                	jno    0xa8e
     a8e:	f3 0a 7a 00          	repz or bh,BYTE PTR [bp+si+0x0]
     a92:	ff                   	(bad)
     a93:	ff                   	(bad)
     a94:	7a 00                	jp     0xa96
     a96:	ff                   	(bad)
     a97:	ff 95 34 ae          	call   WORD PTR [di-0x51cc]
     a9b:	0a 00                	or     al,BYTE PTR [bx+si]
     a9d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     aa0:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     aa4:	07                   	pop    es
     aa5:	4f                   	dec    di
     aa6:	6e                   	outs   dx,BYTE PTR ds:[si]
     aa7:	43                   	inc    bx
     aa8:	6c                   	ins    BYTE PTR es:[di],dx
     aa9:	69 63 6b 71 04       	imul   sp,WORD PTR [bp+di+0x6b],0x471
     aae:	ba 0a 34             	mov    dx,0x340a
     ab1:	01 ff                	add    di,di
     ab3:	ff 34                	push   WORD PTR [si]
     ab5:	01 ff                	add    di,di
     ab7:	ff 95 34 ce          	call   WORD PTR [di-0x31cc]
     abb:	0a 00                	or     al,BYTE PTR [bx+si]
     abd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ac0:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     ac4:	07                   	pop    es
     ac5:	4f                   	dec    di
     ac6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ac7:	43                   	inc    bx
     ac8:	6c                   	ins    BYTE PTR es:[di],dx
     ac9:	6f                   	outs   dx,WORD PTR ds:[si]
     aca:	73 65                	jae    0xb31
     acc:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     acd:	04 da                	add    al,0xda
     acf:	0a 3c                	or     bh,BYTE PTR [si]
     ad1:	01 ff                	add    di,di
     ad3:	ff                   	(bad)
     ad4:	3c 01                	cmp    al,0x1
     ad6:	ff                   	(bad)
     ad7:	ff 95 34 ff          	call   WORD PTR [di-0xcc]
     adb:	0a 00                	or     al,BYTE PTR [bx+si]
     add:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ae0:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     ae4:	0c 4f                	or     al,0x4f
     ae6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ae7:	43                   	inc    bx
     ae8:	6c                   	ins    BYTE PTR es:[di],dx
     ae9:	6f                   	outs   dx,WORD PTR ds:[si]
     aea:	73 65                	jae    0xb51
     aec:	51                   	push   cx
     aed:	75 65                	jne    0xb54
     aef:	72 79                	jb     0xb6a
     af1:	71 00                	jno    0xaf3
     af3:	14 0b                	adc    al,0xb
     af5:	6c                   	ins    BYTE PTR es:[di],dx
     af6:	01 ff                	add    di,di
     af8:	ff 6c 01             	jmp    DWORD PTR [si+0x1]
     afb:	ff                   	(bad)
     afc:	ff 95 34 20          	call   WORD PTR [di+0x2034]
     b00:	0b 00                	or     ax,WORD PTR [bx+si]
     b02:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b05:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     b09:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     b0c:	43                   	inc    bx
     b0d:	72 65                	jb     0xb74
     b0f:	61                   	popa
     b10:	74 65                	je     0xb77
     b12:	71 00                	jno    0xb14
     b14:	37                   	aaa
     b15:	0b 82 00 ff          	or     ax,WORD PTR [bp+si-0x100]
     b19:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     b1d:	ff 95 34 43          	call   WORD PTR [di+0x4334]
     b21:	0b 00                	or     ax,WORD PTR [bx+si]
     b23:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b26:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     b2a:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b2d:	44                   	inc    sp
     b2e:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     b31:	6c                   	ins    BYTE PTR es:[di],dx
     b32:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     b37:	59                   	pop    cx
     b38:	0b 74 01             	or     si,WORD PTR [si+0x1]
     b3b:	ff                   	(bad)
     b3c:	ff 74 01             	push   WORD PTR [si+0x1]
     b3f:	ff                   	(bad)
     b40:	ff 95 34 65          	call   WORD PTR [di+0x6534]
     b44:	0b 00                	or     ax,WORD PTR [bx+si]
     b46:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b49:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     b4d:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     b50:	44                   	inc    sp
     b51:	65 73 74             	gs jae 0xbc8
     b54:	72 6f                	jb     0xbc5
     b56:	79 71                	jns    0xbc9
     b58:	00 c4                	add    ah,al
     b5a:	0b 44 01             	or     ax,WORD PTR [si+0x1]
     b5d:	ff                   	(bad)
     b5e:	ff 44 01             	inc    WORD PTR [si+0x1]
     b61:	ff                   	(bad)
     b62:	ff 95 34 8a          	call   WORD PTR [di-0x75cc]
     b66:	0b 00                	or     ax,WORD PTR [bx+si]
     b68:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b6b:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     b6f:	0c 4f                	or     al,0x4f
     b71:	6e                   	outs   dx,BYTE PTR ds:[si]
     b72:	44                   	inc    sp
     b73:	65 61                	gs popa
     b75:	63 74 69             	arpl   WORD PTR [si+0x69],si
     b78:	76 61                	jbe    0xbdb
     b7a:	74 65                	je     0xbe1
     b7c:	ea 02 a1 0b 62       	jmp    0x620b:0xa102
     b81:	00 ff                	add    bh,bh
     b83:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     b86:	ff                   	(bad)
     b87:	ff 95 34 ad          	call   WORD PTR [di-0x52cc]
     b8b:	0b 00                	or     ax,WORD PTR [bx+si]
     b8d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b90:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
     b94:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b97:	44                   	inc    sp
     b98:	72 61                	jb     0xbfb
     b9a:	67 44                	addr32 inc sp
     b9c:	72 6f                	jb     0xc0d
     b9e:	70 80                	jo     0xb20
     ba0:	02 e3                	add    ah,bl
     ba2:	0b 6a 00             	or     bp,WORD PTR [bp+si+0x0]
     ba5:	ff                   	(bad)
     ba6:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     ba9:	ff                   	(bad)
     baa:	ff 95 34 d0          	call   WORD PTR [di-0x2fcc]
     bae:	0b 00                	or     ax,WORD PTR [bx+si]
     bb0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bb3:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
     bb7:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     bba:	44                   	inc    sp
     bbb:	72 61                	jb     0xc1e
     bbd:	67 4f                	addr32 dec di
     bbf:	76 65                	jbe    0xc26
     bc1:	72 71                	jb     0xc34
     bc3:	00 b2 0c 4c          	add    BYTE PTR [bp+si+0x4c0c],dh
     bc7:	01 ff                	add    di,di
     bc9:	ff 4c 01             	dec    WORD PTR [si+0x1]
     bcc:	ff                   	(bad)
     bcd:	ff 95 34 ef          	call   WORD PTR [di-0x10cc]
     bd1:	0b 00                	or     ax,WORD PTR [bx+si]
     bd3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bd6:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
     bda:	06                   	push   es
     bdb:	4f                   	dec    di
     bdc:	6e                   	outs   dx,BYTE PTR ds:[si]
     bdd:	48                   	dec    ax
     bde:	69 64 65 1a 02       	imul   sp,WORD PTR [si+0x65],0x21a
     be3:	05 0c b0             	add    ax,0xb00c
     be6:	00 ff                	add    bh,bh
     be8:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     bec:	ff 95 34 11          	call   WORD PTR [di+0x1134]
     bf0:	0c 00                	or     al,0x0
     bf2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bf5:	00 80 2f 00          	add    BYTE PTR [bx+si+0x2f],al
     bf9:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     bfc:	4b                   	dec    bx
     bfd:	65 79 44             	gs jns 0xc44
     c00:	6f                   	outs   dx,WORD PTR ds:[si]
     c01:	77 6e                	ja     0xc71
     c03:	54                   	push   sp
     c04:	02 28                	add    ch,BYTE PTR [bx+si]
     c06:	0c b8                	or     al,0xb8
     c08:	00 ff                	add    bh,bh
     c0a:	ff                   	(bad)
     c0b:	b8 00 ff             	mov    ax,0xff00
     c0e:	ff 95 34 34          	call   WORD PTR [di+0x3434]
     c12:	0c 00                	or     al,0x0
     c14:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c17:	00 80 30 00          	add    BYTE PTR [bx+si+0x30],al
     c1b:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     c1e:	4b                   	dec    bx
     c1f:	65 79 50             	gs jns 0xc72
     c22:	72 65                	jb     0xc89
     c24:	73 73                	jae    0xc99
     c26:	1a 02                	sbb    al,BYTE PTR [bp+si]
     c28:	48                   	dec    ax
     c29:	0c c0                	or     al,0xc0
     c2b:	00 ff                	add    bh,bh
     c2d:	ff c0                	inc    ax
     c2f:	00 ff                	add    bh,bh
     c31:	ff 95 34 54          	call   WORD PTR [di+0x5434]
     c35:	0c 00                	or     al,0x0
     c37:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c3a:	00 80 31 00          	add    BYTE PTR [bx+si+0x31],al
     c3e:	07                   	pop    es
     c3f:	4f                   	dec    di
     c40:	6e                   	outs   dx,BYTE PTR ds:[si]
     c41:	4b                   	dec    bx
     c42:	65 79 55             	gs jns 0xc9a
     c45:	70 71                	jo     0xcb8
     c47:	01 6c 0c             	add    WORD PTR [si+0xc],bp
     c4a:	4a                   	dec    dx
     c4b:	00 ff                	add    bh,bh
     c4d:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     c50:	ff                   	(bad)
     c51:	ff 95 34 78          	call   WORD PTR [di+0x7834]
     c55:	0c 00                	or     al,0x0
     c57:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c5a:	00 80 32 00          	add    BYTE PTR [bx+si+0x32],al
     c5e:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     c61:	4d                   	dec    bp
     c62:	6f                   	outs   dx,WORD PTR ds:[si]
     c63:	75 73                	jne    0xcd8
     c65:	65 44                	gs inc sp
     c67:	6f                   	outs   dx,WORD PTR ds:[si]
     c68:	77 6e                	ja     0xcd8
     c6a:	ce                   	into
     c6b:	01 90 0c 52          	add    WORD PTR [bx+si+0x520c],dx
     c6f:	00 ff                	add    bh,bh
     c71:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     c74:	ff                   	(bad)
     c75:	ff 95 34 9c          	call   WORD PTR [di-0x63cc]
     c79:	0c 00                	or     al,0x0
     c7b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c7e:	00 80 33 00          	add    BYTE PTR [bx+si+0x33],al
     c82:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     c85:	4d                   	dec    bp
     c86:	6f                   	outs   dx,WORD PTR ds:[si]
     c87:	75 73                	jne    0xcfc
     c89:	65 4d                	gs dec bp
     c8b:	6f                   	outs   dx,WORD PTR ds:[si]
     c8c:	76 65                	jbe    0xcf3
     c8e:	71 01                	jno    0xc91
     c90:	61                   	popa
     c91:	18 5a 00             	sbb    BYTE PTR [bp+si+0x0],bl
     c94:	ff                   	(bad)
     c95:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     c98:	ff                   	(bad)
     c99:	ff 95 34 be          	call   WORD PTR [di-0x41cc]
     c9d:	0c 00                	or     al,0x0
     c9f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ca2:	00 80 34 00          	add    BYTE PTR [bx+si+0x34],al
     ca6:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     ca9:	4d                   	dec    bp
     caa:	6f                   	outs   dx,WORD PTR ds:[si]
     cab:	75 73                	jne    0xd20
     cad:	65 55                	gs push bp
     caf:	70 71                	jo     0xd22
     cb1:	00 d2                	add    dl,dl
     cb3:	0c 54                	or     al,0x54
     cb5:	01 ff                	add    di,di
     cb7:	ff 54 01             	call   WORD PTR [si+0x1]
     cba:	ff                   	(bad)
     cbb:	ff 95 34 de          	call   WORD PTR [di-0x21cc]
     cbf:	0c 00                	or     al,0x0
     cc1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     cc4:	00 80 35 00          	add    BYTE PTR [bx+si+0x35],al
     cc8:	07                   	pop    es
     cc9:	4f                   	dec    di
     cca:	6e                   	outs   dx,BYTE PTR ds:[si]
     ccb:	50                   	push   ax
     ccc:	61                   	popa
     ccd:	69 6e 74 71 00       	imul   bp,WORD PTR [bp+0x74],0x71
     cd2:	f3 0c 5c             	repz or al,0x5c
     cd5:	01 ff                	add    di,di
     cd7:	ff 5c 01             	call   DWORD PTR [si+0x1]
     cda:	ff                   	(bad)
     cdb:	ff 95 34 ff          	call   WORD PTR [di-0xcc]
     cdf:	0c 00                	or     al,0x0
     ce1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ce4:	00 80 36 00          	add    BYTE PTR [bx+si+0x36],al
     ce8:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     ceb:	52                   	push   dx
     cec:	65 73 69             	gs jae 0xd58
     cef:	7a 65                	jp     0xd56
     cf1:	71 00                	jno    0xcf3
     cf3:	36 0d 64 01          	ss or  ax,0x164
     cf7:	ff                   	(bad)
     cf8:	ff 64 01             	jmp    WORD PTR [si+0x1]
     cfb:	ff                   	(bad)
     cfc:	ff 95 34 5e          	call   WORD PTR [di+0x5e34]
     d00:	0d 00 80             	or     ax,0x8000
     d03:	00 00                	add    BYTE PTR [bx+si],al
     d05:	00 80 37 00          	add    BYTE PTR [bx+si+0x37],al
     d09:	06                   	push   es
     d0a:	4f                   	dec    di
     d0b:	6e                   	outs   dx,BYTE PTR ds:[si]
     d0c:	53                   	push   bx
     d0d:	68 6f 77             	push   0x776f
     d10:	68 0d 00             	push   0xd
     d13:	00 00                	add    BYTE PTR [bx+si],al
     d15:	00 00                	add    BYTE PTR [bx+si],al
     d17:	00 60 0d             	add    BYTE PTR [bx+si+0xd],ah
     d1a:	50                   	push   ax
     d1b:	00 da                	add    dl,bl
     d1d:	05 77 0d             	add    ax,0xd77
     d20:	64 20 9d 0d 9a       	and    BYTE PTR fs:[di-0x65f3],bl
     d25:	1f                   	pop    ds
     d26:	22 0d                	and    cl,BYTE PTR [di]
     d28:	cb                   	retf
     d29:	1f                   	pop    ds
     d2a:	26 0d 60 60          	es or  ax,0x6060
     d2e:	73 0d                	jae    0xd3d
     d30:	cd 11                	int    0x11
     d32:	3a 0d                	cmp    cl,BYTE PTR [di]
     d34:	6e                   	outs   dx,BYTE PTR ds:[si]
     d35:	4f                   	dec    di
     d36:	3e 0d fa 10          	ds or  ax,0x10fa
     d3a:	1e                   	push   ds
     d3b:	0d e5 4f             	or     ax,0x4fe5
     d3e:	42                   	inc    dx
     d3f:	0d f4 4f             	or     ax,0x4ff4
     d42:	46                   	inc    si
     d43:	0d 05 4f             	or     ax,0x4f05
     d46:	4a                   	dec    dx
     d47:	0d 03 50             	or     ax,0x5003
     d4a:	4e                   	dec    si
     d4b:	0d 46 51             	or     ax,0x5146
     d4e:	52                   	push   dx
     d4f:	0d 38 50             	or     ax,0x5038
     d52:	56                   	push   si
     d53:	0d 1a 50             	or     ax,0x501a
     d56:	5a                   	pop    dx
     d57:	0d 21 50             	or     ax,0x5021
     d5a:	32 0d                	xor    cl,BYTE PTR [di]
     d5c:	80 5f 2e 0d          	sbb    BYTE PTR [bx+0x2e],0xd
     d60:	07                   	pop    es
     d61:	54                   	push   sp
     d62:	53                   	push   bx
     d63:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
     d66:	65 6e                	outs   dx,BYTE PTR gs:[si]
     d68:	07                   	pop    es
     d69:	07                   	pop    es
     d6a:	54                   	push   sp
     d6b:	53                   	push   bx
     d6c:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
     d6f:	65 6e                	outs   dx,BYTE PTR gs:[si]
     d71:	30 0d                	xor    BYTE PTR [di],cl
     d73:	c9                   	leave
     d74:	0d 15 06             	or     ax,0x615
     d77:	a9 0d 02             	test   ax,0x20d
     d7a:	00 05                	add    BYTE PTR [di],al
     d7c:	46                   	inc    si
     d7d:	6f                   	outs   dx,WORD PTR ds:[si]
     d7e:	72 6d                	jb     0xded
     d80:	73 00                	jae    0xd82
     d82:	00 e0                	add    al,ah
     d84:	0d 00 00             	or     ax,0x0
     d87:	00 00                	add    BYTE PTR [bx+si],al
     d89:	00 00                	add    BYTE PTR [bx+si],al
     d8b:	d3 0d                	ror    WORD PTR [di],cl
     d8d:	b5 00                	mov    ch,0x0
     d8f:	da 05                	fiadd  DWORD PTR [di]
     d91:	f4                   	hlt
     d92:	0d 64 20             	or     ax,0x2064
     d95:	8a 0e 9a 1f          	mov    cl,BYTE PTR ds:0x1f9a
     d99:	95                   	xchg   bp,ax
     d9a:	0d cb 1f             	or     ax,0x1fcb
     d9d:	99                   	cwd
     d9e:	0d ef 66             	or     ax,0x66ef
     da1:	f0 0d cd 11          	lock or ax,0x11cd
     da5:	ad                   	lods   ax,WORD PTR ds:[si]
     da6:	0d 6e 4f             	or     ax,0x4f6e
     da9:	b1 0d                	mov    cl,0xd
     dab:	fa                   	cli
     dac:	10 91 0d e5          	adc    BYTE PTR [bx+di-0x1af3],dl
     db0:	4f                   	dec    di
     db1:	b5 0d                	mov    ch,0xd
     db3:	f4                   	hlt
     db4:	4f                   	dec    di
     db5:	b9 0d 05             	mov    cx,0x50d
     db8:	4f                   	dec    di
     db9:	bd 0d 03             	mov    bp,0x30d
     dbc:	50                   	push   ax
     dbd:	c1 0d 46             	ror    WORD PTR [di],0x46
     dc0:	51                   	push   cx
     dc1:	c5 0d                	lds    cx,DWORD PTR [di]
     dc3:	38 50 cd             	cmp    BYTE PTR [bx+si-0x33],dl
     dc6:	0d ec 80             	or     ax,0x80ec
     dc9:	d1 0d                	ror    WORD PTR [di],1
     dcb:	21 50 a5             	and    WORD PTR [bx+si-0x5b],dx
     dce:	0d 55 64             	or     ax,0x6455
     dd1:	a1 0d 0c             	mov    ax,ds:0xc0d
     dd4:	54                   	push   sp
     dd5:	41                   	inc    cx
     dd6:	70 70                	jo     0xe48
     dd8:	6c                   	ins    BYTE PTR es:[di],dx
     dd9:	69 63 61 74 69       	imul   sp,WORD PTR [bp+di+0x61],0x6974
     dde:	6f                   	outs   dx,WORD PTR ds:[si]
     ddf:	6e                   	outs   dx,BYTE PTR ds:[si]
     de0:	07                   	pop    es
     de1:	0c 54                	or     al,0x54
     de3:	41                   	inc    cx
     de4:	70 70                	jo     0xe56
     de6:	6c                   	ins    BYTE PTR es:[di],dx
     de7:	69 63 61 74 69       	imul   sp,WORD PTR [bp+di+0x61],0x6974
     dec:	6f                   	outs   dx,WORD PTR ds:[si]
     ded:	6e                   	outs   dx,BYTE PTR ds:[si]
     dee:	a3 0d df             	mov    ds:0xdf0d,ax
     df1:	0e                   	push   cs
     df2:	15 06 47             	adc    ax,0x4706
     df5:	0e                   	push   cs
     df6:	02 00                	add    al,BYTE PTR [bx+si]
     df8:	05 46 6f             	add    ax,0x6f46
     dfb:	72 6d                	jb     0xe6a
     dfd:	73 00                	jae    0xdff
     dff:	00 c8                	add    al,cl
     e01:	02 00                	add    al,BYTE PTR [bx+si]
     e03:	00 8b 46 06          	add    BYTE PTR [bp+di+0x646],cl
     e07:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     e0a:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     e0d:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     e10:	7e 06                	jle    0xe18
     e12:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     e15:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     e18:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e1b:	c9                   	leave
     e1c:	c2 04 00             	ret    0x4
     e1f:	c8 04 00 00          	enter  0x4,0x0
     e23:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     e27:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     e2a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     e2d:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
     e32:	74 0b                	je     0xe3f
     e34:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     e38:	6a 00                	push   0x0
     e3a:	9a ff ff 00 00       	call   0x0:0xffff
     e3f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e42:	06                   	push   es
     e43:	57                   	push   di
     e44:	9a a5 4e 51 0e       	call   0xe51:0x4ea5
     e49:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e4c:	06                   	push   es
     e4d:	57                   	push   di
     e4e:	9a 5e 4e 35 18       	call   0x1835:0x4e5e
     e53:	c9                   	leave
     e54:	cb                   	retf
     e55:	8c d0                	mov    ax,ss
     e57:	90                   	nop
     e58:	45                   	inc    bp
     e59:	55                   	push   bp
     e5a:	89 e5                	mov    bp,sp
     e5c:	1e                   	push   ds
     e5d:	8e d8                	mov    ds,ax
     e5f:	83 ec 06             	sub    sp,0x6
     e62:	56                   	push   si
     e63:	57                   	push   di
     e64:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     e67:	3b 06 44 15          	cmp    ax,WORD PTR ds:0x1544
     e6b:	74 57                	je     0xec4
     e6d:	ff 76 0a             	push   WORD PTR [bp+0xa]
     e70:	9a ac 10 00 00       	call   0x0:0x10ac
     e75:	09 c0                	or     ax,ax
     e77:	74 4b                	je     0xec4
     e79:	ff 76 0a             	push   WORD PTR [bp+0xa]
     e7c:	9a b8 10 00 00       	call   0x0:0x10b8
     e81:	09 c0                	or     ax,ax
     e83:	74 3f                	je     0xec4
     e85:	6a 06                	push   0x6
     e87:	9a 82 01 b4 0f       	call   0xfb4:0x182
     e8c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     e8f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     e92:	a1 4a 15             	mov    ax,ds:0x154a
     e95:	8b 16 4c 15          	mov    dx,WORD PTR ds:0x154c
     e99:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e9c:	26 89 05             	mov    WORD PTR es:[di],ax
     e9f:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     ea3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ea6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     ea9:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     ead:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     eb0:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     eb3:	a3 4a 15             	mov    ds:0x154a,ax
     eb6:	89 16 4c 15          	mov    WORD PTR ds:0x154c,dx
     eba:	ff 76 0a             	push   WORD PTR [bp+0xa]
     ebd:	6a 00                	push   0x0
     ebf:	9a 5c 10 00 00       	call   0x0:0x105c
     ec4:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
     ec9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     ecc:	5f                   	pop    di
     ecd:	5e                   	pop    si
     ece:	8d 66 fe             	lea    sp,[bp-0x2]
     ed1:	1f                   	pop    ds
     ed2:	5d                   	pop    bp
     ed3:	4d                   	dec    bp
     ed4:	ca 06 00             	retf   0x6
     ed7:	01 00                	add    WORD PTR [bx+si],ax
     ed9:	00 00                	add    BYTE PTR [bx+si],al
     edb:	00 00                	add    BYTE PTR [bx+si],al
     edd:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     ede:	0f e5 0e 00 00       	pmulhw mm1,QWORD PTR ds:0x0
     ee3:	c7                   	(bad)
     ee4:	0f 4a 0f             	cmovp  cx,WORD PTR [bx]
     ee7:	c8 0e 00 00          	enter  0xe,0x0
     eeb:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     eef:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
     ef3:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
     ef7:	74 2c                	je     0xf25
     ef9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     efd:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
     f01:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
     f06:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
     f0b:	74 18                	je     0xf25
     f0d:	6a 01                	push   0x1
     f0f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     f13:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
     f17:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
     f1c:	06                   	push   es
     f1d:	57                   	push   di
     f1e:	26 c4 3d             	les    di,DWORD PTR es:[di]
     f21:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
     f25:	a1 44 15             	mov    ax,ds:0x1544
     f28:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     f2b:	a1 4a 15             	mov    ax,ds:0x154a
     f2e:	8b 16 4c 15          	mov    dx,WORD PTR ds:0x154c
     f32:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     f35:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
     f38:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     f3b:	a3 44 15             	mov    ds:0x1544,ax
     f3e:	31 c0                	xor    ax,ax
     f40:	a3 4a 15             	mov    ds:0x154a,ax
     f43:	a3 4c 15             	mov    ds:0x154c,ax
     f46:	bf 55 0e             	mov    di,0xe55
     f49:	b8 af 0f             	mov    ax,0xfaf
     f4c:	50                   	push   ax
     f4d:	57                   	push   di
     f4e:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     f52:	9a 2b 11 00 00       	call   0x0:0x112b
     f57:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     f5a:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     f5d:	b8 e1 0e             	mov    ax,0xee1
     f60:	0e                   	push   cs
     f61:	50                   	push   ax
     f62:	55                   	push   bp
     f63:	ff 36 58 18          	push   WORD PTR ds:0x1858
     f67:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     f6b:	b8 d7 0e             	mov    ax,0xed7
     f6e:	0e                   	push   cs
     f6f:	50                   	push   ax
     f70:	55                   	push   bp
     f71:	ff 36 58 18          	push   WORD PTR ds:0x1858
     f75:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     f79:	9a 44 11 00 00       	call   0x0:0x1144
     f7e:	50                   	push   ax
     f7f:	ff 76 f4             	push   WORD PTR [bp-0xc]
     f82:	ff 76 f2             	push   WORD PTR [bp-0xe]
     f85:	6a 00                	push   0x0
     f87:	6a 00                	push   0x0
     f89:	9a 54 11 00 00       	call   0x0:0x1154
     f8e:	a1 4a 15             	mov    ax,ds:0x154a
     f91:	8b 16 4c 15          	mov    dx,WORD PTR ds:0x154c
     f95:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f98:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f9b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     f9f:	83 c4 06             	add    sp,0x6
     fa2:	eb 17                	jmp    0xfbb
     fa4:	ff 36 4c 15          	push   WORD PTR ds:0x154c
     fa8:	ff 36 4a 15          	push   WORD PTR ds:0x154a
     fac:	9a f0 0f 08 11       	call   0x1108:0xff0
     fb1:	ea 85 13 b9 0f       	jmp    0xfb9:0x1385
     fb6:	9a 34 14 7b 10       	call   0x107b:0x1434
     fbb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     fbf:	83 c4 06             	add    sp,0x6
     fc2:	b8 e6 0f             	mov    ax,0xfe6
     fc5:	0e                   	push   cs
     fc6:	50                   	push   ax
     fc7:	ff 76 f4             	push   WORD PTR [bp-0xc]
     fca:	ff 76 f2             	push   WORD PTR [bp-0xe]
     fcd:	9a 6b 11 00 00       	call   0x0:0x116b
     fd2:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     fd5:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
     fd8:	a3 4a 15             	mov    ds:0x154a,ax
     fdb:	89 16 4c 15          	mov    WORD PTR ds:0x154c,dx
     fdf:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     fe2:	a3 44 15             	mov    ds:0x1544,ax
     fe5:	cb                   	retf
     fe6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     fe9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     fec:	c9                   	leave
     fed:	ca 02 00             	retf   0x2
     ff0:	c8 04 00 00          	enter  0x4,0x0
     ff4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     ff8:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
     ffc:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    1000:	74 2c                	je     0x102e
    1002:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1006:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    100a:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    100f:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    1014:	74 18                	je     0x102e
    1016:	6a 00                	push   0x0
    1018:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    101c:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    1020:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    1025:	06                   	push   es
    1026:	57                   	push   di
    1027:	26 c4 3d             	les    di,DWORD PTR es:[di]
    102a:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    102e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1031:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    1034:	74 49                	je     0x107f
    1036:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1039:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    103c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    103f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1042:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1045:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1049:	9a ff ff 00 00       	call   0x0:0xffff
    104e:	09 c0                	or     ax,ax
    1050:	74 0e                	je     0x1060
    1052:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1055:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1059:	6a 01                	push   0x1
    105b:	9a ff ff 00 00       	call   0x0:0xffff
    1060:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1063:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1066:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    106a:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    106d:	89 56 08             	mov    WORD PTR [bp+0x8],dx
    1070:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1073:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1076:	6a 06                	push   0x6
    1078:	9a 9c 01 cf 14       	call   0x14cf:0x19c
    107d:	eb af                	jmp    0x102e
    107f:	c9                   	leave
    1080:	ca 04 00             	retf   0x4
    1083:	8c d0                	mov    ax,ss
    1085:	90                   	nop
    1086:	45                   	inc    bp
    1087:	55                   	push   bp
    1088:	89 e5                	mov    bp,sp
    108a:	1e                   	push   ds
    108b:	8e d8                	mov    ds,ax
    108d:	83 ec 02             	sub    sp,0x2
    1090:	56                   	push   si
    1091:	57                   	push   di
    1092:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1095:	3b 06 44 15          	cmp    ax,WORD PTR ds:0x1544
    1099:	74 56                	je     0x10f1
    109b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    109e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    10a2:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
    10a6:	74 49                	je     0x10f1
    10a8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10ab:	9a 6f 57 00 00       	call   0x0:0x576f
    10b0:	09 c0                	or     ax,ax
    10b2:	74 3d                	je     0x10f1
    10b4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10b7:	9a 04 6d 00 00       	call   0x0:0x6d04
    10bc:	09 c0                	or     ax,ax
    10be:	74 31                	je     0x10f1
    10c0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10c3:	6a ec                	push   0xffec
    10c5:	9a 76 16 00 00       	call   0x0:0x1676
    10ca:	25 08 00             	and    ax,0x8
    10cd:	81 e2 00 00          	and    dx,0x0
    10d1:	09 d0                	or     ax,dx
    10d3:	75 0f                	jne    0x10e4
    10d5:	83 3e 46 15 00       	cmp    WORD PTR ds:0x1546,0x0
    10da:	75 06                	jne    0x10e2
    10dc:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10df:	a3 46 15             	mov    ds:0x1546,ax
    10e2:	eb 0d                	jmp    0x10f1
    10e4:	83 3e 48 15 00       	cmp    WORD PTR ds:0x1548,0x0
    10e9:	75 06                	jne    0x10f1
    10eb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10ee:	a3 48 15             	mov    ds:0x1548,ax
    10f1:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    10f6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    10f9:	5f                   	pop    di
    10fa:	5e                   	pop    si
    10fb:	8d 66 fe             	lea    sp,[bp-0x2]
    10fe:	1f                   	pop    ds
    10ff:	5d                   	pop    bp
    1100:	4d                   	dec    bp
    1101:	ca 06 00             	retf   0x6
    1104:	00 00                	add    BYTE PTR [bx+si],al
    1106:	64 11 22             	adc    WORD PTR fs:[bp+si],sp
    1109:	11 c8                	adc    ax,cx
    110b:	06                   	push   es
    110c:	00 00                	add    BYTE PTR [bx+si],al
    110e:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    1111:	a3 44 15             	mov    ds:0x1544,ax
    1114:	31 c0                	xor    ax,ax
    1116:	a3 46 15             	mov    ds:0x1546,ax
    1119:	31 c0                	xor    ax,ax
    111b:	a3 48 15             	mov    ds:0x1548,ax
    111e:	bf 83 10             	mov    di,0x1083
    1121:	b8 fa 11             	mov    ax,0x11fa
    1124:	50                   	push   ax
    1125:	57                   	push   di
    1126:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    112a:	9a 19 12 00 00       	call   0x0:0x1219
    112f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1132:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1135:	b8 04 11             	mov    ax,0x1104
    1138:	0e                   	push   cs
    1139:	50                   	push   ax
    113a:	55                   	push   bp
    113b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    113f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1143:	9a 32 12 00 00       	call   0x0:0x1232
    1148:	50                   	push   ax
    1149:	ff 76 fc             	push   WORD PTR [bp-0x4]
    114c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    114f:	6a 00                	push   0x0
    1151:	6a 00                	push   0x0
    1153:	9a 43 12 00 00       	call   0x0:0x1243
    1158:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    115c:	83 c4 06             	add    sp,0x6
    115f:	b8 70 11             	mov    ax,0x1170
    1162:	0e                   	push   cs
    1163:	50                   	push   ax
    1164:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1167:	ff 76 fa             	push   WORD PTR [bp-0x6]
    116a:	9a 5a 12 00 00       	call   0x0:0x125a
    116f:	cb                   	retf
    1170:	83 3e 46 15 00       	cmp    WORD PTR ds:0x1546,0x0
    1175:	74 08                	je     0x117f
    1177:	a1 46 15             	mov    ax,ds:0x1546
    117a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    117d:	eb 06                	jmp    0x1185
    117f:	a1 48 15             	mov    ax,ds:0x1548
    1182:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1185:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1188:	c9                   	leave
    1189:	c2 02 00             	ret    0x2
    118c:	c8 04 00 00          	enter  0x4,0x0
    1190:	a1 34 15             	mov    ax,ds:0x1534
    1193:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1196:	ff 76 06             	push   WORD PTR [bp+0x6]
    1199:	ff 76 04             	push   WORD PTR [bp+0x4]
    119c:	6a 00                	push   0x0
    119e:	6a 00                	push   0x0
    11a0:	6a 00                	push   0x0
    11a2:	9a dc 32 00 00       	call   0x0:0x32dc
    11a7:	a1 34 15             	mov    ax,ds:0x1534
    11aa:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    11ad:	b0 00                	mov    al,0x0
    11af:	75 01                	jne    0x11b2
    11b1:	40                   	inc    ax
    11b2:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    11b5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    11b8:	c9                   	leave
    11b9:	c2 04 00             	ret    0x4
    11bc:	8c d0                	mov    ax,ss
    11be:	90                   	nop
    11bf:	45                   	inc    bp
    11c0:	55                   	push   bp
    11c1:	89 e5                	mov    bp,sp
    11c3:	1e                   	push   ds
    11c4:	8e d8                	mov    ds,ax
    11c6:	83 ec 02             	sub    sp,0x2
    11c9:	56                   	push   si
    11ca:	57                   	push   di
    11cb:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    11d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11d3:	26 8b 05             	mov    ax,WORD PTR es:[di]
    11d6:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    11d9:	75 0d                	jne    0x11e8
    11db:	31 c0                	xor    ax,ax
    11dd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    11e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e3:	26 c6 45 02 01       	mov    BYTE PTR es:[di+0x2],0x1
    11e8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    11eb:	5f                   	pop    di
    11ec:	5e                   	pop    si
    11ed:	8d 66 fe             	lea    sp,[bp-0x2]
    11f0:	1f                   	pop    ds
    11f1:	5d                   	pop    bp
    11f2:	4d                   	dec    bp
    11f3:	ca 06 00             	retf   0x6
    11f6:	00 00                	add    BYTE PTR [bx+si],al
    11f8:	53                   	push   bx
    11f9:	12 10                	adc    dl,BYTE PTR [bx+si]
    11fb:	12 c8                	adc    cl,al
    11fd:	08 00                	or     BYTE PTR [bx+si],al
    11ff:	00 9a ea 4b          	add    BYTE PTR [bp+si+0x4bea],bl
    1203:	00 00                	add    BYTE PTR [bx+si],al
    1205:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1208:	c6 46 fe 00          	mov    BYTE PTR [bp-0x2],0x0
    120c:	bf bc 11             	mov    di,0x11bc
    120f:	b8 d5 14             	mov    ax,0x14d5
    1212:	50                   	push   ax
    1213:	57                   	push   di
    1214:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1218:	9a fc 5f 00 00       	call   0x0:0x5ffc
    121d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1220:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1223:	b8 f6 11             	mov    ax,0x11f6
    1226:	0e                   	push   cs
    1227:	50                   	push   ax
    1228:	55                   	push   bp
    1229:	ff 36 58 18          	push   WORD PTR ds:0x1858
    122d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1231:	9a ff ff 00 00       	call   0x0:0xffff
    1236:	50                   	push   ax
    1237:	ff 76 fa             	push   WORD PTR [bp-0x6]
    123a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    123d:	8d 7e fc             	lea    di,[bp-0x4]
    1240:	16                   	push   ss
    1241:	57                   	push   di
    1242:	9a ff ff 00 00       	call   0x0:0xffff
    1247:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    124b:	83 c4 06             	add    sp,0x6
    124e:	b8 5f 12             	mov    ax,0x125f
    1251:	0e                   	push   cs
    1252:	50                   	push   ax
    1253:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1256:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1259:	9a 2a 60 00 00       	call   0x0:0x602a
    125e:	cb                   	retf
    125f:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    1262:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1265:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1268:	c9                   	leave
    1269:	c3                   	ret
    126a:	c8 06 00 00          	enter  0x6,0x0
    126e:	83 3e 4e 15 00       	cmp    WORD PTR ds:0x154e,0x0
    1273:	74 03                	je     0x1278
    1275:	e9 56 01             	jmp    0x13ce
    1278:	9a ff ff 00 00       	call   0x0:0xffff
    127d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1280:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1283:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1286:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1289:	58                   	pop    ax
    128a:	5a                   	pop    dx
    128b:	50                   	push   ax
    128c:	58                   	pop    ax
    128d:	32 e4                	xor    ah,ah
    128f:	3c 04                	cmp    al,0x4
    1291:	73 32                	jae    0x12c5
    1293:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1296:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1299:	58                   	pop    ax
    129a:	5a                   	pop    dx
    129b:	50                   	push   ax
    129c:	58                   	pop    ax
    129d:	8a c4                	mov    al,ah
    129f:	32 e4                	xor    ah,ah
    12a1:	3c 59                	cmp    al,0x59
    12a3:	73 20                	jae    0x12c5
    12a5:	68 00 80             	push   0x8000
    12a8:	9a c1 12 00 00       	call   0x0:0x12c1
    12ad:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    12b0:	bf 50 15             	mov    di,0x1550
    12b3:	1e                   	push   ds
    12b4:	57                   	push   di
    12b5:	9a ff ff 00 00       	call   0x0:0xffff
    12ba:	a3 4e 15             	mov    ds:0x154e,ax
    12bd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    12c0:	9a ff ff 00 00       	call   0x0:0xffff
    12c5:	83 3e 4e 15 20       	cmp    WORD PTR ds:0x154e,0x20
    12ca:	73 06                	jae    0x12d2
    12cc:	c7 06 4e 15 01 00    	mov    WORD PTR ds:0x154e,0x1
    12d2:	83 3e 4e 15 20       	cmp    WORD PTR ds:0x154e,0x20
    12d7:	73 03                	jae    0x12dc
    12d9:	e9 f2 00             	jmp    0x13ce
    12dc:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    12e0:	bf 5c 15             	mov    di,0x155c
    12e3:	1e                   	push   ds
    12e4:	57                   	push   di
    12e5:	9a 0a 13 00 00       	call   0x0:0x130a
    12ea:	a3 32 2c             	mov    ds:0x2c32,ax
    12ed:	89 16 34 2c          	mov    WORD PTR ds:0x2c34,dx
    12f1:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    12f5:	ff 1e 32 2c          	call   DWORD PTR ds:0x2c32
    12f9:	09 c0                	or     ax,ax
    12fb:	75 03                	jne    0x1300
    12fd:	e9 bf 00             	jmp    0x13bf
    1300:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    1304:	bf 6a 15             	mov    di,0x156a
    1307:	1e                   	push   ds
    1308:	57                   	push   di
    1309:	9a 1f 13 00 00       	call   0x0:0x131f
    130e:	a3 36 2c             	mov    ds:0x2c36,ax
    1311:	89 16 38 2c          	mov    WORD PTR ds:0x2c38,dx
    1315:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    1319:	bf 7a 15             	mov    di,0x157a
    131c:	1e                   	push   ds
    131d:	57                   	push   di
    131e:	9a 34 13 00 00       	call   0x0:0x1334
    1323:	a3 3a 2c             	mov    ds:0x2c3a,ax
    1326:	89 16 3c 2c          	mov    WORD PTR ds:0x2c3c,dx
    132a:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    132e:	bf 8b 15             	mov    di,0x158b
    1331:	1e                   	push   ds
    1332:	57                   	push   di
    1333:	9a 49 13 00 00       	call   0x0:0x1349
    1338:	a3 3e 2c             	mov    ds:0x2c3e,ax
    133b:	89 16 40 2c          	mov    WORD PTR ds:0x2c40,dx
    133f:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    1343:	bf 9c 15             	mov    di,0x159c
    1346:	1e                   	push   ds
    1347:	57                   	push   di
    1348:	9a 5e 13 00 00       	call   0x0:0x135e
    134d:	a3 26 15             	mov    ds:0x1526,ax
    1350:	89 16 28 15          	mov    WORD PTR ds:0x1528,dx
    1354:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    1358:	bf af 15             	mov    di,0x15af
    135b:	1e                   	push   ds
    135c:	57                   	push   di
    135d:	9a 73 13 00 00       	call   0x0:0x1373
    1362:	a3 2a 15             	mov    ds:0x152a,ax
    1365:	89 16 2c 15          	mov    WORD PTR ds:0x152c,dx
    1369:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    136d:	bf bf 15             	mov    di,0x15bf
    1370:	1e                   	push   ds
    1371:	57                   	push   di
    1372:	9a 88 13 00 00       	call   0x0:0x1388
    1377:	a3 42 2c             	mov    ds:0x2c42,ax
    137a:	89 16 44 2c          	mov    WORD PTR ds:0x2c44,dx
    137e:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    1382:	bf d1 15             	mov    di,0x15d1
    1385:	1e                   	push   ds
    1386:	57                   	push   di
    1387:	9a 9d 13 00 00       	call   0x0:0x139d
    138c:	a3 46 2c             	mov    ds:0x2c46,ax
    138f:	89 16 48 2c          	mov    WORD PTR ds:0x2c48,dx
    1393:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    1397:	bf e5 15             	mov    di,0x15e5
    139a:	1e                   	push   ds
    139b:	57                   	push   di
    139c:	9a b2 13 00 00       	call   0x0:0x13b2
    13a1:	a3 4a 2c             	mov    ds:0x2c4a,ax
    13a4:	89 16 4c 2c          	mov    WORD PTR ds:0x2c4c,dx
    13a8:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    13ac:	bf f6 15             	mov    di,0x15f6
    13af:	1e                   	push   ds
    13b0:	57                   	push   di
    13b1:	9a ff ff 00 00       	call   0x0:0xffff
    13b6:	a3 22 15             	mov    ds:0x1522,ax
    13b9:	89 16 24 15          	mov    WORD PTR ds:0x1524,dx
    13bd:	eb 0f                	jmp    0x13ce
    13bf:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    13c3:	9a e7 13 00 00       	call   0x0:0x13e7
    13c8:	c7 06 4e 15 01 00    	mov    WORD PTR ds:0x154e,0x1
    13ce:	c9                   	leave
    13cf:	c3                   	ret
    13d0:	55                   	push   bp
    13d1:	89 e5                	mov    bp,sp
    13d3:	83 3e 4e 15 20       	cmp    WORD PTR ds:0x154e,0x20
    13d8:	72 11                	jb     0x13eb
    13da:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    13de:	ff 1e 36 2c          	call   DWORD PTR ds:0x2c36
    13e2:	ff 36 4e 15          	push   WORD PTR ds:0x154e
    13e6:	9a ff ff 00 00       	call   0x0:0xffff
    13eb:	c9                   	leave
    13ec:	cb                   	retf
    13ed:	55                   	push   bp
    13ee:	89 e5                	mov    bp,sp
    13f0:	83 3e 4e 15 00       	cmp    WORD PTR ds:0x154e,0x0
    13f5:	75 03                	jne    0x13fa
    13f7:	e8 70 fe             	call   0x126a
    13fa:	83 3e 4e 15 20       	cmp    WORD PTR ds:0x154e,0x20
    13ff:	72 0a                	jb     0x140b
    1401:	ff 76 08             	push   WORD PTR [bp+0x8]
    1404:	ff 76 06             	push   WORD PTR [bp+0x6]
    1407:	ff 1e 3e 2c          	call   DWORD PTR ds:0x2c3e
    140b:	c9                   	leave
    140c:	ca 04 00             	retf   0x4
    140f:	55                   	push   bp
    1410:	89 e5                	mov    bp,sp
    1412:	83 3e 4e 15 00       	cmp    WORD PTR ds:0x154e,0x0
    1417:	75 03                	jne    0x141c
    1419:	e8 4e fe             	call   0x126a
    141c:	83 3e 4e 15 20       	cmp    WORD PTR ds:0x154e,0x20
    1421:	72 2a                	jb     0x144d
    1423:	a1 42 2c             	mov    ax,ds:0x2c42
    1426:	0b 06 44 2c          	or     ax,WORD PTR ds:0x2c44
    142a:	74 09                	je     0x1435
    142c:	a1 46 2c             	mov    ax,ds:0x2c46
    142f:	0b 06 48 2c          	or     ax,WORD PTR ds:0x2c48
    1433:	75 04                	jne    0x1439
    1435:	eb 16                	jmp    0x144d
    1437:	eb 14                	jmp    0x144d
    1439:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    143d:	74 0a                	je     0x1449
    143f:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1443:	ff 1e 42 2c          	call   DWORD PTR ds:0x2c42
    1447:	eb 04                	jmp    0x144d
    1449:	ff 1e 46 2c          	call   DWORD PTR ds:0x2c46
    144d:	c9                   	leave
    144e:	ca 02 00             	retf   0x2
    1451:	8c d0                	mov    ax,ss
    1453:	90                   	nop
    1454:	45                   	inc    bp
    1455:	55                   	push   bp
    1456:	89 e5                	mov    bp,sp
    1458:	1e                   	push   ds
    1459:	8e d8                	mov    ds,ax
    145b:	56                   	push   si
    145c:	57                   	push   di
    145d:	31 c0                	xor    ax,ax
    145f:	50                   	push   ax
    1460:	50                   	push   ax
    1461:	ff 76 08             	push   WORD PTR [bp+0x8]
    1464:	ff 76 06             	push   WORD PTR [bp+0x6]
    1467:	ff 76 0a             	push   WORD PTR [bp+0xa]
    146a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    146d:	89 e0                	mov    ax,sp
    146f:	16                   	push   ss
    1470:	50                   	push   ax
    1471:	26 ff 77 06          	push   WORD PTR es:[bx+0x6]
    1475:	26 ff 77 04          	push   WORD PTR es:[bx+0x4]
    1479:	26 ff 1f             	call   DWORD PTR es:[bx]
    147c:	83 c4 08             	add    sp,0x8
    147f:	58                   	pop    ax
    1480:	5a                   	pop    dx
    1481:	5f                   	pop    di
    1482:	5e                   	pop    si
    1483:	1f                   	pop    ds
    1484:	5d                   	pop    bp
    1485:	4d                   	dec    bp
    1486:	ca 0a 00             	retf   0xa
    1489:	c8 0c 00 00          	enter  0xc,0x0
    148d:	a1 50 2c             	mov    ax,ds:0x2c50
    1490:	0b 06 52 2c          	or     ax,WORD PTR ds:0x2c52
    1494:	74 03                	je     0x1499
    1496:	e9 b4 00             	jmp    0x154d
    1499:	ff 36 9a 18          	push   WORD PTR ds:0x189a
    149d:	6a 00                	push   0x0
    149f:	68 00 04             	push   0x400
    14a2:	9a ff ff 00 00       	call   0x0:0xffff
    14a7:	50                   	push   ax
    14a8:	9a ff ff 00 00       	call   0x0:0xffff
    14ad:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    14b0:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    14b3:	a1 4e 2c             	mov    ax,ds:0x2c4e
    14b6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14b9:	26 89 05             	mov    WORD PTR es:[di],ax
    14bc:	bf 04 16             	mov    di,0x1604
    14bf:	1e                   	push   ds
    14c0:	57                   	push   di
    14c1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14c4:	81 c7 02 00          	add    di,0x2
    14c8:	06                   	push   es
    14c9:	57                   	push   di
    14ca:	6a 06                	push   0x6
    14cc:	9a c1 1e 91 15       	call   0x1591:0x1ec1
    14d1:	b8 51 14             	mov    ax,0x1451
    14d4:	ba 5c 16             	mov    dx,0x165c
    14d7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14da:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    14de:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    14e2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14e5:	26 8d 45 0c          	lea    ax,es:[di+0xc]
    14e9:	8c c2                	mov    dx,es
    14eb:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    14ee:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    14f1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    14f4:	26 c6 05 e8          	mov    BYTE PTR es:[di],0xe8
    14f8:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    14fb:	31 d2                	xor    dx,dx
    14fd:	8b c8                	mov    cx,ax
    14ff:	8b da                	mov    bx,dx
    1501:	b8 ff ff             	mov    ax,0xffff
    1504:	ba ff ff             	mov    dx,0xffff
    1507:	2b c1                	sub    ax,cx
    1509:	1b d3                	sbb    dx,bx
    150b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    150e:	26 89 45 01          	mov    WORD PTR es:[di+0x1],ax
    1512:	a1 50 2c             	mov    ax,ds:0x2c50
    1515:	8b 16 52 2c          	mov    dx,WORD PTR ds:0x2c52
    1519:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    151c:	26 89 45 03          	mov    WORD PTR es:[di+0x3],ax
    1520:	26 89 55 05          	mov    WORD PTR es:[di+0x5],dx
    1524:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1527:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    152a:	a3 50 2c             	mov    ds:0x2c50,ax
    152d:	89 16 52 2c          	mov    WORD PTR ds:0x2c52,dx
    1531:	83 46 f4 0b          	add    WORD PTR [bp-0xc],0xb
    1535:	81 7e f4 00 04       	cmp    WORD PTR [bp-0xc],0x400
    153a:	75 b5                	jne    0x14f1
    153c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    153f:	a3 4e 2c             	mov    ds:0x2c4e,ax
    1542:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1545:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1548:	9a ff ff 00 00       	call   0x0:0xffff
    154d:	a1 50 2c             	mov    ax,ds:0x2c50
    1550:	8b 16 52 2c          	mov    dx,WORD PTR ds:0x2c52
    1554:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1557:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    155a:	a1 50 2c             	mov    ax,ds:0x2c50
    155d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1560:	ff 36 52 2c          	push   WORD PTR ds:0x2c52
    1564:	9a bb 15 00 00       	call   0x0:0x15bb
    1569:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    156c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    156f:	26 8b 45 03          	mov    ax,WORD PTR es:[di+0x3]
    1573:	26 8b 55 05          	mov    dx,WORD PTR es:[di+0x5]
    1577:	a3 50 2c             	mov    ds:0x2c50,ax
    157a:	89 16 52 2c          	mov    WORD PTR ds:0x2c52,dx
    157e:	8d 7e 06             	lea    di,[bp+0x6]
    1581:	16                   	push   ss
    1582:	57                   	push   di
    1583:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1586:	81 c7 03 00          	add    di,0x3
    158a:	06                   	push   es
    158b:	57                   	push   di
    158c:	6a 08                	push   0x8
    158e:	9a 1b 16 50 17       	call   0x1750:0x161b
    1593:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1596:	9a d8 15 00 00       	call   0x0:0x15d8
    159b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    159e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    15a1:	c9                   	leave
    15a2:	ca 08 00             	retf   0x8
    15a5:	c8 04 00 00          	enter  0x4,0x0
    15a9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    15ac:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    15af:	74 38                	je     0x15e9
    15b1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    15b4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    15b7:	ff 76 08             	push   WORD PTR [bp+0x8]
    15ba:	9a ff ff 00 00       	call   0x0:0xffff
    15bf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    15c2:	a1 50 2c             	mov    ax,ds:0x2c50
    15c5:	8b 16 52 2c          	mov    dx,WORD PTR ds:0x2c52
    15c9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15cc:	26 89 45 03          	mov    WORD PTR es:[di+0x3],ax
    15d0:	26 89 55 05          	mov    WORD PTR es:[di+0x5],dx
    15d4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    15d7:	9a ff ff 00 00       	call   0x0:0xffff
    15dc:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    15df:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    15e2:	a3 50 2c             	mov    ds:0x2c50,ax
    15e5:	89 16 52 2c          	mov    WORD PTR ds:0x2c52,dx
    15e9:	c9                   	leave
    15ea:	ca 04 00             	retf   0x4
    15ed:	c8 1c 00 00          	enter  0x1c,0x0
    15f1:	a1 8c 18             	mov    ax,ds:0x188c
    15f4:	a3 14 16             	mov    ds:0x1614,ax
    15f7:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    15fb:	ff 36 22 16          	push   WORD PTR ds:0x1622
    15ff:	ff 36 20 16          	push   WORD PTR ds:0x1620
    1603:	8d 7e e4             	lea    di,[bp-0x1c]
    1606:	16                   	push   ss
    1607:	57                   	push   di
    1608:	9a 21 65 00 00       	call   0x0:0x6521
    160d:	09 c0                	or     ax,ax
    160f:	75 0a                	jne    0x161b
    1611:	bf 0a 16             	mov    di,0x160a
    1614:	1e                   	push   ds
    1615:	57                   	push   di
    1616:	9a 35 65 00 00       	call   0x0:0x6535
    161b:	ff 36 22 16          	push   WORD PTR ds:0x1622
    161f:	ff 36 20 16          	push   WORD PTR ds:0x1620
    1623:	bf 32 16             	mov    di,0x1632
    1626:	1e                   	push   ds
    1627:	57                   	push   di
    1628:	6a 00                	push   0x0
    162a:	6a 00                	push   0x0
    162c:	6a 00                	push   0x0
    162e:	6a 00                	push   0x0
    1630:	6a 00                	push   0x0
    1632:	6a 00                	push   0x0
    1634:	6a 00                	push   0x0
    1636:	6a 00                	push   0x0
    1638:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    163c:	6a 00                	push   0x0
    163e:	6a 00                	push   0x0
    1640:	9a 6f 3d 00 00       	call   0x0:0x3d6f
    1645:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1648:	ff 76 fe             	push   WORD PTR [bp-0x2]
    164b:	6a fc                	push   0xfffc
    164d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1650:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1653:	ff 76 08             	push   WORD PTR [bp+0x8]
    1656:	ff 76 06             	push   WORD PTR [bp+0x6]
    1659:	9a 89 14 91 16       	call   0x1691:0x1489
    165e:	52                   	push   dx
    165f:	50                   	push   ax
    1660:	9a c2 3d 00 00       	call   0x0:0x3dc2
    1665:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1668:	c9                   	leave
    1669:	ca 08 00             	retf   0x8
    166c:	c8 04 00 00          	enter  0x4,0x0
    1670:	ff 76 06             	push   WORD PTR [bp+0x6]
    1673:	6a fc                	push   0xfffc
    1675:	9a d3 1a 00 00       	call   0x0:0x1ad3
    167a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    167d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1680:	ff 76 06             	push   WORD PTR [bp+0x6]
    1683:	9a 1a 67 00 00       	call   0x0:0x671a
    1688:	ff 76 fe             	push   WORD PTR [bp-0x2]
    168b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    168e:	9a a5 15 de 17       	call   0x17de:0x15a5
    1693:	c9                   	leave
    1694:	ca 02 00             	retf   0x2
    1697:	c8 02 00 00          	enter  0x2,0x0
    169b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    169f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    16a2:	25 04 00             	and    ax,0x4
    16a5:	09 c0                	or     ax,ax
    16a7:	74 04                	je     0x16ad
    16a9:	80 4e ff 01          	or     BYTE PTR [bp-0x1],0x1
    16ad:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    16b0:	25 08 00             	and    ax,0x8
    16b3:	09 c0                	or     ax,ax
    16b5:	74 04                	je     0x16bb
    16b7:	80 4e ff 04          	or     BYTE PTR [bp-0x1],0x4
    16bb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    16be:	25 01 00             	and    ax,0x1
    16c1:	09 c0                	or     ax,ax
    16c3:	74 04                	je     0x16c9
    16c5:	80 4e ff 08          	or     BYTE PTR [bp-0x1],0x8
    16c9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    16cc:	25 02 00             	and    ax,0x2
    16cf:	09 c0                	or     ax,ax
    16d1:	74 04                	je     0x16d7
    16d3:	80 4e ff 10          	or     BYTE PTR [bp-0x1],0x10
    16d7:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    16da:	25 10 00             	and    ax,0x10
    16dd:	09 c0                	or     ax,ax
    16df:	74 04                	je     0x16e5
    16e1:	80 4e ff 20          	or     BYTE PTR [bp-0x1],0x20
    16e5:	6a 12                	push   0x12
    16e7:	9a 06 17 00 00       	call   0x0:0x1706
    16ec:	09 c0                	or     ax,ax
    16ee:	7d 04                	jge    0x16f4
    16f0:	80 4e ff 02          	or     BYTE PTR [bp-0x1],0x2
    16f4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    16f7:	c9                   	leave
    16f8:	ca 02 00             	retf   0x2
    16fb:	c8 02 00 00          	enter  0x2,0x0
    16ff:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1703:	6a 10                	push   0x10
    1705:	9a 15 17 00 00       	call   0x0:0x1715
    170a:	09 c0                	or     ax,ax
    170c:	7d 04                	jge    0x1712
    170e:	80 4e ff 01          	or     BYTE PTR [bp-0x1],0x1
    1712:	6a 11                	push   0x11
    1714:	9a c2 4b 00 00       	call   0x0:0x4bc2
    1719:	09 c0                	or     ax,ax
    171b:	7d 04                	jge    0x1721
    171d:	80 4e ff 04          	or     BYTE PTR [bp-0x1],0x4
    1721:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1724:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1727:	25 00 00             	and    ax,0x0
    172a:	81 e2 00 20          	and    dx,0x2000
    172e:	09 d0                	or     ax,dx
    1730:	74 04                	je     0x1736
    1732:	80 4e ff 02          	or     BYTE PTR [bp-0x1],0x2
    1736:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1739:	c9                   	leave
    173a:	ca 04 00             	retf   0x4
    173d:	01 26 c8 04          	add    WORD PTR ds:0x4c8,sp
    1741:	02 00                	add    al,BYTE PTR [bx+si]
    1743:	bf 3d 17             	mov    di,0x173d
    1746:	0e                   	push   cs
    1747:	57                   	push   di
    1748:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    174b:	06                   	push   es
    174c:	57                   	push   di
    174d:	9a 78 18 7e 17       	call   0x177e:0x1878
    1752:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1755:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1759:	74 3d                	je     0x1798
    175b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    175e:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1761:	30 e4                	xor    ah,ah
    1763:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1766:	7e 30                	jle    0x1798
    1768:	8d be fc fe          	lea    di,[bp-0x104]
    176c:	16                   	push   ss
    176d:	57                   	push   di
    176e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1771:	40                   	inc    ax
    1772:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1775:	03 f8                	add    di,ax
    1777:	26 8a 05             	mov    al,BYTE PTR es:[di]
    177a:	50                   	push   ax
    177b:	9a e9 18 8d 17       	call   0x178d:0x18e9
    1780:	8d be fc fd          	lea    di,[bp-0x204]
    1784:	16                   	push   ss
    1785:	57                   	push   di
    1786:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1789:	50                   	push   ax
    178a:	9a e9 18 e5 17       	call   0x17e5:0x18e9
    178f:	9a ed 07 58 18       	call   0x1858:0x7ed
    1794:	09 c0                	or     ax,ax
    1796:	74 04                	je     0x179c
    1798:	b0 00                	mov    al,0x0
    179a:	eb 02                	jmp    0x179e
    179c:	b0 01                	mov    al,0x1
    179e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    17a1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    17a4:	c9                   	leave
    17a5:	ca 06 00             	retf   0x6
    17a8:	c8 04 00 00          	enter  0x4,0x0
    17ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17af:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    17b3:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    17b7:	74 13                	je     0x17cc
    17b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17bc:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    17c0:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    17c4:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    17c7:	89 56 08             	mov    WORD PTR [bp+0x8],dx
    17ca:	eb e0                	jmp    0x17ac
    17cc:	31 c0                	xor    ax,ax
    17ce:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17d1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    17d4:	ff 76 08             	push   WORD PTR [bp+0x8]
    17d7:	ff 76 06             	push   WORD PTR [bp+0x6]
    17da:	bf fb 04             	mov    di,0x4fb
    17dd:	b8 0e 18             	mov    ax,0x180e
    17e0:	50                   	push   ax
    17e1:	57                   	push   di
    17e2:	9a 55 22 6f 18       	call   0x186f:0x2255
    17e7:	08 c0                	or     al,al
    17e9:	74 0c                	je     0x17f7
    17eb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    17ee:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    17f1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17f4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    17f7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    17fa:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    17fd:	c9                   	leave
    17fe:	ca 04 00             	retf   0x4
    1801:	c8 0c 02 00          	enter  0x20c,0x0
    1805:	ff 76 08             	push   WORD PTR [bp+0x8]
    1808:	ff 76 06             	push   WORD PTR [bp+0x6]
    180b:	9a a8 17 e0 18       	call   0x18e0:0x17a8
    1810:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1813:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1816:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1819:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    181c:	75 53                	jne    0x1871
    181e:	8d be f4 fd          	lea    di,[bp-0x20c]
    1822:	16                   	push   ss
    1823:	57                   	push   di
    1824:	68 2a f0             	push   0xf02a
    1827:	8d be fc fe          	lea    di,[bp-0x104]
    182b:	16                   	push   ss
    182c:	57                   	push   di
    182d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1830:	06                   	push   es
    1831:	57                   	push   di
    1832:	9a 2a 51 3f 19       	call   0x193f:0x512a
    1837:	83 c4 04             	add    sp,0x4
    183a:	8d 86 fc fe          	lea    ax,[bp-0x104]
    183e:	8c d2                	mov    dx,ss
    1840:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    1844:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    1848:	c6 86 f8 fe 04       	mov    BYTE PTR [bp-0x108],0x4
    184d:	8d be f4 fe          	lea    di,[bp-0x10c]
    1851:	16                   	push   ss
    1852:	57                   	push   di
    1853:	6a 00                	push   0x0
    1855:	9a 50 09 68 18       	call   0x1868:0x950
    185a:	b0 01                	mov    al,0x1
    185c:	50                   	push   ax
    185d:	b8 52 00             	mov    ax,0x52
    1860:	ba 27 1a             	mov    dx,0x1a27
    1863:	52                   	push   dx
    1864:	50                   	push   ax
    1865:	9a e6 28 74 2f       	call   0x2f74:0x28e6
    186a:	52                   	push   dx
    186b:	50                   	push   ax
    186c:	9a 99 13 8a 18       	call   0x188a:0x1399
    1871:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1874:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1877:	c9                   	leave
    1878:	ca 04 00             	retf   0x4
    187b:	55                   	push   bp
    187c:	89 e5                	mov    bp,sp
    187e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1882:	74 08                	je     0x188c
    1884:	83 ec 08             	sub    sp,0x8
    1887:	9a e2 1f 97 18       	call   0x1897:0x1fe2
    188c:	31 c0                	xor    ax,ax
    188e:	50                   	push   ax
    188f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1892:	06                   	push   es
    1893:	57                   	push   di
    1894:	9a 50 1f e7 18       	call   0x18e7:0x1f50
    1899:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    189c:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    189f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18a2:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    18a6:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    18aa:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    18ad:	26 88 45 10          	mov    BYTE PTR es:[di+0x10],al
    18b1:	26 c7 45 08 08 00    	mov    WORD PTR es:[di+0x8],0x8
    18b7:	26 c6 45 13 01       	mov    BYTE PTR es:[di+0x13],0x1
    18bc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    18c0:	74 07                	je     0x18c9
    18c2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    18c6:	83 c4 06             	add    sp,0x6
    18c9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    18cc:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    18cf:	c9                   	leave
    18d0:	ca 0c 00             	retf   0xc
    18d3:	55                   	push   bp
    18d4:	89 e5                	mov    bp,sp
    18d6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    18d9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    18dc:	bf 6f 00             	mov    di,0x6f
    18df:	b8 fd 18             	mov    ax,0x18fd
    18e2:	50                   	push   ax
    18e3:	57                   	push   di
    18e4:	9a 55 22 14 1f       	call   0x1f14:0x2255
    18e9:	08 c0                	or     al,al
    18eb:	74 44                	je     0x1931
    18ed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18f0:	26 8a 45 13          	mov    al,BYTE PTR es:[di+0x13]
    18f4:	50                   	push   ax
    18f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18f8:	06                   	push   es
    18f9:	57                   	push   di
    18fa:	9a 62 1e 0e 19       	call   0x190e:0x1e62
    18ff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1902:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1906:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1909:	06                   	push   es
    190a:	57                   	push   di
    190b:	9a 21 1e 1f 19       	call   0x191f:0x1e21
    1910:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1913:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    191a:	06                   	push   es
    191b:	57                   	push   di
    191c:	9a d0 1c 99 1a       	call   0x1a99:0x1cd0
    1921:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1924:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1928:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    192b:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    192f:	eb 10                	jmp    0x1941
    1931:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1934:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193a:	06                   	push   es
    193b:	57                   	push   di
    193c:	9a fa 10 52 20       	call   0x2052:0x10fa
    1941:	c9                   	leave
    1942:	ca 08 00             	retf   0x8
    1945:	55                   	push   bp
    1946:	89 e5                	mov    bp,sp
    1948:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    194b:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1950:	74 4a                	je     0x199c
    1952:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1955:	26 8a 45 2d          	mov    al,BYTE PTR es:[di+0x2d]
    1959:	3c 00                	cmp    al,0x0
    195b:	75 2d                	jne    0x198a
    195d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1960:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    1964:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1967:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    196b:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    196f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1972:	26 03 45 1e          	add    ax,WORD PTR es:[di+0x1e]
    1976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1979:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    197d:	50                   	push   ax
    197e:	e8 7f f4             	call   0xe00
    1981:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1984:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    1988:	eb 12                	jmp    0x199c
    198a:	3c 04                	cmp    al,0x4
    198c:	75 0e                	jne    0x199c
    198e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1991:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1995:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1998:	36 01 45 fa          	add    WORD PTR ss:[di-0x6],ax
    199c:	c9                   	leave
    199d:	c2 06 00             	ret    0x6
    19a0:	55                   	push   bp
    19a1:	89 e5                	mov    bp,sp
    19a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a6:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    19ab:	74 4a                	je     0x19f7
    19ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19b0:	26 8a 45 2d          	mov    al,BYTE PTR es:[di+0x2d]
    19b4:	3c 00                	cmp    al,0x0
    19b6:	75 2d                	jne    0x19e5
    19b8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    19bb:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    19bf:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    19c2:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    19c6:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    19ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19cd:	26 03 45 20          	add    ax,WORD PTR es:[di+0x20]
    19d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d4:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    19d8:	50                   	push   ax
    19d9:	e8 24 f4             	call   0xe00
    19dc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    19df:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    19e3:	eb 12                	jmp    0x19f7
    19e5:	3c 02                	cmp    al,0x2
    19e7:	75 0e                	jne    0x19f7
    19e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19ec:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    19f0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    19f3:	36 01 45 fa          	add    WORD PTR ss:[di-0x6],ax
    19f7:	c9                   	leave
    19f8:	c2 06 00             	ret    0x6
    19fb:	c8 08 00 00          	enter  0x8,0x0
    19ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a02:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a06:	26 80 bd e0 00 00    	cmp    BYTE PTR es:[di+0xe0],0x0
    1a0c:	75 03                	jne    0x1a11
    1a0e:	e9 8a 00             	jmp    0x1a9b
    1a11:	31 c0                	xor    ax,ax
    1a13:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a16:	31 c0                	xor    ax,ax
    1a18:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1a1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a1e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a22:	06                   	push   es
    1a23:	57                   	push   di
    1a24:	9a fd 39 52 1a       	call   0x1a52:0x39fd
    1a29:	48                   	dec    ax
    1a2a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1a2d:	31 c0                	xor    ax,ax
    1a2f:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1a32:	7f 47                	jg     0x1a7b
    1a34:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a37:	eb 03                	jmp    0x1a3c
    1a39:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1a3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a3f:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    1a44:	75 16                	jne    0x1a5c
    1a46:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a49:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a4d:	06                   	push   es
    1a4e:	57                   	push   di
    1a4f:	9a 8f 39 6b 1a       	call   0x1a6b:0x398f
    1a54:	52                   	push   dx
    1a55:	50                   	push   ax
    1a56:	55                   	push   bp
    1a57:	e8 eb fe             	call   0x1945
    1a5a:	eb 17                	jmp    0x1a73
    1a5c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a62:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a66:	06                   	push   es
    1a67:	57                   	push   di
    1a68:	9a 8f 39 cd 1a       	call   0x1acd:0x398f
    1a6d:	52                   	push   dx
    1a6e:	50                   	push   ax
    1a6f:	55                   	push   bp
    1a70:	e8 2d ff             	call   0x19a0
    1a73:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a76:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1a79:	75 be                	jne    0x1a39
    1a7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a7e:	26 8b 45 11          	mov    ax,WORD PTR es:[di+0x11]
    1a82:	31 d2                	xor    dx,dx
    1a84:	8b c8                	mov    cx,ax
    1a86:	8b da                	mov    bx,dx
    1a88:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a8b:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1a8e:	99                   	cwd
    1a8f:	03 c1                	add    ax,cx
    1a91:	13 d3                	adc    dx,bx
    1a93:	50                   	push   ax
    1a94:	06                   	push   es
    1a95:	57                   	push   di
    1a96:	9a f5 1d e0 1b       	call   0x1be0:0x1df5
    1a9b:	c9                   	leave
    1a9c:	ca 04 00             	retf   0x4
    1a9f:	c8 06 00 00          	enter  0x6,0x0
    1aa3:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    1aa8:	c7 46 fc 10 00       	mov    WORD PTR [bp-0x4],0x10
    1aad:	83 7e 06 01          	cmp    WORD PTR [bp+0x6],0x1
    1ab1:	75 0a                	jne    0x1abd
    1ab3:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    1ab8:	c7 46 fc 20 00       	mov    WORD PTR [bp-0x4],0x20
    1abd:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1ac0:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1ac4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1ac8:	06                   	push   es
    1ac9:	57                   	push   di
    1aca:	9a b9 62 67 1b       	call   0x1b67:0x62b9
    1acf:	50                   	push   ax
    1ad0:	6a f0                	push   0xfff0
    1ad2:	9a 6d 1b 00 00       	call   0x0:0x1b6d
    1ad7:	23 46 fa             	and    ax,WORD PTR [bp-0x6]
    1ada:	23 56 fc             	and    dx,WORD PTR [bp-0x4]
    1add:	09 d0                	or     ax,dx
    1adf:	b0 00                	mov    al,0x0
    1ae1:	74 01                	je     0x1ae4
    1ae3:	40                   	inc    ax
    1ae4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1ae7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1aea:	c9                   	leave
    1aeb:	c2 04 00             	ret    0x4
    1aee:	c8 02 00 00          	enter  0x2,0x0
    1af2:	31 c0                	xor    ax,ax
    1af4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1af7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1afa:	36 80 7d 0c 00       	cmp    BYTE PTR ss:[di+0xc],0x0
    1aff:	75 4f                	jne    0x1b50
    1b01:	36 80 7d 0a 00       	cmp    BYTE PTR ss:[di+0xa],0x0
    1b06:	74 21                	je     0x1b29
    1b08:	ff 76 08             	push   WORD PTR [bp+0x8]
    1b0b:	57                   	push   di
    1b0c:	e8 90 ff             	call   0x1a9f
    1b0f:	08 c0                	or     al,al
    1b11:	75 16                	jne    0x1b29
    1b13:	ff 76 06             	push   WORD PTR [bp+0x6]
    1b16:	9a 42 1b 00 00       	call   0x0:0x1b42
    1b1b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b1e:	36 2b 45 fc          	sub    ax,WORD PTR ss:[di-0x4]
    1b22:	f7 d8                	neg    ax
    1b24:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b27:	eb 27                	jmp    0x1b50
    1b29:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b2c:	36 80 7d 0a 00       	cmp    BYTE PTR ss:[di+0xa],0x0
    1b31:	75 1d                	jne    0x1b50
    1b33:	ff 76 08             	push   WORD PTR [bp+0x8]
    1b36:	57                   	push   di
    1b37:	e8 65 ff             	call   0x1a9f
    1b3a:	08 c0                	or     al,al
    1b3c:	74 12                	je     0x1b50
    1b3e:	ff 76 06             	push   WORD PTR [bp+0x6]
    1b41:	9a c4 2d 00 00       	call   0x0:0x2dc4
    1b46:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b49:	36 2b 45 fc          	sub    ax,WORD PTR ss:[di-0x4]
    1b4d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b50:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b53:	c9                   	leave
    1b54:	c2 06 00             	ret    0x6
    1b57:	c8 04 00 00          	enter  0x4,0x0
    1b5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b5e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1b62:	06                   	push   es
    1b63:	57                   	push   di
    1b64:	9a b9 62 a2 1b       	call   0x1ba2:0x62b9
    1b69:	50                   	push   ax
    1b6a:	6a f0                	push   0xfff0
    1b6c:	9a 10 2e 00 00       	call   0x0:0x2e10
    1b71:	25 00 00             	and    ax,0x0
    1b74:	81 e2 84 00          	and    dx,0x84
    1b78:	09 d0                	or     ax,dx
    1b7a:	b0 00                	mov    al,0x0
    1b7c:	74 01                	je     0x1b7f
    1b7e:	40                   	inc    ax
    1b7f:	98                   	cbw
    1b80:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b86:	26 80 7d 10 01       	cmp    BYTE PTR es:[di+0x10],0x1
    1b8b:	75 1f                	jne    0x1bac
    1b8d:	6a 00                	push   0x0
    1b8f:	6a 15                	push   0x15
    1b91:	55                   	push   bp
    1b92:	e8 59 ff             	call   0x1aee
    1b95:	50                   	push   ax
    1b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b99:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1b9d:	06                   	push   es
    1b9e:	57                   	push   di
    1b9f:	9a f4 18 c1 1b       	call   0x1bc1:0x18f4
    1ba4:	5a                   	pop    dx
    1ba5:	03 c2                	add    ax,dx
    1ba7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1baa:	eb 1d                	jmp    0x1bc9
    1bac:	6a 01                	push   0x1
    1bae:	6a 14                	push   0x14
    1bb0:	55                   	push   bp
    1bb1:	e8 3a ff             	call   0x1aee
    1bb4:	50                   	push   ax
    1bb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb8:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1bbc:	06                   	push   es
    1bbd:	57                   	push   di
    1bbe:	9a a9 18 5b 1d       	call   0x1d5b:0x18a9
    1bc3:	5a                   	pop    dx
    1bc4:	03 c2                	add    ax,dx
    1bc6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1bc9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1bcc:	c9                   	leave
    1bcd:	ca 08 00             	retf   0x8
    1bd0:	c8 02 00 00          	enter  0x2,0x0
    1bd4:	6a 00                	push   0x0
    1bd6:	6a 00                	push   0x0
    1bd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bdb:	06                   	push   es
    1bdc:	57                   	push   di
    1bdd:	9a 57 1b 3d 1c       	call   0x1c3d:0x1b57
    1be2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1be5:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    1be9:	b0 00                	mov    al,0x0
    1beb:	7d 01                	jge    0x1bee
    1bed:	40                   	inc    ax
    1bee:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1bf1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1bf4:	c9                   	leave
    1bf5:	ca 04 00             	retf   0x4
    1bf8:	2c 1c                	sub    al,0x1c
    1bfa:	42                   	inc    dx
    1bfb:	1c 57                	sbb    al,0x57
    1bfd:	1c 7a                	sbb    al,0x7a
    1bff:	1c 99                	sbb    al,0x99
    1c01:	1c ac                	sbb    al,0xac
    1c03:	1c ae                	sbb    al,0xae
    1c05:	1c bc                	sbb    al,0xbc
    1c07:	1c cc                	sbb    al,0xcc
    1c09:	1c c8                	sbb    al,0xc8
    1c0b:	04 00                	add    al,0x0
    1c0d:	00 c4                	add    ah,al
    1c0f:	7e 0a                	jle    0x1c1b
    1c11:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1c14:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1c17:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1c1b:	3d 08 00             	cmp    ax,0x8
    1c1e:	76 03                	jbe    0x1c23
    1c20:	e9 a9 00             	jmp    0x1ccc
    1c23:	89 c3                	mov    bx,ax
    1c25:	d1 e3                	shl    bx,1
    1c27:	2e ff a7 f8 1b       	jmp    WORD PTR cs:[bx+0x1bf8]
    1c2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c2f:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    1c33:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    1c37:	50                   	push   ax
    1c38:	06                   	push   es
    1c39:	57                   	push   di
    1c3a:	9a d0 1c 53 1c       	call   0x1c53:0x1cd0
    1c3f:	e9 8a 00             	jmp    0x1ccc
    1c42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c45:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    1c49:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    1c4d:	50                   	push   ax
    1c4e:	06                   	push   es
    1c4f:	57                   	push   di
    1c50:	9a d0 1c 63 1c       	call   0x1c63:0x1cd0
    1c55:	eb 75                	jmp    0x1ccc
    1c57:	6a 01                	push   0x1
    1c59:	6a 00                	push   0x0
    1c5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c5e:	06                   	push   es
    1c5f:	57                   	push   di
    1c60:	9a 57 1b 76 1c       	call   0x1c76:0x1b57
    1c65:	8b d0                	mov    dx,ax
    1c67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c6a:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    1c6e:	2b c2                	sub    ax,dx
    1c70:	50                   	push   ax
    1c71:	06                   	push   es
    1c72:	57                   	push   di
    1c73:	9a d0 1c 86 1c       	call   0x1c86:0x1cd0
    1c78:	eb 52                	jmp    0x1ccc
    1c7a:	6a 01                	push   0x1
    1c7c:	6a 00                	push   0x0
    1c7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c81:	06                   	push   es
    1c82:	57                   	push   di
    1c83:	9a 57 1b 95 1c       	call   0x1c95:0x1b57
    1c88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c8b:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    1c8f:	50                   	push   ax
    1c90:	06                   	push   es
    1c91:	57                   	push   di
    1c92:	9a d0 1c a8 1c       	call   0x1ca8:0x1cd0
    1c97:	eb 33                	jmp    0x1ccc
    1c99:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c9c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1ca0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca3:	06                   	push   es
    1ca4:	57                   	push   di
    1ca5:	9a d0 1c b8 1c       	call   0x1cb8:0x1cd0
    1caa:	eb 20                	jmp    0x1ccc
    1cac:	eb 1e                	jmp    0x1ccc
    1cae:	6a 00                	push   0x0
    1cb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb3:	06                   	push   es
    1cb4:	57                   	push   di
    1cb5:	9a d0 1c c8 1c       	call   0x1cc8:0x1cd0
    1cba:	eb 10                	jmp    0x1ccc
    1cbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cbf:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1cc3:	06                   	push   es
    1cc4:	57                   	push   di
    1cc5:	9a d0 1c 84 1d       	call   0x1d84:0x1cd0
    1cca:	eb 00                	jmp    0x1ccc
    1ccc:	c9                   	leave
    1ccd:	ca 08 00             	retf   0x8
    1cd0:	c8 08 00 00          	enter  0x8,0x0
    1cd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cd7:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1cdb:	26 f6 45 18 02       	test   BYTE PTR es:[di+0x18],0x2
    1ce0:	74 0d                	je     0x1cef
    1ce2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ce8:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    1cec:	e9 02 01             	jmp    0x1df1
    1cef:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1cf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf5:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    1cf9:	7e 09                	jle    0x1d04
    1cfb:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    1cff:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    1d02:	eb 0b                	jmp    0x1d0f
    1d04:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1d08:	7d 05                	jge    0x1d0f
    1d0a:	31 c0                	xor    ax,ax
    1d0c:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    1d0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d12:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    1d17:	75 07                	jne    0x1d20
    1d19:	31 c0                	xor    ax,ax
    1d1b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d1e:	eb 05                	jmp    0x1d25
    1d20:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    1d25:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1d28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d2b:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
    1d2f:	75 03                	jne    0x1d34
    1d31:	e9 80 00             	jmp    0x1db4
    1d34:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    1d38:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1d3b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1d3e:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    1d42:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    1d47:	75 16                	jne    0x1d5f
    1d49:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1d4c:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    1d4f:	50                   	push   ax
    1d50:	6a 00                	push   0x0
    1d52:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1d56:	06                   	push   es
    1d57:	57                   	push   di
    1d58:	9a b4 5e 74 1d       	call   0x1d74:0x5eb4
    1d5d:	eb 17                	jmp    0x1d76
    1d5f:	6a 00                	push   0x0
    1d61:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1d64:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    1d67:	50                   	push   ax
    1d68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d6b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1d6f:	06                   	push   es
    1d70:	57                   	push   di
    1d71:	9a b4 5e c0 1d       	call   0x1dc0:0x5eb4
    1d76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d79:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1d7d:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1d81:	9a a8 17 1b 1e       	call   0x1e1b:0x17a8
    1d86:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1d89:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1d8c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1d8f:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    1d92:	74 20                	je     0x1db4
    1d94:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1d97:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    1d9c:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    1da1:	74 11                	je     0x1db4
    1da3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1da6:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    1dab:	06                   	push   es
    1dac:	57                   	push   di
    1dad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1db0:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    1db4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db7:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1dbb:	06                   	push   es
    1dbc:	57                   	push   di
    1dbd:	9a b9 62 dd 1d       	call   0x1ddd:0x62b9
    1dc2:	50                   	push   ax
    1dc3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1dc6:	9a ff ff 00 00       	call   0x0:0xffff
    1dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dce:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
    1dd2:	74 1d                	je     0x1df1
    1dd4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1dd8:	06                   	push   es
    1dd9:	57                   	push   di
    1dda:	9a b9 62 dd 1e       	call   0x1edd:0x62b9
    1ddf:	50                   	push   ax
    1de0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1de3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1de6:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1dea:	6a 01                	push   0x1
    1dec:	9a ff ff 00 00       	call   0x0:0xffff
    1df1:	c9                   	leave
    1df2:	ca 06 00             	retf   0x6
    1df5:	55                   	push   bp
    1df6:	89 e5                	mov    bp,sp
    1df8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1dfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dfe:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1e02:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    1e07:	7d 06                	jge    0x1e0f
    1e09:	31 c0                	xor    ax,ax
    1e0b:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1e0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e12:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1e16:	06                   	push   es
    1e17:	57                   	push   di
    1e18:	9a 17 21 3c 1e       	call   0x1e3c:0x2117
    1e1d:	c9                   	leave
    1e1e:	ca 06 00             	retf   0x6
    1e21:	55                   	push   bp
    1e22:	89 e5                	mov    bp,sp
    1e24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e27:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1e2b:	26 c6 85 e0 00 00    	mov    BYTE PTR es:[di+0xe0],0x0
    1e31:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e37:	06                   	push   es
    1e38:	57                   	push   di
    1e39:	9a f5 1d 78 1e       	call   0x1e78:0x1df5
    1e3e:	c9                   	leave
    1e3f:	ca 06 00             	retf   0x6
    1e42:	c8 02 00 00          	enter  0x2,0x0
    1e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e49:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1e4d:	26 80 bd e0 00 00    	cmp    BYTE PTR es:[di+0xe0],0x0
    1e53:	b0 00                	mov    al,0x0
    1e55:	75 01                	jne    0x1e58
    1e57:	40                   	inc    ax
    1e58:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1e5b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e5e:	c9                   	leave
    1e5f:	ca 04 00             	retf   0x4
    1e62:	55                   	push   bp
    1e63:	89 e5                	mov    bp,sp
    1e65:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1e68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e6b:	26 88 45 13          	mov    BYTE PTR es:[di+0x13],al
    1e6f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1e73:	06                   	push   es
    1e74:	57                   	push   di
    1e75:	9a 17 21 b3 1e       	call   0x1eb3:0x2117
    1e7a:	c9                   	leave
    1e7b:	ca 06 00             	retf   0x6
    1e7e:	c8 02 00 00          	enter  0x2,0x0
    1e82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e85:	31 c0                	xor    ax,ax
    1e87:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1e8b:	31 c0                	xor    ax,ax
    1e8d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e90:	26 80 7d 10 01       	cmp    BYTE PTR es:[di+0x10],0x1
    1e95:	75 05                	jne    0x1e9c
    1e97:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    1e9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e9f:	26 80 7d 13 00       	cmp    BYTE PTR es:[di+0x13],0x0
    1ea4:	74 2b                	je     0x1ed1
    1ea6:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    1ea9:	50                   	push   ax
    1eaa:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1ead:	50                   	push   ax
    1eae:	06                   	push   es
    1eaf:	57                   	push   di
    1eb0:	9a 57 1b ff 1e       	call   0x1eff:0x1b57
    1eb5:	8b d0                	mov    dx,ax
    1eb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eba:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1ebe:	2b c2                	sub    ax,dx
    1ec0:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1ec4:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    1ec9:	7d 06                	jge    0x1ed1
    1ecb:	31 c0                	xor    ax,ax
    1ecd:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1ed1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ed4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1ed8:	06                   	push   es
    1ed9:	57                   	push   di
    1eda:	9a b9 62 27 1f       	call   0x1f27:0x62b9
    1edf:	50                   	push   ax
    1ee0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ee3:	6a 00                	push   0x0
    1ee5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ee8:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1eec:	6a 01                	push   0x1
    1eee:	9a ff ff 00 00       	call   0x0:0xffff
    1ef3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ef6:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1efa:	06                   	push   es
    1efb:	57                   	push   di
    1efc:	9a d0 1c 38 1f       	call   0x1f38:0x1cd0
    1f01:	c9                   	leave
    1f02:	ca 08 00             	retf   0x8
    1f05:	55                   	push   bp
    1f06:	89 e5                	mov    bp,sp
    1f08:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1f0c:	74 08                	je     0x1f16
    1f0e:	83 ec 08             	sub    sp,0x8
    1f11:	9a e2 1f a0 1f       	call   0x1fa0:0x1fe2
    1f16:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1f19:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f1c:	31 c0                	xor    ax,ax
    1f1e:	50                   	push   ax
    1f1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f22:	06                   	push   es
    1f23:	57                   	push   di
    1f24:	9a 61 2e bc 1f       	call   0x1fbc:0x2e61
    1f29:	ff 76 08             	push   WORD PTR [bp+0x8]
    1f2c:	ff 76 06             	push   WORD PTR [bp+0x6]
    1f2f:	6a 00                	push   0x0
    1f31:	b0 01                	mov    al,0x1
    1f33:	50                   	push   ax
    1f34:	b8 6f 00             	mov    ax,0x6f
    1f37:	ba 3f 1f             	mov    dx,0x1f3f
    1f3a:	52                   	push   dx
    1f3b:	50                   	push   ax
    1f3c:	9a 7b 18 5d 1f       	call   0x1f5d:0x187b
    1f41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f44:	26 89 85 d8 00       	mov    WORD PTR es:[di+0xd8],ax
    1f49:	26 89 95 da 00       	mov    WORD PTR es:[di+0xda],dx
    1f4e:	ff 76 08             	push   WORD PTR [bp+0x8]
    1f51:	ff 76 06             	push   WORD PTR [bp+0x6]
    1f54:	6a 01                	push   0x1
    1f56:	b0 01                	mov    al,0x1
    1f58:	50                   	push   ax
    1f59:	b8 6f 00             	mov    ax,0x6f
    1f5c:	ba 64 1f             	mov    dx,0x1f64
    1f5f:	52                   	push   dx
    1f60:	50                   	push   ax
    1f61:	9a 7b 18 e2 1f       	call   0x1fe2:0x187b
    1f66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f69:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    1f6e:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
    1f73:	26 c6 85 e0 00 01    	mov    BYTE PTR es:[di+0xe0],0x1
    1f79:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1f7d:	74 07                	je     0x1f86
    1f7f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1f83:	83 c4 06             	add    sp,0x6
    1f86:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1f89:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1f8c:	c9                   	leave
    1f8d:	ca 0a 00             	retf   0xa
    1f90:	55                   	push   bp
    1f91:	89 e5                	mov    bp,sp
    1f93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f96:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1f9b:	06                   	push   es
    1f9c:	57                   	push   di
    1f9d:	9a 7f 1f af 1f       	call   0x1faf:0x1f7f
    1fa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa5:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1faa:	06                   	push   es
    1fab:	57                   	push   di
    1fac:	9a 7f 1f c7 1f       	call   0x1fc7:0x1f7f
    1fb1:	31 c0                	xor    ax,ax
    1fb3:	50                   	push   ax
    1fb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb7:	06                   	push   es
    1fb8:	57                   	push   di
    1fb9:	9a fc 2e d8 1f       	call   0x1fd8:0x2efc
    1fbe:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1fc2:	74 05                	je     0x1fc9
    1fc4:	9a 0f 20 5e 20       	call   0x205e:0x200f
    1fc9:	c9                   	leave
    1fca:	ca 06 00             	retf   0x6
    1fcd:	55                   	push   bp
    1fce:	89 e5                	mov    bp,sp
    1fd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd3:	06                   	push   es
    1fd4:	57                   	push   di
    1fd5:	9a 88 3c 2d 20       	call   0x202d:0x3c88
    1fda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fdd:	06                   	push   es
    1fde:	57                   	push   di
    1fdf:	9a 17 21 f4 1f       	call   0x1ff4:0x2117
    1fe4:	c9                   	leave
    1fe5:	ca 04 00             	retf   0x4
    1fe8:	c8 08 00 00          	enter  0x8,0x0
    1fec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fef:	06                   	push   es
    1ff0:	57                   	push   di
    1ff1:	9a 79 20 91 20       	call   0x2091:0x2079
    1ff6:	8d 7e f8             	lea    di,[bp-0x8]
    1ff9:	16                   	push   ss
    1ffa:	57                   	push   di
    1ffb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ffe:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2003:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2007:	f7 d8                	neg    ax
    2009:	50                   	push   ax
    200a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2012:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2016:	f7 d8                	neg    ax
    2018:	50                   	push   ax
    2019:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    201c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2021:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2025:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2028:	06                   	push   es
    2029:	57                   	push   di
    202a:	9a a9 18 3c 20       	call   0x203c:0x18a9
    202f:	50                   	push   ax
    2030:	e8 cd ed             	call   0xe00
    2033:	50                   	push   ax
    2034:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2037:	06                   	push   es
    2038:	57                   	push   di
    2039:	9a f4 18 73 20       	call   0x2073:0x18f4
    203e:	50                   	push   ax
    203f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2042:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2047:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    204b:	e8 b2 ed             	call   0xe00
    204e:	50                   	push   ax
    204f:	9a ae 06 ca 25       	call   0x25ca:0x6ae
    2054:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2057:	06                   	push   es
    2058:	57                   	push   di
    2059:	6a 08                	push   0x8
    205b:	9a 1b 16 5a 22       	call   0x225a:0x161b
    2060:	ff 76 10             	push   WORD PTR [bp+0x10]
    2063:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2066:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2069:	06                   	push   es
    206a:	57                   	push   di
    206b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    206e:	06                   	push   es
    206f:	57                   	push   di
    2070:	9a c2 35 2d 21       	call   0x212d:0x35c2
    2075:	c9                   	leave
    2076:	ca 0c 00             	retf   0xc
    2079:	55                   	push   bp
    207a:	89 e5                	mov    bp,sp
    207c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    207f:	26 80 bd e1 00 00    	cmp    BYTE PTR es:[di+0xe1],0x0
    2085:	75 1b                	jne    0x20a2
    2087:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    208c:	06                   	push   es
    208d:	57                   	push   di
    208e:	9a fb 19 a0 20       	call   0x20a0:0x19fb
    2093:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2096:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    209b:	06                   	push   es
    209c:	57                   	push   di
    209d:	9a fb 19 c9 20       	call   0x20c9:0x19fb
    20a2:	c9                   	leave
    20a3:	ca 04 00             	retf   0x4
    20a6:	55                   	push   bp
    20a7:	89 e5                	mov    bp,sp
    20a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ac:	26 8a 85 e0 00       	mov    al,BYTE PTR es:[di+0xe0]
    20b1:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    20b4:	74 39                	je     0x20ef
    20b6:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    20b9:	26 88 85 e0 00       	mov    BYTE PTR es:[di+0xe0],al
    20be:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    20c2:	74 09                	je     0x20cd
    20c4:	06                   	push   es
    20c5:	57                   	push   di
    20c6:	9a 79 20 dc 20       	call   0x20dc:0x2079
    20cb:	eb 22                	jmp    0x20ef
    20cd:	6a 00                	push   0x0
    20cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20d2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    20d7:	06                   	push   es
    20d8:	57                   	push   di
    20d9:	9a 21 1e ed 20       	call   0x20ed:0x1e21
    20de:	6a 00                	push   0x0
    20e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20e3:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    20e8:	06                   	push   es
    20e9:	57                   	push   di
    20ea:	9a 21 1e 15 21       	call   0x2115:0x1e21
    20ef:	c9                   	leave
    20f0:	ca 06 00             	retf   0x6
    20f3:	55                   	push   bp
    20f4:	89 e5                	mov    bp,sp
    20f6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20f9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ff:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2104:	06                   	push   es
    2105:	57                   	push   di
    2106:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2109:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    210d:	c9                   	leave
    210e:	ca 08 00             	retf   0x8
    2111:	00 00                	add    BYTE PTR [bx+si],al
    2113:	f2 21 57 21          	repnz and WORD PTR [bx+0x21],dx
    2117:	55                   	push   bp
    2118:	89 e5                	mov    bp,sp
    211a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    211d:	26 80 bd e2 00 00    	cmp    BYTE PTR es:[di+0xe2],0x0
    2123:	74 03                	je     0x2128
    2125:	e9 d4 00             	jmp    0x21fc
    2128:	06                   	push   es
    2129:	57                   	push   di
    212a:	9a fa 64 a6 22       	call   0x22a6:0x64fa
    212f:	08 c0                	or     al,al
    2131:	75 03                	jne    0x2136
    2133:	e9 c6 00             	jmp    0x21fc
    2136:	b8 11 21             	mov    ax,0x2111
    2139:	0e                   	push   cs
    213a:	50                   	push   ax
    213b:	55                   	push   bp
    213c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2140:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2144:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2147:	26 c6 85 e2 00 01    	mov    BYTE PTR es:[di+0xe2],0x1
    214d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2152:	06                   	push   es
    2153:	57                   	push   di
    2154:	9a d0 1b 6e 21       	call   0x216e:0x1bd0
    2159:	08 c0                	or     al,al
    215b:	74 28                	je     0x2185
    215d:	6a 00                	push   0x0
    215f:	6a 01                	push   0x1
    2161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2164:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2169:	06                   	push   es
    216a:	57                   	push   di
    216b:	9a 7e 1e 81 21       	call   0x2181:0x1e7e
    2170:	6a 01                	push   0x1
    2172:	6a 00                	push   0x0
    2174:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2177:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    217c:	06                   	push   es
    217d:	57                   	push   di
    217e:	9a 7e 1e 92 21       	call   0x2192:0x1e7e
    2183:	eb 61                	jmp    0x21e6
    2185:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2188:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    218d:	06                   	push   es
    218e:	57                   	push   di
    218f:	9a d0 1b a9 21       	call   0x21a9:0x1bd0
    2194:	08 c0                	or     al,al
    2196:	74 28                	je     0x21c0
    2198:	6a 00                	push   0x0
    219a:	6a 01                	push   0x1
    219c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    219f:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    21a4:	06                   	push   es
    21a5:	57                   	push   di
    21a6:	9a 7e 1e bc 21       	call   0x21bc:0x1e7e
    21ab:	6a 01                	push   0x1
    21ad:	6a 00                	push   0x0
    21af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    21b7:	06                   	push   es
    21b8:	57                   	push   di
    21b9:	9a 7e 1e d1 21       	call   0x21d1:0x1e7e
    21be:	eb 26                	jmp    0x21e6
    21c0:	6a 00                	push   0x0
    21c2:	6a 00                	push   0x0
    21c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c7:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    21cc:	06                   	push   es
    21cd:	57                   	push   di
    21ce:	9a 7e 1e e4 21       	call   0x21e4:0x1e7e
    21d3:	6a 01                	push   0x1
    21d5:	6a 00                	push   0x0
    21d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21da:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    21df:	06                   	push   es
    21e0:	57                   	push   di
    21e1:	9a 7e 1e 2a 22       	call   0x222a:0x1e7e
    21e6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    21ea:	83 c4 06             	add    sp,0x6
    21ed:	b8 fc 21             	mov    ax,0x21fc
    21f0:	0e                   	push   cs
    21f1:	50                   	push   ax
    21f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21f5:	26 c6 85 e2 00 00    	mov    BYTE PTR es:[di+0xe2],0x0
    21fb:	cb                   	retf
    21fc:	c9                   	leave
    21fd:	ca 04 00             	retf   0x4
    2200:	55                   	push   bp
    2201:	89 e5                	mov    bp,sp
    2203:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2206:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    2209:	74 21                	je     0x222c
    220b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    220e:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    2213:	75 17                	jne    0x222c
    2215:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2218:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    221d:	75 0d                	jne    0x222c
    221f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2222:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2225:	06                   	push   es
    2226:	57                   	push   di
    2227:	9a 30 22 f7 22       	call   0x22f7:0x2230
    222c:	c9                   	leave
    222d:	ca 08 00             	retf   0x8
    2230:	c8 10 00 00          	enter  0x10,0x0
    2234:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2237:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    223a:	75 03                	jne    0x223f
    223c:	e9 a1 01             	jmp    0x23e0
    223f:	8d 7e f0             	lea    di,[bp-0x10]
    2242:	16                   	push   ss
    2243:	57                   	push   di
    2244:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2247:	06                   	push   es
    2248:	57                   	push   di
    2249:	26 c4 3d             	les    di,DWORD PTR es:[di]
    224c:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    2250:	8d 7e f8             	lea    di,[bp-0x8]
    2253:	16                   	push   ss
    2254:	57                   	push   di
    2255:	6a 08                	push   0x8
    2257:	9a 1b 16 63 25       	call   0x2563:0x161b
    225c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    225f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2264:	26 8b 45 11          	mov    ax,WORD PTR es:[di+0x11]
    2268:	29 46 f8             	sub    WORD PTR [bp-0x8],ax
    226b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    226e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2273:	26 8b 45 11          	mov    ax,WORD PTR es:[di+0x11]
    2277:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    227a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    227d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2282:	26 8b 45 11          	mov    ax,WORD PTR es:[di+0x11]
    2286:	29 46 fa             	sub    WORD PTR [bp-0x6],ax
    2289:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    228c:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2291:	26 8b 45 11          	mov    ax,WORD PTR es:[di+0x11]
    2295:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2298:	ff 76 fa             	push   WORD PTR [bp-0x6]
    229b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    229e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    22a1:	06                   	push   es
    22a2:	57                   	push   di
    22a3:	9a d4 19 b2 22       	call   0x22b2:0x19d4
    22a8:	52                   	push   dx
    22a9:	50                   	push   ax
    22aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ad:	06                   	push   es
    22ae:	57                   	push   di
    22af:	9a 06 1a c8 22       	call   0x22c8:0x1a06
    22b4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    22b7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    22ba:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22bd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22c0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    22c3:	06                   	push   es
    22c4:	57                   	push   di
    22c5:	9a d4 19 d4 22       	call   0x22d4:0x19d4
    22ca:	52                   	push   dx
    22cb:	50                   	push   ax
    22cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22cf:	06                   	push   es
    22d0:	57                   	push   di
    22d1:	9a 06 1a 03 23       	call   0x2303:0x1a06
    22d6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    22d9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    22dc:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    22e0:	7d 19                	jge    0x22fb
    22e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    22ea:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    22ee:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    22f1:	50                   	push   ax
    22f2:	06                   	push   es
    22f3:	57                   	push   di
    22f4:	9a d0 1c 5c 23       	call   0x235c:0x1cd0
    22f9:	eb 63                	jmp    0x235e
    22fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fe:	06                   	push   es
    22ff:	57                   	push   di
    2300:	9a a9 18 12 23       	call   0x2312:0x18a9
    2305:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2308:	7d 54                	jge    0x235e
    230a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    230d:	06                   	push   es
    230e:	57                   	push   di
    230f:	9a a9 18 28 23       	call   0x2328:0x18a9
    2314:	8b d0                	mov    dx,ax
    2316:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2319:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    231c:	3b c2                	cmp    ax,dx
    231e:	7e 10                	jle    0x2330
    2320:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2323:	06                   	push   es
    2324:	57                   	push   di
    2325:	9a a9 18 46 23       	call   0x2346:0x18a9
    232a:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    232d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2330:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2333:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2338:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    233b:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    233e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2341:	06                   	push   es
    2342:	57                   	push   di
    2343:	9a a9 18 85 23       	call   0x2385:0x18a9
    2348:	8b d0                	mov    dx,ax
    234a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    234d:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2351:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2354:	2b c2                	sub    ax,dx
    2356:	50                   	push   ax
    2357:	06                   	push   es
    2358:	57                   	push   di
    2359:	9a d0 1c 79 23       	call   0x2379:0x1cd0
    235e:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    2362:	7d 19                	jge    0x237d
    2364:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2367:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    236c:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2370:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    2373:	50                   	push   ax
    2374:	06                   	push   es
    2375:	57                   	push   di
    2376:	9a d0 1c de 23       	call   0x23de:0x1cd0
    237b:	eb 63                	jmp    0x23e0
    237d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2380:	06                   	push   es
    2381:	57                   	push   di
    2382:	9a f4 18 94 23       	call   0x2394:0x18f4
    2387:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    238a:	7d 54                	jge    0x23e0
    238c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    238f:	06                   	push   es
    2390:	57                   	push   di
    2391:	9a f4 18 aa 23       	call   0x23aa:0x18f4
    2396:	8b d0                	mov    dx,ax
    2398:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    239b:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    239e:	3b c2                	cmp    ax,dx
    23a0:	7e 10                	jle    0x23b2
    23a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23a5:	06                   	push   es
    23a6:	57                   	push   di
    23a7:	9a f4 18 c8 23       	call   0x23c8:0x18f4
    23ac:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    23af:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    23b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b5:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    23ba:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    23bd:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    23c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c3:	06                   	push   es
    23c4:	57                   	push   di
    23c5:	9a f4 18 84 24       	call   0x2484:0x18f4
    23ca:	8b d0                	mov    dx,ax
    23cc:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    23cf:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    23d3:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    23d6:	2b c2                	sub    ax,dx
    23d8:	50                   	push   ax
    23d9:	06                   	push   es
    23da:	57                   	push   di
    23db:	9a d0 1c f6 23       	call   0x23f6:0x1cd0
    23e0:	c9                   	leave
    23e1:	ca 08 00             	retf   0x8
    23e4:	55                   	push   bp
    23e5:	89 e5                	mov    bp,sp
    23e7:	6a 00                	push   0x0
    23e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ec:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    23f1:	06                   	push   es
    23f2:	57                   	push   di
    23f3:	9a d0 1c 07 24       	call   0x2407:0x1cd0
    23f8:	6a 00                	push   0x0
    23fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fd:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2402:	06                   	push   es
    2403:	57                   	push   di
    2404:	9a d0 1c 36 24       	call   0x2436:0x1cd0
    2409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240c:	26 80 bd e0 00 00    	cmp    BYTE PTR es:[di+0xe0],0x0
    2412:	75 4b                	jne    0x245f
    2414:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2419:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    241d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2420:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2423:	9a 4b 24 00 00       	call   0x0:0x244b
    2428:	50                   	push   ax
    2429:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2431:	06                   	push   es
    2432:	57                   	push   di
    2433:	9a 21 1e 5d 24       	call   0x245d:0x1e21
    2438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    243b:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2440:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2444:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2447:	ff 76 0a             	push   WORD PTR [bp+0xa]
    244a:	9a 0e 2a 00 00       	call   0x0:0x2a0e
    244f:	50                   	push   ax
    2450:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2453:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2458:	06                   	push   es
    2459:	57                   	push   di
    245a:	9a 21 1e 74 24       	call   0x2474:0x1e21
    245f:	c9                   	leave
    2460:	ca 08 00             	retf   0x8
    2463:	55                   	push   bp
    2464:	89 e5                	mov    bp,sp
    2466:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2469:	ff 76 0a             	push   WORD PTR [bp+0xa]
    246c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246f:	06                   	push   es
    2470:	57                   	push   di
    2471:	9a e4 23 8e 24       	call   0x248e:0x23e4
    2476:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2479:	ff 76 0a             	push   WORD PTR [bp+0xa]
    247c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    247f:	06                   	push   es
    2480:	57                   	push   di
    2481:	9a 9e 5d b5 24       	call   0x24b5:0x5d9e
    2486:	c9                   	leave
    2487:	ca 08 00             	retf   0x8
    248a:	00 00                	add    BYTE PTR [bx+si],al
    248c:	c3                   	ret
    248d:	24 d5                	and    al,0xd5
    248f:	24 55                	and    al,0x55
    2491:	89 e5                	mov    bp,sp
    2493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2496:	26 c6 85 e1 00 01    	mov    BYTE PTR es:[di+0xe1],0x1
    249c:	b8 8a 24             	mov    ax,0x248a
    249f:	0e                   	push   cs
    24a0:	50                   	push   ax
    24a1:	55                   	push   bp
    24a2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    24a6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    24aa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24ad:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24b0:	06                   	push   es
    24b1:	57                   	push   di
    24b2:	9a a8 4d 09 25       	call   0x2509:0x4da8
    24b7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    24bb:	83 c4 06             	add    sp,0x6
    24be:	b8 cd 24             	mov    ax,0x24cd
    24c1:	0e                   	push   cs
    24c2:	50                   	push   ax
    24c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c6:	26 c6 85 e1 00 00    	mov    BYTE PTR es:[di+0xe1],0x0
    24cc:	cb                   	retf
    24cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d0:	06                   	push   es
    24d1:	57                   	push   di
    24d2:	9a 17 21 f7 24       	call   0x24f7:0x2117
    24d7:	c9                   	leave
    24d8:	ca 08 00             	retf   0x8
    24db:	55                   	push   bp
    24dc:	89 e5                	mov    bp,sp
    24de:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    24e1:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    24e6:	75 13                	jne    0x24fb
    24e8:	06                   	push   es
    24e9:	57                   	push   di
    24ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ed:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    24f2:	06                   	push   es
    24f3:	57                   	push   di
    24f4:	9a 0a 1c 2b 25       	call   0x252b:0x1c0a
    24f9:	eb 10                	jmp    0x250b
    24fb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24fe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2501:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2504:	06                   	push   es
    2505:	57                   	push   di
    2506:	9a 8c 4b 3d 25       	call   0x253d:0x4b8c
    250b:	c9                   	leave
    250c:	ca 08 00             	retf   0x8
    250f:	55                   	push   bp
    2510:	89 e5                	mov    bp,sp
    2512:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2515:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    251a:	75 13                	jne    0x252f
    251c:	06                   	push   es
    251d:	57                   	push   di
    251e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2521:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2526:	06                   	push   es
    2527:	57                   	push   di
    2528:	9a 0a 1c 47 25       	call   0x2547:0x1c0a
    252d:	eb 10                	jmp    0x253f
    252f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2532:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2535:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2538:	06                   	push   es
    2539:	57                   	push   di
    253a:	9a b5 4b 8f 26       	call   0x268f:0x4bb5
    253f:	c9                   	leave
    2540:	ca 08 00             	retf   0x8
    2543:	00 00                	add    BYTE PTR [bx+si],al
    2545:	d8 25                	fsub   DWORD PTR [di]
    2547:	51                   	push   cx
    2548:	25 01 00             	and    ax,0x1
    254b:	00 00                	add    BYTE PTR [bx+si],al
    254d:	00 00                	add    BYTE PTR [bx+si],al
    254f:	1a 26 76 25          	sbb    ah,BYTE PTR ds:0x2576
    2553:	c8 00 01 00          	enter  0x100,0x0
    2557:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    255b:	74 08                	je     0x2565
    255d:	83 ec 08             	sub    sp,0x8
    2560:	9a e2 1f 80 25       	call   0x2580:0x1fe2
    2565:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2568:	ff 76 0c             	push   WORD PTR [bp+0xc]
    256b:	31 c0                	xor    ax,ax
    256d:	50                   	push   ax
    256e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2571:	06                   	push   es
    2572:	57                   	push   di
    2573:	9a 5b 26 8a 25       	call   0x258a:0x265b
    2578:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257b:	06                   	push   es
    257c:	57                   	push   di
    257d:	9a dd 20 bf 25       	call   0x25bf:0x20dd
    2582:	8b c8                	mov    cx,ax
    2584:	8b da                	mov    bx,dx
    2586:	b8 fb 04             	mov    ax,0x4fb
    2589:	ba 29 26             	mov    dx,0x2629
    258c:	3b d3                	cmp    dx,bx
    258e:	75 07                	jne    0x2597
    2590:	3b c1                	cmp    ax,cx
    2592:	75 03                	jne    0x2597
    2594:	e9 ad 00             	jmp    0x2644
    2597:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259a:	26 80 8d f5 00 01    	or     BYTE PTR es:[di+0xf5],0x1
    25a0:	b8 43 25             	mov    ax,0x2543
    25a3:	0e                   	push   cs
    25a4:	50                   	push   ax
    25a5:	55                   	push   bp
    25a6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    25aa:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    25ae:	8d be 00 ff          	lea    di,[bp-0x100]
    25b2:	16                   	push   ss
    25b3:	57                   	push   di
    25b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25ba:	06                   	push   es
    25bb:	57                   	push   di
    25bc:	9a ed 20 2e 26       	call   0x262e:0x20ed
    25c1:	ff 76 08             	push   WORD PTR [bp+0x8]
    25c4:	ff 76 06             	push   WORD PTR [bp+0x6]
    25c7:	9a 78 0a b8 27       	call   0x27b8:0xa78
    25cc:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    25d0:	83 c4 06             	add    sp,0x6
    25d3:	b8 e2 25             	mov    ax,0x25e2
    25d6:	0e                   	push   cs
    25d7:	50                   	push   ax
    25d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25db:	26 80 a5 f5 00 fe    	and    BYTE PTR es:[di+0xf5],0xfe
    25e1:	cb                   	retf
    25e2:	b8 49 25             	mov    ax,0x2549
    25e5:	0e                   	push   cs
    25e6:	50                   	push   ax
    25e7:	55                   	push   bp
    25e8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    25ec:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    25f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f3:	26 8b 85 6e 01       	mov    ax,WORD PTR es:[di+0x16e]
    25f8:	09 c0                	or     ax,ax
    25fa:	74 15                	je     0x2611
    25fc:	ff 76 08             	push   WORD PTR [bp+0x8]
    25ff:	ff 76 06             	push   WORD PTR [bp+0x6]
    2602:	26 ff b5 72 01       	push   WORD PTR es:[di+0x172]
    2607:	26 ff b5 70 01       	push   WORD PTR es:[di+0x170]
    260c:	26 ff 9d 6c 01       	call   DWORD PTR es:[di+0x16c]
    2611:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2615:	83 c4 06             	add    sp,0x6
    2618:	eb 16                	jmp    0x2630
    261a:	ff 76 08             	push   WORD PTR [bp+0x8]
    261d:	ff 76 06             	push   WORD PTR [bp+0x6]
    2620:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2624:	06                   	push   es
    2625:	57                   	push   di
    2626:	9a 51 75 42 26       	call   0x2642:0x7551
    262b:	9a 34 14 6a 26       	call   0x266a:0x1434
    2630:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2633:	26 f6 85 f5 00 02    	test   BYTE PTR es:[di+0xf5],0x2
    2639:	74 09                	je     0x2644
    263b:	6a 01                	push   0x1
    263d:	06                   	push   es
    263e:	57                   	push   di
    263f:	9a 19 2f 7d 26       	call   0x267d:0x2f19
    2644:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2648:	74 07                	je     0x2651
    264a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    264e:	83 c4 06             	add    sp,0x6
    2651:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2654:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2657:	c9                   	leave
    2658:	ca 0a 00             	retf   0xa
    265b:	55                   	push   bp
    265c:	89 e5                	mov    bp,sp
    265e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2662:	74 08                	je     0x266c
    2664:	83 ec 08             	sub    sp,0x8
    2667:	9a e2 1f 18 28       	call   0x2818:0x1fe2
    266c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    266f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2672:	31 c0                	xor    ax,ax
    2674:	50                   	push   ax
    2675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2678:	06                   	push   es
    2679:	57                   	push   di
    267a:	9a 05 1f c1 26       	call   0x26c1:0x1f05
    267f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2682:	26 c7 45 26 ab 00    	mov    WORD PTR es:[di+0x26],0xab
    2688:	6a 00                	push   0x0
    268a:	06                   	push   es
    268b:	57                   	push   di
    268c:	9a 7b 17 9b 26       	call   0x269b:0x177b
    2691:	6a 00                	push   0x0
    2693:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2696:	06                   	push   es
    2697:	57                   	push   di
    2698:	9a 9d 17 a8 26       	call   0x26a8:0x179d
    269d:	68 40 01             	push   0x140
    26a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a3:	06                   	push   es
    26a4:	57                   	push   di
    26a5:	9a bf 17 b5 26       	call   0x26b5:0x17bf
    26aa:	68 f0 00             	push   0xf0
    26ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b0:	06                   	push   es
    26b1:	57                   	push   di
    26b2:	9a e1 17 cd 26       	call   0x26cd:0x17e1
    26b7:	6a 00                	push   0x0
    26b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26bc:	06                   	push   es
    26bd:	57                   	push   di
    26be:	9a 19 2f 1f 27       	call   0x271f:0x2f19
    26c3:	6a 00                	push   0x0
    26c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c8:	06                   	push   es
    26c9:	57                   	push   di
    26ca:	9a 32 1f d9 26       	call   0x26d9:0x1f32
    26cf:	6a 00                	push   0x0
    26d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d4:	06                   	push   es
    26d5:	57                   	push   di
    26d6:	9a 3e 1e e5 26       	call   0x26e5:0x1e3e
    26db:	6a 01                	push   0x1
    26dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e0:	06                   	push   es
    26e1:	57                   	push   di
    26e2:	9a 22 63 3d 27       	call   0x273d:0x6322
    26e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ea:	26 c6 85 ec 00 07    	mov    BYTE PTR es:[di+0xec],0x7
    26f0:	26 c6 85 ed 00 02    	mov    BYTE PTR es:[di+0xed],0x2
    26f6:	26 c6 85 ee 00 00    	mov    BYTE PTR es:[di+0xee],0x0
    26fc:	b0 01                	mov    al,0x1
    26fe:	50                   	push   ax
    26ff:	b8 fc 08             	mov    ax,0x8fc
    2702:	ba 0a 27             	mov    dx,0x270a
    2705:	52                   	push   dx
    2706:	50                   	push   ax
    2707:	9a 0e 64 44 27       	call   0x2744:0x640e
    270c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    270f:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    2714:	26 89 95 fe 00       	mov    WORD PTR es:[di+0xfe],dx
    2719:	06                   	push   es
    271a:	57                   	push   di
    271b:	b8 41 2c             	mov    ax,0x2c41
    271e:	ba 8a 27             	mov    dx,0x278a
    2721:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    2726:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    272a:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    272e:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    2732:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    2736:	b0 01                	mov    al,0x1
    2738:	50                   	push   ax
    2739:	b8 96 00             	mov    ax,0x96
    273c:	ba 63 27             	mov    dx,0x2763
    273f:	52                   	push   dx
    2740:	50                   	push   ax
    2741:	9a b8 17 fa 29       	call   0x29fa:0x17b8
    2746:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2749:	26 89 85 f8 00       	mov    WORD PTR es:[di+0xf8],ax
    274e:	26 89 95 fa 00       	mov    WORD PTR es:[di+0xfa],dx
    2753:	ff 76 08             	push   WORD PTR [bp+0x8]
    2756:	ff 76 06             	push   WORD PTR [bp+0x6]
    2759:	26 c4 bd f8 00       	les    di,DWORD PTR es:[di+0xf8]
    275e:	06                   	push   es
    275f:	57                   	push   di
    2760:	9a 64 13 2e 28       	call   0x282e:0x1364
    2765:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2769:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    276d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2770:	26 89 85 14 01       	mov    WORD PTR es:[di+0x114],ax
    2775:	26 c6 85 f7 00 01    	mov    BYTE PTR es:[di+0xf7],0x1
    277b:	ff 76 08             	push   WORD PTR [bp+0x8]
    277e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2781:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2785:	06                   	push   es
    2786:	57                   	push   di
    2787:	9a 9c 61 ab 27       	call   0x27ab:0x619c
    278c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2790:	74 07                	je     0x2799
    2792:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2796:	83 c4 06             	add    sp,0x6
    2799:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    279c:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    279f:	c9                   	leave
    27a0:	ca 0a 00             	retf   0xa
    27a3:	01 00                	add    WORD PTR [bx+si],ax
    27a5:	00 00                	add    BYTE PTR [bx+si],al
    27a7:	00 00                	add    BYTE PTR [bx+si],al
    27a9:	04 28                	add    al,0x28
    27ab:	ca 27 55             	retf   0x5527
    27ae:	89 e5                	mov    bp,sp
    27b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b3:	06                   	push   es
    27b4:	57                   	push   di
    27b5:	9a a5 4e 45 2b       	call   0x2b45:0x4ea5
    27ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27bd:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    27c3:	74 07                	je     0x27cc
    27c5:	06                   	push   es
    27c6:	57                   	push   di
    27c7:	9a b9 5c 13 28       	call   0x2813:0x5cb9
    27cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27cf:	26 8b 85 76 01       	mov    ax,WORD PTR es:[di+0x176]
    27d4:	09 c0                	or     ax,ax
    27d6:	74 42                	je     0x281a
    27d8:	b8 a3 27             	mov    ax,0x27a3
    27db:	0e                   	push   cs
    27dc:	50                   	push   ax
    27dd:	55                   	push   bp
    27de:	ff 36 58 18          	push   WORD PTR ds:0x1858
    27e2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    27e6:	ff 76 08             	push   WORD PTR [bp+0x8]
    27e9:	ff 76 06             	push   WORD PTR [bp+0x6]
    27ec:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    27f1:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    27f6:	26 ff 9d 74 01       	call   DWORD PTR es:[di+0x174]
    27fb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    27ff:	83 c4 06             	add    sp,0x6
    2802:	eb 16                	jmp    0x281a
    2804:	ff 76 08             	push   WORD PTR [bp+0x8]
    2807:	ff 76 06             	push   WORD PTR [bp+0x6]
    280a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    280e:	06                   	push   es
    280f:	57                   	push   di
    2810:	9a 51 75 24 28       	call   0x2824:0x7551
    2815:	9a 34 14 5e 28       	call   0x285e:0x1434
    281a:	6a 00                	push   0x0
    281c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    281f:	06                   	push   es
    2820:	57                   	push   di
    2821:	9a df 44 4f 28       	call   0x284f:0x44df
    2826:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2829:	06                   	push   es
    282a:	57                   	push   di
    282b:	9a fa 64 af 28       	call   0x28af:0x64fa
    2830:	08 c0                	or     al,al
    2832:	74 0c                	je     0x2840
    2834:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2837:	06                   	push   es
    2838:	57                   	push   di
    2839:	26 c4 3d             	les    di,DWORD PTR es:[di]
    283c:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    2840:	ff 76 08             	push   WORD PTR [bp+0x8]
    2843:	ff 76 06             	push   WORD PTR [bp+0x6]
    2846:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    284a:	06                   	push   es
    284b:	57                   	push   di
    284c:	9a b7 61 89 28       	call   0x2889:0x61b7
    2851:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2854:	26 c4 bd f8 00       	les    di,DWORD PTR es:[di+0xf8]
    2859:	06                   	push   es
    285a:	57                   	push   di
    285b:	9a 7f 1f 6d 28       	call   0x286d:0x1f7f
    2860:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2863:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    2868:	06                   	push   es
    2869:	57                   	push   di
    286a:	9a 7f 1f 7c 28       	call   0x287c:0x1f7f
    286f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2872:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    2877:	06                   	push   es
    2878:	57                   	push   di
    2879:	9a 7f 1f 94 28       	call   0x2894:0x1f7f
    287e:	31 c0                	xor    ax,ax
    2880:	50                   	push   ax
    2881:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2884:	06                   	push   es
    2885:	57                   	push   di
    2886:	9a 90 1f 08 29       	call   0x2908:0x1f90
    288b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    288f:	74 05                	je     0x2896
    2891:	9a 0f 20 f4 28       	call   0x28f4:0x200f
    2896:	c9                   	leave
    2897:	ca 06 00             	retf   0x6
    289a:	55                   	push   bp
    289b:	89 e5                	mov    bp,sp
    289d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    28a0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28a3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    28a6:	50                   	push   ax
    28a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28aa:	06                   	push   es
    28ab:	57                   	push   di
    28ac:	9a 32 16 91 29       	call   0x2991:0x1632
    28b1:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    28b4:	3c 00                	cmp    al,0x0
    28b6:	75 54                	jne    0x290c
    28b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28bb:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    28c0:	75 48                	jne    0x290a
    28c2:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    28c7:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    28cc:	75 3c                	jne    0x290a
    28ce:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28d1:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    28d5:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    28d9:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    28dc:	75 2c                	jne    0x290a
    28de:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    28e1:	75 27                	jne    0x290a
    28e3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    28e6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28e9:	bf ef 02             	mov    di,0x2ef
    28ec:	b8 e2 35             	mov    ax,0x35e2
    28ef:	50                   	push   ax
    28f0:	57                   	push   di
    28f1:	9a 55 22 c3 2e       	call   0x2ec3:0x2255
    28f6:	08 c0                	or     al,al
    28f8:	74 10                	je     0x290a
    28fa:	ff 76 0e             	push   WORD PTR [bp+0xe]
    28fd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2900:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2903:	06                   	push   es
    2904:	57                   	push   di
    2905:	9a b2 36 30 29       	call   0x2930:0x36b2
    290a:	eb 48                	jmp    0x2954
    290c:	3c 01                	cmp    al,0x1
    290e:	75 44                	jne    0x2954
    2910:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2913:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    2918:	26 8b 95 02 01       	mov    dx,WORD PTR es:[di+0x102]
    291d:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    2920:	75 10                	jne    0x2932
    2922:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2925:	75 0b                	jne    0x2932
    2927:	6a 00                	push   0x0
    2929:	6a 00                	push   0x0
    292b:	06                   	push   es
    292c:	57                   	push   di
    292d:	9a b2 36 52 29       	call   0x2952:0x36b2
    2932:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2935:	26 8b 85 10 01       	mov    ax,WORD PTR es:[di+0x110]
    293a:	26 8b 95 12 01       	mov    dx,WORD PTR es:[di+0x112]
    293f:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    2942:	75 10                	jne    0x2954
    2944:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2947:	75 0b                	jne    0x2954
    2949:	6a 00                	push   0x0
    294b:	6a 00                	push   0x0
    294d:	06                   	push   es
    294e:	57                   	push   di
    294f:	9a 7a 36 83 29       	call   0x2983:0x367a
    2954:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2957:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    295c:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    2961:	74 18                	je     0x297b
    2963:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2966:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2969:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    296c:	50                   	push   ax
    296d:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    2972:	06                   	push   es
    2973:	57                   	push   di
    2974:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2977:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    297b:	c9                   	leave
    297c:	ca 0a 00             	retf   0xa
    297f:	00 00                	add    BYTE PTR [bx+si],al
    2981:	dd 2a                	(bad)  [bp+si]
    2983:	39 2a                	cmp    WORD PTR [bp+si],bp
    2985:	c8 02 00 00          	enter  0x2,0x0
    2989:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    298c:	06                   	push   es
    298d:	57                   	push   di
    298e:	9a c5 36 c4 29       	call   0x29c4:0x36c5
    2993:	b8 7f 29             	mov    ax,0x297f
    2996:	0e                   	push   cs
    2997:	50                   	push   ax
    2998:	55                   	push   bp
    2999:	ff 36 58 18          	push   WORD PTR ds:0x1858
    299d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    29a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a4:	31 c0                	xor    ax,ax
    29a6:	26 89 85 1e 01       	mov    WORD PTR es:[di+0x11e],ax
    29ab:	31 c0                	xor    ax,ax
    29ad:	26 89 85 20 01       	mov    WORD PTR es:[di+0x120],ax
    29b2:	31 c0                	xor    ax,ax
    29b4:	26 89 85 22 01       	mov    WORD PTR es:[di+0x122],ax
    29b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    29bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    29bf:	06                   	push   es
    29c0:	57                   	push   di
    29c1:	9a ec 30 6a 2a       	call   0x2a6a:0x30ec
    29c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c9:	26 83 bd 14 01 00    	cmp    WORD PTR es:[di+0x114],0x0
    29cf:	75 03                	jne    0x29d4
    29d1:	e9 cf 00             	jmp    0x2aa3
    29d4:	26 83 bd 22 01 00    	cmp    WORD PTR es:[di+0x122],0x0
    29da:	7f 03                	jg     0x29df
    29dc:	e9 c4 00             	jmp    0x2aa3
    29df:	26 8b 85 14 01       	mov    ax,WORD PTR es:[di+0x114]
    29e4:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    29e8:	26 3b 45 1e          	cmp    ax,WORD PTR es:[di+0x1e]
    29ec:	74 43                	je     0x2a31
    29ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f1:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    29f5:	06                   	push   es
    29f6:	57                   	push   di
    29f7:	9a 19 11 1f 2a       	call   0x2a1f:0x1119
    29fc:	50                   	push   ax
    29fd:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2a01:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    2a05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a08:	26 ff b5 14 01       	push   WORD PTR es:[di+0x114]
    2a0d:	9a 7d 2a 00 00       	call   0x0:0x2a7d
    2a12:	50                   	push   ax
    2a13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a16:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2a1a:	06                   	push   es
    2a1b:	57                   	push   di
    2a1c:	9a 32 11 8f 2b       	call   0x2b8f:0x1132
    2a21:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2a25:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2a29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2c:	26 89 85 14 01       	mov    WORD PTR es:[di+0x114],ax
    2a31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a34:	06                   	push   es
    2a35:	57                   	push   di
    2a36:	9a 73 2b 58 2a       	call   0x2a58:0x2b73
    2a3b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a41:	26 8b 85 22 01       	mov    ax,WORD PTR es:[di+0x122]
    2a46:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2a49:	74 58                	je     0x2aa3
    2a4b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a4e:	26 ff b5 22 01       	push   WORD PTR es:[di+0x122]
    2a53:	06                   	push   es
    2a54:	57                   	push   di
    2a55:	9a e4 23 18 2b       	call   0x2b18:0x23e4
    2a5a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a60:	26 ff b5 22 01       	push   WORD PTR es:[di+0x122]
    2a65:	06                   	push   es
    2a66:	57                   	push   di
    2a67:	9a 4a 5d b8 2a       	call   0x2ab8:0x5d4a
    2a6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a6f:	26 ff b5 1e 01       	push   WORD PTR es:[di+0x11e]
    2a74:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a77:	26 ff b5 22 01       	push   WORD PTR es:[di+0x122]
    2a7c:	9a 97 2a 00 00       	call   0x0:0x2a97
    2a81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a84:	26 89 85 1e 01       	mov    WORD PTR es:[di+0x11e],ax
    2a89:	26 ff b5 20 01       	push   WORD PTR es:[di+0x120]
    2a8e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a91:	26 ff b5 22 01       	push   WORD PTR es:[di+0x122]
    2a96:	9a ec 2b 00 00       	call   0x0:0x2bec
    2a9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9e:	26 89 85 20 01       	mov    WORD PTR es:[di+0x120],ax
    2aa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa6:	26 83 bd 1e 01 00    	cmp    WORD PTR es:[di+0x11e],0x0
    2aac:	7e 0c                	jle    0x2aba
    2aae:	26 ff b5 1e 01       	push   WORD PTR es:[di+0x11e]
    2ab3:	06                   	push   es
    2ab4:	57                   	push   di
    2ab5:	9a ce 18 cf 2a       	call   0x2acf:0x18ce
    2aba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2abd:	26 83 bd 20 01 00    	cmp    WORD PTR es:[di+0x120],0x0
    2ac3:	7e 0c                	jle    0x2ad1
    2ac5:	26 ff b5 20 01       	push   WORD PTR es:[di+0x120]
    2aca:	06                   	push   es
    2acb:	57                   	push   di
    2acc:	9a 19 19 e5 2a       	call   0x2ae5:0x1919
    2ad1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2ad5:	83 c4 06             	add    sp,0x6
    2ad8:	b8 e8 2a             	mov    ax,0x2ae8
    2adb:	0e                   	push   cs
    2adc:	50                   	push   ax
    2add:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae0:	06                   	push   es
    2ae1:	57                   	push   di
    2ae2:	9a d4 36 08 2b       	call   0x2b08:0x36d4
    2ae7:	cb                   	retf
    2ae8:	c9                   	leave
    2ae9:	ca 08 00             	retf   0x8
    2aec:	0a 54 65             	or     dl,BYTE PTR [si+0x65]
    2aef:	78 74                	js     0x2b65
    2af1:	48                   	dec    ax
    2af2:	65 69 67 68 74 55    	imul   sp,WORD PTR gs:[bx+0x68],0x5574
    2af8:	89 e5                	mov    bp,sp
    2afa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2afd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b03:	06                   	push   es
    2b04:	57                   	push   di
    2b05:	9a 3a 27 bd 2b       	call   0x2bbd:0x273a
    2b0a:	bf ec 2a             	mov    di,0x2aec
    2b0d:	0e                   	push   cs
    2b0e:	57                   	push   di
    2b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b12:	06                   	push   es
    2b13:	57                   	push   di
    2b14:	bf 3a 2b             	mov    di,0x2b3a
    2b17:	b8 25 2b             	mov    ax,0x2b25
    2b1a:	50                   	push   ax
    2b1b:	57                   	push   di
    2b1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b1f:	06                   	push   es
    2b20:	57                   	push   di
    2b21:	bf 53 2b             	mov    di,0x2b53
    2b24:	b8 5e 2b             	mov    ax,0x2b5e
    2b27:	50                   	push   ax
    2b28:	57                   	push   di
    2b29:	6a 01                	push   0x1
    2b2b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b2e:	06                   	push   es
    2b2f:	57                   	push   di
    2b30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b33:	26 ff 1d             	call   DWORD PTR es:[di]
    2b36:	c9                   	leave
    2b37:	ca 08 00             	retf   0x8
    2b3a:	55                   	push   bp
    2b3b:	89 e5                	mov    bp,sp
    2b3d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b40:	06                   	push   es
    2b41:	57                   	push   di
    2b42:	9a 09 36 6b 2b       	call   0x2b6b:0x3609
    2b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b4a:	26 89 85 22 01       	mov    WORD PTR es:[di+0x122],ax
    2b4f:	c9                   	leave
    2b50:	ca 08 00             	retf   0x8
    2b53:	55                   	push   bp
    2b54:	89 e5                	mov    bp,sp
    2b56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b59:	06                   	push   es
    2b5a:	57                   	push   di
    2b5b:	9a 73 2b 84 2b       	call   0x2b84:0x2b73
    2b60:	99                   	cwd
    2b61:	52                   	push   dx
    2b62:	50                   	push   ax
    2b63:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b66:	06                   	push   es
    2b67:	57                   	push   di
    2b68:	9a cb 44 ac 2f       	call   0x2fac:0x44cb
    2b6d:	c9                   	leave
    2b6e:	ca 08 00             	retf   0x8
    2b71:	01 30                	add    WORD PTR [bx+si],si
    2b73:	c8 02 00 00          	enter  0x2,0x0
    2b77:	bf 71 2b             	mov    di,0x2b71
    2b7a:	0e                   	push   cs
    2b7b:	57                   	push   di
    2b7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b7f:	06                   	push   es
    2b80:	57                   	push   di
    2b81:	9a d5 33 ad 2b       	call   0x2bad:0x33d5
    2b86:	89 c7                	mov    di,ax
    2b88:	8e c2                	mov    es,dx
    2b8a:	06                   	push   es
    2b8b:	57                   	push   di
    2b8c:	9a 4e 20 20 2c       	call   0x2c20:0x204e
    2b91:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2b94:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b97:	c9                   	leave
    2b98:	ca 04 00             	retf   0x4
    2b9b:	c8 02 00 00          	enter  0x2,0x0
    2b9f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ba2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ba5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ba8:	06                   	push   es
    2ba9:	57                   	push   di
    2baa:	9a e4 23 c7 2b       	call   0x2bc7:0x23e4
    2baf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2bb2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2bb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb8:	06                   	push   es
    2bb9:	57                   	push   di
    2bba:	9a 4a 5d d5 2b       	call   0x2bd5:0x5d4a
    2bbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc2:	06                   	push   es
    2bc3:	57                   	push   di
    2bc4:	9a a4 2c f9 2b       	call   0x2bf9:0x2ca4
    2bc9:	08 c0                	or     al,al
    2bcb:	74 47                	je     0x2c14
    2bcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd0:	06                   	push   es
    2bd1:	57                   	push   di
    2bd2:	9a f4 18 e2 2b       	call   0x2be2:0x18f4
    2bd7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2bda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bdd:	06                   	push   es
    2bde:	57                   	push   di
    2bdf:	9a a9 18 4c 2c       	call   0x2c4c:0x18a9
    2be4:	50                   	push   ax
    2be5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2be8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2beb:	9a 05 2c 00 00       	call   0x0:0x2c05
    2bf0:	50                   	push   ax
    2bf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf4:	06                   	push   es
    2bf5:	57                   	push   di
    2bf6:	9a c9 2e 12 2c       	call   0x2c12:0x2ec9
    2bfb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2bfe:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c01:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c04:	9a 2a 2c 00 00       	call   0x0:0x2c2a
    2c09:	50                   	push   ax
    2c0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c0d:	06                   	push   es
    2c0e:	57                   	push   di
    2c0f:	9a f1 2e b0 2c       	call   0x2cb0:0x2ef1
    2c14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c17:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2c1b:	06                   	push   es
    2c1c:	57                   	push   di
    2c1d:	9a cc 11 3b 2c       	call   0x2c3b:0x11cc
    2c22:	50                   	push   ax
    2c23:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c26:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c29:	9a 41 5b 00 00       	call   0x0:0x5b41
    2c2e:	50                   	push   ax
    2c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c32:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2c36:	06                   	push   es
    2c37:	57                   	push   di
    2c38:	9a f5 11 c5 31       	call   0x31c5:0x11f5
    2c3d:	c9                   	leave
    2c3e:	ca 08 00             	retf   0x8
    2c41:	55                   	push   bp
    2c42:	89 e5                	mov    bp,sp
    2c44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c47:	06                   	push   es
    2c48:	57                   	push   di
    2c49:	9a b9 62 0a 2e       	call   0x2e0a:0x62b9
    2c4e:	50                   	push   ax
    2c4f:	9a 85 2c 00 00       	call   0x0:0x2c85
    2c54:	09 c0                	or     ax,ax
    2c56:	74 0e                	je     0x2c66
    2c58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c5b:	06                   	push   es
    2c5c:	57                   	push   di
    2c5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c60:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c64:	eb 3a                	jmp    0x2ca0
    2c66:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2c6a:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2c6e:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    2c72:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    2c75:	75 29                	jne    0x2ca0
    2c77:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    2c7a:	75 24                	jne    0x2ca0
    2c7c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2c80:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    2c84:	9a 65 2e 00 00       	call   0x0:0x2e65
    2c89:	09 c0                	or     ax,ax
    2c8b:	74 13                	je     0x2ca0
    2c8d:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2c91:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    2c95:	6a 00                	push   0x0
    2c97:	6a 00                	push   0x0
    2c99:	6a 01                	push   0x1
    2c9b:	9a 47 34 00 00       	call   0x0:0x3447
    2ca0:	c9                   	leave
    2ca1:	ca 08 00             	retf   0x8
    2ca4:	c8 02 00 00          	enter  0x2,0x0
    2ca8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cab:	06                   	push   es
    2cac:	57                   	push   di
    2cad:	9a c3 2c 09 2d       	call   0x2d09:0x2cc3
    2cb2:	08 c0                	or     al,al
    2cb4:	b0 00                	mov    al,0x0
    2cb6:	75 01                	jne    0x2cb9
    2cb8:	40                   	inc    ax
    2cb9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2cbc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2cbf:	c9                   	leave
    2cc0:	ca 04 00             	retf   0x4
    2cc3:	c8 02 00 00          	enter  0x2,0x0
    2cc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cca:	26 80 bd e0 00 00    	cmp    BYTE PTR es:[di+0xe0],0x0
    2cd0:	75 1f                	jne    0x2cf1
    2cd2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2cd7:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    2cdc:	75 13                	jne    0x2cf1
    2cde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ce1:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2ce6:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    2ceb:	75 04                	jne    0x2cf1
    2ced:	b0 00                	mov    al,0x0
    2cef:	eb 02                	jmp    0x2cf3
    2cf1:	b0 01                	mov    al,0x1
    2cf3:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2cf6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2cf9:	c9                   	leave
    2cfa:	ca 04 00             	retf   0x4
    2cfd:	c8 02 00 00          	enter  0x2,0x0
    2d01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d04:	06                   	push   es
    2d05:	57                   	push   di
    2d06:	9a 95 34 80 2e       	call   0x2e80:0x3495
    2d0b:	08 c0                	or     al,al
    2d0d:	74 15                	je     0x2d24
    2d0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d12:	26 80 bd ed 00 02    	cmp    BYTE PTR es:[di+0xed],0x2
    2d18:	b0 00                	mov    al,0x0
    2d1a:	75 01                	jne    0x2d1d
    2d1c:	40                   	inc    ax
    2d1d:	26 3a 85 e0 00       	cmp    al,BYTE PTR es:[di+0xe0]
    2d22:	75 04                	jne    0x2d28
    2d24:	b0 00                	mov    al,0x0
    2d26:	eb 02                	jmp    0x2d2a
    2d28:	b0 01                	mov    al,0x1
    2d2a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2d2d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2d30:	c9                   	leave
    2d31:	ca 04 00             	retf   0x4
    2d34:	55                   	push   bp
    2d35:	89 e5                	mov    bp,sp
    2d37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d3a:	26 8b 85 4e 01       	mov    ax,WORD PTR es:[di+0x14e]
    2d3f:	09 c0                	or     ax,ax
    2d41:	74 15                	je     0x2d58
    2d43:	ff 76 08             	push   WORD PTR [bp+0x8]
    2d46:	ff 76 06             	push   WORD PTR [bp+0x6]
    2d49:	26 ff b5 52 01       	push   WORD PTR es:[di+0x152]
    2d4e:	26 ff b5 50 01       	push   WORD PTR es:[di+0x150]
    2d53:	26 ff 9d 4c 01       	call   DWORD PTR es:[di+0x14c]
    2d58:	c9                   	leave
    2d59:	ca 04 00             	retf   0x4
    2d5c:	55                   	push   bp
    2d5d:	89 e5                	mov    bp,sp
    2d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d62:	26 8b 85 66 01       	mov    ax,WORD PTR es:[di+0x166]
    2d67:	09 c0                	or     ax,ax
    2d69:	74 15                	je     0x2d80
    2d6b:	ff 76 08             	push   WORD PTR [bp+0x8]
    2d6e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2d71:	26 ff b5 6a 01       	push   WORD PTR es:[di+0x16a]
    2d76:	26 ff b5 68 01       	push   WORD PTR es:[di+0x168]
    2d7b:	26 ff 9d 64 01       	call   DWORD PTR es:[di+0x164]
    2d80:	c9                   	leave
    2d81:	ca 04 00             	retf   0x4
    2d84:	c8 08 00 00          	enter  0x8,0x0
    2d88:	31 c0                	xor    ax,ax
    2d8a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d90:	26 8a 85 ed 00       	mov    al,BYTE PTR es:[di+0xed]
    2d95:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    2d98:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2d9d:	74 04                	je     0x2da3
    2d9f:	c6 46 fd 02          	mov    BYTE PTR [bp-0x3],0x2
    2da3:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    2da7:	74 59                	je     0x2e02
    2da9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2dac:	98                   	cbw
    2dad:	8b d0                	mov    dx,ax
    2daf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db2:	26 8a 85 ed 00       	mov    al,BYTE PTR es:[di+0xed]
    2db7:	98                   	cbw
    2db8:	8b f8                	mov    di,ax
    2dba:	d1 e7                	shl    di,1
    2dbc:	8b 85 32 16          	mov    ax,WORD PTR [di+0x1632]
    2dc0:	03 c2                	add    ax,dx
    2dc2:	50                   	push   ax
    2dc3:	9a e0 2d 00 00       	call   0x0:0x2de0
    2dc8:	d1 e0                	shl    ax,1
    2dca:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2dcd:	80 7e fd 03          	cmp    BYTE PTR [bp-0x3],0x3
    2dd1:	75 04                	jne    0x2dd7
    2dd3:	83 46 fe 02          	add    WORD PTR [bp-0x2],0x2
    2dd7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2ddb:	74 25                	je     0x2e02
    2ddd:	6a 04                	push   0x4
    2ddf:	9a fa 2d 00 00       	call   0x0:0x2dfa
    2de4:	48                   	dec    ax
    2de5:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2de8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2deb:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    2df0:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    2df5:	74 0b                	je     0x2e02
    2df7:	6a 0f                	push   0xf
    2df9:	9a 39 2e 00 00       	call   0x0:0x2e39
    2dfe:	40                   	inc    ax
    2dff:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e05:	06                   	push   es
    2e06:	57                   	push   di
    2e07:	9a b9 62 61 2e       	call   0x2e61:0x62b9
    2e0c:	50                   	push   ax
    2e0d:	6a f0                	push   0xfff0
    2e0f:	9a 9f 3d 00 00       	call   0x0:0x3d9f
    2e14:	8b c8                	mov    cx,ax
    2e16:	8b da                	mov    bx,dx
    2e18:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2e1b:	98                   	cbw
    2e1c:	8b f8                	mov    di,ax
    2e1e:	c1 e7 02             	shl    di,0x2
    2e21:	8b 85 3a 16          	mov    ax,WORD PTR [di+0x163a]
    2e25:	8b 95 3c 16          	mov    dx,WORD PTR [di+0x163c]
    2e29:	23 c1                	and    ax,cx
    2e2b:	23 d3                	and    dx,bx
    2e2d:	09 d0                	or     ax,dx
    2e2f:	74 1d                	je     0x2e4e
    2e31:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2e34:	98                   	cbw
    2e35:	40                   	inc    ax
    2e36:	40                   	inc    ax
    2e37:	50                   	push   ax
    2e38:	9a ac 60 00 00       	call   0x0:0x60ac
    2e3d:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2e40:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    2e43:	3c 01                	cmp    al,0x1
    2e45:	72 07                	jb     0x2e4e
    2e47:	3c 02                	cmp    al,0x2
    2e49:	77 03                	ja     0x2e4e
    2e4b:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    2e4e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e51:	c9                   	leave
    2e52:	ca 06 00             	retf   0x6
    2e55:	c8 08 00 00          	enter  0x8,0x0
    2e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e5c:	06                   	push   es
    2e5d:	57                   	push   di
    2e5e:	9a b9 62 b7 2e       	call   0x2eb7:0x62b9
    2e63:	50                   	push   ax
    2e64:	9a bd 47 00 00       	call   0x0:0x47bd
    2e69:	09 c0                	or     ax,ax
    2e6b:	74 3d                	je     0x2eaa
    2e6d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e70:	06                   	push   es
    2e71:	57                   	push   di
    2e72:	6a 00                	push   0x0
    2e74:	6a 00                	push   0x0
    2e76:	6a 00                	push   0x0
    2e78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e7b:	06                   	push   es
    2e7c:	57                   	push   di
    2e7d:	9a 84 2d 95 2e       	call   0x2e95:0x2d84
    2e82:	8b d0                	mov    dx,ax
    2e84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e87:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2e8b:	2b c2                	sub    ax,dx
    2e8d:	50                   	push   ax
    2e8e:	6a 01                	push   0x1
    2e90:	06                   	push   es
    2e91:	57                   	push   di
    2e92:	9a 84 2d 9e 30       	call   0x309e:0x2d84
    2e97:	8b d0                	mov    dx,ax
    2e99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9c:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2ea0:	2b c2                	sub    ax,dx
    2ea2:	50                   	push   ax
    2ea3:	9a ff ff 00 00       	call   0x0:0xffff
    2ea8:	eb 1b                	jmp    0x2ec5
    2eaa:	8d 7e f8             	lea    di,[bp-0x8]
    2ead:	16                   	push   ss
    2eae:	57                   	push   di
    2eaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb2:	06                   	push   es
    2eb3:	57                   	push   di
    2eb4:	9a 06 63 eb 2e       	call   0x2eeb:0x6306
    2eb9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ebc:	06                   	push   es
    2ebd:	57                   	push   di
    2ebe:	6a 08                	push   0x8
    2ec0:	9a 1b 16 8b 2f       	call   0x2f8b:0x161b
    2ec5:	c9                   	leave
    2ec6:	ca 04 00             	retf   0x4
    2ec9:	55                   	push   bp
    2eca:	89 e5                	mov    bp,sp
    2ecc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ecf:	26 f6 45 28 08       	test   BYTE PTR es:[di+0x28],0x8
    2ed4:	74 0a                	je     0x2ee0
    2ed6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2ed9:	26 89 85 1e 01       	mov    WORD PTR es:[di+0x11e],ax
    2ede:	eb 0d                	jmp    0x2eed
    2ee0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ee3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee6:	06                   	push   es
    2ee7:	57                   	push   di
    2ee8:	9a ce 18 13 2f       	call   0x2f13:0x18ce
    2eed:	c9                   	leave
    2eee:	ca 06 00             	retf   0x6
    2ef1:	55                   	push   bp
    2ef2:	89 e5                	mov    bp,sp
    2ef4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef7:	26 f6 45 28 08       	test   BYTE PTR es:[di+0x28],0x8
    2efc:	74 0a                	je     0x2f08
    2efe:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2f01:	26 89 85 20 01       	mov    WORD PTR es:[di+0x120],ax
    2f06:	eb 0d                	jmp    0x2f15
    2f08:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2f0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f0e:	06                   	push   es
    2f0f:	57                   	push   di
    2f10:	9a 19 19 4c 2f       	call   0x2f4c:0x1919
    2f15:	c9                   	leave
    2f16:	ca 06 00             	retf   0x6
    2f19:	55                   	push   bp
    2f1a:	89 e5                	mov    bp,sp
    2f1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f1f:	26 f6 85 f5 00 01    	test   BYTE PTR es:[di+0xf5],0x1
    2f25:	74 19                	je     0x2f40
    2f27:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2f2b:	74 08                	je     0x2f35
    2f2d:	26 80 8d f5 00 02    	or     BYTE PTR es:[di+0xf5],0x2
    2f33:	eb 09                	jmp    0x2f3e
    2f35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f38:	26 80 a5 f5 00 fd    	and    BYTE PTR es:[di+0xf5],0xfd
    2f3e:	eb 0e                	jmp    0x2f4e
    2f40:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f43:	50                   	push   ax
    2f44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f47:	06                   	push   es
    2f48:	57                   	push   di
    2f49:	9a 77 1c 7d 2f       	call   0x2f7d:0x1c77
    2f4e:	c9                   	leave
    2f4f:	ca 06 00             	retf   0x6
    2f52:	c8 00 01 00          	enter  0x100,0x0
    2f56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f59:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    2f5f:	75 2c                	jne    0x2f8d
    2f61:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2f66:	74 25                	je     0x2f8d
    2f68:	8d be 00 ff          	lea    di,[bp-0x100]
    2f6c:	16                   	push   ss
    2f6d:	57                   	push   di
    2f6e:	68 2b f0             	push   0xf02b
    2f71:	9a 2b 09 84 2f       	call   0x2f84:0x92b
    2f76:	b0 01                	mov    al,0x1
    2f78:	50                   	push   ax
    2f79:	b8 52 00             	mov    ax,0x52
    2f7c:	ba 09 30             	mov    dx,0x3009
    2f7f:	52                   	push   dx
    2f80:	50                   	push   ax
    2f81:	9a e6 28 32 3e       	call   0x3e32:0x28e6
    2f86:	52                   	push   dx
    2f87:	50                   	push   ax
    2f88:	9a 99 13 1c 36       	call   0x361c:0x1399
    2f8d:	c9                   	leave
    2f8e:	ca 04 00             	retf   0x4
    2f91:	55                   	push   bp
    2f92:	89 e5                	mov    bp,sp
    2f94:	ff 76 14             	push   WORD PTR [bp+0x14]
    2f97:	ff 76 12             	push   WORD PTR [bp+0x12]
    2f9a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2f9d:	06                   	push   es
    2f9e:	57                   	push   di
    2f9f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fa2:	06                   	push   es
    2fa3:	57                   	push   di
    2fa4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa7:	06                   	push   es
    2fa8:	57                   	push   di
    2fa9:	9a 38 50 a8 41       	call   0x41a8:0x5038
    2fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb1:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    2fb6:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    2fbb:	74 21                	je     0x2fde
    2fbd:	ff 76 14             	push   WORD PTR [bp+0x14]
    2fc0:	ff 76 12             	push   WORD PTR [bp+0x12]
    2fc3:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2fc6:	06                   	push   es
    2fc7:	57                   	push   di
    2fc8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fcb:	06                   	push   es
    2fcc:	57                   	push   di
    2fcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd0:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    2fd5:	06                   	push   es
    2fd6:	57                   	push   di
    2fd7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2fda:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2fde:	c9                   	leave
    2fdf:	ca 10 00             	retf   0x10
    2fe2:	c8 06 00 00          	enter  0x6,0x0
    2fe6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fe9:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2fec:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2fef:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2ff2:	3d 0c 00             	cmp    ax,0xc
    2ff5:	74 0a                	je     0x3001
    2ff7:	3d 85 00             	cmp    ax,0x85
    2ffa:	74 05                	je     0x3001
    2ffc:	3d 86 00             	cmp    ax,0x86
    2fff:	75 59                	jne    0x305a
    3001:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3004:	06                   	push   es
    3005:	57                   	push   di
    3006:	9a fa 64 30 30       	call   0x3030:0x64fa
    300b:	08 c0                	or     al,al
    300d:	74 48                	je     0x3057
    300f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3012:	26 80 bd ed 00 03    	cmp    BYTE PTR es:[di+0xed],0x3
    3018:	75 3d                	jne    0x3057
    301a:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    3020:	74 35                	je     0x3057
    3022:	a1 26 15             	mov    ax,ds:0x1526
    3025:	0b 06 28 15          	or     ax,WORD PTR ds:0x1528
    3029:	74 2c                	je     0x3057
    302b:	06                   	push   es
    302c:	57                   	push   di
    302d:	9a b9 62 b7 30       	call   0x30b7:0x62b9
    3032:	50                   	push   ax
    3033:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3036:	26 ff 35             	push   WORD PTR es:[di]
    3039:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    303d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3041:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3045:	ff 1e 26 15          	call   DWORD PTR ds:0x1526
    3049:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    304c:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    3050:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    3054:	e9 bb 00             	jmp    0x3112
    3057:	e9 a9 00             	jmp    0x3103
    305a:	3d 06 00             	cmp    ax,0x6
    305d:	74 0d                	je     0x306c
    305f:	3d 07 00             	cmp    ax,0x7
    3062:	74 08                	je     0x306c
    3064:	3d 08 00             	cmp    ax,0x8
    3067:	74 03                	je     0x306c
    3069:	e9 97 00             	jmp    0x3103
    306c:	80 3e 32 15 00       	cmp    BYTE PTR ds:0x1532,0x0
    3071:	75 03                	jne    0x3076
    3073:	e9 9c 00             	jmp    0x3112
    3076:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3079:	26 83 3d 07          	cmp    WORD PTR es:[di],0x7
    307d:	74 03                	je     0x3082
    307f:	e9 81 00             	jmp    0x3103
    3082:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3085:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    308a:	75 77                	jne    0x3103
    308c:	31 c0                	xor    ax,ax
    308e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3091:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    3097:	75 25                	jne    0x30be
    3099:	06                   	push   es
    309a:	57                   	push   di
    309b:	9a ae 32 ac 30       	call   0x30ac:0x32ae
    30a0:	09 d0                	or     ax,dx
    30a2:	74 18                	je     0x30bc
    30a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30a7:	06                   	push   es
    30a8:	57                   	push   di
    30a9:	9a ae 32 fd 31       	call   0x31fd:0x32ae
    30ae:	89 c7                	mov    di,ax
    30b0:	8e c2                	mov    es,dx
    30b2:	06                   	push   es
    30b3:	57                   	push   di
    30b4:	9a b9 62 ee 30       	call   0x30ee:0x62b9
    30b9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    30bc:	eb 35                	jmp    0x30f3
    30be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c1:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    30c6:	26 0b 85 e6 00       	or     ax,WORD PTR es:[di+0xe6]
    30cb:	74 26                	je     0x30f3
    30cd:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    30d2:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    30d7:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    30da:	75 05                	jne    0x30e1
    30dc:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    30df:	74 12                	je     0x30f3
    30e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e4:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    30e9:	06                   	push   es
    30ea:	57                   	push   di
    30eb:	9a b9 62 10 31       	call   0x3110:0x62b9
    30f0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    30f3:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    30f7:	74 0a                	je     0x3103
    30f9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    30fc:	9a 5f 44 00 00       	call   0x0:0x445f
    3101:	eb 0f                	jmp    0x3112
    3103:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3106:	06                   	push   es
    3107:	57                   	push   di
    3108:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    310b:	06                   	push   es
    310c:	57                   	push   di
    310d:	9a 46 44 68 32       	call   0x3268:0x4446
    3112:	c9                   	leave
    3113:	ca 08 00             	retf   0x8
    3116:	c8 04 00 00          	enter  0x4,0x0
    311a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    311d:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    3121:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3124:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3127:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    312a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    312e:	26 ff b5 26 01       	push   WORD PTR es:[di+0x126]
    3133:	26 ff b5 24 01       	push   WORD PTR es:[di+0x124]
    3138:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    313d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3140:	26 ff 35             	push   WORD PTR es:[di]
    3143:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3147:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    314b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    314f:	9a 43 53 00 00       	call   0x0:0x5343
    3154:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3157:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    315b:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    315f:	c9                   	leave
    3160:	c2 02 00             	ret    0x2
    3163:	c8 0c 00 00          	enter  0xc,0x0
    3167:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    316a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    316d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3170:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3173:	3d 84 00             	cmp    ax,0x84
    3176:	75 23                	jne    0x319b
    3178:	55                   	push   bp
    3179:	e8 9a ff             	call   0x3116
    317c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    317f:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    3184:	75 13                	jne    0x3199
    3186:	26 83 7d 08 01       	cmp    WORD PTR es:[di+0x8],0x1
    318b:	75 0c                	jne    0x3199
    318d:	26 c7 45 08 ff ff    	mov    WORD PTR es:[di+0x8],0xffff
    3193:	26 c7 45 0a ff ff    	mov    WORD PTR es:[di+0xa],0xffff
    3199:	eb 47                	jmp    0x31e2
    319b:	3d 14 00             	cmp    ax,0x14
    319e:	75 3e                	jne    0x31de
    31a0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31a3:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    31a7:	8d 7e f4             	lea    di,[bp-0xc]
    31aa:	16                   	push   ss
    31ab:	57                   	push   di
    31ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31af:	06                   	push   es
    31b0:	57                   	push   di
    31b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31b4:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    31b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31bb:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    31c0:	06                   	push   es
    31c1:	57                   	push   di
    31c2:	9a c0 16 cf 34       	call   0x34cf:0x16c0
    31c7:	50                   	push   ax
    31c8:	9a 62 48 00 00       	call   0x0:0x4862
    31cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31d0:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    31d6:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    31dc:	eb 04                	jmp    0x31e2
    31de:	55                   	push   bp
    31df:	e8 34 ff             	call   0x3116
    31e2:	c9                   	leave
    31e3:	ca 08 00             	retf   0x8
    31e6:	c8 04 00 00          	enter  0x4,0x0
    31ea:	ff 76 10             	push   WORD PTR [bp+0x10]
    31ed:	ff 76 0e             	push   WORD PTR [bp+0xe]
    31f0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31f3:	06                   	push   es
    31f4:	57                   	push   di
    31f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f8:	06                   	push   es
    31f9:	57                   	push   di
    31fa:	9a e8 1f 97 32       	call   0x3297:0x1fe8
    31ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3202:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    3208:	74 36                	je     0x3240
    320a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    320d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3210:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3213:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3216:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    321b:	6a 01                	push   0x1
    321d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3220:	26 ff 35             	push   WORD PTR es:[di]
    3223:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3227:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    322b:	26 2b 05             	sub    ax,WORD PTR es:[di]
    322e:	50                   	push   ax
    322f:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    3233:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    3237:	50                   	push   ax
    3238:	68 00 01             	push   0x100
    323b:	9a e4 3d 00 00       	call   0x0:0x3de4
    3240:	c9                   	leave
    3241:	ca 0c 00             	retf   0xc
    3244:	55                   	push   bp
    3245:	89 e5                	mov    bp,sp
    3247:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    324a:	26 8a 85 ec 00       	mov    al,BYTE PTR es:[di+0xec]
    324f:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    3252:	74 16                	je     0x326a
    3254:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3257:	26 88 85 ec 00       	mov    BYTE PTR es:[di+0xec],al
    325c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3261:	75 07                	jne    0x326a
    3263:	06                   	push   es
    3264:	57                   	push   di
    3265:	9a 5a 40 a8 32       	call   0x32a8:0x405a
    326a:	c9                   	leave
    326b:	ca 06 00             	retf   0x6
    326e:	55                   	push   bp
    326f:	89 e5                	mov    bp,sp
    3271:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3274:	26 8a 85 ed 00       	mov    al,BYTE PTR es:[di+0xed]
    3279:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    327c:	74 2c                	je     0x32aa
    327e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3281:	26 88 85 ed 00       	mov    BYTE PTR es:[di+0xed],al
    3286:	26 80 bd ed 00 02    	cmp    BYTE PTR es:[di+0xed],0x2
    328c:	b0 00                	mov    al,0x0
    328e:	75 01                	jne    0x3291
    3290:	40                   	inc    ax
    3291:	50                   	push   ax
    3292:	06                   	push   es
    3293:	57                   	push   di
    3294:	9a a6 20 1b 33       	call   0x331b:0x20a6
    3299:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    32a1:	75 07                	jne    0x32aa
    32a3:	06                   	push   es
    32a4:	57                   	push   di
    32a5:	9a 5a 40 e4 32       	call   0x32e4:0x405a
    32aa:	c9                   	leave
    32ab:	ca 06 00             	retf   0x6
    32ae:	c8 04 00 00          	enter  0x4,0x0
    32b2:	31 c0                	xor    ax,ax
    32b4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    32b7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    32ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32bd:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    32c3:	75 27                	jne    0x32ec
    32c5:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    32cb:	74 1f                	je     0x32ec
    32cd:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    32d2:	68 29 02             	push   0x229
    32d5:	6a 00                	push   0x0
    32d7:	6a 00                	push   0x0
    32d9:	6a 00                	push   0x0
    32db:	9a 2e 36 00 00       	call   0x0:0x362e
    32e0:	50                   	push   ax
    32e1:	9a 4f 0b 20 34       	call   0x3420:0xb4f
    32e6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    32e9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    32ec:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    32ef:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    32f2:	c9                   	leave
    32f3:	ca 04 00             	retf   0x4
    32f6:	c8 06 00 00          	enter  0x6,0x0
    32fa:	31 c0                	xor    ax,ax
    32fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    32ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3302:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    3308:	75 4b                	jne    0x3355
    330a:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    3310:	74 43                	je     0x3355
    3312:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3316:	06                   	push   es
    3317:	57                   	push   di
    3318:	9a f4 60 3c 33       	call   0x333c:0x60f4
    331d:	48                   	dec    ax
    331e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3321:	31 c0                	xor    ax,ax
    3323:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3326:	7f 2d                	jg     0x3355
    3328:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    332b:	eb 03                	jmp    0x3330
    332d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3330:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3333:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3337:	06                   	push   es
    3338:	57                   	push   di
    3339:	9a cf 60 7c 33       	call   0x337c:0x60cf
    333e:	89 c7                	mov    di,ax
    3340:	8e c2                	mov    es,dx
    3342:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    3348:	75 03                	jne    0x334d
    334a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    334d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3350:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3353:	75 d8                	jne    0x332d
    3355:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3358:	c9                   	leave
    3359:	ca 04 00             	retf   0x4
    335c:	c8 08 00 00          	enter  0x8,0x0
    3360:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3363:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    3369:	75 58                	jne    0x33c3
    336b:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    3371:	74 50                	je     0x33c3
    3373:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3377:	06                   	push   es
    3378:	57                   	push   di
    3379:	9a f4 60 9d 33       	call   0x339d:0x60f4
    337e:	48                   	dec    ax
    337f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3382:	31 c0                	xor    ax,ax
    3384:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3387:	7f 3a                	jg     0x33c3
    3389:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    338c:	eb 03                	jmp    0x3391
    338e:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3391:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3394:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3398:	06                   	push   es
    3399:	57                   	push   di
    339a:	9a cf 60 bc 34       	call   0x34bc:0x60cf
    339f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    33a2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    33a5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33a8:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    33ae:	75 0b                	jne    0x33bb
    33b0:	ff 4e 0a             	dec    WORD PTR [bp+0xa]
    33b3:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    33b7:	7d 02                	jge    0x33bb
    33b9:	eb 10                	jmp    0x33cb
    33bb:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    33be:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    33c1:	75 cb                	jne    0x338e
    33c3:	31 c0                	xor    ax,ax
    33c5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    33c8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    33cb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33ce:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33d1:	c9                   	leave
    33d2:	ca 06 00             	retf   0x6
    33d5:	c8 04 00 00          	enter  0x4,0x0
    33d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33dc:	26 8b 85 f8 00       	mov    ax,WORD PTR es:[di+0xf8]
    33e1:	26 8b 95 fa 00       	mov    dx,WORD PTR es:[di+0xfa]
    33e6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    33e9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    33ec:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33ef:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33f2:	c9                   	leave
    33f3:	ca 04 00             	retf   0x4
    33f6:	55                   	push   bp
    33f7:	89 e5                	mov    bp,sp
    33f9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33fc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3402:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    3407:	06                   	push   es
    3408:	57                   	push   di
    3409:	26 c4 3d             	les    di,DWORD PTR es:[di]
    340c:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3410:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3413:	26 80 bd ee 00 01    	cmp    BYTE PTR es:[di+0xee],0x1
    3419:	75 07                	jne    0x3422
    341b:	06                   	push   es
    341c:	57                   	push   di
    341d:	9a c6 22 1f 35       	call   0x351f:0x22c6
    3422:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3425:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3428:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    342c:	26 3b 55 22          	cmp    dx,WORD PTR es:[di+0x22]
    3430:	75 19                	jne    0x344b
    3432:	26 3b 45 20          	cmp    ax,WORD PTR es:[di+0x20]
    3436:	75 13                	jne    0x344b
    3438:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    343c:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    3440:	6a 00                	push   0x0
    3442:	6a 00                	push   0x0
    3444:	6a 01                	push   0x1
    3446:	9a ff ff 00 00       	call   0x0:0xffff
    344b:	c9                   	leave
    344c:	ca 08 00             	retf   0x8
    344f:	c8 02 00 00          	enter  0x2,0x0
    3453:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3456:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    345c:	74 0e                	je     0x346c
    345e:	26 83 7d 3a ff       	cmp    WORD PTR es:[di+0x3a],0xffff
    3463:	75 24                	jne    0x3489
    3465:	26 83 7d 38 f0       	cmp    WORD PTR es:[di+0x38],0xfff0
    346a:	75 1d                	jne    0x3489
    346c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    346f:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    3475:	75 0e                	jne    0x3485
    3477:	26 83 7d 3a ff       	cmp    WORD PTR es:[di+0x3a],0xffff
    347c:	75 0b                	jne    0x3489
    347e:	26 83 7d 38 fa       	cmp    WORD PTR es:[di+0x38],0xfffa
    3483:	75 04                	jne    0x3489
    3485:	b0 00                	mov    al,0x0
    3487:	eb 02                	jmp    0x348b
    3489:	b0 01                	mov    al,0x1
    348b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    348e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3491:	c9                   	leave
    3492:	ca 04 00             	retf   0x4
    3495:	c8 02 00 00          	enter  0x2,0x0
    3499:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    349c:	26 80 7d 2f 00       	cmp    BYTE PTR es:[di+0x2f],0x0
    34a1:	b0 00                	mov    al,0x0
    34a3:	75 01                	jne    0x34a6
    34a5:	40                   	inc    ax
    34a6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    34a9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    34ac:	c9                   	leave
    34ad:	ca 04 00             	retf   0x4
    34b0:	c8 02 00 00          	enter  0x2,0x0
    34b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b7:	06                   	push   es
    34b8:	57                   	push   di
    34b9:	9a 95 34 0e 35       	call   0x350e:0x3495
    34be:	08 c0                	or     al,al
    34c0:	74 13                	je     0x34d5
    34c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c5:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    34ca:	06                   	push   es
    34cb:	57                   	push   di
    34cc:	9a 94 65 19 39       	call   0x3919:0x6594
    34d1:	09 c0                	or     ax,ax
    34d3:	75 04                	jne    0x34d9
    34d5:	b0 00                	mov    al,0x0
    34d7:	eb 02                	jmp    0x34db
    34d9:	b0 01                	mov    al,0x1
    34db:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    34de:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    34e1:	c9                   	leave
    34e2:	ca 04 00             	retf   0x4
    34e5:	c8 02 00 00          	enter  0x2,0x0
    34e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ec:	26 8a 85 f2 00       	mov    al,BYTE PTR es:[di+0xf2]
    34f1:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    34f4:	75 03                	jne    0x34f9
    34f6:	e9 88 00             	jmp    0x3581
    34f9:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    34fd:	75 11                	jne    0x3510
    34ff:	26 80 bd f3 00 00    	cmp    BYTE PTR es:[di+0xf3],0x0
    3505:	75 09                	jne    0x3510
    3507:	6a 01                	push   0x1
    3509:	06                   	push   es
    350a:	57                   	push   di
    350b:	9a 65 38 50 35       	call   0x3550:0x3865
    3510:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3513:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3518:	75 07                	jne    0x3521
    351a:	06                   	push   es
    351b:	57                   	push   di
    351c:	9a ee 3f 5c 35       	call   0x355c:0x3fee
    3521:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3524:	26 8a 85 f2 00       	mov    al,BYTE PTR es:[di+0xf2]
    3529:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    352c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    352f:	26 88 85 f2 00       	mov    BYTE PTR es:[di+0xf2],al
    3534:	80 7e 0a 02          	cmp    BYTE PTR [bp+0xa],0x2
    3538:	74 06                	je     0x3540
    353a:	80 7e ff 02          	cmp    BYTE PTR [bp-0x1],0x2
    353e:	75 1e                	jne    0x355e
    3540:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3543:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    3549:	75 13                	jne    0x355e
    354b:	06                   	push   es
    354c:	57                   	push   di
    354d:	9a 1f 39 7f 35       	call   0x357f:0x391f
    3552:	52                   	push   dx
    3553:	50                   	push   ax
    3554:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3557:	06                   	push   es
    3558:	57                   	push   di
    3559:	9a d5 1e 6d 35       	call   0x356d:0x1ed5
    355e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3561:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3566:	75 07                	jne    0x356f
    3568:	06                   	push   es
    3569:	57                   	push   di
    356a:	9a a5 41 ef 35       	call   0x35ef:0x41a5
    356f:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    3573:	75 0c                	jne    0x3581
    3575:	6a 01                	push   0x1
    3577:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    357a:	06                   	push   es
    357b:	57                   	push   di
    357c:	9a 19 2f ac 36       	call   0x36ac:0x2f19
    3581:	c9                   	leave
    3582:	ca 06 00             	retf   0x6
    3585:	c8 06 00 00          	enter  0x6,0x0
    3589:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    358c:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    3592:	74 03                	je     0x3597
    3594:	e9 b1 00             	jmp    0x3648
    3597:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    359d:	75 03                	jne    0x35a2
    359f:	e9 a6 00             	jmp    0x3648
    35a2:	31 c0                	xor    ax,ax
    35a4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    35a7:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    35ac:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    35b1:	74 11                	je     0x35c4
    35b3:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    35b8:	06                   	push   es
    35b9:	57                   	push   di
    35ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35bd:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    35c1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    35c4:	31 c0                	xor    ax,ax
    35c6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    35c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35cc:	26 8b 85 10 01       	mov    ax,WORD PTR es:[di+0x110]
    35d1:	26 0b 85 12 01       	or     ax,WORD PTR es:[di+0x112]
    35d6:	74 0f                	je     0x35e7
    35d8:	26 c4 bd 10 01       	les    di,DWORD PTR es:[di+0x110]
    35dd:	06                   	push   es
    35de:	57                   	push   di
    35df:	9a 5d 10 74 36       	call   0x3674:0x105d
    35e4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    35e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ea:	06                   	push   es
    35eb:	57                   	push   di
    35ec:	9a b9 62 40 36       	call   0x3640:0x62b9
    35f1:	50                   	push   ax
    35f2:	9a 63 37 00 00       	call   0x0:0x3763
    35f7:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    35fa:	b0 00                	mov    al,0x0
    35fc:	74 01                	je     0x35ff
    35fe:	40                   	inc    ax
    35ff:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    3602:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3605:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    360a:	68 30 02             	push   0x230
    360d:	6a 00                	push   0x0
    360f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3612:	31 d2                	xor    dx,dx
    3614:	b9 10 00             	mov    cx,0x10
    3617:	31 db                	xor    bx,bx
    3619:	9a 39 17 49 3e       	call   0x3e49:0x1739
    361e:	8b c8                	mov    cx,ax
    3620:	8b da                	mov    bx,dx
    3622:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3625:	31 d2                	xor    dx,dx
    3627:	0b c1                	or     ax,cx
    3629:	0b d3                	or     dx,bx
    362b:	52                   	push   dx
    362c:	50                   	push   ax
    362d:	9a bd 3e 00 00       	call   0x0:0x3ebd
    3632:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    3636:	74 10                	je     0x3648
    3638:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    363b:	06                   	push   es
    363c:	57                   	push   di
    363d:	9a b9 62 3f 37       	call   0x373f:0x62b9
    3642:	50                   	push   ax
    3643:	9a ff ff 00 00       	call   0x0:0xffff
    3648:	c9                   	leave
    3649:	ca 04 00             	retf   0x4
    364c:	55                   	push   bp
    364d:	89 e5                	mov    bp,sp
    364f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3652:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3655:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3658:	26 89 85 16 01       	mov    WORD PTR es:[di+0x116],ax
    365d:	26 89 95 18 01       	mov    WORD PTR es:[di+0x118],dx
    3662:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3665:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3668:	74 0c                	je     0x3676
    366a:	6a 00                	push   0x0
    366c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    366f:	06                   	push   es
    3670:	57                   	push   di
    3671:	9a 9b 12 d1 36       	call   0x36d1:0x129b
    3676:	c9                   	leave
    3677:	ca 08 00             	retf   0x8
    367a:	55                   	push   bp
    367b:	89 e5                	mov    bp,sp
    367d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3680:	26 8b 85 10 01       	mov    ax,WORD PTR es:[di+0x110]
    3685:	26 8b 95 12 01       	mov    dx,WORD PTR es:[di+0x112]
    368a:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    368d:	75 05                	jne    0x3694
    368f:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3692:	74 1a                	je     0x36ae
    3694:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3697:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    369a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    369d:	26 89 85 10 01       	mov    WORD PTR es:[di+0x110],ax
    36a2:	26 89 95 12 01       	mov    WORD PTR es:[di+0x112],dx
    36a7:	06                   	push   es
    36a8:	57                   	push   di
    36a9:	9a 85 35 01 38       	call   0x3801:0x3585
    36ae:	c9                   	leave
    36af:	ca 08 00             	retf   0x8
    36b2:	c8 04 00 00          	enter  0x4,0x0
    36b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b9:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    36be:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    36c3:	74 0e                	je     0x36d3
    36c5:	6a 00                	push   0x0
    36c7:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    36cc:	06                   	push   es
    36cd:	57                   	push   di
    36ce:	9a 77 1d a1 37       	call   0x37a1:0x1d77
    36d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36d6:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    36db:	26 8b 95 02 01       	mov    dx,WORD PTR es:[di+0x102]
    36e0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    36e3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    36e6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    36e9:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    36ec:	26 89 85 00 01       	mov    WORD PTR es:[di+0x100],ax
    36f1:	26 89 95 02 01       	mov    WORD PTR es:[di+0x102],dx
    36f6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    36f9:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    36fc:	75 03                	jne    0x3701
    36fe:	e9 ce 00             	jmp    0x37cf
    3701:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3706:	75 0b                	jne    0x3713
    3708:	26 80 bd ed 00 03    	cmp    BYTE PTR es:[di+0xed],0x3
    370e:	75 03                	jne    0x3713
    3710:	e9 bc 00             	jmp    0x37cf
    3713:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3716:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    371b:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3720:	75 0b                	jne    0x372d
    3722:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3725:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    372b:	75 0a                	jne    0x3737
    372d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3730:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3735:	74 6e                	je     0x37a5
    3737:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    373a:	06                   	push   es
    373b:	57                   	push   di
    373c:	9a fa 64 5f 37       	call   0x375f:0x64fa
    3741:	08 c0                	or     al,al
    3743:	74 5e                	je     0x37a3
    3745:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3748:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    374d:	06                   	push   es
    374e:	57                   	push   di
    374f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3752:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    3756:	50                   	push   ax
    3757:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    375a:	06                   	push   es
    375b:	57                   	push   di
    375c:	9a b9 62 74 37       	call   0x3774:0x62b9
    3761:	50                   	push   ax
    3762:	9a ff ff 00 00       	call   0x0:0xffff
    3767:	5a                   	pop    dx
    3768:	3b c2                	cmp    ax,dx
    376a:	74 22                	je     0x378e
    376c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    376f:	06                   	push   es
    3770:	57                   	push   di
    3771:	9a b9 62 96 37       	call   0x3796:0x62b9
    3776:	50                   	push   ax
    3777:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    377a:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    377f:	06                   	push   es
    3780:	57                   	push   di
    3781:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3784:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    3788:	50                   	push   ax
    3789:	9a c9 37 00 00       	call   0x0:0x37c9
    378e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3791:	06                   	push   es
    3792:	57                   	push   di
    3793:	9a b9 62 b5 37       	call   0x37b5:0x62b9
    3798:	50                   	push   ax
    3799:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    379c:	06                   	push   es
    379d:	57                   	push   di
    379e:	9a 77 1d 2b 3d       	call   0x3d2b:0x1d77
    37a3:	eb 28                	jmp    0x37cd
    37a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37a8:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    37ae:	74 1d                	je     0x37cd
    37b0:	06                   	push   es
    37b1:	57                   	push   di
    37b2:	9a fa 64 c3 37       	call   0x37c3:0x64fa
    37b7:	08 c0                	or     al,al
    37b9:	74 12                	je     0x37cd
    37bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37be:	06                   	push   es
    37bf:	57                   	push   di
    37c0:	9a b9 62 d7 37       	call   0x37d7:0x62b9
    37c5:	50                   	push   ax
    37c6:	6a 00                	push   0x0
    37c8:	9a eb 37 00 00       	call   0x0:0x37eb
    37cd:	eb 20                	jmp    0x37ef
    37cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d2:	06                   	push   es
    37d3:	57                   	push   di
    37d4:	9a fa 64 e5 37       	call   0x37e5:0x64fa
    37d9:	08 c0                	or     al,al
    37db:	74 12                	je     0x37ef
    37dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37e0:	06                   	push   es
    37e1:	57                   	push   di
    37e2:	9a b9 62 89 38       	call   0x3889:0x62b9
    37e7:	50                   	push   ax
    37e8:	6a 00                	push   0x0
    37ea:	9a 23 4a 00 00       	call   0x0:0x4a23
    37ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f2:	26 80 bd f1 00 00    	cmp    BYTE PTR es:[di+0xf1],0x0
    37f8:	74 09                	je     0x3803
    37fa:	6a 01                	push   0x1
    37fc:	06                   	push   es
    37fd:	57                   	push   di
    37fe:	9a df 44 0b 38       	call   0x380b:0x44df
    3803:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3806:	06                   	push   es
    3807:	57                   	push   di
    3808:	9a 85 35 43 38       	call   0x3843:0x3585
    380d:	c9                   	leave
    380e:	ca 08 00             	retf   0x8
    3811:	c8 02 00 00          	enter  0x2,0x0
    3815:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3818:	26 8b 85 14 01       	mov    ax,WORD PTR es:[di+0x114]
    381d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3820:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3824:	75 0b                	jne    0x3831
    3826:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    382a:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    382e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3831:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3834:	c9                   	leave
    3835:	ca 04 00             	retf   0x4
    3838:	55                   	push   bp
    3839:	89 e5                	mov    bp,sp
    383b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    383e:	06                   	push   es
    383f:	57                   	push   di
    3840:	9a 11 38 b6 38       	call   0x38b6:0x3811
    3845:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3848:	74 17                	je     0x3861
    384a:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    384e:	74 06                	je     0x3856
    3850:	83 7e 0a 24          	cmp    WORD PTR [bp+0xa],0x24
    3854:	7c 0b                	jl     0x3861
    3856:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3859:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    385c:	26 89 85 14 01       	mov    WORD PTR es:[di+0x114],ax
    3861:	c9                   	leave
    3862:	ca 06 00             	retf   0x6
    3865:	55                   	push   bp
    3866:	89 e5                	mov    bp,sp
    3868:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    386b:	26 8a 85 f3 00       	mov    al,BYTE PTR es:[di+0xf3]
    3870:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    3873:	74 16                	je     0x388b
    3875:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3878:	26 88 85 f3 00       	mov    BYTE PTR es:[di+0xf3],al
    387d:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3882:	75 07                	jne    0x388b
    3884:	06                   	push   es
    3885:	57                   	push   di
    3886:	9a 5a 40 f2 38       	call   0x38f2:0x405a
    388b:	c9                   	leave
    388c:	ca 06 00             	retf   0x6
    388f:	c8 02 00 00          	enter  0x2,0x0
    3893:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3896:	26 83 bd 14 01 00    	cmp    WORD PTR es:[di+0x114],0x0
    389c:	b0 00                	mov    al,0x0
    389e:	74 01                	je     0x38a1
    38a0:	40                   	inc    ax
    38a1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    38a4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    38a7:	c9                   	leave
    38a8:	ca 04 00             	retf   0x4
    38ab:	55                   	push   bp
    38ac:	89 e5                	mov    bp,sp
    38ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b1:	06                   	push   es
    38b2:	57                   	push   di
    38b3:	9a 8f 38 6f 39       	call   0x396f:0x388f
    38b8:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    38bb:	74 20                	je     0x38dd
    38bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38c0:	31 c0                	xor    ax,ax
    38c2:	26 89 85 14 01       	mov    WORD PTR es:[di+0x114],ax
    38c7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    38cb:	74 10                	je     0x38dd
    38cd:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    38d1:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    38d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38d8:	26 89 85 14 01       	mov    WORD PTR es:[di+0x114],ax
    38dd:	c9                   	leave
    38de:	ca 06 00             	retf   0x6
    38e1:	55                   	push   bp
    38e2:	89 e5                	mov    bp,sp
    38e4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    38e7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    38ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ed:	06                   	push   es
    38ee:	57                   	push   di
    38ef:	9a ff 56 5d 39       	call   0x395d:0x56ff
    38f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38f7:	26 8b 85 f8 00       	mov    ax,WORD PTR es:[di+0xf8]
    38fc:	26 0b 85 fa 00       	or     ax,WORD PTR es:[di+0xfa]
    3901:	74 18                	je     0x391b
    3903:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    3907:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    390b:	26 c4 bd f8 00       	les    di,DWORD PTR es:[di+0xf8]
    3910:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    3914:	06                   	push   es
    3915:	57                   	push   di
    3916:	9a 84 16 e9 39       	call   0x39e9:0x1684
    391b:	c9                   	leave
    391c:	ca 08 00             	retf   0x8
    391f:	c8 04 00 00          	enter  0x4,0x0
    3923:	c7 46 fc fa ff       	mov    WORD PTR [bp-0x4],0xfffa
    3928:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    392d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3930:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    3936:	75 0a                	jne    0x3942
    3938:	c7 46 fc f3 ff       	mov    WORD PTR [bp-0x4],0xfff3
    393d:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    3942:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3945:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3948:	c9                   	leave
    3949:	ca 04 00             	retf   0x4
    394c:	55                   	push   bp
    394d:	89 e5                	mov    bp,sp
    394f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3952:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3955:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3958:	06                   	push   es
    3959:	57                   	push   di
    395a:	9a d8 57 89 39       	call   0x3989:0x57d8
    395f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3962:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    3968:	74 23                	je     0x398d
    396a:	06                   	push   es
    396b:	57                   	push   di
    396c:	9a 1f 39 a3 39       	call   0x39a3:0x391f
    3971:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3974:	26 3b 55 3a          	cmp    dx,WORD PTR es:[di+0x3a]
    3978:	75 11                	jne    0x398b
    397a:	26 3b 45 38          	cmp    ax,WORD PTR es:[di+0x38]
    397e:	75 0b                	jne    0x398b
    3980:	6a ff                	push   0xffff
    3982:	6a f0                	push   0xfff0
    3984:	06                   	push   es
    3985:	57                   	push   di
    3986:	9a d5 1e af 39       	call   0x39af:0x1ed5
    398b:	eb 24                	jmp    0x39b1
    398d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3990:	26 83 7d 3a ff       	cmp    WORD PTR es:[di+0x3a],0xffff
    3995:	75 1a                	jne    0x39b1
    3997:	26 83 7d 38 f0       	cmp    WORD PTR es:[di+0x38],0xfff0
    399c:	75 13                	jne    0x39b1
    399e:	06                   	push   es
    399f:	57                   	push   di
    39a0:	9a 1f 39 fa 39       	call   0x39fa:0x391f
    39a5:	52                   	push   dx
    39a6:	50                   	push   ax
    39a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39aa:	06                   	push   es
    39ab:	57                   	push   di
    39ac:	9a d5 1e c6 39       	call   0x39c6:0x1ed5
    39b1:	c9                   	leave
    39b2:	ca 08 00             	retf   0x8
    39b5:	55                   	push   bp
    39b6:	89 e5                	mov    bp,sp
    39b8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    39bb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    39be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c1:	06                   	push   es
    39c2:	57                   	push   di
    39c3:	9a 3a 57 40 3a       	call   0x3a40:0x573a
    39c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39cb:	26 8b 85 f8 00       	mov    ax,WORD PTR es:[di+0xf8]
    39d0:	26 0b 85 fa 00       	or     ax,WORD PTR es:[di+0xfa]
    39d5:	74 14                	je     0x39eb
    39d7:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    39db:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    39df:	26 c4 bd f8 00       	les    di,DWORD PTR es:[di+0xf8]
    39e4:	06                   	push   es
    39e5:	57                   	push   di
    39e6:	9a 99 20 fd 46       	call   0x46fd:0x2099
    39eb:	c9                   	leave
    39ec:	ca 08 00             	retf   0x8
    39ef:	55                   	push   bp
    39f0:	89 e5                	mov    bp,sp
    39f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39f5:	06                   	push   es
    39f6:	57                   	push   di
    39f7:	9a 85 35 0e 3a       	call   0x3a0e:0x3585
    39fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39ff:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    3a04:	26 ff b5 00 01       	push   WORD PTR es:[di+0x100]
    3a09:	06                   	push   es
    3a0a:	57                   	push   di
    3a0b:	9a b2 36 f0 3c       	call   0x3cf0:0x36b2
    3a10:	c9                   	leave
    3a11:	ca 08 00             	retf   0x8
    3a14:	55                   	push   bp
    3a15:	89 e5                	mov    bp,sp
    3a17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a1a:	26 8a 85 ee 00       	mov    al,BYTE PTR es:[di+0xee]
    3a1f:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    3a22:	74 30                	je     0x3a54
    3a24:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3a27:	26 88 85 ee 00       	mov    BYTE PTR es:[di+0xee],al
    3a2c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3a31:	75 21                	jne    0x3a54
    3a33:	26 80 bd a7 00 00    	cmp    BYTE PTR es:[di+0xa7],0x0
    3a39:	74 19                	je     0x3a54
    3a3b:	06                   	push   es
    3a3c:	57                   	push   di
    3a3d:	9a b9 62 69 3a       	call   0x3a69:0x62b9
    3a42:	50                   	push   ax
    3a43:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3a46:	98                   	cbw
    3a47:	8b f8                	mov    di,ax
    3a49:	d1 e7                	shl    di,1
    3a4b:	ff b5 42 16          	push   WORD PTR [di+0x1642]
    3a4f:	9a 6d 4f 00 00       	call   0x0:0x4f6d
    3a54:	c9                   	leave
    3a55:	ca 06 00             	retf   0x6
    3a58:	c8 06 00 00          	enter  0x6,0x0
    3a5c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a5f:	06                   	push   es
    3a60:	57                   	push   di
    3a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a64:	06                   	push   es
    3a65:	57                   	push   di
    3a66:	9a 29 3b 4a 3d       	call   0x3d4a:0x3b29
    3a6b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a6e:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3a71:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3a74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a77:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3a7b:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    3a7f:	75 26                	jne    0x3aa7
    3a81:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3a85:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3a89:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3a8c:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3a90:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3a94:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3a98:	25 ff ff             	and    ax,0xffff
    3a9b:	81 e2 fc bf          	and    dx,0xbffc
    3a9f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3aa3:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3aa7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3aaa:	26 c7 45 1a 08 00    	mov    WORD PTR es:[di+0x1a],0x8
    3ab0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ab3:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3ab8:	74 1d                	je     0x3ad7
    3aba:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3abd:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3ac1:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3ac5:	0d 00 00             	or     ax,0x0
    3ac8:	81 ca cf 00          	or     dx,0xcf
    3acc:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3ad0:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3ad4:	e9 09 02             	jmp    0x3ce0
    3ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ada:	26 8a 85 f3 00       	mov    al,BYTE PTR es:[di+0xf3]
    3adf:	3c 01                	cmp    al,0x1
    3ae1:	72 13                	jb     0x3af6
    3ae3:	3c 02                	cmp    al,0x2
    3ae5:	77 0f                	ja     0x3af6
    3ae7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3aea:	26 c7 45 0c 00 80    	mov    WORD PTR es:[di+0xc],0x8000
    3af0:	26 c7 45 0e 00 80    	mov    WORD PTR es:[di+0xe],0x8000
    3af6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3af9:	26 8a 85 ec 00       	mov    al,BYTE PTR es:[di+0xec]
    3afe:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3b01:	26 8a 85 ed 00       	mov    al,BYTE PTR es:[di+0xed]
    3b06:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    3b09:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    3b0f:	75 0f                	jne    0x3b20
    3b11:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    3b14:	3c 00                	cmp    al,0x0
    3b16:	74 04                	je     0x3b1c
    3b18:	3c 03                	cmp    al,0x3
    3b1a:	75 04                	jne    0x3b20
    3b1c:	c6 46 fe 02          	mov    BYTE PTR [bp-0x2],0x2
    3b20:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    3b23:	3c 00                	cmp    al,0x0
    3b25:	75 2e                	jne    0x3b55
    3b27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b2a:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3b2e:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    3b32:	75 1a                	jne    0x3b4e
    3b34:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b37:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3b3b:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3b3f:	0d 00 00             	or     ax,0x0
    3b42:	81 ca 00 80          	or     dx,0x8000
    3b46:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3b4a:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3b4e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3b52:	e9 9e 00             	jmp    0x3bf3
    3b55:	3c 01                	cmp    al,0x1
    3b57:	75 1c                	jne    0x3b75
    3b59:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b5c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3b60:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3b64:	0d 00 00             	or     ax,0x0
    3b67:	81 ca c0 00          	or     dx,0xc0
    3b6b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3b6f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3b73:	eb 7e                	jmp    0x3bf3
    3b75:	3c 02                	cmp    al,0x2
    3b77:	75 3b                	jne    0x3bb4
    3b79:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b7c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3b80:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3b84:	0d 00 00             	or     ax,0x0
    3b87:	81 ca c4 00          	or     dx,0xc4
    3b8b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3b8f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3b93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b96:	26 8a 85 f3 00       	mov    al,BYTE PTR es:[di+0xf3]
    3b9b:	3c 01                	cmp    al,0x1
    3b9d:	74 04                	je     0x3ba3
    3b9f:	3c 03                	cmp    al,0x3
    3ba1:	75 0f                	jne    0x3bb2
    3ba3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ba6:	26 c7 45 10 00 80    	mov    WORD PTR es:[di+0x10],0x8000
    3bac:	26 c7 45 12 00 80    	mov    WORD PTR es:[di+0x12],0x8000
    3bb2:	eb 3f                	jmp    0x3bf3
    3bb4:	3c 03                	cmp    al,0x3
    3bb6:	75 3b                	jne    0x3bf3
    3bb8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3bbb:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3bbf:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3bc3:	0d 00 00             	or     ax,0x0
    3bc6:	81 ca c0 00          	or     dx,0xc0
    3bca:	0d 80 00             	or     ax,0x80
    3bcd:	81 ca 00 00          	or     dx,0x0
    3bd1:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3bd5:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3bd9:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    3bdf:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    3be5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3be8:	24 01                	and    al,0x1
    3bea:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3bed:	26 c7 45 1a 08 28    	mov    WORD PTR es:[di+0x1a],0x2808
    3bf3:	80 7e fe 03          	cmp    BYTE PTR [bp-0x2],0x3
    3bf7:	75 03                	jne    0x3bfc
    3bf9:	e9 9f 00             	jmp    0x3c9b
    3bfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bff:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    3c05:	75 06                	jne    0x3c0d
    3c07:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
    3c0b:	74 40                	je     0x3c4d
    3c0d:	f6 46 ff 02          	test   BYTE PTR [bp-0x1],0x2
    3c11:	74 1a                	je     0x3c2d
    3c13:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c16:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3c1a:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3c1e:	0d 00 00             	or     ax,0x0
    3c21:	81 ca 02 00          	or     dx,0x2
    3c25:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3c29:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3c2d:	f6 46 ff 04          	test   BYTE PTR [bp-0x1],0x4
    3c31:	74 1a                	je     0x3c4d
    3c33:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c36:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3c3a:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3c3e:	0d 00 00             	or     ax,0x0
    3c41:	81 ca 01 00          	or     dx,0x1
    3c45:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3c49:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3c4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c50:	26 80 bd ee 00 01    	cmp    BYTE PTR es:[di+0xee],0x1
    3c56:	75 1c                	jne    0x3c74
    3c58:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c5b:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3c5f:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3c63:	0d 00 00             	or     ax,0x0
    3c66:	81 ca 00 20          	or     dx,0x2000
    3c6a:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3c6e:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3c72:	eb 25                	jmp    0x3c99
    3c74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c77:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3c7d:	75 1a                	jne    0x3c99
    3c7f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c82:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3c86:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3c8a:	0d 00 00             	or     ax,0x0
    3c8d:	81 ca 00 01          	or     dx,0x100
    3c91:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3c95:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3c99:	eb 09                	jmp    0x3ca4
    3c9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c9e:	26 c6 85 ee 00 00    	mov    BYTE PTR es:[di+0xee],0x0
    3ca4:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
    3ca8:	74 1a                	je     0x3cc4
    3caa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3cad:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3cb1:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3cb5:	0d 00 00             	or     ax,0x0
    3cb8:	81 ca 08 00          	or     dx,0x8
    3cbc:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3cc0:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3cc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cc7:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    3ccd:	75 11                	jne    0x3ce0
    3ccf:	b8 1b 53             	mov    ax,0x531b
    3cd2:	ba 1e 53             	mov    dx,0x531e
    3cd5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3cd8:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    3cdc:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    3ce0:	c9                   	leave
    3ce1:	ca 08 00             	retf   0x8
    3ce4:	c8 04 00 00          	enter  0x4,0x0
    3ce8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ceb:	06                   	push   es
    3cec:	57                   	push   di
    3ced:	9a cd 1f 81 3d       	call   0x3d81:0x1fcd
    3cf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf5:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3cfa:	74 03                	je     0x3cff
    3cfc:	e9 e9 00             	jmp    0x3de8
    3cff:	26 8a 85 f2 00       	mov    al,BYTE PTR es:[di+0xf2]
    3d04:	3c 02                	cmp    al,0x2
    3d06:	74 03                	je     0x3d0b
    3d08:	e9 bd 00             	jmp    0x3dc8
    3d0b:	c7 46 fe 00 ff       	mov    WORD PTR [bp-0x2],0xff00
    3d10:	31 c0                	xor    ax,ax
    3d12:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3d15:	26 8b 85 10 01       	mov    ax,WORD PTR es:[di+0x110]
    3d1a:	26 0b 85 12 01       	or     ax,WORD PTR es:[di+0x112]
    3d1f:	74 0f                	je     0x3d30
    3d21:	26 c4 bd 10 01       	les    di,DWORD PTR es:[di+0x110]
    3d26:	06                   	push   es
    3d27:	57                   	push   di
    3d28:	9a 5d 10 bc 45       	call   0x45bc:0x105d
    3d2d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3d30:	bf 48 16             	mov    di,0x1648
    3d33:	1e                   	push   ds
    3d34:	57                   	push   di
    3d35:	6a 00                	push   0x0
    3d37:	6a 00                	push   0x0
    3d39:	68 33 56             	push   0x5633
    3d3c:	6a 01                	push   0x1
    3d3e:	6a 00                	push   0x0
    3d40:	6a 00                	push   0x0
    3d42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d45:	06                   	push   es
    3d46:	57                   	push   di
    3d47:	9a a9 18 55 3d       	call   0x3d55:0x18a9
    3d4c:	50                   	push   ax
    3d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d50:	06                   	push   es
    3d51:	57                   	push   di
    3d52:	9a f4 18 60 3d       	call   0x3d60:0x18f4
    3d57:	50                   	push   ax
    3d58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d5b:	06                   	push   es
    3d5c:	57                   	push   di
    3d5d:	9a b9 62 d4 3d       	call   0x3dd4:0x62b9
    3d62:	50                   	push   ax
    3d63:	6a 00                	push   0x0
    3d65:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    3d69:	8d 7e fc             	lea    di,[bp-0x4]
    3d6c:	16                   	push   ss
    3d6d:	57                   	push   di
    3d6e:	9a a2 65 00 00       	call   0x0:0x65a2
    3d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d76:	26 89 85 0e 01       	mov    WORD PTR es:[di+0x10e],ax
    3d7b:	06                   	push   es
    3d7c:	57                   	push   di
    3d7d:	bf 63 31             	mov    di,0x3163
    3d80:	b8 88 3d             	mov    ax,0x3d88
    3d83:	50                   	push   ax
    3d84:	57                   	push   di
    3d85:	9a 89 14 0f 40       	call   0x400f:0x1489
    3d8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d8d:	26 89 85 28 01       	mov    WORD PTR es:[di+0x128],ax
    3d92:	26 89 95 2a 01       	mov    WORD PTR es:[di+0x12a],dx
    3d97:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    3d9c:	6a fc                	push   0xfffc
    3d9e:	9a 44 68 00 00       	call   0x0:0x6844
    3da3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da6:	26 89 85 24 01       	mov    WORD PTR es:[di+0x124],ax
    3dab:	26 89 95 26 01       	mov    WORD PTR es:[di+0x126],dx
    3db0:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    3db5:	6a fc                	push   0xfffc
    3db7:	26 ff b5 2a 01       	push   WORD PTR es:[di+0x12a]
    3dbc:	26 ff b5 28 01       	push   WORD PTR es:[di+0x128]
    3dc1:	9a bc 65 00 00       	call   0x0:0x65bc
    3dc6:	eb 20                	jmp    0x3de8
    3dc8:	3c 03                	cmp    al,0x3
    3dca:	75 1c                	jne    0x3de8
    3dcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dcf:	06                   	push   es
    3dd0:	57                   	push   di
    3dd1:	9a b9 62 3b 3e       	call   0x3e3b:0x62b9
    3dd6:	50                   	push   ax
    3dd7:	6a ff                	push   0xffff
    3dd9:	6a 00                	push   0x0
    3ddb:	6a 00                	push   0x0
    3ddd:	6a 00                	push   0x0
    3ddf:	6a 00                	push   0x0
    3de1:	6a 13                	push   0x13
    3de3:	9a 24 54 00 00       	call   0x0:0x5424
    3de8:	c9                   	leave
    3de9:	ca 04 00             	retf   0x4
    3dec:	c8 1a 01 00          	enter  0x11a,0x0
    3df0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3df3:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    3df9:	74 03                	je     0x3dfe
    3dfb:	e9 d3 00             	jmp    0x3ed1
    3dfe:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3e03:	74 03                	je     0x3e08
    3e05:	e9 c9 00             	jmp    0x3ed1
    3e08:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3e0c:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    3e10:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    3e14:	74 10                	je     0x3e26
    3e16:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3e1a:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    3e1e:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    3e24:	75 25                	jne    0x3e4b
    3e26:	8d be e6 fe          	lea    di,[bp-0x11a]
    3e2a:	16                   	push   ss
    3e2b:	57                   	push   di
    3e2c:	68 39 f0             	push   0xf039
    3e2f:	9a 2b 09 42 3e       	call   0x3e42:0x92b
    3e34:	b0 01                	mov    al,0x1
    3e36:	50                   	push   ax
    3e37:	b8 52 00             	mov    ax,0x52
    3e3a:	ba de 3e             	mov    dx,0x3ede
    3e3d:	52                   	push   dx
    3e3e:	50                   	push   ax
    3e3f:	9a e6 28 35 40       	call   0x4035:0x28e6
    3e44:	52                   	push   dx
    3e45:	50                   	push   ax
    3e46:	9a 99 13 4c 40       	call   0x404c:0x1399
    3e4b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e4e:	26 8d 45 34          	lea    ax,es:[di+0x34]
    3e52:	8c c2                	mov    dx,es
    3e54:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    3e57:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    3e5a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3e5d:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3e61:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3e64:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    3e67:	a1 8c 18             	mov    ax,ds:0x188c
    3e6a:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3e6d:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    3e71:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3e74:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    3e78:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3e7b:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    3e7f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3e82:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    3e86:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3e89:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3e8d:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3e91:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3e94:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3e97:	26 8b 45 16          	mov    ax,WORD PTR es:[di+0x16]
    3e9b:	26 8b 55 18          	mov    dx,WORD PTR es:[di+0x18]
    3e9f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ea2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ea5:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3ea9:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    3ead:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    3eb2:	68 20 02             	push   0x220
    3eb5:	6a 00                	push   0x0
    3eb7:	8d 7e e6             	lea    di,[bp-0x1a]
    3eba:	16                   	push   ss
    3ebb:	57                   	push   di
    3ebc:	9a 1b 3f 00 00       	call   0x0:0x3f1b
    3ec1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ec4:	26 89 85 a2 00       	mov    WORD PTR es:[di+0xa2],ax
    3ec9:	26 80 8d f5 00 10    	or     BYTE PTR es:[di+0xf5],0x10
    3ecf:	eb 18                	jmp    0x3ee9
    3ed1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ed4:	06                   	push   es
    3ed5:	57                   	push   di
    3ed6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed9:	06                   	push   es
    3eda:	57                   	push   di
    3edb:	9a 17 3e 13 3f       	call   0x3f13:0x3e17
    3ee0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ee3:	26 80 a5 f5 00 ef    	and    BYTE PTR es:[di+0xf5],0xef
    3ee9:	c9                   	leave
    3eea:	ca 08 00             	retf   0x8
    3eed:	55                   	push   bp
    3eee:	89 e5                	mov    bp,sp
    3ef0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef3:	26 f6 85 f5 00 10    	test   BYTE PTR es:[di+0xf5],0x10
    3ef9:	74 26                	je     0x3f21
    3efb:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3eff:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    3f03:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    3f08:	68 21 02             	push   0x221
    3f0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f0e:	06                   	push   es
    3f0f:	57                   	push   di
    3f10:	9a b9 62 29 3f       	call   0x3f29:0x62b9
    3f15:	50                   	push   ax
    3f16:	6a 00                	push   0x0
    3f18:	6a 00                	push   0x0
    3f1a:	9a 2a 46 00 00       	call   0x0:0x462a
    3f1f:	eb 0a                	jmp    0x3f2b
    3f21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f24:	06                   	push   es
    3f25:	57                   	push   di
    3f26:	9a ed 3e 5f 3f       	call   0x3f5f:0x3eed
    3f2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f2e:	31 c0                	xor    ax,ax
    3f30:	26 89 85 0e 01       	mov    WORD PTR es:[di+0x10e],ax
    3f35:	c9                   	leave
    3f36:	ca 04 00             	retf   0x4
    3f39:	c8 04 00 00          	enter  0x4,0x0
    3f3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f40:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    3f46:	74 75                	je     0x3fbd
    3f48:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f4b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3f4e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3f51:	26 83 3d 05          	cmp    WORD PTR es:[di],0x5
    3f55:	75 2f                	jne    0x3f86
    3f57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f5a:	06                   	push   es
    3f5b:	57                   	push   di
    3f5c:	9a b9 62 8e 3f       	call   0x3f8e:0x62b9
    3f61:	50                   	push   ax
    3f62:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3f65:	26 ff 35             	push   WORD PTR es:[di]
    3f68:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3f6c:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3f70:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3f74:	9a ff 69 00 00       	call   0x0:0x69ff
    3f79:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3f7c:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    3f80:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    3f84:	eb 35                	jmp    0x3fbb
    3f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f89:	06                   	push   es
    3f8a:	57                   	push   di
    3f8b:	9a b9 62 ca 3f       	call   0x3fca:0x62b9
    3f90:	50                   	push   ax
    3f91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f94:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    3f99:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3f9c:	26 ff 35             	push   WORD PTR es:[di]
    3f9f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3fa3:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3fa7:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3fab:	9a ff ff 00 00       	call   0x0:0xffff
    3fb0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3fb3:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    3fb7:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    3fbb:	eb 0f                	jmp    0x3fcc
    3fbd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fc0:	06                   	push   es
    3fc1:	57                   	push   di
    3fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fc5:	06                   	push   es
    3fc6:	57                   	push   di
    3fc7:	9a fa 45 23 40       	call   0x4023:0x45fa
    3fcc:	c9                   	leave
    3fcd:	ca 08 00             	retf   0x8
    3fd0:	c8 00 01 00          	enter  0x100,0x0
    3fd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fd7:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    3fdc:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    3fe1:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    3fe4:	75 08                	jne    0x3fee
    3fe6:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3fe9:	75 03                	jne    0x3fee
    3feb:	e9 8f 00             	jmp    0x407d
    3fee:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3ff1:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3ff4:	74 58                	je     0x404e
    3ff6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3ff9:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3ffc:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    3fff:	75 05                	jne    0x4006
    4001:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    4004:	74 23                	je     0x4029
    4006:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4009:	ff 76 0a             	push   WORD PTR [bp+0xa]
    400c:	9a a8 17 6e 40       	call   0x406e:0x17a8
    4011:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    4014:	75 13                	jne    0x4029
    4016:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    4019:	75 0e                	jne    0x4029
    401b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    401e:	06                   	push   es
    401f:	57                   	push   di
    4020:	9a c4 61 3e 40       	call   0x403e:0x61c4
    4025:	08 c0                	or     al,al
    4027:	75 25                	jne    0x404e
    4029:	8d be 00 ff          	lea    di,[bp-0x100]
    402d:	16                   	push   ss
    402e:	57                   	push   di
    402f:	68 29 f0             	push   0xf029
    4032:	9a 2b 09 45 40       	call   0x4045:0x92b
    4037:	b0 01                	mov    al,0x1
    4039:	50                   	push   ax
    403a:	b8 52 00             	mov    ax,0x52
    403d:	ba 9f 40             	mov    dx,0x409f
    4040:	52                   	push   dx
    4041:	50                   	push   ax
    4042:	9a e6 28 6d 51       	call   0x516d:0x28e6
    4047:	52                   	push   dx
    4048:	50                   	push   ax
    4049:	9a 99 13 7b 40       	call   0x407b:0x1399
    404e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4051:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4054:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4057:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    405c:	26 89 95 e6 00       	mov    WORD PTR es:[di+0xe6],dx
    4061:	26 80 bd f1 00 00    	cmp    BYTE PTR es:[di+0xf1],0x0
    4067:	74 07                	je     0x4070
    4069:	06                   	push   es
    406a:	57                   	push   di
    406b:	9a 33 44 e4 40       	call   0x40e4:0x4433
    4070:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4073:	06                   	push   es
    4074:	57                   	push   di
    4075:	b8 ed ff             	mov    ax,0xffed
    4078:	9a 6a 20 40 42       	call   0x4240:0x206a
    407d:	c9                   	leave
    407e:	ca 08 00             	retf   0x8
    4081:	55                   	push   bp
    4082:	89 e5                	mov    bp,sp
    4084:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4088:	74 33                	je     0x40bd
    408a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    408d:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    4092:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    4097:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    409a:	06                   	push   es
    409b:	57                   	push   di
    409c:	9a 0e 37 d2 40       	call   0x40d2:0x370e
    40a1:	08 c0                	or     al,al
    40a3:	74 18                	je     0x40bd
    40a5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    40a8:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    40ac:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    40b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b3:	26 89 85 e8 00       	mov    WORD PTR es:[di+0xe8],ax
    40b8:	26 89 95 ea 00       	mov    WORD PTR es:[di+0xea],dx
    40bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40c0:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    40c5:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    40ca:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    40cd:	06                   	push   es
    40ce:	57                   	push   di
    40cf:	9a 0e 37 1d 42       	call   0x421d:0x370e
    40d4:	08 c0                	or     al,al
    40d6:	74 0e                	je     0x40e6
    40d8:	6a 00                	push   0x0
    40da:	6a 00                	push   0x0
    40dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40df:	06                   	push   es
    40e0:	57                   	push   di
    40e1:	9a d0 3f 04 41       	call   0x4104:0x3fd0
    40e6:	c9                   	leave
    40e7:	ca 0a 00             	retf   0xa
    40ea:	c8 02 00 00          	enter  0x2,0x0
    40ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40f1:	26 8a 85 f1 00       	mov    al,BYTE PTR es:[di+0xf1]
    40f6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    40f9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    40fc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    40ff:	06                   	push   es
    4100:	57                   	push   di
    4101:	9a d0 3f 20 41       	call   0x4120:0x3fd0
    4106:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    410a:	75 0c                	jne    0x4118
    410c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    410f:	06                   	push   es
    4110:	57                   	push   di
    4111:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4114:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    4118:	c9                   	leave
    4119:	ca 08 00             	retf   0x8
    411c:	00 00                	add    BYTE PTR [bx+si],al
    411e:	05 44 b4             	add    ax,0xb444
    4121:	43                   	inc    bx
    4122:	c8 08 00 00          	enter  0x8,0x0
    4126:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    412a:	ff 06 34 15          	inc    WORD PTR ds:0x1534
    412e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4131:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    4136:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    413b:	75 34                	jne    0x4171
    413d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4140:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4143:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    4146:	75 05                	jne    0x414d
    4148:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    414b:	74 15                	je     0x4162
    414d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4150:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4156:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    415b:	26 89 95 e6 00       	mov    WORD PTR es:[di+0xe6],dx
    4160:	eb 0f                	jmp    0x4171
    4162:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4165:	31 c0                	xor    ax,ax
    4167:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    416c:	26 89 85 e6 00       	mov    WORD PTR es:[di+0xe6],ax
    4171:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4174:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4177:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    417b:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    417f:	26 89 55 2e          	mov    WORD PTR es:[di+0x2e],dx
    4183:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4186:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4189:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    418d:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    4191:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    4195:	ff 76 08             	push   WORD PTR [bp+0x8]
    4198:	ff 76 06             	push   WORD PTR [bp+0x6]
    419b:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    419f:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    41a3:	06                   	push   es
    41a4:	57                   	push   di
    41a5:	9a a7 0f bf 41       	call   0x41bf:0xfa7
    41aa:	6a 00                	push   0x0
    41ac:	ff 76 08             	push   WORD PTR [bp+0x8]
    41af:	ff 76 06             	push   WORD PTR [bp+0x6]
    41b2:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    41b6:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    41ba:	06                   	push   es
    41bb:	57                   	push   di
    41bc:	9a a7 0e a3 5f       	call   0x5fa3:0xea7
    41c1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    41c4:	26 f6 45 28 20       	test   BYTE PTR es:[di+0x28],0x20
    41c9:	74 03                	je     0x41ce
    41cb:	e9 57 02             	jmp    0x4425
    41ce:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    41d1:	26 8a 45 28          	mov    al,BYTE PTR es:[di+0x28]
    41d5:	0c 20                	or     al,0x20
    41d7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    41da:	26 88 45 28          	mov    BYTE PTR es:[di+0x28],al
    41de:	b8 1c 41             	mov    ax,0x411c
    41e1:	0e                   	push   cs
    41e2:	50                   	push   ax
    41e3:	55                   	push   bp
    41e4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    41e8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    41ec:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    41f0:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    41f4:	26 8b 55 3e          	mov    dx,WORD PTR es:[di+0x3e]
    41f8:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    41fb:	75 05                	jne    0x4202
    41fd:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    4200:	74 72                	je     0x4274
    4202:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4206:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    420a:	26 0b 45 3e          	or     ax,WORD PTR es:[di+0x3e]
    420e:	74 35                	je     0x4245
    4210:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4214:	26 c4 7d 3c          	les    di,DWORD PTR es:[di+0x3c]
    4218:	06                   	push   es
    4219:	57                   	push   di
    421a:	9a b9 62 5f 42       	call   0x425f:0x62b9
    421f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4222:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4226:	31 c0                	xor    ax,ax
    4228:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    422c:	26 89 45 3e          	mov    WORD PTR es:[di+0x3e],ax
    4230:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4233:	68 01 0f             	push   0xf01
    4236:	e8 53 cf             	call   0x118c
    4239:	08 c0                	or     al,al
    423b:	75 08                	jne    0x4245
    423d:	9a 6a 14 6f 42       	call   0x426f:0x146a
    4242:	e9 e0 01             	jmp    0x4425
    4245:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4248:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    424b:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    424f:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    4253:	26 89 55 3e          	mov    WORD PTR es:[di+0x3e],dx
    4257:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    425a:	06                   	push   es
    425b:	57                   	push   di
    425c:	9a b9 62 c0 42       	call   0x42c0:0x62b9
    4261:	50                   	push   ax
    4262:	68 00 0f             	push   0xf00
    4265:	e8 24 cf             	call   0x118c
    4268:	08 c0                	or     al,al
    426a:	75 08                	jne    0x4274
    426c:	9a 6a 14 05 43       	call   0x4305:0x146a
    4271:	e9 b1 01             	jmp    0x4425
    4274:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4277:	26 8b 85 e8 00       	mov    ax,WORD PTR es:[di+0xe8]
    427c:	26 0b 85 ea 00       	or     ax,WORD PTR es:[di+0xea]
    4281:	75 10                	jne    0x4293
    4283:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4286:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4289:	26 89 85 e8 00       	mov    WORD PTR es:[di+0xe8],ax
    428e:	26 89 95 ea 00       	mov    WORD PTR es:[di+0xea],dx
    4293:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4296:	26 8b 85 e8 00       	mov    ax,WORD PTR es:[di+0xe8]
    429b:	26 8b 95 ea 00       	mov    dx,WORD PTR es:[di+0xea]
    42a0:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    42a3:	75 08                	jne    0x42ad
    42a5:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    42a8:	75 03                	jne    0x42ad
    42aa:	e9 4c 01             	jmp    0x43f9
    42ad:	ff 76 0c             	push   WORD PTR [bp+0xc]
    42b0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    42b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b6:	26 c4 bd e8 00       	les    di,DWORD PTR es:[di+0xe8]
    42bb:	06                   	push   es
    42bc:	57                   	push   di
    42bd:	9a 0e 37 d3 42       	call   0x42d3:0x370e
    42c2:	08 c0                	or     al,al
    42c4:	75 46                	jne    0x430c
    42c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42c9:	26 c4 bd e8 00       	les    di,DWORD PTR es:[di+0xe8]
    42ce:	06                   	push   es
    42cf:	57                   	push   di
    42d0:	9a b9 62 79 43       	call   0x4379:0x62b9
    42d5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    42d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42db:	26 c4 bd e8 00       	les    di,DWORD PTR es:[di+0xe8]
    42e0:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    42e4:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    42e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42eb:	26 89 85 e8 00       	mov    WORD PTR es:[di+0xe8],ax
    42f0:	26 89 95 ea 00       	mov    WORD PTR es:[di+0xea],dx
    42f5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    42f8:	68 1b 0f             	push   0xf1b
    42fb:	e8 8e ce             	call   0x118c
    42fe:	08 c0                	or     al,al
    4300:	75 08                	jne    0x430a
    4302:	9a 6a 14 89 43       	call   0x4389:0x146a
    4307:	e9 1b 01             	jmp    0x4425
    430a:	eb a1                	jmp    0x42ad
    430c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    430f:	26 8b 85 e8 00       	mov    ax,WORD PTR es:[di+0xe8]
    4314:	26 8b 95 ea 00       	mov    dx,WORD PTR es:[di+0xea]
    4319:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    431c:	75 05                	jne    0x4323
    431e:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    4321:	74 6e                	je     0x4391
    4323:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4326:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4329:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    432c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    432f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4332:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    4336:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    433a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    433d:	26 3b 95 ea 00       	cmp    dx,WORD PTR es:[di+0xea]
    4342:	75 07                	jne    0x434b
    4344:	26 3b 85 e8 00       	cmp    ax,WORD PTR es:[di+0xe8]
    4349:	74 13                	je     0x435e
    434b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    434e:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    4352:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    4356:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4359:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    435c:	eb d1                	jmp    0x432f
    435e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    4361:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    4364:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4367:	26 89 85 e8 00       	mov    WORD PTR es:[di+0xe8],ax
    436c:	26 89 95 ea 00       	mov    WORD PTR es:[di+0xea],dx
    4371:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4374:	06                   	push   es
    4375:	57                   	push   di
    4376:	9a b9 62 f7 43       	call   0x43f7:0x62b9
    437b:	50                   	push   ax
    437c:	68 1a 0f             	push   0xf1a
    437f:	e8 0a ce             	call   0x118c
    4382:	08 c0                	or     al,al
    4384:	75 08                	jne    0x438e
    4386:	9a 6a 14 bb 43       	call   0x43bb:0x146a
    438b:	e9 97 00             	jmp    0x4425
    438e:	e9 7b ff             	jmp    0x430c
    4391:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4394:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    4398:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    439c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    439f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    43a2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    43a5:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    43a8:	74 3a                	je     0x43e4
    43aa:	ff 76 fa             	push   WORD PTR [bp-0x6]
    43ad:	ff 76 f8             	push   WORD PTR [bp-0x8]
    43b0:	bf 72 01             	mov    di,0x172
    43b3:	b8 cf 43             	mov    ax,0x43cf
    43b6:	50                   	push   ax
    43b7:	57                   	push   di
    43b8:	9a 55 22 f9 45       	call   0x45f9:0x2255
    43bd:	08 c0                	or     al,al
    43bf:	74 10                	je     0x43d1
    43c1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    43c4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    43c7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    43ca:	06                   	push   es
    43cb:	57                   	push   di
    43cc:	9a 00 22 1f 44       	call   0x441f:0x2200
    43d1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    43d4:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    43d8:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    43dc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    43df:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    43e2:	eb be                	jmp    0x43a2
    43e4:	68 07 0f             	push   0xf07
    43e7:	6a 00                	push   0x0
    43e9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    43ec:	ff 76 0a             	push   WORD PTR [bp+0xa]
    43ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43f2:	06                   	push   es
    43f3:	57                   	push   di
    43f4:	9a bb 24 5b 44       	call   0x445b:0x24bb
    43f9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    43fd:	83 c4 06             	add    sp,0x6
    4400:	b8 16 44             	mov    ax,0x4416
    4403:	0e                   	push   cs
    4404:	50                   	push   ax
    4405:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4408:	26 8a 45 28          	mov    al,BYTE PTR es:[di+0x28]
    440c:	24 df                	and    al,0xdf
    440e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4411:	26 88 45 28          	mov    BYTE PTR es:[di+0x28],al
    4415:	cb                   	retf
    4416:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    441a:	06                   	push   es
    441b:	57                   	push   di
    441c:	9a 0d 61 ba 44       	call   0x44ba:0x610d
    4421:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    4425:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4428:	c9                   	leave
    4429:	ca 08 00             	retf   0x8
    442c:	55                   	push   bp
    442d:	89 e5                	mov    bp,sp
    442f:	c9                   	leave
    4430:	ca 04 00             	retf   0x4
    4433:	55                   	push   bp
    4434:	89 e5                	mov    bp,sp
    4436:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4439:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    443e:	26 0b 85 e6 00       	or     ax,WORD PTR es:[di+0xe6]
    4443:	74 20                	je     0x4465
    4445:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    444a:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    444f:	75 14                	jne    0x4465
    4451:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    4456:	06                   	push   es
    4457:	57                   	push   di
    4458:	9a b9 62 6d 44       	call   0x446d:0x62b9
    445d:	50                   	push   ax
    445e:	9a 71 44 00 00       	call   0x0:0x4471
    4463:	eb 10                	jmp    0x4475
    4465:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4468:	06                   	push   es
    4469:	57                   	push   di
    446a:	9a b9 62 a8 44       	call   0x44a8:0x62b9
    446f:	50                   	push   ax
    4470:	9a d6 4f 00 00       	call   0x0:0x4fd6
    4475:	c9                   	leave
    4476:	ca 04 00             	retf   0x4
    4479:	55                   	push   bp
    447a:	89 e5                	mov    bp,sp
    447c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    447f:	26 80 bd f1 00 00    	cmp    BYTE PTR es:[di+0xf1],0x0
    4485:	74 23                	je     0x44aa
    4487:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    448c:	26 0b 85 e6 00       	or     ax,WORD PTR es:[di+0xe6]
    4491:	74 17                	je     0x44aa
    4493:	68 04 0f             	push   0xf04
    4496:	6a 00                	push   0x0
    4498:	ff 76 0c             	push   WORD PTR [bp+0xc]
    449b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    449e:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    44a3:	06                   	push   es
    44a4:	57                   	push   di
    44a5:	9a bb 24 ee 45       	call   0x45ee:0x24bb
    44aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ad:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    44b3:	75 26                	jne    0x44db
    44b5:	06                   	push   es
    44b6:	57                   	push   di
    44b7:	9a ae 32 ce 44       	call   0x44ce:0x32ae
    44bc:	09 d0                	or     ax,dx
    44be:	74 1b                	je     0x44db
    44c0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    44c3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    44c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c9:	06                   	push   es
    44ca:	57                   	push   di
    44cb:	9a ae 32 d9 44       	call   0x44d9:0x32ae
    44d0:	89 c7                	mov    di,ax
    44d2:	8e c2                	mov    es,dx
    44d4:	06                   	push   es
    44d5:	57                   	push   di
    44d6:	9a 79 44 3a 47       	call   0x473a:0x4479
    44db:	c9                   	leave
    44dc:	ca 08 00             	retf   0x8
    44df:	c8 0c 00 00          	enter  0xc,0x0
    44e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44e6:	26 f6 85 f5 00 08    	test   BYTE PTR es:[di+0xf5],0x8
    44ec:	74 03                	je     0x44f1
    44ee:	e9 57 01             	jmp    0x4648
    44f1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    44f5:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    44f9:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    44fd:	75 03                	jne    0x4502
    44ff:	e9 46 01             	jmp    0x4648
    4502:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4506:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    450a:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    450f:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    4514:	75 03                	jne    0x4519
    4516:	e9 2f 01             	jmp    0x4648
    4519:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    451d:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    4521:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    4525:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    4528:	75 08                	jne    0x4532
    452a:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    452d:	75 03                	jne    0x4532
    452f:	e9 16 01             	jmp    0x4648
    4532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4535:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    453b:	74 13                	je     0x4550
    453d:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4541:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    4545:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    454b:	75 03                	jne    0x4550
    454d:	e9 f8 00             	jmp    0x4648
    4550:	31 c0                	xor    ax,ax
    4552:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4555:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4558:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    455b:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4560:	75 36                	jne    0x4598
    4562:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4567:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    456c:	74 2a                	je     0x4598
    456e:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4573:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    4578:	75 0b                	jne    0x4585
    457a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    457d:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    4583:	75 13                	jne    0x4598
    4585:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4588:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    458d:	26 8b 95 02 01       	mov    dx,WORD PTR es:[di+0x102]
    4592:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4595:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4598:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    459c:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    45a0:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    45a5:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    45a8:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    45ab:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    45af:	74 0f                	je     0x45c0
    45b1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    45b4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    45b7:	06                   	push   es
    45b8:	57                   	push   di
    45b9:	9a f1 1d ce 45       	call   0x45ce:0x1df1
    45be:	eb 10                	jmp    0x45d0
    45c0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    45c3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    45c6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    45c9:	06                   	push   es
    45ca:	57                   	push   di
    45cb:	9a 2d 1e 36 4a       	call   0x4a36:0x1e2d
    45d0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    45d4:	74 72                	je     0x4648
    45d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45d9:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    45df:	75 67                	jne    0x4648
    45e1:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    45e7:	75 5f                	jne    0x4648
    45e9:	06                   	push   es
    45ea:	57                   	push   di
    45eb:	9a f4 18 05 46       	call   0x4605:0x18f4
    45f0:	99                   	cwd
    45f1:	b9 10 00             	mov    cx,0x10
    45f4:	31 db                	xor    bx,bx
    45f6:	9a 39 17 89 47       	call   0x4789:0x1739
    45fb:	52                   	push   dx
    45fc:	50                   	push   ax
    45fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4600:	06                   	push   es
    4601:	57                   	push   di
    4602:	9a a9 18 1c 46       	call   0x461c:0x18a9
    4607:	99                   	cwd
    4608:	59                   	pop    cx
    4609:	5b                   	pop    bx
    460a:	03 c1                	add    ax,cx
    460c:	13 d3                	adc    dx,bx
    460e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4611:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    4614:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4617:	06                   	push   es
    4618:	57                   	push   di
    4619:	9a b9 62 36 46       	call   0x4636:0x62b9
    461e:	50                   	push   ax
    461f:	6a 05                	push   0x5
    4621:	6a 00                	push   0x0
    4623:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4626:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4629:	9a 44 46 00 00       	call   0x0:0x4644
    462e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4631:	06                   	push   es
    4632:	57                   	push   di
    4633:	9a b9 62 b9 47       	call   0x47b9:0x62b9
    4638:	50                   	push   ax
    4639:	6a 05                	push   0x5
    463b:	6a 02                	push   0x2
    463d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4640:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4643:	9a f8 4b 00 00       	call   0x0:0x4bf8
    4648:	c9                   	leave
    4649:	ca 06 00             	retf   0x6
    464c:	55                   	push   bp
    464d:	89 e5                	mov    bp,sp
    464f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4652:	26 8b 85 2e 01       	mov    ax,WORD PTR es:[di+0x12e]
    4657:	09 c0                	or     ax,ax
    4659:	74 15                	je     0x4670
    465b:	ff 76 08             	push   WORD PTR [bp+0x8]
    465e:	ff 76 06             	push   WORD PTR [bp+0x6]
    4661:	26 ff b5 32 01       	push   WORD PTR es:[di+0x132]
    4666:	26 ff b5 30 01       	push   WORD PTR es:[di+0x130]
    466b:	26 ff 9d 2c 01       	call   DWORD PTR es:[di+0x12c]
    4670:	c9                   	leave
    4671:	ca 04 00             	retf   0x4
    4674:	55                   	push   bp
    4675:	89 e5                	mov    bp,sp
    4677:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    467a:	26 8b 85 46 01       	mov    ax,WORD PTR es:[di+0x146]
    467f:	09 c0                	or     ax,ax
    4681:	74 15                	je     0x4698
    4683:	ff 76 08             	push   WORD PTR [bp+0x8]
    4686:	ff 76 06             	push   WORD PTR [bp+0x6]
    4689:	26 ff b5 4a 01       	push   WORD PTR es:[di+0x14a]
    468e:	26 ff b5 48 01       	push   WORD PTR es:[di+0x148]
    4693:	26 ff 9d 44 01       	call   DWORD PTR es:[di+0x144]
    4698:	c9                   	leave
    4699:	ca 04 00             	retf   0x4
    469c:	55                   	push   bp
    469d:	89 e5                	mov    bp,sp
    469f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46a2:	26 8b 85 56 01       	mov    ax,WORD PTR es:[di+0x156]
    46a7:	09 c0                	or     ax,ax
    46a9:	74 15                	je     0x46c0
    46ab:	ff 76 08             	push   WORD PTR [bp+0x8]
    46ae:	ff 76 06             	push   WORD PTR [bp+0x6]
    46b1:	26 ff b5 5a 01       	push   WORD PTR es:[di+0x15a]
    46b6:	26 ff b5 58 01       	push   WORD PTR es:[di+0x158]
    46bb:	26 ff 9d 54 01       	call   DWORD PTR es:[di+0x154]
    46c0:	c9                   	leave
    46c1:	ca 04 00             	retf   0x4
    46c4:	55                   	push   bp
    46c5:	89 e5                	mov    bp,sp
    46c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46ca:	26 8b 85 5e 01       	mov    ax,WORD PTR es:[di+0x15e]
    46cf:	09 c0                	or     ax,ax
    46d1:	74 15                	je     0x46e8
    46d3:	ff 76 08             	push   WORD PTR [bp+0x8]
    46d6:	ff 76 06             	push   WORD PTR [bp+0x6]
    46d9:	26 ff b5 62 01       	push   WORD PTR es:[di+0x162]
    46de:	26 ff b5 60 01       	push   WORD PTR es:[di+0x160]
    46e3:	26 ff 9d 5c 01       	call   DWORD PTR es:[di+0x15c]
    46e8:	c9                   	leave
    46e9:	ca 04 00             	retf   0x4
    46ec:	c8 02 00 00          	enter  0x2,0x0
    46f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46f3:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    46f8:	06                   	push   es
    46f9:	57                   	push   di
    46fa:	9a 94 65 15 47       	call   0x4715:0x6594
    46ff:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4702:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4706:	75 12                	jne    0x471a
    4708:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    470c:	26 c4 7d 55          	les    di,DWORD PTR es:[di+0x55]
    4710:	06                   	push   es
    4711:	57                   	push   di
    4712:	9a 94 65 4f 47       	call   0x474f:0x6594
    4717:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    471a:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    471e:	75 0f                	jne    0x472f
    4720:	6a 00                	push   0x0
    4722:	6a 00                	push   0x0
    4724:	68 00 7f             	push   0x7f00
    4727:	9a 45 66 00 00       	call   0x0:0x6645
    472c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    472f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4732:	c9                   	leave
    4733:	ca 04 00             	retf   0x4
    4736:	00 00                	add    BYTE PTR [bx+si],al
    4738:	97                   	xchg   di,ax
    4739:	47                   	inc    di
    473a:	fd                   	std
    473b:	47                   	inc    di
    473c:	55                   	push   bp
    473d:	89 e5                	mov    bp,sp
    473f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4742:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4745:	26 c4 bd f8 00       	les    di,DWORD PTR es:[di+0xf8]
    474a:	06                   	push   es
    474b:	57                   	push   di
    474c:	9a 5d 22 a6 47       	call   0x47a6:0x225d
    4751:	b8 36 47             	mov    ax,0x4736
    4754:	0e                   	push   cs
    4755:	50                   	push   ax
    4756:	55                   	push   bp
    4757:	ff 36 58 18          	push   WORD PTR ds:0x1858
    475b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    475f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4762:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    4767:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    476c:	74 10                	je     0x477e
    476e:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    4773:	06                   	push   es
    4774:	57                   	push   di
    4775:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4778:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    477c:	eb 0d                	jmp    0x478b
    477e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4781:	06                   	push   es
    4782:	57                   	push   di
    4783:	b8 e9 ff             	mov    ax,0xffe9
    4786:	9a 6a 20 b9 48       	call   0x48b9:0x206a
    478b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    478f:	83 c4 06             	add    sp,0x6
    4792:	b8 a9 47             	mov    ax,0x47a9
    4795:	0e                   	push   cs
    4796:	50                   	push   ax
    4797:	6a 00                	push   0x0
    4799:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    479c:	26 c4 bd f8 00       	les    di,DWORD PTR es:[di+0xf8]
    47a1:	06                   	push   es
    47a2:	57                   	push   di
    47a3:	9a 5d 22 5e 48       	call   0x485e:0x225d
    47a8:	cb                   	retf
    47a9:	c9                   	leave
    47aa:	ca 06 00             	retf   0x6
    47ad:	c8 22 00 00          	enter  0x22,0x0
    47b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47b4:	06                   	push   es
    47b5:	57                   	push   di
    47b6:	9a b9 62 d2 47       	call   0x47d2:0x62b9
    47bb:	50                   	push   ax
    47bc:	9a 8d 48 00 00       	call   0x0:0x488d
    47c1:	09 c0                	or     ax,ax
    47c3:	75 11                	jne    0x47d6
    47c5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    47c8:	06                   	push   es
    47c9:	57                   	push   di
    47ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47cd:	06                   	push   es
    47ce:	57                   	push   di
    47cf:	9a cb 46 de 47       	call   0x47de:0x46cb
    47d4:	eb 44                	jmp    0x481a
    47d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47d9:	06                   	push   es
    47da:	57                   	push   di
    47db:	9a b9 62 0d 48       	call   0x480d:0x62b9
    47e0:	50                   	push   ax
    47e1:	8d 7e de             	lea    di,[bp-0x22]
    47e4:	16                   	push   ss
    47e5:	57                   	push   di
    47e6:	9a 2e 6a 00 00       	call   0x0:0x6a2e
    47eb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    47ee:	ff 76 fe             	push   WORD PTR [bp-0x2]
    47f1:	6a 00                	push   0x0
    47f3:	6a 00                	push   0x0
    47f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47f8:	06                   	push   es
    47f9:	57                   	push   di
    47fa:	9a ec 46 ca 48       	call   0x48ca:0x46ec
    47ff:	50                   	push   ax
    4800:	9a 50 6a 00 00       	call   0x0:0x6a50
    4805:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4808:	06                   	push   es
    4809:	57                   	push   di
    480a:	9a b9 62 89 48       	call   0x4889:0x62b9
    480f:	50                   	push   ax
    4810:	8d 7e de             	lea    di,[bp-0x22]
    4813:	16                   	push   ss
    4814:	57                   	push   di
    4815:	9a 65 6a 00 00       	call   0x0:0x6a65
    481a:	c9                   	leave
    481b:	ca 08 00             	retf   0x8
    481e:	c8 08 00 00          	enter  0x8,0x0
    4822:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4825:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    482b:	75 3b                	jne    0x4868
    482d:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4832:	75 34                	jne    0x4868
    4834:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4837:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    483b:	8d 7e f8             	lea    di,[bp-0x8]
    483e:	16                   	push   ss
    483f:	57                   	push   di
    4840:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4843:	06                   	push   es
    4844:	57                   	push   di
    4845:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4848:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    484c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4850:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    4854:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    4859:	06                   	push   es
    485a:	57                   	push   di
    485b:	9a c0 16 d2 54       	call   0x54d2:0x16c0
    4860:	50                   	push   ax
    4861:	9a 61 59 00 00       	call   0x0:0x5961
    4866:	eb 12                	jmp    0x487a
    4868:	ff 76 0c             	push   WORD PTR [bp+0xc]
    486b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    486e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4871:	06                   	push   es
    4872:	57                   	push   di
    4873:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4876:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    487a:	c9                   	leave
    487b:	ca 08 00             	retf   0x8
    487e:	55                   	push   bp
    487f:	89 e5                	mov    bp,sp
    4881:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4884:	06                   	push   es
    4885:	57                   	push   di
    4886:	9a b9 62 a3 48       	call   0x48a3:0x62b9
    488b:	50                   	push   ax
    488c:	9a f4 4e 00 00       	call   0x0:0x4ef4
    4891:	09 c0                	or     ax,ax
    4893:	75 12                	jne    0x48a7
    4895:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4898:	ff 76 0a             	push   WORD PTR [bp+0xa]
    489b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    489e:	06                   	push   es
    489f:	57                   	push   di
    48a0:	9a 9e 4c 0e 49       	call   0x490e:0x4c9e
    48a5:	eb 14                	jmp    0x48bb
    48a7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    48aa:	26 c7 05 27 00       	mov    WORD PTR es:[di],0x27
    48af:	06                   	push   es
    48b0:	57                   	push   di
    48b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48b4:	06                   	push   es
    48b5:	57                   	push   di
    48b6:	9a 38 20 36 4d       	call   0x4d36:0x2038
    48bb:	c9                   	leave
    48bc:	ca 08 00             	retf   0x8
    48bf:	55                   	push   bp
    48c0:	89 e5                	mov    bp,sp
    48c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48c5:	06                   	push   es
    48c6:	57                   	push   di
    48c7:	9a ec 46 ea 49       	call   0x49ea:0x46ec
    48cc:	31 d2                	xor    dx,dx
    48ce:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    48d1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    48d5:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    48d9:	c9                   	leave
    48da:	ca 08 00             	retf   0x8
    48dd:	c8 02 00 00          	enter  0x2,0x0
    48e1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    48e4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    48e8:	26 80 bd ed 00 00    	cmp    BYTE PTR es:[di+0xed],0x0
    48ee:	75 03                	jne    0x48f3
    48f0:	e9 cc 00             	jmp    0x49bf
    48f3:	26 f6 85 ec 00 01    	test   BYTE PTR es:[di+0xec],0x1
    48f9:	75 03                	jne    0x48fe
    48fb:	e9 c1 00             	jmp    0x49bf
    48fe:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    4904:	75 03                	jne    0x4909
    4906:	e9 b6 00             	jmp    0x49bf
    4909:	06                   	push   es
    490a:	57                   	push   di
    490b:	9a b9 62 1d 4a       	call   0x4a1d:0x62b9
    4910:	50                   	push   ax
    4911:	6a 00                	push   0x0
    4913:	9a ff ff 00 00       	call   0x0:0xffff
    4918:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    491b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    491e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4922:	26 80 bd ed 00 03    	cmp    BYTE PTR es:[di+0xed],0x3
    4928:	75 5d                	jne    0x4987
    492a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    492d:	68 30 f1             	push   0xf130
    4930:	6a 00                	push   0x0
    4932:	9a 40 49 00 00       	call   0x0:0x4940
    4937:	ff 76 fe             	push   WORD PTR [bp-0x2]
    493a:	6a 07                	push   0x7
    493c:	68 00 04             	push   0x400
    493f:	9a 4d 49 00 00       	call   0x0:0x494d
    4944:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4947:	6a 05                	push   0x5
    4949:	68 00 04             	push   0x400
    494c:	9a 5a 49 00 00       	call   0x0:0x495a
    4951:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4954:	68 30 f0             	push   0xf030
    4957:	6a 00                	push   0x0
    4959:	9a 67 49 00 00       	call   0x0:0x4967
    495e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4961:	68 20 f0             	push   0xf020
    4964:	6a 00                	push   0x0
    4966:	9a 74 49 00 00       	call   0x0:0x4974
    496b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    496e:	68 00 f0             	push   0xf000
    4971:	6a 00                	push   0x0
    4973:	9a 81 49 00 00       	call   0x0:0x4981
    4978:	ff 76 fe             	push   WORD PTR [bp-0x2]
    497b:	68 20 f1             	push   0xf120
    497e:	6a 00                	push   0x0
    4980:	9a ff ff 00 00       	call   0x0:0xffff
    4985:	eb 38                	jmp    0x49bf
    4987:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    498a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    498e:	26 f6 85 ec 00 02    	test   BYTE PTR es:[di+0xec],0x2
    4994:	75 0d                	jne    0x49a3
    4996:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4999:	68 20 f0             	push   0xf020
    499c:	6a 01                	push   0x1
    499e:	9a bb 49 00 00       	call   0x0:0x49bb
    49a3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49a6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    49aa:	26 f6 85 ec 00 04    	test   BYTE PTR es:[di+0xec],0x4
    49b0:	75 0d                	jne    0x49bf
    49b2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    49b5:	68 30 f0             	push   0xf030
    49b8:	6a 01                	push   0x1
    49ba:	9a ff ff 00 00       	call   0x0:0xffff
    49bf:	c9                   	leave
    49c0:	c2 02 00             	ret    0x2
    49c3:	55                   	push   bp
    49c4:	89 e5                	mov    bp,sp
    49c6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    49c9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    49cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49cf:	06                   	push   es
    49d0:	57                   	push   di
    49d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49d4:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    49d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49db:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    49e0:	26 ff b5 00 01       	push   WORD PTR es:[di+0x100]
    49e5:	06                   	push   es
    49e6:	57                   	push   di
    49e7:	9a b2 36 99 4b       	call   0x4b99:0x36b2
    49ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49ef:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    49f4:	75 04                	jne    0x49fa
    49f6:	55                   	push   bp
    49f7:	e8 e3 fe             	call   0x48dd
    49fa:	c9                   	leave
    49fb:	ca 08 00             	retf   0x8
    49fe:	55                   	push   bp
    49ff:	89 e5                	mov    bp,sp
    4a01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a04:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4a09:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    4a0e:	74 28                	je     0x4a38
    4a10:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    4a16:	74 20                	je     0x4a38
    4a18:	06                   	push   es
    4a19:	57                   	push   di
    4a1a:	9a b9 62 65 4a       	call   0x4a65:0x62b9
    4a1f:	50                   	push   ax
    4a20:	6a 00                	push   0x0
    4a22:	9a ff ff 00 00       	call   0x0:0xffff
    4a27:	6a 00                	push   0x0
    4a29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a2c:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4a31:	06                   	push   es
    4a32:	57                   	push   di
    4a33:	9a 77 1d a2 4a       	call   0x4aa2:0x1d77
    4a38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a3b:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4a40:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4a45:	74 10                	je     0x4a57
    4a47:	6a 00                	push   0x0
    4a49:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4a4e:	06                   	push   es
    4a4f:	57                   	push   di
    4a50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a53:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    4a57:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4a5a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a60:	06                   	push   es
    4a61:	57                   	push   di
    4a62:	9a 22 54 b6 4a       	call   0x4ab6:0x5422
    4a67:	c9                   	leave
    4a68:	ca 08 00             	retf   0x8
    4a6b:	c8 04 00 00          	enter  0x4,0x0
    4a6f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a72:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4a75:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4a78:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    4a7d:	75 29                	jne    0x4aa8
    4a7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a82:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4a87:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    4a8c:	74 1a                	je     0x4aa8
    4a8e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4a91:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4a95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a98:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4a9d:	06                   	push   es
    4a9e:	57                   	push   di
    4a9f:	9a be 19 e2 4a       	call   0x4ae2:0x19be
    4aa4:	08 c0                	or     al,al
    4aa6:	75 10                	jne    0x4ab8
    4aa8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4aab:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4aae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ab1:	06                   	push   es
    4ab2:	57                   	push   di
    4ab3:	9a c4 4a 8e 4b       	call   0x4b8e:0x4ac4
    4ab8:	c9                   	leave
    4ab9:	ca 08 00             	retf   0x8
    4abc:	55                   	push   bp
    4abd:	89 e5                	mov    bp,sp
    4abf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ac2:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4ac7:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    4acc:	74 16                	je     0x4ae4
    4ace:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ad1:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ad8:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4add:	06                   	push   es
    4ade:	57                   	push   di
    4adf:	9a fa 19 28 4b       	call   0x4b28:0x19fa
    4ae4:	c9                   	leave
    4ae5:	ca 08 00             	retf   0x8
    4ae8:	00 c8                	add    al,cl
    4aea:	0a 02                	or     al,BYTE PTR [bp+si]
    4aec:	00 c4                	add    ah,al
    4aee:	7e 06                	jle    0x4af6
    4af0:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4af5:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    4afa:	75 03                	jne    0x4aff
    4afc:	e9 ae 00             	jmp    0x4bad
    4aff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b02:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    4b05:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    4b08:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4b0c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4b10:	25 10 00             	and    ax,0x10
    4b13:	09 c0                	or     ax,ax
    4b15:	b0 00                	mov    al,0x0
    4b17:	75 01                	jne    0x4b1a
    4b19:	40                   	inc    ax
    4b1a:	50                   	push   ax
    4b1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b1e:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4b23:	06                   	push   es
    4b24:	57                   	push   di
    4b25:	9a 42 19 65 4b       	call   0x4b65:0x1942
    4b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b2d:	26 89 85 0a 01       	mov    WORD PTR es:[di+0x10a],ax
    4b32:	26 89 95 0c 01       	mov    WORD PTR es:[di+0x10c],dx
    4b37:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    4b3b:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4b3e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4b42:	25 10 00             	and    ax,0x10
    4b45:	09 c0                	or     ax,ax
    4b47:	74 04                	je     0x4b4d
    4b49:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    4b4d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4b50:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4b54:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    4b57:	50                   	push   ax
    4b58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b5b:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4b60:	06                   	push   es
    4b61:	57                   	push   di
    4b62:	9a fb 18 89 4b       	call   0x4b89:0x18fb
    4b67:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b6a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b6d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4b70:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    4b73:	74 28                	je     0x4b9d
    4b75:	8d be f6 fd          	lea    di,[bp-0x20a]
    4b79:	16                   	push   ss
    4b7a:	57                   	push   di
    4b7b:	8d be f6 fe          	lea    di,[bp-0x10a]
    4b7f:	16                   	push   ss
    4b80:	57                   	push   di
    4b81:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4b84:	06                   	push   es
    4b85:	57                   	push   di
    4b86:	9a e8 10 22 6d       	call   0x6d22:0x10e8
    4b8b:	9a 08 0d 88 4c       	call   0x4c88:0xd08
    4b90:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4b94:	06                   	push   es
    4b95:	57                   	push   di
    4b96:	9a 9e 80 ab 4b       	call   0x4bab:0x809e
    4b9b:	eb 10                	jmp    0x4bad
    4b9d:	bf e8 4a             	mov    di,0x4ae8
    4ba0:	0e                   	push   cs
    4ba1:	57                   	push   di
    4ba2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4ba6:	06                   	push   es
    4ba7:	57                   	push   di
    4ba8:	9a 9e 80 0b 4c       	call   0x4c0b:0x809e
    4bad:	c9                   	leave
    4bae:	ca 08 00             	retf   0x8
    4bb1:	c8 04 00 00          	enter  0x4,0x0
    4bb5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4bb8:	26 83 7d 02 02       	cmp    WORD PTR es:[di+0x2],0x2
    4bbd:	75 5d                	jne    0x4c1c
    4bbf:	6a 70                	push   0x70
    4bc1:	9a 6f 50 00 00       	call   0x0:0x506f
    4bc6:	09 c0                	or     ax,ax
    4bc8:	7d 52                	jge    0x4c1c
    4bca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bcd:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    4bd2:	26 0b 85 0c 01       	or     ax,WORD PTR es:[di+0x10c]
    4bd7:	74 43                	je     0x4c1c
    4bd9:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    4bde:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    4be3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4be6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4be9:	9a 3b 54 00 00       	call   0x0:0x543b
    4bee:	50                   	push   ax
    4bef:	6a 1f                	push   0x1f
    4bf1:	6a 00                	push   0x0
    4bf3:	6a 00                	push   0x0
    4bf5:	6a 00                	push   0x0
    4bf7:	9a e1 52 00 00       	call   0x0:0x52e1
    4bfc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4bff:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4c02:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4c06:	06                   	push   es
    4c07:	57                   	push   di
    4c08:	9a 92 77 9a 4c       	call   0x4c9a:0x7792
    4c0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c10:	31 c0                	xor    ax,ax
    4c12:	26 89 85 0a 01       	mov    WORD PTR es:[di+0x10a],ax
    4c17:	26 89 85 0c 01       	mov    WORD PTR es:[di+0x10c],ax
    4c1c:	c9                   	leave
    4c1d:	ca 08 00             	retf   0x8
    4c20:	55                   	push   bp
    4c21:	89 e5                	mov    bp,sp
    4c23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c26:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4c2b:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4c30:	74 1f                	je     0x4c51
    4c32:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c35:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    4c3a:	b0 00                	mov    al,0x0
    4c3c:	74 01                	je     0x4c3f
    4c3e:	40                   	inc    ax
    4c3f:	50                   	push   ax
    4c40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c43:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4c48:	06                   	push   es
    4c49:	57                   	push   di
    4c4a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c4d:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    4c51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c54:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    4c5a:	75 07                	jne    0x4c63
    4c5c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4c61:	74 4e                	je     0x4cb1
    4c63:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c66:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    4c6b:	74 3b                	je     0x4ca8
    4c6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c70:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    4c75:	26 0b 85 e6 00       	or     ax,WORD PTR es:[di+0xe6]
    4c7a:	75 0e                	jne    0x4c8a
    4c7c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4c81:	75 07                	jne    0x4c8a
    4c83:	06                   	push   es
    4c84:	57                   	push   di
    4c85:	9a 11 68 67 4d       	call   0x4d67:0x6811
    4c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c8d:	26 c6 85 f1 00 01    	mov    BYTE PTR es:[di+0xf1],0x1
    4c93:	6a 01                	push   0x1
    4c95:	06                   	push   es
    4c96:	57                   	push   di
    4c97:	9a df 44 a4 4c       	call   0x4ca4:0x44df
    4c9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c9f:	06                   	push   es
    4ca0:	57                   	push   di
    4ca1:	9a 33 44 e3 4c       	call   0x4ce3:0x4433
    4ca6:	eb 09                	jmp    0x4cb1
    4ca8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cab:	26 c6 85 f1 00 00    	mov    BYTE PTR es:[di+0xf1],0x0
    4cb1:	c9                   	leave
    4cb2:	ca 08 00             	retf   0x8
    4cb5:	55                   	push   bp
    4cb6:	89 e5                	mov    bp,sp
    4cb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cbb:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4cc0:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4cc5:	74 0e                	je     0x4cd5
    4cc7:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4ccc:	06                   	push   es
    4ccd:	57                   	push   di
    4cce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cd1:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    4cd5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4cd8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4cdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cde:	06                   	push   es
    4cdf:	57                   	push   di
    4ce0:	9a 90 24 40 4d       	call   0x4d40:0x2490
    4ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ce8:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4ced:	75 35                	jne    0x4d24
    4cef:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4cf2:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    4cf6:	3d 00 00             	cmp    ax,0x0
    4cf9:	75 0b                	jne    0x4d06
    4cfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cfe:	26 c6 85 ee 00 00    	mov    BYTE PTR es:[di+0xee],0x0
    4d04:	eb 1e                	jmp    0x4d24
    4d06:	3d 01 00             	cmp    ax,0x1
    4d09:	75 0b                	jne    0x4d16
    4d0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d0e:	26 c6 85 ee 00 01    	mov    BYTE PTR es:[di+0xee],0x1
    4d14:	eb 0e                	jmp    0x4d24
    4d16:	3d 02 00             	cmp    ax,0x2
    4d19:	75 09                	jne    0x4d24
    4d1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d1e:	26 c6 85 ee 00 02    	mov    BYTE PTR es:[di+0xee],0x2
    4d24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d27:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    4d2c:	75 0a                	jne    0x4d38
    4d2e:	06                   	push   es
    4d2f:	57                   	push   di
    4d30:	b8 e8 ff             	mov    ax,0xffe8
    4d33:	9a 6a 20 3c 50       	call   0x503c:0x206a
    4d38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d3b:	06                   	push   es
    4d3c:	57                   	push   di
    4d3d:	9a 79 20 51 4d       	call   0x4d51:0x2079
    4d42:	c9                   	leave
    4d43:	ca 08 00             	retf   0x8
    4d46:	55                   	push   bp
    4d47:	89 e5                	mov    bp,sp
    4d49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d4c:	06                   	push   es
    4d4d:	57                   	push   di
    4d4e:	9a 56 55 3f 4e       	call   0x4e3f:0x5556
    4d53:	c9                   	leave
    4d54:	ca 08 00             	retf   0x8
    4d57:	55                   	push   bp
    4d58:	89 e5                	mov    bp,sp
    4d5a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d5d:	06                   	push   es
    4d5e:	57                   	push   di
    4d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d62:	06                   	push   es
    4d63:	57                   	push   di
    4d64:	9a 51 1b 09 4e       	call   0x4e09:0x1b51
    4d69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d6c:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4d71:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4d76:	74 0e                	je     0x4d86
    4d78:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4d7d:	06                   	push   es
    4d7e:	57                   	push   di
    4d7f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d82:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    4d86:	c9                   	leave
    4d87:	ca 08 00             	retf   0x8
    4d8a:	55                   	push   bp
    4d8b:	89 e5                	mov    bp,sp
    4d8d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d90:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d96:	06                   	push   es
    4d97:	57                   	push   di
    4d98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d9b:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4d9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4da2:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4da7:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4dac:	74 0f                	je     0x4dbd
    4dae:	6a 01                	push   0x1
    4db0:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4db5:	06                   	push   es
    4db6:	57                   	push   di
    4db7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dba:	26 ff 1d             	call   DWORD PTR es:[di]
    4dbd:	c9                   	leave
    4dbe:	ca 08 00             	retf   0x8
    4dc1:	55                   	push   bp
    4dc2:	89 e5                	mov    bp,sp
    4dc4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4dc7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dcd:	06                   	push   es
    4dce:	57                   	push   di
    4dcf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dd2:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4dd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dd9:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4dde:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4de3:	74 0f                	je     0x4df4
    4de5:	6a 00                	push   0x0
    4de7:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4dec:	06                   	push   es
    4ded:	57                   	push   di
    4dee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4df1:	26 ff 1d             	call   DWORD PTR es:[di]
    4df4:	c9                   	leave
    4df5:	ca 08 00             	retf   0x8
    4df8:	55                   	push   bp
    4df9:	89 e5                	mov    bp,sp
    4dfb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4dfe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e04:	06                   	push   es
    4e05:	57                   	push   di
    4e06:	9a be 53 d2 4e       	call   0x4ed2:0x53be
    4e0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e0e:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    4e13:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    4e18:	74 16                	je     0x4e30
    4e1a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4e1d:	06                   	push   es
    4e1e:	57                   	push   di
    4e1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e22:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    4e27:	06                   	push   es
    4e28:	57                   	push   di
    4e29:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e2c:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    4e30:	c9                   	leave
    4e31:	ca 08 00             	retf   0x8
    4e34:	55                   	push   bp
    4e35:	89 e5                	mov    bp,sp
    4e37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e3a:	06                   	push   es
    4e3b:	57                   	push   di
    4e3c:	9a 48 56 83 4e       	call   0x4e83:0x5648
    4e41:	98                   	cbw
    4e42:	99                   	cwd
    4e43:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4e46:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4e4a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    4e4e:	c9                   	leave
    4e4f:	ca 08 00             	retf   0x8
    4e52:	55                   	push   bp
    4e53:	89 e5                	mov    bp,sp
    4e55:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4e58:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    4e5c:	25 f0 ff             	and    ax,0xfff0
    4e5f:	3d 20 f0             	cmp    ax,0xf020
    4e62:	75 23                	jne    0x4e87
    4e64:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4e68:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    4e6c:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    4e70:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    4e73:	75 12                	jne    0x4e87
    4e75:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    4e78:	75 0d                	jne    0x4e87
    4e7a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4e7e:	06                   	push   es
    4e7f:	57                   	push   di
    4e80:	9a 0d 6f b4 4f       	call   0x4fb4:0x6f0d
    4e85:	eb 4d                	jmp    0x4ed4
    4e87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e8a:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4e8f:	75 33                	jne    0x4ec4
    4e91:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    4e97:	74 2b                	je     0x4ec4
    4e99:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4e9e:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    4ea3:	74 1f                	je     0x4ec4
    4ea5:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    4eaa:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    4eaf:	75 13                	jne    0x4ec4
    4eb1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4eb4:	06                   	push   es
    4eb5:	57                   	push   di
    4eb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eb9:	06                   	push   es
    4eba:	57                   	push   di
    4ebb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ebe:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4ec2:	eb 10                	jmp    0x4ed4
    4ec4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ec7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4eca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ecd:	06                   	push   es
    4ece:	57                   	push   di
    4ecf:	9a ff 52 f0 4e       	call   0x4ef0:0x52ff
    4ed4:	c9                   	leave
    4ed5:	ca 08 00             	retf   0x8
    4ed8:	c8 04 00 00          	enter  0x4,0x0
    4edc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4edf:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4ee3:	3d 01 00             	cmp    ax,0x1
    4ee6:	75 5b                	jne    0x4f43
    4ee8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eeb:	06                   	push   es
    4eec:	57                   	push   di
    4eed:	9a b9 62 0f 4f       	call   0x4f0f:0x62b9
    4ef2:	50                   	push   ax
    4ef3:	9a 50 54 00 00       	call   0x0:0x5450
    4ef8:	09 c0                	or     ax,ax
    4efa:	74 0b                	je     0x4f07
    4efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eff:	26 c6 85 ef 00 02    	mov    BYTE PTR es:[di+0xef],0x2
    4f05:	eb 28                	jmp    0x4f2f
    4f07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f0a:	06                   	push   es
    4f0b:	57                   	push   di
    4f0c:	9a b9 62 58 4f       	call   0x4f58:0x62b9
    4f11:	50                   	push   ax
    4f12:	9a ff ff 00 00       	call   0x0:0xffff
    4f17:	09 c0                	or     ax,ax
    4f19:	74 0b                	je     0x4f26
    4f1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f1e:	26 c6 85 ef 00 03    	mov    BYTE PTR es:[di+0xef],0x3
    4f24:	eb 09                	jmp    0x4f2f
    4f26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f29:	26 c6 85 ef 00 01    	mov    BYTE PTR es:[di+0xef],0x1
    4f2f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f32:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f38:	06                   	push   es
    4f39:	57                   	push   di
    4f3a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f3d:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4f41:	eb 4b                	jmp    0x4f8e
    4f43:	3d 03 00             	cmp    ax,0x3
    4f46:	75 34                	jne    0x4f7c
    4f48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f4b:	26 80 bd ef 00 00    	cmp    BYTE PTR es:[di+0xef],0x0
    4f51:	74 27                	je     0x4f7a
    4f53:	06                   	push   es
    4f54:	57                   	push   di
    4f55:	9a b9 62 01 50       	call   0x5001:0x62b9
    4f5a:	50                   	push   ax
    4f5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f5e:	26 8a 85 ef 00       	mov    al,BYTE PTR es:[di+0xef]
    4f63:	98                   	cbw
    4f64:	8b f8                	mov    di,ax
    4f66:	d1 e7                	shl    di,1
    4f68:	ff b5 50 16          	push   WORD PTR [di+0x1650]
    4f6c:	9a f3 52 00 00       	call   0x0:0x52f3
    4f71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f74:	26 c6 85 ef 00 00    	mov    BYTE PTR es:[di+0xef],0x0
    4f7a:	eb 12                	jmp    0x4f8e
    4f7c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f7f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f85:	06                   	push   es
    4f86:	57                   	push   di
    4f87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f8a:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4f8e:	c9                   	leave
    4f8f:	ca 08 00             	retf   0x8
    4f92:	55                   	push   bp
    4f93:	89 e5                	mov    bp,sp
    4f95:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f98:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f9e:	06                   	push   es
    4f9f:	57                   	push   di
    4fa0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fa3:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4fa7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4faa:	06                   	push   es
    4fab:	57                   	push   di
    4fac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4faf:	06                   	push   es
    4fb0:	57                   	push   di
    4fb1:	9a 20 4c 16 50       	call   0x5016:0x4c20
    4fb6:	c9                   	leave
    4fb7:	ca 08 00             	retf   0x8
    4fba:	c8 04 00 00          	enter  0x4,0x0
    4fbe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4fc1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4fc4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4fc7:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    4fcc:	74 0e                	je     0x4fdc
    4fce:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4fd1:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4fd5:	9a ab 6d 00 00       	call   0x0:0x6dab
    4fda:	eb 27                	jmp    0x5003
    4fdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fdf:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    4fe4:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    4fe9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4fec:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    4ff1:	b0 00                	mov    al,0x0
    4ff3:	75 01                	jne    0x4ff6
    4ff5:	40                   	inc    ax
    4ff6:	50                   	push   ax
    4ff7:	6a 01                	push   0x1
    4ff9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ffc:	06                   	push   es
    4ffd:	57                   	push   di
    4ffe:	9a ce 67 9d 50       	call   0x509d:0x67ce
    5003:	c9                   	leave
    5004:	ca 08 00             	retf   0x8
    5007:	55                   	push   bp
    5008:	89 e5                	mov    bp,sp
    500a:	6a 00                	push   0x0
    500c:	6a 00                	push   0x0
    500e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5011:	06                   	push   es
    5012:	57                   	push   di
    5013:	9a 79 44 39 51       	call   0x5139:0x4479
    5018:	ff 76 0c             	push   WORD PTR [bp+0xc]
    501b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    501e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5021:	06                   	push   es
    5022:	57                   	push   di
    5023:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5026:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    502a:	c9                   	leave
    502b:	ca 08 00             	retf   0x8
    502e:	55                   	push   bp
    502f:	89 e5                	mov    bp,sp
    5031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5034:	06                   	push   es
    5035:	57                   	push   di
    5036:	b8 ee ff             	mov    ax,0xffee
    5039:	9a 6a 20 50 50       	call   0x5050:0x206a
    503e:	c9                   	leave
    503f:	ca 08 00             	retf   0x8
    5042:	55                   	push   bp
    5043:	89 e5                	mov    bp,sp
    5045:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5048:	06                   	push   es
    5049:	57                   	push   di
    504a:	b8 ec ff             	mov    ax,0xffec
    504d:	9a 6a 20 84 51       	call   0x5184:0x206a
    5052:	c9                   	leave
    5053:	ca 08 00             	retf   0x8
    5056:	c8 04 00 00          	enter  0x4,0x0
    505a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    505d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5060:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5063:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    5067:	3d 09 00             	cmp    ax,0x9
    506a:	75 46                	jne    0x50b2
    506c:	6a 11                	push   0x11
    506e:	9a 87 50 00 00       	call   0x0:0x5087
    5073:	09 c0                	or     ax,ax
    5075:	7c 39                	jl     0x50b0
    5077:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    507a:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    507f:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    5084:	6a 10                	push   0x10
    5086:	9a ff ff 00 00       	call   0x0:0xffff
    508b:	09 c0                	or     ax,ax
    508d:	b0 00                	mov    al,0x0
    508f:	7c 01                	jl     0x5092
    5091:	40                   	inc    ax
    5092:	50                   	push   ax
    5093:	6a 01                	push   0x1
    5095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5098:	06                   	push   es
    5099:	57                   	push   di
    509a:	9a ce 67 0a 51       	call   0x510a:0x67ce
    509f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50a2:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    50a8:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    50ae:	eb 7d                	jmp    0x512d
    50b0:	eb 6b                	jmp    0x511d
    50b2:	3d 25 00             	cmp    ax,0x25
    50b5:	74 0f                	je     0x50c6
    50b7:	3d 27 00             	cmp    ax,0x27
    50ba:	74 0a                	je     0x50c6
    50bc:	3d 26 00             	cmp    ax,0x26
    50bf:	74 05                	je     0x50c6
    50c1:	3d 28 00             	cmp    ax,0x28
    50c4:	75 57                	jne    0x511d
    50c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50c9:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    50ce:	26 0b 85 e6 00       	or     ax,WORD PTR es:[di+0xe6]
    50d3:	74 46                	je     0x511b
    50d5:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    50da:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    50df:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50e2:	26 83 7d 02 27       	cmp    WORD PTR es:[di+0x2],0x27
    50e7:	74 0b                	je     0x50f4
    50e9:	26 83 7d 02 28       	cmp    WORD PTR es:[di+0x2],0x28
    50ee:	74 04                	je     0x50f4
    50f0:	b0 00                	mov    al,0x0
    50f2:	eb 02                	jmp    0x50f6
    50f4:	b0 01                	mov    al,0x1
    50f6:	50                   	push   ax
    50f7:	6a 00                	push   0x0
    50f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50fc:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    5101:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5105:	06                   	push   es
    5106:	57                   	push   di
    5107:	9a ce 67 2b 51       	call   0x512b:0x67ce
    510c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    510f:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    5115:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    511b:	eb 10                	jmp    0x512d
    511d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5120:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5123:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5126:	06                   	push   es
    5127:	57                   	push   di
    5128:	9a 10 56 76 51       	call   0x5176:0x5610
    512d:	c9                   	leave
    512e:	ca 08 00             	retf   0x8
    5131:	01 00                	add    WORD PTR [bx+si],ax
    5133:	00 00                	add    BYTE PTR [bx+si],al
    5135:	00 00                	add    BYTE PTR [bx+si],al
    5137:	d3 51 43             	rcl    WORD PTR [bx+di+0x43],cl
    513a:	51                   	push   cx
    513b:	01 00                	add    WORD PTR [bx+si],ax
    513d:	00 00                	add    BYTE PTR [bx+si],al
    513f:	00 00                	add    BYTE PTR [bx+si],al
    5141:	b6 53                	mov    dh,0x53
    5143:	49                   	dec    cx
    5144:	51                   	push   cx
    5145:	00 00                	add    BYTE PTR [bx+si],al
    5147:	b4 54                	mov    ah,0x54
    5149:	e2 51                	loop   0x519c
    514b:	c8 06 01 00          	enter  0x106,0x0
    514f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5152:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    5157:	75 2d                	jne    0x5186
    5159:	26 f6 85 f5 00 04    	test   BYTE PTR es:[di+0xf5],0x4
    515f:	74 25                	je     0x5186
    5161:	8d be fa fe          	lea    di,[bp-0x106]
    5165:	16                   	push   ss
    5166:	57                   	push   di
    5167:	68 2c f0             	push   0xf02c
    516a:	9a 2b 09 7d 51       	call   0x517d:0x92b
    516f:	b0 01                	mov    al,0x1
    5171:	50                   	push   ax
    5172:	b8 52 00             	mov    ax,0x52
    5175:	ba 0c 52             	mov    dx,0x520c
    5178:	52                   	push   dx
    5179:	50                   	push   ax
    517a:	9a e6 28 12 5d       	call   0x5d12:0x28e6
    517f:	52                   	push   dx
    5180:	50                   	push   ax
    5181:	9a 99 13 c8 51       	call   0x51c8:0x1399
    5186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5189:	26 80 8d f5 00 04    	or     BYTE PTR es:[di+0xf5],0x4
    518f:	b8 45 51             	mov    ax,0x5145
    5192:	0e                   	push   cs
    5193:	50                   	push   ax
    5194:	55                   	push   bp
    5195:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5199:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    519d:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    51a2:	74 03                	je     0x51a7
    51a4:	e9 01 03             	jmp    0x54a8
    51a7:	26 80 bd a7 00 00    	cmp    BYTE PTR es:[di+0xa7],0x0
    51ad:	75 03                	jne    0x51b2
    51af:	e9 e0 01             	jmp    0x5392
    51b2:	b8 31 51             	mov    ax,0x5131
    51b5:	0e                   	push   cs
    51b6:	50                   	push   ax
    51b7:	55                   	push   bp
    51b8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    51bc:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    51c0:	06                   	push   es
    51c1:	57                   	push   di
    51c2:	b8 ea ff             	mov    ax,0xffea
    51c5:	9a 6a 20 e7 51       	call   0x51e7:0x206a
    51ca:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    51ce:	83 c4 06             	add    sp,0x6
    51d1:	eb 16                	jmp    0x51e9
    51d3:	ff 76 08             	push   WORD PTR [bp+0x8]
    51d6:	ff 76 06             	push   WORD PTR [bp+0x6]
    51d9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    51dd:	06                   	push   es
    51de:	57                   	push   di
    51df:	9a 51 75 48 52       	call   0x5248:0x7551
    51e4:	9a 34 14 ab 53       	call   0x53ab:0x1434
    51e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ec:	26 80 bd f3 00 04    	cmp    BYTE PTR es:[di+0xf3],0x4
    51f2:	74 03                	je     0x51f7
    51f4:	e9 ae 00             	jmp    0x52a5
    51f7:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    51fd:	75 40                	jne    0x523f
    51ff:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5203:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    5207:	06                   	push   es
    5208:	57                   	push   di
    5209:	9a a9 18 2b 52       	call   0x522b:0x18a9
    520e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5211:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    5215:	99                   	cwd
    5216:	b9 02 00             	mov    cx,0x2
    5219:	f7 f9                	idiv   cx
    521b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    521e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5222:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    5226:	06                   	push   es
    5227:	57                   	push   di
    5228:	9a f4 18 d9 52       	call   0x52d9:0x18f4
    522d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5230:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    5234:	99                   	cwd
    5235:	b9 02 00             	mov    cx,0x2
    5238:	f7 f9                	idiv   cx
    523a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    523d:	eb 36                	jmp    0x5275
    523f:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    5243:	06                   	push   es
    5244:	57                   	push   di
    5245:	9a ba 60 63 52       	call   0x5263:0x60ba
    524a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    524d:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    5251:	99                   	cwd
    5252:	b9 02 00             	mov    cx,0x2
    5255:	f7 f9                	idiv   cx
    5257:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    525a:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    525e:	06                   	push   es
    525f:	57                   	push   di
    5260:	9a a5 60 c5 53       	call   0x53c5:0x60a5
    5265:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5268:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    526c:	99                   	cwd
    526d:	b9 02 00             	mov    cx,0x2
    5270:	f7 f9                	idiv   cx
    5272:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5275:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    5279:	7d 05                	jge    0x5280
    527b:	31 c0                	xor    ax,ax
    527d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5280:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5284:	7d 05                	jge    0x528b
    5286:	31 c0                	xor    ax,ax
    5288:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    528b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    528e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5291:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5294:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    5298:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    529c:	06                   	push   es
    529d:	57                   	push   di
    529e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52a1:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    52a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52a8:	26 c6 85 f3 00 00    	mov    BYTE PTR es:[di+0xf3],0x0
    52ae:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    52b4:	74 03                	je     0x52b9
    52b6:	e9 b5 00             	jmp    0x536e
    52b9:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    52bf:	75 38                	jne    0x52f9
    52c1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    52c5:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    52c9:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    52ce:	68 23 02             	push   0x223
    52d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52d4:	06                   	push   es
    52d5:	57                   	push   di
    52d6:	9a b9 62 ed 52       	call   0x52ed:0x62b9
    52db:	50                   	push   ax
    52dc:	6a 00                	push   0x0
    52de:	6a 00                	push   0x0
    52e0:	9a 68 53 00 00       	call   0x0:0x5368
    52e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52e8:	06                   	push   es
    52e9:	57                   	push   di
    52ea:	9a b9 62 01 53       	call   0x5301:0x62b9
    52ef:	50                   	push   ax
    52f0:	6a 03                	push   0x3
    52f2:	9a 16 53 00 00       	call   0x0:0x5316
    52f7:	eb 58                	jmp    0x5351
    52f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52fc:	06                   	push   es
    52fd:	57                   	push   di
    52fe:	9a b9 62 2a 53       	call   0x532a:0x62b9
    5303:	50                   	push   ax
    5304:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5307:	26 8a 85 ee 00       	mov    al,BYTE PTR es:[di+0xee]
    530c:	98                   	cbw
    530d:	8b f8                	mov    di,ax
    530f:	d1 e7                	shl    di,1
    5311:	ff b5 58 16          	push   WORD PTR [di+0x1658]
    5315:	9a 8b 53 00 00       	call   0x0:0x538b
    531a:	bf ff ff             	mov    di,0xffff
    531d:	b8 ff ff             	mov    ax,0xffff
    5320:	50                   	push   ax
    5321:	57                   	push   di
    5322:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5325:	06                   	push   es
    5326:	57                   	push   di
    5327:	9a b9 62 4f 53       	call   0x534f:0x62b9
    532c:	50                   	push   ax
    532d:	6a 05                	push   0x5
    532f:	6a 00                	push   0x0
    5331:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5334:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    5338:	c1 e0 10             	shl    ax,0x10
    533b:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    533f:	99                   	cwd
    5340:	52                   	push   dx
    5341:	50                   	push   ax
    5342:	9a ff ff 00 00       	call   0x0:0xffff
    5347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    534a:	06                   	push   es
    534b:	57                   	push   di
    534c:	9a 1c 20 76 53       	call   0x5376:0x201c
    5351:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5355:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    5359:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    535e:	68 30 02             	push   0x230
    5361:	6a 01                	push   0x1
    5363:	6a 00                	push   0x0
    5365:	6a 00                	push   0x0
    5367:	9a 4e 55 00 00       	call   0x0:0x554e
    536c:	eb 21                	jmp    0x538f
    536e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5371:	06                   	push   es
    5372:	57                   	push   di
    5373:	9a b9 62 fe 53       	call   0x53fe:0x62b9
    5378:	50                   	push   ax
    5379:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    537c:	26 8a 85 ee 00       	mov    al,BYTE PTR es:[di+0xee]
    5381:	98                   	cbw
    5382:	8b f8                	mov    di,ax
    5384:	d1 e7                	shl    di,1
    5386:	ff b5 58 16          	push   WORD PTR [di+0x1658]
    538a:	9a a4 54 00 00       	call   0x0:0x54a4
    538f:	e9 16 01             	jmp    0x54a8
    5392:	b8 3b 51             	mov    ax,0x513b
    5395:	0e                   	push   cs
    5396:	50                   	push   ax
    5397:	55                   	push   bp
    5398:	ff 36 58 18          	push   WORD PTR ds:0x1858
    539c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    53a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53a3:	06                   	push   es
    53a4:	57                   	push   di
    53a5:	b8 eb ff             	mov    ax,0xffeb
    53a8:	9a 6a 20 ca 53       	call   0x53ca:0x206a
    53ad:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    53b1:	83 c4 06             	add    sp,0x6
    53b4:	eb 16                	jmp    0x53cc
    53b6:	ff 76 08             	push   WORD PTR [bp+0x8]
    53b9:	ff 76 06             	push   WORD PTR [bp+0x6]
    53bc:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    53c0:	06                   	push   es
    53c1:	57                   	push   di
    53c2:	9a 51 75 ec 53       	call   0x53ec:0x7551
    53c7:	9a 34 14 f3 54       	call   0x54f3:0x1434
    53cc:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    53d0:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    53d4:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    53d8:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    53db:	75 11                	jne    0x53ee
    53dd:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    53e0:	75 0c                	jne    0x53ee
    53e2:	6a 00                	push   0x0
    53e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53e7:	06                   	push   es
    53e8:	57                   	push   di
    53e9:	9a df 44 77 55       	call   0x5577:0x44df
    53ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53f1:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    53f7:	75 0a                	jne    0x5403
    53f9:	06                   	push   es
    53fa:	57                   	push   di
    53fb:	9a ee 3f 13 54       	call   0x5413:0x3fee
    5400:	e9 a5 00             	jmp    0x54a8
    5403:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5406:	26 f6 85 f5 00 08    	test   BYTE PTR es:[di+0xf5],0x8
    540c:	74 1c                	je     0x542a
    540e:	06                   	push   es
    540f:	57                   	push   di
    5410:	9a b9 62 37 54       	call   0x5437:0x62b9
    5415:	50                   	push   ax
    5416:	6a 00                	push   0x0
    5418:	6a 00                	push   0x0
    541a:	6a 00                	push   0x0
    541c:	6a 00                	push   0x0
    541e:	6a 00                	push   0x0
    5420:	68 97 00             	push   0x97
    5423:	9a 88 54 00 00       	call   0x0:0x5488
    5428:	eb 7e                	jmp    0x54a8
    542a:	31 c0                	xor    ax,ax
    542c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    542f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5432:	06                   	push   es
    5433:	57                   	push   di
    5434:	9a b9 62 4c 54       	call   0x544c:0x62b9
    5439:	50                   	push   ax
    543a:	9a ba 5d 00 00       	call   0x0:0x5dba
    543f:	5a                   	pop    dx
    5440:	3b c2                	cmp    ax,dx
    5442:	75 25                	jne    0x5469
    5444:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5447:	06                   	push   es
    5448:	57                   	push   di
    5449:	9a b9 62 60 54       	call   0x5460:0x62b9
    544e:	50                   	push   ax
    544f:	9a 66 6b 00 00       	call   0x0:0x6b66
    5454:	09 c0                	or     ax,ax
    5456:	75 11                	jne    0x5469
    5458:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    545b:	06                   	push   es
    545c:	57                   	push   di
    545d:	9a b9 62 77 54       	call   0x5477:0x62b9
    5462:	50                   	push   ax
    5463:	e8 a4 bc             	call   0x110a
    5466:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5469:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    546d:	74 27                	je     0x5496
    546f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5472:	06                   	push   es
    5473:	57                   	push   di
    5474:	9a b9 62 9e 54       	call   0x549e:0x62b9
    5479:	50                   	push   ax
    547a:	6a 00                	push   0x0
    547c:	6a 00                	push   0x0
    547e:	6a 00                	push   0x0
    5480:	6a 00                	push   0x0
    5482:	6a 00                	push   0x0
    5484:	68 97 00             	push   0x97
    5487:	9a 4e 69 00 00       	call   0x0:0x694e
    548c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    548f:	9a 08 5f 00 00       	call   0x0:0x5f08
    5494:	eb 12                	jmp    0x54a8
    5496:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5499:	06                   	push   es
    549a:	57                   	push   di
    549b:	9a b9 62 a5 57       	call   0x57a5:0x62b9
    54a0:	50                   	push   ax
    54a1:	6a 00                	push   0x0
    54a3:	9a 40 6f 00 00       	call   0x0:0x6f40
    54a8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    54ac:	83 c4 06             	add    sp,0x6
    54af:	b8 be 54             	mov    ax,0x54be
    54b2:	0e                   	push   cs
    54b3:	50                   	push   ax
    54b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54b7:	26 80 a5 f5 00 fb    	and    BYTE PTR es:[di+0xf5],0xfb
    54bd:	cb                   	retf
    54be:	c9                   	leave
    54bf:	ca 08 00             	retf   0x8
    54c2:	55                   	push   bp
    54c3:	89 e5                	mov    bp,sp
    54c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54c8:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    54cd:	06                   	push   es
    54ce:	57                   	push   di
    54cf:	9a 94 65 5d 59       	call   0x595d:0x6594
    54d4:	09 c0                	or     ax,ax
    54d6:	75 0c                	jne    0x54e4
    54d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54db:	06                   	push   es
    54dc:	57                   	push   di
    54dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54e0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    54e4:	c9                   	leave
    54e5:	ca 08 00             	retf   0x8
    54e8:	55                   	push   bp
    54e9:	89 e5                	mov    bp,sp
    54eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54ee:	06                   	push   es
    54ef:	57                   	push   di
    54f0:	9a 7f 1f 61 57       	call   0x5761:0x1f7f
    54f5:	c9                   	leave
    54f6:	ca 08 00             	retf   0x8
    54f9:	55                   	push   bp
    54fa:	89 e5                	mov    bp,sp
    54fc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    54ff:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5502:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5505:	06                   	push   es
    5506:	57                   	push   di
    5507:	26 c4 3d             	les    di,DWORD PTR es:[di]
    550a:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    550e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5511:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    5517:	75 39                	jne    0x5552
    5519:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    551d:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    5521:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    5525:	74 2b                	je     0x5552
    5527:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    552b:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    552f:	26 83 bd 0e 01 00    	cmp    WORD PTR es:[di+0x10e],0x0
    5535:	74 1b                	je     0x5552
    5537:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    553b:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    553f:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    5544:	68 30 02             	push   0x230
    5547:	6a 01                	push   0x1
    5549:	6a 00                	push   0x0
    554b:	6a 00                	push   0x0
    554d:	9a ff 57 00 00       	call   0x0:0x57ff
    5552:	c9                   	leave
    5553:	ca 08 00             	retf   0x8
    5556:	c8 02 00 00          	enter  0x2,0x0
    555a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    555d:	26 f6 85 f5 00 08    	test   BYTE PTR es:[di+0xf5],0x8
    5563:	74 0a                	je     0x556f
    5565:	26 c7 85 04 01 02 00 	mov    WORD PTR es:[di+0x104],0x2
    556c:	e9 d5 00             	jmp    0x5644
    556f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5572:	06                   	push   es
    5573:	57                   	push   di
    5574:	9a 48 56 10 56       	call   0x5610:0x5648
    5579:	08 c0                	or     al,al
    557b:	75 03                	jne    0x5580
    557d:	e9 c4 00             	jmp    0x5644
    5580:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5583:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    5589:	75 14                	jne    0x559f
    558b:	26 f6 85 ec 00 02    	test   BYTE PTR es:[di+0xec],0x2
    5591:	74 06                	je     0x5599
    5593:	c6 46 ff 03          	mov    BYTE PTR [bp-0x1],0x3
    5597:	eb 04                	jmp    0x559d
    5599:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    559d:	eb 04                	jmp    0x55a3
    559f:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    55a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55a6:	26 8b 85 36 01       	mov    ax,WORD PTR es:[di+0x136]
    55ab:	09 c0                	or     ax,ax
    55ad:	74 1d                	je     0x55cc
    55af:	ff 76 08             	push   WORD PTR [bp+0x8]
    55b2:	ff 76 06             	push   WORD PTR [bp+0x6]
    55b5:	8d 7e ff             	lea    di,[bp-0x1]
    55b8:	16                   	push   ss
    55b9:	57                   	push   di
    55ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55bd:	26 ff b5 3a 01       	push   WORD PTR es:[di+0x13a]
    55c2:	26 ff b5 38 01       	push   WORD PTR es:[di+0x138]
    55c7:	26 ff 9d 34 01       	call   DWORD PTR es:[di+0x134]
    55cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55cf:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    55d4:	26 0b 85 1c 01       	or     ax,WORD PTR es:[di+0x11c]
    55d9:	74 10                	je     0x55eb
    55db:	6a 01                	push   0x1
    55dd:	26 c4 bd 1a 01       	les    di,DWORD PTR es:[di+0x11a]
    55e2:	06                   	push   es
    55e3:	57                   	push   di
    55e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55e7:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    55eb:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    55ef:	74 53                	je     0x5644
    55f1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    55f5:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    55f9:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    55fd:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    5600:	75 12                	jne    0x5614
    5602:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    5605:	75 0d                	jne    0x5614
    5607:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    560b:	06                   	push   es
    560c:	57                   	push   di
    560d:	9a 43 75 22 56       	call   0x5622:0x7543
    5612:	eb 30                	jmp    0x5644
    5614:	80 7e ff 01          	cmp    BYTE PTR [bp-0x1],0x1
    5618:	75 0c                	jne    0x5626
    561a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    561d:	06                   	push   es
    561e:	57                   	push   di
    561f:	9a b9 5c 36 56       	call   0x5636:0x5cb9
    5624:	eb 1e                	jmp    0x5644
    5626:	80 7e ff 03          	cmp    BYTE PTR [bp-0x1],0x3
    562a:	75 0e                	jne    0x563a
    562c:	6a 01                	push   0x1
    562e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5631:	06                   	push   es
    5632:	57                   	push   di
    5633:	9a 14 3a 42 56       	call   0x5642:0x3a14
    5638:	eb 0a                	jmp    0x5644
    563a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    563d:	06                   	push   es
    563e:	57                   	push   di
    563f:	9a 1d 5f 60 56       	call   0x5660:0x5f1d
    5644:	c9                   	leave
    5645:	ca 04 00             	retf   0x4
    5648:	c8 06 00 00          	enter  0x6,0x0
    564c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    564f:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    5655:	75 44                	jne    0x569b
    5657:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    565b:	06                   	push   es
    565c:	57                   	push   di
    565d:	9a f6 32 80 56       	call   0x5680:0x32f6
    5662:	48                   	dec    ax
    5663:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5666:	31 c0                	xor    ax,ax
    5668:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    566b:	7f 2e                	jg     0x569b
    566d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5670:	eb 03                	jmp    0x5675
    5672:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    5675:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5678:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    567b:	06                   	push   es
    567c:	57                   	push   di
    567d:	9a 5c 33 8b 56       	call   0x568b:0x335c
    5682:	89 c7                	mov    di,ax
    5684:	8e c2                	mov    es,dx
    5686:	06                   	push   es
    5687:	57                   	push   di
    5688:	9a 48 56 d7 56       	call   0x56d7:0x5648
    568d:	08 c0                	or     al,al
    568f:	75 02                	jne    0x5693
    5691:	eb 35                	jmp    0x56c8
    5693:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5696:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    5699:	75 d7                	jne    0x5672
    569b:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    569f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56a2:	26 8b 85 3e 01       	mov    ax,WORD PTR es:[di+0x13e]
    56a7:	09 c0                	or     ax,ax
    56a9:	74 1d                	je     0x56c8
    56ab:	ff 76 08             	push   WORD PTR [bp+0x8]
    56ae:	ff 76 06             	push   WORD PTR [bp+0x6]
    56b1:	8d 7e ff             	lea    di,[bp-0x1]
    56b4:	16                   	push   ss
    56b5:	57                   	push   di
    56b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56b9:	26 ff b5 42 01       	push   WORD PTR es:[di+0x142]
    56be:	26 ff b5 40 01       	push   WORD PTR es:[di+0x140]
    56c3:	26 ff 9d 3c 01       	call   DWORD PTR es:[di+0x13c]
    56c8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    56cb:	c9                   	leave
    56cc:	ca 04 00             	retf   0x4
    56cf:	01 00                	add    WORD PTR [bx+si],ax
    56d1:	00 00                	add    BYTE PTR [bx+si],al
    56d3:	00 00                	add    BYTE PTR [bx+si],al
    56d5:	43                   	inc    bx
    56d6:	57                   	push   di
    56d7:	f7 56 c8             	not    WORD PTR [bp-0x38]
    56da:	02 00                	add    al,BYTE PTR [bx+si]
    56dc:	00 b8 cf 56          	add    BYTE PTR [bx+si+0x56cf],bh
    56e0:	0e                   	push   cs
    56e1:	50                   	push   ax
    56e2:	55                   	push   bp
    56e3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    56e7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    56eb:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    56ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56f2:	06                   	push   es
    56f3:	57                   	push   di
    56f4:	9a 48 56 5c 57       	call   0x575c:0x5648
    56f9:	08 c0                	or     al,al
    56fb:	74 2d                	je     0x572a
    56fd:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    5701:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5704:	26 8b 85 36 01       	mov    ax,WORD PTR es:[di+0x136]
    5709:	09 c0                	or     ax,ax
    570b:	74 1d                	je     0x572a
    570d:	ff 76 08             	push   WORD PTR [bp+0x8]
    5710:	ff 76 06             	push   WORD PTR [bp+0x6]
    5713:	8d 7e ff             	lea    di,[bp-0x1]
    5716:	16                   	push   ss
    5717:	57                   	push   di
    5718:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    571b:	26 ff b5 3a 01       	push   WORD PTR es:[di+0x13a]
    5720:	26 ff b5 38 01       	push   WORD PTR es:[di+0x138]
    5725:	26 ff 9d 34 01       	call   DWORD PTR es:[di+0x134]
    572a:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    572e:	75 0a                	jne    0x573a
    5730:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5733:	31 c0                	xor    ax,ax
    5735:	26 89 85 04 01       	mov    WORD PTR es:[di+0x104],ax
    573a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    573e:	83 c4 06             	add    sp,0x6
    5741:	eb 20                	jmp    0x5763
    5743:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5746:	31 c0                	xor    ax,ax
    5748:	26 89 85 04 01       	mov    WORD PTR es:[di+0x104],ax
    574d:	ff 76 08             	push   WORD PTR [bp+0x8]
    5750:	ff 76 06             	push   WORD PTR [bp+0x6]
    5753:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5757:	06                   	push   es
    5758:	57                   	push   di
    5759:	9a 51 75 72 58       	call   0x5872:0x7551
    575e:	9a 34 14 c5 59       	call   0x59c5:0x1434
    5763:	c9                   	leave
    5764:	ca 04 00             	retf   0x4
    5767:	c8 0c 00 00          	enter  0xc,0x0
    576b:	ff 76 06             	push   WORD PTR [bp+0x6]
    576e:	9a 8a 6d 00 00       	call   0x0:0x6d8a
    5773:	09 c0                	or     ax,ax
    5775:	75 03                	jne    0x577a
    5777:	e9 f0 00             	jmp    0x586a
    577a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    577d:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    5781:	9a ff ff 00 00       	call   0x0:0xffff
    5786:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5789:	ff 76 06             	push   WORD PTR [bp+0x6]
    578c:	8d 7e f8             	lea    di,[bp-0x8]
    578f:	16                   	push   ss
    5790:	57                   	push   di
    5791:	9a ff ff 00 00       	call   0x0:0xffff
    5796:	ff 76 06             	push   WORD PTR [bp+0x6]
    5799:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    579c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    57a0:	06                   	push   es
    57a1:	57                   	push   di
    57a2:	9a b9 62 fc 58       	call   0x58fc:0x62b9
    57a7:	50                   	push   ax
    57a8:	8d 7e f8             	lea    di,[bp-0x8]
    57ab:	16                   	push   ss
    57ac:	57                   	push   di
    57ad:	6a 02                	push   0x2
    57af:	9a ff ff 00 00       	call   0x0:0xffff
    57b4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    57b7:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    57bb:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    57be:	f7 d8                	neg    ax
    57c0:	50                   	push   ax
    57c1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    57c4:	f7 d8                	neg    ax
    57c6:	50                   	push   ax
    57c7:	6a 00                	push   0x0
    57c9:	6a 00                	push   0x0
    57cb:	9a ff ff 00 00       	call   0x0:0xffff
    57d0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    57d3:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    57d7:	6a 00                	push   0x0
    57d9:	6a 00                	push   0x0
    57db:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    57de:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    57e1:	50                   	push   ax
    57e2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    57e5:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    57e8:	50                   	push   ax
    57e9:	9a ff ff 00 00       	call   0x0:0xffff
    57ee:	ff 76 06             	push   WORD PTR [bp+0x6]
    57f1:	6a 14                	push   0x14
    57f3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    57f6:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    57fa:	6a 00                	push   0x0
    57fc:	6a 00                	push   0x0
    57fe:	9a 18 58 00 00       	call   0x0:0x5818
    5803:	ff 76 06             	push   WORD PTR [bp+0x6]
    5806:	6a 0f                	push   0xf
    5808:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    580b:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    580f:	36 ff 75 f2          	push   WORD PTR ss:[di-0xe]
    5813:	36 ff 75 f0          	push   WORD PTR ss:[di-0x10]
    5817:	9a a7 5d 00 00       	call   0x0:0x5da7
    581c:	ff 76 06             	push   WORD PTR [bp+0x6]
    581f:	6a 05                	push   0x5
    5821:	9a 35 58 00 00       	call   0x0:0x5835
    5826:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    5829:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    582d:	74 2c                	je     0x585b
    582f:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5832:	6a 01                	push   0x1
    5834:	9a 52 58 00 00       	call   0x0:0x5852
    5839:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    583c:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    5840:	74 19                	je     0x585b
    5842:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5845:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5848:	57                   	push   di
    5849:	e8 1b ff             	call   0x5767
    584c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    584f:	6a 03                	push   0x3
    5851:	9a 30 68 00 00       	call   0x0:0x6830
    5856:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    5859:	eb e1                	jmp    0x583c
    585b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    585e:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    5862:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5865:	9a ff ff 00 00       	call   0x0:0xffff
    586a:	c9                   	leave
    586b:	c2 04 00             	ret    0x4
    586e:	00 00                	add    BYTE PTR [bx+si],al
    5870:	80 59 7c 58          	sbb    BYTE PTR [bx+di+0x7c],0x58
    5874:	01 00                	add    WORD PTR [bx+si],ax
    5876:	00 00                	add    BYTE PTR [bx+si],al
    5878:	00 00                	add    BYTE PTR [bx+si],al
    587a:	bd 59 82             	mov    bp,0x8259
    587d:	58                   	pop    ax
    587e:	00 00                	add    BYTE PTR [bx+si],al
    5880:	eb 59                	jmp    0x58db
    5882:	88 58 00             	mov    BYTE PTR [bx+si+0x0],bl
    5885:	00 00                	add    BYTE PTR [bx+si],al
    5887:	5a                   	pop    dx
    5888:	19 5a c8             	sbb    WORD PTR [bp+si-0x38],bx
    588b:	18 00                	sbb    BYTE PTR [bx+si],al
    588d:	00 31                	add    BYTE PTR [bx+di],dh
    588f:	c0 89 46 fc 89       	ror    BYTE PTR [bx+di-0x3ba],0x89
    5894:	46                   	inc    si
    5895:	fe                   	(bad)
    5896:	6a 00                	push   0x0
    5898:	9a e8 5f 00 00       	call   0x0:0x5fe8
    589d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    58a0:	31 c0                	xor    ax,ax
    58a2:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    58a5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    58a8:	b8 84 58             	mov    ax,0x5884
    58ab:	0e                   	push   cs
    58ac:	50                   	push   ax
    58ad:	55                   	push   bp
    58ae:	ff 36 58 18          	push   WORD PTR ds:0x1858
    58b2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    58b6:	ff 76 fa             	push   WORD PTR [bp-0x6]
    58b9:	9a ff ff 00 00       	call   0x0:0xffff
    58be:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    58c1:	9a ff ff 00 00       	call   0x0:0xffff
    58c6:	25 00 40             	and    ax,0x4000
    58c9:	81 e2 00 00          	and    dx,0x0
    58cd:	09 d0                	or     ax,dx
    58cf:	74 12                	je     0x58e3
    58d1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    58d4:	31 d2                	xor    dx,dx
    58d6:	0d 00 00             	or     ax,0x0
    58d9:	81 ca fe de          	or     dx,0xdefe
    58dd:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    58e0:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    58e3:	b8 7e 58             	mov    ax,0x587e
    58e6:	0e                   	push   cs
    58e7:	50                   	push   ax
    58e8:	55                   	push   bp
    58e9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    58ed:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    58f1:	ff 76 fa             	push   WORD PTR [bp-0x6]
    58f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58f7:	06                   	push   es
    58f8:	57                   	push   di
    58f9:	9a a9 18 07 59       	call   0x5907:0x18a9
    58fe:	50                   	push   ax
    58ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5902:	06                   	push   es
    5903:	57                   	push   di
    5904:	9a f4 18 6d 59       	call   0x596d:0x18f4
    5909:	50                   	push   ax
    590a:	9a ff ff 00 00       	call   0x0:0xffff
    590f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5912:	b8 74 58             	mov    ax,0x5874
    5915:	0e                   	push   cs
    5916:	50                   	push   ax
    5917:	55                   	push   bp
    5918:	ff 36 58 18          	push   WORD PTR ds:0x1858
    591c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5920:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5923:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5926:	9a 87 59 00 00       	call   0x0:0x5987
    592b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    592e:	b8 6e 58             	mov    ax,0x586e
    5931:	0e                   	push   cs
    5932:	50                   	push   ax
    5933:	55                   	push   bp
    5934:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5938:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    593c:	ff 76 f8             	push   WORD PTR [bp-0x8]
    593f:	8d 7e e8             	lea    di,[bp-0x18]
    5942:	16                   	push   ss
    5943:	57                   	push   di
    5944:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5947:	06                   	push   es
    5948:	57                   	push   di
    5949:	26 c4 3d             	les    di,DWORD PTR es:[di]
    594c:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    5950:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5953:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    5958:	06                   	push   es
    5959:	57                   	push   di
    595a:	9a c0 16 93 59       	call   0x5993:0x16c0
    595f:	50                   	push   ax
    5960:	9a ff ff 00 00       	call   0x0:0xffff
    5965:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5968:	06                   	push   es
    5969:	57                   	push   di
    596a:	9a b9 62 e3 5c       	call   0x5ce3:0x62b9
    596f:	50                   	push   ax
    5970:	55                   	push   bp
    5971:	e8 f3 fd             	call   0x5767
    5974:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5978:	83 c4 06             	add    sp,0x6
    597b:	b8 8c 59             	mov    ax,0x598c
    597e:	0e                   	push   cs
    597f:	50                   	push   ax
    5980:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5983:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5986:	9a ff ff 00 00       	call   0x0:0xffff
    598b:	cb                   	retf
    598c:	b0 01                	mov    al,0x1
    598e:	50                   	push   ax
    598f:	b8 3f 08             	mov    ax,0x83f
    5992:	ba 9a 59             	mov    dx,0x599a
    5995:	52                   	push   dx
    5996:	50                   	push   ax
    5997:	9a bd 56 ad 59       	call   0x59ad:0x56bd
    599c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    599f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    59a2:	ff 76 f4             	push   WORD PTR [bp-0xc]
    59a5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    59a8:	06                   	push   es
    59a9:	57                   	push   di
    59aa:	9a 04 61 8b 5a       	call   0x5a8b:0x6104
    59af:	31 c0                	xor    ax,ax
    59b1:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    59b4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    59b8:	83 c4 06             	add    sp,0x6
    59bb:	eb 22                	jmp    0x59df
    59bd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    59c0:	06                   	push   es
    59c1:	57                   	push   di
    59c2:	9a 7f 1f d8 59       	call   0x59d8:0x1f7f
    59c7:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    59cb:	74 08                	je     0x59d5
    59cd:	ff 76 f4             	push   WORD PTR [bp-0xc]
    59d0:	9a ff ff 00 00       	call   0x0:0xffff
    59d5:	ea 85 13 dd 59       	jmp    0x59dd:0x1385
    59da:	9a 34 14 68 5c       	call   0x5c68:0x1434
    59df:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    59e3:	83 c4 06             	add    sp,0x6
    59e6:	b8 f4 59             	mov    ax,0x59f4
    59e9:	0e                   	push   cs
    59ea:	50                   	push   ax
    59eb:	ff 76 f8             	push   WORD PTR [bp-0x8]
    59ee:	9a ff ff 00 00       	call   0x0:0xffff
    59f3:	cb                   	retf
    59f4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    59f8:	83 c4 06             	add    sp,0x6
    59fb:	b8 0b 5a             	mov    ax,0x5a0b
    59fe:	0e                   	push   cs
    59ff:	50                   	push   ax
    5a00:	6a 00                	push   0x0
    5a02:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5a05:	9a 45 60 00 00       	call   0x0:0x6045
    5a0a:	cb                   	retf
    5a0b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5a0e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5a11:	c9                   	leave
    5a12:	ca 04 00             	retf   0x4
    5a15:	00 00                	add    BYTE PTR [bx+si],al
    5a17:	5c                   	pop    sp
    5a18:	5c                   	pop    sp
    5a19:	1f                   	pop    ds
    5a1a:	5a                   	pop    dx
    5a1b:	00 00                	add    BYTE PTR [bx+si],al
    5a1d:	77 5c                	ja     0x5a7b
    5a1f:	25 5a 00             	and    ax,0x5a
    5a22:	00 92 5c 2b          	add    BYTE PTR [bp+si+0x2b5c],dl
    5a26:	5a                   	pop    dx
    5a27:	00 00                	add    BYTE PTR [bx+si],al
    5a29:	a9 5c 52             	test   ax,0x525c
    5a2c:	5a                   	pop    dx
    5a2d:	c8 30 00 00          	enter  0x30,0x0
    5a31:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5a35:	06                   	push   es
    5a36:	57                   	push   di
    5a37:	9a a8 25 77 5a       	call   0x5a77:0x25a8
    5a3c:	b8 27 5a             	mov    ax,0x5a27
    5a3f:	0e                   	push   cs
    5a40:	50                   	push   ax
    5a41:	55                   	push   bp
    5a42:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5a46:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5a4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a4d:	06                   	push   es
    5a4e:	57                   	push   di
    5a4f:	9a 8a 58 3d 5b       	call   0x5b3d:0x588a
    5a54:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5a57:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5a5a:	b8 21 5a             	mov    ax,0x5a21
    5a5d:	0e                   	push   cs
    5a5e:	50                   	push   ax
    5a5f:	55                   	push   bp
    5a60:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5a64:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5a68:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5a6c:	89 7e d8             	mov    WORD PTR [bp-0x28],di
    5a6f:	8c 46 da             	mov    WORD PTR [bp-0x26],es
    5a72:	06                   	push   es
    5a73:	57                   	push   di
    5a74:	9a 04 2a 8b 5b       	call   0x5b8b:0x2a04
    5a79:	89 c7                	mov    di,ax
    5a7b:	8e c2                	mov    es,dx
    5a7d:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    5a80:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    5a83:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5a86:	06                   	push   es
    5a87:	57                   	push   di
    5a88:	9a 9e 5a a0 5a       	call   0x5aa0:0x5a9e
    5a8d:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    5a90:	ff 76 ec             	push   WORD PTR [bp-0x14]
    5a93:	8d 7e f6             	lea    di,[bp-0xa]
    5a96:	16                   	push   ss
    5a97:	57                   	push   di
    5a98:	8d 7e ee             	lea    di,[bp-0x12]
    5a9b:	16                   	push   ss
    5a9c:	57                   	push   di
    5a9d:	9a e4 37 ab 5a       	call   0x5aab:0x37e4
    5aa2:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    5aa5:	99                   	cwd
    5aa6:	52                   	push   dx
    5aa7:	50                   	push   ax
    5aa8:	9a af 25 ca 5a       	call   0x5aca:0x25af
    5aad:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5ab0:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5ab3:	b8 1b 5a             	mov    ax,0x5a1b
    5ab6:	0e                   	push   cs
    5ab7:	50                   	push   ax
    5ab8:	55                   	push   bp
    5ab9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5abd:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5ac1:	ff 76 f0             	push   WORD PTR [bp-0x10]
    5ac4:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5ac7:	9a af 25 f2 5a       	call   0x5af2:0x25af
    5acc:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5acf:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    5ad2:	b8 15 5a             	mov    ax,0x5a15
    5ad5:	0e                   	push   cs
    5ad6:	50                   	push   ax
    5ad7:	55                   	push   bp
    5ad8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5adc:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5ae0:	ff 76 ec             	push   WORD PTR [bp-0x14]
    5ae3:	6a 00                	push   0x0
    5ae5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5ae8:	06                   	push   es
    5ae9:	57                   	push   di
    5aea:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5aed:	06                   	push   es
    5aee:	57                   	push   di
    5aef:	9a b5 38 2a 5b       	call   0x5b2a:0x38b5
    5af4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5af7:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5afb:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5aff:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5b02:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5b05:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    5b09:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    5b0d:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    5b10:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    5b13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b16:	26 8a 85 f7 00       	mov    al,BYTE PTR es:[di+0xf7]
    5b1b:	3c 01                	cmp    al,0x1
    5b1d:	75 5d                	jne    0x5b7c
    5b1f:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5b22:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    5b25:	06                   	push   es
    5b26:	57                   	push   di
    5b27:	9a d2 21 57 5b       	call   0x5b57:0x21d2
    5b2c:	50                   	push   ax
    5b2d:	6a 58                	push   0x58
    5b2f:	9a 5d 5b 00 00       	call   0x0:0x5b5d
    5b34:	50                   	push   ax
    5b35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b38:	06                   	push   es
    5b39:	57                   	push   di
    5b3a:	9a 11 38 6a 5b       	call   0x5b6a:0x3811
    5b3f:	50                   	push   ax
    5b40:	9a 6e 5b 00 00       	call   0x0:0x5b6e
    5b45:	99                   	cwd
    5b46:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5b49:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    5b4c:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    5b4f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    5b52:	06                   	push   es
    5b53:	57                   	push   di
    5b54:	9a d2 21 22 5c       	call   0x5c22:0x21d2
    5b59:	50                   	push   ax
    5b5a:	6a 5a                	push   0x5a
    5b5c:	9a 34 60 00 00       	call   0x0:0x6034
    5b61:	50                   	push   ax
    5b62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b65:	06                   	push   es
    5b66:	57                   	push   di
    5b67:	9a 11 38 c6 5c       	call   0x5cc6:0x3811
    5b6c:	50                   	push   ax
    5b6d:	9a 92 5b 00 00       	call   0x0:0x5b92
    5b72:	99                   	cwd
    5b73:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5b76:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    5b79:	e9 93 00             	jmp    0x5c0f
    5b7c:	3c 02                	cmp    al,0x2
    5b7e:	75 77                	jne    0x5bf7
    5b80:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5b83:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5b86:	06                   	push   es
    5b87:	57                   	push   di
    5b88:	9a 72 2a a5 5b       	call   0x5ba5:0x2a72
    5b8d:	50                   	push   ax
    5b8e:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    5b91:	9a ea 5b 00 00       	call   0x0:0x5bea
    5b96:	99                   	cwd
    5b97:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5b9a:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    5b9d:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5ba0:	06                   	push   es
    5ba1:	57                   	push   di
    5ba2:	9a 9a 2a bc 5b       	call   0x5bbc:0x2a9a
    5ba7:	99                   	cwd
    5ba8:	3b 56 e2             	cmp    dx,WORD PTR [bp-0x1e]
    5bab:	7f 07                	jg     0x5bb4
    5bad:	7c 18                	jl     0x5bc7
    5baf:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    5bb2:	76 13                	jbe    0x5bc7
    5bb4:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5bb7:	06                   	push   es
    5bb8:	57                   	push   di
    5bb9:	9a 72 2a cf 5b       	call   0x5bcf:0x2a72
    5bbe:	99                   	cwd
    5bbf:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5bc2:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    5bc5:	eb 2e                	jmp    0x5bf5
    5bc7:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5bca:	06                   	push   es
    5bcb:	57                   	push   di
    5bcc:	9a 9a 2a e3 5b       	call   0x5be3:0x2a9a
    5bd1:	99                   	cwd
    5bd2:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5bd5:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    5bd8:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    5bdb:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5bde:	06                   	push   es
    5bdf:	57                   	push   di
    5be0:	9a 9a 2a 17 5c       	call   0x5c17:0x2a9a
    5be5:	50                   	push   ax
    5be6:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5be9:	9a ff ff 00 00       	call   0x0:0xffff
    5bee:	99                   	cwd
    5bef:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5bf2:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    5bf5:	eb 18                	jmp    0x5c0f
    5bf7:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    5bfa:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    5bfd:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5c00:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    5c03:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    5c06:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    5c09:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5c0c:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    5c0f:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    5c12:	06                   	push   es
    5c13:	57                   	push   di
    5c14:	9a 04 2a b2 5c       	call   0x5cb2:0x2a04
    5c19:	89 c7                	mov    di,ax
    5c1b:	8e c2                	mov    es,dx
    5c1d:	06                   	push   es
    5c1e:	57                   	push   di
    5c1f:	9a d2 21 0c 66       	call   0x660c:0x21d2
    5c24:	50                   	push   ax
    5c25:	6a 00                	push   0x0
    5c27:	6a 00                	push   0x0
    5c29:	ff 76 e0             	push   WORD PTR [bp-0x20]
    5c2c:	ff 76 dc             	push   WORD PTR [bp-0x24]
    5c2f:	6a 00                	push   0x0
    5c31:	6a 00                	push   0x0
    5c33:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5c36:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    5c39:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5c3c:	ff 76 f2             	push   WORD PTR [bp-0xe]
    5c3f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5c42:	06                   	push   es
    5c43:	57                   	push   di
    5c44:	6a 00                	push   0x0
    5c46:	68 cc 00             	push   0xcc
    5c49:	6a 20                	push   0x20
    5c4b:	9a ff ff 00 00       	call   0x0:0xffff
    5c50:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5c54:	83 c4 06             	add    sp,0x6
    5c57:	b8 6b 5c             	mov    ax,0x5c6b
    5c5a:	0e                   	push   cs
    5c5b:	50                   	push   ax
    5c5c:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5c5f:	ff 76 f2             	push   WORD PTR [bp-0xe]
    5c62:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5c65:	9a 9c 01 83 5c       	call   0x5c83:0x19c
    5c6a:	cb                   	retf
    5c6b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5c6f:	83 c4 06             	add    sp,0x6
    5c72:	b8 86 5c             	mov    ax,0x5c86
    5c75:	0e                   	push   cs
    5c76:	50                   	push   ax
    5c77:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5c7a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5c7d:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5c80:	9a 9c 01 9a 5c       	call   0x5c9a:0x19c
    5c85:	cb                   	retf
    5c86:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5c8a:	83 c4 06             	add    sp,0x6
    5c8d:	b8 9d 5c             	mov    ax,0x5c9d
    5c90:	0e                   	push   cs
    5c91:	50                   	push   ax
    5c92:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5c95:	06                   	push   es
    5c96:	57                   	push   di
    5c97:	9a 7f 1f 29 5d       	call   0x5d29:0x1f7f
    5c9c:	cb                   	retf
    5c9d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ca1:	83 c4 06             	add    sp,0x6
    5ca4:	b8 b5 5c             	mov    ax,0x5cb5
    5ca7:	0e                   	push   cs
    5ca8:	50                   	push   ax
    5ca9:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5cad:	06                   	push   es
    5cae:	57                   	push   di
    5caf:	9a 55 26 ff ff       	call   0xffff:0x2655
    5cb4:	cb                   	retf
    5cb5:	c9                   	leave
    5cb6:	ca 04 00             	retf   0x4
    5cb9:	55                   	push   bp
    5cba:	89 e5                	mov    bp,sp
    5cbc:	6a 00                	push   0x0
    5cbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cc1:	06                   	push   es
    5cc2:	57                   	push   di
    5cc3:	9a 19 2f d9 5c       	call   0x5cd9:0x2f19
    5cc8:	c9                   	leave
    5cc9:	ca 04 00             	retf   0x4
    5ccc:	55                   	push   bp
    5ccd:	89 e5                	mov    bp,sp
    5ccf:	6a 01                	push   0x1
    5cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cd4:	06                   	push   es
    5cd5:	57                   	push   di
    5cd6:	9a 19 2f 33 5d       	call   0x5d33:0x2f19
    5cdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cde:	06                   	push   es
    5cdf:	57                   	push   di
    5ce0:	9a 1c 20 1b 5d       	call   0x5d1b:0x201c
    5ce5:	c9                   	leave
    5ce6:	ca 04 00             	retf   0x4
    5ce9:	c8 00 01 00          	enter  0x100,0x0
    5ced:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cf0:	26 80 bd f1 00 00    	cmp    BYTE PTR es:[di+0xf1],0x0
    5cf6:	75 3d                	jne    0x5d35
    5cf8:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5cfd:	74 07                	je     0x5d06
    5cff:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    5d04:	75 25                	jne    0x5d2b
    5d06:	8d be 00 ff          	lea    di,[bp-0x100]
    5d0a:	16                   	push   ss
    5d0b:	57                   	push   di
    5d0c:	68 29 f0             	push   0xf029
    5d0f:	9a 2b 09 22 5d       	call   0x5d22:0x92b
    5d14:	b0 01                	mov    al,0x1
    5d16:	50                   	push   ax
    5d17:	b8 52 00             	mov    ax,0x52
    5d1a:	ba 7f 5d             	mov    dx,0x5d7f
    5d1d:	52                   	push   dx
    5d1e:	50                   	push   ax
    5d1f:	9a e6 28 76 5d       	call   0x5d76:0x28e6
    5d24:	52                   	push   dx
    5d25:	50                   	push   ax
    5d26:	9a 99 13 8d 5d       	call   0x5d8d:0x1399
    5d2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d2e:	06                   	push   es
    5d2f:	57                   	push   di
    5d30:	9a 33 44 3d 5d       	call   0x5d3d:0x4433
    5d35:	c9                   	leave
    5d36:	ca 04 00             	retf   0x4
    5d39:	00 00                	add    BYTE PTR [bx+si],al
    5d3b:	c4 5e 43             	les    bx,DWORD PTR [bp+0x43]
    5d3e:	5d                   	pop    bp
    5d3f:	00 00                	add    BYTE PTR [bx+si],al
    5d41:	db 5e f0             	fistp  DWORD PTR [bp-0x10]
    5d44:	5d                   	pop    bp
    5d45:	c8 0e 01 00          	enter  0x10e,0x0
    5d49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d4c:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5d51:	75 17                	jne    0x5d6a
    5d53:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    5d58:	74 10                	je     0x5d6a
    5d5a:	26 f6 85 f5 00 08    	test   BYTE PTR es:[di+0xf5],0x8
    5d60:	75 08                	jne    0x5d6a
    5d62:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    5d68:	75 25                	jne    0x5d8f
    5d6a:	8d be f2 fe          	lea    di,[bp-0x10e]
    5d6e:	16                   	push   ss
    5d6f:	57                   	push   di
    5d70:	68 2d f0             	push   0xf02d
    5d73:	9a 2b 09 86 5d       	call   0x5d86:0x92b
    5d78:	b0 01                	mov    al,0x1
    5d7a:	50                   	push   ax
    5d7b:	b8 52 00             	mov    ax,0x52
    5d7e:	ba 26 5e             	mov    dx,0x5e26
    5d81:	52                   	push   dx
    5d82:	50                   	push   ax
    5d83:	9a e6 28 5f 5f       	call   0x5f5f:0x28e6
    5d88:	52                   	push   dx
    5d89:	50                   	push   ax
    5d8a:	9a 99 13 90 5f       	call   0x5f90:0x1399
    5d8f:	9a 99 5d 00 00       	call   0x0:0x5d99
    5d94:	09 c0                	or     ax,ax
    5d96:	74 13                	je     0x5dab
    5d98:	9a 8b 71 00 00       	call   0x0:0x718b
    5d9d:	50                   	push   ax
    5d9e:	6a 1f                	push   0x1f
    5da0:	6a 00                	push   0x0
    5da2:	6a 00                	push   0x0
    5da4:	6a 00                	push   0x0
    5da6:	9a 33 5e 00 00       	call   0x0:0x5e33
    5dab:	9a ff ff 00 00       	call   0x0:0xffff
    5db0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5db3:	26 80 8d f5 00 08    	or     BYTE PTR es:[di+0xf5],0x8
    5db9:	9a aa 5e 00 00       	call   0x0:0x5eaa
    5dbe:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5dc1:	a1 34 15             	mov    ax,ds:0x1534
    5dc4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5dc7:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    5dcb:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    5dcf:	26 8b 55 3e          	mov    dx,WORD PTR es:[di+0x3e]
    5dd3:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5dd6:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5dd9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5ddc:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5ddf:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    5de3:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    5de7:	26 89 55 3e          	mov    WORD PTR es:[di+0x3e],dx
    5deb:	6a 00                	push   0x0
    5ded:	9a e7 0e 0e 5e       	call   0x5e0e:0xee7
    5df2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5df5:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    5df8:	b8 3f 5d             	mov    ax,0x5d3f
    5dfb:	0e                   	push   cs
    5dfc:	50                   	push   ax
    5dfd:	55                   	push   bp
    5dfe:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5e02:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5e06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e09:	06                   	push   es
    5e0a:	57                   	push   di
    5e0b:	9a cc 5c 4a 5e       	call   0x5e4a:0x5ccc
    5e10:	b8 39 5d             	mov    ax,0x5d39
    5e13:	0e                   	push   cs
    5e14:	50                   	push   ax
    5e15:	55                   	push   bp
    5e16:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5e1a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5e1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e21:	06                   	push   es
    5e22:	57                   	push   di
    5e23:	9a b9 62 8d 5e       	call   0x5e8d:0x62b9
    5e28:	50                   	push   ax
    5e29:	68 00 0f             	push   0xf00
    5e2c:	6a 00                	push   0x0
    5e2e:	6a 00                	push   0x0
    5e30:	6a 00                	push   0x0
    5e32:	9a 9a 5e 00 00       	call   0x0:0x5e9a
    5e37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e3a:	31 c0                	xor    ax,ax
    5e3c:	26 89 85 04 01       	mov    WORD PTR es:[di+0x104],ax
    5e41:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5e45:	06                   	push   es
    5e46:	57                   	push   di
    5e47:	9a 1a 73 73 5e       	call   0x5e73:0x731a
    5e4c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5e50:	26 80 7d 59 00       	cmp    BYTE PTR es:[di+0x59],0x0
    5e55:	74 0c                	je     0x5e63
    5e57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e5a:	26 c7 85 04 01 02 00 	mov    WORD PTR es:[di+0x104],0x2
    5e61:	eb 12                	jmp    0x5e75
    5e63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e66:	26 83 bd 04 01 00    	cmp    WORD PTR es:[di+0x104],0x0
    5e6c:	74 07                	je     0x5e75
    5e6e:	06                   	push   es
    5e6f:	57                   	push   di
    5e70:	9a d9 56 cc 5e       	call   0x5ecc:0x56d9
    5e75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e78:	26 83 bd 04 01 00    	cmp    WORD PTR es:[di+0x104],0x0
    5e7e:	74 c1                	je     0x5e41
    5e80:	26 8b 85 04 01       	mov    ax,WORD PTR es:[di+0x104]
    5e85:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5e88:	06                   	push   es
    5e89:	57                   	push   di
    5e8a:	9a b9 62 a6 5e       	call   0x5ea6:0x62b9
    5e8f:	50                   	push   ax
    5e90:	68 01 0f             	push   0xf01
    5e93:	6a 00                	push   0x0
    5e95:	6a 00                	push   0x0
    5e97:	6a 00                	push   0x0
    5e99:	9a f3 63 00 00       	call   0x0:0x63f3
    5e9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ea1:	06                   	push   es
    5ea2:	57                   	push   di
    5ea3:	9a b9 62 28 5f       	call   0x5f28:0x62b9
    5ea8:	50                   	push   ax
    5ea9:	9a fe 75 00 00       	call   0x0:0x75fe
    5eae:	5a                   	pop    dx
    5eaf:	3b c2                	cmp    ax,dx
    5eb1:	74 05                	je     0x5eb8
    5eb3:	31 c0                	xor    ax,ax
    5eb5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5eb8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ebc:	83 c4 06             	add    sp,0x6
    5ebf:	b8 cf 5e             	mov    ax,0x5ecf
    5ec2:	0e                   	push   cs
    5ec3:	50                   	push   ax
    5ec4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ec7:	06                   	push   es
    5ec8:	57                   	push   di
    5ec9:	9a b9 5c e4 5e       	call   0x5ee4:0x5cb9
    5ece:	cb                   	retf
    5ecf:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ed3:	83 c4 06             	add    sp,0x6
    5ed6:	b8 16 5f             	mov    ax,0x5f16
    5ed9:	0e                   	push   cs
    5eda:	50                   	push   ax
    5edb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5ede:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5ee1:	9a f0 0f ad 5f       	call   0x5fad:0xff0
    5ee6:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    5ee9:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    5eec:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    5ef0:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    5ef4:	26 89 55 3e          	mov    WORD PTR es:[di+0x3e],dx
    5ef8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5efb:	a3 34 15             	mov    ds:0x1534,ax
    5efe:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
    5f02:	74 08                	je     0x5f0c
    5f04:	ff 76 f2             	push   WORD PTR [bp-0xe]
    5f07:	9a 32 6f 00 00       	call   0x0:0x6f32
    5f0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f0f:	26 80 a5 f5 00 f7    	and    BYTE PTR es:[di+0xf5],0xf7
    5f15:	cb                   	retf
    5f16:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5f19:	c9                   	leave
    5f1a:	ca 04 00             	retf   0x4
    5f1d:	55                   	push   bp
    5f1e:	89 e5                	mov    bp,sp
    5f20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f23:	06                   	push   es
    5f24:	57                   	push   di
    5f25:	9a b9 62 f7 61       	call   0x61f7:0x62b9
    5f2a:	50                   	push   ax
    5f2b:	68 21 0f             	push   0xf21
    5f2e:	6a 00                	push   0x0
    5f30:	6a 00                	push   0x0
    5f32:	6a 00                	push   0x0
    5f34:	9a e5 6b 00 00       	call   0x0:0x6be5
    5f39:	c9                   	leave
    5f3a:	ca 04 00             	retf   0x4
    5f3d:	8c d0                	mov    ax,ss
    5f3f:	90                   	nop
    5f40:	45                   	inc    bp
    5f41:	55                   	push   bp
    5f42:	89 e5                	mov    bp,sp
    5f44:	1e                   	push   ds
    5f45:	8e d8                	mov    ds,ax
    5f47:	81 ec 02 01          	sub    sp,0x102
    5f4b:	56                   	push   si
    5f4c:	57                   	push   di
    5f4d:	8d be fc fe          	lea    di,[bp-0x104]
    5f51:	16                   	push   ss
    5f52:	57                   	push   di
    5f53:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5f56:	81 c7 12 00          	add    di,0x12
    5f5a:	06                   	push   es
    5f5b:	57                   	push   di
    5f5c:	9a 6e 0e 95 64       	call   0x6495:0xe6e
    5f61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f64:	06                   	push   es
    5f65:	57                   	push   di
    5f66:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f69:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f6d:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    5f72:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5f75:	5f                   	pop    di
    5f76:	5e                   	pop    si
    5f77:	8d 66 fe             	lea    sp,[bp-0x2]
    5f7a:	1f                   	pop    ds
    5f7b:	5d                   	pop    bp
    5f7c:	4d                   	dec    bp
    5f7d:	ca 0e 00             	retf   0xe
    5f80:	c8 06 00 00          	enter  0x6,0x0
    5f84:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5f88:	74 08                	je     0x5f92
    5f8a:	83 ec 08             	sub    sp,0x8
    5f8d:	9a e2 1f d8 5f       	call   0x5fd8:0x1fe2
    5f92:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5f95:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5f98:	31 c0                	xor    ax,ax
    5f9a:	50                   	push   ax
    5f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f9e:	06                   	push   es
    5f9f:	57                   	push   di
    5fa0:	9a d9 4b b6 5f       	call   0x5fb6:0x4bd9
    5fa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fa8:	06                   	push   es
    5fa9:	57                   	push   di
    5faa:	9a fd 61 f3 5f       	call   0x5ff3:0x61fd
    5faf:	b0 01                	mov    al,0x1
    5fb1:	50                   	push   ax
    5fb2:	b8 c9 03             	mov    ax,0x3c9
    5fb5:	ba bd 5f             	mov    dx,0x5fbd
    5fb8:	52                   	push   dx
    5fb9:	50                   	push   ax
    5fba:	9a 08 1d d1 5f       	call   0x5fd1:0x1d08
    5fbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc2:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    5fc6:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    5fca:	b0 01                	mov    al,0x1
    5fcc:	50                   	push   ax
    5fcd:	b8 a3 02             	mov    ax,0x2a3
    5fd0:	ba 94 60             	mov    dx,0x6094
    5fd3:	52                   	push   dx
    5fd4:	50                   	push   ax
    5fd5:	9a 50 1f 6f 60       	call   0x606f:0x1f50
    5fda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fdd:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    5fe1:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    5fe5:	6a 00                	push   0x0
    5fe7:	9a ff ff 00 00       	call   0x0:0xffff
    5fec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5fef:	bf 3d 5f             	mov    di,0x5f3d
    5ff2:	b8 87 60             	mov    ax,0x6087
    5ff5:	50                   	push   ax
    5ff6:	57                   	push   di
    5ff7:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    5ffb:	9a ff ff 00 00       	call   0x0:0xffff
    6000:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6003:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    6006:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6009:	6a 00                	push   0x0
    600b:	6a 00                	push   0x0
    600d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6010:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6016:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    601a:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    601e:	9a ff ff 00 00       	call   0x0:0xffff
    6023:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6026:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6029:	9a ff ff 00 00       	call   0x0:0xffff
    602e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6031:	6a 5a                	push   0x5a
    6033:	9a ff ff 00 00       	call   0x0:0xffff
    6038:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    603b:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    603f:	6a 00                	push   0x0
    6041:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6044:	9a ff ff 00 00       	call   0x0:0xffff
    6049:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    604d:	74 07                	je     0x6056
    604f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6053:	83 c4 06             	add    sp,0x6
    6056:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6059:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    605c:	c9                   	leave
    605d:	ca 0a 00             	retf   0xa
    6060:	55                   	push   bp
    6061:	89 e5                	mov    bp,sp
    6063:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6066:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    606a:	06                   	push   es
    606b:	57                   	push   di
    606c:	9a 7f 1f 7d 60       	call   0x607d:0x1f7f
    6071:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6074:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6078:	06                   	push   es
    6079:	57                   	push   di
    607a:	9a 7f 1f 9f 60       	call   0x609f:0x1f7f
    607f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6082:	06                   	push   es
    6083:	57                   	push   di
    6084:	9a 5f 62 53 62       	call   0x6253:0x625f
    6089:	31 c0                	xor    ax,ax
    608b:	50                   	push   ax
    608c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    608f:	06                   	push   es
    6090:	57                   	push   di
    6091:	9a 2b 4c e2 60       	call   0x60e2:0x4c2b
    6096:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    609a:	74 05                	je     0x60a1
    609c:	9a 0f 20 b7 62       	call   0x62b7:0x200f
    60a1:	c9                   	leave
    60a2:	ca 06 00             	retf   0x6
    60a5:	c8 02 00 00          	enter  0x2,0x0
    60a9:	6a 01                	push   0x1
    60ab:	9a c1 60 00 00       	call   0x0:0x60c1
    60b0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    60b3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    60b6:	c9                   	leave
    60b7:	ca 04 00             	retf   0x4
    60ba:	c8 02 00 00          	enter  0x2,0x0
    60be:	6a 00                	push   0x0
    60c0:	9a 78 65 00 00       	call   0x0:0x6578
    60c5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    60c8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    60cb:	c9                   	leave
    60cc:	ca 04 00             	retf   0x4
    60cf:	c8 04 00 00          	enter  0x4,0x0
    60d3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    60d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60d9:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    60dd:	06                   	push   es
    60de:	57                   	push   di
    60df:	9a d0 0d b1 61       	call   0x61b1:0xdd0
    60e4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    60e7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    60ea:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    60ed:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    60f0:	c9                   	leave
    60f1:	ca 06 00             	retf   0x6
    60f4:	c8 02 00 00          	enter  0x2,0x0
    60f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60fb:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    60ff:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6103:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6106:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6109:	c9                   	leave
    610a:	ca 04 00             	retf   0x4
    610d:	55                   	push   bp
    610e:	89 e5                	mov    bp,sp
    6110:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6113:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    6117:	26 8b 55 3a          	mov    dx,WORD PTR es:[di+0x3a]
    611b:	26 3b 55 32          	cmp    dx,WORD PTR es:[di+0x32]
    611f:	75 06                	jne    0x6127
    6121:	26 3b 45 30          	cmp    ax,WORD PTR es:[di+0x30]
    6125:	74 2d                	je     0x6154
    6127:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    612a:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    612e:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    6132:	26 89 45 38          	mov    WORD PTR es:[di+0x38],ax
    6136:	26 89 55 3a          	mov    WORD PTR es:[di+0x3a],dx
    613a:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    613e:	09 c0                	or     ax,ax
    6140:	74 12                	je     0x6154
    6142:	ff 76 08             	push   WORD PTR [bp+0x8]
    6145:	ff 76 06             	push   WORD PTR [bp+0x6]
    6148:	26 ff 75 4e          	push   WORD PTR es:[di+0x4e]
    614c:	26 ff 75 4c          	push   WORD PTR es:[di+0x4c]
    6150:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    6154:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6157:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    615b:	26 8b 55 36          	mov    dx,WORD PTR es:[di+0x36]
    615f:	26 3b 55 2e          	cmp    dx,WORD PTR es:[di+0x2e]
    6163:	75 06                	jne    0x616b
    6165:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    6169:	74 2d                	je     0x6198
    616b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616e:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    6172:	26 8b 55 2e          	mov    dx,WORD PTR es:[di+0x2e]
    6176:	26 89 45 34          	mov    WORD PTR es:[di+0x34],ax
    617a:	26 89 55 36          	mov    WORD PTR es:[di+0x36],dx
    617e:	26 8b 45 42          	mov    ax,WORD PTR es:[di+0x42]
    6182:	09 c0                	or     ax,ax
    6184:	74 12                	je     0x6198
    6186:	ff 76 08             	push   WORD PTR [bp+0x8]
    6189:	ff 76 06             	push   WORD PTR [bp+0x6]
    618c:	26 ff 75 46          	push   WORD PTR es:[di+0x46]
    6190:	26 ff 75 44          	push   WORD PTR es:[di+0x44]
    6194:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6198:	c9                   	leave
    6199:	ca 04 00             	retf   0x4
    619c:	55                   	push   bp
    619d:	89 e5                	mov    bp,sp
    619f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    61a2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    61a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61a8:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    61ac:	06                   	push   es
    61ad:	57                   	push   di
    61ae:	9a 2b 0c cc 61       	call   0x61cc:0xc2b
    61b3:	c9                   	leave
    61b4:	ca 08 00             	retf   0x8
    61b7:	55                   	push   bp
    61b8:	89 e5                	mov    bp,sp
    61ba:	ff 76 0c             	push   WORD PTR [bp+0xc]
    61bd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    61c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61c3:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    61c7:	06                   	push   es
    61c8:	57                   	push   di
    61c9:	9a a7 0f 27 66       	call   0x6627:0xfa7
    61ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61d1:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    61d5:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    61da:	75 1d                	jne    0x61f9
    61dc:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    61e0:	26 8b 45 43          	mov    ax,WORD PTR es:[di+0x43]
    61e4:	26 0b 45 45          	or     ax,WORD PTR es:[di+0x45]
    61e8:	74 0f                	je     0x61f9
    61ea:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    61ee:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    61f2:	06                   	push   es
    61f3:	57                   	push   di
    61f4:	9a 1f 6b 52 65       	call   0x6552:0x6b1f
    61f9:	c9                   	leave
    61fa:	ca 08 00             	retf   0x8
    61fd:	c8 04 00 00          	enter  0x4,0x0
    6201:	6a 00                	push   0x0
    6203:	6a 00                	push   0x0
    6205:	68 00 7f             	push   0x7f00
    6208:	9a 46 62 00 00       	call   0x0:0x6246
    620d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6210:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    6214:	c7 46 fe ef ff       	mov    WORD PTR [bp-0x2],0xffef
    6219:	eb 03                	jmp    0x621e
    621b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    621e:	83 7e fe f4          	cmp    WORD PTR [bp-0x2],0xfff4
    6222:	7f 08                	jg     0x622c
    6224:	a1 8c 18             	mov    ax,ds:0x188c
    6227:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    622a:	eb 05                	jmp    0x6231
    622c:	31 c0                	xor    ax,ax
    622e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6231:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6234:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6237:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    623a:	c1 e7 02             	shl    di,0x2
    623d:	ff b5 a4 16          	push   WORD PTR [di+0x16a4]
    6241:	ff b5 a2 16          	push   WORD PTR [di+0x16a2]
    6245:	9a cf 62 00 00       	call   0x0:0x62cf
    624a:	50                   	push   ax
    624b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    624e:	06                   	push   es
    624f:	57                   	push   di
    6250:	9a ef 62 21 64       	call   0x6421:0x62ef
    6255:	83 7e fe fe          	cmp    WORD PTR [bp-0x2],0xfffe
    6259:	75 c0                	jne    0x621b
    625b:	c9                   	leave
    625c:	ca 04 00             	retf   0x4
    625f:	c8 0a 00 00          	enter  0xa,0x0
    6263:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6266:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    626a:	26 8b 55 28          	mov    dx,WORD PTR es:[di+0x28]
    626e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6271:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6274:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6277:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    627a:	74 4b                	je     0x62c7
    627c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    627f:	26 83 7d 04 f4       	cmp    WORD PTR es:[di+0x4],0xfff4
    6284:	7e 0a                	jle    0x6290
    6286:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6289:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    628e:	7e 0c                	jle    0x629c
    6290:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6293:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6297:	9a e7 62 00 00       	call   0x0:0x62e7
    629c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    629f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    62a2:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    62a6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    62a9:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    62ac:	ff 76 fe             	push   WORD PTR [bp-0x2]
    62af:	ff 76 fc             	push   WORD PTR [bp-0x4]
    62b2:	6a 08                	push   0x8
    62b4:	9a 9c 01 f8 62       	call   0x62f8:0x19c
    62b9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    62bc:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    62bf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    62c2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    62c5:	eb ad                	jmp    0x6274
    62c7:	6a 00                	push   0x0
    62c9:	6a 00                	push   0x0
    62cb:	68 00 7f             	push   0x7f00
    62ce:	9a ff ff 00 00       	call   0x0:0xffff
    62d3:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    62d6:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    62d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62dc:	26 3b 45 2a          	cmp    ax,WORD PTR es:[di+0x2a]
    62e0:	74 09                	je     0x62eb
    62e2:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    62e6:	9a ff ff 00 00       	call   0x0:0xffff
    62eb:	c9                   	leave
    62ec:	ca 04 00             	retf   0x4
    62ef:	c8 04 00 00          	enter  0x4,0x0
    62f3:	6a 08                	push   0x8
    62f5:	9a 82 01 65 64       	call   0x6465:0x182
    62fa:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    62fd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6300:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6303:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    6307:	26 8b 55 28          	mov    dx,WORD PTR es:[di+0x28]
    630b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    630e:	26 89 05             	mov    WORD PTR es:[di],ax
    6311:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    6315:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    6318:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    631b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    631f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6322:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6325:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    6329:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    632c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    632f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6332:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    6336:	26 89 55 28          	mov    WORD PTR es:[di+0x28],dx
    633a:	c9                   	leave
    633b:	ca 08 00             	retf   0x8
    633e:	c8 06 00 00          	enter  0x6,0x0
    6342:	31 c0                	xor    ax,ax
    6344:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6347:	83 7e 0a ff          	cmp    WORD PTR [bp+0xa],0xffff
    634b:	74 55                	je     0x63a2
    634d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6350:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    6354:	26 8b 55 28          	mov    dx,WORD PTR es:[di+0x28]
    6358:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    635b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    635e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    6361:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    6364:	74 1e                	je     0x6384
    6366:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6369:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    636d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    6370:	74 12                	je     0x6384
    6372:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6375:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6378:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    637c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    637f:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    6382:	eb da                	jmp    0x635e
    6384:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    6387:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    638a:	75 0c                	jne    0x6398
    638c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    638f:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    6393:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6396:	eb 0a                	jmp    0x63a2
    6398:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    639b:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    639f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    63a2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    63a5:	c9                   	leave
    63a6:	ca 06 00             	retf   0x6
    63a9:	c8 0a 00 00          	enter  0xa,0x0
    63ad:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    63b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63b3:	26 3b 45 20          	cmp    ax,WORD PTR es:[di+0x20]
    63b7:	74 70                	je     0x6429
    63b9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    63bc:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    63c0:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    63c4:	75 50                	jne    0x6416
    63c6:	8d 7e fc             	lea    di,[bp-0x4]
    63c9:	16                   	push   ss
    63ca:	57                   	push   di
    63cb:	9a 0f 78 00 00       	call   0x0:0x780f
    63d0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    63d3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    63d6:	9a ff ff 00 00       	call   0x0:0xffff
    63db:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    63de:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    63e2:	74 32                	je     0x6416
    63e4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    63e7:	68 84 00             	push   0x84
    63ea:	6a 00                	push   0x0
    63ec:	ff 76 fe             	push   WORD PTR [bp-0x2]
    63ef:	ff 76 fc             	push   WORD PTR [bp-0x4]
    63f2:	9a 10 64 00 00       	call   0x0:0x6410
    63f7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    63fa:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    63fd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6400:	6a 20                	push   0x20
    6402:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6405:	ff 76 f6             	push   WORD PTR [bp-0xa]
    6408:	68 00 02             	push   0x200
    640b:	5a                   	pop    dx
    640c:	58                   	pop    ax
    640d:	52                   	push   dx
    640e:	50                   	push   ax
    640f:	9a e3 71 00 00       	call   0x0:0x71e3
    6414:	eb 13                	jmp    0x6429
    6416:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6419:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    641c:	06                   	push   es
    641d:	57                   	push   di
    641e:	9a 3e 63 4b 64       	call   0x644b:0x633e
    6423:	50                   	push   ax
    6424:	9a ff ff 00 00       	call   0x0:0xffff
    6429:	c9                   	leave
    642a:	ca 06 00             	retf   0x6
    642d:	8c d0                	mov    ax,ss
    642f:	90                   	nop
    6430:	45                   	inc    bp
    6431:	55                   	push   bp
    6432:	89 e5                	mov    bp,sp
    6434:	1e                   	push   ds
    6435:	8e d8                	mov    ds,ax
    6437:	56                   	push   si
    6438:	57                   	push   di
    6439:	a1 2a 2c             	mov    ax,ds:0x2c2a
    643c:	0b 06 2c 2c          	or     ax,WORD PTR ds:0x2c2c
    6440:	74 0b                	je     0x644d
    6442:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6446:	06                   	push   es
    6447:	57                   	push   di
    6448:	9a f5 77 fb 64       	call   0x64fb:0x77f5
    644d:	5f                   	pop    di
    644e:	5e                   	pop    si
    644f:	1f                   	pop    ds
    6450:	5d                   	pop    bp
    6451:	4d                   	dec    bp
    6452:	ca 0a 00             	retf   0xa
    6455:	c8 1e 02 00          	enter  0x21e,0x0
    6459:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    645d:	74 08                	je     0x6467
    645f:	83 ec 08             	sub    sp,0x8
    6462:	9a e2 1f 60 65       	call   0x6560:0x1fe2
    6467:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    646b:	8d be e2 fe          	lea    di,[bp-0x11e]
    646f:	16                   	push   ss
    6470:	57                   	push   di
    6471:	68 00 01             	push   0x100
    6474:	9a ff ff 00 00       	call   0x0:0xffff
    6479:	8d be e2 fe          	lea    di,[bp-0x11e]
    647d:	16                   	push   ss
    647e:	57                   	push   di
    647f:	8d be e2 fe          	lea    di,[bp-0x11e]
    6483:	16                   	push   ss
    6484:	57                   	push   di
    6485:	9a ff ff 00 00       	call   0x0:0xffff
    648a:	8d be e2 fe          	lea    di,[bp-0x11e]
    648e:	16                   	push   ss
    648f:	57                   	push   di
    6490:	6a 5c                	push   0x5c
    6492:	9a 47 0e b9 64       	call   0x64b9:0xe47
    6497:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    649a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    649d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    64a0:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    64a3:	74 16                	je     0x64bb
    64a5:	8d be e2 fe          	lea    di,[bp-0x11e]
    64a9:	16                   	push   ss
    64aa:	57                   	push   di
    64ab:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    64ae:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    64b1:	05 01 00             	add    ax,0x1
    64b4:	52                   	push   dx
    64b5:	50                   	push   ax
    64b6:	9a df 0c c6 64       	call   0x64c6:0xcdf
    64bb:	8d be e2 fe          	lea    di,[bp-0x11e]
    64bf:	16                   	push   ss
    64c0:	57                   	push   di
    64c1:	6a 2e                	push   0x2e
    64c3:	9a 1f 0e 49 65       	call   0x6549:0xe1f
    64c8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    64cb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    64ce:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    64d1:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    64d4:	74 07                	je     0x64dd
    64d6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    64d9:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    64dd:	8d be e3 fe          	lea    di,[bp-0x11d]
    64e1:	16                   	push   ss
    64e2:	57                   	push   di
    64e3:	9a ff ff 00 00       	call   0x0:0xffff
    64e8:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    64ed:	75 03                	jne    0x64f2
    64ef:	e9 e3 00             	jmp    0x65d5
    64f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64f5:	06                   	push   es
    64f6:	57                   	push   di
    64f7:	bf 77 6a             	mov    di,0x6a77
    64fa:	b8 02 65             	mov    ax,0x6502
    64fd:	50                   	push   ax
    64fe:	57                   	push   di
    64ff:	9a 89 14 61 66       	call   0x6661:0x1489
    6504:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6507:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    650b:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    650f:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    6513:	ff 36 b6 16          	push   WORD PTR ds:0x16b6
    6517:	ff 36 b4 16          	push   WORD PTR ds:0x16b4
    651b:	8d 7e e2             	lea    di,[bp-0x1e]
    651e:	16                   	push   ss
    651f:	57                   	push   di
    6520:	9a ff ff 00 00       	call   0x0:0xffff
    6525:	09 c0                	or     ax,ax
    6527:	75 39                	jne    0x6562
    6529:	a1 8c 18             	mov    ax,ds:0x188c
    652c:	a3 a8 16             	mov    ds:0x16a8,ax
    652f:	bf 9e 16             	mov    di,0x169e
    6532:	1e                   	push   ds
    6533:	57                   	push   di
    6534:	9a ff ff 00 00       	call   0x0:0xffff
    6539:	09 c0                	or     ax,ax
    653b:	75 25                	jne    0x6562
    653d:	8d be e2 fd          	lea    di,[bp-0x21e]
    6541:	16                   	push   ss
    6542:	57                   	push   di
    6543:	68 27 f0             	push   0xf027
    6546:	9a 2b 09 59 65       	call   0x6559:0x92b
    654b:	b0 01                	mov    al,0x1
    654d:	50                   	push   ax
    654e:	b8 22 00             	mov    ax,0x22
    6551:	ba 6e 68             	mov    dx,0x686e
    6554:	52                   	push   dx
    6555:	50                   	push   ax
    6556:	9a e6 28 67 70       	call   0x7067:0x28e6
    655b:	52                   	push   dx
    655c:	50                   	push   ax
    655d:	9a 99 13 2e 66       	call   0x662e:0x1399
    6562:	ff 36 b6 16          	push   WORD PTR ds:0x16b6
    6566:	ff 36 b4 16          	push   WORD PTR ds:0x16b4
    656a:	8d be e2 fe          	lea    di,[bp-0x11e]
    656e:	16                   	push   ss
    656f:	57                   	push   di
    6570:	68 0a 94             	push   0x940a
    6573:	6a 00                	push   0x0
    6575:	6a 00                	push   0x0
    6577:	9a 86 65 00 00       	call   0x0:0x6586
    657c:	99                   	cwd
    657d:	b9 02 00             	mov    cx,0x2
    6580:	f7 f9                	idiv   cx
    6582:	50                   	push   ax
    6583:	6a 01                	push   0x1
    6585:	9a ff ff 00 00       	call   0x0:0xffff
    658a:	99                   	cwd
    658b:	b9 02 00             	mov    cx,0x2
    658e:	f7 f9                	idiv   cx
    6590:	50                   	push   ax
    6591:	6a 00                	push   0x0
    6593:	6a 00                	push   0x0
    6595:	6a 00                	push   0x0
    6597:	6a 00                	push   0x0
    6599:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    659d:	6a 00                	push   0x0
    659f:	6a 00                	push   0x0
    65a1:	9a ff ff 00 00       	call   0x0:0xffff
    65a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a9:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    65ad:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    65b1:	6a fc                	push   0xfffc
    65b3:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    65b7:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    65bb:	9a ff ff 00 00       	call   0x0:0xffff
    65c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65c3:	26 8b 4d 1a          	mov    cx,WORD PTR es:[di+0x1a]
    65c7:	8c d8                	mov    ax,ds
    65c9:	8b d0                	mov    dx,ax
    65cb:	b8 2e 00             	mov    ax,0x2e
    65ce:	89 c7                	mov    di,ax
    65d0:	8e c2                	mov    es,dx
    65d2:	26 89 0d             	mov    WORD PTR es:[di],cx
    65d5:	a1 16 17             	mov    ax,ds:0x1716
    65d8:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    65dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65df:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    65e3:	26 89 55 2e          	mov    WORD PTR es:[di+0x2e],dx
    65e7:	a1 16 17             	mov    ax,ds:0x1716
    65ea:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    65ee:	26 89 45 28          	mov    WORD PTR es:[di+0x28],ax
    65f2:	26 89 55 2a          	mov    WORD PTR es:[di+0x2a],dx
    65f6:	a1 16 17             	mov    ax,ds:0x1716
    65f9:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    65fd:	26 89 45 4b          	mov    WORD PTR es:[di+0x4b],ax
    6601:	26 89 55 4d          	mov    WORD PTR es:[di+0x4d],dx
    6605:	b0 01                	mov    al,0x1
    6607:	50                   	push   ax
    6608:	b8 fc 08             	mov    ax,0x8fc
    660b:	ba 13 66             	mov    dx,0x6613
    660e:	52                   	push   dx
    660f:	50                   	push   ax
    6610:	9a 0e 64 56 66       	call   0x6656:0x640e
    6615:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6618:	26 89 45 55          	mov    WORD PTR es:[di+0x55],ax
    661c:	26 89 55 57          	mov    WORD PTR es:[di+0x57],dx
    6620:	b0 01                	mov    al,0x1
    6622:	50                   	push   ax
    6623:	b8 a3 02             	mov    ax,0x2a3
    6626:	ba 88 66             	mov    dx,0x6688
    6629:	52                   	push   dx
    662a:	50                   	push   ax
    662b:	9a 50 1f 9b 66       	call   0x669b:0x1f50
    6630:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6633:	26 89 45 4f          	mov    WORD PTR es:[di+0x4f],ax
    6637:	26 89 55 51          	mov    WORD PTR es:[di+0x51],dx
    663b:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    663f:	bf c6 16             	mov    di,0x16c6
    6642:	1e                   	push   ds
    6643:	57                   	push   di
    6644:	9a ff ff 00 00       	call   0x0:0xffff
    6649:	50                   	push   ax
    664a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    664d:	26 c4 7d 55          	les    di,DWORD PTR es:[di+0x55]
    6651:	06                   	push   es
    6652:	57                   	push   di
    6653:	9a b7 68 94 7b       	call   0x7b94:0x68b7
    6658:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    665b:	06                   	push   es
    665c:	57                   	push   di
    665d:	b8 70 80             	mov    ax,0x8070
    6660:	ba 36 67             	mov    dx,0x6736
    6663:	26 c4 7d 55          	les    di,DWORD PTR es:[di+0x55]
    6667:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    666b:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    666f:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    6673:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    6677:	ff 76 0e             	push   WORD PTR [bp+0xe]
    667a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    667d:	31 c0                	xor    ax,ax
    667f:	50                   	push   ax
    6680:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6683:	06                   	push   es
    6684:	57                   	push   di
    6685:	9a d9 4b 94 66       	call   0x6694:0x4bd9
    668a:	e8 dd ab             	call   0x126a
    668d:	b0 01                	mov    al,0x1
    668f:	50                   	push   ax
    6690:	b8 a3 02             	mov    ax,0x2a3
    6693:	ba 02 67             	mov    dx,0x6702
    6696:	52                   	push   dx
    6697:	50                   	push   ax
    6698:	9a 50 1f 49 67       	call   0x6749:0x1f50
    669d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66a0:	26 89 45 5b          	mov    WORD PTR es:[di+0x5b],ax
    66a4:	26 89 55 5d          	mov    WORD PTR es:[di+0x5d],dx
    66a8:	26 c6 45 47 00       	mov    BYTE PTR es:[di+0x47],0x0
    66ad:	31 c0                	xor    ax,ax
    66af:	26 89 45 35          	mov    WORD PTR es:[di+0x35],ax
    66b3:	26 89 45 37          	mov    WORD PTR es:[di+0x37],ax
    66b7:	31 c0                	xor    ax,ax
    66b9:	26 89 45 43          	mov    WORD PTR es:[di+0x43],ax
    66bd:	26 89 45 45          	mov    WORD PTR es:[di+0x45],ax
    66c1:	26 c7 45 31 ff ff    	mov    WORD PTR es:[di+0x31],0xffff
    66c7:	26 c7 45 33 80 00    	mov    WORD PTR es:[di+0x33],0x80
    66cd:	26 c7 45 41 20 03    	mov    WORD PTR es:[di+0x41],0x320
    66d3:	26 c6 45 5a 01       	mov    BYTE PTR es:[di+0x5a],0x1
    66d8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    66dc:	74 07                	je     0x66e5
    66de:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    66e2:	83 c4 06             	add    sp,0x6
    66e5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    66e8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    66eb:	c9                   	leave
    66ec:	ca 0a 00             	retf   0xa
    66ef:	55                   	push   bp
    66f0:	89 e5                	mov    bp,sp
    66f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66f5:	26 c6 45 5a 00       	mov    BYTE PTR es:[di+0x5a],0x0
    66fa:	31 c0                	xor    ax,ax
    66fc:	50                   	push   ax
    66fd:	06                   	push   es
    66fe:	57                   	push   di
    66ff:	9a 2b 4c 89 68       	call   0x6889:0x4c2b
    6704:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    6709:	74 13                	je     0x671e
    670b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    670e:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    6713:	74 09                	je     0x671e
    6715:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6719:	9a ff ff 00 00       	call   0x0:0xffff
    671e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6721:	26 8b 45 1c          	mov    ax,WORD PTR es:[di+0x1c]
    6725:	26 0b 45 1e          	or     ax,WORD PTR es:[di+0x1e]
    6729:	74 0d                	je     0x6738
    672b:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    672f:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    6733:	9a a5 15 3b 67       	call   0x673b:0x15a5
    6738:	9a d0 13 10 68       	call   0x6810:0x13d0
    673d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6740:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    6744:	06                   	push   es
    6745:	57                   	push   di
    6746:	9a 7f 1f 54 67       	call   0x6754:0x1f7f
    674b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    674f:	74 05                	je     0x6756
    6751:	9a 0f 20 e0 6a       	call   0x6ae0:0x200f
    6756:	c9                   	leave
    6757:	ca 06 00             	retf   0x6
    675a:	55                   	push   bp
    675b:	89 e5                	mov    bp,sp
    675d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6760:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    6764:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    6768:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    676b:	75 0f                	jne    0x677c
    676d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    6770:	75 0a                	jne    0x677c
    6772:	31 c0                	xor    ax,ax
    6774:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    6778:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    677c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    677f:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    6783:	26 8b 55 26          	mov    dx,WORD PTR es:[di+0x26]
    6787:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    678a:	75 0f                	jne    0x679b
    678c:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    678f:	75 0a                	jne    0x679b
    6791:	31 c0                	xor    ax,ax
    6793:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    6797:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    679b:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    679f:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    67a3:	26 8b 55 2e          	mov    dx,WORD PTR es:[di+0x2e]
    67a7:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    67aa:	75 13                	jne    0x67bf
    67ac:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    67af:	75 0e                	jne    0x67bf
    67b1:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    67b5:	31 c0                	xor    ax,ax
    67b7:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    67bb:	26 89 45 2e          	mov    WORD PTR es:[di+0x2e],ax
    67bf:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    67c3:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    67c7:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    67cb:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    67ce:	75 13                	jne    0x67e3
    67d0:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    67d3:	75 0e                	jne    0x67e3
    67d5:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    67d9:	31 c0                	xor    ax,ax
    67db:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    67df:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    67e3:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    67e7:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    67eb:	26 8b 55 3e          	mov    dx,WORD PTR es:[di+0x3e]
    67ef:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    67f2:	75 13                	jne    0x6807
    67f4:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    67f7:	75 0e                	jne    0x6807
    67f9:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    67fd:	31 c0                	xor    ax,ax
    67ff:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    6803:	26 89 45 3e          	mov    WORD PTR es:[di+0x3e],ax
    6807:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    680b:	06                   	push   es
    680c:	57                   	push   di
    680d:	9a 0d 61 d3 68       	call   0x68d3:0x610d
    6812:	c9                   	leave
    6813:	ca 08 00             	retf   0x8
    6816:	8c d0                	mov    ax,ss
    6818:	90                   	nop
    6819:	45                   	inc    bp
    681a:	55                   	push   bp
    681b:	89 e5                	mov    bp,sp
    681d:	1e                   	push   ds
    681e:	8e d8                	mov    ds,ax
    6820:	83 ec 02             	sub    sp,0x2
    6823:	56                   	push   si
    6824:	57                   	push   di
    6825:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    682a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    682d:	6a 04                	push   0x4
    682f:	9a f5 68 00 00       	call   0x0:0x68f5
    6834:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6838:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
    683c:	75 5d                	jne    0x689b
    683e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6841:	6a ec                	push   0xffec
    6843:	9a 02 69 00 00       	call   0x0:0x6902
    6848:	25 08 00             	and    ax,0x8
    684b:	81 e2 00 00          	and    dx,0x0
    684f:	09 d0                	or     ax,dx
    6851:	74 3a                	je     0x688d
    6853:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6857:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    685b:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    685f:	74 14                	je     0x6875
    6861:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6865:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6869:	06                   	push   es
    686a:	57                   	push   di
    686b:	9a b9 62 00 6d       	call   0x6d00:0x62b9
    6870:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    6873:	74 18                	je     0x688d
    6875:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6878:	31 d2                	xor    dx,dx
    687a:	52                   	push   dx
    687b:	50                   	push   ax
    687c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6880:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    6884:	06                   	push   es
    6885:	57                   	push   di
    6886:	9a 2b 0c 3d 69       	call   0x693d:0xc2b
    688b:	eb 0e                	jmp    0x689b
    688d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6890:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6893:	26 89 05             	mov    WORD PTR es:[di],ax
    6896:	31 c0                	xor    ax,ax
    6898:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    689b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    689e:	5f                   	pop    di
    689f:	5e                   	pop    si
    68a0:	8d 66 fe             	lea    sp,[bp-0x2]
    68a3:	1f                   	pop    ds
    68a4:	5d                   	pop    bp
    68a5:	4d                   	dec    bp
    68a6:	ca 06 00             	retf   0x6
    68a9:	c8 04 00 00          	enter  0x4,0x0
    68ad:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    68b1:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    68b6:	75 03                	jne    0x68bb
    68b8:	e9 a4 00             	jmp    0x695f
    68bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68be:	26 83 7d 53 00       	cmp    WORD PTR es:[di+0x53],0x0
    68c3:	74 03                	je     0x68c8
    68c5:	e9 90 00             	jmp    0x6958
    68c8:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    68cc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    68cf:	bf 16 68             	mov    di,0x6816
    68d2:	b8 4c 6a             	mov    ax,0x6a4c
    68d5:	50                   	push   ax
    68d6:	57                   	push   di
    68d7:	8d 7e fc             	lea    di,[bp-0x4]
    68da:	16                   	push   ss
    68db:	57                   	push   di
    68dc:	9a ff ff 00 00       	call   0x0:0xffff
    68e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68e4:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    68e8:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    68ed:	74 69                	je     0x6958
    68ef:	ff 76 fc             	push   WORD PTR [bp-0x4]
    68f2:	6a 03                	push   0x3
    68f4:	9a ff ff 00 00       	call   0x0:0xffff
    68f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    68fc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    68ff:	6a ec                	push   0xffec
    6901:	9a ff ff 00 00       	call   0x0:0xffff
    6906:	25 08 00             	and    ax,0x8
    6909:	81 e2 00 00          	and    dx,0x0
    690d:	09 d0                	or     ax,dx
    690f:	74 05                	je     0x6916
    6911:	c7 46 fc fe ff       	mov    WORD PTR [bp-0x4],0xfffe
    6916:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6919:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    691d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6921:	48                   	dec    ax
    6922:	09 c0                	or     ax,ax
    6924:	7c 32                	jl     0x6958
    6926:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6929:	eb 03                	jmp    0x692e
    692b:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    692e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6934:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    6938:	06                   	push   es
    6939:	57                   	push   di
    693a:	9a d0 0d a4 69       	call   0x69a4:0xdd0
    693f:	50                   	push   ax
    6940:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6943:	6a 00                	push   0x0
    6945:	6a 00                	push   0x0
    6947:	6a 00                	push   0x0
    6949:	6a 00                	push   0x0
    694b:	6a 13                	push   0x13
    694d:	9a b4 69 00 00       	call   0x0:0x69b4
    6952:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    6956:	75 d3                	jne    0x692b
    6958:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    695b:	26 ff 45 53          	inc    WORD PTR es:[di+0x53]
    695f:	c9                   	leave
    6960:	ca 04 00             	retf   0x4
    6963:	c8 02 00 00          	enter  0x2,0x0
    6967:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    696b:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    6970:	74 5a                	je     0x69cc
    6972:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6975:	26 ff 4d 53          	dec    WORD PTR es:[di+0x53]
    6979:	26 83 7d 53 00       	cmp    WORD PTR es:[di+0x53],0x0
    697e:	75 4c                	jne    0x69cc
    6980:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    6984:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6988:	48                   	dec    ax
    6989:	09 c0                	or     ax,ax
    698b:	7c 31                	jl     0x69be
    698d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6990:	eb 03                	jmp    0x6995
    6992:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    6995:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6998:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    699b:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    699f:	06                   	push   es
    69a0:	57                   	push   di
    69a1:	9a d0 0d ca 69       	call   0x69ca:0xdd0
    69a6:	50                   	push   ax
    69a7:	6a ff                	push   0xffff
    69a9:	6a 00                	push   0x0
    69ab:	6a 00                	push   0x0
    69ad:	6a 00                	push   0x0
    69af:	6a 00                	push   0x0
    69b1:	6a 13                	push   0x13
    69b3:	9a ff ff 00 00       	call   0x0:0xffff
    69b8:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    69bc:	75 d4                	jne    0x6992
    69be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c1:	26 c4 7d 4f          	les    di,DWORD PTR es:[di+0x4f]
    69c5:	06                   	push   es
    69c6:	57                   	push   di
    69c7:	9a 75 0c c8 6a       	call   0x6ac8:0xc75
    69cc:	c9                   	leave
    69cd:	ca 04 00             	retf   0x4
    69d0:	c8 04 00 00          	enter  0x4,0x0
    69d4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    69d7:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    69db:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    69de:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    69e1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    69e4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    69e8:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    69ec:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    69ef:	26 ff 35             	push   WORD PTR es:[di]
    69f2:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    69f6:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    69fa:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    69fe:	9a ff ff 00 00       	call   0x0:0xffff
    6a03:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6a06:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    6a0a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    6a0e:	c9                   	leave
    6a0f:	c2 02 00             	ret    0x2
    6a12:	c8 26 00 00          	enter  0x26,0x0
    6a16:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6a19:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    6a1d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6a20:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6a24:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6a28:	8d 7e de             	lea    di,[bp-0x22]
    6a2b:	16                   	push   ss
    6a2c:	57                   	push   di
    6a2d:	9a ff ff 00 00       	call   0x0:0xffff
    6a32:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6a35:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6a38:	6a 00                	push   0x0
    6a3a:	6a 00                	push   0x0
    6a3c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6a3f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6a43:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6a47:	06                   	push   es
    6a48:	57                   	push   di
    6a49:	9a ec 46 75 6a       	call   0x6a75:0x46ec
    6a4e:	50                   	push   ax
    6a4f:	9a ff ff 00 00       	call   0x0:0xffff
    6a54:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6a57:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6a5b:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6a5f:	8d 7e de             	lea    di,[bp-0x22]
    6a62:	16                   	push   ss
    6a63:	57                   	push   di
    6a64:	9a ff ff 00 00       	call   0x0:0xffff
    6a69:	c9                   	leave
    6a6a:	c2 02 00             	ret    0x2
    6a6d:	01 00                	add    WORD PTR [bx+si],ax
    6a6f:	00 00                	add    BYTE PTR [bx+si],al
    6a71:	00 00                	add    BYTE PTR [bx+si],al
    6a73:	f4                   	hlt
    6a74:	6e                   	outs   dx,BYTE PTR ds:[si]
    6a75:	12 6b c8             	adc    ch,BYTE PTR [bp+di-0x38]
    6a78:	0e                   	push   cs
    6a79:	00 00                	add    BYTE PTR [bx+si],al
    6a7b:	b8 6d 6a             	mov    ax,0x6a6d
    6a7e:	0e                   	push   cs
    6a7f:	50                   	push   ax
    6a80:	55                   	push   bp
    6a81:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6a85:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6a89:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6a8c:	31 c0                	xor    ax,ax
    6a8e:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    6a92:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    6a96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a99:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    6a9d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6aa1:	48                   	dec    ax
    6aa2:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6aa5:	31 c0                	xor    ax,ax
    6aa7:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6aaa:	7f 41                	jg     0x6aed
    6aac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6aaf:	eb 03                	jmp    0x6ab4
    6ab1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    6ab4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6ab7:	06                   	push   es
    6ab8:	57                   	push   di
    6ab9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6abc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6abf:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    6ac3:	06                   	push   es
    6ac4:	57                   	push   di
    6ac5:	9a d0 0d 6f 73       	call   0x736f:0xdd0
    6aca:	89 c7                	mov    di,ax
    6acc:	8e c2                	mov    es,dx
    6ace:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6ad2:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6ad6:	26 ff 1d             	call   DWORD PTR es:[di]
    6ad9:	08 c0                	or     al,al
    6adb:	74 08                	je     0x6ae5
    6add:	9a 6a 14 07 6f       	call   0x6f07:0x146a
    6ae2:	e9 24 04             	jmp    0x6f09
    6ae5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6ae8:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6aeb:	75 c4                	jne    0x6ab1
    6aed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6af0:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    6af3:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    6af6:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6af9:	3d 12 01             	cmp    ax,0x112
    6afc:	75 1f                	jne    0x6b1d
    6afe:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    6b02:	25 f0 ff             	and    ax,0xfff0
    6b05:	3d 20 f1             	cmp    ax,0xf120
    6b08:	75 0c                	jne    0x6b16
    6b0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b0d:	06                   	push   es
    6b0e:	57                   	push   di
    6b0f:	9a 69 6f 38 6b       	call   0x6b38:0x6f69
    6b14:	eb 04                	jmp    0x6b1a
    6b16:	55                   	push   bp
    6b17:	e8 b6 fe             	call   0x69d0
    6b1a:	e9 ce 03             	jmp    0x6eeb
    6b1d:	3d 10 00             	cmp    ax,0x10
    6b20:	75 1b                	jne    0x6b3d
    6b22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b25:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    6b29:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    6b2d:	74 0b                	je     0x6b3a
    6b2f:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6b33:	06                   	push   es
    6b34:	57                   	push   di
    6b35:	9a 56 55 b7 6b       	call   0x6bb7:0x5556
    6b3a:	e9 ae 03             	jmp    0x6eeb
    6b3d:	3d 15 00             	cmp    ax,0x15
    6b40:	75 17                	jne    0x6b59
    6b42:	83 3e 4e 15 20       	cmp    WORD PTR ds:0x154e,0x20
    6b47:	72 0d                	jb     0x6b56
    6b49:	a1 4a 2c             	mov    ax,ds:0x2c4a
    6b4c:	0b 06 4c 2c          	or     ax,WORD PTR ds:0x2c4c
    6b50:	74 04                	je     0x6b56
    6b52:	ff 1e 4a 2c          	call   DWORD PTR ds:0x2c4a
    6b56:	e9 92 03             	jmp    0x6eeb
    6b59:	3d 0f 00             	cmp    ax,0xf
    6b5c:	75 2a                	jne    0x6b88
    6b5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b61:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6b65:	9a 49 6e 00 00       	call   0x0:0x6e49
    6b6a:	09 c0                	or     ax,ax
    6b6c:	74 13                	je     0x6b81
    6b6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b71:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    6b75:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    6b79:	74 06                	je     0x6b81
    6b7b:	55                   	push   bp
    6b7c:	e8 93 fe             	call   0x6a12
    6b7f:	eb 04                	jmp    0x6b85
    6b81:	55                   	push   bp
    6b82:	e8 4b fe             	call   0x69d0
    6b85:	e9 63 03             	jmp    0x6eeb
    6b88:	3d 14 00             	cmp    ax,0x14
    6b8b:	75 0f                	jne    0x6b9c
    6b8d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b90:	26 c7 05 27 00       	mov    WORD PTR es:[di],0x27
    6b95:	55                   	push   bp
    6b96:	e8 37 fe             	call   0x69d0
    6b99:	e9 4f 03             	jmp    0x6eeb
    6b9c:	3d 37 00             	cmp    ax,0x37
    6b9f:	75 2e                	jne    0x6bcf
    6ba1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ba4:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    6ba8:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    6bac:	74 1a                	je     0x6bc8
    6bae:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6bb2:	06                   	push   es
    6bb3:	57                   	push   di
    6bb4:	9a ec 46 1f 6c       	call   0x6c1f:0x46ec
    6bb9:	31 d2                	xor    dx,dx
    6bbb:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6bbe:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    6bc2:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    6bc6:	eb 04                	jmp    0x6bcc
    6bc8:	55                   	push   bp
    6bc9:	e8 04 fe             	call   0x69d0
    6bcc:	e9 1c 03             	jmp    0x6eeb
    6bcf:	3d 07 00             	cmp    ax,0x7
    6bd2:	75 1c                	jne    0x6bf0
    6bd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bd7:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6bdb:	68 1a 0f             	push   0xf1a
    6bde:	6a 00                	push   0x0
    6be0:	6a 00                	push   0x0
    6be2:	6a 00                	push   0x0
    6be4:	9a 32 6c 00 00       	call   0x0:0x6c32
    6be9:	55                   	push   bp
    6bea:	e8 e3 fd             	call   0x69d0
    6bed:	e9 fb 02             	jmp    0x6eeb
    6bf0:	3d 1c 00             	cmp    ax,0x1c
    6bf3:	75 65                	jne    0x6c5a
    6bf5:	55                   	push   bp
    6bf6:	e8 d7 fd             	call   0x69d0
    6bf9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6bfc:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    6c00:	f7 d8                	neg    ax
    6c02:	18 c0                	sbb    al,al
    6c04:	f6 d8                	neg    al
    6c06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c09:	26 88 45 5a          	mov    BYTE PTR es:[di+0x5a],al
    6c0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6c10:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    6c15:	74 21                	je     0x6c38
    6c17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c1a:	06                   	push   es
    6c1b:	57                   	push   di
    6c1c:	9a 63 69 40 6c       	call   0x6c40:0x6963
    6c21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c24:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6c28:	68 00 0f             	push   0xf00
    6c2b:	6a 00                	push   0x0
    6c2d:	6a 00                	push   0x0
    6c2f:	6a 00                	push   0x0
    6c31:	9a 53 6c 00 00       	call   0x0:0x6c53
    6c36:	eb 1f                	jmp    0x6c57
    6c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c3b:	06                   	push   es
    6c3c:	57                   	push   di
    6c3d:	9a a9 68 71 6c       	call   0x6c71:0x68a9
    6c42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c45:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6c49:	68 01 0f             	push   0xf01
    6c4c:	6a 00                	push   0x0
    6c4e:	6a 00                	push   0x0
    6c50:	6a 00                	push   0x0
    6c52:	9a 87 77 00 00       	call   0x0:0x7787
    6c57:	e9 91 02             	jmp    0x6eeb
    6c5a:	3d 0a 00             	cmp    ax,0xa
    6c5d:	75 73                	jne    0x6cd2
    6c5f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6c62:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    6c67:	74 37                	je     0x6ca0
    6c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c6c:	06                   	push   es
    6c6d:	57                   	push   di
    6c6e:	9a 63 69 8b 6c       	call   0x6c8b:0x6963
    6c73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c76:	26 8b 45 5f          	mov    ax,WORD PTR es:[di+0x5f]
    6c7a:	26 0b 45 61          	or     ax,WORD PTR es:[di+0x61]
    6c7e:	74 1a                	je     0x6c9a
    6c80:	26 ff 75 61          	push   WORD PTR es:[di+0x61]
    6c84:	26 ff 75 5f          	push   WORD PTR es:[di+0x5f]
    6c88:	9a f0 0f b8 6c       	call   0x6cb8:0xff0
    6c8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c90:	31 c0                	xor    ax,ax
    6c92:	26 89 45 5f          	mov    WORD PTR es:[di+0x5f],ax
    6c96:	26 89 45 61          	mov    WORD PTR es:[di+0x61],ax
    6c9a:	55                   	push   bp
    6c9b:	e8 32 fd             	call   0x69d0
    6c9e:	eb 2f                	jmp    0x6ccf
    6ca0:	55                   	push   bp
    6ca1:	e8 2c fd             	call   0x69d0
    6ca4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ca7:	26 8b 45 5f          	mov    ax,WORD PTR es:[di+0x5f]
    6cab:	26 0b 45 61          	or     ax,WORD PTR es:[di+0x61]
    6caf:	75 14                	jne    0x6cc5
    6cb1:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6cb5:	9a e7 0e cd 6c       	call   0x6ccd:0xee7
    6cba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cbd:	26 89 45 5f          	mov    WORD PTR es:[di+0x5f],ax
    6cc1:	26 89 55 61          	mov    WORD PTR es:[di+0x61],dx
    6cc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cc8:	06                   	push   es
    6cc9:	57                   	push   di
    6cca:	9a a9 68 93 6e       	call   0x6e93:0x68a9
    6ccf:	e9 19 02             	jmp    0x6eeb
    6cd2:	3d 16 0f             	cmp    ax,0xf16
    6cd5:	75 63                	jne    0x6d3a
    6cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cda:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    6cde:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    6ce2:	74 53                	je     0x6d37
    6ce4:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6ce8:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    6ced:	26 0b 85 02 01       	or     ax,WORD PTR es:[di+0x102]
    6cf2:	74 43                	je     0x6d37
    6cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cf7:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6cfb:	06                   	push   es
    6cfc:	57                   	push   di
    6cfd:	9a b9 62 61 6d       	call   0x6d61:0x62b9
    6d02:	50                   	push   ax
    6d03:	9a 76 6d 00 00       	call   0x0:0x6d76
    6d08:	09 c0                	or     ax,ax
    6d0a:	74 2b                	je     0x6d37
    6d0c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6d0f:	06                   	push   es
    6d10:	57                   	push   di
    6d11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d14:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6d18:	26 c4 bd 00 01       	les    di,DWORD PTR es:[di+0x100]
    6d1d:	06                   	push   es
    6d1e:	57                   	push   di
    6d1f:	9a 2a 1b ff ff       	call   0xffff:0x1b2a
    6d24:	08 c0                	or     al,al
    6d26:	74 0f                	je     0x6d37
    6d28:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6d2b:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    6d31:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    6d37:	e9 b1 01             	jmp    0x6eeb
    6d3a:	3d 17 0f             	cmp    ax,0xf17
    6d3d:	74 03                	je     0x6d42
    6d3f:	e9 a8 00             	jmp    0x6dea
    6d42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d45:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    6d49:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    6d4d:	75 03                	jne    0x6d52
    6d4f:	e9 95 00             	jmp    0x6de7
    6d52:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    6d56:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    6d59:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    6d5c:	06                   	push   es
    6d5d:	57                   	push   di
    6d5e:	9a b9 62 72 6d       	call   0x6d72:0x62b9
    6d63:	09 c0                	or     ax,ax
    6d65:	75 03                	jne    0x6d6a
    6d67:	e9 7d 00             	jmp    0x6de7
    6d6a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    6d6d:	06                   	push   es
    6d6e:	57                   	push   di
    6d6f:	9a b9 62 86 6d       	call   0x6d86:0x62b9
    6d74:	50                   	push   ax
    6d75:	9a 24 70 00 00       	call   0x0:0x7024
    6d7a:	09 c0                	or     ax,ax
    6d7c:	74 69                	je     0x6de7
    6d7e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    6d81:	06                   	push   es
    6d82:	57                   	push   di
    6d83:	9a b9 62 a7 6d       	call   0x6da7:0x62b9
    6d88:	50                   	push   ax
    6d89:	9a 18 70 00 00       	call   0x0:0x7018
    6d8e:	09 c0                	or     ax,ax
    6d90:	74 55                	je     0x6de7
    6d92:	c6 06 32 15 00       	mov    BYTE PTR ds:0x1532,0x0
    6d97:	9a 52 6e 00 00       	call   0x0:0x6e52
    6d9c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6d9f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    6da2:	06                   	push   es
    6da3:	57                   	push   di
    6da4:	9a b9 62 c9 6d       	call   0x6dc9:0x62b9
    6da9:	50                   	push   ax
    6daa:	9a cf 6d 00 00       	call   0x0:0x6dcf
    6daf:	68 12 01             	push   0x112
    6db2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6db5:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6db9:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6dbd:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6dc1:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    6dc4:	06                   	push   es
    6dc5:	57                   	push   di
    6dc6:	9a bb 24 bb 6f       	call   0x6fbb:0x24bb
    6dcb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6dce:	9a 71 6e 00 00       	call   0x0:0x6e71
    6dd3:	c6 06 32 15 01       	mov    BYTE PTR ds:0x1532,0x1
    6dd8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6ddb:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    6de1:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    6de7:	e9 01 01             	jmp    0x6eeb
    6dea:	3d 00 0f             	cmp    ax,0xf00
    6ded:	75 24                	jne    0x6e13
    6def:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6df2:	26 8b 85 97 00       	mov    ax,WORD PTR es:[di+0x97]
    6df7:	09 c0                	or     ax,ax
    6df9:	74 15                	je     0x6e10
    6dfb:	ff 76 08             	push   WORD PTR [bp+0x8]
    6dfe:	ff 76 06             	push   WORD PTR [bp+0x6]
    6e01:	26 ff b5 9b 00       	push   WORD PTR es:[di+0x9b]
    6e06:	26 ff b5 99 00       	push   WORD PTR es:[di+0x99]
    6e0b:	26 ff 9d 95 00       	call   DWORD PTR es:[di+0x95]
    6e10:	e9 d8 00             	jmp    0x6eeb
    6e13:	3d 01 0f             	cmp    ax,0xf01
    6e16:	75 24                	jne    0x6e3c
    6e18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e1b:	26 8b 85 8f 00       	mov    ax,WORD PTR es:[di+0x8f]
    6e20:	09 c0                	or     ax,ax
    6e22:	74 15                	je     0x6e39
    6e24:	ff 76 08             	push   WORD PTR [bp+0x8]
    6e27:	ff 76 06             	push   WORD PTR [bp+0x6]
    6e2a:	26 ff b5 93 00       	push   WORD PTR es:[di+0x93]
    6e2f:	26 ff b5 91 00       	push   WORD PTR es:[di+0x91]
    6e34:	26 ff 9d 8d 00       	call   DWORD PTR es:[di+0x8d]
    6e39:	e9 af 00             	jmp    0x6eeb
    6e3c:	3d 1a 0f             	cmp    ax,0xf1a
    6e3f:	75 36                	jne    0x6e77
    6e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e44:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6e48:	9a 18 6f 00 00       	call   0x0:0x6f18
    6e4d:	09 c0                	or     ax,ax
    6e4f:	75 24                	jne    0x6e75
    6e51:	9a ff ff 00 00       	call   0x0:0xffff
    6e56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e59:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
    6e5d:	75 16                	jne    0x6e75
    6e5f:	6a 00                	push   0x0
    6e61:	e8 a6 a2             	call   0x110a
    6e64:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6e67:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    6e6b:	74 08                	je     0x6e75
    6e6d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6e70:	9a bf 6f 00 00       	call   0x0:0x6fbf
    6e75:	eb 74                	jmp    0x6eeb
    6e77:	3d 1f 0f             	cmp    ax,0xf1f
    6e7a:	75 1b                	jne    0x6e97
    6e7c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6e7f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6e83:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6e87:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6e8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e8e:	06                   	push   es
    6e8f:	57                   	push   di
    6e90:	9a c7 76 c1 6e       	call   0x6ec1:0x76c7
    6e95:	eb 54                	jmp    0x6eeb
    6e97:	3d 20 0f             	cmp    ax,0xf20
    6e9a:	75 4b                	jne    0x6ee7
    6e9c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6e9f:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    6ea4:	75 1f                	jne    0x6ec5
    6ea6:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    6eaa:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6eae:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6eb2:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6eb6:	26 ff 35             	push   WORD PTR es:[di]
    6eb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ebc:	06                   	push   es
    6ebd:	57                   	push   di
    6ebe:	9a 39 73 e3 6e       	call   0x6ee3:0x7339
    6ec3:	eb 20                	jmp    0x6ee5
    6ec5:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    6ec8:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    6ecc:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6ed0:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6ed4:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6ed8:	26 ff 35             	push   WORD PTR es:[di]
    6edb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ede:	06                   	push   es
    6edf:	57                   	push   di
    6ee0:	9a a7 73 02 6f       	call   0x6f02:0x73a7
    6ee5:	eb 04                	jmp    0x6eeb
    6ee7:	55                   	push   bp
    6ee8:	e8 e5 fa             	call   0x69d0
    6eeb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6eef:	83 c4 06             	add    sp,0x6
    6ef2:	eb 15                	jmp    0x6f09
    6ef4:	ff 76 08             	push   WORD PTR [bp+0x8]
    6ef7:	ff 76 06             	push   WORD PTR [bp+0x6]
    6efa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6efd:	06                   	push   es
    6efe:	57                   	push   di
    6eff:	9a 51 75 28 6f       	call   0x6f28:0x7551
    6f04:	9a 34 14 74 70       	call   0x7074:0x1434
    6f09:	c9                   	leave
    6f0a:	ca 08 00             	retf   0x8
    6f0d:	55                   	push   bp
    6f0e:	89 e5                	mov    bp,sp
    6f10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f13:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6f17:	9a 74 6f 00 00       	call   0x0:0x6f74
    6f1c:	09 c0                	or     ax,ax
    6f1e:	75 45                	jne    0x6f65
    6f20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f23:	06                   	push   es
    6f24:	57                   	push   di
    6f25:	9a a9 68 9e 6f       	call   0x6f9e:0x68a9
    6f2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f2d:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6f31:	9a 84 6f 00 00       	call   0x0:0x6f84
    6f36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f39:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6f3d:	6a 06                	push   0x6
    6f3f:	9a 92 6f 00 00       	call   0x0:0x6f92
    6f44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f47:	26 8b 85 a7 00       	mov    ax,WORD PTR es:[di+0xa7]
    6f4c:	09 c0                	or     ax,ax
    6f4e:	74 15                	je     0x6f65
    6f50:	ff 76 08             	push   WORD PTR [bp+0x8]
    6f53:	ff 76 06             	push   WORD PTR [bp+0x6]
    6f56:	26 ff b5 ab 00       	push   WORD PTR es:[di+0xab]
    6f5b:	26 ff b5 a9 00       	push   WORD PTR es:[di+0xa9]
    6f60:	26 ff 9d a5 00       	call   DWORD PTR es:[di+0xa5]
    6f65:	c9                   	leave
    6f66:	ca 04 00             	retf   0x4
    6f69:	55                   	push   bp
    6f6a:	89 e5                	mov    bp,sp
    6f6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f6f:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6f73:	9a ff ff 00 00       	call   0x0:0xffff
    6f78:	09 c0                	or     ax,ax
    6f7a:	74 68                	je     0x6fe4
    6f7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f7f:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6f83:	9a 59 76 00 00       	call   0x0:0x7659
    6f88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f8b:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6f8f:	6a 09                	push   0x9
    6f91:	9a 6f 79 00 00       	call   0x0:0x796f
    6f96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f99:	06                   	push   es
    6f9a:	57                   	push   di
    6f9b:	9a 63 69 2d 72       	call   0x722d:0x6963
    6fa0:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6fa4:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    6fa8:	26 0b 45 2e          	or     ax,WORD PTR es:[di+0x2e]
    6fac:	74 15                	je     0x6fc3
    6fae:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    6fb2:	26 c4 7d 2c          	les    di,DWORD PTR es:[di+0x2c]
    6fb6:	06                   	push   es
    6fb7:	57                   	push   di
    6fb8:	9a b9 62 c3 71       	call   0x71c3:0x62b9
    6fbd:	50                   	push   ax
    6fbe:	9a ff ff 00 00       	call   0x0:0xffff
    6fc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fc6:	26 8b 85 af 00       	mov    ax,WORD PTR es:[di+0xaf]
    6fcb:	09 c0                	or     ax,ax
    6fcd:	74 15                	je     0x6fe4
    6fcf:	ff 76 08             	push   WORD PTR [bp+0x8]
    6fd2:	ff 76 06             	push   WORD PTR [bp+0x6]
    6fd5:	26 ff b5 b3 00       	push   WORD PTR es:[di+0xb3]
    6fda:	26 ff b5 b1 00       	push   WORD PTR es:[di+0xb1]
    6fdf:	26 ff 9d ad 00       	call   DWORD PTR es:[di+0xad]
    6fe4:	c9                   	leave
    6fe5:	ca 04 00             	retf   0x4
    6fe8:	c8 02 00 00          	enter  0x2,0x0
    6fec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fef:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    6ff4:	74 3e                	je     0x7034
    6ff6:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6ffa:	9a ff ff 00 00       	call   0x0:0xffff
    6fff:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7002:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    7006:	74 2c                	je     0x7034
    7008:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    700b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    700e:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
    7012:	74 20                	je     0x7034
    7014:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7017:	9a 70 7d 00 00       	call   0x0:0x7d70
    701c:	09 c0                	or     ax,ax
    701e:	74 14                	je     0x7034
    7020:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7023:	9a ff ff 00 00       	call   0x0:0xffff
    7028:	09 c0                	or     ax,ax
    702a:	74 08                	je     0x7034
    702c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    702f:	9a ff ff 00 00       	call   0x0:0xffff
    7034:	c9                   	leave
    7035:	ca 04 00             	retf   0x4
    7038:	c8 00 02 00          	enter  0x200,0x0
    703c:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    7041:	74 35                	je     0x7078
    7043:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7046:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    704a:	8d be 00 ff          	lea    di,[bp-0x100]
    704e:	16                   	push   ss
    704f:	57                   	push   di
    7050:	68 00 01             	push   0x100
    7053:	9a ff ff 00 00       	call   0x0:0xffff
    7058:	8d be 00 fe          	lea    di,[bp-0x200]
    705c:	16                   	push   ss
    705d:	57                   	push   di
    705e:	8d be 00 ff          	lea    di,[bp-0x100]
    7062:	16                   	push   ss
    7063:	57                   	push   di
    7064:	9a 6e 0e b2 70       	call   0x70b2:0xe6e
    7069:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    706c:	06                   	push   es
    706d:	57                   	push   di
    706e:	68 ff 00             	push   0xff
    7071:	9a e7 17 8c 70       	call   0x708c:0x17e7
    7076:	eb 16                	jmp    0x708e
    7078:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    707b:	26 c4 7d 4b          	les    di,DWORD PTR es:[di+0x4b]
    707f:	06                   	push   es
    7080:	57                   	push   di
    7081:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7084:	06                   	push   es
    7085:	57                   	push   di
    7086:	68 ff 00             	push   0xff
    7089:	9a e7 17 76 73       	call   0x7376:0x17e7
    708e:	c9                   	leave
    708f:	ca 04 00             	retf   0x4
    7092:	c8 00 01 00          	enter  0x100,0x0
    7096:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    709b:	74 20                	je     0x70bd
    709d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70a0:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    70a4:	8d be 00 ff          	lea    di,[bp-0x100]
    70a8:	16                   	push   ss
    70a9:	57                   	push   di
    70aa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    70ad:	06                   	push   es
    70ae:	57                   	push   di
    70af:	9a 4c 0d ce 70       	call   0x70ce:0xd4c
    70b4:	52                   	push   dx
    70b5:	50                   	push   ax
    70b6:	9a ff ff 00 00       	call   0x0:0xffff
    70bb:	eb 13                	jmp    0x70d0
    70bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70c0:	81 c7 4b 00          	add    di,0x4b
    70c4:	06                   	push   es
    70c5:	57                   	push   di
    70c6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    70c9:	06                   	push   es
    70ca:	57                   	push   di
    70cb:	9a 51 06 0f 75       	call   0x750f:0x651
    70d0:	c9                   	leave
    70d1:	ca 08 00             	retf   0x8
    70d4:	c8 02 00 00          	enter  0x2,0x0
    70d8:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    70dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70df:	26 83 7d 63 00       	cmp    WORD PTR es:[di+0x63],0x0
    70e4:	74 17                	je     0x70fd
    70e6:	26 ff 75 63          	push   WORD PTR es:[di+0x63]
    70ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    70ed:	06                   	push   es
    70ee:	57                   	push   di
    70ef:	9a ff ff 00 00       	call   0x0:0xffff
    70f4:	f7 d8                	neg    ax
    70f6:	18 c0                	sbb    al,al
    70f8:	f6 d8                	neg    al
    70fa:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    70fd:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    7100:	c9                   	leave
    7101:	ca 08 00             	retf   0x8
    7104:	c8 02 00 00          	enter  0x2,0x0
    7108:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    710c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    710f:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    7113:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    7117:	74 49                	je     0x7162
    7119:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    711d:	26 80 bd f2 00 02    	cmp    BYTE PTR es:[di+0xf2],0x2
    7123:	75 3d                	jne    0x7162
    7125:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    7129:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    712d:	26 0b 45 32          	or     ax,WORD PTR es:[di+0x32]
    7131:	74 2f                	je     0x7162
    7133:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    7137:	26 c4 7d 30          	les    di,DWORD PTR es:[di+0x30]
    713b:	26 80 bd f2 00 01    	cmp    BYTE PTR es:[di+0xf2],0x1
    7141:	75 1f                	jne    0x7162
    7143:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7146:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    714a:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    714f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7152:	06                   	push   es
    7153:	57                   	push   di
    7154:	9a ff ff 00 00       	call   0x0:0xffff
    7159:	f7 d8                	neg    ax
    715b:	18 c0                	sbb    al,al
    715d:	f6 d8                	neg    al
    715f:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    7162:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    7165:	c9                   	leave
    7166:	ca 08 00             	retf   0x8
    7169:	c8 08 00 00          	enter  0x8,0x0
    716d:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    7171:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7174:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    7177:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    717a:	26 81 7d 02 00 01    	cmp    WORD PTR es:[di+0x2],0x100
    7180:	72 6d                	jb     0x71ef
    7182:	26 81 7d 02 08 01    	cmp    WORD PTR es:[di+0x2],0x108
    7188:	77 65                	ja     0x71ef
    718a:	9a 55 75 00 00       	call   0x0:0x7555
    718f:	09 c0                	or     ax,ax
    7191:	75 5c                	jne    0x71ef
    7193:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7196:	26 8b 05             	mov    ax,WORD PTR es:[di]
    7199:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    719c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    719f:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    71a3:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    71a7:	74 1f                	je     0x71c8
    71a9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    71ac:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    71b0:	26 3b 85 0e 01       	cmp    ax,WORD PTR es:[di+0x10e]
    71b5:	75 11                	jne    0x71c8
    71b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71ba:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    71be:	06                   	push   es
    71bf:	57                   	push   di
    71c0:	9a b9 62 ea 74       	call   0x74ea:0x62b9
    71c5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    71c8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    71cb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    71ce:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    71d2:	05 00 20             	add    ax,0x2000
    71d5:	50                   	push   ax
    71d6:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    71da:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    71de:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    71e2:	9a 5d 73 00 00       	call   0x0:0x735d
    71e7:	09 d0                	or     ax,dx
    71e9:	74 04                	je     0x71ef
    71eb:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    71ef:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    71f2:	c9                   	leave
    71f3:	ca 08 00             	retf   0x8
    71f6:	c8 02 00 00          	enter  0x2,0x0
    71fa:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    71fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7201:	26 8b 45 43          	mov    ax,WORD PTR es:[di+0x43]
    7205:	26 0b 45 45          	or     ax,WORD PTR es:[di+0x45]
    7209:	74 24                	je     0x722f
    720b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    720e:	06                   	push   es
    720f:	57                   	push   di
    7210:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7213:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7217:	06                   	push   es
    7218:	57                   	push   di
    7219:	26 c4 3d             	les    di,DWORD PTR es:[di]
    721c:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    7221:	08 c0                	or     al,al
    7223:	74 0a                	je     0x722f
    7225:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7228:	06                   	push   es
    7229:	57                   	push   di
    722a:	9a 11 79 99 72       	call   0x7299:0x7911
    722f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    7232:	c9                   	leave
    7233:	ca 08 00             	retf   0x8
    7236:	c8 14 00 00          	enter  0x14,0x0
    723a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    723e:	8d 7e ec             	lea    di,[bp-0x14]
    7241:	16                   	push   ss
    7242:	57                   	push   di
    7243:	6a 00                	push   0x0
    7245:	6a 00                	push   0x0
    7247:	6a 00                	push   0x0
    7249:	6a 01                	push   0x1
    724b:	9a ff ff 00 00       	call   0x0:0xffff
    7250:	09 c0                	or     ax,ax
    7252:	75 03                	jne    0x7257
    7254:	e9 a5 00             	jmp    0x72fc
    7257:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    725b:	83 7e ee 12          	cmp    WORD PTR [bp-0x12],0x12
    725f:	75 03                	jne    0x7264
    7261:	e9 90 00             	jmp    0x72f4
    7264:	c6 46 fe 00          	mov    BYTE PTR [bp-0x2],0x0
    7268:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    726b:	26 8b 45 6f          	mov    ax,WORD PTR es:[di+0x6f]
    726f:	09 c0                	or     ax,ax
    7271:	74 19                	je     0x728c
    7273:	8d 7e ec             	lea    di,[bp-0x14]
    7276:	16                   	push   ss
    7277:	57                   	push   di
    7278:	8d 7e fe             	lea    di,[bp-0x2]
    727b:	16                   	push   ss
    727c:	57                   	push   di
    727d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7280:	26 ff 75 73          	push   WORD PTR es:[di+0x73]
    7284:	26 ff 75 71          	push   WORD PTR es:[di+0x71]
    7288:	26 ff 5d 6d          	call   DWORD PTR es:[di+0x6d]
    728c:	8d 7e ec             	lea    di,[bp-0x14]
    728f:	16                   	push   ss
    7290:	57                   	push   di
    7291:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7294:	06                   	push   es
    7295:	57                   	push   di
    7296:	9a f6 71 b2 72       	call   0x72b2:0x71f6
    729b:	08 c0                	or     al,al
    729d:	75 53                	jne    0x72f2
    729f:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    72a3:	75 4d                	jne    0x72f2
    72a5:	8d 7e ec             	lea    di,[bp-0x14]
    72a8:	16                   	push   ss
    72a9:	57                   	push   di
    72aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72ad:	06                   	push   es
    72ae:	57                   	push   di
    72af:	9a 04 71 c5 72       	call   0x72c5:0x7104
    72b4:	08 c0                	or     al,al
    72b6:	75 3a                	jne    0x72f2
    72b8:	8d 7e ec             	lea    di,[bp-0x14]
    72bb:	16                   	push   ss
    72bc:	57                   	push   di
    72bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72c0:	06                   	push   es
    72c1:	57                   	push   di
    72c2:	9a 69 71 d8 72       	call   0x72d8:0x7169
    72c7:	08 c0                	or     al,al
    72c9:	75 27                	jne    0x72f2
    72cb:	8d 7e ec             	lea    di,[bp-0x14]
    72ce:	16                   	push   ss
    72cf:	57                   	push   di
    72d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72d3:	06                   	push   es
    72d4:	57                   	push   di
    72d5:	9a d4 70 0e 73       	call   0x730e:0x70d4
    72da:	08 c0                	or     al,al
    72dc:	75 14                	jne    0x72f2
    72de:	8d 7e ec             	lea    di,[bp-0x14]
    72e1:	16                   	push   ss
    72e2:	57                   	push   di
    72e3:	9a ff ff 00 00       	call   0x0:0xffff
    72e8:	8d 7e ec             	lea    di,[bp-0x14]
    72eb:	16                   	push   ss
    72ec:	57                   	push   di
    72ed:	9a ff ff 00 00       	call   0x0:0xffff
    72f2:	eb 08                	jmp    0x72fc
    72f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72f7:	26 c6 45 59 01       	mov    BYTE PTR es:[di+0x59],0x1
    72fc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    72ff:	c9                   	leave
    7300:	ca 04 00             	retf   0x4
    7303:	55                   	push   bp
    7304:	89 e5                	mov    bp,sp
    7306:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7309:	06                   	push   es
    730a:	57                   	push   di
    730b:	9a 36 72 25 73       	call   0x7325:0x7236
    7310:	08 c0                	or     al,al
    7312:	74 02                	je     0x7316
    7314:	eb f0                	jmp    0x7306
    7316:	c9                   	leave
    7317:	ca 04 00             	retf   0x4
    731a:	55                   	push   bp
    731b:	89 e5                	mov    bp,sp
    731d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7320:	06                   	push   es
    7321:	57                   	push   di
    7322:	9a 36 72 33 73       	call   0x7333:0x7236
    7327:	08 c0                	or     al,al
    7329:	75 0a                	jne    0x7335
    732b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    732e:	06                   	push   es
    732f:	57                   	push   di
    7330:	9a 1b 7e 64 74       	call   0x7464:0x7e1b
    7335:	c9                   	leave
    7336:	ca 04 00             	retf   0x4
    7339:	c8 04 00 00          	enter  0x4,0x0
    733d:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    7342:	75 1f                	jne    0x7363
    7344:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7347:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    734c:	74 13                	je     0x7361
    734e:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    7352:	68 20 0f             	push   0xf20
    7355:	6a 00                	push   0x0
    7357:	8d 7e 0a             	lea    di,[bp+0xa]
    735a:	16                   	push   ss
    735b:	57                   	push   di
    735c:	9a cb 73 00 00       	call   0x0:0x73cb
    7361:	eb 40                	jmp    0x73a3
    7363:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7366:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    736a:	06                   	push   es
    736b:	57                   	push   di
    736c:	9a a0 0d a1 73       	call   0x73a1:0xda0
    7371:	6a 08                	push   0x8
    7373:	9a 82 01 8d 73       	call   0x738d:0x182
    7378:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    737b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    737e:	8d 7e 0a             	lea    di,[bp+0xa]
    7381:	16                   	push   ss
    7382:	57                   	push   di
    7383:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7386:	06                   	push   es
    7387:	57                   	push   di
    7388:	6a 08                	push   0x8
    738a:	9a 1b 16 3b 74       	call   0x743b:0x161b
    738f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7392:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7395:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7398:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    739c:	06                   	push   es
    739d:	57                   	push   di
    739e:	9a 2b 0c ff 73       	call   0x73ff:0xc2b
    73a3:	c9                   	leave
    73a4:	ca 0c 00             	retf   0xc
    73a7:	c8 08 00 00          	enter  0x8,0x0
    73ab:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    73b0:	75 20                	jne    0x73d2
    73b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73b5:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
    73ba:	74 13                	je     0x73cf
    73bc:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    73c0:	68 20 0f             	push   0xf20
    73c3:	6a 01                	push   0x1
    73c5:	8d 7e 0a             	lea    di,[bp+0xa]
    73c8:	16                   	push   ss
    73c9:	57                   	push   di
    73ca:	9a 6c 75 00 00       	call   0x0:0x756c
    73cf:	e9 86 00             	jmp    0x7458
    73d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73d5:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    73d9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    73dd:	48                   	dec    ax
    73de:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    73e1:	31 c0                	xor    ax,ax
    73e3:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    73e6:	7f 70                	jg     0x7458
    73e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    73eb:	eb 03                	jmp    0x73f0
    73ed:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    73f0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    73f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73f6:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    73fa:	06                   	push   es
    73fb:	57                   	push   di
    73fc:	9a d0 0d 4c 74       	call   0x744c:0xdd0
    7401:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7404:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    7407:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    740a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    740d:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    7411:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    7414:	75 3a                	jne    0x7450
    7416:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7419:	75 35                	jne    0x7450
    741b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    741e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    7422:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    7426:	3b 56 10             	cmp    dx,WORD PTR [bp+0x10]
    7429:	75 25                	jne    0x7450
    742b:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    742e:	75 20                	jne    0x7450
    7430:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7433:	ff 76 fa             	push   WORD PTR [bp-0x6]
    7436:	6a 08                	push   0x8
    7438:	9a 9c 01 c9 74       	call   0x74c9:0x19c
    743d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7440:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7443:	26 c4 7d 5b          	les    di,DWORD PTR es:[di+0x5b]
    7447:	06                   	push   es
    7448:	57                   	push   di
    7449:	9a 94 0c 50 7a       	call   0x7a50:0xc94
    744e:	eb 08                	jmp    0x7458
    7450:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7453:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7456:	75 95                	jne    0x73ed
    7458:	c9                   	leave
    7459:	ca 0c 00             	retf   0xc
    745c:	01 00                	add    WORD PTR [bx+si],ax
    745e:	00 00                	add    BYTE PTR [bx+si],al
    7460:	00 00                	add    BYTE PTR [bx+si],al
    7462:	b5 74                	mov    ch,0x74
    7464:	08 75 c8             	or     BYTE PTR [di-0x38],dh
    7467:	04 00                	add    al,0x0
    7469:	00 c4                	add    ah,al
    746b:	7e 0e                	jle    0x747b
    746d:	06                   	push   es
    746e:	57                   	push   di
    746f:	26 ff 5d f4          	call   DWORD PTR es:[di-0xc]
    7473:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7476:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7479:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    747c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    747f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7482:	26 89 05             	mov    WORD PTR es:[di],ax
    7485:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    7489:	b8 5c 74             	mov    ax,0x745c
    748c:	0e                   	push   cs
    748d:	50                   	push   ax
    748e:	55                   	push   bp
    748f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7493:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7497:	ff 76 08             	push   WORD PTR [bp+0x8]
    749a:	ff 76 06             	push   WORD PTR [bp+0x6]
    749d:	31 c0                	xor    ax,ax
    749f:	50                   	push   ax
    74a0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    74a3:	06                   	push   es
    74a4:	57                   	push   di
    74a5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    74a8:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    74ac:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    74b0:	83 c4 06             	add    sp,0x6
    74b3:	eb 20                	jmp    0x74d5
    74b5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    74b8:	31 c0                	xor    ax,ax
    74ba:	26 89 05             	mov    WORD PTR es:[di],ax
    74bd:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    74c1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    74c4:	06                   	push   es
    74c5:	57                   	push   di
    74c6:	9a 7f 1f ce 74       	call   0x74ce:0x1f7f
    74cb:	ea 85 13 d3 74       	jmp    0x74d3:0x1385
    74d0:	9a 34 14 82 75       	call   0x7582:0x1434
    74d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74d8:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    74dc:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    74e0:	75 1b                	jne    0x74fd
    74e2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    74e5:	06                   	push   es
    74e6:	57                   	push   di
    74e7:	9a 86 62 33 77       	call   0x7733:0x6286
    74ec:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    74ef:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    74f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74f5:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    74f9:	26 89 55 22          	mov    WORD PTR es:[di+0x22],dx
    74fd:	c9                   	leave
    74fe:	ca 0c 00             	retf   0xc
    7501:	55                   	push   bp
    7502:	89 e5                	mov    bp,sp
    7504:	bf 1f 0e             	mov    di,0xe1f
    7507:	b8 29 75             	mov    ax,0x7529
    750a:	50                   	push   ax
    750b:	57                   	push   di
    750c:	9a 74 05 73 75       	call   0x7573:0x574
    7511:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7514:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    7518:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    751c:	74 21                	je     0x753f
    751e:	6a 01                	push   0x1
    7520:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    7524:	06                   	push   es
    7525:	57                   	push   di
    7526:	9a 19 2f 33 75       	call   0x7533:0x2f19
    752b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    752e:	06                   	push   es
    752f:	57                   	push   di
    7530:	9a 1a 73 d8 75       	call   0x75d8:0x731a
    7535:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7538:	26 80 7d 59 00       	cmp    BYTE PTR es:[di+0x59],0x0
    753d:	74 ec                	je     0x752b
    753f:	c9                   	leave
    7540:	ca 04 00             	retf   0x4
    7543:	55                   	push   bp
    7544:	89 e5                	mov    bp,sp
    7546:	6a 00                	push   0x0
    7548:	9a ff ff 00 00       	call   0x0:0xffff
    754d:	c9                   	leave
    754e:	ca 04 00             	retf   0x4
    7551:	55                   	push   bp
    7552:	89 e5                	mov    bp,sp
    7554:	9a 5e 75 00 00       	call   0x0:0x755e
    7559:	09 c0                	or     ax,ax
    755b:	74 13                	je     0x7570
    755d:	9a ff ff 00 00       	call   0x0:0xffff
    7562:	50                   	push   ax
    7563:	6a 1f                	push   0x1f
    7565:	6a 00                	push   0x0
    7567:	6a 00                	push   0x0
    7569:	6a 00                	push   0x0
    756b:	9a ff ff 00 00       	call   0x0:0xffff
    7570:	9a 30 26 7b 75       	call   0x757b:0x2630
    7575:	52                   	push   dx
    7576:	50                   	push   ax
    7577:	bf 2e 00             	mov    di,0x2e
    757a:	b8 8b 75             	mov    ax,0x758b
    757d:	50                   	push   ax
    757e:	57                   	push   di
    757f:	9a 55 22 9a 75       	call   0x759a:0x2255
    7584:	08 c0                	or     al,al
    7586:	74 54                	je     0x75dc
    7588:	9a 30 26 93 75       	call   0x7593:0x2630
    758d:	52                   	push   dx
    758e:	50                   	push   ax
    758f:	bf 58 00             	mov    di,0x58
    7592:	b8 b4 75             	mov    ax,0x75b4
    7595:	50                   	push   ax
    7596:	57                   	push   di
    7597:	9a 55 22 e2 77       	call   0x77e2:0x2255
    759c:	08 c0                	or     al,al
    759e:	75 3a                	jne    0x75da
    75a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75a3:	26 8b 45 67          	mov    ax,WORD PTR es:[di+0x67]
    75a7:	09 c0                	or     ax,ax
    75a9:	74 1e                	je     0x75c9
    75ab:	ff 76 0c             	push   WORD PTR [bp+0xc]
    75ae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    75b1:	9a 30 26 cc 75       	call   0x75cc:0x2630
    75b6:	52                   	push   dx
    75b7:	50                   	push   ax
    75b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75bb:	26 ff 75 6b          	push   WORD PTR es:[di+0x6b]
    75bf:	26 ff 75 69          	push   WORD PTR es:[di+0x69]
    75c3:	26 ff 5d 65          	call   DWORD PTR es:[di+0x65]
    75c7:	eb 11                	jmp    0x75da
    75c9:	9a 30 26 df 75       	call   0x75df:0x2630
    75ce:	52                   	push   dx
    75cf:	50                   	push   ax
    75d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75d3:	06                   	push   es
    75d4:	57                   	push   di
    75d5:	9a 65 76 f7 75       	call   0x75f7:0x7665
    75da:	eb 13                	jmp    0x75ef
    75dc:	9a 30 26 e6 75       	call   0x75e6:0x2630
    75e1:	52                   	push   dx
    75e2:	50                   	push   ax
    75e3:	9a 44 26 ed 75       	call   0x75ed:0x2644
    75e8:	52                   	push   dx
    75e9:	50                   	push   ax
    75ea:	9a 00 27 83 76       	call   0x7683:0x2700
    75ef:	c9                   	leave
    75f0:	ca 08 00             	retf   0x8
    75f3:	00 00                	add    BYTE PTR [bx+si],al
    75f5:	4a                   	dec    dx
    75f6:	76 0a                	jbe    0x7602
    75f8:	76 c8                	jbe    0x75c2
    75fa:	08 00                	or     BYTE PTR [bx+si],al
    75fc:	00 9a ff ff          	add    BYTE PTR [bp+si-0x1],bl
    7600:	00 00                	add    BYTE PTR [bx+si],al
    7602:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7605:	6a 00                	push   0x0
    7607:	9a e7 0e 53 76       	call   0x7653:0xee7
    760c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    760f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7612:	b8 f3 75             	mov    ax,0x75f3
    7615:	0e                   	push   cs
    7616:	50                   	push   ax
    7617:	55                   	push   bp
    7618:	ff 36 58 18          	push   WORD PTR ds:0x1858
    761c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7623:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    7627:	ff 76 12             	push   WORD PTR [bp+0x12]
    762a:	ff 76 10             	push   WORD PTR [bp+0x10]
    762d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7630:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7633:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7636:	9a ff ff 00 00       	call   0x0:0xffff
    763b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    763e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7642:	83 c4 06             	add    sp,0x6
    7645:	b8 5e 76             	mov    ax,0x765e
    7648:	0e                   	push   cs
    7649:	50                   	push   ax
    764a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    764d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    7650:	9a f0 0f 7c 76       	call   0x767c:0xff0
    7655:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7658:	9a ff ff 00 00       	call   0x0:0xffff
    765d:	cb                   	retf
    765e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7661:	c9                   	leave
    7662:	ca 0e 00             	retf   0xe
    7665:	c8 42 02 00          	enter  0x242,0x0
    7669:	8d 7e c0             	lea    di,[bp-0x40]
    766c:	16                   	push   ss
    766d:	57                   	push   di
    766e:	8d be be fd          	lea    di,[bp-0x242]
    7672:	16                   	push   ss
    7673:	57                   	push   di
    7674:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7677:	06                   	push   es
    7678:	57                   	push   di
    7679:	9a 38 70 c1 76       	call   0x76c1:0x7038
    767e:	6a 3f                	push   0x3f
    7680:	9a 6a 0d 99 76       	call   0x7699:0xd6a
    7685:	8d be be fe          	lea    di,[bp-0x142]
    7689:	16                   	push   ss
    768a:	57                   	push   di
    768b:	8d be be fd          	lea    di,[bp-0x242]
    768f:	16                   	push   ss
    7690:	57                   	push   di
    7691:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7694:	06                   	push   es
    7695:	57                   	push   di
    7696:	9a e6 29 9e 76       	call   0x769e:0x29e6
    769b:	9a 4c 0d aa 76       	call   0x76aa:0xd4c
    76a0:	52                   	push   dx
    76a1:	50                   	push   ax
    76a2:	bf d0 16             	mov    di,0x16d0
    76a5:	1e                   	push   ds
    76a6:	57                   	push   di
    76a7:	9a 8f 0d 4f 77       	call   0x774f:0xd8f
    76ac:	8d be be fe          	lea    di,[bp-0x142]
    76b0:	16                   	push   ss
    76b1:	57                   	push   di
    76b2:	8d 7e c0             	lea    di,[bp-0x40]
    76b5:	16                   	push   ss
    76b6:	57                   	push   di
    76b7:	6a 10                	push   0x10
    76b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76bc:	06                   	push   es
    76bd:	57                   	push   di
    76be:	9a f9 75 a6 77       	call   0x77a6:0x75f9
    76c3:	c9                   	leave
    76c4:	ca 08 00             	retf   0x8
    76c7:	c8 06 01 00          	enter  0x106,0x0
    76cb:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    76cf:	c6 86 fd fe 01       	mov    BYTE PTR [bp-0x103],0x1
    76d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76d7:	26 8b 45 77          	mov    ax,WORD PTR es:[di+0x77]
    76db:	09 c0                	or     ax,ax
    76dd:	74 21                	je     0x7700
    76df:	ff 76 0e             	push   WORD PTR [bp+0xe]
    76e2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    76e5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    76e8:	8d be fd fe          	lea    di,[bp-0x103]
    76ec:	16                   	push   ss
    76ed:	57                   	push   di
    76ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76f1:	26 ff 75 7b          	push   WORD PTR es:[di+0x7b]
    76f5:	26 ff 75 79          	push   WORD PTR es:[di+0x79]
    76f9:	26 ff 5d 75          	call   DWORD PTR es:[di+0x75]
    76fd:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    7700:	80 be fd fe 00       	cmp    BYTE PTR [bp-0x103],0x0
    7705:	75 03                	jne    0x770a
    7707:	e9 81 00             	jmp    0x778b
    770a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    770d:	26 c4 7d 28          	les    di,DWORD PTR es:[di+0x28]
    7711:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    7715:	74 55                	je     0x776c
    7717:	31 c0                	xor    ax,ax
    7719:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    771d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7720:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    7724:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    7728:	74 0f                	je     0x7739
    772a:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    772e:	06                   	push   es
    772f:	57                   	push   di
    7730:	9a b9 62 1e 78       	call   0x781e:0x62b9
    7735:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    7739:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    773d:	8d be fe fe          	lea    di,[bp-0x102]
    7741:	16                   	push   ss
    7742:	57                   	push   di
    7743:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7746:	26 c4 7d 28          	les    di,DWORD PTR es:[di+0x28]
    774a:	06                   	push   es
    774b:	57                   	push   di
    774c:	9a 4c 0d a6 7b       	call   0x7ba6:0xd4c
    7751:	52                   	push   dx
    7752:	50                   	push   ax
    7753:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7756:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7759:	ff 76 0a             	push   WORD PTR [bp+0xa]
    775c:	9a ff ff 00 00       	call   0x0:0xffff
    7761:	f7 d8                	neg    ax
    7763:	18 c0                	sbb    al,al
    7765:	f6 d8                	neg    al
    7767:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    776a:	eb 1f                	jmp    0x778b
    776c:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    7771:	75 18                	jne    0x778b
    7773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7776:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    777a:	68 1f 0f             	push   0xf1f
    777d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7780:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7783:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7786:	9a ff ff 00 00       	call   0x0:0xffff
    778b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    778e:	c9                   	leave
    778f:	ca 0a 00             	retf   0xa
    7792:	c8 02 00 00          	enter  0x2,0x0
    7796:	6a 01                	push   0x1
    7798:	ff 76 0c             	push   WORD PTR [bp+0xc]
    779b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    779e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77a1:	06                   	push   es
    77a2:	57                   	push   di
    77a3:	9a c7 76 c7 77       	call   0x77c7:0x76c7
    77a8:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    77ab:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    77ae:	c9                   	leave
    77af:	ca 08 00             	retf   0x8
    77b2:	c8 02 00 00          	enter  0x2,0x0
    77b6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    77b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    77bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    77bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c2:	06                   	push   es
    77c3:	57                   	push   di
    77c4:	9a c7 76 92 78       	call   0x7892:0x76c7
    77c9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    77cc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    77cf:	c9                   	leave
    77d0:	ca 0a 00             	retf   0xa
    77d3:	c8 00 01 00          	enter  0x100,0x0
    77d7:	8d be 00 ff          	lea    di,[bp-0x100]
    77db:	16                   	push   ss
    77dc:	57                   	push   di
    77dd:	6a 00                	push   0x0
    77df:	9a e6 0d ef 77       	call   0x77ef:0xde6
    77e4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    77e7:	06                   	push   es
    77e8:	57                   	push   di
    77e9:	68 ff 00             	push   0xff
    77ec:	9a e7 17 fe 78       	call   0x78fe:0x17e7
    77f1:	c9                   	leave
    77f2:	ca 04 00             	retf   0x4
    77f5:	c8 08 00 00          	enter  0x8,0x0
    77f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77fc:	26 8b 45 43          	mov    ax,WORD PTR es:[di+0x43]
    7800:	26 0b 45 45          	or     ax,WORD PTR es:[di+0x45]
    7804:	75 03                	jne    0x7809
    7806:	e9 8b 00             	jmp    0x7894
    7809:	8d 7e fc             	lea    di,[bp-0x4]
    780c:	16                   	push   ss
    780d:	57                   	push   di
    780e:	9a 25 7e 00 00       	call   0x0:0x7e25
    7813:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7816:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7819:	6a 01                	push   0x1
    781b:	9a 92 0e ee 78       	call   0x78ee:0xe92
    7820:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7823:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7826:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7829:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    782c:	74 12                	je     0x7840
    782e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7831:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    7836:	74 08                	je     0x7840
    7838:	31 c0                	xor    ax,ax
    783a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    783d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7840:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7843:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    7846:	74 2a                	je     0x7872
    7848:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    784b:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7850:	75 20                	jne    0x7872
    7852:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7855:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7859:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    785d:	74 13                	je     0x7872
    785f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7862:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7866:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    786a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    786d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7870:	eb ce                	jmp    0x7840
    7872:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7875:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7878:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    787b:	26 3b 55 37          	cmp    dx,WORD PTR es:[di+0x37]
    787f:	75 13                	jne    0x7894
    7881:	26 3b 45 35          	cmp    ax,WORD PTR es:[di+0x35]
    7885:	75 0d                	jne    0x7894
    7887:	ff 76 fe             	push   WORD PTR [bp-0x2]
    788a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    788d:	06                   	push   es
    788e:	57                   	push   di
    788f:	9a 77 79 9c 78       	call   0x789c:0x7977
    7894:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7897:	06                   	push   es
    7898:	57                   	push   di
    7899:	9a c6 7c 2a 79       	call   0x792a:0x7cc6
    789e:	c9                   	leave
    789f:	ca 04 00             	retf   0x4
    78a2:	55                   	push   bp
    78a3:	89 e5                	mov    bp,sp
    78a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78a8:	26 8a 45 47          	mov    al,BYTE PTR es:[di+0x47]
    78ac:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    78af:	74 5c                	je     0x790d
    78b1:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    78b4:	26 88 45 47          	mov    BYTE PTR es:[di+0x47],al
    78b8:	26 80 7d 47 00       	cmp    BYTE PTR es:[di+0x47],0x0
    78bd:	74 33                	je     0x78f2
    78bf:	ff 76 08             	push   WORD PTR [bp+0x8]
    78c2:	ff 76 06             	push   WORD PTR [bp+0x6]
    78c5:	b0 01                	mov    al,0x1
    78c7:	50                   	push   ax
    78c8:	c4 3e 2e 15          	les    di,DWORD PTR ds:0x152e
    78cc:	06                   	push   es
    78cd:	57                   	push   di
    78ce:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    78d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78d5:	26 89 45 43          	mov    WORD PTR es:[di+0x43],ax
    78d9:	26 89 55 45          	mov    WORD PTR es:[di+0x45],dx
    78dd:	26 ff 75 33          	push   WORD PTR es:[di+0x33]
    78e1:	26 ff 75 31          	push   WORD PTR es:[di+0x31]
    78e5:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    78e9:	06                   	push   es
    78ea:	57                   	push   di
    78eb:	9a d5 1e 49 79       	call   0x7949:0x1ed5
    78f0:	eb 1b                	jmp    0x790d
    78f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78f5:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    78f9:	06                   	push   es
    78fa:	57                   	push   di
    78fb:	9a 7f 1f 04 7a       	call   0x7a04:0x1f7f
    7900:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7903:	31 c0                	xor    ax,ax
    7905:	26 89 45 43          	mov    WORD PTR es:[di+0x43],ax
    7909:	26 89 45 45          	mov    WORD PTR es:[di+0x45],ax
    790d:	c9                   	leave
    790e:	ca 06 00             	retf   0x6
    7911:	55                   	push   bp
    7912:	89 e5                	mov    bp,sp
    7914:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7917:	26 80 7d 47 00       	cmp    BYTE PTR es:[di+0x47],0x0
    791c:	74 55                	je     0x7973
    791e:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7923:	74 07                	je     0x792c
    7925:	06                   	push   es
    7926:	57                   	push   di
    7927:	9a c6 7c d0 79       	call   0x79d0:0x7cc6
    792c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    792f:	31 c0                	xor    ax,ax
    7931:	26 89 45 35          	mov    WORD PTR es:[di+0x35],ax
    7935:	26 89 45 37          	mov    WORD PTR es:[di+0x37],ax
    7939:	26 c6 45 30 00       	mov    BYTE PTR es:[di+0x30],0x0
    793e:	6a 00                	push   0x0
    7940:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7944:	06                   	push   es
    7945:	57                   	push   di
    7946:	9a 77 1c 57 79       	call   0x7957:0x1c77
    794b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    794e:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7952:	06                   	push   es
    7953:	57                   	push   di
    7954:	9a fa 64 69 79       	call   0x7969:0x64fa
    7959:	08 c0                	or     al,al
    795b:	74 16                	je     0x7973
    795d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7960:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7964:	06                   	push   es
    7965:	57                   	push   di
    7966:	9a b9 62 f8 79       	call   0x79f8:0x62b9
    796b:	50                   	push   ax
    796c:	6a 00                	push   0x0
    796e:	9a 8a 7d 00 00       	call   0x0:0x7d8a
    7973:	c9                   	leave
    7974:	ca 04 00             	retf   0x4
    7977:	c8 30 04 00          	enter  0x430,0x0
    797b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    797e:	26 80 7d 47 00       	cmp    BYTE PTR es:[di+0x47],0x0
    7983:	75 03                	jne    0x7988
    7985:	e9 d9 02             	jmp    0x7c61
    7988:	26 8b 45 35          	mov    ax,WORD PTR es:[di+0x35]
    798c:	26 0b 45 37          	or     ax,WORD PTR es:[di+0x37]
    7990:	75 03                	jne    0x7995
    7992:	e9 cc 02             	jmp    0x7c61
    7995:	26 8b 45 35          	mov    ax,WORD PTR es:[di+0x35]
    7999:	26 8b 55 37          	mov    dx,WORD PTR es:[di+0x37]
    799d:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    79a0:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    79a3:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    79a7:	06                   	push   es
    79a8:	57                   	push   di
    79a9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    79ac:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    79b0:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    79b3:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    79b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79b9:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    79bd:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    79c1:	05 06 00             	add    ax,0x6
    79c4:	01 46 e4             	add    WORD PTR [bp-0x1c],ax
    79c7:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    79cb:	06                   	push   es
    79cc:	57                   	push   di
    79cd:	9a ba 60 5f 7c       	call   0x7c5f:0x60ba
    79d2:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    79d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79d8:	26 8b 45 31          	mov    ax,WORD PTR es:[di+0x31]
    79dc:	26 8b 55 33          	mov    dx,WORD PTR es:[di+0x33]
    79e0:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    79e3:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    79e6:	8d be c8 fd          	lea    di,[bp-0x238]
    79ea:	16                   	push   ss
    79eb:	57                   	push   di
    79ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79ef:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    79f3:	06                   	push   es
    79f4:	57                   	push   di
    79f5:	9a 03 18 82 7a       	call   0x7a82:0x1803
    79fa:	8d 7e ec             	lea    di,[bp-0x14]
    79fd:	16                   	push   ss
    79fe:	57                   	push   di
    79ff:	6a 08                	push   0x8
    7a01:	9a 1b 16 0e 7b       	call   0x7b0e:0x161b
    7a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a09:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    7a0d:	06                   	push   es
    7a0e:	57                   	push   di
    7a0f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a12:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    7a16:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7a19:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7a1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a1f:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    7a23:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7a27:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    7a2b:	74 1c                	je     0x7a49
    7a2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a30:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    7a34:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7a38:	06                   	push   es
    7a39:	57                   	push   di
    7a3a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a3d:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    7a41:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7a44:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7a47:	eb 0f                	jmp    0x7a58
    7a49:	6a 00                	push   0x0
    7a4b:	6a 00                	push   0x0
    7a4d:	9a 6e 06 74 7b       	call   0x7b74:0x66e
    7a52:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7a55:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7a58:	8d 7e ec             	lea    di,[bp-0x14]
    7a5b:	16                   	push   ss
    7a5c:	57                   	push   di
    7a5d:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7a60:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    7a63:	50                   	push   ax
    7a64:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7a67:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    7a6a:	50                   	push   ax
    7a6b:	9a c7 7b 00 00       	call   0x0:0x7bc7
    7a70:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7a73:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7a76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a79:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    7a7d:	06                   	push   es
    7a7e:	57                   	push   di
    7a7f:	9a 06 1a ac 7a       	call   0x7aac:0x1a06
    7a84:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    7a87:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    7a8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a8d:	26 8b 45 35          	mov    ax,WORD PTR es:[di+0x35]
    7a91:	26 8b 55 37          	mov    dx,WORD PTR es:[di+0x37]
    7a95:	89 86 d0 fd          	mov    WORD PTR [bp-0x230],ax
    7a99:	89 96 d2 fd          	mov    WORD PTR [bp-0x22e],dx
    7a9d:	8d be d0 fc          	lea    di,[bp-0x330]
    7aa1:	16                   	push   ss
    7aa2:	57                   	push   di
    7aa3:	c4 be d0 fd          	les    di,DWORD PTR [bp-0x230]
    7aa7:	06                   	push   es
    7aa8:	57                   	push   di
    7aa9:	9a e5 1f fb 7a       	call   0x7afb:0x1fe5
    7aae:	83 c4 04             	add    sp,0x4
    7ab1:	80 be d0 fc 00       	cmp    BYTE PTR [bp-0x330],0x0
    7ab6:	75 24                	jne    0x7adc
    7ab8:	c4 be d0 fd          	les    di,DWORD PTR [bp-0x230]
    7abc:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7ac0:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    7ac4:	74 16                	je     0x7adc
    7ac6:	c4 be d0 fd          	les    di,DWORD PTR [bp-0x230]
    7aca:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7ace:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    7ad2:	89 86 d0 fd          	mov    WORD PTR [bp-0x230],ax
    7ad6:	89 96 d2 fd          	mov    WORD PTR [bp-0x22e],dx
    7ada:	eb c1                	jmp    0x7a9d
    7adc:	8b 86 d0 fd          	mov    ax,WORD PTR [bp-0x230]
    7ae0:	0b 86 d2 fd          	or     ax,WORD PTR [bp-0x22e]
    7ae4:	74 2c                	je     0x7b12
    7ae6:	8d be d0 fb          	lea    di,[bp-0x430]
    7aea:	16                   	push   ss
    7aeb:	57                   	push   di
    7aec:	8d be d0 fc          	lea    di,[bp-0x330]
    7af0:	16                   	push   ss
    7af1:	57                   	push   di
    7af2:	c4 be d0 fd          	les    di,DWORD PTR [bp-0x230]
    7af6:	06                   	push   es
    7af7:	57                   	push   di
    7af8:	9a e5 1f 00 7b       	call   0x7b00:0x1fe5
    7afd:	9a ae 0c e7 7b       	call   0x7be7:0xcae
    7b02:	8d be de fe          	lea    di,[bp-0x122]
    7b06:	16                   	push   ss
    7b07:	57                   	push   di
    7b08:	68 ff 00             	push   0xff
    7b0b:	9a e7 17 81 7b       	call   0x7b81:0x17e7
    7b10:	eb 05                	jmp    0x7b17
    7b12:	c6 86 de fe 00       	mov    BYTE PTR [bp-0x122],0x0
    7b17:	c6 86 dd fe 01       	mov    BYTE PTR [bp-0x123],0x1
    7b1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b1f:	26 8b 85 9f 00       	mov    ax,WORD PTR es:[di+0x9f]
    7b24:	09 c0                	or     ax,ax
    7b26:	74 26                	je     0x7b4e
    7b28:	8d be de fe          	lea    di,[bp-0x122]
    7b2c:	16                   	push   ss
    7b2d:	57                   	push   di
    7b2e:	68 ff 00             	push   0xff
    7b31:	8d be dd fe          	lea    di,[bp-0x123]
    7b35:	16                   	push   ss
    7b36:	57                   	push   di
    7b37:	8d 7e de             	lea    di,[bp-0x22]
    7b3a:	16                   	push   ss
    7b3b:	57                   	push   di
    7b3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b3f:	26 ff b5 a3 00       	push   WORD PTR es:[di+0xa3]
    7b44:	26 ff b5 a1 00       	push   WORD PTR es:[di+0xa1]
    7b49:	26 ff 9d 9d 00       	call   DWORD PTR es:[di+0x9d]
    7b4e:	80 be dd fe 00       	cmp    BYTE PTR [bp-0x123],0x0
    7b53:	75 03                	jne    0x7b58
    7b55:	e9 f0 00             	jmp    0x7c48
    7b58:	80 be de fe 00       	cmp    BYTE PTR [bp-0x122],0x0
    7b5d:	77 03                	ja     0x7b62
    7b5f:	e9 e6 00             	jmp    0x7c48
    7b62:	8d be c8 fd          	lea    di,[bp-0x238]
    7b66:	16                   	push   ss
    7b67:	57                   	push   di
    7b68:	6a 00                	push   0x0
    7b6a:	6a 00                	push   0x0
    7b6c:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    7b6f:	6a 00                	push   0x0
    7b71:	9a ae 06 ff ff       	call   0xffff:0x6ae
    7b76:	8d be d4 fe          	lea    di,[bp-0x12c]
    7b7a:	16                   	push   ss
    7b7b:	57                   	push   di
    7b7c:	6a 08                	push   0x8
    7b7e:	9a 1b 16 c0 7c       	call   0x7cc0:0x161b
    7b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b86:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7b8a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7b8f:	06                   	push   es
    7b90:	57                   	push   di
    7b91:	9a d2 21 ff ff       	call   0xffff:0x21d2
    7b96:	50                   	push   ax
    7b97:	8d be d4 fd          	lea    di,[bp-0x22c]
    7b9b:	16                   	push   ss
    7b9c:	57                   	push   di
    7b9d:	8d be de fe          	lea    di,[bp-0x122]
    7ba1:	16                   	push   ss
    7ba2:	57                   	push   di
    7ba3:	9a 4c 0d a9 7c       	call   0x7ca9:0xd4c
    7ba8:	52                   	push   dx
    7ba9:	50                   	push   ax
    7baa:	6a ff                	push   0xffff
    7bac:	8d be d4 fe          	lea    di,[bp-0x12c]
    7bb0:	16                   	push   ss
    7bb1:	57                   	push   di
    7bb2:	68 10 0c             	push   0xc10
    7bb5:	9a ff ff 00 00       	call   0x0:0xffff
    7bba:	8d be d4 fe          	lea    di,[bp-0x12c]
    7bbe:	16                   	push   ss
    7bbf:	57                   	push   di
    7bc0:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    7bc3:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    7bc6:	9a ff ff 00 00       	call   0x0:0xffff
    7bcb:	83 86 d8 fe 06       	add    WORD PTR [bp-0x128],0x6
    7bd0:	83 86 da fe 02       	add    WORD PTR [bp-0x126],0x2
    7bd5:	ff 76 ee             	push   WORD PTR [bp-0x12]
    7bd8:	ff 76 ec             	push   WORD PTR [bp-0x14]
    7bdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bde:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    7be2:	06                   	push   es
    7be3:	57                   	push   di
    7be4:	9a d4 19 03 7c       	call   0x7c03:0x19d4
    7be9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bec:	26 89 45 39          	mov    WORD PTR es:[di+0x39],ax
    7bf0:	26 89 55 3b          	mov    WORD PTR es:[di+0x3b],dx
    7bf4:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7bf7:	ff 76 f0             	push   WORD PTR [bp-0x10]
    7bfa:	26 c4 7d 35          	les    di,DWORD PTR es:[di+0x35]
    7bfe:	06                   	push   es
    7bff:	57                   	push   di
    7c00:	9a d4 19 1f 7c       	call   0x7c1f:0x19d4
    7c05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c08:	26 89 45 3d          	mov    WORD PTR es:[di+0x3d],ax
    7c0c:	26 89 55 3f          	mov    WORD PTR es:[di+0x3f],dx
    7c10:	ff 76 ea             	push   WORD PTR [bp-0x16]
    7c13:	ff 76 e8             	push   WORD PTR [bp-0x18]
    7c16:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7c1a:	06                   	push   es
    7c1b:	57                   	push   di
    7c1c:	9a d5 1e b2 7c       	call   0x7cb2:0x1ed5
    7c21:	8d be d4 fe          	lea    di,[bp-0x12c]
    7c25:	16                   	push   ss
    7c26:	57                   	push   di
    7c27:	8d be de fe          	lea    di,[bp-0x122]
    7c2b:	16                   	push   ss
    7c2c:	57                   	push   di
    7c2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c30:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7c34:	06                   	push   es
    7c35:	57                   	push   di
    7c36:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7c39:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    7c3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c41:	26 c6 45 30 01       	mov    BYTE PTR es:[di+0x30],0x1
    7c46:	eb 0f                	jmp    0x7c57
    7c48:	80 be dd fe 00       	cmp    BYTE PTR [bp-0x123],0x0
    7c4d:	75 08                	jne    0x7c57
    7c4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c52:	26 c6 45 30 00       	mov    BYTE PTR es:[di+0x30],0x0
    7c57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c5a:	06                   	push   es
    7c5b:	57                   	push   di
    7c5c:	9a c6 7c 78 7c       	call   0x7c78:0x7cc6
    7c61:	c9                   	leave
    7c62:	ca 08 00             	retf   0x8
    7c65:	c8 00 01 00          	enter  0x100,0x0
    7c69:	6a 00                	push   0x0
    7c6b:	6a 01                	push   0x1
    7c6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c70:	26 ff 75 41          	push   WORD PTR es:[di+0x41]
    7c74:	bf 2d 64             	mov    di,0x642d
    7c77:	b8 b2 7d             	mov    ax,0x7db2
    7c7a:	50                   	push   ax
    7c7b:	57                   	push   di
    7c7c:	9a ff ff 00 00       	call   0x0:0xffff
    7c81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c84:	26 89 45 49          	mov    WORD PTR es:[di+0x49],ax
    7c88:	26 83 7d 49 00       	cmp    WORD PTR es:[di+0x49],0x0
    7c8d:	b0 00                	mov    al,0x0
    7c8f:	76 01                	jbe    0x7c92
    7c91:	40                   	inc    ax
    7c92:	26 88 45 48          	mov    BYTE PTR es:[di+0x48],al
    7c96:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7c9b:	75 25                	jne    0x7cc2
    7c9d:	8d be 00 ff          	lea    di,[bp-0x100]
    7ca1:	16                   	push   ss
    7ca2:	57                   	push   di
    7ca3:	68 32 f0             	push   0xf032
    7ca6:	9a 2b 09 b9 7c       	call   0x7cb9:0x92b
    7cab:	b0 01                	mov    al,0x1
    7cad:	50                   	push   ax
    7cae:	b8 22 00             	mov    ax,0x22
    7cb1:	ba 6c 7d             	mov    dx,0x7d6c
    7cb4:	52                   	push   dx
    7cb5:	50                   	push   ax
    7cb6:	9a e6 28 98 80       	call   0x8098:0x28e6
    7cbb:	52                   	push   dx
    7cbc:	50                   	push   ax
    7cbd:	9a 99 13 b2 80       	call   0x80b2:0x1399
    7cc2:	c9                   	leave
    7cc3:	ca 04 00             	retf   0x4
    7cc6:	55                   	push   bp
    7cc7:	89 e5                	mov    bp,sp
    7cc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ccc:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7cd1:	74 13                	je     0x7ce6
    7cd3:	6a 00                	push   0x0
    7cd5:	26 ff 75 49          	push   WORD PTR es:[di+0x49]
    7cd9:	9a ff ff 00 00       	call   0x0:0xffff
    7cde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ce1:	26 c6 45 48 00       	mov    BYTE PTR es:[di+0x48],0x0
    7ce6:	c9                   	leave
    7ce7:	ca 04 00             	retf   0x4
    7cea:	c8 04 00 00          	enter  0x4,0x0
    7cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cf1:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7cf5:	26 8b 55 26          	mov    dx,WORD PTR es:[di+0x26]
    7cf9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7cfc:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7cff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7d02:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7d07:	75 20                	jne    0x7d29
    7d09:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7d0c:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7d10:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    7d14:	74 13                	je     0x7d29
    7d16:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7d19:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7d1d:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    7d21:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7d24:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7d27:	eb d6                	jmp    0x7cff
    7d29:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7d2c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d32:	26 3b 55 37          	cmp    dx,WORD PTR es:[di+0x37]
    7d36:	75 1e                	jne    0x7d56
    7d38:	26 3b 45 35          	cmp    ax,WORD PTR es:[di+0x35]
    7d3c:	75 18                	jne    0x7d56
    7d3e:	81 c7 39 00          	add    di,0x39
    7d42:	06                   	push   es
    7d43:	57                   	push   di
    7d44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7d47:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7d4a:	9a ff ff 00 00       	call   0x0:0xffff
    7d4f:	09 c0                	or     ax,ax
    7d51:	74 03                	je     0x7d56
    7d53:	e9 c0 00             	jmp    0x7e16
    7d56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d59:	26 8b 45 43          	mov    ax,WORD PTR es:[di+0x43]
    7d5d:	26 0b 45 45          	or     ax,WORD PTR es:[di+0x45]
    7d61:	74 2b                	je     0x7d8e
    7d63:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7d67:	06                   	push   es
    7d68:	57                   	push   di
    7d69:	9a b9 62 84 7d       	call   0x7d84:0x62b9
    7d6e:	50                   	push   ax
    7d6f:	9a ff ff 00 00       	call   0x0:0xffff
    7d74:	09 c0                	or     ax,ax
    7d76:	74 16                	je     0x7d8e
    7d78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d7b:	26 c4 7d 43          	les    di,DWORD PTR es:[di+0x43]
    7d7f:	06                   	push   es
    7d80:	57                   	push   di
    7d81:	9a b9 62 34 7e       	call   0x7e34:0x62b9
    7d86:	50                   	push   ax
    7d87:	6a 00                	push   0x0
    7d89:	9a ff ff 00 00       	call   0x0:0xffff
    7d8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d91:	26 80 7d 30 00       	cmp    BYTE PTR es:[di+0x30],0x0
    7d96:	74 1e                	je     0x7db6
    7d98:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7d9b:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    7d9e:	74 0a                	je     0x7daa
    7da0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7da3:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7da8:	75 0c                	jne    0x7db6
    7daa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dad:	06                   	push   es
    7dae:	57                   	push   di
    7daf:	9a 11 79 eb 7d       	call   0x7deb:0x7911
    7db4:	eb 60                	jmp    0x7e16
    7db6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7db9:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    7dbc:	74 4b                	je     0x7e09
    7dbe:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7dc1:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7dc6:	74 41                	je     0x7e09
    7dc8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7dcb:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7dce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dd1:	26 89 45 35          	mov    WORD PTR es:[di+0x35],ax
    7dd5:	26 89 55 37          	mov    WORD PTR es:[di+0x37],dx
    7dd9:	26 80 7d 30 00       	cmp    BYTE PTR es:[di+0x30],0x0
    7dde:	74 0f                	je     0x7def
    7de0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7de3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7de6:	06                   	push   es
    7de7:	57                   	push   di
    7de8:	9a 77 79 05 7e       	call   0x7e05:0x7977
    7ded:	eb 18                	jmp    0x7e07
    7def:	e8 0a 94             	call   0x11fc
    7df2:	08 c0                	or     al,al
    7df4:	74 11                	je     0x7e07
    7df6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7df9:	26 80 7d 48 00       	cmp    BYTE PTR es:[di+0x48],0x0
    7dfe:	75 07                	jne    0x7e07
    7e00:	06                   	push   es
    7e01:	57                   	push   di
    7e02:	9a 65 7c 32 7f       	call   0x7f32:0x7c65
    7e07:	eb 0d                	jmp    0x7e16
    7e09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e0c:	31 c0                	xor    ax,ax
    7e0e:	26 89 45 35          	mov    WORD PTR es:[di+0x35],ax
    7e12:	26 89 45 37          	mov    WORD PTR es:[di+0x37],ax
    7e16:	c9                   	leave
    7e17:	ca 08 00             	retf   0x8
    7e1a:	00 c8                	add    al,cl
    7e1c:	0e                   	push   cs
    7e1d:	02 00                	add    al,BYTE PTR [bx+si]
    7e1f:	8d 7e fc             	lea    di,[bp-0x4]
    7e22:	16                   	push   ss
    7e23:	57                   	push   di
    7e24:	9a ff ff 00 00       	call   0x0:0xffff
    7e29:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7e2c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7e2f:	6a 01                	push   0x1
    7e31:	9a 92 0e 59 7e       	call   0x7e59:0xe92
    7e36:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7e39:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7e3c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7e3f:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    7e42:	74 12                	je     0x7e56
    7e44:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7e47:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    7e4c:	74 08                	je     0x7e56
    7e4e:	31 c0                	xor    ax,ax
    7e50:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7e53:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7e56:	9a 61 0d c0 7e       	call   0x7ec0:0xd61
    7e5b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    7e5e:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    7e61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e64:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7e68:	26 8b 55 26          	mov    dx,WORD PTR es:[di+0x26]
    7e6c:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    7e6f:	75 08                	jne    0x7e79
    7e71:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7e74:	75 03                	jne    0x7e79
    7e76:	e9 a0 00             	jmp    0x7f19
    7e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e7c:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7e80:	26 0b 45 26          	or     ax,WORD PTR es:[di+0x26]
    7e84:	74 08                	je     0x7e8e
    7e86:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7e89:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    7e8c:	74 1d                	je     0x7eab
    7e8e:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7e91:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    7e94:	74 2c                	je     0x7ec2
    7e96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e99:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7e9d:	26 8b 55 26          	mov    dx,WORD PTR es:[di+0x26]
    7ea1:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    7ea4:	75 1c                	jne    0x7ec2
    7ea6:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    7ea9:	75 17                	jne    0x7ec2
    7eab:	68 14 0f             	push   0xf14
    7eae:	6a 00                	push   0x0
    7eb0:	6a 00                	push   0x0
    7eb2:	6a 00                	push   0x0
    7eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7eb7:	26 c4 7d 24          	les    di,DWORD PTR es:[di+0x24]
    7ebb:	06                   	push   es
    7ebc:	57                   	push   di
    7ebd:	9a bb 24 17 7f       	call   0x7f17:0x24bb
    7ec2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7ec5:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ecb:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    7ecf:	26 89 55 26          	mov    WORD PTR es:[di+0x26],dx
    7ed3:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7ed7:	26 0b 45 26          	or     ax,WORD PTR es:[di+0x26]
    7edb:	74 08                	je     0x7ee5
    7edd:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7ee0:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    7ee3:	74 1d                	je     0x7f02
    7ee5:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7ee8:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    7eeb:	74 2c                	je     0x7f19
    7eed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ef0:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7ef4:	26 8b 55 26          	mov    dx,WORD PTR es:[di+0x26]
    7ef8:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    7efb:	75 1c                	jne    0x7f19
    7efd:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    7f00:	75 17                	jne    0x7f19
    7f02:	68 13 0f             	push   0xf13
    7f05:	6a 00                	push   0x0
    7f07:	6a 00                	push   0x0
    7f09:	6a 00                	push   0x0
    7f0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f0e:	26 c4 7d 24          	les    di,DWORD PTR es:[di+0x24]
    7f12:	06                   	push   es
    7f13:	57                   	push   di
    7f14:	9a bb 24 85 7f       	call   0x7f85:0x24bb
    7f19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f1c:	26 80 7d 47 00       	cmp    BYTE PTR es:[di+0x47],0x0
    7f21:	74 4c                	je     0x7f6f
    7f23:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7f27:	26 0b 45 26          	or     ax,WORD PTR es:[di+0x26]
    7f2b:	75 09                	jne    0x7f36
    7f2d:	06                   	push   es
    7f2e:	57                   	push   di
    7f2f:	9a 11 79 61 7f       	call   0x7f61:0x7911
    7f34:	eb 39                	jmp    0x7f6f
    7f36:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7f39:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    7f3c:	74 15                	je     0x7f53
    7f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f41:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7f45:	26 8b 55 26          	mov    dx,WORD PTR es:[di+0x26]
    7f49:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    7f4c:	75 17                	jne    0x7f65
    7f4e:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    7f51:	75 12                	jne    0x7f65
    7f53:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7f56:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f5c:	06                   	push   es
    7f5d:	57                   	push   di
    7f5e:	9a ea 7c 6d 7f       	call   0x7f6d:0x7cea
    7f63:	eb 0a                	jmp    0x7f6f
    7f65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f68:	06                   	push   es
    7f69:	57                   	push   di
    7f6a:	9a c6 7c d0 7f       	call   0x7fd0:0x7cc6
    7f6f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7f72:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    7f75:	74 2d                	je     0x7fa4
    7f77:	8d be f2 fe          	lea    di,[bp-0x10e]
    7f7b:	16                   	push   ss
    7f7c:	57                   	push   di
    7f7d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7f80:	06                   	push   es
    7f81:	57                   	push   di
    7f82:	9a e5 1f c0 7f       	call   0x7fc0:0x1fe5
    7f87:	83 c4 04             	add    sp,0x4
    7f8a:	80 be f2 fe 00       	cmp    BYTE PTR [bp-0x10e],0x0
    7f8f:	75 13                	jne    0x7fa4
    7f91:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7f94:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7f98:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    7f9c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7f9f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7fa2:	eb cb                	jmp    0x7f6f
    7fa4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7fa7:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    7faa:	74 28                	je     0x7fd4
    7fac:	8d be f2 fd          	lea    di,[bp-0x20e]
    7fb0:	16                   	push   ss
    7fb1:	57                   	push   di
    7fb2:	8d be f2 fe          	lea    di,[bp-0x10e]
    7fb6:	16                   	push   ss
    7fb7:	57                   	push   di
    7fb8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7fbb:	06                   	push   es
    7fbc:	57                   	push   di
    7fbd:	9a e5 1f c5 7f       	call   0x7fc5:0x1fe5
    7fc2:	9a 08 0d 62 80       	call   0x8062:0xd08
    7fc7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    7fcb:	06                   	push   es
    7fcc:	57                   	push   di
    7fcd:	9a 9e 80 e2 7f       	call   0x7fe2:0x809e
    7fd2:	eb 10                	jmp    0x7fe4
    7fd4:	bf 1a 7e             	mov    di,0x7e1a
    7fd7:	0e                   	push   cs
    7fd8:	57                   	push   di
    7fd9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    7fdd:	06                   	push   es
    7fde:	57                   	push   di
    7fdf:	9a 9e 80 2d 80       	call   0x802d:0x809e
    7fe4:	c6 46 f3 01          	mov    BYTE PTR [bp-0xd],0x1
    7fe8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7feb:	26 8b 85 87 00       	mov    ax,WORD PTR es:[di+0x87]
    7ff0:	09 c0                	or     ax,ax
    7ff2:	74 1d                	je     0x8011
    7ff4:	ff 76 08             	push   WORD PTR [bp+0x8]
    7ff7:	ff 76 06             	push   WORD PTR [bp+0x6]
    7ffa:	8d 7e f3             	lea    di,[bp-0xd]
    7ffd:	16                   	push   ss
    7ffe:	57                   	push   di
    7fff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8002:	26 ff b5 8b 00       	push   WORD PTR es:[di+0x8b]
    8007:	26 ff b5 89 00       	push   WORD PTR es:[di+0x89]
    800c:	26 ff 9d 85 00       	call   DWORD PTR es:[di+0x85]
    8011:	80 7e f3 00          	cmp    BYTE PTR [bp-0xd],0x0
    8015:	74 05                	je     0x801c
    8017:	9a ff ff 00 00       	call   0x0:0xffff
    801c:	c9                   	leave
    801d:	ca 04 00             	retf   0x4
    8020:	c8 04 00 00          	enter  0x4,0x0
    8024:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    8028:	06                   	push   es
    8029:	57                   	push   di
    802a:	9a f4 60 57 80       	call   0x8057:0x60f4
    802f:	48                   	dec    ax
    8030:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8033:	31 c0                	xor    ax,ax
    8035:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    8038:	7f 32                	jg     0x806c
    803a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    803d:	eb 03                	jmp    0x8042
    803f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    8042:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8045:	6a 00                	push   0x0
    8047:	6a 00                	push   0x0
    8049:	6a 00                	push   0x0
    804b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    804e:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    8052:	06                   	push   es
    8053:	57                   	push   di
    8054:	9a cf 60 7e 80       	call   0x807e:0x60cf
    8059:	89 c7                	mov    di,ax
    805b:	8e c2                	mov    es,dx
    805d:	06                   	push   es
    805e:	57                   	push   di
    805f:	9a bb 24 ff ff       	call   0xffff:0x24bb
    8064:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8067:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    806a:	75 d3                	jne    0x803f
    806c:	c9                   	leave
    806d:	ca 06 00             	retf   0x6
    8070:	55                   	push   bp
    8071:	89 e5                	mov    bp,sp
    8073:	68 1d 0f             	push   0xf1d
    8076:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8079:	06                   	push   es
    807a:	57                   	push   di
    807b:	9a 20 80 ff ff       	call   0xffff:0x8020
    8080:	c9                   	leave
    8081:	ca 08 00             	retf   0x8
    8084:	55                   	push   bp
    8085:	89 e5                	mov    bp,sp
    8087:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    808a:	81 c7 28 00          	add    di,0x28
    808e:	06                   	push   es
    808f:	57                   	push   di
    8090:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8093:	06                   	push   es
    8094:	57                   	push   di
    8095:	9a 51 06 c7 80       	call   0x80c7:0x651
    809a:	c9                   	leave
    809b:	ca 08 00             	retf   0x8
    809e:	55                   	push   bp
    809f:	89 e5                	mov    bp,sp
    80a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80a4:	26 c4 7d 2c          	les    di,DWORD PTR es:[di+0x2c]
    80a8:	06                   	push   es
    80a9:	57                   	push   di
    80aa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80ad:	06                   	push   es
    80ae:	57                   	push   di
    80af:	9a be 18 ff ff       	call   0xffff:0x18be
    80b4:	74 32                	je     0x80e8
    80b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80b9:	81 c7 2c 00          	add    di,0x2c
    80bd:	06                   	push   es
    80be:	57                   	push   di
    80bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80c2:	06                   	push   es
    80c3:	57                   	push   di
    80c4:	9a 51 06 ff ff       	call   0xffff:0x651
    80c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80cc:	26 8b 45 7f          	mov    ax,WORD PTR es:[di+0x7f]
    80d0:	09 c0                	or     ax,ax
    80d2:	74 14                	je     0x80e8
    80d4:	ff 76 08             	push   WORD PTR [bp+0x8]
    80d7:	ff 76 06             	push   WORD PTR [bp+0x6]
    80da:	26 ff b5 83 00       	push   WORD PTR es:[di+0x83]
    80df:	26 ff b5 81 00       	push   WORD PTR es:[di+0x81]
    80e4:	26 ff 5d 7d          	call   DWORD PTR es:[di+0x7d]
    80e8:	c9                   	leave
    80e9:	ca 08 00             	retf   0x8
    80ec:	55                   	push   bp
    80ed:	89 e5                	mov    bp,sp
    80ef:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80f2:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    80f6:	26 8b 55 14          	mov    dx,WORD PTR es:[di+0x14]
    80fa:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    80fd:	75 12                	jne    0x8111
    80ff:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    8102:	75 0d                	jne    0x8111
    8104:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8107:	31 c0                	xor    ax,ax
    8109:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    810d:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    8111:	c9                   	leave
    8112:	ca                   	.byte 0xca
    8113:	08                   	.byte 0x8
