; seg03_DATA - Simstra1.dll (module de licence) - x86 16 bits

Disassembly of section .data:

00000000 <.data>:
   0:	00 00                	add    BYTE PTR [bx+si],al
   2:	00 00                	add    BYTE PTR [bx+si],al
   4:	05 00 00             	add    ax,0x0
	...
  3f:	00 0c                	add    BYTE PTR [si],cl
  41:	32 43 7a             	xor    al,BYTE PTR [bp+di+0x7a]
  44:	31 65 72             	xor    WORD PTR [di+0x72],sp
  47:	54                   	push   sp
  48:	26 56                	es push si
  4a:	55                   	push   bp
  4b:	73 34                	jae    0x81
  4d:	ff 53 69             	call   WORD PTR [bp+di+0x69]
  50:	6d                   	ins    WORD PTR es:[di],dx
  51:	73 74                	jae    0xc7
  53:	72 61                	jb     0xb6
  55:	74 20                	je     0x77
  57:	70 6f                	jo     0xc8
  59:	75 72                	jne    0xcd
  5b:	20 57 69             	and    BYTE PTR [bx+0x69],dl
  5e:	6e                   	outs   dx,BYTE PTR ds:[si]
  5f:	64 6f                	outs   dx,WORD PTR fs:[si]
  61:	77 73                	ja     0xd6
  63:	2e 20 56 65          	and    BYTE PTR cs:[bp+0x65],dl
  67:	72 73                	jb     0xdc
  69:	69 6f 6e 20 31       	imul   bp,WORD PTR [bx+0x6e],0x3120
  6e:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
  71:	20 20                	and    BYTE PTR [bx+si],ah
  73:	20 20                	and    BYTE PTR [bx+si],ah
  75:	20 20                	and    BYTE PTR [bx+si],ah
  77:	20 20                	and    BYTE PTR [bx+si],ah
  79:	20 20                	and    BYTE PTR [bx+si],ah
  7b:	20 20                	and    BYTE PTR [bx+si],ah
  7d:	20 20                	and    BYTE PTR [bx+si],ah
  7f:	20 20                	and    BYTE PTR [bx+si],ah
  81:	20 20                	and    BYTE PTR [bx+si],ah
  83:	20 20                	and    BYTE PTR [bx+si],ah
  85:	20 20                	and    BYTE PTR [bx+si],ah
  87:	20 20                	and    BYTE PTR [bx+si],ah
  89:	20 20                	and    BYTE PTR [bx+si],ah
  8b:	20 20                	and    BYTE PTR [bx+si],ah
  8d:	20 20                	and    BYTE PTR [bx+si],ah
  8f:	20 20                	and    BYTE PTR [bx+si],ah
  91:	20 20                	and    BYTE PTR [bx+si],ah
  93:	20 20                	and    BYTE PTR [bx+si],ah
  95:	20 20                	and    BYTE PTR [bx+si],ah
  97:	20 20                	and    BYTE PTR [bx+si],ah
  99:	20 20                	and    BYTE PTR [bx+si],ah
  9b:	20 20                	and    BYTE PTR [bx+si],ah
  9d:	20 20                	and    BYTE PTR [bx+si],ah
  9f:	20 20                	and    BYTE PTR [bx+si],ah
  a1:	20 20                	and    BYTE PTR [bx+si],ah
  a3:	20 20                	and    BYTE PTR [bx+si],ah
  a5:	20 20                	and    BYTE PTR [bx+si],ah
  a7:	20 20                	and    BYTE PTR [bx+si],ah
  a9:	20 20                	and    BYTE PTR [bx+si],ah
  ab:	20 20                	and    BYTE PTR [bx+si],ah
  ad:	20 20                	and    BYTE PTR [bx+si],ah
  af:	20 20                	and    BYTE PTR [bx+si],ah
  b1:	20 20                	and    BYTE PTR [bx+si],ah
  b3:	20 20                	and    BYTE PTR [bx+si],ah
  b5:	20 20                	and    BYTE PTR [bx+si],ah
  b7:	20 20                	and    BYTE PTR [bx+si],ah
  b9:	20 20                	and    BYTE PTR [bx+si],ah
  bb:	20 20                	and    BYTE PTR [bx+si],ah
  bd:	20 20                	and    BYTE PTR [bx+si],ah
  bf:	20 20                	and    BYTE PTR [bx+si],ah
  c1:	20 20                	and    BYTE PTR [bx+si],ah
  c3:	20 20                	and    BYTE PTR [bx+si],ah
  c5:	20 20                	and    BYTE PTR [bx+si],ah
  c7:	20 20                	and    BYTE PTR [bx+si],ah
  c9:	20 20                	and    BYTE PTR [bx+si],ah
  cb:	20 20                	and    BYTE PTR [bx+si],ah
  cd:	20 20                	and    BYTE PTR [bx+si],ah
  cf:	20 20                	and    BYTE PTR [bx+si],ah
  d1:	20 20                	and    BYTE PTR [bx+si],ah
  d3:	20 20                	and    BYTE PTR [bx+si],ah
  d5:	20 20                	and    BYTE PTR [bx+si],ah
  d7:	20 20                	and    BYTE PTR [bx+si],ah
  d9:	20 20                	and    BYTE PTR [bx+si],ah
  db:	20 20                	and    BYTE PTR [bx+si],ah
  dd:	20 20                	and    BYTE PTR [bx+si],ah
  df:	20 20                	and    BYTE PTR [bx+si],ah
  e1:	20 20                	and    BYTE PTR [bx+si],ah
  e3:	20 20                	and    BYTE PTR [bx+si],ah
  e5:	20 20                	and    BYTE PTR [bx+si],ah
  e7:	20 20                	and    BYTE PTR [bx+si],ah
  e9:	20 20                	and    BYTE PTR [bx+si],ah
  eb:	20 20                	and    BYTE PTR [bx+si],ah
  ed:	20 20                	and    BYTE PTR [bx+si],ah
  ef:	20 20                	and    BYTE PTR [bx+si],ah
  f1:	20 20                	and    BYTE PTR [bx+si],ah
  f3:	20 20                	and    BYTE PTR [bx+si],ah
  f5:	20 20                	and    BYTE PTR [bx+si],ah
  f7:	20 20                	and    BYTE PTR [bx+si],ah
  f9:	20 20                	and    BYTE PTR [bx+si],ah
  fb:	20 20                	and    BYTE PTR [bx+si],ah
  fd:	20 20                	and    BYTE PTR [bx+si],ah
  ff:	20 20                	and    BYTE PTR [bx+si],ah
 101:	20 20                	and    BYTE PTR [bx+si],ah
 103:	20 20                	and    BYTE PTR [bx+si],ah
 105:	20 20                	and    BYTE PTR [bx+si],ah
 107:	20 20                	and    BYTE PTR [bx+si],ah
 109:	20 20                	and    BYTE PTR [bx+si],ah
 10b:	20 20                	and    BYTE PTR [bx+si],ah
 10d:	20 20                	and    BYTE PTR [bx+si],ah
 10f:	20 20                	and    BYTE PTR [bx+si],ah
 111:	20 20                	and    BYTE PTR [bx+si],ah
 113:	20 20                	and    BYTE PTR [bx+si],ah
 115:	20 20                	and    BYTE PTR [bx+si],ah
 117:	20 20                	and    BYTE PTR [bx+si],ah
 119:	20 20                	and    BYTE PTR [bx+si],ah
 11b:	20 20                	and    BYTE PTR [bx+si],ah
 11d:	20 20                	and    BYTE PTR [bx+si],ah
 11f:	20 20                	and    BYTE PTR [bx+si],ah
 121:	20 20                	and    BYTE PTR [bx+si],ah
 123:	20 20                	and    BYTE PTR [bx+si],ah
 125:	20 20                	and    BYTE PTR [bx+si],ah
 127:	20 20                	and    BYTE PTR [bx+si],ah
 129:	20 20                	and    BYTE PTR [bx+si],ah
 12b:	20 20                	and    BYTE PTR [bx+si],ah
 12d:	20 20                	and    BYTE PTR [bx+si],ah
 12f:	20 20                	and    BYTE PTR [bx+si],ah
 131:	20 20                	and    BYTE PTR [bx+si],ah
 133:	20 20                	and    BYTE PTR [bx+si],ah
 135:	20 20                	and    BYTE PTR [bx+si],ah
 137:	20 20                	and    BYTE PTR [bx+si],ah
 139:	20 20                	and    BYTE PTR [bx+si],ah
 13b:	20 20                	and    BYTE PTR [bx+si],ah
 13d:	20 20                	and    BYTE PTR [bx+si],ah
 13f:	20 20                	and    BYTE PTR [bx+si],ah
 141:	20 20                	and    BYTE PTR [bx+si],ah
 143:	20 20                	and    BYTE PTR [bx+si],ah
 145:	20 20                	and    BYTE PTR [bx+si],ah
 147:	20 20                	and    BYTE PTR [bx+si],ah
 149:	20 20                	and    BYTE PTR [bx+si],ah
 14b:	20 20                	and    BYTE PTR [bx+si],ah
 14d:	0a 31                	or     dh,BYTE PTR [bx+di]
 14f:	32 2f                	xor    ch,BYTE PTR [bx]
 151:	30 36 2f 31          	xor    BYTE PTR ds:0x312f,dh
 155:	39 39                	cmp    WORD PTR [bx+di],di
 157:	38 02                	cmp    BYTE PTR [bp+si],al
 159:	8e 01                	mov    es,WORD PTR [bx+di]
 15b:	02 01                	add    al,BYTE PTR [bx+di]
 15d:	03 01                	add    ax,WORD PTR [bx+di]
 15f:	04 02                	add    al,0x2
 161:	e8 02 2b             	call   0x2c66
 164:	02 81 01 02          	add    al,BYTE PTR [bx+di+0x201]
 168:	01 03                	add    WORD PTR [bp+di],ax
 16a:	01 04                	add    WORD PTR [si],ax
 16c:	01 05                	add    WORD PTR [di],ax
 16e:	01 06 ff 55          	add    WORD PTR ds:0x55ff,ax
 172:	74 69                	je     0x1dd
 174:	6c                   	ins    BYTE PTR es:[di],dx
 175:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
 17a:	6f                   	outs   dx,WORD PTR ds:[si]
 17b:	6e                   	outs   dx,BYTE PTR ds:[si]
 17c:	20 65 78             	and    BYTE PTR [di+0x78],ah
 17f:	63 6c 75             	arpl   WORD PTR [si+0x75],bp
 182:	73 69                	jae    0x1ed
 184:	76 65                	jbe    0x1eb
 186:	20 65 6e             	and    BYTE PTR [di+0x6e],ah
 189:	20 55 4e             	and    BYTE PTR [di+0x4e],dl
 18c:	20 65 78             	and    BYTE PTR [di+0x78],ah
 18f:	65 6d                	gs ins WORD PTR es:[di],dx
 191:	70 6c                	jo     0x1ff
 193:	61                   	popa
 194:	69 72 65 20 70       	imul   si,WORD PTR [bp+si+0x65],0x7020
 199:	61                   	popa
 19a:	72 3a                	jb     0x1d6
 19c:	20 20                	and    BYTE PTR [bx+si],ah
 19e:	20 20                	and    BYTE PTR [bx+si],ah
 1a0:	20 20                	and    BYTE PTR [bx+si],ah
 1a2:	20 20                	and    BYTE PTR [bx+si],ah
 1a4:	20 20                	and    BYTE PTR [bx+si],ah
 1a6:	20 20                	and    BYTE PTR [bx+si],ah
 1a8:	20 20                	and    BYTE PTR [bx+si],ah
 1aa:	20 20                	and    BYTE PTR [bx+si],ah
 1ac:	20 20                	and    BYTE PTR [bx+si],ah
 1ae:	20 20                	and    BYTE PTR [bx+si],ah
 1b0:	20 20                	and    BYTE PTR [bx+si],ah
 1b2:	20 20                	and    BYTE PTR [bx+si],ah
 1b4:	20 20                	and    BYTE PTR [bx+si],ah
 1b6:	20 20                	and    BYTE PTR [bx+si],ah
 1b8:	20 20                	and    BYTE PTR [bx+si],ah
 1ba:	20 20                	and    BYTE PTR [bx+si],ah
 1bc:	20 20                	and    BYTE PTR [bx+si],ah
 1be:	20 20                	and    BYTE PTR [bx+si],ah
 1c0:	20 20                	and    BYTE PTR [bx+si],ah
 1c2:	20 20                	and    BYTE PTR [bx+si],ah
 1c4:	20 20                	and    BYTE PTR [bx+si],ah
 1c6:	20 20                	and    BYTE PTR [bx+si],ah
 1c8:	20 20                	and    BYTE PTR [bx+si],ah
 1ca:	20 20                	and    BYTE PTR [bx+si],ah
 1cc:	20 20                	and    BYTE PTR [bx+si],ah
 1ce:	20 20                	and    BYTE PTR [bx+si],ah
 1d0:	20 20                	and    BYTE PTR [bx+si],ah
 1d2:	20 20                	and    BYTE PTR [bx+si],ah
 1d4:	20 20                	and    BYTE PTR [bx+si],ah
 1d6:	20 20                	and    BYTE PTR [bx+si],ah
 1d8:	20 20                	and    BYTE PTR [bx+si],ah
 1da:	20 20                	and    BYTE PTR [bx+si],ah
 1dc:	20 20                	and    BYTE PTR [bx+si],ah
 1de:	20 20                	and    BYTE PTR [bx+si],ah
 1e0:	20 20                	and    BYTE PTR [bx+si],ah
 1e2:	20 20                	and    BYTE PTR [bx+si],ah
 1e4:	20 20                	and    BYTE PTR [bx+si],ah
 1e6:	20 20                	and    BYTE PTR [bx+si],ah
 1e8:	20 20                	and    BYTE PTR [bx+si],ah
 1ea:	20 20                	and    BYTE PTR [bx+si],ah
 1ec:	20 20                	and    BYTE PTR [bx+si],ah
 1ee:	20 20                	and    BYTE PTR [bx+si],ah
 1f0:	20 20                	and    BYTE PTR [bx+si],ah
 1f2:	20 20                	and    BYTE PTR [bx+si],ah
 1f4:	20 20                	and    BYTE PTR [bx+si],ah
 1f6:	20 20                	and    BYTE PTR [bx+si],ah
 1f8:	20 20                	and    BYTE PTR [bx+si],ah
 1fa:	20 20                	and    BYTE PTR [bx+si],ah
 1fc:	20 20                	and    BYTE PTR [bx+si],ah
 1fe:	20 20                	and    BYTE PTR [bx+si],ah
 200:	20 20                	and    BYTE PTR [bx+si],ah
 202:	20 20                	and    BYTE PTR [bx+si],ah
 204:	20 20                	and    BYTE PTR [bx+si],ah
 206:	20 20                	and    BYTE PTR [bx+si],ah
 208:	20 20                	and    BYTE PTR [bx+si],ah
 20a:	20 20                	and    BYTE PTR [bx+si],ah
 20c:	20 20                	and    BYTE PTR [bx+si],ah
 20e:	20 20                	and    BYTE PTR [bx+si],ah
 210:	20 20                	and    BYTE PTR [bx+si],ah
 212:	20 20                	and    BYTE PTR [bx+si],ah
 214:	20 20                	and    BYTE PTR [bx+si],ah
 216:	20 20                	and    BYTE PTR [bx+si],ah
 218:	20 20                	and    BYTE PTR [bx+si],ah
 21a:	20 20                	and    BYTE PTR [bx+si],ah
 21c:	20 20                	and    BYTE PTR [bx+si],ah
 21e:	20 20                	and    BYTE PTR [bx+si],ah
 220:	20 20                	and    BYTE PTR [bx+si],ah
 222:	20 20                	and    BYTE PTR [bx+si],ah
 224:	20 20                	and    BYTE PTR [bx+si],ah
 226:	20 20                	and    BYTE PTR [bx+si],ah
 228:	20 20                	and    BYTE PTR [bx+si],ah
 22a:	20 20                	and    BYTE PTR [bx+si],ah
 22c:	20 20                	and    BYTE PTR [bx+si],ah
 22e:	20 20                	and    BYTE PTR [bx+si],ah
 230:	20 20                	and    BYTE PTR [bx+si],ah
 232:	20 20                	and    BYTE PTR [bx+si],ah
 234:	20 20                	and    BYTE PTR [bx+si],ah
 236:	20 20                	and    BYTE PTR [bx+si],ah
 238:	20 20                	and    BYTE PTR [bx+si],ah
 23a:	20 20                	and    BYTE PTR [bx+si],ah
 23c:	20 20                	and    BYTE PTR [bx+si],ah
 23e:	20 20                	and    BYTE PTR [bx+si],ah
 240:	20 20                	and    BYTE PTR [bx+si],ah
 242:	20 20                	and    BYTE PTR [bx+si],ah
 244:	20 20                	and    BYTE PTR [bx+si],ah
 246:	20 20                	and    BYTE PTR [bx+si],ah
 248:	20 20                	and    BYTE PTR [bx+si],ah
 24a:	20 20                	and    BYTE PTR [bx+si],ah
 24c:	20 20                	and    BYTE PTR [bx+si],ah
 24e:	20 20                	and    BYTE PTR [bx+si],ah
 250:	20 20                	and    BYTE PTR [bx+si],ah
 252:	20 20                	and    BYTE PTR [bx+si],ah
 254:	20 20                	and    BYTE PTR [bx+si],ah
 256:	20 20                	and    BYTE PTR [bx+si],ah
 258:	20 20                	and    BYTE PTR [bx+si],ah
 25a:	20 20                	and    BYTE PTR [bx+si],ah
 25c:	20 20                	and    BYTE PTR [bx+si],ah
 25e:	20 20                	and    BYTE PTR [bx+si],ah
 260:	20 20                	and    BYTE PTR [bx+si],ah
 262:	20 20                	and    BYTE PTR [bx+si],ah
 264:	20 20                	and    BYTE PTR [bx+si],ah
 266:	20 20                	and    BYTE PTR [bx+si],ah
 268:	20 20                	and    BYTE PTR [bx+si],ah
 26a:	20 20                	and    BYTE PTR [bx+si],ah
 26c:	20 20                	and    BYTE PTR [bx+si],ah
 26e:	20 20                	and    BYTE PTR [bx+si],ah
 270:	ff 56 45             	call   WORD PTR [bp+0x45]
 273:	52                   	push   dx
 274:	53                   	push   bx
 275:	49                   	dec    cx
 276:	4f                   	dec    di
 277:	4e                   	dec    si
 278:	20 44 45             	and    BYTE PTR [si+0x45],al
 27b:	20 44 45             	and    BYTE PTR [si+0x45],al
 27e:	4d                   	dec    bp
 27f:	4f                   	dec    di
 280:	4e                   	dec    si
 281:	53                   	push   bx
 282:	54                   	push   sp
 283:	52                   	push   dx
 284:	41                   	inc    cx
 285:	54                   	push   sp
 286:	49                   	dec    cx
 287:	4f                   	dec    di
 288:	4e                   	dec    si
 289:	2e 20 20             	and    BYTE PTR cs:[bx+si],ah
 28c:	20 20                	and    BYTE PTR [bx+si],ah
 28e:	20 20                	and    BYTE PTR [bx+si],ah
 290:	20 20                	and    BYTE PTR [bx+si],ah
 292:	20 20                	and    BYTE PTR [bx+si],ah
 294:	20 20                	and    BYTE PTR [bx+si],ah
 296:	20 20                	and    BYTE PTR [bx+si],ah
 298:	20 20                	and    BYTE PTR [bx+si],ah
 29a:	20 20                	and    BYTE PTR [bx+si],ah
 29c:	20 20                	and    BYTE PTR [bx+si],ah
 29e:	20 20                	and    BYTE PTR [bx+si],ah
 2a0:	20 20                	and    BYTE PTR [bx+si],ah
 2a2:	20 20                	and    BYTE PTR [bx+si],ah
 2a4:	20 20                	and    BYTE PTR [bx+si],ah
 2a6:	20 20                	and    BYTE PTR [bx+si],ah
 2a8:	20 20                	and    BYTE PTR [bx+si],ah
 2aa:	20 20                	and    BYTE PTR [bx+si],ah
 2ac:	20 20                	and    BYTE PTR [bx+si],ah
 2ae:	20 20                	and    BYTE PTR [bx+si],ah
 2b0:	20 20                	and    BYTE PTR [bx+si],ah
 2b2:	20 20                	and    BYTE PTR [bx+si],ah
 2b4:	20 20                	and    BYTE PTR [bx+si],ah
 2b6:	20 20                	and    BYTE PTR [bx+si],ah
 2b8:	20 20                	and    BYTE PTR [bx+si],ah
 2ba:	20 20                	and    BYTE PTR [bx+si],ah
 2bc:	20 20                	and    BYTE PTR [bx+si],ah
 2be:	20 20                	and    BYTE PTR [bx+si],ah
 2c0:	20 20                	and    BYTE PTR [bx+si],ah
 2c2:	20 20                	and    BYTE PTR [bx+si],ah
 2c4:	20 20                	and    BYTE PTR [bx+si],ah
 2c6:	20 20                	and    BYTE PTR [bx+si],ah
 2c8:	20 20                	and    BYTE PTR [bx+si],ah
 2ca:	20 20                	and    BYTE PTR [bx+si],ah
 2cc:	20 20                	and    BYTE PTR [bx+si],ah
 2ce:	20 20                	and    BYTE PTR [bx+si],ah
 2d0:	20 20                	and    BYTE PTR [bx+si],ah
 2d2:	20 20                	and    BYTE PTR [bx+si],ah
 2d4:	20 20                	and    BYTE PTR [bx+si],ah
 2d6:	20 20                	and    BYTE PTR [bx+si],ah
 2d8:	20 20                	and    BYTE PTR [bx+si],ah
 2da:	20 20                	and    BYTE PTR [bx+si],ah
 2dc:	20 20                	and    BYTE PTR [bx+si],ah
 2de:	20 20                	and    BYTE PTR [bx+si],ah
 2e0:	20 20                	and    BYTE PTR [bx+si],ah
 2e2:	20 20                	and    BYTE PTR [bx+si],ah
 2e4:	20 20                	and    BYTE PTR [bx+si],ah
 2e6:	20 20                	and    BYTE PTR [bx+si],ah
 2e8:	20 20                	and    BYTE PTR [bx+si],ah
 2ea:	20 20                	and    BYTE PTR [bx+si],ah
 2ec:	20 20                	and    BYTE PTR [bx+si],ah
 2ee:	20 20                	and    BYTE PTR [bx+si],ah
 2f0:	20 20                	and    BYTE PTR [bx+si],ah
 2f2:	20 20                	and    BYTE PTR [bx+si],ah
 2f4:	20 20                	and    BYTE PTR [bx+si],ah
 2f6:	20 20                	and    BYTE PTR [bx+si],ah
 2f8:	20 20                	and    BYTE PTR [bx+si],ah
 2fa:	20 20                	and    BYTE PTR [bx+si],ah
 2fc:	20 20                	and    BYTE PTR [bx+si],ah
 2fe:	20 20                	and    BYTE PTR [bx+si],ah
 300:	20 20                	and    BYTE PTR [bx+si],ah
 302:	20 20                	and    BYTE PTR [bx+si],ah
 304:	20 20                	and    BYTE PTR [bx+si],ah
 306:	20 20                	and    BYTE PTR [bx+si],ah
 308:	20 20                	and    BYTE PTR [bx+si],ah
 30a:	20 20                	and    BYTE PTR [bx+si],ah
 30c:	20 20                	and    BYTE PTR [bx+si],ah
 30e:	20 20                	and    BYTE PTR [bx+si],ah
 310:	20 20                	and    BYTE PTR [bx+si],ah
 312:	20 20                	and    BYTE PTR [bx+si],ah
 314:	20 20                	and    BYTE PTR [bx+si],ah
 316:	20 20                	and    BYTE PTR [bx+si],ah
 318:	20 20                	and    BYTE PTR [bx+si],ah
 31a:	20 20                	and    BYTE PTR [bx+si],ah
 31c:	20 20                	and    BYTE PTR [bx+si],ah
 31e:	20 20                	and    BYTE PTR [bx+si],ah
 320:	20 20                	and    BYTE PTR [bx+si],ah
 322:	20 20                	and    BYTE PTR [bx+si],ah
 324:	20 20                	and    BYTE PTR [bx+si],ah
 326:	20 20                	and    BYTE PTR [bx+si],ah
 328:	20 20                	and    BYTE PTR [bx+si],ah
 32a:	20 20                	and    BYTE PTR [bx+si],ah
 32c:	20 20                	and    BYTE PTR [bx+si],ah
 32e:	20 20                	and    BYTE PTR [bx+si],ah
 330:	20 20                	and    BYTE PTR [bx+si],ah
 332:	20 20                	and    BYTE PTR [bx+si],ah
 334:	20 20                	and    BYTE PTR [bx+si],ah
 336:	20 20                	and    BYTE PTR [bx+si],ah
 338:	20 20                	and    BYTE PTR [bx+si],ah
 33a:	20 20                	and    BYTE PTR [bx+si],ah
 33c:	20 20                	and    BYTE PTR [bx+si],ah
 33e:	20 20                	and    BYTE PTR [bx+si],ah
 340:	20 20                	and    BYTE PTR [bx+si],ah
 342:	20 20                	and    BYTE PTR [bx+si],ah
 344:	20 20                	and    BYTE PTR [bx+si],ah
 346:	20 20                	and    BYTE PTR [bx+si],ah
 348:	20 20                	and    BYTE PTR [bx+si],ah
 34a:	20 20                	and    BYTE PTR [bx+si],ah
 34c:	20 20                	and    BYTE PTR [bx+si],ah
 34e:	20 20                	and    BYTE PTR [bx+si],ah
 350:	20 20                	and    BYTE PTR [bx+si],ah
 352:	20 20                	and    BYTE PTR [bx+si],ah
 354:	20 20                	and    BYTE PTR [bx+si],ah
 356:	20 20                	and    BYTE PTR [bx+si],ah
 358:	20 20                	and    BYTE PTR [bx+si],ah
 35a:	20 20                	and    BYTE PTR [bx+si],ah
 35c:	20 20                	and    BYTE PTR [bx+si],ah
 35e:	20 20                	and    BYTE PTR [bx+si],ah
 360:	20 20                	and    BYTE PTR [bx+si],ah
 362:	20 20                	and    BYTE PTR [bx+si],ah
 364:	20 20                	and    BYTE PTR [bx+si],ah
 366:	20 20                	and    BYTE PTR [bx+si],ah
 368:	20 20                	and    BYTE PTR [bx+si],ah
 36a:	20 20                	and    BYTE PTR [bx+si],ah
 36c:	20 20                	and    BYTE PTR [bx+si],ah
 36e:	20 20                	and    BYTE PTR [bx+si],ah
 370:	ff 4e 6f             	dec    WORD PTR [bp+0x6f]
 373:	6e                   	outs   dx,BYTE PTR ds:[si]
 374:	20 75 74             	and    BYTE PTR [di+0x74],dh
 377:	69 6c 69 73 61       	imul   bp,WORD PTR [si+0x69],0x6173
 37c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
 37f:	20 e0                	and    al,ah
 381:	20 64 65             	and    BYTE PTR [si+0x65],ah
 384:	73 20                	jae    0x3a6
 386:	66 69 6e 73 20 70 e9 	imul   ebp,DWORD PTR [bp+0x73],0x64e97020
 38d:	64 
 38e:	61                   	popa
 38f:	67 6f                	outs   dx,WORD PTR ds:[esi]
 391:	67 69 71 75 65 73    	imul   si,WORD PTR [ecx+0x75],0x7365
 397:	20 6f 75             	and    BYTE PTR [bx+0x75],ch
 39a:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
 39d:	6d                   	ins    WORD PTR es:[di],dx
 39e:	6d                   	ins    WORD PTR es:[di],dx
 39f:	65 72 63             	gs jb  0x405
 3a2:	69 61 6c 65 73       	imul   sp,WORD PTR [bx+di+0x6c],0x7365
 3a7:	2e 20 20             	and    BYTE PTR cs:[bx+si],ah
 3aa:	20 20                	and    BYTE PTR [bx+si],ah
 3ac:	20 20                	and    BYTE PTR [bx+si],ah
 3ae:	20 20                	and    BYTE PTR [bx+si],ah
 3b0:	20 20                	and    BYTE PTR [bx+si],ah
 3b2:	20 20                	and    BYTE PTR [bx+si],ah
 3b4:	20 20                	and    BYTE PTR [bx+si],ah
 3b6:	20 20                	and    BYTE PTR [bx+si],ah
 3b8:	20 20                	and    BYTE PTR [bx+si],ah
 3ba:	20 20                	and    BYTE PTR [bx+si],ah
 3bc:	20 20                	and    BYTE PTR [bx+si],ah
 3be:	20 20                	and    BYTE PTR [bx+si],ah
 3c0:	20 20                	and    BYTE PTR [bx+si],ah
 3c2:	20 20                	and    BYTE PTR [bx+si],ah
 3c4:	20 20                	and    BYTE PTR [bx+si],ah
 3c6:	20 20                	and    BYTE PTR [bx+si],ah
 3c8:	20 20                	and    BYTE PTR [bx+si],ah
 3ca:	20 20                	and    BYTE PTR [bx+si],ah
 3cc:	20 20                	and    BYTE PTR [bx+si],ah
 3ce:	20 20                	and    BYTE PTR [bx+si],ah
 3d0:	20 20                	and    BYTE PTR [bx+si],ah
 3d2:	20 20                	and    BYTE PTR [bx+si],ah
 3d4:	20 20                	and    BYTE PTR [bx+si],ah
 3d6:	20 20                	and    BYTE PTR [bx+si],ah
 3d8:	20 20                	and    BYTE PTR [bx+si],ah
 3da:	20 20                	and    BYTE PTR [bx+si],ah
 3dc:	20 20                	and    BYTE PTR [bx+si],ah
 3de:	20 20                	and    BYTE PTR [bx+si],ah
 3e0:	20 20                	and    BYTE PTR [bx+si],ah
 3e2:	20 20                	and    BYTE PTR [bx+si],ah
 3e4:	20 20                	and    BYTE PTR [bx+si],ah
 3e6:	20 20                	and    BYTE PTR [bx+si],ah
 3e8:	20 20                	and    BYTE PTR [bx+si],ah
 3ea:	20 20                	and    BYTE PTR [bx+si],ah
 3ec:	20 20                	and    BYTE PTR [bx+si],ah
 3ee:	20 20                	and    BYTE PTR [bx+si],ah
 3f0:	20 20                	and    BYTE PTR [bx+si],ah
 3f2:	20 20                	and    BYTE PTR [bx+si],ah
 3f4:	20 20                	and    BYTE PTR [bx+si],ah
 3f6:	20 20                	and    BYTE PTR [bx+si],ah
 3f8:	20 20                	and    BYTE PTR [bx+si],ah
 3fa:	20 20                	and    BYTE PTR [bx+si],ah
 3fc:	20 20                	and    BYTE PTR [bx+si],ah
 3fe:	20 20                	and    BYTE PTR [bx+si],ah
 400:	20 20                	and    BYTE PTR [bx+si],ah
 402:	20 20                	and    BYTE PTR [bx+si],ah
 404:	20 20                	and    BYTE PTR [bx+si],ah
 406:	20 20                	and    BYTE PTR [bx+si],ah
 408:	20 20                	and    BYTE PTR [bx+si],ah
 40a:	20 20                	and    BYTE PTR [bx+si],ah
 40c:	20 20                	and    BYTE PTR [bx+si],ah
 40e:	20 20                	and    BYTE PTR [bx+si],ah
 410:	20 20                	and    BYTE PTR [bx+si],ah
 412:	20 20                	and    BYTE PTR [bx+si],ah
 414:	20 20                	and    BYTE PTR [bx+si],ah
 416:	20 20                	and    BYTE PTR [bx+si],ah
 418:	20 20                	and    BYTE PTR [bx+si],ah
 41a:	20 20                	and    BYTE PTR [bx+si],ah
 41c:	20 20                	and    BYTE PTR [bx+si],ah
 41e:	20 20                	and    BYTE PTR [bx+si],ah
 420:	20 20                	and    BYTE PTR [bx+si],ah
 422:	20 20                	and    BYTE PTR [bx+si],ah
 424:	20 20                	and    BYTE PTR [bx+si],ah
 426:	20 20                	and    BYTE PTR [bx+si],ah
 428:	20 20                	and    BYTE PTR [bx+si],ah
 42a:	20 20                	and    BYTE PTR [bx+si],ah
 42c:	20 20                	and    BYTE PTR [bx+si],ah
 42e:	20 20                	and    BYTE PTR [bx+si],ah
 430:	20 20                	and    BYTE PTR [bx+si],ah
 432:	20 20                	and    BYTE PTR [bx+si],ah
 434:	20 20                	and    BYTE PTR [bx+si],ah
 436:	20 20                	and    BYTE PTR [bx+si],ah
 438:	20 20                	and    BYTE PTR [bx+si],ah
 43a:	20 20                	and    BYTE PTR [bx+si],ah
 43c:	20 20                	and    BYTE PTR [bx+si],ah
 43e:	20 20                	and    BYTE PTR [bx+si],ah
 440:	20 20                	and    BYTE PTR [bx+si],ah
 442:	20 20                	and    BYTE PTR [bx+si],ah
 444:	20 20                	and    BYTE PTR [bx+si],ah
 446:	20 20                	and    BYTE PTR [bx+si],ah
 448:	20 20                	and    BYTE PTR [bx+si],ah
 44a:	20 20                	and    BYTE PTR [bx+si],ah
 44c:	20 20                	and    BYTE PTR [bx+si],ah
 44e:	20 20                	and    BYTE PTR [bx+si],ah
 450:	20 20                	and    BYTE PTR [bx+si],ah
 452:	20 20                	and    BYTE PTR [bx+si],ah
 454:	20 20                	and    BYTE PTR [bx+si],ah
 456:	20 20                	and    BYTE PTR [bx+si],ah
 458:	20 20                	and    BYTE PTR [bx+si],ah
 45a:	20 20                	and    BYTE PTR [bx+si],ah
 45c:	20 20                	and    BYTE PTR [bx+si],ah
 45e:	20 20                	and    BYTE PTR [bx+si],ah
 460:	20 20                	and    BYTE PTR [bx+si],ah
 462:	20 20                	and    BYTE PTR [bx+si],ah
 464:	20 20                	and    BYTE PTR [bx+si],ah
 466:	20 20                	and    BYTE PTR [bx+si],ah
 468:	20 20                	and    BYTE PTR [bx+si],ah
 46a:	20 20                	and    BYTE PTR [bx+si],ah
 46c:	20 20                	and    BYTE PTR [bx+si],ah
 46e:	20 20                	and    BYTE PTR [bx+si],ah
 470:	ff 56 65             	call   WORD PTR [bp+0x65]
 473:	72 73                	jb     0x4e8
 475:	69 6f 6e 20 64       	imul   bp,WORD PTR [bx+0x6e],0x6420
 47a:	65 20 74 65          	and    BYTE PTR gs:[si+0x65],dh
 47e:	73 74                	jae    0x4f4
 480:	2e 20 20             	and    BYTE PTR cs:[bx+si],ah
 483:	20 20                	and    BYTE PTR [bx+si],ah
 485:	20 20                	and    BYTE PTR [bx+si],ah
 487:	20 20                	and    BYTE PTR [bx+si],ah
 489:	20 20                	and    BYTE PTR [bx+si],ah
 48b:	20 20                	and    BYTE PTR [bx+si],ah
 48d:	20 20                	and    BYTE PTR [bx+si],ah
 48f:	20 20                	and    BYTE PTR [bx+si],ah
 491:	20 20                	and    BYTE PTR [bx+si],ah
 493:	20 20                	and    BYTE PTR [bx+si],ah
 495:	20 20                	and    BYTE PTR [bx+si],ah
 497:	20 20                	and    BYTE PTR [bx+si],ah
 499:	20 20                	and    BYTE PTR [bx+si],ah
 49b:	20 20                	and    BYTE PTR [bx+si],ah
 49d:	20 20                	and    BYTE PTR [bx+si],ah
 49f:	20 20                	and    BYTE PTR [bx+si],ah
 4a1:	20 20                	and    BYTE PTR [bx+si],ah
 4a3:	20 20                	and    BYTE PTR [bx+si],ah
 4a5:	20 20                	and    BYTE PTR [bx+si],ah
 4a7:	20 20                	and    BYTE PTR [bx+si],ah
 4a9:	20 20                	and    BYTE PTR [bx+si],ah
 4ab:	20 20                	and    BYTE PTR [bx+si],ah
 4ad:	20 20                	and    BYTE PTR [bx+si],ah
 4af:	20 20                	and    BYTE PTR [bx+si],ah
 4b1:	20 20                	and    BYTE PTR [bx+si],ah
 4b3:	20 20                	and    BYTE PTR [bx+si],ah
 4b5:	20 20                	and    BYTE PTR [bx+si],ah
 4b7:	20 20                	and    BYTE PTR [bx+si],ah
 4b9:	20 20                	and    BYTE PTR [bx+si],ah
 4bb:	20 20                	and    BYTE PTR [bx+si],ah
 4bd:	20 20                	and    BYTE PTR [bx+si],ah
 4bf:	20 20                	and    BYTE PTR [bx+si],ah
 4c1:	20 20                	and    BYTE PTR [bx+si],ah
 4c3:	20 20                	and    BYTE PTR [bx+si],ah
 4c5:	20 20                	and    BYTE PTR [bx+si],ah
 4c7:	20 20                	and    BYTE PTR [bx+si],ah
 4c9:	20 20                	and    BYTE PTR [bx+si],ah
 4cb:	20 20                	and    BYTE PTR [bx+si],ah
 4cd:	20 20                	and    BYTE PTR [bx+si],ah
 4cf:	20 20                	and    BYTE PTR [bx+si],ah
 4d1:	20 20                	and    BYTE PTR [bx+si],ah
 4d3:	20 20                	and    BYTE PTR [bx+si],ah
 4d5:	20 20                	and    BYTE PTR [bx+si],ah
 4d7:	20 20                	and    BYTE PTR [bx+si],ah
 4d9:	20 20                	and    BYTE PTR [bx+si],ah
 4db:	20 20                	and    BYTE PTR [bx+si],ah
 4dd:	20 20                	and    BYTE PTR [bx+si],ah
 4df:	20 20                	and    BYTE PTR [bx+si],ah
 4e1:	20 20                	and    BYTE PTR [bx+si],ah
 4e3:	20 20                	and    BYTE PTR [bx+si],ah
 4e5:	20 20                	and    BYTE PTR [bx+si],ah
 4e7:	20 20                	and    BYTE PTR [bx+si],ah
 4e9:	20 20                	and    BYTE PTR [bx+si],ah
 4eb:	20 20                	and    BYTE PTR [bx+si],ah
 4ed:	20 20                	and    BYTE PTR [bx+si],ah
 4ef:	20 20                	and    BYTE PTR [bx+si],ah
 4f1:	20 20                	and    BYTE PTR [bx+si],ah
 4f3:	20 20                	and    BYTE PTR [bx+si],ah
 4f5:	20 20                	and    BYTE PTR [bx+si],ah
 4f7:	20 20                	and    BYTE PTR [bx+si],ah
 4f9:	20 20                	and    BYTE PTR [bx+si],ah
 4fb:	20 20                	and    BYTE PTR [bx+si],ah
 4fd:	20 20                	and    BYTE PTR [bx+si],ah
 4ff:	20 20                	and    BYTE PTR [bx+si],ah
 501:	20 20                	and    BYTE PTR [bx+si],ah
 503:	20 20                	and    BYTE PTR [bx+si],ah
 505:	20 20                	and    BYTE PTR [bx+si],ah
 507:	20 20                	and    BYTE PTR [bx+si],ah
 509:	20 20                	and    BYTE PTR [bx+si],ah
 50b:	20 20                	and    BYTE PTR [bx+si],ah
 50d:	20 20                	and    BYTE PTR [bx+si],ah
 50f:	20 20                	and    BYTE PTR [bx+si],ah
 511:	20 20                	and    BYTE PTR [bx+si],ah
 513:	20 20                	and    BYTE PTR [bx+si],ah
 515:	20 20                	and    BYTE PTR [bx+si],ah
 517:	20 20                	and    BYTE PTR [bx+si],ah
 519:	20 20                	and    BYTE PTR [bx+si],ah
 51b:	20 20                	and    BYTE PTR [bx+si],ah
 51d:	20 20                	and    BYTE PTR [bx+si],ah
 51f:	20 20                	and    BYTE PTR [bx+si],ah
 521:	20 20                	and    BYTE PTR [bx+si],ah
 523:	20 20                	and    BYTE PTR [bx+si],ah
 525:	20 20                	and    BYTE PTR [bx+si],ah
 527:	20 20                	and    BYTE PTR [bx+si],ah
 529:	20 20                	and    BYTE PTR [bx+si],ah
 52b:	20 20                	and    BYTE PTR [bx+si],ah
 52d:	20 20                	and    BYTE PTR [bx+si],ah
 52f:	20 20                	and    BYTE PTR [bx+si],ah
 531:	20 20                	and    BYTE PTR [bx+si],ah
 533:	20 20                	and    BYTE PTR [bx+si],ah
 535:	20 20                	and    BYTE PTR [bx+si],ah
 537:	20 20                	and    BYTE PTR [bx+si],ah
 539:	20 20                	and    BYTE PTR [bx+si],ah
 53b:	20 20                	and    BYTE PTR [bx+si],ah
 53d:	20 20                	and    BYTE PTR [bx+si],ah
 53f:	20 20                	and    BYTE PTR [bx+si],ah
 541:	20 20                	and    BYTE PTR [bx+si],ah
 543:	20 20                	and    BYTE PTR [bx+si],ah
 545:	20 20                	and    BYTE PTR [bx+si],ah
 547:	20 20                	and    BYTE PTR [bx+si],ah
 549:	20 20                	and    BYTE PTR [bx+si],ah
 54b:	20 20                	and    BYTE PTR [bx+si],ah
 54d:	20 20                	and    BYTE PTR [bx+si],ah
 54f:	20 20                	and    BYTE PTR [bx+si],ah
 551:	20 20                	and    BYTE PTR [bx+si],ah
 553:	20 20                	and    BYTE PTR [bx+si],ah
 555:	20 20                	and    BYTE PTR [bx+si],ah
 557:	20 20                	and    BYTE PTR [bx+si],ah
 559:	20 20                	and    BYTE PTR [bx+si],ah
 55b:	20 20                	and    BYTE PTR [bx+si],ah
 55d:	20 20                	and    BYTE PTR [bx+si],ah
 55f:	20 20                	and    BYTE PTR [bx+si],ah
 561:	20 20                	and    BYTE PTR [bx+si],ah
 563:	20 20                	and    BYTE PTR [bx+si],ah
 565:	20 20                	and    BYTE PTR [bx+si],ah
 567:	20 20                	and    BYTE PTR [bx+si],ah
 569:	20 20                	and    BYTE PTR [bx+si],ah
 56b:	20 20                	and    BYTE PTR [bx+si],ah
 56d:	20 20                	and    BYTE PTR [bx+si],ah
 56f:	20 ff                	and    bh,bh
 571:	52                   	push   dx
 572:	e9 73 65             	jmp    0x6ae8
 575:	72 76                	jb     0x5ed
 577:	e9 65 20             	jmp    0x25df
 57a:	e0 20                	loopne 0x59c
 57c:	4c                   	dec    sp
 57d:	41                   	inc    cx
 57e:	42                   	inc    dx
 57f:	4f                   	dec    di
 580:	44                   	inc    sp
 581:	49                   	dec    cx
 582:	44                   	inc    sp
 583:	41                   	inc    cx
 584:	43                   	inc    bx
 585:	54                   	push   sp
 586:	20 20                	and    BYTE PTR [bx+si],ah
 588:	20 20                	and    BYTE PTR [bx+si],ah
 58a:	20 20                	and    BYTE PTR [bx+si],ah
 58c:	20 20                	and    BYTE PTR [bx+si],ah
 58e:	20 20                	and    BYTE PTR [bx+si],ah
 590:	20 20                	and    BYTE PTR [bx+si],ah
 592:	20 20                	and    BYTE PTR [bx+si],ah
 594:	20 20                	and    BYTE PTR [bx+si],ah
 596:	20 20                	and    BYTE PTR [bx+si],ah
 598:	20 20                	and    BYTE PTR [bx+si],ah
 59a:	20 20                	and    BYTE PTR [bx+si],ah
 59c:	20 20                	and    BYTE PTR [bx+si],ah
 59e:	20 20                	and    BYTE PTR [bx+si],ah
 5a0:	20 20                	and    BYTE PTR [bx+si],ah
 5a2:	20 20                	and    BYTE PTR [bx+si],ah
 5a4:	20 20                	and    BYTE PTR [bx+si],ah
 5a6:	20 20                	and    BYTE PTR [bx+si],ah
 5a8:	20 20                	and    BYTE PTR [bx+si],ah
 5aa:	20 20                	and    BYTE PTR [bx+si],ah
 5ac:	20 20                	and    BYTE PTR [bx+si],ah
 5ae:	20 20                	and    BYTE PTR [bx+si],ah
 5b0:	20 20                	and    BYTE PTR [bx+si],ah
 5b2:	20 20                	and    BYTE PTR [bx+si],ah
 5b4:	20 20                	and    BYTE PTR [bx+si],ah
 5b6:	20 20                	and    BYTE PTR [bx+si],ah
 5b8:	20 20                	and    BYTE PTR [bx+si],ah
 5ba:	20 20                	and    BYTE PTR [bx+si],ah
 5bc:	20 20                	and    BYTE PTR [bx+si],ah
 5be:	20 20                	and    BYTE PTR [bx+si],ah
 5c0:	20 20                	and    BYTE PTR [bx+si],ah
 5c2:	20 20                	and    BYTE PTR [bx+si],ah
 5c4:	20 20                	and    BYTE PTR [bx+si],ah
 5c6:	20 20                	and    BYTE PTR [bx+si],ah
 5c8:	20 20                	and    BYTE PTR [bx+si],ah
 5ca:	20 20                	and    BYTE PTR [bx+si],ah
 5cc:	20 20                	and    BYTE PTR [bx+si],ah
 5ce:	20 20                	and    BYTE PTR [bx+si],ah
 5d0:	20 20                	and    BYTE PTR [bx+si],ah
 5d2:	20 20                	and    BYTE PTR [bx+si],ah
 5d4:	20 20                	and    BYTE PTR [bx+si],ah
 5d6:	20 20                	and    BYTE PTR [bx+si],ah
 5d8:	20 20                	and    BYTE PTR [bx+si],ah
 5da:	20 20                	and    BYTE PTR [bx+si],ah
 5dc:	20 20                	and    BYTE PTR [bx+si],ah
 5de:	20 20                	and    BYTE PTR [bx+si],ah
 5e0:	20 20                	and    BYTE PTR [bx+si],ah
 5e2:	20 20                	and    BYTE PTR [bx+si],ah
 5e4:	20 20                	and    BYTE PTR [bx+si],ah
 5e6:	20 20                	and    BYTE PTR [bx+si],ah
 5e8:	20 20                	and    BYTE PTR [bx+si],ah
 5ea:	20 20                	and    BYTE PTR [bx+si],ah
 5ec:	20 20                	and    BYTE PTR [bx+si],ah
 5ee:	20 20                	and    BYTE PTR [bx+si],ah
 5f0:	20 20                	and    BYTE PTR [bx+si],ah
 5f2:	20 20                	and    BYTE PTR [bx+si],ah
 5f4:	20 20                	and    BYTE PTR [bx+si],ah
 5f6:	20 20                	and    BYTE PTR [bx+si],ah
 5f8:	20 20                	and    BYTE PTR [bx+si],ah
 5fa:	20 20                	and    BYTE PTR [bx+si],ah
 5fc:	20 20                	and    BYTE PTR [bx+si],ah
 5fe:	20 20                	and    BYTE PTR [bx+si],ah
 600:	20 20                	and    BYTE PTR [bx+si],ah
 602:	20 20                	and    BYTE PTR [bx+si],ah
 604:	20 20                	and    BYTE PTR [bx+si],ah
 606:	20 20                	and    BYTE PTR [bx+si],ah
 608:	20 20                	and    BYTE PTR [bx+si],ah
 60a:	20 20                	and    BYTE PTR [bx+si],ah
 60c:	20 20                	and    BYTE PTR [bx+si],ah
 60e:	20 20                	and    BYTE PTR [bx+si],ah
 610:	20 20                	and    BYTE PTR [bx+si],ah
 612:	20 20                	and    BYTE PTR [bx+si],ah
 614:	20 20                	and    BYTE PTR [bx+si],ah
 616:	20 20                	and    BYTE PTR [bx+si],ah
 618:	20 20                	and    BYTE PTR [bx+si],ah
 61a:	20 20                	and    BYTE PTR [bx+si],ah
 61c:	20 20                	and    BYTE PTR [bx+si],ah
 61e:	20 20                	and    BYTE PTR [bx+si],ah
 620:	20 20                	and    BYTE PTR [bx+si],ah
 622:	20 20                	and    BYTE PTR [bx+si],ah
 624:	20 20                	and    BYTE PTR [bx+si],ah
 626:	20 20                	and    BYTE PTR [bx+si],ah
 628:	20 20                	and    BYTE PTR [bx+si],ah
 62a:	20 20                	and    BYTE PTR [bx+si],ah
 62c:	20 20                	and    BYTE PTR [bx+si],ah
 62e:	20 20                	and    BYTE PTR [bx+si],ah
 630:	20 20                	and    BYTE PTR [bx+si],ah
 632:	20 20                	and    BYTE PTR [bx+si],ah
 634:	20 20                	and    BYTE PTR [bx+si],ah
 636:	20 20                	and    BYTE PTR [bx+si],ah
 638:	20 20                	and    BYTE PTR [bx+si],ah
 63a:	20 20                	and    BYTE PTR [bx+si],ah
 63c:	20 20                	and    BYTE PTR [bx+si],ah
 63e:	20 20                	and    BYTE PTR [bx+si],ah
 640:	20 20                	and    BYTE PTR [bx+si],ah
 642:	20 20                	and    BYTE PTR [bx+si],ah
 644:	20 20                	and    BYTE PTR [bx+si],ah
 646:	20 20                	and    BYTE PTR [bx+si],ah
 648:	20 20                	and    BYTE PTR [bx+si],ah
 64a:	20 20                	and    BYTE PTR [bx+si],ah
 64c:	20 20                	and    BYTE PTR [bx+si],ah
 64e:	20 20                	and    BYTE PTR [bx+si],ah
 650:	20 20                	and    BYTE PTR [bx+si],ah
 652:	20 20                	and    BYTE PTR [bx+si],ah
 654:	20 20                	and    BYTE PTR [bx+si],ah
 656:	20 20                	and    BYTE PTR [bx+si],ah
 658:	20 20                	and    BYTE PTR [bx+si],ah
 65a:	20 20                	and    BYTE PTR [bx+si],ah
 65c:	20 20                	and    BYTE PTR [bx+si],ah
 65e:	20 20                	and    BYTE PTR [bx+si],ah
 660:	20 20                	and    BYTE PTR [bx+si],ah
 662:	20 20                	and    BYTE PTR [bx+si],ah
 664:	20 20                	and    BYTE PTR [bx+si],ah
 666:	20 20                	and    BYTE PTR [bx+si],ah
 668:	20 20                	and    BYTE PTR [bx+si],ah
 66a:	20 20                	and    BYTE PTR [bx+si],ah
 66c:	20 20                	and    BYTE PTR [bx+si],ah
 66e:	20 20                	and    BYTE PTR [bx+si],ah
 670:	ff 20                	jmp    WORD PTR [bx+si]
 672:	20 20                	and    BYTE PTR [bx+si],ah
 674:	20 20                	and    BYTE PTR [bx+si],ah
 676:	20 20                	and    BYTE PTR [bx+si],ah
 678:	20 20                	and    BYTE PTR [bx+si],ah
 67a:	20 20                	and    BYTE PTR [bx+si],ah
 67c:	20 20                	and    BYTE PTR [bx+si],ah
 67e:	20 20                	and    BYTE PTR [bx+si],ah
 680:	20 20                	and    BYTE PTR [bx+si],ah
 682:	20 20                	and    BYTE PTR [bx+si],ah
 684:	20 20                	and    BYTE PTR [bx+si],ah
 686:	20 20                	and    BYTE PTR [bx+si],ah
 688:	20 20                	and    BYTE PTR [bx+si],ah
 68a:	20 20                	and    BYTE PTR [bx+si],ah
 68c:	20 20                	and    BYTE PTR [bx+si],ah
 68e:	20 20                	and    BYTE PTR [bx+si],ah
 690:	20 20                	and    BYTE PTR [bx+si],ah
 692:	20 20                	and    BYTE PTR [bx+si],ah
 694:	20 20                	and    BYTE PTR [bx+si],ah
 696:	20 20                	and    BYTE PTR [bx+si],ah
 698:	20 20                	and    BYTE PTR [bx+si],ah
 69a:	20 20                	and    BYTE PTR [bx+si],ah
 69c:	20 20                	and    BYTE PTR [bx+si],ah
 69e:	20 20                	and    BYTE PTR [bx+si],ah
 6a0:	20 20                	and    BYTE PTR [bx+si],ah
 6a2:	20 20                	and    BYTE PTR [bx+si],ah
 6a4:	20 20                	and    BYTE PTR [bx+si],ah
 6a6:	20 20                	and    BYTE PTR [bx+si],ah
 6a8:	20 20                	and    BYTE PTR [bx+si],ah
 6aa:	20 20                	and    BYTE PTR [bx+si],ah
 6ac:	20 20                	and    BYTE PTR [bx+si],ah
 6ae:	20 20                	and    BYTE PTR [bx+si],ah
 6b0:	20 20                	and    BYTE PTR [bx+si],ah
 6b2:	20 20                	and    BYTE PTR [bx+si],ah
 6b4:	20 20                	and    BYTE PTR [bx+si],ah
 6b6:	20 20                	and    BYTE PTR [bx+si],ah
 6b8:	20 20                	and    BYTE PTR [bx+si],ah
 6ba:	20 20                	and    BYTE PTR [bx+si],ah
 6bc:	20 20                	and    BYTE PTR [bx+si],ah
 6be:	20 20                	and    BYTE PTR [bx+si],ah
 6c0:	20 20                	and    BYTE PTR [bx+si],ah
 6c2:	20 20                	and    BYTE PTR [bx+si],ah
 6c4:	20 20                	and    BYTE PTR [bx+si],ah
 6c6:	20 20                	and    BYTE PTR [bx+si],ah
 6c8:	20 20                	and    BYTE PTR [bx+si],ah
 6ca:	20 20                	and    BYTE PTR [bx+si],ah
 6cc:	20 20                	and    BYTE PTR [bx+si],ah
 6ce:	20 20                	and    BYTE PTR [bx+si],ah
 6d0:	20 20                	and    BYTE PTR [bx+si],ah
 6d2:	20 20                	and    BYTE PTR [bx+si],ah
 6d4:	20 20                	and    BYTE PTR [bx+si],ah
 6d6:	20 20                	and    BYTE PTR [bx+si],ah
 6d8:	20 20                	and    BYTE PTR [bx+si],ah
 6da:	20 20                	and    BYTE PTR [bx+si],ah
 6dc:	20 20                	and    BYTE PTR [bx+si],ah
 6de:	20 20                	and    BYTE PTR [bx+si],ah
 6e0:	20 20                	and    BYTE PTR [bx+si],ah
 6e2:	20 20                	and    BYTE PTR [bx+si],ah
 6e4:	20 20                	and    BYTE PTR [bx+si],ah
 6e6:	20 20                	and    BYTE PTR [bx+si],ah
 6e8:	20 20                	and    BYTE PTR [bx+si],ah
 6ea:	20 20                	and    BYTE PTR [bx+si],ah
 6ec:	20 20                	and    BYTE PTR [bx+si],ah
 6ee:	20 20                	and    BYTE PTR [bx+si],ah
 6f0:	20 20                	and    BYTE PTR [bx+si],ah
 6f2:	20 20                	and    BYTE PTR [bx+si],ah
 6f4:	20 20                	and    BYTE PTR [bx+si],ah
 6f6:	20 20                	and    BYTE PTR [bx+si],ah
 6f8:	20 20                	and    BYTE PTR [bx+si],ah
 6fa:	20 20                	and    BYTE PTR [bx+si],ah
 6fc:	20 20                	and    BYTE PTR [bx+si],ah
 6fe:	20 20                	and    BYTE PTR [bx+si],ah
 700:	20 20                	and    BYTE PTR [bx+si],ah
 702:	20 20                	and    BYTE PTR [bx+si],ah
 704:	20 20                	and    BYTE PTR [bx+si],ah
 706:	20 20                	and    BYTE PTR [bx+si],ah
 708:	20 20                	and    BYTE PTR [bx+si],ah
 70a:	20 20                	and    BYTE PTR [bx+si],ah
 70c:	20 20                	and    BYTE PTR [bx+si],ah
 70e:	20 20                	and    BYTE PTR [bx+si],ah
 710:	20 20                	and    BYTE PTR [bx+si],ah
 712:	20 20                	and    BYTE PTR [bx+si],ah
 714:	20 20                	and    BYTE PTR [bx+si],ah
 716:	20 20                	and    BYTE PTR [bx+si],ah
 718:	20 20                	and    BYTE PTR [bx+si],ah
 71a:	20 20                	and    BYTE PTR [bx+si],ah
 71c:	20 20                	and    BYTE PTR [bx+si],ah
 71e:	20 20                	and    BYTE PTR [bx+si],ah
 720:	20 20                	and    BYTE PTR [bx+si],ah
 722:	20 20                	and    BYTE PTR [bx+si],ah
 724:	20 20                	and    BYTE PTR [bx+si],ah
 726:	20 20                	and    BYTE PTR [bx+si],ah
 728:	20 20                	and    BYTE PTR [bx+si],ah
 72a:	20 20                	and    BYTE PTR [bx+si],ah
 72c:	20 20                	and    BYTE PTR [bx+si],ah
 72e:	20 20                	and    BYTE PTR [bx+si],ah
 730:	20 20                	and    BYTE PTR [bx+si],ah
 732:	20 20                	and    BYTE PTR [bx+si],ah
 734:	20 20                	and    BYTE PTR [bx+si],ah
 736:	20 20                	and    BYTE PTR [bx+si],ah
 738:	20 20                	and    BYTE PTR [bx+si],ah
 73a:	20 20                	and    BYTE PTR [bx+si],ah
 73c:	20 20                	and    BYTE PTR [bx+si],ah
 73e:	20 20                	and    BYTE PTR [bx+si],ah
 740:	20 20                	and    BYTE PTR [bx+si],ah
 742:	20 20                	and    BYTE PTR [bx+si],ah
 744:	20 20                	and    BYTE PTR [bx+si],ah
 746:	20 20                	and    BYTE PTR [bx+si],ah
 748:	20 20                	and    BYTE PTR [bx+si],ah
 74a:	20 20                	and    BYTE PTR [bx+si],ah
 74c:	20 20                	and    BYTE PTR [bx+si],ah
 74e:	20 20                	and    BYTE PTR [bx+si],ah
 750:	20 20                	and    BYTE PTR [bx+si],ah
 752:	20 20                	and    BYTE PTR [bx+si],ah
 754:	20 20                	and    BYTE PTR [bx+si],ah
 756:	20 20                	and    BYTE PTR [bx+si],ah
 758:	20 20                	and    BYTE PTR [bx+si],ah
 75a:	20 20                	and    BYTE PTR [bx+si],ah
 75c:	20 20                	and    BYTE PTR [bx+si],ah
 75e:	20 20                	and    BYTE PTR [bx+si],ah
 760:	20 20                	and    BYTE PTR [bx+si],ah
 762:	20 20                	and    BYTE PTR [bx+si],ah
 764:	20 20                	and    BYTE PTR [bx+si],ah
 766:	20 20                	and    BYTE PTR [bx+si],ah
 768:	20 20                	and    BYTE PTR [bx+si],ah
 76a:	20 20                	and    BYTE PTR [bx+si],ah
 76c:	20 20                	and    BYTE PTR [bx+si],ah
 76e:	20 20                	and    BYTE PTR [bx+si],ah
 770:	0a 31                	or     dh,BYTE PTR [bx+di]
 772:	31 2f                	xor    WORD PTR [bx],bp
 774:	30 36 2f 32          	xor    BYTE PTR ds:0x322f,dh
 778:	30 30                	xor    BYTE PTR [bx+si],dh
 77a:	36 42                	ss inc dx
 77c:	85 01                	test   WORD PTR [bx+di],ax
 77e:	2d 01 27             	sub    ax,0x2701
 781:	01 07                	add    WORD PTR [bx],ax
 783:	01 1c                	add    WORD PTR [si],bx
 785:	0e                   	push   cs
 786:	28 0c                	sub    BYTE PTR [si],cl
 788:	4f                   	dec    di
 789:	01 16 15 c1          	add    WORD PTR ds:0xc115,dx
 78d:	0f 29 2b             	movaps XMMWORD PTR [bp+di],xmm5
 790:	67 3e 60             	addr32 ds pusha
 793:	36 e9 01 2d          	ss jmp 0x3498
 797:	03 e1                	add    sp,cx
 799:	31 29                	xor    WORD PTR [bx+di],bp
 79b:	1e                   	push   ds
 79c:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 79d:	0c 8c                	or     al,0x8c
 79f:	0d 29 01             	or     ax,0x129
 7a2:	23 2c                	and    bp,WORD PTR [si]
 7a4:	97                   	xchg   di,ax
 7a5:	41                   	inc    cx
 7a6:	29 39                	sub    WORD PTR [bx+di],di
 7a8:	1b 24                	sbb    sp,WORD PTR [si]
 7aa:	84 26 06 01          	test   BYTE PTR ds:0x106,ah
 7ae:	1e                   	push   ds
 7af:	10 42 15             	adc    BYTE PTR [bp+si+0x15],al
 7b2:	29 27                	sub    WORD PTR [bx],sp
 7b4:	1d 47 35             	sbb    ax,0x3547
 7b7:	3a 44 01             	cmp    al,BYTE PTR [si+0x1]
 7ba:	03 32                	add    si,WORD PTR [bp+si]
 7bc:	57                   	push   di
 7bd:	13 29                	adc    bp,WORD PTR [bx+di]
 7bf:	02 67 2d             	add    ah,BYTE PTR [bx+0x2d]
 7c2:	be 21 ea             	mov    si,0xea21
 7c5:	01 03                	add    WORD PTR [bp+di],ax
 7c7:	3e 53                	ds push bx
 7c9:	1e                   	push   ds
 7ca:	29 1d                	sub    WORD PTR [di],bx
 7cc:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 7cd:	32 50 11             	xor    dl,BYTE PTR [bx+si+0x11]
 7d0:	29 01                	sub    WORD PTR [bx+di],ax
 7d2:	1e                   	push   ds
 7d3:	1b 01                	sbb    ax,WORD PTR [bx+di]
 7d5:	0c 29                	or     al,0x29
 7d7:	02 07                	add    al,BYTE PTR [bx]
 7d9:	1b 17                	sbb    dx,WORD PTR [bx]
 7db:	0c 49                	or     al,0x49
 7dd:	01 02                	add    WORD PTR [bp+si],ax
 7df:	1a d4                	sbb    dl,ah
 7e1:	4b                   	dec    bx
 7e2:	29 0e 11 2f          	sub    WORD PTR ds:0x2f11,cx
 7e6:	8e 15                	mov    ss,WORD PTR [di]
 7e8:	4e                   	dec    si
 7e9:	01 0a                	add    WORD PTR [bp+si],cx
 7eb:	30 c1                	xor    cl,al
 7ed:	29 29                	sub    WORD PTR [bx+di],bp
 7ef:	16                   	push   ss
 7f0:	67 2f                	addr32 das
 7f2:	5f                   	pop    di
 7f3:	21 e7                	and    di,sp
 7f5:	01 0f                	add    WORD PTR [bx],cx
 7f7:	0a 81 4a 29          	or     al,BYTE PTR [bx+di+0x294a]
 7fb:	40                   	inc    ax
 7fc:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 7fd:	47                   	inc    di
 7fe:	84 06 29 01          	test   BYTE PTR ds:0x129,al
 802:	29 49 97             	sub    WORD PTR [bx+di-0x69],cx
 805:	04 29                	add    al,0x29
 807:	4b                   	dec    bx
 808:	0b 2c                	or     bp,WORD PTR [si]
 80a:	fa                   	cli
 80b:	2c 95                	sub    al,0x95
 80d:	01 14                	add    WORD PTR [si],dx
 80f:	0f 42 22             	cmovb  sp,WORD PTR [bp+si]
 812:	29 05                	sub    WORD PTR [di],ax
 814:	4d                   	dec    bp
 815:	09 af 37 6a          	or     WORD PTR [bx+0x6a37],bp
 819:	01 11                	add    WORD PTR [bx+di],dx
 81b:	20 57 23             	and    BYTE PTR [bx+0x23],dl
 81e:	29 04                	sub    WORD PTR [si],ax
 820:	67 28 99 4c ea 01 21 	sub    BYTE PTR [ecx+0x2101ea4c],bl
 827:	1b 93 0f 29          	sbb    dx,WORD PTR [bp+di+0x290f]
 82b:	0a 67 30             	or     ah,BYTE PTR [bx+0x30]
 82e:	9e                   	sahf
 82f:	1c 29                	sbb    al,0x29
 831:	01 16 1b 01          	add    WORD PTR ds:0x11b,dx
 835:	4a                   	dec    dx
 836:	29 2a                	sub    WORD PTR [bp+si],bp
 838:	97                   	xchg   di,ax
 839:	0c 4b                	or     al,0x4b
 83b:	2d 1a 01             	sub    ax,0x11a
 83e:	03 4c d4             	add    cx,WORD PTR [si-0x2c]
 841:	31 29                	xor    WORD PTR [bx+di],bp
 843:	15 c0 40             	adc    ax,0x40c0
 846:	c2 2e 6d             	ret    0x6d2e
 849:	01 30                	add    WORD PTR [bx+si],si
 84b:	49                   	dec    cx
 84c:	c1 34 29             	shl    WORD PTR [si],0x29
 84f:	0f                   	xcrypt-ecb (bad)
 850:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 851:	08 66 17             	or     BYTE PTR [bp+0x17],ah
 854:	e8 01 09             	call   0x1158
 857:	32 81 46 29          	xor    al,BYTE PTR [bx+di+0x2946]
 85b:	0c 27                	or     al,0x27
 85d:	16                   	push   ss
 85e:	d2 2e 2a 01          	shr    BYTE PTR ds:0x12a,cl
 862:	2b 13                	sub    dx,WORD PTR [bp+di]
 864:	97                   	xchg   di,ax
 865:	38 29                	cmp    BYTE PTR [bx+di],ch
 867:	1b db                	sbb    bx,bx
 869:	1c 8f                	sbb    al,0x8f
 86b:	3e 84 01             	test   BYTE PTR ds:[bx+di],al
 86e:	30 51 42             	xor    BYTE PTR [bx+di+0x42],dl
 871:	18 29                	sbb    BYTE PTR [bx+di],ch
 873:	20 5c 4e             	and    BYTE PTR [si+0x4e],bl
 876:	e2 4f                	loop   0x8c7
 878:	69 01 27 24          	imul   ax,WORD PTR [bx+di],0x2427
 87c:	57                   	push   di
 87d:	1b 29                	sbb    bp,WORD PTR [bx+di]
 87f:	43                   	inc    bx
 880:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 881:	41                   	inc    cx
 882:	e1 2f                	loope  0x8b3
 884:	eb 01                	jmp    0x887
 886:	0b 3e b3 1e          	or     di,WORD PTR ds:0x1eb3
 88a:	29 3e e7 25          	sub    WORD PTR ds:0x25e7,di
 88e:	cc                   	int3
 88f:	34 2a                	xor    al,0x2a
 891:	01 09                	add    WORD PTR [bx+di],cx
 893:	25 02 39             	and    ax,0x3902
 896:	29 36 87 13          	sub    WORD PTR ds:0x1387,si
 89a:	ac                   	lods   al,BYTE PTR ds:[si]
 89b:	08 88 01 30          	or     BYTE PTR [bx+si+0x3001],cl
 89f:	1f                   	pop    ds
 8a0:	d4 46                	aam    0x46
 8a2:	29 39                	sub    WORD PTR [bx+di],di
 8a4:	50                   	push   ax
 8a5:	03 12                	add    dx,WORD PTR [bp+si]
 8a7:	24 ae                	and    al,0xae
 8a9:	01 03                	add    WORD PTR [bp+di],ax
 8ab:	07                   	pop    es
 8ac:	c1 0e 29 4d 24       	ror    WORD PTR ds:0x4d29,0x24
 8b1:	1c 3b                	sbb    al,0x3b
 8b3:	20 e8                	and    al,ch
 8b5:	01 2a                	add    WORD PTR [bp+si],bp
 8b7:	03 a1 2b 29          	add    sp,WORD PTR [bx+di+0x292b]
 8bb:	0f                   	xstore-rng (bad)
 8bc:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 8bd:	04 cc                	add    al,0xcc
 8bf:	11 2a                	adc    WORD PTR [bp+si],bp
 8c1:	01 11                	add    WORD PTR [bx+di],dx
 8c3:	44                   	inc    sp
 8c4:	94                   	xchg   sp,ax
 8c5:	1d 29 0a             	sbb    ax,0xa29
 8c8:	0b 2b                	or     bp,WORD PTR [bp+di]
 8ca:	47                   	inc    di
 8cb:	1b 95 01 27          	sbb    dx,WORD PTR [di+0x2701]
 8cf:	03 42 12             	add    ax,WORD PTR [bp+si+0x12]
 8d2:	29 36 4d 4d          	sub    WORD PTR ds:0x4d4d,si
 8d6:	d5 4d                	aad    0x4d
 8d8:	89 01                	mov    WORD PTR [bx+di],ax
 8da:	25 33 57             	and    ax,0x5733
 8dd:	24 29                	and    al,0x29
 8df:	16                   	push   ss
 8e0:	e4 07                	in     al,0x7
 8e2:	81 24 ea 01          	and    WORD PTR [si],0x1ea
 8e6:	03 4f 33             	add    cx,WORD PTR [bx+0x33]
 8e9:	44                   	inc    sp
 8ea:	29 0f                	sub    WORD PTR [bx],cx
 8ec:	67 49                	addr32 dec cx
 8ee:	68 10 2a             	push   0x2a10
 8f1:	01 13                	add    WORD PTR [bp+di],dx
 8f3:	1d 02 38             	sbb    ax,0x3802
 8f6:	29 17                	sub    WORD PTR [bx],dx
 8f8:	97                   	xchg   di,ax
 8f9:	04 a1                	add    al,0xa1
 8fb:	2b 99 01 1d          	sub    bx,WORD PTR [bx+di+0x1d01]
 8ff:	08 d4                	or     ah,dl
 901:	38 29                	cmp    BYTE PTR [bx+di],ch
 903:	10 46 51             	adc    BYTE PTR [bp+0x51],al
 906:	4d                   	dec    bp
 907:	3b 8c 01 2d          	cmp    cx,WORD PTR [si+0x2d01]
 90b:	2c c1                	sub    al,0xc1
 90d:	40                   	inc    ax
 90e:	29 37                	sub    WORD PTR [bx],si
 910:	64 0d 0d 33          	fs or  ax,0x330d
 914:	ed                   	in     ax,dx
 915:	01 28                	add    WORD PTR [bx+si],bp
 917:	51                   	push   cx
 918:	a1 51 29             	mov    ax,ds:0x2951
 91b:	0c a7                	or     al,0xa7
 91d:	40                   	inc    ax
 91e:	dc 1a                	fcomp  QWORD PTR [bp+si]
 920:	29 01                	sub    WORD PTR [bx+di],ax
 922:	2e 04 94             	cs add al,0x94
 925:	02 29                	add    ch,BYTE PTR [bx+di]
 927:	19 1b                	sbb    WORD PTR [bp+di],bx
 929:	06                   	push   es
 92a:	75 50                	jne    0x97c
 92c:	85 01                	test   WORD PTR [bx+di],ax
 92e:	0d 2f 42             	or     ax,0x422f
 931:	47                   	inc    di
 932:	29 34                	sub    WORD PTR [si],si
 934:	db 22                	(bad)  [bp+si]
 936:	ae                   	scas   al,BYTE PTR es:[di]
 937:	12 87 01 23          	adc    al,BYTE PTR [bx+0x2301]
 93b:	16                   	push   ss
 93c:	57                   	push   di
 93d:	34 29                	xor    al,0x29
 93f:	43                   	inc    bx
 940:	64 3f                	fs aas
 942:	f9                   	stc
 943:	20 ec                	and    ah,ch
 945:	01 22                	add    WORD PTR [bp+si],sp
 947:	27                   	daa
 948:	13 3d                	adc    di,WORD PTR [di]
 94a:	29 32                	sub    WORD PTR [bp+si],si
 94c:	27                   	daa
 94d:	17                   	pop    ss
 94e:	1c 08                	sbb    al,0x8
 950:	29 01                	sub    WORD PTR [bx+di],ax
 952:	30 2d                	xor    BYTE PTR [di],ch
 954:	02 19                	add    bl,BYTE PTR [bx+di]
 956:	29 27                	sub    WORD PTR [bx],sp
 958:	07                   	pop    es
 959:	50                   	push   ax
 95a:	e4 17                	in     al,0x17
 95c:	ca 01 25             	retf   0x2501
 95f:	4f                   	dec    di
 960:	d4 2b                	aam    0x2b
 962:	29 1a                	sub    WORD PTR [bp+si],bx
 964:	14 0c                	adc    al,0xc
 966:	12 28                	adc    ch,BYTE PTR [bx+si]
 968:	0d 01 31             	or     ax,0x3101
 96b:	08 c1                	or     cl,al
 96d:	17                   	pop    ss
 96e:	29 13                	sub    WORD PTR [bp+di],dx
 970:	e4 02                	in     al,0x2
 972:	0e                   	push   cs
 973:	39 ec                	cmp    sp,bp
 975:	01 13                	add    WORD PTR [bp+di],dx
 977:	42                   	inc    dx
 978:	41                   	inc    cx
 979:	22 29                	and    ch,BYTE PTR [bx+di]
 97b:	2c 27                	sub    al,0x27
 97d:	04 60                	add    al,0x60
 97f:	3e 29 01             	sub    WORD PTR ds:[bx+di],ax
 982:	10 0c                	adc    BYTE PTR [si],cl
 984:	95                   	xchg   bp,ax
 985:	42                   	inc    dx
 986:	29 48 0b             	sub    WORD PTR [bx+si+0xb],cx
 989:	50                   	push   ax
 98a:	40                   	inc    ax
 98b:	45                   	inc    bp
 98c:	16                   	push   ss
 98d:	01 26 49 42          	add    WORD PTR ds:0x4249,sp
 991:	0d 29 48             	or     ax,0x4829
 994:	88 4c 10             	mov    BYTE PTR [si+0x10],cl
 997:	06                   	push   es
 998:	ab                   	stos   WORD PTR es:[di],ax
 999:	01 12                	add    WORD PTR [bp+si],dx
 99b:	15 57 0d             	adc    ax,0xd57
 99e:	29 0e a5 4a          	sub    WORD PTR ds:0x4aa5,cx
 9a2:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
 9a3:	32 ed                	xor    ch,ch
 9a5:	01 2b                	add    WORD PTR [bp+di],bp
 9a7:	09 d3                	or     bx,dx
 9a9:	42                   	inc    dx
 9aa:	29 35                	sub    WORD PTR [di],si
 9ac:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
 9ad:	46                   	inc    si
 9ae:	8a 0b                	mov    cl,BYTE PTR [bp+di]
 9b0:	26 01 1d             	add    WORD PTR es:[di],bx
 9b3:	18 03                	sbb    BYTE PTR [bp+di],al
 9b5:	1d 29 17             	sbb    ax,0x1729
 9b8:	97                   	xchg   di,ax
 9b9:	19 34                	sbb    WORD PTR [si],si
 9bb:	47                   	inc    di
 9bc:	15 01 0b             	adc    ax,0xb01
 9bf:	3d d4 3b             	cmp    ax,0x3bd4
 9c2:	29 10                	sub    WORD PTR [bx+si],dx
 9c4:	ca 24 e6             	retf   0xe624
 9c7:	37                   	aaa
 9c8:	2c 01                	sub    al,0x1
 9ca:	2c 4d                	sub    al,0x4d
 9cc:	c1 48 29 24          	ror    WORD PTR [bx+si+0x29],0x24
 9d0:	65 08 12             	or     BYTE PTR gs:[bp+si],dl
	...
 9db:	00 ff                	add    bh,bh
 9dd:	ff 00                	inc    WORD PTR [bx+si]
 9df:	00 69 6e             	add    BYTE PTR [bx+di+0x6e],ch
 9e2:	74 6c                	je     0xa50
 9e4:	00 73 43             	add    BYTE PTR [bp+di+0x43],dh
 9e7:	75 72                	jne    0xa5b
 9e9:	72 65                	jb     0xa50
 9eb:	6e                   	outs   dx,BYTE PTR ds:[si]
 9ec:	63 79 00             	arpl   WORD PTR [bx+di+0x0],di
 9ef:	69 43 75 72 72       	imul   ax,WORD PTR [bp+di+0x75],0x7272
 9f4:	65 6e                	outs   dx,BYTE PTR gs:[si]
 9f6:	63 79 00             	arpl   WORD PTR [bx+di+0x0],di
 9f9:	69 4e 65 67 43       	imul   cx,WORD PTR [bp+0x65],0x4367
 9fe:	75 72                	jne    0xa72
 a00:	72 00                	jb     0xa02
 a02:	73 54                	jae    0xa58
 a04:	68 6f 75             	push   0x756f
 a07:	73 61                	jae    0xa6a
 a09:	6e                   	outs   dx,BYTE PTR ds:[si]
 a0a:	64 00 73 44          	add    BYTE PTR fs:[bp+di+0x44],dh
 a0e:	65 63 69 6d          	arpl   WORD PTR gs:[bx+di+0x6d],bp
 a12:	61                   	popa
 a13:	6c                   	ins    BYTE PTR es:[di],dx
 a14:	00 69 43             	add    BYTE PTR [bx+di+0x43],ch
 a17:	75 72                	jne    0xa8b
 a19:	72 44                	jb     0xa5f
 a1b:	69 67 69 74 73       	imul   sp,WORD PTR [bx+0x69],0x7374
 a20:	00 73 44             	add    BYTE PTR [bp+di+0x44],dh
 a23:	61                   	popa
 a24:	74 65                	je     0xa8b
 a26:	00 73 53             	add    BYTE PTR [bp+di+0x53],dh
 a29:	68 6f 72             	push   0x726f
 a2c:	74 44                	je     0xa72
 a2e:	61                   	popa
 a2f:	74 65                	je     0xa96
 a31:	00 73 4c             	add    BYTE PTR [bp+di+0x4c],dh
 a34:	6f                   	outs   dx,WORD PTR ds:[si]
 a35:	6e                   	outs   dx,BYTE PTR ds:[si]
 a36:	67 44                	addr32 inc sp
 a38:	61                   	popa
 a39:	74 65                	je     0xaa0
 a3b:	00 73 54             	add    BYTE PTR [bp+di+0x54],dh
 a3e:	69 6d 65 00 73       	imul   bp,WORD PTR [di+0x65],0x7300
 a43:	31 31                	xor    WORD PTR [bx+di],si
 a45:	35 39 00             	xor    ax,0x39
 a48:	73 32                	jae    0xa7c
 a4a:	33 35                	xor    si,WORD PTR [di]
 a4c:	39 00                	cmp    WORD PTR [bx+si],ax
 a4e:	69 54 4c 5a 65       	imul   dx,WORD PTR [si+0x4c],0x655a
 a53:	72 6f                	jb     0xac4
 a55:	00 69 54             	add    BYTE PTR [bx+di+0x54],ch
 a58:	69 6d 65 00 00       	imul   bp,WORD PTR [di+0x65],0x0
 a5d:	2e 00 00             	add    BYTE PTR cs:[bx+si],al
 a60:	02 00                	add    al,BYTE PTR [bx+si]
 a62:	89 ff                	mov    di,di
 a64:	03 00                	add    ax,WORD PTR [bx+si]
 a66:	8a ff                	mov    bh,bh
 a68:	04 00                	add    al,0x0
 a6a:	8b ff                	mov    di,di
 a6c:	05 00 8c             	add    ax,0x8c00
 a6f:	ff 0f                	dec    WORD PTR [bx]
 a71:	00 8d ff 64          	add    BYTE PTR [di+0x64ff],cl
 a75:	00 8e ff 65          	add    BYTE PTR [bp+0x65ff],cl
 a79:	00 8f ff 6a          	add    BYTE PTR [bx+0x6aff],cl
 a7d:	00 90 ff 00          	add    BYTE PTR [bx+si+0xff],dl
 a81:	00 00                	add    BYTE PTR [bx+si],al
 a83:	00 00                	add    BYTE PTR [bx+si],al
 a85:	00 00                	add    BYTE PTR [bx+si],al
 a87:	00 ff                	add    bh,bh
 a89:	ff 00                	inc    WORD PTR [bx+si]
 a8b:	00 98 ff ff          	add    BYTE PTR [bx+si-0x1],bl
 a8f:	ff 00                	inc    WORD PTR [bx+si]
 a91:	00 91 ff ff          	add    BYTE PTR [bx+di-0x1],dl
 a95:	ff 00                	inc    WORD PTR [bx+si]
 a97:	00 92 ff ff          	add    BYTE PTR [bp+si-0x1],dl
 a9b:	ff 00                	inc    WORD PTR [bx+si]
 a9d:	00 93 ff ff          	add    BYTE PTR [bp+di-0x1],dl
 aa1:	ff 00                	inc    WORD PTR [bx+si]
 aa3:	00 94 ff ff          	add    BYTE PTR [si-0x1],dl
 aa7:	ff 00                	inc    WORD PTR [bx+si]
 aa9:	00 95 ff ff          	add    BYTE PTR [di-0x1],dl
 aad:	ff 00                	inc    WORD PTR [bx+si]
 aaf:	00 96 ff ff          	add    BYTE PTR [bp-0x1],dl
 ab3:	ff 00                	inc    WORD PTR [bx+si]
 ab5:	00 97 ff ff          	add    BYTE PTR [bx-0x1],dl
 ab9:	ff 00                	inc    WORD PTR [bx+si]
 abb:	00 99 ff ff          	add    BYTE PTR [bx+di-0x1],bl
 abf:	ff 00                	inc    WORD PTR [bx+si]
 ac1:	00 9f ff ff          	add    BYTE PTR [bx-0x1],bl
 ac5:	ff 00                	inc    WORD PTR [bx+si]
 ac7:	00 9e ff ff          	add    BYTE PTR [bp-0x1],bl
 acb:	ff 00                	inc    WORD PTR [bx+si]
 acd:	00 9d ff ff          	add    BYTE PTR [di-0x1],bl
 ad1:	ff 00                	inc    WORD PTR [bx+si]
 ad3:	00 9b ff ff          	add    BYTE PTR [bp+di-0x1],bl
 ad7:	ff 00                	inc    WORD PTR [bx+si]
 ad9:	00 9a ff ff          	add    BYTE PTR [bp+si-0x1],bl
 add:	ff 00                	inc    WORD PTR [bx+si]
 adf:	00 9c ff 00          	add    BYTE PTR [si+0xff],bl
	...
 b07:	00 00                	add    BYTE PTR [bx+si],al
 b09:	10 00                	adc    BYTE PTR [bx+si],al
	...
 b13:	02 00                	add    al,BYTE PTR [bx+si]
	...
 b21:	04 00                	add    al,0x0
 b23:	20 02                	and    BYTE PTR [bp+si],al
 b25:	00 00                	add    BYTE PTR [bx+si],al
 b27:	00 00                	add    BYTE PTR [bx+si],al
 b29:	00 52 75             	add    BYTE PTR [bp+si+0x75],dl
 b2c:	6e                   	outs   dx,BYTE PTR ds:[si]
 b2d:	74 69                	je     0xb98
 b2f:	6d                   	ins    WORD PTR es:[di],dx
 b30:	65 20 65 72          	and    BYTE PTR gs:[di+0x72],ah
 b34:	72 6f                	jb     0xba5
 b36:	72 20                	jb     0xb58
 b38:	30 30                	xor    BYTE PTR [bx+si],dh
 b3a:	30 20                	xor    BYTE PTR [bx+si],ah
 b3c:	61                   	popa
 b3d:	74 20                	je     0xb5f
 b3f:	30 30                	xor    BYTE PTR [bx+si],dh
 b41:	30 30                	xor    BYTE PTR [bx+si],dh
 b43:	3a 30                	cmp    dh,BYTE PTR [bx+si]
 b45:	30 30                	xor    BYTE PTR [bx+si],dh
 b47:	30 2e 00 00          	xor    BYTE PTR ds:0x0,ch
 b4b:	01 00                	add    WORD PTR [bx+si],ax
 b4d:	00 04                	add    BYTE PTR [si],al
 b4f:	00 00                	add    BYTE PTR [bx+si],al
 b51:	07                   	pop    es
 b52:	00 00                	add    BYTE PTR [bx+si],al
 b54:	0a 00                	or     al,BYTE PTR [bx+si]
 b56:	00 0d                	add    BYTE PTR [di],cl
 b58:	00 00                	add    BYTE PTR [bx+si],al
 b5a:	00 00                	add    BYTE PTR [bx+si],al
 b5c:	70 3f                	jo     0xb9d
 b5e:	00 00                	add    BYTE PTR [bx+si],al
 b60:	88 3f                	mov    BYTE PTR [bx],bh
 b62:	00 00                	add    BYTE PTR [bx+si],al
 b64:	00 5f 00             	add    BYTE PTR [bx+0x0],bl
 b67:	00 00                	add    BYTE PTR [bx+si],al
 b69:	c0 7e 01 50          	sar    BYTE PTR [bp+0x1],0x50
 b6d:	41                   	inc    cx
 b6e:	00 00                	add    BYTE PTR [bx+si],al
 b70:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
 b74:	47                   	inc    di
 b75:	41                   	inc    cx
 b76:	00 00                	add    BYTE PTR [bx+si],al
 b78:	00 00                	add    BYTE PTR [bx+si],al
 b7a:	00 00                	add    BYTE PTR [bx+si],al
 b7c:	f0 3f                	lock aas
