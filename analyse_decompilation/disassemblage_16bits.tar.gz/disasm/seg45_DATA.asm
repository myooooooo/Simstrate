; ================================================================
; seg45_DATA  (4584 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	01 00                	add    WORD PTR [bx+si],ax
       2:	05 00 00             	add    ax,0x0
       5:	00 00                	add    BYTE PTR [bx+si],al
       7:	00 05                	add    BYTE PTR [di],al
       9:	3d 00 01             	cmp    ax,0x100
       c:	00 00                	add    BYTE PTR [bx+si],al
       e:	01 00                	add    WORD PTR [bx+si],ax
      10:	06                   	push   es
      11:	00 01                	add    BYTE PTR [bx+di],al
      13:	00 03                	add    BYTE PTR [bp+di],al
      15:	43                   	inc    bx
      16:	3a 5c fc             	cmp    bl,BYTE PTR [si-0x4]
      19:	00 01                	add    BYTE PTR [bx+di],al
      1b:	00 00                	add    BYTE PTR [bx+si],al
      1d:	06                   	push   es
      1e:	00 01                	add    BYTE PTR [bx+di],al
      20:	00 ff                	add    bh,bh
      22:	0d 00 01             	or     ax,0x100
      25:	00 00                	add    BYTE PTR [bx+si],al
      27:	01 00                	add    WORD PTR [bx+si],ax
      29:	06                   	push   es
      2a:	00 7c d5             	add    BYTE PTR [si-0x2b],bh
      2d:	40                   	inc    ax
      2e:	03 00                	add    ax,WORD PTR [bx+si]
      30:	0a 08                	or     cl,BYTE PTR [bx+si]
      32:	00 01                	add    BYTE PTR [bx+di],al
      34:	00 00                	add    BYTE PTR [bx+si],al
      36:	01 00                	add    WORD PTR [bx+si],ax
      38:	01 00                	add    WORD PTR [bx+si],ax
      3a:	40                   	inc    ax
      3b:	07                   	pop    es
      3c:	00 01                	add    BYTE PTR [bx+di],al
      3e:	00 00                	add    BYTE PTR [bx+si],al
      40:	01 00                	add    WORD PTR [bx+si],ax
      42:	02 00                	add    al,BYTE PTR [bx+si]
      44:	40                   	inc    ax
      45:	04 09                	add    al,0x9
      47:	00 01                	add    BYTE PTR [bx+di],al
      49:	00 00                	add    BYTE PTR [bx+si],al
      4b:	01 00                	add    WORD PTR [bx+si],ax
      4d:	1d 00 ff             	sbb    ax,0xff00
      50:	00 ff                	add    bh,bh
      52:	00 00                	add    BYTE PTR [bx+si],al
      54:	00 00                	add    BYTE PTR [bx+si],al
      56:	80 00 00             	add    BYTE PTR [bx+si],0x0
      59:	00 ff                	add    bh,bh
      5b:	00 00                	add    BYTE PTR [bx+si],al
      5d:	ff 00                	inc    WORD PTR [bx+si]
      5f:	ff 00                	inc    WORD PTR [bx+si]
      61:	00 ff                	add    bh,bh
      63:	ff 00                	inc    WORD PTR [bx+si]
      65:	00 00                	add    BYTE PTR [bx+si],al
      67:	00 00                	add    BYTE PTR [bx+si],al
      69:	c0 c0 c0             	rol    al,0xc0
      6c:	0d 00 01             	or     ax,0x100
      6f:	00 00                	add    BYTE PTR [bx+si],al
      71:	01 00                	add    WORD PTR [bx+si],ax
      73:	33 00                	xor    ax,WORD PTR [bx+si]
      75:	49                   	dec    cx
      76:	6d                   	ins    WORD PTR es:[di],dx
      77:	70 72                	jo     0xeb
      79:	65 73 73             	gs jae 0xef
      7c:	69 6f 6e 73 20       	imul   bp,WORD PTR [bx+0x6e],0x2073
      81:	74 65                	je     0xe8
      83:	72 6d                	jb     0xf2
      85:	69 6e e9 65 73       	imul   bp,WORD PTR [bp-0x17],0x7365
      8a:	20 3f                	and    BYTE PTR [bx],bh
      8c:	00 52 69             	add    BYTE PTR [bp+si+0x69],dl
      8f:	65 6e                	outs   dx,BYTE PTR gs:[si]
      91:	20 64 65             	and    BYTE PTR [si+0x65],ah
      94:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
      97:	63 68 e9             	arpl   WORD PTR [bx+si-0x17],bp
      9a:	20 21                	and    BYTE PTR [bx+di],ah
      9c:	00 45 72             	add    BYTE PTR [di+0x72],al
      9f:	72 65                	jb     0x106
      a1:	75 72                	jne    0x115
      a3:	00 00                	add    BYTE PTR [bx+si],al
      a5:	00 00                	add    BYTE PTR [bx+si],al
      a7:	42                   	inc    dx
      a8:	07                   	pop    es
      a9:	00 01                	add    BYTE PTR [bx+di],al
      ab:	00 00                	add    BYTE PTR [bx+si],al
      ad:	01 00                	add    WORD PTR [bx+si],ax
      af:	21 00                	and    WORD PTR [bx+si],ax
      b1:	02 00                	add    al,BYTE PTR [bx+si]
      b3:	04 00                	add    al,0x0
      b5:	28 00                	sub    BYTE PTR [bx+si],al
      b7:	43                   	inc    bx
      b8:	00 4a 00             	add    BYTE PTR [bp+si+0x0],cl
      bb:	5a                   	pop    dx
      bc:	00 5a 00             	add    BYTE PTR [bp+si+0x0],bl
      bf:	00 00                	add    BYTE PTR [bx+si],al
      c1:	00 00                	add    BYTE PTR [bx+si],al
      c3:	01 00                	add    WORD PTR [bx+si],ax
      c5:	02 00                	add    al,BYTE PTR [bx+si]
      c7:	04 00                	add    al,0x0
      c9:	26 00 36 00 49       	add    BYTE PTR es:0x4900,dh
      ce:	00 5a 00             	add    BYTE PTR [bp+si+0x0],bl
      d1:	5a                   	pop    dx
      d2:	07                   	pop    es
      d3:	00 01                	add    BYTE PTR [bx+di],al
      d5:	00 00                	add    BYTE PTR [bx+si],al
      d7:	01 00                	add    WORD PTR [bx+si],ax
      d9:	23 00                	and    ax,WORD PTR [bx+si]
      db:	02 00                	add    al,BYTE PTR [bx+si]
      dd:	24 00                	and    al,0x0
      df:	38 00                	cmp    BYTE PTR [bx+si],al
      e1:	5a                   	pop    dx
      e2:	00 6e 00             	add    BYTE PTR [bp+0x0],ch
      e5:	6e                   	outs   dx,BYTE PTR ds:[si]
      e6:	00 6e 00             	add    BYTE PTR [bp+0x0],ch
      e9:	00 00                	add    BYTE PTR [bx+si],al
      eb:	42                   	inc    dx
      ec:	00 00                	add    BYTE PTR [bx+si],al
      ee:	00 00                	add    BYTE PTR [bx+si],al
      f0:	00 02                	add    BYTE PTR [bp+si],al
      f2:	00 04                	add    BYTE PTR [si],al
      f4:	00 24                	add    BYTE PTR [si],ah
      f6:	00 40 00             	add    BYTE PTR [bx+si+0x0],al
      f9:	4a                   	dec    dx
      fa:	00 5a 00             	add    BYTE PTR [bp+si+0x0],bl
      fd:	5a                   	pop    dx
      fe:	07                   	pop    es
      ff:	00 01                	add    BYTE PTR [bx+di],al
     101:	00 00                	add    BYTE PTR [bx+si],al
     103:	01 00                	add    WORD PTR [bx+si],ax
     105:	0d 00 02             	or     ax,0x200
     108:	00 04                	add    BYTE PTR [si],al
     10a:	00 22                	add    BYTE PTR [bp+si],ah
     10c:	00 35                	add    BYTE PTR [di],dh
     10e:	00 48 00             	add    BYTE PTR [bx+si+0x0],cl
     111:	5a                   	pop    dx
     112:	00 5a 07             	add    BYTE PTR [bp+si+0x7],bl
     115:	00 01                	add    BYTE PTR [bx+di],al
     117:	00 00                	add    BYTE PTR [bx+si],al
     119:	01 00                	add    WORD PTR [bx+si],ax
     11b:	21 00                	and    WORD PTR [bx+si],ax
     11d:	02 00                	add    al,BYTE PTR [bx+si]
     11f:	17                   	pop    ss
     120:	00 24                	add    BYTE PTR [si],ah
     122:	00 43 00             	add    BYTE PTR [bp+di+0x0],al
     125:	4a                   	dec    dx
     126:	00 5a 00             	add    BYTE PTR [bp+si+0x0],bl
     129:	5a                   	pop    dx
     12a:	00 00                	add    BYTE PTR [bx+si],al
     12c:	00 00                	add    BYTE PTR [bx+si],al
     12e:	00 03                	add    BYTE PTR [bp+di],al
     130:	00 05                	add    BYTE PTR [di],al
     132:	00 07                	add    BYTE PTR [bx],al
     134:	00 27                	add    BYTE PTR [bx],ah
     136:	00 3a                	add    BYTE PTR [bp+si],bh
     138:	00 4d 00             	add    BYTE PTR [di+0x0],cl
     13b:	5a                   	pop    dx
     13c:	00 5a 09             	add    BYTE PTR [bp+si+0x9],bl
     13f:	01 01                	add    WORD PTR [bx+di],ax
     141:	00 00                	add    BYTE PTR [bx+si],al
     143:	01 00                	add    WORD PTR [bx+si],ax
     145:	0d 00 04             	or     ax,0x400
     148:	00 14                	add    BYTE PTR [si],dl
     14a:	00 28                	add    BYTE PTR [bx+si],ch
     14c:	00 3c                	add    BYTE PTR [si],bh
     14e:	00 4a 00             	add    BYTE PTR [bp+si+0x0],cl
     151:	4e                   	dec    si
     152:	00 4e 07             	add    BYTE PTR [bp+0x7],cl
     155:	01 01                	add    WORD PTR [bx+di],ax
     157:	00 00                	add    BYTE PTR [bx+si],al
     159:	01 00                	add    WORD PTR [bx+si],ax
     15b:	0d 00 04             	or     ax,0x400
     15e:	00 15                	add    BYTE PTR [di],dl
     160:	00 24                	add    BYTE PTR [si],ah
     162:	00 38                	add    BYTE PTR [bx+si],bh
     164:	00 46 00             	add    BYTE PTR [bp+0x0],al
     167:	4e                   	dec    si
     168:	00 4e 07             	add    BYTE PTR [bp+0x7],cl
     16b:	00 01                	add    BYTE PTR [bx+di],al
     16d:	00 00                	add    BYTE PTR [bx+si],al
     16f:	01 00                	add    WORD PTR [bx+si],ax
     171:	19 00                	sbb    WORD PTR [bx+si],ax
     173:	04 00                	add    al,0x0
     175:	08 00                	or     BYTE PTR [bx+si],al
     177:	24 00                	and    al,0x0
     179:	38 00                	cmp    BYTE PTR [bx+si],al
     17b:	4c                   	dec    sp
     17c:	00 4e 00             	add    BYTE PTR [bp+0x0],cl
     17f:	4e                   	dec    si
     180:	00 45 5f             	add    BYTE PTR [di+0x5f],al
     183:	41                   	inc    cx
     184:	75 74                	jne    0x1fa
     186:	72 65                	jb     0x1ed
     188:	20 2e 2e 2e          	and    BYTE PTR ds:0x2e2e,ch
     18c:	02 00                	add    al,BYTE PTR [bx+si]
     18e:	08 00                	or     BYTE PTR [bx+si],al
     190:	00 45 72             	add    BYTE PTR [di+0x72],al
     193:	72 65                	jb     0x1fa
     195:	75 72                	jne    0x209
     197:	00 01                	add    BYTE PTR [bx+di],al
     199:	00 42 00             	add    BYTE PTR [bp+si+0x0],al
     19c:	45                   	inc    bp
     19d:	47                   	inc    di
     19e:	50                   	push   ax
     19f:	46                   	inc    si
     1a0:	61                   	popa
     1a1:	75 6c                	jne    0x20f
     1a3:	74 00                	je     0x1a5
     1a5:	45                   	inc    bp
     1a6:	5f                   	pop    di
     1a7:	41                   	inc    cx
     1a8:	75 74                	jne    0x21e
     1aa:	72 65                	jb     0x211
     1ac:	20 2e 2e 2e          	and    BYTE PTR ds:0x2e2e,ch
     1b0:	00 49 6d             	add    BYTE PTR [bx+di+0x6d],cl
     1b3:	70 72                	jo     0x227
     1b5:	69 6d 65 72 20       	imul   bp,WORD PTR [di+0x65],0x2072
     1ba:	41                   	inc    cx
     1bb:	73 70                	jae    0x22d
     1bd:	65 63 74 20          	arpl   WORD PTR gs:[si+0x20],si
     1c1:	3f                   	aas
     1c2:	00 54 52             	add    BYTE PTR [si+0x52],dl
     1c5:	41                   	inc    cx
     1c6:	49                   	dec    cx
     1c7:	54                   	push   sp
     1c8:	45                   	inc    bp
     1c9:	4d                   	dec    bp
     1ca:	45                   	inc    bp
     1cb:	4e                   	dec    si
     1cc:	54                   	push   sp
     1cd:	20 44 45             	and    BYTE PTR [si+0x45],al
     1d0:	20 44 45             	and    BYTE PTR [si+0x45],al
     1d3:	56                   	push   si
     1d4:	45                   	inc    bp
     1d5:	4c                   	dec    sp
     1d6:	4f                   	dec    di
     1d7:	50                   	push   ax
     1d8:	50                   	push   ax
     1d9:	45                   	inc    bp
     1da:	4d                   	dec    bp
     1db:	45                   	inc    bp
     1dc:	4e                   	dec    si
     1dd:	54                   	push   sp
     1de:	09 00                	or     WORD PTR [bx+si],ax
     1e0:	01 00                	add    WORD PTR [bx+si],ax
     1e2:	00 03                	add    BYTE PTR [bp+di],al
     1e4:	00 0e 00 0c          	add    BYTE PTR ds:0xc00,cl
     1e8:	32 43 7a             	xor    al,BYTE PTR [bp+di+0x7a]
     1eb:	31 65 72             	xor    WORD PTR [di+0x72],sp
     1ee:	54                   	push   sp
     1ef:	26 56                	es push si
     1f1:	55                   	push   bp
     1f2:	73 34                	jae    0x228
     1f4:	00 01                	add    BYTE PTR [bx+di],al
     1f6:	00 3e 00 50          	add    BYTE PTR ds:0x5000,bh
     1fa:	72 6f                	jb     0x26b
     1fc:	62 6c e8             	bound  bp,DWORD PTR [si-0x18]
     1ff:	6d                   	ins    WORD PTR es:[di],dx
     200:	65 00 45 72          	add    BYTE PTR gs:[di+0x72],al
     204:	72 65                	jb     0x26b
     206:	75 72                	jne    0x27a
     208:	00 8e 00 00          	add    BYTE PTR [bp+0x0],cl
     20c:	00 e8                	add    al,ch
     20e:	2b 81 cd cc          	sub    ax,WORD PTR [bx+di-0x3333]
     212:	cc                   	int3
     213:	cc                   	int3
     214:	0c 9c                	or     al,0x9c
     216:	88 d6                	mov    dh,dl
     218:	fe                   	(bad)
     219:	f6 f4                	div    ah
     21b:	bd 74 19             	mov    bp,0x1974
     21e:	56                   	push   si
     21f:	45                   	inc    bp
     220:	52                   	push   dx
     221:	53                   	push   bx
     222:	49                   	dec    cx
     223:	4f                   	dec    di
     224:	4e                   	dec    si
     225:	20 44 45             	and    BYTE PTR [si+0x45],al
     228:	20 44 45             	and    BYTE PTR [si+0x45],al
     22b:	4d                   	dec    bp
     22c:	4f                   	dec    di
     22d:	4e                   	dec    si
     22e:	53                   	push   bx
     22f:	54                   	push   sp
     230:	52                   	push   dx
     231:	41                   	inc    cx
     232:	54                   	push   sp
     233:	49                   	dec    cx
     234:	4f                   	dec    di
     235:	4e                   	dec    si
     236:	2e e6 00             	cs out 0x0,al
     239:	01 00                	add    WORD PTR [bx+si],ax
     23b:	00 01                	add    BYTE PTR [bx+di],al
     23d:	00 38                	add    BYTE PTR [bx+si],bh
     23f:	00 37                	add    BYTE PTR [bx],dh
     241:	4e                   	dec    si
     242:	6f                   	outs   dx,WORD PTR ds:[si]
     243:	6e                   	outs   dx,BYTE PTR ds:[si]
     244:	20 75 74             	and    BYTE PTR [di+0x74],dh
     247:	69 6c 69 73 61       	imul   bp,WORD PTR [si+0x69],0x6173
     24c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     24f:	20 e0                	and    al,ah
     251:	20 64 65             	and    BYTE PTR [si+0x65],ah
     254:	73 20                	jae    0x276
     256:	66 69 6e 73 20 70 e9 	imul   ebp,DWORD PTR [bp+0x73],0x64e97020
     25d:	64 
     25e:	61                   	popa
     25f:	67 6f                	outs   dx,WORD PTR ds:[esi]
     261:	67 69 71 75 65 73    	imul   si,WORD PTR [ecx+0x75],0x7365
     267:	20 6f 75             	and    BYTE PTR [bx+0x75],ch
     26a:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
     26d:	6d                   	ins    WORD PTR es:[di],dx
     26e:	6d                   	ins    WORD PTR es:[di],dx
     26f:	65 72 63             	gs jb  0x2d5
     272:	69 61 6c 65 73       	imul   sp,WORD PTR [bx+di+0x6c],0x7365
     277:	2e c8 00 01 00       	cs enter 0x100,0x0
     27c:	00 01                	add    BYTE PTR [bx+di],al
     27e:	00 11                	add    BYTE PTR [bx+di],dl
     280:	00 10                	add    BYTE PTR [bx+si],dl
     282:	56                   	push   si
     283:	65 72 73             	gs jb  0x2f9
     286:	69 6f 6e 20 64       	imul   bp,WORD PTR [bx+0x6e],0x6420
     28b:	65 20 74 65          	and    BYTE PTR gs:[si+0x65],dh
     28f:	73 74                	jae    0x305
     291:	2e ef                	cs out dx,ax
     293:	00 01                	add    BYTE PTR [bx+di],al
     295:	00 00                	add    BYTE PTR [bx+si],al
     297:	01 00                	add    WORD PTR [bx+si],ax
     299:	16                   	push   ss
     29a:	00 15                	add    BYTE PTR [di],dl
     29c:	52                   	push   dx
     29d:	e9 73 65             	jmp    0x6813
     2a0:	72 76                	jb     0x318
     2a2:	e9 65 20             	jmp    0x230a
     2a5:	e0 20                	loopne 0x2c7
     2a7:	4c                   	dec    sp
     2a8:	41                   	inc    cx
     2a9:	42                   	inc    dx
     2aa:	4f                   	dec    di
     2ab:	44                   	inc    sp
     2ac:	49                   	dec    cx
     2ad:	44                   	inc    sp
     2ae:	41                   	inc    cx
     2af:	43                   	inc    bx
     2b0:	54                   	push   sp
     2b1:	ea 00 01 00 00       	jmp    0x0:0x100
     2b6:	01 00                	add    WORD PTR [bx+si],ax
     2b8:	01 00                	add    WORD PTR [bx+si],ax
     2ba:	01 0d                	add    WORD PTR [di],cx
     2bc:	00 01                	add    BYTE PTR [bx+di],al
     2be:	00 00                	add    BYTE PTR [bx+si],al
     2c0:	0c 00                	or     al,0x0
     2c2:	01 00                	add    WORD PTR [bx+si],ax
     2c4:	20 01                	and    BYTE PTR [bx+di],al
     2c6:	00 9c 00 44          	add    BYTE PTR [si+0x4400],bl
     2ca:	3a 00                	cmp    al,BYTE PTR [bx+si]
     2cc:	00 46 4c             	add    BYTE PTR [bp+0x4c],al
     2cf:	4f                   	dec    di
     2d0:	50                   	push   ax
     2d1:	50                   	push   ax
     2d2:	59                   	pop    cx
     2d3:	00 48 41             	add    BYTE PTR [bx+si+0x41],cl
     2d6:	52                   	push   dx
     2d7:	44                   	inc    sp
     2d8:	00 4e 45             	add    BYTE PTR [bp+0x45],cl
     2db:	54                   	push   sp
     2dc:	57                   	push   di
     2dd:	4f                   	dec    di
     2de:	52                   	push   dx
     2df:	4b                   	dec    bx
     2e0:	00 43 44             	add    BYTE PTR [bp+di+0x44],al
     2e3:	52                   	push   dx
     2e4:	4f                   	dec    di
     2e5:	4d                   	dec    bp
     2e6:	00 52 41             	add    BYTE PTR [bp+si+0x41],dl
     2e9:	4d                   	dec    bp
     2ea:	00 4f 50             	add    BYTE PTR [bx+0x50],cl
     2ed:	45                   	inc    bp
     2ee:	4e                   	dec    si
     2ef:	46                   	inc    si
     2f0:	4f                   	dec    di
     2f1:	4c                   	dec    sp
     2f2:	44                   	inc    sp
     2f3:	45                   	inc    bp
     2f4:	52                   	push   dx
     2f5:	00 43 4c             	add    BYTE PTR [bp+di+0x4c],al
     2f8:	4f                   	dec    di
     2f9:	53                   	push   bx
     2fa:	45                   	inc    bp
     2fb:	44                   	inc    sp
     2fc:	46                   	inc    si
     2fd:	4f                   	dec    di
     2fe:	4c                   	dec    sp
     2ff:	44                   	inc    sp
     300:	45                   	inc    bp
     301:	52                   	push   dx
     302:	00 43 55             	add    BYTE PTR [bp+di+0x55],al
     305:	52                   	push   dx
     306:	52                   	push   dx
     307:	45                   	inc    bp
     308:	4e                   	dec    si
     309:	54                   	push   sp
     30a:	46                   	inc    si
     30b:	4f                   	dec    di
     30c:	4c                   	dec    sp
     30d:	44                   	inc    sp
     30e:	45                   	inc    bp
     30f:	52                   	push   dx
     310:	00 2a                	add    BYTE PTR [bp+si],ch
     312:	2e 2a 00             	sub    al,BYTE PTR cs:[bx+si]
     315:	2a 2e 2a 00          	sub    ch,BYTE PTR ds:0x2a
     319:	45                   	inc    bp
     31a:	58                   	pop    ax
     31b:	45                   	inc    bp
     31c:	43                   	inc    bx
     31d:	55                   	push   bp
     31e:	54                   	push   sp
     31f:	41                   	inc    cx
     320:	42                   	inc    dx
     321:	4c                   	dec    sp
     322:	45                   	inc    bp
     323:	00 43 4c             	add    BYTE PTR [bp+di+0x4c],al
     326:	4f                   	dec    di
     327:	53                   	push   bx
     328:	45                   	inc    bp
     329:	44                   	inc    sp
     32a:	46                   	inc    si
     32b:	4f                   	dec    di
     32c:	4c                   	dec    sp
     32d:	44                   	inc    sp
     32e:	45                   	inc    bp
     32f:	52                   	push   dx
     330:	00 55 4e             	add    BYTE PTR [di+0x4e],dl
     333:	4b                   	dec    bx
     334:	4e                   	dec    si
     335:	4f                   	dec    di
     336:	57                   	push   di
     337:	4e                   	dec    si
     338:	46                   	inc    si
     339:	49                   	dec    cx
     33a:	4c                   	dec    sp
     33b:	45                   	inc    bp
     33c:	00 01                	add    BYTE PTR [bx+di],al
     33e:	00 02                	add    BYTE PTR [bp+si],al
     340:	00 04                	add    BYTE PTR [si],al
     342:	00 08                	add    BYTE PTR [bx+si],cl
     344:	00 10                	add    BYTE PTR [bx+si],dl
     346:	00 20                	add    BYTE PTR [bx+si],ah
     348:	00 00                	add    BYTE PTR [bx+si],al
     34a:	80 44 42 47          	add    BYTE PTR [si+0x42],0x47
     34e:	41                   	inc    cx
     34f:	52                   	push   dx
     350:	52                   	push   dx
     351:	4f                   	dec    di
     352:	57                   	push   di
     353:	00 44 42             	add    BYTE PTR [si+0x42],al
     356:	45                   	inc    bp
     357:	44                   	inc    sp
     358:	49                   	dec    cx
     359:	54                   	push   sp
     35a:	00 44 42             	add    BYTE PTR [si+0x42],al
     35d:	49                   	dec    cx
     35e:	4e                   	dec    si
     35f:	53                   	push   bx
     360:	45                   	inc    bp
     361:	52                   	push   dx
     362:	54                   	push   sp
     363:	00 00                	add    BYTE PTR [bx+si],al
     365:	02 00                	add    al,BYTE PTR [bx+si]
     367:	06                   	push   es
     368:	00 00                	add    BYTE PTR [bx+si],al
     36a:	00 02                	add    BYTE PTR [bp+si],al
     36c:	00 51 08             	add    BYTE PTR [bx+di+0x8],dl
     36f:	01 00                	add    WORD PTR [bx+si],ax
     371:	8e 00                	mov    es,WORD PTR [bx+si]
     373:	20 0a                	and    BYTE PTR [bp+si],cl
     375:	1e                   	push   ds
     376:	0a 23                	or     ah,BYTE PTR [bp+di]
     378:	0a 28                	or     ch,BYTE PTR [bx+si]
     37a:	0a 45 4e             	or     al,BYTE PTR [di+0x4e]
     37d:	00 44 49             	add    BYTE PTR [si+0x49],al
     380:	00 4e 0a             	add    BYTE PTR [bp+0xa],cl
     383:	2c 0a                	sub    al,0xa
     385:	54                   	push   sp
     386:	0a 30                	or     dh,BYTE PTR [bx+si]
     388:	0a 5a 0a             	or     bl,BYTE PTR [bp+si+0xa]
     38b:	34 0a                	xor    al,0xa
     38d:	5f                   	pop    di
     38e:	0a 38                	or     bh,BYTE PTR [bx+si]
     390:	0a 64 0a             	or     ah,BYTE PTR [si+0xa]
     393:	3c 0a                	cmp    al,0xa
     395:	6b 0a 40             	imul   cx,WORD PTR [bp+si],0x40
     398:	0a 72 0a             	or     dh,BYTE PTR [bp+si+0xa]
     39b:	44                   	inc    sp
     39c:	0a 77 0a             	or     dh,BYTE PTR [bx+0xa]
     39f:	48                   	dec    ax
     3a0:	0a 7c 0a             	or     bh,BYTE PTR [si+0xa]
     3a3:	4c                   	dec    sp
     3a4:	0a 83 0a 86          	or     al,BYTE PTR [bp+di-0x79f6]
     3a8:	0b 46 49             	or     ax,WORD PTR [bp+0x49]
     3ab:	52                   	push   dx
     3ac:	53                   	push   bx
     3ad:	54                   	push   sp
     3ae:	00 50 52             	add    BYTE PTR [bx+si+0x52],dl
     3b1:	49                   	dec    cx
     3b2:	4f                   	dec    di
     3b3:	52                   	push   dx
     3b4:	00 4e 45             	add    BYTE PTR [bp+0x45],cl
     3b7:	58                   	pop    ax
     3b8:	54                   	push   sp
     3b9:	00 4c 41             	add    BYTE PTR [si+0x41],cl
     3bc:	53                   	push   bx
     3bd:	54                   	push   sp
     3be:	00 49 4e             	add    BYTE PTR [bx+di+0x4e],cl
     3c1:	53                   	push   bx
     3c2:	45                   	inc    bp
     3c3:	52                   	push   dx
     3c4:	54                   	push   sp
     3c5:	00 44 45             	add    BYTE PTR [si+0x45],al
     3c8:	4c                   	dec    sp
     3c9:	45                   	inc    bp
     3ca:	54                   	push   sp
     3cb:	45                   	inc    bp
     3cc:	00 45 44             	add    BYTE PTR [di+0x44],al
     3cf:	49                   	dec    cx
     3d0:	54                   	push   sp
     3d1:	00 50 4f             	add    BYTE PTR [bx+si+0x4f],dl
     3d4:	53                   	push   bx
     3d5:	54                   	push   sp
     3d6:	00 43 41             	add    BYTE PTR [bp+di+0x41],al
     3d9:	4e                   	dec    si
     3da:	43                   	inc    bx
     3db:	45                   	inc    bp
     3dc:	4c                   	dec    sp
     3dd:	00 52 45             	add    BYTE PTR [bp+si+0x45],dl
     3e0:	46                   	inc    si
     3e1:	52                   	push   dx
     3e2:	45                   	inc    bp
     3e3:	53                   	push   bx
     3e4:	48                   	dec    ax
     3e5:	00 00                	add    BYTE PTR [bx+si],al
     3e7:	43                   	inc    bx
     3e8:	f2 44                	repnz inc sp
     3ea:	f2 45                	repnz inc bp
     3ec:	f2 46                	repnz inc si
     3ee:	f2 47                	repnz inc di
     3f0:	f2 48                	repnz dec ax
     3f2:	f2 49                	repnz dec cx
     3f4:	f2 4a                	repnz dec dx
     3f6:	f2 4b                	repnz dec bx
     3f8:	f2 4c                	repnz dec sp
     3fa:	f2 64 62 6e 5f       	repnz bound bp,DWORD PTR fs:[bp+0x5f]
     3ff:	25 73 08             	and    ax,0x873
     402:	00 01                	add    BYTE PTR [bx+di],al
     404:	00 00                	add    BYTE PTR [bx+si],al
     406:	01 00                	add    WORD PTR [bx+si],ax
     408:	33 00                	xor    ax,WORD PTR [bx+si]
     40a:	53                   	push   bx
     40b:	54                   	push   sp
     40c:	41                   	inc    cx
     40d:	4e                   	dec    si
     40e:	44                   	inc    sp
     40f:	41                   	inc    cx
     410:	52                   	push   dx
     411:	44                   	inc    sp
     412:	00 5c 44             	add    BYTE PTR [si+0x44],bl
     415:	41                   	inc    cx
     416:	54                   	push   sp
     417:	41                   	inc    cx
     418:	42                   	inc    dx
     419:	41                   	inc    cx
     41a:	53                   	push   bx
     41b:	45                   	inc    bp
     41c:	53                   	push   bx
     41d:	5c                   	pop    sp
     41e:	25 73 5c             	and    ax,0x5c73
     421:	44                   	inc    sp
     422:	42                   	inc    dx
     423:	20 4f 50             	and    BYTE PTR [bx+0x50],cl
     426:	45                   	inc    bp
     427:	4e                   	dec    si
     428:	00 00                	add    BYTE PTR [bx+si],al
     42a:	5c                   	pop    sp
     42b:	44                   	inc    sp
     42c:	52                   	push   dx
     42d:	49                   	dec    cx
     42e:	56                   	push   si
     42f:	45                   	inc    bp
     430:	52                   	push   dx
     431:	53                   	push   bx
     432:	5c                   	pop    sp
     433:	25 73 5c             	and    ax,0x5c73
     436:	44                   	inc    sp
     437:	42                   	inc    dx
     438:	20 4f 50             	and    BYTE PTR [bx+0x50],cl
     43b:	45                   	inc    bp
     43c:	4e                   	dec    si
     43d:	02 00                	add    al,BYTE PTR [bx+si]
     43f:	0a 00                	or     al,BYTE PTR [bx+si]
     441:	00 53 54             	add    BYTE PTR [bp+di+0x54],dl
     444:	41                   	inc    cx
     445:	4e                   	dec    si
     446:	44                   	inc    sp
     447:	41                   	inc    cx
     448:	52                   	push   dx
     449:	44                   	inc    sp
     44a:	00 01                	add    BYTE PTR [bx+di],al
     44c:	00 4b 01             	add    BYTE PTR [bp+di+0x1],cl
     44f:	00 00                	add    BYTE PTR [bx+si],al
     451:	00 00                	add    BYTE PTR [bx+si],al
     453:	00 6f 05             	add    BYTE PTR [bx+0x5],ch
     456:	00 0b                	add    BYTE PTR [bp+di],cl
     458:	d0 08                	ror    BYTE PTR [bx+si],1
     45a:	04 0b                	add    al,0xb
     45c:	c8 07 08 0b          	enter  0x807,0xb
     460:	98                   	cbw
     461:	09 0c                	or     WORD PTR [si],cx
     463:	0b 42 0d             	or     ax,WORD PTR [bp+si+0xd]
     466:	10 0b                	adc    BYTE PTR [bp+di],cl
     468:	58                   	pop    ax
     469:	0a 14                	or     dl,BYTE PTR [si]
     46b:	0b 9f 0b 18          	or     bx,WORD PTR [bx+0x180b]
     46f:	0b 67 0c             	or     sp,WORD PTR [bx+0xc]
     472:	1c 0b                	sbb    al,0xb
     474:	3d 0f 20             	cmp    ax,0x200f
     477:	0b fd                	or     di,bp
     479:	0f 24 0b             	mov    ebx,tr1
     47c:	2e 0e                	cs push cs
     47e:	28 0b                	sub    BYTE PTR [bp+di],cl
     480:	bd 10 2c             	mov    bp,0x2c10
     483:	0b 9c 11 30          	or     bx,WORD PTR [si+0x3011]
     487:	0b 81 12 34          	or     ax,WORD PTR [bx+di+0x3412]
     48b:	0b 5e 13             	or     bx,WORD PTR [bp+0x13]
     48e:	38 0b                	cmp    BYTE PTR [bp+di],cl
     490:	1e                   	push   ds
     491:	14 ff                	adc    al,0xff
     493:	ff 00                	inc    WORD PTR [bx+si]
     495:	01 09                	add    WORD PTR [bx+di],cx
     497:	0e                   	push   cs
     498:	05 02 03             	add    ax,0x302
     49b:	06                   	push   es
     49c:	08 0c                	or     BYTE PTR [si],cl
     49e:	0a 0b                	or     cl,BYTE PTR [bp+di]
     4a0:	04 00                	add    al,0x0
     4a2:	00 0d                	add    BYTE PTR [di],cl
     4a4:	00 00                	add    BYTE PTR [bx+si],al
     4a6:	00 01                	add    BYTE PTR [bx+di],al
     4a8:	02 03                	add    al,BYTE PTR [bp+di]
     4aa:	04 05                	add    al,0x5
     4ac:	06                   	push   es
     4ad:	06                   	push   es
     4ae:	08 09                	or     BYTE PTR [bx+di],cl
     4b0:	0a 0b                	or     cl,BYTE PTR [bp+di]
     4b2:	0c 0d                	or     al,0xd
     4b4:	0e                   	push   cs
     4b5:	0e                   	push   cs
     4b6:	0e                   	push   cs
     4b7:	00 02                	add    BYTE PTR [bp+si],al
     4b9:	04 00                	add    al,0x0
     4bb:	00 01                	add    BYTE PTR [bx+di],al
     4bd:	00 00                	add    BYTE PTR [bx+si],al
     4bf:	00 01                	add    BYTE PTR [bx+di],al
     4c1:	00 00                	add    BYTE PTR [bx+si],al
     4c3:	01 05                	add    WORD PTR [di],ax
     4c5:	06                   	push   es
     4c6:	0c 04                	or     al,0x4
     4c8:	07                   	pop    es
     4c9:	07                   	pop    es
     4ca:	08 02                	or     BYTE PTR [bp+si],al
     4cc:	0a 0b                	or     cl,BYTE PTR [bp+di]
     4ce:	09 0f                	or     WORD PTR [bx],cx
     4d0:	03 03                	add    ax,WORD PTR [bp+di]
     4d2:	03 00                	add    ax,WORD PTR [bx+si]
     4d4:	53                   	push   bx
     4d5:	54                   	push   sp
     4d6:	41                   	inc    cx
     4d7:	4e                   	dec    si
     4d8:	44                   	inc    sp
     4d9:	41                   	inc    cx
     4da:	52                   	push   dx
     4db:	44                   	inc    sp
     4dc:	00 00                	add    BYTE PTR [bx+si],al
     4de:	94                   	xchg   sp,ax
     4df:	0b 8a 0b 94          	or     cx,WORD PTR [bp+si-0x6bf5]
     4e3:	0b 8e 0b 9c          	or     cx,WORD PTR [bp-0x63f5]
     4e7:	0b 92 0b a2          	or     dx,WORD PTR [bp+si-0x5df5]
     4eb:	0b 64 0c             	or     sp,WORD PTR [si+0xc]
     4ee:	50                   	push   ax
     4ef:	41                   	inc    cx
     4f0:	52                   	push   dx
     4f1:	41                   	inc    cx
     4f2:	44                   	inc    sp
     4f3:	4f                   	dec    di
     4f4:	58                   	pop    ax
     4f5:	00 44 42             	add    BYTE PTR [si+0x42],al
     4f8:	41                   	inc    cx
     4f9:	53                   	push   bx
     4fa:	45                   	inc    bp
     4fb:	00 41 53             	add    BYTE PTR [bx+di+0x53],al
     4fe:	43                   	inc    bx
     4ff:	49                   	dec    cx
     500:	49                   	dec    cx
     501:	44                   	inc    sp
     502:	52                   	push   dx
     503:	56                   	push   si
     504:	00 00                	add    BYTE PTR [bx+si],al
     506:	00 01                	add    BYTE PTR [bx+di],al
     508:	05 06 0c             	add    ax,0xc06
     50b:	04 07                	add    al,0x7
     50d:	07                   	pop    es
     50e:	08 02                	or     BYTE PTR [bp+si],al
     510:	0a 0b                	or     cl,BYTE PTR [bp+di]
     512:	09 0f                	or     WORD PTR [bx],cx
     514:	03 03                	add    ax,WORD PTR [bp+di]
     516:	03 00                	add    ax,WORD PTR [bx+si]
     518:	02 00                	add    al,BYTE PTR [bx+si]
     51a:	00 00                	add    BYTE PTR [bx+si],al
     51c:	01 00                	add    WORD PTR [bx+si],ax
     51e:	00 00                	add    BYTE PTR [bx+si],al
     520:	01 46 01             	add    WORD PTR [bp+0x1],ax
     523:	54                   	push   sp
     524:	53                   	push   bx
     525:	70 69                	jo     0x590
     527:	6e                   	outs   dx,BYTE PTR ds:[si]
     528:	55                   	push   bp
     529:	70 00                	jo     0x52b
     52b:	00 53 70             	add    BYTE PTR [bp+di+0x70],dl
     52e:	69 6e 44 6f 77       	imul   bp,WORD PTR [bp+0x44],0x776f
     533:	6e                   	outs   dx,BYTE PTR ds:[si]
     534:	00 00                	add    BYTE PTR [bx+si],al
     536:	0f ff 04             	ud0    ax,WORD PTR [si]
     539:	08 57 69             	or     BYTE PTR [bx+0x69],dl
     53c:	6e                   	outs   dx,BYTE PTR ds:[si]
     53d:	64 6f                	outs   dx,WORD PTR fs:[si]
     53f:	77 73                	ja     0x5b4
     541:	00 44 6f             	add    BYTE PTR [si+0x6f],al
     544:	75 62                	jne    0x5a8
     546:	6c                   	ins    BYTE PTR es:[di],dx
     547:	65 43                	gs inc bx
     549:	6c                   	ins    BYTE PTR es:[di],dx
     54a:	69 63 6b 53 70       	imul   sp,WORD PTR [bp+di+0x6b],0x7053
     54f:	65 65 64 00 00       	gs gs add BYTE PTR fs:[bx+si],al
     554:	5f                   	pop    di
     555:	3b 30                	cmp    si,WORD PTR [bx+si]
     557:	00 44 65             	add    BYTE PTR [si+0x65],al
     55a:	6c                   	ins    BYTE PTR es:[di],dx
     55b:	70 68                	jo     0x5c5
     55d:	69 20 50 69          	imul   sp,WORD PTR [bx+si],0x6950
     561:	63 74 75             	arpl   WORD PTR [si+0x75],si
     564:	72 65                	jb     0x5cb
     566:	00 44 65             	add    BYTE PTR [si+0x65],al
     569:	6c                   	ins    BYTE PTR es:[di],dx
     56a:	70 68                	jo     0x5d4
     56c:	69 20 43 6f          	imul   sp,WORD PTR [bx+si],0x6f43
     570:	6d                   	ins    WORD PTR es:[di],dx
     571:	70 6f                	jo     0x5e2
     573:	6e                   	outs   dx,BYTE PTR ds:[si]
     574:	65 6e                	outs   dx,BYTE PTR gs:[si]
     576:	74 00                	je     0x578
     578:	00 01                	add    BYTE PTR [bx+di],al
     57a:	4d                   	dec    bp
     57b:	00 1b                	add    BYTE PTR [bp+di],bl
     57d:	00 00                	add    BYTE PTR [bx+si],al
     57f:	00 00                	add    BYTE PTR [bx+si],al
     581:	00 6f f0             	add    BYTE PTR [bx-0x10],ch
     584:	70 f0                	jo     0x576
     586:	71 f0                	jno    0x578
     588:	72 f0                	jb     0x57a
     58a:	00 00                	add    BYTE PTR [bx+si],al
     58c:	03 7f 00             	add    di,WORD PTR [bx+0x0]
     58f:	00 01                	add    BYTE PTR [bx+di],al
     591:	7f 00                	jg     0x593
     593:	00 04                	add    BYTE PTR [si],al
     595:	7f 00                	jg     0x597
     597:	00 02                	add    BYTE PTR [bp+si],al
     599:	7f 06                	jg     0x5a1
     59b:	00 01                	add    BYTE PTR [bx+di],al
     59d:	00 00                	add    BYTE PTR [bx+si],al
     59f:	01 00                	add    WORD PTR [bx+si],ax
     5a1:	6c                   	ins    BYTE PTR es:[di],dx
     5a2:	00 04                	add    BYTE PTR [si],al
     5a4:	05 01 02             	add    ax,0x201
     5a7:	07                   	pop    es
     5a8:	08 09                	or     BYTE PTR [bx+di],cl
     5aa:	0a 03                	or     al,BYTE PTR [bp+di]
     5ac:	00 73 f0             	add    BYTE PTR [bp+di-0x10],dh
     5af:	74 f0                	je     0x5a1
     5b1:	75 f0                	jne    0x5a3
     5b3:	76 f0                	jbe    0x5a5
     5b5:	7a f0                	jp     0x5a7
     5b7:	7b f0                	jnp    0x5a9
     5b9:	7c f0                	jl     0x5ab
     5bb:	7d f0                	jge    0x5ad
     5bd:	77 f0                	ja     0x5af
     5bf:	86 0c                	xchg   BYTE PTR [si],cl
     5c1:	68 0c 8a             	push   0x8a0c
     5c4:	0c 6c                	or     al,0x6c
     5c6:	0c 8d                	or     al,0x8d
     5c8:	0c 70                	or     al,0x70
     5ca:	0c 90                	or     al,0x90
     5cc:	0c 74                	or     al,0x74
     5ce:	0c 97                	or     al,0x97
     5d0:	0c 78                	or     al,0x78
     5d2:	0c 9d                	or     al,0x9d
     5d4:	0c 7c                	or     al,0x7c
     5d6:	0c a3                	or     al,0xa3
     5d8:	0c 80                	or     al,0x80
     5da:	0c aa                	or     al,0xaa
     5dc:	0c 84                	or     al,0x84
     5de:	0c ae                	or     al,0xae
     5e0:	0c b6                	or     al,0xb6
     5e2:	0d 59 45             	or     ax,0x4559
     5e5:	53                   	push   bx
     5e6:	00 4e 4f             	add    BYTE PTR [bp+0x4f],cl
     5e9:	00 4f 4b             	add    BYTE PTR [bx+0x4b],cl
     5ec:	00 43 41             	add    BYTE PTR [bp+di+0x41],al
     5ef:	4e                   	dec    si
     5f0:	43                   	inc    bx
     5f1:	45                   	inc    bp
     5f2:	4c                   	dec    sp
     5f3:	00 41 42             	add    BYTE PTR [bx+di+0x42],al
     5f6:	4f                   	dec    di
     5f7:	52                   	push   dx
     5f8:	54                   	push   sp
     5f9:	00 52 45             	add    BYTE PTR [bp+si+0x45],dl
     5fc:	54                   	push   sp
     5fd:	52                   	push   dx
     5fe:	59                   	pop    cx
     5ff:	00 49 47             	add    BYTE PTR [bx+di+0x47],cl
     602:	4e                   	dec    si
     603:	4f                   	dec    di
     604:	52                   	push   dx
     605:	45                   	inc    bp
     606:	00 41 4c             	add    BYTE PTR [bx+di+0x4c],al
     609:	4c                   	dec    sp
     60a:	00 48 45             	add    BYTE PTR [bx+si+0x45],cl
     60d:	4c                   	dec    sp
     60e:	50                   	push   ax
     60f:	0c 00                	or     al,0x0
     611:	01 00                	add    WORD PTR [bx+si],ax
     613:	00 01                	add    BYTE PTR [bx+di],al
     615:	00 0b                	add    BYTE PTR [bp+di],cl
     617:	00 83 00 43          	add    BYTE PTR [bp+di+0x4300],al
     61b:	00 4c 49             	add    BYTE PTR [si+0x49],cl
     61e:	53                   	push   bx
     61f:	54                   	push   sp
     620:	42                   	inc    dx
     621:	4f                   	dec    di
     622:	58                   	pop    ax
     623:	02 00                	add    al,BYTE PTR [bx+si]
     625:	10 00                	adc    BYTE PTR [bx+si],al
     627:	00 44 72             	add    BYTE PTR [si+0x72],al
     62a:	6f                   	outs   dx,WORD PTR ds:[si]
     62b:	70 4c                	jo     0x679
     62d:	69 73 74 42 75       	imul   si,WORD PTR [bp+di+0x74],0x7542
     632:	74 74                	je     0x6a8
     634:	6f                   	outs   dx,WORD PTR ds:[si]
     635:	6e                   	outs   dx,BYTE PTR ds:[si]
     636:	00 02                	add    BYTE PTR [bp+si],al
     638:	00 15                	add    BYTE PTR [di],dl
     63a:	00 00                	add    BYTE PTR [bx+si],al
     63c:	01 00                	add    WORD PTR [bx+si],ax
     63e:	00 00                	add    BYTE PTR [bx+si],al
     640:	02 00                	add    al,BYTE PTR [bx+si]
     642:	00 00                	add    BYTE PTR [bx+si],al
     644:	04 00                	add    al,0x0
     646:	00 00                	add    BYTE PTR [bx+si],al
     648:	08 00                	or     BYTE PTR [bx+si],al
     64a:	00 00                	add    BYTE PTR [bx+si],al
     64c:	10 00                	adc    BYTE PTR [bx+si],al
     64e:	00 00                	add    BYTE PTR [bx+si],al
     650:	01 00                	add    WORD PTR [bx+si],ax
     652:	0e                   	push   cs
     653:	00 20                	add    BYTE PTR [bx+si],ah
     655:	00 00                	add    BYTE PTR [bx+si],al
     657:	00 40 00             	add    BYTE PTR [bx+si+0x0],al
     65a:	00 00                	add    BYTE PTR [bx+si],al
     65c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     65f:	00 00                	add    BYTE PTR [bx+si],al
     661:	01 02                	add    WORD PTR [bp+si],ax
     663:	00 05                	add    BYTE PTR [di],al
     665:	00 00                	add    BYTE PTR [bx+si],al
     667:	00 04                	add    BYTE PTR [si],al
     669:	00 00                	add    BYTE PTR [bx+si],al
     66b:	01 00                	add    WORD PTR [bx+si],ax
     66d:	83 00 01             	add    WORD PTR [bx+si],0x1
     670:	00 00                	add    BYTE PTR [bx+si],al
     672:	00 40 00             	add    BYTE PTR [bx+si+0x0],al
     675:	00 00                	add    BYTE PTR [bx+si],al
     677:	00 01                	add    BYTE PTR [bx+di],al
     679:	00 00                	add    BYTE PTR [bx+si],al
     67b:	00 08                	add    BYTE PTR [bx+si],cl
     67d:	00 00                	add    BYTE PTR [bx+si],al
     67f:	08 00                	or     BYTE PTR [bx+si],al
     681:	00 00                	add    BYTE PTR [bx+si],al
     683:	10 00                	adc    BYTE PTR [bx+si],al
     685:	00 00                	add    BYTE PTR [bx+si],al
     687:	00 20                	add    BYTE PTR [bx+si],ah
     689:	00 00                	add    BYTE PTR [bx+si],al
     68b:	00 10                	add    BYTE PTR [bx+si],dl
     68d:	00 00                	add    BYTE PTR [bx+si],al
     68f:	08 00                	or     BYTE PTR [bx+si],al
     691:	00 04                	add    BYTE PTR [si],al
     693:	00 00                	add    BYTE PTR [bx+si],al
     695:	00 00                	add    BYTE PTR [bx+si],al
     697:	80 00 00             	add    BYTE PTR [bx+si],0x0
     69a:	00 20                	add    BYTE PTR [bx+si],ah
     69c:	00 00                	add    BYTE PTR [bx+si],al
     69e:	00 00                	add    BYTE PTR [bx+si],al
     6a0:	02 00                	add    al,BYTE PTR [bx+si]
     6a2:	01 00                	add    WORD PTR [bx+si],ax
     6a4:	00 00                	add    BYTE PTR [bx+si],al
     6a6:	02 00                	add    al,BYTE PTR [bx+si]
     6a8:	00 00                	add    BYTE PTR [bx+si],al
     6aa:	03 00                	add    ax,WORD PTR [bx+si]
     6ac:	00 00                	add    BYTE PTR [bx+si],al
     6ae:	00 00                	add    BYTE PTR [bx+si],al
     6b0:	01 00                	add    WORD PTR [bx+si],ax
     6b2:	02 00                	add    al,BYTE PTR [bx+si]
     6b4:	63 6f 6d             	arpl   WORD PTR [bx+0x6d],bp
     6b7:	6d                   	ins    WORD PTR es:[di],dx
     6b8:	64 6c                	fs ins BYTE PTR es:[di],dx
     6ba:	67 5f                	addr32 pop di
     6bc:	68 65 6c             	push   0x6c65
     6bf:	70 00                	jo     0x6c1
     6c1:	63 6f 6d             	arpl   WORD PTR [bx+0x6d],bp
     6c4:	6d                   	ins    WORD PTR es:[di],dx
     6c5:	64 6c                	fs ins BYTE PTR es:[di],dx
     6c7:	67 5f                	addr32 pop di
     6c9:	46                   	inc    si
     6ca:	69 6e 64 52 65       	imul   bp,WORD PTR [bp+0x64],0x6552
     6cf:	70 6c                	jo     0x73d
     6d1:	61                   	popa
     6d2:	63 65 00             	arpl   WORD PTR [di+0x0],sp
     6d5:	57                   	push   di
     6d6:	6e                   	outs   dx,BYTE PTR ds:[si]
     6d7:	64 50                	fs push ax
     6d9:	72 6f                	jb     0x74a
     6db:	63 4f 66             	arpl   WORD PTR [bx+0x66],cx
     6de:	73 25                	jae    0x705
     6e0:	2e 34 58             	cs xor al,0x58
     6e3:	00 57 6e             	add    BYTE PTR [bx+0x6e],dl
     6e6:	64 50                	fs push ax
     6e8:	72 6f                	jb     0x759
     6ea:	63 53 65             	arpl   WORD PTR [bp+di+0x65],dx
     6ed:	67 25 2e 34          	addr32 and ax,0x342e
     6f1:	58                   	pop    ax
     6f2:	06                   	push   es
     6f3:	00 01                	add    BYTE PTR [bx+di],al
     6f5:	00 00                	add    BYTE PTR [bx+si],al
     6f7:	01 00                	add    WORD PTR [bx+si],ax
     6f9:	9b                   	fwait
     6fa:	00 dc                	add    ah,bl
     6fc:	0d ba 0d             	or     ax,0xdba
     6ff:	e1 0d                	loope  0x70e
     701:	be 0d ea             	mov    si,0xea0d
     704:	0d c2 0d             	or     ax,0xdc2
     707:	f1                   	int1
     708:	0d c6 0d             	or     ax,0xdc6
     70b:	f7 0d ca 0d          	test   WORD PTR [di],0xdca
     70f:	fc                   	cld
     710:	0d ce 0d             	or     ax,0xdce
     713:	04 0e                	add    al,0xe
     715:	d2 0d                	ror    BYTE PTR [di],cl
     717:	0c 0e                	or     al,0xe
     719:	d6                   	(bad)
     71a:	0d 14 0e             	or     ax,0xe14
     71d:	da 0d                	fimul  DWORD PTR [di]
     71f:	1d 0e b2             	sbb    ax,0xb20e
     722:	0e                   	push   cs
     723:	42                   	inc    dx
     724:	42                   	inc    dx
     725:	4f                   	dec    di
     726:	4b                   	dec    bx
     727:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     72a:	43                   	inc    bx
     72b:	41                   	inc    cx
     72c:	4e                   	dec    si
     72d:	43                   	inc    bx
     72e:	45                   	inc    bp
     72f:	4c                   	dec    sp
     730:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     733:	48                   	dec    ax
     734:	45                   	inc    bp
     735:	4c                   	dec    sp
     736:	50                   	push   ax
     737:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     73a:	59                   	pop    cx
     73b:	45                   	inc    bp
     73c:	53                   	push   bx
     73d:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     740:	4e                   	dec    si
     741:	4f                   	dec    di
     742:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     745:	43                   	inc    bx
     746:	4c                   	dec    sp
     747:	4f                   	dec    di
     748:	53                   	push   bx
     749:	45                   	inc    bp
     74a:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     74d:	41                   	inc    cx
     74e:	42                   	inc    dx
     74f:	4f                   	dec    di
     750:	52                   	push   dx
     751:	54                   	push   sp
     752:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     755:	52                   	push   dx
     756:	45                   	inc    bp
     757:	54                   	push   sp
     758:	52                   	push   dx
     759:	59                   	pop    cx
     75a:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     75d:	49                   	dec    cx
     75e:	47                   	inc    di
     75f:	4e                   	dec    si
     760:	4f                   	dec    di
     761:	52                   	push   dx
     762:	45                   	inc    bp
     763:	00 42 42             	add    BYTE PTR [bp+si+0x42],al
     766:	41                   	inc    cx
     767:	4c                   	dec    sp
     768:	4c                   	dec    sp
     769:	00 00                	add    BYTE PTR [bx+si],al
     76b:	00 00                	add    BYTE PTR [bx+si],al
     76d:	3c f0                	cmp    al,0xf0
     76f:	3d f0 40             	cmp    ax,0x40f0
     772:	f0 3e f0 3f          	lock ds lock aas
     776:	f0 41                	lock inc cx
     778:	f0 44                	lock inc sp
     77a:	f0 43                	lock inc bx
     77c:	f0 42                	lock inc dx
     77e:	f0 45                	lock inc bp
     780:	f0 00 00             	lock add BYTE PTR [bx+si],al
     783:	01 00                	add    WORD PTR [bx+si],ax
     785:	02 00                	add    al,BYTE PTR [bx+si]
     787:	00 00                	add    BYTE PTR [bx+si],al
     789:	06                   	push   es
     78a:	00 07                	add    BYTE PTR [bx],al
     78c:	00 00                	add    BYTE PTR [bx+si],al
     78e:	00 03                	add    BYTE PTR [bp+di],al
     790:	00 04                	add    BYTE PTR [si],al
     792:	00 05                	add    BYTE PTR [di],al
     794:	00 08                	add    BYTE PTR [bx+si],cl
     796:	07                   	pop    es
     797:	00 01                	add    BYTE PTR [bx+di],al
     799:	00 00                	add    BYTE PTR [bx+si],al
     79b:	01 00                	add    WORD PTR [bx+si],ax
     79d:	07                   	pop    es
     79e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     7a2:	00 02                	add    BYTE PTR [bp+si],al
     7a4:	00 01                	add    BYTE PTR [bx+di],al
     7a6:	07                   	pop    es
     7a7:	00 01                	add    BYTE PTR [bx+di],al
     7a9:	00 00                	add    BYTE PTR [bx+si],al
     7ab:	01 00                	add    WORD PTR [bx+si],ax
     7ad:	0d 00 80             	or     ax,0x8000
     7b0:	00 20                	add    BYTE PTR [bx+si],ah
     7b2:	00 00                	add    BYTE PTR [bx+si],al
     7b4:	00 02                	add    BYTE PTR [bp+si],al
     7b6:	00 01                	add    BYTE PTR [bx+di],al
     7b8:	00 00                	add    BYTE PTR [bx+si],al
     7ba:	00 10                	add    BYTE PTR [bx+si],dl
     7bc:	07                   	pop    es
     7bd:	00 01                	add    BYTE PTR [bx+di],al
     7bf:	00 00                	add    BYTE PTR [bx+si],al
     7c1:	01 00                	add    WORD PTR [bx+si],ax
     7c3:	01 00                	add    WORD PTR [bx+si],ax
     7c5:	20 08                	and    BYTE PTR [bx+si],cl
     7c7:	00 01                	add    BYTE PTR [bx+di],al
     7c9:	00 00                	add    BYTE PTR [bx+si],al
     7cb:	01 00                	add    WORD PTR [bx+si],ax
     7cd:	01 00                	add    WORD PTR [bx+si],ax
     7cf:	08 06 00 01          	or     BYTE PTR ds:0x100,al
     7d3:	00 00                	add    BYTE PTR [bx+si],al
     7d5:	01 00                	add    WORD PTR [bx+si],ax
     7d7:	0a 00                	or     al,BYTE PTR [bx+si]
     7d9:	08 00                	or     BYTE PTR [bx+si],al
     7db:	00 00                	add    BYTE PTR [bx+si],al
     7dd:	10 00                	adc    BYTE PTR [bx+si],al
     7df:	00 00                	add    BYTE PTR [bx+si],al
     7e1:	00 01                	add    BYTE PTR [bx+di],al
     7e3:	0b 00                	or     ax,WORD PTR [bx+si]
     7e5:	01 00                	add    WORD PTR [bx+si],ax
     7e7:	00 01                	add    BYTE PTR [bx+di],al
     7e9:	00 17                	add    BYTE PTR [bx],dl
     7eb:	00 04                	add    BYTE PTR [si],al
     7ed:	00 00                	add    BYTE PTR [bx+si],al
     7ef:	45                   	inc    bp
     7f0:	44                   	inc    sp
     7f1:	49                   	dec    cx
     7f2:	54                   	push   sp
     7f3:	00 00                	add    BYTE PTR [bx+si],al
     7f5:	25 73 0d             	and    ax,0xd73
     7f8:	0a 00                	or     al,BYTE PTR [bx+si]
     7fa:	0d 0a 25             	or     ax,0x250a
     7fd:	73 00                	jae    0x7ff
     7ff:	b4 0e                	mov    ah,0xe
     801:	88 0f                	mov    BYTE PTR [bx],cl
     803:	06                   	push   es
     804:	00 01                	add    BYTE PTR [bx+di],al
     806:	00 00                	add    BYTE PTR [bx+si],al
     808:	01 00                	add    WORD PTR [bx+si],ax
     80a:	05 00 02             	add    ax,0x200
     80d:	00 00                	add    BYTE PTR [bx+si],al
     80f:	00 01                	add    BYTE PTR [bx+di],al
     811:	09 00                	or     WORD PTR [bx+si],ax
     813:	01 00                	add    WORD PTR [bx+si],ax
     815:	00 01                	add    BYTE PTR [bx+di],al
     817:	00 0f                	add    BYTE PTR [bx],cl
     819:	00 10                	add    BYTE PTR [bx+si],dl
     81b:	00 00                	add    BYTE PTR [bx+si],al
     81d:	00 20                	add    BYTE PTR [bx+si],ah
     81f:	00 00                	add    BYTE PTR [bx+si],al
     821:	00 30                	add    BYTE PTR [bx+si],dh
     823:	00 00                	add    BYTE PTR [bx+si],al
     825:	00 00                	add    BYTE PTR [bx+si],al
     827:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     82b:	01 00                	add    WORD PTR [bx+si],ax
     82d:	00 01                	add    BYTE PTR [bx+di],al
     82f:	00 11                	add    BYTE PTR [bx+di],dl
     831:	00 02                	add    BYTE PTR [bp+si],al
     833:	00 00                	add    BYTE PTR [bx+si],al
     835:	00 01                	add    BYTE PTR [bx+di],al
     837:	00 00                	add    BYTE PTR [bx+si],al
     839:	00 03                	add    BYTE PTR [bp+di],al
     83b:	00 00                	add    BYTE PTR [bx+si],al
     83d:	00 13                	add    BYTE PTR [bp+di],dl
     83f:	00 00                	add    BYTE PTR [bx+si],al
     841:	00 23                	add    BYTE PTR [bp+di],ah
     843:	08 00                	or     BYTE PTR [bx+si],al
     845:	01 00                	add    WORD PTR [bx+si],ax
     847:	00 01                	add    BYTE PTR [bx+di],al
     849:	00 0b                	add    BYTE PTR [bp+di],cl
     84b:	00 01                	add    BYTE PTR [bx+di],al
     84d:	00 00                	add    BYTE PTR [bx+si],al
     84f:	43                   	inc    bx
     850:	4f                   	dec    di
     851:	4d                   	dec    bp
     852:	42                   	inc    dx
     853:	4f                   	dec    di
     854:	42                   	inc    dx
     855:	4f                   	dec    di
     856:	58                   	pop    ax
     857:	06                   	push   es
     858:	00 01                	add    BYTE PTR [bx+di],al
     85a:	00 00                	add    BYTE PTR [bx+si],al
     85c:	01 00                	add    WORD PTR [bx+si],ax
     85e:	01 00                	add    WORD PTR [bx+si],ax
     860:	01 02                	add    WORD PTR [bp+si],ax
     862:	00 10                	add    BYTE PTR [bx+si],dl
     864:	00 00                	add    BYTE PTR [bx+si],al
     866:	00 00                	add    BYTE PTR [bx+si],al
     868:	42                   	inc    dx
     869:	55                   	push   bp
     86a:	54                   	push   sp
     86b:	54                   	push   sp
     86c:	4f                   	dec    di
     86d:	4e                   	dec    si
     86e:	00 00                	add    BYTE PTR [bx+si],al
     870:	20 00                	and    BYTE PTR [bx+si],al
     872:	00 00                	add    BYTE PTR [bx+si],al
     874:	00 01                	add    BYTE PTR [bx+di],al
     876:	00 09                	add    BYTE PTR [bx+di],cl
     878:	00 00                	add    BYTE PTR [bx+si],al
     87a:	00 00                	add    BYTE PTR [bx+si],al
     87c:	42                   	inc    dx
     87d:	55                   	push   bp
     87e:	54                   	push   sp
     87f:	54                   	push   sp
     880:	4f                   	dec    di
     881:	4e                   	dec    si
     882:	06                   	push   es
     883:	00 01                	add    BYTE PTR [bx+di],al
     885:	00 00                	add    BYTE PTR [bx+si],al
     887:	01 00                	add    WORD PTR [bx+si],ax
     889:	05 00 10             	add    ax,0x1000
     88c:	00 00                	add    BYTE PTR [bx+si],al
     88e:	00 20                	add    BYTE PTR [bx+si],ah
     890:	07                   	pop    es
     891:	00 01                	add    BYTE PTR [bx+di],al
     893:	00 00                	add    BYTE PTR [bx+si],al
     895:	01 00                	add    WORD PTR [bx+si],ax
     897:	01 00                	add    WORD PTR [bx+si],ax
     899:	02 02                	add    al,BYTE PTR [bp+si]
     89b:	00 09                	add    BYTE PTR [bx+di],cl
	...
     8a5:	08 00                	or     BYTE PTR [bx+si],al
     8a7:	01 00                	add    WORD PTR [bx+si],ax
     8a9:	03 00                	add    ax,WORD PTR [bx+si]
     8ab:	00 00                	add    BYTE PTR [bx+si],al
     8ad:	01 0b                	add    WORD PTR [bp+di],cx
     8af:	00 01                	add    BYTE PTR [bx+di],al
     8b1:	00 00                	add    BYTE PTR [bx+si],al
     8b3:	01 00                	add    WORD PTR [bx+si],ax
     8b5:	04 02                	add    al,0x2
     8b7:	02 00                	add    al,BYTE PTR [bx+si]
     8b9:	00 4c 49             	add    BYTE PTR [si+0x49],cl
     8bc:	53                   	push   bx
     8bd:	54                   	push   sp
     8be:	42                   	inc    dx
     8bf:	4f                   	dec    di
     8c0:	58                   	pop    ax
     8c1:	00 00                	add    BYTE PTR [bx+si],al
     8c3:	00 00                	add    BYTE PTR [bx+si],al
     8c5:	00 01                	add    BYTE PTR [bx+di],al
     8c7:	00 00                	add    BYTE PTR [bx+si],al
     8c9:	00 53 43             	add    BYTE PTR [bp+di+0x43],dl
     8cc:	52                   	push   dx
     8cd:	4f                   	dec    di
     8ce:	4c                   	dec    sp
     8cf:	4c                   	dec    sp
     8d0:	42                   	inc    dx
     8d1:	41                   	inc    cx
     8d2:	52                   	push   dx
     8d3:	00 00                	add    BYTE PTR [bx+si],al
     8d5:	00 00                	add    BYTE PTR [bx+si],al
     8d7:	00 aa 10 90          	add    BYTE PTR [bp+si-0x6ff0],ch
     8db:	0f 80 00 00          	jo     0x8df
     8df:	00 b2 10 98          	add    BYTE PTR [bp+si-0x67f0],dh
     8e3:	0f 00 80 00 00       	sldt   WORD PTR [bx+si+0x0]
     8e8:	bb 10 a0             	mov    bx,0xa010
     8eb:	0f 80 80 00          	jo     0x96f
     8ef:	00 c3                	add    bl,al
     8f1:	10 a8 0f 00          	adc    BYTE PTR [bx+si+0xf],ch
     8f5:	00 80 00 cb          	add    BYTE PTR [bx+si-0x3500],al
     8f9:	10 b0 0f 80          	adc    BYTE PTR [bx+si-0x7ff1],dh
     8fd:	00 80 00 d2          	add    BYTE PTR [bx+si-0x2e00],al
     901:	10 b8 0f 00          	adc    BYTE PTR [bx+si+0xf],bh
     905:	80 80 00 db 10       	add    BYTE PTR [bx+si-0x2500],0x10
     90a:	c0 0f 80             	ror    BYTE PTR [bx],0x80
     90d:	80 80 00 e2 10       	add    BYTE PTR [bx+si-0x1e00],0x10
     912:	c8 0f c0 c0          	enter  0xc00f,0xc0
     916:	c0 00 e9             	rol    BYTE PTR [bx+si],0xe9
     919:	10 d0                	adc    al,dl
     91b:	0f ff 00             	ud0    ax,WORD PTR [bx+si]
     91e:	00 00                	add    BYTE PTR [bx+si],al
     920:	f2 10 d8             	repnz adc al,bl
     923:	0f 00                	(bad)
     925:	ff 00                	inc    WORD PTR [bx+si]
     927:	00 f8                	add    al,bh
     929:	10 e0                	adc    al,ah
     92b:	0f ff ff             	ud0    di,di
     92e:	00 00                	add    BYTE PTR [bx+si],al
     930:	ff 10                	call   WORD PTR [bx+si]
     932:	e8 0f 00             	call   0x944
     935:	00 ff                	add    bh,bh
     937:	00 08                	add    BYTE PTR [bx+si],cl
     939:	11 f0                	adc    ax,si
     93b:	0f ff 00             	ud0    ax,WORD PTR [bx+si]
     93e:	ff 00                	inc    WORD PTR [bx+si]
     940:	0f 11 f8             	movups xmm0,xmm7
     943:	0f 00                	(bad)
     945:	ff                   	(bad)
     946:	ff 00                	inc    WORD PTR [bx+si]
     948:	19 11                	sbb    WORD PTR [bx+di],dx
     94a:	00 10                	add    BYTE PTR [bx+si],dl
     94c:	ff                   	(bad)
     94d:	ff                   	(bad)
     94e:	ff 00                	inc    WORD PTR [bx+si]
     950:	20 11                	and    BYTE PTR [bx+di],dl
     952:	08 10                	or     BYTE PTR [bx+si],dl
     954:	ff                   	(bad)
     955:	ff                   	(bad)
     956:	ff                   	(bad)
     957:	ff 28                	jmp    DWORD PTR [bx+si]
     959:	11 10                	adc    WORD PTR [bx+si],dx
     95b:	10 fe                	adc    dh,bh
     95d:	ff                   	(bad)
     95e:	ff                   	(bad)
     95f:	ff 34                	push   WORD PTR [si]
     961:	11 18                	adc    WORD PTR [bx+si],bx
     963:	10 fd                	adc    ch,bh
     965:	ff                   	(bad)
     966:	ff                   	(bad)
     967:	ff 41 11             	inc    WORD PTR [bx+di+0x11]
     96a:	20 10                	and    BYTE PTR [bx+si],dl
     96c:	fc                   	cld
     96d:	ff                   	(bad)
     96e:	ff                   	(bad)
     96f:	ff 51 11             	call   WORD PTR [bx+di+0x11]
     972:	28 10                	sub    BYTE PTR [bx+si],dl
     974:	fb                   	sti
     975:	ff                   	(bad)
     976:	ff                   	(bad)
     977:	ff 63 11             	jmp    WORD PTR [bp+di+0x11]
     97a:	30 10                	xor    BYTE PTR [bx+si],dl
     97c:	fa                   	cli
     97d:	ff                   	(bad)
     97e:	ff                   	(bad)
     97f:	ff 6a 11             	jmp    DWORD PTR [bp+si+0x11]
     982:	38 10                	cmp    BYTE PTR [bx+si],dl
     984:	f9                   	stc
     985:	ff                   	(bad)
     986:	ff                   	(bad)
     987:	ff 73 11             	push   WORD PTR [bp+di+0x11]
     98a:	40                   	inc    ax
     98b:	10 f8                	adc    al,bh
     98d:	ff                   	(bad)
     98e:	ff                   	(bad)
     98f:	ff 81 11 48          	inc    WORD PTR [bx+di+0x4811]
     993:	10 f7                	adc    bh,dh
     995:	ff                   	(bad)
     996:	ff                   	(bad)
     997:	ff 8c 11 50          	dec    WORD PTR [si+0x5011]
     99b:	10 f6                	adc    dh,dh
     99d:	ff                   	(bad)
     99e:	ff                   	(bad)
     99f:	ff 99 11 58          	call   DWORD PTR [bx+di+0x5811]
     9a3:	10 f5                	adc    ch,dh
     9a5:	ff                   	(bad)
     9a6:	ff                   	(bad)
     9a7:	ff a7 11 60          	jmp    WORD PTR [bx+0x6011]
     9ab:	10 f4                	adc    ah,dh
     9ad:	ff                   	(bad)
     9ae:	ff                   	(bad)
     9af:	ff b6 11 68          	push   WORD PTR [bp+0x6811]
     9b3:	10 f3                	adc    bl,dh
     9b5:	ff                   	(bad)
     9b6:	ff                   	(bad)
     9b7:	ff c7                	inc    di
     9b9:	11 70 10             	adc    WORD PTR [bx+si+0x10],si
     9bc:	f2 ff                	repnz (bad)
     9be:	ff                   	(bad)
     9bf:	ff d6                	call   si
     9c1:	11 78 10             	adc    WORD PTR [bx+si+0x10],di
     9c4:	f1                   	int1
     9c5:	ff                   	(bad)
     9c6:	ff                   	(bad)
     9c7:	ff e2                	jmp    dx
     9c9:	11 80 10 f0          	adc    WORD PTR [bx+si-0xff0],ax
     9cd:	ff                   	(bad)
     9ce:	ff                   	(bad)
     9cf:	ff f2                	push   dx
     9d1:	11 88 10 ef          	adc    WORD PTR [bx+si-0x10f0],cx
     9d5:	ff                   	(bad)
     9d6:	ff                   	(bad)
     9d7:	ff                   	(bad)
     9d8:	fc                   	cld
     9d9:	11 90 10 ee          	adc    WORD PTR [bx+si-0x11f0],dx
     9dd:	ff                   	(bad)
     9de:	ff                   	(bad)
     9df:	ff 08                	dec    WORD PTR [bx+si]
     9e1:	12 98 10 ed          	adc    bl,BYTE PTR [bx+si-0x12f0]
     9e5:	ff                   	(bad)
     9e6:	ff                   	(bad)
     9e7:	ff 13                	call   WORD PTR [bp+di]
     9e9:	12 a0 10 ec          	adc    ah,BYTE PTR [bx+si-0x13f0]
     9ed:	ff                   	(bad)
     9ee:	ff                   	(bad)
     9ef:	ff 1d                	call   DWORD PTR [di]
     9f1:	12 a8 10 eb          	adc    ch,BYTE PTR [bx+si-0x14f0]
     9f5:	ff                   	(bad)
     9f6:	ff                   	(bad)
     9f7:	ff 33                	push   WORD PTR [bp+di]
     9f9:	12 b6 12 63          	adc    dh,BYTE PTR [bp+0x6312]
     9fd:	6c                   	ins    BYTE PTR es:[di],dx
     9fe:	42                   	inc    dx
     9ff:	6c                   	ins    BYTE PTR es:[di],dx
     a00:	61                   	popa
     a01:	63 6b 00             	arpl   WORD PTR [bp+di+0x0],bp
     a04:	63 6c 4d             	arpl   WORD PTR [si+0x4d],bp
     a07:	61                   	popa
     a08:	72 6f                	jb     0xa79
     a0a:	6f                   	outs   dx,WORD PTR ds:[si]
     a0b:	6e                   	outs   dx,BYTE PTR ds:[si]
     a0c:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a0f:	47                   	inc    di
     a10:	72 65                	jb     0xa77
     a12:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a14:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a17:	4f                   	dec    di
     a18:	6c                   	ins    BYTE PTR es:[di],dx
     a19:	69 76 65 00 63       	imul   si,WORD PTR [bp+0x65],0x6300
     a1e:	6c                   	ins    BYTE PTR es:[di],dx
     a1f:	4e                   	dec    si
     a20:	61                   	popa
     a21:	76 79                	jbe    0xa9c
     a23:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a26:	50                   	push   ax
     a27:	75 72                	jne    0xa9b
     a29:	70 6c                	jo     0xa97
     a2b:	65 00 63 6c          	add    BYTE PTR gs:[bp+di+0x6c],ah
     a2f:	54                   	push   sp
     a30:	65 61                	gs popa
     a32:	6c                   	ins    BYTE PTR es:[di],dx
     a33:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a36:	47                   	inc    di
     a37:	72 61                	jb     0xa9a
     a39:	79 00                	jns    0xa3b
     a3b:	63 6c 53             	arpl   WORD PTR [si+0x53],bp
     a3e:	69 6c 76 65 72       	imul   bp,WORD PTR [si+0x76],0x7265
     a43:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a46:	52                   	push   dx
     a47:	65 64 00 63 6c       	gs add BYTE PTR fs:[bp+di+0x6c],ah
     a4c:	4c                   	dec    sp
     a4d:	69 6d 65 00 63       	imul   bp,WORD PTR [di+0x65],0x6300
     a52:	6c                   	ins    BYTE PTR es:[di],dx
     a53:	59                   	pop    cx
     a54:	65 6c                	gs ins BYTE PTR es:[di],dx
     a56:	6c                   	ins    BYTE PTR es:[di],dx
     a57:	6f                   	outs   dx,WORD PTR ds:[si]
     a58:	77 00                	ja     0xa5a
     a5a:	63 6c 42             	arpl   WORD PTR [si+0x42],bp
     a5d:	6c                   	ins    BYTE PTR es:[di],dx
     a5e:	75 65                	jne    0xac5
     a60:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a63:	46                   	inc    si
     a64:	75 63                	jne    0xac9
     a66:	68 73 69             	push   0x6973
     a69:	61                   	popa
     a6a:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a6d:	41                   	inc    cx
     a6e:	71 75                	jno    0xae5
     a70:	61                   	popa
     a71:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     a74:	57                   	push   di
     a75:	68 69 74             	push   0x7469
     a78:	65 00 63 6c          	add    BYTE PTR gs:[bp+di+0x6c],ah
     a7c:	53                   	push   bx
     a7d:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     a80:	6c                   	ins    BYTE PTR es:[di],dx
     a81:	6c                   	ins    BYTE PTR es:[di],dx
     a82:	42                   	inc    dx
     a83:	61                   	popa
     a84:	72 00                	jb     0xa86
     a86:	63 6c 42             	arpl   WORD PTR [si+0x42],bp
     a89:	61                   	popa
     a8a:	63 6b 67             	arpl   WORD PTR [bp+di+0x67],bp
     a8d:	72 6f                	jb     0xafe
     a8f:	75 6e                	jne    0xaff
     a91:	64 00 63 6c          	add    BYTE PTR fs:[bp+di+0x6c],ah
     a95:	41                   	inc    cx
     a96:	63 74 69             	arpl   WORD PTR [si+0x69],si
     a99:	76 65                	jbe    0xb00
     a9b:	43                   	inc    bx
     a9c:	61                   	popa
     a9d:	70 74                	jo     0xb13
     a9f:	69 6f 6e 00 63       	imul   bp,WORD PTR [bx+0x6e],0x6300
     aa4:	6c                   	ins    BYTE PTR es:[di],dx
     aa5:	49                   	dec    cx
     aa6:	6e                   	outs   dx,BYTE PTR ds:[si]
     aa7:	61                   	popa
     aa8:	63 74 69             	arpl   WORD PTR [si+0x69],si
     aab:	76 65                	jbe    0xb12
     aad:	43                   	inc    bx
     aae:	61                   	popa
     aaf:	70 74                	jo     0xb25
     ab1:	69 6f 6e 00 63       	imul   bp,WORD PTR [bx+0x6e],0x6300
     ab6:	6c                   	ins    BYTE PTR es:[di],dx
     ab7:	4d                   	dec    bp
     ab8:	65 6e                	outs   dx,BYTE PTR gs:[si]
     aba:	75 02                	jne    0xabe
     abc:	00 09                	add    BYTE PTR [bx+di],cl
     abe:	00 00                	add    BYTE PTR [bx+si],al
     ac0:	63 6c 57             	arpl   WORD PTR [si+0x57],bp
     ac3:	69 6e 64 6f 77       	imul   bp,WORD PTR [bp+0x64],0x776f
     ac8:	01 00                	add    WORD PTR [bx+si],ax
     aca:	5a                   	pop    dx
     acb:	00 46 72             	add    BYTE PTR [bp+0x72],al
     ace:	61                   	popa
     acf:	6d                   	ins    WORD PTR es:[di],dx
     ad0:	65 00 63 6c          	add    BYTE PTR gs:[bp+di+0x6c],ah
     ad4:	4d                   	dec    bp
     ad5:	65 6e                	outs   dx,BYTE PTR gs:[si]
     ad7:	75 54                	jne    0xb2d
     ad9:	65 78 74             	gs js  0xb50
     adc:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     adf:	57                   	push   di
     ae0:	69 6e 64 6f 77       	imul   bp,WORD PTR [bp+0x64],0x776f
     ae5:	54                   	push   sp
     ae6:	65 78 74             	gs js  0xb5d
     ae9:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     aec:	43                   	inc    bx
     aed:	61                   	popa
     aee:	70 74                	jo     0xb64
     af0:	69 6f 6e 54 65       	imul   bp,WORD PTR [bx+0x6e],0x6554
     af5:	78 74                	js     0xb6b
     af7:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     afa:	41                   	inc    cx
     afb:	63 74 69             	arpl   WORD PTR [si+0x69],si
     afe:	76 65                	jbe    0xb65
     b00:	42                   	inc    dx
     b01:	6f                   	outs   dx,WORD PTR ds:[si]
     b02:	72 64                	jb     0xb68
     b04:	65 72 00             	gs jb  0xb07
     b07:	63 6c 49             	arpl   WORD PTR [si+0x49],bp
     b0a:	6e                   	outs   dx,BYTE PTR ds:[si]
     b0b:	61                   	popa
     b0c:	63 74 69             	arpl   WORD PTR [si+0x69],si
     b0f:	76 65                	jbe    0xb76
     b11:	42                   	inc    dx
     b12:	6f                   	outs   dx,WORD PTR ds:[si]
     b13:	72 64                	jb     0xb79
     b15:	65 72 00             	gs jb  0xb18
     b18:	63 6c 41             	arpl   WORD PTR [si+0x41],bp
     b1b:	70 70                	jo     0xb8d
     b1d:	57                   	push   di
     b1e:	6f                   	outs   dx,WORD PTR ds:[si]
     b1f:	72 6b                	jb     0xb8c
     b21:	53                   	push   bx
     b22:	70 61                	jo     0xb85
     b24:	63 65 02             	arpl   WORD PTR [di+0x2],sp
     b27:	00 0c                	add    BYTE PTR [si],cl
     b29:	00 00                	add    BYTE PTR [bx+si],al
     b2b:	63 6c 48             	arpl   WORD PTR [si+0x48],bp
     b2e:	69 67 68 6c 69       	imul   sp,WORD PTR [bx+0x68],0x696c
     b33:	67 68 74 01          	addr32 push 0x174
     b37:	00 54 00             	add    BYTE PTR [si+0x0],dl
     b3a:	54                   	push   sp
     b3b:	65 78 74             	gs js  0xbb2
     b3e:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     b41:	42                   	inc    dx
     b42:	74 6e                	je     0xbb2
     b44:	46                   	inc    si
     b45:	61                   	popa
     b46:	63 65 00             	arpl   WORD PTR [di+0x0],sp
     b49:	63 6c 42             	arpl   WORD PTR [si+0x42],bp
     b4c:	74 6e                	je     0xbbc
     b4e:	53                   	push   bx
     b4f:	68 61 64             	push   0x6461
     b52:	6f                   	outs   dx,WORD PTR ds:[si]
     b53:	77 00                	ja     0xb55
     b55:	63 6c 47             	arpl   WORD PTR [si+0x47],bp
     b58:	72 61                	jb     0xbbb
     b5a:	79 54                	jns    0xbb0
     b5c:	65 78 74             	gs js  0xbd3
     b5f:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     b62:	42                   	inc    dx
     b63:	74 6e                	je     0xbd3
     b65:	54                   	push   sp
     b66:	65 78 74             	gs js  0xbdd
     b69:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     b6c:	49                   	dec    cx
     b6d:	6e                   	outs   dx,BYTE PTR ds:[si]
     b6e:	61                   	popa
     b6f:	63 74 69             	arpl   WORD PTR [si+0x69],si
     b72:	76 65                	jbe    0xbd9
     b74:	43                   	inc    bx
     b75:	61                   	popa
     b76:	70 74                	jo     0xbec
     b78:	69 6f 6e 54 65       	imul   bp,WORD PTR [bx+0x6e],0x6554
     b7d:	78 74                	js     0xbf3
     b7f:	00 63 6c             	add    BYTE PTR [bp+di+0x6c],ah
     b82:	42                   	inc    dx
     b83:	74 6e                	je     0xbf3
     b85:	48                   	dec    ax
     b86:	69 67 68 6c 69       	imul   sp,WORD PTR [bx+0x68],0x696c
     b8b:	67 68 74 07          	addr32 push 0x774
     b8f:	00 01                	add    BYTE PTR [bx+di],al
     b91:	00 00                	add    BYTE PTR [bx+si],al
     b93:	01 00                	add    WORD PTR [bx+si],ax
     b95:	07                   	pop    es
     b96:	00 06 53 79          	add    BYTE PTR ds:0x7953,al
     b9a:	73 74                	jae    0xc10
     b9c:	65 6d                	gs ins WORD PTR es:[di],dx
     b9e:	1f                   	pop    ds
     b9f:	00 01                	add    BYTE PTR [bx+di],al
     ba1:	00 00                	add    BYTE PTR [bx+si],al
     ba3:	01 00                	add    WORD PTR [bx+si],ax
     ba5:	17                   	pop    ss
     ba6:	00 01                	add    BYTE PTR [bx+di],al
     ba8:	00 00                	add    BYTE PTR [bx+si],al
     baa:	00 00                	add    BYTE PTR [bx+si],al
     bac:	00 01                	add    BYTE PTR [bx+di],al
     bae:	00 02                	add    BYTE PTR [bp+si],al
     bb0:	00 03                	add    BYTE PTR [bp+di],al
     bb2:	00 04                	add    BYTE PTR [si],al
     bb4:	00 05                	add    BYTE PTR [di],al
     bb6:	00 06 00 00          	add    BYTE PTR ds:0x0,al
     bba:	00 ff                	add    bh,bh
     bbc:	ff                   	(bad)
     bbd:	ff 07                	inc    WORD PTR [bx]
     bbf:	00 01                	add    BYTE PTR [bx+di],al
     bc1:	00 00                	add    BYTE PTR [bx+si],al
     bc3:	01 00                	add    WORD PTR [bx+si],ax
     bc5:	20 01                	and    BYTE PTR [bx+di],al
     bc7:	01 00                	add    WORD PTR [bx+si],ax
     bc9:	10 00                	adc    BYTE PTR [bx+si],al
     bcb:	0b 00                	or     ax,WORD PTR [bx+si]
     bcd:	06                   	push   es
     bce:	00 0d                	add    BYTE PTR [di],cl
     bd0:	00 04                	add    BYTE PTR [si],al
     bd2:	00 0e 00 05          	add    BYTE PTR ds:0x500,cl
     bd6:	00 0c                	add    BYTE PTR [si],cl
     bd8:	00 03                	add    BYTE PTR [bp+di],al
     bda:	00 0f                	add    BYTE PTR [bx],cl
     bdc:	00 02                	add    BYTE PTR [bp+si],al
     bde:	00 09                	add    BYTE PTR [bx+di],cl
     be0:	00 08                	add    BYTE PTR [bx+si],cl
     be2:	00 07                	add    BYTE PTR [bx],al
     be4:	00 0a                	add    BYTE PTR [bp+si],cl
     be6:	00 49 07             	add    BYTE PTR [bx+di+0x7],cl
     be9:	be 12 03             	mov    si,0x312
     bec:	57                   	push   di
     bed:	4d                   	dec    bp
     bee:	46                   	inc    si
     bef:	40                   	inc    ax
     bf0:	2b c6                	sub    ax,si
     bf2:	12 00                	adc    al,BYTE PTR [bx+si]
     bf4:	00 00                	add    BYTE PTR [bx+si],al
     bf6:	00 fc                	add    ah,bh
     bf8:	08 ce                	or     dh,cl
     bfa:	12 03                	adc    al,BYTE PTR [bp+di]
     bfc:	49                   	dec    cx
     bfd:	43                   	inc    bx
     bfe:	4f                   	dec    di
     bff:	50                   	push   ax
     c00:	2b ca                	sub    cx,dx
     c02:	12 ac 12 d6          	adc    ch,BYTE PTR [si-0x29ee]
     c06:	12 3f                	adc    bh,BYTE PTR [bx]
     c08:	08 e2                	or     dl,ah
     c0a:	12 03                	adc    al,BYTE PTR [bp+di]
     c0c:	42                   	inc    dx
     c0d:	4d                   	dec    bp
     c0e:	50                   	push   ax
     c0f:	60                   	pusha
     c10:	2b da                	sub    bx,dx
     c12:	12 bc 12 de          	adc    bh,BYTE PTR [si-0x21ee]
     c16:	12 cc                	adc    cl,ah
     c18:	12 f2                	adc    dh,dl
     c1a:	12 49 07             	adc    cl,BYTE PTR [bx+di+0x7]
     c1d:	ec                   	in     al,dx
     c1e:	12 03                	adc    al,BYTE PTR [bp+di]
     c20:	00 00                	add    BYTE PTR [bx+si],al
     c22:	00 00                	add    BYTE PTR [bx+si],al
     c24:	00 3f                	add    BYTE PTR [bx],bh
     c26:	08 ff                	or     bh,bh
     c28:	ff 02                	inc    WORD PTR [bp+si]
     c2a:	00 e0                	add    al,ah
     c2c:	12 f6                	adc    dh,dh
     c2e:	12 ea                	adc    ch,dl
     c30:	12 7c 13             	adc    bh,BYTE PTR [si+0x13]
     c33:	64 00 fe             	fs add dh,bh
     c36:	00 e8                	add    al,ch
     c38:	03 a0 05 ec          	add    sp,WORD PTR [bx+si-0x13fb]
     c3c:	09 04                	or     WORD PTR [si],ax
     c3e:	00 02                	add    BYTE PTR [bp+si],al
     c40:	00 05                	add    BYTE PTR [di],al
     c42:	00 06 00 03          	add    BYTE PTR ds:0x300,al
     c46:	00 7e f0             	add    BYTE PTR [bp-0x10],bh
     c49:	7f f0                	jg     0xc3b
     c4b:	80 f0 81             	xor    al,0x81
     c4e:	f0 82 f0 83          	lock xor al,0x83
     c52:	f0 84 f0             	lock test al,dh
     c55:	85 f0                	test   ax,si
     c57:	86 f0                	xchg   al,dh
     c59:	87 f0                	xchg   ax,si
     c5b:	88 f0                	mov    al,dh
     c5d:	89 f0                	mov    ax,si
     c5f:	8a f0                	mov    dh,al
     c61:	8b f0                	mov    si,ax
     c63:	8c f0                	mov    ax,?
     c65:	8d                   	lea    si,(bad)
     c66:	f0 8e f0             	lock mov ?,ax
     c69:	8f                   	(bad)
     c6a:	f0 00 00             	lock add BYTE PTR [bx+si],al
     c6d:	01 46 01             	add    WORD PTR [bp+0x1],ax
     c70:	2a 01                	sub    al,BYTE PTR [bx+di]
     c72:	2b 01                	sub    ax,WORD PTR [bx+di]
     c74:	5f                   	pop    di
     c75:	01 2d                	add    WORD PTR [di],bp
     c77:	01 2e 01 2f          	add    WORD PTR ds:0x2f01,bp
     c7b:	01 3b                	add    WORD PTR [bp+di],di
     c7d:	01 3d                	add    WORD PTR [di],di
     c7f:	01 2c                	add    WORD PTR [si],bp
     c81:	01 2d                	add    WORD PTR [di],bp
     c83:	01 2e 01 2f          	add    WORD PTR ds:0x2f01,bp
     c87:	01 60 01             	add    WORD PTR [bx+si+0x1],sp
     c8a:	5b                   	pop    bx
     c8b:	01 5c 01             	add    WORD PTR [si+0x1],bx
     c8e:	5d                   	pop    bp
     c8f:	08 09                	or     BYTE PTR [bx+di],cl
     c91:	02 00                	add    al,BYTE PTR [bx+si]
     c93:	00 00                	add    BYTE PTR [bx+si],al
     c95:	00 0d                	add    BYTE PTR [di],cl
     c97:	0d 02 03             	or     ax,0x302
     c9a:	00 00                	add    BYTE PTR [bx+si],al
     c9c:	00 1b                	add    BYTE PTR [bp+di],bl
     c9e:	1b 02                	sbb    ax,WORD PTR [bp+si]
     ca0:	02 00                	add    al,BYTE PTR [bx+si]
     ca2:	00 00                	add    BYTE PTR [bx+si],al
     ca4:	20 28                	and    BYTE PTR [bx+si],ch
     ca6:	02 04                	add    al,BYTE PTR [si]
     ca8:	00 00                	add    BYTE PTR [bx+si],al
     caa:	00 2d                	add    BYTE PTR [di],ch
     cac:	2e 02 0d             	add    cl,BYTE PTR cs:[di]
     caf:	00 00                	add    BYTE PTR [bx+si],al
     cb1:	00 30                	add    BYTE PTR [bx+si],dh
     cb3:	39 00                	cmp    WORD PTR [bx+si],ax
     cb5:	30 13                	xor    BYTE PTR [bp+di],dl
     cb7:	83 13 41             	adc    WORD PTR [bp+di],0x41
     cba:	5a                   	pop    dx
     cbb:	01 30                	add    WORD PTR [bx+si],si
     cbd:	13 8a 13 60          	adc    cx,WORD PTR [bp+si+0x6013]
     cc1:	69 00 30 13          	imul   ax,WORD PTR [bx+si],0x1330
     cc5:	98                   	cbw
     cc6:	13 6a 6f             	adc    bp,WORD PTR [bp+si+0x6f]
     cc9:	03 00                	add    ax,WORD PTR [bx+si]
     ccb:	00 00                	add    BYTE PTR [bx+si],al
     ccd:	00 6f 87             	add    BYTE PTR [bx-0x79],ch
     cd0:	00 32                	add    BYTE PTR [bp+si],dh
     cd2:	13 f2                	adc    si,dx
     cd4:	13 ba bf 03          	adc    di,WORD PTR [bp+si+0x3bf]
     cd8:	06                   	push   es
     cd9:	00 00                	add    BYTE PTR [bx+si],al
     cdb:	00 c0                	add    al,al
     cdd:	c0 03 0c             	rol    BYTE PTR [bp+di],0xc
     ce0:	00 00                	add    BYTE PTR [bx+si],al
     ce2:	00 db                	add    bl,bl
     ce4:	dd 03                	fld    QWORD PTR [bp+di]
     ce6:	0d 08 00             	or     ax,0x8
     ce9:	01 00                	add    WORD PTR [bx+si],ax
     ceb:	00 01                	add    BYTE PTR [bx+di],al
     ced:	00 05                	add    BYTE PTR [di],al
     cef:	00 40 00             	add    BYTE PTR [bx+si+0x0],al
     cf2:	00 00                	add    BYTE PTR [bx+si],al
     cf4:	20 07                	and    BYTE PTR [bx],al
     cf6:	00 01                	add    BYTE PTR [bx+di],al
     cf8:	00 00                	add    BYTE PTR [bx+si],al
     cfa:	01 00                	add    WORD PTR [bx+si],ax
     cfc:	05 00 08             	add    ax,0x800
     cff:	00 00                	add    BYTE PTR [bx+si],al
     d01:	00 03                	add    BYTE PTR [bp+di],al
     d03:	0c 00                	or     al,0x0
     d05:	01 00                	add    WORD PTR [bx+si],ax
     d07:	00 01                	add    BYTE PTR [bx+di],al
     d09:	00 12                	add    BYTE PTR [bp+si],dl
     d0b:	00 08                	add    BYTE PTR [bx+si],cl
     d0d:	00 00                	add    BYTE PTR [bx+si],al
     d0f:	09 00                	or     WORD PTR [bx+si],ax
     d11:	24 00                	and    al,0x0
     d13:	40                   	inc    ax
     d14:	00 23                	add    BYTE PTR [bp+di],ah
     d16:	00 3b                	add    BYTE PTR [bp+di],bh
     d18:	00 00                	add    BYTE PTR [bx+si],al
     d1a:	00 08                	add    BYTE PTR [bx+si],cl
     d1c:	00 04                	add    BYTE PTR [si],al
     d1e:	09 00                	or     WORD PTR [bx+si],ax
     d20:	01 00                	add    WORD PTR [bx+si],ax
     d22:	00 01                	add    BYTE PTR [bx+di],al
     d24:	00 89 00 ff          	add    BYTE PTR [bx+di-0x100],cl
     d28:	ff 00                	inc    WORD PTR [bx+si]
     d2a:	00 54 14             	add    BYTE PTR [si+0x14],dl
     d2d:	f8                   	clc
     d2e:	13 fe                	adc    di,si
     d30:	ff 5e 14             	call   DWORD PTR [bp+0x14]
     d33:	fe                   	(bad)
     d34:	13 fd                	adc    di,bp
     d36:	ff 66 14             	jmp    WORD PTR [bp+0x14]
     d39:	04 14                	add    al,0x14
     d3b:	fc                   	cld
     d3c:	ff 6e 14             	jmp    DWORD PTR [bp+0x14]
     d3f:	0a 14                	or     dl,BYTE PTR [si]
     d41:	fb                   	sti
     d42:	ff 76 14             	push   WORD PTR [bp+0x14]
     d45:	10 14                	adc    BYTE PTR [si],dl
     d47:	fa                   	cli
     d48:	ff                   	(bad)
     d49:	7d 14                	jge    0xd5f
     d4b:	16                   	push   ss
     d4c:	14 f9                	adc    al,0xf9
     d4e:	ff 88 14 1c          	dec    WORD PTR [bx+si+0x1c14]
     d52:	14 f8                	adc    al,0xf8
     d54:	ff 91 14 22          	call   WORD PTR [bx+di+0x2214]
     d58:	14 f7                	adc    al,0xf7
     d5a:	ff 9c 14 28          	call   DWORD PTR [si+0x2814]
     d5e:	14 f6                	adc    al,0xf6
     d60:	ff a5 14 2e          	jmp    WORD PTR [di+0x2e14]
     d64:	14 f5                	adc    al,0xf5
     d66:	ff af 14 34          	jmp    DWORD PTR [bx+0x3414]
     d6a:	14 f4                	adc    al,0xf4
     d6c:	ff                   	(bad)
     d6d:	bb 14 3a             	mov    bx,0x3a14
     d70:	14 f3                	adc    al,0xf3
     d72:	ff c2                	inc    dx
     d74:	14 40                	adc    al,0x40
     d76:	14 f2                	adc    al,0xf2
     d78:	ff cb                	dec    bx
     d7a:	14 46                	adc    al,0x46
     d7c:	14 f1                	adc    al,0xf1
     d7e:	ff d4                	call   sp
     d80:	14 4c                	adc    al,0x4c
     d82:	14 f0                	adc    al,0xf0
     d84:	ff                   	call   (bad)
     d85:	dd 14                	fst    QWORD PTR [si]
     d87:	52                   	push   dx
     d88:	14 ef                	adc    al,0xef
     d8a:	ff                   	jmp    (bad)
     d8b:	e9 14 22             	jmp    0x2fa2
     d8e:	16                   	push   ss
     d8f:	63 72 44             	arpl   WORD PTR [bp+si+0x44],si
     d92:	65 66 61             	gs popad
     d95:	75 6c                	jne    0xe03
     d97:	74 00                	je     0xd99
     d99:	63 72 41             	arpl   WORD PTR [bp+si+0x41],si
     d9c:	72 72                	jb     0xe10
     d9e:	6f                   	outs   dx,WORD PTR ds:[si]
     d9f:	77 00                	ja     0xda1
     da1:	63 72 43             	arpl   WORD PTR [bp+si+0x43],si
     da4:	72 6f                	jb     0xe15
     da6:	73 73                	jae    0xe1b
     da8:	00 63 72             	add    BYTE PTR [bp+di+0x72],ah
     dab:	49                   	dec    cx
     dac:	42                   	inc    dx
     dad:	65 61                	gs popa
     daf:	6d                   	ins    WORD PTR es:[di],dx
     db0:	02 00                	add    al,BYTE PTR [bx+si]
     db2:	07                   	pop    es
     db3:	00 00                	add    BYTE PTR [bx+si],al
     db5:	63 72 53             	arpl   WORD PTR [bp+si+0x53],si
     db8:	69 7a 65 01 00       	imul   di,WORD PTR [bp+si+0x65],0x1
     dbd:	6f                   	outs   dx,WORD PTR ds:[si]
     dbe:	00 4e 45             	add    BYTE PTR [bp+0x45],cl
     dc1:	53                   	push   bx
     dc2:	57                   	push   di
     dc3:	00 63 72             	add    BYTE PTR [bp+di+0x72],ah
     dc6:	53                   	push   bx
     dc7:	69 7a 65 4e 53       	imul   di,WORD PTR [bp+si+0x65],0x534e
     dcc:	00 63 72             	add    BYTE PTR [bp+di+0x72],ah
     dcf:	53                   	push   bx
     dd0:	69 7a 65 4e 57       	imul   di,WORD PTR [bp+si+0x65],0x574e
     dd5:	53                   	push   bx
     dd6:	45                   	inc    bp
     dd7:	00 63 72             	add    BYTE PTR [bp+di+0x72],ah
     dda:	53                   	push   bx
     ddb:	69 7a 65 57 45       	imul   di,WORD PTR [bp+si+0x65],0x4557
     de0:	00 63 72             	add    BYTE PTR [bp+di+0x72],ah
     de3:	55                   	push   bp
     de4:	70 41                	jo     0xe27
     de6:	72 72                	jb     0xe5a
     de8:	6f                   	outs   dx,WORD PTR ds:[si]
     de9:	77 00                	ja     0xdeb
     deb:	63 72 48             	arpl   WORD PTR [bp+si+0x48],si
     dee:	6f                   	outs   dx,WORD PTR ds:[si]
     def:	75 72                	jne    0xe63
     df1:	47                   	inc    di
     df2:	6c                   	ins    BYTE PTR es:[di],dx
     df3:	61                   	popa
     df4:	73 73                	jae    0xe69
     df6:	00 63 72             	add    BYTE PTR [bp+di+0x72],ah
     df9:	44                   	inc    sp
     dfa:	72 61                	jb     0xe5d
     dfc:	67 00 63 72          	add    BYTE PTR [ebx+0x72],ah
     e00:	4e                   	dec    si
     e01:	6f                   	outs   dx,WORD PTR ds:[si]
     e02:	44                   	inc    sp
     e03:	72 6f                	jb     0xe74
     e05:	70 00                	jo     0xe07
     e07:	63 72 48             	arpl   WORD PTR [bp+si+0x48],si
     e0a:	53                   	push   bx
     e0b:	70 6c                	jo     0xe79
     e0d:	69 74 00 63 72       	imul   si,WORD PTR [si+0x0],0x7263
     e12:	56                   	push   si
     e13:	53                   	push   bx
     e14:	70 6c                	jo     0xe82
     e16:	69 74 00 63 72       	imul   si,WORD PTR [si+0x0],0x7263
     e1b:	4d                   	dec    bp
     e1c:	75 6c                	jne    0xe8a
     e1e:	74 69                	je     0xe89
     e20:	44                   	inc    sp
     e21:	72 61                	jb     0xe84
     e23:	67 00 63 72          	add    BYTE PTR [ebx+0x72],ah
     e27:	53                   	push   bx
     e28:	51                   	push   cx
     e29:	4c                   	dec    sp
     e2a:	57                   	push   di
     e2b:	61                   	popa
     e2c:	69 74 0a 00 01       	imul   si,WORD PTR [si+0xa],0x100
     e31:	00 00                	add    BYTE PTR [bx+si],al
     e33:	01 00                	add    WORD PTR [bx+si],ax
     e35:	25 00 97             	and    ax,0x9700
     e38:	00 57 00             	add    BYTE PTR [bx+0x0],dl
     e3b:	01 00                	add    WORD PTR [bx+si],ax
     e3d:	00 00                	add    BYTE PTR [bx+si],al
     e3f:	43                   	inc    bx
     e40:	6f                   	outs   dx,WORD PTR ds:[si]
     e41:	6e                   	outs   dx,BYTE PTR ds:[si]
     e42:	74 72                	je     0xeb6
     e44:	6f                   	outs   dx,WORD PTR ds:[si]
     e45:	6c                   	ins    BYTE PTR es:[di],dx
     e46:	4f                   	dec    di
     e47:	66 73 25             	data32 jae 0xe6f
     e4a:	2e 34 58             	cs xor al,0x58
     e4d:	00 43 6f             	add    BYTE PTR [bp+di+0x6f],al
     e50:	6e                   	outs   dx,BYTE PTR ds:[si]
     e51:	74 72                	je     0xec5
     e53:	6f                   	outs   dx,WORD PTR ds:[si]
     e54:	6c                   	ins    BYTE PTR es:[di],dx
     e55:	53                   	push   bx
     e56:	65 67 25 2e 34       	gs addr32 and ax,0x342e
     e5b:	58                   	pop    ax
     e5c:	0d 00 01             	or     ax,0x100
     e5f:	00 00                	add    BYTE PTR [bx+si],al
     e61:	01 00                	add    WORD PTR [bx+si],ax
     e63:	15 00 cf             	adc    ax,0xcf00
     e66:	09 ff                	or     di,di
     e68:	ff 01                	inc    WORD PTR [bx+di]
     e6a:	00 00                	add    BYTE PTR [bx+si],al
     e6c:	00 24                	add    BYTE PTR [si],ah
     e6e:	2a 24                	sub    ah,BYTE PTR [si]
     e70:	2a 24                	sub    ah,BYTE PTR [si]
     e72:	2a 00                	sub    al,BYTE PTR [bx+si]
     e74:	37                   	aaa
     e75:	04 01                	add    al,0x1
     e77:	56                   	push   si
     e78:	43                   	inc    bx
     e79:	4c                   	dec    sp
     e7a:	0d 00 01             	or     ax,0x100
     e7d:	00 00                	add    BYTE PTR [bx+si],al
     e7f:	01 00                	add    WORD PTR [bx+si],ax
     e81:	be 00 43             	mov    si,0x4300
     e84:	54                   	push   sp
     e85:	4c                   	dec    sp
     e86:	33 44 56             	xor    ax,WORD PTR [si+0x56]
     e89:	32 2e 44 4c          	xor    ch,BYTE PTR ds:0x4c44
     e8d:	4c                   	dec    sp
     e8e:	00 43 74             	add    BYTE PTR [bp+di+0x74],al
     e91:	6c                   	ins    BYTE PTR es:[di],dx
     e92:	33 64 52             	xor    sp,WORD PTR [si+0x52]
     e95:	65 67 69 73 74 65 72 	imul   si,WORD PTR gs:[ebx+0x74],0x7265
     e9c:	00 43 74             	add    BYTE PTR [bp+di+0x74],al
     e9f:	6c                   	ins    BYTE PTR es:[di],dx
     ea0:	33 64 55             	xor    sp,WORD PTR [si+0x55]
     ea3:	6e                   	outs   dx,BYTE PTR ds:[si]
     ea4:	72 65                	jb     0xf0b
     ea6:	67 69 73 74 65 72    	imul   si,WORD PTR [ebx+0x74],0x7265
     eac:	00 43 74             	add    BYTE PTR [bp+di+0x74],al
     eaf:	6c                   	ins    BYTE PTR es:[di],dx
     eb0:	33 64 53             	xor    sp,WORD PTR [si+0x53]
     eb3:	75 62                	jne    0xf17
     eb5:	63 6c 61             	arpl   WORD PTR [si+0x61],bp
     eb8:	73 73                	jae    0xf2d
     eba:	43                   	inc    bx
     ebb:	74 6c                	je     0xf29
     ebd:	00 43 74             	add    BYTE PTR [bp+di+0x74],al
     ec0:	6c                   	ins    BYTE PTR es:[di],dx
     ec1:	33 64 53             	xor    sp,WORD PTR [si+0x53]
     ec4:	75 62                	jne    0xf28
     ec6:	63 6c 61             	arpl   WORD PTR [si+0x61],bp
     ec9:	73 73                	jae    0xf3e
     ecb:	44                   	inc    sp
     ecc:	6c                   	ins    BYTE PTR es:[di],dx
     ecd:	67 00 43 74          	add    BYTE PTR [ebx+0x74],al
     ed1:	6c                   	ins    BYTE PTR es:[di],dx
     ed2:	33 64 44             	xor    sp,WORD PTR [si+0x44]
     ed5:	6c                   	ins    BYTE PTR es:[di],dx
     ed6:	67 46                	addr32 inc si
     ed8:	72 61                	jb     0xf3b
     eda:	6d                   	ins    WORD PTR es:[di],dx
     edb:	65 50                	gs push ax
     edd:	61                   	popa
     ede:	69 6e 74 00 43       	imul   bp,WORD PTR [bp+0x74],0x4300
     ee3:	74 6c                	je     0xf51
     ee5:	33 64 43             	xor    sp,WORD PTR [si+0x43]
     ee8:	74 6c                	je     0xf56
     eea:	43                   	inc    bx
     eeb:	6f                   	outs   dx,WORD PTR ds:[si]
     eec:	6c                   	ins    BYTE PTR es:[di],dx
     eed:	6f                   	outs   dx,WORD PTR ds:[si]
     eee:	72 45                	jb     0xf35
     ef0:	78 00                	js     0xef2
     ef2:	43                   	inc    bx
     ef3:	74 6c                	je     0xf61
     ef5:	33 64 41             	xor    sp,WORD PTR [si+0x41]
     ef8:	75 74                	jne    0xf6e
     efa:	6f                   	outs   dx,WORD PTR ds:[si]
     efb:	53                   	push   bx
     efc:	75 62                	jne    0xf60
     efe:	63 6c 61             	arpl   WORD PTR [si+0x61],bp
     f01:	73 73                	jae    0xf76
     f03:	00 43 74             	add    BYTE PTR [bp+di+0x74],al
     f06:	6c                   	ins    BYTE PTR es:[di],dx
     f07:	33 64 55             	xor    sp,WORD PTR [si+0x55]
     f0a:	6e                   	outs   dx,BYTE PTR ds:[si]
     f0b:	41                   	inc    cx
     f0c:	75 74                	jne    0xf82
     f0e:	6f                   	outs   dx,WORD PTR ds:[si]
     f0f:	53                   	push   bx
     f10:	75 62                	jne    0xf74
     f12:	63 6c 61             	arpl   WORD PTR [si+0x61],bp
     f15:	73 73                	jae    0xf8a
     f17:	00 43 74             	add    BYTE PTR [bp+di+0x74],al
     f1a:	6c                   	ins    BYTE PTR es:[di],dx
     f1b:	33 44 43             	xor    ax,WORD PTR [si+0x43]
     f1e:	6f                   	outs   dx,WORD PTR ds:[si]
     f1f:	6c                   	ins    BYTE PTR es:[di],dx
     f20:	6f                   	outs   dx,WORD PTR ds:[si]
     f21:	72 43                	jb     0xf66
     f23:	68 61 6e             	push   0x6e61
     f26:	67 65 00 42 74       	add    BYTE PTR gs:[edx+0x74],al
     f2b:	6e                   	outs   dx,BYTE PTR ds:[si]
     f2c:	57                   	push   di
     f2d:	6e                   	outs   dx,BYTE PTR ds:[si]
     f2e:	64 50                	fs push ax
     f30:	72 6f                	jb     0xfa1
     f32:	63 33                	arpl   WORD PTR [bp+di],si
     f34:	64 00 00             	add    BYTE PTR fs:[bx+si],al
     f37:	8c cb                	mov    bx,cs
     f39:	8e c3                	mov    es,bx
     f3b:	5b                   	pop    bx
     f3c:	ea 00 00 a0 16       	jmp    0x16a0:0x0
     f41:	12 00                	adc    al,BYTE PTR [bx+si]
     f43:	01 00                	add    WORD PTR [bx+si],ax
     f45:	00 01                	add    BYTE PTR [bx+di],al
     f47:	00 82 00 24          	add    BYTE PTR [bp+si+0x2400],al
     f4b:	16                   	push   ss
     f4c:	b6 16                	mov    dh,0x16
     f4e:	54                   	push   sp
     f4f:	50                   	push   ax
     f50:	55                   	push   bp
     f51:	74 69                	je     0xfbc
     f53:	6c                   	ins    BYTE PTR es:[di],dx
     f54:	57                   	push   di
     f55:	69 6e 64 6f 77       	imul   bp,WORD PTR [bp+0x64],0x776f
     f5a:	00 00                	add    BYTE PTR [bx+si],al
     f5c:	00 00                	add    BYTE PTR [bx+si],al
     f5e:	05 00 20             	add    ax,0x2000
     f61:	00 07                	add    BYTE PTR [bx],al
     f63:	00 00                	add    BYTE PTR [bx+si],al
     f65:	00 20                	add    BYTE PTR [bx+si],ah
     f67:	00 00                	add    BYTE PTR [bx+si],al
     f69:	00 10                	add    BYTE PTR [bx+si],dl
     f6b:	00 01                	add    BYTE PTR [bx+di],al
     f6d:	00 06 00 03          	add    BYTE PTR ds:0x300,al
     f71:	00 4d 44             	add    BYTE PTR [di+0x44],cl
     f74:	49                   	dec    cx
     f75:	43                   	inc    bx
     f76:	4c                   	dec    sp
     f77:	49                   	dec    cx
     f78:	45                   	inc    bp
     f79:	4e                   	dec    si
     f7a:	54                   	push   sp
     f7b:	00 04                	add    BYTE PTR [si],al
     f7d:	00 07                	add    BYTE PTR [bx],al
     f7f:	00 03                	add    BYTE PTR [bp+di],al
     f81:	00 01                	add    BYTE PTR [bx+di],al
     f83:	00 07                	add    BYTE PTR [bx],al
     f85:	00 03                	add    BYTE PTR [bp+di],al
     f87:	00 fa                	add    dl,bh
     f89:	7f 00                	jg     0xf8b
     f8b:	00 fb                	add    bl,bh
     f8d:	7f 00                	jg     0xf8f
     f8f:	00 fc                	add    ah,bh
     f91:	7f 00                	jg     0xf93
     f93:	00 fd                	add    ch,bh
     f95:	7f 00                	jg     0xf97
     f97:	00 ff                	add    bh,bh
     f99:	7f 00                	jg     0xf9b
     f9b:	00 fe                	add    dh,bh
     f9d:	7f 00                	jg     0xf9f
     f9f:	00 02                	add    BYTE PTR [bp+si],al
     fa1:	7f 00                	jg     0xfa3
     fa3:	00 04                	add    BYTE PTR [si],al
     fa5:	7f 00                	jg     0xfa7
     fa7:	00 84 7f 00          	add    BYTE PTR [si+0x7f],al
     fab:	00 82 7f 00          	add    BYTE PTR [bp+si+0x7f],al
     faf:	00 85 7f 00          	add    BYTE PTR [di+0x7f],al
     fb3:	00 83 7f 00          	add    BYTE PTR [bp+di+0x7f],al
     fb7:	00 80 7f 00          	add    BYTE PTR [bx+si+0x7f],al
     fbb:	00 01                	add    BYTE PTR [bx+di],al
     fbd:	7f 00                	jg     0xfbf
     fbf:	00 03                	add    BYTE PTR [bp+di],al
     fc1:	7f 00                	jg     0xfc3
     fc3:	00 00                	add    BYTE PTR [bx+si],al
     fc5:	7f 00                	jg     0xfc7
     fc7:	00 00                	add    BYTE PTR [bx+si],al
     fc9:	00 ff                	add    bh,bh
     fcb:	ff 12                	call   WORD PTR [bp+si]
     fcd:	00 01                	add    BYTE PTR [bx+di],al
     fcf:	00 00                	add    BYTE PTR [bx+si],al
     fd1:	01 00                	add    WORD PTR [bx+si],ax
     fd3:	4e                   	dec    si
     fd4:	00 b8 16 18          	add    BYTE PTR [bx+si+0x1816],bh
     fd8:	17                   	pop    ss
     fd9:	54                   	push   sp
     fda:	41                   	inc    cx
     fdb:	70 70                	jo     0x104d
     fdd:	6c                   	ins    BYTE PTR es:[di],dx
     fde:	69 63 61 74 69       	imul   sp,WORD PTR [bp+di+0x61],0x6974
     fe3:	6f                   	outs   dx,WORD PTR ds:[si]
     fe4:	6e                   	outs   dx,BYTE PTR ds:[si]
     fe5:	00 00                	add    BYTE PTR [bx+si],al
     fe7:	4d                   	dec    bp
     fe8:	41                   	inc    cx
     fe9:	49                   	dec    cx
     fea:	4e                   	dec    si
     feb:	49                   	dec    cx
     fec:	43                   	inc    bx
     fed:	4f                   	dec    di
     fee:	4e                   	dec    si
     fef:	00 00                	add    BYTE PTR [bx+si],al
     ff1:	2e 00 2e 44 52       	add    BYTE PTR cs:0x5244,ch
     ff6:	56                   	push   si
     ff7:	00 45 78             	add    BYTE PTR [di+0x78],al
     ffa:	74 44                	je     0x1040
     ffc:	65 76 69             	gs jbe 0x1068
     fff:	63 65 4d             	arpl   WORD PTR [di+0x4d],sp
    1002:	6f                   	outs   dx,WORD PTR ds:[si]
    1003:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
    1007:	64 65 76 69          	fs gs jbe 0x1074
    100b:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    100e:	00 77 69             	add    BYTE PTR [bx+0x69],dh
    1011:	6e                   	outs   dx,BYTE PTR ds:[si]
    1012:	64 6f                	outs   dx,WORD PTR fs:[si]
    1014:	77 73                	ja     0x1089
    1016:	00 64 65             	add    BYTE PTR [si+0x65],ah
    1019:	76 69                	jbe    0x1084
    101b:	63 65 00             	arpl   WORD PTR [di+0x0],sp
    101e:	00 54 50             	add    BYTE PTR [si+0x50],dl
    1021:	46                   	inc    si
    1022:	30 14                	xor    BYTE PTR [si],dl
    1024:	00 01                	add    BYTE PTR [bx+di],al
    1026:	00 00                	add    BYTE PTR [bx+si],al
    1028:	01 00                	add    WORD PTR [bx+si],ax
    102a:	0b 00                	or     ax,WORD PTR [bx+si]
    102c:	14 17                	adc    al,0x17
    102e:	50                   	push   ax
    102f:	17                   	pop    ss
    1030:	00 00                	add    BYTE PTR [bx+si],al
    1032:	00 00                	add    BYTE PTR [bx+si],al
    1034:	1f                   	pop    ds
    1035:	00 1c                	add    BYTE PTR [si],bl
    1037:	02 00                	add    al,BYTE PTR [bx+si]
    1039:	0a 00                	or     al,BYTE PTR [bx+si]
    103b:	00 1f                	add    BYTE PTR [bx],bl
    103d:	00 1e 00 1f          	add    BYTE PTR ds:0x1f00,bl
    1041:	00 1e 00 1f          	add    BYTE PTR ds:0x1f00,bl
    1045:	01 00                	add    WORD PTR [bx+si],ax
    1047:	04 00                	add    al,0x0
    1049:	00 1f                	add    BYTE PTR [bx],bl
    104b:	00 1d                	add    BYTE PTR [di],bl
    104d:	02 00                	add    al,BYTE PTR [bx+si]
    104f:	0a 00                	or     al,BYTE PTR [bx+si]
    1051:	00 1f                	add    BYTE PTR [bx],bl
    1053:	00 1e 00 1f          	add    BYTE PTR ds:0x1f00,bl
    1057:	00 1e 00 1f          	add    BYTE PTR ds:0x1f00,bl
    105b:	01 00                	add    WORD PTR [bx+si],ax
    105d:	0f 00 00             	sldt   WORD PTR [bx+si]
    1060:	1e                   	push   ds
    1061:	17                   	pop    ss
    1062:	54                   	push   sp
    1063:	17                   	pop    ss
    1064:	36 17                	ss pop ss
    1066:	ff                   	(bad)
    1067:	ff 69 6e             	jmp    DWORD PTR [bx+di+0x6e]
    106a:	74 6c                	je     0x10d8
    106c:	00 73 02             	add    BYTE PTR [bp+di+0x2],dh
    106f:	00 0a                	add    BYTE PTR [bp+si],cl
    1071:	00 43 75             	add    BYTE PTR [bp+di+0x75],al
    1074:	72 72                	jb     0x10e8
    1076:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1078:	63 79 00             	arpl   WORD PTR [bx+di+0x0],di
    107b:	69 01 00 86          	imul   ax,WORD PTR [bx+di],0x8600
    107f:	00 4e 65             	add    BYTE PTR [bp+0x65],cl
    1082:	67 43                	addr32 inc bx
    1084:	75 72                	jne    0x10f8
    1086:	72 00                	jb     0x1088
    1088:	73 54                	jae    0x10de
    108a:	68 6f 75             	push   0x756f
    108d:	73 61                	jae    0x10f0
    108f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1090:	64 00 73 44          	add    BYTE PTR fs:[bp+di+0x44],dh
    1094:	65 63 69 6d          	arpl   WORD PTR gs:[bx+di+0x6d],bp
    1098:	61                   	popa
    1099:	6c                   	ins    BYTE PTR es:[di],dx
    109a:	00 69 43             	add    BYTE PTR [bx+di+0x43],ch
    109d:	75 72                	jne    0x1111
    109f:	72 44                	jb     0x10e5
    10a1:	69 67 69 74 73       	imul   sp,WORD PTR [bx+0x69],0x7374
    10a6:	00 73 44             	add    BYTE PTR [bp+di+0x44],dh
    10a9:	61                   	popa
    10aa:	74 65                	je     0x1111
    10ac:	00 73 53             	add    BYTE PTR [bp+di+0x53],dh
    10af:	68 6f 72             	push   0x726f
    10b2:	74 44                	je     0x10f8
    10b4:	61                   	popa
    10b5:	74 65                	je     0x111c
    10b7:	00 73 4c             	add    BYTE PTR [bp+di+0x4c],dh
    10ba:	6f                   	outs   dx,WORD PTR ds:[si]
    10bb:	6e                   	outs   dx,BYTE PTR ds:[si]
    10bc:	67 44                	addr32 inc sp
    10be:	61                   	popa
    10bf:	74 65                	je     0x1126
    10c1:	00 73 54             	add    BYTE PTR [bp+di+0x54],dh
    10c4:	69 6d 65 00 73       	imul   bp,WORD PTR [di+0x65],0x7300
    10c9:	31 31                	xor    WORD PTR [bx+di],si
    10cb:	35 39 00             	xor    ax,0x39
    10ce:	73 32                	jae    0x1102
    10d0:	33 35                	xor    si,WORD PTR [di]
    10d2:	39 00                	cmp    WORD PTR [bx+si],ax
    10d4:	69 54 4c 5a 65       	imul   dx,WORD PTR [si+0x4c],0x655a
    10d9:	72 6f                	jb     0x114a
    10db:	00 69 54             	add    BYTE PTR [bx+di+0x54],ch
    10de:	69 6d 65 00 00       	imul   bp,WORD PTR [di+0x65],0x0
    10e3:	2e 00 00             	add    BYTE PTR cs:[bx+si],al
    10e6:	02 00                	add    al,BYTE PTR [bx+si]
    10e8:	89 ff                	mov    di,di
    10ea:	03 00                	add    ax,WORD PTR [bx+si]
    10ec:	8a ff                	mov    bh,bh
    10ee:	04 00                	add    al,0x0
    10f0:	8b ff                	mov    di,di
    10f2:	05 00 8c             	add    ax,0x8c00
    10f5:	ff 0f                	dec    WORD PTR [bx]
    10f7:	00 8d ff 64          	add    BYTE PTR [di+0x64ff],cl
    10fb:	00 8e ff 65          	add    BYTE PTR [bp+0x65ff],cl
    10ff:	00 8f ff 6a          	add    BYTE PTR [bx+0x6aff],cl
    1103:	00 90 ff 08          	add    BYTE PTR [bx+si+0x8ff],dl
    1107:	00 01                	add    BYTE PTR [bx+di],al
    1109:	00 00                	add    BYTE PTR [bx+si],al
    110b:	01 00                	add    WORD PTR [bx+si],ax
    110d:	5a                   	pop    dx
    110e:	00 5d 02             	add    BYTE PTR [di+0x2],bl
    1111:	06                   	push   es
    1112:	18 98 ff 02          	sbb    BYTE PTR [bx+si+0x2ff],bl
    1116:	01 0c                	add    WORD PTR [si],cx
    1118:	18 91 ff 2d          	sbb    BYTE PTR [bx+di+0x2dff],dl
    111c:	01 12                	add    WORD PTR [bp+si],dx
    111e:	18 92 ff 59          	sbb    BYTE PTR [bp+si+0x59ff],dl
    1122:	01 18                	add    WORD PTR [bx+si],bx
    1124:	18 93 ff b1          	sbb    BYTE PTR [bp+di-0x4e01],dl
    1128:	01 1e 18 94          	add    WORD PTR ds:0x9418,bx
    112c:	ff                   	call   (bad)
    112d:	dc 01                	fadd   QWORD PTR [bx+di]
    112f:	24 18                	and    al,0x18
    1131:	95                   	xchg   bp,ax
    1132:	ff 08                	dec    WORD PTR [bx+si]
    1134:	02 2a                	add    ch,BYTE PTR [bp+si]
    1136:	18 96 ff 32          	sbb    BYTE PTR [bp+0x32ff],dl
    113a:	02 30                	add    dh,BYTE PTR [bx+si]
    113c:	18 97 ff 8d          	sbb    BYTE PTR [bx-0x7201],dl
    1140:	02 36 18 99          	add    dh,BYTE PTR ds:0x9918
    1144:	ff 1e 04 3c          	call   DWORD PTR ds:0x3c04
    1148:	18 9f ff f2          	sbb    BYTE PTR [bx-0xd01],bl
    114c:	03 42 18             	add    ax,WORD PTR [bp+si+0x18]
    114f:	9e                   	sahf
    1150:	ff c3                	inc    bx
    1152:	03 48 18             	add    cx,WORD PTR [bx+si+0x18]
    1155:	9d                   	popf
    1156:	ff 6c 03             	jmp    DWORD PTR [si+0x3]
    1159:	4e                   	dec    si
    115a:	18 9b ff 43          	sbb    BYTE PTR [bp+di+0x43ff],bl
    115e:	03 54 18             	add    dx,WORD PTR [si+0x18]
    1161:	9a ff 98 03 ff       	call   0xff03:0x98ff
    1166:	ff 9c ff 27          	call   DWORD PTR [si+0x27ff]
    116a:	00 01                	add    BYTE PTR [bx+di],al
    116c:	00 00                	add    BYTE PTR [bx+si],al
    116e:	01 00                	add    WORD PTR [bx+si],ax
    1170:	01 00                	add    WORD PTR [bx+si],ax
    1172:	10 09                	adc    BYTE PTR [bx+di],cl
    1174:	00 01                	add    BYTE PTR [bx+di],al
    1176:	00 00                	add    BYTE PTR [bx+si],al
    1178:	01 00                	add    WORD PTR [bx+si],ax
    117a:	01 00                	add    WORD PTR [bx+si],ax
    117c:	02 0d                	add    cl,BYTE PTR [di]
    117e:	00 01                	add    BYTE PTR [bx+di],al
    1180:	00 00                	add    BYTE PTR [bx+si],al
    1182:	01 00                	add    WORD PTR [bx+si],ax
    1184:	55                   	push   bp
    1185:	00 04                	add    BYTE PTR [si],al
    1187:	00 20                	add    BYTE PTR [bx+si],ah
    1189:	02 00                	add    al,BYTE PTR [bx+si]
    118b:	00 00                	add    BYTE PTR [bx+si],al
    118d:	00 00                	add    BYTE PTR [bx+si],al
    118f:	52                   	push   dx
    1190:	75 6e                	jne    0x1200
    1192:	74 69                	je     0x11fd
    1194:	6d                   	ins    WORD PTR es:[di],dx
    1195:	65 20 65 72          	and    BYTE PTR gs:[di+0x72],ah
    1199:	72 6f                	jb     0x120a
    119b:	72 20                	jb     0x11bd
    119d:	30 30                	xor    BYTE PTR [bx+si],dh
    119f:	30 20                	xor    BYTE PTR [bx+si],ah
    11a1:	61                   	popa
    11a2:	74 20                	je     0x11c4
    11a4:	30 30                	xor    BYTE PTR [bx+si],dh
    11a6:	30 30                	xor    BYTE PTR [bx+si],dh
    11a8:	3a 30                	cmp    dh,BYTE PTR [bx+si]
    11aa:	30 30                	xor    BYTE PTR [bx+si],dh
    11ac:	30 2e 00 00          	xor    BYTE PTR ds:0x0,ch
    11b0:	01 00                	add    WORD PTR [bx+si],ax
    11b2:	00 04                	add    BYTE PTR [si],al
    11b4:	00 00                	add    BYTE PTR [bx+si],al
    11b6:	07                   	pop    es
    11b7:	00 00                	add    BYTE PTR [bx+si],al
    11b9:	0a 00                	or     al,BYTE PTR [bx+si]
    11bb:	00 0d                	add    BYTE PTR [di],cl
    11bd:	00 00                	add    BYTE PTR [bx+si],al
    11bf:	00 00                	add    BYTE PTR [bx+si],al
    11c1:	70 3f                	jo     0x1202
    11c3:	00 00                	add    BYTE PTR [bx+si],al
    11c5:	88 3f                	mov    BYTE PTR [bx],bh
    11c7:	00 00                	add    BYTE PTR [bx+si],al
    11c9:	00 5f 00             	add    BYTE PTR [bx+0x0],bl
    11cc:	00 00                	add    BYTE PTR [bx+si],al
    11ce:	c0 7e 01 50          	sar    BYTE PTR [bp+0x1],0x50
    11d2:	41                   	inc    cx
    11d3:	00 00                	add    BYTE PTR [bx+si],al
    11d5:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    11d9:	47                   	inc    di
    11da:	41                   	inc    cx
    11db:	06                   	push   es
    11dc:	00 01                	add    BYTE PTR [bx+di],al
    11de:	00 00                	add    BYTE PTR [bx+si],al
    11e0:	01 00                	add    WORD PTR [bx+si],ax
    11e2:	04 00                	add    al,0x0
    11e4:	f0 3f                	lock aas
    11e6:	0d                   	.byte 0xd
    11e7:	0a                   	.byte 0xa
