; ================================================================
; seg32_CODE  (39889 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	20 00                	and    BYTE PTR [bx+si],al
	...
       a:	22 00                	and    al,BYTE PTR [bx+si]
       c:	0c 00                	or     al,0x0
       e:	2e 00 32             	add    BYTE PTR cs:[bp+si],dh
      11:	0f 64 20             	pcmpgtb mm4,QWORD PTR [bx+si]
      14:	52                   	push   dx
      15:	00 9a 1f 14          	add    BYTE PTR [bp+si+0x141f],bl
      19:	00 cb                	add    bl,cl
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	c4 29                	les    bp,DWORD PTR [bx+di]
      20:	10 00                	adc    BYTE PTR [bx+si],al
      22:	15 45 49             	adc    ax,0x4945
      25:	6e                   	outs   dx,BYTE PTR ds:[si]
      26:	76 61                	jbe    0x89
      28:	6c                   	ins    BYTE PTR es:[di],dx
      29:	69 64 47 72 69       	imul   sp,WORD PTR [si+0x47],0x6972
      2e:	64 4f                	fs dec di
      30:	70 65                	jo     0x97
      32:	72 61                	jb     0x95
      34:	74 69                	je     0x9f
      36:	6f                   	outs   dx,WORD PTR ds:[si]
      37:	6e                   	outs   dx,BYTE PTR ds:[si]
      38:	0f 01 00             	sgdtw  [bx+si]
      3b:	00 00                	add    BYTE PTR [bx+si],al
      3d:	00 e9                	add    cl,ch
      3f:	00 dc                	add    ah,bl
      41:	00 05                	add    BYTE PTR [di],al
      43:	01 4f 00             	add    WORD PTR [bx+0x0],cx
      46:	23 01                	and    ax,WORD PTR [bx+di]
      48:	fa                   	cli
      49:	45                   	inc    bp
      4a:	be 00 9a             	mov    si,0x9a00
      4d:	1f                   	pop    ds
      4e:	7d 03                	jge    0x53
      50:	cb                   	retf
      51:	1f                   	pop    ds
      52:	4e                   	dec    si
      53:	00 c8                	add    al,cl
      55:	11 46 00             	adc    WORD PTR [bp+0x0],ax
      58:	cd 11                	int    0x11
      5a:	62 00                	bound  ax,DWORD PTR [bx+si]
      5c:	3a 27                	cmp    ah,BYTE PTR [bx]
      5e:	66 00 fa             	data32 add dl,bh
      61:	10 05                	adc    BYTE PTR [di],al
      63:	03 d6                	add    dx,si
      65:	14 6e                	adc    al,0x6e
      67:	00 f4                	add    ah,dh
      69:	4f                   	dec    di
      6a:	7a 00                	jp     0x6c
      6c:	32 16 96 00          	xor    dl,BYTE PTR ds:0x96
      70:	ec                   	in     al,dx
      71:	30 ce                	xor    dh,cl
      73:	00 51 1b             	add    BYTE PTR [bx+di+0x1b],dl
      76:	65 03 38             	add    di,WORD PTR gs:[bx+si]
      79:	50                   	push   ax
      7a:	82 00 63             	add    BYTE PTR [bx+si],0x63
      7d:	31 9e 00 21          	xor    WORD PTR [bp+0x2100],bx
      81:	50                   	push   ax
      82:	5a                   	pop    dx
      83:	00 5a 11             	add    BYTE PTR [bp+si+0x11],bl
      86:	56                   	push   si
      87:	00 d9                	add    cl,bl
      89:	62 8e 00 06          	bound  cx,DWORD PTR [bp+0x600]
      8d:	63 92 00 8f          	arpl   WORD PTR [bp+si-0x7100],dx
      91:	60                   	pusha
      92:	ca 00 3a             	retf   0x3a00
      95:	1c 76                	sbb    al,0x76
      97:	00 60 1b             	add    BYTE PTR [bx+si+0x1b],ah
      9a:	f9                   	stc
      9b:	00 08                	add    BYTE PTR [bx+si],cl
      9d:	61                   	popa
      9e:	a2 00 5c             	mov    ds:0x5c00,al
      a1:	61                   	popa
      a2:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
      a3:	00 62 5c             	add    BYTE PTR [bp+si+0x5c],ah
      a6:	d2 00                	rol    BYTE PTR [bx+si],cl
      a8:	3a 61 5e             	cmp    ah,BYTE PTR [bx+di+0x5e]
      ab:	00 72 3f             	add    BYTE PTR [bp+si+0x3f],dh
      ae:	b6 00                	mov    dh,0x0
      b0:	80 16 d6 00 17       	adc    BYTE PTR ds:0xd6,0x17
      b5:	3e 4a                	ds dec dx
      b7:	00 62 4b             	add    BYTE PTR [bp+si+0x4b],ah
      ba:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
      bb:	09 ed                	or     bp,bp
      bd:	3e c2 00 77          	ds ret 0x7700
      c1:	3e c6 00 c2          	mov    BYTE PTR ds:[bx+si],0xc2
      c5:	35 8a 00             	xor    ax,0x8a
      c8:	1c 48                	sbb    al,0x48
      ca:	72 00                	jb     0xcc
      cc:	ae                   	scas   al,BYTE PTR es:[di]
      cd:	5f                   	pop    di
      ce:	7e 00                	jle    0xd0
      d0:	35 62 aa             	xor    ax,0xaa62
      d3:	00 2b                	add    BYTE PTR [bp+di],ch
      d5:	17                   	pop    ss
      d6:	9a 00 b0 1c 86       	call   0x861c:0xb000
      db:	00 0c                	add    BYTE PTR [si],cl
      dd:	54                   	push   sp
      de:	49                   	dec    cx
      df:	6e                   	outs   dx,BYTE PTR ds:[si]
      e0:	70 6c                	jo     0x14e
      e2:	61                   	popa
      e3:	63 65 45             	arpl   WORD PTR [di+0x45],sp
      e6:	64 69 74 06 00 19    	imul   si,WORD PTR fs:[si+0x6],0x1900
      ec:	0f 87 00 fd          	ja     0xfdf0
      f0:	ff f1                	push   cx
      f2:	ff                   	jmp    (bad)
      f3:	ef                   	out    dx,ax
      f4:	ff f0                	push   ax
      f6:	ff ca                	dec    dx
      f8:	16                   	push   ss
      f9:	fd                   	std
      fa:	00 d1                	add    cl,dl
      fc:	16                   	push   ss
      fd:	01 01                	add    WORD PTR [bx+di],ax
      ff:	12 17                	adc    dl,BYTE PTR [bx]
     101:	05 01 d0             	add    ax,0xd001
     104:	18 09                	sbb    BYTE PTR [bx+di],cl
     106:	01 38                	add    WORD PTR [bx+si],di
     108:	1a 0d                	sbb    cl,BYTE PTR [di]
     10a:	01 3e 1b 1f          	add    WORD PTR ds:0x1f1b,di
     10e:	01 07                	add    WORD PTR [bx],ax
     110:	0c 54                	or     al,0x54
     112:	49                   	dec    cx
     113:	6e                   	outs   dx,BYTE PTR ds:[si]
     114:	70 6c                	jo     0x182
     116:	61                   	popa
     117:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     11a:	64 69 74 58 00 47    	imul   si,WORD PTR fs:[si+0x58],0x4700
     120:	01 2d                	add    WORD PTR [di],bp
     122:	01 37                	add    WORD PTR [bx],si
     124:	16                   	push   ss
     125:	0a 00                	or     al,BYTE PTR [bx+si]
     127:	05 47 72             	add    ax,0x7247
     12a:	69 64 73 00 00       	imul   sp,WORD PTR [si+0x73],0x0
     12f:	03 0b                	add    cx,WORD PTR [bp+di]
     131:	54                   	push   sp
     132:	47                   	inc    di
     133:	72 69                	jb     0x19e
     135:	64 4f                	fs dec di
     137:	70 74                	jo     0x1ad
     139:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
     13e:	00 00                	add    BYTE PTR [bx+si],al
     140:	00 0e 00 00          	add    BYTE PTR ds:0x0,cl
     144:	00 2f                	add    BYTE PTR [bx],ch
     146:	01 22                	add    WORD PTR [bp+si],sp
     148:	02 0f                	add    cl,BYTE PTR [bx]
     14a:	67 6f                	outs   dx,WORD PTR ds:[esi]
     14c:	46                   	inc    si
     14d:	69 78 65 64 56       	imul   di,WORD PTR [bx+si+0x65],0x5664
     152:	65 72 74             	gs jb  0x1c9
     155:	4c                   	dec    sp
     156:	69 6e 65 0f 67       	imul   bp,WORD PTR [bp+0x65],0x670f
     15b:	6f                   	outs   dx,WORD PTR ds:[si]
     15c:	46                   	inc    si
     15d:	69 78 65 64 48       	imul   di,WORD PTR [bx+si+0x65],0x4864
     162:	6f                   	outs   dx,WORD PTR ds:[si]
     163:	72 7a                	jb     0x1df
     165:	4c                   	dec    sp
     166:	69 6e 65 0a 67       	imul   bp,WORD PTR [bp+0x65],0x670a
     16b:	6f                   	outs   dx,WORD PTR ds:[si]
     16c:	56                   	push   si
     16d:	65 72 74             	gs jb  0x1e4
     170:	4c                   	dec    sp
     171:	69 6e 65 0a 67       	imul   bp,WORD PTR [bp+0x65],0x670a
     176:	6f                   	outs   dx,WORD PTR ds:[si]
     177:	48                   	dec    ax
     178:	6f                   	outs   dx,WORD PTR ds:[si]
     179:	72 7a                	jb     0x1f5
     17b:	4c                   	dec    sp
     17c:	69 6e 65 0d 67       	imul   bp,WORD PTR [bp+0x65],0x670d
     181:	6f                   	outs   dx,WORD PTR ds:[si]
     182:	52                   	push   dx
     183:	61                   	popa
     184:	6e                   	outs   dx,BYTE PTR ds:[si]
     185:	67 65 53             	addr32 gs push bx
     188:	65 6c                	gs ins BYTE PTR es:[di],dx
     18a:	65 63 74 13          	arpl   WORD PTR gs:[si+0x13],si
     18e:	67 6f                	outs   dx,WORD PTR ds:[esi]
     190:	44                   	inc    sp
     191:	72 61                	jb     0x1f4
     193:	77 46                	ja     0x1db
     195:	6f                   	outs   dx,WORD PTR ds:[si]
     196:	63 75 73             	arpl   WORD PTR [di+0x73],si
     199:	53                   	push   bx
     19a:	65 6c                	gs ins BYTE PTR es:[di],dx
     19c:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     1a0:	64 0b 67 6f          	or     sp,WORD PTR fs:[bx+0x6f]
     1a4:	52                   	push   dx
     1a5:	6f                   	outs   dx,WORD PTR ds:[si]
     1a6:	77 53                	ja     0x1fb
     1a8:	69 7a 69 6e 67       	imul   di,WORD PTR [bp+si+0x69],0x676e
     1ad:	0b 67 6f             	or     sp,WORD PTR [bx+0x6f]
     1b0:	43                   	inc    bx
     1b1:	6f                   	outs   dx,WORD PTR ds:[si]
     1b2:	6c                   	ins    BYTE PTR es:[di],dx
     1b3:	53                   	push   bx
     1b4:	69 7a 69 6e 67       	imul   di,WORD PTR [bp+si+0x69],0x676e
     1b9:	0b 67 6f             	or     sp,WORD PTR [bx+0x6f]
     1bc:	52                   	push   dx
     1bd:	6f                   	outs   dx,WORD PTR ds:[si]
     1be:	77 4d                	ja     0x20d
     1c0:	6f                   	outs   dx,WORD PTR ds:[si]
     1c1:	76 69                	jbe    0x22c
     1c3:	6e                   	outs   dx,BYTE PTR ds:[si]
     1c4:	67 0b 67 6f          	or     sp,WORD PTR [edi+0x6f]
     1c8:	43                   	inc    bx
     1c9:	6f                   	outs   dx,WORD PTR ds:[si]
     1ca:	6c                   	ins    BYTE PTR es:[di],dx
     1cb:	4d                   	dec    bp
     1cc:	6f                   	outs   dx,WORD PTR ds:[si]
     1cd:	76 69                	jbe    0x238
     1cf:	6e                   	outs   dx,BYTE PTR ds:[si]
     1d0:	67 09 67 6f          	or     WORD PTR [edi+0x6f],sp
     1d4:	45                   	inc    bp
     1d5:	64 69 74 69 6e 67    	imul   si,WORD PTR fs:[si+0x69],0x676e
     1db:	06                   	push   es
     1dc:	67 6f                	outs   dx,WORD PTR ds:[esi]
     1de:	54                   	push   sp
     1df:	61                   	popa
     1e0:	62 73 0b             	bound  si,DWORD PTR [bp+di+0xb]
     1e3:	67 6f                	outs   dx,WORD PTR ds:[esi]
     1e5:	52                   	push   dx
     1e6:	6f                   	outs   dx,WORD PTR ds:[si]
     1e7:	77 53                	ja     0x23c
     1e9:	65 6c                	gs ins BYTE PTR es:[di],dx
     1eb:	65 63 74 12          	arpl   WORD PTR gs:[si+0x12],si
     1ef:	67 6f                	outs   dx,WORD PTR ds:[esi]
     1f1:	41                   	inc    cx
     1f2:	6c                   	ins    BYTE PTR es:[di],dx
     1f3:	77 61                	ja     0x256
     1f5:	79 73                	jns    0x26a
     1f7:	53                   	push   bx
     1f8:	68 6f 77             	push   0x776f
     1fb:	45                   	inc    bp
     1fc:	64 69 74 6f 72 0f    	imul   si,WORD PTR fs:[si+0x6f],0xf72
     202:	67 6f                	outs   dx,WORD PTR ds:[esi]
     204:	54                   	push   sp
     205:	68 75 6d             	push   0x6d75
     208:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
     20b:	61                   	popa
     20c:	63 6b 69             	arpl   WORD PTR [bp+di+0x69],bp
     20f:	6e                   	outs   dx,BYTE PTR ds:[si]
     210:	67 06                	addr32 push es
     212:	0c 54                	or     al,0x54
     214:	47                   	inc    di
     215:	72 69                	jb     0x280
     217:	64 4f                	fs dec di
     219:	70 74                	jo     0x28f
     21b:	69 6f 6e 73 03       	imul   bp,WORD PTR [bx+0x6e],0x373
     220:	2f                   	das
     221:	01 75 03             	add    WORD PTR [di+0x3],si
     224:	08 10                	or     BYTE PTR [bx+si],dl
     226:	54                   	push   sp
     227:	53                   	push   bx
     228:	65 6c                	gs ins BYTE PTR es:[di],dx
     22a:	65 63 74 43          	arpl   WORD PTR gs:[si+0x43],si
     22e:	65 6c                	gs ins BYTE PTR es:[di],dx
     230:	6c                   	ins    BYTE PTR es:[di],dx
     231:	45                   	inc    bp
     232:	76 65                	jbe    0x299
     234:	6e                   	outs   dx,BYTE PTR ds:[si]
     235:	74 00                	je     0x237
     237:	04 00                	add    al,0x0
     239:	06                   	push   es
     23a:	53                   	push   bx
     23b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     23d:	64 65 72 07          	fs gs jb 0x248
     241:	54                   	push   sp
     242:	4f                   	dec    di
     243:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     246:	63 74 00             	arpl   WORD PTR [si+0x0],si
     249:	03 43 6f             	add    ax,WORD PTR [bp+di+0x6f]
     24c:	6c                   	ins    BYTE PTR es:[di],dx
     24d:	07                   	pop    es
     24e:	4c                   	dec    sp
     24f:	6f                   	outs   dx,WORD PTR ds:[si]
     250:	6e                   	outs   dx,BYTE PTR ds:[si]
     251:	67 69 6e 74 00 03    	imul   bp,WORD PTR [esi+0x74],0x300
     257:	52                   	push   dx
     258:	6f                   	outs   dx,WORD PTR ds:[si]
     259:	77 07                	ja     0x262
     25b:	4c                   	dec    sp
     25c:	6f                   	outs   dx,WORD PTR ds:[si]
     25d:	6e                   	outs   dx,BYTE PTR ds:[si]
     25e:	67 69 6e 74 01 09    	imul   bp,WORD PTR [esi+0x74],0x901
     264:	43                   	inc    bx
     265:	61                   	popa
     266:	6e                   	outs   dx,BYTE PTR ds:[si]
     267:	53                   	push   bx
     268:	65 6c                	gs ins BYTE PTR es:[di],dx
     26a:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
     26e:	42                   	inc    dx
     26f:	6f                   	outs   dx,WORD PTR ds:[si]
     270:	6f                   	outs   dx,WORD PTR ds:[si]
     271:	6c                   	ins    BYTE PTR es:[di],dx
     272:	65 61                	gs popa
     274:	6e                   	outs   dx,BYTE PTR ds:[si]
     275:	08 0e 54 44          	or     BYTE PTR ds:0x4454,cl
     279:	72 61                	jb     0x2dc
     27b:	77 43                	ja     0x2c0
     27d:	65 6c                	gs ins BYTE PTR es:[di],dx
     27f:	6c                   	ins    BYTE PTR es:[di],dx
     280:	45                   	inc    bp
     281:	76 65                	jbe    0x2e8
     283:	6e                   	outs   dx,BYTE PTR ds:[si]
     284:	74 00                	je     0x286
     286:	05 00 06             	add    ax,0x600
     289:	53                   	push   bx
     28a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     28c:	64 65 72 07          	fs gs jb 0x297
     290:	54                   	push   sp
     291:	4f                   	dec    di
     292:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     295:	63 74 00             	arpl   WORD PTR [si+0x0],si
     298:	03 43 6f             	add    ax,WORD PTR [bp+di+0x6f]
     29b:	6c                   	ins    BYTE PTR es:[di],dx
     29c:	07                   	pop    es
     29d:	4c                   	dec    sp
     29e:	6f                   	outs   dx,WORD PTR ds:[si]
     29f:	6e                   	outs   dx,BYTE PTR ds:[si]
     2a0:	67 69 6e 74 00 03    	imul   bp,WORD PTR [esi+0x74],0x300
     2a6:	52                   	push   dx
     2a7:	6f                   	outs   dx,WORD PTR ds:[si]
     2a8:	77 07                	ja     0x2b1
     2aa:	4c                   	dec    sp
     2ab:	6f                   	outs   dx,WORD PTR ds:[si]
     2ac:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ad:	67 69 6e 74 00 04    	imul   bp,WORD PTR [esi+0x74],0x400
     2b3:	52                   	push   dx
     2b4:	65 63 74 05          	arpl   WORD PTR gs:[si+0x5],si
     2b8:	54                   	push   sp
     2b9:	52                   	push   dx
     2ba:	65 63 74 00          	arpl   WORD PTR gs:[si+0x0],si
     2be:	05 53 74             	add    ax,0x7453
     2c1:	61                   	popa
     2c2:	74 65                	je     0x329
     2c4:	0e                   	push   cs
     2c5:	54                   	push   sp
     2c6:	47                   	inc    di
     2c7:	72 69                	jb     0x332
     2c9:	64 44                	fs inc sp
     2cb:	72 61                	jb     0x32e
     2cd:	77 53                	ja     0x322
     2cf:	74 61                	je     0x332
     2d1:	74 65                	je     0x338
     2d3:	6f                   	outs   dx,WORD PTR ds:[si]
     2d4:	04 00                	add    al,0x0
     2d6:	00 00                	add    BYTE PTR [bx+si],al
     2d8:	00 8f 03 83          	add    BYTE PTR [bx-0x7cfd],cl
     2dc:	03 41 01             	add    ax,WORD PTR [bx+di+0x1]
     2df:	f3 08 82 04 fa       	repz or BYTE PTR [bp+si-0x5fc],al
     2e4:	45                   	inc    bp
     2e5:	59                   	pop    cx
     2e6:	03 9a 1f 90          	add    bx,WORD PTR [bp+si-0x6fe1]
     2ea:	04 cb                	add    al,0xcb
     2ec:	1f                   	pop    ds
     2ed:	e9 02 a0             	jmp    0xa2f2
     2f0:	1f                   	pop    ds
     2f1:	dd 03                	fld    QWORD PTR [bp+di]
     2f3:	cd 11                	int    0x11
     2f5:	fd                   	std
     2f6:	02 8d 27 81          	add    cl,BYTE PTR [di-0x7ed9]
     2fa:	03 fa                	add    di,dx
     2fc:	10 bd 05 d6          	adc    BYTE PTR [di-0x29fb],bh
     300:	14 09                	adc    al,0x9
     302:	03 f4                	add    si,sp
     304:	4f                   	dec    di
     305:	15 03 32             	adc    ax,0x3203
     308:	16                   	push   ss
     309:	31 03                	xor    WORD PTR [bp+di],ax
     30b:	ec                   	in     al,dx
     30c:	30 69 03             	xor    BYTE PTR [bx+di+0x3],ch
     30f:	51                   	push   cx
     310:	1b e1                	sbb    sp,cx
     312:	02 38                	add    bh,BYTE PTR [bx+si]
     314:	50                   	push   ax
     315:	1d 03 63             	sbb    ax,0x6303
     318:	31 39                	xor    WORD PTR [bx+di],di
     31a:	03 21                	add    sp,WORD PTR [bx+di]
     31c:	50                   	push   ax
     31d:	f5                   	cmc
     31e:	02 71 1e             	add    dh,BYTE PTR [bx+di+0x1e]
     321:	f1                   	int1
     322:	02 d9                	add    bl,cl
     324:	62 29                	bound  bp,DWORD PTR [bx+di]
     326:	03 06 63 2d          	add    ax,WORD PTR ds:0x2d63
     32a:	03 8f 60 0d          	add    cx,WORD PTR [bx+0xd60]
     32e:	03 3a                	add    di,WORD PTR [bp+si]
     330:	1c 11                	sbb    al,0x11
     332:	03 46 44             	add    ax,WORD PTR [bp+0x44]
     335:	19 03                	sbb    WORD PTR [bp+di],ax
     337:	08 61 3d             	or     BYTE PTR [bx+di+0x3d],ah
     33a:	03 5c 61             	add    bx,WORD PTR [si+0x61]
     33d:	41                   	inc    cx
     33e:	03 62 5c             	add    sp,WORD PTR [bp+si+0x5c]
     341:	6d                   	ins    WORD PTR es:[di],dx
     342:	03 3a                	add    di,WORD PTR [bp+si]
     344:	61                   	popa
     345:	01 03                	add    WORD PTR [bp+di],ax
     347:	72 3f                	jb     0x388
     349:	51                   	push   cx
     34a:	03 dc                	add    bx,sp
     34c:	5c                   	pop    sp
     34d:	79 03                	jns    0x352
     34f:	17                   	pop    ss
     350:	3e 55                	ds push bp
     352:	03 88 3c e5          	add    cx,WORD PTR [bx+si-0x1ac4]
     356:	02 ed                	add    ch,ch
     358:	3e 5d                	ds pop bp
     35a:	03 77 3e             	add    si,WORD PTR [bx+0x3e]
     35d:	61                   	popa
     35e:	03 c2                	add    ax,dx
     360:	35 25 03             	xor    ax,0x325
     363:	26 6d                	es ins WORD PTR es:[di],dx
     365:	49                   	dec    cx
     366:	03 ae 5f 35          	add    bp,WORD PTR [bp+0x355f]
     36a:	03 35                	add    si,WORD PTR [di]
     36c:	62 45 03             	bound  ax,DWORD PTR [di+0x3]
     36f:	ec                   	in     al,dx
     370:	2e 21 03             	and    WORD PTR cs:[bp+di],ax
     373:	b2 5c                	mov    dl,0x5c
     375:	4d                   	dec    bp
     376:	03 93 24 f9          	add    dx,WORD PTR [bp+di-0x6dc]
     37a:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     37d:	ed                   	in     ax,dx
     37e:	02 81 28 71          	add    al,BYTE PTR [bx+di+0x7128]
     382:	03 0b                	add    cx,WORD PTR [bp+di]
     384:	54                   	push   sp
     385:	43                   	inc    bx
     386:	75 73                	jne    0x3fb
     388:	74 6f                	je     0x3f9
     38a:	6d                   	ins    WORD PTR es:[di],dx
     38b:	47                   	inc    di
     38c:	72 69                	jb     0x3f7
     38e:	64 25 00 0e          	fs and ax,0xe00
     392:	0f 10 0f             	movups xmm1,XMMWORD PTR [bx]
     395:	1c 0f                	sbb    al,0xf
     397:	1e                   	push   ds
     398:	0f 02 01             	lar    ax,WORD PTR [bx+di]
     39b:	01 02                	add    WORD PTR [bp+si],ax
     39d:	87 00                	xchg   WORD PTR [bx+si],ax
     39f:	14 01                	adc    al,0x1
     3a1:	08 00                	or     BYTE PTR [bx+si],al
     3a3:	84 00                	test   BYTE PTR [bx+si],al
     3a5:	20 00                	and    BYTE PTR [bx+si],al
     3a7:	07                   	pop    es
     3a8:	00 05                	add    BYTE PTR [di],al
     3aa:	00 13                	add    BYTE PTR [bp+di],dl
     3ac:	01 15                	add    WORD PTR [di],dx
     3ae:	01 11                	add    WORD PTR [bx+di],dx
     3b0:	01 f1                	add    cx,si
     3b2:	ff                   	jmp    (bad)
     3b3:	ef                   	out    dx,ax
     3b4:	ff                   	(bad)
     3b5:	fa                   	cli
     3b6:	ff                   	(bad)
     3b7:	f9                   	stc
     3b8:	ff                   	(bad)
     3b9:	f8                   	clc
     3ba:	ff                   	jmp    (bad)
     3bb:	ee                   	out    dx,al
     3bc:	ff f2                	push   dx
     3be:	ff                   	jmp    (bad)
     3bf:	ed                   	in     ax,dx
     3c0:	ff                   	jmp    (bad)
     3c1:	ec                   	in     al,dx
     3c2:	ff                   	jmp    (bad)
     3c3:	eb ff                	jmp    0x3c4
     3c5:	ea ff e9 ff e8       	jmp    0xe8ff:0xe9ff
     3ca:	ff e7                	jmp    di
     3cc:	ff e6                	jmp    si
     3ce:	ff e5                	jmp    bp
     3d0:	ff e4                	jmp    sp
     3d2:	ff e3                	jmp    bx
     3d4:	ff e2                	jmp    dx
     3d6:	ff e1                	jmp    cx
     3d8:	ff e0                	jmp    ax
     3da:	ff 8d 7c e1          	dec    WORD PTR [di-0x1e84]
     3de:	03 c7                	add    ax,di
     3e0:	7c e5                	jl     0x3c7
     3e2:	03 ea                	add    bp,dx
     3e4:	7c e9                	jl     0x3cf
     3e6:	03 13                	add    dx,WORD PTR [bp+di]
     3e8:	7d ed                	jge    0x3d7
     3ea:	03 2a                	add    bp,WORD PTR [bp+si]
     3ec:	79 f1                	jns    0x3df
     3ee:	03 6f 79             	add    bp,WORD PTR [bx+0x79]
     3f1:	f5                   	cmc
     3f2:	03 ac 79 f9          	add    bp,WORD PTR [si-0x687]
     3f6:	03 6f 7c             	add    bp,WORD PTR [bx+0x7c]
     3f9:	fd                   	std
     3fa:	03 19                	add    bx,WORD PTR [bx+di]
     3fc:	7a 01                	jp     0x3ff
     3fe:	04 7a                	add    al,0x7a
     400:	7a 05                	jp     0x407
     402:	04 aa                	add    al,0xaa
     404:	7a 09                	jp     0x40f
     406:	04 87                	add    al,0x87
     408:	7b 0d                	jnp    0x417
     40a:	04 e8                	add    al,0xe8
     40c:	7b 11                	jnp    0x41f
     40e:	04 6c                	add    al,0x6c
     410:	7e 15                	jle    0x427
     412:	04 51                	add    al,0x51
     414:	7c 19                	jl     0x42f
     416:	04 09                	add    al,0x9
     418:	7c 1d                	jl     0x437
     41a:	04 d1                	add    al,0xd1
     41c:	5e                   	pop    si
     41d:	21 04                	and    WORD PTR [si],ax
     41f:	b6 63                	mov    dh,0x63
     421:	25 04 0f             	and    ax,0xf04
     424:	64 29 04             	sub    WORD PTR fs:[si],ax
     427:	bb 67 2d             	mov    bx,0x2d67
     42a:	04 da                	add    al,0xda
     42c:	6a 31                	push   0x31
     42e:	04 53                	add    al,0x53
     430:	21 35                	and    WORD PTR [di],si
     432:	04 01                	add    al,0x1
     434:	24 39                	and    al,0x39
     436:	04 5f                	add    al,0x5f
     438:	24 3d                	and    al,0x3d
     43a:	04 6e                	add    al,0x6e
     43c:	24 41                	and    al,0x41
     43e:	04 7d                	add    al,0x7d
     440:	24 45                	and    al,0x45
     442:	04 0d                	add    al,0xd
     444:	25 49 04             	and    ax,0x449
     447:	1b 25                	sbb    sp,WORD PTR [di]
     449:	4d                   	dec    bp
     44a:	04 ff                	add    al,0xff
     44c:	24 51                	and    al,0x51
     44e:	04 22                	add    al,0x22
     450:	25 55 04             	and    ax,0x455
     453:	36 28 59 04          	sub    BYTE PTR ss:[bx+di+0x4],bl
     457:	3d 28 5d             	cmp    ax,0x5d28
     45a:	04 90                	add    al,0x90
     45c:	28 61 04             	sub    BYTE PTR [bx+di+0x4],ah
     45f:	f7 28                	imul   WORD PTR [bx+si]
     461:	65 04 4d             	gs add al,0x4d
     464:	7d 69                	jge    0x4cf
     466:	04 ff                	add    al,0xff
     468:	7e 6d                	jle    0x4d7
     46a:	04 1a                	add    al,0x1a
     46c:	7f 7e                	jg     0x4ec
     46e:	04 07                	add    al,0x7
     470:	0b 54 43             	or     dx,WORD PTR [si+0x43]
     473:	75 73                	jne    0x4e8
     475:	74 6f                	je     0x4e6
     477:	6d                   	ins    WORD PTR es:[di],dx
     478:	47                   	inc    di
     479:	72 69                	jb     0x4e4
     47b:	64 f3 02 35          	repz add dh,BYTE PTR fs:[di]
     47f:	06                   	push   es
     480:	8a 09                	mov    cl,BYTE PTR [bx+di]
     482:	98                   	cbw
     483:	04 0a                	add    al,0xa
     485:	00 05                	add    BYTE PTR [di],al
     487:	47                   	inc    di
     488:	72 69                	jb     0x4f3
     48a:	64 73 01             	fs jae 0x48e
     48d:	00 07                	add    BYTE PTR [bx],al
     48f:	23 a5 05 a4          	and    sp,WORD PTR [di-0x5bfb]
     493:	00 ff                	add    bh,bh
     495:	ff 88 64 1d          	dec    WORD PTR [bx+si+0x1d64]
     499:	06                   	push   es
     49a:	01 00                	add    WORD PTR [bx+si],ax
     49c:	00 00                	add    BYTE PTR [bx+si],al
     49e:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     4a2:	00 00                	add    BYTE PTR [bx+si],al
     4a4:	09 00                	or     WORD PTR [bx+si],ax
     4a6:	07                   	pop    es
     4a7:	54                   	push   sp
     4a8:	61                   	popa
     4a9:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     4ac:	6f                   	outs   dx,WORD PTR ds:[si]
     4ad:	70 08                	jo     0x4b7
     4af:	0d 54 47             	or     ax,0x4754
     4b2:	65 74 45             	gs je  0x4fa
     4b5:	64 69 74 45 76 65    	imul   si,WORD PTR fs:[si+0x45],0x6576
     4bb:	6e                   	outs   dx,BYTE PTR ds:[si]
     4bc:	74 00                	je     0x4be
     4be:	04 00                	add    al,0x0
     4c0:	06                   	push   es
     4c1:	53                   	push   bx
     4c2:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4c4:	64 65 72 07          	fs gs jb 0x4cf
     4c8:	54                   	push   sp
     4c9:	4f                   	dec    di
     4ca:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     4cd:	63 74 00             	arpl   WORD PTR [si+0x0],si
     4d0:	04 41                	add    al,0x41
     4d2:	43                   	inc    bx
     4d3:	6f                   	outs   dx,WORD PTR ds:[si]
     4d4:	6c                   	ins    BYTE PTR es:[di],dx
     4d5:	07                   	pop    es
     4d6:	4c                   	dec    sp
     4d7:	6f                   	outs   dx,WORD PTR ds:[si]
     4d8:	6e                   	outs   dx,BYTE PTR ds:[si]
     4d9:	67 69 6e 74 00 04    	imul   bp,WORD PTR [esi+0x74],0x400
     4df:	41                   	inc    cx
     4e0:	52                   	push   dx
     4e1:	6f                   	outs   dx,WORD PTR ds:[si]
     4e2:	77 07                	ja     0x4eb
     4e4:	4c                   	dec    sp
     4e5:	6f                   	outs   dx,WORD PTR ds:[si]
     4e6:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e7:	67 69 6e 74 01 05    	imul   bp,WORD PTR [esi+0x74],0x501
     4ed:	56                   	push   si
     4ee:	61                   	popa
     4ef:	6c                   	ins    BYTE PTR es:[di],dx
     4f0:	75 65                	jne    0x557
     4f2:	0a 4f 70             	or     cl,BYTE PTR [bx+0x70]
     4f5:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4f7:	53                   	push   bx
     4f8:	74 72                	je     0x56c
     4fa:	69 6e 67 08 0d       	imul   bp,WORD PTR [bp+0x67],0xd08
     4ff:	54                   	push   sp
     500:	53                   	push   bx
     501:	65 74 45             	gs je  0x549
     504:	64 69 74 45 76 65    	imul   si,WORD PTR fs:[si+0x45],0x6576
     50a:	6e                   	outs   dx,BYTE PTR ds:[si]
     50b:	74 00                	je     0x50d
     50d:	04 00                	add    al,0x0
     50f:	06                   	push   es
     510:	53                   	push   bx
     511:	65 6e                	outs   dx,BYTE PTR gs:[si]
     513:	64 65 72 07          	fs gs jb 0x51e
     517:	54                   	push   sp
     518:	4f                   	dec    di
     519:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     51c:	63 74 00             	arpl   WORD PTR [si+0x0],si
     51f:	04 41                	add    al,0x41
     521:	43                   	inc    bx
     522:	6f                   	outs   dx,WORD PTR ds:[si]
     523:	6c                   	ins    BYTE PTR es:[di],dx
     524:	07                   	pop    es
     525:	4c                   	dec    sp
     526:	6f                   	outs   dx,WORD PTR ds:[si]
     527:	6e                   	outs   dx,BYTE PTR ds:[si]
     528:	67 69 6e 74 00 04    	imul   bp,WORD PTR [esi+0x74],0x400
     52e:	41                   	inc    cx
     52f:	52                   	push   dx
     530:	6f                   	outs   dx,WORD PTR ds:[si]
     531:	77 07                	ja     0x53a
     533:	4c                   	dec    sp
     534:	6f                   	outs   dx,WORD PTR ds:[si]
     535:	6e                   	outs   dx,BYTE PTR ds:[si]
     536:	67 69 6e 74 02 05    	imul   bp,WORD PTR [esi+0x74],0x502
     53c:	56                   	push   si
     53d:	61                   	popa
     53e:	6c                   	ins    BYTE PTR es:[di],dx
     53f:	75 65                	jne    0x5a6
     541:	06                   	push   es
     542:	53                   	push   bx
     543:	74 72                	je     0x5b7
     545:	69 6e 67 08 0b       	imul   bp,WORD PTR [bp+0x67],0xb08
     54a:	54                   	push   sp
     54b:	4d                   	dec    bp
     54c:	6f                   	outs   dx,WORD PTR ds:[si]
     54d:	76 65                	jbe    0x5b4
     54f:	64 45                	fs inc bp
     551:	76 65                	jbe    0x5b8
     553:	6e                   	outs   dx,BYTE PTR ds:[si]
     554:	74 00                	je     0x556
     556:	03 00                	add    ax,WORD PTR [bx+si]
     558:	06                   	push   es
     559:	53                   	push   bx
     55a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     55c:	64 65 72 07          	fs gs jb 0x567
     560:	54                   	push   sp
     561:	4f                   	dec    di
     562:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     565:	63 74 00             	arpl   WORD PTR [si+0x0],si
     568:	09 46 72             	or     WORD PTR [bp+0x72],ax
     56b:	6f                   	outs   dx,WORD PTR ds:[si]
     56c:	6d                   	ins    WORD PTR es:[di],dx
     56d:	49                   	dec    cx
     56e:	6e                   	outs   dx,BYTE PTR ds:[si]
     56f:	64 65 78 07          	fs gs js 0x57a
     573:	4c                   	dec    sp
     574:	6f                   	outs   dx,WORD PTR ds:[si]
     575:	6e                   	outs   dx,BYTE PTR ds:[si]
     576:	67 69 6e 74 00 07    	imul   bp,WORD PTR [esi+0x74],0x700
     57c:	54                   	push   sp
     57d:	6f                   	outs   dx,WORD PTR ds:[si]
     57e:	49                   	dec    cx
     57f:	6e                   	outs   dx,BYTE PTR ds:[si]
     580:	64 65 78 07          	fs gs js 0x58b
     584:	4c                   	dec    sp
     585:	6f                   	outs   dx,WORD PTR ds:[si]
     586:	6e                   	outs   dx,BYTE PTR ds:[si]
     587:	67 69 6e 74 6b 06    	imul   bp,WORD PTR [esi+0x74],0x66b
     58d:	00 00                	add    BYTE PTR [bx+si],al
     58f:	00 00                	add    BYTE PTR [bx+si],al
     591:	45                   	inc    bp
     592:	06                   	push   es
     593:	3b 06 81 01          	cmp    ax,WORD PTR ds:0x181
     597:	f3 02 55 06          	repz add dl,BYTE PTR [di+0x6]
     59b:	fa                   	cli
     59c:	45                   	inc    bp
     59d:	11 06 9a 1f          	adc    WORD PTR ds:0x1f9a,ax
     5a1:	ea 06 cb 1f a1       	jmp    0xa11f:0xcb06
     5a6:	05 a0 1f             	add    ax,0x1fa0
     5a9:	99                   	cwd
     5aa:	05 cd 11             	add    ax,0x11cd
     5ad:	b5 05                	mov    ch,0x5
     5af:	8d 27                	lea    sp,[bx]
     5b1:	29 06 fa 10          	sub    WORD PTR ds:0x10fa,ax
     5b5:	99                   	cwd
     5b6:	0a d6                	or     dl,dh
     5b8:	14 c1                	adc    al,0xc1
     5ba:	05 f4 4f             	add    ax,0x4ff4
     5bd:	cd 05                	int    0x5
     5bf:	32 16 e9 05          	xor    dl,BYTE PTR ds:0x5e9
     5c3:	ec                   	in     al,dx
     5c4:	30 21                	xor    BYTE PTR [bx+di],ah
     5c6:	06                   	push   es
     5c7:	51                   	push   cx
     5c8:	1b 8a 06 38          	sbb    cx,WORD PTR [bp+si+0x3806]
     5cc:	50                   	push   ax
     5cd:	d5 05                	aad    0x5
     5cf:	63 31                	arpl   WORD PTR [bx+di],si
     5d1:	f1                   	int1
     5d2:	05 21 50             	add    ax,0x5021
     5d5:	ad                   	lods   ax,WORD PTR ds:[si]
     5d6:	05 71 1e             	add    ax,0x1e71
     5d9:	a9 05 d9             	test   ax,0xd905
     5dc:	62 e1 05 06 63 e5    	vpacksswb xmm4{k6},(bad),xmm5
     5e2:	05 8f 60             	add    ax,0x608f
     5e5:	c5 05                	lds    ax,DWORD PTR [di]
     5e7:	3a 1c                	cmp    bl,BYTE PTR [si]
     5e9:	c9                   	leave
     5ea:	05 46 44             	add    ax,0x4446
     5ed:	d1 05                	rol    WORD PTR [di],1
     5ef:	08 61 f5             	or     BYTE PTR [bx+di-0xb],ah
     5f2:	05 5c 61             	add    ax,0x615c
     5f5:	f9                   	stc
     5f6:	05 62 5c             	add    ax,0x5c62
     5f9:	25 06 3a             	and    ax,0x3a06
     5fc:	61                   	popa
     5fd:	b9 05 72             	mov    cx,0x7205
     600:	3f                   	aas
     601:	09 06 dc 5c          	or     WORD PTR ds:0x5cdc,ax
     605:	31 06 17 3e          	xor    WORD PTR ds:0x3e17,ax
     609:	0d 06 88             	or     ax,0x8806
     60c:	3c 9d                	cmp    al,0x9d
     60e:	05 ed 3e             	add    ax,0x3eed
     611:	15 06 77             	adc    ax,0x7706
     614:	3e 19 06 c2 35       	sbb    WORD PTR ds:0x35c2,ax
     619:	dd 05                	fld    QWORD PTR [di]
     61b:	26 6d                	es ins WORD PTR es:[di],dx
     61d:	01 06 ae 5f          	add    WORD PTR ds:0x5fae,ax
     621:	ed                   	in     ax,dx
     622:	05 35 62             	add    ax,0x6235
     625:	fd                   	std
     626:	05 ec 2e             	add    ax,0x2eec
     629:	d9 05                	fld    DWORD PTR [di]
     62b:	b2 5c                	mov    dl,0x5c
     62d:	05 06 93             	add    ax,0x9306
     630:	24 b1                	and    al,0xb1
     632:	05 21 81             	add    ax,0x8121
     635:	39 06 a1 80          	cmp    WORD PTR ds:0x80a1,ax
     639:	2d 06 09             	sub    ax,0x906
     63c:	54                   	push   sp
     63d:	44                   	inc    sp
     63e:	72 61                	jb     0x6a1
     640:	77 47                	ja     0x689
     642:	72 69                	jb     0x6ad
     644:	64 06                	fs push es
     646:	00 e6                	add    dh,ah
     648:	ff                   	jmp    (bad)
     649:	e8 ff ea             	call   0xf14b
     64c:	ff e5                	jmp    bp
     64e:	ff                   	jmp    (bad)
     64f:	e9 ff e3             	jmp    0xea51
     652:	ff ad 7f 59          	jmp    DWORD PTR [di+0x597f]
     656:	06                   	push   es
     657:	e1 7f                	loope  0x6d8
     659:	5d                   	pop    bp
     65a:	06                   	push   es
     65b:	27                   	daa
     65c:	80 61 06 6d          	and    BYTE PTR [bx+di+0x6],0x6d
     660:	80 65 06 e5          	and    BYTE PTR [di+0x6],0xe5
     664:	80 69 06 76          	sub    BYTE PTR [bx+di+0x6],0x76
     668:	81 78 06 07 09       	cmp    WORD PTR [bx+si+0x6],0x907
     66d:	54                   	push   sp
     66e:	44                   	inc    sp
     66f:	72 61                	jb     0x6d2
     671:	77 47                	ja     0x6ba
     673:	72 69                	jb     0x6de
     675:	64 ab                	fs stos WORD PTR es:[di],ax
     677:	05 7c 06             	add    ax,0x67c
     67a:	6f                   	outs   dx,WORD PTR ds:[si]
     67b:	04 b0                	add    al,0xb0
     67d:	06                   	push   es
     67e:	3c 00                	cmp    al,0x0
     680:	05 47 72             	add    ax,0x7247
     683:	69 64 73 33 00       	imul   sp,WORD PTR [si+0x73],0x33
     688:	e2 00                	loop   0x68a
     68a:	92                   	xchg   dx,ax
     68b:	06                   	push   es
     68c:	2d 00 ff             	sub    ax,0xff00
     68f:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     692:	d4 06                	aam    0x6
     694:	01 00                	add    WORD PTR [bx+si],ax
     696:	00 00                	add    BYTE PTR [bx+si],al
     698:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     69c:	00 00                	add    BYTE PTR [bx+si],al
     69e:	0a 00                	or     al,BYTE PTR [bx+si]
     6a0:	05 41 6c             	add    ax,0x6c41
     6a3:	69 67 6e d4 02       	imul   sp,WORD PTR [bx+0x6e],0x2d4
     6a8:	84 1b                	test   BYTE PTR [bp+di],bl
     6aa:	e4 00                	in     al,0x0
     6ac:	ff                   	(bad)
     6ad:	ff                   	(bad)
     6ae:	be 6f f2             	mov    si,0xf26f
     6b1:	06                   	push   es
     6b2:	01 00                	add    WORD PTR [bx+si],ax
     6b4:	00 00                	add    BYTE PTR [bx+si],al
     6b6:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6ba:	00 00                	add    BYTE PTR [bx+si],al
     6bc:	0b 00                	or     ax,WORD PTR [bx+si]
     6be:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
     6c1:	72 64                	jb     0x727
     6c3:	65 72 53             	gs jb  0x719
     6c6:	74 79                	je     0x741
     6c8:	6c                   	ins    BYTE PTR es:[di],dx
     6c9:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
     6cc:	05 08 38             	add    ax,0x3808
     6cf:	00 ff                	add    bh,bh
     6d1:	ff d5                	call   bp
     6d3:	1e                   	push   ds
     6d4:	d8 06 17 1f          	fadd   DWORD PTR ds:0x1f17
     6d8:	13 07                	adc    ax,WORD PTR [bx]
     6da:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     6de:	ff                   	(bad)
     6df:	ff 0c                	dec    WORD PTR [si]
     6e1:	00 05                	add    BYTE PTR [di],al
     6e3:	43                   	inc    bx
     6e4:	6f                   	outs   dx,WORD PTR ds:[si]
     6e5:	6c                   	ins    BYTE PTR es:[di],dx
     6e6:	6f                   	outs   dx,WORD PTR ds:[si]
     6e7:	72 f5                	jb     0x6de
     6e9:	22 0b                	and    cl,BYTE PTR [bp+di]
     6eb:	07                   	pop    es
     6ec:	e6 00                	out    0x0,al
     6ee:	ff                   	(bad)
     6ef:	ff 1b                	call   DWORD PTR [bp+di]
     6f1:	70 31                	jo     0x724
     6f3:	07                   	pop    es
     6f4:	01 00                	add    WORD PTR [bx+si],ax
     6f6:	00 00                	add    BYTE PTR [bx+si],al
     6f8:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     6fc:	00 00                	add    BYTE PTR [bx+si],al
     6fe:	0d 00 08             	or     ax,0x800
     701:	43                   	inc    bx
     702:	6f                   	outs   dx,WORD PTR ds:[si]
     703:	6c                   	ins    BYTE PTR es:[di],dx
     704:	43                   	inc    bx
     705:	6f                   	outs   dx,WORD PTR ds:[si]
     706:	75 6e                	jne    0x776
     708:	74 07                	je     0x711
     70a:	23 29                	and    bp,WORD PTR [bx+di]
     70c:	07                   	pop    es
     70d:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     70e:	00 ff                	add    bh,bh
     710:	ff 22                	jmp    WORD PTR [bp+si]
     712:	63 17                	arpl   WORD PTR [bx],dx
     714:	07                   	pop    es
     715:	54                   	push   sp
     716:	63 a1 07 00          	arpl   WORD PTR [bx+di+0x7],sp
     71a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     71d:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     721:	05 43 74             	add    ax,0x7443
     724:	6c                   	ins    BYTE PTR es:[di],dx
     725:	33 44 d4             	xor    ax,WORD PTR [si-0x2c]
     728:	22 51 07             	and    dl,BYTE PTR [bx+di+0x7]
     72b:	fa                   	cli
     72c:	00 ff                	add    bh,bh
     72e:	ff 72 71             	push   WORD PTR [bp+si+0x71]
     731:	59                   	pop    cx
     732:	07                   	pop    es
     733:	01 00                	add    WORD PTR [bx+si],ax
     735:	00 00                	add    BYTE PTR [bx+si],al
     737:	00 80 40 00          	add    BYTE PTR [bx+si+0x40],al
     73b:	00 00                	add    BYTE PTR [bx+si],al
     73d:	0f 00 0f             	str    WORD PTR [bx]
     740:	44                   	inc    sp
     741:	65 66 61             	gs popad
     744:	75 6c                	jne    0x7b2
     746:	74 43                	je     0x78b
     748:	6f                   	outs   dx,WORD PTR ds:[si]
     749:	6c                   	ins    BYTE PTR es:[di],dx
     74a:	57                   	push   di
     74b:	69 64 74 68 d4       	imul   sp,WORD PTR [si+0x74],0xd468
     750:	22 7a 07             	and    bh,BYTE PTR [bp+si+0x7]
     753:	fc                   	cld
     754:	00 ff                	add    bh,bh
     756:	ff b6 71 0d          	push   WORD PTR [bp+0xd71]
     75a:	08 01                	or     BYTE PTR [bx+di],al
     75c:	00 00                	add    BYTE PTR [bx+si],al
     75e:	00 00                	add    BYTE PTR [bx+si],al
     760:	80 18 00             	sbb    BYTE PTR [bx+si],0x0
     763:	00 00                	add    BYTE PTR [bx+si],al
     765:	10 00                	adc    BYTE PTR [bx+si],al
     767:	10 44 65             	adc    BYTE PTR [si+0x65],al
     76a:	66 61                	popad
     76c:	75 6c                	jne    0x7da
     76e:	74 52                	je     0x7c2
     770:	6f                   	outs   dx,WORD PTR ds:[si]
     771:	77 48                	ja     0x7bb
     773:	65 69 67 68 74 07    	imul   sp,WORD PTR gs:[bx+0x68],0x774
     779:	23 e5                	and    sp,bp
     77b:	07                   	pop    es
     77c:	3b 01                	cmp    ax,WORD PTR [bx+di]
     77e:	ff                   	(bad)
     77f:	ff                   	(bad)
     780:	3b 01                	cmp    ax,WORD PTR [bx+di]
     782:	ff                   	(bad)
     783:	ff 01                	inc    WORD PTR [bx+di]
     785:	00 00                	add    BYTE PTR [bx+si],al
     787:	00 00                	add    BYTE PTR [bx+si],al
     789:	80 01 00             	add    BYTE PTR [bx+di],0x0
     78c:	00 00                	add    BYTE PTR [bx+si],al
     78e:	11 00                	adc    WORD PTR [bx+si],ax
     790:	0e                   	push   cs
     791:	44                   	inc    sp
     792:	65 66 61             	gs popad
     795:	75 6c                	jne    0x803
     797:	74 44                	je     0x7dd
     799:	72 61                	jb     0x7fc
     79b:	77 69                	ja     0x806
     79d:	6e                   	outs   dx,BYTE PTR ds:[si]
     79e:	67 64 00 c4          	addr32 fs add ah,al
     7a2:	07                   	pop    es
     7a3:	3e 00 ff             	ds add bh,bh
     7a6:	ff                   	(bad)
     7a7:	3e 00 ff             	ds add bh,bh
     7aa:	ff 01                	inc    WORD PTR [bx+di]
     7ac:	00 00                	add    BYTE PTR [bx+si],al
     7ae:	00 00                	add    BYTE PTR [bx+si],al
     7b0:	80 f4 ff             	xor    ah,0xff
     7b3:	ff                   	(bad)
     7b4:	ff 12                	call   WORD PTR [bp+si]
     7b6:	00 0a                	add    BYTE PTR [bp+si],cl
     7b8:	44                   	inc    sp
     7b9:	72 61                	jb     0x81c
     7bb:	67 43                	addr32 inc bx
     7bd:	75 72                	jne    0x831
     7bf:	73 6f                	jae    0x830
     7c1:	72 25                	jb     0x7e8
     7c3:	01 ed                	add    bp,bp
     7c5:	07                   	pop    es
     7c6:	2e 00 ff             	cs add bh,bh
     7c9:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     7cd:	ff 01                	inc    WORD PTR [bx+di]
     7cf:	00 00                	add    BYTE PTR [bx+si],al
     7d1:	00 00                	add    BYTE PTR [bx+si],al
     7d3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7d6:	00 00                	add    BYTE PTR [bx+si],al
     7d8:	13 00                	adc    ax,WORD PTR [bx+si]
     7da:	08 44 72             	or     BYTE PTR [si+0x72],al
     7dd:	61                   	popa
     7de:	67 4d                	addr32 dec bp
     7e0:	6f                   	outs   dx,WORD PTR ds:[si]
     7e1:	64 65 07             	fs gs pop es
     7e4:	23 28                	and    bp,WORD PTR [bx+si]
     7e6:	08 2a                	or     BYTE PTR [bp+si],ch
     7e8:	00 ff                	add    bh,bh
     7ea:	ff                   	(bad)
     7eb:	b8 1c 74             	mov    ax,0x741c
     7ee:	08 01                	or     BYTE PTR [bx+di],al
     7f0:	00 00                	add    BYTE PTR [bx+si],al
     7f2:	00 00                	add    BYTE PTR [bx+si],al
     7f4:	80 01 00             	add    BYTE PTR [bx+di],0x0
     7f7:	00 00                	add    BYTE PTR [bx+si],al
     7f9:	14 00                	adc    al,0x0
     7fb:	07                   	pop    es
     7fc:	45                   	inc    bp
     7fd:	6e                   	outs   dx,BYTE PTR ds:[si]
     7fe:	61                   	popa
     7ff:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     802:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     805:	6c                   	ins    BYTE PTR es:[di],dx
     806:	08 02                	or     BYTE PTR [bp+si],al
     808:	01 ff                	add    di,di
     80a:	ff                   	(bad)
     80b:	fa                   	cli
     80c:	71 30                	jno    0x83e
     80e:	08 01                	or     BYTE PTR [bx+di],al
     810:	00 00                	add    BYTE PTR [bx+si],al
     812:	00 00                	add    BYTE PTR [bx+si],al
     814:	80 f0 ff             	xor    al,0xff
     817:	ff                   	(bad)
     818:	ff 15                	call   WORD PTR [di]
     81a:	00 0a                	add    BYTE PTR [bp+si],cl
     81c:	46                   	inc    si
     81d:	69 78 65 64 43       	imul   di,WORD PTR [bx+si+0x65],0x4364
     822:	6f                   	outs   dx,WORD PTR ds:[si]
     823:	6c                   	ins    BYTE PTR es:[di],dx
     824:	6f                   	outs   dx,WORD PTR ds:[si]
     825:	72 d4                	jb     0x7fb
     827:	22 4a 08             	and    cl,BYTE PTR [bp+si+0x8]
     82a:	fe 00                	inc    BYTE PTR [bx+si]
     82c:	ff                   	(bad)
     82d:	ff 32                	push   WORD PTR [bp+si]
     82f:	72 52                	jb     0x883
     831:	08 01                	or     BYTE PTR [bx+di],al
     833:	00 00                	add    BYTE PTR [bx+si],al
     835:	00 00                	add    BYTE PTR [bx+si],al
     837:	80 01 00             	add    BYTE PTR [bx+di],0x0
     83a:	00 00                	add    BYTE PTR [bx+si],al
     83c:	16                   	push   ss
     83d:	00 09                	add    BYTE PTR [bx+di],cl
     83f:	46                   	inc    si
     840:	69 78 65 64 43       	imul   di,WORD PTR [bx+si+0x65],0x4364
     845:	6f                   	outs   dx,WORD PTR ds:[si]
     846:	6c                   	ins    BYTE PTR es:[di],dx
     847:	73 d4                	jae    0x81d
     849:	22 89 08 00          	and    cl,BYTE PTR [bx+di+0x8]
     84d:	01 ff                	add    di,di
     84f:	ff 8b 72 91          	dec    WORD PTR [bp+di-0x6e8e]
     853:	08 01                	or     BYTE PTR [bx+di],al
     855:	00 00                	add    BYTE PTR [bx+si],al
     857:	00 00                	add    BYTE PTR [bx+si],al
     859:	80 01 00             	add    BYTE PTR [bx+di],0x0
     85c:	00 00                	add    BYTE PTR [bx+si],al
     85e:	17                   	pop    ss
     85f:	00 09                	add    BYTE PTR [bx+di],cl
     861:	46                   	inc    si
     862:	69 78 65 64 52       	imul   di,WORD PTR [bx+si+0x65],0x5264
     867:	6f                   	outs   dx,WORD PTR ds:[si]
     868:	77 73                	ja     0x8dd
     86a:	22 03                	and    al,BYTE PTR [bp+di]
     86c:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     86d:	29 34                	sub    WORD PTR [si],si
     86f:	00 ff                	add    bh,bh
     871:	ff                   	jmp    (bad)
     872:	eb 1d                	jmp    0x891
     874:	78 08                	js     0x87e
     876:	08 1e d7 08          	or     BYTE PTR ds:0x8d7,bl
     87a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     87e:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     882:	04 46                	add    al,0x46
     884:	6f                   	outs   dx,WORD PTR ds:[si]
     885:	6e                   	outs   dx,BYTE PTR ds:[si]
     886:	74 d4                	je     0x85c
     888:	22 cf                	and    cl,bh
     88a:	08 06 01 ff          	or     BYTE PTR ds:0xff01,al
     88e:	ff 22                	jmp    WORD PTR [bp+si]
     890:	73 af                	jae    0x841
     892:	08 01                	or     BYTE PTR [bx+di],al
     894:	00 00                	add    BYTE PTR [bx+si],al
     896:	00 00                	add    BYTE PTR [bx+si],al
     898:	80 01 00             	add    BYTE PTR [bx+di],0x0
     89b:	00 00                	add    BYTE PTR [bx+si],al
     89d:	19 00                	sbb    WORD PTR [bx+si],ax
     89f:	0d 47 72             	or     ax,0x7247
     8a2:	69 64 4c 69 6e       	imul   sp,WORD PTR [si+0x4c],0x6e69
     8a7:	65 57                	gs push di
     8a9:	69 64 74 68 11       	imul   sp,WORD PTR [si+0x74],0x1168
     8ae:	02 b7 08 08          	add    dh,BYTE PTR [bx+0x808]
     8b2:	01 ff                	add    di,di
     8b4:	ff                   	(bad)
     8b5:	7d 73                	jge    0x92a
     8b7:	8b 09                	mov    cx,WORD PTR [bx+di]
     8b9:	01 00                	add    WORD PTR [bx+si],ax
     8bb:	00 00                	add    BYTE PTR [bx+si],al
     8bd:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     8c1:	00 00                	add    BYTE PTR [bx+si],al
     8c3:	1a 00                	sbb    al,BYTE PTR [bx+si]
     8c5:	07                   	pop    es
     8c6:	4f                   	dec    di
     8c7:	70 74                	jo     0x93d
     8c9:	69 6f 6e 73 07       	imul   bp,WORD PTR [bx+0x6e],0x773
     8ce:	23 f3                	and    si,bx
     8d0:	08 2c                	or     BYTE PTR [si],ch
     8d2:	00 ff                	add    bh,bh
     8d4:	ff 32                	push   WORD PTR [bp+si]
     8d6:	1f                   	pop    ds
     8d7:	fb                   	sti
     8d8:	08 01                	or     BYTE PTR [bx+di],al
     8da:	00 00                	add    BYTE PTR [bx+si],al
     8dc:	00 00                	add    BYTE PTR [bx+si],al
     8de:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8e1:	00 00                	add    BYTE PTR [bx+si],al
     8e3:	1b 00                	sbb    ax,WORD PTR [bx+si]
     8e5:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     8e8:	72 65                	jb     0x94f
     8ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     8eb:	74 43                	je     0x930
     8ed:	6f                   	outs   dx,WORD PTR ds:[si]
     8ee:	6c                   	ins    BYTE PTR es:[di],dx
     8ef:	6f                   	outs   dx,WORD PTR ds:[si]
     8f0:	72 07                	jb     0x8f9
     8f2:	23 17                	and    dx,WORD PTR [bx]
     8f4:	09 a6 00 ff          	or     WORD PTR [bp-0x100],sp
     8f8:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     8fb:	1f                   	pop    ds
     8fc:	09 01                	or     WORD PTR [bx+di],ax
     8fe:	00 00                	add    BYTE PTR [bx+si],al
     900:	00 00                	add    BYTE PTR [bx+si],al
     902:	80 01 00             	add    BYTE PTR [bx+di],0x0
     905:	00 00                	add    BYTE PTR [bx+si],al
     907:	1c 00                	sbb    al,0x0
     909:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     90c:	72 65                	jb     0x973
     90e:	6e                   	outs   dx,BYTE PTR ds:[si]
     90f:	74 43                	je     0x954
     911:	74 6c                	je     0x97f
     913:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     916:	23 3a                	and    di,WORD PTR [bp+si]
     918:	09 2b                	or     WORD PTR [bp+di],bp
     91a:	00 ff                	add    bh,bh
     91c:	ff                   	(bad)
     91d:	3e 1e                	ds push ds
     91f:	42                   	inc    dx
     920:	09 01                	or     WORD PTR [bx+di],ax
     922:	00 00                	add    BYTE PTR [bx+si],al
     924:	00 00                	add    BYTE PTR [bx+si],al
     926:	80 01 00             	add    BYTE PTR [bx+di],0x0
     929:	00 00                	add    BYTE PTR [bx+si],al
     92b:	1d 00 0a             	sbb    ax,0xa00
     92e:	50                   	push   ax
     92f:	61                   	popa
     930:	72 65                	jb     0x997
     932:	6e                   	outs   dx,BYTE PTR ds:[si]
     933:	74 46                	je     0x97b
     935:	6f                   	outs   dx,WORD PTR ds:[si]
     936:	6e                   	outs   dx,BYTE PTR ds:[si]
     937:	74 07                	je     0x940
     939:	23 83 09 49          	and    ax,WORD PTR [bp+di+0x4909]
     93d:	00 ff                	add    bh,bh
     93f:	ff a1 1e cf          	jmp    WORD PTR [bx+di-0x30e2]
     943:	09 01                	or     WORD PTR [bx+di],ax
     945:	00 00                	add    BYTE PTR [bx+si],al
     947:	00 00                	add    BYTE PTR [bx+si],al
     949:	80 01 00             	add    BYTE PTR [bx+di],0x0
     94c:	00 00                	add    BYTE PTR [bx+si],al
     94e:	1e                   	push   ds
     94f:	00 0e 50 61          	add    BYTE PTR ds:0x6150,cl
     953:	72 65                	jb     0x9ba
     955:	6e                   	outs   dx,BYTE PTR ds:[si]
     956:	74 53                	je     0x9ab
     958:	68 6f 77             	push   0x776f
     95b:	48                   	dec    ax
     95c:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     961:	ff                   	(bad)
     962:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     965:	ff                   	(bad)
     966:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     969:	ff                   	(bad)
     96a:	ff 01                	inc    WORD PTR [bx+di]
     96c:	00 00                	add    BYTE PTR [bx+si],al
     96e:	00 00                	add    BYTE PTR [bx+si],al
     970:	80 00 00             	add    BYTE PTR [bx+si],0x0
     973:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     977:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     97a:	70 75                	jo     0x9f1
     97c:	70 4d                	jo     0x9cb
     97e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     980:	75 f5                	jne    0x977
     982:	22 c7                	and    al,bh
     984:	09 0a                	or     WORD PTR [bp+si],cx
     986:	01 ff                	add    di,di
     988:	ff 26 74 ac          	jmp    WORD PTR ds:0xac74
     98c:	09 01                	or     WORD PTR [bx+di],ax
     98e:	00 00                	add    BYTE PTR [bx+si],al
     990:	00 00                	add    BYTE PTR [bx+si],al
     992:	80 05 00             	add    BYTE PTR [di],0x0
     995:	00 00                	add    BYTE PTR [bx+si],al
     997:	20 00                	and    BYTE PTR [bx+si],al
     999:	08 52 6f             	or     BYTE PTR [bp+si+0x6f],dl
     99c:	77 43                	ja     0x9e1
     99e:	6f                   	outs   dx,WORD PTR ds:[si]
     99f:	75 6e                	jne    0xa0f
     9a1:	74 52                	je     0x9f5
     9a3:	11 67 16             	adc    WORD PTR [bx+0x16],sp
     9a6:	12 01                	adc    al,BYTE PTR [bx+di]
     9a8:	ff                   	(bad)
     9a9:	ff 4c 75             	dec    WORD PTR [si+0x75]
     9ac:	4d                   	dec    bp
     9ad:	0a 01                	or     al,BYTE PTR [bx+di]
     9af:	00 00                	add    BYTE PTR [bx+si],al
     9b1:	00 00                	add    BYTE PTR [bx+si],al
     9b3:	80 03 00             	add    BYTE PTR [bp+di],0x0
     9b6:	00 00                	add    BYTE PTR [bx+si],al
     9b8:	21 00                	and    WORD PTR [bx+si],ax
     9ba:	0a 53 63             	or     dl,BYTE PTR [bp+di+0x63]
     9bd:	72 6f                	jb     0xa2e
     9bf:	6c                   	ins    BYTE PTR es:[di],dx
     9c0:	6c                   	ins    BYTE PTR es:[di],dx
     9c1:	42                   	inc    dx
     9c2:	61                   	popa
     9c3:	72 73                	jb     0xa38
     9c5:	07                   	pop    es
     9c6:	23 09                	and    cx,WORD PTR [bx+di]
     9c8:	0a 48 00             	or     cl,BYTE PTR [bx+si+0x0]
     9cb:	ff                   	(bad)
     9cc:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     9cf:	d3 09                	ror    WORD PTR [bx+di],cl
     9d1:	23 1e e8 09          	and    bx,WORD PTR ds:0x9e8
     9d5:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     9d9:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     9dd:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     9e0:	6f                   	outs   dx,WORD PTR ds:[si]
     9e1:	77 48                	ja     0xa2b
     9e3:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     9e8:	ec                   	in     al,dx
     9e9:	09 a6 63 f0          	or     WORD PTR [bp-0xf9d],sp
     9ed:	09 60 64             	or     WORD PTR [bx+si+0x64],sp
     9f0:	11 0a                	adc    WORD PTR [bp+si],cx
     9f2:	01 00                	add    WORD PTR [bx+si],ax
     9f4:	00 00                	add    BYTE PTR [bx+si],al
     9f6:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     9fa:	ff                   	(bad)
     9fb:	ff 23                	jmp    WORD PTR [bp+di]
     9fd:	00 08                	add    BYTE PTR [bx+si],cl
     9ff:	54                   	push   sp
     a00:	61                   	popa
     a01:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     a04:	64 65 72 07          	fs gs jb 0xa0f
     a08:	23 29                	and    bp,WORD PTR [bx+di]
     a0a:	0a a4 00 ff          	or     ah,BYTE PTR [si-0x100]
     a0e:	ff 88 64 31          	dec    WORD PTR [bx+si+0x3164]
     a12:	0a 01                	or     al,BYTE PTR [bx+di]
     a14:	00 00                	add    BYTE PTR [bx+si],al
     a16:	00 00                	add    BYTE PTR [bx+si],al
     a18:	80 01 00             	add    BYTE PTR [bx+di],0x0
     a1b:	00 00                	add    BYTE PTR [bx+si],al
     a1d:	09 00                	or     WORD PTR [bx+si],ax
     a1f:	07                   	pop    es
     a20:	54                   	push   sp
     a21:	61                   	popa
     a22:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     a25:	6f                   	outs   dx,WORD PTR ds:[si]
     a26:	70 07                	jo     0xa2f
     a28:	23 49 0a             	and    cx,WORD PTR [bx+di+0xa]
     a2b:	29 00                	sub    WORD PTR [bx+si],ax
     a2d:	ff                   	(bad)
     a2e:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     a31:	02 0b                	add    cl,BYTE PTR [bp+di]
     a33:	01 00                	add    WORD PTR [bx+si],ax
     a35:	00 00                	add    BYTE PTR [bx+si],al
     a37:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     a3b:	00 00                	add    BYTE PTR [bx+si],al
     a3d:	24 00                	and    al,0x0
     a3f:	07                   	pop    es
     a40:	56                   	push   si
     a41:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     a46:	65 d4 22             	gs aam 0x22
     a49:	71 0a                	jno    0xa55
     a4b:	52                   	push   dx
     a4c:	6f                   	outs   dx,WORD PTR ds:[si]
     a4d:	75 0a                	jne    0xa59
     a4f:	00 00                	add    BYTE PTR [bx+si],al
     a51:	00 00                	add    BYTE PTR [bx+si],al
     a53:	01 00                	add    WORD PTR [bx+si],ax
     a55:	00 00                	add    BYTE PTR [bx+si],al
     a57:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     a5b:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     a5f:	0f 56 69 73          	orps   xmm5,XMMWORD PTR [bx+di+0x73]
     a63:	69 62 6c 65 43       	imul   sp,WORD PTR [bp+si+0x6c],0x4365
     a68:	6f                   	outs   dx,WORD PTR ds:[si]
     a69:	6c                   	ins    BYTE PTR es:[di],dx
     a6a:	43                   	inc    bx
     a6b:	6f                   	outs   dx,WORD PTR ds:[si]
     a6c:	75 6e                	jne    0xadc
     a6e:	74 d4                	je     0xa44
     a70:	22 d2                	and    dl,dl
     a72:	0d 88 6f             	or     ax,0x6f88
     a75:	b9 0a 00             	mov    cx,0xa
     a78:	00 00                	add    BYTE PTR [bx+si],al
     a7a:	00 01                	add    BYTE PTR [bx+di],al
     a7c:	00 00                	add    BYTE PTR [bx+si],al
     a7e:	00 00                	add    BYTE PTR [bx+si],al
     a80:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a83:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     a87:	0f 56 69 73          	orps   xmm5,XMMWORD PTR [bx+di+0x73]
     a8b:	69 62 6c 65 52       	imul   sp,WORD PTR [bp+si+0x6c],0x5265
     a90:	6f                   	outs   dx,WORD PTR ds:[si]
     a91:	77 43                	ja     0xad6
     a93:	6f                   	outs   dx,WORD PTR ds:[si]
     a94:	75 6e                	jne    0xb04
     a96:	74 71                	je     0xb09
     a98:	00 df                	add    bh,bl
     a9a:	0a 7a 00             	or     bh,BYTE PTR [bp+si+0x0]
     a9d:	ff                   	(bad)
     a9e:	ff                   	(bad)
     a9f:	7a 00                	jp     0xaa1
     aa1:	ff                   	(bad)
     aa2:	ff 01                	inc    WORD PTR [bx+di]
     aa4:	00 00                	add    BYTE PTR [bx+si],al
     aa6:	00 00                	add    BYTE PTR [bx+si],al
     aa8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     aab:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     aaf:	07                   	pop    es
     ab0:	4f                   	dec    di
     ab1:	6e                   	outs   dx,BYTE PTR ds:[si]
     ab2:	43                   	inc    bx
     ab3:	6c                   	ins    BYTE PTR es:[di],dx
     ab4:	69 63 6b 48 05       	imul   sp,WORD PTR [bp+di+0x6b],0x548
     ab9:	48                   	dec    ax
     aba:	0b 41 01             	or     ax,WORD PTR [bx+di+0x1]
     abd:	ff                   	(bad)
     abe:	ff 41 01             	inc    WORD PTR [bx+di+0x1]
     ac1:	ff                   	(bad)
     ac2:	ff 01                	inc    WORD PTR [bx+di]
     ac4:	00 00                	add    BYTE PTR [bx+si],al
     ac6:	00 00                	add    BYTE PTR [bx+si],al
     ac8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     acb:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     acf:	0d 4f 6e             	or     ax,0x6e4f
     ad2:	43                   	inc    bx
     ad3:	6f                   	outs   dx,WORD PTR ds:[si]
     ad4:	6c                   	ins    BYTE PTR es:[di],dx
     ad5:	75 6d                	jne    0xb44
     ad7:	6e                   	outs   dx,BYTE PTR ds:[si]
     ad8:	4d                   	dec    bp
     ad9:	6f                   	outs   dx,WORD PTR ds:[si]
     ada:	76 65                	jbe    0xb41
     adc:	64 71 00             	fs jno 0xadf
     adf:	8d 0b                	lea    cx,[bp+di]
     ae1:	82 00 ff             	add    BYTE PTR [bx+si],0xff
     ae4:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     ae8:	ff 01                	inc    WORD PTR [bx+di]
     aea:	00 00                	add    BYTE PTR [bx+si],al
     aec:	00 00                	add    BYTE PTR [bx+si],al
     aee:	80 00 00             	add    BYTE PTR [bx+si],0x0
     af1:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     af5:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     af8:	44                   	inc    sp
     af9:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     afc:	6c                   	ins    BYTE PTR es:[di],dx
     afd:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     b02:	25 0b 62             	and    ax,0x620b
     b05:	00 ff                	add    bh,bh
     b07:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     b0a:	ff                   	(bad)
     b0b:	ff 01                	inc    WORD PTR [bx+di]
     b0d:	00 00                	add    BYTE PTR [bx+si],al
     b0f:	00 00                	add    BYTE PTR [bx+si],al
     b11:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b14:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     b18:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b1b:	44                   	inc    sp
     b1c:	72 61                	jb     0xb7f
     b1e:	67 44                	addr32 inc sp
     b20:	72 6f                	jb     0xb91
     b22:	70 80                	jo     0xaa4
     b24:	02 6b 0b             	add    ch,BYTE PTR [bp+di+0xb]
     b27:	6a 00                	push   0x0
     b29:	ff                   	(bad)
     b2a:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     b2d:	ff                   	(bad)
     b2e:	ff 01                	inc    WORD PTR [bx+di]
     b30:	00 00                	add    BYTE PTR [bx+si],al
     b32:	00 00                	add    BYTE PTR [bx+si],al
     b34:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b37:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     b3b:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b3e:	44                   	inc    sp
     b3f:	72 61                	jb     0xba2
     b41:	67 4f                	addr32 dec di
     b43:	76 65                	jbe    0xbaa
     b45:	72 75                	jb     0xbbc
     b47:	02 cc                	add    cl,ah
     b49:	0b 49 01             	or     cx,WORD PTR [bx+di+0x1]
     b4c:	ff                   	(bad)
     b4d:	ff 49 01             	dec    WORD PTR [bx+di+0x1]
     b50:	ff                   	(bad)
     b51:	ff 01                	inc    WORD PTR [bx+di]
     b53:	00 00                	add    BYTE PTR [bx+si],al
     b55:	00 00                	add    BYTE PTR [bx+si],al
     b57:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b5a:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
     b5e:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b61:	44                   	inc    sp
     b62:	72 61                	jb     0xbc5
     b64:	77 43                	ja     0xba9
     b66:	65 6c                	gs ins BYTE PTR es:[di],dx
     b68:	6c                   	ins    BYTE PTR es:[di],dx
     b69:	32 03                	xor    al,BYTE PTR [bp+di]
     b6b:	18 0c                	sbb    BYTE PTR [si],cl
     b6d:	72 00                	jb     0xb6f
     b6f:	ff                   	(bad)
     b70:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     b73:	ff                   	(bad)
     b74:	ff 01                	inc    WORD PTR [bx+di]
     b76:	00 00                	add    BYTE PTR [bx+si],al
     b78:	00 00                	add    BYTE PTR [bx+si],al
     b7a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b7d:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
     b81:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     b84:	45                   	inc    bp
     b85:	6e                   	outs   dx,BYTE PTR ds:[si]
     b86:	64 44                	fs inc sp
     b88:	72 61                	jb     0xbeb
     b8a:	67 71 00             	addr32 jno 0xb8d
     b8d:	ad                   	lods   ax,WORD PTR ds:[si]
     b8e:	0b c8                	or     cx,ax
     b90:	00 ff                	add    bh,bh
     b92:	ff c8                	dec    ax
     b94:	00 ff                	add    bh,bh
     b96:	ff 01                	inc    WORD PTR [bx+di]
     b98:	00 00                	add    BYTE PTR [bx+si],al
     b9a:	00 00                	add    BYTE PTR [bx+si],al
     b9c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b9f:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
     ba3:	07                   	pop    es
     ba4:	4f                   	dec    di
     ba5:	6e                   	outs   dx,BYTE PTR ds:[si]
     ba6:	45                   	inc    bp
     ba7:	6e                   	outs   dx,BYTE PTR ds:[si]
     ba8:	74 65                	je     0xc0f
     baa:	72 71                	jb     0xc1d
     bac:	00 55 0d             	add    BYTE PTR [di+0xd],dl
     baf:	d0 00                	rol    BYTE PTR [bx+si],1
     bb1:	ff                   	(bad)
     bb2:	ff d0                	call   ax
     bb4:	00 ff                	add    bh,bh
     bb6:	ff 01                	inc    WORD PTR [bx+di]
     bb8:	00 00                	add    BYTE PTR [bx+si],al
     bba:	00 00                	add    BYTE PTR [bx+si],al
     bbc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bbf:	00 80 2f 00          	add    BYTE PTR [bx+si+0x2f],al
     bc3:	06                   	push   es
     bc4:	4f                   	dec    di
     bc5:	6e                   	outs   dx,BYTE PTR ds:[si]
     bc6:	45                   	inc    bp
     bc7:	78 69                	js     0xc32
     bc9:	74 ae                	je     0xb79
     bcb:	04 f2                	add    al,0xf2
     bcd:	0b 51 01             	or     dx,WORD PTR [bx+di+0x1]
     bd0:	ff                   	(bad)
     bd1:	ff 51 01             	call   WORD PTR [bx+di+0x1]
     bd4:	ff                   	(bad)
     bd5:	ff 01                	inc    WORD PTR [bx+di]
     bd7:	00 00                	add    BYTE PTR [bx+si],al
     bd9:	00 00                	add    BYTE PTR [bx+si],al
     bdb:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bde:	00 80 30 00          	add    BYTE PTR [bx+si+0x30],al
     be2:	0d 4f 6e             	or     ax,0x6e4f
     be5:	47                   	inc    di
     be6:	65 74 45             	gs je  0xc2e
     be9:	64 69 74 4d 61 73    	imul   si,WORD PTR fs:[si+0x4d],0x7361
     bef:	6b ae 04 e7 0c       	imul   bp,WORD PTR [bp-0x18fc],0xc
     bf4:	59                   	pop    cx
     bf5:	01 ff                	add    di,di
     bf7:	ff 59 01             	call   DWORD PTR [bx+di+0x1]
     bfa:	ff                   	(bad)
     bfb:	ff 01                	inc    WORD PTR [bx+di]
     bfd:	00 00                	add    BYTE PTR [bx+si],al
     bff:	00 00                	add    BYTE PTR [bx+si],al
     c01:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c04:	00 80 31 00          	add    BYTE PTR [bx+si+0x31],al
     c08:	0d 4f 6e             	or     ax,0x6e4f
     c0b:	47                   	inc    di
     c0c:	65 74 45             	gs je  0xc54
     c0f:	64 69 74 54 65 78    	imul   si,WORD PTR fs:[si+0x54],0x7865
     c15:	74 1a                	je     0xc31
     c17:	02 3a                	add    bh,BYTE PTR [bp+si]
     c19:	0c b0                	or     al,0xb0
     c1b:	00 ff                	add    bh,bh
     c1d:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     c21:	ff 01                	inc    WORD PTR [bx+di]
     c23:	00 00                	add    BYTE PTR [bx+si],al
     c25:	00 00                	add    BYTE PTR [bx+si],al
     c27:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c2a:	00 80 32 00          	add    BYTE PTR [bx+si+0x32],al
     c2e:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     c31:	4b                   	dec    bx
     c32:	65 79 44             	gs jns 0xc79
     c35:	6f                   	outs   dx,WORD PTR ds:[si]
     c36:	77 6e                	ja     0xca6
     c38:	54                   	push   sp
     c39:	02 5d 0c             	add    bl,BYTE PTR [di+0xc]
     c3c:	b8 00 ff             	mov    ax,0xff00
     c3f:	ff                   	(bad)
     c40:	b8 00 ff             	mov    ax,0xff00
     c43:	ff 01                	inc    WORD PTR [bx+di]
     c45:	00 00                	add    BYTE PTR [bx+si],al
     c47:	00 00                	add    BYTE PTR [bx+si],al
     c49:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c4c:	00 80 33 00          	add    BYTE PTR [bx+si+0x33],al
     c50:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     c53:	4b                   	dec    bx
     c54:	65 79 50             	gs jns 0xca7
     c57:	72 65                	jb     0xcbe
     c59:	73 73                	jae    0xcce
     c5b:	1a 02                	sbb    al,BYTE PTR [bp+si]
     c5d:	7d 0c                	jge    0xc6b
     c5f:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
     c62:	ff c0                	inc    ax
     c64:	00 ff                	add    bh,bh
     c66:	ff 01                	inc    WORD PTR [bx+di]
     c68:	00 00                	add    BYTE PTR [bx+si],al
     c6a:	00 00                	add    BYTE PTR [bx+si],al
     c6c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c6f:	00 80 34 00          	add    BYTE PTR [bx+si+0x34],al
     c73:	07                   	pop    es
     c74:	4f                   	dec    di
     c75:	6e                   	outs   dx,BYTE PTR ds:[si]
     c76:	4b                   	dec    bx
     c77:	65 79 55             	gs jns 0xccf
     c7a:	70 71                	jo     0xced
     c7c:	01 a1 0c 4a          	add    WORD PTR [bx+di+0x4a0c],sp
     c80:	00 ff                	add    bh,bh
     c82:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     c85:	ff                   	(bad)
     c86:	ff 01                	inc    WORD PTR [bx+di]
     c88:	00 00                	add    BYTE PTR [bx+si],al
     c8a:	00 00                	add    BYTE PTR [bx+si],al
     c8c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c8f:	00 80 35 00          	add    BYTE PTR [bx+si+0x35],al
     c93:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     c96:	4d                   	dec    bp
     c97:	6f                   	outs   dx,WORD PTR ds:[si]
     c98:	75 73                	jne    0xd0d
     c9a:	65 44                	gs inc sp
     c9c:	6f                   	outs   dx,WORD PTR ds:[si]
     c9d:	77 6e                	ja     0xd0d
     c9f:	ce                   	into
     ca0:	01 c5                	add    bp,ax
     ca2:	0c 52                	or     al,0x52
     ca4:	00 ff                	add    bh,bh
     ca6:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     ca9:	ff                   	(bad)
     caa:	ff 01                	inc    WORD PTR [bx+di]
     cac:	00 00                	add    BYTE PTR [bx+si],al
     cae:	00 00                	add    BYTE PTR [bx+si],al
     cb0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     cb3:	00 80 36 00          	add    BYTE PTR [bx+si+0x36],al
     cb7:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     cba:	4d                   	dec    bp
     cbb:	6f                   	outs   dx,WORD PTR ds:[si]
     cbc:	75 73                	jne    0xd31
     cbe:	65 4d                	gs dec bp
     cc0:	6f                   	outs   dx,WORD PTR ds:[si]
     cc1:	76 65                	jbe    0xd28
     cc3:	71 01                	jno    0xcc6
     cc5:	bf 0e 5a             	mov    di,0x5a0e
     cc8:	00 ff                	add    bh,bh
     cca:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     ccd:	ff                   	(bad)
     cce:	ff 01                	inc    WORD PTR [bx+di]
     cd0:	00 00                	add    BYTE PTR [bx+si],al
     cd2:	00 00                	add    BYTE PTR [bx+si],al
     cd4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     cd7:	00 80 37 00          	add    BYTE PTR [bx+si+0x37],al
     cdb:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     cde:	4d                   	dec    bp
     cdf:	6f                   	outs   dx,WORD PTR ds:[si]
     ce0:	75 73                	jne    0xd55
     ce2:	65 55                	gs push bp
     ce4:	70 48                	jo     0xd2e
     ce6:	05 0a 0d             	add    ax,0xd0a
     ce9:	61                   	popa
     cea:	01 ff                	add    di,di
     cec:	ff 61 01             	jmp    WORD PTR [bx+di+0x1]
     cef:	ff                   	(bad)
     cf0:	ff 01                	inc    WORD PTR [bx+di]
     cf2:	00 00                	add    BYTE PTR [bx+si],al
     cf4:	00 00                	add    BYTE PTR [bx+si],al
     cf6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     cf9:	00 80 38 00          	add    BYTE PTR [bx+si+0x38],al
     cfd:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     d00:	52                   	push   dx
     d01:	6f                   	outs   dx,WORD PTR ds:[si]
     d02:	77 4d                	ja     0xd51
     d04:	6f                   	outs   dx,WORD PTR ds:[si]
     d05:	76 65                	jbe    0xd6c
     d07:	64 24 02             	fs and al,0x2
     d0a:	2f                   	das
     d0b:	0d 69 01             	or     ax,0x169
     d0e:	ff                   	(bad)
     d0f:	ff 69 01             	jmp    DWORD PTR [bx+di+0x1]
     d12:	ff                   	(bad)
     d13:	ff 01                	inc    WORD PTR [bx+di]
     d15:	00 00                	add    BYTE PTR [bx+si],al
     d17:	00 00                	add    BYTE PTR [bx+si],al
     d19:	80 00 00             	add    BYTE PTR [bx+si],0x0
     d1c:	00 80 39 00          	add    BYTE PTR [bx+si+0x39],al
     d20:	0c 4f                	or     al,0x4f
     d22:	6e                   	outs   dx,BYTE PTR ds:[si]
     d23:	53                   	push   bx
     d24:	65 6c                	gs ins BYTE PTR es:[di],dx
     d26:	65 63 74 43          	arpl   WORD PTR gs:[si+0x43],si
     d2a:	65 6c                	gs ins BYTE PTR es:[di],dx
     d2c:	6c                   	ins    BYTE PTR es:[di],dx
     d2d:	fd                   	std
     d2e:	04 ce                	add    al,0xce
     d30:	0d 71 01             	or     ax,0x171
     d33:	ff                   	(bad)
     d34:	ff 71 01             	push   WORD PTR [bx+di+0x1]
     d37:	ff                   	(bad)
     d38:	ff 01                	inc    WORD PTR [bx+di]
     d3a:	00 00                	add    BYTE PTR [bx+si],al
     d3c:	00 00                	add    BYTE PTR [bx+si],al
     d3e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     d41:	00 80 3a 00          	add    BYTE PTR [bx+si+0x3a],al
     d45:	0d 4f 6e             	or     ax,0x6e4f
     d48:	53                   	push   bx
     d49:	65 74 45             	gs je  0xd91
     d4c:	64 69 74 54 65 78    	imul   si,WORD PTR fs:[si+0x54],0x7865
     d52:	74 71                	je     0xdc5
     d54:	00 a2 0d 79          	add    BYTE PTR [bp+si+0x790d],ah
     d58:	01 ff                	add    di,di
     d5a:	ff                   	(bad)
     d5b:	79 01                	jns    0xd5e
     d5d:	ff                   	(bad)
     d5e:	ff 01                	inc    WORD PTR [bx+di]
     d60:	00 00                	add    BYTE PTR [bx+si],al
     d62:	00 00                	add    BYTE PTR [bx+si],al
     d64:	80 00 00             	add    BYTE PTR [bx+si],0x0
     d67:	00 80 3b 00          	add    BYTE PTR [bx+si+0x3b],al
     d6b:	10 4f 6e             	adc    BYTE PTR [bx+0x6e],cl
     d6e:	54                   	push   sp
     d6f:	6f                   	outs   dx,WORD PTR ds:[si]
     d70:	70 4c                	jo     0xdbe
     d72:	65 66 74 43          	gs data32 je 0xdb9
     d76:	68 61 6e             	push   0x6e61
     d79:	67 65 64 07          	addr32 gs fs pop es
     d7d:	0e                   	push   cs
     d7e:	00 00                	add    BYTE PTR [bx+si],al
     d80:	00 00                	add    BYTE PTR [bx+si],al
     d82:	00 00                	add    BYTE PTR [bx+si],al
     d84:	f4                   	hlt
     d85:	0d 0c 00             	or     ax,0xc
     d88:	2a 03                	sub    al,BYTE PTR [bp+di]
     d8a:	21 0e 64 20          	and    WORD PTR ds:0x2064,cx
     d8e:	47                   	inc    di
     d8f:	0e                   	push   cs
     d90:	9a 1f 8e 0d cb       	call   0xcb0d:0x8e1f
     d95:	1f                   	pop    ds
     d96:	92                   	xchg   dx,ax
     d97:	0d 66 1f             	or     ax,0x1f66
     d9a:	96                   	xchg   si,ax
     d9b:	0d cd 11             	or     ax,0x11cd
     d9e:	8a 0d                	mov    cl,BYTE PTR [di]
     da0:	f0 13 c6             	lock adc ax,si
     da3:	0d 62 90             	or     ax,0x9062
     da6:	1d 0e da             	sbb    ax,0xda0e
     da9:	92                   	xchg   dx,ax
     daa:	ae                   	scas   al,BYTE PTR es:[di]
     dab:	0d 2f 93             	or     ax,0x932f
     dae:	b2 0d                	mov    dl,0xd
     db0:	72 93                	jb     0xd45
     db2:	b6 0d                	mov    dh,0xd
     db4:	c1 93 ba 0d f9       	rcl    WORD PTR [bp+di+0xdba],0xf9
     db9:	93                   	xchg   bx,ax
     dba:	be 0d 32             	mov    si,0x320d
     dbd:	94                   	xchg   sp,ax
     dbe:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     dbf:	0d b6 91             	or     ax,0x91b6
     dc2:	aa                   	stos   BYTE PTR es:[di],al
     dc3:	0d 78 12             	or     ax,0x1278
     dc6:	ca 0d b2             	retf   0xb20d
     dc9:	12 d6                	adc    dl,dh
     dcb:	0d 52 92             	or     ax,0x9252
     dce:	c2 0d 64             	ret    0x640d
     dd1:	20 e2                	and    dl,ah
     dd3:	0d 55 14             	or     ax,0x1455
     dd6:	da 0d                	fimul  DWORD PTR [di]
     dd8:	13 16 de 0d          	adc    dx,WORD PTR ds:0xdde
     ddc:	e0 16                	loopne 0xdf4
     dde:	e6 0d                	out    0xd,al
     de0:	64 20 9a 0d 78       	and    BYTE PTR fs:[bp+si+0x780d],bl
     de5:	17                   	pop    ss
     de6:	ea 0d 24 19 ee       	jmp    0xee19:0x240d
     deb:	0d 39 1a             	or     ax,0x1a39
     dee:	f2 0d ac 1b          	repnz or ax,0x1bac
     df2:	9e                   	sahf
     df3:	0d 12 54             	or     ax,0x5412
     df6:	53                   	push   bx
     df7:	74 72                	je     0xe6b
     df9:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     dfe:	69 64 53 74 72       	imul   sp,WORD PTR [si+0x53],0x7274
     e03:	69 6e 67 73 07       	imul   bp,WORD PTR [bp+0x67],0x773
     e08:	12 54 53             	adc    dl,BYTE PTR [si+0x53]
     e0b:	74 72                	je     0xe7f
     e0d:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     e12:	69 64 53 74 72       	imul   sp,WORD PTR [si+0x53],0x7274
     e17:	69 6e 67 73 9c       	imul   bp,WORD PTR [bp+0x67],0x9c73
     e1c:	0d d7 0e             	or     ax,0xed7
     e1f:	8b 03                	mov    ax,WORD PTR [bp+di]
     e21:	5f                   	pop    di
     e22:	0e                   	push   cs
     e23:	00 00                	add    BYTE PTR [bx+si],al
     e25:	05 47 72             	add    ax,0x7247
     e28:	69 64 73 00 00       	imul   sp,WORD PTR [si+0x73],0x0
     e2d:	03 0f                	add    cx,WORD PTR [bx]
     e2f:	00 00                	add    BYTE PTR [bx+si],al
     e31:	00 00                	add    BYTE PTR [bx+si],al
     e33:	e9 0e dd             	jmp    0xeb44
     e36:	0e                   	push   cs
     e37:	91                   	xchg   cx,ax
     e38:	01 ab 05 f5          	add    WORD PTR [bp+di-0xafb],bp
     e3c:	0e                   	push   cs
     e3d:	fa                   	cli
     e3e:	45                   	inc    bp
     e3f:	b3 0e                	mov    bl,0xe
     e41:	9a 1f 49 0f cb       	call   0xcb0f:0x491f
     e46:	1f                   	pop    ds
     e47:	43                   	inc    bx
     e48:	0e                   	push   cs
     e49:	aa                   	stos   BYTE PTR es:[di],al
     e4a:	94                   	xchg   sp,ax
     e4b:	db 0e cd 11          	fisttp DWORD PTR ds:0x11cd
     e4f:	57                   	push   di
     e50:	0e                   	push   cs
     e51:	8d 27                	lea    sp,[bx]
     e53:	cb                   	retf
     e54:	0e                   	push   cs
     e55:	fa                   	cli
     e56:	10 4b 12             	adc    BYTE PTR [bp+di+0x12],cl
     e59:	d6                   	(bad)
     e5a:	14 63                	adc    al,0x63
     e5c:	0e                   	push   cs
     e5d:	f4                   	hlt
     e5e:	4f                   	dec    di
     e5f:	6f                   	outs   dx,WORD PTR ds:[si]
     e60:	0e                   	push   cs
     e61:	32 16 8b 0e          	xor    dl,BYTE PTR ds:0xe8b
     e65:	ec                   	in     al,dx
     e66:	30 c3                	xor    bl,al
     e68:	0e                   	push   cs
     e69:	51                   	push   cx
     e6a:	1b 43 16             	sbb    ax,WORD PTR [bp+di+0x16]
     e6d:	38 50 77             	cmp    BYTE PTR [bx+si+0x77],dl
     e70:	0e                   	push   cs
     e71:	63 31                	arpl   WORD PTR [bx+di],si
     e73:	93                   	xchg   bx,ax
     e74:	0e                   	push   cs
     e75:	21 50 4f             	and    WORD PTR [bx+si+0x4f],dx
     e78:	0e                   	push   cs
     e79:	4b                   	dec    bx
     e7a:	94                   	xchg   sp,ax
     e7b:	4b                   	dec    bx
     e7c:	0e                   	push   cs
     e7d:	d9 62 83             	fldenv [bp+si-0x7d]
     e80:	0e                   	push   cs
     e81:	06                   	push   es
     e82:	63 87 0e 8f          	arpl   WORD PTR [bx-0x70f2],ax
     e86:	60                   	pusha
     e87:	67 0e                	addr32 push cs
     e89:	3a 1c                	cmp    bl,BYTE PTR [si]
     e8b:	6b 0e 46 44 73       	imul   cx,WORD PTR ds:0x4446,0x73
     e90:	0e                   	push   cs
     e91:	08 61 97             	or     BYTE PTR [bx+di-0x69],ah
     e94:	0e                   	push   cs
     e95:	5c                   	pop    sp
     e96:	61                   	popa
     e97:	9b                   	fwait
     e98:	0e                   	push   cs
     e99:	62 5c c7             	bound  bx,DWORD PTR [si-0x39]
     e9c:	0e                   	push   cs
     e9d:	3a 61 5b             	cmp    ah,BYTE PTR [bx+di+0x5b]
     ea0:	0e                   	push   cs
     ea1:	72 3f                	jb     0xee2
     ea3:	ab                   	stos   WORD PTR es:[di],ax
     ea4:	0e                   	push   cs
     ea5:	dc 5c d3             	fcomp  QWORD PTR [si-0x2d]
     ea8:	0e                   	push   cs
     ea9:	17                   	pop    ss
     eaa:	3e af                	ds scas ax,WORD PTR es:[di]
     eac:	0e                   	push   cs
     ead:	88 3c                	mov    BYTE PTR [si],bh
     eaf:	3f                   	aas
     eb0:	0e                   	push   cs
     eb1:	ed                   	in     ax,dx
     eb2:	3e b7 0e             	ds mov bh,0xe
     eb5:	77 3e                	ja     0xef5
     eb7:	bb 0e c2             	mov    bx,0xc20e
     eba:	35 7f 0e             	xor    ax,0xe7f
     ebd:	26 6d                	es ins WORD PTR es:[di],dx
     ebf:	a3 0e ae             	mov    ds:0xae0e,ax
     ec2:	5f                   	pop    di
     ec3:	8f                   	(bad)
     ec4:	0e                   	push   cs
     ec5:	35 62 9f             	xor    ax,0x9f62
     ec8:	0e                   	push   cs
     ec9:	ec                   	in     al,dx
     eca:	2e 3b 0e b2 5c       	cmp    cx,WORD PTR cs:0x5cb2
     ecf:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     ed0:	0e                   	push   cs
     ed1:	93                   	xchg   bx,ax
     ed2:	24 53                	and    al,0x53
     ed4:	0e                   	push   cs
     ed5:	71 97                	jno    0xe6e
     ed7:	7b 0e                	jnp    0xee7
     ed9:	a1 80 cf             	mov    ax,ds:0xcf80
     edc:	0e                   	push   cs
     edd:	0b 54 53             	or     dx,WORD PTR [si+0x53]
     ee0:	74 72                	je     0xf54
     ee2:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     ee7:	69 64 04 00 e6       	imul   sp,WORD PTR [si+0x4],0xe600
     eec:	ff                   	jmp    (bad)
     eed:	ea ff e9 ff e5       	jmp    0xe5ff:0xe9ff
     ef2:	ff 87 95 f9          	inc    WORD PTR [bx-0x66b]
     ef6:	0e                   	push   cs
     ef7:	05 96 fd             	add    ax,0xfd96
     efa:	0e                   	push   cs
     efb:	6e                   	outs   dx,BYTE PTR ds:[si]
     efc:	96                   	xchg   si,ax
     efd:	01 0f                	add    WORD PTR [bx],cx
     eff:	c7                   	(bad)
     f00:	95                   	xchg   bp,ax
     f01:	12 0f                	adc    cl,BYTE PTR [bx]
     f03:	07                   	pop    es
     f04:	0b 54 53             	or     dx,WORD PTR [si+0x53]
     f07:	74 72                	je     0xf7b
     f09:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     f0e:	69 64 4d 0e 16       	imul   sp,WORD PTR [si+0x4d],0x160e
     f13:	0f 6b 06 3b 0f       	packssdw mm0,QWORD PTR ds:0xf3b
     f18:	3c 00                	cmp    al,0x0
     f1a:	05 47 72             	add    ax,0x7247
     f1d:	69 64 73 00 00       	imul   sp,WORD PTR [si+0x73],0x0
     f22:	c8 00 01 00          	enter  0x100,0x0
     f26:	8d be 00 ff          	lea    di,[bp-0x100]
     f2a:	16                   	push   ss
     f2b:	57                   	push   di
     f2c:	ff 76 04             	push   WORD PTR [bp+0x4]
     f2f:	9a 2b 09 42 0f       	call   0xf42:0x92b
     f34:	b0 01                	mov    al,0x1
     f36:	50                   	push   ax
     f37:	b8 22 00             	mov    ax,0x22
     f3a:	ba d8 19             	mov    dx,0x19d8
     f3d:	52                   	push   dx
     f3e:	50                   	push   ax
     f3f:	9a e6 28 09 14       	call   0x1409:0x28e6
     f44:	52                   	push   dx
     f45:	50                   	push   ax
     f46:	9a 99 13 e6 11       	call   0x11e6:0x1399
     f4b:	c9                   	leave
     f4c:	c2 02 00             	ret    0x2
     f4f:	c8 14 00 00          	enter  0x14,0x0
     f53:	8c d3                	mov    bx,ss
     f55:	8e c3                	mov    es,bx
     f57:	8c db                	mov    bx,ds
     f59:	fc                   	cld
     f5a:	8d 7e f8             	lea    di,[bp-0x8]
     f5d:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
     f60:	b9 08 00             	mov    cx,0x8
     f63:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     f65:	8d 7e f0             	lea    di,[bp-0x10]
     f68:	c5 76 04             	lds    si,DWORD PTR [bp+0x4]
     f6b:	b9 08 00             	mov    cx,0x8
     f6e:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     f70:	8e db                	mov    ds,bx
     f72:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     f75:	89 7e ec             	mov    WORD PTR [bp-0x14],di
     f78:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
     f7b:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     f7e:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
     f81:	26 89 05             	mov    WORD PTR es:[di],ax
     f84:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     f88:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     f8b:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     f8e:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
     f91:	7c 07                	jl     0xf9a
     f93:	7f 15                	jg     0xfaa
     f95:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     f98:	73 10                	jae    0xfaa
     f9a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     f9d:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     fa0:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     fa3:	26 89 05             	mov    WORD PTR es:[di],ax
     fa6:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     faa:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     fad:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     fb0:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     fb3:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     fb7:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     fbb:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     fbe:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     fc1:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
     fc4:	7c 07                	jl     0xfcd
     fc6:	7f 16                	jg     0xfde
     fc8:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     fcb:	73 11                	jae    0xfde
     fcd:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     fd0:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
     fd3:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     fd6:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     fda:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     fde:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     fe1:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     fe4:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     fe7:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     feb:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     fef:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     ff2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     ff5:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
     ff8:	7c 07                	jl     0x1001
     ffa:	7f 16                	jg     0x1012
     ffc:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     fff:	73 11                	jae    0x1012
    1001:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1004:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1007:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    100a:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    100e:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1012:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1015:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1018:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    101b:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    101f:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1023:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1026:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1029:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    102c:	7c 07                	jl     0x1035
    102e:	7f 16                	jg     0x1046
    1030:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1033:	73 11                	jae    0x1046
    1035:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1038:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    103b:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    103e:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1042:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1046:	c9                   	leave
    1047:	c2 08 00             	ret    0x8
    104a:	c8 02 00 00          	enter  0x2,0x0
    104e:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1051:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    1054:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1057:	26 3b 55 02          	cmp    dx,WORD PTR es:[di+0x2]
    105b:	7f 07                	jg     0x1064
    105d:	7c 4a                	jl     0x10a9
    105f:	26 3b 05             	cmp    ax,WORD PTR es:[di]
    1062:	72 45                	jb     0x10a9
    1064:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1067:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    106a:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    106d:	26 3b 55 0a          	cmp    dx,WORD PTR es:[di+0xa]
    1071:	7c 08                	jl     0x107b
    1073:	7f 34                	jg     0x10a9
    1075:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    1079:	77 2e                	ja     0x10a9
    107b:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    107e:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    1081:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1084:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
    1088:	7f 08                	jg     0x1092
    108a:	7c 1d                	jl     0x10a9
    108c:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    1090:	72 17                	jb     0x10a9
    1092:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1095:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    1098:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    109b:	26 3b 55 0e          	cmp    dx,WORD PTR es:[di+0xe]
    109f:	7c 0c                	jl     0x10ad
    10a1:	7f 06                	jg     0x10a9
    10a3:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    10a7:	76 04                	jbe    0x10ad
    10a9:	b0 00                	mov    al,0x0
    10ab:	eb 02                	jmp    0x10af
    10ad:	b0 01                	mov    al,0x1
    10af:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    10b2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    10b5:	c9                   	leave
    10b6:	c2 0c 00             	ret    0xc
    10b9:	c8 06 00 00          	enter  0x6,0x0
    10bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10c0:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    10c3:	26 3b 05             	cmp    ax,WORD PTR es:[di]
    10c6:	7c 1b                	jl     0x10e3
    10c8:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    10cb:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    10cf:	7f 12                	jg     0x10e3
    10d1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10d4:	26 3b 45 02          	cmp    ax,WORD PTR es:[di+0x2]
    10d8:	7c 09                	jl     0x10e3
    10da:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10dd:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    10e1:	7e 04                	jle    0x10e7
    10e3:	b0 00                	mov    al,0x0
    10e5:	eb 02                	jmp    0x10e9
    10e7:	b0 01                	mov    al,0x1
    10e9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    10ec:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    10ef:	c9                   	leave
    10f0:	c2 0a 00             	ret    0xa
    10f3:	c8 02 00 00          	enter  0x2,0x0
    10f7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10fa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    10fd:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1100:	36 c4 7d 0c          	les    di,DWORD PTR ss:[di+0xc]
    1104:	06                   	push   es
    1105:	57                   	push   di
    1106:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1109:	57                   	push   di
    110a:	e8 ac ff             	call   0x10b9
    110d:	08 c0                	or     al,al
    110f:	75 1e                	jne    0x112f
    1111:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1114:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1117:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    111a:	36 c4 7d 08          	les    di,DWORD PTR ss:[di+0x8]
    111e:	06                   	push   es
    111f:	57                   	push   di
    1120:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1123:	57                   	push   di
    1124:	e8 92 ff             	call   0x10b9
    1127:	08 c0                	or     al,al
    1129:	75 04                	jne    0x112f
    112b:	b0 00                	mov    al,0x0
    112d:	eb 02                	jmp    0x1131
    112f:	b0 01                	mov    al,0x1
    1131:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1134:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1138:	74 10                	je     0x114a
    113a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    113d:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1140:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1143:	26 89 05             	mov    WORD PTR es:[di],ax
    1146:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    114a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    114d:	c9                   	leave
    114e:	c2 0a 00             	ret    0xa
    1151:	c8 06 00 00          	enter  0x6,0x0
    1155:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1159:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    115c:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    115f:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    1162:	ff 76 10             	push   WORD PTR [bp+0x10]
    1165:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1168:	06                   	push   es
    1169:	57                   	push   di
    116a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    116d:	57                   	push   di
    116e:	e8 82 ff             	call   0x10f3
    1171:	08 c0                	or     al,al
    1173:	74 2d                	je     0x11a2
    1175:	ff 76 08             	push   WORD PTR [bp+0x8]
    1178:	ff 76 06             	push   WORD PTR [bp+0x6]
    117b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    117e:	81 c7 04 00          	add    di,0x4
    1182:	06                   	push   es
    1183:	57                   	push   di
    1184:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1187:	57                   	push   di
    1188:	e8 68 ff             	call   0x10f3
    118b:	08 c0                	or     al,al
    118d:	75 11                	jne    0x11a0
    118f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1192:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1195:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1198:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    119c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    11a0:	eb 2d                	jmp    0x11cf
    11a2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    11a5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    11a8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    11ab:	06                   	push   es
    11ac:	57                   	push   di
    11ad:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    11b0:	57                   	push   di
    11b1:	e8 3f ff             	call   0x10f3
    11b4:	08 c0                	or     al,al
    11b6:	74 13                	je     0x11cb
    11b8:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    11bb:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    11be:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    11c1:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    11c5:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    11c9:	eb 04                	jmp    0x11cf
    11cb:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    11cf:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    11d2:	c9                   	leave
    11d3:	c2 12 00             	ret    0x12
    11d6:	c8 14 00 00          	enter  0x14,0x0
    11da:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    11dd:	06                   	push   es
    11de:	57                   	push   di
    11df:	6a 20                	push   0x20
    11e1:	6a 00                	push   0x0
    11e3:	9a e5 1e 0f 12       	call   0x120f:0x1ee5
    11e8:	8d 7e f4             	lea    di,[bp-0xc]
    11eb:	16                   	push   ss
    11ec:	57                   	push   di
    11ed:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    11f0:	06                   	push   es
    11f1:	57                   	push   di
    11f2:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    11f5:	06                   	push   es
    11f6:	57                   	push   di
    11f7:	9a ff ff 00 00       	call   0x0:0xffff
    11fc:	09 c0                	or     ax,ax
    11fe:	75 29                	jne    0x1229
    1200:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1203:	06                   	push   es
    1204:	57                   	push   di
    1205:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1208:	06                   	push   es
    1209:	57                   	push   di
    120a:	6a 08                	push   0x8
    120c:	9a 1b 16 24 12       	call   0x1224:0x161b
    1211:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1214:	06                   	push   es
    1215:	57                   	push   di
    1216:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1219:	81 c7 08 00          	add    di,0x8
    121d:	06                   	push   es
    121e:	57                   	push   di
    121f:	6a 08                	push   0x8
    1221:	9a 1b 16 09 15       	call   0x1509:0x161b
    1226:	e9 18 01             	jmp    0x1341
    1229:	8d 7e ec             	lea    di,[bp-0x14]
    122c:	16                   	push   ss
    122d:	57                   	push   di
    122e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1231:	06                   	push   es
    1232:	57                   	push   di
    1233:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1236:	06                   	push   es
    1237:	57                   	push   di
    1238:	9a ff ff 00 00       	call   0x0:0xffff
    123d:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1240:	06                   	push   es
    1241:	57                   	push   di
    1242:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1245:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1248:	9a 6e 06 58 12       	call   0x1258:0x66e
    124d:	52                   	push   dx
    124e:	50                   	push   ax
    124f:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1252:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1255:	9a 6e 06 65 12       	call   0x1265:0x66e
    125a:	52                   	push   dx
    125b:	50                   	push   ax
    125c:	ff 76 ec             	push   WORD PTR [bp-0x14]
    125f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1262:	9a 6e 06 8d 12       	call   0x128d:0x66e
    1267:	52                   	push   dx
    1268:	50                   	push   ax
    1269:	55                   	push   bp
    126a:	e8 e4 fe             	call   0x1151
    126d:	08 c0                	or     al,al
    126f:	74 0a                	je     0x127b
    1271:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1274:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1277:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    127b:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    127e:	81 c7 08 00          	add    di,0x8
    1282:	06                   	push   es
    1283:	57                   	push   di
    1284:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1287:	ff 76 ee             	push   WORD PTR [bp-0x12]
    128a:	9a 6e 06 9a 12       	call   0x129a:0x66e
    128f:	52                   	push   dx
    1290:	50                   	push   ax
    1291:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1294:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1297:	9a 6e 06 a7 12       	call   0x12a7:0x66e
    129c:	52                   	push   dx
    129d:	50                   	push   ax
    129e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    12a1:	ff 76 ee             	push   WORD PTR [bp-0x12]
    12a4:	9a 6e 06 cf 12       	call   0x12cf:0x66e
    12a9:	52                   	push   dx
    12aa:	50                   	push   ax
    12ab:	55                   	push   bp
    12ac:	e8 a2 fe             	call   0x1151
    12af:	08 c0                	or     al,al
    12b1:	74 0a                	je     0x12bd
    12b3:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    12b6:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12b9:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    12bd:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12c0:	81 c7 10 00          	add    di,0x10
    12c4:	06                   	push   es
    12c5:	57                   	push   di
    12c6:	ff 76 f0             	push   WORD PTR [bp-0x10]
    12c9:	ff 76 f6             	push   WORD PTR [bp-0xa]
    12cc:	9a 6e 06 dc 12       	call   0x12dc:0x66e
    12d1:	52                   	push   dx
    12d2:	50                   	push   ax
    12d3:	ff 76 f0             	push   WORD PTR [bp-0x10]
    12d6:	ff 76 fa             	push   WORD PTR [bp-0x6]
    12d9:	9a 6e 06 e9 12       	call   0x12e9:0x66e
    12de:	52                   	push   dx
    12df:	50                   	push   ax
    12e0:	ff 76 f0             	push   WORD PTR [bp-0x10]
    12e3:	ff 76 f2             	push   WORD PTR [bp-0xe]
    12e6:	9a 6e 06 11 13       	call   0x1311:0x66e
    12eb:	52                   	push   dx
    12ec:	50                   	push   ax
    12ed:	55                   	push   bp
    12ee:	e8 60 fe             	call   0x1151
    12f1:	08 c0                	or     al,al
    12f3:	74 0a                	je     0x12ff
    12f5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    12f8:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12fb:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    12ff:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1302:	81 c7 18 00          	add    di,0x18
    1306:	06                   	push   es
    1307:	57                   	push   di
    1308:	ff 76 ec             	push   WORD PTR [bp-0x14]
    130b:	ff 76 f2             	push   WORD PTR [bp-0xe]
    130e:	9a 6e 06 1e 13       	call   0x131e:0x66e
    1313:	52                   	push   dx
    1314:	50                   	push   ax
    1315:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1318:	ff 76 f2             	push   WORD PTR [bp-0xe]
    131b:	9a 6e 06 2b 13       	call   0x132b:0x66e
    1320:	52                   	push   dx
    1321:	50                   	push   ax
    1322:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1325:	ff 76 f2             	push   WORD PTR [bp-0xe]
    1328:	9a 6e 06 e2 1d       	call   0x1de2:0x66e
    132d:	52                   	push   dx
    132e:	50                   	push   ax
    132f:	55                   	push   bp
    1330:	e8 1e fe             	call   0x1151
    1333:	08 c0                	or     al,al
    1335:	74 0a                	je     0x1341
    1337:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    133a:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    133d:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    1341:	c9                   	leave
    1342:	c2 0c 00             	ret    0xc
    1345:	c8 0a 00 00          	enter  0xa,0x0
    1349:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    134c:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    134f:	75 03                	jne    0x1354
    1351:	e9 fc 00             	jmp    0x1450
    1354:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1357:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    135b:	09 c0                	or     ax,ax
    135d:	75 07                	jne    0x1366
    135f:	31 c0                	xor    ax,ax
    1361:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1364:	eb 0c                	jmp    0x1372
    1366:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1369:	26 c4 3d             	les    di,DWORD PTR es:[di]
    136c:	26 8b 05             	mov    ax,WORD PTR es:[di]
    136f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1372:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    1376:	7c 19                	jl     0x1391
    1378:	7f 06                	jg     0x1380
    137a:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    137e:	72 11                	jb     0x1391
    1380:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1383:	31 d2                	xor    dx,dx
    1385:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    1388:	7c 07                	jl     0x1391
    138a:	7f 0b                	jg     0x1397
    138c:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    138f:	73 06                	jae    0x1397
    1391:	68 57 f0             	push   0xf057
    1394:	e8 8b fb             	call   0xf22
    1397:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    139a:	31 d2                	xor    dx,dx
    139c:	03 46 06             	add    ax,WORD PTR [bp+0x6]
    139f:	13 56 08             	adc    dx,WORD PTR [bp+0x8]
    13a2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    13a5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    13a8:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    13ac:	7c 08                	jl     0x13b6
    13ae:	7f 0e                	jg     0x13be
    13b0:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    13b4:	73 08                	jae    0x13be
    13b6:	68 56 f0             	push   0xf056
    13b9:	e8 66 fb             	call   0xf22
    13bc:	eb 15                	jmp    0x13d3
    13be:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    13c2:	7f 09                	jg     0x13cd
    13c4:	7c 0d                	jl     0x13d3
    13c6:	81 7e fc fb 3f       	cmp    WORD PTR [bp-0x4],0x3ffb
    13cb:	72 06                	jb     0x13d3
    13cd:	68 55 f0             	push   0xf055
    13d0:	e8 4f fb             	call   0xf22
    13d3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    13d6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    13d9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    13dc:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    13e0:	09 c0                	or     ax,ax
    13e2:	74 03                	je     0x13e7
    13e4:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    13e7:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    13eb:	76 03                	jbe    0x13f0
    13ed:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    13f0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    13f3:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    13f7:	26 ff 35             	push   WORD PTR es:[di]
    13fa:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    13fd:	d1 e0                	shl    ax,1
    13ff:	50                   	push   ax
    1400:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1403:	d1 e0                	shl    ax,1
    1405:	50                   	push   ax
    1406:	9a a1 04 c6 81       	call   0x81c6:0x4a1
    140b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    140e:	26 89 05             	mov    WORD PTR es:[di],ax
    1411:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    1415:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1419:	09 c0                	or     ax,ax
    141b:	74 33                	je     0x1450
    141d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1420:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1423:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1426:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1429:	73 18                	jae    0x1443
    142b:	8b 56 04             	mov    dx,WORD PTR [bp+0x4]
    142e:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1431:	d1 e0                	shl    ax,1
    1433:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1436:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1439:	03 f8                	add    di,ax
    143b:	26 89 15             	mov    WORD PTR es:[di],dx
    143e:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    1441:	eb e0                	jmp    0x1423
    1443:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1446:	48                   	dec    ax
    1447:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    144a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    144d:	26 89 05             	mov    WORD PTR es:[di],ax
    1450:	c9                   	leave
    1451:	c2 0e 00             	ret    0xe
    1454:	c8 02 00 00          	enter  0x2,0x0
    1458:	31 c0                	xor    ax,ax
    145a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    145d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1460:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1464:	09 c0                	or     ax,ax
    1466:	74 09                	je     0x1471
    1468:	26 c4 3d             	les    di,DWORD PTR es:[di]
    146b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    146e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1471:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1474:	06                   	push   es
    1475:	57                   	push   di
    1476:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1479:	99                   	cwd
    147a:	52                   	push   dx
    147b:	50                   	push   ax
    147c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    147f:	99                   	cwd
    1480:	8b c8                	mov    cx,ax
    1482:	8b da                	mov    bx,dx
    1484:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1487:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    148a:	2b c1                	sub    ax,cx
    148c:	1b d3                	sbb    dx,bx
    148e:	52                   	push   dx
    148f:	50                   	push   ax
    1490:	ff 76 04             	push   WORD PTR [bp+0x4]
    1493:	e8 af fe             	call   0x1345
    1496:	c9                   	leave
    1497:	c2 0a 00             	ret    0xa
    149a:	c8 02 00 00          	enter  0x2,0x0
    149e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    14a1:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    14a5:	09 c0                	or     ax,ax
    14a7:	75 03                	jne    0x14ac
    14a9:	e9 cf 00             	jmp    0x157b
    14ac:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    14af:	d1 e0                	shl    ax,1
    14b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14b4:	03 f8                	add    di,ax
    14b6:	26 8b 05             	mov    ax,WORD PTR es:[di]
    14b9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    14bc:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    14bf:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    14c2:	3b 56 06             	cmp    dx,WORD PTR [bp+0x6]
    14c5:	7c 07                	jl     0x14ce
    14c7:	7f 4a                	jg     0x1513
    14c9:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
    14cc:	73 45                	jae    0x1513
    14ce:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    14d1:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    14d4:	05 01 00             	add    ax,0x1
    14d7:	83 d2 00             	adc    dx,0x0
    14da:	d1 e0                	shl    ax,1
    14dc:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    14df:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14e2:	03 f8                	add    di,ax
    14e4:	06                   	push   es
    14e5:	57                   	push   di
    14e6:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    14e9:	d1 e0                	shl    ax,1
    14eb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    14ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14f1:	03 f8                	add    di,ax
    14f3:	06                   	push   es
    14f4:	57                   	push   di
    14f5:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    14f8:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    14fb:	2b 46 08             	sub    ax,WORD PTR [bp+0x8]
    14fe:	1b 56 0a             	sbb    dx,WORD PTR [bp+0xa]
    1501:	b9 02 00             	mov    cx,0x2
    1504:	31 db                	xor    bx,bx
    1506:	9a 33 16 0f 15       	call   0x150f:0x1633
    150b:	50                   	push   ax
    150c:	9a c1 1e 60 15       	call   0x1560:0x1ec1
    1511:	eb 55                	jmp    0x1568
    1513:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1516:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    1519:	3b 56 06             	cmp    dx,WORD PTR [bp+0x6]
    151c:	7f 07                	jg     0x1525
    151e:	7c 48                	jl     0x1568
    1520:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
    1523:	76 43                	jbe    0x1568
    1525:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    1528:	d1 e0                	shl    ax,1
    152a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    152d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1530:	03 f8                	add    di,ax
    1532:	06                   	push   es
    1533:	57                   	push   di
    1534:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    1537:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    153a:	05 01 00             	add    ax,0x1
    153d:	83 d2 00             	adc    dx,0x0
    1540:	d1 e0                	shl    ax,1
    1542:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1545:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1548:	03 f8                	add    di,ax
    154a:	06                   	push   es
    154b:	57                   	push   di
    154c:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    154f:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    1552:	2b 46 04             	sub    ax,WORD PTR [bp+0x4]
    1555:	1b 56 06             	sbb    dx,WORD PTR [bp+0x6]
    1558:	b9 02 00             	mov    cx,0x2
    155b:	31 db                	xor    bx,bx
    155d:	9a 33 16 66 15       	call   0x1566:0x1633
    1562:	50                   	push   ax
    1563:	9a c1 1e 24 16       	call   0x1624:0x1ec1
    1568:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    156b:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    156e:	d1 e0                	shl    ax,1
    1570:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1573:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1576:	03 f8                	add    di,ax
    1578:	26 89 15             	mov    WORD PTR es:[di],dx
    157b:	c9                   	leave
    157c:	c2 0c 00             	ret    0xc
    157f:	c8 08 00 00          	enter  0x8,0x0
    1583:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    1586:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1589:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
    158c:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    158f:	89 d7                	mov    di,dx
    1591:	89 c6                	mov    si,ax
    1593:	f7 e3                	mul    bx
    1595:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1598:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    159b:	89 f8                	mov    ax,di
    159d:	f7 e1                	mul    cx
    159f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    15a2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    15a5:	89 f8                	mov    ax,di
    15a7:	f7 e3                	mul    bx
    15a9:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    15ac:	11 56 fc             	adc    WORD PTR [bp-0x4],dx
    15af:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    15b3:	89 f0                	mov    ax,si
    15b5:	f7 e1                	mul    cx
    15b7:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    15ba:	11 56 fc             	adc    WORD PTR [bp-0x4],dx
    15bd:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    15c1:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    15c4:	8b 76 fc             	mov    si,WORD PTR [bp-0x4]
    15c7:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    15ca:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    15cd:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    15d0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    15d3:	d1 e9                	shr    cx,1
    15d5:	d1 df                	rcr    di,1
    15d7:	01 f8                	add    ax,di
    15d9:	11 cb                	adc    bx,cx
    15db:	83 d6 00             	adc    si,0x0
    15de:	83 d2 00             	adc    dx,0x0
    15e1:	b9 20 00             	mov    cx,0x20
    15e4:	f8                   	clc
    15e5:	d1 d0                	rcl    ax,1
    15e7:	d1 d3                	rcl    bx,1
    15e9:	d1 d6                	rcl    si,1
    15eb:	d1 d2                	rcl    dx,1
    15ed:	73 0b                	jae    0x15fa
    15ef:	2b 76 04             	sub    si,WORD PTR [bp+0x4]
    15f2:	1b 56 06             	sbb    dx,WORD PTR [bp+0x6]
    15f5:	f9                   	stc
    15f6:	e2 ed                	loop   0x15e5
    15f8:	eb 0f                	jmp    0x1609
    15fa:	3b 56 06             	cmp    dx,WORD PTR [bp+0x6]
    15fd:	72 07                	jb     0x1606
    15ff:	75 ee                	jne    0x15ef
    1601:	3b 76 04             	cmp    si,WORD PTR [bp+0x4]
    1604:	73 e9                	jae    0x15ef
    1606:	f8                   	clc
    1607:	e2 dc                	loop   0x15e5
    1609:	d1 d0                	rcl    ax,1
    160b:	d1 d3                	rcl    bx,1
    160d:	89 f1                	mov    cx,si
    160f:	89 da                	mov    dx,bx
    1611:	c9                   	leave
    1612:	c2 0c 00             	ret    0xc
    1615:	55                   	push   bp
    1616:	89 e5                	mov    bp,sp
    1618:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    161c:	74 08                	je     0x1626
    161e:	83 ec 08             	sub    sp,0x8
    1621:	9a e2 1f 25 17       	call   0x1725:0x1fe2
    1626:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1629:	ff 76 0c             	push   WORD PTR [bp+0xc]
    162c:	31 c0                	xor    ax,ax
    162e:	50                   	push   ax
    162f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1632:	06                   	push   es
    1633:	57                   	push   di
    1634:	9a 5a 11 e2 16       	call   0x16e2:0x115a
    1639:	6a 00                	push   0x0
    163b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    163e:	06                   	push   es
    163f:	57                   	push   di
    1640:	9a 70 63 4f 16       	call   0x164f:0x6370
    1645:	6a 00                	push   0x0
    1647:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    164a:	06                   	push   es
    164b:	57                   	push   di
    164c:	9a 22 63 5b 16       	call   0x165b:0x6322
    1651:	6a 00                	push   0x0
    1653:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1656:	06                   	push   es
    1657:	57                   	push   di
    1658:	9a 88 64 2d 18       	call   0x182d:0x6488
    165d:	6a 00                	push   0x0
    165f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1662:	06                   	push   es
    1663:	57                   	push   di
    1664:	9a bf 47 90 16       	call   0x1690:0x47bf
    1669:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    166d:	74 07                	je     0x1676
    166f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1673:	83 c4 06             	add    sp,0x6
    1676:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1679:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    167c:	c9                   	leave
    167d:	ca 0a 00             	retf   0xa
    1680:	55                   	push   bp
    1681:	89 e5                	mov    bp,sp
    1683:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1686:	06                   	push   es
    1687:	57                   	push   di
    1688:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    168b:	06                   	push   es
    168c:	57                   	push   di
    168d:	9a 5f 4a e9 1a       	call   0x1ae9:0x4a5f
    1692:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1695:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1699:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    169d:	0d 04 00             	or     ax,0x4
    16a0:	81 ca 00 00          	or     dx,0x0
    16a4:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    16a8:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    16ac:	c9                   	leave
    16ad:	ca 08 00             	retf   0x8
    16b0:	55                   	push   bp
    16b1:	89 e5                	mov    bp,sp
    16b3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    16b6:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    16b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16bc:	26 89 85 fd 00       	mov    WORD PTR es:[di+0xfd],ax
    16c1:	26 89 95 ff 00       	mov    WORD PTR es:[di+0xff],dx
    16c6:	c9                   	leave
    16c7:	ca 08 00             	retf   0x8
    16ca:	55                   	push   bp
    16cb:	89 e5                	mov    bp,sp
    16cd:	c9                   	leave
    16ce:	ca 08 00             	retf   0x8
    16d1:	55                   	push   bp
    16d2:	89 e5                	mov    bp,sp
    16d4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16d7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16dd:	06                   	push   es
    16de:	57                   	push   di
    16df:	9a 6f 23 79 18       	call   0x1879:0x236f
    16e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e7:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    16ec:	26 f6 85 09 01 08    	test   BYTE PTR es:[di+0x109],0x8
    16f2:	74 1a                	je     0x170e
    16f4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    16f7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    16fb:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    16ff:	0d 02 00             	or     ax,0x2
    1702:	81 ca 00 00          	or     dx,0x0
    1706:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    170a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    170e:	c9                   	leave
    170f:	ca 08 00             	retf   0x8
    1712:	55                   	push   bp
    1713:	89 e5                	mov    bp,sp
    1715:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1718:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    171d:	06                   	push   es
    171e:	57                   	push   di
    171f:	b8 fd ff             	mov    ax,0xfffd
    1722:	9a 6a 20 3f 17       	call   0x173f:0x206a
    1727:	c9                   	leave
    1728:	ca 04 00             	retf   0x4
    172b:	c8 02 00 00          	enter  0x2,0x0
    172f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1732:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1737:	06                   	push   es
    1738:	57                   	push   di
    1739:	b8 eb ff             	mov    ax,0xffeb
    173c:	9a 6a 20 73 17       	call   0x1773:0x206a
    1741:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1744:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1747:	c9                   	leave
    1748:	ca 04 00             	retf   0x4
    174b:	55                   	push   bp
    174c:	89 e5                	mov    bp,sp
    174e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1751:	36 c4 7d 0c          	les    di,DWORD PTR ss:[di+0xc]
    1755:	06                   	push   es
    1756:	57                   	push   di
    1757:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    175a:	36 8a 45 0a          	mov    al,BYTE PTR ss:[di+0xa]
    175e:	50                   	push   ax
    175f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1762:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1766:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    176b:	06                   	push   es
    176c:	57                   	push   di
    176d:	b8 f1 ff             	mov    ax,0xfff1
    1770:	9a 6a 20 a5 17       	call   0x17a5:0x206a
    1775:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1778:	36 c4 7d 0c          	les    di,DWORD PTR ss:[di+0xc]
    177c:	31 c0                	xor    ax,ax
    177e:	26 89 05             	mov    WORD PTR es:[di],ax
    1781:	c9                   	leave
    1782:	c2 02 00             	ret    0x2
    1785:	c8 08 00 00          	enter  0x8,0x0
    1789:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    178c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1790:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1795:	81 c7 b0 00          	add    di,0xb0
    1799:	06                   	push   es
    179a:	57                   	push   di
    179b:	8d 7e f8             	lea    di,[bp-0x8]
    179e:	16                   	push   ss
    179f:	57                   	push   di
    17a0:	6a 08                	push   0x8
    17a2:	9a 1b 16 20 19       	call   0x1920:0x161b
    17a7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    17aa:	09 c0                	or     ax,ax
    17ac:	74 2b                	je     0x17d9
    17ae:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    17b1:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    17b5:	26 ff b5 ff 00       	push   WORD PTR es:[di+0xff]
    17ba:	26 ff b5 fd 00       	push   WORD PTR es:[di+0xfd]
    17bf:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    17c2:	36 c4 7d 0c          	les    di,DWORD PTR ss:[di+0xc]
    17c6:	06                   	push   es
    17c7:	57                   	push   di
    17c8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    17cb:	36 8a 45 0a          	mov    al,BYTE PTR ss:[di+0xa]
    17cf:	50                   	push   ax
    17d0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17d3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17d6:	ff 5e f8             	call   DWORD PTR [bp-0x8]
    17d9:	c9                   	leave
    17da:	c2 02 00             	ret    0x2
    17dd:	c8 02 00 00          	enter  0x2,0x0
    17e1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    17e4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    17e8:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    17ed:	26 f6 85 09 01 20    	test   BYTE PTR es:[di+0x109],0x20
    17f3:	b0 00                	mov    al,0x0
    17f5:	74 01                	je     0x17f8
    17f7:	40                   	inc    ax
    17f8:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    17fb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    17fe:	c9                   	leave
    17ff:	c2 02 00             	ret    0x2
    1802:	c8 02 00 00          	enter  0x2,0x0
    1806:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1809:	36 f6 45 0a 04       	test   BYTE PTR ss:[di+0xa],0x4
    180e:	b0 00                	mov    al,0x0
    1810:	74 01                	je     0x1813
    1812:	40                   	inc    ax
    1813:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1816:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1819:	c9                   	leave
    181a:	c2 02 00             	ret    0x2
    181d:	c8 04 00 00          	enter  0x4,0x0
    1821:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1824:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1828:	06                   	push   es
    1829:	57                   	push   di
    182a:	9a b9 62 a9 1a       	call   0x1aa9:0x62b9
    182f:	50                   	push   ax
    1830:	68 00 04             	push   0x400
    1833:	6a 00                	push   0x0
    1835:	6a 00                	push   0x0
    1837:	6a 00                	push   0x0
    1839:	9a b6 1a 00 00       	call   0x0:0x1ab6
    183e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1841:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1844:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1847:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    184a:	c9                   	leave
    184b:	c2 02 00             	ret    0x2
    184e:	c8 06 00 00          	enter  0x6,0x0
    1852:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1855:	57                   	push   di
    1856:	e8 c4 ff             	call   0x181d
    1859:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    185c:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    185f:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    1863:	74 08                	je     0x186d
    1865:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1868:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    186b:	75 13                	jne    0x1880
    186d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1870:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    1874:	06                   	push   es
    1875:	57                   	push   di
    1876:	9a fd 14 b9 18       	call   0x18b9:0x14fd
    187b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    187e:	74 04                	je     0x1884
    1880:	b0 00                	mov    al,0x0
    1882:	eb 02                	jmp    0x1886
    1884:	b0 01                	mov    al,0x1
    1886:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1889:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    188c:	c9                   	leave
    188d:	c2 02 00             	ret    0x2
    1890:	c8 06 00 00          	enter  0x6,0x0
    1894:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1897:	57                   	push   di
    1898:	e8 82 ff             	call   0x181d
    189b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    189e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    18a1:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    18a5:	75 19                	jne    0x18c0
    18a7:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    18ab:	74 17                	je     0x18c4
    18ad:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    18b0:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    18b4:	06                   	push   es
    18b5:	57                   	push   di
    18b6:	9a fd 14 32 1a       	call   0x1a32:0x14fd
    18bb:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    18be:	74 04                	je     0x18c4
    18c0:	b0 00                	mov    al,0x0
    18c2:	eb 02                	jmp    0x18c6
    18c4:	b0 01                	mov    al,0x1
    18c6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    18c9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    18cc:	c9                   	leave
    18cd:	c2 02 00             	ret    0x2
    18d0:	55                   	push   bp
    18d1:	89 e5                	mov    bp,sp
    18d3:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    18d6:	26 8b 05             	mov    ax,WORD PTR es:[di]
    18d9:	3d 26 00             	cmp    ax,0x26
    18dc:	74 14                	je     0x18f2
    18de:	3d 28 00             	cmp    ax,0x28
    18e1:	74 0f                	je     0x18f2
    18e3:	3d 21 00             	cmp    ax,0x21
    18e6:	74 0a                	je     0x18f2
    18e8:	3d 22 00             	cmp    ax,0x22
    18eb:	74 05                	je     0x18f2
    18ed:	3d 1b 00             	cmp    ax,0x1b
    18f0:	75 07                	jne    0x18f9
    18f2:	55                   	push   bp
    18f3:	e8 55 fe             	call   0x174b
    18f6:	e9 f4 00             	jmp    0x19ed
    18f9:	3d 2d 00             	cmp    ax,0x2d
    18fc:	75 33                	jne    0x1931
    18fe:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1902:	75 06                	jne    0x190a
    1904:	55                   	push   bp
    1905:	e8 43 fe             	call   0x174b
    1908:	eb 24                	jmp    0x192e
    190a:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    190e:	75 1e                	jne    0x192e
    1910:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1913:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1918:	06                   	push   es
    1919:	57                   	push   di
    191a:	b8 eb ff             	mov    ax,0xffeb
    191d:	9a 6a 20 06 1a       	call   0x1a06:0x206a
    1922:	08 c0                	or     al,al
    1924:	75 08                	jne    0x192e
    1926:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1929:	31 c0                	xor    ax,ax
    192b:	26 89 05             	mov    WORD PTR es:[di],ax
    192e:	e9 bc 00             	jmp    0x19ed
    1931:	3d 25 00             	cmp    ax,0x25
    1934:	75 1f                	jne    0x1955
    1936:	55                   	push   bp
    1937:	e8 a3 fe             	call   0x17dd
    193a:	08 c0                	or     al,al
    193c:	74 14                	je     0x1952
    193e:	55                   	push   bp
    193f:	e8 c0 fe             	call   0x1802
    1942:	08 c0                	or     al,al
    1944:	75 08                	jne    0x194e
    1946:	55                   	push   bp
    1947:	e8 46 ff             	call   0x1890
    194a:	08 c0                	or     al,al
    194c:	74 04                	je     0x1952
    194e:	55                   	push   bp
    194f:	e8 f9 fd             	call   0x174b
    1952:	e9 98 00             	jmp    0x19ed
    1955:	3d 27 00             	cmp    ax,0x27
    1958:	75 1e                	jne    0x1978
    195a:	55                   	push   bp
    195b:	e8 7f fe             	call   0x17dd
    195e:	08 c0                	or     al,al
    1960:	74 14                	je     0x1976
    1962:	55                   	push   bp
    1963:	e8 9c fe             	call   0x1802
    1966:	08 c0                	or     al,al
    1968:	75 08                	jne    0x1972
    196a:	55                   	push   bp
    196b:	e8 e0 fe             	call   0x184e
    196e:	08 c0                	or     al,al
    1970:	74 04                	je     0x1976
    1972:	55                   	push   bp
    1973:	e8 d5 fd             	call   0x174b
    1976:	eb 75                	jmp    0x19ed
    1978:	3d 24 00             	cmp    ax,0x24
    197b:	75 1e                	jne    0x199b
    197d:	55                   	push   bp
    197e:	e8 5c fe             	call   0x17dd
    1981:	08 c0                	or     al,al
    1983:	74 14                	je     0x1999
    1985:	55                   	push   bp
    1986:	e8 79 fe             	call   0x1802
    1989:	08 c0                	or     al,al
    198b:	75 08                	jne    0x1995
    198d:	55                   	push   bp
    198e:	e8 ff fe             	call   0x1890
    1991:	08 c0                	or     al,al
    1993:	74 04                	je     0x1999
    1995:	55                   	push   bp
    1996:	e8 b2 fd             	call   0x174b
    1999:	eb 52                	jmp    0x19ed
    199b:	3d 23 00             	cmp    ax,0x23
    199e:	75 1e                	jne    0x19be
    19a0:	55                   	push   bp
    19a1:	e8 39 fe             	call   0x17dd
    19a4:	08 c0                	or     al,al
    19a6:	74 14                	je     0x19bc
    19a8:	55                   	push   bp
    19a9:	e8 56 fe             	call   0x1802
    19ac:	08 c0                	or     al,al
    19ae:	75 08                	jne    0x19b8
    19b0:	55                   	push   bp
    19b1:	e8 9a fe             	call   0x184e
    19b4:	08 c0                	or     al,al
    19b6:	74 04                	je     0x19bc
    19b8:	55                   	push   bp
    19b9:	e8 8f fd             	call   0x174b
    19bc:	eb 2f                	jmp    0x19ed
    19be:	3d 71 00             	cmp    ax,0x71
    19c1:	75 1b                	jne    0x19de
    19c3:	55                   	push   bp
    19c4:	e8 be fd             	call   0x1785
    19c7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    19ca:	26 83 3d 71          	cmp    WORD PTR es:[di],0x71
    19ce:	75 0c                	jne    0x19dc
    19d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d3:	06                   	push   es
    19d4:	57                   	push   di
    19d5:	9a fb 1b dd 1a       	call   0x1add:0x1bfb
    19da:	eb 58                	jmp    0x1a34
    19dc:	eb 0f                	jmp    0x19ed
    19de:	3d 09 00             	cmp    ax,0x9
    19e1:	75 0a                	jne    0x19ed
    19e3:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    19e7:	75 04                	jne    0x19ed
    19e9:	55                   	push   bp
    19ea:	e8 5e fd             	call   0x174b
    19ed:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    19f0:	26 83 3d 2e          	cmp    WORD PTR es:[di],0x2e
    19f4:	75 1e                	jne    0x1a14
    19f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19f9:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    19fe:	06                   	push   es
    19ff:	57                   	push   di
    1a00:	b8 eb ff             	mov    ax,0xffeb
    1a03:	9a 6a 20 51 1a       	call   0x1a51:0x206a
    1a08:	08 c0                	or     al,al
    1a0a:	75 08                	jne    0x1a14
    1a0c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1a0f:	31 c0                	xor    ax,ax
    1a11:	26 89 05             	mov    WORD PTR es:[di],ax
    1a14:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1a17:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    1a1b:	74 17                	je     0x1a34
    1a1d:	55                   	push   bp
    1a1e:	e8 64 fd             	call   0x1785
    1a21:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1a24:	06                   	push   es
    1a25:	57                   	push   di
    1a26:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1a29:	50                   	push   ax
    1a2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a2d:	06                   	push   es
    1a2e:	57                   	push   di
    1a2f:	9a 0b 12 ce 1a       	call   0x1ace:0x120b
    1a34:	c9                   	leave
    1a35:	ca 0a 00             	retf   0xa
    1a38:	c8 04 00 00          	enter  0x4,0x0
    1a3c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a3f:	06                   	push   es
    1a40:	57                   	push   di
    1a41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a44:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1a49:	06                   	push   es
    1a4a:	57                   	push   di
    1a4b:	b8 ef ff             	mov    ax,0xffef
    1a4e:	9a 6a 20 71 1a       	call   0x1a71:0x206a
    1a53:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a56:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1a59:	3c 20                	cmp    al,0x20
    1a5b:	72 28                	jb     0x1a85
    1a5d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1a60:	50                   	push   ax
    1a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a64:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1a69:	06                   	push   es
    1a6a:	57                   	push   di
    1a6b:	b8 ed ff             	mov    ax,0xffed
    1a6e:	9a 6a 20 18 1b       	call   0x1b18:0x206a
    1a73:	08 c0                	or     al,al
    1a75:	75 0e                	jne    0x1a85
    1a77:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a7a:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1a7e:	6a 00                	push   0x0
    1a80:	9a ff ff 00 00       	call   0x0:0xffff
    1a85:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a88:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1a8b:	3c 09                	cmp    al,0x9
    1a8d:	74 04                	je     0x1a93
    1a8f:	3c 1b                	cmp    al,0x1b
    1a91:	75 0a                	jne    0x1a9d
    1a93:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a96:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1a9a:	e9 88 00             	jmp    0x1b25
    1a9d:	3c 0d                	cmp    al,0xd
    1a9f:	75 53                	jne    0x1af4
    1aa1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aa4:	06                   	push   es
    1aa5:	57                   	push   di
    1aa6:	9a b9 62 f5 1b       	call   0x1bf5:0x62b9
    1aab:	50                   	push   ax
    1aac:	68 00 04             	push   0x400
    1aaf:	6a 00                	push   0x0
    1ab1:	6a 00                	push   0x0
    1ab3:	6a 00                	push   0x0
    1ab5:	9a 13 1c 00 00       	call   0x0:0x1c13
    1aba:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1abd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ac0:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1ac4:	75 1b                	jne    0x1ae1
    1ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac9:	06                   	push   es
    1aca:	57                   	push   di
    1acb:	9a fd 14 38 1b       	call   0x1b38:0x14fd
    1ad0:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1ad3:	75 0c                	jne    0x1ae1
    1ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad8:	06                   	push   es
    1ad9:	57                   	push   di
    1ada:	9a fb 1b ec 1c       	call   0x1cec:0x1bfb
    1adf:	eb 0a                	jmp    0x1aeb
    1ae1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ae4:	06                   	push   es
    1ae5:	57                   	push   di
    1ae6:	9a 3f 4a b4 77       	call   0x77b4:0x4a3f
    1aeb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1aee:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1af2:	eb 31                	jmp    0x1b25
    1af4:	3c 08                	cmp    al,0x8
    1af6:	74 10                	je     0x1b08
    1af8:	3c 16                	cmp    al,0x16
    1afa:	74 0c                	je     0x1b08
    1afc:	3c 18                	cmp    al,0x18
    1afe:	74 08                	je     0x1b08
    1b00:	3c 20                	cmp    al,0x20
    1b02:	72 21                	jb     0x1b25
    1b04:	3c ff                	cmp    al,0xff
    1b06:	77 1d                	ja     0x1b25
    1b08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b0b:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b10:	06                   	push   es
    1b11:	57                   	push   di
    1b12:	b8 eb ff             	mov    ax,0xffeb
    1b15:	9a 6a 20 5a 1b       	call   0x1b5a:0x206a
    1b1a:	08 c0                	or     al,al
    1b1c:	75 07                	jne    0x1b25
    1b1e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b21:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1b25:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b28:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1b2c:	74 0c                	je     0x1b3a
    1b2e:	06                   	push   es
    1b2f:	57                   	push   di
    1b30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b33:	06                   	push   es
    1b34:	57                   	push   di
    1b35:	9a 87 13 cc 76       	call   0x76cc:0x1387
    1b3a:	c9                   	leave
    1b3b:	ca 08 00             	retf   0x8
    1b3e:	55                   	push   bp
    1b3f:	89 e5                	mov    bp,sp
    1b41:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1b44:	06                   	push   es
    1b45:	57                   	push   di
    1b46:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1b49:	50                   	push   ax
    1b4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b4d:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b52:	06                   	push   es
    1b53:	57                   	push   di
    1b54:	b8 f0 ff             	mov    ax,0xfff0
    1b57:	9a 6a 20 a2 1b       	call   0x1ba2:0x206a
    1b5c:	c9                   	leave
    1b5d:	ca 0a 00             	retf   0xa
    1b60:	55                   	push   bp
    1b61:	89 e5                	mov    bp,sp
    1b63:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b66:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1b69:	3d 07 00             	cmp    ax,0x7
    1b6c:	75 3a                	jne    0x1ba8
    1b6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b71:	26 ff b5 ff 00       	push   WORD PTR es:[di+0xff]
    1b76:	26 ff b5 fd 00       	push   WORD PTR es:[di+0xfd]
    1b7b:	ff 76 08             	push   WORD PTR [bp+0x8]
    1b7e:	ff 76 06             	push   WORD PTR [bp+0x6]
    1b81:	9a a8 17 8f 1b       	call   0x1b8f:0x17a8
    1b86:	89 c7                	mov    di,ax
    1b88:	8e c2                	mov    es,dx
    1b8a:	06                   	push   es
    1b8b:	57                   	push   di
    1b8c:	9a 22 41 d5 24       	call   0x24d5:0x4122
    1b91:	08 c0                	or     al,al
    1b93:	74 0f                	je     0x1ba4
    1b95:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b98:	06                   	push   es
    1b99:	57                   	push   di
    1b9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b9d:	06                   	push   es
    1b9e:	57                   	push   di
    1b9f:	9a 38 20 ee 1d       	call   0x1dee:0x2038
    1ba4:	eb 51                	jmp    0x1bf7
    1ba6:	eb 40                	jmp    0x1be8
    1ba8:	3d 01 02             	cmp    ax,0x201
    1bab:	75 3b                	jne    0x1be8
    1bad:	9a 92 79 00 00       	call   0x0:0x7992
    1bb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb5:	26 2b 85 01 01       	sub    ax,WORD PTR es:[di+0x101]
    1bba:	26 1b 95 03 01       	sbb    dx,WORD PTR es:[di+0x103]
    1bbf:	8b c8                	mov    cx,ax
    1bc1:	8b da                	mov    bx,dx
    1bc3:	a1 ca 2a             	mov    ax,ds:0x2aca
    1bc6:	99                   	cwd
    1bc7:	3b d3                	cmp    dx,bx
    1bc9:	7f 06                	jg     0x1bd1
    1bcb:	7c 0c                	jl     0x1bd9
    1bcd:	3b c1                	cmp    ax,cx
    1bcf:	76 08                	jbe    0x1bd9
    1bd1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1bd4:	26 c7 05 03 02       	mov    WORD PTR es:[di],0x203
    1bd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bdc:	31 c0                	xor    ax,ax
    1bde:	26 89 85 01 01       	mov    WORD PTR es:[di+0x101],ax
    1be3:	26 89 85 03 01       	mov    WORD PTR es:[di+0x103],ax
    1be8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1beb:	06                   	push   es
    1bec:	57                   	push   di
    1bed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf0:	06                   	push   es
    1bf1:	57                   	push   di
    1bf2:	9a 46 44 06 1c       	call   0x1c06:0x4446
    1bf7:	c9                   	leave
    1bf8:	ca 08 00             	retf   0x8
    1bfb:	55                   	push   bp
    1bfc:	89 e5                	mov    bp,sp
    1bfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c01:	06                   	push   es
    1c02:	57                   	push   di
    1c03:	9a b9 62 27 1c       	call   0x1c27:0x62b9
    1c08:	50                   	push   ax
    1c09:	68 01 04             	push   0x401
    1c0c:	6a 01                	push   0x1
    1c0e:	6a ff                	push   0xffff
    1c10:	6a ff                	push   0xffff
    1c12:	9a 06 1e 00 00       	call   0x0:0x1e06
    1c17:	c9                   	leave
    1c18:	ca 04 00             	retf   0x4
    1c1b:	c8 08 00 00          	enter  0x8,0x0
    1c1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c22:	06                   	push   es
    1c23:	57                   	push   di
    1c24:	9a b9 62 3b 1c       	call   0x1c3b:0x62b9
    1c29:	50                   	push   ax
    1c2a:	6a 00                	push   0x0
    1c2c:	6a 00                	push   0x0
    1c2e:	9a 9b 1c 00 00       	call   0x0:0x1c9b
    1c33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c36:	06                   	push   es
    1c37:	57                   	push   di
    1c38:	9a b9 62 51 1c       	call   0x1c51:0x62b9
    1c3d:	50                   	push   ax
    1c3e:	6a 00                	push   0x0
    1c40:	6a 00                	push   0x0
    1c42:	6a 01                	push   0x1
    1c44:	9a b7 1c 00 00       	call   0x0:0x1cb7
    1c49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c4c:	06                   	push   es
    1c4d:	57                   	push   di
    1c4e:	9a b9 62 66 1c       	call   0x1c66:0x62b9
    1c53:	50                   	push   ax
    1c54:	8d 7e f8             	lea    di,[bp-0x8]
    1c57:	16                   	push   ss
    1c58:	57                   	push   di
    1c59:	9a ff ff 00 00       	call   0x0:0xffff
    1c5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c61:	06                   	push   es
    1c62:	57                   	push   di
    1c63:	9a b9 62 76 1c       	call   0x1c76:0x62b9
    1c68:	50                   	push   ax
    1c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c6c:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1c71:	06                   	push   es
    1c72:	57                   	push   di
    1c73:	9a b9 62 92 1c       	call   0x1c92:0x62b9
    1c78:	50                   	push   ax
    1c79:	8d 7e f8             	lea    di,[bp-0x8]
    1c7c:	16                   	push   ss
    1c7d:	57                   	push   di
    1c7e:	6a 02                	push   0x2
    1c80:	9a ff ff 00 00       	call   0x0:0xffff
    1c85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c88:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1c8d:	06                   	push   es
    1c8e:	57                   	push   di
    1c8f:	9a b9 62 ac 1c       	call   0x1cac:0x62b9
    1c94:	50                   	push   ax
    1c95:	8d 7e f8             	lea    di,[bp-0x8]
    1c98:	16                   	push   ss
    1c99:	57                   	push   di
    1c9a:	9a ff ff 00 00       	call   0x0:0xffff
    1c9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca2:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1ca7:	06                   	push   es
    1ca8:	57                   	push   di
    1ca9:	9a b9 62 ca 1c       	call   0x1cca:0x62b9
    1cae:	50                   	push   ax
    1caf:	8d 7e f8             	lea    di,[bp-0x8]
    1cb2:	16                   	push   ss
    1cb3:	57                   	push   di
    1cb4:	6a 00                	push   0x0
    1cb6:	9a e6 48 00 00       	call   0x0:0x48e6
    1cbb:	c9                   	leave
    1cbc:	ca 04 00             	retf   0x4
    1cbf:	55                   	push   bp
    1cc0:	89 e5                	mov    bp,sp
    1cc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cc5:	06                   	push   es
    1cc6:	57                   	push   di
    1cc7:	9a fa 64 d8 1c       	call   0x1cd8:0x64fa
    1ccc:	08 c0                	or     al,al
    1cce:	74 5e                	je     0x1d2e
    1cd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cd3:	06                   	push   es
    1cd4:	57                   	push   di
    1cd5:	9a b9 62 f6 1c       	call   0x1cf6:0x62b9
    1cda:	50                   	push   ax
    1cdb:	9a 83 1d 00 00       	call   0x0:0x1d83
    1ce0:	09 c0                	or     ax,ax
    1ce2:	74 4a                	je     0x1d2e
    1ce4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ce7:	06                   	push   es
    1ce8:	57                   	push   di
    1ce9:	9a 1b 1c 60 1d       	call   0x1d60:0x1c1b
    1cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf1:	06                   	push   es
    1cf2:	57                   	push   di
    1cf3:	9a b9 62 13 1d       	call   0x1d13:0x62b9
    1cf8:	50                   	push   ax
    1cf9:	6a 00                	push   0x0
    1cfb:	6a 00                	push   0x0
    1cfd:	6a 00                	push   0x0
    1cff:	6a 00                	push   0x0
    1d01:	6a 00                	push   0x0
    1d03:	68 8c 00             	push   0x8c
    1d06:	9a c2 1d 00 00       	call   0x0:0x1dc2
    1d0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d0e:	06                   	push   es
    1d0f:	57                   	push   di
    1d10:	9a 58 62 26 1d       	call   0x1d26:0x6258
    1d15:	08 c0                	or     al,al
    1d17:	74 15                	je     0x1d2e
    1d19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d1c:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1d21:	06                   	push   es
    1d22:	57                   	push   di
    1d23:	9a b9 62 7f 1d       	call   0x1d7f:0x62b9
    1d28:	50                   	push   ax
    1d29:	9a 39 1e 00 00       	call   0x0:0x1e39
    1d2e:	c9                   	leave
    1d2f:	ca 04 00             	retf   0x4
    1d32:	c8 10 00 00          	enter  0x10,0x0
    1d36:	8c d3                	mov    bx,ss
    1d38:	8e c3                	mov    es,bx
    1d3a:	8c db                	mov    bx,ds
    1d3c:	fc                   	cld
    1d3d:	8d 7e f8             	lea    di,[bp-0x8]
    1d40:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    1d43:	b9 08 00             	mov    cx,0x8
    1d46:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1d48:	8e db                	mov    ds,bx
    1d4a:	8d 7e f8             	lea    di,[bp-0x8]
    1d4d:	16                   	push   ss
    1d4e:	57                   	push   di
    1d4f:	9a 19 23 00 00       	call   0x0:0x2319
    1d54:	09 c0                	or     ax,ax
    1d56:	74 0d                	je     0x1d65
    1d58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d5b:	06                   	push   es
    1d5c:	57                   	push   di
    1d5d:	9a bf 1c 9c 1d       	call   0x1d9c:0x1cbf
    1d62:	e9 d8 00             	jmp    0x1e3d
    1d65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d68:	06                   	push   es
    1d69:	57                   	push   di
    1d6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d6d:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    1d71:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1d75:	75 18                	jne    0x1d8f
    1d77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d7a:	06                   	push   es
    1d7b:	57                   	push   di
    1d7c:	9a b9 62 a6 1d       	call   0x1da6:0x62b9
    1d81:	50                   	push   ax
    1d82:	9a ff ff 00 00       	call   0x0:0xffff
    1d87:	09 c0                	or     ax,ax
    1d89:	74 04                	je     0x1d8f
    1d8b:	b0 00                	mov    al,0x0
    1d8d:	eb 02                	jmp    0x1d91
    1d8f:	b0 01                	mov    al,0x1
    1d91:	88 46 0a             	mov    BYTE PTR [bp+0xa],al
    1d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d97:	06                   	push   es
    1d98:	57                   	push   di
    1d99:	9a 1b 1c 18 1e       	call   0x1e18:0x1c1b
    1d9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da1:	06                   	push   es
    1da2:	57                   	push   di
    1da3:	9a b9 62 f8 1d       	call   0x1df8:0x62b9
    1da8:	50                   	push   ax
    1da9:	6a 00                	push   0x0
    1dab:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1dae:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1db1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1db4:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    1db7:	50                   	push   ax
    1db8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1dbb:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1dbe:	50                   	push   ax
    1dbf:	6a 48                	push   0x48
    1dc1:	9a ff ff 00 00       	call   0x0:0xffff
    1dc6:	8d 7e f0             	lea    di,[bp-0x10]
    1dc9:	16                   	push   ss
    1dca:	57                   	push   di
    1dcb:	6a 02                	push   0x2
    1dcd:	6a 02                	push   0x2
    1dcf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1dd2:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    1dd5:	48                   	dec    ax
    1dd6:	48                   	dec    ax
    1dd7:	50                   	push   ax
    1dd8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ddb:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1dde:	50                   	push   ax
    1ddf:	9a 88 06 de 25       	call   0x25de:0x688
    1de4:	8d 7e f8             	lea    di,[bp-0x8]
    1de7:	16                   	push   ss
    1de8:	57                   	push   di
    1de9:	6a 08                	push   0x8
    1deb:	9a 1b 16 80 1e       	call   0x1e80:0x161b
    1df0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df3:	06                   	push   es
    1df4:	57                   	push   di
    1df5:	9a b9 62 27 1e       	call   0x1e27:0x62b9
    1dfa:	50                   	push   ax
    1dfb:	68 04 04             	push   0x404
    1dfe:	6a 00                	push   0x0
    1e00:	8d 7e f8             	lea    di,[bp-0x8]
    1e03:	16                   	push   ss
    1e04:	57                   	push   di
    1e05:	9a ff ff 00 00       	call   0x0:0xffff
    1e0a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1e0e:	74 0a                	je     0x1e1a
    1e10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e13:	06                   	push   es
    1e14:	57                   	push   di
    1e15:	9a 1b 1c 53 1e       	call   0x1e53:0x1c1b
    1e1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e1d:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1e22:	06                   	push   es
    1e23:	57                   	push   di
    1e24:	9a 58 62 35 1e       	call   0x1e35:0x6258
    1e29:	08 c0                	or     al,al
    1e2b:	74 10                	je     0x1e3d
    1e2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e30:	06                   	push   es
    1e31:	57                   	push   di
    1e32:	9a b9 62 93 1e       	call   0x1e93:0x62b9
    1e37:	50                   	push   ax
    1e38:	9a ff ff 00 00       	call   0x0:0xffff
    1e3d:	c9                   	leave
    1e3e:	ca 0a 00             	retf   0xa
    1e41:	55                   	push   bp
    1e42:	89 e5                	mov    bp,sp
    1e44:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e47:	06                   	push   es
    1e48:	57                   	push   di
    1e49:	6a 00                	push   0x0
    1e4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e4e:	06                   	push   es
    1e4f:	57                   	push   di
    1e50:	9a 32 1d 6b 1e       	call   0x1e6b:0x1d32
    1e55:	c9                   	leave
    1e56:	ca 08 00             	retf   0x8
    1e59:	55                   	push   bp
    1e5a:	89 e5                	mov    bp,sp
    1e5c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e5f:	06                   	push   es
    1e60:	57                   	push   di
    1e61:	6a 01                	push   0x1
    1e63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e66:	06                   	push   es
    1e67:	57                   	push   di
    1e68:	9a 32 1d 87 1f       	call   0x1f87:0x1d32
    1e6d:	c9                   	leave
    1e6e:	ca 08 00             	retf   0x8
    1e71:	55                   	push   bp
    1e72:	89 e5                	mov    bp,sp
    1e74:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1e78:	74 08                	je     0x1e82
    1e7a:	83 ec 08             	sub    sp,0x8
    1e7d:	9a e2 1f 57 1f       	call   0x1f57:0x1fe2
    1e82:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1e85:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e88:	31 c0                	xor    ax,ax
    1e8a:	50                   	push   ax
    1e8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e8e:	06                   	push   es
    1e8f:	57                   	push   di
    1e90:	9a 72 6c 1f 1f       	call   0x1f1f:0x6c72
    1e95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e98:	26 c7 45 26 d2 00    	mov    WORD PTR es:[di+0x26],0xd2
    1e9e:	26 c6 85 e5 00 01    	mov    BYTE PTR es:[di+0xe5],0x1
    1ea4:	26 c7 85 e6 00 05 00 	mov    WORD PTR es:[di+0xe6],0x5
    1eab:	26 c7 85 e8 00 00 00 	mov    WORD PTR es:[di+0xe8],0x0
    1eb2:	26 c7 85 0a 01 05 00 	mov    WORD PTR es:[di+0x10a],0x5
    1eb9:	26 c7 85 0c 01 00 00 	mov    WORD PTR es:[di+0x10c],0x0
    1ec0:	26 c7 85 fe 00 01 00 	mov    WORD PTR es:[di+0xfe],0x1
    1ec7:	26 c7 85 00 01 01 00 	mov    WORD PTR es:[di+0x100],0x1
    1ece:	26 c7 85 06 01 01 00 	mov    WORD PTR es:[di+0x106],0x1
    1ed5:	26 c7 85 08 01 1f 00 	mov    WORD PTR es:[di+0x108],0x1f
    1edc:	26 c7 85 02 01 f0 ff 	mov    WORD PTR es:[di+0x102],0xfff0
    1ee3:	26 c7 85 04 01 ff ff 	mov    WORD PTR es:[di+0x104],0xffff
    1eea:	26 c6 85 12 01 03    	mov    BYTE PTR es:[di+0x112],0x3
    1ef0:	26 c6 85 e4 00 01    	mov    BYTE PTR es:[di+0xe4],0x1
    1ef6:	26 c7 85 fa 00 40 00 	mov    WORD PTR es:[di+0xfa],0x40
    1efd:	26 c7 85 fc 00 18 00 	mov    WORD PTR es:[di+0xfc],0x18
    1f04:	26 c6 85 3b 01 01    	mov    BYTE PTR es:[di+0x13b],0x1
    1f0a:	26 c6 85 40 01 01    	mov    BYTE PTR es:[di+0x140],0x1
    1f10:	26 c6 85 3c 01 00    	mov    BYTE PTR es:[di+0x13c],0x0
    1f16:	6a ff                	push   0xffff
    1f18:	6a fa                	push   0xfffa
    1f1a:	06                   	push   es
    1f1b:	57                   	push   di
    1f1c:	9a d5 1e 2b 1f       	call   0x1f2b:0x1ed5
    1f21:	6a 00                	push   0x0
    1f23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f26:	06                   	push   es
    1f27:	57                   	push   di
    1f28:	9a 32 1f 37 1f       	call   0x1f37:0x1f32
    1f2d:	6a 01                	push   0x1
    1f2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f32:	06                   	push   es
    1f33:	57                   	push   di
    1f34:	9a 88 64 bd 1f       	call   0x1fbd:0x6488
    1f39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3c:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1f40:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1f44:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    1f49:	99                   	cwd
    1f4a:	26 8b 8d e6 00       	mov    cx,WORD PTR es:[di+0xe6]
    1f4f:	26 8b 9d e8 00       	mov    bx,WORD PTR es:[di+0xe8]
    1f54:	9a 33 16 70 1f       	call   0x1f70:0x1633
    1f59:	50                   	push   ax
    1f5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f5d:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    1f62:	99                   	cwd
    1f63:	26 8b 8d 0a 01       	mov    cx,WORD PTR es:[di+0x10a]
    1f68:	26 8b 9d 0c 01       	mov    bx,WORD PTR es:[di+0x10c]
    1f6d:	9a 33 16 b0 1f       	call   0x1fb0:0x1633
    1f72:	50                   	push   ax
    1f73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f76:	06                   	push   es
    1f77:	57                   	push   di
    1f78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f7b:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    1f7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f82:	06                   	push   es
    1f83:	57                   	push   di
    1f84:	9a bd 47 11 23       	call   0x2311:0x47bd
    1f89:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1f8d:	74 07                	je     0x1f96
    1f8f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1f93:	83 c4 06             	add    sp,0x6
    1f96:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1f99:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1f9c:	c9                   	leave
    1f9d:	ca 0a 00             	retf   0xa
    1fa0:	55                   	push   bp
    1fa1:	89 e5                	mov    bp,sp
    1fa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa6:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    1fab:	06                   	push   es
    1fac:	57                   	push   di
    1fad:	9a 7f 1f c8 1f       	call   0x1fc8:0x1f7f
    1fb2:	31 c0                	xor    ax,ax
    1fb4:	50                   	push   ax
    1fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb8:	06                   	push   es
    1fb9:	57                   	push   di
    1fba:	9a dc 6c 29 23       	call   0x2329:0x6cdc
    1fbf:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1fc3:	74 05                	je     0x1fca
    1fc5:	9a 0f 20 8d 20       	call   0x208d:0x200f
    1fca:	c9                   	leave
    1fcb:	ca 06 00             	retf   0x6
    1fce:	c8 10 00 00          	enter  0x10,0x0
    1fd2:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1fd5:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1fd8:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    1fdc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1fdf:	36 03 45 0c          	add    ax,WORD PTR ss:[di+0xc]
    1fe3:	36 13 55 0e          	adc    dx,WORD PTR ss:[di+0xe]
    1fe7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1fea:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    1fed:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1ff0:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    1ff3:	36 3b 55 12          	cmp    dx,WORD PTR ss:[di+0x12]
    1ff7:	7c 08                	jl     0x2001
    1ff9:	7f 0c                	jg     0x2007
    1ffb:	36 3b 45 10          	cmp    ax,WORD PTR ss:[di+0x10]
    1fff:	73 06                	jae    0x2007
    2001:	68 56 f0             	push   0xf056
    2004:	e8 1b ef             	call   0xf22
    2007:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    200a:	36 83 7d 0e 00       	cmp    WORD PTR ss:[di+0xe],0x0
    200f:	7c 09                	jl     0x201a
    2011:	7f 68                	jg     0x207b
    2013:	36 83 7d 0c 00       	cmp    WORD PTR ss:[di+0xc],0x0
    2018:	73 61                	jae    0x207b
    201a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    201d:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    2021:	09 c0                	or     ax,ax
    2023:	74 56                	je     0x207b
    2025:	31 c0                	xor    ax,ax
    2027:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    202a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    202d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2030:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2034:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2038:	36 2b 45 0c          	sub    ax,WORD PTR ss:[di+0xc]
    203c:	36 1b 55 0e          	sbb    dx,WORD PTR ss:[di+0xe]
    2040:	2d 01 00             	sub    ax,0x1
    2043:	83 da 00             	sbb    dx,0x0
    2046:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2049:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    204d:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    2050:	7f 27                	jg     0x2079
    2052:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2055:	eb 03                	jmp    0x205a
    2057:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    205a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    205d:	d1 e0                	shl    ax,1
    205f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2062:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2065:	03 f8                	add    di,ax
    2067:	26 8b 05             	mov    ax,WORD PTR es:[di]
    206a:	99                   	cwd
    206b:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    206e:	11 56 fe             	adc    WORD PTR [bp-0x2],dx
    2071:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2074:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    2077:	75 de                	jne    0x2057
    2079:	eb 1a                	jmp    0x2095
    207b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    207e:	99                   	cwd
    207f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2082:	36 8b 4d 0c          	mov    cx,WORD PTR ss:[di+0xc]
    2086:	36 8b 5d 0e          	mov    bx,WORD PTR ss:[di+0xe]
    208a:	9a 33 16 75 21       	call   0x2175:0x1633
    208f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2092:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2095:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2098:	26 8b 05             	mov    ax,WORD PTR es:[di]
    209b:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    209f:	74 1b                	je     0x20bc
    20a1:	06                   	push   es
    20a2:	57                   	push   di
    20a3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    20a6:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    20aa:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    20ae:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    20b2:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    20b6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20b9:	e8 89 f2             	call   0x1345
    20bc:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    20bf:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    20c2:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    20c5:	26 89 05             	mov    WORD PTR es:[di],ax
    20c8:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    20cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20cf:	26 8b 05             	mov    ax,WORD PTR es:[di]
    20d2:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    20d6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    20d9:	36 3b 55 12          	cmp    dx,WORD PTR ss:[di+0x12]
    20dd:	7f 08                	jg     0x20e7
    20df:	7c 68                	jl     0x2149
    20e1:	36 3b 45 10          	cmp    ax,WORD PTR ss:[di+0x10]
    20e5:	72 62                	jb     0x2149
    20e7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    20ea:	36 83 7d 0e 00       	cmp    WORD PTR ss:[di+0xe],0x0
    20ef:	7c 09                	jl     0x20fa
    20f1:	7f 41                	jg     0x2134
    20f3:	36 83 7d 0c 00       	cmp    WORD PTR ss:[di+0xc],0x0
    20f8:	73 3a                	jae    0x2134
    20fa:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    20fd:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2101:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2105:	36 2b 45 0c          	sub    ax,WORD PTR ss:[di+0xc]
    2109:	36 1b 55 0e          	sbb    dx,WORD PTR ss:[di+0xe]
    210d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2110:	26 3b 55 02          	cmp    dx,WORD PTR es:[di+0x2]
    2114:	7f 07                	jg     0x211d
    2116:	7c 1c                	jl     0x2134
    2118:	26 3b 05             	cmp    ax,WORD PTR es:[di]
    211b:	76 17                	jbe    0x2134
    211d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2120:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2124:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2128:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    212b:	26 89 05             	mov    WORD PTR es:[di],ax
    212e:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    2132:	eb 15                	jmp    0x2149
    2134:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2137:	36 8b 45 0c          	mov    ax,WORD PTR ss:[di+0xc]
    213b:	36 8b 55 0e          	mov    dx,WORD PTR ss:[di+0xe]
    213f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2142:	26 01 05             	add    WORD PTR es:[di],ax
    2145:	26 11 55 02          	adc    WORD PTR es:[di+0x2],dx
    2149:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    214c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    214f:	c9                   	leave
    2150:	c2 10 00             	ret    0x10
    2153:	c8 34 00 00          	enter  0x34,0x0
    2157:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    215a:	0b 46 0e             	or     ax,WORD PTR [bp+0xe]
    215d:	75 03                	jne    0x2162
    215f:	e9 4d 02             	jmp    0x23af
    2162:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2165:	81 c7 f2 00          	add    di,0xf2
    2169:	06                   	push   es
    216a:	57                   	push   di
    216b:	8d 7e f8             	lea    di,[bp-0x8]
    216e:	16                   	push   ss
    216f:	57                   	push   di
    2170:	6a 08                	push   0x8
    2172:	9a 1b 16 68 23       	call   0x2368:0x161b
    2177:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    217a:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    217f:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2184:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2187:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    218a:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    218f:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    2194:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2197:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    219a:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    219f:	99                   	cwd
    21a0:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    21a3:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    21a6:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    21ab:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    21b0:	2d 01 00             	sub    ax,0x1
    21b3:	83 da 00             	sbb    dx,0x0
    21b6:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    21b9:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    21bc:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    21c1:	99                   	cwd
    21c2:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    21c5:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    21c8:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    21cd:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    21d2:	2d 01 00             	sub    ax,0x1
    21d5:	83 da 00             	sbb    dx,0x0
    21d8:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    21db:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    21de:	31 c0                	xor    ax,ax
    21e0:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    21e3:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    21e6:	31 c0                	xor    ax,ax
    21e8:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    21eb:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    21ee:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    21f1:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    21f4:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    21f7:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    21fa:	83 7e ce 00          	cmp    WORD PTR [bp-0x32],0x0
    21fe:	7c 08                	jl     0x2208
    2200:	7f 19                	jg     0x221b
    2202:	83 7e cc 00          	cmp    WORD PTR [bp-0x34],0x0
    2206:	73 13                	jae    0x221b
    2208:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    220b:	8b 56 ce             	mov    dx,WORD PTR [bp-0x32]
    220e:	f7 d2                	not    dx
    2210:	f7 d8                	neg    ax
    2212:	83 da ff             	sbb    dx,0xffff
    2215:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    2218:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    221b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    221f:	74 6f                	je     0x2290
    2221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2224:	81 c7 0a 01          	add    di,0x10a
    2228:	06                   	push   es
    2229:	57                   	push   di
    222a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    222d:	81 c7 0e 01          	add    di,0x10e
    2231:	06                   	push   es
    2232:	57                   	push   di
    2233:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2236:	26 ff b5 fc 00       	push   WORD PTR es:[di+0xfc]
    223b:	8d 7e fc             	lea    di,[bp-0x4]
    223e:	16                   	push   ss
    223f:	57                   	push   di
    2240:	55                   	push   bp
    2241:	e8 8a fd             	call   0x1fce
    2244:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2247:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    224a:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    224d:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    2250:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2253:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2256:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    2259:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    225c:	03 46 cc             	add    ax,WORD PTR [bp-0x34]
    225f:	13 56 ce             	adc    dx,WORD PTR [bp-0x32]
    2262:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2265:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    226a:	7c 09                	jl     0x2275
    226c:	7f 20                	jg     0x228e
    226e:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    2273:	77 19                	ja     0x228e
    2275:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2278:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    227d:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    2282:	2d 01 00             	sub    ax,0x1
    2285:	83 da 00             	sbb    dx,0x0
    2288:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    228b:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    228e:	eb 6d                	jmp    0x22fd
    2290:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2293:	81 c7 e6 00          	add    di,0xe6
    2297:	06                   	push   es
    2298:	57                   	push   di
    2299:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    229c:	81 c7 ea 00          	add    di,0xea
    22a0:	06                   	push   es
    22a1:	57                   	push   di
    22a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a5:	26 ff b5 fa 00       	push   WORD PTR es:[di+0xfa]
    22aa:	8d 7e f8             	lea    di,[bp-0x8]
    22ad:	16                   	push   ss
    22ae:	57                   	push   di
    22af:	55                   	push   bp
    22b0:	e8 1b fd             	call   0x1fce
    22b3:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    22b6:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    22b9:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    22bc:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    22bf:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    22c2:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    22c5:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    22c8:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    22cb:	03 46 cc             	add    ax,WORD PTR [bp-0x34]
    22ce:	13 56 ce             	adc    dx,WORD PTR [bp-0x32]
    22d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22d4:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    22d9:	7c 09                	jl     0x22e4
    22db:	7f 20                	jg     0x22fd
    22dd:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    22e2:	77 19                	ja     0x22fd
    22e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e7:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    22ec:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    22f1:	2d 01 00             	sub    ax,0x1
    22f4:	83 da 00             	sbb    dx,0x0
    22f7:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    22fa:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    22fd:	8d 7e d8             	lea    di,[bp-0x28]
    2300:	16                   	push   ss
    2301:	57                   	push   di
    2302:	8d 7e d0             	lea    di,[bp-0x30]
    2305:	16                   	push   ss
    2306:	57                   	push   di
    2307:	6a 01                	push   0x1
    2309:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    230c:	06                   	push   es
    230d:	57                   	push   di
    230e:	9a 97 44 ad 23       	call   0x23ad:0x4497
    2313:	8d 7e d0             	lea    di,[bp-0x30]
    2316:	16                   	push   ss
    2317:	57                   	push   di
    2318:	9a ff ff 00 00       	call   0x0:0xffff
    231d:	09 c0                	or     ax,ax
    231f:	75 30                	jne    0x2351
    2321:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2324:	06                   	push   es
    2325:	57                   	push   di
    2326:	9a b9 62 49 23       	call   0x2349:0x62b9
    232b:	50                   	push   ax
    232c:	ff 76 ec             	push   WORD PTR [bp-0x14]
    232f:	ff 76 e8             	push   WORD PTR [bp-0x18]
    2332:	8d 7e d0             	lea    di,[bp-0x30]
    2335:	16                   	push   ss
    2336:	57                   	push   di
    2337:	8d 7e d0             	lea    di,[bp-0x30]
    233a:	16                   	push   ss
    233b:	57                   	push   di
    233c:	9a ff 52 00 00       	call   0x0:0x52ff
    2341:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2344:	06                   	push   es
    2345:	57                   	push   di
    2346:	9a b9 62 0c 24       	call   0x240c:0x62b9
    234b:	50                   	push   ax
    234c:	9a ff ff 00 00       	call   0x0:0xffff
    2351:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2354:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2357:	ff 76 f6             	push   WORD PTR [bp-0xa]
    235a:	ff 76 f4             	push   WORD PTR [bp-0xc]
    235d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2360:	06                   	push   es
    2361:	57                   	push   di
    2362:	b8 e4 ff             	mov    ax,0xffe4
    2365:	9a 6a 20 59 24       	call   0x2459:0x206a
    236a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    236d:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2370:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2373:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    2378:	75 1b                	jne    0x2395
    237a:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    237f:	75 14                	jne    0x2395
    2381:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2384:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2387:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    238c:	75 07                	jne    0x2395
    238e:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    2393:	74 1a                	je     0x23af
    2395:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2398:	ff 76 f8             	push   WORD PTR [bp-0x8]
    239b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    239e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    23a1:	6a 01                	push   0x1
    23a3:	6a 01                	push   0x1
    23a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23a8:	06                   	push   es
    23a9:	57                   	push   di
    23aa:	9a d6 4f fb 23       	call   0x23fb:0x4fd6
    23af:	c9                   	leave
    23b0:	ca 0e 00             	retf   0xe
    23b3:	c8 10 00 00          	enter  0x10,0x0
    23b7:	8b 46 16             	mov    ax,WORD PTR [bp+0x16]
    23ba:	8b 56 18             	mov    dx,WORD PTR [bp+0x18]
    23bd:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    23c0:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    23c3:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    23c6:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    23c9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    23cc:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    23cf:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    23d2:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    23d5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    23d8:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    23db:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    23de:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    23e1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    23e4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    23e7:	8d 7e f0             	lea    di,[bp-0x10]
    23ea:	16                   	push   ss
    23eb:	57                   	push   di
    23ec:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    23ef:	06                   	push   es
    23f0:	57                   	push   di
    23f1:	6a 00                	push   0x0
    23f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f6:	06                   	push   es
    23f7:	57                   	push   di
    23f8:	9a 97 44 1e 24       	call   0x241e:0x4497
    23fd:	c9                   	leave
    23fe:	ca 14 00             	retf   0x14
    2401:	55                   	push   bp
    2402:	89 e5                	mov    bp,sp
    2404:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2407:	06                   	push   es
    2408:	57                   	push   di
    2409:	9a 42 4f bb 24       	call   0x24bb:0x4f42
    240e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2411:	26 f6 85 09 01 20    	test   BYTE PTR es:[di+0x109],0x20
    2417:	75 07                	jne    0x2420
    2419:	06                   	push   es
    241a:	57                   	push   di
    241b:	9a 32 25 4d 24       	call   0x244d:0x2532
    2420:	c9                   	leave
    2421:	ca 04 00             	retf   0x4
    2424:	c8 08 00 00          	enter  0x8,0x0
    2428:	8d 7e f8             	lea    di,[bp-0x8]
    242b:	16                   	push   ss
    242c:	57                   	push   di
    242d:	ff 76 10             	push   WORD PTR [bp+0x10]
    2430:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2433:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2436:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2439:	ff 76 10             	push   WORD PTR [bp+0x10]
    243c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    243f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2442:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2445:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2448:	06                   	push   es
    2449:	57                   	push   di
    244a:	9a b3 23 43 25       	call   0x2543:0x23b3
    244f:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2452:	06                   	push   es
    2453:	57                   	push   di
    2454:	6a 08                	push   0x8
    2456:	9a 1b 16 7b 28       	call   0x287b:0x161b
    245b:	c9                   	leave
    245c:	ca 0c 00             	retf   0xc
    245f:	c8 02 00 00          	enter  0x2,0x0
    2463:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2467:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    246a:	c9                   	leave
    246b:	ca 06 00             	retf   0x6
    246e:	c8 02 00 00          	enter  0x2,0x0
    2472:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2476:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2479:	c9                   	leave
    247a:	ca 08 00             	retf   0x8
    247d:	c8 02 00 00          	enter  0x2,0x0
    2481:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2484:	26 8a 85 e5 00       	mov    al,BYTE PTR es:[di+0xe5]
    2489:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    248c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    248f:	c9                   	leave
    2490:	ca 04 00             	retf   0x4
    2493:	c8 02 00 00          	enter  0x2,0x0
    2497:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    249a:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    249f:	25 00 14             	and    ax,0x1400
    24a2:	3d 00 04             	cmp    ax,0x400
    24a5:	75 48                	jne    0x24ef
    24a7:	26 80 bd 3c 01 00    	cmp    BYTE PTR es:[di+0x13c],0x0
    24ad:	74 40                	je     0x24ef
    24af:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    24b4:	75 39                	jne    0x24ef
    24b6:	06                   	push   es
    24b7:	57                   	push   di
    24b8:	9a fa 64 86 25       	call   0x2586:0x64fa
    24bd:	08 c0                	or     al,al
    24bf:	74 2e                	je     0x24ef
    24c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c4:	26 f6 85 09 01 20    	test   BYTE PTR es:[di+0x109],0x20
    24ca:	75 27                	jne    0x24f3
    24cc:	ff 76 08             	push   WORD PTR [bp+0x8]
    24cf:	ff 76 06             	push   WORD PTR [bp+0x6]
    24d2:	9a 01 18 7e 2c       	call   0x2c7e:0x1801
    24d7:	89 c7                	mov    di,ax
    24d9:	8e c2                	mov    es,dx
    24db:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    24e0:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    24e5:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    24e8:	75 05                	jne    0x24ef
    24ea:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    24ed:	74 04                	je     0x24f3
    24ef:	b0 00                	mov    al,0x0
    24f1:	eb 02                	jmp    0x24f5
    24f3:	b0 01                	mov    al,0x1
    24f5:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    24f8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    24fb:	c9                   	leave
    24fc:	ca 04 00             	retf   0x4
    24ff:	55                   	push   bp
    2500:	89 e5                	mov    bp,sp
    2502:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2505:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2509:	c9                   	leave
    250a:	ca 0c 00             	retf   0xc
    250d:	55                   	push   bp
    250e:	89 e5                	mov    bp,sp
    2510:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2513:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2517:	c9                   	leave
    2518:	ca 0c 00             	retf   0xc
    251b:	55                   	push   bp
    251c:	89 e5                	mov    bp,sp
    251e:	c9                   	leave
    251f:	ca 10 00             	retf   0x10
    2522:	c8 02 00 00          	enter  0x2,0x0
    2526:	31 c0                	xor    ax,ax
    2528:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    252b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    252e:	c9                   	leave
    252f:	ca 04 00             	retf   0x4
    2532:	55                   	push   bp
    2533:	89 e5                	mov    bp,sp
    2535:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2538:	26 c6 85 3c 01 00    	mov    BYTE PTR es:[di+0x13c],0x0
    253e:	06                   	push   es
    253f:	57                   	push   di
    2540:	9a 1b 76 5a 25       	call   0x255a:0x761b
    2545:	c9                   	leave
    2546:	ca 04 00             	retf   0x4
    2549:	55                   	push   bp
    254a:	89 e5                	mov    bp,sp
    254c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    254f:	26 c6 85 3c 01 01    	mov    BYTE PTR es:[di+0x13c],0x1
    2555:	06                   	push   es
    2556:	57                   	push   di
    2557:	9a c1 77 6b 25       	call   0x256b:0x77c1
    255c:	c9                   	leave
    255d:	ca 04 00             	retf   0x4
    2560:	55                   	push   bp
    2561:	89 e5                	mov    bp,sp
    2563:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2566:	06                   	push   es
    2567:	57                   	push   di
    2568:	9a 49 25 c6 25       	call   0x25c6:0x2549
    256d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2570:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    2575:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    257a:	74 1f                	je     0x259b
    257c:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    2581:	06                   	push   es
    2582:	57                   	push   di
    2583:	9a b9 62 9f 27       	call   0x279f:0x62b9
    2588:	50                   	push   ax
    2589:	68 02 01             	push   0x102
    258c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    258f:	30 e4                	xor    ah,ah
    2591:	50                   	push   ax
    2592:	6a 00                	push   0x0
    2594:	6a 00                	push   0x0
    2596:	9a ff ff 00 00       	call   0x0:0xffff
    259b:	c9                   	leave
    259c:	ca 06 00             	retf   0x6
    259f:	55                   	push   bp
    25a0:	89 e5                	mov    bp,sp
    25a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a5:	26 c7 85 33 01 ff ff 	mov    WORD PTR es:[di+0x133],0xffff
    25ac:	26 c7 85 35 01 ff ff 	mov    WORD PTR es:[di+0x135],0xffff
    25b3:	26 c7 85 37 01 ff ff 	mov    WORD PTR es:[di+0x137],0xffff
    25ba:	26 c7 85 39 01 ff ff 	mov    WORD PTR es:[di+0x139],0xffff
    25c1:	06                   	push   es
    25c2:	57                   	push   di
    25c3:	9a c1 77 1e 26       	call   0x261e:0x77c1
    25c8:	c9                   	leave
    25c9:	ca 04 00             	retf   0x4
    25cc:	c8 08 00 00          	enter  0x8,0x0
    25d0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25d3:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    25d6:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    25d9:	06                   	push   es
    25da:	57                   	push   di
    25db:	9a 84 36 13 26       	call   0x2613:0x3684
    25e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    25e8:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    25ed:	2d 01 00             	sub    ax,0x1
    25f0:	83 da 00             	sbb    dx,0x0
    25f3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    25f6:	31 c0                	xor    ax,ax
    25f8:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    25fb:	7f 2b                	jg     0x2628
    25fd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2600:	eb 03                	jmp    0x2605
    2602:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2605:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2608:	99                   	cwd
    2609:	52                   	push   dx
    260a:	50                   	push   ax
    260b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    260e:	06                   	push   es
    260f:	57                   	push   di
    2610:	9a 09 36 30 26       	call   0x2630:0x3609
    2615:	50                   	push   ax
    2616:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2619:	06                   	push   es
    261a:	57                   	push   di
    261b:	9a c9 70 88 26       	call   0x2688:0x70c9
    2620:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2623:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2626:	75 da                	jne    0x2602
    2628:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    262b:	06                   	push   es
    262c:	57                   	push   di
    262d:	9a 97 36 48 26       	call   0x2648:0x3697
    2632:	c9                   	leave
    2633:	ca 08 00             	retf   0x8
    2636:	c8 08 00 00          	enter  0x8,0x0
    263a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    263d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2640:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2643:	06                   	push   es
    2644:	57                   	push   di
    2645:	9a 84 36 7d 26       	call   0x267d:0x3684
    264a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    264d:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    2652:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    2657:	2d 01 00             	sub    ax,0x1
    265a:	83 da 00             	sbb    dx,0x0
    265d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2660:	31 c0                	xor    ax,ax
    2662:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2665:	7f 2b                	jg     0x2692
    2667:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    266a:	eb 03                	jmp    0x266f
    266c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    266f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2672:	99                   	cwd
    2673:	52                   	push   dx
    2674:	50                   	push   ax
    2675:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2678:	06                   	push   es
    2679:	57                   	push   di
    267a:	9a 09 36 9a 26       	call   0x269a:0x3609
    267f:	50                   	push   ax
    2680:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2683:	06                   	push   es
    2684:	57                   	push   di
    2685:	9a a3 74 e7 26       	call   0x26e7:0x74a3
    268a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    268d:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2690:	75 da                	jne    0x266c
    2692:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2695:	06                   	push   es
    2696:	57                   	push   di
    2697:	9a 97 36 b2 26       	call   0x26b2:0x3697
    269c:	c9                   	leave
    269d:	ca 08 00             	retf   0x8
    26a0:	c8 08 00 00          	enter  0x8,0x0
    26a4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    26a7:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    26aa:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    26ad:	06                   	push   es
    26ae:	57                   	push   di
    26af:	9a 6d 45 f4 26       	call   0x26f4:0x456d
    26b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b7:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    26bc:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    26c1:	2d 01 00             	sub    ax,0x1
    26c4:	83 da 00             	sbb    dx,0x0
    26c7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    26ca:	31 c0                	xor    ax,ax
    26cc:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    26cf:	7f 2d                	jg     0x26fe
    26d1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26d4:	eb 03                	jmp    0x26d9
    26d6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    26d9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    26dc:	99                   	cwd
    26dd:	52                   	push   dx
    26de:	50                   	push   ax
    26df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e2:	06                   	push   es
    26e3:	57                   	push   di
    26e4:	9a 30 6e 53 27       	call   0x2753:0x6e30
    26e9:	99                   	cwd
    26ea:	52                   	push   dx
    26eb:	50                   	push   ax
    26ec:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    26ef:	06                   	push   es
    26f0:	57                   	push   di
    26f1:	9a cb 44 06 27       	call   0x2706:0x44cb
    26f6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    26f9:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    26fc:	75 d8                	jne    0x26d6
    26fe:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2701:	06                   	push   es
    2702:	57                   	push   di
    2703:	9a 80 45 1e 27       	call   0x271e:0x4580
    2708:	c9                   	leave
    2709:	ca 08 00             	retf   0x8
    270c:	c8 08 00 00          	enter  0x8,0x0
    2710:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2713:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2716:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2719:	06                   	push   es
    271a:	57                   	push   di
    271b:	9a 6d 45 60 27       	call   0x2760:0x456d
    2720:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2723:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    2728:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    272d:	2d 01 00             	sub    ax,0x1
    2730:	83 da 00             	sbb    dx,0x0
    2733:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2736:	31 c0                	xor    ax,ax
    2738:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    273b:	7f 2d                	jg     0x276a
    273d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2740:	eb 03                	jmp    0x2745
    2742:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2745:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2748:	99                   	cwd
    2749:	52                   	push   dx
    274a:	50                   	push   ax
    274b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    274e:	06                   	push   es
    274f:	57                   	push   di
    2750:	9a 8b 6e c6 27       	call   0x27c6:0x6e8b
    2755:	99                   	cwd
    2756:	52                   	push   dx
    2757:	50                   	push   ax
    2758:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    275b:	06                   	push   es
    275c:	57                   	push   di
    275d:	9a cb 44 72 27       	call   0x2772:0x44cb
    2762:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2765:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2768:	75 d8                	jne    0x2742
    276a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    276d:	06                   	push   es
    276e:	57                   	push   di
    276f:	9a 80 45 3a 2e       	call   0x2e3a:0x4580
    2774:	c9                   	leave
    2775:	ca 08 00             	retf   0x8
    2778:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
    277b:	6c                   	ins    BYTE PTR es:[di],dx
    277c:	57                   	push   di
    277d:	69 64 74 68 73       	imul   sp,WORD PTR [si+0x74],0x7368
    2782:	0a 52 6f             	or     dl,BYTE PTR [bp+si+0x6f]
    2785:	77 48                	ja     0x27cf
    2787:	65 69 67 68 74 73    	imul   sp,WORD PTR gs:[bx+0x68],0x7374
    278d:	c8 04 00 00          	enter  0x4,0x0
    2791:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2794:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2797:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279a:	06                   	push   es
    279b:	57                   	push   di
    279c:	9a 3a 27 5a 31       	call   0x315a:0x273a
    27a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a4:	26 80 bd 40 01 00    	cmp    BYTE PTR es:[di+0x140],0x0
    27aa:	75 03                	jne    0x27af
    27ac:	e9 83 00             	jmp    0x2832
    27af:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    27b2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    27b5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    27b8:	bf 78 27             	mov    di,0x2778
    27bb:	0e                   	push   cs
    27bc:	57                   	push   di
    27bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c0:	06                   	push   es
    27c1:	57                   	push   di
    27c2:	bf cc 25             	mov    di,0x25cc
    27c5:	b8 d3 27             	mov    ax,0x27d3
    27c8:	50                   	push   ax
    27c9:	57                   	push   di
    27ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27cd:	06                   	push   es
    27ce:	57                   	push   di
    27cf:	bf a0 26             	mov    di,0x26a0
    27d2:	b8 03 28             	mov    ax,0x2803
    27d5:	50                   	push   ax
    27d6:	57                   	push   di
    27d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27da:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    27df:	26 0b 85 ec 00       	or     ax,WORD PTR es:[di+0xec]
    27e4:	b0 00                	mov    al,0x0
    27e6:	74 01                	je     0x27e9
    27e8:	40                   	inc    ax
    27e9:	50                   	push   ax
    27ea:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27ed:	06                   	push   es
    27ee:	57                   	push   di
    27ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27f2:	26 ff 1d             	call   DWORD PTR es:[di]
    27f5:	bf 82 27             	mov    di,0x2782
    27f8:	0e                   	push   cs
    27f9:	57                   	push   di
    27fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fd:	06                   	push   es
    27fe:	57                   	push   di
    27ff:	bf 36 26             	mov    di,0x2636
    2802:	b8 10 28             	mov    ax,0x2810
    2805:	50                   	push   ax
    2806:	57                   	push   di
    2807:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    280a:	06                   	push   es
    280b:	57                   	push   di
    280c:	bf 0c 27             	mov    di,0x270c
    280f:	b8 55 28             	mov    ax,0x2855
    2812:	50                   	push   ax
    2813:	57                   	push   di
    2814:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2817:	26 8b 85 0e 01       	mov    ax,WORD PTR es:[di+0x10e]
    281c:	26 0b 85 10 01       	or     ax,WORD PTR es:[di+0x110]
    2821:	b0 00                	mov    al,0x0
    2823:	74 01                	je     0x2826
    2825:	40                   	inc    ax
    2826:	50                   	push   ax
    2827:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    282a:	06                   	push   es
    282b:	57                   	push   di
    282c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    282f:	26 ff 1d             	call   DWORD PTR es:[di]
    2832:	c9                   	leave
    2833:	ca 08 00             	retf   0x8
    2836:	55                   	push   bp
    2837:	89 e5                	mov    bp,sp
    2839:	c9                   	leave
    283a:	ca 0c 00             	retf   0xc
    283d:	55                   	push   bp
    283e:	89 e5                	mov    bp,sp
    2840:	c9                   	leave
    2841:	ca 0c 00             	retf   0xc
    2844:	c8 24 00 00          	enter  0x24,0x0
    2848:	8d 7e e4             	lea    di,[bp-0x1c]
    284b:	16                   	push   ss
    284c:	57                   	push   di
    284d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2850:	06                   	push   es
    2851:	57                   	push   di
    2852:	9a 4f 34 6f 28       	call   0x286f:0x344f
    2857:	8d 7e dc             	lea    di,[bp-0x24]
    285a:	16                   	push   ss
    285b:	57                   	push   di
    285c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    285f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2862:	8d 7e e4             	lea    di,[bp-0x1c]
    2865:	16                   	push   ss
    2866:	57                   	push   di
    2867:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    286a:	06                   	push   es
    286b:	57                   	push   di
    286c:	9a 26 32 b9 28       	call   0x28b9:0x3226
    2871:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2874:	06                   	push   es
    2875:	57                   	push   di
    2876:	6a 08                	push   0x8
    2878:	9a 1b 16 0e 2f       	call   0x2f0e:0x161b
    287d:	c9                   	leave
    287e:	ca 08 00             	retf   0x8
    2881:	c8 02 00 00          	enter  0x2,0x0
    2885:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2889:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    288c:	c9                   	leave
    288d:	ca 0c 00             	retf   0xc
    2890:	55                   	push   bp
    2891:	89 e5                	mov    bp,sp
    2893:	c9                   	leave
    2894:	ca 0c 00             	retf   0xc
    2897:	c8 28 00 00          	enter  0x28,0x0
    289b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289e:	26 8a 85 3f 01       	mov    al,BYTE PTR es:[di+0x13f]
    28a3:	88 46 e1             	mov    BYTE PTR [bp-0x1f],al
    28a6:	80 7e e1 00          	cmp    BYTE PTR [bp-0x1f],0x0
    28aa:	75 38                	jne    0x28e4
    28ac:	8d 7e e2             	lea    di,[bp-0x1e]
    28af:	16                   	push   ss
    28b0:	57                   	push   di
    28b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b4:	06                   	push   es
    28b5:	57                   	push   di
    28b6:	9a 20 36 e2 28       	call   0x28e2:0x3620
    28bb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28be:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28c1:	8d 7e e1             	lea    di,[bp-0x1f]
    28c4:	16                   	push   ss
    28c5:	57                   	push   di
    28c6:	8d 7e dc             	lea    di,[bp-0x24]
    28c9:	16                   	push   ss
    28ca:	57                   	push   di
    28cb:	8d 7e da             	lea    di,[bp-0x26]
    28ce:	16                   	push   ss
    28cf:	57                   	push   di
    28d0:	8d 7e d8             	lea    di,[bp-0x28]
    28d3:	16                   	push   ss
    28d4:	57                   	push   di
    28d5:	8d 7e e2             	lea    di,[bp-0x1e]
    28d8:	16                   	push   ss
    28d9:	57                   	push   di
    28da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28dd:	06                   	push   es
    28de:	57                   	push   di
    28df:	9a 36 38 33 29       	call   0x2933:0x3836
    28e4:	80 7e e1 00          	cmp    BYTE PTR [bp-0x1f],0x0
    28e8:	b0 00                	mov    al,0x0
    28ea:	74 01                	je     0x28ed
    28ec:	40                   	inc    ax
    28ed:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    28f0:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    28f3:	c9                   	leave
    28f4:	ca 08 00             	retf   0x8
    28f7:	c8 08 00 00          	enter  0x8,0x0
    28fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28fe:	26 80 bd 3c 01 00    	cmp    BYTE PTR es:[di+0x13c],0x0
    2904:	74 3e                	je     0x2944
    2906:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    290b:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    2910:	74 32                	je     0x2944
    2912:	8d 7e f8             	lea    di,[bp-0x8]
    2915:	16                   	push   ss
    2916:	57                   	push   di
    2917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    291a:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    291f:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    2924:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    2929:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    292e:	06                   	push   es
    292f:	57                   	push   di
    2930:	9a 24 24 42 29       	call   0x2942:0x2424
    2935:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2938:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    293d:	06                   	push   es
    293e:	57                   	push   di
    293f:	9a 41 1e d7 29       	call   0x29d7:0x1e41
    2944:	c9                   	leave
    2945:	ca 04 00             	retf   0x4
    2948:	c8 0e 00 00          	enter  0xe,0x0
    294c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    294f:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2953:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2957:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    295c:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    295f:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2962:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2965:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2969:	81 c7 de ff          	add    di,0xffde
    296d:	16                   	push   ss
    296e:	07                   	pop    es
    296f:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2973:	75 03                	jne    0x2978
    2975:	e9 de 00             	jmp    0x2a56
    2978:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    297b:	36 8b 45 1a          	mov    ax,WORD PTR ss:[di+0x1a]
    297f:	36 8b 55 1c          	mov    dx,WORD PTR ss:[di+0x1c]
    2983:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2986:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2989:	36 80 7d 20 00       	cmp    BYTE PTR ss:[di+0x20],0x0
    298e:	74 18                	je     0x29a8
    2990:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    2994:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    2998:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    299b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    299f:	06                   	push   es
    29a0:	57                   	push   di
    29a1:	9a da 13 bf 29       	call   0x29bf:0x13da
    29a6:	eb 19                	jmp    0x29c1
    29a8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    29ab:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    29af:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    29b3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    29b6:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    29ba:	06                   	push   es
    29bb:	57                   	push   di
    29bc:	9a da 13 06 2a       	call   0x2a06:0x13da
    29c1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    29c4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    29c7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    29ca:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    29ce:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    29d2:	06                   	push   es
    29d3:	57                   	push   di
    29d4:	9a 30 6e 3a 2a       	call   0x2a3a:0x6e30
    29d9:	8b d0                	mov    dx,ax
    29db:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    29de:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    29e2:	36 8b 45 de          	mov    ax,WORD PTR ss:[di-0x22]
    29e6:	d1 e8                	shr    ax,1
    29e8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    29eb:	36 03 45 14          	add    ax,WORD PTR ss:[di+0x14]
    29ef:	03 c2                	add    ax,dx
    29f1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    29f4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29f7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    29fa:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    29fe:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2a01:	06                   	push   es
    2a02:	57                   	push   di
    2a03:	9a b8 1d 1a 2a       	call   0x2a1a:0x1db8
    2a08:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a0b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a0e:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    2a12:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2a15:	06                   	push   es
    2a16:	57                   	push   di
    2a17:	9a 7b 1d b7 2a       	call   0x2ab7:0x1d7b
    2a1c:	83 46 fa 01          	add    WORD PTR [bp-0x6],0x1
    2a20:	83 56 fc 00          	adc    WORD PTR [bp-0x4],0x0
    2a24:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2a27:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2a2a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a2d:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2a31:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2a35:	06                   	push   es
    2a36:	57                   	push   di
    2a37:	9a 30 6e ea 2a       	call   0x2aea:0x6e30
    2a3c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a3f:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2a43:	36 03 45 de          	add    ax,WORD PTR ss:[di-0x22]
    2a47:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2a4a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a4d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a50:	36 3b 45 10          	cmp    ax,WORD PTR ss:[di+0x10]
    2a54:	7e 9e                	jle    0x29f4
    2a56:	c9                   	leave
    2a57:	c2 02 00             	ret    0x2
    2a5a:	c8 0e 00 00          	enter  0xe,0x0
    2a5e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a61:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2a65:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2a69:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2a6e:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2a71:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2a74:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a77:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2a7b:	81 c7 de ff          	add    di,0xffde
    2a7f:	16                   	push   ss
    2a80:	07                   	pop    es
    2a81:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    2a86:	75 03                	jne    0x2a8b
    2a88:	e9 de 00             	jmp    0x2b69
    2a8b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a8e:	36 8b 45 16          	mov    ax,WORD PTR ss:[di+0x16]
    2a92:	36 8b 55 18          	mov    dx,WORD PTR ss:[di+0x18]
    2a96:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2a99:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2a9c:	36 80 7d 1e 00       	cmp    BYTE PTR ss:[di+0x1e],0x0
    2aa1:	74 18                	je     0x2abb
    2aa3:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    2aa7:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    2aab:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2aae:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2ab2:	06                   	push   es
    2ab3:	57                   	push   di
    2ab4:	9a da 13 d2 2a       	call   0x2ad2:0x13da
    2ab9:	eb 19                	jmp    0x2ad4
    2abb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2abe:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    2ac2:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    2ac6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2ac9:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2acd:	06                   	push   es
    2ace:	57                   	push   di
    2acf:	9a da 13 19 2b       	call   0x2b19:0x13da
    2ad4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ad7:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2ada:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2add:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2ae1:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2ae5:	06                   	push   es
    2ae6:	57                   	push   di
    2ae7:	9a 8b 6e 4d 2b       	call   0x2b4d:0x6e8b
    2aec:	8b d0                	mov    dx,ax
    2aee:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2af1:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2af5:	36 8b 45 e0          	mov    ax,WORD PTR ss:[di-0x20]
    2af9:	d1 e8                	shr    ax,1
    2afb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2afe:	36 03 45 12          	add    ax,WORD PTR ss:[di+0x12]
    2b02:	03 c2                	add    ax,dx
    2b04:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2b07:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b0a:	36 ff 75 14          	push   WORD PTR ss:[di+0x14]
    2b0e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b11:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2b14:	06                   	push   es
    2b15:	57                   	push   di
    2b16:	9a b8 1d 2d 2b       	call   0x2b2d:0x1db8
    2b1b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b1e:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    2b22:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b25:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2b28:	06                   	push   es
    2b29:	57                   	push   di
    2b2a:	9a 7b 1d b5 2b       	call   0x2bb5:0x1d7b
    2b2f:	83 46 fa 01          	add    WORD PTR [bp-0x6],0x1
    2b33:	83 56 fc 00          	adc    WORD PTR [bp-0x4],0x0
    2b37:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2b3a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2b3d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b40:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2b44:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2b48:	06                   	push   es
    2b49:	57                   	push   di
    2b4a:	9a 8b 6e 18 2c       	call   0x2c18:0x6e8b
    2b4f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b52:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    2b56:	36 03 45 e0          	add    ax,WORD PTR ss:[di-0x20]
    2b5a:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2b5d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b60:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b63:	36 3b 45 0e          	cmp    ax,WORD PTR ss:[di+0xe]
    2b67:	7e 9e                	jle    0x2b07
    2b69:	c9                   	leave
    2b6a:	c2 02 00             	ret    0x2
    2b6d:	c8 06 00 00          	enter  0x6,0x0
    2b71:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b74:	81 c7 de ff          	add    di,0xffde
    2b78:	16                   	push   ss
    2b79:	07                   	pop    es
    2b7a:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2b7e:	75 07                	jne    0x2b87
    2b80:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    2b85:	74 10                	je     0x2b97
    2b87:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    2b8a:	3b 46 10             	cmp    ax,WORD PTR [bp+0x10]
    2b8d:	74 08                	je     0x2b97
    2b8f:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    2b92:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    2b95:	75 02                	jne    0x2b99
    2b97:	eb 36                	jmp    0x2bcf
    2b99:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2b9c:	36 ff 75 de          	push   WORD PTR ss:[di-0x22]
    2ba0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2ba3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2ba7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2bac:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2bb0:	06                   	push   es
    2bb1:	57                   	push   di
    2bb2:	9a f5 14 56 2c       	call   0x2c56:0x14f5
    2bb7:	80 7e 20 00          	cmp    BYTE PTR [bp+0x20],0x0
    2bbb:	75 0a                	jne    0x2bc7
    2bbd:	55                   	push   bp
    2bbe:	e8 87 fd             	call   0x2948
    2bc1:	55                   	push   bp
    2bc2:	e8 95 fe             	call   0x2a5a
    2bc5:	eb 08                	jmp    0x2bcf
    2bc7:	55                   	push   bp
    2bc8:	e8 8f fe             	call   0x2a5a
    2bcb:	55                   	push   bp
    2bcc:	e8 79 fd             	call   0x2948
    2bcf:	c9                   	leave
    2bd0:	c2 1e 00             	ret    0x1e
    2bd3:	c8 22 00 00          	enter  0x22,0x0
    2bd7:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    2bda:	8b 56 16             	mov    dx,WORD PTR [bp+0x16]
    2bdd:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2be0:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2be3:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    2be6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2be9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2bec:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2bef:	7c 03                	jl     0x2bf4
    2bf1:	e9 f4 02             	jmp    0x2ee8
    2bf4:	8b 46 18             	mov    ax,WORD PTR [bp+0x18]
    2bf7:	8b 56 1a             	mov    dx,WORD PTR [bp+0x1a]
    2bfa:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2bfd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2c00:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    2c03:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2c06:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c09:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2c0c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2c0f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2c13:	06                   	push   es
    2c14:	57                   	push   di
    2c15:	9a 8b 6e 3d 2c       	call   0x2c3d:0x6e8b
    2c1a:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    2c1d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2c20:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2c23:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    2c26:	7c 03                	jl     0x2c2b
    2c28:	e9 a5 02             	jmp    0x2ed0
    2c2b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c2e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c31:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2c34:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2c38:	06                   	push   es
    2c39:	57                   	push   di
    2c3a:	9a 30 6e 1d 2f       	call   0x2f1d:0x6e30
    2c3f:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    2c42:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2c45:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2c48:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2c4c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2c51:	06                   	push   es
    2c52:	57                   	push   di
    2c53:	9a d2 21 68 2d       	call   0x2d68:0x21d2
    2c58:	50                   	push   ax
    2c59:	8d 7e f0             	lea    di,[bp-0x10]
    2c5c:	16                   	push   ss
    2c5d:	57                   	push   di
    2c5e:	9a ff ff 00 00       	call   0x0:0xffff
    2c63:	09 c0                	or     ax,ax
    2c65:	75 03                	jne    0x2c6a
    2c67:	e9 4e 02             	jmp    0x2eb8
    2c6a:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    2c6d:	88 46 ef             	mov    BYTE PTR [bp-0x11],al
    2c70:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2c73:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    2c77:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    2c7b:	9a 01 18 4b 64       	call   0x644b:0x1801
    2c80:	89 c7                	mov    di,ax
    2c82:	8e c2                	mov    es,dx
    2c84:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    2c89:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    2c8e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2c91:	36 3b 55 08          	cmp    dx,WORD PTR ss:[di+0x8]
    2c95:	75 06                	jne    0x2c9d
    2c97:	36 3b 45 06          	cmp    ax,WORD PTR ss:[di+0x6]
    2c9b:	74 04                	je     0x2ca1
    2c9d:	b0 00                	mov    al,0x0
    2c9f:	eb 02                	jmp    0x2ca3
    2ca1:	b0 01                	mov    al,0x1
    2ca3:	88 46 ee             	mov    BYTE PTR [bp-0x12],al
    2ca6:	80 7e ee 00          	cmp    BYTE PTR [bp-0x12],0x0
    2caa:	74 33                	je     0x2cdf
    2cac:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2caf:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2cb2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2cb5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2cb9:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    2cbe:	75 1f                	jne    0x2cdf
    2cc0:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    2cc5:	75 18                	jne    0x2cdf
    2cc7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cca:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2ccd:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    2cd2:	75 0b                	jne    0x2cdf
    2cd4:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    2cd9:	75 04                	jne    0x2cdf
    2cdb:	80 4e ef 02          	or     BYTE PTR [bp-0x11],0x2
    2cdf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ce2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ce5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2ce8:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2ceb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2cee:	81 c7 ce ff          	add    di,0xffce
    2cf2:	16                   	push   ss
    2cf3:	57                   	push   di
    2cf4:	e8 53 e3             	call   0x104a
    2cf7:	08 c0                	or     al,al
    2cf9:	74 04                	je     0x2cff
    2cfb:	80 4e ef 01          	or     BYTE PTR [bp-0x11],0x1
    2cff:	f6 46 ef 02          	test   BYTE PTR [bp-0x11],0x2
    2d03:	74 21                	je     0x2d26
    2d05:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d08:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d0c:	26 f6 85 09 01 04    	test   BYTE PTR es:[di+0x109],0x4
    2d12:	74 12                	je     0x2d26
    2d14:	26 80 bd 3c 01 00    	cmp    BYTE PTR es:[di+0x13c],0x0
    2d1a:	74 0a                	je     0x2d26
    2d1c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2d21:	75 03                	jne    0x2d26
    2d23:	e9 92 01             	jmp    0x2eb8
    2d26:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d29:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d2d:	26 80 bd 3b 01 00    	cmp    BYTE PTR es:[di+0x13b],0x0
    2d33:	75 0a                	jne    0x2d3f
    2d35:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2d3a:	75 03                	jne    0x2d3f
    2d3c:	e9 93 00             	jmp    0x2dd2
    2d3f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d42:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d46:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2d4b:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    2d4e:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    2d51:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d54:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d58:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2d5c:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2d60:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2d63:	06                   	push   es
    2d64:	57                   	push   di
    2d65:	9a 99 20 99 2d       	call   0x2d99:0x2099
    2d6a:	f6 46 ef 01          	test   BYTE PTR [bp-0x11],0x1
    2d6e:	74 3f                	je     0x2daf
    2d70:	f6 46 ef 02          	test   BYTE PTR [bp-0x11],0x2
    2d74:	74 13                	je     0x2d89
    2d76:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d79:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d7d:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    2d82:	25 20 10             	and    ax,0x1020
    2d85:	09 c0                	or     ax,ax
    2d87:	74 26                	je     0x2daf
    2d89:	6a ff                	push   0xffff
    2d8b:	6a f2                	push   0xfff2
    2d8d:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2d90:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2d94:	06                   	push   es
    2d95:	57                   	push   di
    2d96:	9a 84 16 ab 2d       	call   0x2dab:0x1684
    2d9b:	6a ff                	push   0xffff
    2d9d:	6a f1                	push   0xfff1
    2d9f:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2da2:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2da6:	06                   	push   es
    2da7:	57                   	push   di
    2da8:	9a df 0f c1 2d       	call   0x2dc1:0xfdf
    2dad:	eb 14                	jmp    0x2dc3
    2daf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2db2:	ff 76 08             	push   WORD PTR [bp+0x8]
    2db5:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2db8:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2dbc:	06                   	push   es
    2dbd:	57                   	push   di
    2dbe:	9a 84 16 d0 2d       	call   0x2dd0:0x1684
    2dc3:	8d 7e f0             	lea    di,[bp-0x10]
    2dc6:	16                   	push   ss
    2dc7:	57                   	push   di
    2dc8:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2dcb:	06                   	push   es
    2dcc:	57                   	push   di
    2dcd:	9a e5 1c 2d 2e       	call   0x2e2d:0x1ce5
    2dd2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2dd5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2dd8:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2ddb:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2dde:	8d 7e f0             	lea    di,[bp-0x10]
    2de1:	16                   	push   ss
    2de2:	57                   	push   di
    2de3:	8a 46 ef             	mov    al,BYTE PTR [bp-0x11]
    2de6:	50                   	push   ax
    2de7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2dea:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2dee:	06                   	push   es
    2def:	57                   	push   di
    2df0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2df3:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    2df8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2dfb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2dff:	26 80 bd 3b 01 00    	cmp    BYTE PTR es:[di+0x13b],0x0
    2e05:	74 69                	je     0x2e70
    2e07:	f6 46 ef 04          	test   BYTE PTR [bp-0x11],0x4
    2e0b:	74 63                	je     0x2e70
    2e0d:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    2e13:	74 5b                	je     0x2e70
    2e15:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2e1a:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    2e1d:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    2e20:	6a ff                	push   0xffff
    2e22:	6a eb                	push   0xffeb
    2e24:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2e28:	06                   	push   es
    2e29:	57                   	push   di
    2e2a:	9a da 13 6e 2e       	call   0x2e6e:0x13da
    2e2f:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2e32:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2e35:	48                   	dec    ax
    2e36:	50                   	push   ax
    2e37:	9a 6e 06 57 2e       	call   0x2e57:0x66e
    2e3c:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2e3f:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2e42:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2e45:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    2e48:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    2e4b:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    2e4e:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2e51:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2e54:	9a 6e 06 ca 31       	call   0x31ca:0x66e
    2e59:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2e5c:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    2e5f:	8d 7e de             	lea    di,[bp-0x22]
    2e62:	16                   	push   ss
    2e63:	57                   	push   di
    2e64:	6a 02                	push   0x2
    2e66:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2e69:	06                   	push   es
    2e6a:	57                   	push   di
    2e6b:	9a e1 1d ab 2e       	call   0x2eab:0x1de1
    2e70:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2e73:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2e77:	26 80 bd 3b 01 00    	cmp    BYTE PTR es:[di+0x13b],0x0
    2e7d:	74 39                	je     0x2eb8
    2e7f:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2e84:	75 32                	jne    0x2eb8
    2e86:	f6 46 ef 02          	test   BYTE PTR [bp-0x11],0x2
    2e8a:	74 2c                	je     0x2eb8
    2e8c:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    2e91:	25 00 24             	and    ax,0x2400
    2e94:	3d 00 24             	cmp    ax,0x2400
    2e97:	74 1f                	je     0x2eb8
    2e99:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    2e9f:	75 17                	jne    0x2eb8
    2ea1:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2ea6:	06                   	push   es
    2ea7:	57                   	push   di
    2ea8:	9a d2 21 02 2f       	call   0x2f02:0x21d2
    2ead:	50                   	push   ax
    2eae:	8d 7e f0             	lea    di,[bp-0x10]
    2eb1:	16                   	push   ss
    2eb2:	57                   	push   di
    2eb3:	9a ff ff 00 00       	call   0x0:0xffff
    2eb8:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2ebb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2ebe:	36 03 45 de          	add    ax,WORD PTR ss:[di-0x22]
    2ec2:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2ec5:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    2ec9:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    2ecd:	e9 50 fd             	jmp    0x2c20
    2ed0:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2ed3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2ed6:	36 03 45 e0          	add    ax,WORD PTR ss:[di-0x20]
    2eda:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2edd:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    2ee1:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    2ee5:	e9 01 fd             	jmp    0x2be9
    2ee8:	c9                   	leave
    2ee9:	c2 18 00             	ret    0x18
    2eec:	c8 52 00 00          	enter  0x52,0x0
    2ef0:	8d 7e b6             	lea    di,[bp-0x4a]
    2ef3:	16                   	push   ss
    2ef4:	57                   	push   di
    2ef5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef8:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2efd:	06                   	push   es
    2efe:	57                   	push   di
    2eff:	9a ae 21 37 2f       	call   0x2f37:0x21ae
    2f04:	8d 7e c6             	lea    di,[bp-0x3a]
    2f07:	16                   	push   ss
    2f08:	57                   	push   di
    2f09:	6a 08                	push   0x8
    2f0b:	9a 1b 16 7f 30       	call   0x307f:0x161b
    2f10:	8d 7e de             	lea    di,[bp-0x22]
    2f13:	16                   	push   ss
    2f14:	57                   	push   di
    2f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f18:	06                   	push   es
    2f19:	57                   	push   di
    2f1a:	9a 4f 34 73 30       	call   0x3073:0x344f
    2f1f:	c7 46 fa c0 c0       	mov    WORD PTR [bp-0x6],0xc0c0
    2f24:	c7 46 fc c0 00       	mov    WORD PTR [bp-0x4],0xc0
    2f29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f2c:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2f30:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    2f34:	9a a5 0c 92 31       	call   0x3192:0xca5
    2f39:	81 fa c0 00          	cmp    dx,0xc0
    2f3d:	75 0f                	jne    0x2f4e
    2f3f:	3d c0 c0             	cmp    ax,0xc0c0
    2f42:	75 0a                	jne    0x2f4e
    2f44:	c7 46 fa 80 80       	mov    WORD PTR [bp-0x6],0x8080
    2f49:	c7 46 fc 80 00       	mov    WORD PTR [bp-0x4],0x80
    2f4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f51:	26 f6 85 08 01 01    	test   BYTE PTR es:[di+0x108],0x1
    2f57:	b0 00                	mov    al,0x0
    2f59:	74 01                	je     0x2f5c
    2f5b:	40                   	inc    ax
    2f5c:	50                   	push   ax
    2f5d:	26 f6 85 08 01 02    	test   BYTE PTR es:[di+0x108],0x2
    2f63:	b0 00                	mov    al,0x0
    2f65:	74 01                	je     0x2f68
    2f67:	40                   	inc    ax
    2f68:	50                   	push   ax
    2f69:	6a 00                	push   0x0
    2f6b:	6a 00                	push   0x0
    2f6d:	6a 00                	push   0x0
    2f6f:	6a 00                	push   0x0
    2f71:	6a 00                	push   0x0
    2f73:	6a 00                	push   0x0
    2f75:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    2f78:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    2f7b:	6a 00                	push   0x0
    2f7d:	6a 00                	push   0x0
    2f7f:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    2f84:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    2f89:	55                   	push   bp
    2f8a:	e8 e0 fb             	call   0x2b6d
    2f8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f90:	26 f6 85 08 01 01    	test   BYTE PTR es:[di+0x108],0x1
    2f96:	b0 00                	mov    al,0x0
    2f98:	74 01                	je     0x2f9b
    2f9a:	40                   	inc    ax
    2f9b:	50                   	push   ax
    2f9c:	26 f6 85 08 01 02    	test   BYTE PTR es:[di+0x108],0x2
    2fa2:	b0 00                	mov    al,0x0
    2fa4:	74 01                	je     0x2fa7
    2fa6:	40                   	inc    ax
    2fa7:	50                   	push   ax
    2fa8:	26 ff b5 15 01       	push   WORD PTR es:[di+0x115]
    2fad:	26 ff b5 13 01       	push   WORD PTR es:[di+0x113]
    2fb2:	6a 00                	push   0x0
    2fb4:	6a 00                	push   0x0
    2fb6:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    2fb9:	6a 00                	push   0x0
    2fbb:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    2fbe:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    2fc1:	6a 00                	push   0x0
    2fc3:	6a 00                	push   0x0
    2fc5:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    2fca:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    2fcf:	55                   	push   bp
    2fd0:	e8 9a fb             	call   0x2b6d
    2fd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd6:	26 f6 85 08 01 01    	test   BYTE PTR es:[di+0x108],0x1
    2fdc:	b0 00                	mov    al,0x0
    2fde:	74 01                	je     0x2fe1
    2fe0:	40                   	inc    ax
    2fe1:	50                   	push   ax
    2fe2:	26 f6 85 08 01 02    	test   BYTE PTR es:[di+0x108],0x2
    2fe8:	b0 00                	mov    al,0x0
    2fea:	74 01                	je     0x2fed
    2fec:	40                   	inc    ax
    2fed:	50                   	push   ax
    2fee:	6a 00                	push   0x0
    2ff0:	6a 00                	push   0x0
    2ff2:	26 ff b5 19 01       	push   WORD PTR es:[di+0x119]
    2ff7:	26 ff b5 17 01       	push   WORD PTR es:[di+0x117]
    2ffc:	6a 00                	push   0x0
    2ffe:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3001:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    3004:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3007:	6a 00                	push   0x0
    3009:	6a 00                	push   0x0
    300b:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    3010:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    3015:	55                   	push   bp
    3016:	e8 54 fb             	call   0x2b6d
    3019:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    301c:	26 f6 85 08 01 04    	test   BYTE PTR es:[di+0x108],0x4
    3022:	b0 00                	mov    al,0x0
    3024:	74 01                	je     0x3027
    3026:	40                   	inc    ax
    3027:	50                   	push   ax
    3028:	26 f6 85 08 01 08    	test   BYTE PTR es:[di+0x108],0x8
    302e:	b0 00                	mov    al,0x0
    3030:	74 01                	je     0x3033
    3032:	40                   	inc    ax
    3033:	50                   	push   ax
    3034:	26 ff b5 15 01       	push   WORD PTR es:[di+0x115]
    3039:	26 ff b5 13 01       	push   WORD PTR es:[di+0x113]
    303e:	26 ff b5 19 01       	push   WORD PTR es:[di+0x119]
    3043:	26 ff b5 17 01       	push   WORD PTR es:[di+0x117]
    3048:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    304b:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    304e:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3051:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3054:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3057:	ff 76 fa             	push   WORD PTR [bp-0x6]
    305a:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    305e:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    3062:	55                   	push   bp
    3063:	e8 07 fb             	call   0x2b6d
    3066:	8d 7e ae             	lea    di,[bp-0x52]
    3069:	16                   	push   ss
    306a:	57                   	push   di
    306b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    306e:	06                   	push   es
    306f:	57                   	push   di
    3070:	9a e6 6e 6d 31       	call   0x316d:0x6ee6
    3075:	8d 7e ce             	lea    di,[bp-0x32]
    3078:	16                   	push   ss
    3079:	57                   	push   di
    307a:	6a 10                	push   0x10
    307c:	9a 1b 16 20 37       	call   0x3720:0x161b
    3081:	6a 00                	push   0x0
    3083:	6a 00                	push   0x0
    3085:	6a 00                	push   0x0
    3087:	6a 00                	push   0x0
    3089:	6a 00                	push   0x0
    308b:	6a 00                	push   0x0
    308d:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    3090:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3093:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3096:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    309b:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    30a0:	6a 04                	push   0x4
    30a2:	55                   	push   bp
    30a3:	e8 2d fb             	call   0x2bd3
    30a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30a9:	26 ff b5 15 01       	push   WORD PTR es:[di+0x115]
    30ae:	26 ff b5 13 01       	push   WORD PTR es:[di+0x113]
    30b3:	6a 00                	push   0x0
    30b5:	6a 00                	push   0x0
    30b7:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    30ba:	26 2b 85 3d 01       	sub    ax,WORD PTR es:[di+0x13d]
    30bf:	50                   	push   ax
    30c0:	6a 00                	push   0x0
    30c2:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    30c5:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    30c8:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    30cd:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    30d2:	6a 04                	push   0x4
    30d4:	55                   	push   bp
    30d5:	e8 fb fa             	call   0x2bd3
    30d8:	6a 00                	push   0x0
    30da:	6a 00                	push   0x0
    30dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30df:	26 ff b5 19 01       	push   WORD PTR es:[di+0x119]
    30e4:	26 ff b5 17 01       	push   WORD PTR es:[di+0x117]
    30e9:	6a 00                	push   0x0
    30eb:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    30ee:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    30f1:	ff 76 e8             	push   WORD PTR [bp-0x18]
    30f4:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    30f9:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    30fe:	6a 04                	push   0x4
    3100:	55                   	push   bp
    3101:	e8 cf fa             	call   0x2bd3
    3104:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3107:	26 ff b5 15 01       	push   WORD PTR es:[di+0x115]
    310c:	26 ff b5 13 01       	push   WORD PTR es:[di+0x113]
    3111:	26 ff b5 19 01       	push   WORD PTR es:[di+0x119]
    3116:	26 ff b5 17 01       	push   WORD PTR es:[di+0x117]
    311b:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    311e:	26 2b 85 3d 01       	sub    ax,WORD PTR es:[di+0x13d]
    3123:	50                   	push   ax
    3124:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3127:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    312a:	ff 76 e8             	push   WORD PTR [bp-0x18]
    312d:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    3131:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    3135:	6a 00                	push   0x0
    3137:	55                   	push   bp
    3138:	e8 98 fa             	call   0x2bd3
    313b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    313e:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3143:	75 4f                	jne    0x3194
    3145:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    314b:	74 47                	je     0x3194
    314d:	26 80 bd 3b 01 00    	cmp    BYTE PTR es:[di+0x13b],0x0
    3153:	74 3f                	je     0x3194
    3155:	06                   	push   es
    3156:	57                   	push   di
    3157:	9a 58 62 5f 34       	call   0x345f:0x6258
    315c:	08 c0                	or     al,al
    315e:	74 34                	je     0x3194
    3160:	8d 7e ae             	lea    di,[bp-0x52]
    3163:	16                   	push   ss
    3164:	57                   	push   di
    3165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3168:	06                   	push   es
    3169:	57                   	push   di
    316a:	9a e6 6e 7e 31       	call   0x317e:0x6ee6
    316f:	8d 7e be             	lea    di,[bp-0x42]
    3172:	16                   	push   ss
    3173:	57                   	push   di
    3174:	6a 00                	push   0x0
    3176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3179:	06                   	push   es
    317a:	57                   	push   di
    317b:	9a 97 44 da 32       	call   0x32da:0x4497
    3180:	8d 7e be             	lea    di,[bp-0x42]
    3183:	16                   	push   ss
    3184:	57                   	push   di
    3185:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3188:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    318d:	06                   	push   es
    318e:	57                   	push   di
    318f:	9a 66 1c b5 31       	call   0x31b5:0x1c66
    3194:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    3197:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    319a:	7d 3f                	jge    0x31db
    319c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    319f:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    31a3:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    31a7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    31ac:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    31b0:	06                   	push   es
    31b1:	57                   	push   di
    31b2:	9a 84 16 d9 31       	call   0x31d9:0x1684
    31b7:	8d 7e b6             	lea    di,[bp-0x4a]
    31ba:	16                   	push   ss
    31bb:	57                   	push   di
    31bc:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    31bf:	6a 00                	push   0x0
    31c1:	ff 76 ec             	push   WORD PTR [bp-0x14]
    31c4:	ff 76 e8             	push   WORD PTR [bp-0x18]
    31c7:	9a 88 06 11 32       	call   0x3211:0x688
    31cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31cf:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    31d4:	06                   	push   es
    31d5:	57                   	push   di
    31d6:	9a e5 1c fc 31       	call   0x31fc:0x1ce5
    31db:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    31de:	3b 46 ea             	cmp    ax,WORD PTR [bp-0x16]
    31e1:	7d 3f                	jge    0x3222
    31e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e6:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    31ea:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    31ee:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    31f3:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    31f7:	06                   	push   es
    31f8:	57                   	push   di
    31f9:	9a 84 16 20 32       	call   0x3220:0x1684
    31fe:	8d 7e b6             	lea    di,[bp-0x4a]
    3201:	16                   	push   ss
    3202:	57                   	push   di
    3203:	6a 00                	push   0x0
    3205:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3208:	ff 76 ec             	push   WORD PTR [bp-0x14]
    320b:	ff 76 ea             	push   WORD PTR [bp-0x16]
    320e:	9a 88 06 d6 52       	call   0x52d6:0x688
    3213:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3216:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    321b:	06                   	push   es
    321c:	57                   	push   di
    321d:	9a e5 1c 8a 3f       	call   0x3f8a:0x1ce5
    3222:	c9                   	leave
    3223:	ca 04 00             	retf   0x4
    3226:	c8 16 00 00          	enter  0x16,0x0
    322a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    322d:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    3230:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    3233:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    3236:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    323a:	7d 1f                	jge    0x325b
    323c:	31 c0                	xor    ax,ax
    323e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3241:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3244:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3247:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    324c:	48                   	dec    ax
    324d:	99                   	cwd
    324e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3251:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3254:	31 c0                	xor    ax,ax
    3256:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3259:	eb 33                	jmp    0x328e
    325b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    325e:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    3263:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    3268:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    326b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    326e:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    3273:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    3278:	2d 01 00             	sub    ax,0x1
    327b:	83 da 00             	sbb    dx,0x0
    327e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3281:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3284:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3287:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    328b:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    328e:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    3291:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    3294:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3297:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    329a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    329d:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    32a0:	3b 56 ec             	cmp    dx,WORD PTR [bp-0x14]
    32a3:	7f 5a                	jg     0x32ff
    32a5:	7c 05                	jl     0x32ac
    32a7:	3b 46 ea             	cmp    ax,WORD PTR [bp-0x16]
    32aa:	77 53                	ja     0x32ff
    32ac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    32af:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    32b2:	eb 08                	jmp    0x32bc
    32b4:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    32b8:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    32bc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    32bf:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    32c2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    32c5:	26 89 05             	mov    WORD PTR es:[di],ax
    32c8:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    32cc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    32cf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    32d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32d5:	06                   	push   es
    32d6:	57                   	push   di
    32d7:	9a 30 6e ca 33       	call   0x33ca:0x6e30
    32dc:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    32df:	26 03 05             	add    ax,WORD PTR es:[di]
    32e2:	01 46 f2             	add    WORD PTR [bp-0xe],ax
    32e5:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    32e8:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    32eb:	7d 02                	jge    0x32ef
    32ed:	eb 10                	jmp    0x32ff
    32ef:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    32f2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    32f5:	3b 56 ec             	cmp    dx,WORD PTR [bp-0x14]
    32f8:	75 ba                	jne    0x32b4
    32fa:	3b 46 ea             	cmp    ax,WORD PTR [bp-0x16]
    32fd:	75 b5                	jne    0x32b4
    32ff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3302:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3305:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    3308:	7f 07                	jg     0x3311
    330a:	7c 13                	jl     0x331f
    330c:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    330f:	76 0e                	jbe    0x331f
    3311:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3314:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    3319:	26 c7 45 02 ff ff    	mov    WORD PTR es:[di+0x2],0xffff
    331f:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    3322:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3325:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    3329:	7d 1f                	jge    0x334a
    332b:	31 c0                	xor    ax,ax
    332d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3330:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3333:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3336:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    333b:	48                   	dec    ax
    333c:	99                   	cwd
    333d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3340:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3343:	31 c0                	xor    ax,ax
    3345:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3348:	eb 33                	jmp    0x337d
    334a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    334d:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    3352:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    3357:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    335a:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    335d:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3362:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    3367:	2d 01 00             	sub    ax,0x1
    336a:	83 da 00             	sbb    dx,0x0
    336d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3370:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3373:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3376:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    337a:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    337d:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    3380:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    3383:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3386:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    3389:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    338c:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    338f:	3b 56 ec             	cmp    dx,WORD PTR [bp-0x14]
    3392:	7f 5c                	jg     0x33f0
    3394:	7c 05                	jl     0x339b
    3396:	3b 46 ea             	cmp    ax,WORD PTR [bp-0x16]
    3399:	77 55                	ja     0x33f0
    339b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    339e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    33a1:	eb 08                	jmp    0x33ab
    33a3:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    33a7:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    33ab:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33ae:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33b1:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    33b4:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    33b8:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    33bc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    33bf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    33c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c5:	06                   	push   es
    33c6:	57                   	push   di
    33c7:	9a 8b 6e 75 34       	call   0x3475:0x6e8b
    33cc:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    33cf:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    33d3:	01 46 f2             	add    WORD PTR [bp-0xe],ax
    33d6:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    33d9:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    33dc:	7d 02                	jge    0x33e0
    33de:	eb 10                	jmp    0x33f0
    33e0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33e3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33e6:	3b 56 ec             	cmp    dx,WORD PTR [bp-0x14]
    33e9:	75 b8                	jne    0x33a3
    33eb:	3b 46 ea             	cmp    ax,WORD PTR [bp-0x16]
    33ee:	75 b3                	jne    0x33a3
    33f0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33f3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33f6:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    33f9:	7f 07                	jg     0x3402
    33fb:	7c 14                	jl     0x3411
    33fd:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    3400:	76 0f                	jbe    0x3411
    3402:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3405:	26 c7 45 04 ff ff    	mov    WORD PTR es:[di+0x4],0xffff
    340b:	26 c7 45 06 ff ff    	mov    WORD PTR es:[di+0x6],0xffff
    3411:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3414:	26 83 7d 06 ff       	cmp    WORD PTR es:[di+0x6],0xffff
    3419:	75 14                	jne    0x342f
    341b:	26 83 7d 04 ff       	cmp    WORD PTR es:[di+0x4],0xffff
    3420:	75 0d                	jne    0x342f
    3422:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    3427:	26 c7 45 02 ff ff    	mov    WORD PTR es:[di+0x2],0xffff
    342d:	eb 1c                	jmp    0x344b
    342f:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3432:	26 83 7d 02 ff       	cmp    WORD PTR es:[di+0x2],0xffff
    3437:	75 12                	jne    0x344b
    3439:	26 83 3d ff          	cmp    WORD PTR es:[di],0xffff
    343d:	75 0c                	jne    0x344b
    343f:	26 c7 45 04 ff ff    	mov    WORD PTR es:[di+0x4],0xffff
    3445:	26 c7 45 06 ff ff    	mov    WORD PTR es:[di+0x6],0xffff
    344b:	c9                   	leave
    344c:	ca 0c 00             	retf   0xc
    344f:	55                   	push   bp
    3450:	89 e5                	mov    bp,sp
    3452:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3455:	06                   	push   es
    3456:	57                   	push   di
    3457:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    345a:	06                   	push   es
    345b:	57                   	push   di
    345c:	9a a9 18 6a 34       	call   0x346a:0x18a9
    3461:	50                   	push   ax
    3462:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3465:	06                   	push   es
    3466:	57                   	push   di
    3467:	9a f4 18 87 38       	call   0x3887:0x18f4
    346c:	50                   	push   ax
    346d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3470:	06                   	push   es
    3471:	57                   	push   di
    3472:	9a 7b 34 8c 34       	call   0x348c:0x347b
    3477:	c9                   	leave
    3478:	ca 08 00             	retf   0x8
    347b:	c8 0c 00 00          	enter  0xc,0x0
    347f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3482:	06                   	push   es
    3483:	57                   	push   di
    3484:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3487:	06                   	push   es
    3488:	57                   	push   di
    3489:	9a 20 36 12 35       	call   0x3512:0x3620
    348e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3491:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3494:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3497:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    349a:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    349e:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    34a1:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    34a5:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    34a9:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    34ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b0:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    34b5:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    34ba:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34bd:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    34c1:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    34c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c8:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    34cd:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    34d2:	2d 01 00             	sub    ax,0x1
    34d5:	83 da 00             	sbb    dx,0x0
    34d8:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    34db:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    34de:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    34e3:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    34e8:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    34eb:	7f 71                	jg     0x355e
    34ed:	7c 05                	jl     0x34f4
    34ef:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    34f2:	77 6a                	ja     0x355e
    34f4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34f7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    34fa:	eb 08                	jmp    0x3504
    34fc:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    3500:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    3504:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3507:	ff 76 fc             	push   WORD PTR [bp-0x4]
    350a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    350d:	06                   	push   es
    350e:	57                   	push   di
    350f:	9a 30 6e ce 35       	call   0x35ce:0x6e30
    3514:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3517:	26 03 05             	add    ax,WORD PTR es:[di]
    351a:	26 01 45 08          	add    WORD PTR es:[di+0x8],ax
    351e:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    3522:	26 03 05             	add    ax,WORD PTR es:[di]
    3525:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    3529:	7d 0a                	jge    0x3535
    352b:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    352f:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    3533:	eb 29                	jmp    0x355e
    3535:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3538:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    353b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    353e:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    3542:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    3546:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    354a:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    354e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3551:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3554:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    3557:	75 a3                	jne    0x34fc
    3559:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    355c:	75 9e                	jne    0x34fc
    355e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3561:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    3565:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    3569:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    356c:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    3571:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    3576:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3579:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    357d:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    3581:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3584:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3589:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    358e:	2d 01 00             	sub    ax,0x1
    3591:	83 da 00             	sbb    dx,0x0
    3594:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3597:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    359a:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    359f:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    35a4:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    35a7:	7f 73                	jg     0x361c
    35a9:	7c 05                	jl     0x35b0
    35ab:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    35ae:	77 6c                	ja     0x361c
    35b0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    35b3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    35b6:	eb 08                	jmp    0x35c0
    35b8:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    35bc:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    35c0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    35c3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    35c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35c9:	06                   	push   es
    35ca:	57                   	push   di
    35cb:	9a 8b 6e a2 36       	call   0x36a2:0x6e8b
    35d0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35d3:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    35d7:	26 01 45 0a          	add    WORD PTR es:[di+0xa],ax
    35db:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    35df:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    35e3:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
    35e7:	7d 0a                	jge    0x35f3
    35e9:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    35ed:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    35f1:	eb 29                	jmp    0x361c
    35f3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    35f6:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    35f9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35fc:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3600:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    3604:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    3608:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    360c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    360f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3612:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    3615:	75 a1                	jne    0x35b8
    3617:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    361a:	75 9c                	jne    0x35b8
    361c:	c9                   	leave
    361d:	ca 0c 00             	retf   0xc
    3620:	c8 08 00 00          	enter  0x8,0x0
    3624:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3627:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    362a:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    362d:	31 c0                	xor    ax,ax
    362f:	26 89 05             	mov    WORD PTR es:[di],ax
    3632:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3635:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    363a:	25 05 00             	and    ax,0x5
    363d:	09 c0                	or     ax,ax
    363f:	74 0b                	je     0x364c
    3641:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    3646:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3649:	26 89 05             	mov    WORD PTR es:[di],ax
    364c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    364f:	31 c0                	xor    ax,ax
    3651:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    3655:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3658:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    365d:	25 0a 00             	and    ax,0xa
    3660:	09 c0                	or     ax,ax
    3662:	74 0c                	je     0x3670
    3664:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    3669:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    366c:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    3670:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3673:	31 c0                	xor    ax,ax
    3675:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3679:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    367c:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    3681:	48                   	dec    ax
    3682:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3685:	31 c0                	xor    ax,ax
    3687:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    368a:	7f 2a                	jg     0x36b6
    368c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    368f:	eb 03                	jmp    0x3694
    3691:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3694:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3697:	99                   	cwd
    3698:	52                   	push   dx
    3699:	50                   	push   ax
    369a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    369d:	06                   	push   es
    369e:	57                   	push   di
    369f:	9a 30 6e e8 36       	call   0x36e8:0x6e30
    36a4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    36a7:	26 03 05             	add    ax,WORD PTR es:[di]
    36aa:	26 01 45 04          	add    WORD PTR es:[di+0x4],ax
    36ae:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36b1:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    36b4:	75 db                	jne    0x3691
    36b6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    36b9:	31 c0                	xor    ax,ax
    36bb:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    36bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36c2:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    36c7:	48                   	dec    ax
    36c8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    36cb:	31 c0                	xor    ax,ax
    36cd:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    36d0:	7f 2b                	jg     0x36fd
    36d2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    36d5:	eb 03                	jmp    0x36da
    36d7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    36da:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36dd:	99                   	cwd
    36de:	52                   	push   dx
    36df:	50                   	push   ax
    36e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36e3:	06                   	push   es
    36e4:	57                   	push   di
    36e5:	9a 8b 6e 72 37       	call   0x3772:0x6e8b
    36ea:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    36ed:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    36f1:	26 01 45 06          	add    WORD PTR es:[di+0x6],ax
    36f5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36f8:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    36fb:	75 da                	jne    0x36d7
    36fd:	c9                   	leave
    36fe:	ca 08 00             	retf   0x8
    3701:	c8 12 00 00          	enter  0x12,0x0
    3705:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3708:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    370b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    370e:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3711:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3714:	06                   	push   es
    3715:	57                   	push   di
    3716:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3719:	06                   	push   es
    371a:	57                   	push   di
    371b:	6a 08                	push   0x8
    371d:	9a 1b 16 76 3b       	call   0x3b76:0x161b
    3722:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3725:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    3729:	26 03 05             	add    ax,WORD PTR es:[di]
    372c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    372f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3732:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    3737:	99                   	cwd
    3738:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    373b:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    373e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3741:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3744:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3748:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    374b:	7c 5b                	jl     0x37a8
    374d:	7f 05                	jg     0x3754
    374f:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    3752:	72 54                	jb     0x37a8
    3754:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3757:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    375a:	eb 08                	jmp    0x3764
    375c:	83 6e fa 01          	sub    WORD PTR [bp-0x6],0x1
    3760:	83 5e fc 00          	sbb    WORD PTR [bp-0x4],0x0
    3764:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3767:	ff 76 fa             	push   WORD PTR [bp-0x6]
    376a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    376d:	06                   	push   es
    376e:	57                   	push   di
    376f:	9a 30 6e fa 37       	call   0x37fa:0x6e30
    3774:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3777:	26 03 05             	add    ax,WORD PTR es:[di]
    377a:	29 46 fe             	sub    WORD PTR [bp-0x2],ax
    377d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3780:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    3784:	7d 02                	jge    0x3788
    3786:	eb 20                	jmp    0x37a8
    3788:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    378b:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    378e:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3791:	26 89 05             	mov    WORD PTR es:[di],ax
    3794:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3798:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    379b:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    379e:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    37a1:	75 b9                	jne    0x375c
    37a3:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    37a6:	75 b4                	jne    0x375c
    37a8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    37ab:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    37af:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    37b3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    37b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b9:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    37be:	99                   	cwd
    37bf:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    37c2:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    37c5:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    37c8:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    37cc:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    37d0:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    37d3:	7c 5d                	jl     0x3832
    37d5:	7f 05                	jg     0x37dc
    37d7:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    37da:	72 56                	jb     0x3832
    37dc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    37df:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    37e2:	eb 08                	jmp    0x37ec
    37e4:	83 6e fa 01          	sub    WORD PTR [bp-0x6],0x1
    37e8:	83 5e fc 00          	sbb    WORD PTR [bp-0x4],0x0
    37ec:	ff 76 fc             	push   WORD PTR [bp-0x4]
    37ef:	ff 76 fa             	push   WORD PTR [bp-0x6]
    37f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f5:	06                   	push   es
    37f6:	57                   	push   di
    37f7:	9a 8b 6e 26 39       	call   0x3926:0x6e8b
    37fc:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    37ff:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    3803:	29 46 fe             	sub    WORD PTR [bp-0x2],ax
    3806:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3809:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    380d:	7d 02                	jge    0x3811
    380f:	eb 21                	jmp    0x3832
    3811:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3814:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    3817:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    381a:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    381e:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3822:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3825:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    3828:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    382b:	75 b7                	jne    0x37e4
    382d:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    3830:	75 b2                	jne    0x37e4
    3832:	c9                   	leave
    3833:	ca 0c 00             	retf   0xc
    3836:	c8 10 00 00          	enter  0x10,0x0
    383a:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    383d:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3841:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    3844:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    3849:	26 c7 45 02 ff ff    	mov    WORD PTR es:[di+0x2],0xffff
    384f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3852:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    3857:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    385a:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    385f:	74 08                	je     0x3869
    3861:	80 4e fe 80          	or     BYTE PTR [bp-0x2],0x80
    3865:	80 4e fe 40          	or     BYTE PTR [bp-0x2],0x40
    3869:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    386c:	25 c0 00             	and    ax,0xc0
    386f:	09 c0                	or     ax,ax
    3871:	75 03                	jne    0x3876
    3873:	e9 5a 02             	jmp    0x3ad0
    3876:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3879:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    387c:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    387f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3882:	06                   	push   es
    3883:	57                   	push   di
    3884:	9a f4 18 98 38       	call   0x3898:0x18f4
    3889:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    388c:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    3890:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3893:	06                   	push   es
    3894:	57                   	push   di
    3895:	9a a9 18 cd 3d       	call   0x3dcd:0x18a9
    389a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    389d:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    38a1:	8b 46 20             	mov    ax,WORD PTR [bp+0x20]
    38a4:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    38a8:	7f 03                	jg     0x38ad
    38aa:	e9 30 01             	jmp    0x39dd
    38ad:	f6 46 fe 80          	test   BYTE PTR [bp-0x2],0x80
    38b1:	75 03                	jne    0x38b6
    38b3:	e9 27 01             	jmp    0x39dd
    38b6:	8b 46 1e             	mov    ax,WORD PTR [bp+0x1e]
    38b9:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    38bd:	7c 03                	jl     0x38c2
    38bf:	e9 0e 02             	jmp    0x3ad0
    38c2:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    38c5:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    38c9:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    38cc:	26 8b 05             	mov    ax,WORD PTR es:[di]
    38cf:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    38d2:	31 c0                	xor    ax,ax
    38d4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    38d7:	83 7e f6 07          	cmp    WORD PTR [bp-0xa],0x7
    38db:	7d 10                	jge    0x38ed
    38dd:	c7 46 f6 07 00       	mov    WORD PTR [bp-0xa],0x7
    38e2:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    38e5:	26 2b 05             	sub    ax,WORD PTR es:[di]
    38e8:	d1 e8                	shr    ax,1
    38ea:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    38ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38f0:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    38f5:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    38fa:	2d 01 00             	sub    ax,0x1
    38fd:	83 da 00             	sbb    dx,0x0
    3900:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3903:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    3908:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    390b:	7e 03                	jle    0x3910
    390d:	e9 80 00             	jmp    0x3990
    3910:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3913:	eb 03                	jmp    0x3918
    3915:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3918:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    391b:	99                   	cwd
    391c:	52                   	push   dx
    391d:	50                   	push   ax
    391e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3921:	06                   	push   es
    3922:	57                   	push   di
    3923:	9a 30 6e 66 3a       	call   0x3a66:0x6e30
    3928:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    392b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    392e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3931:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    3935:	7e 02                	jle    0x3939
    3937:	eb 57                	jmp    0x3990
    3939:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    393c:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    393f:	3b 46 20             	cmp    ax,WORD PTR [bp+0x20]
    3942:	7f 3b                	jg     0x397f
    3944:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3947:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    394a:	03 46 f6             	add    ax,WORD PTR [bp-0xa]
    394d:	3b 46 20             	cmp    ax,WORD PTR [bp+0x20]
    3950:	7c 2d                	jl     0x397f
    3952:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    3955:	26 c6 05 03          	mov    BYTE PTR es:[di],0x3
    3959:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    395c:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    395f:	26 89 05             	mov    WORD PTR es:[di],ax
    3962:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3965:	2b 46 20             	sub    ax,WORD PTR [bp+0x20]
    3968:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    396b:	26 89 05             	mov    WORD PTR es:[di],ax
    396e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3971:	99                   	cwd
    3972:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    3975:	26 89 05             	mov    WORD PTR es:[di],ax
    3978:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    397c:	e9 51 01             	jmp    0x3ad0
    397f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3982:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3985:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    3988:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    398b:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    398e:	75 85                	jne    0x3915
    3990:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3993:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    3997:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    399a:	3b 46 20             	cmp    ax,WORD PTR [bp+0x20]
    399d:	7f 3b                	jg     0x39da
    399f:	8b 46 20             	mov    ax,WORD PTR [bp+0x20]
    39a2:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    39a6:	7f 32                	jg     0x39da
    39a8:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    39ab:	26 c6 05 03          	mov    BYTE PTR es:[di],0x3
    39af:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    39b2:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    39b6:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    39b9:	26 89 05             	mov    WORD PTR es:[di],ax
    39bc:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    39bf:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    39c3:	2b 46 20             	sub    ax,WORD PTR [bp+0x20]
    39c6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    39c9:	26 89 05             	mov    WORD PTR es:[di],ax
    39cc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    39cf:	99                   	cwd
    39d0:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    39d3:	26 89 05             	mov    WORD PTR es:[di],ax
    39d6:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    39da:	e9 f3 00             	jmp    0x3ad0
    39dd:	8b 46 1e             	mov    ax,WORD PTR [bp+0x1e]
    39e0:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    39e3:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    39e7:	7f 03                	jg     0x39ec
    39e9:	e9 e4 00             	jmp    0x3ad0
    39ec:	f6 46 fe 40          	test   BYTE PTR [bp-0x2],0x40
    39f0:	75 03                	jne    0x39f5
    39f2:	e9 db 00             	jmp    0x3ad0
    39f5:	8b 46 20             	mov    ax,WORD PTR [bp+0x20]
    39f8:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    39fc:	7c 03                	jl     0x3a01
    39fe:	e9 cf 00             	jmp    0x3ad0
    3a01:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3a04:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    3a08:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3a0b:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    3a0f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3a12:	31 c0                	xor    ax,ax
    3a14:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3a17:	83 7e f6 07          	cmp    WORD PTR [bp-0xa],0x7
    3a1b:	7d 10                	jge    0x3a2d
    3a1d:	c7 46 f6 07 00       	mov    WORD PTR [bp-0xa],0x7
    3a22:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3a25:	26 2b 05             	sub    ax,WORD PTR es:[di]
    3a28:	d1 e8                	shr    ax,1
    3a2a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3a2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a30:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3a35:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    3a3a:	2d 01 00             	sub    ax,0x1
    3a3d:	83 da 00             	sbb    dx,0x0
    3a40:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3a43:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    3a48:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    3a4b:	7e 03                	jle    0x3a50
    3a4d:	e9 80 00             	jmp    0x3ad0
    3a50:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a53:	eb 03                	jmp    0x3a58
    3a55:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3a58:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a5b:	99                   	cwd
    3a5c:	52                   	push   dx
    3a5d:	50                   	push   ax
    3a5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a61:	06                   	push   es
    3a62:	57                   	push   di
    3a63:	9a 8b 6e 3f 3c       	call   0x3c3f:0x6e8b
    3a68:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    3a6b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3a6e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3a71:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    3a75:	7e 02                	jle    0x3a79
    3a77:	eb 57                	jmp    0x3ad0
    3a79:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3a7c:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    3a7f:	3b 46 1e             	cmp    ax,WORD PTR [bp+0x1e]
    3a82:	7f 3a                	jg     0x3abe
    3a84:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3a87:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    3a8a:	03 46 f6             	add    ax,WORD PTR [bp-0xa]
    3a8d:	3b 46 1e             	cmp    ax,WORD PTR [bp+0x1e]
    3a90:	7c 2c                	jl     0x3abe
    3a92:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    3a95:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    3a99:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3a9c:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3a9f:	26 89 05             	mov    WORD PTR es:[di],ax
    3aa2:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3aa5:	2b 46 1e             	sub    ax,WORD PTR [bp+0x1e]
    3aa8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3aab:	26 89 05             	mov    WORD PTR es:[di],ax
    3aae:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3ab1:	99                   	cwd
    3ab2:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    3ab5:	26 89 05             	mov    WORD PTR es:[di],ax
    3ab8:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3abc:	eb 12                	jmp    0x3ad0
    3abe:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3ac1:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    3ac5:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    3ac8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3acb:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    3ace:	75 85                	jne    0x3a55
    3ad0:	c9                   	leave
    3ad1:	ca 1c 00             	retf   0x1c
    3ad4:	c8 08 00 00          	enter  0x8,0x0
    3ad8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3adb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3adf:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    3ae4:	26 0b 85 ec 00       	or     ax,WORD PTR es:[di+0xec]
    3ae9:	74 42                	je     0x3b2d
    3aeb:	81 c7 ea 00          	add    di,0xea
    3aef:	06                   	push   es
    3af0:	57                   	push   di
    3af1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3af4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3af8:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    3afd:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    3b02:	26 ff b5 fa 00       	push   WORD PTR es:[di+0xfa]
    3b07:	e8 4a d9             	call   0x1454
    3b0a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b0d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3b11:	81 c7 ee 00          	add    di,0xee
    3b15:	06                   	push   es
    3b16:	57                   	push   di
    3b17:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b1a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3b1e:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    3b23:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    3b28:	6a 01                	push   0x1
    3b2a:	e8 27 d9             	call   0x1454
    3b2d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b30:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3b34:	26 8b 85 0e 01       	mov    ax,WORD PTR es:[di+0x10e]
    3b39:	26 0b 85 10 01       	or     ax,WORD PTR es:[di+0x110]
    3b3e:	74 1f                	je     0x3b5f
    3b40:	81 c7 0e 01          	add    di,0x10e
    3b44:	06                   	push   es
    3b45:	57                   	push   di
    3b46:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b49:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3b4d:	26 ff b5 0c 01       	push   WORD PTR es:[di+0x10c]
    3b52:	26 ff b5 0a 01       	push   WORD PTR es:[di+0x10a]
    3b57:	26 ff b5 fc 00       	push   WORD PTR es:[di+0xfc]
    3b5c:	e8 f5 d8             	call   0x1454
    3b5f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b62:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3b66:	81 c7 f2 00          	add    di,0xf2
    3b6a:	06                   	push   es
    3b6b:	57                   	push   di
    3b6c:	8d 7e f8             	lea    di,[bp-0x8]
    3b6f:	16                   	push   ss
    3b70:	57                   	push   di
    3b71:	6a 08                	push   0x8
    3b73:	9a 1b 16 c1 3c       	call   0x3cc1:0x161b
    3b78:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b7b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3b7f:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    3b84:	26 8b 95 f8 00       	mov    dx,WORD PTR es:[di+0xf8]
    3b89:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    3b8e:	7f 09                	jg     0x3b99
    3b90:	7c 24                	jl     0x3bb6
    3b92:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    3b97:	72 1d                	jb     0x3bb6
    3b99:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3b9c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3ba0:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3ba5:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    3baa:	2d 01 00             	sub    ax,0x1
    3bad:	83 da 00             	sbb    dx,0x0
    3bb0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3bb3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3bb6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3bb9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3bbd:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    3bc2:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    3bc7:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    3bcc:	7f 09                	jg     0x3bd7
    3bce:	7c 24                	jl     0x3bf4
    3bd0:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    3bd5:	72 1d                	jb     0x3bf4
    3bd7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3bda:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3bde:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    3be3:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    3be8:	2d 01 00             	sub    ax,0x1
    3beb:	83 da 00             	sbb    dx,0x0
    3bee:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3bf1:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3bf4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3bf7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3bfb:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    3c00:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    3c05:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    3c08:	75 19                	jne    0x3c23
    3c0a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3c0d:	75 14                	jne    0x3c23
    3c0f:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    3c14:	26 8b 95 f8 00       	mov    dx,WORD PTR es:[di+0xf8]
    3c19:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    3c1c:	75 05                	jne    0x3c23
    3c1e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3c21:	74 1e                	je     0x3c41
    3c23:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3c26:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3c29:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3c2c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3c2f:	6a 01                	push   0x1
    3c31:	6a 01                	push   0x1
    3c33:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3c36:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3c3a:	06                   	push   es
    3c3b:	57                   	push   di
    3c3c:	9a d6 4f 81 3c       	call   0x3c81:0x4fd6
    3c41:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3c44:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3c48:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    3c4d:	26 8b 95 de 00       	mov    dx,WORD PTR es:[di+0xde]
    3c52:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    3c55:	75 19                	jne    0x3c70
    3c57:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3c5a:	75 14                	jne    0x3c70
    3c5c:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    3c61:	26 8b 95 e2 00       	mov    dx,WORD PTR es:[di+0xe2]
    3c66:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    3c69:	75 05                	jne    0x3c70
    3c6b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3c6e:	74 13                	je     0x3c83
    3c70:	8d 7e f8             	lea    di,[bp-0x8]
    3c73:	16                   	push   ss
    3c74:	57                   	push   di
    3c75:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3c78:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3c7c:	06                   	push   es
    3c7d:	57                   	push   di
    3c7e:	9a 25 4f 8f 3c       	call   0x3c8f:0x4f25
    3c83:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3c86:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3c8a:	06                   	push   es
    3c8b:	57                   	push   di
    3c8c:	9a 82 48 9d 3c       	call   0x3c9d:0x4882
    3c91:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3c94:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3c98:	06                   	push   es
    3c99:	57                   	push   di
    3c9a:	9a 86 5b cf 3c       	call   0x3ccf:0x5b86
    3c9f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3ca2:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    3ca6:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    3caa:	36 ff 75 fa          	push   WORD PTR ss:[di-0x6]
    3cae:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    3cb2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3cb5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3cb9:	06                   	push   es
    3cba:	57                   	push   di
    3cbb:	b8 e4 ff             	mov    ax,0xffe4
    3cbe:	9a 6a 20 ac 3d       	call   0x3dac:0x206a
    3cc3:	c9                   	leave
    3cc4:	c2 02 00             	ret    0x2
    3cc7:	01 00                	add    WORD PTR [bx+si],ax
    3cc9:	00 00                	add    BYTE PTR [bx+si],al
    3ccb:	00 00                	add    BYTE PTR [bx+si],al
    3ccd:	82 3d bb             	cmp    BYTE PTR [di],0xbb
    3cd0:	3d c8 08             	cmp    ax,0x8c8
    3cd3:	00 00                	add    BYTE PTR [bx+si],al
    3cd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cd8:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    3cdd:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    3ce2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ce5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ce8:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3ced:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    3cf2:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3cf5:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3cf8:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    3cfb:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    3cfe:	26 89 85 e6 00       	mov    WORD PTR es:[di+0xe6],ax
    3d03:	26 89 95 e8 00       	mov    WORD PTR es:[di+0xe8],dx
    3d08:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3d0b:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3d0e:	26 89 85 0a 01       	mov    WORD PTR es:[di+0x10a],ax
    3d13:	26 89 95 0c 01       	mov    WORD PTR es:[di+0x10c],dx
    3d18:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    3d1d:	99                   	cwd
    3d1e:	3b 56 10             	cmp    dx,WORD PTR [bp+0x10]
    3d21:	7f 07                	jg     0x3d2a
    3d23:	7c 19                	jl     0x3d3e
    3d25:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    3d28:	76 14                	jbe    0x3d3e
    3d2a:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    3d2d:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    3d30:	2d 01 00             	sub    ax,0x1
    3d33:	83 da 00             	sbb    dx,0x0
    3d36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d39:	26 89 85 fe 00       	mov    WORD PTR es:[di+0xfe],ax
    3d3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d41:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    3d46:	99                   	cwd
    3d47:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    3d4a:	7f 07                	jg     0x3d53
    3d4c:	7c 19                	jl     0x3d67
    3d4e:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3d51:	76 14                	jbe    0x3d67
    3d53:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3d56:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3d59:	2d 01 00             	sub    ax,0x1
    3d5c:	83 da 00             	sbb    dx,0x0
    3d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d62:	26 89 85 00 01       	mov    WORD PTR es:[di+0x100],ax
    3d67:	b8 c7 3c             	mov    ax,0x3cc7
    3d6a:	0e                   	push   cs
    3d6b:	50                   	push   ax
    3d6c:	55                   	push   bp
    3d6d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3d71:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3d75:	55                   	push   bp
    3d76:	e8 5b fd             	call   0x3ad4
    3d79:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3d7d:	83 c4 06             	add    sp,0x6
    3d80:	eb 31                	jmp    0x3db3
    3d82:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d85:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3d88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d8b:	26 89 85 e6 00       	mov    WORD PTR es:[di+0xe6],ax
    3d90:	26 89 95 e8 00       	mov    WORD PTR es:[di+0xe8],dx
    3d95:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3d98:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    3d9b:	26 89 85 0a 01       	mov    WORD PTR es:[di+0x10a],ax
    3da0:	26 89 95 0c 01       	mov    WORD PTR es:[di+0x10c],dx
    3da5:	55                   	push   bp
    3da6:	e8 2b fd             	call   0x3ad4
    3da9:	ea 85 13 b1 3d       	jmp    0x3db1:0x1385
    3dae:	9a 34 14 6c 3e       	call   0x3e6c:0x1434
    3db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db6:	06                   	push   es
    3db7:	57                   	push   di
    3db8:	9a 82 48 e3 3d       	call   0x3de3:0x4882
    3dbd:	c9                   	leave
    3dbe:	ca 0c 00             	retf   0xc
    3dc1:	c8 38 00 00          	enter  0x38,0x0
    3dc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dc8:	06                   	push   es
    3dc9:	57                   	push   di
    3dca:	9a fa 64 bc 41       	call   0x41bc:0x64fa
    3dcf:	08 c0                	or     al,al
    3dd1:	75 03                	jne    0x3dd6
    3dd3:	e9 99 01             	jmp    0x3f6f
    3dd6:	8d 7e e4             	lea    di,[bp-0x1c]
    3dd9:	16                   	push   ss
    3dda:	57                   	push   di
    3ddb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dde:	06                   	push   es
    3ddf:	57                   	push   di
    3de0:	9a 4f 34 85 3e       	call   0x3e85:0x344f
    3de5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3de8:	89 7e d0             	mov    WORD PTR [bp-0x30],di
    3deb:	8c 46 d2             	mov    WORD PTR [bp-0x2e],es
    3dee:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3df1:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3df5:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    3df8:	7f 5f                	jg     0x3e59
    3dfa:	7c 05                	jl     0x3e01
    3dfc:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    3dff:	77 58                	ja     0x3e59
    3e01:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3e04:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3e08:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3e0c:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    3e0f:	7f 48                	jg     0x3e59
    3e11:	7c 05                	jl     0x3e18
    3e13:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3e16:	77 41                	ja     0x3e59
    3e18:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3e1b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3e1e:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3e22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e25:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    3e2a:	7c 2d                	jl     0x3e59
    3e2c:	7f 07                	jg     0x3e35
    3e2e:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    3e33:	72 24                	jb     0x3e59
    3e35:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3e38:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3e3c:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3e40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e43:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    3e48:	7c 0f                	jl     0x3e59
    3e4a:	7e 03                	jle    0x3e4f
    3e4c:	e9 20 01             	jmp    0x3f6f
    3e4f:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    3e54:	72 03                	jb     0x3e59
    3e56:	e9 16 01             	jmp    0x3f6f
    3e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e5c:	81 c7 13 01          	add    di,0x113
    3e60:	06                   	push   es
    3e61:	57                   	push   di
    3e62:	8d 7e d4             	lea    di,[bp-0x2c]
    3e65:	16                   	push   ss
    3e66:	57                   	push   di
    3e67:	6a 08                	push   0x8
    3e69:	9a 1b 16 91 3e       	call   0x3e91:0x161b
    3e6e:	8d 7e c8             	lea    di,[bp-0x38]
    3e71:	16                   	push   ss
    3e72:	57                   	push   di
    3e73:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e76:	06                   	push   es
    3e77:	57                   	push   di
    3e78:	8d 7e e4             	lea    di,[bp-0x1c]
    3e7b:	16                   	push   ss
    3e7c:	57                   	push   di
    3e7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e80:	06                   	push   es
    3e81:	57                   	push   di
    3e82:	9a 01 37 6d 3f       	call   0x3f6d:0x3701
    3e87:	8d 7e dc             	lea    di,[bp-0x24]
    3e8a:	16                   	push   ss
    3e8b:	57                   	push   di
    3e8c:	6a 08                	push   0x8
    3e8e:	9a 1b 16 a8 40       	call   0x40a8:0x161b
    3e93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e96:	06                   	push   es
    3e97:	57                   	push   di
    3e98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e9b:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    3e9f:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3ea2:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3ea5:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3eac:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    3eb1:	7c 09                	jl     0x3ebc
    3eb3:	7f 20                	jg     0x3ed5
    3eb5:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    3eba:	73 19                	jae    0x3ed5
    3ebc:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3ebf:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3ec2:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3ec6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ec9:	26 89 85 13 01       	mov    WORD PTR es:[di+0x113],ax
    3ece:	26 89 95 15 01       	mov    WORD PTR es:[di+0x115],dx
    3ed3:	eb 29                	jmp    0x3efe
    3ed5:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3ed8:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3edb:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3edf:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    3ee2:	7f 07                	jg     0x3eeb
    3ee4:	7c 18                	jl     0x3efe
    3ee6:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    3ee9:	76 13                	jbe    0x3efe
    3eeb:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    3eee:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    3ef1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef4:	26 89 85 13 01       	mov    WORD PTR es:[di+0x113],ax
    3ef9:	26 89 95 15 01       	mov    WORD PTR es:[di+0x115],dx
    3efe:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3f01:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3f05:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3f09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f0c:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    3f11:	7c 09                	jl     0x3f1c
    3f13:	7f 21                	jg     0x3f36
    3f15:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    3f1a:	73 1a                	jae    0x3f36
    3f1c:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3f1f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3f23:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3f27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f2a:	26 89 85 17 01       	mov    WORD PTR es:[di+0x117],ax
    3f2f:	26 89 95 19 01       	mov    WORD PTR es:[di+0x119],dx
    3f34:	eb 2a                	jmp    0x3f60
    3f36:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    3f39:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3f3d:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3f41:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    3f44:	7f 07                	jg     0x3f4d
    3f46:	7c 18                	jl     0x3f60
    3f48:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3f4b:	76 13                	jbe    0x3f60
    3f4d:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    3f50:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    3f53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f56:	26 89 85 17 01       	mov    WORD PTR es:[di+0x117],ax
    3f5b:	26 89 95 19 01       	mov    WORD PTR es:[di+0x119],dx
    3f60:	8d 7e d4             	lea    di,[bp-0x2c]
    3f63:	16                   	push   ss
    3f64:	57                   	push   di
    3f65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f68:	06                   	push   es
    3f69:	57                   	push   di
    3f6a:	9a 5a 54 77 3f       	call   0x3f77:0x545a
    3f6f:	c9                   	leave
    3f70:	ca 08 00             	retf   0x8
    3f73:	00 00                	add    BYTE PTR [bx+si],al
    3f75:	83 40 7d 3f          	add    WORD PTR [bx+si+0x7d],0x3f
    3f79:	00 00                	add    BYTE PTR [bx+si],al
    3f7b:	a0 40 b3             	mov    al,ds:0xb340
    3f7e:	40                   	inc    ax
    3f7f:	c8 0c 00 00          	enter  0xc,0x0
    3f83:	b0 01                	mov    al,0x1
    3f85:	50                   	push   ax
    3f86:	b8 11 04             	mov    ax,0x411
    3f89:	ba 91 3f             	mov    dx,0x3f91
    3f8c:	52                   	push   dx
    3f8d:	50                   	push   ax
    3f8e:	9a a4 12 e3 3f       	call   0x3fe3:0x12a4
    3f93:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3f96:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3f99:	b8 79 3f             	mov    ax,0x3f79
    3f9c:	0e                   	push   cs
    3f9d:	50                   	push   ax
    3f9e:	55                   	push   bp
    3f9f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3fa3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3fa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3faa:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3faf:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3fb2:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3fb5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fb8:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3fbb:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3fbe:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3fc1:	26 ff 75 0d          	push   WORD PTR es:[di+0xd]
    3fc5:	26 ff 75 0b          	push   WORD PTR es:[di+0xb]
    3fc9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3fcc:	06                   	push   es
    3fcd:	57                   	push   di
    3fce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fd1:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3fd5:	6a 02                	push   0x2
    3fd7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3fda:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3fde:	06                   	push   es
    3fdf:	57                   	push   di
    3fe0:	9a b0 14 f3 3f       	call   0x3ff3:0x14b0
    3fe5:	6a 0e                	push   0xe
    3fe7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3fea:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3fee:	06                   	push   es
    3fef:	57                   	push   di
    3ff0:	9a 73 14 03 40       	call   0x4003:0x1473
    3ff5:	6a 01                	push   0x1
    3ff7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3ffa:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3ffe:	06                   	push   es
    3fff:	57                   	push   di
    4000:	9a f5 14 2d 40       	call   0x402d:0x14f5
    4005:	b8 73 3f             	mov    ax,0x3f73
    4008:	0e                   	push   cs
    4009:	50                   	push   ax
    400a:	55                   	push   bp
    400b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    400f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4016:	26 80 bd 3f 01 02    	cmp    BYTE PTR es:[di+0x13f],0x2
    401c:	75 2c                	jne    0x404a
    401e:	6a 00                	push   0x0
    4020:	26 ff b5 1f 01       	push   WORD PTR es:[di+0x11f]
    4025:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4028:	06                   	push   es
    4029:	57                   	push   di
    402a:	9a b8 1d 46 40       	call   0x4046:0x1db8
    402f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4032:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4036:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4039:	26 ff b5 1f 01       	push   WORD PTR es:[di+0x11f]
    403e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4041:	06                   	push   es
    4042:	57                   	push   di
    4043:	9a 7b 1d 5c 40       	call   0x405c:0x1d7b
    4048:	eb 2d                	jmp    0x4077
    404a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    404d:	26 ff b5 1f 01       	push   WORD PTR es:[di+0x11f]
    4052:	6a 00                	push   0x0
    4054:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4057:	06                   	push   es
    4058:	57                   	push   di
    4059:	9a b8 1d 75 40       	call   0x4075:0x1db8
    405e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4061:	26 ff b5 1f 01       	push   WORD PTR es:[di+0x11f]
    4066:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4069:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    406d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4070:	06                   	push   es
    4071:	57                   	push   di
    4072:	9a 7b 1d 91 40       	call   0x4091:0x1d7b
    4077:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    407b:	83 c4 06             	add    sp,0x6
    407e:	b8 94 40             	mov    ax,0x4094
    4081:	0e                   	push   cs
    4082:	50                   	push   ax
    4083:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4086:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4089:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    408c:	06                   	push   es
    408d:	57                   	push   di
    408e:	9a b6 20 c6 40       	call   0x40c6:0x20b6
    4093:	cb                   	retf
    4094:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4098:	83 c4 06             	add    sp,0x6
    409b:	b8 ab 40             	mov    ax,0x40ab
    409e:	0e                   	push   cs
    409f:	50                   	push   ax
    40a0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    40a3:	06                   	push   es
    40a4:	57                   	push   di
    40a5:	9a 7f 1f 78 41       	call   0x4178:0x1f7f
    40aa:	cb                   	retf
    40ab:	c9                   	leave
    40ac:	ca 08 00             	retf   0x8
    40af:	00 00                	add    BYTE PTR [bx+si],al
    40b1:	55                   	push   bp
    40b2:	42                   	inc    dx
    40b3:	b9 40 00             	mov    cx,0x40
    40b6:	00 77 42             	add    BYTE PTR [bx+0x42],dh
    40b9:	6c                   	ins    BYTE PTR es:[di],dx
    40ba:	41                   	inc    cx
    40bb:	c8 1a 00 00          	enter  0x1a,0x0
    40bf:	b0 01                	mov    al,0x1
    40c1:	50                   	push   ax
    40c2:	b8 11 04             	mov    ax,0x411
    40c5:	ba cd 40             	mov    dx,0x40cd
    40c8:	52                   	push   dx
    40c9:	50                   	push   ax
    40ca:	9a a4 12 21 41       	call   0x4121:0x12a4
    40cf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    40d2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    40d5:	b8 b5 40             	mov    ax,0x40b5
    40d8:	0e                   	push   cs
    40d9:	50                   	push   ax
    40da:	55                   	push   bp
    40db:	ff 36 58 18          	push   WORD PTR ds:0x1858
    40df:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    40e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e6:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    40eb:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    40ee:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    40f1:	26 ff 75 0d          	push   WORD PTR es:[di+0xd]
    40f5:	26 ff 75 0b          	push   WORD PTR es:[di+0xb]
    40f9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    40fc:	06                   	push   es
    40fd:	57                   	push   di
    40fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4101:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    4105:	b8 af 40             	mov    ax,0x40af
    4108:	0e                   	push   cs
    4109:	50                   	push   ax
    410a:	55                   	push   bp
    410b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    410f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4113:	6a 02                	push   0x2
    4115:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    4118:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    411c:	06                   	push   es
    411d:	57                   	push   di
    411e:	9a b0 14 31 41       	call   0x4131:0x14b0
    4123:	6a 0e                	push   0xe
    4125:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    4128:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    412c:	06                   	push   es
    412d:	57                   	push   di
    412e:	9a 73 14 41 41       	call   0x4141:0x1473
    4133:	6a 05                	push   0x5
    4135:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    4138:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    413c:	06                   	push   es
    413d:	57                   	push   di
    413e:	9a f5 14 b2 41       	call   0x41b2:0x14f5
    4143:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4146:	26 80 bd 3f 01 04    	cmp    BYTE PTR es:[di+0x13f],0x4
    414c:	74 03                	je     0x4151
    414e:	e9 7d 00             	jmp    0x41ce
    4151:	8d 7e e6             	lea    di,[bp-0x1a]
    4154:	16                   	push   ss
    4155:	57                   	push   di
    4156:	6a 00                	push   0x0
    4158:	6a 00                	push   0x0
    415a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    415d:	26 ff b5 29 01       	push   WORD PTR es:[di+0x129]
    4162:	26 ff b5 27 01       	push   WORD PTR es:[di+0x127]
    4167:	06                   	push   es
    4168:	57                   	push   di
    4169:	9a 24 24 e9 41       	call   0x41e9:0x2424
    416e:	8d 7e f2             	lea    di,[bp-0xe]
    4171:	16                   	push   ss
    4172:	57                   	push   di
    4173:	6a 08                	push   0x8
    4175:	9a 1b 16 f5 41       	call   0x41f5:0x161b
    417a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    417d:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    4182:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    4187:	26 3b 95 25 01       	cmp    dx,WORD PTR es:[di+0x125]
    418c:	7f 09                	jg     0x4197
    418e:	7c 0f                	jl     0x419f
    4190:	26 3b 85 23 01       	cmp    ax,WORD PTR es:[di+0x123]
    4195:	76 08                	jbe    0x419f
    4197:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    419a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    419d:	eb 06                	jmp    0x41a5
    419f:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    41a2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    41a5:	6a 00                	push   0x0
    41a7:	ff 76 fa             	push   WORD PTR [bp-0x6]
    41aa:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    41ad:	06                   	push   es
    41ae:	57                   	push   di
    41af:	9a b8 1d ca 41       	call   0x41ca:0x1db8
    41b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41b7:	06                   	push   es
    41b8:	57                   	push   di
    41b9:	9a a9 18 3c 42       	call   0x423c:0x18a9
    41be:	50                   	push   ax
    41bf:	ff 76 fa             	push   WORD PTR [bp-0x6]
    41c2:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    41c5:	06                   	push   es
    41c6:	57                   	push   di
    41c7:	9a 7b 1d 2f 42       	call   0x422f:0x1d7b
    41cc:	eb 7b                	jmp    0x4249
    41ce:	8d 7e e6             	lea    di,[bp-0x1a]
    41d1:	16                   	push   ss
    41d2:	57                   	push   di
    41d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41d6:	26 ff b5 29 01       	push   WORD PTR es:[di+0x129]
    41db:	26 ff b5 27 01       	push   WORD PTR es:[di+0x127]
    41e0:	6a 00                	push   0x0
    41e2:	6a 00                	push   0x0
    41e4:	06                   	push   es
    41e5:	57                   	push   di
    41e6:	9a 24 24 a3 42       	call   0x42a3:0x2424
    41eb:	8d 7e f2             	lea    di,[bp-0xe]
    41ee:	16                   	push   ss
    41ef:	57                   	push   di
    41f0:	6a 08                	push   0x8
    41f2:	9a 1b 16 7f 42       	call   0x427f:0x161b
    41f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41fa:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    41ff:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    4204:	26 3b 95 25 01       	cmp    dx,WORD PTR es:[di+0x125]
    4209:	7f 09                	jg     0x4214
    420b:	7c 0f                	jl     0x421c
    420d:	26 3b 85 23 01       	cmp    ax,WORD PTR es:[di+0x123]
    4212:	76 08                	jbe    0x421c
    4214:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4217:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    421a:	eb 06                	jmp    0x4222
    421c:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    421f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4222:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4225:	6a 00                	push   0x0
    4227:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    422a:	06                   	push   es
    422b:	57                   	push   di
    422c:	9a b8 1d 47 42       	call   0x4247:0x1db8
    4231:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4234:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4237:	06                   	push   es
    4238:	57                   	push   di
    4239:	9a f4 18 b5 48       	call   0x48b5:0x18f4
    423e:	50                   	push   ax
    423f:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    4242:	06                   	push   es
    4243:	57                   	push   di
    4244:	9a 7b 1d 68 42       	call   0x4268:0x1d7b
    4249:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    424d:	83 c4 06             	add    sp,0x6
    4250:	b8 6b 42             	mov    ax,0x426b
    4253:	0e                   	push   cs
    4254:	50                   	push   ax
    4255:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4258:	ff 76 fc             	push   WORD PTR [bp-0x4]
    425b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    425e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4263:	06                   	push   es
    4264:	57                   	push   di
    4265:	9a b6 20 e9 4b       	call   0x4be9:0x20b6
    426a:	cb                   	retf
    426b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    426f:	83 c4 06             	add    sp,0x6
    4272:	b8 82 42             	mov    ax,0x4282
    4275:	0e                   	push   cs
    4276:	50                   	push   ax
    4277:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    427a:	06                   	push   es
    427b:	57                   	push   di
    427c:	9a 7f 1f ba 42       	call   0x42ba:0x1f7f
    4281:	cb                   	retf
    4282:	c9                   	leave
    4283:	ca 04 00             	retf   0x4
    4286:	55                   	push   bp
    4287:	89 e5                	mov    bp,sp
    4289:	ff 76 12             	push   WORD PTR [bp+0x12]
    428c:	ff 76 10             	push   WORD PTR [bp+0x10]
    428f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4292:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4295:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4298:	50                   	push   ax
    4299:	6a 01                	push   0x1
    429b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    429e:	06                   	push   es
    429f:	57                   	push   di
    42a0:	9a d6 4f ad 42       	call   0x42ad:0x4fd6
    42a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42a8:	06                   	push   es
    42a9:	57                   	push   di
    42aa:	9a c1 77 79 43       	call   0x4379:0x77c1
    42af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b2:	06                   	push   es
    42b3:	57                   	push   di
    42b4:	b8 fe ff             	mov    ax,0xfffe
    42b7:	9a 6a 20 bb 44       	call   0x44bb:0x206a
    42bc:	c9                   	leave
    42bd:	ca 0e 00             	retf   0xe
    42c0:	c8 12 00 00          	enter  0x12,0x0
    42c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42c7:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    42ca:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    42cd:	31 c0                	xor    ax,ax
    42cf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    42d2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    42d5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    42d9:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    42de:	99                   	cwd
    42df:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    42e2:	7f 07                	jg     0x42eb
    42e4:	7c 0f                	jl     0x42f5
    42e6:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    42e9:	76 0a                	jbe    0x42f5
    42eb:	31 c0                	xor    ax,ax
    42ed:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    42f0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    42f3:	eb 3e                	jmp    0x4333
    42f5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    42f8:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    42fb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    42fe:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4302:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    4307:	7f 09                	jg     0x4312
    4309:	7c 11                	jl     0x431c
    430b:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    4310:	72 0a                	jb     0x431c
    4312:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4315:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4319:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    431c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    431f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4323:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    4328:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    432d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4330:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4333:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4336:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4339:	2d 01 00             	sub    ax,0x1
    433c:	83 da 00             	sbb    dx,0x0
    433f:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    4342:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    4345:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4348:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    434b:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    434e:	7f 54                	jg     0x43a4
    4350:	7c 05                	jl     0x4357
    4352:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    4355:	77 4d                	ja     0x43a4
    4357:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    435a:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    435d:	eb 08                	jmp    0x4367
    435f:	83 46 f6 01          	add    WORD PTR [bp-0xa],0x1
    4363:	83 56 f8 00          	adc    WORD PTR [bp-0x8],0x0
    4367:	ff 76 f8             	push   WORD PTR [bp-0x8]
    436a:	ff 76 f6             	push   WORD PTR [bp-0xa]
    436d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4370:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4374:	06                   	push   es
    4375:	57                   	push   di
    4376:	9a 30 6e 64 44       	call   0x4464:0x6e30
    437b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    437e:	26 03 05             	add    ax,WORD PTR es:[di]
    4381:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    4384:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4387:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    438b:	7e 07                	jle    0x4394
    438d:	31 c0                	xor    ax,ax
    438f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4392:	eb 10                	jmp    0x43a4
    4394:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4397:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    439a:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    439d:	75 c0                	jne    0x435f
    439f:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    43a2:	75 bb                	jne    0x435f
    43a4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    43a7:	c9                   	leave
    43a8:	c2 0a 00             	ret    0xa
    43ab:	c8 12 00 00          	enter  0x12,0x0
    43af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43b2:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    43b5:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    43b8:	31 c0                	xor    ax,ax
    43ba:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    43bd:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    43c0:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    43c4:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    43c9:	99                   	cwd
    43ca:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    43cd:	7f 07                	jg     0x43d6
    43cf:	7c 0f                	jl     0x43e0
    43d1:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    43d4:	76 0a                	jbe    0x43e0
    43d6:	31 c0                	xor    ax,ax
    43d8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    43db:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    43de:	eb 3e                	jmp    0x441e
    43e0:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    43e3:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    43e6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    43e9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    43ed:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    43f2:	7f 09                	jg     0x43fd
    43f4:	7c 11                	jl     0x4407
    43f6:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    43fb:	72 0a                	jb     0x4407
    43fd:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4400:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    4404:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4407:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    440a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    440e:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    4413:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    4418:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    441b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    441e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4421:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4424:	2d 01 00             	sub    ax,0x1
    4427:	83 da 00             	sbb    dx,0x0
    442a:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    442d:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    4430:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4433:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    4436:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    4439:	7f 55                	jg     0x4490
    443b:	7c 05                	jl     0x4442
    443d:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    4440:	77 4e                	ja     0x4490
    4442:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4445:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4448:	eb 08                	jmp    0x4452
    444a:	83 46 f6 01          	add    WORD PTR [bp-0xa],0x1
    444e:	83 56 f8 00          	adc    WORD PTR [bp-0x8],0x0
    4452:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4455:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4458:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    445b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    445f:	06                   	push   es
    4460:	57                   	push   di
    4461:	9a 8b 6e f1 44       	call   0x44f1:0x6e8b
    4466:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4469:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    446d:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    4470:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4473:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    4477:	7e 07                	jle    0x4480
    4479:	31 c0                	xor    ax,ax
    447b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    447e:	eb 10                	jmp    0x4490
    4480:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4483:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    4486:	3b 56 f0             	cmp    dx,WORD PTR [bp-0x10]
    4489:	75 bf                	jne    0x444a
    448b:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    448e:	75 ba                	jne    0x444a
    4490:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4493:	c9                   	leave
    4494:	c2 0a 00             	ret    0xa
    4497:	c8 34 00 00          	enter  0x34,0x0
    449b:	8c d3                	mov    bx,ss
    449d:	8e c3                	mov    es,bx
    449f:	8c db                	mov    bx,ds
    44a1:	fc                   	cld
    44a2:	8d 7e f0             	lea    di,[bp-0x10]
    44a5:	c5 76 10             	lds    si,DWORD PTR [bp+0x10]
    44a8:	b9 10 00             	mov    cx,0x10
    44ab:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    44ad:	8e db                	mov    ds,bx
    44af:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    44b2:	06                   	push   es
    44b3:	57                   	push   di
    44b4:	6a 08                	push   0x8
    44b6:	6a 00                	push   0x0
    44b8:	9a e5 1e f7 47       	call   0x47f7:0x1ee5
    44bd:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    44c0:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    44c3:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    44c6:	7f 19                	jg     0x44e1
    44c8:	7c 05                	jl     0x44cf
    44ca:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    44cd:	77 12                	ja     0x44e1
    44cf:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    44d2:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    44d5:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    44d8:	7f 07                	jg     0x44e1
    44da:	7c 08                	jl     0x44e4
    44dc:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    44df:	76 03                	jbe    0x44e4
    44e1:	e9 d5 02             	jmp    0x47b9
    44e4:	8d 7e d4             	lea    di,[bp-0x2c]
    44e7:	16                   	push   ss
    44e8:	57                   	push   di
    44e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ec:	06                   	push   es
    44ed:	57                   	push   di
    44ee:	9a 4f 34 e7 46       	call   0x46e7:0x344f
    44f3:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    44f6:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    44f9:	05 01 00             	add    ax,0x1
    44fc:	83 d2 00             	adc    dx,0x0
    44ff:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    4502:	7c 07                	jl     0x450b
    4504:	7f 08                	jg     0x450e
    4506:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    4509:	73 03                	jae    0x450e
    450b:	e9 ab 02             	jmp    0x47b9
    450e:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4511:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4514:	05 01 00             	add    ax,0x1
    4517:	83 d2 00             	adc    dx,0x0
    451a:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    451d:	7c 07                	jl     0x4526
    451f:	7f 08                	jg     0x4529
    4521:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    4524:	73 03                	jae    0x4529
    4526:	e9 90 02             	jmp    0x47b9
    4529:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    452c:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    4531:	99                   	cwd
    4532:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    4535:	7c 07                	jl     0x453e
    4537:	7f 4f                	jg     0x4588
    4539:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    453c:	77 4a                	ja     0x4588
    453e:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    4541:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    4544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4547:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    454c:	7c 09                	jl     0x4557
    454e:	7f 38                	jg     0x4588
    4550:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    4555:	73 31                	jae    0x4588
    4557:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    455a:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    455d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4560:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    4565:	7c 09                	jl     0x4570
    4567:	7f 0c                	jg     0x4575
    4569:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    456e:	73 05                	jae    0x4575
    4570:	e9 46 02             	jmp    0x47b9
    4573:	eb 13                	jmp    0x4588
    4575:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4578:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    457d:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    4582:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    4585:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    4588:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    458b:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    458e:	3b 56 e6             	cmp    dx,WORD PTR [bp-0x1a]
    4591:	7f 07                	jg     0x459a
    4593:	7c 53                	jl     0x45e8
    4595:	3b 46 e4             	cmp    ax,WORD PTR [bp-0x1c]
    4598:	76 4e                	jbe    0x45e8
    459a:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    459d:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    45a0:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    45a3:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    45a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45a9:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    45ae:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    45b3:	2d 01 00             	sub    ax,0x1
    45b6:	83 da 00             	sbb    dx,0x0
    45b9:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    45bc:	7f 07                	jg     0x45c5
    45be:	7c 0d                	jl     0x45cd
    45c0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    45c3:	76 08                	jbe    0x45cd
    45c5:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    45c9:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    45cd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    45d0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    45d3:	8d 7e d4             	lea    di,[bp-0x2c]
    45d6:	16                   	push   ss
    45d7:	57                   	push   di
    45d8:	55                   	push   bp
    45d9:	e8 e4 fc             	call   0x42c0
    45dc:	09 c0                	or     ax,ax
    45de:	75 08                	jne    0x45e8
    45e0:	83 6e f8 01          	sub    WORD PTR [bp-0x8],0x1
    45e4:	83 5e fa 00          	sbb    WORD PTR [bp-0x6],0x0
    45e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45eb:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    45f0:	99                   	cwd
    45f1:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    45f4:	7c 07                	jl     0x45fd
    45f6:	7f 4f                	jg     0x4647
    45f8:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    45fb:	77 4a                	ja     0x4647
    45fd:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    4600:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    4603:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4606:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    460b:	7c 09                	jl     0x4616
    460d:	7f 38                	jg     0x4647
    460f:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    4614:	73 31                	jae    0x4647
    4616:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4619:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    461c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    461f:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    4624:	7c 09                	jl     0x462f
    4626:	7f 0c                	jg     0x4634
    4628:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    462d:	73 05                	jae    0x4634
    462f:	e9 87 01             	jmp    0x47b9
    4632:	eb 13                	jmp    0x4647
    4634:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4637:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    463c:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    4641:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4644:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    4647:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    464a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    464d:	3b 56 ea             	cmp    dx,WORD PTR [bp-0x16]
    4650:	7f 07                	jg     0x4659
    4652:	7c 53                	jl     0x46a7
    4654:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    4657:	76 4e                	jbe    0x46a7
    4659:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    465c:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    465f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4662:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4665:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4668:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    466d:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    4672:	2d 01 00             	sub    ax,0x1
    4675:	83 da 00             	sbb    dx,0x0
    4678:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    467b:	7f 07                	jg     0x4684
    467d:	7c 0d                	jl     0x468c
    467f:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4682:	76 08                	jbe    0x468c
    4684:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    4688:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    468c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    468f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4692:	8d 7e d4             	lea    di,[bp-0x2c]
    4695:	16                   	push   ss
    4696:	57                   	push   di
    4697:	55                   	push   bp
    4698:	e8 10 fd             	call   0x43ab
    469b:	09 c0                	or     ax,ax
    469d:	75 08                	jne    0x46a7
    469f:	83 6e fc 01          	sub    WORD PTR [bp-0x4],0x1
    46a3:	83 5e fe 00          	sbb    WORD PTR [bp-0x2],0x0
    46a7:	ff 76 f2             	push   WORD PTR [bp-0xe]
    46aa:	ff 76 f0             	push   WORD PTR [bp-0x10]
    46ad:	8d 7e d4             	lea    di,[bp-0x2c]
    46b0:	16                   	push   ss
    46b1:	57                   	push   di
    46b2:	55                   	push   bp
    46b3:	e8 0a fc             	call   0x42c0
    46b6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    46b9:	26 89 05             	mov    WORD PTR es:[di],ax
    46bc:	ff 76 fa             	push   WORD PTR [bp-0x6]
    46bf:	ff 76 f8             	push   WORD PTR [bp-0x8]
    46c2:	8d 7e d4             	lea    di,[bp-0x2c]
    46c5:	16                   	push   ss
    46c6:	57                   	push   di
    46c7:	55                   	push   bp
    46c8:	e8 f5 fb             	call   0x42c0
    46cb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    46ce:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    46d2:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    46d7:	75 1c                	jne    0x46f5
    46d9:	ff 76 f2             	push   WORD PTR [bp-0xe]
    46dc:	ff 76 f0             	push   WORD PTR [bp-0x10]
    46df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46e2:	06                   	push   es
    46e3:	57                   	push   di
    46e4:	9a 30 6e 03 47       	call   0x4703:0x6e30
    46e9:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    46ec:	26 03 05             	add    ax,WORD PTR es:[di]
    46ef:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    46f3:	eb 17                	jmp    0x470c
    46f5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    46f8:	ff 76 f8             	push   WORD PTR [bp-0x8]
    46fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46fe:	06                   	push   es
    46ff:	57                   	push   di
    4700:	9a 30 6e 70 47       	call   0x4770:0x6e30
    4705:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4708:	26 01 45 04          	add    WORD PTR es:[di+0x4],ax
    470c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    470f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4713:	3b 46 e2             	cmp    ax,WORD PTR [bp-0x1e]
    4716:	7e 07                	jle    0x471f
    4718:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    471b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    471f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4723:	74 0a                	je     0x472f
    4725:	8b 46 d4             	mov    ax,WORD PTR [bp-0x2c]
    4728:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    472b:	26 01 45 04          	add    WORD PTR es:[di+0x4],ax
    472f:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4732:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4735:	8d 7e d4             	lea    di,[bp-0x2c]
    4738:	16                   	push   ss
    4739:	57                   	push   di
    473a:	55                   	push   bp
    473b:	e8 6d fc             	call   0x43ab
    473e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4741:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    4745:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4748:	ff 76 fc             	push   WORD PTR [bp-0x4]
    474b:	8d 7e d4             	lea    di,[bp-0x2c]
    474e:	16                   	push   ss
    474f:	57                   	push   di
    4750:	55                   	push   bp
    4751:	e8 57 fc             	call   0x43ab
    4754:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4757:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    475b:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    4760:	75 1d                	jne    0x477f
    4762:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4765:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4768:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    476b:	06                   	push   es
    476c:	57                   	push   di
    476d:	9a 8b 6e 8d 47       	call   0x478d:0x6e8b
    4772:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4775:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    4779:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    477d:	eb 17                	jmp    0x4796
    477f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4782:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4785:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4788:	06                   	push   es
    4789:	57                   	push   di
    478a:	9a 8b 6e 7c 48       	call   0x487c:0x6e8b
    478f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4792:	26 01 45 06          	add    WORD PTR es:[di+0x6],ax
    4796:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    479a:	74 0a                	je     0x47a6
    479c:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    479f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    47a2:	26 01 45 06          	add    WORD PTR es:[di+0x6],ax
    47a6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    47a9:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    47ad:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    47b0:	7e 07                	jle    0x47b9
    47b2:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    47b5:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    47b9:	c9                   	leave
    47ba:	ca 0e 00             	retf   0xe
    47bd:	55                   	push   bp
    47be:	89 e5                	mov    bp,sp
    47c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47c3:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    47c8:	99                   	cwd
    47c9:	26 89 85 13 01       	mov    WORD PTR es:[di+0x113],ax
    47ce:	26 89 95 15 01       	mov    WORD PTR es:[di+0x115],dx
    47d3:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    47d8:	99                   	cwd
    47d9:	26 89 85 17 01       	mov    WORD PTR es:[di+0x117],ax
    47de:	26 89 95 19 01       	mov    WORD PTR es:[di+0x119],dx
    47e3:	81 c7 13 01          	add    di,0x113
    47e7:	06                   	push   es
    47e8:	57                   	push   di
    47e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47ec:	81 c7 f2 00          	add    di,0xf2
    47f0:	06                   	push   es
    47f1:	57                   	push   di
    47f2:	6a 08                	push   0x8
    47f4:	9a 1b 16 10 48       	call   0x4810:0x161b
    47f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47fc:	81 c7 f2 00          	add    di,0xf2
    4800:	06                   	push   es
    4801:	57                   	push   di
    4802:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4805:	81 c7 dc 00          	add    di,0xdc
    4809:	06                   	push   es
    480a:	57                   	push   di
    480b:	6a 08                	push   0x8
    480d:	9a 1b 16 9e 49       	call   0x499e:0x161b
    4812:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4815:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    481b:	74 1a                	je     0x4837
    481d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    4822:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    4827:	2d 01 00             	sub    ax,0x1
    482a:	83 da 00             	sbb    dx,0x0
    482d:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    4832:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
    4837:	c9                   	leave
    4838:	ca 04 00             	retf   0x4
    483b:	c8 10 00 00          	enter  0x10,0x0
    483f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4842:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4845:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4848:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    484b:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    484e:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    4851:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    4854:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    4857:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    485a:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    485d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4860:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4863:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    4866:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    4869:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    486c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    486f:	8d 7e f0             	lea    di,[bp-0x10]
    4872:	16                   	push   ss
    4873:	57                   	push   di
    4874:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4877:	06                   	push   es
    4878:	57                   	push   di
    4879:	9a 95 48 d1 48       	call   0x48d1:0x4895
    487e:	c9                   	leave
    487f:	ca 0c 00             	retf   0xc
    4882:	55                   	push   bp
    4883:	89 e5                	mov    bp,sp
    4885:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4888:	06                   	push   es
    4889:	57                   	push   di
    488a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    488d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4891:	c9                   	leave
    4892:	ca 04 00             	retf   0x4
    4895:	c8 18 00 00          	enter  0x18,0x0
    4899:	8c d3                	mov    bx,ss
    489b:	8e c3                	mov    es,bx
    489d:	8c db                	mov    bx,ds
    489f:	fc                   	cld
    48a0:	8d 7e f0             	lea    di,[bp-0x10]
    48a3:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    48a6:	b9 10 00             	mov    cx,0x10
    48a9:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    48ab:	8e db                	mov    ds,bx
    48ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48b0:	06                   	push   es
    48b1:	57                   	push   di
    48b2:	9a fa 64 db 48       	call   0x48db:0x64fa
    48b7:	08 c0                	or     al,al
    48b9:	75 02                	jne    0x48bd
    48bb:	eb 2d                	jmp    0x48ea
    48bd:	8d 7e f0             	lea    di,[bp-0x10]
    48c0:	16                   	push   ss
    48c1:	57                   	push   di
    48c2:	8d 7e e8             	lea    di,[bp-0x18]
    48c5:	16                   	push   ss
    48c6:	57                   	push   di
    48c7:	6a 01                	push   0x1
    48c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48cc:	06                   	push   es
    48cd:	57                   	push   di
    48ce:	9a 97 44 92 49       	call   0x4992:0x4497
    48d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48d6:	06                   	push   es
    48d7:	57                   	push   di
    48d8:	9a b9 62 1a 4c       	call   0x4c1a:0x62b9
    48dd:	50                   	push   ax
    48de:	8d 7e e8             	lea    di,[bp-0x18]
    48e1:	16                   	push   ss
    48e2:	57                   	push   di
    48e3:	6a 00                	push   0x0
    48e5:	9a 9c 52 00 00       	call   0x0:0x529c
    48ea:	c9                   	leave
    48eb:	ca 08 00             	retf   0x8
    48ee:	c8 04 00 00          	enter  0x4,0x0
    48f2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    48f5:	36 83 7d 0e 00       	cmp    WORD PTR ss:[di+0xe],0x0
    48fa:	75 15                	jne    0x4911
    48fc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    48ff:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4903:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    4908:	99                   	cwd
    4909:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    490c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    490f:	eb 13                	jmp    0x4924
    4911:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4914:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4918:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    491d:	99                   	cwd
    491e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4921:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4924:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4927:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    492a:	c9                   	leave
    492b:	c2 02 00             	ret    0x2
    492e:	c8 04 00 00          	enter  0x4,0x0
    4932:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4935:	36 83 7d 0e 00       	cmp    WORD PTR ss:[di+0xe],0x0
    493a:	75 10                	jne    0x494c
    493c:	36 8b 45 e8          	mov    ax,WORD PTR ss:[di-0x18]
    4940:	36 8b 55 ea          	mov    dx,WORD PTR ss:[di-0x16]
    4944:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4947:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    494a:	eb 11                	jmp    0x495d
    494c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    494f:	36 8b 45 ec          	mov    ax,WORD PTR ss:[di-0x14]
    4953:	36 8b 55 ee          	mov    dx,WORD PTR ss:[di-0x12]
    4957:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    495a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    495d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4960:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4963:	c9                   	leave
    4964:	c2 02 00             	ret    0x2
    4967:	c8 14 00 00          	enter  0x14,0x0
    496b:	8d 7e ec             	lea    di,[bp-0x14]
    496e:	16                   	push   ss
    496f:	57                   	push   di
    4970:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4973:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4977:	81 c7 13 01          	add    di,0x113
    497b:	06                   	push   es
    497c:	57                   	push   di
    497d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4980:	81 c7 cc ff          	add    di,0xffcc
    4984:	16                   	push   ss
    4985:	57                   	push   di
    4986:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4989:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    498d:	06                   	push   es
    498e:	57                   	push   di
    498f:	9a 01 37 1d 4a       	call   0x4a1d:0x3701
    4994:	8d 7e f4             	lea    di,[bp-0xc]
    4997:	16                   	push   ss
    4998:	57                   	push   di
    4999:	6a 08                	push   0x8
    499b:	9a 1b 16 1b 4d       	call   0x4d1b:0x161b
    49a0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49a3:	36 83 7d 0e 00       	cmp    WORD PTR ss:[di+0xe],0x0
    49a8:	75 1f                	jne    0x49c9
    49aa:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49ad:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    49b1:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    49b6:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    49bb:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    49be:	1b 56 f6             	sbb    dx,WORD PTR [bp-0xa]
    49c1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    49c4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    49c7:	eb 1d                	jmp    0x49e6
    49c9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49cc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    49d0:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    49d5:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    49da:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    49dd:	1b 56 fa             	sbb    dx,WORD PTR [bp-0x6]
    49e0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    49e3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    49e6:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    49ea:	7c 08                	jl     0x49f4
    49ec:	7f 10                	jg     0x49fe
    49ee:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    49f2:	73 0a                	jae    0x49fe
    49f4:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    49f9:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    49fe:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4a01:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4a04:	c9                   	leave
    4a05:	c2 02 00             	ret    0x2
    4a08:	c8 20 00 00          	enter  0x20,0x0
    4a0c:	8d 7e e0             	lea    di,[bp-0x20]
    4a0f:	16                   	push   ss
    4a10:	57                   	push   di
    4a11:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a14:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4a18:	06                   	push   es
    4a19:	57                   	push   di
    4a1a:	9a 4f 34 79 4c       	call   0x4c79:0x344f
    4a1f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a22:	36 83 7d 0e 00       	cmp    WORD PTR ss:[di+0xe],0x0
    4a27:	75 1f                	jne    0x4a48
    4a29:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    4a2c:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    4a2f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a32:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4a36:	26 2b 85 13 01       	sub    ax,WORD PTR es:[di+0x113]
    4a3b:	26 1b 95 15 01       	sbb    dx,WORD PTR es:[di+0x115]
    4a40:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4a43:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4a46:	eb 1d                	jmp    0x4a65
    4a48:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    4a4b:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    4a4e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a51:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4a55:	26 2b 85 17 01       	sub    ax,WORD PTR es:[di+0x117]
    4a5a:	26 1b 95 19 01       	sbb    dx,WORD PTR es:[di+0x119]
    4a5f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4a62:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4a65:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4a69:	7c 08                	jl     0x4a73
    4a6b:	7f 10                	jg     0x4a7d
    4a6d:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    4a71:	73 0a                	jae    0x4a7d
    4a73:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4a78:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    4a7d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4a80:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4a83:	c9                   	leave
    4a84:	c2 02 00             	ret    0x2
    4a87:	bf 4a d4             	mov    di,0xd44a
    4a8a:	4a                   	dec    dx
    4a8b:	e9 4a 07             	jmp    0x51d8
    4a8e:	4b                   	dec    bx
    4a8f:	1c 4b                	sbb    al,0x4b
    4a91:	1c 4b                	sbb    al,0x4b
    4a93:	83 4b 74 4b          	or     WORD PTR [bp+di+0x74],0x4b
    4a97:	c8 04 00 00          	enter  0x4,0x0
    4a9b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4a9e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4aa1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4aa4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4aa7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4aaa:	36 8b 45 0c          	mov    ax,WORD PTR ss:[di+0xc]
    4aae:	3d 07 00             	cmp    ax,0x7
    4ab1:	76 03                	jbe    0x4ab6
    4ab3:	e9 da 00             	jmp    0x4b90
    4ab6:	89 c3                	mov    bx,ax
    4ab8:	d1 e3                	shl    bx,1
    4aba:	2e ff a7 87 4a       	jmp    WORD PTR cs:[bx+0x4a87]
    4abf:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4ac2:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4ac5:	2d 01 00             	sub    ax,0x1
    4ac8:	83 da 00             	sbb    dx,0x0
    4acb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4ace:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4ad1:	e9 bc 00             	jmp    0x4b90
    4ad4:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4ad7:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4ada:	05 01 00             	add    ax,0x1
    4add:	83 d2 00             	adc    dx,0x0
    4ae0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4ae3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4ae6:	e9 a7 00             	jmp    0x4b90
    4ae9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4aec:	57                   	push   di
    4aed:	e8 77 fe             	call   0x4967
    4af0:	8b c8                	mov    cx,ax
    4af2:	8b da                	mov    bx,dx
    4af4:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4af7:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4afa:	2b c1                	sub    ax,cx
    4afc:	1b d3                	sbb    dx,bx
    4afe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b01:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b04:	e9 89 00             	jmp    0x4b90
    4b07:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b0a:	57                   	push   di
    4b0b:	e8 fa fe             	call   0x4a08
    4b0e:	03 46 06             	add    ax,WORD PTR [bp+0x6]
    4b11:	13 56 08             	adc    dx,WORD PTR [bp+0x8]
    4b14:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b17:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b1a:	eb 74                	jmp    0x4b90
    4b1c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b1f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4b23:	26 f6 85 09 01 40    	test   BYTE PTR es:[di+0x109],0x40
    4b29:	75 0a                	jne    0x4b35
    4b2b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b2e:	36 83 7d 0c 04       	cmp    WORD PTR ss:[di+0xc],0x4
    4b33:	75 3d                	jne    0x4b72
    4b35:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b38:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    4b3c:	31 d2                	xor    dx,dx
    4b3e:	52                   	push   dx
    4b3f:	50                   	push   ax
    4b40:	57                   	push   di
    4b41:	e8 aa fd             	call   0x48ee
    4b44:	52                   	push   dx
    4b45:	50                   	push   ax
    4b46:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b49:	57                   	push   di
    4b4a:	e8 e1 fd             	call   0x492e
    4b4d:	59                   	pop    cx
    4b4e:	5b                   	pop    bx
    4b4f:	2b c1                	sub    ax,cx
    4b51:	1b d3                	sbb    dx,bx
    4b53:	52                   	push   dx
    4b54:	50                   	push   ax
    4b55:	6a 00                	push   0x0
    4b57:	68 ff 7f             	push   0x7fff
    4b5a:	e8 22 ca             	call   0x157f
    4b5d:	52                   	push   dx
    4b5e:	50                   	push   ax
    4b5f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b62:	57                   	push   di
    4b63:	e8 88 fd             	call   0x48ee
    4b66:	59                   	pop    cx
    4b67:	5b                   	pop    bx
    4b68:	03 c1                	add    ax,cx
    4b6a:	13 d3                	adc    dx,bx
    4b6c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b6f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b72:	eb 1c                	jmp    0x4b90
    4b74:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b77:	57                   	push   di
    4b78:	e8 73 fd             	call   0x48ee
    4b7b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b7e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b81:	eb 0d                	jmp    0x4b90
    4b83:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4b86:	57                   	push   di
    4b87:	e8 64 fd             	call   0x48ee
    4b8a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b8d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b90:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4b93:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4b96:	c9                   	leave
    4b97:	c2 06 00             	ret    0x6
    4b9a:	01 30                	add    WORD PTR [bx+si],si
    4b9c:	d3 4b f1             	ror    WORD PTR [bp+di-0xf],cl
    4b9f:	4b                   	dec    bx
    4ba0:	0e                   	push   cs
    4ba1:	4c                   	dec    sp
    4ba2:	21 4c 34             	and    WORD PTR [si+0x34],cx
    4ba5:	4c                   	dec    sp
    4ba6:	3c 4c                	cmp    al,0x4c
    4ba8:	5a                   	pop    dx
    4ba9:	4c                   	dec    sp
    4baa:	53                   	push   bx
    4bab:	4c                   	dec    sp
    4bac:	c8 14 00 00          	enter  0x14,0x0
    4bb0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4bb3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4bb7:	26 8b 85 3d 01       	mov    ax,WORD PTR es:[di+0x13d]
    4bbc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4bbf:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    4bc2:	3d 07 00             	cmp    ax,0x7
    4bc5:	76 03                	jbe    0x4bca
    4bc7:	e9 b7 00             	jmp    0x4c81
    4bca:	89 c3                	mov    bx,ax
    4bcc:	d1 e3                	shl    bx,1
    4bce:	2e ff a7 9c 4b       	jmp    WORD PTR cs:[bx+0x4b9c]
    4bd3:	bf 9a 4b             	mov    di,0x4b9a
    4bd6:	0e                   	push   cs
    4bd7:	57                   	push   di
    4bd8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4bdb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4bdf:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4be4:	06                   	push   es
    4be5:	57                   	push   di
    4be6:	9a 03 20 07 4c       	call   0x4c07:0x2003
    4beb:	29 46 fe             	sub    WORD PTR [bp-0x2],ax
    4bee:	e9 90 00             	jmp    0x4c81
    4bf1:	bf 9a 4b             	mov    di,0x4b9a
    4bf4:	0e                   	push   cs
    4bf5:	57                   	push   di
    4bf6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4bf9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4bfd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4c02:	06                   	push   es
    4c03:	57                   	push   di
    4c04:	9a 03 20 36 97       	call   0x9736:0x2003
    4c09:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    4c0c:	eb 73                	jmp    0x4c81
    4c0e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4c11:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4c15:	06                   	push   es
    4c16:	57                   	push   di
    4c17:	9a a9 18 2d 4c       	call   0x4c2d:0x18a9
    4c1c:	29 46 fe             	sub    WORD PTR [bp-0x2],ax
    4c1f:	eb 60                	jmp    0x4c81
    4c21:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4c24:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4c28:	06                   	push   es
    4c29:	57                   	push   di
    4c2a:	9a a9 18 66 4c       	call   0x4c66:0x18a9
    4c2f:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    4c32:	eb 4d                	jmp    0x4c81
    4c34:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4c37:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c3a:	eb 45                	jmp    0x4c81
    4c3c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4c3f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4c43:	26 f6 85 09 01 40    	test   BYTE PTR es:[di+0x109],0x40
    4c49:	74 06                	je     0x4c51
    4c4b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4c4e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c51:	eb 2e                	jmp    0x4c81
    4c53:	31 c0                	xor    ax,ax
    4c55:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c58:	eb 27                	jmp    0x4c81
    4c5a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4c5d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4c61:	06                   	push   es
    4c62:	57                   	push   di
    4c63:	9a a9 18 9a 4c       	call   0x4c9a:0x18a9
    4c68:	50                   	push   ax
    4c69:	6a 00                	push   0x0
    4c6b:	6a 00                	push   0x0
    4c6d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4c70:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4c74:	06                   	push   es
    4c75:	57                   	push   di
    4c76:	9a 30 6e ad 4c       	call   0x4cad:0x6e30
    4c7b:	5a                   	pop    dx
    4c7c:	2b c2                	sub    ax,dx
    4c7e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c81:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4c85:	7d 07                	jge    0x4c8e
    4c87:	31 c0                	xor    ax,ax
    4c89:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c8c:	eb 50                	jmp    0x4cde
    4c8e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4c91:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4c95:	06                   	push   es
    4c96:	57                   	push   di
    4c97:	9a a9 18 c3 4c       	call   0x4cc3:0x18a9
    4c9c:	50                   	push   ax
    4c9d:	6a 00                	push   0x0
    4c9f:	6a 00                	push   0x0
    4ca1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4ca4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4ca8:	06                   	push   es
    4ca9:	57                   	push   di
    4caa:	9a 30 6e d6 4c       	call   0x4cd6:0x6e30
    4caf:	5a                   	pop    dx
    4cb0:	2b c2                	sub    ax,dx
    4cb2:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    4cb5:	7f 27                	jg     0x4cde
    4cb7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4cba:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4cbe:	06                   	push   es
    4cbf:	57                   	push   di
    4cc0:	9a a9 18 71 4d       	call   0x4d71:0x18a9
    4cc5:	50                   	push   ax
    4cc6:	6a 00                	push   0x0
    4cc8:	6a 00                	push   0x0
    4cca:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4ccd:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4cd1:	06                   	push   es
    4cd2:	57                   	push   di
    4cd3:	9a 30 6e 0d 4d       	call   0x4d0d:0x6e30
    4cd8:	5a                   	pop    dx
    4cd9:	2b c2                	sub    ax,dx
    4cdb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4cde:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ce1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4ce4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4ce8:	26 3b 85 3d 01       	cmp    ax,WORD PTR es:[di+0x13d]
    4ced:	74 72                	je     0x4d61
    4cef:	26 8b 85 3d 01       	mov    ax,WORD PTR es:[di+0x13d]
    4cf4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4cf7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4cfa:	26 89 85 3d 01       	mov    WORD PTR es:[di+0x13d],ax
    4cff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4d02:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    4d05:	50                   	push   ax
    4d06:	6a 00                	push   0x0
    4d08:	06                   	push   es
    4d09:	57                   	push   di
    4d0a:	9a 2e 54 41 4d       	call   0x4d41:0x542e
    4d0f:	8d 7e ec             	lea    di,[bp-0x14]
    4d12:	16                   	push   ss
    4d13:	57                   	push   di
    4d14:	6a 10                	push   0x10
    4d16:	6a 00                	push   0x0
    4d18:	9a e5 1e 19 4e       	call   0x4e19:0x1ee5
    4d1d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4d20:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4d24:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4d29:	99                   	cwd
    4d2a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4d2d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    4d30:	8d 7e ec             	lea    di,[bp-0x14]
    4d33:	16                   	push   ss
    4d34:	57                   	push   di
    4d35:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4d38:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4d3c:	06                   	push   es
    4d3d:	57                   	push   di
    4d3e:	9a 95 48 5f 4d       	call   0x4d5f:0x4895
    4d43:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4d46:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4d4a:	06                   	push   es
    4d4b:	57                   	push   di
    4d4c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d4f:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    4d53:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4d56:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4d5a:	06                   	push   es
    4d5b:	57                   	push   di
    4d5c:	9a 2f 57 c5 4d       	call   0x4dc5:0x572f
    4d61:	c9                   	leave
    4d62:	c2 06 00             	ret    0x6
    4d65:	c8 3c 00 00          	enter  0x3c,0x0
    4d69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d6c:	06                   	push   es
    4d6d:	57                   	push   di
    4d6e:	9a c4 61 29 52       	call   0x5229:0x61c4
    4d73:	08 c0                	or     al,al
    4d75:	74 1b                	je     0x4d92
    4d77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d7a:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
    4d80:	74 10                	je     0x4d92
    4d82:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4d87:	75 09                	jne    0x4d92
    4d89:	06                   	push   es
    4d8a:	57                   	push   di
    4d8b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d8e:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    4d92:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    4d96:	75 20                	jne    0x4db8
    4d98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d9b:	26 83 bd e8 00 00    	cmp    WORD PTR es:[di+0xe8],0x0
    4da1:	75 15                	jne    0x4db8
    4da3:	26 83 bd e6 00 01    	cmp    WORD PTR es:[di+0xe6],0x1
    4da9:	75 0d                	jne    0x4db8
    4dab:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4dae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4db1:	55                   	push   bp
    4db2:	e8 f7 fd             	call   0x4bac
    4db5:	e9 69 01             	jmp    0x4f21
    4db8:	8d 7e cc             	lea    di,[bp-0x34]
    4dbb:	16                   	push   ss
    4dbc:	57                   	push   di
    4dbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dc0:	06                   	push   es
    4dc1:	57                   	push   di
    4dc2:	9a 4f 34 0d 4e       	call   0x4e0d:0x344f
    4dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dca:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    4dcf:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    4dd4:	2d 01 00             	sub    ax,0x1
    4dd7:	83 da 00             	sbb    dx,0x0
    4dda:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    4ddd:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    4de0:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    4de5:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    4dea:	2d 01 00             	sub    ax,0x1
    4ded:	83 da 00             	sbb    dx,0x0
    4df0:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    4df3:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    4df6:	8d 7e c4             	lea    di,[bp-0x3c]
    4df9:	16                   	push   ss
    4dfa:	57                   	push   di
    4dfb:	8d 7e e8             	lea    di,[bp-0x18]
    4dfe:	16                   	push   ss
    4dff:	57                   	push   di
    4e00:	8d 7e cc             	lea    di,[bp-0x34]
    4e03:	16                   	push   ss
    4e04:	57                   	push   di
    4e05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e08:	06                   	push   es
    4e09:	57                   	push   di
    4e0a:	9a 01 37 1f 4f       	call   0x4f1f:0x3701
    4e0f:	8d 7e e8             	lea    di,[bp-0x18]
    4e12:	16                   	push   ss
    4e13:	57                   	push   di
    4e14:	6a 08                	push   0x8
    4e16:	9a 1b 16 2e 4e       	call   0x4e2e:0x161b
    4e1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e1e:	81 c7 13 01          	add    di,0x113
    4e22:	06                   	push   es
    4e23:	57                   	push   di
    4e24:	8d 7e f0             	lea    di,[bp-0x10]
    4e27:	16                   	push   ss
    4e28:	57                   	push   di
    4e29:	6a 08                	push   0x8
    4e2b:	9a 1b 16 52 4f       	call   0x4f52:0x161b
    4e30:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    4e34:	75 12                	jne    0x4e48
    4e36:	ff 76 f2             	push   WORD PTR [bp-0xe]
    4e39:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4e3c:	55                   	push   bp
    4e3d:	e8 57 fc             	call   0x4a97
    4e40:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    4e43:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    4e46:	eb 10                	jmp    0x4e58
    4e48:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4e4b:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4e4e:	55                   	push   bp
    4e4f:	e8 45 fc             	call   0x4a97
    4e52:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4e55:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    4e58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5b:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    4e60:	99                   	cwd
    4e61:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    4e64:	7f 07                	jg     0x4e6d
    4e66:	7c 16                	jl     0x4e7e
    4e68:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    4e6b:	76 11                	jbe    0x4e7e
    4e6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e70:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    4e75:	99                   	cwd
    4e76:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    4e79:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    4e7c:	eb 1e                	jmp    0x4e9c
    4e7e:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    4e81:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    4e84:	3b 56 ea             	cmp    dx,WORD PTR [bp-0x16]
    4e87:	7f 07                	jg     0x4e90
    4e89:	7c 11                	jl     0x4e9c
    4e8b:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    4e8e:	76 0c                	jbe    0x4e9c
    4e90:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4e93:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4e96:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    4e99:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    4e9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e9f:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4ea4:	99                   	cwd
    4ea5:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    4ea8:	7f 07                	jg     0x4eb1
    4eaa:	7c 16                	jl     0x4ec2
    4eac:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    4eaf:	76 11                	jbe    0x4ec2
    4eb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eb4:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    4eb9:	99                   	cwd
    4eba:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4ebd:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    4ec0:	eb 1e                	jmp    0x4ee0
    4ec2:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    4ec5:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    4ec8:	3b 56 ee             	cmp    dx,WORD PTR [bp-0x12]
    4ecb:	7f 07                	jg     0x4ed4
    4ecd:	7c 11                	jl     0x4ee0
    4ecf:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    4ed2:	76 0c                	jbe    0x4ee0
    4ed4:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    4ed7:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
    4eda:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4edd:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    4ee0:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    4ee3:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    4ee6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ee9:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    4eee:	75 1b                	jne    0x4f0b
    4ef0:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    4ef5:	75 14                	jne    0x4f0b
    4ef7:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    4efa:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    4efd:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    4f02:	75 07                	jne    0x4f0b
    4f04:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    4f09:	74 16                	je     0x4f21
    4f0b:	ff 76 f2             	push   WORD PTR [bp-0xe]
    4f0e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4f11:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4f14:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4f17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f1a:	06                   	push   es
    4f1b:	57                   	push   di
    4f1c:	9a 73 51 46 4f       	call   0x4f46:0x5173
    4f21:	c9                   	leave
    4f22:	ca 0a 00             	retf   0xa
    4f25:	c8 20 00 00          	enter  0x20,0x0
    4f29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f2c:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    4f31:	25 10 04             	and    ax,0x410
    4f34:	3d 10 00             	cmp    ax,0x10
    4f37:	75 79                	jne    0x4fb2
    4f39:	8d 7e e0             	lea    di,[bp-0x20]
    4f3c:	16                   	push   ss
    4f3d:	57                   	push   di
    4f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f41:	06                   	push   es
    4f42:	57                   	push   di
    4f43:	9a e6 6e 9f 4f       	call   0x4f9f:0x6ee6
    4f48:	8d 7e f0             	lea    di,[bp-0x10]
    4f4b:	16                   	push   ss
    4f4c:	57                   	push   di
    4f4d:	6a 10                	push   0x10
    4f4f:	9a 1b 16 67 4f       	call   0x4f67:0x161b
    4f54:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4f57:	06                   	push   es
    4f58:	57                   	push   di
    4f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f5c:	81 c7 dc 00          	add    di,0xdc
    4f60:	06                   	push   es
    4f61:	57                   	push   di
    4f62:	6a 08                	push   0x8
    4f64:	9a 1b 16 67 50       	call   0x5067:0x161b
    4f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f6c:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    4f72:	74 1a                	je     0x4f8e
    4f74:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    4f79:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    4f7e:	2d 01 00             	sub    ax,0x1
    4f81:	83 da 00             	sbb    dx,0x0
    4f84:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
    4f89:	26 89 95 e2 00       	mov    WORD PTR es:[di+0xe2],dx
    4f8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f91:	81 c7 dc 00          	add    di,0xdc
    4f95:	06                   	push   es
    4f96:	57                   	push   di
    4f97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f9a:	06                   	push   es
    4f9b:	57                   	push   di
    4f9c:	9a c1 3d ae 4f       	call   0x4fae:0x3dc1
    4fa1:	8d 7e f0             	lea    di,[bp-0x10]
    4fa4:	16                   	push   ss
    4fa5:	57                   	push   di
    4fa6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fa9:	06                   	push   es
    4faa:	57                   	push   di
    4fab:	9a 1d 52 d0 4f       	call   0x4fd0:0x521d
    4fb0:	eb 20                	jmp    0x4fd2
    4fb2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4fb5:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4fb9:	26 ff 35             	push   WORD PTR es:[di]
    4fbc:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4fc0:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    4fc4:	6a 01                	push   0x1
    4fc6:	6a 01                	push   0x1
    4fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fcb:	06                   	push   es
    4fcc:	57                   	push   di
    4fcd:	9a d6 4f 5b 50       	call   0x505b:0x4fd6
    4fd2:	c9                   	leave
    4fd3:	ca 08 00             	retf   0x8
    4fd6:	c8 28 00 00          	enter  0x28,0x0
    4fda:	83 7e 14 00          	cmp    WORD PTR [bp+0x14],0x0
    4fde:	7c 48                	jl     0x5028
    4fe0:	7f 06                	jg     0x4fe8
    4fe2:	83 7e 12 00          	cmp    WORD PTR [bp+0x12],0x0
    4fe6:	72 40                	jb     0x5028
    4fe8:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    4fec:	7c 3a                	jl     0x5028
    4fee:	7f 06                	jg     0x4ff6
    4ff0:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    4ff4:	72 32                	jb     0x5028
    4ff6:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    4ff9:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    4ffc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fff:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    5004:	7f 22                	jg     0x5028
    5006:	7c 07                	jl     0x500f
    5008:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    500d:	73 19                	jae    0x5028
    500f:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    5012:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    5015:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5018:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    501d:	7f 09                	jg     0x5028
    501f:	7c 0d                	jl     0x502e
    5021:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    5026:	72 06                	jb     0x502e
    5028:	68 57 f0             	push   0xf057
    502b:	e8 f4 be             	call   0xf22
    502e:	ff 76 14             	push   WORD PTR [bp+0x14]
    5031:	ff 76 12             	push   WORD PTR [bp+0x12]
    5034:	ff 76 10             	push   WORD PTR [bp+0x10]
    5037:	ff 76 0e             	push   WORD PTR [bp+0xe]
    503a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    503d:	06                   	push   es
    503e:	57                   	push   di
    503f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5042:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    5047:	08 c0                	or     al,al
    5049:	75 03                	jne    0x504e
    504b:	e9 21 01             	jmp    0x516f
    504e:	8d 7e d8             	lea    di,[bp-0x28]
    5051:	16                   	push   ss
    5052:	57                   	push   di
    5053:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5056:	06                   	push   es
    5057:	57                   	push   di
    5058:	9a e6 6e ae 50       	call   0x50ae:0x6ee6
    505d:	8d 7e f0             	lea    di,[bp-0x10]
    5060:	16                   	push   ss
    5061:	57                   	push   di
    5062:	6a 10                	push   0x10
    5064:	9a 1b 16 7c 50       	call   0x507c:0x161b
    5069:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    506c:	81 c7 f2 00          	add    di,0xf2
    5070:	06                   	push   es
    5071:	57                   	push   di
    5072:	8d 7e e8             	lea    di,[bp-0x18]
    5075:	16                   	push   ss
    5076:	57                   	push   di
    5077:	6a 08                	push   0x8
    5079:	9a 1b 16 d8 50       	call   0x50d8:0x161b
    507e:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    5081:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    5084:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5087:	26 89 85 f2 00       	mov    WORD PTR es:[di+0xf2],ax
    508c:	26 89 95 f4 00       	mov    WORD PTR es:[di+0xf4],dx
    5091:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    5094:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    5097:	26 89 85 f6 00       	mov    WORD PTR es:[di+0xf6],ax
    509c:	26 89 95 f8 00       	mov    WORD PTR es:[di+0xf8],dx
    50a1:	26 f6 85 09 01 20    	test   BYTE PTR es:[di+0x109],0x20
    50a7:	75 07                	jne    0x50b0
    50a9:	06                   	push   es
    50aa:	57                   	push   di
    50ab:	9a 32 25 2b 51       	call   0x512b:0x2532
    50b0:	80 7e 0c 00          	cmp    BYTE PTR [bp+0xc],0x0
    50b4:	75 0b                	jne    0x50c1
    50b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50b9:	26 f6 85 08 01 10    	test   BYTE PTR es:[di+0x108],0x10
    50bf:	75 3e                	jne    0x50ff
    50c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50c4:	81 c7 f2 00          	add    di,0xf2
    50c8:	06                   	push   es
    50c9:	57                   	push   di
    50ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50cd:	81 c7 dc 00          	add    di,0xdc
    50d1:	06                   	push   es
    50d2:	57                   	push   di
    50d3:	6a 08                	push   0x8
    50d5:	9a 1b 16 c3 51       	call   0x51c3:0x161b
    50da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50dd:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    50e3:	74 1a                	je     0x50ff
    50e5:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    50ea:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    50ef:	2d 01 00             	sub    ax,0x1
    50f2:	83 da 00             	sbb    dx,0x0
    50f5:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    50fa:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
    50ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5102:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    5108:	74 10                	je     0x511a
    510a:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    510f:	99                   	cwd
    5110:	26 89 85 f2 00       	mov    WORD PTR es:[di+0xf2],ax
    5115:	26 89 95 f4 00       	mov    WORD PTR es:[di+0xf4],dx
    511a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    511d:	81 c7 f2 00          	add    di,0xf2
    5121:	06                   	push   es
    5122:	57                   	push   di
    5123:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5126:	06                   	push   es
    5127:	57                   	push   di
    5128:	9a c1 3d 3a 51       	call   0x513a:0x3dc1
    512d:	8d 7e f0             	lea    di,[bp-0x10]
    5130:	16                   	push   ss
    5131:	57                   	push   di
    5132:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5135:	06                   	push   es
    5136:	57                   	push   di
    5137:	9a 1d 52 50 51       	call   0x5150:0x521d
    513c:	ff 76 ea             	push   WORD PTR [bp-0x16]
    513f:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5142:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5145:	ff 76 ec             	push   WORD PTR [bp-0x14]
    5148:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    514b:	06                   	push   es
    514c:	57                   	push   di
    514d:	9a 3b 48 6d 51       	call   0x516d:0x483b
    5152:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5155:	81 c7 f2 00          	add    di,0xf2
    5159:	ff 76 14             	push   WORD PTR [bp+0x14]
    515c:	ff 76 12             	push   WORD PTR [bp+0x12]
    515f:	ff 76 10             	push   WORD PTR [bp+0x10]
    5162:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5168:	06                   	push   es
    5169:	57                   	push   di
    516a:	9a 3b 48 f5 51       	call   0x51f5:0x483b
    516f:	c9                   	leave
    5170:	ca 10 00             	retf   0x10
    5173:	c8 08 00 00          	enter  0x8,0x0
    5177:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    517a:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    517d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5180:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    5185:	75 1d                	jne    0x51a4
    5187:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    518c:	75 16                	jne    0x51a4
    518e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5191:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    5194:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    5199:	75 09                	jne    0x51a4
    519b:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    51a0:	75 02                	jne    0x51a4
    51a2:	eb 53                	jmp    0x51f7
    51a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51a7:	06                   	push   es
    51a8:	57                   	push   di
    51a9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51ac:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    51b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51b3:	81 c7 13 01          	add    di,0x113
    51b7:	06                   	push   es
    51b8:	57                   	push   di
    51b9:	8d 7e f8             	lea    di,[bp-0x8]
    51bc:	16                   	push   ss
    51bd:	57                   	push   di
    51be:	6a 08                	push   0x8
    51c0:	9a 1b 16 e2 52       	call   0x52e2:0x161b
    51c5:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    51c8:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    51cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ce:	26 89 85 13 01       	mov    WORD PTR es:[di+0x113],ax
    51d3:	26 89 95 15 01       	mov    WORD PTR es:[di+0x115],dx
    51d8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    51db:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    51de:	26 89 85 17 01       	mov    WORD PTR es:[di+0x117],ax
    51e3:	26 89 95 19 01       	mov    WORD PTR es:[di+0x119],dx
    51e8:	8d 7e f8             	lea    di,[bp-0x8]
    51eb:	16                   	push   ss
    51ec:	57                   	push   di
    51ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51f0:	06                   	push   es
    51f1:	57                   	push   di
    51f2:	9a 5a 54 06 52       	call   0x5206:0x545a
    51f7:	c9                   	leave
    51f8:	ca 0c 00             	retf   0xc
    51fb:	55                   	push   bp
    51fc:	89 e5                	mov    bp,sp
    51fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5201:	06                   	push   es
    5202:	57                   	push   di
    5203:	9a 82 48 17 52       	call   0x5217:0x4882
    5208:	c9                   	leave
    5209:	ca 0c 00             	retf   0xc
    520c:	55                   	push   bp
    520d:	89 e5                	mov    bp,sp
    520f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5212:	06                   	push   es
    5213:	57                   	push   di
    5214:	9a 82 48 45 52       	call   0x5245:0x4882
    5219:	c9                   	leave
    521a:	ca 0c 00             	retf   0xc
    521d:	c8 42 00 00          	enter  0x42,0x0
    5221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5224:	06                   	push   es
    5225:	57                   	push   di
    5226:	9a fa 64 8b 52       	call   0x528b:0x64fa
    522b:	08 c0                	or     al,al
    522d:	75 02                	jne    0x5231
    522f:	eb 75                	jmp    0x52a6
    5231:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5234:	06                   	push   es
    5235:	57                   	push   di
    5236:	8d 7e f8             	lea    di,[bp-0x8]
    5239:	16                   	push   ss
    523a:	57                   	push   di
    523b:	6a 01                	push   0x1
    523d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5240:	06                   	push   es
    5241:	57                   	push   di
    5242:	9a 97 44 54 52       	call   0x5254:0x4497
    5247:	8d 7e be             	lea    di,[bp-0x42]
    524a:	16                   	push   ss
    524b:	57                   	push   di
    524c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    524f:	06                   	push   es
    5250:	57                   	push   di
    5251:	9a e6 6e 65 52       	call   0x5265:0x6ee6
    5256:	8d 7e f0             	lea    di,[bp-0x10]
    5259:	16                   	push   ss
    525a:	57                   	push   di
    525b:	6a 01                	push   0x1
    525d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5260:	06                   	push   es
    5261:	57                   	push   di
    5262:	9a 97 44 3f 54       	call   0x543f:0x4497
    5267:	8d 7e f8             	lea    di,[bp-0x8]
    526a:	16                   	push   ss
    526b:	57                   	push   di
    526c:	8d 7e f0             	lea    di,[bp-0x10]
    526f:	16                   	push   ss
    5270:	57                   	push   di
    5271:	8d 7e d0             	lea    di,[bp-0x30]
    5274:	16                   	push   ss
    5275:	57                   	push   di
    5276:	e8 5d bf             	call   0x11d6
    5279:	31 c0                	xor    ax,ax
    527b:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    527e:	eb 03                	jmp    0x5283
    5280:	ff 46 ce             	inc    WORD PTR [bp-0x32]
    5283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5286:	06                   	push   es
    5287:	57                   	push   di
    5288:	9a b9 62 ec 52       	call   0x52ec:0x62b9
    528d:	50                   	push   ax
    528e:	8b 7e ce             	mov    di,WORD PTR [bp-0x32]
    5291:	c1 e7 03             	shl    di,0x3
    5294:	8d 7b d0             	lea    di,[bp+di-0x30]
    5297:	16                   	push   ss
    5298:	57                   	push   di
    5299:	6a 00                	push   0x0
    529b:	9a ff ff 00 00       	call   0x0:0xffff
    52a0:	83 7e ce 03          	cmp    WORD PTR [bp-0x32],0x3
    52a4:	75 da                	jne    0x5280
    52a6:	c9                   	leave
    52a7:	ca 08 00             	retf   0x8
    52aa:	c8 14 00 00          	enter  0x14,0x0
    52ae:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    52b1:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    52b4:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    52b7:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    52bb:	75 49                	jne    0x5306
    52bd:	8d 7e ec             	lea    di,[bp-0x14]
    52c0:	16                   	push   ss
    52c1:	57                   	push   di
    52c2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    52c5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    52c9:	6a 00                	push   0x0
    52cb:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    52cf:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    52d3:	9a 88 06 25 53       	call   0x5325:0x688
    52d8:	8d 7e f8             	lea    di,[bp-0x8]
    52db:	16                   	push   ss
    52dc:	57                   	push   di
    52dd:	6a 08                	push   0x8
    52df:	9a 1b 16 31 53       	call   0x5331:0x161b
    52e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52e7:	06                   	push   es
    52e8:	57                   	push   di
    52e9:	9a b9 62 3b 53       	call   0x533b:0x62b9
    52ee:	50                   	push   ax
    52ef:	ff 76 10             	push   WORD PTR [bp+0x10]
    52f2:	6a 00                	push   0x0
    52f4:	8d 7e f8             	lea    di,[bp-0x8]
    52f7:	16                   	push   ss
    52f8:	57                   	push   di
    52f9:	8d 7e f8             	lea    di,[bp-0x8]
    52fc:	16                   	push   ss
    52fd:	57                   	push   di
    52fe:	9a 4e 53 00 00       	call   0x0:0x534e
    5303:	e9 24 01             	jmp    0x542a
    5306:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    530a:	75 49                	jne    0x5355
    530c:	8d 7e ec             	lea    di,[bp-0x14]
    530f:	16                   	push   ss
    5310:	57                   	push   di
    5311:	6a 00                	push   0x0
    5313:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5316:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    531a:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    531e:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    5322:	9a 88 06 6e 53       	call   0x536e:0x688
    5327:	8d 7e f8             	lea    di,[bp-0x8]
    532a:	16                   	push   ss
    532b:	57                   	push   di
    532c:	6a 08                	push   0x8
    532e:	9a 1b 16 7a 53       	call   0x537a:0x161b
    5333:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5336:	06                   	push   es
    5337:	57                   	push   di
    5338:	9a b9 62 84 53       	call   0x5384:0x62b9
    533d:	50                   	push   ax
    533e:	6a 00                	push   0x0
    5340:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5343:	8d 7e f8             	lea    di,[bp-0x8]
    5346:	16                   	push   ss
    5347:	57                   	push   di
    5348:	8d 7e f8             	lea    di,[bp-0x8]
    534b:	16                   	push   ss
    534c:	57                   	push   di
    534d:	9a 97 53 00 00       	call   0x0:0x5397
    5352:	e9 d5 00             	jmp    0x542a
    5355:	8d 7e ec             	lea    di,[bp-0x14]
    5358:	16                   	push   ss
    5359:	57                   	push   di
    535a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    535d:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5361:	6a 00                	push   0x0
    5363:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    5367:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    536b:	9a 88 06 b4 53       	call   0x53b4:0x688
    5370:	8d 7e f8             	lea    di,[bp-0x8]
    5373:	16                   	push   ss
    5374:	57                   	push   di
    5375:	6a 08                	push   0x8
    5377:	9a 1b 16 c0 53       	call   0x53c0:0x161b
    537c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    537f:	06                   	push   es
    5380:	57                   	push   di
    5381:	9a b9 62 ca 53       	call   0x53ca:0x62b9
    5386:	50                   	push   ax
    5387:	ff 76 10             	push   WORD PTR [bp+0x10]
    538a:	6a 00                	push   0x0
    538c:	8d 7e f8             	lea    di,[bp-0x8]
    538f:	16                   	push   ss
    5390:	57                   	push   di
    5391:	8d 7e f8             	lea    di,[bp-0x8]
    5394:	16                   	push   ss
    5395:	57                   	push   di
    5396:	9a dd 53 00 00       	call   0x0:0x53dd
    539b:	8d 7e ec             	lea    di,[bp-0x14]
    539e:	16                   	push   ss
    539f:	57                   	push   di
    53a0:	6a 00                	push   0x0
    53a2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    53a5:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    53a9:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    53ad:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    53b1:	9a 88 06 fc 53       	call   0x53fc:0x688
    53b6:	8d 7e f8             	lea    di,[bp-0x8]
    53b9:	16                   	push   ss
    53ba:	57                   	push   di
    53bb:	6a 08                	push   0x8
    53bd:	9a 1b 16 08 54       	call   0x5408:0x161b
    53c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53c5:	06                   	push   es
    53c6:	57                   	push   di
    53c7:	9a b9 62 12 54       	call   0x5412:0x62b9
    53cc:	50                   	push   ax
    53cd:	6a 00                	push   0x0
    53cf:	ff 76 0e             	push   WORD PTR [bp+0xe]
    53d2:	8d 7e f8             	lea    di,[bp-0x8]
    53d5:	16                   	push   ss
    53d6:	57                   	push   di
    53d7:	8d 7e f8             	lea    di,[bp-0x8]
    53da:	16                   	push   ss
    53db:	57                   	push   di
    53dc:	9a 26 54 00 00       	call   0x0:0x5426
    53e1:	8d 7e ec             	lea    di,[bp-0x14]
    53e4:	16                   	push   ss
    53e5:	57                   	push   di
    53e6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    53e9:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    53ed:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    53f1:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    53f5:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    53f9:	9a 88 06 85 82       	call   0x8285:0x688
    53fe:	8d 7e f8             	lea    di,[bp-0x8]
    5401:	16                   	push   ss
    5402:	57                   	push   di
    5403:	6a 08                	push   0x8
    5405:	9a 1b 16 5a 55       	call   0x555a:0x161b
    540a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    540d:	06                   	push   es
    540e:	57                   	push   di
    540f:	9a b9 62 ff 56       	call   0x56ff:0x62b9
    5414:	50                   	push   ax
    5415:	ff 76 10             	push   WORD PTR [bp+0x10]
    5418:	ff 76 0e             	push   WORD PTR [bp+0xe]
    541b:	8d 7e f8             	lea    di,[bp-0x8]
    541e:	16                   	push   ss
    541f:	57                   	push   di
    5420:	8d 7e f8             	lea    di,[bp-0x8]
    5423:	16                   	push   ss
    5424:	57                   	push   di
    5425:	9a ff ff 00 00       	call   0x0:0xffff
    542a:	c9                   	leave
    542b:	ca 0c 00             	retf   0xc
    542e:	c8 1c 00 00          	enter  0x1c,0x0
    5432:	8d 7e e4             	lea    di,[bp-0x1c]
    5435:	16                   	push   ss
    5436:	57                   	push   di
    5437:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    543a:	06                   	push   es
    543b:	57                   	push   di
    543c:	9a 4f 34 54 54       	call   0x5454:0x344f
    5441:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5444:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5447:	8d 7e e4             	lea    di,[bp-0x1c]
    544a:	16                   	push   ss
    544b:	57                   	push   di
    544c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    544f:	06                   	push   es
    5450:	57                   	push   di
    5451:	9a aa 52 66 54       	call   0x5466:0x52aa
    5456:	c9                   	leave
    5457:	ca 08 00             	retf   0x8
    545a:	c8 40 00 00          	enter  0x40,0x0
    545e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5461:	06                   	push   es
    5462:	57                   	push   di
    5463:	9a 2f 57 75 54       	call   0x5475:0x572f
    5468:	8d 7e e4             	lea    di,[bp-0x1c]
    546b:	16                   	push   ss
    546c:	57                   	push   di
    546d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5470:	06                   	push   es
    5471:	57                   	push   di
    5472:	9a 4f 34 26 55       	call   0x5526:0x344f
    5477:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    547a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    547d:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    5481:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5484:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    5489:	7c 09                	jl     0x5494
    548b:	7f 2c                	jg     0x54b9
    548d:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    5492:	73 25                	jae    0x54b9
    5494:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5497:	26 8b 05             	mov    ax,WORD PTR es:[di]
    549a:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    549e:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    54a1:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    54a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54a7:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    54ac:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    54b1:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    54b4:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    54b7:	eb 23                	jmp    0x54dc
    54b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54bc:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    54c1:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    54c6:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    54c9:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    54cc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    54cf:	26 8b 05             	mov    ax,WORD PTR es:[di]
    54d2:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    54d6:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    54d9:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    54dc:	31 c0                	xor    ax,ax
    54de:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    54e1:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    54e4:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    54e7:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
    54ea:	2d 01 00             	sub    ax,0x1
    54ed:	83 da 00             	sbb    dx,0x0
    54f0:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    54f3:	89 56 c2             	mov    WORD PTR [bp-0x3e],dx
    54f6:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    54f9:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    54fc:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    54ff:	7f 6e                	jg     0x556f
    5501:	7c 05                	jl     0x5508
    5503:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    5506:	77 67                	ja     0x556f
    5508:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    550b:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    550e:	eb 08                	jmp    0x5518
    5510:	83 46 cc 01          	add    WORD PTR [bp-0x34],0x1
    5514:	83 56 ce 00          	adc    WORD PTR [bp-0x32],0x0
    5518:	ff 76 ce             	push   WORD PTR [bp-0x32]
    551b:	ff 76 cc             	push   WORD PTR [bp-0x34]
    551e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5521:	06                   	push   es
    5522:	57                   	push   di
    5523:	9a 30 6e 4d 55       	call   0x554d:0x6e30
    5528:	03 46 e4             	add    ax,WORD PTR [bp-0x1c]
    552b:	99                   	cwd
    552c:	01 46 d0             	add    WORD PTR [bp-0x30],ax
    552f:	11 56 d2             	adc    WORD PTR [bp-0x2e],dx
    5532:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    5535:	2b 46 e8             	sub    ax,WORD PTR [bp-0x18]
    5538:	99                   	cwd
    5539:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
    553c:	7c 07                	jl     0x5545
    553e:	7f 1f                	jg     0x555f
    5540:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
    5543:	73 1a                	jae    0x555f
    5545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5548:	06                   	push   es
    5549:	57                   	push   di
    554a:	9a 82 48 51 56       	call   0x5651:0x4882
    554f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5552:	06                   	push   es
    5553:	57                   	push   di
    5554:	b8 e3 ff             	mov    ax,0xffe3
    5557:	9a 6a 20 85 56       	call   0x5685:0x206a
    555c:	e9 8d 01             	jmp    0x56ec
    555f:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    5562:	8b 56 ce             	mov    dx,WORD PTR [bp-0x32]
    5565:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    5568:	75 a6                	jne    0x5510
    556a:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    556d:	75 a1                	jne    0x5510
    556f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5572:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5575:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    5579:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    557c:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    5581:	7c 09                	jl     0x558c
    5583:	7f 1a                	jg     0x559f
    5585:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    558a:	73 13                	jae    0x559f
    558c:	8b 46 d0             	mov    ax,WORD PTR [bp-0x30]
    558f:	8b 56 d2             	mov    dx,WORD PTR [bp-0x2e]
    5592:	f7 d2                	not    dx
    5594:	f7 d8                	neg    ax
    5596:	83 da ff             	sbb    dx,0xffff
    5599:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    559c:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    559f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    55a2:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    55a6:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    55aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55ad:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    55b2:	7c 09                	jl     0x55bd
    55b4:	7f 2d                	jg     0x55e3
    55b6:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    55bb:	73 26                	jae    0x55e3
    55bd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    55c0:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    55c4:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    55c8:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    55cb:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    55ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55d1:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    55d6:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    55db:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    55de:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    55e1:	eb 24                	jmp    0x5607
    55e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55e6:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    55eb:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    55f0:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    55f3:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    55f6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    55f9:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    55fd:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5601:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    5604:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    5607:	31 c0                	xor    ax,ax
    5609:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    560c:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    560f:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    5612:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
    5615:	2d 01 00             	sub    ax,0x1
    5618:	83 da 00             	sbb    dx,0x0
    561b:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    561e:	89 56 c2             	mov    WORD PTR [bp-0x3e],dx
    5621:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    5624:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    5627:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    562a:	7f 6d                	jg     0x5699
    562c:	7c 05                	jl     0x5633
    562e:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    5631:	77 66                	ja     0x5699
    5633:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    5636:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    5639:	eb 08                	jmp    0x5643
    563b:	83 46 cc 01          	add    WORD PTR [bp-0x34],0x1
    563f:	83 56 ce 00          	adc    WORD PTR [bp-0x32],0x0
    5643:	ff 76 ce             	push   WORD PTR [bp-0x32]
    5646:	ff 76 cc             	push   WORD PTR [bp-0x34]
    5649:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    564c:	06                   	push   es
    564d:	57                   	push   di
    564e:	9a 8b 6e 78 56       	call   0x5678:0x6e8b
    5653:	03 46 e6             	add    ax,WORD PTR [bp-0x1a]
    5656:	99                   	cwd
    5657:	01 46 d4             	add    WORD PTR [bp-0x2c],ax
    565a:	11 56 d6             	adc    WORD PTR [bp-0x2a],dx
    565d:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    5660:	2b 46 ea             	sub    ax,WORD PTR [bp-0x16]
    5663:	99                   	cwd
    5664:	3b 56 d6             	cmp    dx,WORD PTR [bp-0x2a]
    5667:	7c 07                	jl     0x5670
    5669:	7f 1e                	jg     0x5689
    566b:	3b 46 d4             	cmp    ax,WORD PTR [bp-0x2c]
    566e:	73 19                	jae    0x5689
    5670:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5673:	06                   	push   es
    5674:	57                   	push   di
    5675:	9a 82 48 dd 56       	call   0x56dd:0x4882
    567a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    567d:	06                   	push   es
    567e:	57                   	push   di
    567f:	b8 e3 ff             	mov    ax,0xffe3
    5682:	9a 6a 20 ea 56       	call   0x56ea:0x206a
    5687:	eb 63                	jmp    0x56ec
    5689:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    568c:	8b 56 ce             	mov    dx,WORD PTR [bp-0x32]
    568f:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    5692:	75 a7                	jne    0x563b
    5694:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    5697:	75 a2                	jne    0x563b
    5699:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    569c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    56a0:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    56a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56a7:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    56ac:	7c 09                	jl     0x56b7
    56ae:	7f 1a                	jg     0x56ca
    56b0:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    56b5:	73 13                	jae    0x56ca
    56b7:	8b 46 d4             	mov    ax,WORD PTR [bp-0x2c]
    56ba:	8b 56 d6             	mov    dx,WORD PTR [bp-0x2a]
    56bd:	f7 d2                	not    dx
    56bf:	f7 d8                	neg    ax
    56c1:	83 da ff             	sbb    dx,0xffff
    56c4:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    56c7:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    56ca:	ff 76 d0             	push   WORD PTR [bp-0x30]
    56cd:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    56d0:	8d 7e e4             	lea    di,[bp-0x1c]
    56d3:	16                   	push   ss
    56d4:	57                   	push   di
    56d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d8:	06                   	push   es
    56d9:	57                   	push   di
    56da:	9a aa 52 5c 57       	call   0x575c:0x52aa
    56df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56e2:	06                   	push   es
    56e3:	57                   	push   di
    56e4:	b8 e3 ff             	mov    ax,0xffe3
    56e7:	9a 6a 20 b0 57       	call   0x57b0:0x206a
    56ec:	c9                   	leave
    56ed:	ca 08 00             	retf   0x8
    56f0:	55                   	push   bp
    56f1:	89 e5                	mov    bp,sp
    56f3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    56f6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    56fa:	06                   	push   es
    56fb:	57                   	push   di
    56fc:	9a b9 62 1b 57       	call   0x571b:0x62b9
    5701:	50                   	push   ax
    5702:	ff 76 08             	push   WORD PTR [bp+0x8]
    5705:	9a ff ff 00 00       	call   0x0:0xffff
    570a:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    570d:	74 1c                	je     0x572b
    570f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5712:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5716:	06                   	push   es
    5717:	57                   	push   di
    5718:	9a b9 62 3b 57       	call   0x573b:0x62b9
    571d:	50                   	push   ax
    571e:	ff 76 08             	push   WORD PTR [bp+0x8]
    5721:	ff 76 06             	push   WORD PTR [bp+0x6]
    5724:	6a 01                	push   0x1
    5726:	9a ff ff 00 00       	call   0x0:0xffff
    572b:	c9                   	leave
    572c:	c2 06 00             	ret    0x6
    572f:	c8 2c 00 00          	enter  0x2c,0x0
    5733:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5736:	06                   	push   es
    5737:	57                   	push   di
    5738:	9a fa 64 e6 58       	call   0x58e6:0x64fa
    573d:	08 c0                	or     al,al
    573f:	74 0b                	je     0x574c
    5741:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5744:	26 80 bd 12 01 00    	cmp    BYTE PTR es:[di+0x112],0x0
    574a:	75 03                	jne    0x574f
    574c:	e9 24 01             	jmp    0x5873
    574f:	8d 7e e4             	lea    di,[bp-0x1c]
    5752:	16                   	push   ss
    5753:	57                   	push   di
    5754:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5757:	06                   	push   es
    5758:	57                   	push   di
    5759:	9a 4f 34 a4 57       	call   0x57a4:0x344f
    575e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5761:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5766:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    576b:	2d 01 00             	sub    ax,0x1
    576e:	83 da 00             	sbb    dx,0x0
    5771:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5774:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    5777:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    577c:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    5781:	2d 01 00             	sub    ax,0x1
    5784:	83 da 00             	sbb    dx,0x0
    5787:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    578a:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    578d:	8d 7e d4             	lea    di,[bp-0x2c]
    5790:	16                   	push   ss
    5791:	57                   	push   di
    5792:	8d 7e dc             	lea    di,[bp-0x24]
    5795:	16                   	push   ss
    5796:	57                   	push   di
    5797:	8d 7e e4             	lea    di,[bp-0x1c]
    579a:	16                   	push   ss
    579b:	57                   	push   di
    579c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    579f:	06                   	push   es
    57a0:	57                   	push   di
    57a1:	9a 01 37 34 59       	call   0x5934:0x3701
    57a6:	8d 7e dc             	lea    di,[bp-0x24]
    57a9:	16                   	push   ss
    57aa:	57                   	push   di
    57ab:	6a 08                	push   0x8
    57ad:	9a 1b 16 ad 59       	call   0x59ad:0x161b
    57b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57b5:	26 8a 85 12 01       	mov    al,BYTE PTR es:[di+0x112]
    57ba:	3c 01                	cmp    al,0x1
    57bc:	74 04                	je     0x57c2
    57be:	3c 03                	cmp    al,0x3
    57c0:	75 62                	jne    0x5824
    57c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57c5:	26 83 bd e8 00 00    	cmp    WORD PTR es:[di+0xe8],0x0
    57cb:	75 15                	jne    0x57e2
    57cd:	26 83 bd e6 00 01    	cmp    WORD PTR es:[di+0xe6],0x1
    57d3:	75 0d                	jne    0x57e2
    57d5:	6a 00                	push   0x0
    57d7:	26 ff b5 3d 01       	push   WORD PTR es:[di+0x13d]
    57dc:	55                   	push   bp
    57dd:	e8 10 ff             	call   0x56f0
    57e0:	eb 42                	jmp    0x5824
    57e2:	6a 00                	push   0x0
    57e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57e7:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    57ec:	99                   	cwd
    57ed:	8b c8                	mov    cx,ax
    57ef:	8b da                	mov    bx,dx
    57f1:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    57f6:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    57fb:	2b c1                	sub    ax,cx
    57fd:	1b d3                	sbb    dx,bx
    57ff:	52                   	push   dx
    5800:	50                   	push   ax
    5801:	6a 00                	push   0x0
    5803:	68 ff 7f             	push   0x7fff
    5806:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    580b:	99                   	cwd
    580c:	8b c8                	mov    cx,ax
    580e:	8b da                	mov    bx,dx
    5810:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    5813:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    5816:	2b c1                	sub    ax,cx
    5818:	1b d3                	sbb    dx,bx
    581a:	52                   	push   dx
    581b:	50                   	push   ax
    581c:	e8 60 bd             	call   0x157f
    581f:	50                   	push   ax
    5820:	55                   	push   bp
    5821:	e8 cc fe             	call   0x56f0
    5824:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5827:	26 8a 85 12 01       	mov    al,BYTE PTR es:[di+0x112]
    582c:	3c 02                	cmp    al,0x2
    582e:	72 43                	jb     0x5873
    5830:	3c 03                	cmp    al,0x3
    5832:	77 3f                	ja     0x5873
    5834:	6a 01                	push   0x1
    5836:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    583b:	99                   	cwd
    583c:	8b c8                	mov    cx,ax
    583e:	8b da                	mov    bx,dx
    5840:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    5845:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    584a:	2b c1                	sub    ax,cx
    584c:	1b d3                	sbb    dx,bx
    584e:	52                   	push   dx
    584f:	50                   	push   ax
    5850:	6a 00                	push   0x0
    5852:	68 ff 7f             	push   0x7fff
    5855:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    585a:	99                   	cwd
    585b:	8b c8                	mov    cx,ax
    585d:	8b da                	mov    bx,dx
    585f:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    5862:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    5865:	2b c1                	sub    ax,cx
    5867:	1b d3                	sbb    dx,bx
    5869:	52                   	push   dx
    586a:	50                   	push   ax
    586b:	e8 11 bd             	call   0x157f
    586e:	50                   	push   ax
    586f:	55                   	push   bp
    5870:	e8 7d fe             	call   0x56f0
    5873:	c9                   	leave
    5874:	ca 04 00             	retf   0x4
    5877:	55                   	push   bp
    5878:	89 e5                	mov    bp,sp
    587a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    587d:	36 80 7d d2 00       	cmp    BYTE PTR ss:[di-0x2e],0x0
    5882:	75 18                	jne    0x589c
    5884:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5887:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    588b:	06                   	push   es
    588c:	57                   	push   di
    588d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5890:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    5894:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5897:	36 c6 45 d2 01       	mov    BYTE PTR ss:[di-0x2e],0x1
    589c:	c9                   	leave
    589d:	c2 02 00             	ret    0x2
    58a0:	c8 06 00 00          	enter  0x6,0x0
    58a4:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    58a8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    58ab:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    58af:	26 80 bd 12 01 03    	cmp    BYTE PTR es:[di+0x112],0x3
    58b5:	74 23                	je     0x58da
    58b7:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    58bb:	75 08                	jne    0x58c5
    58bd:	26 80 bd 12 01 01    	cmp    BYTE PTR es:[di+0x112],0x1
    58c3:	74 15                	je     0x58da
    58c5:	83 7e 06 01          	cmp    WORD PTR [bp+0x6],0x1
    58c9:	75 3e                	jne    0x5909
    58cb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    58ce:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    58d2:	26 80 bd 12 01 02    	cmp    BYTE PTR es:[di+0x112],0x2
    58d8:	75 2f                	jne    0x5909
    58da:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    58dd:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    58e1:	06                   	push   es
    58e2:	57                   	push   di
    58e3:	9a b9 62 e5 59       	call   0x59e5:0x62b9
    58e8:	50                   	push   ax
    58e9:	ff 76 06             	push   WORD PTR [bp+0x6]
    58ec:	8d 7e fc             	lea    di,[bp-0x4]
    58ef:	16                   	push   ss
    58f0:	57                   	push   di
    58f1:	8d 7e fa             	lea    di,[bp-0x6]
    58f4:	16                   	push   ss
    58f5:	57                   	push   di
    58f6:	9a ff ff 00 00       	call   0x0:0xffff
    58fb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    58fe:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    5901:	b0 00                	mov    al,0x0
    5903:	74 01                	je     0x5906
    5905:	40                   	inc    ax
    5906:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5909:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    590c:	c9                   	leave
    590d:	c2 04 00             	ret    0x4
    5910:	c8 08 00 00          	enter  0x8,0x0
    5914:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5917:	81 c7 d4 ff          	add    di,0xffd4
    591b:	16                   	push   ss
    591c:	57                   	push   di
    591d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5920:	36 ff 75 e2          	push   WORD PTR ss:[di-0x1e]
    5924:	36 ff 75 e0          	push   WORD PTR ss:[di-0x20]
    5928:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    592b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    592f:	06                   	push   es
    5930:	57                   	push   di
    5931:	9a 7b 34 9d 59       	call   0x599d:0x347b
    5936:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5939:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    593d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5942:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    5947:	2d 01 00             	sub    ax,0x1
    594a:	83 da 00             	sbb    dx,0x0
    594d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5950:	36 89 45 f8          	mov    WORD PTR ss:[di-0x8],ax
    5954:	36 89 55 fa          	mov    WORD PTR ss:[di-0x6],dx
    5958:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    595b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    595f:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    5964:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    5969:	2d 01 00             	sub    ax,0x1
    596c:	83 da 00             	sbb    dx,0x0
    596f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5972:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    5976:	36 89 55 fe          	mov    WORD PTR ss:[di-0x2],dx
    597a:	8d 7e f8             	lea    di,[bp-0x8]
    597d:	16                   	push   ss
    597e:	57                   	push   di
    597f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5982:	81 c7 f8 ff          	add    di,0xfff8
    5986:	16                   	push   ss
    5987:	57                   	push   di
    5988:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    598b:	81 c7 d4 ff          	add    di,0xffd4
    598f:	16                   	push   ss
    5990:	57                   	push   di
    5991:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5994:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5998:	06                   	push   es
    5999:	57                   	push   di
    599a:	9a 01 37 f8 59       	call   0x59f8:0x3701
    599f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    59a2:	81 c7 f8 ff          	add    di,0xfff8
    59a6:	16                   	push   ss
    59a7:	57                   	push   di
    59a8:	6a 08                	push   0x8
    59aa:	9a 1b 16 f8 5b       	call   0x5bf8:0x161b
    59af:	c9                   	leave
    59b0:	c2 02 00             	ret    0x2
    59b3:	c8 02 00 00          	enter  0x2,0x0
    59b7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    59ba:	36 8a 45 d3          	mov    al,BYTE PTR ss:[di-0x2d]
    59be:	3c 01                	cmp    al,0x1
    59c0:	74 07                	je     0x59c9
    59c2:	3c 03                	cmp    al,0x3
    59c4:	74 03                	je     0x59c9
    59c6:	e9 fe 00             	jmp    0x5ac7
    59c9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    59cc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    59d0:	26 83 bd e8 00 00    	cmp    WORD PTR es:[di+0xe8],0x0
    59d6:	75 53                	jne    0x5a2b
    59d8:	26 83 bd e6 00 01    	cmp    WORD PTR es:[di+0xe6],0x1
    59de:	75 4b                	jne    0x5a2b
    59e0:	06                   	push   es
    59e1:	57                   	push   di
    59e2:	9a a9 18 17 5a       	call   0x5a17:0x18a9
    59e7:	50                   	push   ax
    59e8:	6a 00                	push   0x0
    59ea:	6a 00                	push   0x0
    59ec:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    59ef:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    59f3:	06                   	push   es
    59f4:	57                   	push   di
    59f5:	9a 30 6e 84 5b       	call   0x5b84:0x6e30
    59fa:	5a                   	pop    dx
    59fb:	2b c2                	sub    ax,dx
    59fd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5a00:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    5a04:	7d 05                	jge    0x5a0b
    5a06:	31 c0                	xor    ax,ax
    5a08:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5a0b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a0e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5a12:	06                   	push   es
    5a13:	57                   	push   di
    5a14:	9a b9 62 5c 5a       	call   0x5a5c:0x62b9
    5a19:	50                   	push   ax
    5a1a:	6a 00                	push   0x0
    5a1c:	6a 00                	push   0x0
    5a1e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5a21:	6a 01                	push   0x1
    5a23:	9a 69 5a 00 00       	call   0x0:0x5a69
    5a28:	e9 9c 00             	jmp    0x5ac7
    5a2b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a2e:	57                   	push   di
    5a2f:	e8 de fe             	call   0x5910
    5a32:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a35:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5a39:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    5a3e:	99                   	cwd
    5a3f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a42:	36 3b 55 fa          	cmp    dx,WORD PTR ss:[di-0x6]
    5a46:	7c 08                	jl     0x5a50
    5a48:	7f 25                	jg     0x5a6f
    5a4a:	36 3b 45 f8          	cmp    ax,WORD PTR ss:[di-0x8]
    5a4e:	73 1f                	jae    0x5a6f
    5a50:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a53:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5a57:	06                   	push   es
    5a58:	57                   	push   di
    5a59:	9a b9 62 7b 5a       	call   0x5a7b:0x62b9
    5a5e:	50                   	push   ax
    5a5f:	6a 00                	push   0x0
    5a61:	6a 00                	push   0x0
    5a63:	68 ff 7f             	push   0x7fff
    5a66:	6a 01                	push   0x1
    5a68:	9a 87 5a 00 00       	call   0x0:0x5a87
    5a6d:	eb 1c                	jmp    0x5a8b
    5a6f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a72:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5a76:	06                   	push   es
    5a77:	57                   	push   di
    5a78:	9a b9 62 11 5b       	call   0x5b11:0x62b9
    5a7d:	50                   	push   ax
    5a7e:	6a 00                	push   0x0
    5a80:	6a 00                	push   0x0
    5a82:	6a 00                	push   0x0
    5a84:	6a 01                	push   0x1
    5a86:	9a 1e 5b 00 00       	call   0x0:0x5b1e
    5a8b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5a8e:	36 8b 45 f0          	mov    ax,WORD PTR ss:[di-0x10]
    5a92:	36 8b 55 f2          	mov    dx,WORD PTR ss:[di-0xe]
    5a96:	36 3b 55 fa          	cmp    dx,WORD PTR ss:[di-0x6]
    5a9a:	7f 08                	jg     0x5aa4
    5a9c:	7c 29                	jl     0x5ac7
    5a9e:	36 3b 45 f8          	cmp    ax,WORD PTR ss:[di-0x8]
    5aa2:	76 23                	jbe    0x5ac7
    5aa4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5aa7:	57                   	push   di
    5aa8:	e8 cc fd             	call   0x5877
    5aab:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5aae:	36 8b 45 f8          	mov    ax,WORD PTR ss:[di-0x8]
    5ab2:	36 8b 55 fa          	mov    dx,WORD PTR ss:[di-0x6]
    5ab6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5ab9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5abd:	26 89 85 13 01       	mov    WORD PTR es:[di+0x113],ax
    5ac2:	26 89 95 15 01       	mov    WORD PTR es:[di+0x115],dx
    5ac7:	c9                   	leave
    5ac8:	c2 02 00             	ret    0x2
    5acb:	55                   	push   bp
    5acc:	89 e5                	mov    bp,sp
    5ace:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5ad1:	36 8a 45 d3          	mov    al,BYTE PTR ss:[di-0x2d]
    5ad5:	3c 02                	cmp    al,0x2
    5ad7:	73 03                	jae    0x5adc
    5ad9:	e9 a0 00             	jmp    0x5b7c
    5adc:	3c 03                	cmp    al,0x3
    5ade:	76 03                	jbe    0x5ae3
    5ae0:	e9 99 00             	jmp    0x5b7c
    5ae3:	57                   	push   di
    5ae4:	e8 29 fe             	call   0x5910
    5ae7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5aea:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5aee:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    5af3:	99                   	cwd
    5af4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5af7:	36 3b 55 fe          	cmp    dx,WORD PTR ss:[di-0x2]
    5afb:	7c 08                	jl     0x5b05
    5afd:	7f 25                	jg     0x5b24
    5aff:	36 3b 45 fc          	cmp    ax,WORD PTR ss:[di-0x4]
    5b03:	73 1f                	jae    0x5b24
    5b05:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5b08:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5b0c:	06                   	push   es
    5b0d:	57                   	push   di
    5b0e:	9a b9 62 30 5b       	call   0x5b30:0x62b9
    5b13:	50                   	push   ax
    5b14:	6a 01                	push   0x1
    5b16:	6a 00                	push   0x0
    5b18:	68 ff 7f             	push   0x7fff
    5b1b:	6a 01                	push   0x1
    5b1d:	9a 3c 5b 00 00       	call   0x0:0x5b3c
    5b22:	eb 1c                	jmp    0x5b40
    5b24:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5b27:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5b2b:	06                   	push   es
    5b2c:	57                   	push   di
    5b2d:	9a b9 62 9a 5b       	call   0x5b9a:0x62b9
    5b32:	50                   	push   ax
    5b33:	6a 01                	push   0x1
    5b35:	6a 00                	push   0x0
    5b37:	6a 00                	push   0x0
    5b39:	6a 01                	push   0x1
    5b3b:	9a ff ff 00 00       	call   0x0:0xffff
    5b40:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5b43:	36 8b 45 f4          	mov    ax,WORD PTR ss:[di-0xc]
    5b47:	36 8b 55 f6          	mov    dx,WORD PTR ss:[di-0xa]
    5b4b:	36 3b 55 fe          	cmp    dx,WORD PTR ss:[di-0x2]
    5b4f:	7f 08                	jg     0x5b59
    5b51:	7c 29                	jl     0x5b7c
    5b53:	36 3b 45 fc          	cmp    ax,WORD PTR ss:[di-0x4]
    5b57:	76 23                	jbe    0x5b7c
    5b59:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5b5c:	57                   	push   di
    5b5d:	e8 17 fd             	call   0x5877
    5b60:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5b63:	36 8b 45 fc          	mov    ax,WORD PTR ss:[di-0x4]
    5b67:	36 8b 55 fe          	mov    dx,WORD PTR ss:[di-0x2]
    5b6b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5b6e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5b72:	26 89 85 17 01       	mov    WORD PTR es:[di+0x117],ax
    5b77:	26 89 95 19 01       	mov    WORD PTR es:[di+0x119],dx
    5b7c:	c9                   	leave
    5b7d:	c2 02 00             	ret    0x2
    5b80:	00 00                	add    BYTE PTR [bx+si],al
    5b82:	5e                   	pop    si
    5b83:	5c                   	pop    sp
    5b84:	72 5c                	jb     0x5be2
    5b86:	c8 2e 00 00          	enter  0x2e,0x0
    5b8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b8d:	26 80 bd 12 01 00    	cmp    BYTE PTR es:[di+0x112],0x0
    5b93:	74 0b                	je     0x5ba0
    5b95:	06                   	push   es
    5b96:	57                   	push   di
    5b97:	9a fa 64 ab 5b       	call   0x5bab:0x64fa
    5b9c:	08 c0                	or     al,al
    5b9e:	75 03                	jne    0x5ba3
    5ba0:	e9 0b 01             	jmp    0x5cae
    5ba3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ba6:	06                   	push   es
    5ba7:	57                   	push   di
    5ba8:	9a a9 18 b8 5b       	call   0x5bb8:0x18a9
    5bad:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    5bb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bb3:	06                   	push   es
    5bb4:	57                   	push   di
    5bb5:	9a f4 18 29 5c       	call   0x5c29:0x18f4
    5bba:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5bbd:	6a 00                	push   0x0
    5bbf:	55                   	push   bp
    5bc0:	e8 dd fc             	call   0x58a0
    5bc3:	08 c0                	or     al,al
    5bc5:	74 0a                	je     0x5bd1
    5bc7:	6a 03                	push   0x3
    5bc9:	9a de 5b 00 00       	call   0x0:0x5bde
    5bce:	01 46 e0             	add    WORD PTR [bp-0x20],ax
    5bd1:	6a 01                	push   0x1
    5bd3:	55                   	push   bp
    5bd4:	e8 c9 fc             	call   0x58a0
    5bd7:	08 c0                	or     al,al
    5bd9:	74 0a                	je     0x5be5
    5bdb:	6a 02                	push   0x2
    5bdd:	9a ff ff 00 00       	call   0x0:0xffff
    5be2:	01 46 e2             	add    WORD PTR [bp-0x1e],ax
    5be5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5be8:	81 c7 13 01          	add    di,0x113
    5bec:	06                   	push   es
    5bed:	57                   	push   di
    5bee:	8d 7e f0             	lea    di,[bp-0x10]
    5bf1:	16                   	push   ss
    5bf2:	57                   	push   di
    5bf3:	6a 08                	push   0x8
    5bf5:	9a 1b 16 fd 5e       	call   0x5efd:0x161b
    5bfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bfd:	26 8a 85 12 01       	mov    al,BYTE PTR es:[di+0x112]
    5c02:	88 46 d3             	mov    BYTE PTR [bp-0x2d],al
    5c05:	26 c6 85 12 01 00    	mov    BYTE PTR es:[di+0x112],0x0
    5c0b:	c6 46 d2 00          	mov    BYTE PTR [bp-0x2e],0x0
    5c0f:	b8 80 5b             	mov    ax,0x5b80
    5c12:	0e                   	push   cs
    5c13:	50                   	push   ax
    5c14:	55                   	push   bp
    5c15:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5c19:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5c1d:	55                   	push   bp
    5c1e:	e8 92 fd             	call   0x59b3
    5c21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c24:	06                   	push   es
    5c25:	57                   	push   di
    5c26:	9a f4 18 3a 5c       	call   0x5c3a:0x18f4
    5c2b:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5c2e:	55                   	push   bp
    5c2f:	e8 99 fe             	call   0x5acb
    5c32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c35:	06                   	push   es
    5c36:	57                   	push   di
    5c37:	9a a9 18 49 5c       	call   0x5c49:0x18a9
    5c3c:	3b 46 e2             	cmp    ax,WORD PTR [bp-0x1e]
    5c3f:	74 11                	je     0x5c52
    5c41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c44:	06                   	push   es
    5c45:	57                   	push   di
    5c46:	9a a9 18 ed 5c       	call   0x5ced:0x18a9
    5c4b:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    5c4e:	55                   	push   bp
    5c4f:	e8 61 fd             	call   0x59b3
    5c52:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5c56:	83 c4 06             	add    sp,0x6
    5c59:	b8 6a 5c             	mov    ax,0x5c6a
    5c5c:	0e                   	push   cs
    5c5d:	50                   	push   ax
    5c5e:	8a 46 d3             	mov    al,BYTE PTR [bp-0x2d]
    5c61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c64:	26 88 85 12 01       	mov    BYTE PTR es:[di+0x112],al
    5c69:	cb                   	retf
    5c6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c6d:	06                   	push   es
    5c6e:	57                   	push   di
    5c6f:	9a 2f 57 ac 5c       	call   0x5cac:0x572f
    5c74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c77:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    5c7c:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    5c81:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    5c84:	75 19                	jne    0x5c9f
    5c86:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    5c89:	75 14                	jne    0x5c9f
    5c8b:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    5c90:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    5c95:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    5c98:	75 05                	jne    0x5c9f
    5c9a:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    5c9d:	74 0f                	je     0x5cae
    5c9f:	8d 7e f0             	lea    di,[bp-0x10]
    5ca2:	16                   	push   ss
    5ca3:	57                   	push   di
    5ca4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ca7:	06                   	push   es
    5ca8:	57                   	push   di
    5ca9:	9a 5a 54 c3 5c       	call   0x5cc3:0x545a
    5cae:	c9                   	leave
    5caf:	ca 04 00             	retf   0x4
    5cb2:	c8 04 00 00          	enter  0x4,0x0
    5cb6:	ff 76 08             	push   WORD PTR [bp+0x8]
    5cb9:	ff 76 06             	push   WORD PTR [bp+0x6]
    5cbc:	b0 01                	mov    al,0x1
    5cbe:	50                   	push   ax
    5cbf:	b8 58 00             	mov    ax,0x58
    5cc2:	ba ca 5c             	mov    dx,0x5cca
    5cc5:	52                   	push   dx
    5cc6:	50                   	push   ax
    5cc7:	9a 15 16 ad 5d       	call   0x5dad:0x1615
    5ccc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5ccf:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5cd2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5cd5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5cd8:	c9                   	leave
    5cd9:	ca 04 00             	retf   0x4
    5cdc:	c8 04 00 00          	enter  0x4,0x0
    5ce0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5ce3:	06                   	push   es
    5ce4:	57                   	push   di
    5ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ce8:	06                   	push   es
    5ce9:	57                   	push   di
    5cea:	9a 29 3b e6 5e       	call   0x5ee6:0x3b29
    5cef:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5cf2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5cf5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5cf8:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5cfc:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5d00:	0d 00 00             	or     ax,0x0
    5d03:	81 ca 01 00          	or     dx,0x1
    5d07:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5d0b:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5d0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d12:	26 80 bd e4 00 01    	cmp    BYTE PTR es:[di+0xe4],0x1
    5d18:	75 1a                	jne    0x5d34
    5d1a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5d1d:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5d21:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5d25:	0d 00 00             	or     ax,0x0
    5d28:	81 ca 80 00          	or     dx,0x80
    5d2c:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5d30:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5d34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d37:	26 8a 85 12 01       	mov    al,BYTE PTR es:[di+0x112]
    5d3c:	3c 02                	cmp    al,0x2
    5d3e:	72 1e                	jb     0x5d5e
    5d40:	3c 03                	cmp    al,0x3
    5d42:	77 1a                	ja     0x5d5e
    5d44:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5d47:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5d4b:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5d4f:	0d 00 00             	or     ax,0x0
    5d52:	81 ca 20 00          	or     dx,0x20
    5d56:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5d5a:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5d5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d61:	26 8a 85 12 01       	mov    al,BYTE PTR es:[di+0x112]
    5d66:	3c 01                	cmp    al,0x1
    5d68:	74 04                	je     0x5d6e
    5d6a:	3c 03                	cmp    al,0x3
    5d6c:	75 1a                	jne    0x5d88
    5d6e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5d71:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5d75:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5d79:	0d 00 00             	or     ax,0x0
    5d7c:	81 ca 10 00          	or     dx,0x10
    5d80:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5d84:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5d88:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5d8b:	26 c7 45 1a 08 00    	mov    WORD PTR es:[di+0x1a],0x8
    5d91:	c9                   	leave
    5d92:	ca 08 00             	retf   0x8
    5d95:	55                   	push   bp
    5d96:	89 e5                	mov    bp,sp
    5d98:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5d9b:	81 c7 cc ff          	add    di,0xffcc
    5d9f:	16                   	push   ss
    5da0:	57                   	push   di
    5da1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5da4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5da8:	06                   	push   es
    5da9:	57                   	push   di
    5daa:	9a 4f 34 34 62       	call   0x6234:0x344f
    5daf:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5db2:	36 8b 45 dc          	mov    ax,WORD PTR ss:[di-0x24]
    5db6:	36 8b 55 de          	mov    dx,WORD PTR ss:[di-0x22]
    5dba:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5dbd:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5dc1:	26 2b 85 13 01       	sub    ax,WORD PTR es:[di+0x113]
    5dc6:	26 1b 95 15 01       	sbb    dx,WORD PTR es:[di+0x115]
    5dcb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5dce:	36 89 45 ca          	mov    WORD PTR ss:[di-0x36],ax
    5dd2:	36 83 7d ca 01       	cmp    WORD PTR ss:[di-0x36],0x1
    5dd7:	7d 06                	jge    0x5ddf
    5dd9:	36 c7 45 ca 01 00    	mov    WORD PTR ss:[di-0x36],0x1
    5ddf:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5de2:	36 8b 45 e0          	mov    ax,WORD PTR ss:[di-0x20]
    5de6:	36 8b 55 e2          	mov    dx,WORD PTR ss:[di-0x1e]
    5dea:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5ded:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5df1:	26 2b 85 17 01       	sub    ax,WORD PTR es:[di+0x117]
    5df6:	26 1b 95 19 01       	sbb    dx,WORD PTR es:[di+0x119]
    5dfb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5dfe:	36 89 45 c8          	mov    WORD PTR ss:[di-0x38],ax
    5e02:	36 83 7d c8 01       	cmp    WORD PTR ss:[di-0x38],0x1
    5e07:	7d 06                	jge    0x5e0f
    5e09:	36 c7 45 c8 01 00    	mov    WORD PTR ss:[di-0x38],0x1
    5e0f:	c9                   	leave
    5e10:	c2 02 00             	ret    0x2
    5e13:	c8 04 00 00          	enter  0x4,0x0
    5e17:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    5e1a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5e1d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5e20:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5e23:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    5e27:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    5e2a:	7f 07                	jg     0x5e33
    5e2c:	7c 17                	jl     0x5e45
    5e2e:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    5e31:	76 12                	jbe    0x5e45
    5e33:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5e36:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    5e39:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e3c:	26 89 05             	mov    WORD PTR es:[di],ax
    5e3f:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    5e43:	eb 26                	jmp    0x5e6b
    5e45:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e48:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5e4b:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    5e4f:	3b 56 14             	cmp    dx,WORD PTR [bp+0x14]
    5e52:	7c 07                	jl     0x5e5b
    5e54:	7f 15                	jg     0x5e6b
    5e56:	3b 46 12             	cmp    ax,WORD PTR [bp+0x12]
    5e59:	73 10                	jae    0x5e6b
    5e5b:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    5e5e:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    5e61:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e64:	26 89 05             	mov    WORD PTR es:[di],ax
    5e67:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    5e6b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e6e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5e72:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5e76:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    5e79:	7f 07                	jg     0x5e82
    5e7b:	7c 18                	jl     0x5e95
    5e7d:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    5e80:	76 13                	jbe    0x5e95
    5e82:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5e85:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5e88:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e8b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5e8f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5e93:	eb 28                	jmp    0x5ebd
    5e95:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e98:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5e9c:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5ea0:	3b 56 10             	cmp    dx,WORD PTR [bp+0x10]
    5ea3:	7c 07                	jl     0x5eac
    5ea5:	7f 16                	jg     0x5ebd
    5ea7:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    5eaa:	73 11                	jae    0x5ebd
    5eac:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    5eaf:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    5eb2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5eb5:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5eb9:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5ebd:	c9                   	leave
    5ebe:	c2 16 00             	ret    0x16
    5ec1:	b5 5f                	mov    ch,0x5f
    5ec3:	ca 5f f5             	retf   0xf55f
    5ec6:	5f                   	pop    di
    5ec7:	d8 5f 72             	fcomp  DWORD PTR [bx+0x72]
    5eca:	5f                   	pop    di
    5ecb:	5c                   	pop    sp
    5ecc:	5f                   	pop    di
    5ecd:	94                   	xchg   sp,ax
    5ece:	5f                   	pop    di
    5ecf:	67 5f                	addr32 pop di
    5ed1:	c8 40 00 00          	enter  0x40,0x0
    5ed5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5ed8:	06                   	push   es
    5ed9:	57                   	push   di
    5eda:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5edd:	50                   	push   ax
    5ede:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ee1:	06                   	push   es
    5ee2:	57                   	push   di
    5ee3:	9a 6a 4f c6 63       	call   0x63c6:0x4f6a
    5ee8:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5eeb:	26 ff 35             	push   WORD PTR es:[di]
    5eee:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5ef1:	50                   	push   ax
    5ef2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ef5:	06                   	push   es
    5ef6:	57                   	push   di
    5ef7:	b8 ec ff             	mov    ax,0xffec
    5efa:	9a 6a 20 1e 5f       	call   0x5f1e:0x206a
    5eff:	08 c0                	or     al,al
    5f01:	75 08                	jne    0x5f0b
    5f03:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5f06:	31 c0                	xor    ax,ax
    5f08:	26 89 05             	mov    WORD PTR es:[di],ax
    5f0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f0e:	81 c7 f2 00          	add    di,0xf2
    5f12:	06                   	push   es
    5f13:	57                   	push   di
    5f14:	8d 7e f0             	lea    di,[bp-0x10]
    5f17:	16                   	push   ss
    5f18:	57                   	push   di
    5f19:	6a 08                	push   0x8
    5f1b:	9a 1b 16 33 5f       	call   0x5f33:0x161b
    5f20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f23:	81 c7 13 01          	add    di,0x113
    5f27:	06                   	push   es
    5f28:	57                   	push   di
    5f29:	8d 7e f8             	lea    di,[bp-0x8]
    5f2c:	16                   	push   ss
    5f2d:	57                   	push   di
    5f2e:	6a 08                	push   0x8
    5f30:	9a 1b 16 bc 62       	call   0x62bc:0x161b
    5f35:	55                   	push   bp
    5f36:	e8 5c fe             	call   0x5d95
    5f39:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    5f3d:	75 03                	jne    0x5f42
    5f3f:	e9 e5 00             	jmp    0x6027
    5f42:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5f45:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5f48:	2d 21 00             	sub    ax,0x21
    5f4b:	3d 07 00             	cmp    ax,0x7
    5f4e:	76 03                	jbe    0x5f53
    5f50:	e9 d1 00             	jmp    0x6024
    5f53:	89 c3                	mov    bx,ax
    5f55:	d1 e3                	shl    bx,1
    5f57:	2e ff a7 c1 5e       	jmp    WORD PTR cs:[bx+0x5ec1]
    5f5c:	83 6e fc 01          	sub    WORD PTR [bp-0x4],0x1
    5f60:	83 5e fe 00          	sbb    WORD PTR [bp-0x2],0x0
    5f64:	e9 bd 00             	jmp    0x6024
    5f67:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    5f6b:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    5f6f:	e9 b2 00             	jmp    0x6024
    5f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f75:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    5f7b:	75 14                	jne    0x5f91
    5f7d:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    5f80:	99                   	cwd
    5f81:	29 46 f0             	sub    WORD PTR [bp-0x10],ax
    5f84:	19 56 f2             	sbb    WORD PTR [bp-0xe],dx
    5f87:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    5f8a:	99                   	cwd
    5f8b:	29 46 f8             	sub    WORD PTR [bp-0x8],ax
    5f8e:	19 56 fa             	sbb    WORD PTR [bp-0x6],dx
    5f91:	e9 90 00             	jmp    0x6024
    5f94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f97:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    5f9d:	75 14                	jne    0x5fb3
    5f9f:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    5fa2:	99                   	cwd
    5fa3:	01 46 f0             	add    WORD PTR [bp-0x10],ax
    5fa6:	11 56 f2             	adc    WORD PTR [bp-0xe],dx
    5fa9:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    5fac:	99                   	cwd
    5fad:	01 46 f8             	add    WORD PTR [bp-0x8],ax
    5fb0:	11 56 fa             	adc    WORD PTR [bp-0x6],dx
    5fb3:	eb 6f                	jmp    0x6024
    5fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fb8:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    5fbd:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    5fc2:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5fc5:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5fc8:	eb 5a                	jmp    0x6024
    5fca:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    5fcd:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    5fd0:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5fd3:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5fd6:	eb 4c                	jmp    0x6024
    5fd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fdb:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    5fe0:	99                   	cwd
    5fe1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    5fe4:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    5fe7:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    5fec:	99                   	cwd
    5fed:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5ff0:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5ff3:	eb 2f                	jmp    0x6024
    5ff5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ff8:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5ffd:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    6002:	2d 01 00             	sub    ax,0x1
    6005:	83 da 00             	sbb    dx,0x0
    6008:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    600b:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    600e:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    6013:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    6018:	2d 01 00             	sub    ax,0x1
    601b:	83 da 00             	sbb    dx,0x0
    601e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6021:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    6024:	e9 43 02             	jmp    0x626a
    6027:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    602a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    602d:	3d 26 00             	cmp    ax,0x26
    6030:	75 0b                	jne    0x603d
    6032:	83 6e f4 01          	sub    WORD PTR [bp-0xc],0x1
    6036:	83 5e f6 00          	sbb    WORD PTR [bp-0xa],0x0
    603a:	e9 2d 02             	jmp    0x626a
    603d:	3d 28 00             	cmp    ax,0x28
    6040:	75 0b                	jne    0x604d
    6042:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    6046:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    604a:	e9 1d 02             	jmp    0x626a
    604d:	3d 25 00             	cmp    ax,0x25
    6050:	75 20                	jne    0x6072
    6052:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6055:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    605b:	74 0a                	je     0x6067
    605d:	83 6e f4 01          	sub    WORD PTR [bp-0xc],0x1
    6061:	83 5e f6 00          	sbb    WORD PTR [bp-0xa],0x0
    6065:	eb 08                	jmp    0x606f
    6067:	83 6e f0 01          	sub    WORD PTR [bp-0x10],0x1
    606b:	83 5e f2 00          	sbb    WORD PTR [bp-0xe],0x0
    606f:	e9 f8 01             	jmp    0x626a
    6072:	3d 27 00             	cmp    ax,0x27
    6075:	75 20                	jne    0x6097
    6077:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    607a:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    6080:	74 0a                	je     0x608c
    6082:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    6086:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    608a:	eb 08                	jmp    0x6094
    608c:	83 46 f0 01          	add    WORD PTR [bp-0x10],0x1
    6090:	83 56 f2 00          	adc    WORD PTR [bp-0xe],0x0
    6094:	e9 d3 01             	jmp    0x626a
    6097:	3d 22 00             	cmp    ax,0x22
    609a:	75 17                	jne    0x60b3
    609c:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    609f:	99                   	cwd
    60a0:	01 46 f4             	add    WORD PTR [bp-0xc],ax
    60a3:	11 56 f6             	adc    WORD PTR [bp-0xa],dx
    60a6:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    60a9:	99                   	cwd
    60aa:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    60ad:	11 56 fe             	adc    WORD PTR [bp-0x2],dx
    60b0:	e9 b7 01             	jmp    0x626a
    60b3:	3d 21 00             	cmp    ax,0x21
    60b6:	75 17                	jne    0x60cf
    60b8:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    60bb:	99                   	cwd
    60bc:	29 46 f4             	sub    WORD PTR [bp-0xc],ax
    60bf:	19 56 f6             	sbb    WORD PTR [bp-0xa],dx
    60c2:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    60c5:	99                   	cwd
    60c6:	29 46 fc             	sub    WORD PTR [bp-0x4],ax
    60c9:	19 56 fe             	sbb    WORD PTR [bp-0x2],dx
    60cc:	e9 9b 01             	jmp    0x626a
    60cf:	3d 24 00             	cmp    ax,0x24
    60d2:	75 2b                	jne    0x60ff
    60d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60d7:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    60dd:	74 0e                	je     0x60ed
    60df:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    60e4:	99                   	cwd
    60e5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    60e8:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    60eb:	eb 0f                	jmp    0x60fc
    60ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60f0:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    60f5:	99                   	cwd
    60f6:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    60f9:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    60fc:	e9 6b 01             	jmp    0x626a
    60ff:	3d 23 00             	cmp    ax,0x23
    6102:	75 3f                	jne    0x6143
    6104:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6107:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    610d:	74 18                	je     0x6127
    610f:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    6114:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    6119:	2d 01 00             	sub    ax,0x1
    611c:	83 da 00             	sbb    dx,0x0
    611f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6122:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    6125:	eb 19                	jmp    0x6140
    6127:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    612a:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    612f:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    6134:	2d 01 00             	sub    ax,0x1
    6137:	83 da 00             	sbb    dx,0x0
    613a:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    613d:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    6140:	e9 27 01             	jmp    0x626a
    6143:	3d 09 00             	cmp    ax,0x9
    6146:	74 03                	je     0x614b
    6148:	e9 0e 01             	jmp    0x6259
    614b:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    614f:	74 03                	je     0x6154
    6151:	e9 03 01             	jmp    0x6257
    6154:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    6158:	74 6f                	je     0x61c9
    615a:	83 6e f0 01          	sub    WORD PTR [bp-0x10],0x1
    615e:	83 5e f2 00          	sbb    WORD PTR [bp-0xe],0x0
    6162:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6165:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    616a:	99                   	cwd
    616b:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    616e:	7f 07                	jg     0x6177
    6170:	7c 51                	jl     0x61c3
    6172:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    6175:	76 4c                	jbe    0x61c3
    6177:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    617a:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    617f:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    6184:	2d 01 00             	sub    ax,0x1
    6187:	83 da 00             	sbb    dx,0x0
    618a:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    618d:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    6190:	83 6e f4 01          	sub    WORD PTR [bp-0xc],0x1
    6194:	83 5e f6 00          	sbb    WORD PTR [bp-0xa],0x0
    6198:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    619d:	99                   	cwd
    619e:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    61a1:	7f 07                	jg     0x61aa
    61a3:	7c 1e                	jl     0x61c3
    61a5:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    61a8:	76 19                	jbe    0x61c3
    61aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61ad:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    61b2:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    61b7:	2d 01 00             	sub    ax,0x1
    61ba:	83 da 00             	sbb    dx,0x0
    61bd:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    61c0:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    61c3:	c6 46 0a 00          	mov    BYTE PTR [bp+0xa],0x0
    61c7:	eb 5d                	jmp    0x6226
    61c9:	83 46 f0 01          	add    WORD PTR [bp-0x10],0x1
    61cd:	83 56 f2 00          	adc    WORD PTR [bp-0xe],0x0
    61d1:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    61d4:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    61d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61da:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    61df:	7f 09                	jg     0x61ea
    61e1:	7c 43                	jl     0x6226
    61e3:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    61e8:	72 3c                	jb     0x6226
    61ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61ed:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    61f2:	99                   	cwd
    61f3:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    61f6:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    61f9:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    61fd:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    6201:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    6204:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    6207:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    620c:	7f 09                	jg     0x6217
    620e:	7c 16                	jl     0x6226
    6210:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    6215:	72 0f                	jb     0x6226
    6217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    621a:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    621f:	99                   	cwd
    6220:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6223:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    6226:	ff 76 f2             	push   WORD PTR [bp-0xe]
    6229:	ff 76 f0             	push   WORD PTR [bp-0x10]
    622c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    622f:	06                   	push   es
    6230:	57                   	push   di
    6231:	9a 14 6f 68 62       	call   0x6268:0x6f14
    6236:	08 c0                	or     al,al
    6238:	75 1d                	jne    0x6257
    623a:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    623d:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    6240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6243:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    6248:	74 03                	je     0x624d
    624a:	e9 07 ff             	jmp    0x6154
    624d:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    6252:	74 03                	je     0x6257
    6254:	e9 fd fe             	jmp    0x6154
    6257:	eb 11                	jmp    0x626a
    6259:	3d 71 00             	cmp    ax,0x71
    625c:	75 0c                	jne    0x626a
    625e:	6a 01                	push   0x1
    6260:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6263:	06                   	push   es
    6264:	57                   	push   di
    6265:	9a e4 72 b0 62       	call   0x62b0:0x72e4
    626a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    626d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    6272:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    6277:	2d 01 00             	sub    ax,0x1
    627a:	83 da 00             	sbb    dx,0x0
    627d:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    6280:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    6283:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    6288:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    628d:	2d 01 00             	sub    ax,0x1
    6290:	83 da 00             	sbb    dx,0x0
    6293:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    6296:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    6299:	8d 7e c0             	lea    di,[bp-0x40]
    629c:	16                   	push   ss
    629d:	57                   	push   di
    629e:	8d 7e e8             	lea    di,[bp-0x18]
    62a1:	16                   	push   ss
    62a2:	57                   	push   di
    62a3:	8d 7e cc             	lea    di,[bp-0x34]
    62a6:	16                   	push   ss
    62a7:	57                   	push   di
    62a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ab:	06                   	push   es
    62ac:	57                   	push   di
    62ad:	9a 01 37 25 63       	call   0x6325:0x3701
    62b2:	8d 7e e8             	lea    di,[bp-0x18]
    62b5:	16                   	push   ss
    62b6:	57                   	push   di
    62b7:	6a 08                	push   0x8
    62b9:	9a 1b 16 8b 64       	call   0x648b:0x161b
    62be:	8d 7e f8             	lea    di,[bp-0x8]
    62c1:	16                   	push   ss
    62c2:	57                   	push   di
    62c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62c6:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    62cb:	99                   	cwd
    62cc:	52                   	push   dx
    62cd:	50                   	push   ax
    62ce:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    62d3:	99                   	cwd
    62d4:	52                   	push   dx
    62d5:	50                   	push   ax
    62d6:	ff 76 ea             	push   WORD PTR [bp-0x16]
    62d9:	ff 76 e8             	push   WORD PTR [bp-0x18]
    62dc:	ff 76 ee             	push   WORD PTR [bp-0x12]
    62df:	ff 76 ec             	push   WORD PTR [bp-0x14]
    62e2:	55                   	push   bp
    62e3:	e8 2d fb             	call   0x5e13
    62e6:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    62e9:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    62ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ef:	26 3b 95 15 01       	cmp    dx,WORD PTR es:[di+0x115]
    62f4:	75 1b                	jne    0x6311
    62f6:	26 3b 85 13 01       	cmp    ax,WORD PTR es:[di+0x113]
    62fb:	75 14                	jne    0x6311
    62fd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6300:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6303:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    6308:	75 07                	jne    0x6311
    630a:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    630f:	74 16                	je     0x6327
    6311:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6314:	ff 76 f8             	push   WORD PTR [bp-0x8]
    6317:	ff 76 fe             	push   WORD PTR [bp-0x2]
    631a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    631d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6320:	06                   	push   es
    6321:	57                   	push   di
    6322:	9a 73 51 b0 63       	call   0x63b0:0x5173
    6327:	8d 7e f0             	lea    di,[bp-0x10]
    632a:	16                   	push   ss
    632b:	57                   	push   di
    632c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    632f:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    6334:	99                   	cwd
    6335:	52                   	push   dx
    6336:	50                   	push   ax
    6337:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    633c:	99                   	cwd
    633d:	52                   	push   dx
    633e:	50                   	push   ax
    633f:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    6344:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    6349:	2d 01 00             	sub    ax,0x1
    634c:	83 da 00             	sbb    dx,0x0
    634f:	52                   	push   dx
    6350:	50                   	push   ax
    6351:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    6356:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    635b:	2d 01 00             	sub    ax,0x1
    635e:	83 da 00             	sbb    dx,0x0
    6361:	52                   	push   dx
    6362:	50                   	push   ax
    6363:	55                   	push   bp
    6364:	e8 ac fa             	call   0x5e13
    6367:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    636a:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    636d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6370:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    6375:	75 1b                	jne    0x6392
    6377:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    637c:	75 14                	jne    0x6392
    637e:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    6381:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    6384:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    6389:	75 07                	jne    0x6392
    638b:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    6390:	74 20                	je     0x63b2
    6392:	ff 76 f2             	push   WORD PTR [bp-0xe]
    6395:	ff 76 f0             	push   WORD PTR [bp-0x10]
    6398:	ff 76 f6             	push   WORD PTR [bp-0xa]
    639b:	ff 76 f4             	push   WORD PTR [bp-0xc]
    639e:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    63a2:	b0 00                	mov    al,0x0
    63a4:	75 01                	jne    0x63a7
    63a6:	40                   	inc    ax
    63a7:	50                   	push   ax
    63a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63ab:	06                   	push   es
    63ac:	57                   	push   di
    63ad:	9a 86 42 ec 63       	call   0x63ec:0x4286
    63b2:	c9                   	leave
    63b3:	ca 0a 00             	retf   0xa
    63b6:	55                   	push   bp
    63b7:	89 e5                	mov    bp,sp
    63b9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63bc:	06                   	push   es
    63bd:	57                   	push   di
    63be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63c1:	06                   	push   es
    63c2:	57                   	push   di
    63c3:	9a 1f 52 30 64       	call   0x6430:0x521f
    63c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63cb:	26 f6 85 09 01 20    	test   BYTE PTR es:[di+0x109],0x20
    63d1:	75 2e                	jne    0x6401
    63d3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63d6:	26 80 3d 0d          	cmp    BYTE PTR es:[di],0xd
    63da:	75 25                	jne    0x6401
    63dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63df:	26 80 bd 3c 01 00    	cmp    BYTE PTR es:[di+0x13c],0x0
    63e5:	74 09                	je     0x63f0
    63e7:	06                   	push   es
    63e8:	57                   	push   di
    63e9:	9a 32 25 f8 63       	call   0x63f8:0x2532
    63ee:	eb 0a                	jmp    0x63fa
    63f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63f3:	06                   	push   es
    63f4:	57                   	push   di
    63f5:	9a 49 25 0d 64       	call   0x640d:0x2549
    63fa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63fd:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    6401:	c9                   	leave
    6402:	ca 08 00             	retf   0x8
    6405:	01 00                	add    WORD PTR [bx+si],ax
    6407:	00 00                	add    BYTE PTR [bx+si],al
    6409:	00 00                	add    BYTE PTR [bx+si],al
    640b:	38 67 1f             	cmp    BYTE PTR [bx+0x1f],ah
    640e:	64 c8 2e 00 00       	fs enter 0x2e,0x0
    6413:	c6 46 db 00          	mov    BYTE PTR [bp-0x25],0x0
    6417:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    641a:	06                   	push   es
    641b:	57                   	push   di
    641c:	9a 1b 76 a6 64       	call   0x64a6:0x761b
    6421:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6424:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    6429:	75 49                	jne    0x6474
    642b:	06                   	push   es
    642c:	57                   	push   di
    642d:	9a c4 61 6f 64       	call   0x646f:0x61c4
    6432:	08 c0                	or     al,al
    6434:	74 3e                	je     0x6474
    6436:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6439:	06                   	push   es
    643a:	57                   	push   di
    643b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    643e:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    6442:	ff 76 08             	push   WORD PTR [bp+0x8]
    6445:	ff 76 06             	push   WORD PTR [bp+0x6]
    6448:	9a 01 18 46 7b       	call   0x7b46:0x1801
    644d:	89 c7                	mov    di,ax
    644f:	8e c2                	mov    es,dx
    6451:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    6456:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    645b:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    645e:	75 05                	jne    0x6465
    6460:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    6463:	74 0f                	je     0x6474
    6465:	6a 00                	push   0x0
    6467:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    646a:	06                   	push   es
    646b:	57                   	push   di
    646c:	9a b3 1f d7 65       	call   0x65d7:0x1fb3
    6471:	e9 d9 02             	jmp    0x674d
    6474:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
    6478:	75 16                	jne    0x6490
    647a:	f6 46 0e 40          	test   BYTE PTR [bp+0xe],0x40
    647e:	74 10                	je     0x6490
    6480:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6483:	06                   	push   es
    6484:	57                   	push   di
    6485:	b8 fd ff             	mov    ax,0xfffd
    6488:	9a 6a 20 22 65       	call   0x6522:0x206a
    648d:	e9 79 02             	jmp    0x6709
    6490:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
    6494:	74 03                	je     0x6499
    6496:	e9 70 02             	jmp    0x6709
    6499:	8d 7e dc             	lea    di,[bp-0x24]
    649c:	16                   	push   ss
    649d:	57                   	push   di
    649e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64a1:	06                   	push   es
    64a2:	57                   	push   di
    64a3:	9a 4f 34 df 64       	call   0x64df:0x344f
    64a8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    64ab:	ff 76 0a             	push   WORD PTR [bp+0xa]
    64ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64b1:	81 c7 3f 01          	add    di,0x13f
    64b5:	06                   	push   es
    64b6:	57                   	push   di
    64b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64ba:	81 c7 1b 01          	add    di,0x11b
    64be:	06                   	push   es
    64bf:	57                   	push   di
    64c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64c3:	81 c7 1f 01          	add    di,0x11f
    64c7:	06                   	push   es
    64c8:	57                   	push   di
    64c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64cc:	81 c7 21 01          	add    di,0x121
    64d0:	06                   	push   es
    64d1:	57                   	push   di
    64d2:	8d 7e dc             	lea    di,[bp-0x24]
    64d5:	16                   	push   ss
    64d6:	57                   	push   di
    64d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64da:	06                   	push   es
    64db:	57                   	push   di
    64dc:	9a 36 38 f9 64       	call   0x64f9:0x3836
    64e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64e4:	26 80 bd 3f 01 00    	cmp    BYTE PTR es:[di+0x13f],0x0
    64ea:	74 12                	je     0x64fe
    64ec:	8d 7e dc             	lea    di,[bp-0x24]
    64ef:	16                   	push   ss
    64f0:	57                   	push   di
    64f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64f4:	06                   	push   es
    64f5:	57                   	push   di
    64f6:	9a 7f 3f 16 65       	call   0x6516:0x3f7f
    64fb:	e9 4f 02             	jmp    0x674d
    64fe:	8d 7e d2             	lea    di,[bp-0x2e]
    6501:	16                   	push   ss
    6502:	57                   	push   di
    6503:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6506:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6509:	8d 7e dc             	lea    di,[bp-0x24]
    650c:	16                   	push   ss
    650d:	57                   	push   di
    650e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6511:	06                   	push   es
    6512:	57                   	push   di
    6513:	9a 26 32 92 65       	call   0x6592:0x3226
    6518:	8d 7e f8             	lea    di,[bp-0x8]
    651b:	16                   	push   ss
    651c:	57                   	push   di
    651d:	6a 08                	push   0x8
    651f:	9a 1b 16 c5 65       	call   0x65c5:0x161b
    6524:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6527:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    652c:	99                   	cwd
    652d:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    6530:	7c 0d                	jl     0x653f
    6532:	7e 03                	jle    0x6537
    6534:	e9 e4 00             	jmp    0x661b
    6537:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    653a:	76 03                	jbe    0x653f
    653c:	e9 dc 00             	jmp    0x661b
    653f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6542:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    6547:	99                   	cwd
    6548:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    654b:	7c 0d                	jl     0x655a
    654d:	7e 03                	jle    0x6552
    654f:	e9 c9 00             	jmp    0x661b
    6552:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    6555:	76 03                	jbe    0x655a
    6557:	e9 c1 00             	jmp    0x661b
    655a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    655d:	26 f6 85 09 01 04    	test   BYTE PTR es:[di+0x109],0x4
    6563:	74 64                	je     0x65c9
    6565:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6568:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    656b:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    6570:	75 24                	jne    0x6596
    6572:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    6577:	75 1d                	jne    0x6596
    6579:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    657c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    657f:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    6584:	75 10                	jne    0x6596
    6586:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    658b:	75 09                	jne    0x6596
    658d:	06                   	push   es
    658e:	57                   	push   di
    658f:	9a 49 25 ae 65       	call   0x65ae:0x2549
    6594:	eb 24                	jmp    0x65ba
    6596:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6599:	ff 76 f8             	push   WORD PTR [bp-0x8]
    659c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    659f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    65a2:	6a 01                	push   0x1
    65a4:	6a 01                	push   0x1
    65a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a9:	06                   	push   es
    65aa:	57                   	push   di
    65ab:	9a d6 4f b8 65       	call   0x65b8:0x4fd6
    65b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65b3:	06                   	push   es
    65b4:	57                   	push   di
    65b5:	9a c1 77 fa 65       	call   0x65fa:0x77c1
    65ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65bd:	06                   	push   es
    65be:	57                   	push   di
    65bf:	b8 fe ff             	mov    ax,0xfffe
    65c2:	9a 6a 20 4b 67       	call   0x674b:0x206a
    65c7:	eb 4f                	jmp    0x6618
    65c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65cc:	26 c6 85 3f 01 01    	mov    BYTE PTR es:[di+0x13f],0x1
    65d2:	06                   	push   es
    65d3:	57                   	push   di
    65d4:	9a b9 62 2d 67       	call   0x672d:0x62b9
    65d9:	50                   	push   ax
    65da:	6a 01                	push   0x1
    65dc:	6a 3c                	push   0x3c
    65de:	6a 00                	push   0x0
    65e0:	6a 00                	push   0x0
    65e2:	9a ff ff 00 00       	call   0x0:0xffff
    65e7:	f6 46 0e 01          	test   BYTE PTR [bp+0xe],0x1
    65eb:	74 11                	je     0x65fe
    65ed:	8d 7e f8             	lea    di,[bp-0x8]
    65f0:	16                   	push   ss
    65f1:	57                   	push   di
    65f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65f5:	06                   	push   es
    65f6:	57                   	push   di
    65f7:	9a 25 4f 16 66       	call   0x6616:0x4f25
    65fc:	eb 1a                	jmp    0x6618
    65fe:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6601:	ff 76 f8             	push   WORD PTR [bp-0x8]
    6604:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6607:	ff 76 fc             	push   WORD PTR [bp-0x4]
    660a:	6a 01                	push   0x1
    660c:	6a 01                	push   0x1
    660e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6611:	06                   	push   es
    6612:	57                   	push   di
    6613:	9a d6 4f 8b 66       	call   0x668b:0x4fd6
    6618:	e9 ee 00             	jmp    0x6709
    661b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    661e:	26 f6 85 09 01 01    	test   BYTE PTR es:[di+0x109],0x1
    6624:	74 6d                	je     0x6693
    6626:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    662b:	99                   	cwd
    662c:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    662f:	7f 07                	jg     0x6638
    6631:	7c 60                	jl     0x6693
    6633:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6636:	76 5b                	jbe    0x6693
    6638:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    663b:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    6640:	99                   	cwd
    6641:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    6644:	7c 07                	jl     0x664d
    6646:	7f 4b                	jg     0x6693
    6648:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    664b:	77 46                	ja     0x6693
    664d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6650:	26 c6 85 3f 01 04    	mov    BYTE PTR es:[di+0x13f],0x4
    6656:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6659:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    665c:	26 89 85 23 01       	mov    WORD PTR es:[di+0x123],ax
    6661:	26 89 95 25 01       	mov    WORD PTR es:[di+0x125],dx
    6666:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    666b:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6670:	26 89 85 27 01       	mov    WORD PTR es:[di+0x127],ax
    6675:	26 89 95 29 01       	mov    WORD PTR es:[di+0x129],dx
    667a:	06                   	push   es
    667b:	57                   	push   di
    667c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    667f:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    6683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6686:	06                   	push   es
    6687:	57                   	push   di
    6688:	9a bb 40 03 67       	call   0x6703:0x40bb
    668d:	c6 46 db 01          	mov    BYTE PTR [bp-0x25],0x1
    6691:	eb 76                	jmp    0x6709
    6693:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6696:	26 f6 85 09 01 02    	test   BYTE PTR es:[di+0x109],0x2
    669c:	74 6b                	je     0x6709
    669e:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    66a3:	99                   	cwd
    66a4:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    66a7:	7f 07                	jg     0x66b0
    66a9:	7c 5e                	jl     0x6709
    66ab:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    66ae:	76 59                	jbe    0x6709
    66b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66b3:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    66b8:	99                   	cwd
    66b9:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    66bc:	7c 07                	jl     0x66c5
    66be:	7f 49                	jg     0x6709
    66c0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    66c3:	77 44                	ja     0x6709
    66c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66c8:	26 c6 85 3f 01 05    	mov    BYTE PTR es:[di+0x13f],0x5
    66ce:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    66d1:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    66d4:	26 89 85 23 01       	mov    WORD PTR es:[di+0x123],ax
    66d9:	26 89 95 25 01       	mov    WORD PTR es:[di+0x125],dx
    66de:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    66e3:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    66e8:	26 89 85 27 01       	mov    WORD PTR es:[di+0x127],ax
    66ed:	26 89 95 29 01       	mov    WORD PTR es:[di+0x129],dx
    66f2:	06                   	push   es
    66f3:	57                   	push   di
    66f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    66f7:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    66fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66fe:	06                   	push   es
    66ff:	57                   	push   di
    6700:	9a bb 40 46 67       	call   0x6746:0x40bb
    6705:	c6 46 db 01          	mov    BYTE PTR [bp-0x25],0x1
    6709:	b8 05 64             	mov    ax,0x6405
    670c:	0e                   	push   cs
    670d:	50                   	push   ax
    670e:	55                   	push   bp
    670f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6713:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6717:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    671a:	50                   	push   ax
    671b:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    671e:	50                   	push   ax
    671f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6722:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6725:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6728:	06                   	push   es
    6729:	57                   	push   di
    672a:	9a c0 27 08 69       	call   0x6908:0x27c0
    672f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6733:	83 c4 06             	add    sp,0x6
    6736:	eb 15                	jmp    0x674d
    6738:	80 7e db 00          	cmp    BYTE PTR [bp-0x25],0x0
    673c:	74 0a                	je     0x6748
    673e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6741:	06                   	push   es
    6742:	57                   	push   di
    6743:	9a bb 40 8d 67       	call   0x678d:0x40bb
    6748:	9a 34 14 0d 68       	call   0x680d:0x1434
    674d:	c9                   	leave
    674e:	ca 0c 00             	retf   0xc
    6751:	55                   	push   bp
    6752:	89 e5                	mov    bp,sp
    6754:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6757:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    675a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    675d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6761:	26 3b 95 29 01       	cmp    dx,WORD PTR es:[di+0x129]
    6766:	75 07                	jne    0x676f
    6768:	26 3b 85 27 01       	cmp    ax,WORD PTR es:[di+0x127]
    676d:	74 3e                	je     0x67ad
    676f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6772:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6775:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    6778:	7f 07                	jg     0x6781
    677a:	7c 31                	jl     0x67ad
    677c:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    677f:	72 2c                	jb     0x67ad
    6781:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6784:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6788:	06                   	push   es
    6789:	57                   	push   di
    678a:	9a bb 40 ab 67       	call   0x67ab:0x40bb
    678f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6792:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6795:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6798:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    679c:	26 89 85 27 01       	mov    WORD PTR es:[di+0x127],ax
    67a1:	26 89 95 29 01       	mov    WORD PTR es:[di+0x129],dx
    67a6:	06                   	push   es
    67a7:	57                   	push   di
    67a8:	9a bb 40 e7 67       	call   0x67e7:0x40bb
    67ad:	c9                   	leave
    67ae:	c2 0a 00             	ret    0xa
    67b1:	da 67 9a             	fisub  DWORD PTR [bx-0x66]
    67b4:	68 9a 68             	push   0x689a
    67b7:	f4                   	hlt
    67b8:	68 f4 68             	push   0x68f4
    67bb:	c8 30 00 00          	enter  0x30,0x0
    67bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67c2:	26 8a 85 3f 01       	mov    al,BYTE PTR es:[di+0x13f]
    67c7:	2c 01                	sub    al,0x1
    67c9:	3c 04                	cmp    al,0x4
    67cb:	76 03                	jbe    0x67d0
    67cd:	e9 d5 01             	jmp    0x69a5
    67d0:	98                   	cbw
    67d1:	89 c3                	mov    bx,ax
    67d3:	d1 e3                	shl    bx,1
    67d5:	2e ff a7 b1 67       	jmp    WORD PTR cs:[bx+0x67b1]
    67da:	8d 7e e4             	lea    di,[bp-0x1c]
    67dd:	16                   	push   ss
    67de:	57                   	push   di
    67df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67e2:	06                   	push   es
    67e3:	57                   	push   di
    67e4:	9a 4f 34 01 68       	call   0x6801:0x344f
    67e9:	8d 7e d0             	lea    di,[bp-0x30]
    67ec:	16                   	push   ss
    67ed:	57                   	push   di
    67ee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    67f1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    67f4:	8d 7e e4             	lea    di,[bp-0x1c]
    67f7:	16                   	push   ss
    67f8:	57                   	push   di
    67f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67fc:	06                   	push   es
    67fd:	57                   	push   di
    67fe:	9a 26 32 95 68       	call   0x6895:0x3226
    6803:	8d 7e dc             	lea    di,[bp-0x24]
    6806:	16                   	push   ss
    6807:	57                   	push   di
    6808:	6a 08                	push   0x8
    680a:	9a 1b 16 6f 69       	call   0x696f:0x161b
    680f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6812:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    6817:	99                   	cwd
    6818:	3b 56 de             	cmp    dx,WORD PTR [bp-0x22]
    681b:	7c 07                	jl     0x6824
    681d:	7f 78                	jg     0x6897
    681f:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    6822:	77 73                	ja     0x6897
    6824:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6827:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    682c:	99                   	cwd
    682d:	3b 56 e2             	cmp    dx,WORD PTR [bp-0x1e]
    6830:	7c 07                	jl     0x6839
    6832:	7f 63                	jg     0x6897
    6834:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    6837:	77 5e                	ja     0x6897
    6839:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    683c:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    683f:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    6842:	7c 07                	jl     0x684b
    6844:	7f 51                	jg     0x6897
    6846:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    6849:	77 4c                	ja     0x6897
    684b:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    684e:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    6851:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    6854:	7c 07                	jl     0x685d
    6856:	7f 3f                	jg     0x6897
    6858:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    685b:	77 3a                	ja     0x6897
    685d:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    6860:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    6863:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6866:	26 3b 95 de 00       	cmp    dx,WORD PTR es:[di+0xde]
    686b:	75 1b                	jne    0x6888
    686d:	26 3b 85 dc 00       	cmp    ax,WORD PTR es:[di+0xdc]
    6872:	75 14                	jne    0x6888
    6874:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    6877:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    687a:	26 3b 95 e2 00       	cmp    dx,WORD PTR es:[di+0xe2]
    687f:	75 07                	jne    0x6888
    6881:	26 3b 85 e0 00       	cmp    ax,WORD PTR es:[di+0xe0]
    6886:	74 0f                	je     0x6897
    6888:	8d 7e dc             	lea    di,[bp-0x24]
    688b:	16                   	push   ss
    688c:	57                   	push   di
    688d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6890:	06                   	push   es
    6891:	57                   	push   di
    6892:	9a 25 4f a7 68       	call   0x68a7:0x4f25
    6897:	e9 0b 01             	jmp    0x69a5
    689a:	8d 7e e4             	lea    di,[bp-0x1c]
    689d:	16                   	push   ss
    689e:	57                   	push   di
    689f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68a2:	06                   	push   es
    68a3:	57                   	push   di
    68a4:	9a 4f 34 b6 68       	call   0x68b6:0x344f
    68a9:	8d 7e e4             	lea    di,[bp-0x1c]
    68ac:	16                   	push   ss
    68ad:	57                   	push   di
    68ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68b1:	06                   	push   es
    68b2:	57                   	push   di
    68b3:	9a 7f 3f ef 68       	call   0x68ef:0x3f7f
    68b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68bb:	26 80 bd 3f 01 02    	cmp    BYTE PTR es:[di+0x13f],0x2
    68c1:	75 0f                	jne    0x68d2
    68c3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    68c6:	26 03 85 21 01       	add    ax,WORD PTR es:[di+0x121]
    68cb:	26 89 85 1f 01       	mov    WORD PTR es:[di+0x11f],ax
    68d0:	eb 10                	jmp    0x68e2
    68d2:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    68d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68d8:	26 03 85 21 01       	add    ax,WORD PTR es:[di+0x121]
    68dd:	26 89 85 1f 01       	mov    WORD PTR es:[di+0x11f],ax
    68e2:	8d 7e e4             	lea    di,[bp-0x1c]
    68e5:	16                   	push   ss
    68e6:	57                   	push   di
    68e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68ea:	06                   	push   es
    68eb:	57                   	push   di
    68ec:	9a 7f 3f 63 69       	call   0x6963:0x3f7f
    68f1:	e9 b1 00             	jmp    0x69a5
    68f4:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    68f7:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    68fa:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    68fd:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    6900:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6903:	06                   	push   es
    6904:	57                   	push   di
    6905:	9a a9 18 17 69       	call   0x6917:0x18a9
    690a:	3b 46 da             	cmp    ax,WORD PTR [bp-0x26]
    690d:	7f 0e                	jg     0x691d
    690f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6912:	06                   	push   es
    6913:	57                   	push   di
    6914:	9a a9 18 30 69       	call   0x6930:0x18a9
    6919:	48                   	dec    ax
    691a:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    691d:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    6921:	7d 05                	jge    0x6928
    6923:	31 c0                	xor    ax,ax
    6925:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    6928:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    692b:	06                   	push   es
    692c:	57                   	push   di
    692d:	9a f4 18 3f 69       	call   0x693f:0x18f4
    6932:	3b 46 d8             	cmp    ax,WORD PTR [bp-0x28]
    6935:	7f 0e                	jg     0x6945
    6937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    693a:	06                   	push   es
    693b:	57                   	push   di
    693c:	9a f4 18 b7 69       	call   0x69b7:0x18f4
    6941:	48                   	dec    ax
    6942:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    6945:	83 7e d8 00          	cmp    WORD PTR [bp-0x28],0x0
    6949:	7d 05                	jge    0x6950
    694b:	31 c0                	xor    ax,ax
    694d:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    6950:	8d 7e d0             	lea    di,[bp-0x30]
    6953:	16                   	push   ss
    6954:	57                   	push   di
    6955:	ff 76 da             	push   WORD PTR [bp-0x26]
    6958:	ff 76 d8             	push   WORD PTR [bp-0x28]
    695b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    695e:	06                   	push   es
    695f:	57                   	push   di
    6960:	9a 44 28 d8 6a       	call   0x6ad8:0x2844
    6965:	8d 7e dc             	lea    di,[bp-0x24]
    6968:	16                   	push   ss
    6969:	57                   	push   di
    696a:	6a 08                	push   0x8
    696c:	9a 1b 16 1c 6b       	call   0x6b1c:0x161b
    6971:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6974:	26 80 bd 3f 01 04    	cmp    BYTE PTR es:[di+0x13f],0x4
    697a:	75 14                	jne    0x6990
    697c:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    697f:	ff 76 e0             	push   WORD PTR [bp-0x20]
    6982:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    6987:	99                   	cwd
    6988:	52                   	push   dx
    6989:	50                   	push   ax
    698a:	55                   	push   bp
    698b:	e8 c3 fd             	call   0x6751
    698e:	eb 15                	jmp    0x69a5
    6990:	ff 76 de             	push   WORD PTR [bp-0x22]
    6993:	ff 76 dc             	push   WORD PTR [bp-0x24]
    6996:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6999:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    699e:	99                   	cwd
    699f:	52                   	push   dx
    69a0:	50                   	push   ax
    69a1:	55                   	push   bp
    69a2:	e8 ac fd             	call   0x6751
    69a5:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    69a8:	50                   	push   ax
    69a9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    69ac:	ff 76 0a             	push   WORD PTR [bp+0xa]
    69af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69b2:	06                   	push   es
    69b3:	57                   	push   di
    69b4:	9a f2 2a 26 6b       	call   0x6b26:0x2af2
    69b9:	c9                   	leave
    69ba:	ca 0a 00             	retf   0xa
    69bd:	c8 08 00 00          	enter  0x8,0x0
    69c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c4:	26 8b 05             	mov    ax,WORD PTR es:[di]
    69c7:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    69cb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    69ce:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    69d2:	26 3b 95 25 01       	cmp    dx,WORD PTR es:[di+0x125]
    69d7:	75 1e                	jne    0x69f7
    69d9:	26 3b 85 23 01       	cmp    ax,WORD PTR es:[di+0x123]
    69de:	75 17                	jne    0x69f7
    69e0:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    69e5:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    69ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69ed:	26 89 05             	mov    WORD PTR es:[di],ax
    69f0:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    69f4:	e9 cf 00             	jmp    0x6ac6
    69f7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    69fa:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    69fe:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6a03:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6a08:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6a0b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6a0e:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    6a13:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    6a18:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6a1b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6a1e:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6a23:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6a28:	26 3b 95 29 01       	cmp    dx,WORD PTR es:[di+0x129]
    6a2d:	7f 09                	jg     0x6a38
    6a2f:	7c 2e                	jl     0x6a5f
    6a31:	26 3b 85 27 01       	cmp    ax,WORD PTR es:[di+0x127]
    6a36:	76 27                	jbe    0x6a5f
    6a38:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6a3b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6a3f:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    6a44:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    6a49:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6a4c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6a4f:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6a54:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6a59:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6a5c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6a5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a62:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6a65:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    6a69:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    6a6c:	7f 07                	jg     0x6a75
    6a6e:	7c 56                	jl     0x6ac6
    6a70:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    6a73:	72 51                	jb     0x6ac6
    6a75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a78:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6a7b:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    6a7f:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    6a82:	7c 07                	jl     0x6a8b
    6a84:	7f 40                	jg     0x6ac6
    6a86:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6a89:	77 3b                	ja     0x6ac6
    6a8b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    6a8e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    6a92:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6a97:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6a9c:	26 3b 95 29 01       	cmp    dx,WORD PTR es:[di+0x129]
    6aa1:	7f 09                	jg     0x6aac
    6aa3:	7c 15                	jl     0x6aba
    6aa5:	26 3b 85 27 01       	cmp    ax,WORD PTR es:[di+0x127]
    6aaa:	76 0e                	jbe    0x6aba
    6aac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aaf:	26 83 05 01          	add    WORD PTR es:[di],0x1
    6ab3:	26 83 55 02 00       	adc    WORD PTR es:[di+0x2],0x0
    6ab8:	eb 0c                	jmp    0x6ac6
    6aba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6abd:	26 83 2d 01          	sub    WORD PTR es:[di],0x1
    6ac1:	26 83 5d 02 00       	sbb    WORD PTR es:[di+0x2],0x0
    6ac6:	c9                   	leave
    6ac7:	c2 06 00             	ret    0x6
    6aca:	07                   	pop    es
    6acb:	6b 4a 6b 4a          	imul   cx,WORD PTR [bp+si+0x6b],0x4a
    6acf:	6b 5d 6c 5d          	imul   bx,WORD PTR [di+0x6c],0x5d
    6ad3:	6c                   	ins    BYTE PTR es:[di],dx
    6ad4:	00 00                	add    BYTE PTR [bx+si],al
    6ad6:	22 6e 38             	and    ch,BYTE PTR [bp+0x38]
    6ad9:	6b c8 24             	imul   cx,ax,0x24
    6adc:	00 00                	add    BYTE PTR [bx+si],al
    6ade:	b8 d4 6a             	mov    ax,0x6ad4
    6ae1:	0e                   	push   cs
    6ae2:	50                   	push   ax
    6ae3:	55                   	push   bp
    6ae4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6ae8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6aec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aef:	26 8a 85 3f 01       	mov    al,BYTE PTR es:[di+0x13f]
    6af4:	2c 01                	sub    al,0x1
    6af6:	3c 04                	cmp    al,0x4
    6af8:	76 03                	jbe    0x6afd
    6afa:	e9 f7 02             	jmp    0x6df4
    6afd:	98                   	cbw
    6afe:	89 c3                	mov    bx,ax
    6b00:	d1 e3                	shl    bx,1
    6b02:	2e ff a7 ca 6a       	jmp    WORD PTR cs:[bx+0x6aca]
    6b07:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    6b0a:	50                   	push   ax
    6b0b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6b0e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6b11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b14:	06                   	push   es
    6b15:	57                   	push   di
    6b16:	b8 f9 ff             	mov    ax,0xfff9
    6b19:	9a 6a 20 45 6b       	call   0x6b45:0x206a
    6b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b21:	06                   	push   es
    6b22:	57                   	push   di
    6b23:	9a b9 62 14 6e       	call   0x6e14:0x62b9
    6b28:	50                   	push   ax
    6b29:	6a 01                	push   0x1
    6b2b:	9a ff ff 00 00       	call   0x0:0xffff
    6b30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b33:	06                   	push   es
    6b34:	57                   	push   di
    6b35:	9a c1 77 57 6b       	call   0x6b57:0x77c1
    6b3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b3d:	06                   	push   es
    6b3e:	57                   	push   di
    6b3f:	b8 fe ff             	mov    ax,0xfffe
    6b42:	9a 6a 20 45 6d       	call   0x6d45:0x206a
    6b47:	e9 b4 02             	jmp    0x6dfe
    6b4a:	8d 7e e4             	lea    di,[bp-0x1c]
    6b4d:	16                   	push   ss
    6b4e:	57                   	push   di
    6b4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b52:	06                   	push   es
    6b53:	57                   	push   di
    6b54:	9a 4f 34 66 6b       	call   0x6b66:0x344f
    6b59:	8d 7e e4             	lea    di,[bp-0x1c]
    6b5c:	16                   	push   ss
    6b5d:	57                   	push   di
    6b5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b61:	06                   	push   es
    6b62:	57                   	push   di
    6b63:	9a 7f 3f ac 6b       	call   0x6bac:0x3f7f
    6b68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b6b:	26 80 bd 3f 01 03    	cmp    BYTE PTR es:[di+0x13f],0x3
    6b71:	75 73                	jne    0x6be6
    6b73:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    6b76:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    6b79:	26 8b 85 1b 01       	mov    ax,WORD PTR es:[di+0x11b]
    6b7e:	26 8b 95 1d 01       	mov    dx,WORD PTR es:[di+0x11d]
    6b83:	2d 01 00             	sub    ax,0x1
    6b86:	83 da 00             	sbb    dx,0x0
    6b89:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    6b8c:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    6b91:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    6b94:	7f 26                	jg     0x6bbc
    6b96:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    6b99:	eb 03                	jmp    0x6b9e
    6b9b:	ff 46 e2             	inc    WORD PTR [bp-0x1e]
    6b9e:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    6ba1:	99                   	cwd
    6ba2:	52                   	push   dx
    6ba3:	50                   	push   ax
    6ba4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ba7:	06                   	push   es
    6ba8:	57                   	push   di
    6ba9:	9a 30 6e e2 6b       	call   0x6be2:0x6e30
    6bae:	03 46 e4             	add    ax,WORD PTR [bp-0x1c]
    6bb1:	01 46 e0             	add    WORD PTR [bp-0x20],ax
    6bb4:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    6bb7:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    6bba:	75 df                	jne    0x6b9b
    6bbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bbf:	26 8b 85 1f 01       	mov    ax,WORD PTR es:[di+0x11f]
    6bc4:	2b 46 e0             	sub    ax,WORD PTR [bp-0x20]
    6bc7:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    6bca:	83 7e de 01          	cmp    WORD PTR [bp-0x22],0x1
    6bce:	7e 14                	jle    0x6be4
    6bd0:	26 ff b5 1d 01       	push   WORD PTR es:[di+0x11d]
    6bd5:	26 ff b5 1b 01       	push   WORD PTR es:[di+0x11b]
    6bda:	ff 76 de             	push   WORD PTR [bp-0x22]
    6bdd:	06                   	push   es
    6bde:	57                   	push   di
    6bdf:	9a c9 70 22 6c       	call   0x6c22:0x70c9
    6be4:	eb 74                	jmp    0x6c5a
    6be6:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    6be9:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    6bec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bef:	26 8b 85 1b 01       	mov    ax,WORD PTR es:[di+0x11b]
    6bf4:	26 8b 95 1d 01       	mov    dx,WORD PTR es:[di+0x11d]
    6bf9:	2d 01 00             	sub    ax,0x1
    6bfc:	83 da 00             	sbb    dx,0x0
    6bff:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    6c02:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    6c07:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    6c0a:	7f 26                	jg     0x6c32
    6c0c:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    6c0f:	eb 03                	jmp    0x6c14
    6c11:	ff 46 e2             	inc    WORD PTR [bp-0x1e]
    6c14:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    6c17:	99                   	cwd
    6c18:	52                   	push   dx
    6c19:	50                   	push   ax
    6c1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c1d:	06                   	push   es
    6c1e:	57                   	push   di
    6c1f:	9a 8b 6e 58 6c       	call   0x6c58:0x6e8b
    6c24:	03 46 e6             	add    ax,WORD PTR [bp-0x1a]
    6c27:	01 46 e0             	add    WORD PTR [bp-0x20],ax
    6c2a:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    6c2d:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    6c30:	75 df                	jne    0x6c11
    6c32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c35:	26 8b 85 1f 01       	mov    ax,WORD PTR es:[di+0x11f]
    6c3a:	2b 46 e0             	sub    ax,WORD PTR [bp-0x20]
    6c3d:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    6c40:	83 7e de 01          	cmp    WORD PTR [bp-0x22],0x1
    6c44:	7e 14                	jle    0x6c5a
    6c46:	26 ff b5 1d 01       	push   WORD PTR es:[di+0x11d]
    6c4b:	26 ff b5 1b 01       	push   WORD PTR es:[di+0x11b]
    6c50:	ff 76 de             	push   WORD PTR [bp-0x22]
    6c53:	06                   	push   es
    6c54:	57                   	push   di
    6c55:	9a a3 74 65 6c       	call   0x6c65:0x74a3
    6c5a:	e9 a1 01             	jmp    0x6dfe
    6c5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c60:	06                   	push   es
    6c61:	57                   	push   di
    6c62:	9a bb 40 f0 6d       	call   0x6df0:0x40bb
    6c67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c6a:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6c6f:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6c74:	26 3b 95 29 01       	cmp    dx,WORD PTR es:[di+0x129]
    6c79:	75 0a                	jne    0x6c85
    6c7b:	26 3b 85 27 01       	cmp    ax,WORD PTR es:[di+0x127]
    6c80:	75 03                	jne    0x6c85
    6c82:	e9 63 01             	jmp    0x6de8
    6c85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c88:	26 80 bd 3f 01 05    	cmp    BYTE PTR es:[di+0x13f],0x5
    6c8e:	74 03                	je     0x6c93
    6c90:	e9 c4 00             	jmp    0x6d57
    6c93:	26 8b 85 ec 00       	mov    ax,WORD PTR es:[di+0xec]
    6c98:	09 c0                	or     ax,ax
    6c9a:	74 63                	je     0x6cff
    6c9c:	81 c7 ea 00          	add    di,0xea
    6ca0:	06                   	push   es
    6ca1:	57                   	push   di
    6ca2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ca5:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6caa:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6caf:	05 01 00             	add    ax,0x1
    6cb2:	83 d2 00             	adc    dx,0x0
    6cb5:	52                   	push   dx
    6cb6:	50                   	push   ax
    6cb7:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    6cbc:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    6cc1:	05 01 00             	add    ax,0x1
    6cc4:	83 d2 00             	adc    dx,0x0
    6cc7:	52                   	push   dx
    6cc8:	50                   	push   ax
    6cc9:	e8 ce a7             	call   0x149a
    6ccc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ccf:	81 c7 ee 00          	add    di,0xee
    6cd3:	06                   	push   es
    6cd4:	57                   	push   di
    6cd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cd8:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6cdd:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6ce2:	05 01 00             	add    ax,0x1
    6ce5:	83 d2 00             	adc    dx,0x0
    6ce8:	52                   	push   dx
    6ce9:	50                   	push   ax
    6cea:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    6cef:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    6cf4:	05 01 00             	add    ax,0x1
    6cf7:	83 d2 00             	adc    dx,0x0
    6cfa:	52                   	push   dx
    6cfb:	50                   	push   ax
    6cfc:	e8 9b a7             	call   0x149a
    6cff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d02:	81 c7 f2 00          	add    di,0xf2
    6d06:	06                   	push   es
    6d07:	57                   	push   di
    6d08:	55                   	push   bp
    6d09:	e8 b1 fc             	call   0x69bd
    6d0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d0f:	81 c7 dc 00          	add    di,0xdc
    6d13:	06                   	push   es
    6d14:	57                   	push   di
    6d15:	55                   	push   bp
    6d16:	e8 a4 fc             	call   0x69bd
    6d19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d1c:	81 c7 33 01          	add    di,0x133
    6d20:	06                   	push   es
    6d21:	57                   	push   di
    6d22:	55                   	push   bp
    6d23:	e8 97 fc             	call   0x69bd
    6d26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d29:	26 ff b5 25 01       	push   WORD PTR es:[di+0x125]
    6d2e:	26 ff b5 23 01       	push   WORD PTR es:[di+0x123]
    6d33:	26 ff b5 29 01       	push   WORD PTR es:[di+0x129]
    6d38:	26 ff b5 27 01       	push   WORD PTR es:[di+0x127]
    6d3d:	06                   	push   es
    6d3e:	57                   	push   di
    6d3f:	b8 e6 ff             	mov    ax,0xffe6
    6d42:	9a 6a 20 52 6d       	call   0x6d52:0x206a
    6d47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d4a:	06                   	push   es
    6d4b:	57                   	push   di
    6d4c:	b8 e1 ff             	mov    ax,0xffe1
    6d4f:	9a 6a 20 9e 6d       	call   0x6d9e:0x206a
    6d54:	e9 91 00             	jmp    0x6de8
    6d57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d5a:	26 8b 85 10 01       	mov    ax,WORD PTR es:[di+0x110]
    6d5f:	09 c0                	or     ax,ax
    6d61:	74 3d                	je     0x6da0
    6d63:	81 c7 0e 01          	add    di,0x10e
    6d67:	06                   	push   es
    6d68:	57                   	push   di
    6d69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d6c:	26 8b 85 23 01       	mov    ax,WORD PTR es:[di+0x123]
    6d71:	26 8b 95 25 01       	mov    dx,WORD PTR es:[di+0x125]
    6d76:	05 01 00             	add    ax,0x1
    6d79:	83 d2 00             	adc    dx,0x0
    6d7c:	52                   	push   dx
    6d7d:	50                   	push   ax
    6d7e:	26 8b 85 27 01       	mov    ax,WORD PTR es:[di+0x127]
    6d83:	26 8b 95 29 01       	mov    dx,WORD PTR es:[di+0x129]
    6d88:	05 01 00             	add    ax,0x1
    6d8b:	83 d2 00             	adc    dx,0x0
    6d8e:	52                   	push   dx
    6d8f:	50                   	push   ax
    6d90:	e8 07 a7             	call   0x149a
    6d93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d96:	06                   	push   es
    6d97:	57                   	push   di
    6d98:	b8 e0 ff             	mov    ax,0xffe0
    6d9b:	9a 6a 20 e6 6d       	call   0x6de6:0x206a
    6da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6da3:	81 c7 f6 00          	add    di,0xf6
    6da7:	06                   	push   es
    6da8:	57                   	push   di
    6da9:	55                   	push   bp
    6daa:	e8 10 fc             	call   0x69bd
    6dad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6db0:	81 c7 e0 00          	add    di,0xe0
    6db4:	06                   	push   es
    6db5:	57                   	push   di
    6db6:	55                   	push   bp
    6db7:	e8 03 fc             	call   0x69bd
    6dba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dbd:	81 c7 37 01          	add    di,0x137
    6dc1:	06                   	push   es
    6dc2:	57                   	push   di
    6dc3:	55                   	push   bp
    6dc4:	e8 f6 fb             	call   0x69bd
    6dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dca:	26 ff b5 25 01       	push   WORD PTR es:[di+0x125]
    6dcf:	26 ff b5 23 01       	push   WORD PTR es:[di+0x123]
    6dd4:	26 ff b5 29 01       	push   WORD PTR es:[di+0x129]
    6dd9:	26 ff b5 27 01       	push   WORD PTR es:[di+0x127]
    6dde:	06                   	push   es
    6ddf:	57                   	push   di
    6de0:	b8 e5 ff             	mov    ax,0xffe5
    6de3:	9a 6a 20 0e 6f       	call   0x6f0e:0x206a
    6de8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6deb:	06                   	push   es
    6dec:	57                   	push   di
    6ded:	9a c1 77 fc 6d       	call   0x6dfc:0x77c1
    6df2:	eb 0a                	jmp    0x6dfe
    6df4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6df7:	06                   	push   es
    6df8:	57                   	push   di
    6df9:	9a c1 77 63 6f       	call   0x6f63:0x77c1
    6dfe:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    6e01:	50                   	push   ax
    6e02:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    6e05:	50                   	push   ax
    6e06:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6e09:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6e0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e0f:	06                   	push   es
    6e10:	57                   	push   di
    6e11:	9a 65 2b db 6f       	call   0x6fdb:0x2b65
    6e16:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6e1a:	83 c4 06             	add    sp,0x6
    6e1d:	b8 2c 6e             	mov    ax,0x6e2c
    6e20:	0e                   	push   cs
    6e21:	50                   	push   ax
    6e22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e25:	26 c6 85 3f 01 00    	mov    BYTE PTR es:[di+0x13f],0x0
    6e2b:	cb                   	retf
    6e2c:	c9                   	leave
    6e2d:	ca 0c 00             	retf   0xc
    6e30:	c8 02 00 00          	enter  0x2,0x0
    6e34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e37:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    6e3c:	26 0b 85 ec 00       	or     ax,WORD PTR es:[di+0xec]
    6e41:	74 16                	je     0x6e59
    6e43:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6e46:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6e49:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    6e4e:	7f 09                	jg     0x6e59
    6e50:	7c 14                	jl     0x6e66
    6e52:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    6e57:	72 0d                	jb     0x6e66
    6e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e5c:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    6e61:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6e64:	eb 1e                	jmp    0x6e84
    6e66:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6e69:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6e6c:	05 01 00             	add    ax,0x1
    6e6f:	83 d2 00             	adc    dx,0x0
    6e72:	d1 e0                	shl    ax,1
    6e74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e77:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    6e7c:	03 f8                	add    di,ax
    6e7e:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6e81:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6e84:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6e87:	c9                   	leave
    6e88:	ca 08 00             	retf   0x8
    6e8b:	c8 02 00 00          	enter  0x2,0x0
    6e8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e92:	26 8b 85 0e 01       	mov    ax,WORD PTR es:[di+0x10e]
    6e97:	26 0b 85 10 01       	or     ax,WORD PTR es:[di+0x110]
    6e9c:	74 16                	je     0x6eb4
    6e9e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6ea1:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6ea4:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    6ea9:	7f 09                	jg     0x6eb4
    6eab:	7c 14                	jl     0x6ec1
    6ead:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    6eb2:	72 0d                	jb     0x6ec1
    6eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6eb7:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    6ebc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6ebf:	eb 1e                	jmp    0x6edf
    6ec1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6ec4:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6ec7:	05 01 00             	add    ax,0x1
    6eca:	83 d2 00             	adc    dx,0x0
    6ecd:	d1 e0                	shl    ax,1
    6ecf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ed2:	26 c4 bd 0e 01       	les    di,DWORD PTR es:[di+0x10e]
    6ed7:	03 f8                	add    di,ax
    6ed9:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6edc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6edf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6ee2:	c9                   	leave
    6ee3:	ca 08 00             	retf   0x8
    6ee6:	c8 10 00 00          	enter  0x10,0x0
    6eea:	8d 7e f0             	lea    di,[bp-0x10]
    6eed:	16                   	push   ss
    6eee:	57                   	push   di
    6eef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ef2:	81 c7 f2 00          	add    di,0xf2
    6ef6:	06                   	push   es
    6ef7:	57                   	push   di
    6ef8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6efb:	81 c7 dc 00          	add    di,0xdc
    6eff:	06                   	push   es
    6f00:	57                   	push   di
    6f01:	e8 4b a0             	call   0xf4f
    6f04:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f07:	06                   	push   es
    6f08:	57                   	push   di
    6f09:	6a 10                	push   0x10
    6f0b:	9a 1b 16 6c 71       	call   0x716c:0x161b
    6f10:	c9                   	leave
    6f11:	ca 04 00             	retf   0x4
    6f14:	c8 02 00 00          	enter  0x2,0x0
    6f18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f1b:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    6f20:	26 0b 85 f0 00       	or     ax,WORD PTR es:[di+0xf0]
    6f25:	75 06                	jne    0x6f2d
    6f27:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    6f2b:	eb 1e                	jmp    0x6f4b
    6f2d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6f30:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6f33:	05 01 00             	add    ax,0x1
    6f36:	83 d2 00             	adc    dx,0x0
    6f39:	d1 e0                	shl    ax,1
    6f3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f3e:	26 c4 bd ee 00       	les    di,DWORD PTR es:[di+0xee]
    6f43:	03 f8                	add    di,ax
    6f45:	26 8a 05             	mov    al,BYTE PTR es:[di]
    6f48:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6f4b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6f4e:	c9                   	leave
    6f4f:	ca 08 00             	retf   0x8
    6f52:	c8 1e 00 00          	enter  0x1e,0x0
    6f56:	8d 7e e2             	lea    di,[bp-0x1e]
    6f59:	16                   	push   ss
    6f5a:	57                   	push   di
    6f5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f5e:	06                   	push   es
    6f5f:	57                   	push   di
    6f60:	9a 4f 34 99 6f       	call   0x6f99:0x344f
    6f65:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    6f68:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    6f6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f6e:	26 2b 85 13 01       	sub    ax,WORD PTR es:[di+0x113]
    6f73:	26 1b 95 15 01       	sbb    dx,WORD PTR es:[di+0x115]
    6f78:	05 01 00             	add    ax,0x1
    6f7b:	83 d2 00             	adc    dx,0x0
    6f7e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6f81:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6f84:	c9                   	leave
    6f85:	ca 04 00             	retf   0x4
    6f88:	c8 1e 00 00          	enter  0x1e,0x0
    6f8c:	8d 7e e2             	lea    di,[bp-0x1e]
    6f8f:	16                   	push   ss
    6f90:	57                   	push   di
    6f91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f94:	06                   	push   es
    6f95:	57                   	push   di
    6f96:	9a 4f 34 15 70       	call   0x7015:0x344f
    6f9b:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    6f9e:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    6fa1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fa4:	26 2b 85 17 01       	sub    ax,WORD PTR es:[di+0x117]
    6fa9:	26 1b 95 19 01       	sbb    dx,WORD PTR es:[di+0x119]
    6fae:	05 01 00             	add    ax,0x1
    6fb1:	83 d2 00             	adc    dx,0x0
    6fb4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6fb7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6fba:	c9                   	leave
    6fbb:	ca 04 00             	retf   0x4
    6fbe:	55                   	push   bp
    6fbf:	89 e5                	mov    bp,sp
    6fc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fc4:	26 8a 85 e4 00       	mov    al,BYTE PTR es:[di+0xe4]
    6fc9:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6fcc:	74 0f                	je     0x6fdd
    6fce:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6fd1:	26 88 85 e4 00       	mov    BYTE PTR es:[di+0xe4],al
    6fd6:	06                   	push   es
    6fd7:	57                   	push   di
    6fd8:	9a 5a 40 69 75       	call   0x7569:0x405a
    6fdd:	c9                   	leave
    6fde:	ca 06 00             	retf   0x6
    6fe1:	55                   	push   bp
    6fe2:	89 e5                	mov    bp,sp
    6fe4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fe7:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    6fec:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    6ff1:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    6ff4:	75 05                	jne    0x6ffb
    6ff6:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    6ff9:	74 1c                	je     0x7017
    6ffb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6ffe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7001:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7004:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    7009:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    700e:	6a 01                	push   0x1
    7010:	06                   	push   es
    7011:	57                   	push   di
    7012:	9a 86 42 7b 70       	call   0x707b:0x4286
    7017:	c9                   	leave
    7018:	ca 08 00             	retf   0x8
    701b:	c8 04 00 00          	enter  0x4,0x0
    701f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7022:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    7027:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    702c:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    702f:	75 08                	jne    0x7039
    7031:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7034:	75 03                	jne    0x7039
    7036:	e9 8c 00             	jmp    0x70c5
    7039:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    703d:	7c 08                	jl     0x7047
    703f:	7f 10                	jg     0x7051
    7041:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    7045:	73 0a                	jae    0x7051
    7047:	c7 46 0a 01 00       	mov    WORD PTR [bp+0xa],0x1
    704c:	c7 46 0c 00 00       	mov    WORD PTR [bp+0xc],0x0
    7051:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7054:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    7059:	99                   	cwd
    705a:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    705d:	7f 07                	jg     0x7066
    705f:	7c 1c                	jl     0x707d
    7061:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7064:	72 17                	jb     0x707d
    7066:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7069:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    706c:	2d 01 00             	sub    ax,0x1
    706f:	83 da 00             	sbb    dx,0x0
    7072:	50                   	push   ax
    7073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7076:	06                   	push   es
    7077:	57                   	push   di
    7078:	9a 32 72 95 70       	call   0x7095:0x7232
    707d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7080:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7083:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7086:	26 ff b5 0c 01       	push   WORD PTR es:[di+0x10c]
    708b:	26 ff b5 0a 01       	push   WORD PTR es:[di+0x10a]
    7090:	06                   	push   es
    7091:	57                   	push   di
    7092:	9a d1 3c 41 71       	call   0x7141:0x3cd1
    7097:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    709a:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    70a0:	74 23                	je     0x70c5
    70a2:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    70a7:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    70ac:	2d 01 00             	sub    ax,0x1
    70af:	83 da 00             	sbb    dx,0x0
    70b2:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    70b7:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
    70bc:	06                   	push   es
    70bd:	57                   	push   di
    70be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    70c1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    70c5:	c9                   	leave
    70c6:	ca 08 00             	retf   0x8
    70c9:	55                   	push   bp
    70ca:	89 e5                	mov    bp,sp
    70cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70cf:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    70d4:	26 0b 85 ec 00       	or     ax,WORD PTR es:[di+0xec]
    70d9:	75 1b                	jne    0x70f6
    70db:	81 c7 ea 00          	add    di,0xea
    70df:	06                   	push   es
    70e0:	57                   	push   di
    70e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70e4:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    70e9:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    70ee:	26 ff b5 fa 00       	push   WORD PTR es:[di+0xfa]
    70f3:	e8 5e a3             	call   0x1454
    70f6:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    70f9:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    70fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70ff:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    7104:	7f 09                	jg     0x710f
    7106:	7c 0d                	jl     0x7115
    7108:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    710d:	72 06                	jb     0x7115
    710f:	68 57 f0             	push   0xf057
    7112:	e8 0d 9e             	call   0xf22
    7115:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7118:	ff 76 0c             	push   WORD PTR [bp+0xc]
    711b:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    711e:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    7121:	05 01 00             	add    ax,0x1
    7124:	83 d2 00             	adc    dx,0x0
    7127:	d1 e0                	shl    ax,1
    7129:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    712c:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    7131:	03 f8                	add    di,ax
    7133:	26 ff 35             	push   WORD PTR es:[di]
    7136:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7139:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    713c:	06                   	push   es
    713d:	57                   	push   di
    713e:	9a fb 51 b0 71       	call   0x71b0:0x51fb
    7143:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
    7146:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    7149:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    714c:	05 01 00             	add    ax,0x1
    714f:	83 d2 00             	adc    dx,0x0
    7152:	d1 e0                	shl    ax,1
    7154:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7157:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    715c:	03 f8                	add    di,ax
    715e:	26 89 0d             	mov    WORD PTR es:[di],cx
    7161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7164:	06                   	push   es
    7165:	57                   	push   di
    7166:	b8 e1 ff             	mov    ax,0xffe1
    7169:	9a 6a 20 a6 71       	call   0x71a6:0x206a
    716e:	c9                   	leave
    716f:	ca 0a 00             	retf   0xa
    7172:	55                   	push   bp
    7173:	89 e5                	mov    bp,sp
    7175:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7178:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    717d:	26 0b 85 ec 00       	or     ax,WORD PTR es:[di+0xec]
    7182:	74 0f                	je     0x7193
    7184:	81 c7 ea 00          	add    di,0xea
    7188:	06                   	push   es
    7189:	57                   	push   di
    718a:	6a 00                	push   0x0
    718c:	6a 00                	push   0x0
    718e:	6a 00                	push   0x0
    7190:	e8 c1 a2             	call   0x1454
    7193:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7196:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7199:	26 89 85 fa 00       	mov    WORD PTR es:[di+0xfa],ax
    719e:	06                   	push   es
    719f:	57                   	push   di
    71a0:	b8 e1 ff             	mov    ax,0xffe1
    71a3:	9a 6a 20 ea 71       	call   0x71ea:0x206a
    71a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71ab:	06                   	push   es
    71ac:	57                   	push   di
    71ad:	9a 82 48 f4 71       	call   0x71f4:0x4882
    71b2:	c9                   	leave
    71b3:	ca 06 00             	retf   0x6
    71b6:	55                   	push   bp
    71b7:	89 e5                	mov    bp,sp
    71b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71bc:	26 8b 85 0e 01       	mov    ax,WORD PTR es:[di+0x10e]
    71c1:	26 0b 85 10 01       	or     ax,WORD PTR es:[di+0x110]
    71c6:	74 0f                	je     0x71d7
    71c8:	81 c7 0e 01          	add    di,0x10e
    71cc:	06                   	push   es
    71cd:	57                   	push   di
    71ce:	6a 00                	push   0x0
    71d0:	6a 00                	push   0x0
    71d2:	6a 00                	push   0x0
    71d4:	e8 7d a2             	call   0x1454
    71d7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    71da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71dd:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    71e2:	06                   	push   es
    71e3:	57                   	push   di
    71e4:	b8 e0 ff             	mov    ax,0xffe0
    71e7:	9a 6a 20 46 75       	call   0x7546:0x206a
    71ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71ef:	06                   	push   es
    71f0:	57                   	push   di
    71f1:	9a 82 48 2c 72       	call   0x722c:0x4882
    71f6:	c9                   	leave
    71f7:	ca 06 00             	retf   0x6
    71fa:	55                   	push   bp
    71fb:	89 e5                	mov    bp,sp
    71fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7200:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    7205:	26 8b 95 04 01       	mov    dx,WORD PTR es:[di+0x104]
    720a:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    720d:	75 05                	jne    0x7214
    720f:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7212:	74 1a                	je     0x722e
    7214:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7217:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    721a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    721d:	26 89 85 02 01       	mov    WORD PTR es:[di+0x102],ax
    7222:	26 89 95 04 01       	mov    WORD PTR es:[di+0x104],dx
    7227:	06                   	push   es
    7228:	57                   	push   di
    7229:	9a 82 48 7b 72       	call   0x727b:0x4882
    722e:	c9                   	leave
    722f:	ca 08 00             	retf   0x8
    7232:	55                   	push   bp
    7233:	89 e5                	mov    bp,sp
    7235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7238:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    723d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7240:	74 45                	je     0x7287
    7242:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    7246:	7d 06                	jge    0x724e
    7248:	68 57 f0             	push   0xf057
    724b:	e8 d4 9c             	call   0xf22
    724e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7251:	99                   	cwd
    7252:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7255:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    725a:	7f 09                	jg     0x7265
    725c:	7c 0d                	jl     0x726b
    725e:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    7263:	72 06                	jb     0x726b
    7265:	68 58 f0             	push   0xf058
    7268:	e8 b7 9c             	call   0xf22
    726b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    726e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7271:	26 89 85 fe 00       	mov    WORD PTR es:[di+0xfe],ax
    7276:	06                   	push   es
    7277:	57                   	push   di
    7278:	9a bd 47 85 72       	call   0x7285:0x47bd
    727d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7280:	06                   	push   es
    7281:	57                   	push   di
    7282:	9a 82 48 d4 72       	call   0x72d4:0x4882
    7287:	c9                   	leave
    7288:	ca 06 00             	retf   0x6
    728b:	55                   	push   bp
    728c:	89 e5                	mov    bp,sp
    728e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7291:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    7296:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7299:	74 45                	je     0x72e0
    729b:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    729f:	7d 06                	jge    0x72a7
    72a1:	68 57 f0             	push   0xf057
    72a4:	e8 7b 9c             	call   0xf22
    72a7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    72aa:	99                   	cwd
    72ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72ae:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    72b3:	7f 09                	jg     0x72be
    72b5:	7c 0d                	jl     0x72c4
    72b7:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    72bc:	72 06                	jb     0x72c4
    72be:	68 59 f0             	push   0xf059
    72c1:	e8 5e 9c             	call   0xf22
    72c4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    72c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72ca:	26 89 85 00 01       	mov    WORD PTR es:[di+0x100],ax
    72cf:	06                   	push   es
    72d0:	57                   	push   di
    72d1:	9a bd 47 de 72       	call   0x72de:0x47bd
    72d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72d9:	06                   	push   es
    72da:	57                   	push   di
    72db:	9a 82 48 f5 72       	call   0x72f5:0x4882
    72e0:	c9                   	leave
    72e1:	ca 06 00             	retf   0x6
    72e4:	55                   	push   bp
    72e5:	89 e5                	mov    bp,sp
    72e7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    72eb:	75 0c                	jne    0x72f9
    72ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72f0:	06                   	push   es
    72f1:	57                   	push   di
    72f2:	9a 32 25 01 73       	call   0x7301:0x2532
    72f7:	eb 25                	jmp    0x731e
    72f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72fc:	06                   	push   es
    72fd:	57                   	push   di
    72fe:	9a 49 25 1c 73       	call   0x731c:0x2549
    7303:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7306:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    730b:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    7310:	74 0c                	je     0x731e
    7312:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7317:	06                   	push   es
    7318:	57                   	push   di
    7319:	9a fb 1b 3f 73       	call   0x733f:0x1bfb
    731e:	c9                   	leave
    731f:	ca 06 00             	retf   0x6
    7322:	55                   	push   bp
    7323:	89 e5                	mov    bp,sp
    7325:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7328:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    732d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7330:	74 0f                	je     0x7341
    7332:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7335:	26 89 85 06 01       	mov    WORD PTR es:[di+0x106],ax
    733a:	06                   	push   es
    733b:	57                   	push   di
    733c:	9a 82 48 77 73       	call   0x7377:0x4882
    7341:	c9                   	leave
    7342:	ca 06 00             	retf   0x6
    7345:	55                   	push   bp
    7346:	89 e5                	mov    bp,sp
    7348:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    734b:	26 8b 85 13 01       	mov    ax,WORD PTR es:[di+0x113]
    7350:	26 8b 95 15 01       	mov    dx,WORD PTR es:[di+0x115]
    7355:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    7358:	75 05                	jne    0x735f
    735a:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    735d:	74 1a                	je     0x7379
    735f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7362:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7365:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7368:	26 ff b5 19 01       	push   WORD PTR es:[di+0x119]
    736d:	26 ff b5 17 01       	push   WORD PTR es:[di+0x117]
    7372:	06                   	push   es
    7373:	57                   	push   di
    7374:	9a 73 51 a8 73       	call   0x73a8:0x5173
    7379:	c9                   	leave
    737a:	ca 08 00             	retf   0x8
    737d:	55                   	push   bp
    737e:	89 e5                	mov    bp,sp
    7380:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7383:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    7388:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    738b:	74 5b                	je     0x73e8
    738d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7390:	26 89 85 08 01       	mov    WORD PTR es:[di+0x108],ax
    7395:	26 80 bd 3c 01 00    	cmp    BYTE PTR es:[di+0x13c],0x0
    739b:	75 19                	jne    0x73b6
    739d:	f6 46 0b 20          	test   BYTE PTR [bp+0xb],0x20
    73a1:	74 09                	je     0x73ac
    73a3:	06                   	push   es
    73a4:	57                   	push   di
    73a5:	9a 49 25 b4 73       	call   0x73b4:0x2549
    73aa:	eb 0a                	jmp    0x73b6
    73ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73af:	06                   	push   es
    73b0:	57                   	push   di
    73b1:	9a 32 25 dc 73       	call   0x73dc:0x2532
    73b6:	f6 46 0b 10          	test   BYTE PTR [bp+0xb],0x10
    73ba:	74 22                	je     0x73de
    73bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73bf:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    73c4:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    73c9:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    73ce:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    73d3:	6a 01                	push   0x1
    73d5:	6a 00                	push   0x0
    73d7:	06                   	push   es
    73d8:	57                   	push   di
    73d9:	9a d6 4f e6 73       	call   0x73e6:0x4fd6
    73de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73e1:	06                   	push   es
    73e2:	57                   	push   di
    73e3:	9a 82 48 20 74       	call   0x7420:0x4882
    73e8:	c9                   	leave
    73e9:	ca 06 00             	retf   0x6
    73ec:	55                   	push   bp
    73ed:	89 e5                	mov    bp,sp
    73ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73f2:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    73f7:	26 8b 95 f8 00       	mov    dx,WORD PTR es:[di+0xf8]
    73fc:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    73ff:	75 05                	jne    0x7406
    7401:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7404:	74 1c                	je     0x7422
    7406:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7409:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    740e:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    7413:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7416:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7419:	6a 01                	push   0x1
    741b:	06                   	push   es
    741c:	57                   	push   di
    741d:	9a 86 42 83 74       	call   0x7483:0x4286
    7422:	c9                   	leave
    7423:	ca 08 00             	retf   0x8
    7426:	c8 04 00 00          	enter  0x4,0x0
    742a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    742d:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    7432:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    7437:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    743a:	75 05                	jne    0x7441
    743c:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    743f:	74 5e                	je     0x749f
    7441:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    7445:	7c 08                	jl     0x744f
    7447:	7f 10                	jg     0x7459
    7449:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    744d:	73 0a                	jae    0x7459
    744f:	c7 46 0a 01 00       	mov    WORD PTR [bp+0xa],0x1
    7454:	c7 46 0c 00 00       	mov    WORD PTR [bp+0xc],0x0
    7459:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    745c:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    7461:	99                   	cwd
    7462:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    7465:	7f 07                	jg     0x746e
    7467:	7c 1c                	jl     0x7485
    7469:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    746c:	72 17                	jb     0x7485
    746e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7471:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    7474:	2d 01 00             	sub    ax,0x1
    7477:	83 da 00             	sbb    dx,0x0
    747a:	50                   	push   ax
    747b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    747e:	06                   	push   es
    747f:	57                   	push   di
    7480:	9a 8b 72 9d 74       	call   0x749d:0x728b
    7485:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7488:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    748d:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    7492:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7495:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7498:	06                   	push   es
    7499:	57                   	push   di
    749a:	9a d1 3c 1b 75       	call   0x751b:0x3cd1
    749f:	c9                   	leave
    74a0:	ca 08 00             	retf   0x8
    74a3:	55                   	push   bp
    74a4:	89 e5                	mov    bp,sp
    74a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74a9:	26 8b 85 0e 01       	mov    ax,WORD PTR es:[di+0x10e]
    74ae:	26 0b 85 10 01       	or     ax,WORD PTR es:[di+0x110]
    74b3:	75 1b                	jne    0x74d0
    74b5:	81 c7 0e 01          	add    di,0x10e
    74b9:	06                   	push   es
    74ba:	57                   	push   di
    74bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74be:	26 ff b5 0c 01       	push   WORD PTR es:[di+0x10c]
    74c3:	26 ff b5 0a 01       	push   WORD PTR es:[di+0x10a]
    74c8:	26 ff b5 fc 00       	push   WORD PTR es:[di+0xfc]
    74cd:	e8 84 9f             	call   0x1454
    74d0:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    74d3:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    74d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74d9:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    74de:	7f 09                	jg     0x74e9
    74e0:	7c 0d                	jl     0x74ef
    74e2:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    74e7:	72 06                	jb     0x74ef
    74e9:	68 57 f0             	push   0xf057
    74ec:	e8 33 9a             	call   0xf22
    74ef:	ff 76 0e             	push   WORD PTR [bp+0xe]
    74f2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    74f5:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    74f8:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    74fb:	05 01 00             	add    ax,0x1
    74fe:	83 d2 00             	adc    dx,0x0
    7501:	d1 e0                	shl    ax,1
    7503:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7506:	26 c4 bd 0e 01       	les    di,DWORD PTR es:[di+0x10e]
    750b:	03 f8                	add    di,ax
    750d:	26 ff 35             	push   WORD PTR es:[di]
    7510:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7513:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7516:	06                   	push   es
    7517:	57                   	push   di
    7518:	9a 0c 52 0f 76       	call   0x760f:0x520c
    751d:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
    7520:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    7523:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    7526:	05 01 00             	add    ax,0x1
    7529:	83 d2 00             	adc    dx,0x0
    752c:	d1 e0                	shl    ax,1
    752e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7531:	26 c4 bd 0e 01       	les    di,DWORD PTR es:[di+0x10e]
    7536:	03 f8                	add    di,ax
    7538:	26 89 0d             	mov    WORD PTR es:[di],cx
    753b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    753e:	06                   	push   es
    753f:	57                   	push   di
    7540:	b8 e0 ff             	mov    ax,0xffe0
    7543:	9a 6a 20 f7 76       	call   0x76f7:0x206a
    7548:	c9                   	leave
    7549:	ca 0a 00             	retf   0xa
    754c:	55                   	push   bp
    754d:	89 e5                	mov    bp,sp
    754f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7552:	26 8a 85 12 01       	mov    al,BYTE PTR es:[di+0x112]
    7557:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    755a:	74 0f                	je     0x756b
    755c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    755f:	26 88 85 12 01       	mov    BYTE PTR es:[di+0x112],al
    7564:	06                   	push   es
    7565:	57                   	push   di
    7566:	9a 5a 40 69 79       	call   0x7969:0x405a
    756b:	c9                   	leave
    756c:	ca 06 00             	retf   0x6
    756f:	55                   	push   bp
    7570:	89 e5                	mov    bp,sp
    7572:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7575:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    757a:	26 0b 85 f0 00       	or     ax,WORD PTR es:[di+0xf0]
    757f:	75 18                	jne    0x7599
    7581:	81 c7 ee 00          	add    di,0xee
    7585:	06                   	push   es
    7586:	57                   	push   di
    7587:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    758a:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    758f:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    7594:	6a 01                	push   0x1
    7596:	e8 bb 9e             	call   0x1454
    7599:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    759c:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    759f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75a2:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    75a7:	7f 09                	jg     0x75b2
    75a9:	7c 0d                	jl     0x75b8
    75ab:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    75b0:	72 06                	jb     0x75b8
    75b2:	68 57 f0             	push   0xf057
    75b5:	e8 6a 99             	call   0xf22
    75b8:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    75bb:	98                   	cbw
    75bc:	8b c8                	mov    cx,ax
    75be:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    75c1:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    75c4:	05 01 00             	add    ax,0x1
    75c7:	83 d2 00             	adc    dx,0x0
    75ca:	d1 e0                	shl    ax,1
    75cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75cf:	26 c4 bd ee 00       	les    di,DWORD PTR es:[di+0xee]
    75d4:	03 f8                	add    di,ax
    75d6:	26 89 0d             	mov    WORD PTR es:[di],cx
    75d9:	c9                   	leave
    75da:	ca 0a 00             	retf   0xa
    75dd:	55                   	push   bp
    75de:	89 e5                	mov    bp,sp
    75e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75e3:	26 8b 85 17 01       	mov    ax,WORD PTR es:[di+0x117]
    75e8:	26 8b 95 19 01       	mov    dx,WORD PTR es:[di+0x119]
    75ed:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    75f0:	75 05                	jne    0x75f7
    75f2:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    75f5:	74 1a                	je     0x7611
    75f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75fa:	26 ff b5 15 01       	push   WORD PTR es:[di+0x115]
    75ff:	26 ff b5 13 01       	push   WORD PTR es:[di+0x113]
    7604:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7607:	ff 76 0a             	push   WORD PTR [bp+0xa]
    760a:	06                   	push   es
    760b:	57                   	push   di
    760c:	9a 73 51 19 76       	call   0x7619:0x5173
    7611:	c9                   	leave
    7612:	ca 08 00             	retf   0x8
    7615:	00 00                	add    BYTE PTR [bx+si],al
    7617:	4e                   	dec    si
    7618:	76 40                	jbe    0x765a
    761a:	76 55                	jbe    0x7671
    761c:	89 e5                	mov    bp,sp
    761e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7621:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    7626:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    762b:	74 4d                	je     0x767a
    762d:	b8 15 76             	mov    ax,0x7615
    7630:	0e                   	push   cs
    7631:	50                   	push   ax
    7632:	55                   	push   bp
    7633:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7637:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    763b:	06                   	push   es
    763c:	57                   	push   di
    763d:	9a c3 78 77 76       	call   0x7677:0x78c3
    7642:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7646:	83 c4 06             	add    sp,0x6
    7649:	b8 7a 76             	mov    ax,0x767a
    764c:	0e                   	push   cs
    764d:	50                   	push   ax
    764e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7651:	26 c7 85 33 01 ff ff 	mov    WORD PTR es:[di+0x133],0xffff
    7658:	26 c7 85 35 01 ff ff 	mov    WORD PTR es:[di+0x135],0xffff
    765f:	26 c7 85 37 01 ff ff 	mov    WORD PTR es:[di+0x137],0xffff
    7666:	26 c7 85 39 01 ff ff 	mov    WORD PTR es:[di+0x139],0xffff
    766d:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7672:	06                   	push   es
    7673:	57                   	push   di
    7674:	9a bf 1c 0f 78       	call   0x780f:0x1cbf
    7679:	cb                   	retf
    767a:	c9                   	leave
    767b:	ca 04 00             	retf   0x4
    767e:	00 c8                	add    al,cl
    7680:	02 01                	add    al,BYTE PTR [bx+di]
    7682:	00 c6                	add    dh,al
    7684:	46                   	inc    si
    7685:	ff 00                	inc    WORD PTR [bx+si]
    7687:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    768a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    768e:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    7693:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    7698:	26 89 85 33 01       	mov    WORD PTR es:[di+0x133],ax
    769d:	26 89 95 35 01       	mov    WORD PTR es:[di+0x135],dx
    76a2:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    76a7:	26 8b 95 f8 00       	mov    dx,WORD PTR es:[di+0xf8]
    76ac:	26 89 85 37 01       	mov    WORD PTR es:[di+0x137],ax
    76b1:	26 89 95 39 01       	mov    WORD PTR es:[di+0x139],dx
    76b6:	bf 7e 76             	mov    di,0x767e
    76b9:	0e                   	push   cs
    76ba:	57                   	push   di
    76bb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    76be:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    76c2:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    76c7:	06                   	push   es
    76c8:	57                   	push   di
    76c9:	9a b5 15 0a 77       	call   0x770a:0x15b5
    76ce:	8d be fe fe          	lea    di,[bp-0x102]
    76d2:	16                   	push   ss
    76d3:	57                   	push   di
    76d4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    76d7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    76db:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    76e0:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    76e5:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    76ea:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    76ef:	06                   	push   es
    76f0:	57                   	push   di
    76f1:	b8 e8 ff             	mov    ax,0xffe8
    76f4:	9a 6a 20 35 77       	call   0x7735:0x206a
    76f9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    76fc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7700:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7705:	06                   	push   es
    7706:	57                   	push   di
    7707:	9a 2a 19 48 77       	call   0x7748:0x192a
    770c:	8d be fe fe          	lea    di,[bp-0x102]
    7710:	16                   	push   ss
    7711:	57                   	push   di
    7712:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7715:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7719:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    771e:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    7723:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    7728:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    772d:	06                   	push   es
    772e:	57                   	push   di
    772f:	b8 ea ff             	mov    ax,0xffea
    7732:	9a 6a 20 59 77       	call   0x7759:0x206a
    7737:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    773a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    773e:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7743:	06                   	push   es
    7744:	57                   	push   di
    7745:	9a b5 15 6d 77       	call   0x776d:0x15b5
    774a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    774d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7751:	06                   	push   es
    7752:	57                   	push   di
    7753:	b8 e7 ff             	mov    ax,0xffe7
    7756:	9a 6a 20 24 79       	call   0x7924:0x206a
    775b:	50                   	push   ax
    775c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    775f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7763:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7768:	06                   	push   es
    7769:	57                   	push   di
    776a:	9a 6b 1a 80 77       	call   0x7780:0x1a6b
    776f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7772:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7776:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    777b:	06                   	push   es
    777c:	57                   	push   di
    777d:	9a 55 1a 17 79       	call   0x7917:0x1a55
    7782:	3d ff ff             	cmp    ax,0xffff
    7785:	75 0f                	jne    0x7796
    7787:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    778a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    778e:	26 c6 85 e5 00 00    	mov    BYTE PTR es:[di+0xe5],0x0
    7794:	eb 0d                	jmp    0x77a3
    7796:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7799:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    779d:	26 c6 85 e5 00 01    	mov    BYTE PTR es:[di+0xe5],0x1
    77a3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    77a6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    77aa:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    77af:	06                   	push   es
    77b0:	57                   	push   di
    77b1:	9a 3f 4a ff ff       	call   0xffff:0x4a3f
    77b6:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    77ba:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    77bd:	c9                   	leave
    77be:	c2 02 00             	ret    0x2
    77c1:	c8 08 00 00          	enter  0x8,0x0
    77c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c8:	06                   	push   es
    77c9:	57                   	push   di
    77ca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77cd:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    77d2:	08 c0                	or     al,al
    77d4:	75 03                	jne    0x77d9
    77d6:	e9 e6 00             	jmp    0x78bf
    77d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77dc:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    77e1:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    77e6:	75 4d                	jne    0x7835
    77e8:	06                   	push   es
    77e9:	57                   	push   di
    77ea:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77ed:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    77f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77f5:	26 89 85 2f 01       	mov    WORD PTR es:[di+0x12f],ax
    77fa:	26 89 95 31 01       	mov    WORD PTR es:[di+0x131],dx
    77ff:	ff 76 08             	push   WORD PTR [bp+0x8]
    7802:	ff 76 06             	push   WORD PTR [bp+0x6]
    7805:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    780a:	06                   	push   es
    780b:	57                   	push   di
    780c:	9a b0 16 70 78       	call   0x7870:0x16b0
    7811:	ff 76 08             	push   WORD PTR [bp+0x8]
    7814:	ff 76 06             	push   WORD PTR [bp+0x6]
    7817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    781a:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    781f:	06                   	push   es
    7820:	57                   	push   di
    7821:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7824:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    7828:	55                   	push   bp
    7829:	e8 53 fe             	call   0x767f
    782c:	08 c0                	or     al,al
    782e:	75 03                	jne    0x7833
    7830:	e9 8c 00             	jmp    0x78bf
    7833:	eb 47                	jmp    0x787c
    7835:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7838:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    783d:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    7842:	26 3b 95 35 01       	cmp    dx,WORD PTR es:[di+0x135]
    7847:	75 1f                	jne    0x7868
    7849:	26 3b 85 33 01       	cmp    ax,WORD PTR es:[di+0x133]
    784e:	75 18                	jne    0x7868
    7850:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    7855:	26 8b 95 f8 00       	mov    dx,WORD PTR es:[di+0xf8]
    785a:	26 3b 95 39 01       	cmp    dx,WORD PTR es:[di+0x139]
    785f:	75 07                	jne    0x7868
    7861:	26 3b 85 37 01       	cmp    ax,WORD PTR es:[di+0x137]
    7866:	74 14                	je     0x787c
    7868:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    786b:	06                   	push   es
    786c:	57                   	push   di
    786d:	9a 1b 76 ae 78       	call   0x78ae:0x761b
    7872:	55                   	push   bp
    7873:	e8 09 fe             	call   0x767f
    7876:	08 c0                	or     al,al
    7878:	75 02                	jne    0x787c
    787a:	eb 43                	jmp    0x78bf
    787c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    787f:	06                   	push   es
    7880:	57                   	push   di
    7881:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7884:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    7889:	08 c0                	or     al,al
    788b:	74 32                	je     0x78bf
    788d:	8d 7e f8             	lea    di,[bp-0x8]
    7890:	16                   	push   ss
    7891:	57                   	push   di
    7892:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7895:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    789a:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    789f:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    78a4:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    78a9:	06                   	push   es
    78aa:	57                   	push   di
    78ab:	9a 24 24 bd 78       	call   0x78bd:0x2424
    78b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78b3:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    78b8:	06                   	push   es
    78b9:	57                   	push   di
    78ba:	9a 59 1e 57 79       	call   0x7957:0x1e59
    78bf:	c9                   	leave
    78c0:	ca 04 00             	retf   0x4
    78c3:	c8 00 01 00          	enter  0x100,0x0
    78c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78ca:	26 83 bd 35 01 ff    	cmp    WORD PTR es:[di+0x135],0xffff
    78d0:	75 08                	jne    0x78da
    78d2:	26 83 bd 33 01 ff    	cmp    WORD PTR es:[di+0x133],0xffff
    78d8:	74 4c                	je     0x7926
    78da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78dd:	26 83 bd 39 01 ff    	cmp    WORD PTR es:[di+0x139],0xffff
    78e3:	75 08                	jne    0x78ed
    78e5:	26 83 bd 37 01 ff    	cmp    WORD PTR es:[di+0x137],0xffff
    78eb:	74 39                	je     0x7926
    78ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78f0:	26 ff b5 35 01       	push   WORD PTR es:[di+0x135]
    78f5:	26 ff b5 33 01       	push   WORD PTR es:[di+0x133]
    78fa:	26 ff b5 39 01       	push   WORD PTR es:[di+0x139]
    78ff:	26 ff b5 37 01       	push   WORD PTR es:[di+0x137]
    7904:	8d be 00 ff          	lea    di,[bp-0x100]
    7908:	16                   	push   ss
    7909:	57                   	push   di
    790a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    790d:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7912:	06                   	push   es
    7913:	57                   	push   di
    7914:	9a 24 15 ff ff       	call   0xffff:0x1524
    7919:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    791c:	06                   	push   es
    791d:	57                   	push   di
    791e:	b8 e9 ff             	mov    ax,0xffe9
    7921:	9a 6a 20 64 7d       	call   0x7d64:0x206a
    7926:	c9                   	leave
    7927:	ca 04 00             	retf   0x4
    792a:	55                   	push   bp
    792b:	89 e5                	mov    bp,sp
    792d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7930:	26 f6 85 09 01 04    	test   BYTE PTR es:[di+0x109],0x4
    7936:	74 23                	je     0x795b
    7938:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    793b:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
    793f:	3c 08                	cmp    al,0x8
    7941:	74 04                	je     0x7947
    7943:	3c 20                	cmp    al,0x20
    7945:	72 14                	jb     0x795b
    7947:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    794a:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
    794e:	50                   	push   ax
    794f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7952:	06                   	push   es
    7953:	57                   	push   di
    7954:	9a 60 25 3c 7a       	call   0x7a3c:0x2560
    7959:	eb 10                	jmp    0x796b
    795b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    795e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7961:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7964:	06                   	push   es
    7965:	57                   	push   di
    7966:	9a d3 52 80 79       	call   0x7980:0x52d3
    796b:	c9                   	leave
    796c:	ca 08 00             	retf   0x8
    796f:	55                   	push   bp
    7970:	89 e5                	mov    bp,sp
    7972:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7975:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7978:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    797b:	06                   	push   es
    797c:	57                   	push   di
    797d:	9a 2c 28 61 7a       	call   0x7a61:0x282c
    7982:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7985:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    798a:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    798f:	74 17                	je     0x79a8
    7991:	9a ff ff 00 00       	call   0x0:0xffff
    7996:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7999:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    799e:	26 89 85 01 01       	mov    WORD PTR es:[di+0x101],ax
    79a3:	26 89 95 03 01       	mov    WORD PTR es:[di+0x103],dx
    79a8:	c9                   	leave
    79a9:	ca 08 00             	retf   0x8
    79ac:	55                   	push   bp
    79ad:	89 e5                	mov    bp,sp
    79af:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    79b2:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    79b8:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    79be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79c1:	26 f6 85 09 01 10    	test   BYTE PTR es:[di+0x109],0x10
    79c7:	74 02                	je     0x79cb
    79c9:	eb 4a                	jmp    0x7a15
    79cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79ce:	26 f6 85 09 01 08    	test   BYTE PTR es:[di+0x109],0x8
    79d4:	74 1a                	je     0x79f0
    79d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    79d9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    79dd:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    79e1:	0d 02 00             	or     ax,0x2
    79e4:	81 ca 00 00          	or     dx,0x0
    79e8:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    79ec:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    79f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79f3:	26 f6 85 09 01 04    	test   BYTE PTR es:[di+0x109],0x4
    79f9:	74 1a                	je     0x7a15
    79fb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    79fe:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    7a02:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    7a06:	0d 80 00             	or     ax,0x80
    7a09:	81 ca 00 00          	or     dx,0x0
    7a0d:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    7a11:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    7a15:	c9                   	leave
    7a16:	ca 08 00             	retf   0x8
    7a19:	c8 10 00 00          	enter  0x10,0x0
    7a1d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7a20:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7a23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a26:	06                   	push   es
    7a27:	57                   	push   di
    7a28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a2b:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    7a2f:	8d 7e f0             	lea    di,[bp-0x10]
    7a32:	16                   	push   ss
    7a33:	57                   	push   di
    7a34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a37:	06                   	push   es
    7a38:	57                   	push   di
    7a39:	9a e6 6e 46 7a       	call   0x7a46:0x6ee6
    7a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a41:	06                   	push   es
    7a42:	57                   	push   di
    7a43:	9a 95 48 74 7a       	call   0x7a74:0x4895
    7a48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a4b:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    7a50:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    7a55:	74 1f                	je     0x7a76
    7a57:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7a5c:	06                   	push   es
    7a5d:	57                   	push   di
    7a5e:	9a b9 62 da 7a       	call   0x7ada:0x62b9
    7a63:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7a66:	26 3b 45 02          	cmp    ax,WORD PTR es:[di+0x2]
    7a6a:	74 0a                	je     0x7a76
    7a6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a6f:	06                   	push   es
    7a70:	57                   	push   di
    7a71:	9a 1b 76 f6 7a       	call   0x7af6:0x761b
    7a76:	c9                   	leave
    7a77:	ca 08 00             	retf   0x8
    7a7a:	55                   	push   bp
    7a7b:	89 e5                	mov    bp,sp
    7a7d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7a80:	06                   	push   es
    7a81:	57                   	push   di
    7a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a85:	06                   	push   es
    7a86:	57                   	push   di
    7a87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a8a:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    7a8e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7a91:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    7a95:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    7a99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a9c:	26 89 85 2b 01       	mov    WORD PTR es:[di+0x12b],ax
    7aa1:	26 89 95 2d 01       	mov    WORD PTR es:[di+0x12d],dx
    7aa6:	c9                   	leave
    7aa7:	ca 08 00             	retf   0x8
    7aaa:	c8 2c 00 00          	enter  0x2c,0x0
    7aae:	31 c0                	xor    ax,ax
    7ab0:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    7ab3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7ab6:	26 83 7d 04 01       	cmp    WORD PTR es:[di+0x4],0x1
    7abb:	74 03                	je     0x7ac0
    7abd:	e9 a3 00             	jmp    0x7b63
    7ac0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ac3:	26 80 bd 3f 01 00    	cmp    BYTE PTR es:[di+0x13f],0x0
    7ac9:	75 5f                	jne    0x7b2a
    7acb:	26 ff b5 2d 01       	push   WORD PTR es:[di+0x12d]
    7ad0:	26 ff b5 2b 01       	push   WORD PTR es:[di+0x12b]
    7ad5:	06                   	push   es
    7ad6:	57                   	push   di
    7ad7:	9a 06 1a 81 7b       	call   0x7b81:0x1a06
    7adc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7adf:	26 89 85 2b 01       	mov    WORD PTR es:[di+0x12b],ax
    7ae4:	26 89 95 2d 01       	mov    WORD PTR es:[di+0x12d],dx
    7ae9:	8d 7e e4             	lea    di,[bp-0x1c]
    7aec:	16                   	push   ss
    7aed:	57                   	push   di
    7aee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7af1:	06                   	push   es
    7af2:	57                   	push   di
    7af3:	9a 20 36 26 7b       	call   0x7b26:0x3620
    7af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7afb:	26 ff b5 2b 01       	push   WORD PTR es:[di+0x12b]
    7b00:	26 ff b5 2d 01       	push   WORD PTR es:[di+0x12d]
    7b05:	8d 7e e3             	lea    di,[bp-0x1d]
    7b08:	16                   	push   ss
    7b09:	57                   	push   di
    7b0a:	8d 7e de             	lea    di,[bp-0x22]
    7b0d:	16                   	push   ss
    7b0e:	57                   	push   di
    7b0f:	8d 7e dc             	lea    di,[bp-0x24]
    7b12:	16                   	push   ss
    7b13:	57                   	push   di
    7b14:	8d 7e da             	lea    di,[bp-0x26]
    7b17:	16                   	push   ss
    7b18:	57                   	push   di
    7b19:	8d 7e e4             	lea    di,[bp-0x1c]
    7b1c:	16                   	push   ss
    7b1d:	57                   	push   di
    7b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b21:	06                   	push   es
    7b22:	57                   	push   di
    7b23:	9a 36 38 ce 7b       	call   0x7bce:0x3836
    7b28:	eb 0b                	jmp    0x7b35
    7b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b2d:	26 8a 85 3f 01       	mov    al,BYTE PTR es:[di+0x13f]
    7b32:	88 46 e3             	mov    BYTE PTR [bp-0x1d],al
    7b35:	80 7e e3 02          	cmp    BYTE PTR [bp-0x1d],0x2
    7b39:	75 12                	jne    0x7b4d
    7b3b:	6a f1                	push   0xfff1
    7b3d:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    7b41:	06                   	push   es
    7b42:	57                   	push   di
    7b43:	9a 3e 63 5e 7b       	call   0x7b5e:0x633e
    7b48:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    7b4b:	eb 16                	jmp    0x7b63
    7b4d:	80 7e e3 03          	cmp    BYTE PTR [bp-0x1d],0x3
    7b51:	75 10                	jne    0x7b63
    7b53:	6a f2                	push   0xfff2
    7b55:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    7b59:	06                   	push   es
    7b5a:	57                   	push   di
    7b5b:	9a 3e 63 ff ff       	call   0xffff:0x633e
    7b60:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    7b63:	83 7e d8 00          	cmp    WORD PTR [bp-0x28],0x0
    7b67:	74 0a                	je     0x7b73
    7b69:	ff 76 d8             	push   WORD PTR [bp-0x28]
    7b6c:	9a ff ff 00 00       	call   0x0:0xffff
    7b71:	eb 10                	jmp    0x7b83
    7b73:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7b76:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7b79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b7c:	06                   	push   es
    7b7d:	57                   	push   di
    7b7e:	9a f8 4d b6 7b       	call   0x7bb6:0x4df8
    7b83:	c9                   	leave
    7b84:	ca 08 00             	retf   0x8
    7b87:	c8 10 00 00          	enter  0x10,0x0
    7b8b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7b8e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7b91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b94:	06                   	push   es
    7b95:	57                   	push   di
    7b96:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b99:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    7b9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ba0:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    7ba5:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    7baa:	74 15                	je     0x7bc1
    7bac:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7bb1:	06                   	push   es
    7bb2:	57                   	push   di
    7bb3:	9a b9 62 f9 7b       	call   0x7bf9:0x62b9
    7bb8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7bbb:	26 3b 45 02          	cmp    ax,WORD PTR es:[di+0x2]
    7bbf:	74 23                	je     0x7be4
    7bc1:	8d 7e f0             	lea    di,[bp-0x10]
    7bc4:	16                   	push   ss
    7bc5:	57                   	push   di
    7bc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bc9:	06                   	push   es
    7bca:	57                   	push   di
    7bcb:	9a e6 6e d8 7b       	call   0x7bd8:0x6ee6
    7bd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bd3:	06                   	push   es
    7bd4:	57                   	push   di
    7bd5:	9a 95 48 e2 7b       	call   0x7be2:0x4895
    7bda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bdd:	06                   	push   es
    7bde:	57                   	push   di
    7bdf:	9a c1 77 03 7c       	call   0x7c03:0x77c1
    7be4:	c9                   	leave
    7be5:	ca 08 00             	retf   0x8
    7be8:	55                   	push   bp
    7be9:	89 e5                	mov    bp,sp
    7beb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7bee:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7bf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bf4:	06                   	push   es
    7bf5:	57                   	push   di
    7bf6:	9a a8 4d 2f 7c       	call   0x7c2f:0x4da8
    7bfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bfe:	06                   	push   es
    7bff:	57                   	push   di
    7c00:	9a 86 5b 4b 7c       	call   0x7c4b:0x5b86
    7c05:	c9                   	leave
    7c06:	ca 08 00             	retf   0x8
    7c09:	c8 04 00 00          	enter  0x4,0x0
    7c0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7c10:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    7c13:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    7c16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c19:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    7c1e:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    7c23:	74 28                	je     0x7c4d
    7c25:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7c2a:	06                   	push   es
    7c2b:	57                   	push   di
    7c2c:	9a b9 62 b1 7c       	call   0x7cb1:0x62b9
    7c31:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7c34:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    7c38:	75 13                	jne    0x7c4d
    7c3a:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    7c3e:	3d 00 03             	cmp    ax,0x300
    7c41:	75 0a                	jne    0x7c4d
    7c43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c46:	06                   	push   es
    7c47:	57                   	push   di
    7c48:	9a c3 78 69 7c       	call   0x7c69:0x78c3
    7c4d:	c9                   	leave
    7c4e:	ca 08 00             	retf   0x8
    7c51:	55                   	push   bp
    7c52:	89 e5                	mov    bp,sp
    7c54:	6a 01                	push   0x1
    7c56:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7c59:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    7c5d:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    7c61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c64:	06                   	push   es
    7c65:	57                   	push   di
    7c66:	9a 65 4d 87 7c       	call   0x7c87:0x4d65
    7c6b:	c9                   	leave
    7c6c:	ca 08 00             	retf   0x8
    7c6f:	55                   	push   bp
    7c70:	89 e5                	mov    bp,sp
    7c72:	6a 00                	push   0x0
    7c74:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7c77:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    7c7b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    7c7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c82:	06                   	push   es
    7c83:	57                   	push   di
    7c84:	9a 65 4d 00 7d       	call   0x7d00:0x4d65
    7c89:	c9                   	leave
    7c8a:	ca 08 00             	retf   0x8
    7c8d:	55                   	push   bp
    7c8e:	89 e5                	mov    bp,sp
    7c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c93:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    7c98:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    7c9d:	74 14                	je     0x7cb3
    7c9f:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7ca3:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7ca7:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    7cac:	06                   	push   es
    7cad:	57                   	push   di
    7cae:	9a eb 1d c1 7c       	call   0x7cc1:0x1deb
    7cb3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7cb6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7cb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cbc:	06                   	push   es
    7cbd:	57                   	push   di
    7cbe:	9a 3a 57 d8 7c       	call   0x7cd8:0x573a
    7cc3:	c9                   	leave
    7cc4:	ca 08 00             	retf   0x8
    7cc7:	55                   	push   bp
    7cc8:	89 e5                	mov    bp,sp
    7cca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7ccd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7cd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cd3:	06                   	push   es
    7cd4:	57                   	push   di
    7cd5:	9a d8 57 95 7e       	call   0x7e95:0x57d8
    7cda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cdd:	06                   	push   es
    7cde:	57                   	push   di
    7cdf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7ce2:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    7ce6:	c9                   	leave
    7ce7:	ca 08 00             	retf   0x8
    7cea:	55                   	push   bp
    7ceb:	89 e5                	mov    bp,sp
    7ced:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7cf0:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    7cf4:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    7cf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cfb:	06                   	push   es
    7cfc:	57                   	push   di
    7cfd:	9a 97 28 66 7e       	call   0x7e66:0x2897
    7d02:	98                   	cbw
    7d03:	99                   	cwd
    7d04:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d07:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    7d0b:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    7d0f:	c9                   	leave
    7d10:	ca 08 00             	retf   0x8
    7d13:	55                   	push   bp
    7d14:	89 e5                	mov    bp,sp
    7d16:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7d19:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7d1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d1f:	06                   	push   es
    7d20:	57                   	push   di
    7d21:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7d24:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    7d28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d2b:	26 f6 85 09 01 04    	test   BYTE PTR es:[di+0x109],0x4
    7d31:	74 16                	je     0x7d49
    7d33:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d36:	26 80 7d 02 0d       	cmp    BYTE PTR es:[di+0x2],0xd
    7d3b:	75 0c                	jne    0x7d49
    7d3d:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    7d43:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    7d49:	c9                   	leave
    7d4a:	ca 08 00             	retf   0x8
    7d4d:	c8 10 00 00          	enter  0x10,0x0
    7d51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d54:	81 c7 dc 00          	add    di,0xdc
    7d58:	06                   	push   es
    7d59:	57                   	push   di
    7d5a:	8d 7e f0             	lea    di,[bp-0x10]
    7d5d:	16                   	push   ss
    7d5e:	57                   	push   di
    7d5f:	6a 08                	push   0x8
    7d61:	9a 1b 16 f9 7e       	call   0x7ef9:0x161b
    7d66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d69:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    7d6e:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    7d73:	2d 01 00             	sub    ax,0x1
    7d76:	83 da 00             	sbb    dx,0x0
    7d79:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7d7c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7d7f:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    7d84:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    7d89:	2d 01 00             	sub    ax,0x1
    7d8c:	83 da 00             	sbb    dx,0x0
    7d8f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7d92:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7d95:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    7d99:	74 1e                	je     0x7db9
    7d9b:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    7da0:	99                   	cwd
    7da1:	26 3b 95 de 00       	cmp    dx,WORD PTR es:[di+0xde]
    7da6:	7c 09                	jl     0x7db1
    7da8:	7f 0f                	jg     0x7db9
    7daa:	26 3b 85 dc 00       	cmp    ax,WORD PTR es:[di+0xdc]
    7daf:	73 08                	jae    0x7db9
    7db1:	83 6e f0 01          	sub    WORD PTR [bp-0x10],0x1
    7db5:	83 5e f2 00          	sbb    WORD PTR [bp-0xe],0x0
    7db9:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    7dbd:	74 21                	je     0x7de0
    7dbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dc2:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    7dc7:	26 8b 95 de 00       	mov    dx,WORD PTR es:[di+0xde]
    7dcc:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    7dcf:	7c 07                	jl     0x7dd8
    7dd1:	7f 0d                	jg     0x7de0
    7dd3:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7dd6:	73 08                	jae    0x7de0
    7dd8:	83 46 f0 01          	add    WORD PTR [bp-0x10],0x1
    7ddc:	83 56 f2 00          	adc    WORD PTR [bp-0xe],0x0
    7de0:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    7de4:	74 21                	je     0x7e07
    7de6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7de9:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    7dee:	99                   	cwd
    7def:	26 3b 95 e2 00       	cmp    dx,WORD PTR es:[di+0xe2]
    7df4:	7c 09                	jl     0x7dff
    7df6:	7f 0f                	jg     0x7e07
    7df8:	26 3b 85 e0 00       	cmp    ax,WORD PTR es:[di+0xe0]
    7dfd:	73 08                	jae    0x7e07
    7dff:	83 6e f4 01          	sub    WORD PTR [bp-0xc],0x1
    7e03:	83 5e f6 00          	sbb    WORD PTR [bp-0xa],0x0
    7e07:	f6 46 0a 08          	test   BYTE PTR [bp+0xa],0x8
    7e0b:	74 21                	je     0x7e2e
    7e0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e10:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    7e15:	26 8b 95 e2 00       	mov    dx,WORD PTR es:[di+0xe2]
    7e1a:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    7e1d:	7c 07                	jl     0x7e26
    7e1f:	7f 0d                	jg     0x7e2e
    7e21:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    7e24:	73 08                	jae    0x7e2e
    7e26:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    7e2a:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    7e2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e31:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    7e36:	26 8b 95 de 00       	mov    dx,WORD PTR es:[di+0xde]
    7e3b:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    7e3e:	75 19                	jne    0x7e59
    7e40:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    7e43:	75 14                	jne    0x7e59
    7e45:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    7e4a:	26 8b 95 e2 00       	mov    dx,WORD PTR es:[di+0xe2]
    7e4f:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    7e52:	75 05                	jne    0x7e59
    7e54:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    7e57:	74 0f                	je     0x7e68
    7e59:	8d 7e f0             	lea    di,[bp-0x10]
    7e5c:	16                   	push   ss
    7e5d:	57                   	push   di
    7e5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e61:	06                   	push   es
    7e62:	57                   	push   di
    7e63:	9a 25 4f aa 7e       	call   0x7eaa:0x4f25
    7e68:	c9                   	leave
    7e69:	ca 06 00             	retf   0x6
    7e6c:	c8 22 00 00          	enter  0x22,0x0
    7e70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e73:	26 80 bd 3f 01 01    	cmp    BYTE PTR es:[di+0x13f],0x1
    7e79:	74 02                	je     0x7e7d
    7e7b:	eb 7e                	jmp    0x7efb
    7e7d:	8d 7e fc             	lea    di,[bp-0x4]
    7e80:	16                   	push   ss
    7e81:	57                   	push   di
    7e82:	9a ff ff 00 00       	call   0x0:0xffff
    7e87:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7e8a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e90:	06                   	push   es
    7e91:	57                   	push   di
    7e92:	9a 06 1a ff ff       	call   0xffff:0x1a06
    7e97:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7e9a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7e9d:	8d 7e e0             	lea    di,[bp-0x20]
    7ea0:	16                   	push   ss
    7ea1:	57                   	push   di
    7ea2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ea5:	06                   	push   es
    7ea6:	57                   	push   di
    7ea7:	9a 4f 34 0a 7f       	call   0x7f0a:0x344f
    7eac:	c6 46 df 00          	mov    BYTE PTR [bp-0x21],0x0
    7eb0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7eb3:	3b 46 e4             	cmp    ax,WORD PTR [bp-0x1c]
    7eb6:	7d 06                	jge    0x7ebe
    7eb8:	80 4e df 01          	or     BYTE PTR [bp-0x21],0x1
    7ebc:	eb 0c                	jmp    0x7eca
    7ebe:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7ec1:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7ec4:	7e 04                	jle    0x7eca
    7ec6:	80 4e df 02          	or     BYTE PTR [bp-0x21],0x2
    7eca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7ecd:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    7ed0:	7d 06                	jge    0x7ed8
    7ed2:	80 4e df 04          	or     BYTE PTR [bp-0x21],0x4
    7ed6:	eb 0c                	jmp    0x7ee4
    7ed8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7edb:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    7ede:	7e 04                	jle    0x7ee4
    7ee0:	80 4e df 08          	or     BYTE PTR [bp-0x21],0x8
    7ee4:	80 7e df 00          	cmp    BYTE PTR [bp-0x21],0x0
    7ee8:	74 11                	je     0x7efb
    7eea:	8a 46 df             	mov    al,BYTE PTR [bp-0x21]
    7eed:	50                   	push   ax
    7eee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ef1:	06                   	push   es
    7ef2:	57                   	push   di
    7ef3:	b8 e2 ff             	mov    ax,0xffe2
    7ef6:	9a 6a 20 5e 7f       	call   0x7f5e:0x206a
    7efb:	c9                   	leave
    7efc:	ca 08 00             	retf   0x8
    7eff:	55                   	push   bp
    7f00:	89 e5                	mov    bp,sp
    7f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f05:	06                   	push   es
    7f06:	57                   	push   di
    7f07:	9a 86 5b 14 7f       	call   0x7f14:0x5b86
    7f0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f0f:	06                   	push   es
    7f10:	57                   	push   di
    7f11:	9a c1 77 25 7f       	call   0x7f25:0x77c1
    7f16:	c9                   	leave
    7f17:	ca 04 00             	retf   0x4
    7f1a:	55                   	push   bp
    7f1b:	89 e5                	mov    bp,sp
    7f1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f20:	06                   	push   es
    7f21:	57                   	push   di
    7f22:	9a 86 5b 2f 7f       	call   0x7f2f:0x5b86
    7f27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f2a:	06                   	push   es
    7f2b:	57                   	push   di
    7f2c:	9a c1 77 52 7f       	call   0x7f52:0x77c1
    7f31:	c9                   	leave
    7f32:	ca 04 00             	retf   0x4
    7f35:	c8 08 00 00          	enter  0x8,0x0
    7f39:	8d 7e f8             	lea    di,[bp-0x8]
    7f3c:	16                   	push   ss
    7f3d:	57                   	push   di
    7f3e:	ff 76 10             	push   WORD PTR [bp+0x10]
    7f41:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7f44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7f47:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7f4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f4d:	06                   	push   es
    7f4e:	57                   	push   di
    7f4f:	9a 24 24 7b 7f       	call   0x7f7b:0x2424
    7f54:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    7f57:	06                   	push   es
    7f58:	57                   	push   di
    7f59:	6a 08                	push   0x8
    7f5b:	9a 1b 16 87 7f       	call   0x7f87:0x161b
    7f60:	c9                   	leave
    7f61:	ca 0c 00             	retf   0xc
    7f64:	c8 10 00 00          	enter  0x10,0x0
    7f68:	8d 7e f0             	lea    di,[bp-0x10]
    7f6b:	16                   	push   ss
    7f6c:	57                   	push   di
    7f6d:	ff 76 14             	push   WORD PTR [bp+0x14]
    7f70:	ff 76 12             	push   WORD PTR [bp+0x12]
    7f73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f76:	06                   	push   es
    7f77:	57                   	push   di
    7f78:	9a 44 28 81 81       	call   0x8181:0x2844
    7f7d:	8d 7e f8             	lea    di,[bp-0x8]
    7f80:	16                   	push   ss
    7f81:	57                   	push   di
    7f82:	6a 08                	push   0x8
    7f84:	9a 1b 16 c2 81       	call   0x81c2:0x161b
    7f89:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7f8c:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7f8f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    7f92:	26 89 05             	mov    WORD PTR es:[di],ax
    7f95:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    7f99:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7f9c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7f9f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7fa2:	26 89 05             	mov    WORD PTR es:[di],ax
    7fa5:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    7fa9:	c9                   	leave
    7faa:	ca 10 00             	retf   0x10
    7fad:	55                   	push   bp
    7fae:	89 e5                	mov    bp,sp
    7fb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7fb3:	26 8b 85 43 01       	mov    ax,WORD PTR es:[di+0x143]
    7fb8:	09 c0                	or     ax,ax
    7fba:	74 21                	je     0x7fdd
    7fbc:	ff 76 08             	push   WORD PTR [bp+0x8]
    7fbf:	ff 76 06             	push   WORD PTR [bp+0x6]
    7fc2:	ff 76 10             	push   WORD PTR [bp+0x10]
    7fc5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7fc8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7fcb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7fce:	26 ff b5 47 01       	push   WORD PTR es:[di+0x147]
    7fd3:	26 ff b5 45 01       	push   WORD PTR es:[di+0x145]
    7fd8:	26 ff 9d 41 01       	call   DWORD PTR es:[di+0x141]
    7fdd:	c9                   	leave
    7fde:	ca 0c 00             	retf   0xc
    7fe1:	55                   	push   bp
    7fe2:	89 e5                	mov    bp,sp
    7fe4:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    7fe7:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    7feb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7fee:	26 8b 85 53 01       	mov    ax,WORD PTR es:[di+0x153]
    7ff3:	09 c0                	or     ax,ax
    7ff5:	74 2c                	je     0x8023
    7ff7:	ff 76 08             	push   WORD PTR [bp+0x8]
    7ffa:	ff 76 06             	push   WORD PTR [bp+0x6]
    7ffd:	ff 76 10             	push   WORD PTR [bp+0x10]
    8000:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8003:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8006:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8009:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    800c:	06                   	push   es
    800d:	57                   	push   di
    800e:	68 ff 00             	push   0xff
    8011:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8014:	26 ff b5 57 01       	push   WORD PTR es:[di+0x157]
    8019:	26 ff b5 55 01       	push   WORD PTR es:[di+0x155]
    801e:	26 ff 9d 51 01       	call   DWORD PTR es:[di+0x151]
    8023:	c9                   	leave
    8024:	ca 0c 00             	retf   0xc
    8027:	55                   	push   bp
    8028:	89 e5                	mov    bp,sp
    802a:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    802d:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    8031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8034:	26 8b 85 5b 01       	mov    ax,WORD PTR es:[di+0x15b]
    8039:	09 c0                	or     ax,ax
    803b:	74 2c                	je     0x8069
    803d:	ff 76 08             	push   WORD PTR [bp+0x8]
    8040:	ff 76 06             	push   WORD PTR [bp+0x6]
    8043:	ff 76 10             	push   WORD PTR [bp+0x10]
    8046:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8049:	ff 76 0c             	push   WORD PTR [bp+0xc]
    804c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    804f:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    8052:	06                   	push   es
    8053:	57                   	push   di
    8054:	68 ff 00             	push   0xff
    8057:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    805a:	26 ff b5 5f 01       	push   WORD PTR es:[di+0x15f]
    805f:	26 ff b5 5d 01       	push   WORD PTR es:[di+0x15d]
    8064:	26 ff 9d 59 01       	call   DWORD PTR es:[di+0x159]
    8069:	c9                   	leave
    806a:	ca 0c 00             	retf   0xc
    806d:	55                   	push   bp
    806e:	89 e5                	mov    bp,sp
    8070:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8073:	26 8b 85 63 01       	mov    ax,WORD PTR es:[di+0x163]
    8078:	09 c0                	or     ax,ax
    807a:	74 21                	je     0x809d
    807c:	ff 76 08             	push   WORD PTR [bp+0x8]
    807f:	ff 76 06             	push   WORD PTR [bp+0x6]
    8082:	ff 76 10             	push   WORD PTR [bp+0x10]
    8085:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8088:	ff 76 0c             	push   WORD PTR [bp+0xc]
    808b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    808e:	26 ff b5 67 01       	push   WORD PTR es:[di+0x167]
    8093:	26 ff b5 65 01       	push   WORD PTR es:[di+0x165]
    8098:	26 ff 9d 61 01       	call   DWORD PTR es:[di+0x161]
    809d:	c9                   	leave
    809e:	ca 0c 00             	retf   0xc
    80a1:	c8 02 00 00          	enter  0x2,0x0
    80a5:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    80a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80ac:	26 8b 85 6b 01       	mov    ax,WORD PTR es:[di+0x16b]
    80b1:	09 c0                	or     ax,ax
    80b3:	74 29                	je     0x80de
    80b5:	ff 76 08             	push   WORD PTR [bp+0x8]
    80b8:	ff 76 06             	push   WORD PTR [bp+0x6]
    80bb:	ff 76 10             	push   WORD PTR [bp+0x10]
    80be:	ff 76 0e             	push   WORD PTR [bp+0xe]
    80c1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    80c4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    80c7:	8d 7e ff             	lea    di,[bp-0x1]
    80ca:	16                   	push   ss
    80cb:	57                   	push   di
    80cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80cf:	26 ff b5 6f 01       	push   WORD PTR es:[di+0x16f]
    80d4:	26 ff b5 6d 01       	push   WORD PTR es:[di+0x16d]
    80d9:	26 ff 9d 69 01       	call   DWORD PTR es:[di+0x169]
    80de:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    80e1:	c9                   	leave
    80e2:	ca 0c 00             	retf   0xc
    80e5:	55                   	push   bp
    80e6:	89 e5                	mov    bp,sp
    80e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80eb:	26 8b 85 73 01       	mov    ax,WORD PTR es:[di+0x173]
    80f0:	09 c0                	or     ax,ax
    80f2:	74 29                	je     0x811d
    80f4:	ff 76 08             	push   WORD PTR [bp+0x8]
    80f7:	ff 76 06             	push   WORD PTR [bp+0x6]
    80fa:	ff 76 14             	push   WORD PTR [bp+0x14]
    80fd:	ff 76 12             	push   WORD PTR [bp+0x12]
    8100:	ff 76 10             	push   WORD PTR [bp+0x10]
    8103:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8106:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8109:	06                   	push   es
    810a:	57                   	push   di
    810b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    810e:	26 ff b5 77 01       	push   WORD PTR es:[di+0x177]
    8113:	26 ff b5 75 01       	push   WORD PTR es:[di+0x175]
    8118:	26 ff 9d 71 01       	call   DWORD PTR es:[di+0x171]
    811d:	c9                   	leave
    811e:	ca 10 00             	retf   0x10
    8121:	c8 08 00 00          	enter  0x8,0x0
    8125:	8c d3                	mov    bx,ss
    8127:	8e c3                	mov    es,bx
    8129:	8c db                	mov    bx,ds
    812b:	fc                   	cld
    812c:	8d 7e f8             	lea    di,[bp-0x8]
    812f:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    8132:	b9 08 00             	mov    cx,0x8
    8135:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    8137:	8e db                	mov    ds,bx
    8139:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    813c:	26 8b 85 4b 01       	mov    ax,WORD PTR es:[di+0x14b]
    8141:	09 c0                	or     ax,ax
    8143:	74 2d                	je     0x8172
    8145:	ff 76 08             	push   WORD PTR [bp+0x8]
    8148:	ff 76 06             	push   WORD PTR [bp+0x6]
    814b:	ff 76 16             	push   WORD PTR [bp+0x16]
    814e:	ff 76 14             	push   WORD PTR [bp+0x14]
    8151:	ff 76 12             	push   WORD PTR [bp+0x12]
    8154:	ff 76 10             	push   WORD PTR [bp+0x10]
    8157:	8d 7e f8             	lea    di,[bp-0x8]
    815a:	16                   	push   ss
    815b:	57                   	push   di
    815c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    815f:	50                   	push   ax
    8160:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8163:	26 ff b5 4f 01       	push   WORD PTR es:[di+0x14f]
    8168:	26 ff b5 4d 01       	push   WORD PTR es:[di+0x14d]
    816d:	26 ff 9d 49 01       	call   DWORD PTR es:[di+0x149]
    8172:	c9                   	leave
    8173:	ca 12 00             	retf   0x12
    8176:	55                   	push   bp
    8177:	89 e5                	mov    bp,sp
    8179:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    817c:	06                   	push   es
    817d:	57                   	push   di
    817e:	9a f7 28 fd 81       	call   0x81fd:0x28f7
    8183:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8186:	26 8b 85 7b 01       	mov    ax,WORD PTR es:[di+0x17b]
    818b:	09 c0                	or     ax,ax
    818d:	74 15                	je     0x81a4
    818f:	ff 76 08             	push   WORD PTR [bp+0x8]
    8192:	ff 76 06             	push   WORD PTR [bp+0x6]
    8195:	26 ff b5 7f 01       	push   WORD PTR es:[di+0x17f]
    819a:	26 ff b5 7d 01       	push   WORD PTR es:[di+0x17d]
    819f:	26 ff 9d 79 01       	call   DWORD PTR es:[di+0x179]
    81a4:	c9                   	leave
    81a5:	ca 04 00             	retf   0x4
	...
    81b0:	c8 81 0c 00          	enter  0xc81,0x0
    81b4:	2e 00 72 89          	add    BYTE PTR cs:[bp+si-0x77],dh
    81b8:	64 20 f9             	fs and cl,bh
    81bb:	81 9a 1f ba 81 cb    	sbb    WORD PTR [bp+si-0x45e1],0xcb81
    81c1:	1f                   	pop    ds
    81c2:	be 81 c4             	mov    si,0xc481
    81c5:	29 b6 81 16          	sub    WORD PTR [bp+0x1681],si
    81c9:	45                   	inc    bp
    81ca:	53                   	push   bx
    81cb:	74 72                	je     0x823f
    81cd:	69 6e 67 53 70       	imul   bp,WORD PTR [bp+0x67],0x7053
    81d2:	61                   	popa
    81d3:	72 73                	jb     0x8248
    81d5:	65 4c                	gs dec sp
    81d7:	69 73 74 45 72       	imul   si,WORD PTR [bp+di+0x74],0x7245
    81dc:	72 6f                	jb     0x824d
    81de:	72 00                	jb     0x81e0
    81e0:	00 00                	add    BYTE PTR [bx+si],al
    81e2:	00 00                	add    BYTE PTR [bx+si],al
    81e4:	00 00                	add    BYTE PTR [bx+si],al
    81e6:	00 ff                	add    bh,bh
    81e8:	81 18 00 2c          	sbb    WORD PTR [bx+si],0x2c00
    81ec:	1f                   	pop    ds
    81ed:	2d 82 64             	sub    ax,0x6482
    81f0:	20 ed                	and    ch,ch
    81f2:	81 9a 1f f1 81 cb    	sbb    WORD PTR [bp+si-0xee1],0xcb81
    81f8:	1f                   	pop    ds
    81f9:	f5                   	cmc
    81fa:	81 42 84 35 82       	add    WORD PTR [bp+si-0x7c],0x8235
    81ff:	13 54 53             	adc    dx,WORD PTR [si+0x53]
    8202:	70 61                	jo     0x8265
    8204:	72 73                	jb     0x8279
    8206:	65 50                	gs push ax
    8208:	6f                   	outs   dx,WORD PTR ds:[si]
    8209:	69 6e 74 65 72       	imul   bp,WORD PTR [bp+0x74],0x7265
    820e:	41                   	inc    cx
    820f:	72 72                	jb     0x8283
    8211:	61                   	popa
    8212:	79 00                	jns    0x8214
    8214:	00 00                	add    BYTE PTR [bx+si],al
    8216:	00 00                	add    BYTE PTR [bx+si],al
    8218:	00 00                	add    BYTE PTR [bx+si],al
    821a:	00 37                	add    BYTE PTR [bx],dh
    821c:	82 0b 00             	or     BYTE PTR [bp+di],0x0
    821f:	2c 1f                	sub    al,0x1f
    8221:	5d                   	pop    bp
    8222:	82 64 20 21          	and    BYTE PTR [si+0x20],0x21
    8226:	82 9a 1f 25 82       	sbb    BYTE PTR [bp+si+0x251f],0x82
    822b:	cb                   	retf
    822c:	1f                   	pop    ds
    822d:	29 82 7f 88          	sub    WORD PTR [bp+si-0x7781],ax
    8231:	71 82                	jno    0x81b5
    8233:	62 89 31 82          	bound  cx,DWORD PTR [bx+di-0x7dcf]
    8237:	0b 54 53             	or     dx,WORD PTR [si+0x53]
    823a:	70 61                	jo     0x829d
    823c:	72 73                	jb     0x82b1
    823e:	65 4c                	gs dec sp
    8240:	69 73 74 d5 82       	imul   si,WORD PTR [bp+di+0x74],0x82d5
    8245:	00 00                	add    BYTE PTR [bx+si],al
    8247:	00 00                	add    BYTE PTR [bx+si],al
    8249:	00 00                	add    BYTE PTR [bx+si],al
    824b:	c3                   	ret
    824c:	82 12 00             	adc    BYTE PTR [bp+si],0x0
    824f:	2a 03                	sub    al,BYTE PTR [bp+di]
    8251:	ee                   	out    dx,al
    8252:	82 64 20 08          	and    BYTE PTR [si+0x20],0x8
    8256:	83 9a 1f 55 82       	sbb    WORD PTR [bp+si+0x551f],0xff82
    825b:	cb                   	retf
    825c:	1f                   	pop    ds
    825d:	59                   	pop    cx
    825e:	82 b6 8b 69 82       	xor    BYTE PTR [bp+0x698b],0x82
    8263:	cd 11                	int    0x11
    8265:	51                   	push   cx
    8266:	82 f5 8c             	xor    ch,0x8c
    8269:	99                   	cwd
    826a:	82 48 13 a1          	or     BYTE PTR [bx+si+0x13],0xa1
    826e:	82 28 8d             	sub    BYTE PTR [bx+si],0x8d
    8271:	75 82                	jne    0x81f5
    8273:	6e                   	outs   dx,BYTE PTR ds:[si]
    8274:	8d 79 82             	lea    di,[bx+di-0x7e]
    8277:	87 8d 7d 82          	xchg   WORD PTR [di-0x7d83],cx
    827b:	ce                   	into
    827c:	8d 81 82 71          	lea    ax,[bx+di+0x7182]
    8280:	8e bd 82 35          	mov    ?,WORD PTR [di+0x3582]
    8284:	1c 89                	sbb    al,0x89
    8286:	82 4a 12 8d          	or     BYTE PTR [bp+si+0x12],0x8d
    828a:	82 78 12 91          	cmp    BYTE PTR [bx+si+0x12],0x91
    828e:	82 b2 12 6d 82       	xor    BYTE PTR [bp+si+0x6d12],0x82
    8293:	d4 8f                	aam    0x8f
    8295:	ea 82 1b 8f 9d       	jmp    0x9d8f:0x1b82
    829a:	82 6a 8f a9          	sub    BYTE PTR [bp+si-0x71],0xa9
    829e:	82 13 16             	adc    BYTE PTR [bp+di],0x16
    82a1:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    82a2:	82 e0 16             	and    al,0x16
    82a5:	ad                   	lods   ax,WORD PTR ds:[si]
    82a6:	82 85 8f 95 82       	add    BYTE PTR [di-0x6a71],0x82
    82ab:	78 17                	js     0x82c4
    82ad:	b1 82                	mov    cl,0x82
    82af:	24 19                	and    al,0x19
    82b1:	b5 82                	mov    ch,0x82
    82b3:	39 1a                	cmp    WORD PTR [bp+si],bx
    82b5:	b9 82 ac             	mov    cx,0xac82
    82b8:	1b 65 82             	sbb    sp,WORD PTR [di-0x7e]
    82bb:	ca 8e c1             	retf   0xc18e
    82be:	82 ee 8e             	sub    dh,0x8e
    82c1:	61                   	popa
    82c2:	82 11 54             	adc    BYTE PTR [bx+di],0x54
    82c5:	53                   	push   bx
    82c6:	74 72                	je     0x833a
    82c8:	69 6e 67 53 70       	imul   bp,WORD PTR [bp+0x67],0x7053
    82cd:	61                   	popa
    82ce:	72 73                	jb     0x8343
    82d0:	65 4c                	gs dec sp
    82d2:	69 73 74 07 11       	imul   si,WORD PTR [bp+di+0x74],0x1107
    82d7:	54                   	push   sp
    82d8:	53                   	push   bx
    82d9:	74 72                	je     0x834d
    82db:	69 6e 67 53 70       	imul   bp,WORD PTR [bp+0x67],0x7053
    82e0:	61                   	popa
    82e1:	72 73                	jb     0x8356
    82e3:	65 4c                	gs dec sp
    82e5:	69 73 74 63 82       	imul   si,WORD PTR [bp+di+0x74],0x8263
    82ea:	e1 86                	loope  0x8272
    82ec:	8b 03                	mov    ax,WORD PTR [bp+di]
    82ee:	7b 89                	jnp    0x8279
    82f0:	00 00                	add    BYTE PTR [bx+si],al
    82f2:	05 47 72             	add    ax,0x7247
    82f5:	69 64 73 00 00       	imul   sp,WORD PTR [si+0x73],0x0
    82fa:	c8 0a 00 00          	enter  0xa,0x0
    82fe:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    8301:	c1 e0 02             	shl    ax,0x2
    8304:	50                   	push   ax
    8305:	9a 82 01 39 83       	call   0x8339:0x182
    830a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    830d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    8310:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8313:	26 8b 05             	mov    ax,WORD PTR es:[di]
    8316:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    8319:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    831c:	26 89 05             	mov    WORD PTR es:[di],ax
    831f:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    8323:	76 28                	jbe    0x834d
    8325:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8328:	06                   	push   es
    8329:	57                   	push   di
    832a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    832d:	06                   	push   es
    832e:	57                   	push   di
    832f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    8332:	c1 e0 02             	shl    ax,0x2
    8335:	50                   	push   ax
    8336:	9a c1 1e 4b 83       	call   0x834b:0x1ec1
    833b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    833e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8341:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    8344:	c1 e0 02             	shl    ax,0x2
    8347:	50                   	push   ax
    8348:	9a 9c 01 69 83       	call   0x8369:0x19c
    834d:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    8350:	c1 e0 02             	shl    ax,0x2
    8353:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8356:	03 f8                	add    di,ax
    8358:	06                   	push   es
    8359:	57                   	push   di
    835a:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    835d:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    8360:	c1 e0 02             	shl    ax,0x2
    8363:	50                   	push   ax
    8364:	6a 00                	push   0x0
    8366:	9a e5 1e 94 83       	call   0x8394:0x1ee5
    836b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    836e:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    8371:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8374:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8377:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    837a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    837d:	c9                   	leave
    837e:	c2 0a 00             	ret    0xa
    8381:	c8 0a 00 00          	enter  0xa,0x0
    8385:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    8388:	c1 e0 02             	shl    ax,0x2
    838b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    838e:	ff 76 f6             	push   WORD PTR [bp-0xa]
    8391:	9a 82 01 a9 83       	call   0x83a9:0x182
    8396:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8399:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    839c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    839f:	06                   	push   es
    83a0:	57                   	push   di
    83a1:	ff 76 f6             	push   WORD PTR [bp-0xa]
    83a4:	6a 00                	push   0x0
    83a6:	9a e5 1e d0 83       	call   0x83d0:0x1ee5
    83ab:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    83ae:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    83b1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    83b4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    83b7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    83ba:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    83bd:	c9                   	leave
    83be:	c2 04 00             	ret    0x4
    83c1:	55                   	push   bp
    83c2:	89 e5                	mov    bp,sp
    83c4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    83c8:	74 08                	je     0x83d2
    83ca:	83 ec 08             	sub    sp,0x8
    83cd:	9a e2 1f a7 84       	call   0x84a7:0x1fe2
    83d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    83d5:	31 c0                	xor    ax,ax
    83d7:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    83db:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    83df:	31 c0                	xor    ax,ax
    83e1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    83e5:	26 c7 45 0e ff ff    	mov    WORD PTR es:[di+0xe],0xffff
    83eb:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    83ee:	98                   	cbw
    83ef:	8b f8                	mov    di,ax
    83f1:	8a 85 dc 0b          	mov    al,BYTE PTR [di+0xbdc]
    83f5:	30 e4                	xor    ah,ah
    83f7:	40                   	inc    ax
    83f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    83fb:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    83ff:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    8402:	98                   	cbw
    8403:	8b f8                	mov    di,ax
    8405:	8a 85 dc 0b          	mov    al,BYTE PTR [di+0xbdc]
    8409:	30 e4                	xor    ah,ah
    840b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    840e:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    8412:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    8415:	98                   	cbw
    8416:	8b f8                	mov    di,ax
    8418:	8a 85 de 0b          	mov    al,BYTE PTR [di+0xbde]
    841c:	30 e4                	xor    ah,ah
    841e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8421:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    8425:	26 c7 45 12 ff ff    	mov    WORD PTR es:[di+0x12],0xffff
    842b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    842f:	74 07                	je     0x8438
    8431:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8435:	83 c4 06             	add    sp,0x6
    8438:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    843b:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    843e:	c9                   	leave
    843f:	ca 08 00             	retf   0x8
    8442:	c8 04 00 00          	enter  0x4,0x0
    8446:	31 c0                	xor    ax,ax
    8448:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    844b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    844e:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    8452:	c1 e0 02             	shl    ax,0x2
    8455:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8458:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    845b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    845f:	31 d2                	xor    dx,dx
    8461:	8b c8                	mov    cx,ax
    8463:	8b da                	mov    bx,dx
    8465:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8468:	99                   	cwd
    8469:	3b d3                	cmp    dx,bx
    846b:	7c 06                	jl     0x8473
    846d:	7f 3f                	jg     0x84ae
    846f:	3b c1                	cmp    ax,cx
    8471:	73 3b                	jae    0x84ae
    8473:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8476:	c1 e0 02             	shl    ax,0x2
    8479:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    847c:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8480:	03 f8                	add    di,ax
    8482:	26 8b 05             	mov    ax,WORD PTR es:[di]
    8485:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    8489:	74 1e                	je     0x84a9
    848b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    848e:	c1 e0 02             	shl    ax,0x2
    8491:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8494:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8498:	03 f8                	add    di,ax
    849a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    849e:	26 ff 35             	push   WORD PTR es:[di]
    84a1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    84a4:	9a 9c 01 ce 84       	call   0x84ce:0x19c
    84a9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    84ac:	eb aa                	jmp    0x8458
    84ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84b1:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    84b5:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    84b9:	74 15                	je     0x84d0
    84bb:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    84bf:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    84c3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    84c7:	c1 e0 02             	shl    ax,0x2
    84ca:	50                   	push   ax
    84cb:	9a 9c 01 d9 84       	call   0x84d9:0x19c
    84d0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    84d4:	74 05                	je     0x84db
    84d6:	9a 0f 20 cf 85       	call   0x85cf:0x200f
    84db:	c9                   	leave
    84dc:	ca 06 00             	retf   0x6
    84df:	c8 0c 00 00          	enter  0xc,0x0
    84e3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    84e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84e9:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    84ed:	75 11                	jne    0x8500
    84ef:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    84f3:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    84f7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    84fa:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    84fd:	e9 a5 00             	jmp    0x85a5
    8500:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8503:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    8507:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    850a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    850d:	8b 4e f4             	mov    cx,WORD PTR [bp-0xc]
    8510:	d3 e8                	shr    ax,cl
    8512:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    8515:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    8518:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    851b:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    851f:	72 0a                	jb     0x852b
    8521:	31 c0                	xor    ax,ax
    8523:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8526:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    8529:	eb 40                	jmp    0x856b
    852b:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    852e:	c1 e0 02             	shl    ax,0x2
    8531:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8534:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8538:	03 f8                	add    di,ax
    853a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    853d:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    8541:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8544:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    8547:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    854a:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    854d:	74 1c                	je     0x856b
    854f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8552:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    8556:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    8559:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    855c:	23 46 f4             	and    ax,WORD PTR [bp-0xc]
    855f:	c1 e0 02             	shl    ax,0x2
    8562:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    8565:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    8568:	01 46 f8             	add    WORD PTR [bp-0x8],ax
    856b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    856e:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    8571:	75 0a                	jne    0x857d
    8573:	31 c0                	xor    ax,ax
    8575:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8578:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    857b:	eb 10                	jmp    0x858d
    857d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8580:	26 8b 05             	mov    ax,WORD PTR es:[di]
    8583:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    8587:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    858a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    858d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8590:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8593:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    8597:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    859a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    859d:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    85a1:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    85a5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    85a8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    85ab:	c9                   	leave
    85ac:	ca 06 00             	retf   0x6
    85af:	c8 12 00 00          	enter  0x12,0x0
    85b3:	31 c0                	xor    ax,ax
    85b5:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    85b8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    85bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    85be:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    85c2:	31 d2                	xor    dx,dx
    85c4:	8b c8                	mov    cx,ax
    85c6:	8b da                	mov    bx,dx
    85c8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    85cb:	99                   	cwd
    85cc:	9a 16 17 94 86       	call   0x8694:0x1716
    85d1:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    85d4:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    85d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    85da:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    85de:	72 1e                	jb     0x85fe
    85e0:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    85e4:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    85e8:	81 c7 08 00          	add    di,0x8
    85ec:	06                   	push   es
    85ed:	57                   	push   di
    85ee:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    85f1:	40                   	inc    ax
    85f2:	50                   	push   ax
    85f3:	e8 04 fd             	call   0x82fa
    85f6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    85f9:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    85fc:	eb 11                	jmp    0x860f
    85fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8601:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    8605:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    8609:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    860c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    860f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    8612:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    8615:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8618:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    861c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    8620:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    8623:	c1 e0 02             	shl    ax,0x2
    8626:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8629:	03 f8                	add    di,ax
    862b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    862e:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    8632:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    8635:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    8638:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    863b:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    863e:	75 2b                	jne    0x866b
    8640:	ff 76 ee             	push   WORD PTR [bp-0x12]
    8643:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8646:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    864a:	e8 34 fd             	call   0x8381
    864d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    8650:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    8653:	8b 4e f4             	mov    cx,WORD PTR [bp-0xc]
    8656:	8b 5e f6             	mov    bx,WORD PTR [bp-0xa]
    8659:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    865c:	c1 e0 02             	shl    ax,0x2
    865f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8662:	03 f8                	add    di,ax
    8664:	26 89 0d             	mov    WORD PTR es:[di],cx
    8667:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
    866b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    866e:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    8671:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    8674:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    8677:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    867a:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    867e:	31 d2                	xor    dx,dx
    8680:	8b c8                	mov    cx,ax
    8682:	8b da                	mov    bx,dx
    8684:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8687:	99                   	cwd
    8688:	23 c1                	and    ax,cx
    868a:	23 d3                	and    dx,bx
    868c:	b9 04 00             	mov    cx,0x4
    868f:	31 db                	xor    bx,bx
    8691:	9a 33 16 58 88       	call   0x8858:0x1633
    8696:	01 46 f0             	add    WORD PTR [bp-0x10],ax
    8699:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    869c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    869f:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    86a3:	7e 07                	jle    0x86ac
    86a5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    86a8:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    86ac:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    86af:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    86b2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    86b5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    86b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86bb:	26 c7 45 12 ff ff    	mov    WORD PTR es:[di+0x12],0xffff
    86c1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    86c4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    86c7:	c9                   	leave
    86c8:	ca 06 00             	retf   0x6
    86cb:	55                   	push   bp
    86cc:	89 e5                	mov    bp,sp
    86ce:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    86d1:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    86d4:	75 11                	jne    0x86e7
    86d6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    86d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86dc:	06                   	push   es
    86dd:	57                   	push   di
    86de:	9a df 84 f8 86       	call   0x86f8:0x84df
    86e3:	09 d0                	or     ax,dx
    86e5:	74 32                	je     0x8719
    86e7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    86ea:	ff 76 0a             	push   WORD PTR [bp+0xa]
    86ed:	ff 76 0e             	push   WORD PTR [bp+0xe]
    86f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86f3:	06                   	push   es
    86f4:	57                   	push   di
    86f5:	9a af 85 17 87       	call   0x8717:0x85af
    86fa:	89 c7                	mov    di,ax
    86fc:	8e c2                	mov    es,dx
    86fe:	58                   	pop    ax
    86ff:	5a                   	pop    dx
    8700:	26 89 05             	mov    WORD PTR es:[di],ax
    8703:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    8707:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    870a:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    870d:	75 0a                	jne    0x8719
    870f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8712:	06                   	push   es
    8713:	57                   	push   di
    8714:	9a 1d 88 2a 88       	call   0x882a:0x881d
    8719:	c9                   	leave
    871a:	ca 0a 00             	retf   0xa
    871d:	c8 12 00 00          	enter  0x12,0x0
    8721:	31 c0                	xor    ax,ax
    8723:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8726:	31 c0                	xor    ax,ax
    8728:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    872b:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    872e:	24 fe                	and    al,0xfe
    8730:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    8733:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    8736:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8739:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    873d:	72 03                	jb     0x8742
    873f:	e9 9b 00             	jmp    0x87dd
    8742:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    8746:	74 03                	je     0x874b
    8748:	e9 92 00             	jmp    0x87dd
    874b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    874e:	c1 e0 02             	shl    ax,0x2
    8751:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8755:	03 f8                	add    di,ax
    8757:	26 8b 05             	mov    ax,WORD PTR es:[di]
    875a:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    875e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    8761:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    8764:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    8767:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    876a:	74 6b                	je     0x87d7
    876c:	31 c0                	xor    ax,ax
    876e:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    8771:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    8774:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8777:	26 8b 4d 0c          	mov    cx,WORD PTR es:[di+0xc]
    877b:	d3 e0                	shl    ax,cl
    877d:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    8780:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8783:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    8787:	31 d2                	xor    dx,dx
    8789:	8b c8                	mov    cx,ax
    878b:	8b da                	mov    bx,dx
    878d:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    8790:	99                   	cwd
    8791:	3b d3                	cmp    dx,bx
    8793:	7c 06                	jl     0x879b
    8795:	7f 40                	jg     0x87d7
    8797:	3b c1                	cmp    ax,cx
    8799:	73 3c                	jae    0x87d7
    879b:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    879f:	75 36                	jne    0x87d7
    87a1:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    87a4:	26 8b 05             	mov    ax,WORD PTR es:[di]
    87a7:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    87ab:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    87ae:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    87b1:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    87b4:	0b 46 f8             	or     ax,WORD PTR [bp-0x8]
    87b7:	74 12                	je     0x87cb
    87b9:	ff 76 ee             	push   WORD PTR [bp-0x12]
    87bc:	ff 76 f8             	push   WORD PTR [bp-0x8]
    87bf:	ff 76 f6             	push   WORD PTR [bp-0xa]
    87c2:	ff 76 f2             	push   WORD PTR [bp-0xe]
    87c5:	ff 5e 0a             	call   DWORD PTR [bp+0xa]
    87c8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    87cb:	83 46 fa 04          	add    WORD PTR [bp-0x6],0x4
    87cf:	ff 46 f0             	inc    WORD PTR [bp-0x10]
    87d2:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    87d5:	eb a9                	jmp    0x8780
    87d7:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    87da:	e9 56 ff             	jmp    0x8733
    87dd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    87e0:	c9                   	leave
    87e1:	ca 08 00             	retf   0x8
    87e4:	c8 02 00 00          	enter  0x2,0x0
    87e8:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    87eb:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    87ee:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    87f2:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    87f6:	7e 07                	jle    0x87ff
    87f8:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    87fd:	eb 17                	jmp    0x8816
    87ff:	31 c0                	xor    ax,ax
    8801:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8804:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    8807:	0b 46 0a             	or     ax,WORD PTR [bp+0xa]
    880a:	74 0a                	je     0x8816
    880c:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    880f:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    8812:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    8816:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8819:	c9                   	leave
    881a:	ca 08 00             	retf   0x8
    881d:	c8 04 00 00          	enter  0x4,0x0
    8821:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
    8826:	bf e4 87             	mov    di,0x87e4
    8829:	b8 36 88             	mov    ax,0x8836
    882c:	50                   	push   ax
    882d:	57                   	push   di
    882e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8831:	06                   	push   es
    8832:	57                   	push   di
    8833:	9a 1d 87 66 88       	call   0x8866:0x871d
    8838:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    883b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    883e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8841:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    8845:	c9                   	leave
    8846:	ca 04 00             	retf   0x4
    8849:	55                   	push   bp
    884a:	89 e5                	mov    bp,sp
    884c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    8850:	74 08                	je     0x885a
    8852:	83 ec 08             	sub    sp,0x8
    8855:	9a e2 1f a8 88       	call   0x88a8:0x1fe2
    885a:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    885d:	50                   	push   ax
    885e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8861:	06                   	push   es
    8862:	57                   	push   di
    8863:	9a fd 8a d1 88       	call   0x88d1:0x8afd
    8868:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    886c:	74 07                	je     0x8875
    886e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8872:	83 c4 06             	add    sp,0x6
    8875:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    8878:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    887b:	c9                   	leave
    887c:	ca 08 00             	retf   0x8
    887f:	55                   	push   bp
    8880:	89 e5                	mov    bp,sp
    8882:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8885:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    8889:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    888d:	74 10                	je     0x889f
    888f:	b0 01                	mov    al,0x1
    8891:	50                   	push   ax
    8892:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8896:	06                   	push   es
    8897:	57                   	push   di
    8898:	26 c4 3d             	les    di,DWORD PTR es:[di]
    889b:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    889f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    88a3:	74 05                	je     0x88aa
    88a5:	9a 0f 20 89 89       	call   0x8989:0x200f
    88aa:	c9                   	leave
    88ab:	ca 06 00             	retf   0x6
    88ae:	55                   	push   bp
    88af:	89 e5                	mov    bp,sp
    88b1:	b0 01                	mov    al,0x1
    88b3:	50                   	push   ax
    88b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88b7:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    88bb:	06                   	push   es
    88bc:	57                   	push   di
    88bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    88c0:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    88c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88c7:	26 8a 45 0a          	mov    al,BYTE PTR es:[di+0xa]
    88cb:	50                   	push   ax
    88cc:	06                   	push   es
    88cd:	57                   	push   di
    88ce:	9a fd 8a 27 89       	call   0x8927:0x8afd
    88d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88d6:	31 c0                	xor    ax,ax
    88d8:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    88dc:	c9                   	leave
    88dd:	ca 04 00             	retf   0x4
    88e0:	c8 04 00 00          	enter  0x4,0x0
    88e4:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    88e8:	7c 0c                	jl     0x88f6
    88ea:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    88ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88f0:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    88f4:	7c 02                	jl     0x88f8
    88f6:	eb 66                	jmp    0x895e
    88f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88fb:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    88ff:	48                   	dec    ax
    8900:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8903:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8906:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    8909:	7f 36                	jg     0x8941
    890b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    890e:	eb 03                	jmp    0x8913
    8910:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    8913:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8916:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8919:	40                   	inc    ax
    891a:	50                   	push   ax
    891b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    891e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8922:	06                   	push   es
    8923:	57                   	push   di
    8924:	9a df 84 37 89       	call   0x8937:0x84df
    8929:	52                   	push   dx
    892a:	50                   	push   ax
    892b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    892e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8932:	06                   	push   es
    8933:	57                   	push   di
    8934:	9a cb 86 55 89       	call   0x8955:0x86cb
    8939:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    893c:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    893f:	75 cf                	jne    0x8910
    8941:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8944:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    8948:	6a 00                	push   0x0
    894a:	6a 00                	push   0x0
    894c:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8950:	06                   	push   es
    8951:	57                   	push   di
    8952:	9a cb 86 9e 89       	call   0x899e:0x86cb
    8957:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    895a:	26 ff 4d 08          	dec    WORD PTR es:[di+0x8]
    895e:	c9                   	leave
    895f:	ca 06 00             	retf   0x6
    8962:	c8 00 01 00          	enter  0x100,0x0
    8966:	8d be 00 ff          	lea    di,[bp-0x100]
    896a:	16                   	push   ss
    896b:	57                   	push   di
    896c:	68 0b f0             	push   0xf00b
    896f:	9a 2b 09 82 89       	call   0x8982:0x92b
    8974:	b0 01                	mov    al,0x1
    8976:	50                   	push   ax
    8977:	b8 17 02             	mov    ax,0x217
    897a:	ba 05 8c             	mov    dx,0x8c05
    897d:	52                   	push   dx
    897e:	50                   	push   ax
    897f:	9a e6 28 fe 8e       	call   0x8efe:0x28e6
    8984:	52                   	push   dx
    8985:	50                   	push   ax
    8986:	9a 99 13 7e 8b       	call   0x8b7e:0x1399
    898b:	c9                   	leave
    898c:	ca 04 00             	retf   0x4
    898f:	c8 04 00 00          	enter  0x4,0x0
    8993:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8996:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8999:	06                   	push   es
    899a:	57                   	push   di
    899b:	9a fd 89 b4 89       	call   0x89b4:0x89fd
    89a0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    89a3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    89a6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    89a9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    89ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89af:	06                   	push   es
    89b0:	57                   	push   di
    89b1:	9a fd 89 c0 89       	call   0x89c0:0x89fd
    89b6:	52                   	push   dx
    89b7:	50                   	push   ax
    89b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89bb:	06                   	push   es
    89bc:	57                   	push   di
    89bd:	9a 2d 8b d3 89       	call   0x89d3:0x8b2d
    89c2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    89c5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    89c8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    89cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89ce:	06                   	push   es
    89cf:	57                   	push   di
    89d0:	9a 2d 8b f7 89       	call   0x89f7:0x8b2d
    89d5:	c9                   	leave
    89d6:	ca 08 00             	retf   0x8
    89d9:	55                   	push   bp
    89da:	89 e5                	mov    bp,sp
    89dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89df:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    89e3:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    89e6:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    89ea:	89 46 08             	mov    WORD PTR [bp+0x8],ax
    89ed:	89 ec                	mov    sp,bp
    89ef:	5d                   	pop    bp
    89f0:	81 e5 fe ff          	and    bp,0xfffe
    89f4:	ea 1d 87 21 8a       	jmp    0x8a21:0x871d
    89f9:	c9                   	leave
    89fa:	ca 08 00             	retf   0x8
    89fd:	c8 04 00 00          	enter  0x4,0x0
    8a01:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    8a05:	7d 0b                	jge    0x8a12
    8a07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a0a:	06                   	push   es
    8a0b:	57                   	push   di
    8a0c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8a0f:	26 ff 1d             	call   DWORD PTR es:[di]
    8a12:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8a15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a18:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8a1c:	06                   	push   es
    8a1d:	57                   	push   di
    8a1e:	9a df 84 6e 8a       	call   0x8a6e:0x84df
    8a23:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8a26:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8a29:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8a2c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    8a2f:	c9                   	leave
    8a30:	ca 06 00             	retf   0x6
    8a33:	c8 02 00 00          	enter  0x2,0x0
    8a37:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    8a3b:	7d 0b                	jge    0x8a48
    8a3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a40:	06                   	push   es
    8a41:	57                   	push   di
    8a42:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8a45:	26 ff 1d             	call   DWORD PTR es:[di]
    8a48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a4b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    8a4f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8a52:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8a55:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    8a58:	7e 2b                	jle    0x8a85
    8a5a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8a5d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8a60:	48                   	dec    ax
    8a61:	50                   	push   ax
    8a62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a65:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8a69:	06                   	push   es
    8a6a:	57                   	push   di
    8a6b:	9a df 84 7e 8a       	call   0x8a7e:0x84df
    8a70:	52                   	push   dx
    8a71:	50                   	push   ax
    8a72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a75:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8a79:	06                   	push   es
    8a7a:	57                   	push   di
    8a7b:	9a cb 86 9a 8a       	call   0x8a9a:0x86cb
    8a80:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    8a83:	eb cd                	jmp    0x8a52
    8a85:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8a88:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8a8b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8a8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a91:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8a95:	06                   	push   es
    8a96:	57                   	push   di
    8a97:	9a cb 86 d1 8a       	call   0x8ad1:0x86cb
    8a9c:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    8a9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8aa2:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    8aa6:	7e 07                	jle    0x8aaf
    8aa8:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    8aab:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    8aaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8ab2:	26 ff 45 08          	inc    WORD PTR es:[di+0x8]
    8ab6:	c9                   	leave
    8ab7:	ca 0a 00             	retf   0xa
    8aba:	c8 04 00 00          	enter  0x4,0x0
    8abe:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    8ac1:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    8ac4:	74 33                	je     0x8af9
    8ac6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8ac9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8acc:	06                   	push   es
    8acd:	57                   	push   di
    8ace:	9a fd 89 e4 8a       	call   0x8ae4:0x89fd
    8ad3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8ad6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8ad9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8adc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8adf:	06                   	push   es
    8ae0:	57                   	push   di
    8ae1:	9a e0 88 f7 8a       	call   0x8af7:0x88e0
    8ae6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8ae9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8aec:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8aef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8af2:	06                   	push   es
    8af3:	57                   	push   di
    8af4:	9a 33 8a 15 8b       	call   0x8b15:0x8a33
    8af9:	c9                   	leave
    8afa:	ca 08 00             	retf   0x8
    8afd:	55                   	push   bp
    8afe:	89 e5                	mov    bp,sp
    8b00:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    8b03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b06:	26 88 45 0a          	mov    BYTE PTR es:[di+0xa],al
    8b0a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    8b0d:	50                   	push   ax
    8b0e:	b0 01                	mov    al,0x1
    8b10:	50                   	push   ax
    8b11:	b8 ff 81             	mov    ax,0x81ff
    8b14:	ba 1c 8b             	mov    dx,0x8b1c
    8b17:	52                   	push   dx
    8b18:	50                   	push   ax
    8b19:	9a c1 83 56 8b       	call   0x8b56:0x83c1
    8b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b21:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    8b25:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    8b29:	c9                   	leave
    8b2a:	ca 06 00             	retf   0x6
    8b2d:	55                   	push   bp
    8b2e:	89 e5                	mov    bp,sp
    8b30:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    8b34:	7d 0b                	jge    0x8b41
    8b36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b39:	06                   	push   es
    8b3a:	57                   	push   di
    8b3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8b3e:	26 ff 1d             	call   DWORD PTR es:[di]
    8b41:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8b44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8b47:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8b4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b4d:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8b51:	06                   	push   es
    8b52:	57                   	push   di
    8b53:	9a cb 86 8b 8b       	call   0x8b8b:0x86cb
    8b58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b5b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8b5f:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    8b63:	40                   	inc    ax
    8b64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b67:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    8b6b:	c9                   	leave
    8b6c:	ca 0a 00             	retf   0xa
    8b6f:	55                   	push   bp
    8b70:	89 e5                	mov    bp,sp
    8b72:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    8b76:	74 08                	je     0x8b80
    8b78:	83 ec 08             	sub    sp,0x8
    8b7b:	9a e2 1f eb 8b       	call   0x8beb:0x1fe2
    8b80:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    8b83:	50                   	push   ax
    8b84:	b0 01                	mov    al,0x1
    8b86:	50                   	push   ax
    8b87:	b8 33 82             	mov    ax,0x8233
    8b8a:	ba 92 8b             	mov    dx,0x8b92
    8b8d:	52                   	push   dx
    8b8e:	50                   	push   ax
    8b8f:	9a 49 88 ae 8c       	call   0x8cae:0x8849
    8b94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b97:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    8b9b:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    8b9f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    8ba3:	74 07                	je     0x8bac
    8ba5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8ba9:	83 c4 06             	add    sp,0x6
    8bac:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    8baf:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    8bb2:	c9                   	leave
    8bb3:	ca 08 00             	retf   0x8
    8bb6:	55                   	push   bp
    8bb7:	89 e5                	mov    bp,sp
    8bb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8bbc:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    8bc0:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    8bc4:	74 1c                	je     0x8be2
    8bc6:	06                   	push   es
    8bc7:	57                   	push   di
    8bc8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8bcb:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    8bcf:	b0 01                	mov    al,0x1
    8bd1:	50                   	push   ax
    8bd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8bd5:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8bd9:	06                   	push   es
    8bda:	57                   	push   di
    8bdb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8bde:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    8be2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    8be6:	74 05                	je     0x8bed
    8be8:	9a 0f 20 68 8d       	call   0x8d68:0x200f
    8bed:	c9                   	leave
    8bee:	ca 06 00             	retf   0x6
    8bf1:	c8 06 02 00          	enter  0x206,0x0
    8bf5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8bf8:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    8bfc:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    8c00:	06                   	push   es
    8c01:	57                   	push   di
    8c02:	9a 09 36 19 8c       	call   0x8c19:0x3609
    8c07:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8c0a:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    8c0e:	7e 30                	jle    0x8c40
    8c10:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    8c14:	06                   	push   es
    8c15:	57                   	push   di
    8c16:	9a 09 36 2b 8c       	call   0x8c2b:0x3609
    8c1b:	50                   	push   ax
    8c1c:	8d be fa fd          	lea    di,[bp-0x206]
    8c20:	16                   	push   ss
    8c21:	57                   	push   di
    8c22:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    8c26:	06                   	push   es
    8c27:	57                   	push   di
    8c28:	9a 74 3f 39 8c       	call   0x8c39:0x3f74
    8c2d:	6a 00                	push   0x0
    8c2f:	6a 00                	push   0x0
    8c31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8c34:	06                   	push   es
    8c35:	57                   	push   di
    8c36:	9a 3c 17 77 8c       	call   0x8c77:0x173c
    8c3b:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    8c3e:	eb ca                	jmp    0x8c0a
    8c40:	c9                   	leave
    8c41:	ca 08 00             	retf   0x8
    8c44:	c8 02 00 00          	enter  0x2,0x0
    8c48:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    8c4b:	36 ff 45 fe          	inc    WORD PTR ss:[di-0x2]
    8c4f:	31 c0                	xor    ax,ax
    8c51:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8c54:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8c57:	c9                   	leave
    8c58:	ca 08 00             	retf   0x8
    8c5b:	c8 06 00 00          	enter  0x6,0x0
    8c5f:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    8c62:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    8c66:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    8c69:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    8c6c:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    8c6f:	99                   	cwd
    8c70:	52                   	push   dx
    8c71:	50                   	push   ax
    8c72:	06                   	push   es
    8c73:	57                   	push   di
    8c74:	9a cb 44 8a 8c       	call   0x8c8a:0x44cb
    8c79:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    8c7c:	81 c7 04 00          	add    di,0x4
    8c80:	06                   	push   es
    8c81:	57                   	push   di
    8c82:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    8c85:	06                   	push   es
    8c86:	57                   	push   di
    8c87:	9a 9d 4b d1 8c       	call   0x8cd1:0x4b9d
    8c8c:	31 c0                	xor    ax,ax
    8c8e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8c91:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8c94:	c9                   	leave
    8c95:	ca 08 00             	retf   0x8
    8c98:	c8 08 00 00          	enter  0x8,0x0
    8c9c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8c9f:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    8ca2:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    8ca5:	31 c0                	xor    ax,ax
    8ca7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8caa:	bf 44 8c             	mov    di,0x8c44
    8cad:	b8 be 8c             	mov    ax,0x8cbe
    8cb0:	50                   	push   ax
    8cb1:	57                   	push   di
    8cb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8cb5:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8cb9:	06                   	push   es
    8cba:	57                   	push   di
    8cbb:	9a d9 89 d7 8c       	call   0x8cd7:0x89d9
    8cc0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8cc3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8cc6:	99                   	cwd
    8cc7:	52                   	push   dx
    8cc8:	50                   	push   ax
    8cc9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8ccc:	06                   	push   es
    8ccd:	57                   	push   di
    8cce:	9a cb 44 3c 8e       	call   0x8e3c:0x44cb
    8cd3:	bf 5b 8c             	mov    di,0x8c5b
    8cd6:	b8 e7 8c             	mov    ax,0x8ce7
    8cd9:	50                   	push   ax
    8cda:	57                   	push   di
    8cdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8cde:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8ce2:	06                   	push   es
    8ce3:	57                   	push   di
    8ce4:	9a d9 89 06 8d       	call   0x8d06:0x89d9
    8ce9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8cec:	c9                   	leave
    8ced:	ca 08 00             	retf   0x8
    8cf0:	04 4c                	add    al,0x4c
    8cf2:	69 73 74 55 89       	imul   si,WORD PTR [bp+di+0x74],0x8955
    8cf7:	e5 bf                	in     ax,0xbf
    8cf9:	f0 8c 0e 57 c4       	lock mov WORD PTR ds:0xc457,cs
    8cfe:	7e 06                	jle    0x8d06
    8d00:	06                   	push   es
    8d01:	57                   	push   di
    8d02:	bf f1 8b             	mov    di,0x8bf1
    8d05:	b8 13 8d             	mov    ax,0x8d13
    8d08:	50                   	push   ax
    8d09:	57                   	push   di
    8d0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8d0d:	06                   	push   es
    8d0e:	57                   	push   di
    8d0f:	bf 98 8c             	mov    di,0x8c98
    8d12:	b8 3b 8d             	mov    ax,0x8d3b
    8d15:	50                   	push   ax
    8d16:	57                   	push   di
    8d17:	6a 01                	push   0x1
    8d19:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8d1c:	06                   	push   es
    8d1d:	57                   	push   di
    8d1e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8d21:	26 ff 1d             	call   DWORD PTR es:[di]
    8d24:	c9                   	leave
    8d25:	ca 08 00             	retf   0x8
    8d28:	c8 04 00 00          	enter  0x4,0x0
    8d2c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8d32:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8d36:	06                   	push   es
    8d37:	57                   	push   di
    8d38:	9a fd 89 9a 8d       	call   0x8d9a:0x89fd
    8d3d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8d40:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8d43:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8d46:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    8d49:	75 09                	jne    0x8d54
    8d4b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    8d4e:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    8d52:	eb 16                	jmp    0x8d6a
    8d54:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    8d57:	81 c7 04 00          	add    di,0x4
    8d5b:	06                   	push   es
    8d5c:	57                   	push   di
    8d5d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    8d60:	06                   	push   es
    8d61:	57                   	push   di
    8d62:	68 ff 00             	push   0xff
    8d65:	9a e7 17 15 8f       	call   0x8f15:0x17e7
    8d6a:	c9                   	leave
    8d6b:	ca 06 00             	retf   0x6
    8d6e:	c8 02 00 00          	enter  0x2,0x0
    8d72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8d75:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8d79:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    8d7d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8d80:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8d83:	c9                   	leave
    8d84:	ca 04 00             	retf   0x4
    8d87:	c8 08 00 00          	enter  0x8,0x0
    8d8b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8d8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8d91:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8d95:	06                   	push   es
    8d96:	57                   	push   di
    8d97:	9a fd 89 e1 8d       	call   0x8de1:0x89fd
    8d9c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8d9f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    8da2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    8da5:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    8da8:	75 0a                	jne    0x8db4
    8daa:	31 c0                	xor    ax,ax
    8dac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8daf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8db2:	eb 10                	jmp    0x8dc4
    8db4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8db7:	26 8b 05             	mov    ax,WORD PTR es:[di]
    8dba:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    8dbe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8dc1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8dc4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8dc7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    8dca:	c9                   	leave
    8dcb:	ca 06 00             	retf   0x6
    8dce:	c8 08 00 00          	enter  0x8,0x0
    8dd2:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8dd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8dd8:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8ddc:	06                   	push   es
    8ddd:	57                   	push   di
    8dde:	9a fd 89 27 8e       	call   0x8e27:0x89fd
    8de3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8de6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8de9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8dec:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    8def:	75 0a                	jne    0x8dfb
    8df1:	31 c0                	xor    ax,ax
    8df3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8df6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    8df9:	eb 10                	jmp    0x8e0b
    8dfb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    8dfe:	26 8b 05             	mov    ax,WORD PTR es:[di]
    8e01:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    8e05:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8e08:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    8e0b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8e0e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    8e12:	75 17                	jne    0x8e2b
    8e14:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8e17:	6a 00                	push   0x0
    8e19:	6a 00                	push   0x0
    8e1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8e1e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8e22:	06                   	push   es
    8e23:	57                   	push   di
    8e24:	9a 2d 8b 4c 8e       	call   0x8e4c:0x8b2d
    8e29:	eb 23                	jmp    0x8e4e
    8e2b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8e2e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8e31:	06                   	push   es
    8e32:	57                   	push   di
    8e33:	ff 76 fa             	push   WORD PTR [bp-0x6]
    8e36:	ff 76 f8             	push   WORD PTR [bp-0x8]
    8e39:	9a 9e 1c 5f 8e       	call   0x8e5f:0x1c9e
    8e3e:	52                   	push   dx
    8e3f:	50                   	push   ax
    8e40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8e43:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8e47:	06                   	push   es
    8e48:	57                   	push   di
    8e49:	9a 2d 8b 84 8e       	call   0x8e84:0x8b2d
    8e4e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8e51:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    8e54:	74 0b                	je     0x8e61
    8e56:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8e59:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8e5c:	9a e9 1c 47 8f       	call   0x8f47:0x1ce9
    8e61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8e64:	06                   	push   es
    8e65:	57                   	push   di
    8e66:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8e69:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    8e6d:	c9                   	leave
    8e6e:	ca 0a 00             	retf   0xa
    8e71:	c8 04 00 00          	enter  0x4,0x0
    8e75:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8e78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8e7b:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8e7f:	06                   	push   es
    8e80:	57                   	push   di
    8e81:	9a fd 89 07 8f       	call   0x8f07:0x89fd
    8e86:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8e89:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8e8c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8e8f:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    8e92:	74 12                	je     0x8ea6
    8e94:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8e97:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    8e9a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    8e9d:	26 89 05             	mov    WORD PTR es:[di],ax
    8ea0:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    8ea4:	eb 14                	jmp    0x8eba
    8ea6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8ea9:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    8eac:	74 0c                	je     0x8eba
    8eae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8eb1:	06                   	push   es
    8eb2:	57                   	push   di
    8eb3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8eb6:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    8eba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8ebd:	06                   	push   es
    8ebe:	57                   	push   di
    8ebf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8ec2:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    8ec6:	c9                   	leave
    8ec7:	ca 0a 00             	retf   0xa
    8eca:	55                   	push   bp
    8ecb:	89 e5                	mov    bp,sp
    8ecd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8ed0:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    8ed4:	09 c0                	or     ax,ax
    8ed6:	74 12                	je     0x8eea
    8ed8:	ff 76 08             	push   WORD PTR [bp+0x8]
    8edb:	ff 76 06             	push   WORD PTR [bp+0x6]
    8ede:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    8ee2:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    8ee6:	26 ff 5d 0a          	call   DWORD PTR es:[di+0xa]
    8eea:	c9                   	leave
    8eeb:	ca 04 00             	retf   0x4
    8eee:	c8 00 01 00          	enter  0x100,0x0
    8ef2:	8d be 00 ff          	lea    di,[bp-0x100]
    8ef6:	16                   	push   ss
    8ef7:	57                   	push   di
    8ef8:	68 47 f0             	push   0xf047
    8efb:	9a 2b 09 0e 8f       	call   0x8f0e:0x92b
    8f00:	b0 01                	mov    al,0x1
    8f02:	50                   	push   ax
    8f03:	b8 c8 81             	mov    ax,0x81c8
    8f06:	ba 2e 8f             	mov    dx,0x8f2e
    8f09:	52                   	push   dx
    8f0a:	50                   	push   ax
    8f0b:	9a e6 28 23 97       	call   0x9723:0x28e6
    8f10:	52                   	push   dx
    8f11:	50                   	push   ax
    8f12:	9a 99 13 1e 90       	call   0x901e:0x1399
    8f17:	c9                   	leave
    8f18:	ca 04 00             	retf   0x4
    8f1b:	c8 04 00 00          	enter  0x4,0x0
    8f1f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8f22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8f25:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8f29:	06                   	push   es
    8f2a:	57                   	push   di
    8f2b:	9a fd 89 58 8f       	call   0x8f58:0x89fd
    8f30:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8f33:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    8f36:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    8f39:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    8f3c:	74 0b                	je     0x8f49
    8f3e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8f41:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8f44:	9a e9 1c 97 8f       	call   0x8f97:0x1ce9
    8f49:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8f4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8f4f:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8f53:	06                   	push   es
    8f54:	57                   	push   di
    8f55:	9a e0 88 7f 8f       	call   0x8f7f:0x88e0
    8f5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8f5d:	06                   	push   es
    8f5e:	57                   	push   di
    8f5f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8f62:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    8f66:	c9                   	leave
    8f67:	ca 06 00             	retf   0x6
    8f6a:	55                   	push   bp
    8f6b:	89 e5                	mov    bp,sp
    8f6d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8f70:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8f73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8f76:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8f7a:	06                   	push   es
    8f7b:	57                   	push   di
    8f7c:	9a 8f 89 a7 8f       	call   0x8fa7:0x898f
    8f81:	c9                   	leave
    8f82:	ca 08 00             	retf   0x8
    8f85:	55                   	push   bp
    8f86:	89 e5                	mov    bp,sp
    8f88:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8f8b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8f8e:	06                   	push   es
    8f8f:	57                   	push   di
    8f90:	6a 00                	push   0x0
    8f92:	6a 00                	push   0x0
    8f94:	9a 9e 1c c6 8f       	call   0x8fc6:0x1c9e
    8f99:	52                   	push   dx
    8f9a:	50                   	push   ax
    8f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8f9e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8fa2:	06                   	push   es
    8fa3:	57                   	push   di
    8fa4:	9a 33 8a dc 8f       	call   0x8fdc:0x8a33
    8fa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8fac:	06                   	push   es
    8fad:	57                   	push   di
    8fae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8fb1:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    8fb5:	c9                   	leave
    8fb6:	ca 0a 00             	retf   0xa
    8fb9:	c8 02 00 00          	enter  0x2,0x0
    8fbd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8fc0:	ff 76 08             	push   WORD PTR [bp+0x8]
    8fc3:	9a e9 1c 70 90       	call   0x9070:0x1ce9
    8fc8:	31 c0                	xor    ax,ax
    8fca:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8fcd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8fd0:	c9                   	leave
    8fd1:	ca 08 00             	retf   0x8
    8fd4:	c8 02 00 00          	enter  0x2,0x0
    8fd8:	bf b9 8f             	mov    di,0x8fb9
    8fdb:	b8 ec 8f             	mov    ax,0x8fec
    8fde:	50                   	push   ax
    8fdf:	57                   	push   di
    8fe0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8fe3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8fe7:	06                   	push   es
    8fe8:	57                   	push   di
    8fe9:	9a d9 89 fd 8f       	call   0x8ffd:0x89d9
    8fee:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8ff4:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    8ff8:	06                   	push   es
    8ff9:	57                   	push   di
    8ffa:	9a ae 88 60 90       	call   0x9060:0x88ae
    8fff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9002:	06                   	push   es
    9003:	57                   	push   di
    9004:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9007:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    900b:	c9                   	leave
    900c:	ca 04 00             	retf   0x4
    900f:	55                   	push   bp
    9010:	89 e5                	mov    bp,sp
    9012:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    9016:	74 08                	je     0x9020
    9018:	83 ec 08             	sub    sp,0x8
    901b:	9a e2 1f 2b 90       	call   0x902b:0x1fe2
    9020:	31 c0                	xor    ax,ax
    9022:	50                   	push   ax
    9023:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9026:	06                   	push   es
    9027:	57                   	push   di
    9028:	9a 50 1f 77 90       	call   0x9077:0x1f50
    902d:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    9030:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    9033:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9036:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    903a:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    903e:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    9041:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    9045:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    9049:	74 07                	je     0x9052
    904b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    904f:	83 c4 06             	add    sp,0x6
    9052:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    9055:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    9058:	c9                   	leave
    9059:	ca 0e 00             	retf   0xe
    905c:	00 00                	add    BYTE PTR [bx+si],al
    905e:	36 91                	ss xchg cx,ax
    9060:	74 92                	je     0x8ff4
    9062:	c8 06 01 00          	enter  0x106,0x0
    9066:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9069:	ff 76 0a             	push   WORD PTR [bp+0xa]
    906c:	bf 2a 03             	mov    di,0x32a
    906f:	b8 88 90             	mov    ax,0x9088
    9072:	50                   	push   ax
    9073:	57                   	push   di
    9074:	9a 55 22 29 93       	call   0x9329:0x2255
    9079:	08 c0                	or     al,al
    907b:	75 03                	jne    0x9080
    907d:	e9 c3 00             	jmp    0x9143
    9080:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9083:	06                   	push   es
    9084:	57                   	push   di
    9085:	9a c5 13 3e 91       	call   0x913e:0x13c5
    908a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    908d:	06                   	push   es
    908e:	57                   	push   di
    908f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9092:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    9096:	48                   	dec    ax
    9097:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    909a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    909d:	06                   	push   es
    909e:	57                   	push   di
    909f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    90a2:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    90a6:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    90a9:	7f 10                	jg     0x90bb
    90ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    90ae:	06                   	push   es
    90af:	57                   	push   di
    90b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    90b3:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    90b7:	48                   	dec    ax
    90b8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    90bb:	b8 5c 90             	mov    ax,0x905c
    90be:	0e                   	push   cs
    90bf:	50                   	push   ax
    90c0:	55                   	push   bp
    90c1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    90c5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    90c9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    90cc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    90cf:	31 c0                	xor    ax,ax
    90d1:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    90d4:	7f 54                	jg     0x912a
    90d6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    90d9:	eb 03                	jmp    0x90de
    90db:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    90de:	ff 76 fe             	push   WORD PTR [bp-0x2]
    90e1:	8d be fa fe          	lea    di,[bp-0x106]
    90e5:	16                   	push   ss
    90e6:	57                   	push   di
    90e7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    90ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    90ed:	06                   	push   es
    90ee:	57                   	push   di
    90ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    90f2:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    90f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    90f9:	06                   	push   es
    90fa:	57                   	push   di
    90fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    90fe:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    9102:	ff 76 fe             	push   WORD PTR [bp-0x2]
    9105:	ff 76 fe             	push   WORD PTR [bp-0x2]
    9108:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    910b:	06                   	push   es
    910c:	57                   	push   di
    910d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9110:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    9114:	52                   	push   dx
    9115:	50                   	push   ax
    9116:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9119:	06                   	push   es
    911a:	57                   	push   di
    911b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    911e:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    9122:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    9125:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    9128:	75 b1                	jne    0x90db
    912a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    912e:	83 c4 06             	add    sp,0x6
    9131:	b8 41 91             	mov    ax,0x9141
    9134:	0e                   	push   cs
    9135:	50                   	push   ax
    9136:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9139:	06                   	push   es
    913a:	57                   	push   di
    913b:	9a 35 14 51 91       	call   0x9151:0x1435
    9140:	cb                   	retf
    9141:	eb 10                	jmp    0x9153
    9143:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9146:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9149:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    914c:	06                   	push   es
    914d:	57                   	push   di
    914e:	9a 48 13 ff ff       	call   0xffff:0x1348
    9153:	c9                   	leave
    9154:	ca 08 00             	retf   0x8
    9157:	55                   	push   bp
    9158:	89 e5                	mov    bp,sp
    915a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    915d:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    9162:	75 12                	jne    0x9176
    9164:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    9167:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    916c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    916f:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    9174:	eb 3c                	jmp    0x91b2
    9176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9179:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    917e:	7e 19                	jle    0x9199
    9180:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    9183:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    9186:	26 89 05             	mov    WORD PTR es:[di],ax
    9189:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    918c:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    9190:	48                   	dec    ax
    9191:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    9194:	26 89 05             	mov    WORD PTR es:[di],ax
    9197:	eb 19                	jmp    0x91b2
    9199:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    919c:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    91a0:	f7 d8                	neg    ax
    91a2:	48                   	dec    ax
    91a3:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    91a6:	26 89 05             	mov    WORD PTR es:[di],ax
    91a9:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    91ac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    91af:	26 89 05             	mov    WORD PTR es:[di],ax
    91b2:	c9                   	leave
    91b3:	ca 0e 00             	retf   0xe
    91b6:	c8 06 01 00          	enter  0x106,0x0
    91ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    91bd:	06                   	push   es
    91be:	57                   	push   di
    91bf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    91c2:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    91c6:	48                   	dec    ax
    91c7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    91ca:	31 c0                	xor    ax,ax
    91cc:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    91cf:	7f 4b                	jg     0x921c
    91d1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    91d4:	eb 03                	jmp    0x91d9
    91d6:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    91d9:	8d be fa fe          	lea    di,[bp-0x106]
    91dd:	16                   	push   ss
    91de:	57                   	push   di
    91df:	ff 76 fc             	push   WORD PTR [bp-0x4]
    91e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    91e5:	06                   	push   es
    91e6:	57                   	push   di
    91e7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    91ea:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    91ee:	83 c4 04             	add    sp,0x4
    91f1:	80 be fa fe 00       	cmp    BYTE PTR [bp-0x106],0x0
    91f6:	75 1c                	jne    0x9214
    91f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    91fb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    91fe:	06                   	push   es
    91ff:	57                   	push   di
    9200:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9203:	06                   	push   es
    9204:	57                   	push   di
    9205:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9208:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    920c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    920f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    9212:	eb 0d                	jmp    0x9221
    9214:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    9217:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    921a:	75 ba                	jne    0x91d6
    921c:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    9221:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    9224:	c9                   	leave
    9225:	ca 08 00             	retf   0x8
    9228:	00 c8                	add    al,cl
    922a:	02 00                	add    al,BYTE PTR [bx+si]
    922c:	00 ff                	add    bh,bh
    922e:	76 0c                	jbe    0x923c
    9230:	bf 28 92             	mov    di,0x9228
    9233:	0e                   	push   cs
    9234:	57                   	push   di
    9235:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    9238:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    923c:	06                   	push   es
    923d:	57                   	push   di
    923e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9241:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    9245:	31 c0                	xor    ax,ax
    9247:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    924a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    924d:	c9                   	leave
    924e:	ca 08 00             	retf   0x8
    9251:	00 c8                	add    al,cl
    9253:	06                   	push   es
    9254:	00 00                	add    BYTE PTR [bx+si],al
    9256:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9259:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    925e:	7e 3c                	jle    0x929c
    9260:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    9264:	48                   	dec    ax
    9265:	50                   	push   ax
    9266:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    926a:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    926f:	06                   	push   es
    9270:	57                   	push   di
    9271:	9a fd 89 88 92       	call   0x9288:0x89fd
    9276:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9279:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    927c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    927f:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    9282:	74 16                	je     0x929a
    9284:	bf 29 92             	mov    di,0x9229
    9287:	b8 98 92             	mov    ax,0x9298
    928a:	50                   	push   ax
    928b:	57                   	push   di
    928c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    928f:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    9293:	06                   	push   es
    9294:	57                   	push   di
    9295:	9a d9 89 f3 92       	call   0x92f3:0x89d9
    929a:	eb 3a                	jmp    0x92d6
    929c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    929f:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    92a4:	7d 30                	jge    0x92d6
    92a6:	06                   	push   es
    92a7:	57                   	push   di
    92a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    92ab:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    92af:	48                   	dec    ax
    92b0:	09 c0                	or     ax,ax
    92b2:	7c 22                	jl     0x92d6
    92b4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    92b7:	eb 03                	jmp    0x92bc
    92b9:	ff 4e fa             	dec    WORD PTR [bp-0x6]
    92bc:	ff 76 fa             	push   WORD PTR [bp-0x6]
    92bf:	bf 51 92             	mov    di,0x9251
    92c2:	0e                   	push   cs
    92c3:	57                   	push   di
    92c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    92c7:	06                   	push   es
    92c8:	57                   	push   di
    92c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    92cc:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    92d0:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    92d4:	75 e3                	jne    0x92b9
    92d6:	c9                   	leave
    92d7:	ca 04 00             	retf   0x4
    92da:	c8 04 01 00          	enter  0x104,0x0
    92de:	ff 76 0a             	push   WORD PTR [bp+0xa]
    92e1:	8d 7e fe             	lea    di,[bp-0x2]
    92e4:	16                   	push   ss
    92e5:	57                   	push   di
    92e6:	8d 7e fc             	lea    di,[bp-0x4]
    92e9:	16                   	push   ss
    92ea:	57                   	push   di
    92eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    92ee:	06                   	push   es
    92ef:	57                   	push   di
    92f0:	9a 57 91 1c 93       	call   0x931c:0x9157
    92f5:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    92f9:	7d 09                	jge    0x9304
    92fb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    92fe:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    9302:	eb 27                	jmp    0x932b
    9304:	8d be fc fe          	lea    di,[bp-0x104]
    9308:	16                   	push   ss
    9309:	57                   	push   di
    930a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    930d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    9310:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9313:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    9317:	06                   	push   es
    9318:	57                   	push   di
    9319:	9a 68 9a 8b 93       	call   0x938b:0x9a68
    931e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    9321:	06                   	push   es
    9322:	57                   	push   di
    9323:	68 ff 00             	push   0xff
    9326:	9a e7 17 5a 94       	call   0x945a:0x17e7
    932b:	c9                   	leave
    932c:	ca 06 00             	retf   0x6
    932f:	c8 02 00 00          	enter  0x2,0x0
    9333:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9336:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    933b:	75 07                	jne    0x9344
    933d:	31 c0                	xor    ax,ax
    933f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    9342:	eb 27                	jmp    0x936b
    9344:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9347:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    934c:	7e 0e                	jle    0x935c
    934e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    9352:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    9357:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    935a:	eb 0f                	jmp    0x936b
    935c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    935f:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    9363:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    9368:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    936b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    936e:	c9                   	leave
    936f:	ca 04 00             	retf   0x4
    9372:	c8 08 00 00          	enter  0x8,0x0
    9376:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9379:	8d 7e fa             	lea    di,[bp-0x6]
    937c:	16                   	push   ss
    937d:	57                   	push   di
    937e:	8d 7e f8             	lea    di,[bp-0x8]
    9381:	16                   	push   ss
    9382:	57                   	push   di
    9383:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9386:	06                   	push   es
    9387:	57                   	push   di
    9388:	9a 57 91 af 93       	call   0x93af:0x9157
    938d:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    9391:	7d 0a                	jge    0x939d
    9393:	31 c0                	xor    ax,ax
    9395:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9398:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    939b:	eb 1a                	jmp    0x93b7
    939d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    93a0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    93a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    93a6:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    93aa:	06                   	push   es
    93ab:	57                   	push   di
    93ac:	9a bb 9a da 93       	call   0x93da:0x9abb
    93b1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    93b4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    93b7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    93ba:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    93bd:	c9                   	leave
    93be:	ca 06 00             	retf   0x6
    93c1:	c8 04 00 00          	enter  0x4,0x0
    93c5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    93c8:	8d 7e fe             	lea    di,[bp-0x2]
    93cb:	16                   	push   ss
    93cc:	57                   	push   di
    93cd:	8d 7e fc             	lea    di,[bp-0x4]
    93d0:	16                   	push   ss
    93d1:	57                   	push   di
    93d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    93d5:	06                   	push   es
    93d6:	57                   	push   di
    93d7:	9a 57 91 f3 93       	call   0x93f3:0x9157
    93dc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    93df:	ff 76 fc             	push   WORD PTR [bp-0x4]
    93e2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    93e5:	06                   	push   es
    93e6:	57                   	push   di
    93e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    93ea:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    93ee:	06                   	push   es
    93ef:	57                   	push   di
    93f0:	9a 08 9b 12 94       	call   0x9412:0x9b08
    93f5:	c9                   	leave
    93f6:	ca 0a 00             	retf   0xa
    93f9:	c8 04 00 00          	enter  0x4,0x0
    93fd:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9400:	8d 7e fe             	lea    di,[bp-0x2]
    9403:	16                   	push   ss
    9404:	57                   	push   di
    9405:	8d 7e fc             	lea    di,[bp-0x4]
    9408:	16                   	push   ss
    9409:	57                   	push   di
    940a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    940d:	06                   	push   es
    940e:	57                   	push   di
    940f:	9a 57 91 2c 94       	call   0x942c:0x9157
    9414:	ff 76 fe             	push   WORD PTR [bp-0x2]
    9417:	ff 76 fc             	push   WORD PTR [bp-0x4]
    941a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    941d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9420:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9423:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    9427:	06                   	push   es
    9428:	57                   	push   di
    9429:	9a 5f 9b 45 94       	call   0x9445:0x9b5f
    942e:	c9                   	leave
    942f:	ca 0a 00             	retf   0xa
    9432:	55                   	push   bp
    9433:	89 e5                	mov    bp,sp
    9435:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    9438:	50                   	push   ax
    9439:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    943c:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    9440:	06                   	push   es
    9441:	57                   	push   di
    9442:	9a ae 98 6d 94       	call   0x946d:0x98ae
    9447:	c9                   	leave
    9448:	ca 06 00             	retf   0x6
    944b:	55                   	push   bp
    944c:	89 e5                	mov    bp,sp
    944e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    9452:	74 08                	je     0x945c
    9454:	83 ec 08             	sub    sp,0x8
    9457:	9a e2 1f 9c 94       	call   0x949c:0x1fe2
    945c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    945f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9462:	31 c0                	xor    ax,ax
    9464:	50                   	push   ax
    9465:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9468:	06                   	push   es
    9469:	57                   	push   di
    946a:	9a 71 1e 77 94       	call   0x9477:0x1e71
    946f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9472:	06                   	push   es
    9473:	57                   	push   di
    9474:	9a d9 97 c1 94       	call   0x94c1:0x97d9
    9479:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    947d:	74 07                	je     0x9486
    947f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    9483:	83 c4 06             	add    sp,0x6
    9486:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    9489:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    948c:	c9                   	leave
    948d:	ca 0a 00             	retf   0xa
    9490:	c8 02 00 00          	enter  0x2,0x0
    9494:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    9497:	06                   	push   es
    9498:	57                   	push   di
    9499:	9a 7f 1f e1 94       	call   0x94e1:0x1f7f
    949e:	31 c0                	xor    ax,ax
    94a0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    94a3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    94a6:	c9                   	leave
    94a7:	ca 08 00             	retf   0x8
    94aa:	c8 04 00 00          	enter  0x4,0x0
    94ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    94b1:	26 8b 85 85 01       	mov    ax,WORD PTR es:[di+0x185]
    94b6:	26 0b 85 87 01       	or     ax,WORD PTR es:[di+0x187]
    94bb:	74 26                	je     0x94e3
    94bd:	bf 90 94             	mov    di,0x9490
    94c0:	b8 d2 94             	mov    ax,0x94d2
    94c3:	50                   	push   ax
    94c4:	57                   	push   di
    94c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    94c8:	26 c4 bd 85 01       	les    di,DWORD PTR es:[di+0x185]
    94cd:	06                   	push   es
    94ce:	57                   	push   di
    94cf:	9a d9 89 f6 94       	call   0x94f6:0x89d9
    94d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    94d7:	26 c4 bd 85 01       	les    di,DWORD PTR es:[di+0x185]
    94dc:	06                   	push   es
    94dd:	57                   	push   di
    94de:	9a 7f 1f 16 95       	call   0x9516:0x1f7f
    94e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    94e6:	26 8b 85 89 01       	mov    ax,WORD PTR es:[di+0x189]
    94eb:	26 0b 85 8b 01       	or     ax,WORD PTR es:[di+0x18b]
    94f0:	74 26                	je     0x9518
    94f2:	bf 90 94             	mov    di,0x9490
    94f5:	b8 07 95             	mov    ax,0x9507
    94f8:	50                   	push   ax
    94f9:	57                   	push   di
    94fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    94fd:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    9502:	06                   	push   es
    9503:	57                   	push   di
    9504:	9a d9 89 2b 95       	call   0x952b:0x89d9
    9509:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    950c:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    9511:	06                   	push   es
    9512:	57                   	push   di
    9513:	9a 7f 1f 4b 95       	call   0x954b:0x1f7f
    9518:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    951b:	26 8b 85 81 01       	mov    ax,WORD PTR es:[di+0x181]
    9520:	26 0b 85 83 01       	or     ax,WORD PTR es:[di+0x183]
    9525:	74 26                	je     0x954d
    9527:	bf 90 94             	mov    di,0x9490
    952a:	b8 3c 95             	mov    ax,0x953c
    952d:	50                   	push   ax
    952e:	57                   	push   di
    952f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9532:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    9537:	06                   	push   es
    9538:	57                   	push   di
    9539:	9a d9 89 58 95       	call   0x9558:0x89d9
    953e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9541:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    9546:	06                   	push   es
    9547:	57                   	push   di
    9548:	9a 7f 1f 63 95       	call   0x9563:0x1f7f
    954d:	31 c0                	xor    ax,ax
    954f:	50                   	push   ax
    9550:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9553:	06                   	push   es
    9554:	57                   	push   di
    9555:	9a a0 1f 8e 95       	call   0x958e:0x1fa0
    955a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    955e:	74 05                	je     0x9565
    9560:	9a 0f 20 2a 96       	call   0x962a:0x200f
    9565:	c9                   	leave
    9566:	ca 06 00             	retf   0x6
    9569:	55                   	push   bp
    956a:	89 e5                	mov    bp,sp
    956c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    956f:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    9573:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    9577:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    957a:	06                   	push   es
    957b:	57                   	push   di
    957c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    957f:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    9583:	c9                   	leave
    9584:	ca 08 00             	retf   0x8
    9587:	55                   	push   bp
    9588:	89 e5                	mov    bp,sp
    958a:	bf 69 95             	mov    di,0x9569
    958d:	b8 9f 95             	mov    ax,0x959f
    9590:	50                   	push   ax
    9591:	57                   	push   di
    9592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9595:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    959a:	06                   	push   es
    959b:	57                   	push   di
    959c:	9a d9 89 c1 95       	call   0x95c1:0x89d9
    95a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    95a4:	06                   	push   es
    95a5:	57                   	push   di
    95a6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    95a9:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    95ad:	ff 76 10             	push   WORD PTR [bp+0x10]
    95b0:	ff 76 0e             	push   WORD PTR [bp+0xe]
    95b3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    95b6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    95b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    95bc:	06                   	push   es
    95bd:	57                   	push   di
    95be:	9a ad 7f dd 95       	call   0x95dd:0x7fad
    95c3:	c9                   	leave
    95c4:	ca 0c 00             	retf   0xc
    95c7:	55                   	push   bp
    95c8:	89 e5                	mov    bp,sp
    95ca:	ff 76 0e             	push   WORD PTR [bp+0xe]
    95cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    95d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    95d3:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    95d8:	06                   	push   es
    95d9:	57                   	push   di
    95da:	9a ba 8a ff 95       	call   0x95ff:0x8aba
    95df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    95e2:	06                   	push   es
    95e3:	57                   	push   di
    95e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    95e7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    95eb:	ff 76 10             	push   WORD PTR [bp+0x10]
    95ee:	ff 76 0e             	push   WORD PTR [bp+0xe]
    95f1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    95f4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    95f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    95fa:	06                   	push   es
    95fb:	57                   	push   di
    95fc:	9a 6d 80 1d 96       	call   0x961d:0x806d
    9601:	c9                   	leave
    9602:	ca 0c 00             	retf   0xc
    9605:	c8 00 01 00          	enter  0x100,0x0
    9609:	8d be 00 ff          	lea    di,[bp-0x100]
    960d:	16                   	push   ss
    960e:	57                   	push   di
    960f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9612:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9615:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9618:	06                   	push   es
    9619:	57                   	push   di
    961a:	9a 68 9a 6c 96       	call   0x966c:0x9a68
    961f:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    9622:	06                   	push   es
    9623:	57                   	push   di
    9624:	68 ff 00             	push   0xff
    9627:	9a e7 17 a8 96       	call   0x96a8:0x17e7
    962c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    962f:	26 8b 85 5b 01       	mov    ax,WORD PTR es:[di+0x15b]
    9634:	09 c0                	or     ax,ax
    9636:	74 2c                	je     0x9664
    9638:	ff 76 08             	push   WORD PTR [bp+0x8]
    963b:	ff 76 06             	push   WORD PTR [bp+0x6]
    963e:	ff 76 10             	push   WORD PTR [bp+0x10]
    9641:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9644:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9647:	ff 76 0a             	push   WORD PTR [bp+0xa]
    964a:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    964d:	06                   	push   es
    964e:	57                   	push   di
    964f:	68 ff 00             	push   0xff
    9652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9655:	26 ff b5 5f 01       	push   WORD PTR es:[di+0x15f]
    965a:	26 ff b5 5d 01       	push   WORD PTR es:[di+0x15d]
    965f:	26 ff 9d 59 01       	call   DWORD PTR es:[di+0x159]
    9664:	c9                   	leave
    9665:	ca 0c 00             	retf   0xc
    9668:	00 00                	add    BYTE PTR [bx+si],al
    966a:	cd 96                	int    0x96
    966c:	7a 96                	jp     0x9604
    966e:	c8 00 01 00          	enter  0x100,0x0
    9672:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9675:	06                   	push   es
    9676:	57                   	push   di
    9677:	9a bb 97 a3 96       	call   0x96a3:0x97bb
    967c:	b8 68 96             	mov    ax,0x9668
    967f:	0e                   	push   cs
    9680:	50                   	push   ax
    9681:	55                   	push   bp
    9682:	ff 36 58 18          	push   WORD PTR ds:0x1858
    9686:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    968a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    968d:	06                   	push   es
    968e:	57                   	push   di
    968f:	8d be 00 ff          	lea    di,[bp-0x100]
    9693:	16                   	push   ss
    9694:	57                   	push   di
    9695:	ff 76 12             	push   WORD PTR [bp+0x12]
    9698:	ff 76 0e             	push   WORD PTR [bp+0xe]
    969b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    969e:	06                   	push   es
    969f:	57                   	push   di
    96a0:	9a 68 9a bf 96       	call   0x96bf:0x9a68
    96a5:	9a be 18 b5 9a       	call   0x9ab5:0x18be
    96aa:	74 15                	je     0x96c1
    96ac:	ff 76 12             	push   WORD PTR [bp+0x12]
    96af:	ff 76 0e             	push   WORD PTR [bp+0xe]
    96b2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    96b5:	06                   	push   es
    96b6:	57                   	push   di
    96b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    96ba:	06                   	push   es
    96bb:	57                   	push   di
    96bc:	9a 08 9b d5 96       	call   0x96d5:0x9b08
    96c1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    96c5:	83 c4 06             	add    sp,0x6
    96c8:	b8 d8 96             	mov    ax,0x96d8
    96cb:	0e                   	push   cs
    96cc:	50                   	push   ax
    96cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    96d0:	06                   	push   es
    96d1:	57                   	push   di
    96d2:	9a ca 97 f1 96       	call   0x96f1:0x97ca
    96d7:	cb                   	retf
    96d8:	ff 76 14             	push   WORD PTR [bp+0x14]
    96db:	ff 76 12             	push   WORD PTR [bp+0x12]
    96de:	ff 76 10             	push   WORD PTR [bp+0x10]
    96e1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    96e4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    96e7:	06                   	push   es
    96e8:	57                   	push   di
    96e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    96ec:	06                   	push   es
    96ed:	57                   	push   di
    96ee:	9a e5 80 1e 97       	call   0x971e:0x80e5
    96f3:	c9                   	leave
    96f4:	ca 10 00             	retf   0x10
    96f7:	c8 00 02 00          	enter  0x200,0x0
    96fb:	8d be 00 ff          	lea    di,[bp-0x100]
    96ff:	16                   	push   ss
    9700:	57                   	push   di
    9701:	8d be 00 fe          	lea    di,[bp-0x200]
    9705:	16                   	push   ss
    9706:	57                   	push   di
    9707:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    970a:	36 ff 75 14          	push   WORD PTR ss:[di+0x14]
    970e:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    9712:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    9715:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    9719:	06                   	push   es
    971a:	57                   	push   di
    971b:	9a 68 9a b5 97       	call   0x97b5:0x9a68
    9720:	9a 4c 0d 61 97       	call   0x9761:0xd4c
    9725:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    9728:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    972c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    9731:	06                   	push   es
    9732:	57                   	push   di
    9733:	9a d2 21 ff ff       	call   0xffff:0x21d2
    9738:	50                   	push   ax
    9739:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    973c:	36 8b 45 f8          	mov    ax,WORD PTR ss:[di-0x8]
    9740:	40                   	inc    ax
    9741:	40                   	inc    ax
    9742:	50                   	push   ax
    9743:	36 8b 45 fa          	mov    ax,WORD PTR ss:[di-0x6]
    9747:	40                   	inc    ax
    9748:	40                   	inc    ax
    9749:	50                   	push   ax
    974a:	6a 06                	push   0x6
    974c:	81 c7 f8 ff          	add    di,0xfff8
    9750:	16                   	push   ss
    9751:	57                   	push   di
    9752:	8d be 00 ff          	lea    di,[bp-0x100]
    9756:	16                   	push   ss
    9757:	57                   	push   di
    9758:	8d be 00 ff          	lea    di,[bp-0x100]
    975c:	16                   	push   ss
    975d:	57                   	push   di
    975e:	9a 8c 0c ff ff       	call   0xffff:0xc8c
    9763:	50                   	push   ax
    9764:	6a 00                	push   0x0
    9766:	6a 00                	push   0x0
    9768:	9a ff ff 00 00       	call   0x0:0xffff
    976d:	c9                   	leave
    976e:	c2 02 00             	ret    0x2
    9771:	c8 08 00 00          	enter  0x8,0x0
    9775:	8c d3                	mov    bx,ss
    9777:	8e c3                	mov    es,bx
    9779:	8c db                	mov    bx,ds
    977b:	fc                   	cld
    977c:	8d 7e f8             	lea    di,[bp-0x8]
    977f:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    9782:	b9 08 00             	mov    cx,0x8
    9785:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    9787:	8e db                	mov    ds,bx
    9789:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    978c:	26 80 bd 3b 01 00    	cmp    BYTE PTR es:[di+0x13b],0x0
    9792:	74 04                	je     0x9798
    9794:	55                   	push   bp
    9795:	e8 5f ff             	call   0x96f7
    9798:	ff 76 16             	push   WORD PTR [bp+0x16]
    979b:	ff 76 14             	push   WORD PTR [bp+0x14]
    979e:	ff 76 12             	push   WORD PTR [bp+0x12]
    97a1:	ff 76 10             	push   WORD PTR [bp+0x10]
    97a4:	8d 7e f8             	lea    di,[bp-0x8]
    97a7:	16                   	push   ss
    97a8:	57                   	push   di
    97a9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    97ac:	50                   	push   ax
    97ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    97b0:	06                   	push   es
    97b1:	57                   	push   di
    97b2:	9a 21 81 14 98       	call   0x9814:0x8121
    97b7:	c9                   	leave
    97b8:	ca 12 00             	retf   0x12
    97bb:	55                   	push   bp
    97bc:	89 e5                	mov    bp,sp
    97be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    97c1:	26 ff 85 8f 01       	inc    WORD PTR es:[di+0x18f]
    97c6:	c9                   	leave
    97c7:	ca 04 00             	retf   0x4
    97ca:	55                   	push   bp
    97cb:	89 e5                	mov    bp,sp
    97cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    97d0:	26 ff 8d 8f 01       	dec    WORD PTR es:[di+0x18f]
    97d5:	c9                   	leave
    97d6:	ca 04 00             	retf   0x4
    97d9:	c8 02 00 00          	enter  0x2,0x0
    97dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    97e0:	26 8b 85 89 01       	mov    ax,WORD PTR es:[di+0x189]
    97e5:	26 0b 85 8b 01       	or     ax,WORD PTR es:[di+0x18b]
    97ea:	75 3e                	jne    0x982a
    97ec:	26 83 bd e8 00 00    	cmp    WORD PTR es:[di+0xe8],0x0
    97f2:	7f 0b                	jg     0x97ff
    97f4:	7c 0f                	jl     0x9805
    97f6:	26 81 bd e6 00 00 02 	cmp    WORD PTR es:[di+0xe6],0x200
    97fd:	76 06                	jbe    0x9805
    97ff:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    9803:	eb 04                	jmp    0x9809
    9805:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    9809:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    980c:	50                   	push   ax
    980d:	b0 01                	mov    al,0x1
    980f:	50                   	push   ax
    9810:	b8 33 82             	mov    ax,0x8233
    9813:	ba 1b 98             	mov    dx,0x981b
    9816:	52                   	push   dx
    9817:	50                   	push   ax
    9818:	9a 49 88 64 98       	call   0x9864:0x8849
    981d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9820:	26 89 85 89 01       	mov    WORD PTR es:[di+0x189],ax
    9825:	26 89 95 8b 01       	mov    WORD PTR es:[di+0x18b],dx
    982a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    982d:	26 83 bd 0c 01 00    	cmp    WORD PTR es:[di+0x10c],0x0
    9833:	7f 0b                	jg     0x9840
    9835:	7c 0f                	jl     0x9846
    9837:	26 81 bd 0a 01 00 01 	cmp    WORD PTR es:[di+0x10a],0x100
    983e:	76 06                	jbe    0x9846
    9840:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    9844:	eb 04                	jmp    0x984a
    9846:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    984a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    984d:	26 8b 85 85 01       	mov    ax,WORD PTR es:[di+0x185]
    9852:	26 0b 85 87 01       	or     ax,WORD PTR es:[di+0x187]
    9857:	75 21                	jne    0x987a
    9859:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    985c:	50                   	push   ax
    985d:	b0 01                	mov    al,0x1
    985f:	50                   	push   ax
    9860:	b8 33 82             	mov    ax,0x8233
    9863:	ba 6b 98             	mov    dx,0x986b
    9866:	52                   	push   dx
    9867:	50                   	push   ax
    9868:	9a 49 88 94 98       	call   0x9894:0x8849
    986d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9870:	26 89 85 85 01       	mov    WORD PTR es:[di+0x185],ax
    9875:	26 89 95 87 01       	mov    WORD PTR es:[di+0x187],dx
    987a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    987d:	26 8b 85 81 01       	mov    ax,WORD PTR es:[di+0x181]
    9882:	26 0b 85 83 01       	or     ax,WORD PTR es:[di+0x183]
    9887:	75 21                	jne    0x98aa
    9889:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    988c:	50                   	push   ax
    988d:	b0 01                	mov    al,0x1
    988f:	50                   	push   ax
    9890:	b8 33 82             	mov    ax,0x8233
    9893:	ba 9b 98             	mov    dx,0x989b
    9896:	52                   	push   dx
    9897:	50                   	push   ax
    9898:	9a 49 88 cf 98       	call   0x98cf:0x8849
    989d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    98a0:	26 89 85 81 01       	mov    WORD PTR es:[di+0x181],ax
    98a5:	26 89 95 83 01       	mov    WORD PTR es:[di+0x183],dx
    98aa:	c9                   	leave
    98ab:	ca 04 00             	retf   0x4
    98ae:	55                   	push   bp
    98af:	89 e5                	mov    bp,sp
    98b1:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    98b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    98b7:	26 88 85 8d 01       	mov    BYTE PTR es:[di+0x18d],al
    98bc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    98c0:	75 18                	jne    0x98da
    98c2:	26 80 bd 8e 01 00    	cmp    BYTE PTR es:[di+0x18e],0x0
    98c8:	74 10                	je     0x98da
    98ca:	06                   	push   es
    98cb:	57                   	push   di
    98cc:	9a 82 48 fd 98       	call   0x98fd:0x4882
    98d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    98d4:	26 c6 85 8e 01 00    	mov    BYTE PTR es:[di+0x18e],0x0
    98da:	c9                   	leave
    98db:	ca 06 00             	retf   0x6
    98de:	55                   	push   bp
    98df:	89 e5                	mov    bp,sp
    98e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    98e4:	26 80 bd 8d 01 00    	cmp    BYTE PTR es:[di+0x18d],0x0
    98ea:	75 15                	jne    0x9901
    98ec:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    98ef:	99                   	cwd
    98f0:	52                   	push   dx
    98f1:	50                   	push   ax
    98f2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    98f5:	99                   	cwd
    98f6:	52                   	push   dx
    98f7:	50                   	push   ax
    98f8:	06                   	push   es
    98f9:	57                   	push   di
    98fa:	9a 3b 48 3e 99       	call   0x993e:0x483b
    98ff:	eb 09                	jmp    0x990a
    9901:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9904:	26 c6 85 8e 01 01    	mov    BYTE PTR es:[di+0x18e],0x1
    990a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    990d:	99                   	cwd
    990e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9911:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    9916:	75 28                	jne    0x9940
    9918:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    991d:	75 21                	jne    0x9940
    991f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    9922:	99                   	cwd
    9923:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    9928:	75 16                	jne    0x9940
    992a:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    992f:	75 0f                	jne    0x9940
    9931:	26 83 bd 8f 01 00    	cmp    WORD PTR es:[di+0x18f],0x0
    9937:	75 07                	jne    0x9940
    9939:	06                   	push   es
    993a:	57                   	push   di
    993b:	9a 9f 25 7e 99       	call   0x997e:0x259f
    9940:	c9                   	leave
    9941:	ca 08 00             	retf   0x8
    9944:	c8 0a 00 00          	enter  0xa,0x0
    9948:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    994c:	74 12                	je     0x9960
    994e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9951:	26 8d 85 89 01       	lea    ax,es:[di+0x189]
    9956:	8c c2                	mov    dx,es
    9958:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    995b:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    995e:	eb 10                	jmp    0x9970
    9960:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9963:	26 8d 85 85 01       	lea    ax,es:[di+0x185]
    9968:	8c c2                	mov    dx,es
    996a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    996d:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    9970:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9973:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    9976:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9979:	06                   	push   es
    997a:	57                   	push   di
    997b:	9a fd 89 b9 99       	call   0x99b9:0x89fd
    9980:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9983:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    9986:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    9989:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    998c:	75 50                	jne    0x99de
    998e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    9992:	74 0b                	je     0x999f
    9994:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    9997:	f7 d8                	neg    ax
    9999:	48                   	dec    ax
    999a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    999d:	eb 07                	jmp    0x99a6
    999f:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    99a2:	40                   	inc    ax
    99a3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    99a6:	ff 76 08             	push   WORD PTR [bp+0x8]
    99a9:	ff 76 06             	push   WORD PTR [bp+0x6]
    99ac:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    99af:	99                   	cwd
    99b0:	52                   	push   dx
    99b1:	50                   	push   ax
    99b2:	b0 01                	mov    al,0x1
    99b4:	50                   	push   ax
    99b5:	b8 9c 0d             	mov    ax,0xd9c
    99b8:	ba c0 99             	mov    dx,0x99c0
    99bb:	52                   	push   dx
    99bc:	50                   	push   ax
    99bd:	9a 0f 90 dc 99       	call   0x99dc:0x900f
    99c2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    99c5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    99c8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    99cb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    99ce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    99d1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    99d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    99d7:	06                   	push   es
    99d8:	57                   	push   di
    99d9:	9a 2d 8b fc 99       	call   0x99fc:0x8b2d
    99de:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    99e1:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    99e4:	c9                   	leave
    99e5:	ca 08 00             	retf   0x8
    99e8:	c8 06 00 00          	enter  0x6,0x0
    99ec:	ff 76 0a             	push   WORD PTR [bp+0xa]
    99ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    99f2:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    99f7:	06                   	push   es
    99f8:	57                   	push   di
    99f9:	9a fd 89 37 9a       	call   0x9a37:0x89fd
    99fe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9a01:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    9a04:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    9a07:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    9a0a:	75 52                	jne    0x9a5e
    9a0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9a0f:	26 83 bd e8 00 00    	cmp    WORD PTR es:[di+0xe8],0x0
    9a15:	7f 0b                	jg     0x9a22
    9a17:	7c 0f                	jl     0x9a28
    9a19:	26 81 bd e6 00 00 02 	cmp    WORD PTR es:[di+0xe6],0x200
    9a20:	76 06                	jbe    0x9a28
    9a22:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    9a26:	eb 04                	jmp    0x9a2c
    9a28:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    9a2c:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    9a2f:	50                   	push   ax
    9a30:	b0 01                	mov    al,0x1
    9a32:	50                   	push   ax
    9a33:	b8 63 82             	mov    ax,0x8263
    9a36:	ba 3e 9a             	mov    dx,0x9a3e
    9a39:	52                   	push   dx
    9a3a:	50                   	push   ax
    9a3b:	9a 6f 8b 5c 9a       	call   0x9a5c:0x8b6f
    9a40:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9a43:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    9a46:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9a49:	ff 76 fe             	push   WORD PTR [bp-0x2]
    9a4c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    9a4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9a52:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    9a57:	06                   	push   es
    9a58:	57                   	push   di
    9a59:	9a 2d 8b 7c 9a       	call   0x9a7c:0x8b2d
    9a5e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    9a61:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    9a64:	c9                   	leave
    9a65:	ca 06 00             	retf   0x6
    9a68:	c8 04 01 00          	enter  0x104,0x0
    9a6c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9a6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9a72:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    9a77:	06                   	push   es
    9a78:	57                   	push   di
    9a79:	9a fd 89 cf 9a       	call   0x9acf:0x89fd
    9a7e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9a81:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    9a84:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    9a87:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    9a8a:	75 09                	jne    0x9a95
    9a8c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    9a8f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    9a93:	eb 22                	jmp    0x9ab7
    9a95:	8d be fc fe          	lea    di,[bp-0x104]
    9a99:	16                   	push   ss
    9a9a:	57                   	push   di
    9a9b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9a9e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    9aa1:	06                   	push   es
    9aa2:	57                   	push   di
    9aa3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9aa6:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    9aaa:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    9aad:	06                   	push   es
    9aae:	57                   	push   di
    9aaf:	68 ff 00             	push   0xff
    9ab2:	9a e7 17 ff ff       	call   0xffff:0x17e7
    9ab7:	c9                   	leave
    9ab8:	ca 08 00             	retf   0x8
    9abb:	c8 08 00 00          	enter  0x8,0x0
    9abf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9ac2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9ac5:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    9aca:	06                   	push   es
    9acb:	57                   	push   di
    9acc:	9a fd 89 1e 9b       	call   0x9b1e:0x89fd
    9ad1:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    9ad4:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    9ad7:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    9ada:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    9add:	75 0a                	jne    0x9ae9
    9adf:	31 c0                	xor    ax,ax
    9ae1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9ae4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    9ae7:	eb 15                	jmp    0x9afe
    9ae9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9aec:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    9aef:	06                   	push   es
    9af0:	57                   	push   di
    9af1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9af4:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    9af8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    9afb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    9afe:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    9b01:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    9b04:	c9                   	leave
    9b05:	ca 08 00             	retf   0x8
    9b08:	55                   	push   bp
    9b09:	89 e5                	mov    bp,sp
    9b0b:	ff 76 10             	push   WORD PTR [bp+0x10]
    9b0e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    9b11:	06                   	push   es
    9b12:	57                   	push   di
    9b13:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9b16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b19:	06                   	push   es
    9b1a:	57                   	push   di
    9b1b:	9a e8 99 3a 9b       	call   0x9b3a:0x99e8
    9b20:	89 c7                	mov    di,ax
    9b22:	8e c2                	mov    es,dx
    9b24:	06                   	push   es
    9b25:	57                   	push   di
    9b26:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9b29:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    9b2d:	ff 76 10             	push   WORD PTR [bp+0x10]
    9b30:	6a 01                	push   0x1
    9b32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b35:	06                   	push   es
    9b36:	57                   	push   di
    9b37:	9a 44 99 49 9b       	call   0x9b49:0x9944
    9b3c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9b3f:	6a 00                	push   0x0
    9b41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b44:	06                   	push   es
    9b45:	57                   	push   di
    9b46:	9a 44 99 59 9b       	call   0x9b59:0x9944
    9b4b:	ff 76 10             	push   WORD PTR [bp+0x10]
    9b4e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9b51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b54:	06                   	push   es
    9b55:	57                   	push   di
    9b56:	9a de 98 76 9b       	call   0x9b76:0x98de
    9b5b:	c9                   	leave
    9b5c:	ca 0c 00             	retf   0xc
    9b5f:	55                   	push   bp
    9b60:	89 e5                	mov    bp,sp
    9b62:	ff 76 10             	push   WORD PTR [bp+0x10]
    9b65:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9b68:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9b6b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9b6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b71:	06                   	push   es
    9b72:	57                   	push   di
    9b73:	9a e8 99 92 9b       	call   0x9b92:0x99e8
    9b78:	89 c7                	mov    di,ax
    9b7a:	8e c2                	mov    es,dx
    9b7c:	06                   	push   es
    9b7d:	57                   	push   di
    9b7e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    9b81:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    9b85:	ff 76 10             	push   WORD PTR [bp+0x10]
    9b88:	6a 01                	push   0x1
    9b8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b8d:	06                   	push   es
    9b8e:	57                   	push   di
    9b8f:	9a 44 99 a1 9b       	call   0x9ba1:0x9944
    9b94:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9b97:	6a 00                	push   0x0
    9b99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b9c:	06                   	push   es
    9b9d:	57                   	push   di
    9b9e:	9a 44 99 b1 9b       	call   0x9bb1:0x9944
    9ba3:	ff 76 10             	push   WORD PTR [bp+0x10]
    9ba6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    9ba9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9bac:	06                   	push   es
    9bad:	57                   	push   di
    9bae:	9a de 98 ff ff       	call   0xffff:0x98de
    9bb3:	c9                   	leave
    9bb4:	ca 0c 00             	retf   0xc
    9bb7:	55                   	push   bp
    9bb8:	89 e5                	mov    bp,sp
    9bba:	bf e0 0b             	mov    di,0xbe0
    9bbd:	1e                   	push   ds
    9bbe:	57                   	push   di
    9bbf:	bf e8 0b             	mov    di,0xbe8
    9bc2:	1e                   	push   ds
    9bc3:	57                   	push   di
    9bc4:	68 90 01             	push   0x190
    9bc7:	9a ff ff 00 00       	call   0x0:0xffff
    9bcc:	a3 ca 2a             	mov    ds:0x2aca,ax
    9bcf:	c9                   	leave
    9bd0:	cb                   	retf
