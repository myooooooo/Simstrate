; ================================================================
; seg05_CODE  (35667 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	05 00 5e             	add    ax,0x5e00
       3:	10 95 06 ab          	adc    BYTE PTR [di-0x54fa],dl
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 8d          	add    BYTE PTR [bp-0x7300],bl
       d:	08 fb                	or     bl,bh
       f:	04 72                	add    al,0x72
      11:	10 39                	adc    BYTE PTR [bx+di],bh
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 90 10 cb       	call   0xcb10:0x901f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 ce                	adc    dh,cl
      2d:	2e d6                	cs (bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 51                	sbb    al,0x51
      61:	28 e2                	sub    dl,ah
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0c 54                	or     al,0x54
      a0:	46                   	inc    si
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	47                   	inc    di
      a5:	72 61                	jb     0x108
      a7:	70 68                	jo     0x111
      a9:	65 32 4a 00          	xor    cl,BYTE PTR gs:[bp+si+0x0]
      ad:	66 16                	pushd  ss
      af:	c2 00 0e             	ret    0xe00
      b2:	50                   	push   ax
      b3:	61                   	popa
      b4:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
      b9:	78 32                	js     0xed
      bb:	50                   	push   ax
      bc:	61                   	popa
      bd:	69 6e 74 16 19       	imul   bp,WORD PTR [bp+0x74],0x1916
      c2:	d5 00                	aad    0x0
      c4:	0e                   	push   cs
      c5:	50                   	push   ax
      c6:	61                   	popa
      c7:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
      cc:	78 33                	js     0x101
      ce:	50                   	push   ax
      cf:	61                   	popa
      d0:	69 6e 74 bd 1c       	imul   bp,WORD PTR [bp+0x74],0x1cbd
      d5:	e8 00 0e             	call   0xed8
      d8:	50                   	push   ax
      d9:	61                   	popa
      da:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
      df:	78 31                	js     0x112
      e1:	50                   	push   ax
      e2:	61                   	popa
      e3:	69 6e 74 1c 27       	imul   bp,WORD PTR [bp+0x74],0x271c
      e8:	fa                   	cli
      e9:	00 0d                	add    BYTE PTR [di],cl
      eb:	54                   	push   sp
      ec:	61                   	popa
      ed:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      f0:	61                   	popa
      f1:	75 31                	jne    0x124
      f3:	43                   	inc    bx
      f4:	6c                   	ins    BYTE PTR es:[di],dx
      f5:	69 63 6b b7 28       	imul   sp,WORD PTR [bp+di+0x6b],0x28b7
      fa:	0b 01                	or     ax,WORD PTR [bx+di]
      fc:	0c 47                	or     al,0x47
      fe:	72 61                	jb     0x161
     100:	70 68                	jo     0x16a
     102:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     106:	69 63 6b 7d 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2d7d
     10b:	1a 01                	sbb    al,BYTE PTR [bx+di]
     10d:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     110:	72 6d                	jb     0x17f
     112:	43                   	inc    bx
     113:	72 65                	jb     0x17a
     115:	61                   	popa
     116:	74 65                	je     0x17d
     118:	fb                   	sti
     119:	34 2f                	xor    al,0x2f
     11b:	01 10                	add    WORD PTR [bx+si],dx
     11d:	53                   	push   bx
     11e:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     121:	6c                   	ins    BYTE PTR es:[di],dx
     122:	6c                   	ins    BYTE PTR es:[di],dx
     123:	42                   	inc    dx
     124:	61                   	popa
     125:	72 31                	jb     0x158
     127:	53                   	push   bx
     128:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     12b:	6c                   	ins    BYTE PTR es:[di],dx
     12c:	6c                   	ins    BYTE PTR es:[di],dx
     12d:	2d 35 40             	sub    ax,0x4035
     130:	01 0c                	add    WORD PTR [si],cx
     132:	50                   	push   ax
     133:	61                   	popa
     134:	6e                   	outs   dx,BYTE PTR ds:[si]
     135:	65 6c                	gs ins BYTE PTR es:[di],dx
     137:	39 52 65             	cmp    WORD PTR [bp+si+0x65],dx
     13a:	73 69                	jae    0x1a5
     13c:	7a 65                	jp     0x1a3
     13e:	10 33                	adc    BYTE PTR [bp+di],dh
     140:	53                   	push   bx
     141:	01 0e 49 6d          	add    WORD PTR ds:0x6d49,cx
     145:	70 72                	jo     0x1b9
     147:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     14c:	43                   	inc    bx
     14d:	6c                   	ins    BYTE PTR es:[di],dx
     14e:	69 63 6b 11 34       	imul   sp,WORD PTR [bp+di+0x6b],0x3411
     153:	65 01 0d             	add    WORD PTR gs:[di],cx
     156:	51                   	push   cx
     157:	75 69                	jne    0x1c2
     159:	74 74                	je     0x1cf
     15b:	65 72 31             	gs jb  0x18f
     15e:	43                   	inc    bx
     15f:	6c                   	ins    BYTE PTR es:[di],dx
     160:	69 63 6b 29 34       	imul   sp,WORD PTR [bp+di+0x6b],0x3429
     165:	8a 01                	mov    al,BYTE PTR [bx+di]
     167:	20 43 6f             	and    BYTE PTR [bp+di+0x6f],al
     16a:	6e                   	outs   dx,BYTE PTR ds:[si]
     16b:	66 69 67 75 72 61 74 	imul   esp,DWORD PTR [bx+0x75],0x69746172
     172:	69 
     173:	6f                   	outs   dx,WORD PTR ds:[si]
     174:	6e                   	outs   dx,BYTE PTR ds:[si]
     175:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
     178:	69 6d 70 72 65       	imul   bp,WORD PTR [di+0x70],0x6572
     17d:	73 73                	jae    0x1f2
     17f:	69 6f 6e 31 43       	imul   bp,WORD PTR [bx+0x6e],0x4331
     184:	6c                   	ins    BYTE PTR es:[di],dx
     185:	69 63 6b 45 35       	imul   sp,WORD PTR [bp+di+0x6b],0x3545
     18a:	9d                   	popf
     18b:	01 0e 50 61          	add    WORD PTR ds:0x6150,cx
     18f:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     194:	78 35                	js     0x1cb
     196:	50                   	push   ax
     197:	61                   	popa
     198:	69 6e 74 56 36       	imul   bp,WORD PTR [bp+0x74],0x3656
     19d:	b0 01                	mov    al,0x1
     19f:	0e                   	push   cs
     1a0:	50                   	push   ax
     1a1:	61                   	popa
     1a2:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     1a7:	78 36                	js     0x1df
     1a9:	50                   	push   ax
     1aa:	61                   	popa
     1ab:	69 6e 74 a1 31       	imul   bp,WORD PTR [bp+0x74],0x31a1
     1b0:	bd 01 08             	mov    bp,0x801
     1b3:	46                   	inc    si
     1b4:	6f                   	outs   dx,WORD PTR ds:[si]
     1b5:	72 6d                	jb     0x224
     1b7:	53                   	push   bx
     1b8:	68 6f 77             	push   0x776f
     1bb:	a3 23 d0             	mov    ds:0xd023,ax
     1be:	01 0e 50 61          	add    WORD PTR ds:0x6150,cx
     1c2:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     1c7:	78 34                	js     0x1fd
     1c9:	50                   	push   ax
     1ca:	61                   	popa
     1cb:	69 6e 74 65 3e       	imul   bp,WORD PTR [bp+0x74],0x3e65
     1d0:	e7 01                	out    0x1,ax
     1d2:	12 50 61             	adc    dl,BYTE PTR [bx+si+0x61]
     1d5:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     1da:	78 31                	js     0x20d
     1dc:	4d                   	dec    bp
     1dd:	6f                   	outs   dx,WORD PTR ds:[si]
     1de:	75 73                	jne    0x253
     1e0:	65 4d                	gs dec bp
     1e2:	6f                   	outs   dx,WORD PTR ds:[si]
     1e3:	76 65                	jbe    0x24a
     1e5:	98                   	cbw
     1e6:	44                   	inc    sp
     1e7:	fe 01                	inc    BYTE PTR [bx+di]
     1e9:	12 50 61             	adc    dl,BYTE PTR [bx+si+0x61]
     1ec:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     1f1:	78 31                	js     0x224
     1f3:	4d                   	dec    bp
     1f4:	6f                   	outs   dx,WORD PTR ds:[si]
     1f5:	75 73                	jne    0x26a
     1f7:	65 44                	gs inc sp
     1f9:	6f                   	outs   dx,WORD PTR ds:[si]
     1fa:	77 6e                	ja     0x26a
     1fc:	dc 44 13             	fadd   QWORD PTR [si+0x13]
     1ff:	02 10                	add    dl,BYTE PTR [bx+si]
     201:	50                   	push   ax
     202:	61                   	popa
     203:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     208:	78 31                	js     0x23b
     20a:	4d                   	dec    bp
     20b:	6f                   	outs   dx,WORD PTR ds:[si]
     20c:	75 73                	jne    0x281
     20e:	65 55                	gs push bp
     210:	70 d1                	jo     0x1e3
     212:	45                   	inc    bp
     213:	2a 02                	sub    al,BYTE PTR [bp+si]
     215:	12 50 61             	adc    dl,BYTE PTR [bx+si+0x61]
     218:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     21d:	78 34                	js     0x253
     21f:	4d                   	dec    bp
     220:	6f                   	outs   dx,WORD PTR ds:[si]
     221:	75 73                	jne    0x296
     223:	65 4d                	gs dec bp
     225:	6f                   	outs   dx,WORD PTR ds:[si]
     226:	76 65                	jbe    0x28d
     228:	eb 45                	jmp    0x26f
     22a:	3d 02 0e             	cmp    ax,0xe02
     22d:	50                   	push   ax
     22e:	61                   	popa
     22f:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     234:	78 34                	js     0x26a
     236:	43                   	inc    bx
     237:	6c                   	ins    BYTE PTR es:[di],dx
     238:	69 63 6b 8d 39       	imul   sp,WORD PTR [bp+di+0x6b],0x398d
     23d:	4c                   	dec    sp
     23e:	02 0a                	add    cl,BYTE PTR [bp+si]
     240:	48                   	dec    ax
     241:	61                   	popa
     242:	75 74                	jne    0x2b8
     244:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     247:	69 63 6b ed 39       	imul   sp,WORD PTR [bp+di+0x6b],0x39ed
     24c:	5d                   	pop    bp
     24d:	02 0c                	add    cl,BYTE PTR [si]
     24f:	47                   	inc    di
     250:	61                   	popa
     251:	75 63                	jne    0x2b6
     253:	68 65 31             	push   0x3165
     256:	43                   	inc    bx
     257:	6c                   	ins    BYTE PTR es:[di],dx
     258:	69 63 6b 4d 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a4d
     25d:	6e                   	outs   dx,BYTE PTR ds:[si]
     25e:	02 0c                	add    cl,BYTE PTR [si]
     260:	44                   	inc    sp
     261:	72 6f                	jb     0x2d2
     263:	69 74 65 31 43       	imul   si,WORD PTR [si+0x65],0x4331
     268:	6c                   	ins    BYTE PTR es:[di],dx
     269:	69 63 6b ad 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3aad
     26e:	7c 02                	jl     0x272
     270:	09 42 61             	or     WORD PTR [bp+si+0x61],ax
     273:	73 31                	jae    0x2a6
     275:	43                   	inc    bx
     276:	6c                   	ins    BYTE PTR es:[di],dx
     277:	69 63 6b 4b 47       	imul   sp,WORD PTR [bp+di+0x6b],0x474b
     27c:	8e 02                	mov    es,WORD PTR [bp+si]
     27e:	0d 4c 65             	or     ax,0x654c
     281:	67 65 6e             	outs   dx,BYTE PTR gs:[esi]
     284:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     289:	69 63 6b 60 3c       	imul   sp,WORD PTR [bp+di+0x6b],0x3c60
     28e:	9d                   	popf
     28f:	02 0a                	add    cl,BYTE PTR [bp+si]
     291:	48                   	dec    ax
     292:	61                   	popa
     293:	75 74                	jne    0x309
     295:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     298:	69 63 6b d5 3c       	imul   sp,WORD PTR [bp+di+0x6b],0x3cd5
     29d:	ab                   	stos   WORD PTR es:[di],ax
     29e:	02 09                	add    cl,BYTE PTR [bx+di]
     2a0:	42                   	inc    dx
     2a1:	61                   	popa
     2a2:	73 32                	jae    0x2d6
     2a4:	43                   	inc    bx
     2a5:	6c                   	ins    BYTE PTR es:[di],dx
     2a6:	69 63 6b 4a 3d       	imul   sp,WORD PTR [bp+di+0x6b],0x3d4a
     2ab:	bc 02 0c             	mov    sp,0xc02
     2ae:	47                   	inc    di
     2af:	61                   	popa
     2b0:	75 63                	jne    0x315
     2b2:	68 65 32             	push   0x3265
     2b5:	43                   	inc    bx
     2b6:	6c                   	ins    BYTE PTR es:[di],dx
     2b7:	69 63 6b bf 3d       	imul   sp,WORD PTR [bp+di+0x6b],0x3dbf
     2bc:	cd 02                	int    0x2
     2be:	0c 44                	or     al,0x44
     2c0:	72 6f                	jb     0x331
     2c2:	69 74 65 32 43       	imul   si,WORD PTR [si+0x65],0x4332
     2c7:	6c                   	ins    BYTE PTR es:[di],dx
     2c8:	69 63 6b ab 47       	imul   sp,WORD PTR [bp+di+0x6b],0x47ab
     2cd:	e3 02                	jcxz   0x2d1
     2cf:	11 42 61             	adc    WORD PTR [bp+si+0x61],ax
     2d2:	72 72                	jb     0x346
     2d4:	65 4f                	gs dec di
     2d6:	75 74                	jne    0x34c
     2d8:	69 6c 73 31 43       	imul   bp,WORD PTR [si+0x73],0x4331
     2dd:	6c                   	ins    BYTE PTR es:[di],dx
     2de:	69 63 6b ec 87       	imul   sp,WORD PTR [bp+di+0x6b],0x87ec
     2e3:	f3 02 0b             	repz add cl,BYTE PTR [bp+di]
     2e6:	53                   	push   bx
     2e7:	65 72 69             	gs jb  0x353
     2ea:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2ee:	69 63 6b c5 48       	imul   sp,WORD PTR [bp+di+0x6b],0x48c5
     2f3:	0e                   	push   cs
     2f4:	03 16 53 74          	add    dx,WORD PTR ds:0x7453
     2f8:	72 69                	jb     0x363
     2fa:	6e                   	outs   dx,BYTE PTR ds:[si]
     2fb:	67 47                	addr32 inc di
     2fd:	72 69                	jb     0x368
     2ff:	64 31 43 6f          	xor    WORD PTR fs:[bp+di+0x6f],ax
     303:	6c                   	ins    BYTE PTR es:[di],dx
     304:	75 6d                	jne    0x373
     306:	6e                   	outs   dx,BYTE PTR ds:[si]
     307:	4d                   	dec    bp
     308:	6f                   	outs   dx,WORD PTR ds:[si]
     309:	76 65                	jbe    0x370
     30b:	64 0b 48 22          	or     cx,WORD PTR fs:[bx+si+0x22]
     30f:	03 0f                	add    cx,WORD PTR [bx]
     311:	42                   	inc    dx
     312:	61                   	popa
     313:	72 72                	jb     0x387
     315:	65 45                	gs inc bp
     317:	74 61                	je     0x37a
     319:	74 31                	je     0x34c
     31b:	43                   	inc    bx
     31c:	6c                   	ins    BYTE PTR es:[di],dx
     31d:	69 63 6b e4 48       	imul   sp,WORD PTR [bp+di+0x6b],0x48e4
     322:	38 03                	cmp    BYTE PTR [bp+di],al
     324:	11 53 70             	adc    WORD PTR [bp+di+0x70],dx
     327:	65 65 64 42          	gs gs fs inc dx
     32b:	75 74                	jne    0x3a1
     32d:	74 6f                	je     0x39e
     32f:	6e                   	outs   dx,BYTE PTR ds:[si]
     330:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     333:	69 63 6b 28 49       	imul   sp,WORD PTR [bp+di+0x6b],0x4928
     338:	4e                   	dec    si
     339:	03 11                	add    dx,WORD PTR [bx+di]
     33b:	53                   	push   bx
     33c:	70 65                	jo     0x3a3
     33e:	65 64 42             	gs fs inc dx
     341:	75 74                	jne    0x3b7
     343:	74 6f                	je     0x3b4
     345:	6e                   	outs   dx,BYTE PTR ds:[si]
     346:	39 43 6c             	cmp    WORD PTR [bp+di+0x6c],ax
     349:	69 63 6b 3b 4a       	imul   sp,WORD PTR [bp+di+0x6b],0x4a3b
     34e:	66 03 13             	add    edx,DWORD PTR [bp+di]
     351:	53                   	push   bx
     352:	70 65                	jo     0x3b9
     354:	65 64 42             	gs fs inc dx
     357:	75 74                	jne    0x3cd
     359:	74 6f                	je     0x3ca
     35b:	6e                   	outs   dx,BYTE PTR ds:[si]
     35c:	32 4d 6f             	xor    cl,BYTE PTR [di+0x6f]
     35f:	75 73                	jne    0x3d4
     361:	65 55                	gs push bp
     363:	70 b7                	jo     0x31c
     365:	4a                   	dec    dx
     366:	7c 03                	jl     0x36b
     368:	11 53 70             	adc    WORD PTR [bp+di+0x70],dx
     36b:	65 65 64 42          	gs gs fs inc dx
     36f:	75 74                	jne    0x3e5
     371:	74 6f                	je     0x3e2
     373:	6e                   	outs   dx,BYTE PTR ds:[si]
     374:	33 43 6c             	xor    ax,WORD PTR [bp+di+0x6c]
     377:	69 63 6b 7b 49       	imul   sp,WORD PTR [bp+di+0x6b],0x497b
     37c:	93                   	xchg   bx,ax
     37d:	03 12                	add    dx,WORD PTR [bp+si]
     37f:	53                   	push   bx
     380:	70 65                	jo     0x3e7
     382:	65 64 42             	gs fs inc dx
     385:	75 74                	jne    0x3fb
     387:	74 6f                	je     0x3f8
     389:	6e                   	outs   dx,BYTE PTR ds:[si]
     38a:	31 30                	xor    WORD PTR [bx+si],si
     38c:	43                   	inc    bx
     38d:	6c                   	ins    BYTE PTR es:[di],dx
     38e:	69 63 6b 46 34       	imul   sp,WORD PTR [bp+di+0x6b],0x3446
     393:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     394:	03 0c                	add    cx,WORD PTR [si]
     396:	43                   	inc    bx
     397:	6f                   	outs   dx,WORD PTR ds:[si]
     398:	70 69                	jo     0x403
     39a:	65 72 31             	gs jb  0x3ce
     39d:	43                   	inc    bx
     39e:	6c                   	ins    BYTE PTR es:[di],dx
     39f:	69 63 6b d5 4a       	imul   sp,WORD PTR [bp+di+0x6b],0x4ad5
     3a4:	ba 03 11             	mov    dx,0x1103
     3a7:	53                   	push   bx
     3a8:	70 65                	jo     0x40f
     3aa:	65 64 42             	gs fs inc dx
     3ad:	75 74                	jne    0x423
     3af:	74 6f                	je     0x420
     3b1:	6e                   	outs   dx,BYTE PTR ds:[si]
     3b2:	34 43                	xor    al,0x43
     3b4:	6c                   	ins    BYTE PTR es:[di],dx
     3b5:	69 63 6b ce 49       	imul   sp,WORD PTR [bp+di+0x6b],0x49ce
     3ba:	d0 03                	rol    BYTE PTR [bp+di],1
     3bc:	11 53 70             	adc    WORD PTR [bp+di+0x70],dx
     3bf:	65 65 64 42          	gs gs fs inc dx
     3c3:	75 74                	jne    0x439
     3c5:	74 6f                	je     0x436
     3c7:	6e                   	outs   dx,BYTE PTR ds:[si]
     3c8:	35 43 6c             	xor    ax,0x6c43
     3cb:	69 63 6b 0d 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3b0d
     3d0:	df 03                	fild   WORD PTR [bp+di]
     3d2:	0a 48 61             	or     cl,BYTE PTR [bx+si+0x61]
     3d5:	75 74                	jne    0x44b
     3d7:	33 43 6c             	xor    ax,WORD PTR [bp+di+0x6c]
     3da:	69 63 6b 2b 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3b2b
     3df:	f0 03 0c             	lock add cx,WORD PTR [si]
     3e2:	47                   	inc    di
     3e3:	61                   	popa
     3e4:	75 63                	jne    0x449
     3e6:	68 65 33             	push   0x3365
     3e9:	43                   	inc    bx
     3ea:	6c                   	ins    BYTE PTR es:[di],dx
     3eb:	69 63 6b 49 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3b49
     3f0:	01 04                	add    WORD PTR [si],ax
     3f2:	0c 44                	or     al,0x44
     3f4:	72 6f                	jb     0x465
     3f6:	69 74 65 33 43       	imul   si,WORD PTR [si+0x65],0x4333
     3fb:	6c                   	ins    BYTE PTR es:[di],dx
     3fc:	69 63 6b 67 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3b67
     401:	0f 04                	(bad)
     403:	09 42 61             	or     WORD PTR [bp+si+0x61],ax
     406:	73 33                	jae    0x43b
     408:	43                   	inc    bx
     409:	6c                   	ins    BYTE PTR es:[di],dx
     40a:	69 63 6b 6b 48       	imul   sp,WORD PTR [bp+di+0x6b],0x486b
     40f:	21 04                	and    WORD PTR [si],ax
     411:	0d 4c 65             	or     ax,0x654c
     414:	67 65 6e             	outs   dx,BYTE PTR gs:[esi]
     417:	64 65 32 43 6c       	fs xor al,BYTE PTR gs:[bp+di+0x6c]
     41c:	69 63 6b 89 48       	imul   sp,WORD PTR [bp+di+0x6b],0x4889
     421:	37                   	aaa
     422:	04 11                	add    al,0x11
     424:	42                   	inc    dx
     425:	61                   	popa
     426:	72 72                	jb     0x49a
     428:	65 4f                	gs dec di
     42a:	75 74                	jne    0x4a0
     42c:	69 6c 73 32 43       	imul   bp,WORD PTR [si+0x73],0x4332
     431:	6c                   	ins    BYTE PTR es:[di],dx
     432:	69 63 6b a7 48       	imul   sp,WORD PTR [bp+di+0x6b],0x48a7
     437:	4b                   	dec    bx
     438:	04 0f                	add    al,0xf
     43a:	42                   	inc    dx
     43b:	61                   	popa
     43c:	72 72                	jb     0x4b0
     43e:	65 45                	gs inc bp
     440:	74 61                	je     0x4a3
     442:	74 32                	je     0x476
     444:	43                   	inc    bx
     445:	6c                   	ins    BYTE PTR es:[di],dx
     446:	69 63 6b 2f 4e       	imul   sp,WORD PTR [bp+di+0x6b],0x4e2f
     44b:	5b                   	pop    bx
     44c:	04 0b                	add    al,0xb
     44e:	65 73 73             	gs jae 0x4c4
     451:	61                   	popa
     452:	69 31 43 6c          	imul   si,WORD PTR [bx+di],0x6c43
     456:	69 63 6b e2 88       	imul   sp,WORD PTR [bp+di+0x6b],0x88e2
     45b:	6d                   	ins    WORD PTR es:[di],dx
     45c:	04 0d                	add    al,0xd
     45e:	54                   	push   sp
     45f:	61                   	popa
     460:	42                   	inc    dx
     461:	6c                   	ins    BYTE PTR es:[di],dx
     462:	65 61                	gs popa
     464:	75 32                	jne    0x498
     466:	43                   	inc    bx
     467:	6c                   	ins    BYTE PTR es:[di],dx
     468:	69 63 6b 6e 89       	imul   sp,WORD PTR [bp+di+0x6b],0x896e
     46d:	81 04 0f 42          	add    WORD PTR [si],0x420f
     471:	61                   	popa
     472:	72 72                	jb     0x4e6
     474:	65 45                	gs inc bp
     476:	74 61                	je     0x4d9
     478:	74 33                	je     0x4ad
     47a:	43                   	inc    bx
     47b:	6c                   	ins    BYTE PTR es:[di],dx
     47c:	69 63 6b 13 8a       	imul   sp,WORD PTR [bp+di+0x6b],0x8a13
     481:	91                   	xchg   cx,ax
     482:	04 0b                	add    al,0xb
     484:	49                   	dec    cx
     485:	6e                   	outs   dx,BYTE PTR ds:[si]
     486:	64 65 78 31          	fs gs js 0x4bb
     48a:	43                   	inc    bx
     48b:	6c                   	ins    BYTE PTR es:[di],dx
     48c:	69 63 6b 32 8a       	imul   sp,WORD PTR [bp+di+0x6b],0x8a32
     491:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     492:	04 10                	add    al,0x10
     494:	52                   	push   dx
     495:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     499:	72 63                	jb     0x4fe
     49b:	68 65 72             	push   0x7265
     49e:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     4a1:	69 63 6b 53 8a       	imul   sp,WORD PTR [bp+di+0x6b],0x8a53
     4a6:	be 04 13             	mov    si,0x1304
     4a9:	55                   	push   bp
     4aa:	74 69                	je     0x515
     4ac:	6c                   	ins    BYTE PTR es:[di],dx
     4ad:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     4b2:	61                   	popa
     4b3:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     4b8:	6c                   	ins    BYTE PTR es:[di],dx
     4b9:	69 63 6b 72 8a       	imul   sp,WORD PTR [bp+di+0x6b],0x8a72
     4be:	d0 04                	rol    BYTE PTR [si],1
     4c0:	0d 41 70             	or     ax,0x7041
     4c3:	72 6f                	jb     0x534
     4c5:	70 6f                	jo     0x536
     4c7:	73 31                	jae    0x4fa
     4c9:	43                   	inc    bx
     4ca:	6c                   	ins    BYTE PTR es:[di],dx
     4cb:	69 63 6b c2 85       	imul   sp,WORD PTR [bp+di+0x6b],0x85c2
     4d0:	e1 04                	loope  0x4d6
     4d2:	0c 53                	or     al,0x53
     4d4:	75 6a                	jne    0x540
     4d6:	65 74 31             	gs je  0x50a
     4d9:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     4dc:	69 63 6b 78 86       	imul   sp,WORD PTR [bp+di+0x6b],0x8678
     4e1:	f2 04 0c             	repnz add al,0xc
     4e4:	53                   	push   bx
     4e5:	75 6a                	jne    0x551
     4e7:	65 74 32             	gs je  0x51c
     4ea:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     4ed:	69 63 6b 2e 87       	imul   sp,WORD PTR [bp+di+0x6b],0x872e
     4f2:	03 05                	add    ax,WORD PTR [di]
     4f4:	0c 53                	or     al,0x53
     4f6:	75 6a                	jne    0x562
     4f8:	65 74 33             	gs je  0x52e
     4fb:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     4fe:	69 63 6b e1 8a       	imul   sp,WORD PTR [bp+di+0x6b],0x8ae1
     503:	15 05 0d             	adc    ax,0xd05
     506:	42                   	inc    dx
     507:	6c                   	ins    BYTE PTR es:[di],dx
     508:	6f                   	outs   dx,WORD PTR ds:[si]
     509:	71 75                	jno    0x580
     50b:	65 72 31             	gs jb  0x53f
     50e:	43                   	inc    bx
     50f:	6c                   	ins    BYTE PTR es:[di],dx
     510:	69 63 6b ff 8a       	imul   sp,WORD PTR [bp+di+0x6b],0x8aff
     515:	2b 05                	sub    ax,WORD PTR [di]
     517:	11 53 70             	adc    WORD PTR [bp+di+0x70],dx
     51a:	65 65 64 42          	gs gs fs inc dx
     51e:	75 74                	jne    0x594
     520:	74 6f                	je     0x591
     522:	6e                   	outs   dx,BYTE PTR ds:[si]
     523:	36 43                	ss inc bx
     525:	6c                   	ins    BYTE PTR es:[di],dx
     526:	69 63 6b cf 52       	imul   sp,WORD PTR [bp+di+0x6b],0x52cf
     52b:	48                   	dec    ax
     52c:	05 18 44             	add    ax,0x4418
     52f:	65 6d                	gs ins WORD PTR es:[di],dx
     531:	61                   	popa
     532:	6e                   	outs   dx,BYTE PTR ds:[si]
     533:	64 65 53             	fs gs push bx
     536:	75 72                	jne    0x5aa
     538:	6c                   	ins    BYTE PTR es:[di],dx
     539:	65 4d                	gs dec bp
     53b:	61                   	popa
     53c:	72 63                	jb     0x5a1
     53e:	68 65 31             	push   0x3165
     541:	43                   	inc    bx
     542:	6c                   	ins    BYTE PTR es:[di],dx
     543:	69 63 6b 8f 5b       	imul   sp,WORD PTR [bp+di+0x6b],0x5b8f
     548:	67 05 1a 44          	addr32 add ax,0x441a
     54c:	65 6d                	gs ins WORD PTR es:[di],dx
     54e:	61                   	popa
     54f:	6e                   	outs   dx,BYTE PTR ds:[si]
     550:	64 65 50             	fs gs push ax
     553:	61                   	popa
     554:	72 45                	jb     0x59b
     556:	6e                   	outs   dx,BYTE PTR ds:[si]
     557:	74 72                	je     0x5cb
     559:	65 70 72             	gs jo  0x5ce
     55c:	69 73 65 31 43       	imul   si,WORD PTR [bp+di+0x65],0x4331
     561:	6c                   	ins    BYTE PTR es:[di],dx
     562:	69 63 6b 4f 60       	imul   sp,WORD PTR [bp+di+0x6b],0x604f
     567:	82 05 16             	add    BYTE PTR [di],0x16
     56a:	56                   	push   si
     56b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     56d:	74 65                	je     0x5d4
     56f:	73 50                	jae    0x5c1
     571:	61                   	popa
     572:	72 50                	jb     0x5c4
     574:	72 6f                	jb     0x5e5
     576:	64 75 69             	fs jne 0x5e2
     579:	74 31                	je     0x5ac
     57b:	43                   	inc    bx
     57c:	6c                   	ins    BYTE PTR es:[di],dx
     57d:	69 63 6b dc 64       	imul   sp,WORD PTR [bp+di+0x6b],0x64dc
     582:	a0 05 19             	mov    al,ds:0x1905
     585:	56                   	push   si
     586:	65 6e                	outs   dx,BYTE PTR gs:[si]
     588:	74 65                	je     0x5ef
     58a:	73 50                	jae    0x5dc
     58c:	61                   	popa
     58d:	72 45                	jb     0x5d4
     58f:	6e                   	outs   dx,BYTE PTR ds:[si]
     590:	74 72                	je     0x604
     592:	65 70 72             	gs jo  0x607
     595:	69 73 65 31 43       	imul   si,WORD PTR [bp+di+0x65],0x4331
     59a:	6c                   	ins    BYTE PTR es:[di],dx
     59b:	69 63 6b 75 6e       	imul   sp,WORD PTR [bp+di+0x6b],0x6e75
     5a0:	c3                   	ret
     5a1:	05 1e 50             	add    ax,0x501e
     5a4:	61                   	popa
     5a5:	72 74                	jb     0x61b
     5a7:	73 4d                	jae    0x5f6
     5a9:	61                   	popa
     5aa:	72 63                	jb     0x60f
     5ac:	68 65 50             	push   0x5065
     5af:	61                   	popa
     5b0:	72 45                	jb     0x5f7
     5b2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5b3:	74 72                	je     0x627
     5b5:	65 70 72             	gs jo  0x62a
     5b8:	69 73 65 31 43       	imul   si,WORD PTR [bp+di+0x65],0x4331
     5bd:	6c                   	ins    BYTE PTR es:[di],dx
     5be:	69 63 6b b6 72       	imul   sp,WORD PTR [bp+di+0x6b],0x72b6
     5c3:	d9 05                	fld    DWORD PTR [di]
     5c5:	11 52 65             	adc    WORD PTR [bp+si+0x65],dx
     5c8:	73 75                	jae    0x63f
     5ca:	6c                   	ins    BYTE PTR es:[di],dx
     5cb:	74 61                	je     0x62e
     5cd:	74 4e                	je     0x61d
     5cf:	65 74 31             	gs je  0x603
     5d2:	43                   	inc    bx
     5d3:	6c                   	ins    BYTE PTR es:[di],dx
     5d4:	69 63 6b f3 4a       	imul   sp,WORD PTR [bp+di+0x6b],0x4af3
     5d9:	ef                   	out    dx,ax
     5da:	05 11 53             	add    ax,0x5311
     5dd:	70 65                	jo     0x644
     5df:	65 64 42             	gs fs inc dx
     5e2:	75 74                	jne    0x658
     5e4:	74 6f                	je     0x655
     5e6:	6e                   	outs   dx,BYTE PTR ds:[si]
     5e7:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     5ea:	69 63 6b 09 4b       	imul   sp,WORD PTR [bp+di+0x6b],0x4b09
     5ef:	05 06 11             	add    ax,0x1106
     5f2:	53                   	push   bx
     5f3:	70 65                	jo     0x65a
     5f5:	65 64 42             	gs fs inc dx
     5f8:	75 74                	jne    0x66e
     5fa:	74 6f                	je     0x66b
     5fc:	6e                   	outs   dx,BYTE PTR ds:[si]
     5fd:	37                   	aaa
     5fe:	43                   	inc    bx
     5ff:	6c                   	ins    BYTE PTR es:[di],dx
     600:	69 63 6b eb 89       	imul   sp,WORD PTR [bp+di+0x6b],0x89eb
     605:	15 06 0b             	adc    ax,0xb06
     608:	46                   	inc    si
     609:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     60e:	43                   	inc    bx
     60f:	6c                   	ins    BYTE PTR es:[di],dx
     610:	69 63 6b b4 69       	imul   sp,WORD PTR [bp+di+0x6b],0x69b4
     615:	35 06 1b             	xor    ax,0x1b06
     618:	50                   	push   ax
     619:	61                   	popa
     61a:	72 74                	jb     0x690
     61c:	73 4d                	jae    0x66b
     61e:	61                   	popa
     61f:	72 63                	jb     0x684
     621:	68 65 50             	push   0x5065
     624:	61                   	popa
     625:	72 50                	jb     0x677
     627:	72 6f                	jb     0x698
     629:	64 75 69             	fs jne 0x695
     62c:	74 31                	je     0x65f
     62e:	43                   	inc    bx
     62f:	6c                   	ins    BYTE PTR es:[di],dx
     630:	69 63 6b cb 4b       	imul   sp,WORD PTR [bp+di+0x6b],0x4bcb
     635:	43                   	inc    bx
     636:	06                   	push   es
     637:	09 4e 75             	or     WORD PTR [bp+0x75],cx
     63a:	6c                   	ins    BYTE PTR es:[di],dx
     63b:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     63e:	69 63 6b 75 57       	imul   sp,WORD PTR [bp+di+0x6b],0x5775
     643:	61                   	popa
     644:	06                   	push   es
     645:	19 44 65             	sbb    WORD PTR [si+0x65],ax
     648:	6d                   	ins    WORD PTR es:[di],dx
     649:	52                   	push   dx
     64a:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
     64d:	6c                   	ins    BYTE PTR es:[di],dx
     64e:	65 73 75             	gs jae 0x6c6
     651:	72 6c                	jb     0x6bf
     653:	65 6d                	gs ins WORD PTR es:[di],dx
     655:	61                   	popa
     656:	72 63                	jb     0x6bb
     658:	68 65 43             	push   0x4365
     65b:	6c                   	ins    BYTE PTR es:[di],dx
     65c:	69 63 6b cd 76       	imul   sp,WORD PTR [bp+di+0x6b],0x76cd
     661:	7d 06                	jge    0x669
     663:	17                   	pop    ss
     664:	52                   	push   dx
     665:	65 73 73             	gs jae 0x6db
     668:	6f                   	outs   dx,WORD PTR ds:[si]
     669:	75 72                	jne    0x6dd
     66b:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     66e:	70 72                	jo     0x6e2
     670:	6f                   	outs   dx,WORD PTR ds:[si]
     671:	70 72                	jo     0x6e5
     673:	65 73 31             	gs jae 0x6a7
     676:	43                   	inc    bx
     677:	6c                   	ins    BYTE PTR es:[di],dx
     678:	69 63 6b 21 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c21
     67d:	6e                   	outs   dx,BYTE PTR ds:[si]
     67e:	10 15                	adc    BYTE PTR [di],dl
     680:	54                   	push   sp
     681:	61                   	popa
     682:	75 78                	jne    0x6fc
     684:	65 6e                	outs   dx,BYTE PTR gs:[si]
     686:	64 65 74 74          	fs gs je 0x6fe
     68a:	65 6d                	gs ins WORD PTR es:[di],dx
     68c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     68e:	74 31                	je     0x6c1
     690:	43                   	inc    bx
     691:	6c                   	ins    BYTE PTR es:[di],dx
     692:	69 63 6b b8 00       	imul   sp,WORD PTR [bp+di+0x6b],0xb8
     697:	20 10                	and    BYTE PTR [bx+si],dl
     699:	7c 01                	jl     0x69c
     69b:	00 00                	add    BYTE PTR [bx+si],al
     69d:	06                   	push   es
     69e:	50                   	push   ax
     69f:	61                   	popa
     6a0:	6e                   	outs   dx,BYTE PTR ds:[si]
     6a1:	65 6c                	gs ins BYTE PTR es:[di],dx
     6a3:	31 80 01 00          	xor    WORD PTR [bx+si+0x1],ax
     6a7:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     6ab:	6e                   	outs   dx,BYTE PTR ds:[si]
     6ac:	65 6c                	gs ins BYTE PTR es:[di],dx
     6ae:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     6b2:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     6b6:	6e                   	outs   dx,BYTE PTR ds:[si]
     6b7:	65 6c                	gs ins BYTE PTR es:[di],dx
     6b9:	34 88                	xor    al,0x88
     6bb:	01 00                	add    WORD PTR [bx+si],ax
     6bd:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     6c1:	6e                   	outs   dx,BYTE PTR ds:[si]
     6c2:	65 6c                	gs ins BYTE PTR es:[di],dx
     6c4:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     6c8:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     6cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     6cd:	65 6c                	gs ins BYTE PTR es:[di],dx
     6cf:	36 90                	ss nop
     6d1:	01 00                	add    WORD PTR [bx+si],ax
     6d3:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     6d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     6d8:	65 6c                	gs ins BYTE PTR es:[di],dx
     6da:	37                   	aaa
     6db:	94                   	xchg   sp,ax
     6dc:	01 00                	add    WORD PTR [bx+si],ax
     6de:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     6e2:	6e                   	outs   dx,BYTE PTR ds:[si]
     6e3:	65 6c                	gs ins BYTE PTR es:[di],dx
     6e5:	38 98 01 04          	cmp    BYTE PTR [bx+si+0x401],bl
     6e9:	00 0b                	add    BYTE PTR [bp+di],cl
     6eb:	53                   	push   bx
     6ec:	74 72                	je     0x760
     6ee:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     6f3:	69 64 31 9c 01       	imul   sp,WORD PTR [si+0x31],0x19c
     6f8:	08 00                	or     BYTE PTR [bx+si],al
     6fa:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     6fd:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     702:	78 34                	js     0x738
     704:	a0 01 0c             	mov    al,ds:0xc01
     707:	00 09                	add    BYTE PTR [bx+di],cl
     709:	4d                   	dec    bp
     70a:	61                   	popa
     70b:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     710:	75 31                	jne    0x743
     712:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     713:	01 10                	add    WORD PTR [bx+si],dx
     715:	00 08                	add    BYTE PTR [bx+si],cl
     717:	46                   	inc    si
     718:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     71d:	72 31                	jb     0x750
     71f:	a8 01                	test   al,0x1
     721:	10 00                	adc    BYTE PTR [bx+si],al
     723:	08 51 75             	or     BYTE PTR [bx+di+0x75],dl
     726:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
     72b:	31 ac 01 10          	xor    WORD PTR [si+0x1001],bp
     72f:	00 02                	add    BYTE PTR [bp+si],al
     731:	4e                   	dec    si
     732:	31 b0 01 10          	xor    WORD PTR [bx+si+0x1001],si
     736:	00 1b                	add    BYTE PTR [bp+di],bl
     738:	43                   	inc    bx
     739:	6f                   	outs   dx,WORD PTR ds:[si]
     73a:	6e                   	outs   dx,BYTE PTR ds:[si]
     73b:	66 69 67 75 72 61 74 	imul   esp,DWORD PTR [bx+0x75],0x69746172
     742:	69 
     743:	6f                   	outs   dx,WORD PTR ds:[si]
     744:	6e                   	outs   dx,BYTE PTR ds:[si]
     745:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
     748:	69 6d 70 72 65       	imul   bp,WORD PTR [di+0x70],0x6572
     74d:	73 73                	jae    0x7c2
     74f:	69 6f 6e 31 b4       	imul   bp,WORD PTR [bx+0x6e],0xb431
     754:	01 10                	add    WORD PTR [bx+si],dx
     756:	00 09                	add    BYTE PTR [bx+di],cl
     758:	49                   	dec    cx
     759:	6d                   	ins    WORD PTR es:[di],dx
     75a:	70 72                	jo     0x7ce
     75c:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     761:	b8 01 10             	mov    ax,0x1001
     764:	00 08                	add    BYTE PTR [bx+si],cl
     766:	45                   	inc    bp
     767:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     76d:	31 bc 01 10          	xor    WORD PTR [si+0x1001],di
     771:	00 08                	add    BYTE PTR [bx+si],cl
     773:	54                   	push   sp
     774:	61                   	popa
     775:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     778:	61                   	popa
     779:	75 31                	jne    0x7ac
     77b:	c0 01 10             	rol    BYTE PTR [bx+di],0x10
     77e:	00 07                	add    BYTE PTR [bx],al
     780:	47                   	inc    di
     781:	72 61                	jb     0x7e4
     783:	70 68                	jo     0x7ed
     785:	65 31 c4             	gs xor sp,ax
     788:	01 10                	add    WORD PTR [bx+si],dx
     78a:	00 05                	add    BYTE PTR [di],al
     78c:	41                   	inc    cx
     78d:	69 64 65 31 c8       	imul   sp,WORD PTR [si+0x65],0xc831
     792:	01 10                	add    WORD PTR [bx+si],dx
     794:	00 08                	add    BYTE PTR [bx+si],cl
     796:	41                   	inc    cx
     797:	70 72                	jo     0x80b
     799:	6f                   	outs   dx,WORD PTR ds:[si]
     79a:	70 6f                	jo     0x80b
     79c:	73 31                	jae    0x7cf
     79e:	cc                   	int3
     79f:	01 10                	add    WORD PTR [bx+si],dx
     7a1:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     7a5:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     7aa:	72 6c                	jb     0x818
     7ac:	61                   	popa
     7ad:	69 64 65 31 d0       	imul   sp,WORD PTR [si+0x65],0xd031
     7b2:	01 10                	add    WORD PTR [bx+si],dx
     7b4:	00 0b                	add    BYTE PTR [bp+di],cl
     7b6:	52                   	push   dx
     7b7:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     7bb:	72 63                	jb     0x820
     7bd:	68 65 72             	push   0x7265
     7c0:	31 d4                	xor    sp,dx
     7c2:	01 10                	add    WORD PTR [bx+si],dx
     7c4:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     7c8:	64 65 78 31          	fs gs js 0x7fd
     7cc:	d8 01                	fadd   DWORD PTR [bx+di]
     7ce:	10 00                	adc    BYTE PTR [bx+si],al
     7d0:	0a 53 65             	or     dl,BYTE PTR [bp+di+0x65]
     7d3:	6c                   	ins    BYTE PTR es:[di],dx
     7d4:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
     7d8:	6f                   	outs   dx,WORD PTR ds:[si]
     7d9:	6e                   	outs   dx,BYTE PTR ds:[si]
     7da:	31 dc                	xor    sp,bx
     7dc:	01 10                	add    WORD PTR [bx+si],dx
     7de:	00 07                	add    BYTE PTR [bx],al
     7e0:	53                   	push   bx
     7e1:	65 72 69             	gs jb  0x84d
     7e4:	65 73 31             	gs jae 0x818
     7e7:	e0 01                	loopne 0x7ea
     7e9:	10 00                	adc    BYTE PTR [bx+si],al
     7eb:	08 50 72             	or     BYTE PTR [bx+si+0x72],dl
     7ee:	6f                   	outs   dx,WORD PTR ds:[si]
     7ef:	64 75 69             	fs jne 0x85b
     7f2:	74 31                	je     0x825
     7f4:	e4 01                	in     al,0x1
     7f6:	14 00                	adc    al,0x0
     7f8:	13 50 72             	adc    dx,WORD PTR [bx+si+0x72]
     7fb:	69 6e 74 65 72       	imul   bp,WORD PTR [bp+0x74],0x7265
     800:	53                   	push   bx
     801:	65 74 75             	gs je  0x879
     804:	70 44                	jo     0x84a
     806:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     80b:	31 e8                	xor    ax,bp
     80d:	01 18                	add    WORD PTR [bx+si],bx
     80f:	00 0c                	add    BYTE PTR [si],cl
     811:	50                   	push   ax
     812:	72 69                	jb     0x87d
     814:	6e                   	outs   dx,BYTE PTR ds:[si]
     815:	74 44                	je     0x85b
     817:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     81c:	31 ec                	xor    sp,bp
     81e:	01 1c                	add    WORD PTR [si],bx
     820:	00 0b                	add    BYTE PTR [bp+di],cl
     822:	46                   	inc    si
     823:	6f                   	outs   dx,WORD PTR ds:[si]
     824:	6e                   	outs   dx,BYTE PTR ds:[si]
     825:	74 44                	je     0x86b
     827:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     82c:	31 f0                	xor    ax,si
     82e:	01 00                	add    WORD PTR [bx+si],ax
     830:	00 07                	add    BYTE PTR [bx],al
     832:	50                   	push   ax
     833:	61                   	popa
     834:	6e                   	outs   dx,BYTE PTR ds:[si]
     835:	65 6c                	gs ins BYTE PTR es:[di],dx
     837:	31 39                	xor    WORD PTR [bx+di],di
     839:	f4                   	hlt
     83a:	01 00                	add    WORD PTR [bx+si],ax
     83c:	00 07                	add    BYTE PTR [bx],al
     83e:	50                   	push   ax
     83f:	61                   	popa
     840:	6e                   	outs   dx,BYTE PTR ds:[si]
     841:	65 6c                	gs ins BYTE PTR es:[di],dx
     843:	31 30                	xor    WORD PTR [bx+si],si
     845:	f8                   	clc
     846:	01 20                	add    WORD PTR [bx+si],sp
     848:	00 0a                	add    BYTE PTR [bp+si],cl
     84a:	53                   	push   bx
     84b:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
     84e:	6c                   	ins    BYTE PTR es:[di],dx
     84f:	6c                   	ins    BYTE PTR es:[di],dx
     850:	42                   	inc    dx
     851:	61                   	popa
     852:	72 31                	jb     0x885
     854:	fc                   	cld
     855:	01 00                	add    WORD PTR [bx+si],ax
     857:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     85b:	6e                   	outs   dx,BYTE PTR ds:[si]
     85c:	65 6c                	gs ins BYTE PTR es:[di],dx
     85e:	39 00                	cmp    WORD PTR [bx+si],ax
     860:	02 00                	add    al,BYTE PTR [bx+si]
     862:	00 07                	add    BYTE PTR [bx],al
     864:	50                   	push   ax
     865:	61                   	popa
     866:	6e                   	outs   dx,BYTE PTR ds:[si]
     867:	65 6c                	gs ins BYTE PTR es:[di],dx
     869:	31 31                	xor    WORD PTR [bx+di],si
     86b:	04 02                	add    al,0x2
     86d:	00 00                	add    BYTE PTR [bx+si],al
     86f:	07                   	pop    es
     870:	50                   	push   ax
     871:	61                   	popa
     872:	6e                   	outs   dx,BYTE PTR ds:[si]
     873:	65 6c                	gs ins BYTE PTR es:[di],dx
     875:	31 32                	xor    WORD PTR [bp+si],si
     877:	08 02                	or     BYTE PTR [bp+si],al
     879:	08 00                	or     BYTE PTR [bx+si],al
     87b:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     87e:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     883:	78 35                	js     0x8ba
     885:	0c 02                	or     al,0x2
     887:	00 00                	add    BYTE PTR [bx+si],al
     889:	07                   	pop    es
     88a:	50                   	push   ax
     88b:	61                   	popa
     88c:	6e                   	outs   dx,BYTE PTR ds:[si]
     88d:	65 6c                	gs ins BYTE PTR es:[di],dx
     88f:	31 33                	xor    WORD PTR [bp+di],si
     891:	10 02                	adc    BYTE PTR [bp+si],al
     893:	08 00                	or     BYTE PTR [bx+si],al
     895:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     898:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     89d:	78 36                	js     0x8d5
     89f:	14 02                	adc    al,0x2
     8a1:	00 00                	add    BYTE PTR [bx+si],al
     8a3:	07                   	pop    es
     8a4:	50                   	push   ax
     8a5:	61                   	popa
     8a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     8a7:	65 6c                	gs ins BYTE PTR es:[di],dx
     8a9:	31 34                	xor    WORD PTR [si],si
     8ab:	18 02                	sbb    BYTE PTR [bp+si],al
     8ad:	00 00                	add    BYTE PTR [bx+si],al
     8af:	07                   	pop    es
     8b0:	50                   	push   ax
     8b1:	61                   	popa
     8b2:	6e                   	outs   dx,BYTE PTR ds:[si]
     8b3:	65 6c                	gs ins BYTE PTR es:[di],dx
     8b5:	31 35                	xor    WORD PTR [di],si
     8b7:	1c 02                	sbb    al,0x2
     8b9:	08 00                	or     BYTE PTR [bx+si],al
     8bb:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     8be:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     8c3:	78 33                	js     0x8f8
     8c5:	20 02                	and    BYTE PTR [bp+si],al
     8c7:	00 00                	add    BYTE PTR [bx+si],al
     8c9:	07                   	pop    es
     8ca:	50                   	push   ax
     8cb:	61                   	popa
     8cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     8cd:	65 6c                	gs ins BYTE PTR es:[di],dx
     8cf:	31 36 24 02          	xor    WORD PTR ds:0x224,si
     8d3:	00 00                	add    BYTE PTR [bx+si],al
     8d5:	07                   	pop    es
     8d6:	50                   	push   ax
     8d7:	61                   	popa
     8d8:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d9:	65 6c                	gs ins BYTE PTR es:[di],dx
     8db:	31 37                	xor    WORD PTR [bx],si
     8dd:	28 02                	sub    BYTE PTR [bp+si],al
     8df:	08 00                	or     BYTE PTR [bx+si],al
     8e1:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     8e4:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     8e9:	78 32                	js     0x91d
     8eb:	2c 02                	sub    al,0x2
     8ed:	00 00                	add    BYTE PTR [bx+si],al
     8ef:	07                   	pop    es
     8f0:	50                   	push   ax
     8f1:	61                   	popa
     8f2:	6e                   	outs   dx,BYTE PTR ds:[si]
     8f3:	65 6c                	gs ins BYTE PTR es:[di],dx
     8f5:	31 38                	xor    WORD PTR [bx+si],di
     8f7:	30 02                	xor    BYTE PTR [bp+si],al
     8f9:	08 00                	or     BYTE PTR [bx+si],al
     8fb:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     8fe:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     903:	78 31                	js     0x936
     905:	34 02                	xor    al,0x2
     907:	00 00                	add    BYTE PTR [bx+si],al
     909:	06                   	push   es
     90a:	50                   	push   ax
     90b:	61                   	popa
     90c:	6e                   	outs   dx,BYTE PTR ds:[si]
     90d:	65 6c                	gs ins BYTE PTR es:[di],dx
     90f:	35 38 02             	xor    ax,0x238
     912:	10 00                	adc    BYTE PTR [bx+si],al
     914:	08 4f 70             	or     BYTE PTR [bx+0x70],cl
     917:	74 69                	je     0x982
     919:	6f                   	outs   dx,WORD PTR ds:[si]
     91a:	6e                   	outs   dx,BYTE PTR ds:[si]
     91b:	73 31                	jae    0x94e
     91d:	3c 02                	cmp    al,0x2
     91f:	10 00                	adc    BYTE PTR [bx+si],al
     921:	07                   	pop    es
     922:	54                   	push   sp
     923:	69 74 72 65 73       	imul   si,WORD PTR [si+0x72],0x7365
     928:	31 40 02             	xor    WORD PTR [bx+si+0x2],ax
     92b:	10 00                	adc    BYTE PTR [bx+si],al
     92d:	05 48 61             	add    ax,0x6148
     930:	75 74                	jne    0x9a6
     932:	31 44 02             	xor    WORD PTR [si+0x2],ax
     935:	10 00                	adc    BYTE PTR [bx+si],al
     937:	07                   	pop    es
     938:	47                   	inc    di
     939:	61                   	popa
     93a:	75 63                	jne    0x99f
     93c:	68 65 31             	push   0x3165
     93f:	48                   	dec    ax
     940:	02 10                	add    dl,BYTE PTR [bx+si]
     942:	00 07                	add    BYTE PTR [bx],al
     944:	44                   	inc    sp
     945:	72 6f                	jb     0x9b6
     947:	69 74 65 31 4c       	imul   si,WORD PTR [si+0x65],0x4c31
     94c:	02 10                	add    dl,BYTE PTR [bx+si]
     94e:	00 08                	add    BYTE PTR [bx+si],cl
     950:	4c                   	dec    sp
     951:	65 67 65 6e          	gs outs dx,BYTE PTR gs:[esi]
     955:	64 65 31 50 02       	fs xor WORD PTR gs:[bx+si+0x2],dx
     95a:	10 00                	adc    BYTE PTR [bx+si],al
     95c:	06                   	push   es
     95d:	53                   	push   bx
     95e:	65 72 69             	gs jb  0x9ca
     961:	65 31 54 02          	xor    WORD PTR gs:[si+0x2],dx
     965:	10 00                	adc    BYTE PTR [bx+si],al
     967:	06                   	push   es
     968:	53                   	push   bx
     969:	65 72 69             	gs jb  0x9d5
     96c:	65 32 58 02          	xor    bl,BYTE PTR gs:[bx+si+0x2]
     970:	10 00                	adc    BYTE PTR [bx+si],al
     972:	06                   	push   es
     973:	53                   	push   bx
     974:	65 72 69             	gs jb  0x9e0
     977:	65 33 5c 02          	xor    bx,WORD PTR gs:[si+0x2]
     97b:	10 00                	adc    BYTE PTR [bx+si],al
     97d:	06                   	push   es
     97e:	53                   	push   bx
     97f:	65 72 69             	gs jb  0x9eb
     982:	65 34 60             	gs xor al,0x60
     985:	02 10                	add    dl,BYTE PTR [bx+si]
     987:	00 06 53 65          	add    BYTE PTR ds:0x6553,al
     98b:	72 69                	jb     0x9f6
     98d:	65 35 64 02          	gs xor ax,0x264
     991:	10 00                	adc    BYTE PTR [bx+si],al
     993:	06                   	push   es
     994:	53                   	push   bx
     995:	65 72 69             	gs jb  0xa01
     998:	65 36 68 02 10       	gs ss push 0x1002
     99d:	00 06 53 65          	add    BYTE PTR ds:0x6553,al
     9a1:	72 69                	jb     0xa0c
     9a3:	65 37                	gs aaa
     9a5:	6c                   	ins    BYTE PTR es:[di],dx
     9a6:	02 10                	add    dl,BYTE PTR [bx+si]
     9a8:	00 06 53 65          	add    BYTE PTR ds:0x6553,al
     9ac:	72 69                	jb     0xa17
     9ae:	65 38 70 02          	cmp    BYTE PTR gs:[bx+si+0x2],dh
     9b2:	10 00                	adc    BYTE PTR [bx+si],al
     9b4:	06                   	push   es
     9b5:	4e                   	dec    si
     9b6:	50                   	push   ax
     9b7:	72 6f                	jb     0xa28
     9b9:	64 31 74 02          	xor    WORD PTR fs:[si+0x2],si
     9bd:	10 00                	adc    BYTE PTR [bx+si],al
     9bf:	06                   	push   es
     9c0:	4e                   	dec    si
     9c1:	50                   	push   ax
     9c2:	72 6f                	jb     0xa33
     9c4:	64 32 78 02          	xor    bh,BYTE PTR fs:[bx+si+0x2]
     9c8:	10 00                	adc    BYTE PTR [bx+si],al
     9ca:	0c 42                	or     al,0x42
     9cc:	61                   	popa
     9cd:	72 72                	jb     0xa41
     9cf:	65 4f                	gs dec di
     9d1:	75 74                	jne    0xa47
     9d3:	69 6c 73 31 7c       	imul   bp,WORD PTR [si+0x73],0x7c31
     9d8:	02 10                	add    dl,BYTE PTR [bx+si]
     9da:	00 04                	add    BYTE PTR [si],al
     9dc:	42                   	inc    dx
     9dd:	61                   	popa
     9de:	73 31                	jae    0xa11
     9e0:	80 02 10             	add    BYTE PTR [bp+si],0x10
     9e3:	00 0a                	add    BYTE PTR [bp+si],cl
     9e5:	42                   	inc    dx
     9e6:	61                   	popa
     9e7:	72 72                	jb     0xa5b
     9e9:	65 45                	gs inc bp
     9eb:	74 61                	je     0xa4e
     9ed:	74 31                	je     0xa20
     9ef:	84 02                	test   BYTE PTR [bp+si],al
     9f1:	24 00                	and    al,0x0
     9f3:	0a 50 6f             	or     dl,BYTE PTR [bx+si+0x6f]
     9f6:	70 75                	jo     0xa6d
     9f8:	70 4d                	jo     0xa47
     9fa:	65 6e                	outs   dx,BYTE PTR gs:[si]
     9fc:	75 31                	jne    0xa2f
     9fe:	88 02                	mov    BYTE PTR [bp+si],al
     a00:	10 00                	adc    BYTE PTR [bx+si],al
     a02:	07                   	pop    es
     a03:	54                   	push   sp
     a04:	69 74 72 65 73       	imul   si,WORD PTR [si+0x72],0x7365
     a09:	33 8c 02 10          	xor    cx,WORD PTR [si+0x1002]
     a0d:	00 04                	add    BYTE PTR [si],al
     a0f:	42                   	inc    dx
     a10:	61                   	popa
     a11:	73 33                	jae    0xa46
     a13:	90                   	nop
     a14:	02 10                	add    dl,BYTE PTR [bx+si]
     a16:	00 07                	add    BYTE PTR [bx],al
     a18:	44                   	inc    sp
     a19:	72 6f                	jb     0xa8a
     a1b:	69 74 65 33 94       	imul   si,WORD PTR [si+0x65],0x9433
     a20:	02 10                	add    dl,BYTE PTR [bx+si]
     a22:	00 07                	add    BYTE PTR [bx],al
     a24:	47                   	inc    di
     a25:	61                   	popa
     a26:	75 63                	jne    0xa8b
     a28:	68 65 33             	push   0x3365
     a2b:	98                   	cbw
     a2c:	02 10                	add    dl,BYTE PTR [bx+si]
     a2e:	00 05                	add    BYTE PTR [di],al
     a30:	48                   	dec    ax
     a31:	61                   	popa
     a32:	75 74                	jne    0xaa8
     a34:	33 9c 02 10          	xor    bx,WORD PTR [si+0x1002]
     a38:	00 08                	add    BYTE PTR [bx+si],cl
     a3a:	4c                   	dec    sp
     a3b:	65 67 65 6e          	gs outs dx,BYTE PTR gs:[esi]
     a3f:	64 65 32 a0 02 10    	fs xor ah,BYTE PTR gs:[bx+si+0x1002]
     a45:	00 0c                	add    BYTE PTR [si],cl
     a47:	42                   	inc    dx
     a48:	61                   	popa
     a49:	72 72                	jb     0xabd
     a4b:	65 4f                	gs dec di
     a4d:	75 74                	jne    0xac3
     a4f:	69 6c 73 32 a4       	imul   bp,WORD PTR [si+0x73],0xa432
     a54:	02 10                	add    dl,BYTE PTR [bx+si]
     a56:	00 0a                	add    BYTE PTR [bp+si],cl
     a58:	42                   	inc    dx
     a59:	61                   	popa
     a5a:	72 72                	jb     0xace
     a5c:	65 45                	gs inc bp
     a5e:	74 61                	je     0xac1
     a60:	74 32                	je     0xa94
     a62:	a8 02                	test   al,0x2
     a64:	10 00                	adc    BYTE PTR [bx+si],al
     a66:	02 4e 32             	add    cl,BYTE PTR [bp+0x32]
     a69:	ac                   	lods   al,BYTE PTR ds:[si]
     a6a:	02 10                	add    dl,BYTE PTR [bx+si]
     a6c:	00 0b                	add    BYTE PTR [bp+di],cl
     a6e:	43                   	inc    bx
     a6f:	61                   	popa
     a70:	72 61                	jb     0xad3
     a72:	63 74 65             	arpl   WORD PTR [si+0x65],si
     a75:	72 65                	jb     0xadc
     a77:	73 31                	jae    0xaaa
     a79:	b0 02                	mov    al,0x2
     a7b:	10 00                	adc    BYTE PTR [bx+si],al
     a7d:	07                   	pop    es
     a7e:	54                   	push   sp
     a7f:	69 74 72 65 73       	imul   si,WORD PTR [si+0x72],0x7365
     a84:	32 b4 02 10          	xor    dh,BYTE PTR [si+0x1002]
     a88:	00 04                	add    BYTE PTR [si],al
     a8a:	42                   	inc    dx
     a8b:	61                   	popa
     a8c:	73 32                	jae    0xac0
     a8e:	b8 02 10             	mov    ax,0x1002
     a91:	00 07                	add    BYTE PTR [bx],al
     a93:	44                   	inc    sp
     a94:	72 6f                	jb     0xb05
     a96:	69 74 65 32 bc       	imul   si,WORD PTR [si+0x65],0xbc32
     a9b:	02 10                	add    dl,BYTE PTR [bx+si]
     a9d:	00 07                	add    BYTE PTR [bx],al
     a9f:	47                   	inc    di
     aa0:	61                   	popa
     aa1:	75 63                	jne    0xb06
     aa3:	68 65 32             	push   0x3265
     aa6:	c0 02 10             	rol    BYTE PTR [bp+si],0x10
     aa9:	00 05                	add    BYTE PTR [di],al
     aab:	48                   	dec    ax
     aac:	61                   	popa
     aad:	75 74                	jne    0xb23
     aaf:	32 c4                	xor    al,ah
     ab1:	02 10                	add    dl,BYTE PTR [bx+si]
     ab3:	00 02                	add    BYTE PTR [bp+si],al
     ab5:	4e                   	dec    si
     ab6:	33 c8                	xor    cx,ax
     ab8:	02 10                	add    dl,BYTE PTR [bx+si]
     aba:	00 07                	add    BYTE PTR [bx],al
     abc:	43                   	inc    bx
     abd:	6f                   	outs   dx,WORD PTR ds:[si]
     abe:	70 69                	jo     0xb29
     ac0:	65 72 31             	gs jb  0xaf4
     ac3:	cc                   	int3
     ac4:	02 28                	add    ch,BYTE PTR [bx+si]
     ac6:	00 05                	add    BYTE PTR [di],al
     ac8:	4d                   	dec    bp
     ac9:	65 6d                	gs ins WORD PTR es:[di],dx
     acb:	6f                   	outs   dx,WORD PTR ds:[si]
     acc:	31 d0                	xor    ax,dx
     ace:	02 2c                	add    ch,BYTE PTR [si]
     ad0:	00 08                	add    BYTE PTR [bx+si],cl
     ad2:	54                   	push   sp
     ad3:	61                   	popa
     ad4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ad7:	41                   	inc    cx
     ad8:	44                   	inc    sp
     ad9:	47                   	inc    di
     ada:	d4 02                	aam    0x2
     adc:	2c 00                	sub    al,0x0
     ade:	08 54 61             	or     BYTE PTR [si+0x61],dl
     ae1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ae4:	41                   	inc    cx
     ae5:	44                   	inc    sp
     ae6:	50                   	push   ax
     ae7:	d8 02                	fadd   DWORD PTR [bp+si]
     ae9:	2c 00                	sub    al,0x0
     aeb:	08 54 61             	or     BYTE PTR [si+0x61],dl
     aee:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     af1:	45                   	inc    bp
     af2:	44                   	inc    sp
     af3:	47                   	inc    di
     af4:	dc 02                	fadd   QWORD PTR [bp+si]
     af6:	2c 00                	sub    al,0x0
     af8:	08 54 61             	or     BYTE PTR [si+0x61],dl
     afb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     afe:	45                   	inc    bp
     aff:	44                   	inc    sp
     b00:	50                   	push   ax
     b01:	e0 02                	loopne 0xb05
     b03:	2c 00                	sub    al,0x0
     b05:	08 54 61             	or     BYTE PTR [si+0x61],dl
     b08:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b0b:	45                   	inc    bp
     b0c:	52                   	push   dx
     b0d:	47                   	inc    di
     b0e:	e4 02                	in     al,0x2
     b10:	2c 00                	sub    al,0x0
     b12:	08 54 61             	or     BYTE PTR [si+0x61],dl
     b15:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b18:	45                   	inc    bp
     b19:	52                   	push   dx
     b1a:	50                   	push   ax
     b1b:	e8 02 2c             	call   0x3720
     b1e:	00 08                	add    BYTE PTR [bx+si],cl
     b20:	54                   	push   sp
     b21:	61                   	popa
     b22:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b25:	4d                   	dec    bp
     b26:	52                   	push   dx
     b27:	50                   	push   ax
     b28:	ec                   	in     al,dx
     b29:	02 10                	add    dl,BYTE PTR [bx+si]
     b2b:	00 06 65 73          	add    BYTE PTR ds:0x7365,al
     b2f:	73 61                	jae    0xb92
     b31:	69 31 f0 02          	imul   si,WORD PTR [bx+di],0x2f0
     b35:	10 00                	adc    BYTE PTR [bx+si],al
     b37:	08 54 61             	or     BYTE PTR [si+0x61],dl
     b3a:	42                   	inc    dx
     b3b:	6c                   	ins    BYTE PTR es:[di],dx
     b3c:	65 61                	gs popa
     b3e:	75 32                	jne    0xb72
     b40:	f4                   	hlt
     b41:	02 10                	add    dl,BYTE PTR [bx+si]
     b43:	00 0a                	add    BYTE PTR [bp+si],cl
     b45:	42                   	inc    dx
     b46:	61                   	popa
     b47:	72 72                	jb     0xbbb
     b49:	65 45                	gs inc bp
     b4b:	74 61                	je     0xbae
     b4d:	74 33                	je     0xb82
     b4f:	f8                   	clc
     b50:	02 10                	add    dl,BYTE PTR [bx+si]
     b52:	00 07                	add    BYTE PTR [bx],al
     b54:	53                   	push   bx
     b55:	75 6a                	jne    0xbc1
     b57:	65 74 73             	gs je  0xbcd
     b5a:	31 fc                	xor    sp,di
     b5c:	02 10                	add    dl,BYTE PTR [bx+si]
     b5e:	00 07                	add    BYTE PTR [bx],al
     b60:	53                   	push   bx
     b61:	75 6a                	jne    0xbcd
     b63:	65 74 31             	gs je  0xb97
     b66:	31 00                	xor    WORD PTR [bx+si],ax
     b68:	03 10                	add    dx,WORD PTR [bx+si]
     b6a:	00 07                	add    BYTE PTR [bx],al
     b6c:	53                   	push   bx
     b6d:	75 6a                	jne    0xbd9
     b6f:	65 74 31             	gs je  0xba3
     b72:	32 04                	xor    al,BYTE PTR [si]
     b74:	03 10                	add    dx,WORD PTR [bx+si]
     b76:	00 07                	add    BYTE PTR [bx],al
     b78:	53                   	push   bx
     b79:	75 6a                	jne    0xbe5
     b7b:	65 74 31             	gs je  0xbaf
     b7e:	33 08                	xor    cx,WORD PTR [bx+si]
     b80:	03 10                	add    dx,WORD PTR [bx+si]
     b82:	00 07                	add    BYTE PTR [bx],al
     b84:	53                   	push   bx
     b85:	75 6a                	jne    0xbf1
     b87:	65 74 31             	gs je  0xbbb
     b8a:	34 0c                	xor    al,0xc
     b8c:	03 10                	add    dx,WORD PTR [bx+si]
     b8e:	00 07                	add    BYTE PTR [bx],al
     b90:	53                   	push   bx
     b91:	75 6a                	jne    0xbfd
     b93:	65 74 31             	gs je  0xbc7
     b96:	35 10 03             	xor    ax,0x310
     b99:	10 00                	adc    BYTE PTR [bx+si],al
     b9b:	07                   	pop    es
     b9c:	53                   	push   bx
     b9d:	75 6a                	jne    0xc09
     b9f:	65 74 31             	gs je  0xbd3
     ba2:	36 14 03             	ss adc al,0x3
     ba5:	10 00                	adc    BYTE PTR [bx+si],al
     ba7:	07                   	pop    es
     ba8:	53                   	push   bx
     ba9:	75 6a                	jne    0xc15
     bab:	65 74 31             	gs je  0xbdf
     bae:	37                   	aaa
     baf:	18 03                	sbb    BYTE PTR [bp+di],al
     bb1:	10 00                	adc    BYTE PTR [bx+si],al
     bb3:	07                   	pop    es
     bb4:	53                   	push   bx
     bb5:	75 6a                	jne    0xc21
     bb7:	65 74 31             	gs je  0xbeb
     bba:	38 1c                	cmp    BYTE PTR [si],bl
     bbc:	03 10                	add    dx,WORD PTR [bx+si]
     bbe:	00 08                	add    BYTE PTR [bx+si],cl
     bc0:	53                   	push   bx
     bc1:	65 67 6d             	gs ins WORD PTR es:[edi],dx
     bc4:	65 6e                	outs   dx,BYTE PTR gs:[si]
     bc6:	74 31                	je     0xbf9
     bc8:	20 03                	and    BYTE PTR [bp+di],al
     bca:	10 00                	adc    BYTE PTR [bx+si],al
     bcc:	06                   	push   es
     bcd:	4e                   	dec    si
     bce:	53                   	push   bx
     bcf:	65 67 74 31          	gs addr32 je 0xc04
     bd3:	24 03                	and    al,0x3
     bd5:	10 00                	adc    BYTE PTR [bx+si],al
     bd7:	06                   	push   es
     bd8:	4e                   	dec    si
     bd9:	53                   	push   bx
     bda:	65 67 74 32          	gs addr32 je 0xc10
     bde:	28 03                	sub    BYTE PTR [bp+di],al
     be0:	10 00                	adc    BYTE PTR [bx+si],al
     be2:	06                   	push   es
     be3:	4e                   	dec    si
     be4:	73 65                	jae    0xc4b
     be6:	67 74 33             	addr32 je 0xc1c
     be9:	2c 03                	sub    al,0x3
     beb:	10 00                	adc    BYTE PTR [bx+si],al
     bed:	07                   	pop    es
     bee:	53                   	push   bx
     bef:	75 6a                	jne    0xc5b
     bf1:	65 74 73             	gs je  0xc67
     bf4:	32 30                	xor    dh,BYTE PTR [bx+si]
     bf6:	03 10                	add    dx,WORD PTR [bx+si]
     bf8:	00 07                	add    BYTE PTR [bx],al
     bfa:	53                   	push   bx
     bfb:	75 6a                	jne    0xc67
     bfd:	65 74 32             	gs je  0xc32
     c00:	38 34                	cmp    BYTE PTR [si],dh
     c02:	03 10                	add    dx,WORD PTR [bx+si]
     c04:	00 07                	add    BYTE PTR [bx],al
     c06:	53                   	push   bx
     c07:	75 6a                	jne    0xc73
     c09:	65 74 32             	gs je  0xc3e
     c0c:	37                   	aaa
     c0d:	38 03                	cmp    BYTE PTR [bp+di],al
     c0f:	10 00                	adc    BYTE PTR [bx+si],al
     c11:	07                   	pop    es
     c12:	53                   	push   bx
     c13:	75 6a                	jne    0xc7f
     c15:	65 74 32             	gs je  0xc4a
     c18:	36 3c 03             	ss cmp al,0x3
     c1b:	10 00                	adc    BYTE PTR [bx+si],al
     c1d:	07                   	pop    es
     c1e:	53                   	push   bx
     c1f:	75 6a                	jne    0xc8b
     c21:	65 74 32             	gs je  0xc56
     c24:	35 40 03             	xor    ax,0x340
     c27:	10 00                	adc    BYTE PTR [bx+si],al
     c29:	07                   	pop    es
     c2a:	53                   	push   bx
     c2b:	75 6a                	jne    0xc97
     c2d:	65 74 32             	gs je  0xc62
     c30:	34 44                	xor    al,0x44
     c32:	03 10                	add    dx,WORD PTR [bx+si]
     c34:	00 07                	add    BYTE PTR [bx],al
     c36:	53                   	push   bx
     c37:	75 6a                	jne    0xca3
     c39:	65 74 32             	gs je  0xc6e
     c3c:	33 48 03             	xor    cx,WORD PTR [bx+si+0x3]
     c3f:	10 00                	adc    BYTE PTR [bx+si],al
     c41:	07                   	pop    es
     c42:	53                   	push   bx
     c43:	75 6a                	jne    0xcaf
     c45:	65 74 32             	gs je  0xc7a
     c48:	32 4c 03             	xor    cl,BYTE PTR [si+0x3]
     c4b:	10 00                	adc    BYTE PTR [bx+si],al
     c4d:	07                   	pop    es
     c4e:	53                   	push   bx
     c4f:	75 6a                	jne    0xcbb
     c51:	65 74 32             	gs je  0xc86
     c54:	31 50 03             	xor    WORD PTR [bx+si+0x3],dx
     c57:	10 00                	adc    BYTE PTR [bx+si],al
     c59:	07                   	pop    es
     c5a:	53                   	push   bx
     c5b:	75 6a                	jne    0xcc7
     c5d:	65 74 73             	gs je  0xcd3
     c60:	33 54 03             	xor    dx,WORD PTR [si+0x3]
     c63:	10 00                	adc    BYTE PTR [bx+si],al
     c65:	07                   	pop    es
     c66:	53                   	push   bx
     c67:	75 6a                	jne    0xcd3
     c69:	65 74 33             	gs je  0xc9f
     c6c:	38 58 03             	cmp    BYTE PTR [bx+si+0x3],bl
     c6f:	10 00                	adc    BYTE PTR [bx+si],al
     c71:	07                   	pop    es
     c72:	53                   	push   bx
     c73:	75 6a                	jne    0xcdf
     c75:	65 74 33             	gs je  0xcab
     c78:	37                   	aaa
     c79:	5c                   	pop    sp
     c7a:	03 10                	add    dx,WORD PTR [bx+si]
     c7c:	00 07                	add    BYTE PTR [bx],al
     c7e:	53                   	push   bx
     c7f:	75 6a                	jne    0xceb
     c81:	65 74 33             	gs je  0xcb7
     c84:	36 60                	ss pusha
     c86:	03 10                	add    dx,WORD PTR [bx+si]
     c88:	00 07                	add    BYTE PTR [bx],al
     c8a:	53                   	push   bx
     c8b:	75 6a                	jne    0xcf7
     c8d:	65 74 33             	gs je  0xcc3
     c90:	35 64 03             	xor    ax,0x364
     c93:	10 00                	adc    BYTE PTR [bx+si],al
     c95:	07                   	pop    es
     c96:	53                   	push   bx
     c97:	75 6a                	jne    0xd03
     c99:	65 74 33             	gs je  0xccf
     c9c:	34 68                	xor    al,0x68
     c9e:	03 10                	add    dx,WORD PTR [bx+si]
     ca0:	00 07                	add    BYTE PTR [bx],al
     ca2:	53                   	push   bx
     ca3:	75 6a                	jne    0xd0f
     ca5:	65 74 33             	gs je  0xcdb
     ca8:	33 6c 03             	xor    bp,WORD PTR [si+0x3]
     cab:	10 00                	adc    BYTE PTR [bx+si],al
     cad:	07                   	pop    es
     cae:	53                   	push   bx
     caf:	75 6a                	jne    0xd1b
     cb1:	65 74 33             	gs je  0xce7
     cb4:	32 70 03             	xor    dh,BYTE PTR [bx+si+0x3]
     cb7:	10 00                	adc    BYTE PTR [bx+si],al
     cb9:	07                   	pop    es
     cba:	53                   	push   bx
     cbb:	75 6a                	jne    0xd27
     cbd:	65 74 33             	gs je  0xcf3
     cc0:	31 74 03             	xor    WORD PTR [si+0x3],si
     cc3:	10 00                	adc    BYTE PTR [bx+si],al
     cc5:	0b 45 6e             	or     ax,WORD PTR [di+0x6e]
     cc8:	74 72                	je     0xd3c
     cca:	65 70 72             	gs jo  0xd3f
     ccd:	69 73 65 31 78       	imul   si,WORD PTR [bp+di+0x65],0x7831
     cd2:	03 10                	add    dx,WORD PTR [bx+si]
     cd4:	00 05                	add    BYTE PTR [di],al
     cd6:	4e                   	dec    si
     cd7:	45                   	inc    bp
     cd8:	6e                   	outs   dx,BYTE PTR ds:[si]
     cd9:	74 31                	je     0xd0c
     cdb:	7c 03                	jl     0xce0
     cdd:	10 00                	adc    BYTE PTR [bx+si],al
     cdf:	05 4e 45             	add    ax,0x454e
     ce2:	6e                   	outs   dx,BYTE PTR ds:[si]
     ce3:	74 32                	je     0xd17
     ce5:	80 03 10             	add    BYTE PTR [bp+di],0x10
     ce8:	00 05                	add    BYTE PTR [di],al
     cea:	4e                   	dec    si
     ceb:	45                   	inc    bp
     cec:	6e                   	outs   dx,BYTE PTR ds:[si]
     ced:	74 33                	je     0xd22
     cef:	84 03                	test   BYTE PTR [bp+di],al
     cf1:	10 00                	adc    BYTE PTR [bx+si],al
     cf3:	05 4e 45             	add    ax,0x454e
     cf6:	6e                   	outs   dx,BYTE PTR ds:[si]
     cf7:	74 34                	je     0xd2d
     cf9:	88 03                	mov    BYTE PTR [bp+di],al
     cfb:	10 00                	adc    BYTE PTR [bx+si],al
     cfd:	05 4e 45             	add    ax,0x454e
     d00:	6e                   	outs   dx,BYTE PTR ds:[si]
     d01:	74 35                	je     0xd38
     d03:	8c 03                	mov    WORD PTR [bp+di],es
     d05:	10 00                	adc    BYTE PTR [bx+si],al
     d07:	05 4e 65             	add    ax,0x654e
     d0a:	6e                   	outs   dx,BYTE PTR ds:[si]
     d0b:	74 36                	je     0xd43
     d0d:	90                   	nop
     d0e:	03 10                	add    dx,WORD PTR [bx+si]
     d10:	00 05                	add    BYTE PTR [di],al
     d12:	4e                   	dec    si
     d13:	45                   	inc    bp
     d14:	6e                   	outs   dx,BYTE PTR ds:[si]
     d15:	74 37                	je     0xd4e
     d17:	94                   	xchg   sp,ax
     d18:	03 10                	add    dx,WORD PTR [bx+si]
     d1a:	00 05                	add    BYTE PTR [di],al
     d1c:	4e                   	dec    si
     d1d:	45                   	inc    bp
     d1e:	6e                   	outs   dx,BYTE PTR ds:[si]
     d1f:	74 38                	je     0xd59
     d21:	98                   	cbw
     d22:	03 10                	add    dx,WORD PTR [bx+si]
     d24:	00 0d                	add    BYTE PTR [di],cl
     d26:	54                   	push   sp
     d27:	6f                   	outs   dx,WORD PTR ds:[si]
     d28:	75 73                	jne    0xd9d
     d2a:	53                   	push   bx
     d2b:	65 67 6d             	gs ins WORD PTR es:[edi],dx
     d2e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     d30:	74 73                	je     0xda5
     d32:	31 9c 03 10          	xor    WORD PTR [si+0x1003],bx
     d36:	00 12                	add    BYTE PTR [bp+si],dl
     d38:	54                   	push   sp
     d39:	6f                   	outs   dx,WORD PTR ds:[si]
     d3a:	75 74                	jne    0xdb0
     d3c:	65 73 45             	gs jae 0xd84
     d3f:	6e                   	outs   dx,BYTE PTR ds:[si]
     d40:	74 72                	je     0xdb4
     d42:	65 70 72             	gs jo  0xdb7
     d45:	69 73 65 73 31       	imul   si,WORD PTR [bp+di+0x65],0x3173
     d4a:	a0 03 10             	mov    al,ds:0x1003
     d4d:	00 0d                	add    BYTE PTR [di],cl
     d4f:	54                   	push   sp
     d50:	6f                   	outs   dx,WORD PTR ds:[si]
     d51:	75 73                	jne    0xdc6
     d53:	70 72                	jo     0xdc7
     d55:	6f                   	outs   dx,WORD PTR ds:[si]
     d56:	64 75 69             	fs jne 0xdc2
     d59:	74 73                	je     0xdce
     d5b:	31 a4 03 10          	xor    WORD PTR [si+0x1003],sp
     d5f:	00 07                	add    BYTE PTR [bx],al
     d61:	53                   	push   bx
     d62:	75 6a                	jne    0xdce
     d64:	65 74 31             	gs je  0xd98
     d67:	39 a8 03 10          	cmp    WORD PTR [bx+si+0x1003],bp
     d6b:	00 07                	add    BYTE PTR [bx],al
     d6d:	53                   	push   bx
     d6e:	75 6a                	jne    0xdda
     d70:	65 74 32             	gs je  0xda5
     d73:	39 ac 03 10          	cmp    WORD PTR [si+0x1003],bp
     d77:	00 07                	add    BYTE PTR [bx],al
     d79:	53                   	push   bx
     d7a:	75 6a                	jne    0xde6
     d7c:	65 74 33             	gs je  0xdb2
     d7f:	39 b0 03 10          	cmp    WORD PTR [bx+si+0x1003],si
     d83:	00 06 53 65          	add    BYTE PTR ds:0x6553,al
     d87:	72 69                	jb     0xdf2
     d89:	65 39 b4 03 10       	cmp    WORD PTR gs:[si+0x1003],si
     d8e:	00 08                	add    BYTE PTR [bx+si],cl
     d90:	45                   	inc    bp
     d91:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     d94:	6c                   	ins    BYTE PTR es:[di],dx
     d95:	6c                   	ins    BYTE PTR es:[di],dx
     d96:	65 31 b8 03 10       	xor    WORD PTR gs:[bx+si+0x1003],di
     d9b:	00 08                	add    BYTE PTR [bx+si],cl
     d9d:	42                   	inc    dx
     d9e:	6c                   	ins    BYTE PTR es:[di],dx
     d9f:	6f                   	outs   dx,WORD PTR ds:[si]
     da0:	71 75                	jno    0xe17
     da2:	65 72 31             	gs jb  0xdd6
     da5:	bc 03 10             	mov    sp,0x1003
     da8:	00 08                	add    BYTE PTR [bx+si],cl
     daa:	44                   	inc    sp
     dab:	65 6d                	gs ins WORD PTR es:[di],dx
     dad:	61                   	popa
     dae:	6e                   	outs   dx,BYTE PTR ds:[si]
     daf:	64 65 31 c0          	fs gs xor ax,ax
     db3:	03 10                	add    dx,WORD PTR [bx+si]
     db5:	00 13                	add    BYTE PTR [bp+di],dl
     db7:	44                   	inc    sp
     db8:	65 6d                	gs ins WORD PTR es:[di],dx
     dba:	61                   	popa
     dbb:	6e                   	outs   dx,BYTE PTR ds:[si]
     dbc:	64 65 53             	fs gs push bx
     dbf:	75 72                	jne    0xe33
     dc1:	6c                   	ins    BYTE PTR es:[di],dx
     dc2:	65 4d                	gs dec bp
     dc4:	61                   	popa
     dc5:	72 63                	jb     0xe2a
     dc7:	68 65 31             	push   0x3165
     dca:	c4 03                	les    ax,DWORD PTR [bp+di]
     dcc:	10 00                	adc    BYTE PTR [bx+si],al
     dce:	15 44 65             	adc    ax,0x6544
     dd1:	6d                   	ins    WORD PTR es:[di],dx
     dd2:	61                   	popa
     dd3:	6e                   	outs   dx,BYTE PTR ds:[si]
     dd4:	64 65 50             	fs gs push ax
     dd7:	61                   	popa
     dd8:	72 45                	jb     0xe1f
     dda:	6e                   	outs   dx,BYTE PTR ds:[si]
     ddb:	74 72                	je     0xe4f
     ddd:	65 70 72             	gs jo  0xe52
     de0:	69 73 65 31 c8       	imul   si,WORD PTR [bp+di+0x65],0xc831
     de5:	03 10                	add    dx,WORD PTR [bx+si]
     de7:	00 07                	add    BYTE PTR [bx],al
     de9:	56                   	push   si
     dea:	65 6e                	outs   dx,BYTE PTR gs:[si]
     dec:	74 65                	je     0xe53
     dee:	73 31                	jae    0xe21
     df0:	cc                   	int3
     df1:	03 10                	add    dx,WORD PTR [bx+si]
     df3:	00 11                	add    BYTE PTR [bx+di],dl
     df5:	56                   	push   si
     df6:	65 6e                	outs   dx,BYTE PTR gs:[si]
     df8:	74 65                	je     0xe5f
     dfa:	73 50                	jae    0xe4c
     dfc:	61                   	popa
     dfd:	72 50                	jb     0xe4f
     dff:	72 6f                	jb     0xe70
     e01:	64 75 69             	fs jne 0xe6d
     e04:	74 31                	je     0xe37
     e06:	d0 03                	rol    BYTE PTR [bp+di],1
     e08:	10 00                	adc    BYTE PTR [bx+si],al
     e0a:	14 56                	adc    al,0x56
     e0c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     e0e:	74 65                	je     0xe75
     e10:	73 50                	jae    0xe62
     e12:	61                   	popa
     e13:	72 45                	jb     0xe5a
     e15:	6e                   	outs   dx,BYTE PTR ds:[si]
     e16:	74 72                	je     0xe8a
     e18:	65 70 72             	gs jo  0xe8d
     e1b:	69 73 65 31 d4       	imul   si,WORD PTR [bp+di+0x65],0xd431
     e20:	03 10                	add    dx,WORD PTR [bx+si]
     e22:	00 19                	add    BYTE PTR [bx+di],bl
     e24:	50                   	push   ax
     e25:	61                   	popa
     e26:	72 74                	jb     0xe9c
     e28:	73 4d                	jae    0xe77
     e2a:	61                   	popa
     e2b:	72 63                	jb     0xe90
     e2d:	68 65 50             	push   0x5065
     e30:	61                   	popa
     e31:	72 45                	jb     0xe78
     e33:	6e                   	outs   dx,BYTE PTR ds:[si]
     e34:	74 72                	je     0xea8
     e36:	65 70 72             	gs jo  0xeab
     e39:	69 73 65 31 d8       	imul   si,WORD PTR [bp+di+0x65],0xd831
     e3e:	03 10                	add    dx,WORD PTR [bx+si]
     e40:	00 0c                	add    BYTE PTR [si],cl
     e42:	52                   	push   dx
     e43:	65 73 75             	gs jae 0xebb
     e46:	6c                   	ins    BYTE PTR es:[di],dx
     e47:	74 61                	je     0xeaa
     e49:	74 4e                	je     0xe99
     e4b:	65 74 31             	gs je  0xe7f
     e4e:	dc 03                	fadd   QWORD PTR [bp+di]
     e50:	10 00                	adc    BYTE PTR [bx+si],al
     e52:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
     e55:	e0 03                	loopne 0xe5a
     e57:	10 00                	adc    BYTE PTR [bx+si],al
     e59:	02 4e 35             	add    cl,BYTE PTR [bp+0x35]
     e5c:	e4 03                	in     al,0x3
     e5e:	10 00                	adc    BYTE PTR [bx+si],al
     e60:	06                   	push   es
     e61:	46                   	inc    si
     e62:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     e67:	e8 03 10             	call   0x1e6d
     e6a:	00 02                	add    BYTE PTR [bp+si],al
     e6c:	4e                   	dec    si
     e6d:	36 ec                	ss in  al,dx
     e6f:	03 00                	add    ax,WORD PTR [bx+si]
     e71:	00 0c                	add    BYTE PTR [si],cl
     e73:	50                   	push   ax
     e74:	61                   	popa
     e75:	6e                   	outs   dx,BYTE PTR ds:[si]
     e76:	65 6c                	gs ins BYTE PTR es:[di],dx
     e78:	42                   	inc    dx
     e79:	75 74                	jne    0xeef
     e7b:	74 6f                	je     0xeec
     e7d:	6e                   	outs   dx,BYTE PTR ds:[si]
     e7e:	73 f0                	jae    0xe70
     e80:	03 30                	add    si,WORD PTR [bx+si]
     e82:	00 0c                	add    BYTE PTR [si],cl
     e84:	53                   	push   bx
     e85:	70 65                	jo     0xeec
     e87:	65 64 42             	gs fs inc dx
     e8a:	75 74                	jne    0xf00
     e8c:	74 6f                	je     0xefd
     e8e:	6e                   	outs   dx,BYTE PTR ds:[si]
     e8f:	33 f4                	xor    si,sp
     e91:	03 30                	add    si,WORD PTR [bx+si]
     e93:	00 0c                	add    BYTE PTR [si],cl
     e95:	53                   	push   bx
     e96:	70 65                	jo     0xefd
     e98:	65 64 42             	gs fs inc dx
     e9b:	75 74                	jne    0xf11
     e9d:	74 6f                	je     0xf0e
     e9f:	6e                   	outs   dx,BYTE PTR ds:[si]
     ea0:	34 f8                	xor    al,0xf8
     ea2:	03 30                	add    si,WORD PTR [bx+si]
     ea4:	00 0c                	add    BYTE PTR [si],cl
     ea6:	53                   	push   bx
     ea7:	70 65                	jo     0xf0e
     ea9:	65 64 42             	gs fs inc dx
     eac:	75 74                	jne    0xf22
     eae:	74 6f                	je     0xf1f
     eb0:	6e                   	outs   dx,BYTE PTR ds:[si]
     eb1:	31 fc                	xor    sp,di
     eb3:	03 30                	add    si,WORD PTR [bx+si]
     eb5:	00 0c                	add    BYTE PTR [si],cl
     eb7:	53                   	push   bx
     eb8:	70 65                	jo     0xf1f
     eba:	65 64 42             	gs fs inc dx
     ebd:	75 74                	jne    0xf33
     ebf:	74 6f                	je     0xf30
     ec1:	6e                   	outs   dx,BYTE PTR ds:[si]
     ec2:	39 00                	cmp    WORD PTR [bx+si],ax
     ec4:	04 30                	add    al,0x30
     ec6:	00 0d                	add    BYTE PTR [di],cl
     ec8:	53                   	push   bx
     ec9:	70 65                	jo     0xf30
     ecb:	65 64 42             	gs fs inc dx
     ece:	75 74                	jne    0xf44
     ed0:	74 6f                	je     0xf41
     ed2:	6e                   	outs   dx,BYTE PTR ds:[si]
     ed3:	31 30                	xor    WORD PTR [bx+si],si
     ed5:	04 04                	add    al,0x4
     ed7:	30 00                	xor    BYTE PTR [bx+si],al
     ed9:	0c 53                	or     al,0x53
     edb:	70 65                	jo     0xf42
     edd:	65 64 42             	gs fs inc dx
     ee0:	75 74                	jne    0xf56
     ee2:	74 6f                	je     0xf53
     ee4:	6e                   	outs   dx,BYTE PTR ds:[si]
     ee5:	35 08 04             	xor    ax,0x408
     ee8:	30 00                	xor    BYTE PTR [bx+si],al
     eea:	0c 53                	or     al,0x53
     eec:	70 65                	jo     0xf53
     eee:	65 64 42             	gs fs inc dx
     ef1:	75 74                	jne    0xf67
     ef3:	74 6f                	je     0xf64
     ef5:	6e                   	outs   dx,BYTE PTR ds:[si]
     ef6:	36 0c 04             	ss or  al,0x4
     ef9:	30 00                	xor    BYTE PTR [bx+si],al
     efb:	0c 53                	or     al,0x53
     efd:	70 65                	jo     0xf64
     eff:	65 64 42             	gs fs inc dx
     f02:	75 74                	jne    0xf78
     f04:	74 6f                	je     0xf75
     f06:	6e                   	outs   dx,BYTE PTR ds:[si]
     f07:	32 10                	xor    dl,BYTE PTR [bx+si]
     f09:	04 00                	add    al,0x0
     f0b:	00 0d                	add    BYTE PTR [di],cl
     f0d:	50                   	push   ax
     f0e:	61                   	popa
     f0f:	6e                   	outs   dx,BYTE PTR ds:[si]
     f10:	65 6c                	gs ins BYTE PTR es:[di],dx
     f12:	45                   	inc    bp
     f13:	64 69 74 73 31 32    	imul   si,WORD PTR fs:[si+0x73],0x3231
     f19:	33 14                	xor    dx,WORD PTR [si]
     f1b:	04 34                	add    al,0x34
     f1d:	00 05                	add    BYTE PTR [di],al
     f1f:	45                   	inc    bp
     f20:	64 69 74 31 18 04    	imul   si,WORD PTR fs:[si+0x31],0x418
     f26:	34 00                	xor    al,0x0
     f28:	05 45 64             	add    ax,0x6445
     f2b:	69 74 32 1c 04       	imul   si,WORD PTR [si+0x32],0x41c
     f30:	34 00                	xor    al,0x0
     f32:	05 45 64             	add    ax,0x6445
     f35:	69 74 33 20 04       	imul   si,WORD PTR [si+0x33],0x420
     f3a:	00 00                	add    BYTE PTR [bx+si],al
     f3c:	10 50 61             	adc    BYTE PTR [bx+si+0x61],dl
     f3f:	6e                   	outs   dx,BYTE PTR ds:[si]
     f40:	65 6c                	gs ins BYTE PTR es:[di],dx
     f42:	4c                   	dec    sp
     f43:	61                   	popa
     f44:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     f47:	73 55                	jae    0xf9e
     f49:	30 31                	xor    BYTE PTR [bx+di],dh
     f4b:	32 33                	xor    dh,BYTE PTR [bp+di]
     f4d:	24 04                	and    al,0x4
     f4f:	38 00                	cmp    BYTE PTR [bx+si],al
     f51:	08 4c 61             	or     BYTE PTR [si+0x61],cl
     f54:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     f57:	55                   	push   bp
     f58:	31 32                	xor    WORD PTR [bp+si],si
     f5a:	28 04                	sub    BYTE PTR [si],al
     f5c:	38 00                	cmp    BYTE PTR [bx+si],al
     f5e:	07                   	pop    es
     f5f:	4c                   	dec    sp
     f60:	61                   	popa
     f61:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     f64:	55                   	push   bp
     f65:	33 2c                	xor    bp,WORD PTR [si]
     f67:	04 10                	add    al,0x10
     f69:	00 02                	add    BYTE PTR [bp+si],al
     f6b:	4e                   	dec    si
     f6c:	38 30                	cmp    BYTE PTR [bx+si],dh
     f6e:	04 30                	add    al,0x30
     f70:	00 0c                	add    BYTE PTR [si],cl
     f72:	53                   	push   bx
     f73:	70 65                	jo     0xfda
     f75:	65 64 42             	gs fs inc dx
     f78:	75 74                	jne    0xfee
     f7a:	74 6f                	je     0xfeb
     f7c:	6e                   	outs   dx,BYTE PTR ds:[si]
     f7d:	37                   	aaa
     f7e:	34 04                	xor    al,0x4
     f80:	10 00                	adc    BYTE PTR [bx+si],al
     f82:	02 4e 39             	add    cl,BYTE PTR [bp+0x39]
     f85:	38 04                	cmp    BYTE PTR [si],al
     f87:	10 00                	adc    BYTE PTR [bx+si],al
     f89:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     f8c:	30 3c                	xor    BYTE PTR [si],bh
     f8e:	04 10                	add    al,0x10
     f90:	00 02                	add    BYTE PTR [bp+si],al
     f92:	4e                   	dec    si
     f93:	37                   	aaa
     f94:	40                   	inc    ax
     f95:	04 10                	add    al,0x10
     f97:	00 0e 50 61          	add    BYTE PTR ds:0x6150,cl
     f9b:	72 74                	jb     0x1011
     f9d:	73 64                	jae    0x1003
     f9f:	65 6d                	gs ins WORD PTR es:[di],dx
     fa1:	61                   	popa
     fa2:	72 63                	jb     0x1007
     fa4:	68 65 31             	push   0x3165
     fa7:	44                   	inc    sp
     fa8:	04 10                	add    al,0x10
     faa:	00 16 50 61          	add    BYTE PTR ds:0x6150,dl
     fae:	72 74                	jb     0x1024
     fb0:	73 4d                	jae    0xfff
     fb2:	61                   	popa
     fb3:	72 63                	jb     0x1018
     fb5:	68 65 50             	push   0x5065
     fb8:	61                   	popa
     fb9:	72 50                	jb     0x100b
     fbb:	72 6f                	jb     0x102c
     fbd:	64 75 69             	fs jne 0x1029
     fc0:	74 31                	je     0xff3
     fc2:	48                   	dec    ax
     fc3:	04 10                	add    al,0x10
     fc5:	00 04                	add    BYTE PTR [si],al
     fc7:	4e                   	dec    si
     fc8:	75 6c                	jne    0x1036
     fca:	31 4c 04             	xor    WORD PTR [si+0x4],cx
     fcd:	10 00                	adc    BYTE PTR [bx+si],al
     fcf:	14 44                	adc    al,0x44
     fd1:	65 6d                	gs ins WORD PTR es:[di],dx
     fd3:	52                   	push   dx
     fd4:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
     fd7:	6c                   	ins    BYTE PTR es:[di],dx
     fd8:	65 73 75             	gs jae 0x1050
     fdb:	72 6c                	jb     0x1049
     fdd:	65 6d                	gs ins WORD PTR es:[di],dx
     fdf:	61                   	popa
     fe0:	72 63                	jb     0x1045
     fe2:	68 65 50             	push   0x5065
     fe5:	04 10                	add    al,0x10
     fe7:	00 12                	add    BYTE PTR [bp+si],dl
     fe9:	52                   	push   dx
     fea:	65 73 73             	gs jae 0x1060
     fed:	6f                   	outs   dx,WORD PTR ds:[si]
     fee:	75 72                	jne    0x1062
     ff0:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     ff3:	70 72                	jo     0x1067
     ff5:	6f                   	outs   dx,WORD PTR ds:[si]
     ff6:	70 72                	jo     0x106a
     ff8:	65 73 31             	gs jae 0x102c
     ffb:	54                   	push   sp
     ffc:	04 10                	add    al,0x10
     ffe:	00 10                	add    BYTE PTR [bx+si],dl
    1000:	54                   	push   sp
    1001:	61                   	popa
    1002:	75 78                	jne    0x107c
    1004:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1006:	64 65 74 74          	fs gs je 0x107e
    100a:	65 6d                	gs ins WORD PTR es:[di],dx
    100c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    100e:	74 31                	je     0x1041
    1010:	58                   	pop    ax
    1011:	04 10                	add    al,0x10
    1013:	00 0b                	add    BYTE PTR [bp+di],cl
    1015:	52                   	push   dx
    1016:	73 75                	jae    0x108d
    1018:	6c                   	ins    BYTE PTR es:[di],dx
    1019:	74 61                	je     0x107c
    101b:	74 6e                	je     0x108b
    101d:	65 74 31             	gs je  0x1051
    1020:	0f 00 ad 0d 2c       	verw   WORD PTR [di+0x2c0d]
    1025:	10 4d 0e             	adc    BYTE PTR [di+0xe],cl
    1028:	23 15                	and    dx,WORD PTR [di]
    102a:	22 03                	and    al,BYTE PTR [bp+di]
    102c:	04 2f                	add    al,0x2f
    102e:	ef                   	out    dx,ax
    102f:	02 34                	add    dh,BYTE PTR [si]
    1031:	10 94 00 48          	adc    BYTE PTR [si+0x4800],dl
    1035:	10 2b                	adc    BYTE PTR [bp+di],ch
    1037:	07                   	pop    es
    1038:	3c 10                	cmp    al,0x10
    103a:	7e 08                	jle    0x1044
    103c:	40                   	inc    ax
    103d:	10 de                	adc    dh,bl
    103f:	05 2b 33             	add    ax,0x332b
    1042:	db 38                	fstp   TBYTE PTR [bx+si]
    1044:	4c                   	dec    sp
    1045:	10 c6                	adc    dh,al
    1047:	03 3d                	add    di,WORD PTR [di]
    1049:	11 91 12 58          	adc    WORD PTR [bx+di+0x5812],dx
    104d:	10 38                	adc    BYTE PTR [bx+si],bh
    104f:	01 13                	add    WORD PTR [bp+di],dx
    1051:	31 bb 00 6e          	xor    WORD PTR [bp+di+0x6e00],di
    1055:	27                   	daa
    1056:	90                   	nop
    1057:	0b 5c 10             	or     bx,WORD PTR [si+0x10]
    105a:	17                   	pop    ss
    105b:	06                   	push   es
    105c:	05 2c 07             	add    ax,0x72c
    105f:	0c 54                	or     al,0x54
    1061:	46                   	inc    si
    1062:	6f                   	outs   dx,WORD PTR ds:[si]
    1063:	72 6d                	jb     0x10d2
    1065:	47                   	inc    di
    1066:	72 61                	jb     0x10c9
    1068:	70 68                	jo     0x10d2
    106a:	65 32 22             	xor    ah,BYTE PTR gs:[bp+si]
    106d:	00 85 10 7b          	add    BYTE PTR [di+0x7b10],al
    1071:	06                   	push   es
    1072:	ab                   	stos   WORD PTR es:[di],ax
    1073:	10 38                	adc    BYTE PTR [bx+si],bh
    1075:	00 08                	add    BYTE PTR [bx+si],cl
    1077:	47                   	inc    di
    1078:	72 64                	jb     0x10de
    107a:	75 6e                	jne    0x10ea
    107c:	69 74 32 00 00       	imul   si,WORD PTR [si+0x32],0x0
    1081:	00 00                	add    BYTE PTR [bx+si],al
    1083:	e9 10 a4             	jmp    0xb496
    1086:	10 55 89             	adc    BYTE PTR [di-0x77],dl
    1089:	e5 b8                	in     ax,0xb8
    108b:	08 00                	or     BYTE PTR [bx+si],al
    108d:	9a 44 04 fe 10       	call   0x10fe:0x444
    1092:	83 ec 08             	sub    sp,0x8
    1095:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1099:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    109d:	b0 01                	mov    al,0x1
    109f:	50                   	push   ax
    10a0:	b8 22 00             	mov    ax,0x22
    10a3:	ba 6d 11             	mov    dx,0x116d
    10a6:	52                   	push   dx
    10a7:	50                   	push   ax
    10a8:	9a 53 25 d1 10       	call   0x10d1:0x2553
    10ad:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    10b0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    10b3:	b8 81 10             	mov    ax,0x1081
    10b6:	0e                   	push   cs
    10b7:	50                   	push   ax
    10b8:	55                   	push   bp
    10b9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    10bd:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    10c1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10c4:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    10c7:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    10ca:	6a 02                	push   0x2
    10cc:	06                   	push   es
    10cd:	57                   	push   di
    10ce:	9a 14 3a db 10       	call   0x10db:0x3a14
    10d3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    10d6:	06                   	push   es
    10d7:	57                   	push   di
    10d8:	9a 45 5d f1 10       	call   0x10f1:0x5d45
    10dd:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    10e1:	83 c4 06             	add    sp,0x6
    10e4:	b8 f4 10             	mov    ax,0x10f4
    10e7:	0e                   	push   cs
    10e8:	50                   	push   ax
    10e9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10ec:	06                   	push   es
    10ed:	57                   	push   di
    10ee:	9a 1d 5f 16 11       	call   0x1116:0x5f1d
    10f3:	cb                   	retf
    10f4:	c9                   	leave
    10f5:	cb                   	retf
    10f6:	55                   	push   bp
    10f7:	89 e5                	mov    bp,sp
    10f9:	31 c0                	xor    ax,ax
    10fb:	9a 44 04 2a 11       	call   0x112a:0x444
    1100:	6a 00                	push   0x0
    1102:	9a c2 38 ff ff       	call   0xffff:0x38c2
    1107:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    110a:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    1111:	06                   	push   es
    1112:	57                   	push   di
    1113:	9a 56 55 ca 31       	call   0x31ca:0x5556
    1118:	9a c3 28 90 12       	call   0x1290:0x28c3
    111d:	c9                   	leave
    111e:	ca 04 00             	retf   0x4
    1121:	55                   	push   bp
    1122:	89 e5                	mov    bp,sp
    1124:	b8 08 00             	mov    ax,0x8
    1127:	9a 44 04 47 11       	call   0x1147:0x444
    112c:	83 ec 08             	sub    sp,0x8
    112f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1132:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    1135:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    1138:	06                   	push   es
    1139:	57                   	push   di
    113a:	9a 26 13 66 11       	call   0x1166:0x1326
    113f:	2d 01 00             	sub    ax,0x1
    1142:	71 05                	jno    0x1149
    1144:	9a 3e 04 90 11       	call   0x1190:0x43e
    1149:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    114c:	31 c0                	xor    ax,ax
    114e:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1151:	7f 24                	jg     0x1177
    1153:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1156:	eb 03                	jmp    0x115b
    1158:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    115b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    115e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1161:	06                   	push   es
    1162:	57                   	push   di
    1163:	9a 53 13 81 11       	call   0x1181:0x1353
    1168:	52                   	push   dx
    1169:	50                   	push   ax
    116a:	9a 21 11 da 11       	call   0x11da:0x1121
    116f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1172:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1175:	75 e1                	jne    0x1158
    1177:	6a 00                	push   0x0
    1179:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    117c:	06                   	push   es
    117d:	57                   	push   di
    117e:	9a 75 12 aa 11       	call   0x11aa:0x1275
    1183:	c9                   	leave
    1184:	ca 04 00             	retf   0x4
    1187:	55                   	push   bp
    1188:	89 e5                	mov    bp,sp
    118a:	b8 0c 00             	mov    ax,0xc
    118d:	9a 44 04 b4 11       	call   0x11b4:0x444
    1192:	83 ec 0c             	sub    sp,0xc
    1195:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1198:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    119b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    119e:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    11a2:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    11a5:	06                   	push   es
    11a6:	57                   	push   di
    11a7:	9a 26 13 d3 11       	call   0x11d3:0x1326
    11ac:	2d 01 00             	sub    ax,0x1
    11af:	71 05                	jno    0x11b6
    11b1:	9a 3e 04 36 12       	call   0x1236:0x43e
    11b6:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    11b9:	31 c0                	xor    ax,ax
    11bb:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    11be:	7f 2a                	jg     0x11ea
    11c0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    11c3:	eb 03                	jmp    0x11c8
    11c5:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    11c8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    11cb:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11ce:	06                   	push   es
    11cf:	57                   	push   di
    11d0:	9a 53 13 fa 11       	call   0x11fa:0x1353
    11d5:	52                   	push   dx
    11d6:	50                   	push   ax
    11d7:	9a 87 11 1b 14       	call   0x141b:0x1187
    11dc:	0a 46 fb             	or     al,BYTE PTR [bp-0x5]
    11df:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    11e2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    11e5:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    11e8:	75 db                	jne    0x11c5
    11ea:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    11ee:	74 0e                	je     0x11fe
    11f0:	6a 01                	push   0x1
    11f2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11f5:	06                   	push   es
    11f6:	57                   	push   di
    11f7:	9a 75 12 08 12       	call   0x1208:0x1275
    11fc:	eb 0c                	jmp    0x120a
    11fe:	6a 00                	push   0x0
    1200:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1203:	06                   	push   es
    1204:	57                   	push   di
    1205:	9a 75 12 1c 25       	call   0x251c:0x1275
    120a:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    120d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1210:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1213:	c9                   	leave
    1214:	ca 04 00             	retf   0x4
    1217:	05 25 2a             	add    ax,0x2a25
    121a:	2e 2a 66 05          	sub    ah,BYTE PTR cs:[bp+0x5]
    121e:	25 2a 2e             	and    ax,0x2e2a
    1221:	2a 65 01             	sub    ah,BYTE PTR [di+0x1]
    1224:	2c 00                	sub    al,0x0
    1226:	00 00                	add    BYTE PTR [bx+si],al
    1228:	00 ff                	add    bh,bh
    122a:	00 00                	add    BYTE PTR [bx+si],al
    122c:	00 55 89             	add    BYTE PTR [di-0x77],dl
    122f:	e5 b8                	in     ax,0xb8
    1231:	24 02                	and    al,0x2
    1233:	9a 44 04 9e 12       	call   0x129e:0x444
    1238:	81 ec 24 02          	sub    sp,0x224
    123c:	8d be dc fd          	lea    di,[bp-0x224]
    1240:	16                   	push   ss
    1241:	57                   	push   di
    1242:	bf 17 12             	mov    di,0x1217
    1245:	0e                   	push   cs
    1246:	57                   	push   di
    1247:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    124a:	99                   	cwd
    124b:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    124f:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    1253:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    1258:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    125b:	99                   	cwd
    125c:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    1260:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    1264:	c6 86 e8 fe 00       	mov    BYTE PTR [bp-0x118],0x0
    1269:	9b dd 46 0e          	fld    QWORD PTR [bp+0xe]
    126d:	9b db be f4 fe       	fstp   TBYTE PTR [bp-0x10c]
    1272:	8d 86 f4 fe          	lea    ax,[bp-0x10c]
    1276:	8c d2                	mov    dx,ss
    1278:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    127c:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    1280:	c6 86 f0 fe 03       	mov    BYTE PTR [bp-0x110],0x3
    1285:	8d be dc fe          	lea    di,[bp-0x124]
    1289:	16                   	push   ss
    128a:	57                   	push   di
    128b:	6a 02                	push   0x2
    128d:	9a 34 10 09 13       	call   0x1309:0x1034
    1292:	8d be 00 ff          	lea    di,[bp-0x100]
    1296:	16                   	push   ss
    1297:	57                   	push   di
    1298:	68 ff 00             	push   0xff
    129b:	9a e7 17 d2 12       	call   0x12d2:0x17e7
    12a0:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    12a4:	30 e4                	xor    ah,ah
    12a6:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    12a9:	7e 6e                	jle    0x1319
    12ab:	8d be dc fd          	lea    di,[bp-0x224]
    12af:	16                   	push   ss
    12b0:	57                   	push   di
    12b1:	bf 1d 12             	mov    di,0x121d
    12b4:	0e                   	push   cs
    12b5:	57                   	push   di
    12b6:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    12b9:	99                   	cwd
    12ba:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    12be:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    12c2:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    12c7:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    12ca:	2d 08 00             	sub    ax,0x8
    12cd:	71 05                	jno    0x12d4
    12cf:	9a 3e 04 17 13       	call   0x1317:0x43e
    12d4:	99                   	cwd
    12d5:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    12d9:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    12dd:	c6 86 e8 fe 00       	mov    BYTE PTR [bp-0x118],0x0
    12e2:	9b dd 46 0e          	fld    QWORD PTR [bp+0xe]
    12e6:	9b db be f4 fe       	fstp   TBYTE PTR [bp-0x10c]
    12eb:	8d 86 f4 fe          	lea    ax,[bp-0x10c]
    12ef:	8c d2                	mov    dx,ss
    12f1:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    12f5:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    12f9:	c6 86 f0 fe 03       	mov    BYTE PTR [bp-0x110],0x3
    12fe:	8d be dc fe          	lea    di,[bp-0x124]
    1302:	16                   	push   ss
    1303:	57                   	push   di
    1304:	6a 02                	push   0x2
    1306:	9a 34 10 30 18       	call   0x1830:0x1034
    130b:	8d be 00 ff          	lea    di,[bp-0x100]
    130f:	16                   	push   ss
    1310:	57                   	push   di
    1311:	68 ff 00             	push   0xff
    1314:	9a e7 17 2d 13       	call   0x132d:0x17e7
    1319:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    131e:	75 11                	jne    0x1331
    1320:	8d be 00 ff          	lea    di,[bp-0x100]
    1324:	16                   	push   ss
    1325:	57                   	push   di
    1326:	6a 01                	push   0x1
    1328:	6a 01                	push   0x1
    132a:	9a 75 19 3f 13       	call   0x133f:0x1975
    132f:	eb e8                	jmp    0x1319
    1331:	bf 23 12             	mov    di,0x1223
    1334:	0e                   	push   cs
    1335:	57                   	push   di
    1336:	8d be 00 ff          	lea    di,[bp-0x100]
    133a:	16                   	push   ss
    133b:	57                   	push   di
    133c:	9a 78 18 57 13       	call   0x1357:0x1878
    1341:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1345:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    134a:	7e 14                	jle    0x1360
    134c:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    1350:	99                   	cwd
    1351:	bf 25 12             	mov    di,0x1225
    1354:	9a 16 04 71 13       	call   0x1371:0x416
    1359:	8b f8                	mov    di,ax
    135b:	c6 83 00 ff 2e       	mov    BYTE PTR [bp+di-0x100],0x2e
    1360:	8d be 00 ff          	lea    di,[bp-0x100]
    1364:	16                   	push   ss
    1365:	57                   	push   di
    1366:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    1369:	06                   	push   es
    136a:	57                   	push   di
    136b:	68 ff 00             	push   0xff
    136e:	9a e7 17 88 13       	call   0x1388:0x17e7
    1373:	c9                   	leave
    1374:	ca 10 00             	retf   0x10
    1377:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    137b:	ff                   	(bad)
    137c:	7f 00                	jg     0x137e
    137e:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1381:	e5 b8                	in     ax,0xb8
    1383:	02 00                	add    al,BYTE PTR [bx+si]
    1385:	9a 44 04 aa 13       	call   0x13aa:0x444
    138a:	83 ec 02             	sub    sp,0x2
    138d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1390:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    1395:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    139a:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    139f:	2d 01 00             	sub    ax,0x1
    13a2:	83 da 00             	sbb    dx,0x0
    13a5:	71 05                	jno    0x13ac
    13a7:	9a 3e 04 b2 13       	call   0x13b2:0x43e
    13ac:	bf 77 13             	mov    di,0x1377
    13af:	9a 16 04 cf 13       	call   0x13cf:0x416
    13b4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    13b7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    13ba:	c9                   	leave
    13bb:	ca 04 00             	retf   0x4
    13be:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    13c2:	ff                   	(bad)
    13c3:	7f 00                	jg     0x13c5
    13c5:	00 55 89             	add    BYTE PTR [di-0x77],dl
    13c8:	e5 b8                	in     ax,0xb8
    13ca:	02 00                	add    al,BYTE PTR [bx+si]
    13cc:	9a 44 04 f1 13       	call   0x13f1:0x444
    13d1:	83 ec 02             	sub    sp,0x2
    13d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d7:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    13dc:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    13e1:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    13e6:	2d 01 00             	sub    ax,0x1
    13e9:	83 da 00             	sbb    dx,0x0
    13ec:	71 05                	jno    0x13f3
    13ee:	9a 3e 04 f9 13       	call   0x13f9:0x43e
    13f3:	bf be 13             	mov    di,0x13be
    13f6:	9a 16 04 0e 14       	call   0x140e:0x416
    13fb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    13fe:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1401:	c9                   	leave
    1402:	ca 04 00             	retf   0x4
    1405:	55                   	push   bp
    1406:	89 e5                	mov    bp,sp
    1408:	b8 04 00             	mov    ax,0x4
    140b:	9a 44 04 25 14       	call   0x1425:0x444
    1410:	83 ec 04             	sub    sp,0x4
    1413:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1416:	06                   	push   es
    1417:	57                   	push   di
    1418:	9a c6 13 c3 16       	call   0x16c3:0x13c6
    141d:	05 01 00             	add    ax,0x1
    1420:	71 05                	jno    0x1427
    1422:	9a 3e 04 78 14       	call   0x1478:0x43e
    1427:	8b c8                	mov    cx,ax
    1429:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    142c:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1431:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1435:	99                   	cwd
    1436:	f7 f9                	idiv   cx
    1438:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    143b:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    143f:	7d 05                	jge    0x1446
    1441:	c7 46 fc 14 00       	mov    WORD PTR [bp-0x4],0x14
    1446:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1449:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    144c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    144f:	c9                   	leave
    1450:	ca 04 00             	retf   0x4
    1453:	00 80 e0 37          	add    BYTE PTR [bx+si+0x37e0],al
    1457:	79 c3                	jns    0x141c
    1459:	41                   	inc    cx
    145a:	43                   	inc    bx
    145b:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    145f:	ff                   	(bad)
    1460:	7f 00                	jg     0x1462
    1462:	00 00                	add    BYTE PTR [bx+si],al
    1464:	00 00                	add    BYTE PTR [bx+si],al
    1466:	00 00                	add    BYTE PTR [bx+si],al
    1468:	00 80 3f 00          	add    BYTE PTR [bx+si+0x3f],al
    146c:	00 00                	add    BYTE PTR [bx+si],al
    146e:	40                   	inc    ax
    146f:	55                   	push   bp
    1470:	89 e5                	mov    bp,sp
    1472:	b8 26 01             	mov    ax,0x126
    1475:	9a 44 04 ba 14       	call   0x14ba:0x444
    147a:	81 ec 26 01          	sub    sp,0x126
    147e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1481:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    1486:	89 7e de             	mov    WORD PTR [bp-0x22],di
    1489:	8c 46 e0             	mov    WORD PTR [bp-0x20],es
    148c:	9b 2e dd 06 53 14    	fld    QWORD PTR cs:0x1453
    1492:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    1496:	90                   	nop
    1497:	9b 9b dd 46 e8       	fld    QWORD PTR [bp-0x18]
    149c:	9b d9 e0             	fchs
    149f:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    14a3:	90                   	nop
    14a4:	9b                   	fwait
    14a5:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    14aa:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    14af:	2d 01 00             	sub    ax,0x1
    14b2:	83 da 00             	sbb    dx,0x0
    14b5:	71 05                	jno    0x14bc
    14b7:	9a 3e 04 c2 14       	call   0x14c2:0x43e
    14bc:	bf 5b 14             	mov    di,0x145b
    14bf:	9a 16 04 f2 14       	call   0x14f2:0x416
    14c4:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    14c7:	b8 01 00             	mov    ax,0x1
    14ca:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    14cd:	7e 03                	jle    0x14d2
    14cf:	e9 b8 00             	jmp    0x158a
    14d2:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    14d5:	eb 03                	jmp    0x14da
    14d7:	ff 46 e4             	inc    WORD PTR [bp-0x1c]
    14da:	c4 7e de             	les    di,DWORD PTR [bp-0x22]
    14dd:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    14e2:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    14e7:	2d 01 00             	sub    ax,0x1
    14ea:	83 da 00             	sbb    dx,0x0
    14ed:	71 05                	jno    0x14f4
    14ef:	9a 3e 04 fa 14       	call   0x14fa:0x43e
    14f4:	bf 5b 14             	mov    di,0x145b
    14f7:	9a 16 04 2d 15       	call   0x152d:0x416
    14fc:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    14ff:	b8 01 00             	mov    ax,0x1
    1502:	3b 46 da             	cmp    ax,WORD PTR [bp-0x26]
    1505:	7f 78                	jg     0x157f
    1507:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    150a:	eb 03                	jmp    0x150f
    150c:	ff 46 e6             	inc    WORD PTR [bp-0x1a]
    150f:	8d be da fe          	lea    di,[bp-0x126]
    1513:	16                   	push   ss
    1514:	57                   	push   di
    1515:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    1518:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    151b:	c4 7e de             	les    di,DWORD PTR [bp-0x22]
    151e:	06                   	push   es
    151f:	57                   	push   di
    1520:	9a 68 9a 17 21       	call   0x2117:0x9a68
    1525:	8d 7e e2             	lea    di,[bp-0x1e]
    1528:	16                   	push   ss
    1529:	57                   	push   di
    152a:	9a 86 1e 6f 16       	call   0x166f:0x1e86
    152f:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1533:	90                   	nop
    1534:	9b                   	fwait
    1535:	83 7e e2 00          	cmp    WORD PTR [bp-0x1e],0x0
    1539:	75 3c                	jne    0x1577
    153b:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    153f:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    1543:	9b dd 7e d8          	fstsw  WORD PTR [bp-0x28]
    1547:	90                   	nop
    1548:	9b                   	fwait
    1549:	8a 66 d9             	mov    ah,BYTE PTR [bp-0x27]
    154c:	9e                   	sahf
    154d:	76 0a                	jbe    0x1559
    154f:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    1553:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    1557:	90                   	nop
    1558:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    155d:	9b dc 5e e8          	fcomp  QWORD PTR [bp-0x18]
    1561:	9b dd 7e d8          	fstsw  WORD PTR [bp-0x28]
    1565:	90                   	nop
    1566:	9b                   	fwait
    1567:	8a 66 d9             	mov    ah,BYTE PTR [bp-0x27]
    156a:	9e                   	sahf
    156b:	73 0a                	jae    0x1577
    156d:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    1571:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    1575:	90                   	nop
    1576:	9b                   	fwait
    1577:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    157a:	3b 46 da             	cmp    ax,WORD PTR [bp-0x26]
    157d:	75 8d                	jne    0x150c
    157f:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    1582:	3b 46 dc             	cmp    ax,WORD PTR [bp-0x24]
    1585:	74 03                	je     0x158a
    1587:	e9 4d ff             	jmp    0x14d7
    158a:	ff 76 f6             	push   WORD PTR [bp-0xa]
    158d:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1590:	ff 76 f2             	push   WORD PTR [bp-0xe]
    1593:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1596:	9a a6 2f b0 15       	call   0x15b0:0x2fa6
    159b:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    159f:	90                   	nop
    15a0:	9b                   	fwait
    15a1:	ff 76 ee             	push   WORD PTR [bp-0x12]
    15a4:	ff 76 ec             	push   WORD PTR [bp-0x14]
    15a7:	ff 76 ea             	push   WORD PTR [bp-0x16]
    15aa:	ff 76 e8             	push   WORD PTR [bp-0x18]
    15ad:	9a a6 2f 55 16       	call   0x1655:0x2fa6
    15b2:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    15b6:	90                   	nop
    15b7:	9b                   	fwait
    15b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15bb:	26 80 bd 5d 08 00    	cmp    BYTE PTR es:[di+0x85d],0x0
    15c1:	74 0e                	je     0x15d1
    15c3:	9b dd 46 e8          	fld    QWORD PTR [bp-0x18]
    15c7:	9b 26 dd 9d 76 08    	fstp   QWORD PTR es:[di+0x876]
    15cd:	90                   	nop
    15ce:	9b                   	fwait
    15cf:	eb 11                	jmp    0x15e2
    15d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15d4:	9b 26 dd 85 66 08    	fld    QWORD PTR es:[di+0x866]
    15da:	9b 26 dd 9d 76 08    	fstp   QWORD PTR es:[di+0x876]
    15e0:	90                   	nop
    15e1:	9b                   	fwait
    15e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15e5:	26 80 bd 5c 08 00    	cmp    BYTE PTR es:[di+0x85c],0x0
    15eb:	74 1c                	je     0x1609
    15ed:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    15f1:	9b 26 dd 9d 6e 08    	fstp   QWORD PTR es:[di+0x86e]
    15f7:	90                   	nop
    15f8:	9b                   	fwait
    15f9:	9b 2e d9 06 63 14    	fld    DWORD PTR cs:0x1463
    15ff:	9b 26 dd 9d 7e 08    	fstp   QWORD PTR es:[di+0x87e]
    1605:	90                   	nop
    1606:	9b                   	fwait
    1607:	eb 11                	jmp    0x161a
    1609:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    160c:	9b 26 dd 85 5e 08    	fld    QWORD PTR es:[di+0x85e]
    1612:	9b 26 dd 9d 6e 08    	fstp   QWORD PTR es:[di+0x86e]
    1618:	90                   	nop
    1619:	9b                   	fwait
    161a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    161d:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    1623:	9b 26 dc 9d 76 08    	fcomp  QWORD PTR es:[di+0x876]
    1629:	9b dd 7e e0          	fstsw  WORD PTR [bp-0x20]
    162d:	90                   	nop
    162e:	9b                   	fwait
    162f:	8a 66 e1             	mov    ah,BYTE PTR [bp-0x1f]
    1632:	9e                   	sahf
    1633:	77 2d                	ja     0x1662
    1635:	9b 26 dd 85 76 08    	fld    QWORD PTR es:[di+0x876]
    163b:	9b 2e d8 06 67 14    	fadd   DWORD PTR cs:0x1467
    1641:	9b 2e d8 0e 6b 14    	fmul   DWORD PTR cs:0x146b
    1647:	83 ec 08             	sub    sp,0x8
    164a:	89 e3                	mov    bx,sp
    164c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1650:	90                   	nop
    1651:	9b                   	fwait
    1652:	9a a6 2f 7b 1a       	call   0x1a7b:0x2fa6
    1657:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    165a:	9b 26 dd 9d 6e 08    	fstp   QWORD PTR es:[di+0x86e]
    1660:	90                   	nop
    1661:	9b                   	fwait
    1662:	c9                   	leave
    1663:	ca 04 00             	retf   0x4
    1666:	55                   	push   bp
    1667:	89 e5                	mov    bp,sp
    1669:	b8 1c 02             	mov    ax,0x21c
    166c:	9a 44 04 14 17       	call   0x1714:0x444
    1671:	81 ec 1c 02          	sub    sp,0x21c
    1675:	31 c0                	xor    ax,ax
    1677:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    167b:	31 c0                	xor    ax,ax
    167d:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    1681:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1684:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    1689:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    168d:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    1691:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1694:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    1699:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    169d:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    16a1:	8d be ea fe          	lea    di,[bp-0x116]
    16a5:	16                   	push   ss
    16a6:	57                   	push   di
    16a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16aa:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    16af:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    16b4:	06                   	push   es
    16b5:	57                   	push   di
    16b6:	9a e5 1c ee 16       	call   0x16ee:0x1ce5
    16bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16be:	06                   	push   es
    16bf:	57                   	push   di
    16c0:	9a 7f 13 21 17       	call   0x1721:0x137f
    16c5:	09 c0                	or     ax,ax
    16c7:	7f 03                	jg     0x16cc
    16c9:	e9 2a 02             	jmp    0x18f6
    16cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16cf:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    16d4:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    16d8:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    16dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16df:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    16e4:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    16e9:	06                   	push   es
    16ea:	57                   	push   di
    16eb:	9a 99 20 d6 17       	call   0x17d6:0x2099
    16f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f3:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    16f8:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    16fc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    16ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1702:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    1707:	26 8b 85 da 00       	mov    ax,WORD PTR es:[di+0xda]
    170c:	05 01 00             	add    ax,0x1
    170f:	71 05                	jno    0x1716
    1711:	9a 3e 04 30 17       	call   0x1730:0x43e
    1716:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1719:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    171c:	06                   	push   es
    171d:	57                   	push   di
    171e:	9a 05 14 58 17       	call   0x1758:0x1405
    1723:	8b c8                	mov    cx,ax
    1725:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1728:	2d 04 00             	sub    ax,0x4
    172b:	71 05                	jno    0x1732
    172d:	9a 3e 04 42 17       	call   0x1742:0x43e
    1732:	99                   	cwd
    1733:	f7 f9                	idiv   cx
    1735:	8b d0                	mov    dx,ax
    1737:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    173a:	2d 01 00             	sub    ax,0x1
    173d:	71 05                	jno    0x1744
    173f:	9a 3e 04 4b 17       	call   0x174b:0x43e
    1744:	03 c2                	add    ax,dx
    1746:	71 05                	jno    0x174d
    1748:	9a 3e 04 b0 17       	call   0x17b0:0x43e
    174d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1750:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1753:	06                   	push   es
    1754:	57                   	push   di
    1755:	9a c6 13 67 17       	call   0x1767:0x13c6
    175a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    175d:	7d 0d                	jge    0x176c
    175f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1762:	06                   	push   es
    1763:	57                   	push   di
    1764:	9a c6 13 a1 17       	call   0x17a1:0x13c6
    1769:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    176c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    176f:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    1774:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1779:	89 be e6 fe          	mov    WORD PTR [bp-0x11a],di
    177d:	8c 86 e8 fe          	mov    WORD PTR [bp-0x118],es
    1781:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1784:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    1788:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    178b:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    178f:	7f 60                	jg     0x17f1
    1791:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1794:	eb 03                	jmp    0x1799
    1796:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1799:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    179c:	06                   	push   es
    179d:	57                   	push   di
    179e:	9a 05 14 5c 18       	call   0x185c:0x1405
    17a3:	8b d0                	mov    dx,ax
    17a5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    17a8:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    17ab:	71 05                	jno    0x17b2
    17ad:	9a 3e 04 ba 17       	call   0x17ba:0x43e
    17b2:	05 01 00             	add    ax,0x1
    17b5:	71 05                	jno    0x17bc
    17b7:	9a 3e 04 c3 17       	call   0x17c3:0x43e
    17bc:	f7 ea                	imul   dx
    17be:	71 05                	jno    0x17c5
    17c0:	9a 3e 04 3e 18       	call   0x183e:0x43e
    17c5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    17c8:	ff 76 f4             	push   WORD PTR [bp-0xc]
    17cb:	6a 00                	push   0x0
    17cd:	c4 be e6 fe          	les    di,DWORD PTR [bp-0x11a]
    17d1:	06                   	push   es
    17d2:	57                   	push   di
    17d3:	9a b8 1d e6 17       	call   0x17e6:0x1db8
    17d8:	ff 76 f4             	push   WORD PTR [bp-0xc]
    17db:	6a 02                	push   0x2
    17dd:	c4 be e6 fe          	les    di,DWORD PTR [bp-0x11a]
    17e1:	06                   	push   es
    17e2:	57                   	push   di
    17e3:	9a 7b 1d 4f 18       	call   0x184f:0x1d7b
    17e8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    17eb:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    17ef:	75 a5                	jne    0x1796
    17f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17f4:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    17f9:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    17fe:	89 be e6 fe          	mov    WORD PTR [bp-0x11a],di
    1802:	8c 86 e8 fe          	mov    WORD PTR [bp-0x118],es
    1806:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1809:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    180d:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1810:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    1814:	7e 03                	jle    0x1819
    1816:	e9 dd 00             	jmp    0x18f6
    1819:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    181c:	eb 03                	jmp    0x1821
    181e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1821:	8d be e4 fd          	lea    di,[bp-0x21c]
    1825:	16                   	push   ss
    1826:	57                   	push   di
    1827:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    182a:	99                   	cwd
    182b:	52                   	push   dx
    182c:	50                   	push   ax
    182d:	9a a9 08 dd 18       	call   0x18dd:0x8a9
    1832:	8d be f2 fe          	lea    di,[bp-0x10e]
    1836:	16                   	push   ss
    1837:	57                   	push   di
    1838:	68 ff 00             	push   0xff
    183b:	9a e7 17 6b 18       	call   0x186b:0x17e7
    1840:	8d be f2 fe          	lea    di,[bp-0x10e]
    1844:	16                   	push   ss
    1845:	57                   	push   di
    1846:	c4 be e6 fe          	les    di,DWORD PTR [bp-0x11a]
    184a:	06                   	push   es
    184b:	57                   	push   di
    184c:	9a 03 20 e8 18       	call   0x18e8:0x2003
    1851:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1857:	06                   	push   es
    1858:	57                   	push   di
    1859:	9a 05 14 12 19       	call   0x1912:0x1405
    185e:	8b d0                	mov    dx,ax
    1860:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1863:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    1866:	71 05                	jno    0x186d
    1868:	9a 3e 04 75 18       	call   0x1875:0x43e
    186d:	05 01 00             	add    ax,0x1
    1870:	71 05                	jno    0x1877
    1872:	9a 3e 04 7e 18       	call   0x187e:0x43e
    1877:	f7 ea                	imul   dx
    1879:	71 05                	jno    0x1880
    187b:	9a 3e 04 98 18       	call   0x1898:0x43e
    1880:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1883:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1886:	99                   	cwd
    1887:	b9 02 00             	mov    cx,0x2
    188a:	f7 f9                	idiv   cx
    188c:	8b d0                	mov    dx,ax
    188e:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1891:	2b c2                	sub    ax,dx
    1893:	71 05                	jno    0x189a
    1895:	9a 3e 04 ad 18       	call   0x18ad:0x43e
    189a:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    189d:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    18a2:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    18a5:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    18a8:	71 05                	jno    0x18af
    18aa:	9a 3e 04 1f 19       	call   0x191f:0x43e
    18af:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    18b2:	b0 00                	mov    al,0x0
    18b4:	7d 01                	jge    0x18b7
    18b6:	40                   	inc    ax
    18b7:	8a d0                	mov    dl,al
    18b9:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    18bd:	b0 00                	mov    al,0x0
    18bf:	7e 01                	jle    0x18c2
    18c1:	40                   	inc    ax
    18c2:	22 c2                	and    al,dl
    18c4:	08 c0                	or     al,al
    18c6:	74 22                	je     0x18ea
    18c8:	ff 76 f4             	push   WORD PTR [bp-0xc]
    18cb:	ff 76 f2             	push   WORD PTR [bp-0xe]
    18ce:	8d be e4 fd          	lea    di,[bp-0x21c]
    18d2:	16                   	push   ss
    18d3:	57                   	push   di
    18d4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    18d7:	99                   	cwd
    18d8:	52                   	push   dx
    18d9:	50                   	push   ax
    18da:	9a a9 08 0e 19       	call   0x190e:0x8a9
    18df:	c4 be e6 fe          	les    di,DWORD PTR [bp-0x11a]
    18e3:	06                   	push   es
    18e4:	57                   	push   di
    18e5:	9a 09 1f 69 19       	call   0x1969:0x1f09
    18ea:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    18ed:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    18f1:	74 03                	je     0x18f6
    18f3:	e9 28 ff             	jmp    0x181e
    18f6:	c9                   	leave
    18f7:	ca 08 00             	retf   0x8
    18fa:	00 00                	add    BYTE PTR [bx+si],al
    18fc:	00 00                	add    BYTE PTR [bx+si],al
    18fe:	00 00                	add    BYTE PTR [bx+si],al
    1900:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    1903:	80 ff ff             	cmp    bh,0xff
    1906:	ff                   	(bad)
    1907:	7f 00                	jg     0x1909
    1909:	00 01                	add    BYTE PTR [bx+di],al
    190b:	00 86 01 9f          	add    BYTE PTR [bp-0x60ff],al
    190f:	1c 97                	sbb    al,0x97
    1911:	1a 73 19             	sbb    dh,BYTE PTR [bp+di+0x19]
    1914:	01 48 55             	add    WORD PTR [bx+si+0x55],cx
    1917:	89 e5                	mov    bp,sp
    1919:	b8 2e 02             	mov    ax,0x22e
    191c:	9a 44 04 b7 19       	call   0x19b7:0x444
    1921:	81 ec 2e 02          	sub    sp,0x22e
    1925:	31 c0                	xor    ax,ax
    1927:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    192b:	31 c0                	xor    ax,ax
    192d:	89 86 da fe          	mov    WORD PTR [bp-0x126],ax
    1931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1934:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    1939:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    193d:	89 86 de fe          	mov    WORD PTR [bp-0x122],ax
    1941:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1944:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    1949:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    194d:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    1951:	8d be d8 fe          	lea    di,[bp-0x128]
    1955:	16                   	push   ss
    1956:	57                   	push   di
    1957:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    195a:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    195f:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1964:	06                   	push   es
    1965:	57                   	push   di
    1966:	9a e5 1c ab 19       	call   0x19ab:0x1ce5
    196b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    196e:	06                   	push   es
    196f:	57                   	push   di
    1970:	9a 7f 13 d9 1b       	call   0x1bd9:0x137f
    1975:	09 c0                	or     ax,ax
    1977:	7f 03                	jg     0x197c
    1979:	e9 0b 03             	jmp    0x1c87
    197c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    197f:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    1984:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1988:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    198b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    198e:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1993:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1997:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    199a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    199d:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    19a2:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    19a6:	06                   	push   es
    19a7:	57                   	push   di
    19a8:	9a cc 11 3d 1b       	call   0x1b3d:0x11cc
    19ad:	b9 02 00             	mov    cx,0x2
    19b0:	f7 e9                	imul   cx
    19b2:	71 05                	jno    0x19b9
    19b4:	9a 3e 04 eb 19       	call   0x19eb:0x43e
    19b9:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    19bc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    19bf:	99                   	cwd
    19c0:	f7 7e f2             	idiv   WORD PTR [bp-0xe]
    19c3:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    19c7:	83 be e0 fe 00       	cmp    WORD PTR [bp-0x120],0x0
    19cc:	7f 06                	jg     0x19d4
    19ce:	c7 86 e0 fe 01 00    	mov    WORD PTR [bp-0x120],0x1
    19d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d7:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    19dd:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    19e3:	9b df 86 e0 fe       	fild   WORD PTR [bp-0x120]
    19e8:	9a b2 04 80 1a       	call   0x1a80:0x4b2
    19ed:	9b dd 9e e2 fe       	fstp   QWORD PTR [bp-0x11e]
    19f2:	90                   	nop
    19f3:	9b 9b dd 86 e2 fe    	fld    QWORD PTR [bp-0x11e]
    19f9:	9b 2e d8 1e fa 18    	fcomp  DWORD PTR cs:0x18fa
    19ff:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    1a04:	90                   	nop
    1a05:	9b                   	fwait
    1a06:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    1a0a:	9e                   	sahf
    1a0b:	77 0d                	ja     0x1a1a
    1a0d:	9b 2e d9 06 fe 18    	fld    DWORD PTR cs:0x18fe
    1a13:	9b dd 9e e2 fe       	fstp   QWORD PTR [bp-0x11e]
    1a18:	90                   	nop
    1a19:	9b 9b dd 86 e2 fe    	fld    QWORD PTR [bp-0x11e]
    1a1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a22:	9b 26 dc 9d 7e 08    	fcomp  QWORD PTR es:[di+0x87e]
    1a28:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    1a2d:	90                   	nop
    1a2e:	9b                   	fwait
    1a2f:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    1a33:	9e                   	sahf
    1a34:	73 79                	jae    0x1aaf
    1a36:	9b 26 dd 85 7e 08    	fld    QWORD PTR es:[di+0x87e]
    1a3c:	9b dd 9e e2 fe       	fstp   QWORD PTR [bp-0x11e]
    1a41:	90                   	nop
    1a42:	9b                   	fwait
    1a43:	b8 0a 19             	mov    ax,0x190a
    1a46:	0e                   	push   cs
    1a47:	50                   	push   ax
    1a48:	55                   	push   bp
    1a49:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1a4d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1a51:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    1a57:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    1a5d:	83 ec 08             	sub    sp,0x8
    1a60:	89 e3                	mov    bx,sp
    1a62:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1a66:	90                   	nop
    1a67:	9b                   	fwait
    1a68:	ff b6 e8 fe          	push   WORD PTR [bp-0x118]
    1a6c:	ff b6 e6 fe          	push   WORD PTR [bp-0x11a]
    1a70:	ff b6 e4 fe          	push   WORD PTR [bp-0x11c]
    1a74:	ff b6 e2 fe          	push   WORD PTR [bp-0x11e]
    1a78:	9a a7 2e 0c 1e       	call   0x1e0c:0x2ea7
    1a7d:	9a 2f 10 88 1a       	call   0x1a88:0x102f
    1a82:	bf 02 19             	mov    di,0x1902
    1a85:	9a 16 04 a0 1a       	call   0x1aa0:0x416
    1a8a:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    1a8e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1a92:	83 c4 06             	add    sp,0x6
    1a95:	eb 0b                	jmp    0x1aa2
    1a97:	c7 86 e0 fe 01 00    	mov    WORD PTR [bp-0x120],0x1
    1a9d:	9a 34 14 ba 1a       	call   0x1aba:0x1434
    1aa2:	83 be e0 fe 00       	cmp    WORD PTR [bp-0x120],0x0
    1aa7:	7f 06                	jg     0x1aaf
    1aa9:	c7 86 e0 fe 01 00    	mov    WORD PTR [bp-0x120],0x1
    1aaf:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1ab2:	2b 46 f2             	sub    ax,WORD PTR [bp-0xe]
    1ab5:	71 05                	jno    0x1abc
    1ab7:	9a 3e 04 f0 1a       	call   0x1af0:0x43e
    1abc:	99                   	cwd
    1abd:	f7 be e0 fe          	idiv   WORD PTR [bp-0x120]
    1ac1:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1ac4:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    1ac8:	7f 05                	jg     0x1acf
    1aca:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    1acf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad2:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    1ad7:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1adc:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    1ae0:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    1ae4:	8b 86 e0 fe          	mov    ax,WORD PTR [bp-0x120]
    1ae8:	05 01 00             	add    ax,0x1
    1aeb:	71 05                	jno    0x1af2
    1aed:	9a 3e 04 11 1b       	call   0x1b11:0x43e
    1af2:	89 86 d2 fe          	mov    WORD PTR [bp-0x12e],ax
    1af6:	31 c0                	xor    ax,ax
    1af8:	3b 86 d2 fe          	cmp    ax,WORD PTR [bp-0x12e]
    1afc:	7f 66                	jg     0x1b64
    1afe:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b01:	eb 03                	jmp    0x1b06
    1b03:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1b06:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b09:	f7 6e f4             	imul   WORD PTR [bp-0xc]
    1b0c:	71 05                	jno    0x1b13
    1b0e:	9a 3e 04 20 1b       	call   0x1b20:0x43e
    1b13:	8b d0                	mov    dx,ax
    1b15:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b18:	05 01 00             	add    ax,0x1
    1b1b:	71 05                	jno    0x1b22
    1b1d:	9a 3e 04 29 1b       	call   0x1b29:0x43e
    1b22:	2b c2                	sub    ax,dx
    1b24:	71 05                	jno    0x1b2b
    1b26:	9a 3e 04 4a 1b       	call   0x1b4a:0x43e
    1b2b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1b2e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b31:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1b34:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    1b38:	06                   	push   es
    1b39:	57                   	push   di
    1b3a:	9a b8 1d 59 1b       	call   0x1b59:0x1db8
    1b3f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b42:	2d 02 00             	sub    ax,0x2
    1b45:	71 05                	jno    0x1b4c
    1b47:	9a 3e 04 85 1b       	call   0x1b85:0x43e
    1b4c:	50                   	push   ax
    1b4d:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1b50:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    1b54:	06                   	push   es
    1b55:	57                   	push   di
    1b56:	9a 7b 1d f8 1b       	call   0x1bf8:0x1d7b
    1b5b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b5e:	3b 86 d2 fe          	cmp    ax,WORD PTR [bp-0x12e]
    1b62:	75 9f                	jne    0x1b03
    1b64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b67:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    1b6c:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1b71:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    1b75:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    1b79:	8b 86 e0 fe          	mov    ax,WORD PTR [bp-0x120]
    1b7d:	05 01 00             	add    ax,0x1
    1b80:	71 05                	jno    0x1b87
    1b82:	9a 3e 04 e7 1b       	call   0x1be7:0x43e
    1b87:	89 86 d2 fe          	mov    WORD PTR [bp-0x12e],ax
    1b8b:	31 c0                	xor    ax,ax
    1b8d:	3b 86 d2 fe          	cmp    ax,WORD PTR [bp-0x12e]
    1b91:	7e 03                	jle    0x1b96
    1b93:	e9 f1 00             	jmp    0x1c87
    1b96:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b99:	eb 03                	jmp    0x1b9e
    1b9b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1b9e:	9b df 46 fe          	fild   WORD PTR [bp-0x2]
    1ba2:	9b dc 8e e2 fe       	fmul   QWORD PTR [bp-0x11e]
    1ba7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1baa:	9b 26 dc 85 76 08    	fadd   QWORD PTR es:[di+0x876]
    1bb0:	9b dd 9e ea fe       	fstp   QWORD PTR [bp-0x116]
    1bb5:	90                   	nop
    1bb6:	9b                   	fwait
    1bb7:	8d be d2 fd          	lea    di,[bp-0x22e]
    1bbb:	16                   	push   ss
    1bbc:	57                   	push   di
    1bbd:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    1bc1:	ff b6 ee fe          	push   WORD PTR [bp-0x112]
    1bc5:	ff b6 ec fe          	push   WORD PTR [bp-0x114]
    1bc9:	ff b6 ea fe          	push   WORD PTR [bp-0x116]
    1bcd:	6a 0c                	push   0xc
    1bcf:	6a 02                	push   0x2
    1bd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bd4:	06                   	push   es
    1bd5:	57                   	push   di
    1bd6:	9a 2d 12 a3 1c       	call   0x1ca3:0x122d
    1bdb:	8d be f2 fe          	lea    di,[bp-0x10e]
    1bdf:	16                   	push   ss
    1be0:	57                   	push   di
    1be1:	68 ff 00             	push   0xff
    1be4:	9a e7 17 07 1c       	call   0x1c07:0x17e7
    1be9:	8d be f2 fe          	lea    di,[bp-0x10e]
    1bed:	16                   	push   ss
    1bee:	57                   	push   di
    1bef:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    1bf3:	06                   	push   es
    1bf4:	57                   	push   di
    1bf5:	9a 03 20 4b 1c       	call   0x1c4b:0x2003
    1bfa:	8b d0                	mov    dx,ax
    1bfc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1bff:	2d 04 00             	sub    ax,0x4
    1c02:	71 05                	jno    0x1c09
    1c04:	9a 3e 04 10 1c       	call   0x1c10:0x43e
    1c09:	2b c2                	sub    ax,dx
    1c0b:	71 05                	jno    0x1c12
    1c0d:	9a 3e 04 20 1c       	call   0x1c20:0x43e
    1c12:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1c15:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c18:	f7 6e f4             	imul   WORD PTR [bp-0xc]
    1c1b:	71 05                	jno    0x1c22
    1c1d:	9a 3e 04 2f 1c       	call   0x1c2f:0x43e
    1c22:	8b d0                	mov    dx,ax
    1c24:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1c27:	05 01 00             	add    ax,0x1
    1c2a:	71 05                	jno    0x1c31
    1c2c:	9a 3e 04 38 1c       	call   0x1c38:0x43e
    1c31:	2b c2                	sub    ax,dx
    1c33:	71 05                	jno    0x1c3a
    1c35:	9a 3e 04 5f 1c       	call   0x1c5f:0x43e
    1c3a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1c3d:	bf 14 19             	mov    di,0x1914
    1c40:	0e                   	push   cs
    1c41:	57                   	push   di
    1c42:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    1c46:	06                   	push   es
    1c47:	57                   	push   di
    1c48:	9a 4e 20 79 1c       	call   0x1c79:0x204e
    1c4d:	99                   	cwd
    1c4e:	b9 02 00             	mov    cx,0x2
    1c51:	f7 f9                	idiv   cx
    1c53:	8b d0                	mov    dx,ax
    1c55:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1c58:	2b c2                	sub    ax,dx
    1c5a:	71 05                	jno    0x1c61
    1c5c:	9a 3e 04 c6 1c       	call   0x1cc6:0x43e
    1c61:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1c64:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1c67:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1c6a:	8d be f2 fe          	lea    di,[bp-0x10e]
    1c6e:	16                   	push   ss
    1c6f:	57                   	push   di
    1c70:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    1c74:	06                   	push   es
    1c75:	57                   	push   di
    1c76:	9a 09 1f 0b 1d       	call   0x1d0b:0x1f09
    1c7b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c7e:	3b 86 d2 fe          	cmp    ax,WORD PTR [bp-0x12e]
    1c82:	74 03                	je     0x1c87
    1c84:	e9 14 ff             	jmp    0x1b9b
    1c87:	c9                   	leave
    1c88:	ca 08 00             	retf   0x8
    1c8b:	00 00                	add    BYTE PTR [bx+si],al
    1c8d:	00 00                	add    BYTE PTR [bx+si],al
    1c8f:	00 00                	add    BYTE PTR [bx+si],al
    1c91:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    1c94:	80 ff ff             	cmp    bh,0xff
    1c97:	ff                   	(bad)
    1c98:	7f 00                	jg     0x1c9a
    1c9a:	00 01                	add    BYTE PTR [bx+di],al
    1c9c:	00 86 01 29          	add    BYTE PTR [bp+0x2901],al
    1ca0:	23 27                	and    sp,WORD PTR [bx]
    1ca2:	1e                   	push   ds
    1ca3:	15 1d 01             	adc    ax,0x11d
    1ca6:	00 00                	add    BYTE PTR [bx+si],al
    1ca8:	00 08                	add    BYTE PTR [bx+si],cl
    1caa:	00 00                	add    BYTE PTR [bx+si],al
    1cac:	00 eb                	add    bl,ch
    1cae:	ff                   	(bad)
    1caf:	ff                   	(bad)
    1cb0:	ff                   	(bad)
    1cb1:	ff                   	(bad)
    1cb2:	ff                   	(bad)
    1cb3:	ff 02                	inc    WORD PTR [bp+si]
    1cb5:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1cb9:	ff                   	(bad)
    1cba:	7f 00                	jg     0x1cbc
    1cbc:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1cbf:	e5 b8                	in     ax,0xb8
    1cc1:	3c 01                	cmp    al,0x1
    1cc3:	9a 44 04 59 1d       	call   0x1d59:0x444
    1cc8:	81 ec 3c 01          	sub    sp,0x13c
    1ccc:	31 c0                	xor    ax,ax
    1cce:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    1cd1:	31 c0                	xor    ax,ax
    1cd3:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    1cd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cd9:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1cde:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1ce2:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    1ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ce8:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1ced:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1cf1:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    1cf4:	8d 7e cc             	lea    di,[bp-0x34]
    1cf7:	16                   	push   ss
    1cf8:	57                   	push   di
    1cf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cfc:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1d01:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1d06:	06                   	push   es
    1d07:	57                   	push   di
    1d08:	9a e5 1c 4d 1d       	call   0x1d4d:0x1ce5
    1d0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d10:	06                   	push   es
    1d11:	57                   	push   di
    1d12:	9a 7f 13 cd 1e       	call   0x1ecd:0x137f
    1d17:	09 c0                	or     ax,ax
    1d19:	7f 03                	jg     0x1d1e
    1d1b:	e9 71 06             	jmp    0x238f
    1d1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d21:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1d26:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1d2a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d30:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1d35:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1d39:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d3f:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    1d44:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1d48:	06                   	push   es
    1d49:	57                   	push   di
    1d4a:	9a cc 11 79 1e       	call   0x1e79:0x11cc
    1d4f:	b9 02 00             	mov    cx,0x2
    1d52:	f7 e9                	imul   cx
    1d54:	71 05                	jno    0x1d5b
    1d56:	9a 3e 04 89 1d       	call   0x1d89:0x43e
    1d5b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1d5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d61:	99                   	cwd
    1d62:	f7 7e f4             	idiv   WORD PTR [bp-0xc]
    1d65:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    1d68:	83 7e d4 00          	cmp    WORD PTR [bp-0x2c],0x0
    1d6c:	7f 05                	jg     0x1d73
    1d6e:	c7 46 d4 01 00       	mov    WORD PTR [bp-0x2c],0x1
    1d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d76:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    1d7c:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    1d82:	9b df 46 d4          	fild   WORD PTR [bp-0x2c]
    1d86:	9a b2 04 11 1e       	call   0x1e11:0x4b2
    1d8b:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    1d8f:	90                   	nop
    1d90:	9b 9b dd 46 d8       	fld    QWORD PTR [bp-0x28]
    1d95:	9b 2e d8 1e 8b 1c    	fcomp  DWORD PTR cs:0x1c8b
    1d9b:	9b dd 7e ca          	fstsw  WORD PTR [bp-0x36]
    1d9f:	90                   	nop
    1da0:	9b                   	fwait
    1da1:	8a 66 cb             	mov    ah,BYTE PTR [bp-0x35]
    1da4:	9e                   	sahf
    1da5:	77 0c                	ja     0x1db3
    1da7:	9b 2e d9 06 8f 1c    	fld    DWORD PTR cs:0x1c8f
    1dad:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    1db1:	90                   	nop
    1db2:	9b 9b dd 46 d8       	fld    QWORD PTR [bp-0x28]
    1db7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dba:	9b 26 dc 9d 7e 08    	fcomp  QWORD PTR es:[di+0x87e]
    1dc0:	9b dd 7e ca          	fstsw  WORD PTR [bp-0x36]
    1dc4:	90                   	nop
    1dc5:	9b                   	fwait
    1dc6:	8a 66 cb             	mov    ah,BYTE PTR [bp-0x35]
    1dc9:	9e                   	sahf
    1dca:	73 70                	jae    0x1e3c
    1dcc:	9b 26 dd 85 7e 08    	fld    QWORD PTR es:[di+0x87e]
    1dd2:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    1dd6:	90                   	nop
    1dd7:	9b                   	fwait
    1dd8:	b8 9b 1c             	mov    ax,0x1c9b
    1ddb:	0e                   	push   cs
    1ddc:	50                   	push   ax
    1ddd:	55                   	push   bp
    1dde:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1de2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1de6:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    1dec:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    1df2:	83 ec 08             	sub    sp,0x8
    1df5:	89 e3                	mov    bx,sp
    1df7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1dfb:	90                   	nop
    1dfc:	9b                   	fwait
    1dfd:	ff 76 de             	push   WORD PTR [bp-0x22]
    1e00:	ff 76 dc             	push   WORD PTR [bp-0x24]
    1e03:	ff 76 da             	push   WORD PTR [bp-0x26]
    1e06:	ff 76 d8             	push   WORD PTR [bp-0x28]
    1e09:	9a a7 2e 5e 22       	call   0x225e:0x2ea7
    1e0e:	9a 2f 10 19 1e       	call   0x1e19:0x102f
    1e13:	bf 93 1c             	mov    di,0x1c93
    1e16:	9a 16 04 2f 1e       	call   0x1e2f:0x416
    1e1b:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    1e1e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1e22:	83 c4 06             	add    sp,0x6
    1e25:	eb 0a                	jmp    0x1e31
    1e27:	c7 46 d4 01 00       	mov    WORD PTR [bp-0x2c],0x1
    1e2c:	9a 34 14 47 1e       	call   0x1e47:0x1434
    1e31:	83 7e d4 00          	cmp    WORD PTR [bp-0x2c],0x0
    1e35:	7f 05                	jg     0x1e3c
    1e37:	c7 46 d4 01 00       	mov    WORD PTR [bp-0x2c],0x1
    1e3c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e3f:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    1e42:	71 05                	jno    0x1e49
    1e44:	9a 3e 04 c0 1e       	call   0x1ec0:0x43e
    1e49:	99                   	cwd
    1e4a:	f7 7e d4             	idiv   WORD PTR [bp-0x2c]
    1e4d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e50:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    1e54:	7f 05                	jg     0x1e5b
    1e56:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    1e5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e5e:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1e63:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1e68:	89 7e c8             	mov    WORD PTR [bp-0x38],di
    1e6b:	8c 46 ca             	mov    WORD PTR [bp-0x36],es
    1e6e:	6a 00                	push   0x0
    1e70:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1e74:	06                   	push   es
    1e75:	57                   	push   di
    1e76:	9a b0 14 89 1e       	call   0x1e89:0x14b0
    1e7b:	6a 04                	push   0x4
    1e7d:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    1e80:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1e84:	06                   	push   es
    1e85:	57                   	push   di
    1e86:	9a 73 14 99 1e       	call   0x1e99:0x1473
    1e8b:	6a 01                	push   0x1
    1e8d:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    1e90:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1e94:	06                   	push   es
    1e95:	57                   	push   di
    1e96:	9a f5 14 a9 1e       	call   0x1ea9:0x14f5
    1e9b:	6a 00                	push   0x0
    1e9d:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    1ea0:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1ea4:	06                   	push   es
    1ea5:	57                   	push   di
    1ea6:	9a 7c 17 3e 1f       	call   0x1f3e:0x177c
    1eab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eae:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    1eb3:	26 8b 85 da 00       	mov    ax,WORD PTR es:[di+0xda]
    1eb8:	05 01 00             	add    ax,0x1
    1ebb:	71 05                	jno    0x1ec2
    1ebd:	9a 3e 04 dc 1e       	call   0x1edc:0x43e
    1ec2:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    1ec5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec8:	06                   	push   es
    1ec9:	57                   	push   di
    1eca:	9a 05 14 04 1f       	call   0x1f04:0x1405
    1ecf:	8b c8                	mov    cx,ax
    1ed1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ed4:	2d 04 00             	sub    ax,0x4
    1ed7:	71 05                	jno    0x1ede
    1ed9:	9a 3e 04 ee 1e       	call   0x1eee:0x43e
    1ede:	99                   	cwd
    1edf:	f7 f9                	idiv   cx
    1ee1:	8b d0                	mov    dx,ax
    1ee3:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    1ee6:	2d 01 00             	sub    ax,0x1
    1ee9:	71 05                	jno    0x1ef0
    1eeb:	9a 3e 04 f7 1e       	call   0x1ef7:0x43e
    1ef0:	03 c2                	add    ax,dx
    1ef2:	71 05                	jno    0x1ef9
    1ef4:	9a 3e 04 5d 1f       	call   0x1f5d:0x43e
    1ef9:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eff:	06                   	push   es
    1f00:	57                   	push   di
    1f01:	9a c6 13 13 1f       	call   0x1f13:0x13c6
    1f06:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    1f09:	7d 0d                	jge    0x1f18
    1f0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f0e:	06                   	push   es
    1f0f:	57                   	push   di
    1f10:	9a c6 13 80 1f       	call   0x1f80:0x13c6
    1f15:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1f18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f1b:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    1f20:	89 7e c8             	mov    WORD PTR [bp-0x38],di
    1f23:	8c 46 ca             	mov    WORD PTR [bp-0x36],es
    1f26:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1f2b:	89 7e c4             	mov    WORD PTR [bp-0x3c],di
    1f2e:	8c 46 c6             	mov    WORD PTR [bp-0x3a],es
    1f31:	6a 00                	push   0x0
    1f33:	6a 00                	push   0x0
    1f35:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1f39:	06                   	push   es
    1f3a:	57                   	push   di
    1f3b:	9a da 13 b5 1f       	call   0x1fb5:0x13da
    1f40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f43:	26 80 bd 88 08 00    	cmp    BYTE PTR es:[di+0x888],0x0
    1f49:	74 07                	je     0x1f52
    1f4b:	31 c0                	xor    ax,ax
    1f4d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1f50:	eb 10                	jmp    0x1f62
    1f52:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f55:	2d 02 00             	sub    ax,0x2
    1f58:	71 05                	jno    0x1f5f
    1f5a:	9a 3e 04 8f 1f       	call   0x1f8f:0x43e
    1f5f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1f62:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    1f65:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    1f68:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    1f6b:	3b 46 c2             	cmp    ax,WORD PTR [bp-0x3e]
    1f6e:	7f 5f                	jg     0x1fcf
    1f70:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1f73:	eb 03                	jmp    0x1f78
    1f75:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    1f78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7b:	06                   	push   es
    1f7c:	57                   	push   di
    1f7d:	9a 05 14 ec 20       	call   0x20ec:0x1405
    1f82:	8b d0                	mov    dx,ax
    1f84:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1f87:	2b 46 ea             	sub    ax,WORD PTR [bp-0x16]
    1f8a:	71 05                	jno    0x1f91
    1f8c:	9a 3e 04 99 1f       	call   0x1f99:0x43e
    1f91:	05 01 00             	add    ax,0x1
    1f94:	71 05                	jno    0x1f9b
    1f96:	9a 3e 04 a2 1f       	call   0x1fa2:0x43e
    1f9b:	f7 ea                	imul   dx
    1f9d:	71 05                	jno    0x1fa4
    1f9f:	9a 3e 04 f2 1f       	call   0x1ff2:0x43e
    1fa4:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1fa7:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1faa:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1fad:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    1fb0:	06                   	push   es
    1fb1:	57                   	push   di
    1fb2:	9a b8 1d c5 1f       	call   0x1fc5:0x1db8
    1fb7:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1fba:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fbd:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    1fc0:	06                   	push   es
    1fc1:	57                   	push   di
    1fc2:	9a 7b 1d 31 20       	call   0x2031:0x1d7b
    1fc7:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1fca:	3b 46 c2             	cmp    ax,WORD PTR [bp-0x3e]
    1fcd:	75 a6                	jne    0x1f75
    1fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd2:	26 80 bd 87 08 00    	cmp    BYTE PTR es:[di+0x887],0x0
    1fd8:	74 08                	je     0x1fe2
    1fda:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1fdd:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1fe0:	eb 05                	jmp    0x1fe7
    1fe2:	c7 46 f6 02 00       	mov    WORD PTR [bp-0xa],0x2
    1fe7:	8b 46 d4             	mov    ax,WORD PTR [bp-0x2c]
    1fea:	05 01 00             	add    ax,0x1
    1fed:	71 05                	jno    0x1ff4
    1fef:	9a 3e 04 11 20       	call   0x2011:0x43e
    1ff4:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    1ff7:	31 c0                	xor    ax,ax
    1ff9:	3b 46 c2             	cmp    ax,WORD PTR [bp-0x3e]
    1ffc:	7f 4d                	jg     0x204b
    1ffe:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2001:	eb 03                	jmp    0x2006
    2003:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    2006:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2009:	f7 6e fa             	imul   WORD PTR [bp-0x6]
    200c:	71 05                	jno    0x2013
    200e:	9a 3e 04 1f 20       	call   0x201f:0x43e
    2013:	8b d0                	mov    dx,ax
    2015:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2018:	2b c2                	sub    ax,dx
    201a:	71 05                	jno    0x2021
    201c:	9a 3e 04 68 20       	call   0x2068:0x43e
    2021:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2024:	6a 00                	push   0x0
    2026:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2029:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    202c:	06                   	push   es
    202d:	57                   	push   di
    202e:	9a b8 1d 41 20       	call   0x2041:0x1db8
    2033:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2036:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2039:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    203c:	06                   	push   es
    203d:	57                   	push   di
    203e:	9a 7b 1d 57 20       	call   0x2057:0x1d7b
    2043:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2046:	3b 46 c2             	cmp    ax,WORD PTR [bp-0x3e]
    2049:	75 b8                	jne    0x2003
    204b:	6a 01                	push   0x1
    204d:	6a 01                	push   0x1
    204f:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    2052:	06                   	push   es
    2053:	57                   	push   di
    2054:	9a b8 1d 75 20       	call   0x2075:0x1db8
    2059:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    205c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2060:	2d 01 00             	sub    ax,0x1
    2063:	71 05                	jno    0x206a
    2065:	9a 3e 04 86 20       	call   0x2086:0x43e
    206a:	50                   	push   ax
    206b:	6a 01                	push   0x1
    206d:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    2070:	06                   	push   es
    2071:	57                   	push   di
    2072:	9a 7b 1d a3 20       	call   0x20a3:0x1d7b
    2077:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    207a:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    207e:	2d 01 00             	sub    ax,0x1
    2081:	71 05                	jno    0x2088
    2083:	9a 3e 04 98 20       	call   0x2098:0x43e
    2088:	50                   	push   ax
    2089:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    208c:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2090:	2d 01 00             	sub    ax,0x1
    2093:	71 05                	jno    0x209a
    2095:	9a 3e 04 b6 20       	call   0x20b6:0x43e
    209a:	50                   	push   ax
    209b:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    209e:	06                   	push   es
    209f:	57                   	push   di
    20a0:	9a 7b 1d c1 20       	call   0x20c1:0x1d7b
    20a5:	6a 01                	push   0x1
    20a7:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    20aa:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    20ae:	2d 01 00             	sub    ax,0x1
    20b1:	71 05                	jno    0x20b8
    20b3:	9a 3e 04 5d 21       	call   0x215d:0x43e
    20b8:	50                   	push   ax
    20b9:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    20bc:	06                   	push   es
    20bd:	57                   	push   di
    20be:	9a 7b 1d cf 20       	call   0x20cf:0x1d7b
    20c3:	6a 01                	push   0x1
    20c5:	6a 01                	push   0x1
    20c7:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    20ca:	06                   	push   es
    20cb:	57                   	push   di
    20cc:	9a 7b 1d 3c 21       	call   0x213c:0x1d7b
    20d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20d4:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    20d9:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    20de:	89 7e c8             	mov    WORD PTR [bp-0x38],di
    20e1:	8c 46 ca             	mov    WORD PTR [bp-0x36],es
    20e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20e7:	06                   	push   es
    20e8:	57                   	push   di
    20e9:	9a 7f 13 e5 21       	call   0x21e5:0x137f
    20ee:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    20f1:	b8 01 00             	mov    ax,0x1
    20f4:	3b 46 c6             	cmp    ax,WORD PTR [bp-0x3a]
    20f7:	7e 03                	jle    0x20fc
    20f9:	e9 51 02             	jmp    0x234d
    20fc:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    20ff:	eb 03                	jmp    0x2104
    2101:	ff 46 f0             	inc    WORD PTR [bp-0x10]
    2104:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2107:	99                   	cwd
    2108:	52                   	push   dx
    2109:	50                   	push   ax
    210a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    210d:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2112:	06                   	push   es
    2113:	57                   	push   di
    2114:	9a 30 6e 25 22       	call   0x2225:0x6e30
    2119:	09 c0                	or     ax,ax
    211b:	7f 03                	jg     0x2120
    211d:	e9 22 02             	jmp    0x2342
    2120:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2123:	26 80 bd 89 08 00    	cmp    BYTE PTR es:[di+0x889],0x0
    2129:	74 27                	je     0x2152
    212b:	68 ff 00             	push   0xff
    212e:	6a ff                	push   0xffff
    2130:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2133:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2137:	06                   	push   es
    2138:	57                   	push   di
    2139:	9a 84 16 4e 21       	call   0x214e:0x1684
    213e:	6a 00                	push   0x0
    2140:	6a 00                	push   0x0
    2142:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2145:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2149:	06                   	push   es
    214a:	57                   	push   di
    214b:	9a da 13 9c 21       	call   0x219c:0x13da
    2150:	eb 72                	jmp    0x21c4
    2152:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2155:	2d 01 00             	sub    ax,0x1
    2158:	71 05                	jno    0x215f
    215a:	9a 3e 04 6e 21       	call   0x216e:0x43e
    215f:	99                   	cwd
    2160:	b9 08 00             	mov    cx,0x8
    2163:	f7 f9                	idiv   cx
    2165:	92                   	xchg   dx,ax
    2166:	05 01 00             	add    ax,0x1
    2169:	71 05                	jno    0x2170
    216b:	9a 3e 04 77 21       	call   0x2177:0x43e
    2170:	99                   	cwd
    2171:	bf a5 1c             	mov    di,0x1ca5
    2174:	9a 16 04 8c 21       	call   0x218c:0x416
    2179:	8b f8                	mov    di,ax
    217b:	c1 e7 02             	shl    di,0x2
    217e:	8b 85 72 01          	mov    ax,WORD PTR [di+0x172]
    2182:	8b 95 74 01          	mov    dx,WORD PTR [di+0x174]
    2186:	bf ad 1c             	mov    di,0x1cad
    2189:	9a 16 04 b2 21       	call   0x21b2:0x416
    218e:	52                   	push   dx
    218f:	50                   	push   ax
    2190:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2193:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2197:	06                   	push   es
    2198:	57                   	push   di
    2199:	9a 84 16 aa 21       	call   0x21aa:0x1684
    219e:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    21a1:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    21a5:	06                   	push   es
    21a6:	57                   	push   di
    21a7:	9a 61 16 c2 21       	call   0x21c2:0x1661
    21ac:	bf ad 1c             	mov    di,0x1cad
    21af:	9a 16 04 f4 21       	call   0x21f4:0x416
    21b4:	52                   	push   dx
    21b5:	50                   	push   ax
    21b6:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    21b9:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    21bd:	06                   	push   es
    21be:	57                   	push   di
    21bf:	9a da 13 9d 22       	call   0x229d:0x13da
    21c4:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    21c7:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    21ca:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    21cd:	3b 46 c4             	cmp    ax,WORD PTR [bp-0x3c]
    21d0:	7e 03                	jle    0x21d5
    21d2:	e9 6d 01             	jmp    0x2342
    21d5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    21d8:	eb 03                	jmp    0x21dd
    21da:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    21dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e0:	06                   	push   es
    21e1:	57                   	push   di
    21e2:	9a 05 14 00 24       	call   0x2400:0x1405
    21e7:	8b d0                	mov    dx,ax
    21e9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    21ec:	2b 46 ea             	sub    ax,WORD PTR [bp-0x16]
    21ef:	71 05                	jno    0x21f6
    21f1:	9a 3e 04 fe 21       	call   0x21fe:0x43e
    21f6:	05 01 00             	add    ax,0x1
    21f9:	71 05                	jno    0x2200
    21fb:	9a 3e 04 07 22       	call   0x2207:0x43e
    2200:	f7 ea                	imul   dx
    2202:	71 05                	jno    0x2209
    2204:	9a 3e 04 2f 22       	call   0x222f:0x43e
    2209:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    220c:	8d be c4 fe          	lea    di,[bp-0x13c]
    2210:	16                   	push   ss
    2211:	57                   	push   di
    2212:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2215:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2218:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    221b:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2220:	06                   	push   es
    2221:	57                   	push   di
    2222:	9a 68 9a f7 24       	call   0x24f7:0x9a68
    2227:	8d 7e d6             	lea    di,[bp-0x2a]
    222a:	16                   	push   ss
    222b:	57                   	push   di
    222c:	9a 86 1e 6a 22       	call   0x226a:0x1e86
    2231:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    2235:	90                   	nop
    2236:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    223b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223e:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    2244:	83 ec 08             	sub    sp,0x8
    2247:	89 e3                	mov    bx,sp
    2249:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    224d:	90                   	nop
    224e:	9b                   	fwait
    224f:	ff 76 de             	push   WORD PTR [bp-0x22]
    2252:	ff 76 dc             	push   WORD PTR [bp-0x24]
    2255:	ff 76 da             	push   WORD PTR [bp-0x26]
    2258:	ff 76 d8             	push   WORD PTR [bp-0x28]
    225b:	9a a7 2e 41 3c       	call   0x3c41:0x2ea7
    2260:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    2264:	9b de c9             	fmulp  st(1),st
    2267:	9a 2f 10 72 22       	call   0x2272:0x102f
    226c:	bf b5 1c             	mov    di,0x1cb5
    226f:	9a 16 04 82 22       	call   0x2282:0x416
    2274:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2277:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    227a:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    227d:	71 05                	jno    0x2284
    227f:	9a 3e 04 bc 22       	call   0x22bc:0x43e
    2284:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2287:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    228a:	3b 46 ea             	cmp    ax,WORD PTR [bp-0x16]
    228d:	75 12                	jne    0x22a1
    228f:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2292:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2295:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2298:	06                   	push   es
    2299:	57                   	push   di
    229a:	9a b8 1d af 22       	call   0x22af:0x1db8
    229f:	eb 10                	jmp    0x22b1
    22a1:	ff 76 ee             	push   WORD PTR [bp-0x12]
    22a4:	ff 76 ec             	push   WORD PTR [bp-0x14]
    22a7:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    22aa:	06                   	push   es
    22ab:	57                   	push   di
    22ac:	9a 7b 1d f1 22       	call   0x22f1:0x1d7b
    22b1:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    22b4:	2d 04 00             	sub    ax,0x4
    22b7:	71 05                	jno    0x22be
    22b9:	9a 3e 04 ca 22       	call   0x22ca:0x43e
    22be:	50                   	push   ax
    22bf:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    22c2:	2d 04 00             	sub    ax,0x4
    22c5:	71 05                	jno    0x22cc
    22c7:	9a 3e 04 d8 22       	call   0x22d8:0x43e
    22cc:	50                   	push   ax
    22cd:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    22d0:	05 04 00             	add    ax,0x4
    22d3:	71 05                	jno    0x22da
    22d5:	9a 3e 04 e6 22       	call   0x22e6:0x43e
    22da:	50                   	push   ax
    22db:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    22de:	05 04 00             	add    ax,0x4
    22e1:	71 05                	jno    0x22e8
    22e3:	9a 3e 04 09 23       	call   0x2309:0x43e
    22e8:	50                   	push   ax
    22e9:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    22ec:	06                   	push   es
    22ed:	57                   	push   di
    22ee:	9a a2 1c 33 23       	call   0x2333:0x1ca2
    22f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f6:	26 80 bd 89 08 00    	cmp    BYTE PTR es:[di+0x889],0x0
    22fc:	74 39                	je     0x2337
    22fe:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2301:	05 05 00             	add    ax,0x5
    2304:	71 05                	jno    0x230b
    2306:	9a 3e 04 17 23       	call   0x2317:0x43e
    230b:	50                   	push   ax
    230c:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    230f:	2d 04 00             	sub    ax,0x4
    2312:	71 05                	jno    0x2319
    2314:	9a 3e 04 ac 23       	call   0x23ac:0x43e
    2319:	50                   	push   ax
    231a:	8d be c4 fe          	lea    di,[bp-0x13c]
    231e:	16                   	push   ss
    231f:	57                   	push   di
    2320:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2323:	99                   	cwd
    2324:	52                   	push   dx
    2325:	50                   	push   ax
    2326:	9a a9 08 a7 30       	call   0x30a7:0x8a9
    232b:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    232e:	06                   	push   es
    232f:	57                   	push   di
    2330:	9a 09 1f 5d 23       	call   0x235d:0x1f09
    2335:	eb 00                	jmp    0x2337
    2337:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    233a:	3b 46 c4             	cmp    ax,WORD PTR [bp-0x3c]
    233d:	74 03                	je     0x2342
    233f:	e9 98 fe             	jmp    0x21da
    2342:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2345:	3b 46 c6             	cmp    ax,WORD PTR [bp-0x3a]
    2348:	74 03                	je     0x234d
    234a:	e9 b4 fd             	jmp    0x2101
    234d:	6a 00                	push   0x0
    234f:	6a 00                	push   0x0
    2351:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2354:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2358:	06                   	push   es
    2359:	57                   	push   di
    235a:	9a da 13 6d 23       	call   0x236d:0x13da
    235f:	6a 02                	push   0x2
    2361:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2364:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2368:	06                   	push   es
    2369:	57                   	push   di
    236a:	9a b0 14 7d 23       	call   0x237d:0x14b0
    236f:	6a 01                	push   0x1
    2371:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2374:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2378:	06                   	push   es
    2379:	57                   	push   di
    237a:	9a f5 14 8d 23       	call   0x238d:0x14f5
    237f:	6a 0e                	push   0xe
    2381:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    2384:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2388:	06                   	push   es
    2389:	57                   	push   di
    238a:	9a 73 14 f6 23       	call   0x23f6:0x1473
    238f:	c9                   	leave
    2390:	ca 08 00             	retf   0x8
    2393:	eb ff                	jmp    0x2394
    2395:	ff                   	(bad)
    2396:	ff                   	(bad)
    2397:	ff                   	(bad)
    2398:	ff                   	(bad)
    2399:	ff 02                	inc    WORD PTR [bp+si]
    239b:	01 00                	add    WORD PTR [bx+si],ax
    239d:	00 00                	add    BYTE PTR [bx+si],al
    239f:	08 00                	or     BYTE PTR [bx+si],al
    23a1:	00 00                	add    BYTE PTR [bx+si],al
    23a3:	55                   	push   bp
    23a4:	89 e5                	mov    bp,sp
    23a6:	b8 26 02             	mov    ax,0x226
    23a9:	9a 44 04 37 24       	call   0x2437:0x444
    23ae:	81 ec 26 02          	sub    sp,0x226
    23b2:	31 c0                	xor    ax,ax
    23b4:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    23b8:	31 c0                	xor    ax,ax
    23ba:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    23be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c1:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    23c6:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    23ca:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    23ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d1:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    23d6:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    23da:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    23de:	8d be e4 fe          	lea    di,[bp-0x11c]
    23e2:	16                   	push   ss
    23e3:	57                   	push   di
    23e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e7:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    23ec:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    23f1:	06                   	push   es
    23f2:	57                   	push   di
    23f3:	9a e5 1c 1a 24       	call   0x241a:0x1ce5
    23f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fb:	06                   	push   es
    23fc:	57                   	push   di
    23fd:	9a 7f 13 2d 24       	call   0x242d:0x137f
    2402:	09 c0                	or     ax,ax
    2404:	7f 03                	jg     0x2409
    2406:	e9 07 03             	jmp    0x2710
    2409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240c:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    2411:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2415:	06                   	push   es
    2416:	57                   	push   di
    2417:	9a cc 11 91 24       	call   0x2491:0x11cc
    241c:	99                   	cwd
    241d:	b9 02 00             	mov    cx,0x2
    2420:	f7 f9                	idiv   cx
    2422:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2425:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2428:	06                   	push   es
    2429:	57                   	push   di
    242a:	9a 7f 13 ca 24       	call   0x24ca:0x137f
    242f:	05 01 00             	add    ax,0x1
    2432:	71 05                	jno    0x2439
    2434:	9a 3e 04 5a 24       	call   0x245a:0x43e
    2439:	8b c8                	mov    cx,ax
    243b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    243e:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    2443:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2447:	99                   	cwd
    2448:	f7 f9                	idiv   cx
    244a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    244d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2450:	b9 03 00             	mov    cx,0x3
    2453:	f7 e9                	imul   cx
    2455:	71 05                	jno    0x245c
    2457:	9a 3e 04 6e 24       	call   0x246e:0x43e
    245c:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    245f:	7e 12                	jle    0x2473
    2461:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2464:	b9 03 00             	mov    cx,0x3
    2467:	f7 e9                	imul   cx
    2469:	71 05                	jno    0x2470
    246b:	9a 3e 04 99 24       	call   0x2499:0x43e
    2470:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2473:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2476:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    247b:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    2480:	89 be dc fe          	mov    WORD PTR [bp-0x124],di
    2484:	8c 86 de fe          	mov    WORD PTR [bp-0x122],es
    2488:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    248c:	06                   	push   es
    248d:	57                   	push   di
    248e:	9a b7 13 b0 24       	call   0x24b0:0x13b7
    2493:	bf 93 23             	mov    di,0x2393
    2496:	9a 16 04 b8 24       	call   0x24b8:0x416
    249b:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    249f:	89 96 f2 fe          	mov    WORD PTR [bp-0x10e],dx
    24a3:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    24a7:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    24ab:	06                   	push   es
    24ac:	57                   	push   di
    24ad:	9a 61 16 a5 25       	call   0x25a5:0x1661
    24b2:	bf 93 23             	mov    di,0x2393
    24b5:	9a 16 04 0c 25       	call   0x250c:0x416
    24ba:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    24be:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    24c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c5:	06                   	push   es
    24c6:	57                   	push   di
    24c7:	9a 7f 13 35 27       	call   0x2735:0x137f
    24cc:	89 86 da fe          	mov    WORD PTR [bp-0x126],ax
    24d0:	b8 01 00             	mov    ax,0x1
    24d3:	3b 86 da fe          	cmp    ax,WORD PTR [bp-0x126]
    24d7:	7e 03                	jle    0x24dc
    24d9:	e9 34 02             	jmp    0x2710
    24dc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    24df:	eb 03                	jmp    0x24e4
    24e1:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    24e4:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    24e7:	99                   	cwd
    24e8:	52                   	push   dx
    24e9:	50                   	push   ax
    24ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ed:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    24f2:	06                   	push   es
    24f3:	57                   	push   di
    24f4:	9a 30 6e 51 25       	call   0x2551:0x6e30
    24f9:	09 c0                	or     ax,ax
    24fb:	b0 00                	mov    al,0x0
    24fd:	74 01                	je     0x2500
    24ff:	40                   	inc    ax
    2500:	50                   	push   ax
    2501:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2504:	2d 01 00             	sub    ax,0x1
    2507:	71 05                	jno    0x250e
    2509:	9a 3e 04 39 25       	call   0x2539:0x43e
    250e:	50                   	push   ax
    250f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2512:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    2517:	06                   	push   es
    2518:	57                   	push   di
    2519:	9a 53 13 27 25       	call   0x2527:0x1353
    251e:	89 c7                	mov    di,ax
    2520:	8e c2                	mov    es,dx
    2522:	06                   	push   es
    2523:	57                   	push   di
    2524:	9a 75 12 4c 27       	call   0x274c:0x1275
    2529:	c7 46 f8 0a 00       	mov    WORD PTR [bp-0x8],0xa
    252e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2531:	f7 6e fe             	imul   WORD PTR [bp-0x2]
    2534:	71 05                	jno    0x253b
    2536:	9a 3e 04 65 25       	call   0x2565:0x43e
    253b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    253e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2541:	99                   	cwd
    2542:	52                   	push   dx
    2543:	50                   	push   ax
    2544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2547:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    254c:	06                   	push   es
    254d:	57                   	push   di
    254e:	9a 30 6e ad 26       	call   0x26ad:0x6e30
    2553:	09 c0                	or     ax,ax
    2555:	75 03                	jne    0x255a
    2557:	e9 f9 00             	jmp    0x2653
    255a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    255d:	2d 01 00             	sub    ax,0x1
    2560:	71 05                	jno    0x2567
    2562:	9a 3e 04 76 25       	call   0x2576:0x43e
    2567:	99                   	cwd
    2568:	b9 08 00             	mov    cx,0x8
    256b:	f7 f9                	idiv   cx
    256d:	92                   	xchg   dx,ax
    256e:	05 01 00             	add    ax,0x1
    2571:	71 05                	jno    0x2578
    2573:	9a 3e 04 7f 25       	call   0x257f:0x43e
    2578:	99                   	cwd
    2579:	bf 9b 23             	mov    di,0x239b
    257c:	9a 16 04 94 25       	call   0x2594:0x416
    2581:	8b f8                	mov    di,ax
    2583:	c1 e7 02             	shl    di,0x2
    2586:	8b 85 72 01          	mov    ax,WORD PTR [di+0x172]
    258a:	8b 95 74 01          	mov    dx,WORD PTR [di+0x174]
    258e:	bf 93 23             	mov    di,0x2393
    2591:	9a 16 04 bc 25       	call   0x25bc:0x416
    2596:	52                   	push   dx
    2597:	50                   	push   ax
    2598:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    259c:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    25a0:	06                   	push   es
    25a1:	57                   	push   di
    25a2:	9a da 13 b4 25       	call   0x25b4:0x13da
    25a7:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    25ab:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    25af:	06                   	push   es
    25b0:	57                   	push   di
    25b1:	9a b7 13 cd 25       	call   0x25cd:0x13b7
    25b6:	bf 93 23             	mov    di,0x2393
    25b9:	9a 16 04 da 25       	call   0x25da:0x416
    25be:	52                   	push   dx
    25bf:	50                   	push   ax
    25c0:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    25c4:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    25c8:	06                   	push   es
    25c9:	57                   	push   di
    25ca:	9a 84 16 2d 26       	call   0x262d:0x1684
    25cf:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    25d2:	2d 03 00             	sub    ax,0x3
    25d5:	71 05                	jno    0x25dc
    25d7:	9a 3e 04 eb 25       	call   0x25eb:0x43e
    25dc:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    25e0:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    25e3:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    25e6:	71 05                	jno    0x25ed
    25e8:	9a 3e 04 fc 25       	call   0x25fc:0x43e
    25ed:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    25f1:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    25f4:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    25f7:	71 05                	jno    0x25fe
    25f9:	9a 3e 04 0d 26       	call   0x260d:0x43e
    25fe:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2602:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2605:	05 0d 00             	add    ax,0xd
    2608:	71 05                	jno    0x260f
    260a:	9a 3e 04 61 26       	call   0x2661:0x43e
    260f:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    2613:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2616:	26 80 bd 89 08 00    	cmp    BYTE PTR es:[di+0x889],0x0
    261c:	75 11                	jne    0x262f
    261e:	8d be e4 fe          	lea    di,[bp-0x11c]
    2622:	16                   	push   ss
    2623:	57                   	push   di
    2624:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    2628:	06                   	push   es
    2629:	57                   	push   di
    262a:	9a e5 1c 40 26       	call   0x2640:0x1ce5
    262f:	6a 00                	push   0x0
    2631:	6a 00                	push   0x0
    2633:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    2637:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    263b:	06                   	push   es
    263c:	57                   	push   di
    263d:	9a 84 16 51 26       	call   0x2651:0x1684
    2642:	8d be e4 fe          	lea    di,[bp-0x11c]
    2646:	16                   	push   ss
    2647:	57                   	push   di
    2648:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    264c:	06                   	push   es
    264d:	57                   	push   di
    264e:	9a 30 1d 72 26       	call   0x2672:0x1d30
    2653:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2657:	8b 96 f2 fe          	mov    dx,WORD PTR [bp-0x10e]
    265b:	bf 93 23             	mov    di,0x2393
    265e:	9a 16 04 82 26       	call   0x2682:0x416
    2663:	52                   	push   dx
    2664:	50                   	push   ax
    2665:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    2669:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    266d:	06                   	push   es
    266e:	57                   	push   di
    266f:	9a da 13 93 26       	call   0x2693:0x13da
    2674:	8b 86 ec fe          	mov    ax,WORD PTR [bp-0x114]
    2678:	8b 96 ee fe          	mov    dx,WORD PTR [bp-0x112]
    267c:	bf 93 23             	mov    di,0x2393
    267f:	9a 16 04 bb 26       	call   0x26bb:0x416
    2684:	52                   	push   dx
    2685:	50                   	push   ax
    2686:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    268a:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    268e:	06                   	push   es
    268f:	57                   	push   di
    2690:	9a 84 16 cc 26       	call   0x26cc:0x1684
    2695:	8d be da fd          	lea    di,[bp-0x226]
    2699:	16                   	push   ss
    269a:	57                   	push   di
    269b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    269e:	6a 00                	push   0x0
    26a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a3:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    26a8:	06                   	push   es
    26a9:	57                   	push   di
    26aa:	9a 68 9a cc 27       	call   0x27cc:0x9a68
    26af:	8d be f4 fe          	lea    di,[bp-0x10c]
    26b3:	16                   	push   ss
    26b4:	57                   	push   di
    26b5:	68 ff 00             	push   0xff
    26b8:	9a e7 17 e2 26       	call   0x26e2:0x17e7
    26bd:	8d be f4 fe          	lea    di,[bp-0x10c]
    26c1:	16                   	push   ss
    26c2:	57                   	push   di
    26c3:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    26c7:	06                   	push   es
    26c8:	57                   	push   di
    26c9:	9a 4e 20 02 27       	call   0x2702:0x204e
    26ce:	99                   	cwd
    26cf:	b9 02 00             	mov    cx,0x2
    26d2:	f7 f9                	idiv   cx
    26d4:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    26d7:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    26da:	05 14 00             	add    ax,0x14
    26dd:	71 05                	jno    0x26e4
    26df:	9a 3e 04 f0 26       	call   0x26f0:0x43e
    26e4:	50                   	push   ax
    26e5:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    26e8:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    26eb:	71 05                	jno    0x26f2
    26ed:	9a 3e 04 25 27       	call   0x2725:0x43e
    26f2:	50                   	push   ax
    26f3:	8d be f4 fe          	lea    di,[bp-0x10c]
    26f7:	16                   	push   ss
    26f8:	57                   	push   di
    26f9:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    26fd:	06                   	push   es
    26fe:	57                   	push   di
    26ff:	9a 09 1f fe 27       	call   0x27fe:0x1f09
    2704:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2707:	3b 86 da fe          	cmp    ax,WORD PTR [bp-0x126]
    270b:	74 03                	je     0x2710
    270d:	e9 d1 fd             	jmp    0x24e1
    2710:	c9                   	leave
    2711:	ca 08 00             	retf   0x8
    2714:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2718:	ff                   	(bad)
    2719:	7f 00                	jg     0x271b
    271b:	00 55 89             	add    BYTE PTR [di-0x77],dl
    271e:	e5 b8                	in     ax,0xb8
    2720:	0c 02                	or     al,0x2
    2722:	9a 44 04 92 27       	call   0x2792:0x444
    2727:	81 ec 0c 02          	sub    sp,0x20c
    272b:	6a 01                	push   0x1
    272d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2730:	06                   	push   es
    2731:	57                   	push   di
    2732:	9a d0 31 d0 28       	call   0x28d0:0x31d0
    2737:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    273a:	26 c6 85 8c 08 00    	mov    BYTE PTR es:[di+0x88c],0x0
    2740:	6a 01                	push   0x1
    2742:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2747:	06                   	push   es
    2748:	57                   	push   di
    2749:	9a 75 12 5d 27       	call   0x275d:0x1275
    274e:	6a 00                	push   0x0
    2750:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2753:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2758:	06                   	push   es
    2759:	57                   	push   di
    275a:	9a 75 12 29 29       	call   0x2929:0x1275
    275f:	6a 01                	push   0x1
    2761:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2764:	26 c4 bd f8 03       	les    di,DWORD PTR es:[di+0x3f8]
    2769:	06                   	push   es
    276a:	57                   	push   di
    276b:	9a 70 24 4b 29       	call   0x294b:0x2470
    2770:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2773:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2778:	c7 46 fc 2d 00       	mov    WORD PTR [bp-0x4],0x2d
    277d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2782:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2787:	2d 01 00             	sub    ax,0x1
    278a:	83 da 00             	sbb    dx,0x0
    278d:	71 05                	jno    0x2794
    278f:	9a 3e 04 9a 27       	call   0x279a:0x43e
    2794:	bf 14 27             	mov    di,0x2714
    2797:	9a 16 04 da 27       	call   0x27da:0x416
    279c:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    27a0:	b8 01 00             	mov    ax,0x1
    27a3:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    27a7:	7e 03                	jle    0x27ac
    27a9:	e9 95 00             	jmp    0x2841
    27ac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    27af:	eb 03                	jmp    0x27b4
    27b1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    27b4:	8d be f4 fd          	lea    di,[bp-0x20c]
    27b8:	16                   	push   ss
    27b9:	57                   	push   di
    27ba:	ff 76 fe             	push   WORD PTR [bp-0x2]
    27bd:	6a 00                	push   0x0
    27bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c2:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    27c7:	06                   	push   es
    27c8:	57                   	push   di
    27c9:	9a 68 9a ad 29       	call   0x29ad:0x9a68
    27ce:	8d be fa fe          	lea    di,[bp-0x106]
    27d2:	16                   	push   ss
    27d3:	57                   	push   di
    27d4:	68 ff 00             	push   0xff
    27d7:	9a e7 17 22 28       	call   0x2822:0x17e7
    27dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27df:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    27e4:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    27e8:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    27ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27ef:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    27f4:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    27f9:	06                   	push   es
    27fa:	57                   	push   di
    27fb:	9a 99 20 18 28       	call   0x2818:0x2099
    2800:	8d be fa fe          	lea    di,[bp-0x106]
    2804:	16                   	push   ss
    2805:	57                   	push   di
    2806:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2809:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    280e:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    2813:	06                   	push   es
    2814:	57                   	push   di
    2815:	9a 03 20 df 29       	call   0x29df:0x2003
    281a:	05 2d 00             	add    ax,0x2d
    281d:	71 05                	jno    0x2824
    281f:	9a 3e 04 c0 28       	call   0x28c0:0x43e
    2824:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2827:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    282a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    282d:	7e 06                	jle    0x2835
    282f:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2832:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2835:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2838:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    283c:	74 03                	je     0x2841
    283e:	e9 70 ff             	jmp    0x27b1
    2841:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2844:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2847:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    284c:	06                   	push   es
    284d:	57                   	push   di
    284e:	9a bf 17 73 28       	call   0x2873:0x17bf
    2853:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2856:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    285b:	06                   	push   es
    285c:	57                   	push   di
    285d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2860:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2864:	6a 00                	push   0x0
    2866:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2869:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    286e:	06                   	push   es
    286f:	57                   	push   di
    2870:	9a 77 1c 84 28       	call   0x2884:0x1c77
    2875:	6a 01                	push   0x1
    2877:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287a:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    287f:	06                   	push   es
    2880:	57                   	push   di
    2881:	9a 77 1c 95 28       	call   0x2895:0x1c77
    2886:	6a 05                	push   0x5
    2888:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    288b:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    2890:	06                   	push   es
    2891:	57                   	push   di
    2892:	9a 72 16 e5 28       	call   0x28e5:0x1672
    2897:	c9                   	leave
    2898:	ca 08 00             	retf   0x8
    289b:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    289f:	ff                   	(bad)
    28a0:	7f 00                	jg     0x28a2
    28a2:	00 02                	add    BYTE PTR [bp+si],al
    28a4:	31 32                	xor    WORD PTR [bp+si],si
    28a6:	01 45 0e             	add    WORD PTR [di+0xe],ax
    28a9:	38 38                	cmp    BYTE PTR [bx+si],bh
    28ab:	38 38                	cmp    BYTE PTR [bx+si],bh
    28ad:	38 38                	cmp    BYTE PTR [bx+si],bh
    28af:	38 38                	cmp    BYTE PTR [bx+si],bh
    28b1:	38 38                	cmp    BYTE PTR [bx+si],bh
    28b3:	38 38                	cmp    BYTE PTR [bx+si],bh
    28b5:	38 38                	cmp    BYTE PTR [bx+si],bh
    28b7:	55                   	push   bp
    28b8:	89 e5                	mov    bp,sp
    28ba:	b8 0c 03             	mov    ax,0x30c
    28bd:	9a 44 04 70 29       	call   0x2970:0x444
    28c2:	81 ec 0c 03          	sub    sp,0x30c
    28c6:	6a 01                	push   0x1
    28c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28cb:	06                   	push   es
    28cc:	57                   	push   di
    28cd:	9a d0 31 94 2a       	call   0x2a94:0x31d0
    28d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d5:	26 c6 85 8c 08 01    	mov    BYTE PTR es:[di+0x88c],0x1
    28db:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    28e0:	06                   	push   es
    28e1:	57                   	push   di
    28e2:	9a 58 22 f6 28       	call   0x28f6:0x2258
    28e7:	6a 00                	push   0x0
    28e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ec:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    28f1:	06                   	push   es
    28f2:	57                   	push   di
    28f3:	9a 77 1c 07 29       	call   0x2907:0x1c77
    28f8:	6a 01                	push   0x1
    28fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28fd:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2902:	06                   	push   es
    2903:	57                   	push   di
    2904:	9a 77 1c 18 29       	call   0x2918:0x1c77
    2909:	6a 05                	push   0x5
    290b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290e:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2913:	06                   	push   es
    2914:	57                   	push   di
    2915:	9a 72 16 39 2a       	call   0x2a39:0x1672
    291a:	6a 00                	push   0x0
    291c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    291f:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2924:	06                   	push   es
    2925:	57                   	push   di
    2926:	9a 75 12 3a 29       	call   0x293a:0x1275
    292b:	6a 01                	push   0x1
    292d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2930:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2935:	06                   	push   es
    2936:	57                   	push   di
    2937:	9a 75 12 32 2e       	call   0x2e32:0x1275
    293c:	6a 00                	push   0x0
    293e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2941:	26 c4 bd f8 03       	les    di,DWORD PTR es:[di+0x3f8]
    2946:	06                   	push   es
    2947:	57                   	push   di
    2948:	9a 70 24 64 49       	call   0x4964:0x2470
    294d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2950:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2955:	c7 86 fc fd 2d 00    	mov    WORD PTR [bp-0x204],0x2d
    295b:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2960:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2965:	2d 01 00             	sub    ax,0x1
    2968:	83 da 00             	sbb    dx,0x0
    296b:	71 05                	jno    0x2972
    296d:	9a 3e 04 78 29       	call   0x2978:0x43e
    2972:	bf 9b 28             	mov    di,0x289b
    2975:	9a 16 04 bb 29       	call   0x29bb:0x416
    297a:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    297e:	b8 01 00             	mov    ax,0x1
    2981:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    2985:	7e 03                	jle    0x298a
    2987:	e9 9e 00             	jmp    0x2a28
    298a:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    298e:	eb 04                	jmp    0x2994
    2990:	ff 86 fe fd          	inc    WORD PTR [bp-0x202]
    2994:	8d be f4 fc          	lea    di,[bp-0x30c]
    2998:	16                   	push   ss
    2999:	57                   	push   di
    299a:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    299e:	6a 00                	push   0x0
    29a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a3:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    29a8:	06                   	push   es
    29a9:	57                   	push   di
    29aa:	9a 68 9a a4 2c       	call   0x2ca4:0x9a68
    29af:	8d be 00 ff          	lea    di,[bp-0x100]
    29b3:	16                   	push   ss
    29b4:	57                   	push   di
    29b5:	68 ff 00             	push   0xff
    29b8:	9a e7 17 03 2a       	call   0x2a03:0x17e7
    29bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c0:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    29c5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    29c9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    29cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29d0:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    29d5:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    29da:	06                   	push   es
    29db:	57                   	push   di
    29dc:	9a 99 20 f9 29       	call   0x29f9:0x2099
    29e1:	8d be 00 ff          	lea    di,[bp-0x100]
    29e5:	16                   	push   ss
    29e6:	57                   	push   di
    29e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ea:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    29ef:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    29f4:	06                   	push   es
    29f5:	57                   	push   di
    29f6:	9a 03 20 54 2a       	call   0x2a54:0x2003
    29fb:	05 2d 00             	add    ax,0x2d
    29fe:	71 05                	jno    0x2a05
    2a00:	9a 3e 04 60 2a       	call   0x2a60:0x43e
    2a05:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    2a09:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    2a0d:	3b 86 fc fd          	cmp    ax,WORD PTR [bp-0x204]
    2a11:	7e 08                	jle    0x2a1b
    2a13:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    2a17:	89 86 fc fd          	mov    WORD PTR [bp-0x204],ax
    2a1b:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    2a1f:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    2a23:	74 03                	je     0x2a28
    2a25:	e9 68 ff             	jmp    0x2990
    2a28:	ff b6 fc fd          	push   WORD PTR [bp-0x204]
    2a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2f:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2a34:	06                   	push   es
    2a35:	57                   	push   di
    2a36:	9a bf 17 6c 2a       	call   0x2a6c:0x17bf
    2a3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a3e:	26 c4 bd 24 02       	les    di,DWORD PTR es:[di+0x224]
    2a43:	89 be f6 fd          	mov    WORD PTR [bp-0x20a],di
    2a47:	8c 86 f8 fd          	mov    WORD PTR [bp-0x208],es
    2a4b:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2a4f:	06                   	push   es
    2a50:	57                   	push   di
    2a51:	9a cc 11 5d 2b       	call   0x2b5d:0x11cc
    2a56:	b9 02 00             	mov    cx,0x2
    2a59:	f7 e9                	imul   cx
    2a5b:	71 05                	jno    0x2a62
    2a5d:	9a 3e 04 9e 2a       	call   0x2a9e:0x43e
    2a62:	50                   	push   ax
    2a63:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    2a67:	06                   	push   es
    2a68:	57                   	push   di
    2a69:	9a e1 17 83 2b       	call   0x2b83:0x17e1
    2a6e:	8d be fa fc          	lea    di,[bp-0x306]
    2a72:	16                   	push   ss
    2a73:	57                   	push   di
    2a74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a77:	26 ff b5 74 08       	push   WORD PTR es:[di+0x874]
    2a7c:	26 ff b5 72 08       	push   WORD PTR es:[di+0x872]
    2a81:	26 ff b5 70 08       	push   WORD PTR es:[di+0x870]
    2a86:	26 ff b5 6e 08       	push   WORD PTR es:[di+0x86e]
    2a8b:	6a 0c                	push   0xc
    2a8d:	6a 02                	push   0x2
    2a8f:	06                   	push   es
    2a90:	57                   	push   di
    2a91:	9a 2d 12 d4 2a       	call   0x2ad4:0x122d
    2a96:	bf a3 28             	mov    di,0x28a3
    2a99:	0e                   	push   cs
    2a9a:	57                   	push   di
    2a9b:	9a 4c 18 ac 2a       	call   0x2aac:0x184c
    2aa0:	8d be 00 ff          	lea    di,[bp-0x100]
    2aa4:	16                   	push   ss
    2aa5:	57                   	push   di
    2aa6:	68 ff 00             	push   0xff
    2aa9:	9a e7 17 de 2a       	call   0x2ade:0x17e7
    2aae:	8d be fa fc          	lea    di,[bp-0x306]
    2ab2:	16                   	push   ss
    2ab3:	57                   	push   di
    2ab4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ab7:	26 ff b5 7c 08       	push   WORD PTR es:[di+0x87c]
    2abc:	26 ff b5 7a 08       	push   WORD PTR es:[di+0x87a]
    2ac1:	26 ff b5 78 08       	push   WORD PTR es:[di+0x878]
    2ac6:	26 ff b5 76 08       	push   WORD PTR es:[di+0x876]
    2acb:	6a 0c                	push   0xc
    2acd:	6a 02                	push   0x2
    2acf:	06                   	push   es
    2ad0:	57                   	push   di
    2ad1:	9a 2d 12 8d 2b       	call   0x2b8d:0x122d
    2ad6:	bf a3 28             	mov    di,0x28a3
    2ad9:	0e                   	push   cs
    2ada:	57                   	push   di
    2adb:	9a 4c 18 ec 2a       	call   0x2aec:0x184c
    2ae0:	8d be 00 fe          	lea    di,[bp-0x200]
    2ae4:	16                   	push   ss
    2ae5:	57                   	push   di
    2ae6:	68 ff 00             	push   0xff
    2ae9:	9a e7 17 0a 2b       	call   0x2b0a:0x17e7
    2aee:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    2af2:	3a 86 00 ff          	cmp    al,BYTE PTR [bp-0x100]
    2af6:	76 14                	jbe    0x2b0c
    2af8:	8d be 00 fe          	lea    di,[bp-0x200]
    2afc:	16                   	push   ss
    2afd:	57                   	push   di
    2afe:	8d be 00 ff          	lea    di,[bp-0x100]
    2b02:	16                   	push   ss
    2b03:	57                   	push   di
    2b04:	68 ff 00             	push   0xff
    2b07:	9a e7 17 1a 2b       	call   0x2b1a:0x17e7
    2b0c:	bf a6 28             	mov    di,0x28a6
    2b0f:	0e                   	push   cs
    2b10:	57                   	push   di
    2b11:	8d be 00 ff          	lea    di,[bp-0x100]
    2b15:	16                   	push   ss
    2b16:	57                   	push   di
    2b17:	9a 78 18 31 2b       	call   0x2b31:0x1878
    2b1c:	09 c0                	or     ax,ax
    2b1e:	7e 13                	jle    0x2b33
    2b20:	bf a8 28             	mov    di,0x28a8
    2b23:	0e                   	push   cs
    2b24:	57                   	push   di
    2b25:	8d be 00 ff          	lea    di,[bp-0x100]
    2b29:	16                   	push   ss
    2b2a:	57                   	push   di
    2b2b:	68 ff 00             	push   0xff
    2b2e:	9a e7 17 aa 2b       	call   0x2baa:0x17e7
    2b33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b36:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    2b3b:	89 be f6 fd          	mov    WORD PTR [bp-0x20a],di
    2b3f:	8c 86 f8 fd          	mov    WORD PTR [bp-0x208],es
    2b43:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2b47:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2b4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b4e:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    2b53:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    2b58:	06                   	push   es
    2b59:	57                   	push   di
    2b5a:	9a 99 20 77 2b       	call   0x2b77:0x2099
    2b5f:	8d be 00 ff          	lea    di,[bp-0x100]
    2b63:	16                   	push   ss
    2b64:	57                   	push   di
    2b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b68:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    2b6d:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    2b72:	06                   	push   es
    2b73:	57                   	push   di
    2b74:	9a 03 20 98 35       	call   0x3598:0x2003
    2b79:	50                   	push   ax
    2b7a:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    2b7e:	06                   	push   es
    2b7f:	57                   	push   di
    2b80:	9a bf 17 9c 2b       	call   0x2b9c:0x17bf
    2b85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b88:	06                   	push   es
    2b89:	57                   	push   di
    2b8a:	9a 5e 34 c2 2b       	call   0x2bc2:0x345e
    2b8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b92:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    2b97:	06                   	push   es
    2b98:	57                   	push   di
    2b99:	9a 6b 22 be 2d       	call   0x2dbe:0x226b
    2b9e:	c9                   	leave
    2b9f:	ca 08 00             	retf   0x8
    2ba2:	55                   	push   bp
    2ba3:	89 e5                	mov    bp,sp
    2ba5:	31 c0                	xor    ax,ax
    2ba7:	9a 44 04 e3 2b       	call   0x2be3:0x444
    2bac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2baf:	26 80 bd 8c 08 00    	cmp    BYTE PTR es:[di+0x88c],0x0
    2bb5:	74 0f                	je     0x2bc6
    2bb7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2bba:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2bbd:	06                   	push   es
    2bbe:	57                   	push   di
    2bbf:	9a b7 28 d4 2b       	call   0x2bd4:0x28b7
    2bc4:	eb 10                	jmp    0x2bd6
    2bc6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2bc9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2bcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bcf:	06                   	push   es
    2bd0:	57                   	push   di
    2bd1:	9a 1c 27 f0 2b       	call   0x2bf0:0x271c
    2bd6:	c9                   	leave
    2bd7:	ca 08 00             	retf   0x8
    2bda:	55                   	push   bp
    2bdb:	89 e5                	mov    bp,sp
    2bdd:	b8 04 00             	mov    ax,0x4
    2be0:	9a 44 04 32 2c       	call   0x2c32:0x444
    2be5:	83 ec 04             	sub    sp,0x4
    2be8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2beb:	06                   	push   es
    2bec:	57                   	push   di
    2bed:	9a 29 2c 9b 31       	call   0x319b:0x2c29
    2bf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf5:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    2bfa:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2bfd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2c00:	06                   	push   es
    2c01:	57                   	push   di
    2c02:	9a 3f 4a 0f 2c       	call   0x2c0f:0x4a3f
    2c07:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c0a:	06                   	push   es
    2c0b:	57                   	push   di
    2c0c:	9a ff 49 19 2c       	call   0x2c19:0x49ff
    2c11:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c14:	06                   	push   es
    2c15:	57                   	push   di
    2c16:	9a e3 49 45 2c       	call   0x2c45:0x49e3
    2c1b:	c9                   	leave
    2c1c:	ca 04 00             	retf   0x4
    2c1f:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2c23:	ff                   	(bad)
    2c24:	7f 00                	jg     0x2c26
    2c26:	00 01                	add    BYTE PTR [bx+di],al
    2c28:	09 55 89             	or     WORD PTR [di-0x77],dx
    2c2b:	e5 b8                	in     ax,0xb8
    2c2d:	0c 03                	or     al,0x3
    2c2f:	9a 44 04 6c 2c       	call   0x2c6c:0x444
    2c34:	81 ec 0c 03          	sub    sp,0x30c
    2c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c3b:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    2c40:	06                   	push   es
    2c41:	57                   	push   di
    2c42:	9a e3 49 e6 34       	call   0x34e6:0x49e3
    2c47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c4a:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2c4f:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
    2c53:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
    2c57:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    2c5c:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    2c61:	2d 01 00             	sub    ax,0x1
    2c64:	83 da 00             	sbb    dx,0x0
    2c67:	71 05                	jno    0x2c6e
    2c69:	9a 3e 04 74 2c       	call   0x2c74:0x43e
    2c6e:	bf 1f 2c             	mov    di,0x2c1f
    2c71:	9a 16 04 b2 2c       	call   0x2cb2:0x416
    2c76:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    2c7a:	31 c0                	xor    ax,ax
    2c7c:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    2c80:	7e 03                	jle    0x2c85
    2c82:	e9 e3 00             	jmp    0x2d68
    2c85:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    2c89:	eb 04                	jmp    0x2c8f
    2c8b:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    2c8f:	8d be f6 fd          	lea    di,[bp-0x20a]
    2c93:	16                   	push   ss
    2c94:	57                   	push   di
    2c95:	6a 00                	push   0x0
    2c97:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    2c9b:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2c9f:	06                   	push   es
    2ca0:	57                   	push   di
    2ca1:	9a 68 9a 20 2d       	call   0x2d20:0x9a68
    2ca6:	8d be 00 ff          	lea    di,[bp-0x100]
    2caa:	16                   	push   ss
    2cab:	57                   	push   di
    2cac:	68 ff 00             	push   0xff
    2caf:	9a e7 17 cd 2c       	call   0x2ccd:0x17e7
    2cb4:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2cb8:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2cbd:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2cc2:	2d 01 00             	sub    ax,0x1
    2cc5:	83 da 00             	sbb    dx,0x0
    2cc8:	71 05                	jno    0x2ccf
    2cca:	9a 3e 04 d5 2c       	call   0x2cd5:0x43e
    2ccf:	bf 1f 2c             	mov    di,0x2c1f
    2cd2:	9a 16 04 fd 2c       	call   0x2cfd:0x416
    2cd7:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    2cdb:	b8 01 00             	mov    ax,0x1
    2cde:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    2ce2:	7f 5b                	jg     0x2d3f
    2ce4:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    2ce8:	eb 04                	jmp    0x2cee
    2cea:	ff 86 fc fe          	inc    WORD PTR [bp-0x104]
    2cee:	8d be f4 fd          	lea    di,[bp-0x20c]
    2cf2:	16                   	push   ss
    2cf3:	57                   	push   di
    2cf4:	8d be 00 ff          	lea    di,[bp-0x100]
    2cf8:	16                   	push   ss
    2cf9:	57                   	push   di
    2cfa:	9a cd 17 07 2d       	call   0x2d07:0x17cd
    2cff:	bf 27 2c             	mov    di,0x2c27
    2d02:	0e                   	push   cs
    2d03:	57                   	push   di
    2d04:	9a 4c 18 25 2d       	call   0x2d25:0x184c
    2d09:	8d be f4 fc          	lea    di,[bp-0x30c]
    2d0d:	16                   	push   ss
    2d0e:	57                   	push   di
    2d0f:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    2d13:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    2d17:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2d1b:	06                   	push   es
    2d1c:	57                   	push   di
    2d1d:	9a 68 9a ee 2f       	call   0x2fee:0x9a68
    2d22:	9a 4c 18 33 2d       	call   0x2d33:0x184c
    2d27:	8d be 00 ff          	lea    di,[bp-0x100]
    2d2b:	16                   	push   ss
    2d2c:	57                   	push   di
    2d2d:	68 ff 00             	push   0xff
    2d30:	9a e7 17 86 2d       	call   0x2d86:0x17e7
    2d35:	8b 86 fc fe          	mov    ax,WORD PTR [bp-0x104]
    2d39:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    2d3d:	75 ab                	jne    0x2cea
    2d3f:	8d be 00 ff          	lea    di,[bp-0x100]
    2d43:	16                   	push   ss
    2d44:	57                   	push   di
    2d45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d48:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    2d4d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2d52:	06                   	push   es
    2d53:	57                   	push   di
    2d54:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d57:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2d5b:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    2d5f:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    2d63:	74 03                	je     0x2d68
    2d65:	e9 23 ff             	jmp    0x2c8b
    2d68:	c9                   	leave
    2d69:	ca 04 00             	retf   0x4
    2d6c:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    2d6f:	6d                   	ins    WORD PTR es:[di],dx
    2d70:	73 74                	jae    0x2de6
    2d72:	72 61                	jb     0x2dd5
    2d74:	74 20                	je     0x2d96
    2d76:	2d 20 03             	sub    ax,0x320
    2d79:	20 2d                	and    BYTE PTR [di],ch
    2d7b:	20 00                	and    BYTE PTR [bx+si],al
    2d7d:	55                   	push   bp
    2d7e:	89 e5                	mov    bp,sp
    2d80:	b8 02 04             	mov    ax,0x402
    2d83:	9a 44 04 9a 2d       	call   0x2d9a:0x444
    2d88:	81 ec 02 04          	sub    sp,0x402
    2d8c:	8d be fe fd          	lea    di,[bp-0x202]
    2d90:	16                   	push   ss
    2d91:	57                   	push   di
    2d92:	bf 6c 2d             	mov    di,0x2d6c
    2d95:	0e                   	push   cs
    2d96:	57                   	push   di
    2d97:	9a cd 17 a4 2d       	call   0x2da4:0x17cd
    2d9c:	bf fa 1d             	mov    di,0x1dfa
    2d9f:	1e                   	push   ds
    2da0:	57                   	push   di
    2da1:	9a 4c 18 ae 2d       	call   0x2dae:0x184c
    2da6:	bf 78 2d             	mov    di,0x2d78
    2da9:	0e                   	push   cs
    2daa:	57                   	push   di
    2dab:	9a 4c 18 c3 2d       	call   0x2dc3:0x184c
    2db0:	8d be fe fc          	lea    di,[bp-0x302]
    2db4:	16                   	push   ss
    2db5:	57                   	push   di
    2db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db9:	06                   	push   es
    2dba:	57                   	push   di
    2dbb:	9a 53 1d e1 2d       	call   0x2de1:0x1d53
    2dc0:	9a 4c 18 d1 2d       	call   0x2dd1:0x184c
    2dc5:	8d be fe fe          	lea    di,[bp-0x102]
    2dc9:	16                   	push   ss
    2dca:	57                   	push   di
    2dcb:	68 ff 00             	push   0xff
    2dce:	9a e7 17 ee 2d       	call   0x2dee:0x17e7
    2dd3:	8d be fe fe          	lea    di,[bp-0x102]
    2dd7:	16                   	push   ss
    2dd8:	57                   	push   di
    2dd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ddc:	06                   	push   es
    2ddd:	57                   	push   di
    2dde:	9a 8c 1d 47 2f       	call   0x2f47:0x1d8c
    2de3:	a1 4c 01             	mov    ax,ds:0x14c
    2de6:	2d 01 00             	sub    ax,0x1
    2de9:	71 05                	jno    0x2df0
    2deb:	9a 3e 04 0e 2e       	call   0x2e0e:0x43e
    2df0:	a3 a2 1e             	mov    ds:0x1ea2,ax
    2df3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df6:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    2dfb:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2dff:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2e03:	a1 4e 01             	mov    ax,ds:0x14e
    2e06:	2d 01 00             	sub    ax,0x1
    2e09:	71 05                	jno    0x2e10
    2e0b:	9a 3e 04 d8 2e       	call   0x2ed8:0x43e
    2e10:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    2e14:	31 c0                	xor    ax,ax
    2e16:	3b 86 f8 fe          	cmp    ax,WORD PTR [bp-0x108]
    2e1a:	7f 2c                	jg     0x2e48
    2e1c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e1f:	eb 03                	jmp    0x2e24
    2e21:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2e24:	6a 01                	push   0x1
    2e26:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e29:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e2d:	06                   	push   es
    2e2e:	57                   	push   di
    2e2f:	9a 53 13 3d 2e       	call   0x2e3d:0x1353
    2e34:	89 c7                	mov    di,ax
    2e36:	8e c2                	mov    es,dx
    2e38:	06                   	push   es
    2e39:	57                   	push   di
    2e3a:	9a a5 13 66 2e       	call   0x2e66:0x13a5
    2e3f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e42:	3b 86 f8 fe          	cmp    ax,WORD PTR [bp-0x108]
    2e46:	75 d9                	jne    0x2e21
    2e48:	a1 4e 01             	mov    ax,ds:0x14e
    2e4b:	3d 07 00             	cmp    ax,0x7
    2e4e:	7f 29                	jg     0x2e79
    2e50:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e53:	eb 03                	jmp    0x2e58
    2e55:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2e58:	6a 00                	push   0x0
    2e5a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e5d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e61:	06                   	push   es
    2e62:	57                   	push   di
    2e63:	9a 53 13 71 2e       	call   0x2e71:0x1353
    2e68:	89 c7                	mov    di,ax
    2e6a:	8e c2                	mov    es,dx
    2e6c:	06                   	push   es
    2e6d:	57                   	push   di
    2e6e:	9a a5 13 86 2e       	call   0x2e86:0x13a5
    2e73:	83 7e fe 07          	cmp    WORD PTR [bp-0x2],0x7
    2e77:	75 dc                	jne    0x2e55
    2e79:	6a 01                	push   0x1
    2e7b:	6a 08                	push   0x8
    2e7d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e81:	06                   	push   es
    2e82:	57                   	push   di
    2e83:	9a 53 13 91 2e       	call   0x2e91:0x1353
    2e88:	89 c7                	mov    di,ax
    2e8a:	8e c2                	mov    es,dx
    2e8c:	06                   	push   es
    2e8d:	57                   	push   di
    2e8e:	9a a5 13 a2 2e       	call   0x2ea2:0x13a5
    2e93:	6a 00                	push   0x0
    2e95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e98:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    2e9d:	06                   	push   es
    2e9e:	57                   	push   di
    2e9f:	9a a5 13 b3 2e       	call   0x2eb3:0x13a5
    2ea4:	6a 00                	push   0x0
    2ea6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea9:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2eae:	06                   	push   es
    2eaf:	57                   	push   di
    2eb0:	9a a5 13 c4 2e       	call   0x2ec4:0x13a5
    2eb5:	6a 00                	push   0x0
    2eb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eba:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    2ebf:	06                   	push   es
    2ec0:	57                   	push   di
    2ec1:	9a a5 13 fe 31       	call   0x31fe:0x13a5
    2ec6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec9:	06                   	push   es
    2eca:	57                   	push   di
    2ecb:	9a 7d 52 fc 2e       	call   0x2efc:0x527d
    2ed0:	2d 01 00             	sub    ax,0x1
    2ed3:	71 05                	jno    0x2eda
    2ed5:	9a 3e 04 0b 2f       	call   0x2f0b:0x43e
    2eda:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    2ede:	31 c0                	xor    ax,ax
    2ee0:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    2ee4:	7e 03                	jle    0x2ee9
    2ee6:	e9 7e 00             	jmp    0x2f67
    2ee9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2eec:	eb 03                	jmp    0x2ef1
    2eee:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2ef1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ef4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef7:	06                   	push   es
    2ef8:	57                   	push   di
    2ef9:	9a 46 52 1c 2f       	call   0x2f1c:0x5246
    2efe:	52                   	push   dx
    2eff:	50                   	push   ax
    2f00:	bf ad 0d             	mov    di,0xdad
    2f03:	b8 24 2f             	mov    ax,0x2f24
    2f06:	50                   	push   ax
    2f07:	57                   	push   di
    2f08:	9a 55 22 2b 2f       	call   0x2f2b:0x2255
    2f0d:	08 c0                	or     al,al
    2f0f:	74 4d                	je     0x2f5e
    2f11:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f17:	06                   	push   es
    2f18:	57                   	push   di
    2f19:	9a 46 52 ff ff       	call   0xffff:0x5246
    2f1e:	52                   	push   dx
    2f1f:	50                   	push   ax
    2f20:	bf ad 0d             	mov    di,0xdad
    2f23:	b8 5c 2f             	mov    ax,0x2f5c
    2f26:	50                   	push   ax
    2f27:	57                   	push   di
    2f28:	9a 73 22 94 2f       	call   0x2f94:0x2273
    2f2d:	89 c7                	mov    di,ax
    2f2f:	8e c2                	mov    es,dx
    2f31:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
    2f35:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
    2f39:	bf 7c 2d             	mov    di,0x2d7c
    2f3c:	0e                   	push   cs
    2f3d:	57                   	push   di
    2f3e:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2f42:	06                   	push   es
    2f43:	57                   	push   di
    2f44:	9a 8c 1d b9 2f       	call   0x2fb9:0x1d8c
    2f49:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2f4d:	26 80 bd dd 00 02    	cmp    BYTE PTR es:[di+0xdd],0x2
    2f53:	75 09                	jne    0x2f5e
    2f55:	6a 00                	push   0x0
    2f57:	06                   	push   es
    2f58:	57                   	push   di
    2f59:	9a 3e 2c 76 2f       	call   0x2f76:0x2c3e
    2f5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f61:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    2f65:	75 87                	jne    0x2eee
    2f67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6a:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    2f6f:	6a 02                	push   0x2
    2f71:	06                   	push   es
    2f72:	57                   	push   di
    2f73:	9a 3e 2c a7 2f       	call   0x2fa7:0x2c3e
    2f78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f7b:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    2f80:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2f84:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2f88:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2f8c:	05 01 00             	add    ax,0x1
    2f8f:	71 05                	jno    0x2f96
    2f91:	9a 3e 04 ae 2f       	call   0x2fae:0x43e
    2f96:	50                   	push   ax
    2f97:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f9b:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    2f9f:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    2fa3:	bf ad 0d             	mov    di,0xdad
    2fa6:	b8 a8 3b             	mov    ax,0x3ba8
    2fa9:	50                   	push   ax
    2faa:	57                   	push   di
    2fab:	9a 73 22 52 30       	call   0x3052:0x2273
    2fb0:	89 c7                	mov    di,ax
    2fb2:	8e c2                	mov    es,dx
    2fb4:	06                   	push   es
    2fb5:	57                   	push   di
    2fb6:	9a e1 17 c6 2f       	call   0x2fc6:0x17e1
    2fbb:	6a 02                	push   0x2
    2fbd:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2fc1:	06                   	push   es
    2fc2:	57                   	push   di
    2fc3:	9a 72 16 df 2f       	call   0x2fdf:0x1672
    2fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fcb:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2fd0:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2fd4:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2fd8:	6a 05                	push   0x5
    2fda:	06                   	push   es
    2fdb:	57                   	push   di
    2fdc:	9a 72 16 48 30       	call   0x3048:0x1672
    2fe1:	6a 00                	push   0x0
    2fe3:	6a 01                	push   0x1
    2fe5:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2fe9:	06                   	push   es
    2fea:	57                   	push   di
    2feb:	9a 1b 70 fd 2f       	call   0x2ffd:0x701b
    2ff0:	6a 00                	push   0x0
    2ff2:	6a 01                	push   0x1
    2ff4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2ff8:	06                   	push   es
    2ff9:	57                   	push   di
    2ffa:	9a 26 74 11 30       	call   0x3011:0x7426
    2fff:	6a 00                	push   0x0
    3001:	6a 00                	push   0x0
    3003:	bf 7c 2d             	mov    di,0x2d7c
    3006:	0e                   	push   cs
    3007:	57                   	push   di
    3008:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    300c:	06                   	push   es
    300d:	57                   	push   di
    300e:	9a 08 9b 36 42       	call   0x4236:0x9b08
    3013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3016:	26 c6 85 86 08 00    	mov    BYTE PTR es:[di+0x886],0x0
    301c:	26 c6 85 87 08 00    	mov    BYTE PTR es:[di+0x887],0x0
    3022:	26 c6 85 88 08 00    	mov    BYTE PTR es:[di+0x888],0x0
    3028:	26 c6 85 89 08 00    	mov    BYTE PTR es:[di+0x889],0x0
    302e:	26 c6 85 8c 08 01    	mov    BYTE PTR es:[di+0x88c],0x1
    3034:	8d be fe fd          	lea    di,[bp-0x202]
    3038:	16                   	push   ss
    3039:	57                   	push   di
    303a:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    303e:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    3043:	06                   	push   es
    3044:	57                   	push   di
    3045:	9a 53 1d 68 30       	call   0x3068:0x1d53
    304a:	bf 78 2d             	mov    di,0x2d78
    304d:	0e                   	push   cs
    304e:	57                   	push   di
    304f:	9a 4c 18 6d 30       	call   0x306d:0x184c
    3054:	8d be fe fc          	lea    di,[bp-0x302]
    3058:	16                   	push   ss
    3059:	57                   	push   di
    305a:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    305e:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    3063:	06                   	push   es
    3064:	57                   	push   di
    3065:	9a 53 1d 7c 30       	call   0x307c:0x1d53
    306a:	9a 4c 18 9c 30       	call   0x309c:0x184c
    306f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3072:	26 c4 bd 24 04       	les    di,DWORD PTR es:[di+0x424]
    3077:	06                   	push   es
    3078:	57                   	push   di
    3079:	9a 8c 1d 92 30       	call   0x3092:0x1d8c
    307e:	8d be fe fd          	lea    di,[bp-0x202]
    3082:	16                   	push   ss
    3083:	57                   	push   di
    3084:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3088:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    308d:	06                   	push   es
    308e:	57                   	push   di
    308f:	9a 53 1d ff 30       	call   0x30ff:0x1d53
    3094:	bf 78 2d             	mov    di,0x2d78
    3097:	0e                   	push   cs
    3098:	57                   	push   di
    3099:	9a 4c 18 bc 30       	call   0x30bc:0x184c
    309e:	8d be fe fc          	lea    di,[bp-0x302]
    30a2:	16                   	push   ss
    30a3:	57                   	push   di
    30a4:	9a fe 15 b7 30       	call   0x30b7:0x15fe
    30a9:	83 ec 08             	sub    sp,0x8
    30ac:	89 e3                	mov    bx,sp
    30ae:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    30b2:	90                   	nop
    30b3:	9b                   	fwait
    30b4:	9a bf 1c d1 30       	call   0x30d1:0x1cbf
    30b9:	9a 4c 18 c6 30       	call   0x30c6:0x184c
    30be:	bf 78 2d             	mov    di,0x2d78
    30c1:	0e                   	push   cs
    30c2:	57                   	push   di
    30c3:	9a 4c 18 e6 30       	call   0x30e6:0x184c
    30c8:	8d be fe fb          	lea    di,[bp-0x402]
    30cc:	16                   	push   ss
    30cd:	57                   	push   di
    30ce:	9a fe 15 e1 30       	call   0x30e1:0x15fe
    30d3:	83 ec 08             	sub    sp,0x8
    30d6:	89 e3                	mov    bx,sp
    30d8:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    30dc:	90                   	nop
    30dd:	9b                   	fwait
    30de:	9a e4 1c 48 3e       	call   0x3e48:0x1ce4
    30e3:	9a 4c 18 f0 30       	call   0x30f0:0x184c
    30e8:	bf 78 2d             	mov    di,0x2d78
    30eb:	0e                   	push   cs
    30ec:	57                   	push   di
    30ed:	9a 4c 18 a9 31       	call   0x31a9:0x184c
    30f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f5:	26 c4 bd 28 04       	les    di,DWORD PTR es:[di+0x428]
    30fa:	06                   	push   es
    30fb:	57                   	push   di
    30fc:	9a 8c 1d eb 31       	call   0x31eb:0x1d8c
    3101:	bf 32 1e             	mov    di,0x1e32
    3104:	1e                   	push   ds
    3105:	57                   	push   di
    3106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3109:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    310e:	06                   	push   es
    310f:	57                   	push   di
    3110:	9a 17 30 27 31       	call   0x3127:0x3017
    3115:	bf 40 1e             	mov    di,0x1e40
    3118:	1e                   	push   ds
    3119:	57                   	push   di
    311a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    311d:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    3122:	06                   	push   es
    3123:	57                   	push   di
    3124:	9a 17 30 3b 31       	call   0x313b:0x3017
    3129:	bf 4e 1e             	mov    di,0x1e4e
    312c:	1e                   	push   ds
    312d:	57                   	push   di
    312e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3131:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    3136:	06                   	push   es
    3137:	57                   	push   di
    3138:	9a 17 30 4f 31       	call   0x314f:0x3017
    313d:	bf 5c 1e             	mov    di,0x1e5c
    3140:	1e                   	push   ds
    3141:	57                   	push   di
    3142:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3145:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    314a:	06                   	push   es
    314b:	57                   	push   di
    314c:	9a 17 30 63 31       	call   0x3163:0x3017
    3151:	bf 78 1e             	mov    di,0x1e78
    3154:	1e                   	push   ds
    3155:	57                   	push   di
    3156:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3159:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    315e:	06                   	push   es
    315f:	57                   	push   di
    3160:	9a 17 30 77 31       	call   0x3177:0x3017
    3165:	bf 86 1e             	mov    di,0x1e86
    3168:	1e                   	push   ds
    3169:	57                   	push   di
    316a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    316d:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    3172:	06                   	push   es
    3173:	57                   	push   di
    3174:	9a 17 30 8b 31       	call   0x318b:0x3017
    3179:	bf 94 1e             	mov    di,0x1e94
    317c:	1e                   	push   ds
    317d:	57                   	push   di
    317e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3181:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    3186:	06                   	push   es
    3187:	57                   	push   di
    3188:	9a 17 30 95 50       	call   0x5095:0x3017
    318d:	ff 76 08             	push   WORD PTR [bp+0x8]
    3190:	ff 76 06             	push   WORD PTR [bp+0x6]
    3193:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3196:	06                   	push   es
    3197:	57                   	push   di
    3198:	9a b7 28 bd 31       	call   0x31bd:0x28b7
    319d:	c9                   	leave
    319e:	ca 08 00             	retf   0x8
    31a1:	55                   	push   bp
    31a2:	89 e5                	mov    bp,sp
    31a4:	31 c0                	xor    ax,ax
    31a6:	9a 44 04 d8 31       	call   0x31d8:0x444
    31ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ae:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    31b3:	26 ff b5 48 04       	push   WORD PTR es:[di+0x448]
    31b8:	06                   	push   es
    31b9:	57                   	push   di
    31ba:	9a cb 4b 06 33       	call   0x3306:0x4bcb
    31bf:	6a 00                	push   0x0
    31c1:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    31c5:	06                   	push   es
    31c6:	57                   	push   di
    31c7:	9a a9 63 a5 33       	call   0x33a5:0x63a9
    31cc:	c9                   	leave
    31cd:	ca 08 00             	retf   0x8
    31d0:	55                   	push   bp
    31d1:	89 e5                	mov    bp,sp
    31d3:	31 c0                	xor    ax,ax
    31d5:	9a 44 04 45 32       	call   0x3245:0x444
    31da:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    31dd:	50                   	push   ax
    31de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e1:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    31e6:	06                   	push   es
    31e7:	57                   	push   di
    31e8:	9a 77 1c 6b 32       	call   0x326b:0x1c77
    31ed:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    31f0:	50                   	push   ax
    31f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f4:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    31f9:	06                   	push   es
    31fa:	57                   	push   di
    31fb:	9a 9b 12 11 32       	call   0x3211:0x129b
    3200:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3203:	50                   	push   ax
    3204:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3207:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    320c:	06                   	push   es
    320d:	57                   	push   di
    320e:	9a 9b 12 24 32       	call   0x3224:0x129b
    3213:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3216:	50                   	push   ax
    3217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    321a:	26 c4 bd b4 03       	les    di,DWORD PTR es:[di+0x3b4]
    321f:	06                   	push   es
    3220:	57                   	push   di
    3221:	9a 9b 12 37 32       	call   0x3237:0x129b
    3226:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3229:	50                   	push   ax
    322a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322d:	26 c4 bd 38 02       	les    di,DWORD PTR es:[di+0x238]
    3232:	06                   	push   es
    3233:	57                   	push   di
    3234:	9a 9b 12 58 32       	call   0x3258:0x129b
    3239:	c9                   	leave
    323a:	ca 06 00             	retf   0x6
    323d:	55                   	push   bp
    323e:	89 e5                	mov    bp,sp
    3240:	31 c0                	xor    ax,ax
    3242:	9a 44 04 19 33       	call   0x3319:0x444
    3247:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    324a:	50                   	push   ax
    324b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    324e:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3253:	06                   	push   es
    3254:	57                   	push   di
    3255:	9a 9b 12 7e 32       	call   0x327e:0x129b
    325a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    325d:	50                   	push   ax
    325e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3261:	26 c4 bd f0 03       	les    di,DWORD PTR es:[di+0x3f0]
    3266:	06                   	push   es
    3267:	57                   	push   di
    3268:	9a b8 1c 91 32       	call   0x3291:0x1cb8
    326d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3270:	50                   	push   ax
    3271:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3274:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3279:	06                   	push   es
    327a:	57                   	push   di
    327b:	9a 9b 12 b9 39       	call   0x39b9:0x129b
    3280:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3283:	50                   	push   ax
    3284:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3287:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
    328c:	06                   	push   es
    328d:	57                   	push   di
    328e:	9a b8 1c a4 32       	call   0x32a4:0x1cb8
    3293:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3296:	50                   	push   ax
    3297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329a:	26 c4 bd f8 03       	les    di,DWORD PTR es:[di+0x3f8]
    329f:	06                   	push   es
    32a0:	57                   	push   di
    32a1:	9a b8 1c b7 32       	call   0x32b7:0x1cb8
    32a6:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    32a9:	50                   	push   ax
    32aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32ad:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    32b2:	06                   	push   es
    32b3:	57                   	push   di
    32b4:	9a b8 1c ca 32       	call   0x32ca:0x1cb8
    32b9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    32bc:	50                   	push   ax
    32bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32c0:	26 c4 bd 00 04       	les    di,DWORD PTR es:[di+0x400]
    32c5:	06                   	push   es
    32c6:	57                   	push   di
    32c7:	9a b8 1c dd 32       	call   0x32dd:0x1cb8
    32cc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    32cf:	50                   	push   ax
    32d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32d3:	26 c4 bd 04 04       	les    di,DWORD PTR es:[di+0x404]
    32d8:	06                   	push   es
    32d9:	57                   	push   di
    32da:	9a b8 1c f0 32       	call   0x32f0:0x1cb8
    32df:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    32e2:	50                   	push   ax
    32e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e6:	26 c4 bd 0c 04       	les    di,DWORD PTR es:[di+0x40c]
    32eb:	06                   	push   es
    32ec:	57                   	push   di
    32ed:	9a b8 1c 43 33       	call   0x3343:0x1cb8
    32f2:	c9                   	leave
    32f3:	ca 06 00             	retf   0x6
    32f6:	eb ff                	jmp    0x32f7
    32f8:	ff                   	(bad)
    32f9:	ff                   	(bad)
    32fa:	ff                   	(bad)
    32fb:	ff                   	(bad)
    32fc:	ff 02                	inc    WORD PTR [bp+si]
    32fe:	01 00                	add    WORD PTR [bx+si],ax
    3300:	00 00                	add    BYTE PTR [bx+si],al
    3302:	00 00                	add    BYTE PTR [bx+si],al
    3304:	b0 33                	mov    al,0x33
    3306:	58                   	pop    ax
    3307:	34 eb                	xor    al,0xeb
    3309:	ff                   	(bad)
    330a:	ff                   	(bad)
    330b:	ff                   	(bad)
    330c:	ff                   	(bad)
    330d:	ff                   	(bad)
    330e:	ff 02                	inc    WORD PTR [bp+si]
    3310:	55                   	push   bp
    3311:	89 e5                	mov    bp,sp
    3313:	b8 04 00             	mov    ax,0x4
    3316:	9a 44 04 78 33       	call   0x3378:0x444
    331b:	83 ec 04             	sub    sp,0x4
    331e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3321:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    3326:	06                   	push   es
    3327:	57                   	push   di
    3328:	9a 17 2f 40 34       	call   0x3440:0x2f17
    332d:	08 c0                	or     al,al
    332f:	75 03                	jne    0x3334
    3331:	e9 d9 00             	jmp    0x340d
    3334:	6a 00                	push   0x0
    3336:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3339:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    333e:	06                   	push   es
    333f:	57                   	push   di
    3340:	9a 77 1c 54 33       	call   0x3354:0x1c77
    3345:	6a 00                	push   0x0
    3347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    334a:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
    334f:	06                   	push   es
    3350:	57                   	push   di
    3351:	9a 77 1c 65 33       	call   0x3365:0x1c77
    3356:	6a 01                	push   0x1
    3358:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    335b:	26 c4 bd 20 04       	les    di,DWORD PTR es:[di+0x420]
    3360:	06                   	push   es
    3361:	57                   	push   di
    3362:	9a 77 1c 8d 33       	call   0x338d:0x1c77
    3367:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    336a:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    336e:	26 8b 55 3a          	mov    dx,WORD PTR es:[di+0x3a]
    3372:	bf f6 32             	mov    di,0x32f6
    3375:	9a 16 04 b3 33       	call   0x33b3:0x416
    337a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    337d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3380:	68 ff 00             	push   0xff
    3383:	6a ff                	push   0xffff
    3385:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3388:	06                   	push   es
    3389:	57                   	push   di
    338a:	9a d5 1e cd 33       	call   0x33cd:0x1ed5
    338f:	b8 fe 32             	mov    ax,0x32fe
    3392:	0e                   	push   cs
    3393:	50                   	push   ax
    3394:	55                   	push   bp
    3395:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3399:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    339d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a0:	06                   	push   es
    33a1:	57                   	push   di
    33a2:	9a 2d 5a 0b 34       	call   0x340b:0x5a2d
    33a7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    33ab:	83 c4 06             	add    sp,0x6
    33ae:	eb 05                	jmp    0x33b5
    33b0:	9a 34 14 c1 33       	call   0x33c1:0x1434
    33b5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33b8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33bb:	bf 08 33             	mov    di,0x3308
    33be:	9a 16 04 19 34       	call   0x3419:0x416
    33c3:	52                   	push   dx
    33c4:	50                   	push   ax
    33c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c8:	06                   	push   es
    33c9:	57                   	push   di
    33ca:	9a d5 1e de 33       	call   0x33de:0x1ed5
    33cf:	6a 00                	push   0x0
    33d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d4:	26 c4 bd 20 04       	les    di,DWORD PTR es:[di+0x420]
    33d9:	06                   	push   es
    33da:	57                   	push   di
    33db:	9a 77 1c ef 33       	call   0x33ef:0x1c77
    33e0:	6a 01                	push   0x1
    33e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e5:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
    33ea:	06                   	push   es
    33eb:	57                   	push   di
    33ec:	9a 77 1c 00 34       	call   0x3400:0x1c77
    33f1:	6a 01                	push   0x1
    33f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33f6:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    33fb:	06                   	push   es
    33fc:	57                   	push   di
    33fd:	9a 77 1c b3 34       	call   0x34b3:0x1c77
    3402:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3406:	06                   	push   es
    3407:	57                   	push   di
    3408:	9a 03 73 23 34       	call   0x3423:0x7303
    340d:	c9                   	leave
    340e:	ca 08 00             	retf   0x8
    3411:	55                   	push   bp
    3412:	89 e5                	mov    bp,sp
    3414:	31 c0                	xor    ax,ax
    3416:	9a 44 04 31 34       	call   0x3431:0x444
    341b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341e:	06                   	push   es
    341f:	57                   	push   di
    3420:	9a 56 55 0d 8a       	call   0x8a0d:0x5556
    3425:	c9                   	leave
    3426:	ca 08 00             	retf   0x8
    3429:	55                   	push   bp
    342a:	89 e5                	mov    bp,sp
    342c:	31 c0                	xor    ax,ax
    342e:	9a 44 04 4e 34       	call   0x344e:0x444
    3433:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3436:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    343b:	06                   	push   es
    343c:	57                   	push   di
    343d:	9a 41 2e 94 3c       	call   0x3c94:0x2e41
    3442:	c9                   	leave
    3443:	ca 08 00             	retf   0x8
    3446:	55                   	push   bp
    3447:	89 e5                	mov    bp,sp
    3449:	31 c0                	xor    ax,ax
    344b:	9a 44 04 67 34       	call   0x3467:0x444
    3450:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3453:	06                   	push   es
    3454:	57                   	push   di
    3455:	9a da 2b 74 34       	call   0x3474:0x2bda
    345a:	c9                   	leave
    345b:	ca 08 00             	retf   0x8
    345e:	55                   	push   bp
    345f:	89 e5                	mov    bp,sp
    3461:	b8 06 00             	mov    ax,0x6
    3464:	9a 44 04 d1 34       	call   0x34d1:0x444
    3469:	83 ec 06             	sub    sp,0x6
    346c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    346f:	06                   	push   es
    3470:	57                   	push   di
    3471:	9a 05 14 a0 34       	call   0x34a0:0x1405
    3476:	8b c8                	mov    cx,ax
    3478:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    347b:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    3480:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3484:	99                   	cwd
    3485:	f7 f9                	idiv   cx
    3487:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    348a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    348d:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    3492:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3495:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3498:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    349b:	06                   	push   es
    349c:	57                   	push   di
    349d:	9a c6 13 c7 34       	call   0x34c7:0x13c6
    34a2:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    34a5:	b0 00                	mov    al,0x0
    34a7:	7e 01                	jle    0x34aa
    34a9:	40                   	inc    ax
    34aa:	50                   	push   ax
    34ab:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    34ae:	06                   	push   es
    34af:	57                   	push   di
    34b0:	9a 77 1c 18 35       	call   0x3518:0x1c77
    34b5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    34b8:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    34bd:	74 29                	je     0x34e8
    34bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c2:	06                   	push   es
    34c3:	57                   	push   di
    34c4:	9a c6 13 3f 35       	call   0x353f:0x13c6
    34c9:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    34cc:	71 05                	jno    0x34d3
    34ce:	9a 3e 04 db 34       	call   0x34db:0x43e
    34d3:	05 01 00             	add    ax,0x1
    34d6:	71 05                	jno    0x34dd
    34d8:	9a 3e 04 03 35       	call   0x3503:0x43e
    34dd:	50                   	push   ax
    34de:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    34e1:	06                   	push   es
    34e2:	57                   	push   di
    34e3:	9a a8 85 f5 34       	call   0x34f5:0x85a8
    34e8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    34eb:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
    34f0:	06                   	push   es
    34f1:	57                   	push   di
    34f2:	9a 6c 85 ff ff       	call   0xffff:0x856c
    34f7:	c9                   	leave
    34f8:	ca 04 00             	retf   0x4
    34fb:	55                   	push   bp
    34fc:	89 e5                	mov    bp,sp
    34fe:	31 c0                	xor    ax,ax
    3500:	9a 44 04 35 35       	call   0x3535:0x444
    3505:	80 7e 0e 08          	cmp    BYTE PTR [bp+0xe],0x8
    3509:	75 1e                	jne    0x3529
    350b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    350e:	26 c4 bd 20 02       	les    di,DWORD PTR es:[di+0x220]
    3513:	06                   	push   es
    3514:	57                   	push   di
    3515:	9a 58 22 27 35       	call   0x3527:0x2258
    351a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    351d:	26 c4 bd 20 02       	les    di,DWORD PTR es:[di+0x220]
    3522:	06                   	push   es
    3523:	57                   	push   di
    3524:	9a 6b 22 d5 37       	call   0x37d5:0x226b
    3529:	c9                   	leave
    352a:	ca 0e 00             	retf   0xe
    352d:	55                   	push   bp
    352e:	89 e5                	mov    bp,sp
    3530:	31 c0                	xor    ax,ax
    3532:	9a 44 04 4e 35       	call   0x354e:0x444
    3537:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    353a:	06                   	push   es
    353b:	57                   	push   di
    353c:	9a 5e 34 fc 38       	call   0x38fc:0x345e
    3541:	c9                   	leave
    3542:	ca 08 00             	retf   0x8
    3545:	55                   	push   bp
    3546:	89 e5                	mov    bp,sp
    3548:	b8 14 01             	mov    ax,0x114
    354b:	9a 44 04 cc 35       	call   0x35cc:0x444
    3550:	81 ec 14 01          	sub    sp,0x114
    3554:	31 c0                	xor    ax,ax
    3556:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    355a:	31 c0                	xor    ax,ax
    355c:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    3560:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3563:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    3568:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    356c:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    3570:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3573:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    3578:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    357c:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    3580:	8d be f4 fe          	lea    di,[bp-0x10c]
    3584:	16                   	push   ss
    3585:	57                   	push   di
    3586:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3589:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    358e:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    3593:	06                   	push   es
    3594:	57                   	push   di
    3595:	9a e5 1c dd 35       	call   0x35dd:0x1ce5
    359a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    359d:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    35a2:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    35a6:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    35aa:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    35af:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    35b3:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    35b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ba:	81 c7 5c 06          	add    di,0x65c
    35be:	06                   	push   es
    35bf:	57                   	push   di
    35c0:	8d be fc fe          	lea    di,[bp-0x104]
    35c4:	16                   	push   ss
    35c5:	57                   	push   di
    35c6:	68 ff 00             	push   0xff
    35c9:	9a e7 17 f0 35       	call   0x35f0:0x17e7
    35ce:	8d be fc fe          	lea    di,[bp-0x104]
    35d2:	16                   	push   ss
    35d3:	57                   	push   di
    35d4:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    35d8:	06                   	push   es
    35d9:	57                   	push   di
    35da:	9a 03 20 1d 36       	call   0x361d:0x2003
    35df:	8b d0                	mov    dx,ax
    35e1:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    35e5:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    35e9:	2b c2                	sub    ax,dx
    35eb:	71 05                	jno    0x35f2
    35ed:	9a 3e 04 09 36       	call   0x3609:0x43e
    35f2:	99                   	cwd
    35f3:	b9 02 00             	mov    cx,0x2
    35f6:	f7 f9                	idiv   cx
    35f8:	8b d0                	mov    dx,ax
    35fa:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    35fe:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    3602:	2b c2                	sub    ax,dx
    3604:	71 05                	jno    0x360b
    3606:	9a 3e 04 30 36       	call   0x3630:0x43e
    360b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    360e:	8d be fc fe          	lea    di,[bp-0x104]
    3612:	16                   	push   ss
    3613:	57                   	push   di
    3614:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3618:	06                   	push   es
    3619:	57                   	push   di
    361a:	9a 4e 20 50 36       	call   0x3650:0x204e
    361f:	8b d0                	mov    dx,ax
    3621:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    3625:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3629:	2b c2                	sub    ax,dx
    362b:	71 05                	jno    0x3632
    362d:	9a 3e 04 5f 36       	call   0x365f:0x43e
    3632:	99                   	cwd
    3633:	b9 02 00             	mov    cx,0x2
    3636:	f7 f9                	idiv   cx
    3638:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    363b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    363e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3641:	8d be fc fe          	lea    di,[bp-0x104]
    3645:	16                   	push   ss
    3646:	57                   	push   di
    3647:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    364b:	06                   	push   es
    364c:	57                   	push   di
    364d:	9a 09 1f a9 36       	call   0x36a9:0x1f09
    3652:	c9                   	leave
    3653:	ca 08 00             	retf   0x8
    3656:	55                   	push   bp
    3657:	89 e5                	mov    bp,sp
    3659:	b8 14 01             	mov    ax,0x114
    365c:	9a 44 04 dd 36       	call   0x36dd:0x444
    3661:	81 ec 14 01          	sub    sp,0x114
    3665:	31 c0                	xor    ax,ax
    3667:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    366b:	31 c0                	xor    ax,ax
    366d:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    3671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3674:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    3679:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    367d:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    3681:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3684:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    3689:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    368d:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    3691:	8d be f4 fe          	lea    di,[bp-0x10c]
    3695:	16                   	push   ss
    3696:	57                   	push   di
    3697:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    369a:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    369f:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    36a4:	06                   	push   es
    36a5:	57                   	push   di
    36a6:	9a e5 1c ee 36       	call   0x36ee:0x1ce5
    36ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ae:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    36b3:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    36b7:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    36bb:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    36c0:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    36c4:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    36c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36cb:	81 c7 5c 07          	add    di,0x75c
    36cf:	06                   	push   es
    36d0:	57                   	push   di
    36d1:	8d be fc fe          	lea    di,[bp-0x104]
    36d5:	16                   	push   ss
    36d6:	57                   	push   di
    36d7:	68 ff 00             	push   0xff
    36da:	9a e7 17 01 37       	call   0x3701:0x17e7
    36df:	8d be fc fe          	lea    di,[bp-0x104]
    36e3:	16                   	push   ss
    36e4:	57                   	push   di
    36e5:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    36e9:	06                   	push   es
    36ea:	57                   	push   di
    36eb:	9a 03 20 1b 37       	call   0x371b:0x2003
    36f0:	8b d0                	mov    dx,ax
    36f2:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    36f6:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    36fa:	2b c2                	sub    ax,dx
    36fc:	71 05                	jno    0x3703
    36fe:	9a 3e 04 2e 37       	call   0x372e:0x43e
    3703:	99                   	cwd
    3704:	b9 02 00             	mov    cx,0x2
    3707:	f7 f9                	idiv   cx
    3709:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    370c:	8d be fc fe          	lea    di,[bp-0x104]
    3710:	16                   	push   ss
    3711:	57                   	push   di
    3712:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3716:	06                   	push   es
    3717:	57                   	push   di
    3718:	9a 4e 20 61 37       	call   0x3761:0x204e
    371d:	8b d0                	mov    dx,ax
    371f:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    3723:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3727:	2b c2                	sub    ax,dx
    3729:	71 05                	jno    0x3730
    372b:	9a 3e 04 47 37       	call   0x3747:0x43e
    3730:	99                   	cwd
    3731:	b9 02 00             	mov    cx,0x2
    3734:	f7 f9                	idiv   cx
    3736:	8b d0                	mov    dx,ax
    3738:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    373c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3740:	2b c2                	sub    ax,dx
    3742:	71 05                	jno    0x3749
    3744:	9a 3e 04 70 37       	call   0x3770:0x43e
    3749:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    374c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    374f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3752:	8d be fc fe          	lea    di,[bp-0x104]
    3756:	16                   	push   ss
    3757:	57                   	push   di
    3758:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    375c:	06                   	push   es
    375d:	57                   	push   di
    375e:	9a 09 1f bd 37       	call   0x37bd:0x1f09
    3763:	c9                   	leave
    3764:	ca 08 00             	retf   0x8
    3767:	55                   	push   bp
    3768:	89 e5                	mov    bp,sp
    376a:	b8 04 01             	mov    ax,0x104
    376d:	9a 44 04 a2 37       	call   0x37a2:0x444
    3772:	81 ec 04 01          	sub    sp,0x104
    3776:	8c d3                	mov    bx,ss
    3778:	8e c3                	mov    es,bx
    377a:	8c db                	mov    bx,ds
    377c:	fc                   	cld
    377d:	8d be 00 ff          	lea    di,[bp-0x100]
    3781:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    3784:	ac                   	lods   al,BYTE PTR ds:[si]
    3785:	aa                   	stos   BYTE PTR es:[di],al
    3786:	91                   	xchg   cx,ax
    3787:	30 ed                	xor    ch,ch
    3789:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    378b:	8e db                	mov    ds,bx
    378d:	8d be 00 ff          	lea    di,[bp-0x100]
    3791:	16                   	push   ss
    3792:	57                   	push   di
    3793:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3796:	81 c7 5c 04          	add    di,0x45c
    379a:	06                   	push   es
    379b:	57                   	push   di
    379c:	68 ff 00             	push   0xff
    379f:	9a e7 17 c9 37       	call   0x37c9:0x17e7
    37a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37a7:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    37ac:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    37b0:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    37b4:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    37b8:	06                   	push   es
    37b9:	57                   	push   di
    37ba:	9a cc 11 45 38       	call   0x3845:0x11cc
    37bf:	b9 02 00             	mov    cx,0x2
    37c2:	f7 e9                	imul   cx
    37c4:	71 05                	jno    0x37cb
    37c6:	9a 3e 04 f8 37       	call   0x37f8:0x43e
    37cb:	50                   	push   ax
    37cc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    37d0:	06                   	push   es
    37d1:	57                   	push   di
    37d2:	9a e1 17 e9 37       	call   0x37e9:0x17e1
    37d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37da:	81 c7 5c 04          	add    di,0x45c
    37de:	06                   	push   es
    37df:	57                   	push   di
    37e0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    37e4:	06                   	push   es
    37e5:	57                   	push   di
    37e6:	9a 8c 1d 5d 38       	call   0x385d:0x1d8c
    37eb:	c9                   	leave
    37ec:	ca 08 00             	retf   0x8
    37ef:	55                   	push   bp
    37f0:	89 e5                	mov    bp,sp
    37f2:	b8 04 01             	mov    ax,0x104
    37f5:	9a 44 04 2a 38       	call   0x382a:0x444
    37fa:	81 ec 04 01          	sub    sp,0x104
    37fe:	8c d3                	mov    bx,ss
    3800:	8e c3                	mov    es,bx
    3802:	8c db                	mov    bx,ds
    3804:	fc                   	cld
    3805:	8d be 00 ff          	lea    di,[bp-0x100]
    3809:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    380c:	ac                   	lods   al,BYTE PTR ds:[si]
    380d:	aa                   	stos   BYTE PTR es:[di],al
    380e:	91                   	xchg   cx,ax
    380f:	30 ed                	xor    ch,ch
    3811:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    3813:	8e db                	mov    ds,bx
    3815:	8d be 00 ff          	lea    di,[bp-0x100]
    3819:	16                   	push   ss
    381a:	57                   	push   di
    381b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    381e:	81 c7 5c 05          	add    di,0x55c
    3822:	06                   	push   es
    3823:	57                   	push   di
    3824:	68 ff 00             	push   0xff
    3827:	9a e7 17 51 38       	call   0x3851:0x17e7
    382c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    382f:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3834:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    3838:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    383c:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3840:	06                   	push   es
    3841:	57                   	push   di
    3842:	9a cc 11 cd 38       	call   0x38cd:0x11cc
    3847:	b9 02 00             	mov    cx,0x2
    384a:	f7 e9                	imul   cx
    384c:	71 05                	jno    0x3853
    384e:	9a 3e 04 80 38       	call   0x3880:0x43e
    3853:	50                   	push   ax
    3854:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3858:	06                   	push   es
    3859:	57                   	push   di
    385a:	9a e1 17 71 38       	call   0x3871:0x17e1
    385f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3862:	81 c7 5c 05          	add    di,0x55c
    3866:	06                   	push   es
    3867:	57                   	push   di
    3868:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    386c:	06                   	push   es
    386d:	57                   	push   di
    386e:	9a 8c 1d e5 38       	call   0x38e5:0x1d8c
    3873:	c9                   	leave
    3874:	ca 08 00             	retf   0x8
    3877:	55                   	push   bp
    3878:	89 e5                	mov    bp,sp
    387a:	b8 04 01             	mov    ax,0x104
    387d:	9a 44 04 b2 38       	call   0x38b2:0x444
    3882:	81 ec 04 01          	sub    sp,0x104
    3886:	8c d3                	mov    bx,ss
    3888:	8e c3                	mov    es,bx
    388a:	8c db                	mov    bx,ds
    388c:	fc                   	cld
    388d:	8d be 00 ff          	lea    di,[bp-0x100]
    3891:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    3894:	ac                   	lods   al,BYTE PTR ds:[si]
    3895:	aa                   	stos   BYTE PTR es:[di],al
    3896:	91                   	xchg   cx,ax
    3897:	30 ed                	xor    ch,ch
    3899:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    389b:	8e db                	mov    ds,bx
    389d:	8d be 00 ff          	lea    di,[bp-0x100]
    38a1:	16                   	push   ss
    38a2:	57                   	push   di
    38a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a6:	81 c7 5c 06          	add    di,0x65c
    38aa:	06                   	push   es
    38ab:	57                   	push   di
    38ac:	68 ff 00             	push   0xff
    38af:	9a e7 17 d9 38       	call   0x38d9:0x17e7
    38b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b7:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    38bc:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    38c0:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    38c4:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    38c8:	06                   	push   es
    38c9:	57                   	push   di
    38ca:	9a cc 11 58 39       	call   0x3958:0x11cc
    38cf:	b9 02 00             	mov    cx,0x2
    38d2:	f7 e9                	imul   cx
    38d4:	71 05                	jno    0x38db
    38d6:	9a 3e 04 0b 39       	call   0x390b:0x43e
    38db:	50                   	push   ax
    38dc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    38e0:	06                   	push   es
    38e1:	57                   	push   di
    38e2:	9a bf 17 70 39       	call   0x3970:0x17bf
    38e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ea:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    38ef:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    38f4:	68 84 03             	push   0x384
    38f7:	06                   	push   es
    38f8:	57                   	push   di
    38f9:	9a 85 3b 87 39       	call   0x3987:0x3b85
    38fe:	c9                   	leave
    38ff:	ca 08 00             	retf   0x8
    3902:	55                   	push   bp
    3903:	89 e5                	mov    bp,sp
    3905:	b8 04 01             	mov    ax,0x104
    3908:	9a 44 04 3d 39       	call   0x393d:0x444
    390d:	81 ec 04 01          	sub    sp,0x104
    3911:	8c d3                	mov    bx,ss
    3913:	8e c3                	mov    es,bx
    3915:	8c db                	mov    bx,ds
    3917:	fc                   	cld
    3918:	8d be 00 ff          	lea    di,[bp-0x100]
    391c:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    391f:	ac                   	lods   al,BYTE PTR ds:[si]
    3920:	aa                   	stos   BYTE PTR es:[di],al
    3921:	91                   	xchg   cx,ax
    3922:	30 ed                	xor    ch,ch
    3924:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    3926:	8e db                	mov    ds,bx
    3928:	8d be 00 ff          	lea    di,[bp-0x100]
    392c:	16                   	push   ss
    392d:	57                   	push   di
    392e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3931:	81 c7 5c 07          	add    di,0x75c
    3935:	06                   	push   es
    3936:	57                   	push   di
    3937:	68 ff 00             	push   0xff
    393a:	9a e7 17 64 39       	call   0x3964:0x17e7
    393f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3942:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    3947:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    394b:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    394f:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3953:	06                   	push   es
    3954:	57                   	push   di
    3955:	9a cc 11 e4 3b       	call   0x3be4:0x11cc
    395a:	b9 02 00             	mov    cx,0x2
    395d:	f7 e9                	imul   cx
    395f:	71 05                	jno    0x3966
    3961:	9a 3e 04 96 39       	call   0x3996:0x43e
    3966:	50                   	push   ax
    3967:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    396b:	06                   	push   es
    396c:	57                   	push   di
    396d:	9a bf 17 d0 39       	call   0x39d0:0x17bf
    3972:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3975:	26 ff b5 12 02       	push   WORD PTR es:[di+0x212]
    397a:	26 ff b5 10 02       	push   WORD PTR es:[di+0x210]
    397f:	68 7c fc             	push   0xfc7c
    3982:	06                   	push   es
    3983:	57                   	push   di
    3984:	9a 85 3b 25 3b       	call   0x3b25:0x3b85
    3989:	c9                   	leave
    398a:	ca 08 00             	retf   0x8
    398d:	55                   	push   bp
    398e:	89 e5                	mov    bp,sp
    3990:	b8 04 00             	mov    ax,0x4
    3993:	9a 44 04 f6 39       	call   0x39f6:0x444
    3998:	83 ec 04             	sub    sp,0x4
    399b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    399e:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    39a3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    39a6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    39a9:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    39ae:	b0 00                	mov    al,0x0
    39b0:	75 01                	jne    0x39b3
    39b2:	40                   	inc    ax
    39b3:	50                   	push   ax
    39b4:	06                   	push   es
    39b5:	57                   	push   di
    39b6:	9a 75 12 e7 39       	call   0x39e7:0x1275
    39bb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    39be:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    39c2:	50                   	push   ax
    39c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c6:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    39cb:	06                   	push   es
    39cc:	57                   	push   di
    39cd:	9a 77 1c 30 3a       	call   0x3a30:0x1c77
    39d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    39d5:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    39d9:	50                   	push   ax
    39da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39dd:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    39e2:	06                   	push   es
    39e3:	57                   	push   di
    39e4:	9a 75 12 19 3a       	call   0x3a19:0x1275
    39e9:	c9                   	leave
    39ea:	ca 08 00             	retf   0x8
    39ed:	55                   	push   bp
    39ee:	89 e5                	mov    bp,sp
    39f0:	b8 04 00             	mov    ax,0x4
    39f3:	9a 44 04 56 3a       	call   0x3a56:0x444
    39f8:	83 ec 04             	sub    sp,0x4
    39fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39fe:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    3a03:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a06:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a09:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    3a0e:	b0 00                	mov    al,0x0
    3a10:	75 01                	jne    0x3a13
    3a12:	40                   	inc    ax
    3a13:	50                   	push   ax
    3a14:	06                   	push   es
    3a15:	57                   	push   di
    3a16:	9a 75 12 47 3a       	call   0x3a47:0x1275
    3a1b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a1e:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    3a22:	50                   	push   ax
    3a23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a26:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    3a2b:	06                   	push   es
    3a2c:	57                   	push   di
    3a2d:	9a 77 1c 90 3a       	call   0x3a90:0x1c77
    3a32:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a35:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    3a39:	50                   	push   ax
    3a3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a3d:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    3a42:	06                   	push   es
    3a43:	57                   	push   di
    3a44:	9a 75 12 79 3a       	call   0x3a79:0x1275
    3a49:	c9                   	leave
    3a4a:	ca 08 00             	retf   0x8
    3a4d:	55                   	push   bp
    3a4e:	89 e5                	mov    bp,sp
    3a50:	b8 04 00             	mov    ax,0x4
    3a53:	9a 44 04 b6 3a       	call   0x3ab6:0x444
    3a58:	83 ec 04             	sub    sp,0x4
    3a5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a5e:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    3a63:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a66:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a69:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    3a6e:	b0 00                	mov    al,0x0
    3a70:	75 01                	jne    0x3a73
    3a72:	40                   	inc    ax
    3a73:	50                   	push   ax
    3a74:	06                   	push   es
    3a75:	57                   	push   di
    3a76:	9a 75 12 a7 3a       	call   0x3aa7:0x1275
    3a7b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a7e:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    3a82:	50                   	push   ax
    3a83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a86:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    3a8b:	06                   	push   es
    3a8c:	57                   	push   di
    3a8d:	9a 77 1c f0 3a       	call   0x3af0:0x1c77
    3a92:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a95:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    3a99:	50                   	push   ax
    3a9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a9d:	26 c4 bd 90 02       	les    di,DWORD PTR es:[di+0x290]
    3aa2:	06                   	push   es
    3aa3:	57                   	push   di
    3aa4:	9a 75 12 d9 3a       	call   0x3ad9:0x1275
    3aa9:	c9                   	leave
    3aaa:	ca 08 00             	retf   0x8
    3aad:	55                   	push   bp
    3aae:	89 e5                	mov    bp,sp
    3ab0:	b8 04 00             	mov    ax,0x4
    3ab3:	9a 44 04 15 3b       	call   0x3b15:0x444
    3ab8:	83 ec 04             	sub    sp,0x4
    3abb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3abe:	26 c4 bd 7c 02       	les    di,DWORD PTR es:[di+0x27c]
    3ac3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3ac6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3ac9:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    3ace:	b0 00                	mov    al,0x0
    3ad0:	75 01                	jne    0x3ad3
    3ad2:	40                   	inc    ax
    3ad3:	50                   	push   ax
    3ad4:	06                   	push   es
    3ad5:	57                   	push   di
    3ad6:	9a 75 12 07 3b       	call   0x3b07:0x1275
    3adb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3ade:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    3ae2:	50                   	push   ax
    3ae3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ae6:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3aeb:	06                   	push   es
    3aec:	57                   	push   di
    3aed:	9a 77 1c ca 3b       	call   0x3bca:0x1c77
    3af2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3af5:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    3af9:	50                   	push   ax
    3afa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afd:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    3b02:	06                   	push   es
    3b03:	57                   	push   di
    3b04:	9a 75 12 77 47       	call   0x4777:0x1275
    3b09:	c9                   	leave
    3b0a:	ca 08 00             	retf   0x8
    3b0d:	55                   	push   bp
    3b0e:	89 e5                	mov    bp,sp
    3b10:	31 c0                	xor    ax,ax
    3b12:	9a 44 04 33 3b       	call   0x3b33:0x444
    3b17:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b1a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b20:	06                   	push   es
    3b21:	57                   	push   di
    3b22:	9a 8d 39 43 3b       	call   0x3b43:0x398d
    3b27:	c9                   	leave
    3b28:	ca 08 00             	retf   0x8
    3b2b:	55                   	push   bp
    3b2c:	89 e5                	mov    bp,sp
    3b2e:	31 c0                	xor    ax,ax
    3b30:	9a 44 04 51 3b       	call   0x3b51:0x444
    3b35:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b38:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b3e:	06                   	push   es
    3b3f:	57                   	push   di
    3b40:	9a ed 39 61 3b       	call   0x3b61:0x39ed
    3b45:	c9                   	leave
    3b46:	ca 08 00             	retf   0x8
    3b49:	55                   	push   bp
    3b4a:	89 e5                	mov    bp,sp
    3b4c:	31 c0                	xor    ax,ax
    3b4e:	9a 44 04 6f 3b       	call   0x3b6f:0x444
    3b53:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b56:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b5c:	06                   	push   es
    3b5d:	57                   	push   di
    3b5e:	9a 4d 3a 7f 3b       	call   0x3b7f:0x3a4d
    3b63:	c9                   	leave
    3b64:	ca 08 00             	retf   0x8
    3b67:	55                   	push   bp
    3b68:	89 e5                	mov    bp,sp
    3b6a:	31 c0                	xor    ax,ax
    3b6c:	9a 44 04 8e 3b       	call   0x3b8e:0x444
    3b71:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b74:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b7a:	06                   	push   es
    3b7b:	57                   	push   di
    3b7c:	9a ad 3a cf 3c       	call   0x3ccf:0x3aad
    3b81:	c9                   	leave
    3b82:	ca 08 00             	retf   0x8
    3b85:	55                   	push   bp
    3b86:	89 e5                	mov    bp,sp
    3b88:	b8 10 00             	mov    ax,0x10
    3b8b:	9a 44 04 af 3b       	call   0x3baf:0x444
    3b90:	83 ec 10             	sub    sp,0x10
    3b93:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3b96:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3b99:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3b9c:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    3ba0:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    3ba4:	bf ad 0d             	mov    di,0xdad
    3ba7:	b8 ff ff             	mov    ax,0xffff
    3baa:	50                   	push   ax
    3bab:	57                   	push   di
    3bac:	9a 73 22 f0 3b       	call   0x3bf0:0x2273
    3bb1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3bb4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3bb7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3bba:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3bbe:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3bc2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3bc5:	06                   	push   es
    3bc6:	57                   	push   di
    3bc7:	9a eb 1d fb 3b       	call   0x3bfb:0x1deb
    3bcc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3bcf:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    3bd2:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    3bd5:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    3bd9:	74 24                	je     0x3bff
    3bdb:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3bdf:	06                   	push   es
    3be0:	57                   	push   di
    3be1:	9a cc 11 0b 3c       	call   0x3c0b:0x11cc
    3be6:	b9 02 00             	mov    cx,0x2
    3be9:	f7 e9                	imul   cx
    3beb:	71 05                	jno    0x3bf2
    3bed:	9a 3e 04 17 3c       	call   0x3c17:0x43e
    3bf2:	50                   	push   ax
    3bf3:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    3bf6:	06                   	push   es
    3bf7:	57                   	push   di
    3bf8:	9a bf 17 22 3c       	call   0x3c22:0x17bf
    3bfd:	eb 25                	jmp    0x3c24
    3bff:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    3c02:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3c06:	06                   	push   es
    3c07:	57                   	push   di
    3c08:	9a cc 11 50 3c       	call   0x3c50:0x11cc
    3c0d:	b9 02 00             	mov    cx,0x2
    3c10:	f7 e9                	imul   cx
    3c12:	71 05                	jno    0x3c19
    3c14:	9a 3e 04 69 3c       	call   0x3c69:0x43e
    3c19:	50                   	push   ax
    3c1a:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    3c1d:	06                   	push   es
    3c1e:	57                   	push   di
    3c1f:	9a e1 17 5a 3c       	call   0x3c5a:0x17e1
    3c24:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3c27:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    3c2b:	26 8b 55 36          	mov    dx,WORD PTR es:[di+0x36]
    3c2f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3c32:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3c35:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3c38:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3c3b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c3e:	9a 35 33 c9 3f       	call   0x3fc9:0x3335
    3c43:	50                   	push   ax
    3c44:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3c47:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3c4b:	06                   	push   es
    3c4c:	57                   	push   di
    3c4d:	9a eb 10 b1 3e       	call   0x3eb1:0x10eb
    3c52:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3c55:	06                   	push   es
    3c56:	57                   	push   di
    3c57:	9a c6 22 bc 3c       	call   0x3cbc:0x22c6
    3c5c:	c9                   	leave
    3c5d:	ca 0a 00             	retf   0xa
    3c60:	55                   	push   bp
    3c61:	89 e5                	mov    bp,sp
    3c63:	b8 04 00             	mov    ax,0x4
    3c66:	9a 44 04 de 3c       	call   0x3cde:0x444
    3c6b:	83 ec 04             	sub    sp,0x4
    3c6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c71:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3c76:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3c79:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3c7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c7f:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    3c84:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3c88:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3c8c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c8f:	06                   	push   es
    3c90:	57                   	push   di
    3c91:	9a 93 2a 9e 3c       	call   0x3c9e:0x2a93
    3c96:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c99:	06                   	push   es
    3c9a:	57                   	push   di
    3c9b:	9a 0d 2b 09 3d       	call   0x3d09:0x2b0d
    3ca0:	08 c0                	or     al,al
    3ca2:	74 2d                	je     0x3cd1
    3ca4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3ca7:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    3cab:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    3caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cb2:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    3cb7:	06                   	push   es
    3cb8:	57                   	push   di
    3cb9:	9a eb 1d 31 3d       	call   0x3d31:0x1deb
    3cbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cc1:	81 c7 5c 04          	add    di,0x45c
    3cc5:	06                   	push   es
    3cc6:	57                   	push   di
    3cc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cca:	06                   	push   es
    3ccb:	57                   	push   di
    3ccc:	9a 67 37 44 3d       	call   0x3d44:0x3767
    3cd1:	c9                   	leave
    3cd2:	ca 08 00             	retf   0x8
    3cd5:	55                   	push   bp
    3cd6:	89 e5                	mov    bp,sp
    3cd8:	b8 04 00             	mov    ax,0x4
    3cdb:	9a 44 04 53 3d       	call   0x3d53:0x444
    3ce0:	83 ec 04             	sub    sp,0x4
    3ce3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ce6:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3ceb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3cee:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3cf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf4:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3cf9:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3cfd:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3d01:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d04:	06                   	push   es
    3d05:	57                   	push   di
    3d06:	9a 93 2a 13 3d       	call   0x3d13:0x2a93
    3d0b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d0e:	06                   	push   es
    3d0f:	57                   	push   di
    3d10:	9a 0d 2b 7e 3d       	call   0x3d7e:0x2b0d
    3d15:	08 c0                	or     al,al
    3d17:	74 2d                	je     0x3d46
    3d19:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d1c:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    3d20:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    3d24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d27:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3d2c:	06                   	push   es
    3d2d:	57                   	push   di
    3d2e:	9a eb 1d a6 3d       	call   0x3da6:0x1deb
    3d33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d36:	81 c7 5c 05          	add    di,0x55c
    3d3a:	06                   	push   es
    3d3b:	57                   	push   di
    3d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d3f:	06                   	push   es
    3d40:	57                   	push   di
    3d41:	9a ef 37 b9 3d       	call   0x3db9:0x37ef
    3d46:	c9                   	leave
    3d47:	ca 08 00             	retf   0x8
    3d4a:	55                   	push   bp
    3d4b:	89 e5                	mov    bp,sp
    3d4d:	b8 04 00             	mov    ax,0x4
    3d50:	9a 44 04 c8 3d       	call   0x3dc8:0x444
    3d55:	83 ec 04             	sub    sp,0x4
    3d58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d5b:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3d60:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3d63:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3d66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d69:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    3d6e:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3d72:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3d76:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d79:	06                   	push   es
    3d7a:	57                   	push   di
    3d7b:	9a 93 2a 88 3d       	call   0x3d88:0x2a93
    3d80:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d83:	06                   	push   es
    3d84:	57                   	push   di
    3d85:	9a 0d 2b f3 3d       	call   0x3df3:0x2b0d
    3d8a:	08 c0                	or     al,al
    3d8c:	74 2d                	je     0x3dbb
    3d8e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3d91:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    3d95:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    3d99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d9c:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    3da1:	06                   	push   es
    3da2:	57                   	push   di
    3da3:	9a eb 1d 1b 3e       	call   0x3e1b:0x1deb
    3da8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dab:	81 c7 5c 06          	add    di,0x65c
    3daf:	06                   	push   es
    3db0:	57                   	push   di
    3db1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db4:	06                   	push   es
    3db5:	57                   	push   di
    3db6:	9a 77 38 2e 3e       	call   0x3e2e:0x3877
    3dbb:	c9                   	leave
    3dbc:	ca 08 00             	retf   0x8
    3dbf:	55                   	push   bp
    3dc0:	89 e5                	mov    bp,sp
    3dc2:	b8 04 00             	mov    ax,0x4
    3dc5:	9a 44 04 6e 3e       	call   0x3e6e:0x444
    3dca:	83 ec 04             	sub    sp,0x4
    3dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dd0:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3dd5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3dd8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3ddb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dde:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    3de3:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3de7:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3deb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3dee:	06                   	push   es
    3def:	57                   	push   di
    3df0:	9a 93 2a fd 3d       	call   0x3dfd:0x2a93
    3df5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3df8:	06                   	push   es
    3df9:	57                   	push   di
    3dfa:	9a 0d 2b 16 89       	call   0x8916:0x2b0d
    3dff:	08 c0                	or     al,al
    3e01:	74 2d                	je     0x3e30
    3e03:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3e06:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    3e0a:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    3e0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e11:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    3e16:	06                   	push   es
    3e17:	57                   	push   di
    3e18:	9a eb 1d 80 40       	call   0x4080:0x1deb
    3e1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e20:	81 c7 5c 07          	add    di,0x75c
    3e24:	06                   	push   es
    3e25:	57                   	push   di
    3e26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e29:	06                   	push   es
    3e2a:	57                   	push   di
    3e2b:	9a 02 39 4c 3e       	call   0x3e4c:0x3902
    3e30:	c9                   	leave
    3e31:	ca 08 00             	retf   0x8
    3e34:	00 00                	add    BYTE PTR [bx+si],al
    3e36:	00 00                	add    BYTE PTR [bx+si],al
    3e38:	00 00                	add    BYTE PTR [bx+si],al
    3e3a:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    3e3d:	80 ff ff             	cmp    bh,0xff
    3e40:	ff                   	(bad)
    3e41:	7f 00                	jg     0x3e43
    3e43:	00 01                	add    BYTE PTR [bx+di],al
    3e45:	00 86 01 4d          	add    BYTE PTR [bp+0x4d01],al
    3e49:	43                   	inc    bx
    3e4a:	e4 3f                	in     al,0x3f
    3e4c:	0c 41                	or     al,0x41
    3e4e:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    3e52:	ff                   	(bad)
    3e53:	7f 00                	jg     0x3e55
    3e55:	00 00                	add    BYTE PTR [bx+si],al
    3e57:	00 40 40             	add    BYTE PTR [bx+si+0x40],al
    3e5a:	02 2c                	add    ch,BYTE PTR [si]
    3e5c:	20 03                	and    BYTE PTR [bp+di],al
    3e5e:	59                   	pop    cx
    3e5f:	3d 20 03             	cmp    ax,0x320
    3e62:	58                   	pop    ax
    3e63:	3d 20 55             	cmp    ax,0x5520
    3e66:	89 e5                	mov    bp,sp
    3e68:	b8 42 04             	mov    ax,0x442
    3e6b:	9a 44 04 12 3f       	call   0x3f12:0x444
    3e70:	81 ec 42 04          	sub    sp,0x442
    3e74:	80 3e 9a 01 00       	cmp    BYTE PTR ds:0x19a,0x0
    3e79:	75 03                	jne    0x3e7e
    3e7b:	e9 0a 06             	jmp    0x4488
    3e7e:	f6 46 0e 08          	test   BYTE PTR [bp+0xe],0x8
    3e82:	75 03                	jne    0x3e87
    3e84:	e9 01 06             	jmp    0x4488
    3e87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e8a:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    3e8f:	89 be ca fd          	mov    WORD PTR [bp-0x236],di
    3e93:	8c 86 cc fd          	mov    WORD PTR [bp-0x234],es
    3e97:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    3e9c:	89 be c6 fd          	mov    WORD PTR [bp-0x23a],di
    3ea0:	8c 86 c8 fd          	mov    WORD PTR [bp-0x238],es
    3ea4:	6a 00                	push   0x0
    3ea6:	6a 00                	push   0x0
    3ea8:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3eac:	06                   	push   es
    3ead:	57                   	push   di
    3eae:	9a da 13 c2 3e       	call   0x3ec2:0x13da
    3eb3:	6a 02                	push   0x2
    3eb5:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    3eb9:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3ebd:	06                   	push   es
    3ebe:	57                   	push   di
    3ebf:	9a b0 14 d3 3e       	call   0x3ed3:0x14b0
    3ec4:	6a 01                	push   0x1
    3ec6:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    3eca:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3ece:	06                   	push   es
    3ecf:	57                   	push   di
    3ed0:	9a f5 14 e4 3e       	call   0x3ee4:0x14f5
    3ed5:	6a 0e                	push   0xe
    3ed7:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    3edb:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3edf:	06                   	push   es
    3ee0:	57                   	push   di
    3ee1:	9a 73 14 06 3f       	call   0x3f06:0x1473
    3ee6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ee9:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    3eee:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    3ef2:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3ef5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef8:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    3efd:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    3f01:	06                   	push   es
    3f02:	57                   	push   di
    3f03:	9a cc 11 2e 40       	call   0x402e:0x11cc
    3f08:	b9 02 00             	mov    cx,0x2
    3f0b:	f7 e9                	imul   cx
    3f0d:	71 05                	jno    0x3f14
    3f0f:	9a 3e 04 42 3f       	call   0x3f42:0x43e
    3f14:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3f17:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    3f1a:	99                   	cwd
    3f1b:	f7 7e e8             	idiv   WORD PTR [bp-0x18]
    3f1e:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3f21:	83 7e ee 00          	cmp    WORD PTR [bp-0x12],0x0
    3f25:	7f 05                	jg     0x3f2c
    3f27:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
    3f2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f2f:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    3f35:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    3f3b:	9b df 46 ee          	fild   WORD PTR [bp-0x12]
    3f3f:	9a b2 04 ce 3f       	call   0x3fce:0x4b2
    3f44:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    3f48:	90                   	nop
    3f49:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
    3f4e:	9b 2e d8 1e 34 3e    	fcomp  DWORD PTR cs:0x3e34
    3f54:	9b dd be c4 fd       	fstsw  WORD PTR [bp-0x23c]
    3f59:	90                   	nop
    3f5a:	9b                   	fwait
    3f5b:	8a a6 c5 fd          	mov    ah,BYTE PTR [bp-0x23b]
    3f5f:	9e                   	sahf
    3f60:	77 0c                	ja     0x3f6e
    3f62:	9b 2e d9 06 38 3e    	fld    DWORD PTR cs:0x3e38
    3f68:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    3f6c:	90                   	nop
    3f6d:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
    3f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f75:	9b 26 dc 9d 7e 08    	fcomp  QWORD PTR es:[di+0x87e]
    3f7b:	9b dd be c4 fd       	fstsw  WORD PTR [bp-0x23c]
    3f80:	90                   	nop
    3f81:	9b                   	fwait
    3f82:	8a a6 c5 fd          	mov    ah,BYTE PTR [bp-0x23b]
    3f86:	9e                   	sahf
    3f87:	73 70                	jae    0x3ff9
    3f89:	9b 26 dd 85 7e 08    	fld    QWORD PTR es:[di+0x87e]
    3f8f:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    3f93:	90                   	nop
    3f94:	9b                   	fwait
    3f95:	b8 44 3e             	mov    ax,0x3e44
    3f98:	0e                   	push   cs
    3f99:	50                   	push   ax
    3f9a:	55                   	push   bp
    3f9b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3f9f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3fa3:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    3fa9:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    3faf:	83 ec 08             	sub    sp,0x8
    3fb2:	89 e3                	mov    bx,sp
    3fb4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3fb8:	90                   	nop
    3fb9:	9b                   	fwait
    3fba:	ff 76 f6             	push   WORD PTR [bp-0xa]
    3fbd:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3fc0:	ff 76 f2             	push   WORD PTR [bp-0xe]
    3fc3:	ff 76 f0             	push   WORD PTR [bp-0x10]
    3fc6:	9a a7 2e 2a 41       	call   0x412a:0x2ea7
    3fcb:	9a 2f 10 d6 3f       	call   0x3fd6:0x102f
    3fd0:	bf 3c 3e             	mov    di,0x3e3c
    3fd3:	9a 16 04 ec 3f       	call   0x3fec:0x416
    3fd8:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3fdb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3fdf:	83 c4 06             	add    sp,0x6
    3fe2:	eb 0a                	jmp    0x3fee
    3fe4:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
    3fe9:	9a 34 14 04 40       	call   0x4004:0x1434
    3fee:	83 7e ee 00          	cmp    WORD PTR [bp-0x12],0x0
    3ff2:	7f 05                	jg     0x3ff9
    3ff4:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
    3ff9:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    3ffc:	2b 46 e8             	sub    ax,WORD PTR [bp-0x18]
    3fff:	71 05                	jno    0x4006
    4001:	9a 3e 04 4c 41       	call   0x414c:0x43e
    4006:	99                   	cwd
    4007:	f7 7e ee             	idiv   WORD PTR [bp-0x12]
    400a:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    400d:	83 7e ec 00          	cmp    WORD PTR [bp-0x14],0x0
    4011:	7f 05                	jg     0x4018
    4013:	c7 46 ec 01 00       	mov    WORD PTR [bp-0x14],0x1
    4018:	80 3e 9b 01 00       	cmp    BYTE PTR ds:0x19b,0x0
    401d:	74 52                	je     0x4071
    401f:	6a 00                	push   0x0
    4021:	ff 36 98 01          	push   WORD PTR ds:0x198
    4025:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    4029:	06                   	push   es
    402a:	57                   	push   di
    402b:	9a b8 1d 45 40       	call   0x4045:0x1db8
    4030:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    4034:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    4038:	ff 36 98 01          	push   WORD PTR ds:0x198
    403c:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    4040:	06                   	push   es
    4041:	57                   	push   di
    4042:	9a 7b 1d 56 40       	call   0x4056:0x1d7b
    4047:	ff 36 96 01          	push   WORD PTR ds:0x196
    404b:	6a 00                	push   0x0
    404d:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    4051:	06                   	push   es
    4052:	57                   	push   di
    4053:	9a b8 1d 6d 40       	call   0x406d:0x1db8
    4058:	ff 36 96 01          	push   WORD PTR ds:0x196
    405c:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    4060:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    4064:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    4068:	06                   	push   es
    4069:	57                   	push   di
    406a:	9a 7b 1d b2 40       	call   0x40b2:0x1d7b
    406f:	eb 33                	jmp    0x40a4
    4071:	6a 01                	push   0x1
    4073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4076:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    407b:	06                   	push   es
    407c:	57                   	push   di
    407d:	9a 77 1c 91 40       	call   0x4091:0x1c77
    4082:	6a 01                	push   0x1
    4084:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4087:	26 c4 bd 18 04       	les    di,DWORD PTR es:[di+0x418]
    408c:	06                   	push   es
    408d:	57                   	push   di
    408e:	9a 77 1c a2 40       	call   0x40a2:0x1c77
    4093:	6a 01                	push   0x1
    4095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4098:	26 c4 bd 1c 04       	les    di,DWORD PTR es:[di+0x41c]
    409d:	06                   	push   es
    409e:	57                   	push   di
    409f:	9a 77 1c d2 43       	call   0x43d2:0x1c77
    40a4:	6a 00                	push   0x0
    40a6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    40a9:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    40ad:	06                   	push   es
    40ae:	57                   	push   di
    40af:	9a b8 1d c8 40       	call   0x40c8:0x1db8
    40b4:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    40b8:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    40bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    40bf:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    40c3:	06                   	push   es
    40c4:	57                   	push   di
    40c5:	9a 7b 1d d8 40       	call   0x40d8:0x1d7b
    40ca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    40cd:	6a 00                	push   0x0
    40cf:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    40d3:	06                   	push   es
    40d4:	57                   	push   di
    40d5:	9a b8 1d ee 40       	call   0x40ee:0x1db8
    40da:	ff 76 0c             	push   WORD PTR [bp+0xc]
    40dd:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    40e1:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    40e5:	c4 be c6 fd          	les    di,DWORD PTR [bp-0x23a]
    40e9:	06                   	push   es
    40ea:	57                   	push   di
    40eb:	9a 7b 1d 14 45       	call   0x4514:0x1d7b
    40f0:	c6 06 9b 01 01       	mov    BYTE PTR ds:0x19b,0x1
    40f5:	9b df 46 0c          	fild   WORD PTR [bp+0xc]
    40f9:	83 ec 08             	sub    sp,0x8
    40fc:	89 e3                	mov    bx,sp
    40fe:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4102:	90                   	nop
    4103:	9b                   	fwait
    4104:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4107:	06                   	push   es
    4108:	57                   	push   di
    4109:	9a 05 14 a5 41       	call   0x41a5:0x1405
    410e:	99                   	cwd
    410f:	89 86 c2 fd          	mov    WORD PTR [bp-0x23e],ax
    4113:	89 96 c4 fd          	mov    WORD PTR [bp-0x23c],dx
    4117:	9b db 86 c2 fd       	fild   DWORD PTR [bp-0x23e]
    411c:	83 ec 08             	sub    sp,0x8
    411f:	89 e3                	mov    bx,sp
    4121:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4125:	90                   	nop
    4126:	9b                   	fwait
    4127:	9a a7 2e 92 42       	call   0x4292:0x2ea7
    412c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    412f:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    4134:	9b 26 df 85 da 00    	fild   WORD PTR es:[di+0xda]
    413a:	9b de c1             	faddp  st(1),st
    413d:	9b dd 9e d0 fd       	fstp   QWORD PTR [bp-0x230]
    4142:	90                   	nop
    4143:	9b 9b dd 86 d0 fd    	fld    QWORD PTR [bp-0x230]
    4149:	9a 2f 10 54 41       	call   0x4154:0x102f
    414e:	bf 4e 3e             	mov    di,0x3e4e
    4151:	9a 16 04 69 41       	call   0x4169:0x416
    4156:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    4159:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    415d:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    4161:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    4164:	71 05                	jno    0x416b
    4166:	9a 3e 04 80 41       	call   0x4180:0x43e
    416b:	99                   	cwd
    416c:	89 86 c2 fd          	mov    WORD PTR [bp-0x23e],ax
    4170:	89 96 c4 fd          	mov    WORD PTR [bp-0x23c],dx
    4174:	9b db 86 c2 fd       	fild   DWORD PTR [bp-0x23e]
    4179:	9b df 46 ec          	fild   WORD PTR [bp-0x14]
    417d:	9a b2 04 63 42       	call   0x4263:0x4b2
    4182:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4189:	9b 26 dc 85 76 08    	fadd   QWORD PTR es:[di+0x876]
    418f:	9b dd 9e d8 fd       	fstp   QWORD PTR [bp-0x228]
    4194:	90                   	nop
    4195:	9b                   	fwait
    4196:	31 c0                	xor    ax,ax
    4198:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    419b:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    41a0:	06                   	push   es
    41a1:	57                   	push   di
    41a2:	9a 05 14 e3 41       	call   0x41e3:0x1405
    41a7:	99                   	cwd
    41a8:	89 86 c2 fd          	mov    WORD PTR [bp-0x23e],ax
    41ac:	89 96 c4 fd          	mov    WORD PTR [bp-0x23c],dx
    41b0:	9b db 86 c2 fd       	fild   DWORD PTR [bp-0x23e]
    41b5:	9b df 46 e4          	fild   WORD PTR [bp-0x1c]
    41b9:	9b dc a6 d0 fd       	fsub   QWORD PTR [bp-0x230]
    41be:	9b de c9             	fmulp  st(1),st
    41c1:	9b d9 e1             	fabs
    41c4:	9b 2e d8 1e 56 3e    	fcomp  DWORD PTR cs:0x3e56
    41ca:	9b dd be c0 fd       	fstsw  WORD PTR [bp-0x240]
    41cf:	90                   	nop
    41d0:	9b                   	fwait
    41d1:	8a a6 c1 fd          	mov    ah,BYTE PTR [bp-0x23f]
    41d5:	9e                   	sahf
    41d6:	72 03                	jb     0x41db
    41d8:	e9 93 01             	jmp    0x436e
    41db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41de:	06                   	push   es
    41df:	57                   	push   di
    41e0:	9a c6 13 09 42       	call   0x4209:0x13c6
    41e5:	3b 46 e4             	cmp    ax,WORD PTR [bp-0x1c]
    41e8:	b0 00                	mov    al,0x0
    41ea:	7c 01                	jl     0x41ed
    41ec:	40                   	inc    ax
    41ed:	8a d0                	mov    dl,al
    41ef:	83 7e e4 00          	cmp    WORD PTR [bp-0x1c],0x0
    41f3:	b0 00                	mov    al,0x0
    41f5:	7e 01                	jle    0x41f8
    41f7:	40                   	inc    ax
    41f8:	22 c2                	and    al,dl
    41fa:	08 c0                	or     al,al
    41fc:	75 03                	jne    0x4201
    41fe:	e9 6d 01             	jmp    0x436e
    4201:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4204:	06                   	push   es
    4205:	57                   	push   di
    4206:	9a 7f 13 2a 44       	call   0x442a:0x137f
    420b:	89 86 be fd          	mov    WORD PTR [bp-0x242],ax
    420f:	b8 01 00             	mov    ax,0x1
    4212:	3b 86 be fd          	cmp    ax,WORD PTR [bp-0x242]
    4216:	7e 03                	jle    0x421b
    4218:	e9 53 01             	jmp    0x436e
    421b:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    421e:	eb 03                	jmp    0x4223
    4220:	ff 46 e2             	inc    WORD PTR [bp-0x1e]
    4223:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    4226:	99                   	cwd
    4227:	52                   	push   dx
    4228:	50                   	push   ax
    4229:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    422c:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    4231:	06                   	push   es
    4232:	57                   	push   di
    4233:	9a 30 6e 58 42       	call   0x4258:0x6e30
    4238:	09 c0                	or     ax,ax
    423a:	7f 03                	jg     0x423f
    423c:	e9 23 01             	jmp    0x4362
    423f:	8d be be fc          	lea    di,[bp-0x342]
    4243:	16                   	push   ss
    4244:	57                   	push   di
    4245:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    4248:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    424b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    424e:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    4253:	06                   	push   es
    4254:	57                   	push   di
    4255:	9a 68 9a f6 46       	call   0x46f6:0x9a68
    425a:	8d be ce fd          	lea    di,[bp-0x232]
    425e:	16                   	push   ss
    425f:	57                   	push   di
    4260:	9a 86 1e 9e 42       	call   0x429e:0x1e86
    4265:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4269:	90                   	nop
    426a:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    426f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4272:	9b 26 dc a5 76 08    	fsub   QWORD PTR es:[di+0x876]
    4278:	83 ec 08             	sub    sp,0x8
    427b:	89 e3                	mov    bx,sp
    427d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4281:	90                   	nop
    4282:	9b                   	fwait
    4283:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4286:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4289:	ff 76 f2             	push   WORD PTR [bp-0xe]
    428c:	ff 76 f0             	push   WORD PTR [bp-0x10]
    428f:	9a a7 2e 2e 7b       	call   0x7b2e:0x2ea7
    4294:	9b df 46 ec          	fild   WORD PTR [bp-0x14]
    4298:	9b de c9             	fmulp  st(1),st
    429b:	9a 2f 10 a6 42       	call   0x42a6:0x102f
    42a0:	bf 4e 3e             	mov    di,0x3e4e
    42a3:	9a 16 04 bb 42       	call   0x42bb:0x416
    42a8:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    42ab:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    42af:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    42b3:	2b 46 e0             	sub    ax,WORD PTR [bp-0x20]
    42b6:	71 05                	jno    0x42bd
    42b8:	9a 3e 04 cb 42       	call   0x42cb:0x43e
    42bd:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    42c0:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    42c3:	2b 46 e0             	sub    ax,WORD PTR [bp-0x20]
    42c6:	71 05                	jno    0x42cd
    42c8:	9a 3e 04 d7 42       	call   0x42d7:0x43e
    42cd:	99                   	cwd
    42ce:	31 d0                	xor    ax,dx
    42d0:	29 d0                	sub    ax,dx
    42d2:	71 05                	jno    0x42d9
    42d4:	9a 3e 04 13 43       	call   0x4313:0x43e
    42d9:	3d 03 00             	cmp    ax,0x3
    42dc:	7c 03                	jl     0x42e1
    42de:	e9 81 00             	jmp    0x4362
    42e1:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    42e4:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    42e7:	9b df 46 e4          	fild   WORD PTR [bp-0x1c]
    42eb:	9b dd 9e d0 fd       	fstp   QWORD PTR [bp-0x230]
    42f0:	90                   	nop
    42f1:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    42f6:	9b dd 9e d8 fd       	fstp   QWORD PTR [bp-0x228]
    42fb:	90                   	nop
    42fc:	9b                   	fwait
    42fd:	80 be e0 fe 00       	cmp    BYTE PTR [bp-0x120],0x0
    4302:	76 29                	jbe    0x432d
    4304:	8d be be fc          	lea    di,[bp-0x342]
    4308:	16                   	push   ss
    4309:	57                   	push   di
    430a:	8d be e0 fe          	lea    di,[bp-0x120]
    430e:	16                   	push   ss
    430f:	57                   	push   di
    4310:	9a cd 17 1d 43       	call   0x431d:0x17cd
    4315:	bf 5a 3e             	mov    di,0x3e5a
    4318:	0e                   	push   cs
    4319:	57                   	push   di
    431a:	9a 4c 18 2b 43       	call   0x432b:0x184c
    431f:	8d be e0 fe          	lea    di,[bp-0x120]
    4323:	16                   	push   ss
    4324:	57                   	push   di
    4325:	68 ff 00             	push   0xff
    4328:	9a e7 17 3c 43       	call   0x433c:0x17e7
    432d:	8d be be fb          	lea    di,[bp-0x442]
    4331:	16                   	push   ss
    4332:	57                   	push   di
    4333:	8d be e0 fe          	lea    di,[bp-0x120]
    4337:	16                   	push   ss
    4338:	57                   	push   di
    4339:	9a cd 17 52 43       	call   0x4352:0x17cd
    433e:	8d be be fc          	lea    di,[bp-0x342]
    4342:	16                   	push   ss
    4343:	57                   	push   di
    4344:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    4347:	99                   	cwd
    4348:	52                   	push   dx
    4349:	50                   	push   ax
    434a:	9a a9 08 c0 4c       	call   0x4cc0:0x8a9
    434f:	9a 4c 18 60 43       	call   0x4360:0x184c
    4354:	8d be e0 fe          	lea    di,[bp-0x120]
    4358:	16                   	push   ss
    4359:	57                   	push   di
    435a:	68 ff 00             	push   0xff
    435d:	9a e7 17 84 43       	call   0x4384:0x17e7
    4362:	8b 46 e2             	mov    ax,WORD PTR [bp-0x1e]
    4365:	3b 86 be fd          	cmp    ax,WORD PTR [bp-0x242]
    4369:	74 03                	je     0x436e
    436b:	e9 b2 fe             	jmp    0x4220
    436e:	83 7e e6 00          	cmp    WORD PTR [bp-0x1a],0x0
    4372:	75 3e                	jne    0x43b2
    4374:	c4 be ca fd          	les    di,DWORD PTR [bp-0x236]
    4378:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    437c:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    437f:	71 05                	jno    0x4386
    4381:	9a 3e 04 9b 43       	call   0x439b:0x43e
    4386:	99                   	cwd
    4387:	89 86 c2 fd          	mov    WORD PTR [bp-0x23e],ax
    438b:	89 96 c4 fd          	mov    WORD PTR [bp-0x23c],dx
    438f:	9b db 86 c2 fd       	fild   DWORD PTR [bp-0x23e]
    4394:	9b df 46 ec          	fild   WORD PTR [bp-0x14]
    4398:	9a b2 04 0a 44       	call   0x440a:0x4b2
    439d:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    43a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43a4:	9b 26 dc 85 76 08    	fadd   QWORD PTR es:[di+0x876]
    43aa:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    43ae:	90                   	nop
    43af:	9b                   	fwait
    43b0:	eb 0b                	jmp    0x43bd
    43b2:	9b dd 86 d8 fd       	fld    QWORD PTR [bp-0x228]
    43b7:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    43bb:	90                   	nop
    43bc:	9b                   	fwait
    43bd:	83 7e e6 00          	cmp    WORD PTR [bp-0x1a],0x0
    43c1:	7e 28                	jle    0x43eb
    43c3:	6a 01                	push   0x1
    43c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43c8:	26 c4 bd 1c 04       	les    di,DWORD PTR es:[di+0x41c]
    43cd:	06                   	push   es
    43ce:	57                   	push   di
    43cf:	9a 77 1c e7 43       	call   0x43e7:0x1c77
    43d4:	8d be e0 fe          	lea    di,[bp-0x120]
    43d8:	16                   	push   ss
    43d9:	57                   	push   di
    43da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43dd:	26 c4 bd 1c 04       	les    di,DWORD PTR es:[di+0x41c]
    43e2:	06                   	push   es
    43e3:	57                   	push   di
    43e4:	9a 8c 1d fa 43       	call   0x43fa:0x1d8c
    43e9:	eb 11                	jmp    0x43fc
    43eb:	6a 00                	push   0x0
    43ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43f0:	26 c4 bd 1c 04       	les    di,DWORD PTR es:[di+0x41c]
    43f5:	06                   	push   es
    43f6:	57                   	push   di
    43f7:	9a 77 1c 3e 44       	call   0x443e:0x1c77
    43fc:	8d be c6 fb          	lea    di,[bp-0x43a]
    4400:	16                   	push   ss
    4401:	57                   	push   di
    4402:	bf 5d 3e             	mov    di,0x3e5d
    4405:	0e                   	push   cs
    4406:	57                   	push   di
    4407:	9a cd 17 2f 44       	call   0x442f:0x17cd
    440c:	8d be c6 fc          	lea    di,[bp-0x33a]
    4410:	16                   	push   ss
    4411:	57                   	push   di
    4412:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4415:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4418:	ff 76 fa             	push   WORD PTR [bp-0x6]
    441b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    441e:	6a 14                	push   0x14
    4420:	6a 02                	push   0x2
    4422:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4425:	06                   	push   es
    4426:	57                   	push   di
    4427:	9a 2d 12 72 44       	call   0x4472:0x122d
    442c:	9a 4c 18 4e 44       	call   0x444e:0x184c
    4431:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4434:	26 c4 bd 18 04       	les    di,DWORD PTR es:[di+0x418]
    4439:	06                   	push   es
    443a:	57                   	push   di
    443b:	9a 8c 1d 86 44       	call   0x4486:0x1d8c
    4440:	8d be c6 fb          	lea    di,[bp-0x43a]
    4444:	16                   	push   ss
    4445:	57                   	push   di
    4446:	bf 61 3e             	mov    di,0x3e61
    4449:	0e                   	push   cs
    444a:	57                   	push   di
    444b:	9a cd 17 77 44       	call   0x4477:0x17cd
    4450:	8d be c6 fc          	lea    di,[bp-0x33a]
    4454:	16                   	push   ss
    4455:	57                   	push   di
    4456:	ff b6 d6 fd          	push   WORD PTR [bp-0x22a]
    445a:	ff b6 d4 fd          	push   WORD PTR [bp-0x22c]
    445e:	ff b6 d2 fd          	push   WORD PTR [bp-0x22e]
    4462:	ff b6 d0 fd          	push   WORD PTR [bp-0x230]
    4466:	6a 0a                	push   0xa
    4468:	6a 02                	push   0x2
    446a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    446d:	06                   	push   es
    446e:	57                   	push   di
    446f:	9a 2d 12 d6 44       	call   0x44d6:0x122d
    4474:	9a 4c 18 a0 44       	call   0x44a0:0x184c
    4479:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    447c:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    4481:	06                   	push   es
    4482:	57                   	push   di
    4483:	9a 8c 1d a9 45       	call   0x45a9:0x1d8c
    4488:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    448b:	a3 96 01             	mov    ds:0x196,ax
    448e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4491:	a3 98 01             	mov    ds:0x198,ax
    4494:	c9                   	leave
    4495:	ca 0e 00             	retf   0xe
    4498:	55                   	push   bp
    4499:	89 e5                	mov    bp,sp
    449b:	31 c0                	xor    ax,ax
    449d:	9a 44 04 e5 44       	call   0x44e5:0x444
    44a2:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
    44a6:	75 30                	jne    0x44d8
    44a8:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    44ab:	a3 96 01             	mov    ds:0x196,ax
    44ae:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    44b1:	a3 98 01             	mov    ds:0x198,ax
    44b4:	c6 06 9a 01 01       	mov    BYTE PTR ds:0x19a,0x1
    44b9:	c6 06 9b 01 00       	mov    BYTE PTR ds:0x19b,0x0
    44be:	ff 76 14             	push   WORD PTR [bp+0x14]
    44c1:	ff 76 12             	push   WORD PTR [bp+0x12]
    44c4:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    44c7:	50                   	push   ax
    44c8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    44cb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    44ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44d1:	06                   	push   es
    44d2:	57                   	push   di
    44d3:	9a 65 3e 1d 46       	call   0x461d:0x3e65
    44d8:	c9                   	leave
    44d9:	ca 10 00             	retf   0x10
    44dc:	55                   	push   bp
    44dd:	89 e5                	mov    bp,sp
    44df:	b8 04 00             	mov    ax,0x4
    44e2:	9a 44 04 d9 45       	call   0x45d9:0x444
    44e7:	83 ec 04             	sub    sp,0x4
    44ea:	80 3e 9b 01 00       	cmp    BYTE PTR ds:0x19b,0x0
    44ef:	75 03                	jne    0x44f4
    44f1:	e9 9c 00             	jmp    0x4590
    44f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44f7:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    44fc:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    4501:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4504:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4507:	6a 00                	push   0x0
    4509:	6a 00                	push   0x0
    450b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    450f:	06                   	push   es
    4510:	57                   	push   di
    4511:	9a da 13 24 45       	call   0x4524:0x13da
    4516:	6a 02                	push   0x2
    4518:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    451b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    451f:	06                   	push   es
    4520:	57                   	push   di
    4521:	9a b0 14 34 45       	call   0x4534:0x14b0
    4526:	6a 01                	push   0x1
    4528:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    452b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    452f:	06                   	push   es
    4530:	57                   	push   di
    4531:	9a f5 14 44 45       	call   0x4544:0x14f5
    4536:	6a 0e                	push   0xe
    4538:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    453b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    453f:	06                   	push   es
    4540:	57                   	push   di
    4541:	9a 73 14 54 45       	call   0x4554:0x1473
    4546:	6a 00                	push   0x0
    4548:	ff 36 98 01          	push   WORD PTR ds:0x198
    454c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    454f:	06                   	push   es
    4550:	57                   	push   di
    4551:	9a b8 1d 69 45       	call   0x4569:0x1db8
    4556:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4559:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    455d:	ff 36 98 01          	push   WORD PTR ds:0x198
    4561:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4564:	06                   	push   es
    4565:	57                   	push   di
    4566:	9a 7b 1d 79 45       	call   0x4579:0x1d7b
    456b:	ff 36 96 01          	push   WORD PTR ds:0x196
    456f:	6a 00                	push   0x0
    4571:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4574:	06                   	push   es
    4575:	57                   	push   di
    4576:	9a b8 1d 8e 45       	call   0x458e:0x1db8
    457b:	ff 36 96 01          	push   WORD PTR ds:0x196
    457f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4582:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    4586:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4589:	06                   	push   es
    458a:	57                   	push   di
    458b:	9a 7b 1d 0a 46       	call   0x460a:0x1d7b
    4590:	c6 06 9a 01 00       	mov    BYTE PTR ds:0x19a,0x0
    4595:	c6 06 9b 01 00       	mov    BYTE PTR ds:0x19b,0x0
    459a:	6a 00                	push   0x0
    459c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    459f:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    45a4:	06                   	push   es
    45a5:	57                   	push   di
    45a6:	9a 77 1c ba 45       	call   0x45ba:0x1c77
    45ab:	6a 00                	push   0x0
    45ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45b0:	26 c4 bd 18 04       	les    di,DWORD PTR es:[di+0x418]
    45b5:	06                   	push   es
    45b6:	57                   	push   di
    45b7:	9a 77 1c cb 45       	call   0x45cb:0x1c77
    45bc:	6a 00                	push   0x0
    45be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45c1:	26 c4 bd 1c 04       	les    di,DWORD PTR es:[di+0x41c]
    45c6:	06                   	push   es
    45c7:	57                   	push   di
    45c8:	9a 77 1c a5 47       	call   0x47a5:0x1c77
    45cd:	c9                   	leave
    45ce:	ca 10 00             	retf   0x10
    45d1:	55                   	push   bp
    45d2:	89 e5                	mov    bp,sp
    45d4:	31 c0                	xor    ax,ax
    45d6:	9a 44 04 f4 45       	call   0x45f4:0x444
    45db:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    45de:	a3 9c 01             	mov    ds:0x19c,ax
    45e1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    45e4:	a3 9e 01             	mov    ds:0x19e,ax
    45e7:	c9                   	leave
    45e8:	ca 0e 00             	retf   0xe
    45eb:	55                   	push   bp
    45ec:	89 e5                	mov    bp,sp
    45ee:	b8 0e 00             	mov    ax,0xe
    45f1:	9a 44 04 27 46       	call   0x4627:0x444
    45f6:	83 ec 0e             	sub    sp,0xe
    45f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45fc:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    4601:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    4605:	06                   	push   es
    4606:	57                   	push   di
    4607:	9a cc 11 94 4d       	call   0x4d94:0x11cc
    460c:	99                   	cwd
    460d:	b9 02 00             	mov    cx,0x2
    4610:	f7 f9                	idiv   cx
    4612:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4615:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4618:	06                   	push   es
    4619:	57                   	push   di
    461a:	9a 7f 13 70 46       	call   0x4670:0x137f
    461f:	05 01 00             	add    ax,0x1
    4622:	71 05                	jno    0x4629
    4624:	9a 3e 04 4a 46       	call   0x464a:0x43e
    4629:	8b c8                	mov    cx,ax
    462b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    462e:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    4633:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    4637:	99                   	cwd
    4638:	f7 f9                	idiv   cx
    463a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    463d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4640:	b9 03 00             	mov    cx,0x3
    4643:	f7 e9                	imul   cx
    4645:	71 05                	jno    0x464c
    4647:	9a 3e 04 5e 46       	call   0x465e:0x43e
    464c:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    464f:	7e 12                	jle    0x4663
    4651:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4654:	b9 03 00             	mov    cx,0x3
    4657:	f7 e9                	imul   cx
    4659:	71 05                	jno    0x4660
    465b:	9a 3e 04 90 46       	call   0x4690:0x43e
    4660:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4663:	31 c0                	xor    ax,ax
    4665:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4668:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    466b:	06                   	push   es
    466c:	57                   	push   di
    466d:	9a 7f 13 83 48       	call   0x4883:0x137f
    4672:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4675:	b8 01 00             	mov    ax,0x1
    4678:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    467b:	7f 5a                	jg     0x46d7
    467d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4680:	eb 03                	jmp    0x4685
    4682:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    4685:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4688:	f7 6e fe             	imul   WORD PTR [bp-0x2]
    468b:	71 05                	jno    0x4692
    468d:	9a 3e 04 a0 46       	call   0x46a0:0x43e
    4692:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4695:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    4698:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    469b:	71 05                	jno    0x46a2
    469d:	9a 3e 04 b8 46       	call   0x46b8:0x43e
    46a2:	3b 06 9e 01          	cmp    ax,WORD PTR ds:0x19e
    46a6:	b0 00                	mov    al,0x0
    46a8:	7e 01                	jle    0x46ab
    46aa:	40                   	inc    ax
    46ab:	8a d0                	mov    dl,al
    46ad:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    46b0:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    46b3:	71 05                	jno    0x46ba
    46b5:	9a 3e 04 54 47       	call   0x4754:0x43e
    46ba:	3b 06 9e 01          	cmp    ax,WORD PTR ds:0x19e
    46be:	b0 00                	mov    al,0x0
    46c0:	7d 01                	jge    0x46c3
    46c2:	40                   	inc    ax
    46c3:	22 c2                	and    al,dl
    46c5:	08 c0                	or     al,al
    46c7:	74 06                	je     0x46cf
    46c9:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    46cc:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    46cf:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    46d2:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    46d5:	75 ab                	jne    0x4682
    46d7:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    46db:	7e 6a                	jle    0x4747
    46dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46e0:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    46e5:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    46e8:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    46eb:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    46ee:	99                   	cwd
    46ef:	52                   	push   dx
    46f0:	50                   	push   ax
    46f1:	06                   	push   es
    46f2:	57                   	push   di
    46f3:	9a 30 6e 0c 47       	call   0x470c:0x6e30
    46f8:	09 c0                	or     ax,ax
    46fa:	7e 14                	jle    0x4710
    46fc:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    46ff:	99                   	cwd
    4700:	52                   	push   dx
    4701:	50                   	push   ax
    4702:	6a 00                	push   0x0
    4704:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4707:	06                   	push   es
    4708:	57                   	push   di
    4709:	9a c9 70 23 47       	call   0x4723:0x70c9
    470e:	eb 15                	jmp    0x4725
    4710:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4713:	99                   	cwd
    4714:	52                   	push   dx
    4715:	50                   	push   ax
    4716:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4719:	26 ff b5 fa 00       	push   WORD PTR es:[di+0xfa]
    471e:	06                   	push   es
    471f:	57                   	push   di
    4720:	9a c9 70 3e 4b       	call   0x4b3e:0x70c9
    4725:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4728:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    472d:	06                   	push   es
    472e:	57                   	push   di
    472f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4732:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4736:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4739:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    473e:	06                   	push   es
    473f:	57                   	push   di
    4740:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4743:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4747:	c9                   	leave
    4748:	ca 08 00             	retf   0x8
    474b:	55                   	push   bp
    474c:	89 e5                	mov    bp,sp
    474e:	b8 04 00             	mov    ax,0x4
    4751:	9a 44 04 b4 47       	call   0x47b4:0x444
    4756:	83 ec 04             	sub    sp,0x4
    4759:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    475c:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    4761:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4764:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4767:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    476c:	b0 00                	mov    al,0x0
    476e:	75 01                	jne    0x4771
    4770:	40                   	inc    ax
    4771:	50                   	push   ax
    4772:	06                   	push   es
    4773:	57                   	push   di
    4774:	9a 75 12 8e 47       	call   0x478e:0x1275
    4779:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    477c:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    4780:	50                   	push   ax
    4781:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4784:	26 c4 bd 9c 02       	les    di,DWORD PTR es:[di+0x29c]
    4789:	06                   	push   es
    478a:	57                   	push   di
    478b:	9a 75 12 d7 47       	call   0x47d7:0x1275
    4790:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4793:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    4797:	50                   	push   ax
    4798:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    479b:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    47a0:	06                   	push   es
    47a1:	57                   	push   di
    47a2:	9a 77 1c 05 48       	call   0x4805:0x1c77
    47a7:	c9                   	leave
    47a8:	ca 08 00             	retf   0x8
    47ab:	55                   	push   bp
    47ac:	89 e5                	mov    bp,sp
    47ae:	b8 04 00             	mov    ax,0x4
    47b1:	9a 44 04 14 48       	call   0x4814:0x444
    47b6:	83 ec 04             	sub    sp,0x4
    47b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47bc:	26 c4 bd 78 02       	les    di,DWORD PTR es:[di+0x278]
    47c1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    47c4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    47c7:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    47cc:	b0 00                	mov    al,0x0
    47ce:	75 01                	jne    0x47d1
    47d0:	40                   	inc    ax
    47d1:	50                   	push   ax
    47d2:	06                   	push   es
    47d3:	57                   	push   di
    47d4:	9a 75 12 ee 47       	call   0x47ee:0x1275
    47d9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    47dc:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    47e0:	50                   	push   ax
    47e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47e4:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    47e9:	06                   	push   es
    47ea:	57                   	push   di
    47eb:	9a 75 12 37 48       	call   0x4837:0x1275
    47f0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    47f3:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    47f7:	50                   	push   ax
    47f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47fb:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    4800:	06                   	push   es
    4801:	57                   	push   di
    4802:	9a 77 1c 65 48       	call   0x4865:0x1c77
    4807:	c9                   	leave
    4808:	ca 08 00             	retf   0x8
    480b:	55                   	push   bp
    480c:	89 e5                	mov    bp,sp
    480e:	b8 04 00             	mov    ax,0x4
    4811:	9a 44 04 73 48       	call   0x4873:0x444
    4816:	83 ec 04             	sub    sp,0x4
    4819:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    481c:	26 c4 bd 80 02       	les    di,DWORD PTR es:[di+0x280]
    4821:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4824:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4827:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    482c:	b0 00                	mov    al,0x0
    482e:	75 01                	jne    0x4831
    4830:	40                   	inc    ax
    4831:	50                   	push   ax
    4832:	06                   	push   es
    4833:	57                   	push   di
    4834:	9a 75 12 4e 48       	call   0x484e:0x1275
    4839:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    483c:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    4840:	50                   	push   ax
    4841:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4844:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    4849:	06                   	push   es
    484a:	57                   	push   di
    484b:	9a 75 12 fb 4b       	call   0x4bfb:0x1275
    4850:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4853:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    4857:	50                   	push   ax
    4858:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    485b:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    4860:	06                   	push   es
    4861:	57                   	push   di
    4862:	9a 77 1c 94 4a       	call   0x4a94:0x1c77
    4867:	c9                   	leave
    4868:	ca 08 00             	retf   0x8
    486b:	55                   	push   bp
    486c:	89 e5                	mov    bp,sp
    486e:	31 c0                	xor    ax,ax
    4870:	9a 44 04 91 48       	call   0x4891:0x444
    4875:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4878:	ff 76 0a             	push   WORD PTR [bp+0xa]
    487b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    487e:	06                   	push   es
    487f:	57                   	push   di
    4880:	9a 4b 47 a1 48       	call   0x48a1:0x474b
    4885:	c9                   	leave
    4886:	ca 08 00             	retf   0x8
    4889:	55                   	push   bp
    488a:	89 e5                	mov    bp,sp
    488c:	31 c0                	xor    ax,ax
    488e:	9a 44 04 af 48       	call   0x48af:0x444
    4893:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4896:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4899:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    489c:	06                   	push   es
    489d:	57                   	push   di
    489e:	9a ab 47 bf 48       	call   0x48bf:0x47ab
    48a3:	c9                   	leave
    48a4:	ca 08 00             	retf   0x8
    48a7:	55                   	push   bp
    48a8:	89 e5                	mov    bp,sp
    48aa:	31 c0                	xor    ax,ax
    48ac:	9a 44 04 cd 48       	call   0x48cd:0x444
    48b1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    48b4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    48b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48ba:	06                   	push   es
    48bb:	57                   	push   di
    48bc:	9a 0b 48 10 49       	call   0x4910:0x480b
    48c1:	c9                   	leave
    48c2:	ca 08 00             	retf   0x8
    48c5:	55                   	push   bp
    48c6:	89 e5                	mov    bp,sp
    48c8:	31 c0                	xor    ax,ax
    48ca:	9a 44 04 ed 48       	call   0x48ed:0x444
    48cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48d2:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    48d7:	06                   	push   es
    48d8:	57                   	push   di
    48d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48dc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    48e0:	c9                   	leave
    48e1:	ca 10 00             	retf   0x10
    48e4:	55                   	push   bp
    48e5:	89 e5                	mov    bp,sp
    48e7:	b8 04 00             	mov    ax,0x4
    48ea:	9a 44 04 30 49       	call   0x4930:0x444
    48ef:	83 ec 04             	sub    sp,0x4
    48f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48f5:	26 c4 bd f8 03       	les    di,DWORD PTR es:[di+0x3f8]
    48fa:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    4900:	74 12                	je     0x4914
    4902:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4905:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4908:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    490b:	06                   	push   es
    490c:	57                   	push   di
    490d:	9a 1c 27 22 49       	call   0x4922:0x271c
    4912:	eb 10                	jmp    0x4924
    4914:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4917:	ff 76 0a             	push   WORD PTR [bp+0xa]
    491a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    491d:	06                   	push   es
    491e:	57                   	push   di
    491f:	9a b7 28 cf 4a       	call   0x4acf:0x28b7
    4924:	c9                   	leave
    4925:	ca 08 00             	retf   0x8
    4928:	55                   	push   bp
    4929:	89 e5                	mov    bp,sp
    492b:	31 c0                	xor    ax,ax
    492d:	9a 44 04 83 49       	call   0x4983:0x444
    4932:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4935:	26 80 bd 87 08 00    	cmp    BYTE PTR es:[di+0x887],0x0
    493b:	b0 00                	mov    al,0x0
    493d:	75 01                	jne    0x4940
    493f:	40                   	inc    ax
    4940:	26 88 85 87 08       	mov    BYTE PTR es:[di+0x887],al
    4945:	26 8a 85 88 08       	mov    al,BYTE PTR es:[di+0x888]
    494a:	26 22 85 87 08       	and    al,BYTE PTR es:[di+0x887]
    494f:	26 88 85 86 08       	mov    BYTE PTR es:[di+0x886],al
    4954:	26 8a 85 86 08       	mov    al,BYTE PTR es:[di+0x886]
    4959:	50                   	push   ax
    495a:	26 c4 bd 04 04       	les    di,DWORD PTR es:[di+0x404]
    495f:	06                   	push   es
    4960:	57                   	push   di
    4961:	9a 70 24 b7 49       	call   0x49b7:0x2470
    4966:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4969:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    496e:	06                   	push   es
    496f:	57                   	push   di
    4970:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4973:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4977:	c9                   	leave
    4978:	ca 08 00             	retf   0x8
    497b:	55                   	push   bp
    497c:	89 e5                	mov    bp,sp
    497e:	31 c0                	xor    ax,ax
    4980:	9a 44 04 d6 49       	call   0x49d6:0x444
    4985:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4988:	26 80 bd 88 08 00    	cmp    BYTE PTR es:[di+0x888],0x0
    498e:	b0 00                	mov    al,0x0
    4990:	75 01                	jne    0x4993
    4992:	40                   	inc    ax
    4993:	26 88 85 88 08       	mov    BYTE PTR es:[di+0x888],al
    4998:	26 8a 85 88 08       	mov    al,BYTE PTR es:[di+0x888]
    499d:	26 22 85 87 08       	and    al,BYTE PTR es:[di+0x887]
    49a2:	26 88 85 86 08       	mov    BYTE PTR es:[di+0x886],al
    49a7:	26 8a 85 86 08       	mov    al,BYTE PTR es:[di+0x886]
    49ac:	50                   	push   ax
    49ad:	26 c4 bd 04 04       	les    di,DWORD PTR es:[di+0x404]
    49b2:	06                   	push   es
    49b3:	57                   	push   di
    49b4:	9a 70 24 0f 4a       	call   0x4a0f:0x2470
    49b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49bc:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    49c1:	06                   	push   es
    49c2:	57                   	push   di
    49c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49c6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    49ca:	c9                   	leave
    49cb:	ca 08 00             	retf   0x8
    49ce:	55                   	push   bp
    49cf:	89 e5                	mov    bp,sp
    49d1:	31 c0                	xor    ax,ax
    49d3:	9a 44 04 44 4a       	call   0x4a44:0x444
    49d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49db:	26 80 bd 86 08 00    	cmp    BYTE PTR es:[di+0x886],0x0
    49e1:	b0 00                	mov    al,0x0
    49e3:	75 01                	jne    0x49e6
    49e5:	40                   	inc    ax
    49e6:	26 88 85 86 08       	mov    BYTE PTR es:[di+0x886],al
    49eb:	26 8a 85 86 08       	mov    al,BYTE PTR es:[di+0x886]
    49f0:	26 88 85 88 08       	mov    BYTE PTR es:[di+0x888],al
    49f5:	26 8a 85 86 08       	mov    al,BYTE PTR es:[di+0x886]
    49fa:	26 88 85 87 08       	mov    BYTE PTR es:[di+0x887],al
    49ff:	26 8a 85 87 08       	mov    al,BYTE PTR es:[di+0x887]
    4a04:	50                   	push   ax
    4a05:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    4a0a:	06                   	push   es
    4a0b:	57                   	push   di
    4a0c:	9a 70 24 24 4a       	call   0x4a24:0x2470
    4a11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a14:	26 8a 85 88 08       	mov    al,BYTE PTR es:[di+0x888]
    4a19:	50                   	push   ax
    4a1a:	26 c4 bd 00 04       	les    di,DWORD PTR es:[di+0x400]
    4a1f:	06                   	push   es
    4a20:	57                   	push   di
    4a21:	9a 70 24 db 8a       	call   0x8adb:0x2470
    4a26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a29:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    4a2e:	06                   	push   es
    4a2f:	57                   	push   di
    4a30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a33:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4a37:	c9                   	leave
    4a38:	ca 08 00             	retf   0x8
    4a3b:	55                   	push   bp
    4a3c:	89 e5                	mov    bp,sp
    4a3e:	b8 08 00             	mov    ax,0x8
    4a41:	9a 44 04 69 4a       	call   0x4a69:0x444
    4a46:	83 ec 08             	sub    sp,0x8
    4a49:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
    4a4d:	75 64                	jne    0x4ab3
    4a4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a52:	26 c4 bd 0c 04       	les    di,DWORD PTR es:[di+0x40c]
    4a57:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    4a5a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    4a5d:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    4a60:	26 03 45 1e          	add    ax,WORD PTR es:[di+0x1e]
    4a64:	71 05                	jno    0x4a6b
    4a66:	9a 3e 04 7d 4a       	call   0x4a7d:0x43e
    4a6b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4a6e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4a71:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4a74:	26 03 45 20          	add    ax,WORD PTR es:[di+0x20]
    4a78:	71 05                	jno    0x4a7f
    4a7a:	9a 3e 04 bf 4a       	call   0x4abf:0x43e
    4a7f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4a82:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4a85:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4a88:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4a8b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    4a8f:	06                   	push   es
    4a90:	57                   	push   di
    4a91:	9a d4 19 3e 89       	call   0x893e:0x19d4
    4a96:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4a99:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4a9c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4a9f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4aa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4aa5:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    4aaa:	06                   	push   es
    4aab:	57                   	push   di
    4aac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4aaf:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4ab3:	c9                   	leave
    4ab4:	ca 10 00             	retf   0x10
    4ab7:	55                   	push   bp
    4ab8:	89 e5                	mov    bp,sp
    4aba:	31 c0                	xor    ax,ax
    4abc:	9a 44 04 dd 4a       	call   0x4add:0x444
    4ac1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ac4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ac7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4aca:	06                   	push   es
    4acb:	57                   	push   di
    4acc:	9a 10 33 ed 4a       	call   0x4aed:0x3310
    4ad1:	c9                   	leave
    4ad2:	ca 08 00             	retf   0x8
    4ad5:	55                   	push   bp
    4ad6:	89 e5                	mov    bp,sp
    4ad8:	31 c0                	xor    ax,ax
    4ada:	9a 44 04 fb 4a       	call   0x4afb:0x444
    4adf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ae2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ae5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ae8:	06                   	push   es
    4ae9:	57                   	push   di
    4aea:	9a 46 34 c5 4b       	call   0x4bc5:0x3446
    4aef:	c9                   	leave
    4af0:	ca 08 00             	retf   0x8
    4af3:	55                   	push   bp
    4af4:	89 e5                	mov    bp,sp
    4af6:	31 c0                	xor    ax,ax
    4af8:	9a 44 04 12 4b       	call   0x4b12:0x444
    4afd:	c9                   	leave
    4afe:	ca 08 00             	retf   0x8
    4b01:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    4b05:	ff                   	(bad)
    4b06:	7f 00                	jg     0x4b08
    4b08:	00 55 89             	add    BYTE PTR [di-0x77],dl
    4b0b:	e5 b8                	in     ax,0xb8
    4b0d:	0a 00                	or     al,BYTE PTR [bx+si]
    4b0f:	9a 44 04 61 4b       	call   0x4b61:0x444
    4b14:	83 ec 0a             	sub    sp,0xa
    4b17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b1a:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    4b1f:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    4b22:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    4b25:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4b2a:	75 03                	jne    0x4b2f
    4b2c:	e9 7e 00             	jmp    0x4bad
    4b2f:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    4b34:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    4b39:	06                   	push   es
    4b3a:	57                   	push   di
    4b3b:	9a 30 6e 8c 4b       	call   0x4b8c:0x6e30
    4b40:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b43:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    4b47:	7e 64                	jle    0x4bad
    4b49:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4b4c:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    4b51:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    4b56:	2d 01 00             	sub    ax,0x1
    4b59:	83 da 00             	sbb    dx,0x0
    4b5c:	71 05                	jno    0x4b63
    4b5e:	9a 3e 04 69 4b       	call   0x4b69:0x43e
    4b63:	bf 01 4b             	mov    di,0x4b01
    4b66:	9a 16 04 b9 4b       	call   0x4bb9:0x416
    4b6b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4b6e:	b8 01 00             	mov    ax,0x1
    4b71:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    4b74:	7f 37                	jg     0x4bad
    4b76:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4b79:	eb 03                	jmp    0x4b7e
    4b7b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4b7e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b81:	99                   	cwd
    4b82:	52                   	push   dx
    4b83:	50                   	push   ax
    4b84:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4b87:	06                   	push   es
    4b88:	57                   	push   di
    4b89:	9a 30 6e a3 4b       	call   0x4ba3:0x6e30
    4b8e:	09 c0                	or     ax,ax
    4b90:	7e 13                	jle    0x4ba5
    4b92:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b95:	99                   	cwd
    4b96:	52                   	push   dx
    4b97:	50                   	push   ax
    4b98:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4b9b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4b9e:	06                   	push   es
    4b9f:	57                   	push   di
    4ba0:	9a c9 70 88 4c       	call   0x4c88:0x70c9
    4ba5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ba8:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    4bab:	75 ce                	jne    0x4b7b
    4bad:	c9                   	leave
    4bae:	ca 08 00             	retf   0x8
    4bb1:	55                   	push   bp
    4bb2:	89 e5                	mov    bp,sp
    4bb4:	31 c0                	xor    ax,ax
    4bb6:	9a 44 04 d3 4b       	call   0x4bd3:0x444
    4bbb:	6a 00                	push   0x0
    4bbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bc0:	06                   	push   es
    4bc1:	57                   	push   di
    4bc2:	9a d0 31 ea 4b       	call   0x4bea:0x31d0
    4bc7:	c9                   	leave
    4bc8:	ca 04 00             	retf   0x4
    4bcb:	55                   	push   bp
    4bcc:	89 e5                	mov    bp,sp
    4bce:	31 c0                	xor    ax,ax
    4bd0:	9a 44 04 56 4c       	call   0x4c56:0x444
    4bd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bd8:	26 c7 85 8a 08 05 00 	mov    WORD PTR es:[di+0x88a],0x5
    4bdf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4be2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4be5:	06                   	push   es
    4be6:	57                   	push   di
    4be7:	9a 5b 7f 38 4c       	call   0x4c38:0x7f5b
    4bec:	6a 00                	push   0x0
    4bee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bf1:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    4bf6:	06                   	push   es
    4bf7:	57                   	push   di
    4bf8:	9a a5 13 0c 4c       	call   0x4c0c:0x13a5
    4bfd:	6a 00                	push   0x0
    4bff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c02:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    4c07:	06                   	push   es
    4c08:	57                   	push   di
    4c09:	9a a5 13 1d 4c       	call   0x4c1d:0x13a5
    4c0e:	6a 00                	push   0x0
    4c10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c13:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    4c18:	06                   	push   es
    4c19:	57                   	push   di
    4c1a:	9a a5 13 2e 4c       	call   0x4c2e:0x13a5
    4c1f:	6a 00                	push   0x0
    4c21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c24:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    4c29:	06                   	push   es
    4c2a:	57                   	push   di
    4c2b:	9a a5 13 64 4e       	call   0x4e64:0x13a5
    4c30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c33:	06                   	push   es
    4c34:	57                   	push   di
    4c35:	9a b1 4b 6d 4c       	call   0x4c6d:0x4bb1
    4c3a:	c9                   	leave
    4c3b:	ca 08 00             	retf   0x8
    4c3e:	08 4e 6f             	or     BYTE PTR [bp+0x6f],cl
    4c41:	6e                   	outs   dx,BYTE PTR ds:[si]
    4c42:	20 53 65             	and    BYTE PTR [bp+di+0x65],dl
    4c45:	6e                   	outs   dx,BYTE PTR ds:[si]
    4c46:	73 00                	jae    0x4c48
    4c48:	00 30                	add    BYTE PTR [bx+si],dh
    4c4a:	41                   	inc    cx
    4c4b:	01 31                	add    WORD PTR [bx+di],si
    4c4d:	55                   	push   bp
    4c4e:	89 e5                	mov    bp,sp
    4c50:	b8 10 02             	mov    ax,0x210
    4c53:	9a 44 04 f7 4c       	call   0x4cf7:0x444
    4c58:	81 ec 10 02          	sub    sp,0x210
    4c5c:	6a ff                	push   0xffff
    4c5e:	6a ff                	push   0xffff
    4c60:	bf 3e 4c             	mov    di,0x4c3e
    4c63:	0e                   	push   cs
    4c64:	57                   	push   di
    4c65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c68:	06                   	push   es
    4c69:	57                   	push   di
    4c6a:	9a 90 7d 92 4c       	call   0x4c92:0x7d90
    4c6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c72:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    4c77:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
    4c7b:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
    4c7f:	6a 00                	push   0x0
    4c81:	6a 65                	push   0x65
    4c83:	06                   	push   es
    4c84:	57                   	push   di
    4c85:	9a 26 74 cb 4c       	call   0x4ccb:0x7426
    4c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c8d:	06                   	push   es
    4c8e:	57                   	push   di
    4c8f:	9a c6 13 d5 4c       	call   0x4cd5:0x13c6
    4c94:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    4c98:	b8 01 00             	mov    ax,0x1
    4c9b:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    4c9f:	7e 03                	jle    0x4ca4
    4ca1:	e9 c3 00             	jmp    0x4d67
    4ca4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ca7:	eb 03                	jmp    0x4cac
    4ca9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4cac:	6a 00                	push   0x0
    4cae:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4cb1:	8d be f6 fd          	lea    di,[bp-0x20a]
    4cb5:	16                   	push   ss
    4cb6:	57                   	push   di
    4cb7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4cba:	99                   	cwd
    4cbb:	52                   	push   dx
    4cbc:	50                   	push   ax
    4cbd:	9a a9 08 bc 4d       	call   0x4dbc:0x8a9
    4cc2:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4cc6:	06                   	push   es
    4cc7:	57                   	push   di
    4cc8:	9a 08 9b 50 4d       	call   0x4d50:0x9b08
    4ccd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cd0:	06                   	push   es
    4cd1:	57                   	push   di
    4cd2:	9a 7f 13 2b 4d       	call   0x4d2b:0x137f
    4cd7:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    4cdb:	b8 01 00             	mov    ax,0x1
    4cde:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    4ce2:	7f 77                	jg     0x4d5b
    4ce4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4ce7:	eb 03                	jmp    0x4cec
    4ce9:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4cec:	8d be f0 fd          	lea    di,[bp-0x210]
    4cf0:	16                   	push   ss
    4cf1:	57                   	push   di
    4cf2:	6a 64                	push   0x64
    4cf4:	9a 2b 1c 39 4d       	call   0x4d39:0x1c2b
    4cf9:	31 d2                	xor    dx,dx
    4cfb:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    4cff:	89 96 f2 fe          	mov    WORD PTR [bp-0x10e],dx
    4d03:	9b db 86 f0 fe       	fild   DWORD PTR [bp-0x110]
    4d08:	9b 2e d8 0e 47 4c    	fmul   DWORD PTR cs:0x4c47
    4d0e:	9b d9 c0             	fld    st(0)
    4d11:	9b de c9             	fmulp  st(1),st
    4d14:	83 ec 08             	sub    sp,0x8
    4d17:	89 e3                	mov    bx,sp
    4d19:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d1d:	90                   	nop
    4d1e:	9b                   	fwait
    4d1f:	6a 0c                	push   0xc
    4d21:	6a 02                	push   0x2
    4d23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d26:	06                   	push   es
    4d27:	57                   	push   di
    4d28:	9a 2d 12 b4 4d       	call   0x4db4:0x122d
    4d2d:	8d be fc fe          	lea    di,[bp-0x104]
    4d31:	16                   	push   ss
    4d32:	57                   	push   di
    4d33:	68 ff 00             	push   0xff
    4d36:	9a e7 17 84 4d       	call   0x4d84:0x17e7
    4d3b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4d3e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4d41:	8d be fc fe          	lea    di,[bp-0x104]
    4d45:	16                   	push   ss
    4d46:	57                   	push   di
    4d47:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4d4b:	06                   	push   es
    4d4c:	57                   	push   di
    4d4d:	9a 08 9b 7a 4d       	call   0x4d7a:0x9b08
    4d52:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4d55:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    4d59:	75 8e                	jne    0x4ce9
    4d5b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4d5e:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    4d62:	74 03                	je     0x4d67
    4d64:	e9 42 ff             	jmp    0x4ca9
    4d67:	8d be f8 fd          	lea    di,[bp-0x208]
    4d6b:	16                   	push   ss
    4d6c:	57                   	push   di
    4d6d:	6a 01                	push   0x1
    4d6f:	6a 00                	push   0x0
    4d71:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4d75:	06                   	push   es
    4d76:	57                   	push   di
    4d77:	9a 68 9a a0 4d       	call   0x4da0:0x9a68
    4d7c:	bf 4b 4c             	mov    di,0x4c4b
    4d7f:	0e                   	push   cs
    4d80:	57                   	push   di
    4d81:	9a 4c 18 c6 4d       	call   0x4dc6:0x184c
    4d86:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4d8a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4d8f:	06                   	push   es
    4d90:	57                   	push   di
    4d91:	9a 03 20 d6 4d       	call   0x4dd6:0x2003
    4d96:	50                   	push   ax
    4d97:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4d9b:	06                   	push   es
    4d9c:	57                   	push   di
    4d9d:	9a 72 71 e2 4d       	call   0x4de2:0x7172
    4da2:	6a 00                	push   0x0
    4da4:	6a 00                	push   0x0
    4da6:	8d be f8 fd          	lea    di,[bp-0x208]
    4daa:	16                   	push   ss
    4dab:	57                   	push   di
    4dac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4daf:	06                   	push   es
    4db0:	57                   	push   di
    4db1:	9a c6 13 ec 4d       	call   0x4dec:0x13c6
    4db6:	99                   	cwd
    4db7:	52                   	push   dx
    4db8:	50                   	push   ax
    4db9:	9a a9 08 f4 4e       	call   0x4ef4:0x8a9
    4dbe:	bf 4b 4c             	mov    di,0x4c4b
    4dc1:	0e                   	push   cs
    4dc2:	57                   	push   di
    4dc3:	9a 4c 18 38 4e       	call   0x4e38:0x184c
    4dc8:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4dcc:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4dd1:	06                   	push   es
    4dd2:	57                   	push   di
    4dd3:	9a 03 20 6b 83       	call   0x836b:0x2003
    4dd8:	50                   	push   ax
    4dd9:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    4ddd:	06                   	push   es
    4dde:	57                   	push   di
    4ddf:	9a c9 70 dc 51       	call   0x51dc:0x70c9
    4de4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4de7:	06                   	push   es
    4de8:	57                   	push   di
    4de9:	9a 6f 14 fc 4d       	call   0x4dfc:0x146f
    4dee:	ff 76 08             	push   WORD PTR [bp+0x8]
    4df1:	ff 76 06             	push   WORD PTR [bp+0x6]
    4df4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4df7:	06                   	push   es
    4df8:	57                   	push   di
    4df9:	9a a2 2b 53 4e       	call   0x4e53:0x2ba2
    4dfe:	c9                   	leave
    4dff:	ca 04 00             	retf   0x4
    4e02:	07                   	pop    es
    4e03:	26 53                	es push bx
    4e05:	e9 72 69             	jmp    0xb77a
    4e08:	65 73 01             	gs jae 0x4e0c
    4e0b:	26 0c 54             	es or  al,0x54
    4e0e:	69 74 72 65 20       	imul   si,WORD PTR [si+0x72],0x2065
    4e13:	67 61                	addr32 popa
    4e15:	75 63                	jne    0x4e7a
    4e17:	68 65 0b             	push   0xb65
    4e1a:	54                   	push   sp
    4e1b:	69 74 72 65 20       	imul   si,WORD PTR [si+0x72],0x2065
    4e20:	64 72 6f             	fs jb  0x4e92
    4e23:	69 74 09 54 69       	imul   si,WORD PTR [si+0x9],0x6954
    4e28:	74 72                	je     0x4e9c
    4e2a:	65 20 62 61          	and    BYTE PTR gs:[bp+si+0x61],ah
    4e2e:	73 55                	jae    0x4e85
    4e30:	89 e5                	mov    bp,sp
    4e32:	b8 08 02             	mov    ax,0x208
    4e35:	9a 44 04 b7 4e       	call   0x4eb7:0x444
    4e3a:	81 ec 08 02          	sub    sp,0x208
    4e3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e41:	31 c0                	xor    ax,ax
    4e43:	26 89 85 8a 08       	mov    WORD PTR es:[di+0x88a],ax
    4e48:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e4b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e4e:	06                   	push   es
    4e4f:	57                   	push   di
    4e50:	9a 5b 7f 7f 4f       	call   0x4f7f:0x7f5b
    4e55:	6a 00                	push   0x0
    4e57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5a:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    4e5f:	06                   	push   es
    4e60:	57                   	push   di
    4e61:	9a a5 13 75 4e       	call   0x4e75:0x13a5
    4e66:	6a 00                	push   0x0
    4e68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e6b:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    4e70:	06                   	push   es
    4e71:	57                   	push   di
    4e72:	9a a5 13 86 4e       	call   0x4e86:0x13a5
    4e77:	6a 00                	push   0x0
    4e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e7c:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    4e81:	06                   	push   es
    4e82:	57                   	push   di
    4e83:	9a a5 13 a3 4e       	call   0x4ea3:0x13a5
    4e88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e8b:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    4e90:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    4e93:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    4e96:	bf 02 4e             	mov    di,0x4e02
    4e99:	0e                   	push   cs
    4e9a:	57                   	push   di
    4e9b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4e9e:	06                   	push   es
    4e9f:	57                   	push   di
    4ea0:	9a 37 12 ad 4e       	call   0x4ead:0x1237
    4ea5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4ea8:	06                   	push   es
    4ea9:	57                   	push   di
    4eaa:	9a 26 13 06 4f       	call   0x4f06:0x1326
    4eaf:	2d 01 00             	sub    ax,0x1
    4eb2:	71 05                	jno    0x4eb9
    4eb4:	9a 3e 04 d9 4e       	call   0x4ed9:0x43e
    4eb9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4ebc:	31 c0                	xor    ax,ax
    4ebe:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4ec1:	7f 72                	jg     0x4f35
    4ec3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ec6:	eb 03                	jmp    0x4ecb
    4ec8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4ecb:	8d be f8 fd          	lea    di,[bp-0x208]
    4ecf:	16                   	push   ss
    4ed0:	57                   	push   di
    4ed1:	bf 0a 4e             	mov    di,0x4e0a
    4ed4:	0e                   	push   cs
    4ed5:	57                   	push   di
    4ed6:	9a cd 17 ec 4e       	call   0x4eec:0x17cd
    4edb:	8d be f8 fe          	lea    di,[bp-0x108]
    4edf:	16                   	push   ss
    4ee0:	57                   	push   di
    4ee1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ee4:	05 01 00             	add    ax,0x1
    4ee7:	71 05                	jno    0x4eee
    4ee9:	9a 3e 04 f9 4e       	call   0x4ef9:0x43e
    4eee:	99                   	cwd
    4eef:	52                   	push   dx
    4ef0:	50                   	push   ax
    4ef1:	9a a9 08 4e 82       	call   0x824e:0x8a9
    4ef6:	9a 4c 18 49 4f       	call   0x4f49:0x184c
    4efb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4efe:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4f01:	06                   	push   es
    4f02:	57                   	push   di
    4f03:	9a 53 13 11 4f       	call   0x4f11:0x1353
    4f08:	89 c7                	mov    di,ax
    4f0a:	8e c2                	mov    es,dx
    4f0c:	06                   	push   es
    4f0d:	57                   	push   di
    4f0e:	9a 37 12 20 4f       	call   0x4f20:0x1237
    4f13:	6a 01                	push   0x1
    4f15:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4f18:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4f1b:	06                   	push   es
    4f1c:	57                   	push   di
    4f1d:	9a 53 13 2b 4f       	call   0x4f2b:0x1353
    4f22:	89 c7                	mov    di,ax
    4f24:	8e c2                	mov    es,dx
    4f26:	06                   	push   es
    4f27:	57                   	push   di
    4f28:	9a a5 13 3f 4f       	call   0x4f3f:0x13a5
    4f2d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f30:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4f33:	75 93                	jne    0x4ec8
    4f35:	6a 00                	push   0x0
    4f37:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4f3a:	06                   	push   es
    4f3b:	57                   	push   di
    4f3c:	9a 26 13 54 4f       	call   0x4f54:0x1326
    4f41:	2d 01 00             	sub    ax,0x1
    4f44:	71 05                	jno    0x4f4b
    4f46:	9a 3e 04 c6 4f       	call   0x4fc6:0x43e
    4f4b:	50                   	push   ax
    4f4c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4f4f:	06                   	push   es
    4f50:	57                   	push   di
    4f51:	9a 53 13 5f 4f       	call   0x4f5f:0x1353
    4f56:	89 c7                	mov    di,ax
    4f58:	8e c2                	mov    es,dx
    4f5a:	06                   	push   es
    4f5b:	57                   	push   di
    4f5c:	9a a5 13 70 4f       	call   0x4f70:0x13a5
    4f61:	6a 01                	push   0x1
    4f63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f66:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    4f6b:	06                   	push   es
    4f6c:	57                   	push   di
    4f6d:	9a a5 13 bc 4f       	call   0x4fbc:0x13a5
    4f72:	bf 0c 4e             	mov    di,0x4e0c
    4f75:	0e                   	push   cs
    4f76:	57                   	push   di
    4f77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f7a:	06                   	push   es
    4f7b:	57                   	push   di
    4f7c:	9a 77 38 8e 4f       	call   0x4f8e:0x3877
    4f81:	bf 19 4e             	mov    di,0x4e19
    4f84:	0e                   	push   cs
    4f85:	57                   	push   di
    4f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f89:	06                   	push   es
    4f8a:	57                   	push   di
    4f8b:	9a 02 39 9d 4f       	call   0x4f9d:0x3902
    4f90:	bf 25 4e             	mov    di,0x4e25
    4f93:	0e                   	push   cs
    4f94:	57                   	push   di
    4f95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f98:	06                   	push   es
    4f99:	57                   	push   di
    4f9a:	9a ef 37 a7 4f       	call   0x4fa7:0x37ef
    4f9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fa2:	06                   	push   es
    4fa3:	57                   	push   di
    4fa4:	9a 10 81 06 50       	call   0x5006:0x8110
    4fa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fac:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    4fb1:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    4fb4:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    4fb7:	06                   	push   es
    4fb8:	57                   	push   di
    4fb9:	9a 26 13 e7 4f       	call   0x4fe7:0x1326
    4fbe:	2d 01 00             	sub    ax,0x1
    4fc1:	71 05                	jno    0x4fc8
    4fc3:	9a 3e 04 5a 50       	call   0x505a:0x43e
    4fc8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4fcb:	31 c0                	xor    ax,ax
    4fcd:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4fd0:	7f 2a                	jg     0x4ffc
    4fd2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4fd5:	eb 03                	jmp    0x4fda
    4fd7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4fda:	6a 01                	push   0x1
    4fdc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4fdf:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4fe2:	06                   	push   es
    4fe3:	57                   	push   di
    4fe4:	9a 53 13 f2 4f       	call   0x4ff2:0x1353
    4fe9:	89 c7                	mov    di,ax
    4feb:	8e c2                	mov    es,dx
    4fed:	06                   	push   es
    4fee:	57                   	push   di
    4fef:	9a 75 12 03 53       	call   0x5303:0x1275
    4ff4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ff7:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4ffa:	75 db                	jne    0x4fd7
    4ffc:	6a 01                	push   0x1
    4ffe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5001:	06                   	push   es
    5002:	57                   	push   di
    5003:	9a 8f 8a 10 50       	call   0x5010:0x8a8f
    5008:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    500b:	06                   	push   es
    500c:	57                   	push   di
    500d:	9a 4d 4c 71 50       	call   0x5071:0x4c4d
    5012:	c9                   	leave
    5013:	ca 08 00             	retf   0x8
    5016:	21 44 65             	and    WORD PTR [si+0x65],ax
    5019:	6d                   	ins    WORD PTR es:[di],dx
    501a:	61                   	popa
    501b:	6e                   	outs   dx,BYTE PTR ds:[si]
    501c:	64 65 20 70 6f       	fs and BYTE PTR gs:[bx+si+0x6f],dh
    5021:	74 65                	je     0x5088
    5023:	6e                   	outs   dx,BYTE PTR ds:[si]
    5024:	74 69                	je     0x508f
    5026:	65 6c                	gs ins BYTE PTR es:[di],dx
    5028:	6c                   	ins    BYTE PTR es:[di],dx
    5029:	65 20 73 75          	and    BYTE PTR gs:[bp+di+0x75],dh
    502d:	72 20                	jb     0x504f
    502f:	6c                   	ins    BYTE PTR es:[di],dx
    5030:	65 20 6d 61          	and    BYTE PTR gs:[di+0x61],ch
    5034:	72 63                	jb     0x5099
    5036:	68 e9 0c             	push   0xce9
    5039:	56                   	push   si
    503a:	6f                   	outs   dx,WORD PTR ds:[si]
    503b:	6c                   	ins    BYTE PTR es:[di],dx
    503c:	75 6d                	jne    0x50ab
    503e:	65 4d                	gs dec bp
    5040:	61                   	popa
    5041:	72 63                	jb     0x50a6
    5043:	68 65 00             	push   0x65
    5046:	80 ff ff             	cmp    bh,0xff
    5049:	ff                   	(bad)
    504a:	7f 00                	jg     0x504c
    504c:	00 00                	add    BYTE PTR [bx+si],al
    504e:	00 00                	add    BYTE PTR [bx+si],al
    5050:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5053:	e5 b8                	in     ax,0xb8
    5055:	18 02                	sbb    BYTE PTR [bp+si],al
    5057:	9a 44 04 a9 51       	call   0x51a9:0x444
    505c:	81 ec 18 02          	sub    sp,0x218
    5060:	6a ff                	push   0xffff
    5062:	6a ff                	push   0xffff
    5064:	bf 16 50             	mov    di,0x5016
    5067:	0e                   	push   cs
    5068:	57                   	push   di
    5069:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    506c:	06                   	push   es
    506d:	57                   	push   di
    506e:	9a 90 7d 55 51       	call   0x5155:0x7d90
    5073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5076:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    507b:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    507f:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    5083:	06                   	push   es
    5084:	57                   	push   di
    5085:	9a d2 31 ad 50       	call   0x50ad:0x31d2
    508a:	6a 01                	push   0x1
    508c:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    5090:	06                   	push   es
    5091:	57                   	push   di
    5092:	9a fb 2f a2 50       	call   0x50a2:0x2ffb
    5097:	6a 00                	push   0x0
    5099:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    509d:	06                   	push   es
    509e:	57                   	push   di
    509f:	9a d2 2e 47 51       	call   0x5147:0x2ed2
    50a4:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    50a8:	06                   	push   es
    50a9:	57                   	push   di
    50aa:	9a bf 31 65 51       	call   0x5165:0x31bf
    50af:	a1 a2 1e             	mov    ax,ds:0x1ea2
    50b2:	99                   	cwd
    50b3:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    50b7:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    50bb:	b8 01 00             	mov    ax,0x1
    50be:	31 d2                	xor    dx,dx
    50c0:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    50c4:	7e 03                	jle    0x50c9
    50c6:	e9 af 01             	jmp    0x5278
    50c9:	7c 09                	jl     0x50d4
    50cb:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    50cf:	76 03                	jbe    0x50d4
    50d1:	e9 a4 01             	jmp    0x5278
    50d4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    50d7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    50da:	eb 08                	jmp    0x50e4
    50dc:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    50e0:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    50e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50e7:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    50ec:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    50f0:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    50f4:	31 c0                	xor    ax,ax
    50f6:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    50f9:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    50fc:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    5101:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    5106:	eb 08                	jmp    0x5110
    5108:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    510c:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    5110:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5113:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5116:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    511a:	89 96 da fe          	mov    WORD PTR [bp-0x126],dx
    511e:	c6 86 dc fe 00       	mov    BYTE PTR [bp-0x124],0x0
    5123:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5126:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5129:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    512d:	89 96 e2 fe          	mov    WORD PTR [bp-0x11e],dx
    5131:	c6 86 e4 fe 00       	mov    BYTE PTR [bp-0x11c],0x0
    5136:	8d be d8 fe          	lea    di,[bp-0x128]
    513a:	16                   	push   ss
    513b:	57                   	push   di
    513c:	6a 01                	push   0x1
    513e:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    5142:	06                   	push   es
    5143:	57                   	push   di
    5144:	9a 95 28 ba 54       	call   0x54ba:0x2895
    5149:	08 c0                	or     al,al
    514b:	75 0a                	jne    0x5157
    514d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5150:	06                   	push   es
    5151:	57                   	push   di
    5152:	9a f6 10 9b 51       	call   0x519b:0x10f6
    5157:	bf 38 50             	mov    di,0x5038
    515a:	0e                   	push   cs
    515b:	57                   	push   di
    515c:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    5160:	06                   	push   es
    5161:	57                   	push   di
    5162:	9a 9b 3b 85 52       	call   0x5285:0x3b9b
    5167:	89 c7                	mov    di,ax
    5169:	8e c2                	mov    es,dx
    516b:	06                   	push   es
    516c:	57                   	push   di
    516d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5170:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5174:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5177:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    517a:	8d be e8 fd          	lea    di,[bp-0x218]
    517e:	16                   	push   ss
    517f:	57                   	push   di
    5180:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    5184:	83 ec 08             	sub    sp,0x8
    5187:	89 e3                	mov    bx,sp
    5189:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    518d:	90                   	nop
    518e:	9b                   	fwait
    518f:	6a 0c                	push   0xc
    5191:	6a 00                	push   0x0
    5193:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5196:	06                   	push   es
    5197:	57                   	push   di
    5198:	9a 2d 12 2a 52       	call   0x522a:0x122d
    519d:	8d be f0 fe          	lea    di,[bp-0x110]
    51a1:	16                   	push   ss
    51a2:	57                   	push   di
    51a3:	68 ff 00             	push   0xff
    51a6:	9a e7 17 b7 51       	call   0x51b7:0x17e7
    51ab:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    51ae:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    51b1:	bf 45 50             	mov    di,0x5045
    51b4:	9a 16 04 c6 51       	call   0x51c6:0x416
    51b9:	50                   	push   ax
    51ba:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    51bd:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    51c0:	bf 45 50             	mov    di,0x5045
    51c3:	9a 16 04 ef 51       	call   0x51ef:0x416
    51c8:	50                   	push   ax
    51c9:	8d be f0 fe          	lea    di,[bp-0x110]
    51cd:	16                   	push   ss
    51ce:	57                   	push   di
    51cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51d2:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    51d7:	06                   	push   es
    51d8:	57                   	push   di
    51d9:	9a 08 9b 5e 52       	call   0x525e:0x9b08
    51de:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    51e1:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    51e4:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    51e7:	13 56 f6             	adc    dx,WORD PTR [bp-0xa]
    51ea:	71 05                	jno    0x51f1
    51ec:	9a 3e 04 38 52       	call   0x5238:0x43e
    51f1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    51f4:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    51f7:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    51fb:	74 03                	je     0x5200
    51fd:	e9 08 ff             	jmp    0x5108
    5200:	83 7e f8 02          	cmp    WORD PTR [bp-0x8],0x2
    5204:	74 03                	je     0x5209
    5206:	e9 ff fe             	jmp    0x5108
    5209:	8d be e8 fd          	lea    di,[bp-0x218]
    520d:	16                   	push   ss
    520e:	57                   	push   di
    520f:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    5213:	83 ec 08             	sub    sp,0x8
    5216:	89 e3                	mov    bx,sp
    5218:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    521c:	90                   	nop
    521d:	9b                   	fwait
    521e:	6a 0c                	push   0xc
    5220:	6a 00                	push   0x0
    5222:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5225:	06                   	push   es
    5226:	57                   	push   di
    5227:	9a 2d 12 a3 52       	call   0x52a3:0x122d
    522c:	8d be f0 fe          	lea    di,[bp-0x110]
    5230:	16                   	push   ss
    5231:	57                   	push   di
    5232:	68 ff 00             	push   0xff
    5235:	9a e7 17 48 52       	call   0x5248:0x17e7
    523a:	6a 03                	push   0x3
    523c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    523f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5242:	bf 45 50             	mov    di,0x5045
    5245:	9a 16 04 d8 52       	call   0x52d8:0x416
    524a:	50                   	push   ax
    524b:	8d be f0 fe          	lea    di,[bp-0x110]
    524f:	16                   	push   ss
    5250:	57                   	push   di
    5251:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5254:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5259:	06                   	push   es
    525a:	57                   	push   di
    525b:	9a 08 9b 82 56       	call   0x5682:0x9b08
    5260:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5263:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5266:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    526a:	74 03                	je     0x526f
    526c:	e9 6d fe             	jmp    0x50dc
    526f:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    5273:	74 03                	je     0x5278
    5275:	e9 64 fe             	jmp    0x50dc
    5278:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    527b:	26 c4 bd e8 02       	les    di,DWORD PTR es:[di+0x2e8]
    5280:	06                   	push   es
    5281:	57                   	push   di
    5282:	9a d2 31 ad 54       	call   0x54ad:0x31d2
    5287:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    528a:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    5290:	9b 2e d9 06 4d 50    	fld    DWORD PTR cs:0x504d
    5296:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    529c:	90                   	nop
    529d:	9b                   	fwait
    529e:	06                   	push   es
    529f:	57                   	push   di
    52a0:	9a 6f 14 b3 52       	call   0x52b3:0x146f
    52a5:	ff 76 08             	push   WORD PTR [bp+0x8]
    52a8:	ff 76 06             	push   WORD PTR [bp+0x6]
    52ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52ae:	06                   	push   es
    52af:	57                   	push   di
    52b0:	9a a2 2b f2 52       	call   0x52f2:0x2ba2
    52b5:	c9                   	leave
    52b6:	ca 04 00             	retf   0x4
    52b9:	07                   	pop    es
    52ba:	64 65 6d             	fs gs ins WORD PTR es:[di],dx
    52bd:	61                   	popa
    52be:	6e                   	outs   dx,BYTE PTR ds:[si]
    52bf:	64 65 00 08          	fs add BYTE PTR gs:[bx+si],cl
    52c3:	50                   	push   ax
    52c4:	e9 72 69             	jmp    0xbc39
    52c7:	6f                   	outs   dx,WORD PTR ds:[si]
    52c8:	64 65 73 00          	fs gs jae 0x52cc
    52cc:	00 00                	add    BYTE PTR [bx+si],al
    52ce:	00 55 89             	add    BYTE PTR [di-0x77],dl
    52d1:	e5 b8                	in     ax,0xb8
    52d3:	08 00                	or     BYTE PTR [bx+si],al
    52d5:	9a 44 04 46 53       	call   0x5346:0x444
    52da:	83 ec 08             	sub    sp,0x8
    52dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52e0:	26 c7 85 8a 08 0b 00 	mov    WORD PTR es:[di+0x88a],0xb
    52e7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    52ea:	ff 76 0a             	push   WORD PTR [bp+0xa]
    52ed:	06                   	push   es
    52ee:	57                   	push   di
    52ef:	9a 5b 7f 7a 53       	call   0x537a:0x7f5b
    52f4:	6a 00                	push   0x0
    52f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52f9:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    52fe:	06                   	push   es
    52ff:	57                   	push   di
    5300:	9a a5 13 14 53       	call   0x5314:0x13a5
    5305:	6a 00                	push   0x0
    5307:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    530a:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    530f:	06                   	push   es
    5310:	57                   	push   di
    5311:	9a a5 13 25 53       	call   0x5325:0x13a5
    5316:	6a 00                	push   0x0
    5318:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    531b:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    5320:	06                   	push   es
    5321:	57                   	push   di
    5322:	9a a5 13 3c 53       	call   0x533c:0x13a5
    5327:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    532a:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    532f:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5332:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5335:	6a 00                	push   0x0
    5337:	06                   	push   es
    5338:	57                   	push   di
    5339:	9a 26 13 51 53       	call   0x5351:0x1326
    533e:	2d 01 00             	sub    ax,0x1
    5341:	71 05                	jno    0x5348
    5343:	9a 3e 04 e1 53       	call   0x53e1:0x43e
    5348:	50                   	push   ax
    5349:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    534c:	06                   	push   es
    534d:	57                   	push   di
    534e:	9a 53 13 5c 53       	call   0x535c:0x1353
    5353:	89 c7                	mov    di,ax
    5355:	8e c2                	mov    es,dx
    5357:	06                   	push   es
    5358:	57                   	push   di
    5359:	9a a5 13 8b 53       	call   0x538b:0x13a5
    535e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5361:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    5366:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    536b:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    5370:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    5375:	06                   	push   es
    5376:	57                   	push   di
    5377:	9a bd 7f 9a 53       	call   0x539a:0x7fbd
    537c:	6a 01                	push   0x1
    537e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5381:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    5386:	06                   	push   es
    5387:	57                   	push   di
    5388:	9a a5 13 d7 53       	call   0x53d7:0x13a5
    538d:	bf b9 52             	mov    di,0x52b9
    5390:	0e                   	push   cs
    5391:	57                   	push   di
    5392:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5395:	06                   	push   es
    5396:	57                   	push   di
    5397:	9a 77 38 a9 53       	call   0x53a9:0x3877
    539c:	bf c1 52             	mov    di,0x52c1
    539f:	0e                   	push   cs
    53a0:	57                   	push   di
    53a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53a4:	06                   	push   es
    53a5:	57                   	push   di
    53a6:	9a 02 39 b8 53       	call   0x53b8:0x3902
    53ab:	bf c2 52             	mov    di,0x52c2
    53ae:	0e                   	push   cs
    53af:	57                   	push   di
    53b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53b3:	06                   	push   es
    53b4:	57                   	push   di
    53b5:	9a ef 37 c2 53       	call   0x53c2:0x37ef
    53ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53bd:	06                   	push   es
    53be:	57                   	push   di
    53bf:	9a 10 81 21 54       	call   0x5421:0x8110
    53c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53c7:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    53cc:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    53cf:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    53d2:	06                   	push   es
    53d3:	57                   	push   di
    53d4:	9a 26 13 02 54       	call   0x5402:0x1326
    53d9:	2d 01 00             	sub    ax,0x1
    53dc:	71 05                	jno    0x53e3
    53de:	9a 3e 04 7f 54       	call   0x547f:0x43e
    53e3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    53e6:	31 c0                	xor    ax,ax
    53e8:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    53eb:	7f 2a                	jg     0x5417
    53ed:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    53f0:	eb 03                	jmp    0x53f5
    53f2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    53f5:	6a 01                	push   0x1
    53f7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    53fa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    53fd:	06                   	push   es
    53fe:	57                   	push   di
    53ff:	9a 53 13 0d 54       	call   0x540d:0x1353
    5404:	89 c7                	mov    di,ax
    5406:	8e c2                	mov    es,dx
    5408:	06                   	push   es
    5409:	57                   	push   di
    540a:	9a 75 12 a9 57       	call   0x57a9:0x1275
    540f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5412:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    5415:	75 db                	jne    0x53f2
    5417:	6a 01                	push   0x1
    5419:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    541c:	06                   	push   es
    541d:	57                   	push   di
    541e:	9a 8f 8a 3f 54       	call   0x543f:0x8a8f
    5423:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5426:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    542c:	9b 2e d9 06 cb 52    	fld    DWORD PTR cs:0x52cb
    5432:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    5438:	90                   	nop
    5439:	9b                   	fwait
    543a:	06                   	push   es
    543b:	57                   	push   di
    543c:	9a 51 50 96 54       	call   0x5496:0x5051
    5441:	c9                   	leave
    5442:	ca 08 00             	retf   0x8
    5445:	1c 44                	sbb    al,0x44
    5447:	65 6d                	gs ins WORD PTR es:[di],dx
    5449:	61                   	popa
    544a:	6e                   	outs   dx,BYTE PTR ds:[si]
    544b:	64 65 20 72 e9       	fs and BYTE PTR gs:[bp+si-0x17],dh
    5450:	65 6c                	gs ins BYTE PTR es:[di],dx
    5452:	6c                   	ins    BYTE PTR es:[di],dx
    5453:	65 20 73 75          	and    BYTE PTR gs:[bp+di+0x75],dh
    5457:	72 20                	jb     0x5479
    5459:	6c                   	ins    BYTE PTR es:[di],dx
    545a:	65 20 6d 61          	and    BYTE PTR gs:[di+0x61],ch
    545e:	72 63                	jb     0x54c3
    5460:	68 e9 07             	push   0x7e9
    5463:	44                   	inc    sp
    5464:	65 6d                	gs ins WORD PTR es:[di],dx
    5466:	61                   	popa
    5467:	6e                   	outs   dx,BYTE PTR ds:[si]
    5468:	64 65 00 80 ff ff    	fs add BYTE PTR gs:[bx+si-0x1],al
    546e:	ff                   	(bad)
    546f:	7f 00                	jg     0x5471
    5471:	00 00                	add    BYTE PTR [bx+si],al
    5473:	00 00                	add    BYTE PTR [bx+si],al
    5475:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5478:	e5 b8                	in     ax,0xb8
    547a:	20 02                	and    BYTE PTR [bp+si],al
    547c:	9a 44 04 00 56       	call   0x5600:0x444
    5481:	81 ec 20 02          	sub    sp,0x220
    5485:	6a ff                	push   0xffff
    5487:	6a ff                	push   0xffff
    5489:	bf 45 54             	mov    di,0x5445
    548c:	0e                   	push   cs
    548d:	57                   	push   di
    548e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5491:	06                   	push   es
    5492:	57                   	push   di
    5493:	9a 90 7d ca 55       	call   0x55ca:0x7d90
    5498:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    549b:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    54a0:	89 be e4 fe          	mov    WORD PTR [bp-0x11c],di
    54a4:	8c 86 e6 fe          	mov    WORD PTR [bp-0x11a],es
    54a8:	06                   	push   es
    54a9:	57                   	push   di
    54aa:	9a d2 31 d2 54       	call   0x54d2:0x31d2
    54af:	6a 01                	push   0x1
    54b1:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    54b5:	06                   	push   es
    54b6:	57                   	push   di
    54b7:	9a fb 2f c7 54       	call   0x54c7:0x2ffb
    54bc:	6a 00                	push   0x0
    54be:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    54c2:	06                   	push   es
    54c3:	57                   	push   di
    54c4:	9a d2 2e bc 55       	call   0x55bc:0x2ed2
    54c9:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    54cd:	06                   	push   es
    54ce:	57                   	push   di
    54cf:	9a bf 31 da 55       	call   0x55da:0x31bf
    54d4:	a1 a2 1e             	mov    ax,ds:0x1ea2
    54d7:	99                   	cwd
    54d8:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    54dc:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    54e0:	b8 01 00             	mov    ax,0x1
    54e3:	31 d2                	xor    dx,dx
    54e5:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    54e9:	7e 03                	jle    0x54ee
    54eb:	e9 30 02             	jmp    0x571e
    54ee:	7c 09                	jl     0x54f9
    54f0:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    54f4:	76 03                	jbe    0x54f9
    54f6:	e9 25 02             	jmp    0x571e
    54f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    54fc:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    54ff:	eb 08                	jmp    0x5509
    5501:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    5505:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    5509:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    550c:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    5511:	89 be e0 fe          	mov    WORD PTR [bp-0x120],di
    5515:	8c 86 e2 fe          	mov    WORD PTR [bp-0x11e],es
    5519:	31 c0                	xor    ax,ax
    551b:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    551e:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    5521:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    5526:	c7 46 f6 00 00       	mov    WORD PTR [bp-0xa],0x0
    552b:	eb 08                	jmp    0x5535
    552d:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    5531:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    5535:	31 c0                	xor    ax,ax
    5537:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    553a:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    553d:	a1 4e 01             	mov    ax,ds:0x14e
    5540:	99                   	cwd
    5541:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    5545:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    5549:	b8 01 00             	mov    ax,0x1
    554c:	31 d2                	xor    dx,dx
    554e:	3b 96 de fe          	cmp    dx,WORD PTR [bp-0x122]
    5552:	7e 03                	jle    0x5557
    5554:	e9 c9 00             	jmp    0x5620
    5557:	7c 09                	jl     0x5562
    5559:	3b 86 dc fe          	cmp    ax,WORD PTR [bp-0x124]
    555d:	76 03                	jbe    0x5562
    555f:	e9 be 00             	jmp    0x5620
    5562:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5565:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5568:	eb 08                	jmp    0x5572
    556a:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    556e:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    5572:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5575:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5578:	89 86 c4 fe          	mov    WORD PTR [bp-0x13c],ax
    557c:	89 96 c6 fe          	mov    WORD PTR [bp-0x13a],dx
    5580:	c6 86 c8 fe 00       	mov    BYTE PTR [bp-0x138],0x0
    5585:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5588:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    558b:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    558f:	89 96 ce fe          	mov    WORD PTR [bp-0x132],dx
    5593:	c6 86 d0 fe 00       	mov    BYTE PTR [bp-0x130],0x0
    5598:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    559b:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    559e:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    55a2:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    55a6:	c6 86 d8 fe 00       	mov    BYTE PTR [bp-0x128],0x0
    55ab:	8d be c4 fe          	lea    di,[bp-0x13c]
    55af:	16                   	push   ss
    55b0:	57                   	push   di
    55b1:	6a 02                	push   0x2
    55b3:	c4 be e0 fe          	les    di,DWORD PTR [bp-0x120]
    55b7:	06                   	push   es
    55b8:	57                   	push   di
    55b9:	9a 95 28 44 59       	call   0x5944:0x2895
    55be:	08 c0                	or     al,al
    55c0:	75 0a                	jne    0x55cc
    55c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55c5:	06                   	push   es
    55c6:	57                   	push   di
    55c7:	9a f6 10 41 56       	call   0x5641:0x10f6
    55cc:	bf 62 54             	mov    di,0x5462
    55cf:	0e                   	push   cs
    55d0:	57                   	push   di
    55d1:	c4 be e0 fe          	les    di,DWORD PTR [bp-0x120]
    55d5:	06                   	push   es
    55d6:	57                   	push   di
    55d7:	9a 9b 3b 2b 57       	call   0x572b:0x3b9b
    55dc:	89 c7                	mov    di,ax
    55de:	8e c2                	mov    es,dx
    55e0:	06                   	push   es
    55e1:	57                   	push   di
    55e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55e5:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    55e9:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    55ec:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    55ef:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    55f2:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
    55f5:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    55f8:	13 56 f2             	adc    dx,WORD PTR [bp-0xe]
    55fb:	71 05                	jno    0x5602
    55fd:	9a 3e 04 4f 56       	call   0x564f:0x43e
    5602:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    5605:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    5608:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    560b:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    560e:	3b 96 de fe          	cmp    dx,WORD PTR [bp-0x122]
    5612:	74 03                	je     0x5617
    5614:	e9 53 ff             	jmp    0x556a
    5617:	3b 86 dc fe          	cmp    ax,WORD PTR [bp-0x124]
    561b:	74 03                	je     0x5620
    561d:	e9 4a ff             	jmp    0x556a
    5620:	8d be e0 fd          	lea    di,[bp-0x220]
    5624:	16                   	push   ss
    5625:	57                   	push   di
    5626:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
    562a:	83 ec 08             	sub    sp,0x8
    562d:	89 e3                	mov    bx,sp
    562f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5633:	90                   	nop
    5634:	9b                   	fwait
    5635:	6a 0c                	push   0xc
    5637:	6a 00                	push   0x0
    5639:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    563c:	06                   	push   es
    563d:	57                   	push   di
    563e:	9a 2d 12 d0 56       	call   0x56d0:0x122d
    5643:	8d be e8 fe          	lea    di,[bp-0x118]
    5647:	16                   	push   ss
    5648:	57                   	push   di
    5649:	68 ff 00             	push   0xff
    564c:	9a e7 17 5d 56       	call   0x565d:0x17e7
    5651:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    5654:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    5657:	bf 6a 54             	mov    di,0x546a
    565a:	9a 16 04 6c 56       	call   0x566c:0x416
    565f:	50                   	push   ax
    5660:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5663:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5666:	bf 6a 54             	mov    di,0x546a
    5669:	9a 16 04 95 56       	call   0x5695:0x416
    566e:	50                   	push   ax
    566f:	8d be e8 fe          	lea    di,[bp-0x118]
    5673:	16                   	push   ss
    5674:	57                   	push   di
    5675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5678:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    567d:	06                   	push   es
    567e:	57                   	push   di
    567f:	9a 08 9b 04 57       	call   0x5704:0x9b08
    5684:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    5687:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    568a:	03 46 ec             	add    ax,WORD PTR [bp-0x14]
    568d:	13 56 ee             	adc    dx,WORD PTR [bp-0x12]
    5690:	71 05                	jno    0x5697
    5692:	9a 3e 04 de 56       	call   0x56de:0x43e
    5697:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    569a:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    569d:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    56a1:	74 03                	je     0x56a6
    56a3:	e9 87 fe             	jmp    0x552d
    56a6:	83 7e f4 02          	cmp    WORD PTR [bp-0xc],0x2
    56aa:	74 03                	je     0x56af
    56ac:	e9 7e fe             	jmp    0x552d
    56af:	8d be e0 fd          	lea    di,[bp-0x220]
    56b3:	16                   	push   ss
    56b4:	57                   	push   di
    56b5:	9b db 46 e8          	fild   DWORD PTR [bp-0x18]
    56b9:	83 ec 08             	sub    sp,0x8
    56bc:	89 e3                	mov    bx,sp
    56be:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    56c2:	90                   	nop
    56c3:	9b                   	fwait
    56c4:	6a 0c                	push   0xc
    56c6:	6a 00                	push   0x0
    56c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56cb:	06                   	push   es
    56cc:	57                   	push   di
    56cd:	9a 2d 12 49 57       	call   0x5749:0x122d
    56d2:	8d be e8 fe          	lea    di,[bp-0x118]
    56d6:	16                   	push   ss
    56d7:	57                   	push   di
    56d8:	68 ff 00             	push   0xff
    56db:	9a e7 17 ee 56       	call   0x56ee:0x17e7
    56e0:	6a 03                	push   0x3
    56e2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    56e5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    56e8:	bf 6a 54             	mov    di,0x546a
    56eb:	9a 16 04 7e 57       	call   0x577e:0x416
    56f0:	50                   	push   ax
    56f1:	8d be e8 fe          	lea    di,[bp-0x118]
    56f5:	16                   	push   ss
    56f6:	57                   	push   di
    56f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56fa:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    56ff:	06                   	push   es
    5700:	57                   	push   di
    5701:	9a 08 9b 9c 5a       	call   0x5a9c:0x9b08
    5706:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5709:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    570c:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    5710:	74 03                	je     0x5715
    5712:	e9 ec fd             	jmp    0x5501
    5715:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    5719:	74 03                	je     0x571e
    571b:	e9 e3 fd             	jmp    0x5501
    571e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5721:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    5726:	06                   	push   es
    5727:	57                   	push   di
    5728:	9a d2 31 37 59       	call   0x5937:0x31d2
    572d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5730:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    5736:	9b 2e d9 06 72 54    	fld    DWORD PTR cs:0x5472
    573c:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    5742:	90                   	nop
    5743:	9b                   	fwait
    5744:	06                   	push   es
    5745:	57                   	push   di
    5746:	9a 6f 14 59 57       	call   0x5759:0x146f
    574b:	ff 76 08             	push   WORD PTR [bp+0x8]
    574e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5751:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5754:	06                   	push   es
    5755:	57                   	push   di
    5756:	9a a2 2b 98 57       	call   0x5798:0x2ba2
    575b:	c9                   	leave
    575c:	ca 04 00             	retf   0x4
    575f:	07                   	pop    es
    5760:	64 65 6d             	fs gs ins WORD PTR es:[di],dx
    5763:	61                   	popa
    5764:	6e                   	outs   dx,BYTE PTR ds:[si]
    5765:	64 65 00 08          	fs add BYTE PTR gs:[bx+si],cl
    5769:	50                   	push   ax
    576a:	e9 72 69             	jmp    0xc0df
    576d:	6f                   	outs   dx,WORD PTR ds:[si]
    576e:	64 65 73 00          	fs gs jae 0x5772
    5772:	00 00                	add    BYTE PTR [bx+si],al
    5774:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5777:	e5 b8                	in     ax,0xb8
    5779:	08 00                	or     BYTE PTR [bx+si],al
    577b:	9a 44 04 ec 57       	call   0x57ec:0x444
    5780:	83 ec 08             	sub    sp,0x8
    5783:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5786:	26 c7 85 8a 08 0c 00 	mov    WORD PTR es:[di+0x88a],0xc
    578d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5790:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5793:	06                   	push   es
    5794:	57                   	push   di
    5795:	9a 5b 7f 20 58       	call   0x5820:0x7f5b
    579a:	6a 00                	push   0x0
    579c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    579f:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    57a4:	06                   	push   es
    57a5:	57                   	push   di
    57a6:	9a a5 13 ba 57       	call   0x57ba:0x13a5
    57ab:	6a 00                	push   0x0
    57ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57b0:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    57b5:	06                   	push   es
    57b6:	57                   	push   di
    57b7:	9a a5 13 cb 57       	call   0x57cb:0x13a5
    57bc:	6a 00                	push   0x0
    57be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57c1:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    57c6:	06                   	push   es
    57c7:	57                   	push   di
    57c8:	9a a5 13 e2 57       	call   0x57e2:0x13a5
    57cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57d0:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    57d5:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    57d8:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    57db:	6a 00                	push   0x0
    57dd:	06                   	push   es
    57de:	57                   	push   di
    57df:	9a 26 13 f7 57       	call   0x57f7:0x1326
    57e4:	2d 01 00             	sub    ax,0x1
    57e7:	71 05                	jno    0x57ee
    57e9:	9a 3e 04 87 58       	call   0x5887:0x43e
    57ee:	50                   	push   ax
    57ef:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    57f2:	06                   	push   es
    57f3:	57                   	push   di
    57f4:	9a 53 13 02 58       	call   0x5802:0x1353
    57f9:	89 c7                	mov    di,ax
    57fb:	8e c2                	mov    es,dx
    57fd:	06                   	push   es
    57fe:	57                   	push   di
    57ff:	9a a5 13 31 58       	call   0x5831:0x13a5
    5804:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5807:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    580c:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    5811:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    5816:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    581b:	06                   	push   es
    581c:	57                   	push   di
    581d:	9a bd 7f 40 58       	call   0x5840:0x7fbd
    5822:	6a 01                	push   0x1
    5824:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5827:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    582c:	06                   	push   es
    582d:	57                   	push   di
    582e:	9a a5 13 7d 58       	call   0x587d:0x13a5
    5833:	bf 5f 57             	mov    di,0x575f
    5836:	0e                   	push   cs
    5837:	57                   	push   di
    5838:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    583b:	06                   	push   es
    583c:	57                   	push   di
    583d:	9a 77 38 4f 58       	call   0x584f:0x3877
    5842:	bf 67 57             	mov    di,0x5767
    5845:	0e                   	push   cs
    5846:	57                   	push   di
    5847:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    584a:	06                   	push   es
    584b:	57                   	push   di
    584c:	9a 02 39 5e 58       	call   0x585e:0x3902
    5851:	bf 68 57             	mov    di,0x5768
    5854:	0e                   	push   cs
    5855:	57                   	push   di
    5856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5859:	06                   	push   es
    585a:	57                   	push   di
    585b:	9a ef 37 68 58       	call   0x5868:0x37ef
    5860:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5863:	06                   	push   es
    5864:	57                   	push   di
    5865:	9a 10 81 c7 58       	call   0x58c7:0x8110
    586a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    586d:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    5872:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5875:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5878:	06                   	push   es
    5879:	57                   	push   di
    587a:	9a 26 13 a8 58       	call   0x58a8:0x1326
    587f:	2d 01 00             	sub    ax,0x1
    5882:	71 05                	jno    0x5889
    5884:	9a 3e 04 08 59       	call   0x5908:0x43e
    5889:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    588c:	31 c0                	xor    ax,ax
    588e:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    5891:	7f 2a                	jg     0x58bd
    5893:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5896:	eb 03                	jmp    0x589b
    5898:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    589b:	6a 01                	push   0x1
    589d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    58a0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    58a3:	06                   	push   es
    58a4:	57                   	push   di
    58a5:	9a 53 13 b3 58       	call   0x58b3:0x1353
    58aa:	89 c7                	mov    di,ax
    58ac:	8e c2                	mov    es,dx
    58ae:	06                   	push   es
    58af:	57                   	push   di
    58b0:	9a 75 12 c9 5b       	call   0x5bc9:0x1275
    58b5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    58b8:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    58bb:	75 db                	jne    0x5898
    58bd:	6a 01                	push   0x1
    58bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58c2:	06                   	push   es
    58c3:	57                   	push   di
    58c4:	9a 8f 8a e5 58       	call   0x58e5:0x8a8f
    58c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58cc:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    58d2:	9b 2e d9 06 71 57    	fld    DWORD PTR cs:0x5771
    58d8:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    58de:	90                   	nop
    58df:	9b                   	fwait
    58e0:	06                   	push   es
    58e1:	57                   	push   di
    58e2:	9a 76 54 20 59       	call   0x5920:0x5476
    58e7:	c9                   	leave
    58e8:	ca 08 00             	retf   0x8
    58eb:	07                   	pop    es
    58ec:	44                   	inc    sp
    58ed:	65 6d                	gs ins WORD PTR es:[di],dx
    58ef:	61                   	popa
    58f0:	6e                   	outs   dx,BYTE PTR ds:[si]
    58f1:	64 65 00 80 ff ff    	fs add BYTE PTR gs:[bx+si-0x1],al
    58f7:	ff                   	(bad)
    58f8:	7f 00                	jg     0x58fa
    58fa:	00 00                	add    BYTE PTR [bx+si],al
    58fc:	00 00                	add    BYTE PTR [bx+si],al
    58fe:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5901:	e5 b8                	in     ax,0xb8
    5903:	18 02                	sbb    BYTE PTR [bp+si],al
    5905:	9a 44 04 69 5a       	call   0x5a69:0x444
    590a:	81 ec 18 02          	sub    sp,0x218
    590e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5911:	6a ff                	push   0xffff
    5913:	bf eb 58             	mov    di,0x58eb
    5916:	0e                   	push   cs
    5917:	57                   	push   di
    5918:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    591b:	06                   	push   es
    591c:	57                   	push   di
    591d:	9a 90 7d 15 5a       	call   0x5a15:0x7d90
    5922:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5925:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    592a:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    592e:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    5932:	06                   	push   es
    5933:	57                   	push   di
    5934:	9a d2 31 5c 59       	call   0x595c:0x31d2
    5939:	6a 01                	push   0x1
    593b:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    593f:	06                   	push   es
    5940:	57                   	push   di
    5941:	9a fb 2f 51 59       	call   0x5951:0x2ffb
    5946:	6a 00                	push   0x0
    5948:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    594c:	06                   	push   es
    594d:	57                   	push   di
    594e:	9a d2 2e 07 5a       	call   0x5a07:0x2ed2
    5953:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    5957:	06                   	push   es
    5958:	57                   	push   di
    5959:	9a bf 31 25 5a       	call   0x5a25:0x31bf
    595e:	a1 a2 1e             	mov    ax,ds:0x1ea2
    5961:	99                   	cwd
    5962:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    5966:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    596a:	b8 01 00             	mov    ax,0x1
    596d:	31 d2                	xor    dx,dx
    596f:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    5973:	7e 03                	jle    0x5978
    5975:	e9 c0 01             	jmp    0x5b38
    5978:	7c 09                	jl     0x5983
    597a:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    597e:	76 03                	jbe    0x5983
    5980:	e9 b5 01             	jmp    0x5b38
    5983:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5986:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5989:	eb 08                	jmp    0x5993
    598b:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    598f:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    5993:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5996:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    599b:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    599f:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    59a3:	31 c0                	xor    ax,ax
    59a5:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    59a8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    59ab:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    59b0:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    59b5:	eb 08                	jmp    0x59bf
    59b7:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    59bb:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    59bf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    59c2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    59c5:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    59c9:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    59cd:	c6 86 d4 fe 00       	mov    BYTE PTR [bp-0x12c],0x0
    59d2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    59d5:	99                   	cwd
    59d6:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    59da:	89 96 da fe          	mov    WORD PTR [bp-0x126],dx
    59de:	c6 86 dc fe 00       	mov    BYTE PTR [bp-0x124],0x0
    59e3:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    59e6:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    59e9:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    59ed:	89 96 e2 fe          	mov    WORD PTR [bp-0x11e],dx
    59f1:	c6 86 e4 fe 00       	mov    BYTE PTR [bp-0x11c],0x0
    59f6:	8d be d0 fe          	lea    di,[bp-0x130]
    59fa:	16                   	push   ss
    59fb:	57                   	push   di
    59fc:	6a 02                	push   0x2
    59fe:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    5a02:	06                   	push   es
    5a03:	57                   	push   di
    5a04:	9a 95 28 d2 5d       	call   0x5dd2:0x2895
    5a09:	08 c0                	or     al,al
    5a0b:	75 0a                	jne    0x5a17
    5a0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a10:	06                   	push   es
    5a11:	57                   	push   di
    5a12:	9a f6 10 5b 5a       	call   0x5a5b:0x10f6
    5a17:	bf eb 58             	mov    di,0x58eb
    5a1a:	0e                   	push   cs
    5a1b:	57                   	push   di
    5a1c:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    5a20:	06                   	push   es
    5a21:	57                   	push   di
    5a22:	9a 9b 3b 45 5b       	call   0x5b45:0x3b9b
    5a27:	89 c7                	mov    di,ax
    5a29:	8e c2                	mov    es,dx
    5a2b:	06                   	push   es
    5a2c:	57                   	push   di
    5a2d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a30:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5a34:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5a37:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5a3a:	8d be e8 fd          	lea    di,[bp-0x218]
    5a3e:	16                   	push   ss
    5a3f:	57                   	push   di
    5a40:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    5a44:	83 ec 08             	sub    sp,0x8
    5a47:	89 e3                	mov    bx,sp
    5a49:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5a4d:	90                   	nop
    5a4e:	9b                   	fwait
    5a4f:	6a 0c                	push   0xc
    5a51:	6a 00                	push   0x0
    5a53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a56:	06                   	push   es
    5a57:	57                   	push   di
    5a58:	9a 2d 12 ea 5a       	call   0x5aea:0x122d
    5a5d:	8d be f0 fe          	lea    di,[bp-0x110]
    5a61:	16                   	push   ss
    5a62:	57                   	push   di
    5a63:	68 ff 00             	push   0xff
    5a66:	9a e7 17 77 5a       	call   0x5a77:0x17e7
    5a6b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5a6e:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5a71:	bf f3 58             	mov    di,0x58f3
    5a74:	9a 16 04 86 5a       	call   0x5a86:0x416
    5a79:	50                   	push   ax
    5a7a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5a7d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5a80:	bf f3 58             	mov    di,0x58f3
    5a83:	9a 16 04 af 5a       	call   0x5aaf:0x416
    5a88:	50                   	push   ax
    5a89:	8d be f0 fe          	lea    di,[bp-0x110]
    5a8d:	16                   	push   ss
    5a8e:	57                   	push   di
    5a8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a92:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5a97:	06                   	push   es
    5a98:	57                   	push   di
    5a99:	9a 08 9b 1e 5b       	call   0x5b1e:0x9b08
    5a9e:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    5aa1:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    5aa4:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    5aa7:	13 56 f6             	adc    dx,WORD PTR [bp-0xa]
    5aaa:	71 05                	jno    0x5ab1
    5aac:	9a 3e 04 f8 5a       	call   0x5af8:0x43e
    5ab1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    5ab4:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    5ab7:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    5abb:	74 03                	je     0x5ac0
    5abd:	e9 f7 fe             	jmp    0x59b7
    5ac0:	83 7e f8 02          	cmp    WORD PTR [bp-0x8],0x2
    5ac4:	74 03                	je     0x5ac9
    5ac6:	e9 ee fe             	jmp    0x59b7
    5ac9:	8d be e8 fd          	lea    di,[bp-0x218]
    5acd:	16                   	push   ss
    5ace:	57                   	push   di
    5acf:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    5ad3:	83 ec 08             	sub    sp,0x8
    5ad6:	89 e3                	mov    bx,sp
    5ad8:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5adc:	90                   	nop
    5add:	9b                   	fwait
    5ade:	6a 0c                	push   0xc
    5ae0:	6a 00                	push   0x0
    5ae2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ae5:	06                   	push   es
    5ae6:	57                   	push   di
    5ae7:	9a 2d 12 63 5b       	call   0x5b63:0x122d
    5aec:	8d be f0 fe          	lea    di,[bp-0x110]
    5af0:	16                   	push   ss
    5af1:	57                   	push   di
    5af2:	68 ff 00             	push   0xff
    5af5:	9a e7 17 08 5b       	call   0x5b08:0x17e7
    5afa:	6a 03                	push   0x3
    5afc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5aff:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5b02:	bf f3 58             	mov    di,0x58f3
    5b05:	9a 16 04 98 5b       	call   0x5b98:0x416
    5b0a:	50                   	push   ax
    5b0b:	8d be f0 fe          	lea    di,[bp-0x110]
    5b0f:	16                   	push   ss
    5b10:	57                   	push   di
    5b11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b14:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5b19:	06                   	push   es
    5b1a:	57                   	push   di
    5b1b:	9a 08 9b 4b 5f       	call   0x5f4b:0x9b08
    5b20:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5b23:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5b26:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    5b2a:	74 03                	je     0x5b2f
    5b2c:	e9 5c fe             	jmp    0x598b
    5b2f:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    5b33:	74 03                	je     0x5b38
    5b35:	e9 53 fe             	jmp    0x598b
    5b38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b3b:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    5b40:	06                   	push   es
    5b41:	57                   	push   di
    5b42:	9a d2 31 c5 5d       	call   0x5dc5:0x31d2
    5b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b4a:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    5b50:	9b 2e d9 06 fb 58    	fld    DWORD PTR cs:0x58fb
    5b56:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    5b5c:	90                   	nop
    5b5d:	9b                   	fwait
    5b5e:	06                   	push   es
    5b5f:	57                   	push   di
    5b60:	9a 6f 14 73 5b       	call   0x5b73:0x146f
    5b65:	ff 76 08             	push   WORD PTR [bp+0x8]
    5b68:	ff 76 06             	push   WORD PTR [bp+0x6]
    5b6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b6e:	06                   	push   es
    5b6f:	57                   	push   di
    5b70:	9a a2 2b b2 5b       	call   0x5bb2:0x2ba2
    5b75:	c9                   	leave
    5b76:	ca 06 00             	retf   0x6
    5b79:	07                   	pop    es
    5b7a:	44                   	inc    sp
    5b7b:	65 6d                	gs ins WORD PTR es:[di],dx
    5b7d:	61                   	popa
    5b7e:	6e                   	outs   dx,BYTE PTR ds:[si]
    5b7f:	64 65 00 08          	fs add BYTE PTR gs:[bx+si],cl
    5b83:	50                   	push   ax
    5b84:	e9 72 69             	jmp    0xc4f9
    5b87:	6f                   	outs   dx,WORD PTR ds:[si]
    5b88:	64 65 73 00          	fs gs jae 0x5b8c
    5b8c:	00 00                	add    BYTE PTR [bx+si],al
    5b8e:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5b91:	e5 b8                	in     ax,0xb8
    5b93:	08 00                	or     BYTE PTR [bx+si],al
    5b95:	9a 44 04 d3 5b       	call   0x5bd3:0x444
    5b9a:	83 ec 08             	sub    sp,0x8
    5b9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ba0:	26 c7 85 8a 08 0d 00 	mov    WORD PTR es:[di+0x88a],0xd
    5ba7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5baa:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5bad:	06                   	push   es
    5bae:	57                   	push   di
    5baf:	9a 5b 7f 07 5c       	call   0x5c07:0x7f5b
    5bb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bb7:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    5bbc:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5bbf:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5bc2:	6a 00                	push   0x0
    5bc4:	06                   	push   es
    5bc5:	57                   	push   di
    5bc6:	9a 26 13 de 5b       	call   0x5bde:0x1326
    5bcb:	2d 01 00             	sub    ax,0x1
    5bce:	71 05                	jno    0x5bd5
    5bd0:	9a 3e 04 5b 5c       	call   0x5c5b:0x43e
    5bd5:	50                   	push   ax
    5bd6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5bd9:	06                   	push   es
    5bda:	57                   	push   di
    5bdb:	9a 53 13 e9 5b       	call   0x5be9:0x1353
    5be0:	89 c7                	mov    di,ax
    5be2:	8e c2                	mov    es,dx
    5be4:	06                   	push   es
    5be5:	57                   	push   di
    5be6:	9a a5 13 18 5c       	call   0x5c18:0x13a5
    5beb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bee:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    5bf3:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    5bf8:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    5bfd:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    5c02:	06                   	push   es
    5c03:	57                   	push   di
    5c04:	9a bd 7f 8f 5c       	call   0x5c8f:0x7fbd
    5c09:	6a 01                	push   0x1
    5c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c0e:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    5c13:	06                   	push   es
    5c14:	57                   	push   di
    5c15:	9a a5 13 29 5c       	call   0x5c29:0x13a5
    5c1a:	6a 00                	push   0x0
    5c1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c1f:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    5c24:	06                   	push   es
    5c25:	57                   	push   di
    5c26:	9a a5 13 3a 5c       	call   0x5c3a:0x13a5
    5c2b:	6a 00                	push   0x0
    5c2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c30:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    5c35:	06                   	push   es
    5c36:	57                   	push   di
    5c37:	9a a5 13 51 5c       	call   0x5c51:0x13a5
    5c3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c3f:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    5c44:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5c47:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5c4a:	6a 00                	push   0x0
    5c4c:	06                   	push   es
    5c4d:	57                   	push   di
    5c4e:	9a 26 13 66 5c       	call   0x5c66:0x1326
    5c53:	2d 01 00             	sub    ax,0x1
    5c56:	71 05                	jno    0x5c5d
    5c58:	9a 3e 04 14 5d       	call   0x5d14:0x43e
    5c5d:	50                   	push   ax
    5c5e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5c61:	06                   	push   es
    5c62:	57                   	push   di
    5c63:	9a 53 13 71 5c       	call   0x5c71:0x1353
    5c68:	89 c7                	mov    di,ax
    5c6a:	8e c2                	mov    es,dx
    5c6c:	06                   	push   es
    5c6d:	57                   	push   di
    5c6e:	9a a5 13 a0 5c       	call   0x5ca0:0x13a5
    5c73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c76:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    5c7b:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    5c80:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    5c85:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    5c8a:	06                   	push   es
    5c8b:	57                   	push   di
    5c8c:	9a bd 7f af 5c       	call   0x5caf:0x7fbd
    5c91:	6a 01                	push   0x1
    5c93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c96:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    5c9b:	06                   	push   es
    5c9c:	57                   	push   di
    5c9d:	9a a5 13 ea 5c       	call   0x5cea:0x13a5
    5ca2:	bf 79 5b             	mov    di,0x5b79
    5ca5:	0e                   	push   cs
    5ca6:	57                   	push   di
    5ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5caa:	06                   	push   es
    5cab:	57                   	push   di
    5cac:	9a 77 38 be 5c       	call   0x5cbe:0x3877
    5cb1:	bf 81 5b             	mov    di,0x5b81
    5cb4:	0e                   	push   cs
    5cb5:	57                   	push   di
    5cb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cb9:	06                   	push   es
    5cba:	57                   	push   di
    5cbb:	9a 02 39 cd 5c       	call   0x5ccd:0x3902
    5cc0:	bf 82 5b             	mov    di,0x5b82
    5cc3:	0e                   	push   cs
    5cc4:	57                   	push   di
    5cc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cc8:	06                   	push   es
    5cc9:	57                   	push   di
    5cca:	9a ef 37 d7 5c       	call   0x5cd7:0x37ef
    5ccf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cd2:	06                   	push   es
    5cd3:	57                   	push   di
    5cd4:	9a 10 81 54 5d       	call   0x5d54:0x8110
    5cd9:	6a 01                	push   0x1
    5cdb:	6a 00                	push   0x0
    5cdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ce0:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    5ce5:	06                   	push   es
    5ce6:	57                   	push   di
    5ce7:	9a 53 13 f5 5c       	call   0x5cf5:0x1353
    5cec:	89 c7                	mov    di,ax
    5cee:	8e c2                	mov    es,dx
    5cf0:	06                   	push   es
    5cf1:	57                   	push   di
    5cf2:	9a 75 12 0a 5d       	call   0x5d0a:0x1275
    5cf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cfa:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    5cff:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5d02:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5d05:	06                   	push   es
    5d06:	57                   	push   di
    5d07:	9a 26 13 35 5d       	call   0x5d35:0x1326
    5d0c:	2d 01 00             	sub    ax,0x1
    5d0f:	71 05                	jno    0x5d16
    5d11:	9a 3e 04 96 5d       	call   0x5d96:0x43e
    5d16:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5d19:	31 c0                	xor    ax,ax
    5d1b:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    5d1e:	7f 2a                	jg     0x5d4a
    5d20:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5d23:	eb 03                	jmp    0x5d28
    5d25:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5d28:	6a 01                	push   0x1
    5d2a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5d2d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5d30:	06                   	push   es
    5d31:	57                   	push   di
    5d32:	9a 53 13 40 5d       	call   0x5d40:0x1353
    5d37:	89 c7                	mov    di,ax
    5d39:	8e c2                	mov    es,dx
    5d3b:	06                   	push   es
    5d3c:	57                   	push   di
    5d3d:	9a 75 12 89 60       	call   0x6089:0x1275
    5d42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5d45:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    5d48:	75 db                	jne    0x5d25
    5d4a:	6a 01                	push   0x1
    5d4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d4f:	06                   	push   es
    5d50:	57                   	push   di
    5d51:	9a 8f 8a 74 5d       	call   0x5d74:0x8a8f
    5d56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d59:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    5d5f:	9b 2e d9 06 8b 5b    	fld    DWORD PTR cs:0x5b8b
    5d65:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    5d6b:	90                   	nop
    5d6c:	9b                   	fwait
    5d6d:	6a 01                	push   0x1
    5d6f:	06                   	push   es
    5d70:	57                   	push   di
    5d71:	9a ff 58 ae 5d       	call   0x5dae:0x58ff
    5d76:	c9                   	leave
    5d77:	ca 08 00             	retf   0x8
    5d7a:	06                   	push   es
    5d7b:	56                   	push   si
    5d7c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    5d7e:	74 65                	je     0x5de5
    5d80:	73 00                	jae    0x5d82
    5d82:	80 ff ff             	cmp    bh,0xff
    5d85:	ff                   	(bad)
    5d86:	7f 00                	jg     0x5d88
    5d88:	00 00                	add    BYTE PTR [bx+si],al
    5d8a:	00 00                	add    BYTE PTR [bx+si],al
    5d8c:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5d8f:	e5 b8                	in     ax,0xb8
    5d91:	1c 02                	sbb    al,0x2
    5d93:	9a 44 04 18 5f       	call   0x5f18:0x444
    5d98:	81 ec 1c 02          	sub    sp,0x21c
    5d9c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d9f:	6a ff                	push   0xffff
    5da1:	bf 7a 5d             	mov    di,0x5d7a
    5da4:	0e                   	push   cs
    5da5:	57                   	push   di
    5da6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5da9:	06                   	push   es
    5daa:	57                   	push   di
    5dab:	9a 90 7d c4 5e       	call   0x5ec4:0x7d90
    5db0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5db3:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    5db8:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    5dbc:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    5dc0:	06                   	push   es
    5dc1:	57                   	push   di
    5dc2:	9a d2 31 ea 5d       	call   0x5dea:0x31d2
    5dc7:	6a 01                	push   0x1
    5dc9:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    5dcd:	06                   	push   es
    5dce:	57                   	push   di
    5dcf:	9a fb 2f df 5d       	call   0x5ddf:0x2ffb
    5dd4:	6a 00                	push   0x0
    5dd6:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    5dda:	06                   	push   es
    5ddb:	57                   	push   di
    5ddc:	9a d2 2e b6 5e       	call   0x5eb6:0x2ed2
    5de1:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    5de5:	06                   	push   es
    5de6:	57                   	push   di
    5de7:	9a bf 31 d4 5e       	call   0x5ed4:0x31bf
    5dec:	a1 a2 1e             	mov    ax,ds:0x1ea2
    5def:	99                   	cwd
    5df0:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    5df4:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    5df8:	b8 01 00             	mov    ax,0x1
    5dfb:	31 d2                	xor    dx,dx
    5dfd:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    5e01:	7e 03                	jle    0x5e06
    5e03:	e9 f3 01             	jmp    0x5ff9
    5e06:	7c 09                	jl     0x5e11
    5e08:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    5e0c:	76 03                	jbe    0x5e11
    5e0e:	e9 e8 01             	jmp    0x5ff9
    5e11:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5e14:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5e17:	eb 08                	jmp    0x5e21
    5e19:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    5e1d:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    5e21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e24:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    5e29:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    5e2d:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    5e31:	31 c0                	xor    ax,ax
    5e33:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    5e36:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5e39:	a1 4e 01             	mov    ax,ds:0x14e
    5e3c:	99                   	cwd
    5e3d:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    5e41:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    5e45:	b8 01 00             	mov    ax,0x1
    5e48:	31 d2                	xor    dx,dx
    5e4a:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    5e4e:	7e 03                	jle    0x5e53
    5e50:	e9 2b 01             	jmp    0x5f7e
    5e53:	7c 09                	jl     0x5e5e
    5e55:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    5e59:	76 03                	jbe    0x5e5e
    5e5b:	e9 20 01             	jmp    0x5f7e
    5e5e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5e61:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5e64:	eb 08                	jmp    0x5e6e
    5e66:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    5e6a:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    5e6e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5e71:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5e74:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    5e78:	89 96 ce fe          	mov    WORD PTR [bp-0x132],dx
    5e7c:	c6 86 d0 fe 00       	mov    BYTE PTR [bp-0x130],0x0
    5e81:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5e84:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5e87:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    5e8b:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    5e8f:	c6 86 d8 fe 00       	mov    BYTE PTR [bp-0x128],0x0
    5e94:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5e97:	99                   	cwd
    5e98:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    5e9c:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    5ea0:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    5ea5:	8d be cc fe          	lea    di,[bp-0x134]
    5ea9:	16                   	push   ss
    5eaa:	57                   	push   di
    5eab:	6a 02                	push   0x2
    5ead:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    5eb1:	06                   	push   es
    5eb2:	57                   	push   di
    5eb3:	9a 95 28 92 62       	call   0x6292:0x2895
    5eb8:	08 c0                	or     al,al
    5eba:	75 0a                	jne    0x5ec6
    5ebc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ebf:	06                   	push   es
    5ec0:	57                   	push   di
    5ec1:	9a f6 10 0a 5f       	call   0x5f0a:0x10f6
    5ec6:	bf 7a 5d             	mov    di,0x5d7a
    5ec9:	0e                   	push   cs
    5eca:	57                   	push   di
    5ecb:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    5ecf:	06                   	push   es
    5ed0:	57                   	push   di
    5ed1:	9a 9b 3b 06 60       	call   0x6006:0x3b9b
    5ed6:	89 c7                	mov    di,ax
    5ed8:	8e c2                	mov    es,dx
    5eda:	06                   	push   es
    5edb:	57                   	push   di
    5edc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5edf:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5ee3:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5ee6:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5ee9:	8d be e4 fd          	lea    di,[bp-0x21c]
    5eed:	16                   	push   ss
    5eee:	57                   	push   di
    5eef:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    5ef3:	83 ec 08             	sub    sp,0x8
    5ef6:	89 e3                	mov    bx,sp
    5ef8:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5efc:	90                   	nop
    5efd:	9b                   	fwait
    5efe:	6a 0c                	push   0xc
    5f00:	6a 00                	push   0x0
    5f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f05:	06                   	push   es
    5f06:	57                   	push   di
    5f07:	9a 2d 12 9f 5f       	call   0x5f9f:0x122d
    5f0c:	8d be f0 fe          	lea    di,[bp-0x110]
    5f10:	16                   	push   ss
    5f11:	57                   	push   di
    5f12:	68 ff 00             	push   0xff
    5f15:	9a e7 17 26 5f       	call   0x5f26:0x17e7
    5f1a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5f1d:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5f20:	bf 81 5d             	mov    di,0x5d81
    5f23:	9a 16 04 35 5f       	call   0x5f35:0x416
    5f28:	50                   	push   ax
    5f29:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5f2c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5f2f:	bf 81 5d             	mov    di,0x5d81
    5f32:	9a 16 04 5e 5f       	call   0x5f5e:0x416
    5f37:	50                   	push   ax
    5f38:	8d be f0 fe          	lea    di,[bp-0x110]
    5f3c:	16                   	push   ss
    5f3d:	57                   	push   di
    5f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f41:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5f46:	06                   	push   es
    5f47:	57                   	push   di
    5f48:	9a 08 9b df 5f       	call   0x5fdf:0x9b08
    5f4d:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    5f50:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    5f53:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    5f56:	13 56 f6             	adc    dx,WORD PTR [bp-0xa]
    5f59:	71 05                	jno    0x5f60
    5f5b:	9a 3e 04 ad 5f       	call   0x5fad:0x43e
    5f60:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    5f63:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    5f66:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5f69:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5f6c:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    5f70:	74 03                	je     0x5f75
    5f72:	e9 f1 fe             	jmp    0x5e66
    5f75:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    5f79:	74 03                	je     0x5f7e
    5f7b:	e9 e8 fe             	jmp    0x5e66
    5f7e:	8d be e8 fd          	lea    di,[bp-0x218]
    5f82:	16                   	push   ss
    5f83:	57                   	push   di
    5f84:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    5f88:	83 ec 08             	sub    sp,0x8
    5f8b:	89 e3                	mov    bx,sp
    5f8d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5f91:	90                   	nop
    5f92:	9b                   	fwait
    5f93:	6a 0c                	push   0xc
    5f95:	6a 00                	push   0x0
    5f97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f9a:	06                   	push   es
    5f9b:	57                   	push   di
    5f9c:	9a 2d 12 24 60       	call   0x6024:0x122d
    5fa1:	8d be f0 fe          	lea    di,[bp-0x110]
    5fa5:	16                   	push   ss
    5fa6:	57                   	push   di
    5fa7:	68 ff 00             	push   0xff
    5faa:	9a e7 17 ba 5f       	call   0x5fba:0x17e7
    5faf:	a1 4e 01             	mov    ax,ds:0x14e
    5fb2:	05 01 00             	add    ax,0x1
    5fb5:	71 05                	jno    0x5fbc
    5fb7:	9a 3e 04 c9 5f       	call   0x5fc9:0x43e
    5fbc:	50                   	push   ax
    5fbd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5fc0:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5fc3:	bf 81 5d             	mov    di,0x5d81
    5fc6:	9a 16 04 58 60       	call   0x6058:0x416
    5fcb:	50                   	push   ax
    5fcc:	8d be f0 fe          	lea    di,[bp-0x110]
    5fd0:	16                   	push   ss
    5fd1:	57                   	push   di
    5fd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fd5:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5fda:	06                   	push   es
    5fdb:	57                   	push   di
    5fdc:	9a 08 9b ea 63       	call   0x63ea:0x9b08
    5fe1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5fe4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5fe7:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    5feb:	74 03                	je     0x5ff0
    5fed:	e9 29 fe             	jmp    0x5e19
    5ff0:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    5ff4:	74 03                	je     0x5ff9
    5ff6:	e9 20 fe             	jmp    0x5e19
    5ff9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ffc:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6001:	06                   	push   es
    6002:	57                   	push   di
    6003:	9a d2 31 85 62       	call   0x6285:0x31d2
    6008:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    600b:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    6011:	9b 2e d9 06 89 5d    	fld    DWORD PTR cs:0x5d89
    6017:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    601d:	90                   	nop
    601e:	9b                   	fwait
    601f:	06                   	push   es
    6020:	57                   	push   di
    6021:	9a 6f 14 34 60       	call   0x6034:0x146f
    6026:	ff 76 08             	push   WORD PTR [bp+0x8]
    6029:	ff 76 06             	push   WORD PTR [bp+0x6]
    602c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    602f:	06                   	push   es
    6030:	57                   	push   di
    6031:	9a a2 2b 72 60       	call   0x6072:0x2ba2
    6036:	c9                   	leave
    6037:	ca 06 00             	retf   0x6
    603a:	06                   	push   es
    603b:	56                   	push   si
    603c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    603e:	74 65                	je     0x60a5
    6040:	73 00                	jae    0x6042
    6042:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    6045:	72 69                	jb     0x60b0
    6047:	6f                   	outs   dx,WORD PTR ds:[si]
    6048:	64 65 73 00          	fs gs jae 0x604c
    604c:	00 00                	add    BYTE PTR [bx+si],al
    604e:	00 55 89             	add    BYTE PTR [di-0x77],dl
    6051:	e5 b8                	in     ax,0xb8
    6053:	08 00                	or     BYTE PTR [bx+si],al
    6055:	9a 44 04 93 60       	call   0x6093:0x444
    605a:	83 ec 08             	sub    sp,0x8
    605d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6060:	26 c7 85 8a 08 15 00 	mov    WORD PTR es:[di+0x88a],0x15
    6067:	ff 76 0c             	push   WORD PTR [bp+0xc]
    606a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    606d:	06                   	push   es
    606e:	57                   	push   di
    606f:	9a 5b 7f c7 60       	call   0x60c7:0x7f5b
    6074:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6077:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    607c:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    607f:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6082:	6a 00                	push   0x0
    6084:	06                   	push   es
    6085:	57                   	push   di
    6086:	9a 26 13 9e 60       	call   0x609e:0x1326
    608b:	2d 01 00             	sub    ax,0x1
    608e:	71 05                	jno    0x6095
    6090:	9a 3e 04 1b 61       	call   0x611b:0x43e
    6095:	50                   	push   ax
    6096:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6099:	06                   	push   es
    609a:	57                   	push   di
    609b:	9a 53 13 a9 60       	call   0x60a9:0x1353
    60a0:	89 c7                	mov    di,ax
    60a2:	8e c2                	mov    es,dx
    60a4:	06                   	push   es
    60a5:	57                   	push   di
    60a6:	9a a5 13 d8 60       	call   0x60d8:0x13a5
    60ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60ae:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    60b3:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    60b8:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    60bd:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    60c2:	06                   	push   es
    60c3:	57                   	push   di
    60c4:	9a bd 7f 4f 61       	call   0x614f:0x7fbd
    60c9:	6a 01                	push   0x1
    60cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60ce:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    60d3:	06                   	push   es
    60d4:	57                   	push   di
    60d5:	9a a5 13 e9 60       	call   0x60e9:0x13a5
    60da:	6a 00                	push   0x0
    60dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60df:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    60e4:	06                   	push   es
    60e5:	57                   	push   di
    60e6:	9a a5 13 fa 60       	call   0x60fa:0x13a5
    60eb:	6a 00                	push   0x0
    60ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60f0:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    60f5:	06                   	push   es
    60f6:	57                   	push   di
    60f7:	9a a5 13 11 61       	call   0x6111:0x13a5
    60fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60ff:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    6104:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6107:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    610a:	6a 00                	push   0x0
    610c:	06                   	push   es
    610d:	57                   	push   di
    610e:	9a 26 13 26 61       	call   0x6126:0x1326
    6113:	2d 01 00             	sub    ax,0x1
    6116:	71 05                	jno    0x611d
    6118:	9a 3e 04 d4 61       	call   0x61d4:0x43e
    611d:	50                   	push   ax
    611e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6121:	06                   	push   es
    6122:	57                   	push   di
    6123:	9a 53 13 31 61       	call   0x6131:0x1353
    6128:	89 c7                	mov    di,ax
    612a:	8e c2                	mov    es,dx
    612c:	06                   	push   es
    612d:	57                   	push   di
    612e:	9a a5 13 60 61       	call   0x6160:0x13a5
    6133:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6136:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    613b:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    6140:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    6145:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    614a:	06                   	push   es
    614b:	57                   	push   di
    614c:	9a bd 7f 6f 61       	call   0x616f:0x7fbd
    6151:	6a 01                	push   0x1
    6153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6156:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    615b:	06                   	push   es
    615c:	57                   	push   di
    615d:	9a a5 13 aa 61       	call   0x61aa:0x13a5
    6162:	bf 3a 60             	mov    di,0x603a
    6165:	0e                   	push   cs
    6166:	57                   	push   di
    6167:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616a:	06                   	push   es
    616b:	57                   	push   di
    616c:	9a 77 38 7e 61       	call   0x617e:0x3877
    6171:	bf 41 60             	mov    di,0x6041
    6174:	0e                   	push   cs
    6175:	57                   	push   di
    6176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6179:	06                   	push   es
    617a:	57                   	push   di
    617b:	9a 02 39 8d 61       	call   0x618d:0x3902
    6180:	bf 42 60             	mov    di,0x6042
    6183:	0e                   	push   cs
    6184:	57                   	push   di
    6185:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6188:	06                   	push   es
    6189:	57                   	push   di
    618a:	9a ef 37 97 61       	call   0x6197:0x37ef
    618f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6192:	06                   	push   es
    6193:	57                   	push   di
    6194:	9a 10 81 14 62       	call   0x6214:0x8110
    6199:	6a 01                	push   0x1
    619b:	6a 00                	push   0x0
    619d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61a0:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    61a5:	06                   	push   es
    61a6:	57                   	push   di
    61a7:	9a 53 13 b5 61       	call   0x61b5:0x1353
    61ac:	89 c7                	mov    di,ax
    61ae:	8e c2                	mov    es,dx
    61b0:	06                   	push   es
    61b1:	57                   	push   di
    61b2:	9a 75 12 ca 61       	call   0x61ca:0x1275
    61b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61ba:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    61bf:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    61c2:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    61c5:	06                   	push   es
    61c6:	57                   	push   di
    61c7:	9a 26 13 f5 61       	call   0x61f5:0x1326
    61cc:	2d 01 00             	sub    ax,0x1
    61cf:	71 05                	jno    0x61d6
    61d1:	9a 3e 04 56 62       	call   0x6256:0x43e
    61d6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    61d9:	31 c0                	xor    ax,ax
    61db:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    61de:	7f 2a                	jg     0x620a
    61e0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    61e3:	eb 03                	jmp    0x61e8
    61e5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    61e8:	6a 01                	push   0x1
    61ea:	ff 76 fe             	push   WORD PTR [bp-0x2]
    61ed:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    61f0:	06                   	push   es
    61f1:	57                   	push   di
    61f2:	9a 53 13 00 62       	call   0x6200:0x1353
    61f7:	89 c7                	mov    di,ax
    61f9:	8e c2                	mov    es,dx
    61fb:	06                   	push   es
    61fc:	57                   	push   di
    61fd:	9a 75 12 16 65       	call   0x6516:0x1275
    6202:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6205:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6208:	75 db                	jne    0x61e5
    620a:	6a 01                	push   0x1
    620c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    620f:	06                   	push   es
    6210:	57                   	push   di
    6211:	9a 8f 8a 34 62       	call   0x6234:0x8a8f
    6216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6219:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    621f:	9b 2e d9 06 4b 60    	fld    DWORD PTR cs:0x604b
    6225:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    622b:	90                   	nop
    622c:	9b                   	fwait
    622d:	6a 01                	push   0x1
    622f:	06                   	push   es
    6230:	57                   	push   di
    6231:	9a 8d 5d 6e 62       	call   0x626e:0x5d8d
    6236:	c9                   	leave
    6237:	ca 08 00             	retf   0x8
    623a:	06                   	push   es
    623b:	56                   	push   si
    623c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    623e:	74 65                	je     0x62a5
    6240:	73 00                	jae    0x6242
    6242:	80 ff ff             	cmp    bh,0xff
    6245:	ff                   	(bad)
    6246:	7f 00                	jg     0x6248
    6248:	00 00                	add    BYTE PTR [bx+si],al
    624a:	00 00                	add    BYTE PTR [bx+si],al
    624c:	00 55 89             	add    BYTE PTR [di-0x77],dl
    624f:	e5 b8                	in     ax,0xb8
    6251:	18 02                	sbb    BYTE PTR [bp+si],al
    6253:	9a 44 04 b7 63       	call   0x63b7:0x444
    6258:	81 ec 18 02          	sub    sp,0x218
    625c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    625f:	6a ff                	push   0xffff
    6261:	bf 3a 62             	mov    di,0x623a
    6264:	0e                   	push   cs
    6265:	57                   	push   di
    6266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6269:	06                   	push   es
    626a:	57                   	push   di
    626b:	9a 90 7d 63 63       	call   0x6363:0x7d90
    6270:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6273:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6278:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    627c:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    6280:	06                   	push   es
    6281:	57                   	push   di
    6282:	9a d2 31 aa 62       	call   0x62aa:0x31d2
    6287:	6a 01                	push   0x1
    6289:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    628d:	06                   	push   es
    628e:	57                   	push   di
    628f:	9a fb 2f 9f 62       	call   0x629f:0x2ffb
    6294:	6a 00                	push   0x0
    6296:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    629a:	06                   	push   es
    629b:	57                   	push   di
    629c:	9a d2 2e 55 63       	call   0x6355:0x2ed2
    62a1:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    62a5:	06                   	push   es
    62a6:	57                   	push   di
    62a7:	9a bf 31 73 63       	call   0x6373:0x31bf
    62ac:	a1 a2 1e             	mov    ax,ds:0x1ea2
    62af:	99                   	cwd
    62b0:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    62b4:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    62b8:	b8 01 00             	mov    ax,0x1
    62bb:	31 d2                	xor    dx,dx
    62bd:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    62c1:	7e 03                	jle    0x62c6
    62c3:	e9 c0 01             	jmp    0x6486
    62c6:	7c 09                	jl     0x62d1
    62c8:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    62cc:	76 03                	jbe    0x62d1
    62ce:	e9 b5 01             	jmp    0x6486
    62d1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    62d4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    62d7:	eb 08                	jmp    0x62e1
    62d9:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    62dd:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    62e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62e4:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    62e9:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    62ed:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    62f1:	31 c0                	xor    ax,ax
    62f3:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    62f6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    62f9:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    62fe:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    6303:	eb 08                	jmp    0x630d
    6305:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    6309:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    630d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6310:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6313:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    6317:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    631b:	c6 86 d4 fe 00       	mov    BYTE PTR [bp-0x12c],0x0
    6320:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6323:	99                   	cwd
    6324:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    6328:	89 96 da fe          	mov    WORD PTR [bp-0x126],dx
    632c:	c6 86 dc fe 00       	mov    BYTE PTR [bp-0x124],0x0
    6331:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6334:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    6337:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    633b:	89 96 e2 fe          	mov    WORD PTR [bp-0x11e],dx
    633f:	c6 86 e4 fe 00       	mov    BYTE PTR [bp-0x11c],0x0
    6344:	8d be d0 fe          	lea    di,[bp-0x130]
    6348:	16                   	push   ss
    6349:	57                   	push   di
    634a:	6a 02                	push   0x2
    634c:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    6350:	06                   	push   es
    6351:	57                   	push   di
    6352:	9a 95 28 33 67       	call   0x6733:0x2895
    6357:	08 c0                	or     al,al
    6359:	75 0a                	jne    0x6365
    635b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    635e:	06                   	push   es
    635f:	57                   	push   di
    6360:	9a f6 10 a9 63       	call   0x63a9:0x10f6
    6365:	bf 3a 62             	mov    di,0x623a
    6368:	0e                   	push   cs
    6369:	57                   	push   di
    636a:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    636e:	06                   	push   es
    636f:	57                   	push   di
    6370:	9a 9b 3b 93 64       	call   0x6493:0x3b9b
    6375:	89 c7                	mov    di,ax
    6377:	8e c2                	mov    es,dx
    6379:	06                   	push   es
    637a:	57                   	push   di
    637b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    637e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6382:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6385:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    6388:	8d be e8 fd          	lea    di,[bp-0x218]
    638c:	16                   	push   ss
    638d:	57                   	push   di
    638e:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    6392:	83 ec 08             	sub    sp,0x8
    6395:	89 e3                	mov    bx,sp
    6397:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    639b:	90                   	nop
    639c:	9b                   	fwait
    639d:	6a 0c                	push   0xc
    639f:	6a 00                	push   0x0
    63a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63a4:	06                   	push   es
    63a5:	57                   	push   di
    63a6:	9a 2d 12 38 64       	call   0x6438:0x122d
    63ab:	8d be f0 fe          	lea    di,[bp-0x110]
    63af:	16                   	push   ss
    63b0:	57                   	push   di
    63b1:	68 ff 00             	push   0xff
    63b4:	9a e7 17 c5 63       	call   0x63c5:0x17e7
    63b9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    63bc:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    63bf:	bf 41 62             	mov    di,0x6241
    63c2:	9a 16 04 d4 63       	call   0x63d4:0x416
    63c7:	50                   	push   ax
    63c8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    63cb:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    63ce:	bf 41 62             	mov    di,0x6241
    63d1:	9a 16 04 fd 63       	call   0x63fd:0x416
    63d6:	50                   	push   ax
    63d7:	8d be f0 fe          	lea    di,[bp-0x110]
    63db:	16                   	push   ss
    63dc:	57                   	push   di
    63dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63e0:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    63e5:	06                   	push   es
    63e6:	57                   	push   di
    63e7:	9a 08 9b 6c 64       	call   0x646c:0x9b08
    63ec:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    63ef:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    63f2:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    63f5:	13 56 f6             	adc    dx,WORD PTR [bp-0xa]
    63f8:	71 05                	jno    0x63ff
    63fa:	9a 3e 04 46 64       	call   0x6446:0x43e
    63ff:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    6402:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    6405:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    6409:	74 03                	je     0x640e
    640b:	e9 f7 fe             	jmp    0x6305
    640e:	83 7e f8 02          	cmp    WORD PTR [bp-0x8],0x2
    6412:	74 03                	je     0x6417
    6414:	e9 ee fe             	jmp    0x6305
    6417:	8d be e8 fd          	lea    di,[bp-0x218]
    641b:	16                   	push   ss
    641c:	57                   	push   di
    641d:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    6421:	83 ec 08             	sub    sp,0x8
    6424:	89 e3                	mov    bx,sp
    6426:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    642a:	90                   	nop
    642b:	9b                   	fwait
    642c:	6a 0c                	push   0xc
    642e:	6a 00                	push   0x0
    6430:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6433:	06                   	push   es
    6434:	57                   	push   di
    6435:	9a 2d 12 b1 64       	call   0x64b1:0x122d
    643a:	8d be f0 fe          	lea    di,[bp-0x110]
    643e:	16                   	push   ss
    643f:	57                   	push   di
    6440:	68 ff 00             	push   0xff
    6443:	9a e7 17 56 64       	call   0x6456:0x17e7
    6448:	6a 03                	push   0x3
    644a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    644d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6450:	bf 41 62             	mov    di,0x6241
    6453:	9a 16 04 e5 64       	call   0x64e5:0x416
    6458:	50                   	push   ax
    6459:	8d be f0 fe          	lea    di,[bp-0x110]
    645d:	16                   	push   ss
    645e:	57                   	push   di
    645f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6462:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    6467:	06                   	push   es
    6468:	57                   	push   di
    6469:	9a 08 9b ad 68       	call   0x68ad:0x9b08
    646e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6471:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6474:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    6478:	74 03                	je     0x647d
    647a:	e9 5c fe             	jmp    0x62d9
    647d:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    6481:	74 03                	je     0x6486
    6483:	e9 53 fe             	jmp    0x62d9
    6486:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6489:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    648e:	06                   	push   es
    648f:	57                   	push   di
    6490:	9a d2 31 26 67       	call   0x6726:0x31d2
    6495:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6498:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    649e:	9b 2e d9 06 49 62    	fld    DWORD PTR cs:0x6249
    64a4:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    64aa:	90                   	nop
    64ab:	9b                   	fwait
    64ac:	06                   	push   es
    64ad:	57                   	push   di
    64ae:	9a 6f 14 c1 64       	call   0x64c1:0x146f
    64b3:	ff 76 08             	push   WORD PTR [bp+0x8]
    64b6:	ff 76 06             	push   WORD PTR [bp+0x6]
    64b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64bc:	06                   	push   es
    64bd:	57                   	push   di
    64be:	9a a2 2b ff 64       	call   0x64ff:0x2ba2
    64c3:	c9                   	leave
    64c4:	ca 06 00             	retf   0x6
    64c7:	06                   	push   es
    64c8:	56                   	push   si
    64c9:	65 6e                	outs   dx,BYTE PTR gs:[si]
    64cb:	74 65                	je     0x6532
    64cd:	73 00                	jae    0x64cf
    64cf:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    64d2:	72 69                	jb     0x653d
    64d4:	6f                   	outs   dx,WORD PTR ds:[si]
    64d5:	64 65 73 00          	fs gs jae 0x64d9
    64d9:	00 00                	add    BYTE PTR [bx+si],al
    64db:	00 55 89             	add    BYTE PTR [di-0x77],dl
    64de:	e5 b8                	in     ax,0xb8
    64e0:	08 00                	or     BYTE PTR [bx+si],al
    64e2:	9a 44 04 20 65       	call   0x6520:0x444
    64e7:	83 ec 08             	sub    sp,0x8
    64ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64ed:	26 c7 85 8a 08 16 00 	mov    WORD PTR es:[di+0x88a],0x16
    64f4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    64f7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    64fa:	06                   	push   es
    64fb:	57                   	push   di
    64fc:	9a 5b 7f 54 65       	call   0x6554:0x7f5b
    6501:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6504:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    6509:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    650c:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    650f:	6a 00                	push   0x0
    6511:	06                   	push   es
    6512:	57                   	push   di
    6513:	9a 26 13 2b 65       	call   0x652b:0x1326
    6518:	2d 01 00             	sub    ax,0x1
    651b:	71 05                	jno    0x6522
    651d:	9a 3e 04 a8 65       	call   0x65a8:0x43e
    6522:	50                   	push   ax
    6523:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6526:	06                   	push   es
    6527:	57                   	push   di
    6528:	9a 53 13 36 65       	call   0x6536:0x1353
    652d:	89 c7                	mov    di,ax
    652f:	8e c2                	mov    es,dx
    6531:	06                   	push   es
    6532:	57                   	push   di
    6533:	9a a5 13 65 65       	call   0x6565:0x13a5
    6538:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    653b:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    6540:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    6545:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    654a:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    654f:	06                   	push   es
    6550:	57                   	push   di
    6551:	9a bd 7f dc 65       	call   0x65dc:0x7fbd
    6556:	6a 01                	push   0x1
    6558:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    655b:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    6560:	06                   	push   es
    6561:	57                   	push   di
    6562:	9a a5 13 76 65       	call   0x6576:0x13a5
    6567:	6a 00                	push   0x0
    6569:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    656c:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    6571:	06                   	push   es
    6572:	57                   	push   di
    6573:	9a a5 13 87 65       	call   0x6587:0x13a5
    6578:	6a 00                	push   0x0
    657a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    657d:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    6582:	06                   	push   es
    6583:	57                   	push   di
    6584:	9a a5 13 9e 65       	call   0x659e:0x13a5
    6589:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    658c:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    6591:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6594:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6597:	6a 00                	push   0x0
    6599:	06                   	push   es
    659a:	57                   	push   di
    659b:	9a 26 13 b3 65       	call   0x65b3:0x1326
    65a0:	2d 01 00             	sub    ax,0x1
    65a3:	71 05                	jno    0x65aa
    65a5:	9a 3e 04 61 66       	call   0x6661:0x43e
    65aa:	50                   	push   ax
    65ab:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    65ae:	06                   	push   es
    65af:	57                   	push   di
    65b0:	9a 53 13 be 65       	call   0x65be:0x1353
    65b5:	89 c7                	mov    di,ax
    65b7:	8e c2                	mov    es,dx
    65b9:	06                   	push   es
    65ba:	57                   	push   di
    65bb:	9a a5 13 ed 65       	call   0x65ed:0x13a5
    65c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65c3:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    65c8:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    65cd:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    65d2:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    65d7:	06                   	push   es
    65d8:	57                   	push   di
    65d9:	9a bd 7f fc 65       	call   0x65fc:0x7fbd
    65de:	6a 01                	push   0x1
    65e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65e3:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    65e8:	06                   	push   es
    65e9:	57                   	push   di
    65ea:	9a a5 13 37 66       	call   0x6637:0x13a5
    65ef:	bf c7 64             	mov    di,0x64c7
    65f2:	0e                   	push   cs
    65f3:	57                   	push   di
    65f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65f7:	06                   	push   es
    65f8:	57                   	push   di
    65f9:	9a 77 38 0b 66       	call   0x660b:0x3877
    65fe:	bf ce 64             	mov    di,0x64ce
    6601:	0e                   	push   cs
    6602:	57                   	push   di
    6603:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6606:	06                   	push   es
    6607:	57                   	push   di
    6608:	9a 02 39 1a 66       	call   0x661a:0x3902
    660d:	bf cf 64             	mov    di,0x64cf
    6610:	0e                   	push   cs
    6611:	57                   	push   di
    6612:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6615:	06                   	push   es
    6616:	57                   	push   di
    6617:	9a ef 37 24 66       	call   0x6624:0x37ef
    661c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    661f:	06                   	push   es
    6620:	57                   	push   di
    6621:	9a 10 81 a1 66       	call   0x66a1:0x8110
    6626:	6a 01                	push   0x1
    6628:	6a 00                	push   0x0
    662a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    662d:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    6632:	06                   	push   es
    6633:	57                   	push   di
    6634:	9a 53 13 42 66       	call   0x6642:0x1353
    6639:	89 c7                	mov    di,ax
    663b:	8e c2                	mov    es,dx
    663d:	06                   	push   es
    663e:	57                   	push   di
    663f:	9a 75 12 57 66       	call   0x6657:0x1275
    6644:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6647:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    664c:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    664f:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6652:	06                   	push   es
    6653:	57                   	push   di
    6654:	9a 26 13 82 66       	call   0x6682:0x1326
    6659:	2d 01 00             	sub    ax,0x1
    665c:	71 05                	jno    0x6663
    665e:	9a 3e 04 f7 66       	call   0x66f7:0x43e
    6663:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6666:	31 c0                	xor    ax,ax
    6668:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    666b:	7f 2a                	jg     0x6697
    666d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6670:	eb 03                	jmp    0x6675
    6672:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    6675:	6a 01                	push   0x1
    6677:	ff 76 fe             	push   WORD PTR [bp-0x2]
    667a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    667d:	06                   	push   es
    667e:	57                   	push   di
    667f:	9a 53 13 8d 66       	call   0x668d:0x1353
    6684:	89 c7                	mov    di,ax
    6686:	8e c2                	mov    es,dx
    6688:	06                   	push   es
    6689:	57                   	push   di
    668a:	9a 75 12 ee 69       	call   0x69ee:0x1275
    668f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6692:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6695:	75 db                	jne    0x6672
    6697:	6a 01                	push   0x1
    6699:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    669c:	06                   	push   es
    669d:	57                   	push   di
    669e:	9a 8f 8a c1 66       	call   0x66c1:0x8a8f
    66a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66a6:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    66ac:	9b 2e d9 06 d8 64    	fld    DWORD PTR cs:0x64d8
    66b2:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    66b8:	90                   	nop
    66b9:	9b                   	fwait
    66ba:	6a 01                	push   0x1
    66bc:	06                   	push   es
    66bd:	57                   	push   di
    66be:	9a 4d 62 0f 67       	call   0x670f:0x624d
    66c3:	c9                   	leave
    66c4:	ca 08 00             	retf   0x8
    66c7:	0f                   	movmskps esp,(bad)
    66c8:	50                   	push   ax
    66c9:	61                   	popa
    66ca:	72 74                	jb     0x6740
    66cc:	73 20                	jae    0x66ee
    66ce:	64 65 20 6d 61       	fs and BYTE PTR gs:[di+0x61],ch
    66d3:	72 63                	jb     0x6738
    66d5:	68 e9 00             	push   0xe9
    66d8:	00 00                	add    BYTE PTR [bx+si],al
    66da:	00 0a                	add    BYTE PTR [bp+si],cl
    66dc:	50                   	push   ax
    66dd:	61                   	popa
    66de:	72 74                	jb     0x6754
    66e0:	4d                   	dec    bp
    66e1:	61                   	popa
    66e2:	72 63                	jb     0x6747
    66e4:	68 65 00             	push   0x65
    66e7:	80 ff ff             	cmp    bh,0xff
    66ea:	ff                   	(bad)
    66eb:	7f 00                	jg     0x66ed
    66ed:	00 55 89             	add    BYTE PTR [di-0x77],dl
    66f0:	e5 b8                	in     ax,0xb8
    66f2:	24 02                	and    al,0x2
    66f4:	9a 44 04 7a 68       	call   0x687a:0x444
    66f9:	81 ec 24 02          	sub    sp,0x224
    66fd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6700:	6a ff                	push   0xffff
    6702:	bf c7 66             	mov    di,0x66c7
    6705:	0e                   	push   cs
    6706:	57                   	push   di
    6707:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    670a:	06                   	push   es
    670b:	57                   	push   di
    670c:	9a 90 7d 29 68       	call   0x6829:0x7d90
    6711:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6714:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6719:	89 be e4 fe          	mov    WORD PTR [bp-0x11c],di
    671d:	8c 86 e6 fe          	mov    WORD PTR [bp-0x11a],es
    6721:	06                   	push   es
    6722:	57                   	push   di
    6723:	9a d2 31 4b 67       	call   0x674b:0x31d2
    6728:	6a 01                	push   0x1
    672a:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    672e:	06                   	push   es
    672f:	57                   	push   di
    6730:	9a fb 2f 40 67       	call   0x6740:0x2ffb
    6735:	6a 00                	push   0x0
    6737:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    673b:	06                   	push   es
    673c:	57                   	push   di
    673d:	9a d2 2e 1b 68       	call   0x681b:0x2ed2
    6742:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    6746:	06                   	push   es
    6747:	57                   	push   di
    6748:	9a bf 31 39 68       	call   0x6839:0x31bf
    674d:	a1 a2 1e             	mov    ax,ds:0x1ea2
    6750:	99                   	cwd
    6751:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    6755:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    6759:	b8 01 00             	mov    ax,0x1
    675c:	31 d2                	xor    dx,dx
    675e:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    6762:	7e 03                	jle    0x6767
    6764:	e9 e6 01             	jmp    0x694d
    6767:	7c 09                	jl     0x6772
    6769:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    676d:	76 03                	jbe    0x6772
    676f:	e9 db 01             	jmp    0x694d
    6772:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6775:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6778:	eb 08                	jmp    0x6782
    677a:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    677e:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    6782:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6785:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    678a:	89 be e0 fe          	mov    WORD PTR [bp-0x120],di
    678e:	8c 86 e2 fe          	mov    WORD PTR [bp-0x11e],es
    6792:	9b 2e d9 06 d7 66    	fld    DWORD PTR cs:0x66d7
    6798:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    679c:	90                   	nop
    679d:	9b                   	fwait
    679e:	a1 4e 01             	mov    ax,ds:0x14e
    67a1:	99                   	cwd
    67a2:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    67a6:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    67aa:	b8 01 00             	mov    ax,0x1
    67ad:	31 d2                	xor    dx,dx
    67af:	3b 96 de fe          	cmp    dx,WORD PTR [bp-0x122]
    67b3:	7e 03                	jle    0x67b8
    67b5:	e9 1d 01             	jmp    0x68d5
    67b8:	7c 09                	jl     0x67c3
    67ba:	3b 86 dc fe          	cmp    ax,WORD PTR [bp-0x124]
    67be:	76 03                	jbe    0x67c3
    67c0:	e9 12 01             	jmp    0x68d5
    67c3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    67c6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    67c9:	eb 08                	jmp    0x67d3
    67cb:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    67cf:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    67d3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    67d6:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    67d9:	89 86 c4 fe          	mov    WORD PTR [bp-0x13c],ax
    67dd:	89 96 c6 fe          	mov    WORD PTR [bp-0x13a],dx
    67e1:	c6 86 c8 fe 00       	mov    BYTE PTR [bp-0x138],0x0
    67e6:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    67e9:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    67ec:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    67f0:	89 96 ce fe          	mov    WORD PTR [bp-0x132],dx
    67f4:	c6 86 d0 fe 00       	mov    BYTE PTR [bp-0x130],0x0
    67f9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    67fc:	99                   	cwd
    67fd:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    6801:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    6805:	c6 86 d8 fe 00       	mov    BYTE PTR [bp-0x128],0x0
    680a:	8d be c4 fe          	lea    di,[bp-0x13c]
    680e:	16                   	push   ss
    680f:	57                   	push   di
    6810:	6a 02                	push   0x2
    6812:	c4 be e0 fe          	les    di,DWORD PTR [bp-0x120]
    6816:	06                   	push   es
    6817:	57                   	push   di
    6818:	9a 95 28 27 6c       	call   0x6c27:0x2895
    681d:	08 c0                	or     al,al
    681f:	75 0a                	jne    0x682b
    6821:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6824:	06                   	push   es
    6825:	57                   	push   di
    6826:	9a f6 10 6c 68       	call   0x686c:0x10f6
    682b:	bf db 66             	mov    di,0x66db
    682e:	0e                   	push   cs
    682f:	57                   	push   di
    6830:	c4 be e0 fe          	les    di,DWORD PTR [bp-0x120]
    6834:	06                   	push   es
    6835:	57                   	push   di
    6836:	9a 9b 3b 5a 69       	call   0x695a:0x3b9b
    683b:	89 c7                	mov    di,ax
    683d:	8e c2                	mov    es,dx
    683f:	06                   	push   es
    6840:	57                   	push   di
    6841:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6844:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6848:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    684c:	90                   	nop
    684d:	9b                   	fwait
    684e:	8d be dc fd          	lea    di,[bp-0x224]
    6852:	16                   	push   ss
    6853:	57                   	push   di
    6854:	ff 76 f6             	push   WORD PTR [bp-0xa]
    6857:	ff 76 f4             	push   WORD PTR [bp-0xc]
    685a:	ff 76 f2             	push   WORD PTR [bp-0xe]
    685d:	ff 76 f0             	push   WORD PTR [bp-0x10]
    6860:	6a 0c                	push   0xc
    6862:	6a 02                	push   0x2
    6864:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6867:	06                   	push   es
    6868:	57                   	push   di
    6869:	9a 2d 12 f3 68       	call   0x68f3:0x122d
    686e:	8d be e8 fe          	lea    di,[bp-0x118]
    6872:	16                   	push   ss
    6873:	57                   	push   di
    6874:	68 ff 00             	push   0xff
    6877:	9a e7 17 88 68       	call   0x6888:0x17e7
    687c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    687f:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    6882:	bf e6 66             	mov    di,0x66e6
    6885:	9a 16 04 97 68       	call   0x6897:0x416
    688a:	50                   	push   ax
    688b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    688e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6891:	bf e6 66             	mov    di,0x66e6
    6894:	9a 16 04 01 69       	call   0x6901:0x416
    6899:	50                   	push   ax
    689a:	8d be e8 fe          	lea    di,[bp-0x118]
    689e:	16                   	push   ss
    689f:	57                   	push   di
    68a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68a3:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    68a8:	06                   	push   es
    68a9:	57                   	push   di
    68aa:	9a 08 9b 33 69       	call   0x6933:0x9b08
    68af:	9b dd 46 e8          	fld    QWORD PTR [bp-0x18]
    68b3:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    68b7:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    68bb:	90                   	nop
    68bc:	9b                   	fwait
    68bd:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    68c0:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    68c3:	3b 96 de fe          	cmp    dx,WORD PTR [bp-0x122]
    68c7:	74 03                	je     0x68cc
    68c9:	e9 ff fe             	jmp    0x67cb
    68cc:	3b 86 dc fe          	cmp    ax,WORD PTR [bp-0x124]
    68d0:	74 03                	je     0x68d5
    68d2:	e9 f6 fe             	jmp    0x67cb
    68d5:	8d be e0 fd          	lea    di,[bp-0x220]
    68d9:	16                   	push   ss
    68da:	57                   	push   di
    68db:	ff 76 ee             	push   WORD PTR [bp-0x12]
    68de:	ff 76 ec             	push   WORD PTR [bp-0x14]
    68e1:	ff 76 ea             	push   WORD PTR [bp-0x16]
    68e4:	ff 76 e8             	push   WORD PTR [bp-0x18]
    68e7:	6a 0c                	push   0xc
    68e9:	6a 00                	push   0x0
    68eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68ee:	06                   	push   es
    68ef:	57                   	push   di
    68f0:	9a 2d 12 78 69       	call   0x6978:0x122d
    68f5:	8d be e8 fe          	lea    di,[bp-0x118]
    68f9:	16                   	push   ss
    68fa:	57                   	push   di
    68fb:	68 ff 00             	push   0xff
    68fe:	9a e7 17 0e 69       	call   0x690e:0x17e7
    6903:	a1 4e 01             	mov    ax,ds:0x14e
    6906:	05 01 00             	add    ax,0x1
    6909:	71 05                	jno    0x6910
    690b:	9a 3e 04 1d 69       	call   0x691d:0x43e
    6910:	50                   	push   ax
    6911:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6914:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6917:	bf e6 66             	mov    di,0x66e6
    691a:	9a 16 04 bd 69       	call   0x69bd:0x416
    691f:	50                   	push   ax
    6920:	8d be e8 fe          	lea    di,[bp-0x118]
    6924:	16                   	push   ss
    6925:	57                   	push   di
    6926:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6929:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    692e:	06                   	push   es
    692f:	57                   	push   di
    6930:	9a 08 9b 80 6d       	call   0x6d80:0x9b08
    6935:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6938:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    693b:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    693f:	74 03                	je     0x6944
    6941:	e9 36 fe             	jmp    0x677a
    6944:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    6948:	74 03                	je     0x694d
    694a:	e9 2d fe             	jmp    0x677a
    694d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6950:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6955:	06                   	push   es
    6956:	57                   	push   di
    6957:	9a d2 31 1a 6c       	call   0x6c1a:0x31d2
    695c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    695f:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    6965:	9b 2e d9 06 d7 66    	fld    DWORD PTR cs:0x66d7
    696b:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    6971:	90                   	nop
    6972:	9b                   	fwait
    6973:	06                   	push   es
    6974:	57                   	push   di
    6975:	9a 6f 14 88 69       	call   0x6988:0x146f
    697a:	ff 76 08             	push   WORD PTR [bp+0x8]
    697d:	ff 76 06             	push   WORD PTR [bp+0x6]
    6980:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6983:	06                   	push   es
    6984:	57                   	push   di
    6985:	9a a2 2b d7 69       	call   0x69d7:0x2ba2
    698a:	c9                   	leave
    698b:	ca 06 00             	retf   0x6
    698e:	0f                   	movmskps esp,(bad)
    698f:	50                   	push   ax
    6990:	61                   	popa
    6991:	72 74                	jb     0x6a07
    6993:	73 20                	jae    0x69b5
    6995:	64 65 20 6d 61       	fs and BYTE PTR gs:[di+0x61],ch
    699a:	72 63                	jb     0x69ff
    699c:	68 e9 00             	push   0xe9
    699f:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    69a2:	72 69                	jb     0x6a0d
    69a4:	6f                   	outs   dx,WORD PTR ds:[si]
    69a5:	64 65 73 00          	fs gs jae 0x69a9
    69a9:	00 00                	add    BYTE PTR [bx+si],al
    69ab:	00 00                	add    BYTE PTR [bx+si],al
    69ad:	00 c8                	add    al,cl
    69af:	42                   	inc    dx
    69b0:	00 00                	add    BYTE PTR [bx+si],al
    69b2:	20 41 55             	and    BYTE PTR [bx+di+0x55],al
    69b5:	89 e5                	mov    bp,sp
    69b7:	b8 08 00             	mov    ax,0x8
    69ba:	9a 44 04 f8 69       	call   0x69f8:0x444
    69bf:	83 ec 08             	sub    sp,0x8
    69c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c5:	26 c7 85 8a 08 1f 00 	mov    WORD PTR es:[di+0x88a],0x1f
    69cc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    69cf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    69d2:	06                   	push   es
    69d3:	57                   	push   di
    69d4:	9a 5b 7f 2c 6a       	call   0x6a2c:0x7f5b
    69d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69dc:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    69e1:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    69e4:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    69e7:	6a 00                	push   0x0
    69e9:	06                   	push   es
    69ea:	57                   	push   di
    69eb:	9a 26 13 03 6a       	call   0x6a03:0x1326
    69f0:	2d 01 00             	sub    ax,0x1
    69f3:	71 05                	jno    0x69fa
    69f5:	9a 3e 04 80 6a       	call   0x6a80:0x43e
    69fa:	50                   	push   ax
    69fb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    69fe:	06                   	push   es
    69ff:	57                   	push   di
    6a00:	9a 53 13 0e 6a       	call   0x6a0e:0x1353
    6a05:	89 c7                	mov    di,ax
    6a07:	8e c2                	mov    es,dx
    6a09:	06                   	push   es
    6a0a:	57                   	push   di
    6a0b:	9a a5 13 3d 6a       	call   0x6a3d:0x13a5
    6a10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a13:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    6a18:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    6a1d:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    6a22:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    6a27:	06                   	push   es
    6a28:	57                   	push   di
    6a29:	9a bd 7f b4 6a       	call   0x6ab4:0x7fbd
    6a2e:	6a 01                	push   0x1
    6a30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a33:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    6a38:	06                   	push   es
    6a39:	57                   	push   di
    6a3a:	9a a5 13 4e 6a       	call   0x6a4e:0x13a5
    6a3f:	6a 00                	push   0x0
    6a41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a44:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    6a49:	06                   	push   es
    6a4a:	57                   	push   di
    6a4b:	9a a5 13 5f 6a       	call   0x6a5f:0x13a5
    6a50:	6a 00                	push   0x0
    6a52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a55:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    6a5a:	06                   	push   es
    6a5b:	57                   	push   di
    6a5c:	9a a5 13 76 6a       	call   0x6a76:0x13a5
    6a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a64:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    6a69:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6a6c:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6a6f:	6a 00                	push   0x0
    6a71:	06                   	push   es
    6a72:	57                   	push   di
    6a73:	9a 26 13 8b 6a       	call   0x6a8b:0x1326
    6a78:	2d 01 00             	sub    ax,0x1
    6a7b:	71 05                	jno    0x6a82
    6a7d:	9a 3e 04 39 6b       	call   0x6b39:0x43e
    6a82:	50                   	push   ax
    6a83:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6a86:	06                   	push   es
    6a87:	57                   	push   di
    6a88:	9a 53 13 96 6a       	call   0x6a96:0x1353
    6a8d:	89 c7                	mov    di,ax
    6a8f:	8e c2                	mov    es,dx
    6a91:	06                   	push   es
    6a92:	57                   	push   di
    6a93:	9a a5 13 c5 6a       	call   0x6ac5:0x13a5
    6a98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a9b:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    6aa0:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    6aa5:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    6aaa:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    6aaf:	06                   	push   es
    6ab0:	57                   	push   di
    6ab1:	9a bd 7f d4 6a       	call   0x6ad4:0x7fbd
    6ab6:	6a 01                	push   0x1
    6ab8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6abb:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    6ac0:	06                   	push   es
    6ac1:	57                   	push   di
    6ac2:	9a a5 13 0f 6b       	call   0x6b0f:0x13a5
    6ac7:	bf 8e 69             	mov    di,0x698e
    6aca:	0e                   	push   cs
    6acb:	57                   	push   di
    6acc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6acf:	06                   	push   es
    6ad0:	57                   	push   di
    6ad1:	9a 77 38 e3 6a       	call   0x6ae3:0x3877
    6ad6:	bf 9e 69             	mov    di,0x699e
    6ad9:	0e                   	push   cs
    6ada:	57                   	push   di
    6adb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ade:	06                   	push   es
    6adf:	57                   	push   di
    6ae0:	9a 02 39 f2 6a       	call   0x6af2:0x3902
    6ae5:	bf 9f 69             	mov    di,0x699f
    6ae8:	0e                   	push   cs
    6ae9:	57                   	push   di
    6aea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aed:	06                   	push   es
    6aee:	57                   	push   di
    6aef:	9a ef 37 fc 6a       	call   0x6afc:0x37ef
    6af4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6af7:	06                   	push   es
    6af8:	57                   	push   di
    6af9:	9a 10 81 79 6b       	call   0x6b79:0x8110
    6afe:	6a 01                	push   0x1
    6b00:	6a 00                	push   0x0
    6b02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b05:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    6b0a:	06                   	push   es
    6b0b:	57                   	push   di
    6b0c:	9a 53 13 1a 6b       	call   0x6b1a:0x1353
    6b11:	89 c7                	mov    di,ax
    6b13:	8e c2                	mov    es,dx
    6b15:	06                   	push   es
    6b16:	57                   	push   di
    6b17:	9a 75 12 2f 6b       	call   0x6b2f:0x1275
    6b1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b1f:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    6b24:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6b27:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6b2a:	06                   	push   es
    6b2b:	57                   	push   di
    6b2c:	9a 26 13 5a 6b       	call   0x6b5a:0x1326
    6b31:	2d 01 00             	sub    ax,0x1
    6b34:	71 05                	jno    0x6b3b
    6b36:	9a 3e 04 eb 6b       	call   0x6beb:0x43e
    6b3b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6b3e:	31 c0                	xor    ax,ax
    6b40:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6b43:	7f 2a                	jg     0x6b6f
    6b45:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6b48:	eb 03                	jmp    0x6b4d
    6b4a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    6b4d:	6a 01                	push   0x1
    6b4f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6b52:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6b55:	06                   	push   es
    6b56:	57                   	push   di
    6b57:	9a 53 13 65 6b       	call   0x6b65:0x1353
    6b5c:	89 c7                	mov    di,ax
    6b5e:	8e c2                	mov    es,dx
    6b60:	06                   	push   es
    6b61:	57                   	push   di
    6b62:	9a 75 12 af 6e       	call   0x6eaf:0x1275
    6b67:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6b6a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    6b6d:	75 db                	jne    0x6b4a
    6b6f:	6a 00                	push   0x0
    6b71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b74:	06                   	push   es
    6b75:	57                   	push   di
    6b76:	9a 8f 8a b5 6b       	call   0x6bb5:0x8a8f
    6b7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b7e:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    6b84:	9b 2e d9 06 a8 69    	fld    DWORD PTR cs:0x69a8
    6b8a:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    6b90:	90                   	nop
    6b91:	9b                   	fwait
    6b92:	9b 2e d9 06 ac 69    	fld    DWORD PTR cs:0x69ac
    6b98:	9b 26 dd 9d 5e 08    	fstp   QWORD PTR es:[di+0x85e]
    6b9e:	90                   	nop
    6b9f:	9b                   	fwait
    6ba0:	9b 2e d9 06 b0 69    	fld    DWORD PTR cs:0x69b0
    6ba6:	9b 26 dd 9d 7e 08    	fstp   QWORD PTR es:[di+0x87e]
    6bac:	90                   	nop
    6bad:	9b                   	fwait
    6bae:	6a 01                	push   0x1
    6bb0:	06                   	push   es
    6bb1:	57                   	push   di
    6bb2:	9a ee 66 03 6c       	call   0x6c03:0x66ee
    6bb7:	c9                   	leave
    6bb8:	ca 08 00             	retf   0x8
    6bbb:	0f                   	movmskps esp,(bad)
    6bbc:	50                   	push   ax
    6bbd:	61                   	popa
    6bbe:	72 74                	jb     0x6c34
    6bc0:	73 20                	jae    0x6be2
    6bc2:	64 65 20 6d 61       	fs and BYTE PTR gs:[di+0x61],ch
    6bc7:	72 63                	jb     0x6c2c
    6bc9:	68 e9 00             	push   0xe9
    6bcc:	00 00                	add    BYTE PTR [bx+si],al
    6bce:	00 0a                	add    BYTE PTR [bp+si],cl
    6bd0:	50                   	push   ax
    6bd1:	61                   	popa
    6bd2:	72 74                	jb     0x6c48
    6bd4:	4d                   	dec    bp
    6bd5:	61                   	popa
    6bd6:	72 63                	jb     0x6c3b
    6bd8:	68 65 00             	push   0x65
    6bdb:	80 ff ff             	cmp    bh,0xff
    6bde:	ff                   	(bad)
    6bdf:	7f 00                	jg     0x6be1
    6be1:	00 55 89             	add    BYTE PTR [di-0x77],dl
    6be4:	e5 b8                	in     ax,0xb8
    6be6:	20 02                	and    BYTE PTR [bp+si],al
    6be8:	9a 44 04 4d 6d       	call   0x6d4d:0x444
    6bed:	81 ec 20 02          	sub    sp,0x220
    6bf1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6bf4:	6a ff                	push   0xffff
    6bf6:	bf bb 6b             	mov    di,0x6bbb
    6bf9:	0e                   	push   cs
    6bfa:	57                   	push   di
    6bfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bfe:	06                   	push   es
    6bff:	57                   	push   di
    6c00:	9a 90 7d fc 6c       	call   0x6cfc:0x7d90
    6c05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c08:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6c0d:	89 be e4 fe          	mov    WORD PTR [bp-0x11c],di
    6c11:	8c 86 e6 fe          	mov    WORD PTR [bp-0x11a],es
    6c15:	06                   	push   es
    6c16:	57                   	push   di
    6c17:	9a d2 31 3f 6c       	call   0x6c3f:0x31d2
    6c1c:	6a 01                	push   0x1
    6c1e:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    6c22:	06                   	push   es
    6c23:	57                   	push   di
    6c24:	9a fb 2f 34 6c       	call   0x6c34:0x2ffb
    6c29:	6a 00                	push   0x0
    6c2b:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    6c2f:	06                   	push   es
    6c30:	57                   	push   di
    6c31:	9a d2 2e ee 6c       	call   0x6cee:0x2ed2
    6c36:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    6c3a:	06                   	push   es
    6c3b:	57                   	push   di
    6c3c:	9a bf 31 0c 6d       	call   0x6d0c:0x31bf
    6c41:	a1 a2 1e             	mov    ax,ds:0x1ea2
    6c44:	99                   	cwd
    6c45:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    6c49:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    6c4d:	b8 01 00             	mov    ax,0x1
    6c50:	31 d2                	xor    dx,dx
    6c52:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    6c56:	7e 03                	jle    0x6c5b
    6c58:	e9 b3 01             	jmp    0x6e0e
    6c5b:	7c 09                	jl     0x6c66
    6c5d:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    6c61:	76 03                	jbe    0x6c66
    6c63:	e9 a8 01             	jmp    0x6e0e
    6c66:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6c69:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6c6c:	eb 08                	jmp    0x6c76
    6c6e:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    6c72:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    6c76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c79:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6c7e:	89 be e0 fe          	mov    WORD PTR [bp-0x120],di
    6c82:	8c 86 e2 fe          	mov    WORD PTR [bp-0x11e],es
    6c86:	9b 2e d9 06 cb 6b    	fld    DWORD PTR cs:0x6bcb
    6c8c:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    6c90:	90                   	nop
    6c91:	9b                   	fwait
    6c92:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    6c97:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    6c9c:	eb 08                	jmp    0x6ca6
    6c9e:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    6ca2:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    6ca6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6ca9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6cac:	89 86 c8 fe          	mov    WORD PTR [bp-0x138],ax
    6cb0:	89 96 ca fe          	mov    WORD PTR [bp-0x136],dx
    6cb4:	c6 86 cc fe 00       	mov    BYTE PTR [bp-0x134],0x0
    6cb9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6cbc:	99                   	cwd
    6cbd:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    6cc1:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    6cc5:	c6 86 d4 fe 00       	mov    BYTE PTR [bp-0x12c],0x0
    6cca:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6ccd:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    6cd0:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    6cd4:	89 96 da fe          	mov    WORD PTR [bp-0x126],dx
    6cd8:	c6 86 dc fe 00       	mov    BYTE PTR [bp-0x124],0x0
    6cdd:	8d be c8 fe          	lea    di,[bp-0x138]
    6ce1:	16                   	push   ss
    6ce2:	57                   	push   di
    6ce3:	6a 02                	push   0x2
    6ce5:	c4 be e0 fe          	les    di,DWORD PTR [bp-0x120]
    6ce9:	06                   	push   es
    6cea:	57                   	push   di
    6ceb:	9a 95 28 e3 70       	call   0x70e3:0x2895
    6cf0:	08 c0                	or     al,al
    6cf2:	75 0a                	jne    0x6cfe
    6cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cf7:	06                   	push   es
    6cf8:	57                   	push   di
    6cf9:	9a f6 10 3f 6d       	call   0x6d3f:0x10f6
    6cfe:	bf cf 6b             	mov    di,0x6bcf
    6d01:	0e                   	push   cs
    6d02:	57                   	push   di
    6d03:	c4 be e0 fe          	les    di,DWORD PTR [bp-0x120]
    6d07:	06                   	push   es
    6d08:	57                   	push   di
    6d09:	9a 9b 3b 1b 6e       	call   0x6e1b:0x3b9b
    6d0e:	89 c7                	mov    di,ax
    6d10:	8e c2                	mov    es,dx
    6d12:	06                   	push   es
    6d13:	57                   	push   di
    6d14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d17:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6d1b:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    6d1f:	90                   	nop
    6d20:	9b                   	fwait
    6d21:	8d be e0 fd          	lea    di,[bp-0x220]
    6d25:	16                   	push   ss
    6d26:	57                   	push   di
    6d27:	ff 76 f6             	push   WORD PTR [bp-0xa]
    6d2a:	ff 76 f4             	push   WORD PTR [bp-0xc]
    6d2d:	ff 76 f2             	push   WORD PTR [bp-0xe]
    6d30:	ff 76 f0             	push   WORD PTR [bp-0x10]
    6d33:	6a 0c                	push   0xc
    6d35:	6a 02                	push   0x2
    6d37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d3a:	06                   	push   es
    6d3b:	57                   	push   di
    6d3c:	9a 2d 12 c0 6d       	call   0x6dc0:0x122d
    6d41:	8d be e8 fe          	lea    di,[bp-0x118]
    6d45:	16                   	push   ss
    6d46:	57                   	push   di
    6d47:	68 ff 00             	push   0xff
    6d4a:	9a e7 17 5b 6d       	call   0x6d5b:0x17e7
    6d4f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6d52:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    6d55:	bf da 6b             	mov    di,0x6bda
    6d58:	9a 16 04 6a 6d       	call   0x6d6a:0x416
    6d5d:	50                   	push   ax
    6d5e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6d61:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6d64:	bf da 6b             	mov    di,0x6bda
    6d67:	9a 16 04 ce 6d       	call   0x6dce:0x416
    6d6c:	50                   	push   ax
    6d6d:	8d be e8 fe          	lea    di,[bp-0x118]
    6d71:	16                   	push   ss
    6d72:	57                   	push   di
    6d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d76:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    6d7b:	06                   	push   es
    6d7c:	57                   	push   di
    6d7d:	9a 08 9b f4 6d       	call   0x6df4:0x9b08
    6d82:	9b dd 46 e8          	fld    QWORD PTR [bp-0x18]
    6d86:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    6d8a:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    6d8e:	90                   	nop
    6d8f:	9b                   	fwait
    6d90:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    6d94:	74 03                	je     0x6d99
    6d96:	e9 05 ff             	jmp    0x6c9e
    6d99:	83 7e f8 02          	cmp    WORD PTR [bp-0x8],0x2
    6d9d:	74 03                	je     0x6da2
    6d9f:	e9 fc fe             	jmp    0x6c9e
    6da2:	8d be e0 fd          	lea    di,[bp-0x220]
    6da6:	16                   	push   ss
    6da7:	57                   	push   di
    6da8:	ff 76 ee             	push   WORD PTR [bp-0x12]
    6dab:	ff 76 ec             	push   WORD PTR [bp-0x14]
    6dae:	ff 76 ea             	push   WORD PTR [bp-0x16]
    6db1:	ff 76 e8             	push   WORD PTR [bp-0x18]
    6db4:	6a 0c                	push   0xc
    6db6:	6a 00                	push   0x0
    6db8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dbb:	06                   	push   es
    6dbc:	57                   	push   di
    6dbd:	9a 2d 12 39 6e       	call   0x6e39:0x122d
    6dc2:	8d be e8 fe          	lea    di,[bp-0x118]
    6dc6:	16                   	push   ss
    6dc7:	57                   	push   di
    6dc8:	68 ff 00             	push   0xff
    6dcb:	9a e7 17 de 6d       	call   0x6dde:0x17e7
    6dd0:	6a 03                	push   0x3
    6dd2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6dd5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6dd8:	bf da 6b             	mov    di,0x6bda
    6ddb:	9a 16 04 7e 6e       	call   0x6e7e:0x416
    6de0:	50                   	push   ax
    6de1:	8d be e8 fe          	lea    di,[bp-0x118]
    6de5:	16                   	push   ss
    6de6:	57                   	push   di
    6de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dea:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    6def:	06                   	push   es
    6df0:	57                   	push   di
    6df1:	9a 08 9b 40 72       	call   0x7240:0x9b08
    6df6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6df9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6dfc:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    6e00:	74 03                	je     0x6e05
    6e02:	e9 69 fe             	jmp    0x6c6e
    6e05:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    6e09:	74 03                	je     0x6e0e
    6e0b:	e9 60 fe             	jmp    0x6c6e
    6e0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e11:	26 c4 bd e4 02       	les    di,DWORD PTR es:[di+0x2e4]
    6e16:	06                   	push   es
    6e17:	57                   	push   di
    6e18:	9a d2 31 d6 70       	call   0x70d6:0x31d2
    6e1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e20:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    6e26:	9b 2e d9 06 cb 6b    	fld    DWORD PTR cs:0x6bcb
    6e2c:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    6e32:	90                   	nop
    6e33:	9b                   	fwait
    6e34:	06                   	push   es
    6e35:	57                   	push   di
    6e36:	9a 6f 14 49 6e       	call   0x6e49:0x146f
    6e3b:	ff 76 08             	push   WORD PTR [bp+0x8]
    6e3e:	ff 76 06             	push   WORD PTR [bp+0x6]
    6e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e44:	06                   	push   es
    6e45:	57                   	push   di
    6e46:	9a a2 2b 98 6e       	call   0x6e98:0x2ba2
    6e4b:	c9                   	leave
    6e4c:	ca 06 00             	retf   0x6
    6e4f:	0f                   	movmskps esp,(bad)
    6e50:	50                   	push   ax
    6e51:	61                   	popa
    6e52:	72 74                	jb     0x6ec8
    6e54:	73 20                	jae    0x6e76
    6e56:	64 65 20 6d 61       	fs and BYTE PTR gs:[di+0x61],ch
    6e5b:	72 63                	jb     0x6ec0
    6e5d:	68 e9 00             	push   0xe9
    6e60:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    6e63:	72 69                	jb     0x6ece
    6e65:	6f                   	outs   dx,WORD PTR ds:[si]
    6e66:	64 65 73 00          	fs gs jae 0x6e6a
    6e6a:	00 00                	add    BYTE PTR [bx+si],al
    6e6c:	00 00                	add    BYTE PTR [bx+si],al
    6e6e:	00 c8                	add    al,cl
    6e70:	42                   	inc    dx
    6e71:	00 00                	add    BYTE PTR [bx+si],al
    6e73:	20 41 55             	and    BYTE PTR [bx+di+0x55],al
    6e76:	89 e5                	mov    bp,sp
    6e78:	b8 08 00             	mov    ax,0x8
    6e7b:	9a 44 04 b9 6e       	call   0x6eb9:0x444
    6e80:	83 ec 08             	sub    sp,0x8
    6e83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e86:	26 c7 85 8a 08 20 00 	mov    WORD PTR es:[di+0x88a],0x20
    6e8d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6e90:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6e93:	06                   	push   es
    6e94:	57                   	push   di
    6e95:	9a 5b 7f ed 6e       	call   0x6eed:0x7f5b
    6e9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e9d:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    6ea2:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6ea5:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6ea8:	6a 00                	push   0x0
    6eaa:	06                   	push   es
    6eab:	57                   	push   di
    6eac:	9a 26 13 c4 6e       	call   0x6ec4:0x1326
    6eb1:	2d 01 00             	sub    ax,0x1
    6eb4:	71 05                	jno    0x6ebb
    6eb6:	9a 3e 04 41 6f       	call   0x6f41:0x43e
    6ebb:	50                   	push   ax
    6ebc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6ebf:	06                   	push   es
    6ec0:	57                   	push   di
    6ec1:	9a 53 13 cf 6e       	call   0x6ecf:0x1353
    6ec6:	89 c7                	mov    di,ax
    6ec8:	8e c2                	mov    es,dx
    6eca:	06                   	push   es
    6ecb:	57                   	push   di
    6ecc:	9a a5 13 fe 6e       	call   0x6efe:0x13a5
    6ed1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ed4:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    6ed9:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    6ede:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    6ee3:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    6ee8:	06                   	push   es
    6ee9:	57                   	push   di
    6eea:	9a bd 7f 75 6f       	call   0x6f75:0x7fbd
    6eef:	6a 01                	push   0x1
    6ef1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ef4:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    6ef9:	06                   	push   es
    6efa:	57                   	push   di
    6efb:	9a a5 13 0f 6f       	call   0x6f0f:0x13a5
    6f00:	6a 00                	push   0x0
    6f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f05:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    6f0a:	06                   	push   es
    6f0b:	57                   	push   di
    6f0c:	9a a5 13 20 6f       	call   0x6f20:0x13a5
    6f11:	6a 00                	push   0x0
    6f13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f16:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    6f1b:	06                   	push   es
    6f1c:	57                   	push   di
    6f1d:	9a a5 13 37 6f       	call   0x6f37:0x13a5
    6f22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f25:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    6f2a:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6f2d:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6f30:	6a 00                	push   0x0
    6f32:	06                   	push   es
    6f33:	57                   	push   di
    6f34:	9a 26 13 4c 6f       	call   0x6f4c:0x1326
    6f39:	2d 01 00             	sub    ax,0x1
    6f3c:	71 05                	jno    0x6f43
    6f3e:	9a 3e 04 fa 6f       	call   0x6ffa:0x43e
    6f43:	50                   	push   ax
    6f44:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6f47:	06                   	push   es
    6f48:	57                   	push   di
    6f49:	9a 53 13 57 6f       	call   0x6f57:0x1353
    6f4e:	89 c7                	mov    di,ax
    6f50:	8e c2                	mov    es,dx
    6f52:	06                   	push   es
    6f53:	57                   	push   di
    6f54:	9a a5 13 86 6f       	call   0x6f86:0x13a5
    6f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f5c:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    6f61:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    6f66:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    6f6b:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    6f70:	06                   	push   es
    6f71:	57                   	push   di
    6f72:	9a bd 7f 95 6f       	call   0x6f95:0x7fbd
    6f77:	6a 01                	push   0x1
    6f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f7c:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    6f81:	06                   	push   es
    6f82:	57                   	push   di
    6f83:	9a a5 13 d0 6f       	call   0x6fd0:0x13a5
    6f88:	bf 4f 6e             	mov    di,0x6e4f
    6f8b:	0e                   	push   cs
    6f8c:	57                   	push   di
    6f8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f90:	06                   	push   es
    6f91:	57                   	push   di
    6f92:	9a 77 38 a4 6f       	call   0x6fa4:0x3877
    6f97:	bf 5f 6e             	mov    di,0x6e5f
    6f9a:	0e                   	push   cs
    6f9b:	57                   	push   di
    6f9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f9f:	06                   	push   es
    6fa0:	57                   	push   di
    6fa1:	9a 02 39 b3 6f       	call   0x6fb3:0x3902
    6fa6:	bf 60 6e             	mov    di,0x6e60
    6fa9:	0e                   	push   cs
    6faa:	57                   	push   di
    6fab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fae:	06                   	push   es
    6faf:	57                   	push   di
    6fb0:	9a ef 37 bd 6f       	call   0x6fbd:0x37ef
    6fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fb8:	06                   	push   es
    6fb9:	57                   	push   di
    6fba:	9a 10 81 3a 70       	call   0x703a:0x8110
    6fbf:	6a 01                	push   0x1
    6fc1:	6a 00                	push   0x0
    6fc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fc6:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    6fcb:	06                   	push   es
    6fcc:	57                   	push   di
    6fcd:	9a 53 13 db 6f       	call   0x6fdb:0x1353
    6fd2:	89 c7                	mov    di,ax
    6fd4:	8e c2                	mov    es,dx
    6fd6:	06                   	push   es
    6fd7:	57                   	push   di
    6fd8:	9a 75 12 f0 6f       	call   0x6ff0:0x1275
    6fdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fe0:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    6fe5:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6fe8:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6feb:	06                   	push   es
    6fec:	57                   	push   di
    6fed:	9a 26 13 1b 70       	call   0x701b:0x1326
    6ff2:	2d 01 00             	sub    ax,0x1
    6ff5:	71 05                	jno    0x6ffc
    6ff7:	9a 3e 04 a8 70       	call   0x70a8:0x43e
    6ffc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6fff:	31 c0                	xor    ax,ax
    7001:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7004:	7f 2a                	jg     0x7030
    7006:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7009:	eb 03                	jmp    0x700e
    700b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    700e:	6a 01                	push   0x1
    7010:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7013:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    7016:	06                   	push   es
    7017:	57                   	push   di
    7018:	9a 53 13 26 70       	call   0x7026:0x1353
    701d:	89 c7                	mov    di,ax
    701f:	8e c2                	mov    es,dx
    7021:	06                   	push   es
    7022:	57                   	push   di
    7023:	9a 75 12 ea 72       	call   0x72ea:0x1275
    7028:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    702b:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    702e:	75 db                	jne    0x700b
    7030:	6a 00                	push   0x0
    7032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7035:	06                   	push   es
    7036:	57                   	push   di
    7037:	9a 8f 8a 76 70       	call   0x7076:0x8a8f
    703c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    703f:	26 c6 85 5d 08 00    	mov    BYTE PTR es:[di+0x85d],0x0
    7045:	9b 2e d9 06 69 6e    	fld    DWORD PTR cs:0x6e69
    704b:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    7051:	90                   	nop
    7052:	9b                   	fwait
    7053:	9b 2e d9 06 6d 6e    	fld    DWORD PTR cs:0x6e6d
    7059:	9b 26 dd 9d 5e 08    	fstp   QWORD PTR es:[di+0x85e]
    705f:	90                   	nop
    7060:	9b                   	fwait
    7061:	9b 2e d9 06 71 6e    	fld    DWORD PTR cs:0x6e71
    7067:	9b 26 dd 9d 7e 08    	fstp   QWORD PTR es:[di+0x87e]
    706d:	90                   	nop
    706e:	9b                   	fwait
    706f:	6a 01                	push   0x1
    7071:	06                   	push   es
    7072:	57                   	push   di
    7073:	9a e2 6b bf 70       	call   0x70bf:0x6be2
    7078:	c9                   	leave
    7079:	ca 08 00             	retf   0x8
    707c:	0e                   	push   cs
    707d:	52                   	push   dx
    707e:	e9 73 75             	jmp    0xe5f4
    7081:	6c                   	ins    BYTE PTR es:[di],dx
    7082:	74 61                	je     0x70e5
    7084:	74 73                	je     0x70f9
    7086:	20 6e 65             	and    BYTE PTR [bp+0x65],ch
    7089:	74 73                	je     0x70fe
    708b:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    708e:	73 75                	jae    0x7105
    7090:	6c                   	ins    BYTE PTR es:[di],dx
    7091:	74 61                	je     0x70f4
    7093:	74 4e                	je     0x70e3
    7095:	65 74 00             	gs je  0x7098
    7098:	80 ff ff             	cmp    bh,0xff
    709b:	ff                   	(bad)
    709c:	7f 00                	jg     0x709e
    709e:	00 55 89             	add    BYTE PTR [di-0x77],dl
    70a1:	e5 b8                	in     ax,0xb8
    70a3:	1c 02                	sbb    al,0x2
    70a5:	9a 44 04 0d 72       	call   0x720d:0x444
    70aa:	81 ec 1c 02          	sub    sp,0x21c
    70ae:	6a ff                	push   0xffff
    70b0:	6a ff                	push   0xffff
    70b2:	bf 7c 70             	mov    di,0x707c
    70b5:	0e                   	push   cs
    70b6:	57                   	push   di
    70b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70ba:	06                   	push   es
    70bb:	57                   	push   di
    70bc:	9a 90 7d bc 71       	call   0x71bc:0x7d90
    70c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70c4:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    70c9:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    70cd:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    70d1:	06                   	push   es
    70d2:	57                   	push   di
    70d3:	9a d2 31 fb 70       	call   0x70fb:0x31d2
    70d8:	6a 01                	push   0x1
    70da:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    70de:	06                   	push   es
    70df:	57                   	push   di
    70e0:	9a fb 2f f0 70       	call   0x70f0:0x2ffb
    70e5:	6a 00                	push   0x0
    70e7:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    70eb:	06                   	push   es
    70ec:	57                   	push   di
    70ed:	9a d2 2e ae 71       	call   0x71ae:0x2ed2
    70f2:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    70f6:	06                   	push   es
    70f7:	57                   	push   di
    70f8:	9a bf 31 cc 71       	call   0x71cc:0x31bf
    70fd:	a1 a2 1e             	mov    ax,ds:0x1ea2
    7100:	99                   	cwd
    7101:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    7105:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    7109:	b8 01 00             	mov    ax,0x1
    710c:	31 d2                	xor    dx,dx
    710e:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    7112:	7e 03                	jle    0x7117
    7114:	e9 5b 01             	jmp    0x7272
    7117:	7c 09                	jl     0x7122
    7119:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    711d:	76 03                	jbe    0x7122
    711f:	e9 50 01             	jmp    0x7272
    7122:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7125:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7128:	eb 08                	jmp    0x7132
    712a:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    712e:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    7132:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7135:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    713a:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    713e:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    7142:	a1 4e 01             	mov    ax,ds:0x14e
    7145:	99                   	cwd
    7146:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    714a:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    714e:	b8 01 00             	mov    ax,0x1
    7151:	31 d2                	xor    dx,dx
    7153:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    7157:	7e 03                	jle    0x715c
    7159:	e9 fe 00             	jmp    0x725a
    715c:	7c 09                	jl     0x7167
    715e:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    7162:	76 03                	jbe    0x7167
    7164:	e9 f3 00             	jmp    0x725a
    7167:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    716a:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    716d:	eb 08                	jmp    0x7177
    716f:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    7173:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    7177:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    717a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    717d:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    7181:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    7185:	c6 86 d8 fe 00       	mov    BYTE PTR [bp-0x128],0x0
    718a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    718d:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7190:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    7194:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    7198:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    719d:	8d be d4 fe          	lea    di,[bp-0x12c]
    71a1:	16                   	push   ss
    71a2:	57                   	push   di
    71a3:	6a 01                	push   0x1
    71a5:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    71a9:	06                   	push   es
    71aa:	57                   	push   di
    71ab:	9a 95 28 a0 74       	call   0x74a0:0x2895
    71b0:	08 c0                	or     al,al
    71b2:	75 0a                	jne    0x71be
    71b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71b7:	06                   	push   es
    71b8:	57                   	push   di
    71b9:	9a f6 10 ff 71       	call   0x71ff:0x10f6
    71be:	bf 8b 70             	mov    di,0x708b
    71c1:	0e                   	push   cs
    71c2:	57                   	push   di
    71c3:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    71c7:	06                   	push   es
    71c8:	57                   	push   di
    71c9:	9a 9b 3b 7f 72       	call   0x727f:0x3b9b
    71ce:	89 c7                	mov    di,ax
    71d0:	8e c2                	mov    es,dx
    71d2:	06                   	push   es
    71d3:	57                   	push   di
    71d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    71d7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    71db:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    71df:	90                   	nop
    71e0:	9b                   	fwait
    71e1:	8d be e4 fd          	lea    di,[bp-0x21c]
    71e5:	16                   	push   ss
    71e6:	57                   	push   di
    71e7:	ff 76 f6             	push   WORD PTR [bp-0xa]
    71ea:	ff 76 f4             	push   WORD PTR [bp-0xc]
    71ed:	ff 76 f2             	push   WORD PTR [bp-0xe]
    71f0:	ff 76 f0             	push   WORD PTR [bp-0x10]
    71f3:	6a 0c                	push   0xc
    71f5:	6a 02                	push   0x2
    71f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71fa:	06                   	push   es
    71fb:	57                   	push   di
    71fc:	9a 2d 12 89 72       	call   0x7289:0x122d
    7201:	8d be f0 fe          	lea    di,[bp-0x110]
    7205:	16                   	push   ss
    7206:	57                   	push   di
    7207:	68 ff 00             	push   0xff
    720a:	9a e7 17 1b 72       	call   0x721b:0x17e7
    720f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7212:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7215:	bf 97 70             	mov    di,0x7097
    7218:	9a 16 04 2a 72       	call   0x722a:0x416
    721d:	50                   	push   ax
    721e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7221:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7224:	bf 97 70             	mov    di,0x7097
    7227:	9a 16 04 bf 72       	call   0x72bf:0x416
    722c:	50                   	push   ax
    722d:	8d be f0 fe          	lea    di,[bp-0x110]
    7231:	16                   	push   ss
    7232:	57                   	push   di
    7233:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7236:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    723b:	06                   	push   es
    723c:	57                   	push   di
    723d:	9a 08 9b 51 76       	call   0x7651:0x9b08
    7242:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7245:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7248:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    724c:	74 03                	je     0x7251
    724e:	e9 1e ff             	jmp    0x716f
    7251:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    7255:	74 03                	je     0x725a
    7257:	e9 15 ff             	jmp    0x716f
    725a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    725d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7260:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    7264:	74 03                	je     0x7269
    7266:	e9 c1 fe             	jmp    0x712a
    7269:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    726d:	74 03                	je     0x7272
    726f:	e9 b8 fe             	jmp    0x712a
    7272:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7275:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    727a:	06                   	push   es
    727b:	57                   	push   di
    727c:	9a d2 31 93 74       	call   0x7493:0x31d2
    7281:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7284:	06                   	push   es
    7285:	57                   	push   di
    7286:	9a 6f 14 99 72       	call   0x7299:0x146f
    728b:	ff 76 08             	push   WORD PTR [bp+0x8]
    728e:	ff 76 06             	push   WORD PTR [bp+0x6]
    7291:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7294:	06                   	push   es
    7295:	57                   	push   di
    7296:	9a a2 2b d9 72       	call   0x72d9:0x2ba2
    729b:	c9                   	leave
    729c:	ca 04 00             	retf   0x4
    729f:	0c 52                	or     al,0x52
    72a1:	e9 73 75             	jmp    0xe817
    72a4:	6c                   	ins    BYTE PTR es:[di],dx
    72a5:	74 61                	je     0x7308
    72a7:	74 20                	je     0x72c9
    72a9:	6e                   	outs   dx,BYTE PTR ds:[si]
    72aa:	65 74 00             	gs je  0x72ad
    72ad:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    72b0:	72 69                	jb     0x731b
    72b2:	6f                   	outs   dx,WORD PTR ds:[si]
    72b3:	64 65 73 55          	fs gs jae 0x730c
    72b7:	89 e5                	mov    bp,sp
    72b9:	b8 08 00             	mov    ax,0x8
    72bc:	9a 44 04 2d 73       	call   0x732d:0x444
    72c1:	83 ec 08             	sub    sp,0x8
    72c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72c7:	26 c7 85 8a 08 29 00 	mov    WORD PTR es:[di+0x88a],0x29
    72ce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    72d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    72d4:	06                   	push   es
    72d5:	57                   	push   di
    72d6:	9a 5b 7f 61 73       	call   0x7361:0x7f5b
    72db:	6a 00                	push   0x0
    72dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72e0:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    72e5:	06                   	push   es
    72e6:	57                   	push   di
    72e7:	9a a5 13 fb 72       	call   0x72fb:0x13a5
    72ec:	6a 00                	push   0x0
    72ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72f1:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    72f6:	06                   	push   es
    72f7:	57                   	push   di
    72f8:	9a a5 13 0c 73       	call   0x730c:0x13a5
    72fd:	6a 00                	push   0x0
    72ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7302:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    7307:	06                   	push   es
    7308:	57                   	push   di
    7309:	9a a5 13 23 73       	call   0x7323:0x13a5
    730e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7311:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    7316:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    7319:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    731c:	6a 00                	push   0x0
    731e:	06                   	push   es
    731f:	57                   	push   di
    7320:	9a 26 13 38 73       	call   0x7338:0x1326
    7325:	2d 01 00             	sub    ax,0x1
    7328:	71 05                	jno    0x732f
    732a:	9a 3e 04 c8 73       	call   0x73c8:0x43e
    732f:	50                   	push   ax
    7330:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    7333:	06                   	push   es
    7334:	57                   	push   di
    7335:	9a 53 13 43 73       	call   0x7343:0x1353
    733a:	89 c7                	mov    di,ax
    733c:	8e c2                	mov    es,dx
    733e:	06                   	push   es
    733f:	57                   	push   di
    7340:	9a a5 13 72 73       	call   0x7372:0x13a5
    7345:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7348:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    734d:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    7352:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    7357:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    735c:	06                   	push   es
    735d:	57                   	push   di
    735e:	9a bd 7f 81 73       	call   0x7381:0x7fbd
    7363:	6a 01                	push   0x1
    7365:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7368:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    736d:	06                   	push   es
    736e:	57                   	push   di
    736f:	9a a5 13 be 73       	call   0x73be:0x13a5
    7374:	bf 9f 72             	mov    di,0x729f
    7377:	0e                   	push   cs
    7378:	57                   	push   di
    7379:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    737c:	06                   	push   es
    737d:	57                   	push   di
    737e:	9a 77 38 90 73       	call   0x7390:0x3877
    7383:	bf ac 72             	mov    di,0x72ac
    7386:	0e                   	push   cs
    7387:	57                   	push   di
    7388:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    738b:	06                   	push   es
    738c:	57                   	push   di
    738d:	9a 02 39 9f 73       	call   0x739f:0x3902
    7392:	bf ad 72             	mov    di,0x72ad
    7395:	0e                   	push   cs
    7396:	57                   	push   di
    7397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    739a:	06                   	push   es
    739b:	57                   	push   di
    739c:	9a ef 37 a9 73       	call   0x73a9:0x37ef
    73a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73a4:	06                   	push   es
    73a5:	57                   	push   di
    73a6:	9a 10 81 08 74       	call   0x7408:0x8110
    73ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73ae:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    73b3:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    73b6:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    73b9:	06                   	push   es
    73ba:	57                   	push   di
    73bb:	9a 26 13 e9 73       	call   0x73e9:0x1326
    73c0:	2d 01 00             	sub    ax,0x1
    73c3:	71 05                	jno    0x73ca
    73c5:	9a 3e 04 65 74       	call   0x7465:0x43e
    73ca:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    73cd:	31 c0                	xor    ax,ax
    73cf:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    73d2:	7f 2a                	jg     0x73fe
    73d4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    73d7:	eb 03                	jmp    0x73dc
    73d9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    73dc:	6a 01                	push   0x1
    73de:	ff 76 fe             	push   WORD PTR [bp-0x2]
    73e1:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    73e4:	06                   	push   es
    73e5:	57                   	push   di
    73e6:	9a 53 13 f4 73       	call   0x73f4:0x1353
    73eb:	89 c7                	mov    di,ax
    73ed:	8e c2                	mov    es,dx
    73ef:	06                   	push   es
    73f0:	57                   	push   di
    73f1:	9a 75 12 01 77       	call   0x7701:0x1275
    73f6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    73f9:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    73fc:	75 db                	jne    0x73d9
    73fe:	6a 01                	push   0x1
    7400:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7403:	06                   	push   es
    7404:	57                   	push   di
    7405:	9a 8f 8a 18 74       	call   0x7418:0x8a8f
    740a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    740d:	26 c6 85 5d 08 01    	mov    BYTE PTR es:[di+0x85d],0x1
    7413:	06                   	push   es
    7414:	57                   	push   di
    7415:	9a 9f 70 7c 74       	call   0x747c:0x709f
    741a:	c9                   	leave
    741b:	ca 08 00             	retf   0x8
    741e:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
    7421:	73 73                	jae    0x7496
    7423:	6f                   	outs   dx,WORD PTR ds:[si]
    7424:	75 72                	jne    0x7498
    7426:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    7429:	20 70 72             	and    BYTE PTR [bx+si+0x72],dh
    742c:	6f                   	outs   dx,WORD PTR ds:[si]
    742d:	70 72                	jo     0x74a1
    742f:	65 73 0d             	gs jae 0x743f
    7432:	43                   	inc    bx
    7433:	61                   	popa
    7434:	70 69                	jo     0x749f
    7436:	74 61                	je     0x7499
    7438:	6c                   	ins    BYTE PTR es:[di],dx
    7439:	53                   	push   bx
    743a:	6f                   	outs   dx,WORD PTR ds:[si]
    743b:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    743e:	6c                   	ins    BYTE PTR es:[di],dx
    743f:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    7442:	73 65                	jae    0x74a9
    7444:	72 76                	jb     0x74bc
    7446:	65 73 0b             	gs jae 0x7454
    7449:	52                   	push   dx
    744a:	65 73 75             	gs jae 0x74c2
    744d:	6c                   	ins    BYTE PTR es:[di],dx
    744e:	74 61                	je     0x74b1
    7450:	74 4e                	je     0x74a0
    7452:	65 74 00             	gs je  0x7455
    7455:	80 ff ff             	cmp    bh,0xff
    7458:	ff                   	(bad)
    7459:	7f 00                	jg     0x745b
    745b:	00 55 89             	add    BYTE PTR [di-0x77],dl
    745e:	e5 b8                	in     ax,0xb8
    7460:	1c 02                	sbb    al,0x2
    7462:	9a 44 04 1e 76       	call   0x761e:0x444
    7467:	81 ec 1c 02          	sub    sp,0x21c
    746b:	6a ff                	push   0xffff
    746d:	6a ff                	push   0xffff
    746f:	bf 1e 74             	mov    di,0x741e
    7472:	0e                   	push   cs
    7473:	57                   	push   di
    7474:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7477:	06                   	push   es
    7478:	57                   	push   di
    7479:	9a 90 7d 79 75       	call   0x7579:0x7d90
    747e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7481:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    7486:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    748a:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    748e:	06                   	push   es
    748f:	57                   	push   di
    7490:	9a d2 31 b8 74       	call   0x74b8:0x31d2
    7495:	6a 01                	push   0x1
    7497:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    749b:	06                   	push   es
    749c:	57                   	push   di
    749d:	9a fb 2f ad 74       	call   0x74ad:0x2ffb
    74a2:	6a 00                	push   0x0
    74a4:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    74a8:	06                   	push   es
    74a9:	57                   	push   di
    74aa:	9a d2 2e 6b 75       	call   0x756b:0x2ed2
    74af:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    74b3:	06                   	push   es
    74b4:	57                   	push   di
    74b5:	9a bf 31 89 75       	call   0x7589:0x31bf
    74ba:	a1 a2 1e             	mov    ax,ds:0x1ea2
    74bd:	99                   	cwd
    74be:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    74c2:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    74c6:	b8 01 00             	mov    ax,0x1
    74c9:	31 d2                	xor    dx,dx
    74cb:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    74cf:	7e 03                	jle    0x74d4
    74d1:	e9 af 01             	jmp    0x7683
    74d4:	7c 09                	jl     0x74df
    74d6:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    74da:	76 03                	jbe    0x74df
    74dc:	e9 a4 01             	jmp    0x7683
    74df:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    74e2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    74e5:	eb 08                	jmp    0x74ef
    74e7:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    74eb:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    74ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74f2:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    74f7:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    74fb:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    74ff:	a1 4e 01             	mov    ax,ds:0x14e
    7502:	99                   	cwd
    7503:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    7507:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    750b:	b8 01 00             	mov    ax,0x1
    750e:	31 d2                	xor    dx,dx
    7510:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    7514:	7e 03                	jle    0x7519
    7516:	e9 52 01             	jmp    0x766b
    7519:	7c 09                	jl     0x7524
    751b:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    751f:	76 03                	jbe    0x7524
    7521:	e9 47 01             	jmp    0x766b
    7524:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7527:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    752a:	eb 08                	jmp    0x7534
    752c:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    7530:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    7534:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7537:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    753a:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    753e:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    7542:	c6 86 d8 fe 00       	mov    BYTE PTR [bp-0x128],0x0
    7547:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    754a:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    754d:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    7551:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    7555:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    755a:	8d be d4 fe          	lea    di,[bp-0x12c]
    755e:	16                   	push   ss
    755f:	57                   	push   di
    7560:	6a 01                	push   0x1
    7562:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    7566:	06                   	push   es
    7567:	57                   	push   di
    7568:	9a 95 28 ef 78       	call   0x78ef:0x2895
    756d:	08 c0                	or     al,al
    756f:	75 0a                	jne    0x757b
    7571:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7574:	06                   	push   es
    7575:	57                   	push   di
    7576:	9a f6 10 10 76       	call   0x7610:0x10f6
    757b:	bf 31 74             	mov    di,0x7431
    757e:	0e                   	push   cs
    757f:	57                   	push   di
    7580:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    7584:	06                   	push   es
    7585:	57                   	push   di
    7586:	9a 9b 3b ab 75       	call   0x75ab:0x3b9b
    758b:	89 c7                	mov    di,ax
    758d:	8e c2                	mov    es,dx
    758f:	06                   	push   es
    7590:	57                   	push   di
    7591:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7594:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7598:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    759d:	bf 3f 74             	mov    di,0x743f
    75a0:	0e                   	push   cs
    75a1:	57                   	push   di
    75a2:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    75a6:	06                   	push   es
    75a7:	57                   	push   di
    75a8:	9a 9b 3b d5 75       	call   0x75d5:0x3b9b
    75ad:	89 c7                	mov    di,ax
    75af:	8e c2                	mov    es,dx
    75b1:	06                   	push   es
    75b2:	57                   	push   di
    75b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    75b6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    75ba:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    75bf:	9b de c1             	faddp  st(1),st
    75c2:	9b db be d0 fe       	fstp   TBYTE PTR [bp-0x130]
    75c7:	bf 48 74             	mov    di,0x7448
    75ca:	0e                   	push   cs
    75cb:	57                   	push   di
    75cc:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    75d0:	06                   	push   es
    75d1:	57                   	push   di
    75d2:	9a 9b 3b 90 76       	call   0x7690:0x3b9b
    75d7:	89 c7                	mov    di,ax
    75d9:	8e c2                	mov    es,dx
    75db:	06                   	push   es
    75dc:	57                   	push   di
    75dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    75e0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    75e4:	9b db ae d0 fe       	fld    TBYTE PTR [bp-0x130]
    75e9:	9b de c1             	faddp  st(1),st
    75ec:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    75f0:	90                   	nop
    75f1:	9b                   	fwait
    75f2:	8d be e4 fd          	lea    di,[bp-0x21c]
    75f6:	16                   	push   ss
    75f7:	57                   	push   di
    75f8:	ff 76 f6             	push   WORD PTR [bp-0xa]
    75fb:	ff 76 f4             	push   WORD PTR [bp-0xc]
    75fe:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7601:	ff 76 f0             	push   WORD PTR [bp-0x10]
    7604:	6a 0c                	push   0xc
    7606:	6a 02                	push   0x2
    7608:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    760b:	06                   	push   es
    760c:	57                   	push   di
    760d:	9a 2d 12 9a 76       	call   0x769a:0x122d
    7612:	8d be f0 fe          	lea    di,[bp-0x110]
    7616:	16                   	push   ss
    7617:	57                   	push   di
    7618:	68 ff 00             	push   0xff
    761b:	9a e7 17 2c 76       	call   0x762c:0x17e7
    7620:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7623:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7626:	bf 54 74             	mov    di,0x7454
    7629:	9a 16 04 3b 76       	call   0x763b:0x416
    762e:	50                   	push   ax
    762f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7632:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7635:	bf 54 74             	mov    di,0x7454
    7638:	9a 16 04 d6 76       	call   0x76d6:0x416
    763d:	50                   	push   ax
    763e:	8d be f0 fe          	lea    di,[bp-0x110]
    7642:	16                   	push   ss
    7643:	57                   	push   di
    7644:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7647:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    764c:	06                   	push   es
    764d:	57                   	push   di
    764e:	9a 08 9b a5 7b       	call   0x7ba5:0x9b08
    7653:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7656:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7659:	3b 96 e6 fe          	cmp    dx,WORD PTR [bp-0x11a]
    765d:	74 03                	je     0x7662
    765f:	e9 ca fe             	jmp    0x752c
    7662:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    7666:	74 03                	je     0x766b
    7668:	e9 c1 fe             	jmp    0x752c
    766b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    766e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7671:	3b 96 ee fe          	cmp    dx,WORD PTR [bp-0x112]
    7675:	74 03                	je     0x767a
    7677:	e9 6d fe             	jmp    0x74e7
    767a:	3b 86 ec fe          	cmp    ax,WORD PTR [bp-0x114]
    767e:	74 03                	je     0x7683
    7680:	e9 64 fe             	jmp    0x74e7
    7683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7686:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    768b:	06                   	push   es
    768c:	57                   	push   di
    768d:	9a d2 31 e2 78       	call   0x78e2:0x31d2
    7692:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7695:	06                   	push   es
    7696:	57                   	push   di
    7697:	9a 6f 14 aa 76       	call   0x76aa:0x146f
    769c:	ff 76 08             	push   WORD PTR [bp+0x8]
    769f:	ff 76 06             	push   WORD PTR [bp+0x6]
    76a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76a5:	06                   	push   es
    76a6:	57                   	push   di
    76a7:	9a a2 2b f0 76       	call   0x76f0:0x2ba2
    76ac:	c9                   	leave
    76ad:	ca 04 00             	retf   0x4
    76b0:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
    76b3:	73 73                	jae    0x7728
    76b5:	6f                   	outs   dx,WORD PTR ds:[si]
    76b6:	75 72                	jne    0x772a
    76b8:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    76bb:	20 70 72             	and    BYTE PTR [bx+si+0x72],dh
    76be:	6f                   	outs   dx,WORD PTR ds:[si]
    76bf:	70 72                	jo     0x7733
    76c1:	65 73 00             	gs jae 0x76c4
    76c4:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    76c7:	72 69                	jb     0x7732
    76c9:	6f                   	outs   dx,WORD PTR ds:[si]
    76ca:	64 65 73 55          	fs gs jae 0x7723
    76ce:	89 e5                	mov    bp,sp
    76d0:	b8 08 00             	mov    ax,0x8
    76d3:	9a 44 04 44 77       	call   0x7744:0x444
    76d8:	83 ec 08             	sub    sp,0x8
    76db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76de:	26 c7 85 8a 08 2a 00 	mov    WORD PTR es:[di+0x88a],0x2a
    76e5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    76e8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    76eb:	06                   	push   es
    76ec:	57                   	push   di
    76ed:	9a 5b 7f 78 77       	call   0x7778:0x7f5b
    76f2:	6a 00                	push   0x0
    76f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76f7:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    76fc:	06                   	push   es
    76fd:	57                   	push   di
    76fe:	9a a5 13 12 77       	call   0x7712:0x13a5
    7703:	6a 00                	push   0x0
    7705:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7708:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    770d:	06                   	push   es
    770e:	57                   	push   di
    770f:	9a a5 13 23 77       	call   0x7723:0x13a5
    7714:	6a 00                	push   0x0
    7716:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7719:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    771e:	06                   	push   es
    771f:	57                   	push   di
    7720:	9a a5 13 3a 77       	call   0x773a:0x13a5
    7725:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7728:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    772d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    7730:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    7733:	6a 00                	push   0x0
    7735:	06                   	push   es
    7736:	57                   	push   di
    7737:	9a 26 13 4f 77       	call   0x774f:0x1326
    773c:	2d 01 00             	sub    ax,0x1
    773f:	71 05                	jno    0x7746
    7741:	9a 3e 04 df 77       	call   0x77df:0x43e
    7746:	50                   	push   ax
    7747:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    774a:	06                   	push   es
    774b:	57                   	push   di
    774c:	9a 53 13 5a 77       	call   0x775a:0x1353
    7751:	89 c7                	mov    di,ax
    7753:	8e c2                	mov    es,dx
    7755:	06                   	push   es
    7756:	57                   	push   di
    7757:	9a a5 13 89 77       	call   0x7789:0x13a5
    775c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    775f:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    7764:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    7769:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    776e:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    7773:	06                   	push   es
    7774:	57                   	push   di
    7775:	9a bd 7f 98 77       	call   0x7798:0x7fbd
    777a:	6a 01                	push   0x1
    777c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    777f:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    7784:	06                   	push   es
    7785:	57                   	push   di
    7786:	9a a5 13 d5 77       	call   0x77d5:0x13a5
    778b:	bf b0 76             	mov    di,0x76b0
    778e:	0e                   	push   cs
    778f:	57                   	push   di
    7790:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7793:	06                   	push   es
    7794:	57                   	push   di
    7795:	9a 77 38 a7 77       	call   0x77a7:0x3877
    779a:	bf c3 76             	mov    di,0x76c3
    779d:	0e                   	push   cs
    779e:	57                   	push   di
    779f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77a2:	06                   	push   es
    77a3:	57                   	push   di
    77a4:	9a 02 39 b6 77       	call   0x77b6:0x3902
    77a9:	bf c4 76             	mov    di,0x76c4
    77ac:	0e                   	push   cs
    77ad:	57                   	push   di
    77ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77b1:	06                   	push   es
    77b2:	57                   	push   di
    77b3:	9a ef 37 c0 77       	call   0x77c0:0x37ef
    77b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77bb:	06                   	push   es
    77bc:	57                   	push   di
    77bd:	9a 10 81 1f 78       	call   0x781f:0x8110
    77c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c5:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    77ca:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    77cd:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    77d0:	06                   	push   es
    77d1:	57                   	push   di
    77d2:	9a 26 13 00 78       	call   0x7800:0x1326
    77d7:	2d 01 00             	sub    ax,0x1
    77da:	71 05                	jno    0x77e1
    77dc:	9a 3e 04 b4 78       	call   0x78b4:0x43e
    77e1:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    77e4:	31 c0                	xor    ax,ax
    77e6:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    77e9:	7f 2a                	jg     0x7815
    77eb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    77ee:	eb 03                	jmp    0x77f3
    77f0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    77f3:	6a 01                	push   0x1
    77f5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    77f8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    77fb:	06                   	push   es
    77fc:	57                   	push   di
    77fd:	9a 53 13 0b 78       	call   0x780b:0x1353
    7802:	89 c7                	mov    di,ax
    7804:	8e c2                	mov    es,dx
    7806:	06                   	push   es
    7807:	57                   	push   di
    7808:	9a 75 12 55 7c       	call   0x7c55:0x1275
    780d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7810:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7813:	75 db                	jne    0x77f0
    7815:	6a 01                	push   0x1
    7817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    781a:	06                   	push   es
    781b:	57                   	push   di
    781c:	9a 8f 8a 2f 78       	call   0x782f:0x8a8f
    7821:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7824:	26 c6 85 5d 08 01    	mov    BYTE PTR es:[di+0x85d],0x1
    782a:	06                   	push   es
    782b:	57                   	push   di
    782c:	9a 5c 74 cb 78       	call   0x78cb:0x745c
    7831:	c9                   	leave
    7832:	ca 08 00             	retf   0x8
    7835:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    7838:	75 78                	jne    0x78b2
    783a:	20 64 27             	and    BYTE PTR [si+0x27],ah
    783d:	65 6e                	outs   dx,BYTE PTR gs:[si]
    783f:	64 65 74 74          	fs gs je 0x78b7
    7843:	65 6d                	gs ins WORD PTR es:[di],dx
    7845:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7847:	74 0d                	je     0x7856
    7849:	43                   	inc    bx
    784a:	61                   	popa
    784b:	70 69                	jo     0x78b6
    784d:	74 61                	je     0x78b0
    784f:	6c                   	ins    BYTE PTR es:[di],dx
    7850:	53                   	push   bx
    7851:	6f                   	outs   dx,WORD PTR ds:[si]
    7852:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    7855:	6c                   	ins    BYTE PTR es:[di],dx
    7856:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    7859:	73 65                	jae    0x78c0
    785b:	72 76                	jb     0x78d3
    785d:	65 73 0b             	gs jae 0x786b
    7860:	52                   	push   dx
    7861:	65 73 75             	gs jae 0x78d9
    7864:	6c                   	ins    BYTE PTR es:[di],dx
    7865:	74 61                	je     0x78c8
    7867:	74 4e                	je     0x78b7
    7869:	65 74 07             	gs je  0x7873
    786c:	45                   	inc    bp
    786d:	6d                   	ins    WORD PTR es:[di],dx
    786e:	70 72                	jo     0x78e2
    7870:	75 6e                	jne    0x78e0
    7872:	74 0d                	je     0x7881
    7874:	44                   	inc    sp
    7875:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7879:	76 65                	jbe    0x78e0
    787b:	72 74                	jb     0x78f1
    787d:	41                   	inc    cx
    787e:	75 74                	jne    0x78f4
    7880:	6f                   	outs   dx,WORD PTR ds:[si]
    7881:	0e                   	push   cs
    7882:	44                   	inc    sp
    7883:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7887:	76 65                	jbe    0x78ee
    7889:	72 74                	jb     0x78ff
    788b:	4e                   	dec    si
    788c:	61                   	popa
    788d:	75 74                	jne    0x7903
    788f:	6f                   	outs   dx,WORD PTR ds:[si]
    7890:	0c 46                	or     al,0x46
    7892:	6f                   	outs   dx,WORD PTR ds:[si]
    7893:	75 72                	jne    0x7907
    7895:	6e                   	outs   dx,BYTE PTR ds:[si]
    7896:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    789b:	72 73                	jb     0x7910
    789d:	05 49 6d             	add    ax,0x6d49
    78a0:	70 6f                	jo     0x7911
    78a2:	74 00                	je     0x78a4
    78a4:	80 ff ff             	cmp    bh,0xff
    78a7:	ff                   	(bad)
    78a8:	7f 00                	jg     0x78aa
    78aa:	00 55 89             	add    BYTE PTR [di-0x77],dl
    78ad:	e5 b8                	in     ax,0xb8
    78af:	2c 02                	sub    al,0x2
    78b1:	9a 44 04 72 7b       	call   0x7b72:0x444
    78b6:	81 ec 2c 02          	sub    sp,0x22c
    78ba:	6a ff                	push   0xffff
    78bc:	6a ff                	push   0xffff
    78be:	bf 35 78             	mov    di,0x7835
    78c1:	0e                   	push   cs
    78c2:	57                   	push   di
    78c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78c6:	06                   	push   es
    78c7:	57                   	push   di
    78c8:	9a 90 7d c8 79       	call   0x79c8:0x7d90
    78cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78d0:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    78d5:	89 be dc fe          	mov    WORD PTR [bp-0x124],di
    78d9:	8c 86 de fe          	mov    WORD PTR [bp-0x122],es
    78dd:	06                   	push   es
    78de:	57                   	push   di
    78df:	9a d2 31 07 79       	call   0x7907:0x31d2
    78e4:	6a 01                	push   0x1
    78e6:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    78ea:	06                   	push   es
    78eb:	57                   	push   di
    78ec:	9a fb 2f fc 78       	call   0x78fc:0x2ffb
    78f1:	6a 00                	push   0x0
    78f3:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    78f7:	06                   	push   es
    78f8:	57                   	push   di
    78f9:	9a d2 2e ba 79       	call   0x79ba:0x2ed2
    78fe:	c4 be dc fe          	les    di,DWORD PTR [bp-0x124]
    7902:	06                   	push   es
    7903:	57                   	push   di
    7904:	9a bf 31 d8 79       	call   0x79d8:0x31bf
    7909:	a1 a2 1e             	mov    ax,ds:0x1ea2
    790c:	99                   	cwd
    790d:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    7911:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    7915:	b8 01 00             	mov    ax,0x1
    7918:	31 d2                	xor    dx,dx
    791a:	3b 96 de fe          	cmp    dx,WORD PTR [bp-0x122]
    791e:	7e 03                	jle    0x7923
    7920:	e9 b4 02             	jmp    0x7bd7
    7923:	7c 09                	jl     0x792e
    7925:	3b 86 dc fe          	cmp    ax,WORD PTR [bp-0x124]
    7929:	76 03                	jbe    0x792e
    792b:	e9 a9 02             	jmp    0x7bd7
    792e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7931:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7934:	eb 08                	jmp    0x793e
    7936:	83 46 fc 01          	add    WORD PTR [bp-0x4],0x1
    793a:	83 56 fe 00          	adc    WORD PTR [bp-0x2],0x0
    793e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7941:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    7946:	89 be d8 fe          	mov    WORD PTR [bp-0x128],di
    794a:	8c 86 da fe          	mov    WORD PTR [bp-0x126],es
    794e:	a1 4e 01             	mov    ax,ds:0x14e
    7951:	99                   	cwd
    7952:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    7956:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    795a:	b8 01 00             	mov    ax,0x1
    795d:	31 d2                	xor    dx,dx
    795f:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    7963:	7e 03                	jle    0x7968
    7965:	e9 57 02             	jmp    0x7bbf
    7968:	7c 09                	jl     0x7973
    796a:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    796e:	76 03                	jbe    0x7973
    7970:	e9 4c 02             	jmp    0x7bbf
    7973:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7976:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7979:	eb 08                	jmp    0x7983
    797b:	83 46 f8 01          	add    WORD PTR [bp-0x8],0x1
    797f:	83 56 fa 00          	adc    WORD PTR [bp-0x6],0x0
    7983:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7986:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7989:	89 86 c4 fe          	mov    WORD PTR [bp-0x13c],ax
    798d:	89 96 c6 fe          	mov    WORD PTR [bp-0x13a],dx
    7991:	c6 86 c8 fe 00       	mov    BYTE PTR [bp-0x138],0x0
    7996:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7999:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    799c:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    79a0:	89 96 ce fe          	mov    WORD PTR [bp-0x132],dx
    79a4:	c6 86 d0 fe 00       	mov    BYTE PTR [bp-0x130],0x0
    79a9:	8d be c4 fe          	lea    di,[bp-0x13c]
    79ad:	16                   	push   ss
    79ae:	57                   	push   di
    79af:	6a 01                	push   0x1
    79b1:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    79b5:	06                   	push   es
    79b6:	57                   	push   di
    79b7:	9a 95 28 ff ff       	call   0xffff:0x2895
    79bc:	08 c0                	or     al,al
    79be:	75 0a                	jne    0x79ca
    79c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79c3:	06                   	push   es
    79c4:	57                   	push   di
    79c5:	9a f6 10 64 7b       	call   0x7b64:0x10f6
    79ca:	bf 48 78             	mov    di,0x7848
    79cd:	0e                   	push   cs
    79ce:	57                   	push   di
    79cf:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    79d3:	06                   	push   es
    79d4:	57                   	push   di
    79d5:	9a 9b 3b fa 79       	call   0x79fa:0x3b9b
    79da:	89 c7                	mov    di,ax
    79dc:	8e c2                	mov    es,dx
    79de:	06                   	push   es
    79df:	57                   	push   di
    79e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    79e3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    79e7:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    79ec:	bf 56 78             	mov    di,0x7856
    79ef:	0e                   	push   cs
    79f0:	57                   	push   di
    79f1:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    79f5:	06                   	push   es
    79f6:	57                   	push   di
    79f7:	9a 9b 3b 24 7a       	call   0x7a24:0x3b9b
    79fc:	89 c7                	mov    di,ax
    79fe:	8e c2                	mov    es,dx
    7a00:	06                   	push   es
    7a01:	57                   	push   di
    7a02:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a05:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7a09:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    7a0e:	9b de c1             	faddp  st(1),st
    7a11:	9b db be c0 fe       	fstp   TBYTE PTR [bp-0x140]
    7a16:	bf 5f 78             	mov    di,0x785f
    7a19:	0e                   	push   cs
    7a1a:	57                   	push   di
    7a1b:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    7a1f:	06                   	push   es
    7a20:	57                   	push   di
    7a21:	9a 9b 3b 4f 7a       	call   0x7a4f:0x3b9b
    7a26:	89 c7                	mov    di,ax
    7a28:	8e c2                	mov    es,dx
    7a2a:	06                   	push   es
    7a2b:	57                   	push   di
    7a2c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a2f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7a33:	9b db ae c0 fe       	fld    TBYTE PTR [bp-0x140]
    7a38:	9b de c1             	faddp  st(1),st
    7a3b:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    7a3f:	90                   	nop
    7a40:	9b                   	fwait
    7a41:	bf 6b 78             	mov    di,0x786b
    7a44:	0e                   	push   cs
    7a45:	57                   	push   di
    7a46:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    7a4a:	06                   	push   es
    7a4b:	57                   	push   di
    7a4c:	9a 9b 3b 71 7a       	call   0x7a71:0x3b9b
    7a51:	89 c7                	mov    di,ax
    7a53:	8e c2                	mov    es,dx
    7a55:	06                   	push   es
    7a56:	57                   	push   di
    7a57:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a5a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7a5e:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    7a63:	bf 73 78             	mov    di,0x7873
    7a66:	0e                   	push   cs
    7a67:	57                   	push   di
    7a68:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    7a6c:	06                   	push   es
    7a6d:	57                   	push   di
    7a6e:	9a 9b 3b 9b 7a       	call   0x7a9b:0x3b9b
    7a73:	89 c7                	mov    di,ax
    7a75:	8e c2                	mov    es,dx
    7a77:	06                   	push   es
    7a78:	57                   	push   di
    7a79:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a7c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7a80:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    7a85:	9b de c1             	faddp  st(1),st
    7a88:	9b db be c0 fe       	fstp   TBYTE PTR [bp-0x140]
    7a8d:	bf 81 78             	mov    di,0x7881
    7a90:	0e                   	push   cs
    7a91:	57                   	push   di
    7a92:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    7a96:	06                   	push   es
    7a97:	57                   	push   di
    7a98:	9a 9b 3b c5 7a       	call   0x7ac5:0x3b9b
    7a9d:	89 c7                	mov    di,ax
    7a9f:	8e c2                	mov    es,dx
    7aa1:	06                   	push   es
    7aa2:	57                   	push   di
    7aa3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7aa6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7aaa:	9b db ae c0 fe       	fld    TBYTE PTR [bp-0x140]
    7aaf:	9b de c1             	faddp  st(1),st
    7ab2:	9b db be b6 fe       	fstp   TBYTE PTR [bp-0x14a]
    7ab7:	bf 90 78             	mov    di,0x7890
    7aba:	0e                   	push   cs
    7abb:	57                   	push   di
    7abc:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    7ac0:	06                   	push   es
    7ac1:	57                   	push   di
    7ac2:	9a 9b 3b ef 7a       	call   0x7aef:0x3b9b
    7ac7:	89 c7                	mov    di,ax
    7ac9:	8e c2                	mov    es,dx
    7acb:	06                   	push   es
    7acc:	57                   	push   di
    7acd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7ad0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7ad4:	9b db ae b6 fe       	fld    TBYTE PTR [bp-0x14a]
    7ad9:	9b de c1             	faddp  st(1),st
    7adc:	9b db be ac fe       	fstp   TBYTE PTR [bp-0x154]
    7ae1:	bf 9d 78             	mov    di,0x789d
    7ae4:	0e                   	push   cs
    7ae5:	57                   	push   di
    7ae6:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    7aea:	06                   	push   es
    7aeb:	57                   	push   di
    7aec:	9a 9b 3b e4 7b       	call   0x7be4:0x3b9b
    7af1:	89 c7                	mov    di,ax
    7af3:	8e c2                	mov    es,dx
    7af5:	06                   	push   es
    7af6:	57                   	push   di
    7af7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7afa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7afe:	9b db ae ac fe       	fld    TBYTE PTR [bp-0x154]
    7b03:	9b de c1             	faddp  st(1),st
    7b06:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    7b0a:	90                   	nop
    7b0b:	9b                   	fwait
    7b0c:	ff 76 ee             	push   WORD PTR [bp-0x12]
    7b0f:	ff 76 ec             	push   WORD PTR [bp-0x14]
    7b12:	ff 76 ea             	push   WORD PTR [bp-0x16]
    7b15:	ff 76 e8             	push   WORD PTR [bp-0x18]
    7b18:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    7b1c:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    7b20:	83 ec 08             	sub    sp,0x8
    7b23:	89 e3                	mov    bx,sp
    7b25:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    7b29:	90                   	nop
    7b2a:	9b                   	fwait
    7b2b:	9a a7 2e 3e 7b       	call   0x7b3e:0x2ea7
    7b30:	83 ec 08             	sub    sp,0x8
    7b33:	89 e3                	mov    bx,sp
    7b35:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    7b39:	90                   	nop
    7b3a:	9b                   	fwait
    7b3b:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    7b40:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    7b44:	90                   	nop
    7b45:	9b                   	fwait
    7b46:	8d be d4 fd          	lea    di,[bp-0x22c]
    7b4a:	16                   	push   ss
    7b4b:	57                   	push   di
    7b4c:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    7b4f:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    7b52:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    7b55:	ff 76 e0             	push   WORD PTR [bp-0x20]
    7b58:	6a 0c                	push   0xc
    7b5a:	6a 02                	push   0x2
    7b5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b5f:	06                   	push   es
    7b60:	57                   	push   di
    7b61:	9a 2d 12 ee 7b       	call   0x7bee:0x122d
    7b66:	8d be e0 fe          	lea    di,[bp-0x120]
    7b6a:	16                   	push   ss
    7b6b:	57                   	push   di
    7b6c:	68 ff 00             	push   0xff
    7b6f:	9a e7 17 80 7b       	call   0x7b80:0x17e7
    7b74:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7b77:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7b7a:	bf a3 78             	mov    di,0x78a3
    7b7d:	9a 16 04 8f 7b       	call   0x7b8f:0x416
    7b82:	50                   	push   ax
    7b83:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7b86:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7b89:	bf a3 78             	mov    di,0x78a3
    7b8c:	9a 16 04 2a 7c       	call   0x7c2a:0x416
    7b91:	50                   	push   ax
    7b92:	8d be e0 fe          	lea    di,[bp-0x120]
    7b96:	16                   	push   ss
    7b97:	57                   	push   di
    7b98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b9b:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    7ba0:	06                   	push   es
    7ba1:	57                   	push   di
    7ba2:	9a 08 9b 55 7f       	call   0x7f55:0x9b08
    7ba7:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7baa:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    7bad:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    7bb1:	74 03                	je     0x7bb6
    7bb3:	e9 c5 fd             	jmp    0x797b
    7bb6:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    7bba:	74 03                	je     0x7bbf
    7bbc:	e9 bc fd             	jmp    0x797b
    7bbf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7bc2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7bc5:	3b 96 de fe          	cmp    dx,WORD PTR [bp-0x122]
    7bc9:	74 03                	je     0x7bce
    7bcb:	e9 68 fd             	jmp    0x7936
    7bce:	3b 86 dc fe          	cmp    ax,WORD PTR [bp-0x124]
    7bd2:	74 03                	je     0x7bd7
    7bd4:	e9 5f fd             	jmp    0x7936
    7bd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bda:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    7bdf:	06                   	push   es
    7be0:	57                   	push   di
    7be1:	9a d2 31 ff ff       	call   0xffff:0x31d2
    7be6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7be9:	06                   	push   es
    7bea:	57                   	push   di
    7beb:	9a 6f 14 fe 7b       	call   0x7bfe:0x146f
    7bf0:	ff 76 08             	push   WORD PTR [bp+0x8]
    7bf3:	ff 76 06             	push   WORD PTR [bp+0x6]
    7bf6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bf9:	06                   	push   es
    7bfa:	57                   	push   di
    7bfb:	9a a2 2b 44 7c       	call   0x7c44:0x2ba2
    7c00:	c9                   	leave
    7c01:	ca 04 00             	retf   0x4
    7c04:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    7c07:	75 78                	jne    0x7c81
    7c09:	20 64 27             	and    BYTE PTR [si+0x27],ah
    7c0c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7c0e:	64 65 74 74          	fs gs je 0x7c86
    7c12:	65 6d                	gs ins WORD PTR es:[di],dx
    7c14:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7c16:	74 00                	je     0x7c18
    7c18:	08 50 e9             	or     BYTE PTR [bx+si-0x17],dl
    7c1b:	72 69                	jb     0x7c86
    7c1d:	6f                   	outs   dx,WORD PTR ds:[si]
    7c1e:	64 65 73 55          	fs gs jae 0x7c77
    7c22:	89 e5                	mov    bp,sp
    7c24:	b8 08 00             	mov    ax,0x8
    7c27:	9a 44 04 98 7c       	call   0x7c98:0x444
    7c2c:	83 ec 08             	sub    sp,0x8
    7c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c32:	26 c7 85 8a 08 2b 00 	mov    WORD PTR es:[di+0x88a],0x2b
    7c39:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7c3c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7c3f:	06                   	push   es
    7c40:	57                   	push   di
    7c41:	9a 5b 7f cc 7c       	call   0x7ccc:0x7f5b
    7c46:	6a 00                	push   0x0
    7c48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c4b:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    7c50:	06                   	push   es
    7c51:	57                   	push   di
    7c52:	9a a5 13 66 7c       	call   0x7c66:0x13a5
    7c57:	6a 00                	push   0x0
    7c59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c5c:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    7c61:	06                   	push   es
    7c62:	57                   	push   di
    7c63:	9a a5 13 77 7c       	call   0x7c77:0x13a5
    7c68:	6a 00                	push   0x0
    7c6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c6d:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    7c72:	06                   	push   es
    7c73:	57                   	push   di
    7c74:	9a a5 13 8e 7c       	call   0x7c8e:0x13a5
    7c79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c7c:	26 c4 bd 74 03       	les    di,DWORD PTR es:[di+0x374]
    7c81:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    7c84:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    7c87:	6a 00                	push   0x0
    7c89:	06                   	push   es
    7c8a:	57                   	push   di
    7c8b:	9a 26 13 a3 7c       	call   0x7ca3:0x1326
    7c90:	2d 01 00             	sub    ax,0x1
    7c93:	71 05                	jno    0x7c9a
    7c95:	9a 3e 04 33 7d       	call   0x7d33:0x43e
    7c9a:	50                   	push   ax
    7c9b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    7c9e:	06                   	push   es
    7c9f:	57                   	push   di
    7ca0:	9a 53 13 ae 7c       	call   0x7cae:0x1353
    7ca5:	89 c7                	mov    di,ax
    7ca7:	8e c2                	mov    es,dx
    7ca9:	06                   	push   es
    7caa:	57                   	push   di
    7cab:	9a a5 13 dd 7c       	call   0x7cdd:0x13a5
    7cb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cb3:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    7cb8:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    7cbd:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    7cc2:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    7cc7:	06                   	push   es
    7cc8:	57                   	push   di
    7cc9:	9a bd 7f ec 7c       	call   0x7cec:0x7fbd
    7cce:	6a 01                	push   0x1
    7cd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cd3:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    7cd8:	06                   	push   es
    7cd9:	57                   	push   di
    7cda:	9a a5 13 29 7d       	call   0x7d29:0x13a5
    7cdf:	bf 04 7c             	mov    di,0x7c04
    7ce2:	0e                   	push   cs
    7ce3:	57                   	push   di
    7ce4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ce7:	06                   	push   es
    7ce8:	57                   	push   di
    7ce9:	9a 77 38 fb 7c       	call   0x7cfb:0x3877
    7cee:	bf 17 7c             	mov    di,0x7c17
    7cf1:	0e                   	push   cs
    7cf2:	57                   	push   di
    7cf3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cf6:	06                   	push   es
    7cf7:	57                   	push   di
    7cf8:	9a 02 39 0a 7d       	call   0x7d0a:0x3902
    7cfd:	bf 18 7c             	mov    di,0x7c18
    7d00:	0e                   	push   cs
    7d01:	57                   	push   di
    7d02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d05:	06                   	push   es
    7d06:	57                   	push   di
    7d07:	9a ef 37 14 7d       	call   0x7d14:0x37ef
    7d0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d0f:	06                   	push   es
    7d10:	57                   	push   di
    7d11:	9a 10 81 73 7d       	call   0x7d73:0x8110
    7d16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d19:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    7d1e:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    7d21:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    7d24:	06                   	push   es
    7d25:	57                   	push   di
    7d26:	9a 26 13 54 7d       	call   0x7d54:0x1326
    7d2b:	2d 01 00             	sub    ax,0x1
    7d2e:	71 05                	jno    0x7d35
    7d30:	9a 3e 04 99 7d       	call   0x7d99:0x43e
    7d35:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7d38:	31 c0                	xor    ax,ax
    7d3a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7d3d:	7f 2a                	jg     0x7d69
    7d3f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7d42:	eb 03                	jmp    0x7d47
    7d44:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    7d47:	6a 01                	push   0x1
    7d49:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7d4c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    7d4f:	06                   	push   es
    7d50:	57                   	push   di
    7d51:	9a 53 13 5f 7d       	call   0x7d5f:0x1353
    7d56:	89 c7                	mov    di,ax
    7d58:	8e c2                	mov    es,dx
    7d5a:	06                   	push   es
    7d5b:	57                   	push   di
    7d5c:	9a 75 12 e9 7d       	call   0x7de9:0x1275
    7d61:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7d64:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    7d67:	75 db                	jne    0x7d44
    7d69:	6a 01                	push   0x1
    7d6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d6e:	06                   	push   es
    7d6f:	57                   	push   di
    7d70:	9a 8f 8a 83 7d       	call   0x7d83:0x8a8f
    7d75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d78:	26 c6 85 5d 08 01    	mov    BYTE PTR es:[di+0x85d],0x1
    7d7e:	06                   	push   es
    7d7f:	57                   	push   di
    7d80:	9a ab 78 39 7f       	call   0x7f39:0x78ab
    7d85:	c9                   	leave
    7d86:	ca 08 00             	retf   0x8
    7d89:	01 26 04 20          	add    WORD PTR ds:0x2004,sp
    7d8d:	2d 2d 20             	sub    ax,0x202d
    7d90:	55                   	push   bp
    7d91:	89 e5                	mov    bp,sp
    7d93:	b8 02 04             	mov    ax,0x402
    7d96:	9a 44 04 d9 7d       	call   0x7dd9:0x444
    7d9b:	81 ec 02 04          	sub    sp,0x402
    7d9f:	8c d3                	mov    bx,ss
    7da1:	8e c3                	mov    es,bx
    7da3:	8c db                	mov    bx,ds
    7da5:	fc                   	cld
    7da6:	8d be 00 ff          	lea    di,[bp-0x100]
    7daa:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    7dad:	ac                   	lods   al,BYTE PTR ds:[si]
    7dae:	aa                   	stos   BYTE PTR es:[di],al
    7daf:	91                   	xchg   cx,ax
    7db0:	30 ed                	xor    ch,ch
    7db2:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    7db4:	8e db                	mov    ds,bx
    7db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7db9:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    7dbe:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    7dc3:	75 03                	jne    0x7dc8
    7dc5:	e9 93 00             	jmp    0x7e5b
    7dc8:	8d be fe fb          	lea    di,[bp-0x402]
    7dcc:	16                   	push   ss
    7dcd:	57                   	push   di
    7dce:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    7dd1:	2d 01 00             	sub    ax,0x1
    7dd4:	71 05                	jno    0x7ddb
    7dd6:	9a 3e 04 02 7e       	call   0x7e02:0x43e
    7ddb:	50                   	push   ax
    7ddc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ddf:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    7de4:	06                   	push   es
    7de5:	57                   	push   di
    7de6:	9a 53 13 f4 7d       	call   0x7df4:0x1353
    7deb:	89 c7                	mov    di,ax
    7ded:	8e c2                	mov    es,dx
    7def:	06                   	push   es
    7df0:	57                   	push   di
    7df1:	9a 61 11 93 7e       	call   0x7e93:0x1161
    7df6:	8d be 00 fe          	lea    di,[bp-0x200]
    7dfa:	16                   	push   ss
    7dfb:	57                   	push   di
    7dfc:	68 ff 00             	push   0xff
    7dff:	9a e7 17 12 7e       	call   0x7e12:0x17e7
    7e04:	bf 89 7d             	mov    di,0x7d89
    7e07:	0e                   	push   cs
    7e08:	57                   	push   di
    7e09:	8d be 00 fe          	lea    di,[bp-0x200]
    7e0d:	16                   	push   ss
    7e0e:	57                   	push   di
    7e0f:	9a 78 18 2e 7e       	call   0x7e2e:0x1878
    7e14:	89 86 fe fc          	mov    WORD PTR [bp-0x302],ax
    7e18:	83 be fe fc 00       	cmp    WORD PTR [bp-0x302],0x0
    7e1d:	7e 11                	jle    0x7e30
    7e1f:	8d be 00 fe          	lea    di,[bp-0x200]
    7e23:	16                   	push   ss
    7e24:	57                   	push   di
    7e25:	ff b6 fe fc          	push   WORD PTR [bp-0x302]
    7e29:	6a 01                	push   0x1
    7e2b:	9a 75 19 3f 7e       	call   0x7e3f:0x1975
    7e30:	8d be fe fb          	lea    di,[bp-0x402]
    7e34:	16                   	push   ss
    7e35:	57                   	push   di
    7e36:	8d be 00 fe          	lea    di,[bp-0x200]
    7e3a:	16                   	push   ss
    7e3b:	57                   	push   di
    7e3c:	9a cd 17 49 7e       	call   0x7e49:0x17cd
    7e41:	bf 8b 7d             	mov    di,0x7d8b
    7e44:	0e                   	push   cs
    7e45:	57                   	push   di
    7e46:	9a 4c 18 57 7e       	call   0x7e57:0x184c
    7e4b:	8d be 00 fe          	lea    di,[bp-0x200]
    7e4f:	16                   	push   ss
    7e50:	57                   	push   di
    7e51:	68 ff 00             	push   0xff
    7e54:	9a e7 17 83 7e       	call   0x7e83:0x17e7
    7e59:	eb 05                	jmp    0x7e60
    7e5b:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    7e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e63:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    7e68:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    7e6d:	75 03                	jne    0x7e72
    7e6f:	e9 93 00             	jmp    0x7f05
    7e72:	8d be fe fb          	lea    di,[bp-0x402]
    7e76:	16                   	push   ss
    7e77:	57                   	push   di
    7e78:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    7e7b:	2d 01 00             	sub    ax,0x1
    7e7e:	71 05                	jno    0x7e85
    7e80:	9a 3e 04 ac 7e       	call   0x7eac:0x43e
    7e85:	50                   	push   ax
    7e86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e89:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    7e8e:	06                   	push   es
    7e8f:	57                   	push   di
    7e90:	9a 53 13 9e 7e       	call   0x7e9e:0x1353
    7e95:	89 c7                	mov    di,ax
    7e97:	8e c2                	mov    es,dx
    7e99:	06                   	push   es
    7e9a:	57                   	push   di
    7e9b:	9a 61 11 85 7f       	call   0x7f85:0x1161
    7ea0:	8d be 00 fd          	lea    di,[bp-0x300]
    7ea4:	16                   	push   ss
    7ea5:	57                   	push   di
    7ea6:	68 ff 00             	push   0xff
    7ea9:	9a e7 17 bc 7e       	call   0x7ebc:0x17e7
    7eae:	bf 89 7d             	mov    di,0x7d89
    7eb1:	0e                   	push   cs
    7eb2:	57                   	push   di
    7eb3:	8d be 00 fd          	lea    di,[bp-0x300]
    7eb7:	16                   	push   ss
    7eb8:	57                   	push   di
    7eb9:	9a 78 18 d8 7e       	call   0x7ed8:0x1878
    7ebe:	89 86 fe fc          	mov    WORD PTR [bp-0x302],ax
    7ec2:	83 be fe fc 00       	cmp    WORD PTR [bp-0x302],0x0
    7ec7:	7e 11                	jle    0x7eda
    7ec9:	8d be 00 fd          	lea    di,[bp-0x300]
    7ecd:	16                   	push   ss
    7ece:	57                   	push   di
    7ecf:	ff b6 fe fc          	push   WORD PTR [bp-0x302]
    7ed3:	6a 01                	push   0x1
    7ed5:	9a 75 19 e8 7e       	call   0x7ee8:0x1975
    7eda:	8d be fe fb          	lea    di,[bp-0x402]
    7ede:	16                   	push   ss
    7edf:	57                   	push   di
    7ee0:	bf 8b 7d             	mov    di,0x7d8b
    7ee3:	0e                   	push   cs
    7ee4:	57                   	push   di
    7ee5:	9a cd 17 f3 7e       	call   0x7ef3:0x17cd
    7eea:	8d be 00 fd          	lea    di,[bp-0x300]
    7eee:	16                   	push   ss
    7eef:	57                   	push   di
    7ef0:	9a 4c 18 01 7f       	call   0x7f01:0x184c
    7ef5:	8d be 00 fd          	lea    di,[bp-0x300]
    7ef9:	16                   	push   ss
    7efa:	57                   	push   di
    7efb:	68 ff 00             	push   0xff
    7efe:	9a e7 17 19 7f       	call   0x7f19:0x17e7
    7f03:	eb 05                	jmp    0x7f0a
    7f05:	c6 86 00 fd 00       	mov    BYTE PTR [bp-0x300],0x0
    7f0a:	8d be fe fb          	lea    di,[bp-0x402]
    7f0e:	16                   	push   ss
    7f0f:	57                   	push   di
    7f10:	8d be 00 fe          	lea    di,[bp-0x200]
    7f14:	16                   	push   ss
    7f15:	57                   	push   di
    7f16:	9a cd 17 24 7f       	call   0x7f24:0x17cd
    7f1b:	8d be 00 ff          	lea    di,[bp-0x100]
    7f1f:	16                   	push   ss
    7f20:	57                   	push   di
    7f21:	9a 4c 18 2f 7f       	call   0x7f2f:0x184c
    7f26:	8d be 00 fd          	lea    di,[bp-0x300]
    7f2a:	16                   	push   ss
    7f2b:	57                   	push   di
    7f2c:	9a 4c 18 64 7f       	call   0x7f64:0x184c
    7f31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f34:	06                   	push   es
    7f35:	57                   	push   di
    7f36:	9a 67 37 79 7f       	call   0x7f79:0x3767
    7f3b:	6a 00                	push   0x0
    7f3d:	6a 00                	push   0x0
    7f3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f42:	81 c7 5c 04          	add    di,0x45c
    7f46:	06                   	push   es
    7f47:	57                   	push   di
    7f48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f4b:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    7f50:	06                   	push   es
    7f51:	57                   	push   di
    7f52:	9a 08 9b a7 81       	call   0x81a7:0x9b08
    7f57:	c9                   	leave
    7f58:	ca 0c 00             	retf   0xc
    7f5b:	55                   	push   bp
    7f5c:	89 e5                	mov    bp,sp
    7f5e:	b8 04 00             	mov    ax,0x4
    7f61:	9a 44 04 8c 7f       	call   0x7f8c:0x444
    7f66:	83 ec 04             	sub    sp,0x4
    7f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f6c:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    7f71:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    7f76:	9a 21 11 ab 7f       	call   0x7fab:0x1121
    7f7b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7f7e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7f81:	bf 94 00             	mov    di,0x94
    7f84:	b8 99 7f             	mov    ax,0x7f99
    7f87:	50                   	push   ax
    7f88:	57                   	push   di
    7f89:	9a 73 22 c6 7f       	call   0x7fc6:0x2273
    7f8e:	89 c7                	mov    di,ax
    7f90:	8e c2                	mov    es,dx
    7f92:	6a 01                	push   0x1
    7f94:	06                   	push   es
    7f95:	57                   	push   di
    7f96:	9a 75 12 da 7f       	call   0x7fda:0x1275
    7f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f9e:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    7fa3:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    7fa8:	9a 87 11 b7 7f       	call   0x7fb7:0x1187
    7fad:	6a 01                	push   0x1
    7faf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7fb2:	06                   	push   es
    7fb3:	57                   	push   di
    7fb4:	9a 3d 32 e4 84       	call   0x84e4:0x323d
    7fb9:	c9                   	leave
    7fba:	ca 08 00             	retf   0x8
    7fbd:	55                   	push   bp
    7fbe:	89 e5                	mov    bp,sp
    7fc0:	b8 0e 01             	mov    ax,0x10e
    7fc3:	9a 44 04 e4 7f       	call   0x7fe4:0x444
    7fc8:	81 ec 0e 01          	sub    sp,0x10e
    7fcc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7fcf:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    7fd2:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    7fd5:	06                   	push   es
    7fd6:	57                   	push   di
    7fd7:	9a 26 13 05 80       	call   0x8005:0x1326
    7fdc:	2d 01 00             	sub    ax,0x1
    7fdf:	71 05                	jno    0x7fe6
    7fe1:	9a 3e 04 54 80       	call   0x8054:0x43e
    7fe6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    7fe9:	31 c0                	xor    ax,ax
    7feb:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    7fee:	7f 2a                	jg     0x801a
    7ff0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7ff3:	eb 03                	jmp    0x7ff8
    7ff5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    7ff8:	6a 00                	push   0x0
    7ffa:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7ffd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8000:	06                   	push   es
    8001:	57                   	push   di
    8002:	9a 53 13 10 80       	call   0x8010:0x1353
    8007:	89 c7                	mov    di,ax
    8009:	8e c2                	mov    es,dx
    800b:	06                   	push   es
    800c:	57                   	push   di
    800d:	9a a5 13 31 80       	call   0x8031:0x13a5
    8012:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8015:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    8018:	75 db                	jne    0x7ff5
    801a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    801d:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    8020:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    8023:	8d be f8 fe          	lea    di,[bp-0x108]
    8027:	16                   	push   ss
    8028:	57                   	push   di
    8029:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    802c:	06                   	push   es
    802d:	57                   	push   di
    802e:	9a 61 11 3b 80       	call   0x803b:0x1161
    8033:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8036:	06                   	push   es
    8037:	57                   	push   di
    8038:	9a 37 12 4a 80       	call   0x804a:0x1237
    803d:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
    8042:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8045:	06                   	push   es
    8046:	57                   	push   di
    8047:	9a 26 13 76 80       	call   0x8076:0x1326
    804c:	2d 01 00             	sub    ax,0x1
    804f:	71 05                	jno    0x8056
    8051:	9a 3e 04 19 81       	call   0x8119:0x43e
    8056:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    8059:	31 c0                	xor    ax,ax
    805b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    805e:	7e 03                	jle    0x8063
    8060:	e9 96 00             	jmp    0x80f9
    8063:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8066:	eb 03                	jmp    0x806b
    8068:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    806b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    806e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    8071:	06                   	push   es
    8072:	57                   	push   di
    8073:	9a 53 13 9a 80       	call   0x809a:0x1353
    8078:	89 c7                	mov    di,ax
    807a:	8e c2                	mov    es,dx
    807c:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    807f:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    8082:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    8087:	74 65                	je     0x80ee
    8089:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    808c:	8d be f2 fe          	lea    di,[bp-0x10e]
    8090:	16                   	push   ss
    8091:	57                   	push   di
    8092:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    8095:	06                   	push   es
    8096:	57                   	push   di
    8097:	9a 61 11 a7 80       	call   0x80a7:0x1161
    809c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    809f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80a2:	06                   	push   es
    80a3:	57                   	push   di
    80a4:	9a 53 13 b2 80       	call   0x80b2:0x1353
    80a9:	89 c7                	mov    di,ax
    80ab:	8e c2                	mov    es,dx
    80ad:	06                   	push   es
    80ae:	57                   	push   di
    80af:	9a 37 12 c7 80       	call   0x80c7:0x1237
    80b4:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    80b7:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
    80bb:	50                   	push   ax
    80bc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    80bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80c2:	06                   	push   es
    80c3:	57                   	push   di
    80c4:	9a 53 13 d2 80       	call   0x80d2:0x1353
    80c9:	89 c7                	mov    di,ax
    80cb:	8e c2                	mov    es,dx
    80cd:	06                   	push   es
    80ce:	57                   	push   di
    80cf:	9a a5 13 e1 80       	call   0x80e1:0x13a5
    80d4:	6a 00                	push   0x0
    80d6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    80d9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80dc:	06                   	push   es
    80dd:	57                   	push   di
    80de:	9a 53 13 ec 80       	call   0x80ec:0x1353
    80e3:	89 c7                	mov    di,ax
    80e5:	8e c2                	mov    es,dx
    80e7:	06                   	push   es
    80e8:	57                   	push   di
    80e9:	9a 75 12 39 81       	call   0x8139:0x1275
    80ee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    80f1:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    80f4:	74 03                	je     0x80f9
    80f6:	e9 6f ff             	jmp    0x8068
    80f9:	c9                   	leave
    80fa:	ca 0c 00             	retf   0xc
    80fd:	00 00                	add    BYTE PTR [bx+si],al
    80ff:	80 ff ff             	cmp    bh,0xff
    8102:	ff                   	(bad)
    8103:	7f 00                	jg     0x8105
    8105:	00 05                	add    BYTE PTR [di],al
    8107:	50                   	push   ax
    8108:	65 72 2e             	gs jb  0x8139
    810b:	20 01                	and    BYTE PTR [bx+di],al
    810d:	26 01 31             	add    WORD PTR es:[bx+di],si
    8110:	55                   	push   bp
    8111:	89 e5                	mov    bp,sp
    8113:	b8 0e 03             	mov    ax,0x30e
    8116:	9a 44 04 43 81       	call   0x8143:0x444
    811b:	81 ec 0e 03          	sub    sp,0x30e
    811f:	31 c0                	xor    ax,ax
    8121:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    8124:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8127:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    812c:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    8130:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    8134:	06                   	push   es
    8135:	57                   	push   di
    8136:	9a 26 13 65 81       	call   0x8165:0x1326
    813b:	2d 01 00             	sub    ax,0x1
    813e:	71 05                	jno    0x8145
    8140:	9a 3e 04 99 81       	call   0x8199:0x43e
    8145:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    8149:	31 c0                	xor    ax,ax
    814b:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    814f:	7f 2d                	jg     0x817e
    8151:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8154:	eb 03                	jmp    0x8159
    8156:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    8159:	ff 76 fe             	push   WORD PTR [bp-0x2]
    815c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    8160:	06                   	push   es
    8161:	57                   	push   di
    8162:	9a 53 13 83 82       	call   0x8283:0x1353
    8167:	89 c7                	mov    di,ax
    8169:	8e c2                	mov    es,dx
    816b:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    8170:	74 03                	je     0x8175
    8172:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    8175:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8178:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    817c:	75 d8                	jne    0x8156
    817e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8181:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    8186:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    818a:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    818e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    8191:	05 01 00             	add    ax,0x1
    8194:	71 05                	jno    0x819b
    8196:	9a 3e 04 b4 81       	call   0x81b4:0x43e
    819b:	99                   	cwd
    819c:	52                   	push   dx
    819d:	50                   	push   ax
    819e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    81a2:	06                   	push   es
    81a3:	57                   	push   di
    81a4:	9a 1b 70 c2 81       	call   0x81c2:0x701b
    81a9:	a1 a2 1e             	mov    ax,ds:0x1ea2
    81ac:	05 01 00             	add    ax,0x1
    81af:	71 05                	jno    0x81b6
    81b1:	9a 3e 04 0b 82       	call   0x820b:0x43e
    81b6:	99                   	cwd
    81b7:	52                   	push   dx
    81b8:	50                   	push   ax
    81b9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    81bd:	06                   	push   es
    81be:	57                   	push   di
    81bf:	9a 26 74 cf 81       	call   0x81cf:0x7426
    81c4:	6a 01                	push   0x1
    81c6:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    81ca:	06                   	push   es
    81cb:	57                   	push   di
    81cc:	9a 8b 72 dc 81       	call   0x81dc:0x728b
    81d1:	6a 01                	push   0x1
    81d3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    81d7:	06                   	push   es
    81d8:	57                   	push   di
    81d9:	9a 32 72 f0 81       	call   0x81f0:0x7232
    81de:	6a 00                	push   0x0
    81e0:	6a 00                	push   0x0
    81e2:	bf fd 80             	mov    di,0x80fd
    81e5:	0e                   	push   cs
    81e6:	57                   	push   di
    81e7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    81eb:	06                   	push   es
    81ec:	57                   	push   di
    81ed:	9a 08 9b 5e 82       	call   0x825e:0x9b08
    81f2:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    81f6:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    81fb:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    8200:	2d 01 00             	sub    ax,0x1
    8203:	83 da 00             	sbb    dx,0x0
    8206:	71 05                	jno    0x820d
    8208:	9a 3e 04 13 82       	call   0x8213:0x43e
    820d:	bf fe 80             	mov    di,0x80fe
    8210:	9a 16 04 3d 82       	call   0x823d:0x416
    8215:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    8219:	b8 01 00             	mov    ax,0x1
    821c:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    8220:	7f 47                	jg     0x8269
    8222:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8225:	eb 03                	jmp    0x822a
    8227:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    822a:	6a 00                	push   0x0
    822c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    822f:	8d be f2 fc          	lea    di,[bp-0x30e]
    8233:	16                   	push   ss
    8234:	57                   	push   di
    8235:	bf 06 81             	mov    di,0x8106
    8238:	0e                   	push   cs
    8239:	57                   	push   di
    823a:	9a cd 17 53 82       	call   0x8253:0x17cd
    823f:	8d be f2 fd          	lea    di,[bp-0x20e]
    8243:	16                   	push   ss
    8244:	57                   	push   di
    8245:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8248:	99                   	cwd
    8249:	52                   	push   dx
    824a:	50                   	push   ax
    824b:	9a a9 08 ff ff       	call   0xffff:0x8a9
    8250:	9a 4c 18 8d 82       	call   0x828d:0x184c
    8255:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    8259:	06                   	push   es
    825a:	57                   	push   di
    825b:	9a 08 9b 2d 83       	call   0x832d:0x9b08
    8260:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8263:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    8267:	75 be                	jne    0x8227
    8269:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    826e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8271:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    8276:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    827a:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    827e:	06                   	push   es
    827f:	57                   	push   di
    8280:	9a 26 13 b2 82       	call   0x82b2:0x1326
    8285:	2d 01 00             	sub    ax,0x1
    8288:	71 05                	jno    0x828f
    828a:	9a 3e 04 ee 82       	call   0x82ee:0x43e
    828f:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    8293:	31 c0                	xor    ax,ax
    8295:	3b 86 ee fe          	cmp    ax,WORD PTR [bp-0x112]
    8299:	7e 03                	jle    0x829e
    829b:	e9 a0 00             	jmp    0x833e
    829e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    82a1:	eb 03                	jmp    0x82a6
    82a3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    82a6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    82a9:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    82ad:	06                   	push   es
    82ae:	57                   	push   di
    82af:	9a 53 13 d5 82       	call   0x82d5:0x1353
    82b4:	89 c7                	mov    di,ax
    82b6:	8e c2                	mov    es,dx
    82b8:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    82bd:	74 73                	je     0x8332
    82bf:	8d be ee fd          	lea    di,[bp-0x212]
    82c3:	16                   	push   ss
    82c4:	57                   	push   di
    82c5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    82c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82cb:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    82d0:	06                   	push   es
    82d1:	57                   	push   di
    82d2:	9a 53 13 e0 82       	call   0x82e0:0x1353
    82d7:	89 c7                	mov    di,ax
    82d9:	8e c2                	mov    es,dx
    82db:	06                   	push   es
    82dc:	57                   	push   di
    82dd:	9a 61 11 aa 83       	call   0x83aa:0x1161
    82e2:	8d be f8 fe          	lea    di,[bp-0x108]
    82e6:	16                   	push   ss
    82e7:	57                   	push   di
    82e8:	68 ff 00             	push   0xff
    82eb:	9a e7 17 fe 82       	call   0x82fe:0x17e7
    82f0:	bf 0c 81             	mov    di,0x810c
    82f3:	0e                   	push   cs
    82f4:	57                   	push   di
    82f5:	8d be f8 fe          	lea    di,[bp-0x108]
    82f9:	16                   	push   ss
    82fa:	57                   	push   di
    82fb:	9a 78 18 17 83       	call   0x8317:0x1878
    8300:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8303:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    8307:	7e 10                	jle    0x8319
    8309:	8d be f8 fe          	lea    di,[bp-0x108]
    830d:	16                   	push   ss
    830e:	57                   	push   di
    830f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8312:	6a 01                	push   0x1
    8314:	9a 75 19 5b 83       	call   0x835b:0x1975
    8319:	ff 76 f8             	push   WORD PTR [bp-0x8]
    831c:	6a 00                	push   0x0
    831e:	8d be f8 fe          	lea    di,[bp-0x108]
    8322:	16                   	push   ss
    8323:	57                   	push   di
    8324:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    8328:	06                   	push   es
    8329:	57                   	push   di
    832a:	9a 08 9b 51 83       	call   0x8351:0x9b08
    832f:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    8332:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8335:	3b 86 ee fe          	cmp    ax,WORD PTR [bp-0x112]
    8339:	74 03                	je     0x833e
    833b:	e9 65 ff             	jmp    0x82a3
    833e:	8d be f4 fd          	lea    di,[bp-0x20c]
    8342:	16                   	push   ss
    8343:	57                   	push   di
    8344:	6a 01                	push   0x1
    8346:	6a 00                	push   0x0
    8348:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    834c:	06                   	push   es
    834d:	57                   	push   di
    834e:	9a 68 9a 77 83       	call   0x8377:0x9a68
    8353:	bf 0e 81             	mov    di,0x810e
    8356:	0e                   	push   cs
    8357:	57                   	push   di
    8358:	9a 4c 18 86 83       	call   0x8386:0x184c
    835d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    8361:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    8366:	06                   	push   es
    8367:	57                   	push   di
    8368:	9a 03 20 4c 89       	call   0x894c:0x2003
    836d:	50                   	push   ax
    836e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    8372:	06                   	push   es
    8373:	57                   	push   di
    8374:	9a 72 71 9e 88       	call   0x889e:0x7172
    8379:	c9                   	leave
    837a:	ca 04 00             	retf   0x4
    837d:	55                   	push   bp
    837e:	89 e5                	mov    bp,sp
    8380:	b8 0e 00             	mov    ax,0xe
    8383:	9a 44 04 b4 83       	call   0x83b4:0x444
    8388:	83 ec 0e             	sub    sp,0xe
    838b:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    8390:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8393:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    8398:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    839b:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    839e:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    83a3:	74 53                	je     0x83f8
    83a5:	06                   	push   es
    83a6:	57                   	push   di
    83a7:	9a 26 13 d3 83       	call   0x83d3:0x1326
    83ac:	2d 01 00             	sub    ax,0x1
    83af:	71 05                	jno    0x83b6
    83b1:	9a 3e 04 eb 83       	call   0x83eb:0x43e
    83b6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    83b9:	31 c0                	xor    ax,ax
    83bb:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    83be:	7f 38                	jg     0x83f8
    83c0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    83c3:	eb 03                	jmp    0x83c8
    83c5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    83c8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    83cb:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    83ce:	06                   	push   es
    83cf:	57                   	push   di
    83d0:	9a 53 13 17 84       	call   0x8417:0x1353
    83d5:	89 c7                	mov    di,ax
    83d7:	8e c2                	mov    es,dx
    83d9:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    83de:	74 10                	je     0x83f0
    83e0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    83e3:	05 01 00             	add    ax,0x1
    83e6:	71 05                	jno    0x83ed
    83e8:	9a 3e 04 21 84       	call   0x8421:0x43e
    83ed:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    83f0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    83f3:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    83f6:	75 cd                	jne    0x83c5
    83f8:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    83fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8400:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    8405:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    8408:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    840b:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    8410:	74 53                	je     0x8465
    8412:	06                   	push   es
    8413:	57                   	push   di
    8414:	9a 26 13 40 84       	call   0x8440:0x1326
    8419:	2d 01 00             	sub    ax,0x1
    841c:	71 05                	jno    0x8423
    841e:	9a 3e 04 58 84       	call   0x8458:0x43e
    8423:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    8426:	31 c0                	xor    ax,ax
    8428:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    842b:	7f 38                	jg     0x8465
    842d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8430:	eb 03                	jmp    0x8435
    8432:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    8435:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8438:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    843b:	06                   	push   es
    843c:	57                   	push   di
    843d:	9a 53 13 84 84       	call   0x8484:0x1353
    8442:	89 c7                	mov    di,ax
    8444:	8e c2                	mov    es,dx
    8446:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    844b:	74 10                	je     0x845d
    844d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8450:	05 01 00             	add    ax,0x1
    8453:	71 05                	jno    0x845a
    8455:	9a 3e 04 8e 84       	call   0x848e:0x43e
    845a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    845d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8460:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    8463:	75 cd                	jne    0x8432
    8465:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    846a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    846d:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    8472:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    8475:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    8478:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
    847d:	74 53                	je     0x84d2
    847f:	06                   	push   es
    8480:	57                   	push   di
    8481:	9a 26 13 ad 84       	call   0x84ad:0x1326
    8486:	2d 01 00             	sub    ax,0x1
    8489:	71 05                	jno    0x8490
    848b:	9a 3e 04 c5 84       	call   0x84c5:0x43e
    8490:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    8493:	31 c0                	xor    ax,ax
    8495:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    8498:	7f 38                	jg     0x84d2
    849a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    849d:	eb 03                	jmp    0x84a2
    849f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    84a2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    84a5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    84a8:	06                   	push   es
    84a9:	57                   	push   di
    84aa:	9a 53 13 da 85       	call   0x85da:0x1353
    84af:	89 c7                	mov    di,ax
    84b1:	8e c2                	mov    es,dx
    84b3:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    84b8:	74 10                	je     0x84ca
    84ba:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    84bd:	05 01 00             	add    ax,0x1
    84c0:	71 05                	jno    0x84c7
    84c2:	9a 3e 04 cb 85       	call   0x85cb:0x43e
    84c7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    84ca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    84cd:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    84d0:	75 cd                	jne    0x849f
    84d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84d5:	26 8b 85 8a 08       	mov    ax,WORD PTR es:[di+0x88a]
    84da:	3d 00 00             	cmp    ax,0x0
    84dd:	75 0a                	jne    0x84e9
    84df:	06                   	push   es
    84e0:	57                   	push   di
    84e1:	9a 4d 4c f6 84       	call   0x84f6:0x4c4d
    84e6:	e9 d5 00             	jmp    0x85be
    84e9:	3d 0b 00             	cmp    ax,0xb
    84ec:	75 0d                	jne    0x84fb
    84ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84f1:	06                   	push   es
    84f2:	57                   	push   di
    84f3:	9a 51 50 08 85       	call   0x8508:0x5051
    84f8:	e9 c3 00             	jmp    0x85be
    84fb:	3d 0c 00             	cmp    ax,0xc
    84fe:	75 0d                	jne    0x850d
    8500:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8503:	06                   	push   es
    8504:	57                   	push   di
    8505:	9a 76 54 1d 85       	call   0x851d:0x5476
    850a:	e9 b1 00             	jmp    0x85be
    850d:	3d 0d 00             	cmp    ax,0xd
    8510:	75 10                	jne    0x8522
    8512:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8515:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8518:	06                   	push   es
    8519:	57                   	push   di
    851a:	9a ff 58 32 85       	call   0x8532:0x58ff
    851f:	e9 9c 00             	jmp    0x85be
    8522:	3d 15 00             	cmp    ax,0x15
    8525:	75 10                	jne    0x8537
    8527:	ff 76 fc             	push   WORD PTR [bp-0x4]
    852a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    852d:	06                   	push   es
    852e:	57                   	push   di
    852f:	9a 8d 5d 47 85       	call   0x8547:0x5d8d
    8534:	e9 87 00             	jmp    0x85be
    8537:	3d 16 00             	cmp    ax,0x16
    853a:	75 0f                	jne    0x854b
    853c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    853f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8542:	06                   	push   es
    8543:	57                   	push   di
    8544:	9a 4d 62 5b 85       	call   0x855b:0x624d
    8549:	eb 73                	jmp    0x85be
    854b:	3d 1f 00             	cmp    ax,0x1f
    854e:	75 0f                	jne    0x855f
    8550:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8553:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8556:	06                   	push   es
    8557:	57                   	push   di
    8558:	9a ee 66 6f 85       	call   0x856f:0x66ee
    855d:	eb 5f                	jmp    0x85be
    855f:	3d 20 00             	cmp    ax,0x20
    8562:	75 0f                	jne    0x8573
    8564:	ff 76 fc             	push   WORD PTR [bp-0x4]
    8567:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    856a:	06                   	push   es
    856b:	57                   	push   di
    856c:	9a e2 6b 80 85       	call   0x8580:0x6be2
    8571:	eb 4b                	jmp    0x85be
    8573:	3d 29 00             	cmp    ax,0x29
    8576:	75 0c                	jne    0x8584
    8578:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    857b:	06                   	push   es
    857c:	57                   	push   di
    857d:	9a 9f 70 91 85       	call   0x8591:0x709f
    8582:	eb 3a                	jmp    0x85be
    8584:	3d 2a 00             	cmp    ax,0x2a
    8587:	75 0c                	jne    0x8595
    8589:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    858c:	06                   	push   es
    858d:	57                   	push   di
    858e:	9a 5c 74 a2 85       	call   0x85a2:0x745c
    8593:	eb 29                	jmp    0x85be
    8595:	3d 2b 00             	cmp    ax,0x2b
    8598:	75 0c                	jne    0x85a6
    859a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    859d:	06                   	push   es
    859e:	57                   	push   di
    859f:	9a ab 78 b3 85       	call   0x85b3:0x78ab
    85a4:	eb 18                	jmp    0x85be
    85a6:	3d 05 00             	cmp    ax,0x5
    85a9:	75 0c                	jne    0x85b7
    85ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    85ae:	06                   	push   es
    85af:	57                   	push   di
    85b0:	9a b1 4b 72 86       	call   0x8672:0x4bb1
    85b5:	eb 07                	jmp    0x85be
    85b7:	6a 30                	push   0x30
    85b9:	9a ff ff 00 00       	call   0x0:0xffff
    85be:	c9                   	leave
    85bf:	ca 04 00             	retf   0x4
    85c2:	55                   	push   bp
    85c3:	89 e5                	mov    bp,sp
    85c5:	b8 0c 00             	mov    ax,0xc
    85c8:	9a 44 04 e1 85       	call   0x85e1:0x444
    85cd:	83 ec 0c             	sub    sp,0xc
    85d0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    85d3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    85d6:	bf 94 00             	mov    di,0x94
    85d9:	b8 f4 85             	mov    ax,0x85f4
    85dc:	50                   	push   ax
    85dd:	57                   	push   di
    85de:	9a 73 22 1d 86       	call   0x861d:0x2273
    85e3:	89 c7                	mov    di,ax
    85e5:	8e c2                	mov    es,dx
    85e7:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    85ea:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    85ed:	6a 01                	push   0x1
    85ef:	06                   	push   es
    85f0:	57                   	push   di
    85f1:	9a 75 12 13 86       	call   0x8613:0x1275
    85f6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    85f9:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    85fe:	74 6a                	je     0x866a
    8600:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8603:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    8608:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    860b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    860e:	06                   	push   es
    860f:	57                   	push   di
    8610:	9a 26 13 3c 86       	call   0x863c:0x1326
    8615:	2d 01 00             	sub    ax,0x1
    8618:	71 05                	jno    0x861f
    861a:	9a 3e 04 81 86       	call   0x8681:0x43e
    861f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    8622:	31 c0                	xor    ax,ax
    8624:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    8627:	7f 41                	jg     0x866a
    8629:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    862c:	eb 03                	jmp    0x8631
    862e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    8631:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8634:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    8637:	06                   	push   es
    8638:	57                   	push   di
    8639:	9a 53 13 55 86       	call   0x8655:0x1353
    863e:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    8641:	75 05                	jne    0x8648
    8643:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    8646:	74 1a                	je     0x8662
    8648:	6a 00                	push   0x0
    864a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    864d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    8650:	06                   	push   es
    8651:	57                   	push   di
    8652:	9a 53 13 60 86       	call   0x8660:0x1353
    8657:	89 c7                	mov    di,ax
    8659:	8e c2                	mov    es,dx
    865b:	06                   	push   es
    865c:	57                   	push   di
    865d:	9a 75 12 90 86       	call   0x8690:0x1275
    8662:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8665:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    8668:	75 c4                	jne    0x862e
    866a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    866d:	06                   	push   es
    866e:	57                   	push   di
    866f:	9a 7d 83 28 87       	call   0x8728:0x837d
    8674:	c9                   	leave
    8675:	ca 08 00             	retf   0x8
    8678:	55                   	push   bp
    8679:	89 e5                	mov    bp,sp
    867b:	b8 0c 00             	mov    ax,0xc
    867e:	9a 44 04 97 86       	call   0x8697:0x444
    8683:	83 ec 0c             	sub    sp,0xc
    8686:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8689:	ff 76 0a             	push   WORD PTR [bp+0xa]
    868c:	bf 94 00             	mov    di,0x94
    868f:	b8 aa 86             	mov    ax,0x86aa
    8692:	50                   	push   ax
    8693:	57                   	push   di
    8694:	9a 73 22 d3 86       	call   0x86d3:0x2273
    8699:	89 c7                	mov    di,ax
    869b:	8e c2                	mov    es,dx
    869d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    86a0:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    86a3:	6a 01                	push   0x1
    86a5:	06                   	push   es
    86a6:	57                   	push   di
    86a7:	9a 75 12 c9 86       	call   0x86c9:0x1275
    86ac:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    86af:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    86b4:	74 6a                	je     0x8720
    86b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86b9:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    86be:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    86c1:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    86c4:	06                   	push   es
    86c5:	57                   	push   di
    86c6:	9a 26 13 f2 86       	call   0x86f2:0x1326
    86cb:	2d 01 00             	sub    ax,0x1
    86ce:	71 05                	jno    0x86d5
    86d0:	9a 3e 04 37 87       	call   0x8737:0x43e
    86d5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    86d8:	31 c0                	xor    ax,ax
    86da:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    86dd:	7f 41                	jg     0x8720
    86df:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    86e2:	eb 03                	jmp    0x86e7
    86e4:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    86e7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    86ea:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    86ed:	06                   	push   es
    86ee:	57                   	push   di
    86ef:	9a 53 13 0b 87       	call   0x870b:0x1353
    86f4:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    86f7:	75 05                	jne    0x86fe
    86f9:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    86fc:	74 1a                	je     0x8718
    86fe:	6a 00                	push   0x0
    8700:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8703:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    8706:	06                   	push   es
    8707:	57                   	push   di
    8708:	9a 53 13 16 87       	call   0x8716:0x1353
    870d:	89 c7                	mov    di,ax
    870f:	8e c2                	mov    es,dx
    8711:	06                   	push   es
    8712:	57                   	push   di
    8713:	9a 75 12 46 87       	call   0x8746:0x1275
    8718:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    871b:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    871e:	75 c4                	jne    0x86e4
    8720:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8723:	06                   	push   es
    8724:	57                   	push   di
    8725:	9a 7d 83 de 87       	call   0x87de:0x837d
    872a:	c9                   	leave
    872b:	ca 08 00             	retf   0x8
    872e:	55                   	push   bp
    872f:	89 e5                	mov    bp,sp
    8731:	b8 0c 00             	mov    ax,0xc
    8734:	9a 44 04 4d 87       	call   0x874d:0x444
    8739:	83 ec 0c             	sub    sp,0xc
    873c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    873f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8742:	bf 94 00             	mov    di,0x94
    8745:	b8 60 87             	mov    ax,0x8760
    8748:	50                   	push   ax
    8749:	57                   	push   di
    874a:	9a 73 22 89 87       	call   0x8789:0x2273
    874f:	89 c7                	mov    di,ax
    8751:	8e c2                	mov    es,dx
    8753:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    8756:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    8759:	6a 01                	push   0x1
    875b:	06                   	push   es
    875c:	57                   	push   di
    875d:	9a 75 12 7f 87       	call   0x877f:0x1275
    8762:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    8765:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    876a:	74 6a                	je     0x87d6
    876c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    876f:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    8774:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    8777:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    877a:	06                   	push   es
    877b:	57                   	push   di
    877c:	9a 26 13 a8 87       	call   0x87a8:0x1326
    8781:	2d 01 00             	sub    ax,0x1
    8784:	71 05                	jno    0x878b
    8786:	9a 3e 04 f5 87       	call   0x87f5:0x43e
    878b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    878e:	31 c0                	xor    ax,ax
    8790:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    8793:	7f 41                	jg     0x87d6
    8795:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8798:	eb 03                	jmp    0x879d
    879a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    879d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    87a0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    87a3:	06                   	push   es
    87a4:	57                   	push   di
    87a5:	9a 53 13 c1 87       	call   0x87c1:0x1353
    87aa:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    87ad:	75 05                	jne    0x87b4
    87af:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    87b2:	74 1a                	je     0x87ce
    87b4:	6a 00                	push   0x0
    87b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    87b9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    87bc:	06                   	push   es
    87bd:	57                   	push   di
    87be:	9a 53 13 cc 87       	call   0x87cc:0x1353
    87c3:	89 c7                	mov    di,ax
    87c5:	8e c2                	mov    es,dx
    87c7:	06                   	push   es
    87c8:	57                   	push   di
    87c9:	9a 75 12 04 88       	call   0x8804:0x1275
    87ce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    87d1:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    87d4:	75 c4                	jne    0x879a
    87d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    87d9:	06                   	push   es
    87da:	57                   	push   di
    87db:	9a 7d 83 f9 8a       	call   0x8af9:0x837d
    87e0:	c9                   	leave
    87e1:	ca 08 00             	retf   0x8
    87e4:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    87e8:	ff                   	(bad)
    87e9:	7f 00                	jg     0x87eb
    87eb:	00 55 89             	add    BYTE PTR [di-0x77],dl
    87ee:	e5 b8                	in     ax,0xb8
    87f0:	08 00                	or     BYTE PTR [bx+si],al
    87f2:	9a 44 04 0b 88       	call   0x880b:0x444
    87f7:	83 ec 08             	sub    sp,0x8
    87fa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    87fd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8800:	bf 94 00             	mov    di,0x94
    8803:	b8 21 88             	mov    ax,0x8821
    8806:	50                   	push   ax
    8807:	57                   	push   di
    8808:	9a 73 22 46 88       	call   0x8846:0x2273
    880d:	89 c7                	mov    di,ax
    880f:	8e c2                	mov    es,dx
    8811:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    8816:	b0 00                	mov    al,0x0
    8818:	75 01                	jne    0x881b
    881a:	40                   	inc    ax
    881b:	50                   	push   ax
    881c:	06                   	push   es
    881d:	57                   	push   di
    881e:	9a 75 12 7e 88       	call   0x887e:0x1275
    8823:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8826:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    882b:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    882e:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    8831:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    8836:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    883b:	2d 01 00             	sub    ax,0x1
    883e:	83 da 00             	sbb    dx,0x0
    8841:	71 05                	jno    0x8848
    8843:	9a 3e 04 4e 88       	call   0x884e:0x43e
    8848:	bf e4 87             	mov    di,0x87e4
    884b:	9a 16 04 6e 88       	call   0x886e:0x416
    8850:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    8853:	b8 01 00             	mov    ax,0x1
    8856:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    8859:	7f 61                	jg     0x88bc
    885b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    885e:	eb 03                	jmp    0x8863
    8860:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    8863:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    8866:	2d 01 00             	sub    ax,0x1
    8869:	71 05                	jno    0x8870
    886b:	9a 3e 04 eb 88       	call   0x88eb:0x43e
    8870:	50                   	push   ax
    8871:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8874:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    8879:	06                   	push   es
    887a:	57                   	push   di
    887b:	9a 53 13 c0 8a       	call   0x8ac0:0x1353
    8880:	89 c7                	mov    di,ax
    8882:	8e c2                	mov    es,dx
    8884:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    8889:	74 17                	je     0x88a2
    888b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    888e:	99                   	cwd
    888f:	52                   	push   dx
    8890:	50                   	push   ax
    8891:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    8894:	26 ff b5 fa 00       	push   WORD PTR es:[di+0xfa]
    8899:	06                   	push   es
    889a:	57                   	push   di
    889b:	9a c9 70 b2 88       	call   0x88b2:0x70c9
    88a0:	eb 12                	jmp    0x88b4
    88a2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    88a5:	99                   	cwd
    88a6:	52                   	push   dx
    88a7:	50                   	push   ax
    88a8:	6a 00                	push   0x0
    88aa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    88ad:	06                   	push   es
    88ae:	57                   	push   di
    88af:	9a c9 70 68 89       	call   0x8968:0x70c9
    88b4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    88b7:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    88ba:	75 a4                	jne    0x8860
    88bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88bf:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    88c4:	06                   	push   es
    88c5:	57                   	push   di
    88c6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    88c9:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    88cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88d0:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
    88d5:	06                   	push   es
    88d6:	57                   	push   di
    88d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    88da:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    88de:	c9                   	leave
    88df:	ca 08 00             	retf   0x8
    88e2:	55                   	push   bp
    88e3:	89 e5                	mov    bp,sp
    88e5:	b8 04 00             	mov    ax,0x4
    88e8:	9a 44 04 58 89       	call   0x8958:0x444
    88ed:	83 ec 04             	sub    sp,0x4
    88f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    88f3:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    88f8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    88fb:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    88fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8901:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    8906:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    890a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    890e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    8911:	06                   	push   es
    8912:	57                   	push   di
    8913:	9a 93 2a 20 89       	call   0x8920:0x2a93
    8918:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    891b:	06                   	push   es
    891c:	57                   	push   di
    891d:	9a 0d 2b a2 89       	call   0x89a2:0x2b0d
    8922:	08 c0                	or     al,al
    8924:	74 44                	je     0x896a
    8926:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    8929:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    892d:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    8931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8934:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    8939:	06                   	push   es
    893a:	57                   	push   di
    893b:	9a eb 1d ca 89       	call   0x89ca:0x1deb
    8940:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    8943:	26 c4 7d 1f          	les    di,DWORD PTR es:[di+0x1f]
    8947:	06                   	push   es
    8948:	57                   	push   di
    8949:	9a cc 11 ff ff       	call   0xffff:0x11cc
    894e:	b9 02 00             	mov    cx,0x2
    8951:	f7 e9                	imul   cx
    8953:	71 05                	jno    0x895a
    8955:	9a 3e 04 77 89       	call   0x8977:0x43e
    895a:	50                   	push   ax
    895b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    895e:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    8963:	06                   	push   es
    8964:	57                   	push   di
    8965:	9a b6 71 ff ff       	call   0xffff:0x71b6
    896a:	c9                   	leave
    896b:	ca 08 00             	retf   0x8
    896e:	55                   	push   bp
    896f:	89 e5                	mov    bp,sp
    8971:	b8 04 00             	mov    ax,0x4
    8974:	9a 44 04 f3 89       	call   0x89f3:0x444
    8979:	83 ec 04             	sub    sp,0x4
    897c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    897f:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    8984:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    8987:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    898a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    898d:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    8992:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    8996:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    899a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    899d:	06                   	push   es
    899e:	57                   	push   di
    899f:	9a 93 2a ac 89       	call   0x89ac:0x2a93
    89a4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    89a7:	06                   	push   es
    89a8:	57                   	push   di
    89a9:	9a 0d 2b ff ff       	call   0xffff:0x2b0d
    89ae:	08 c0                	or     al,al
    89b0:	74 35                	je     0x89e7
    89b2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    89b5:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    89b9:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    89bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89c0:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    89c5:	06                   	push   es
    89c6:	57                   	push   di
    89c7:	9a eb 1d e5 89       	call   0x89e5:0x1deb
    89cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89cf:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    89d4:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    89d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89db:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    89e0:	06                   	push   es
    89e1:	57                   	push   di
    89e2:	9a e1 17 ff ff       	call   0xffff:0x17e1
    89e7:	c9                   	leave
    89e8:	ca 08 00             	retf   0x8
    89eb:	55                   	push   bp
    89ec:	89 e5                	mov    bp,sp
    89ee:	31 c0                	xor    ax,ax
    89f0:	9a 44 04 1b 8a       	call   0x8a1b:0x444
    89f5:	6a 01                	push   0x1
    89f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    89fa:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    89ff:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    8a04:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    8a08:	06                   	push   es
    8a09:	57                   	push   di
    8a0a:	9a b2 77 2c 8a       	call   0x8a2c:0x77b2
    8a0f:	c9                   	leave
    8a10:	ca 08 00             	retf   0x8
    8a13:	55                   	push   bp
    8a14:	89 e5                	mov    bp,sp
    8a16:	31 c0                	xor    ax,ax
    8a18:	9a 44 04 3a 8a       	call   0x8a3a:0x444
    8a1d:	6a 03                	push   0x3
    8a1f:	6a 00                	push   0x0
    8a21:	6a 00                	push   0x0
    8a23:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    8a27:	06                   	push   es
    8a28:	57                   	push   di
    8a29:	9a b2 77 4d 8a       	call   0x8a4d:0x77b2
    8a2e:	c9                   	leave
    8a2f:	ca 08 00             	retf   0x8
    8a32:	55                   	push   bp
    8a33:	89 e5                	mov    bp,sp
    8a35:	31 c0                	xor    ax,ax
    8a37:	9a 44 04 5b 8a       	call   0x8a5b:0x444
    8a3c:	68 05 01             	push   0x105
    8a3f:	bf a0 01             	mov    di,0x1a0
    8a42:	1e                   	push   ds
    8a43:	57                   	push   di
    8a44:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    8a48:	06                   	push   es
    8a49:	57                   	push   di
    8a4a:	9a b2 77 6c 8a       	call   0x8a6c:0x77b2
    8a4f:	c9                   	leave
    8a50:	ca 08 00             	retf   0x8
    8a53:	55                   	push   bp
    8a54:	89 e5                	mov    bp,sp
    8a56:	31 c0                	xor    ax,ax
    8a58:	9a 44 04 7b 8a       	call   0x8a7b:0x444
    8a5d:	6a 04                	push   0x4
    8a5f:	6a 00                	push   0x0
    8a61:	6a 00                	push   0x0
    8a63:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    8a67:	06                   	push   es
    8a68:	57                   	push   di
    8a69:	9a b2 77 89 8a       	call   0x8a89:0x77b2
    8a6e:	c9                   	leave
    8a6f:	ca 08 00             	retf   0x8
    8a72:	55                   	push   bp
    8a73:	89 e5                	mov    bp,sp
    8a75:	b8 04 00             	mov    ax,0x4
    8a78:	9a 44 04 97 8a       	call   0x8a97:0x444
    8a7d:	83 ec 04             	sub    sp,0x4
    8a80:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    8a84:	06                   	push   es
    8a85:	57                   	push   di
    8a86:	9a 45 5d ff ff       	call   0xffff:0x5d45
    8a8b:	c9                   	leave
    8a8c:	ca 08 00             	retf   0x8
    8a8f:	55                   	push   bp
    8a90:	89 e5                	mov    bp,sp
    8a92:	31 c0                	xor    ax,ax
    8a94:	9a 44 04 e9 8a       	call   0x8ae9:0x444
    8a99:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    8a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8a9f:	26 88 85 5c 08       	mov    BYTE PTR es:[di+0x85c],al
    8aa4:	26 c6 85 5d 08 01    	mov    BYTE PTR es:[di+0x85d],0x1
    8aaa:	26 80 bd 5c 08 00    	cmp    BYTE PTR es:[di+0x85c],0x0
    8ab0:	b0 00                	mov    al,0x0
    8ab2:	75 01                	jne    0x8ab5
    8ab4:	40                   	inc    ax
    8ab5:	50                   	push   ax
    8ab6:	26 c4 bd b8 03       	les    di,DWORD PTR es:[di+0x3b8]
    8abb:	06                   	push   es
    8abc:	57                   	push   di
    8abd:	9a 75 12 ff ff       	call   0xffff:0x1275
    8ac2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8ac5:	26 80 bd 5c 08 00    	cmp    BYTE PTR es:[di+0x85c],0x0
    8acb:	b0 00                	mov    al,0x0
    8acd:	75 01                	jne    0x8ad0
    8acf:	40                   	inc    ax
    8ad0:	50                   	push   ax
    8ad1:	26 c4 bd 08 04       	les    di,DWORD PTR es:[di+0x408]
    8ad6:	06                   	push   es
    8ad7:	57                   	push   di
    8ad8:	9a 70 24 ff ff       	call   0xffff:0x2470
    8add:	c9                   	leave
    8ade:	ca 06 00             	retf   0x6
    8ae1:	55                   	push   bp
    8ae2:	89 e5                	mov    bp,sp
    8ae4:	31 c0                	xor    ax,ax
    8ae6:	9a 44 04 07 8b       	call   0x8b07:0x444
    8aeb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8aee:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8af1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8af4:	06                   	push   es
    8af5:	57                   	push   di
    8af6:	9a ff 8a 1d 8b       	call   0x8b1d:0x8aff
    8afb:	c9                   	leave
    8afc:	ca 08 00             	retf   0x8
    8aff:	55                   	push   bp
    8b00:	89 e5                	mov    bp,sp
    8b02:	31 c0                	xor    ax,ax
    8b04:	9a 44 04 ff ff       	call   0xffff:0x444
    8b09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b0c:	26 80 bd 5c 08 00    	cmp    BYTE PTR es:[di+0x85c],0x0
    8b12:	b0 00                	mov    al,0x0
    8b14:	75 01                	jne    0x8b17
    8b16:	40                   	inc    ax
    8b17:	50                   	push   ax
    8b18:	06                   	push   es
    8b19:	57                   	push   di
    8b1a:	9a 8f 8a 4e 8b       	call   0x8b4e:0x8a8f
    8b1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b22:	26 80 bd 5c 08 00    	cmp    BYTE PTR es:[di+0x85c],0x0
    8b28:	75 1c                	jne    0x8b46
    8b2a:	9b 26 dd 85 6e 08    	fld    QWORD PTR es:[di+0x86e]
    8b30:	9b 26 dd 9d 5e 08    	fstp   QWORD PTR es:[di+0x85e]
    8b36:	90                   	nop
    8b37:	9b                   	fwait
    8b38:	9b 26 dd 85 76 08    	fld    QWORD PTR es:[di+0x876]
    8b3e:	9b 26 dd 9d 66 08    	fstp   QWORD PTR es:[di+0x866]
    8b44:	90                   	nop
    8b45:	9b                   	fwait
    8b46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b49:	06                   	push   es
    8b4a:	57                   	push   di
    8b4b:	9a 7d 83 ff ff       	call   0xffff:0x837d
    8b50:	c9                   	leave
    8b51:	ca                   	.byte 0xca
    8b52:	08                   	.byte 0x8
