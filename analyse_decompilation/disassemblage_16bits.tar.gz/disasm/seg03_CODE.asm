; ================================================================
; seg03_CODE  (16242 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	03 00                	add    ax,WORD PTR [bx+si]
       2:	eb 03                	jmp    0x7
       4:	24 02                	and    al,0x2
       6:	aa                   	stos   BYTE PTR es:[di],al
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 fc          	add    BYTE PTR [bp-0x400],bl
       d:	02 fb                	add    bh,bl
       f:	04 fe                	add    al,0xfe
      11:	03 39                	add    di,WORD PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 1a 04 cb       	call   0xcb04:0x1a1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 54 0f             	adc    BYTE PTR [si+0xf],dl
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c cb                	sbb    al,0xcb
      61:	04 e2                	add    al,0xe2
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0b 54 46             	or     dx,WORD PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	54                   	push   sp
      a5:	61                   	popa
      a6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      a9:	73 14                	jae    0xbf
      ab:	00 8a 04 bd          	add    BYTE PTR [bp+si-0x42fc],cl
      af:	00 0a                	add    BYTE PTR [bp+si],cl
      b1:	46                   	inc    si
      b2:	6f                   	outs   dx,WORD PTR ds:[si]
      b3:	72 6d                	jb     0x122
      b5:	43                   	inc    bx
      b6:	72 65                	jb     0x11d
      b8:	61                   	popa
      b9:	74 65                	je     0x120
      bb:	74 05                	je     0xc2
      bd:	cb                   	retf
      be:	00 09                	add    BYTE PTR [bx+di],cl
      c0:	46                   	inc    si
      c1:	6f                   	outs   dx,WORD PTR ds:[si]
      c2:	72 6d                	jb     0x131
      c4:	43                   	inc    bx
      c5:	6c                   	ins    BYTE PTR es:[di],dx
      c6:	6f                   	outs   dx,WORD PTR ds:[si]
      c7:	73 65                	jae    0x12e
      c9:	98                   	cbw
      ca:	05 dc 00             	add    ax,0xdc
      cd:	0c 46                	or     al,0x46
      cf:	65 72 6d             	gs jb  0x13f
      d2:	65 72 31             	gs jb  0x106
      d5:	43                   	inc    bx
      d6:	6c                   	ins    BYTE PTR es:[di],dx
      d7:	69 63 6b b8 05       	imul   sp,WORD PTR [bp+di+0x6b],0x5b8
      dc:	ed                   	in     ax,dx
      dd:	00 0c                	add    BYTE PTR [si],cl
      df:	4f                   	dec    di
      e0:	75 76                	jne    0x158
      e2:	72 69                	jb     0x14d
      e4:	72 31                	jb     0x117
      e6:	43                   	inc    bx
      e7:	6c                   	ins    BYTE PTR es:[di],dx
      e8:	69 63 6b ce 08       	imul   sp,WORD PTR [bp+di+0x6b],0x8ce
      ed:	02 01                	add    al,BYTE PTR [bx+di]
      ef:	10 43 61             	adc    BYTE PTR [bp+di+0x61],al
      f2:	72 61                	jb     0x155
      f4:	63 74 65             	arpl   WORD PTR [si+0x65],si
      f7:	72 65                	jb     0x15e
      f9:	73 31                	jae    0x12c
      fb:	43                   	inc    bx
      fc:	6c                   	ins    BYTE PTR es:[di],dx
      fd:	69 63 6b 20 09       	imul   sp,WORD PTR [bp+di+0x6b],0x920
     102:	13 01                	adc    ax,WORD PTR [bx+di]
     104:	0c 43                	or     al,0x43
     106:	6f                   	outs   dx,WORD PTR ds:[si]
     107:	70 69                	jo     0x172
     109:	65 72 31             	gs jb  0x13d
     10c:	43                   	inc    bx
     10d:	6c                   	ins    BYTE PTR es:[di],dx
     10e:	69 63 6b 69 09       	imul   sp,WORD PTR [bp+di+0x6b],0x969
     113:	23 01                	and    ax,WORD PTR [bx+di]
     115:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
     118:	64 65 78 31          	fs gs js 0x14d
     11c:	43                   	inc    bx
     11d:	6c                   	ins    BYTE PTR es:[di],dx
     11e:	69 63 6b 88 09       	imul   sp,WORD PTR [bp+di+0x6b],0x988
     123:	38 01                	cmp    BYTE PTR [bx+di],al
     125:	10 52 65             	adc    BYTE PTR [bp+si+0x65],dl
     128:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     12b:	72 63                	jb     0x190
     12d:	68 65 72             	push   0x7265
     130:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     133:	69 63 6b a9 09       	imul   sp,WORD PTR [bp+di+0x6b],0x9a9
     138:	50                   	push   ax
     139:	01 13                	add    WORD PTR [bp+di],dx
     13b:	55                   	push   bp
     13c:	74 69                	je     0x1a7
     13e:	6c                   	ins    BYTE PTR es:[di],dx
     13f:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     144:	61                   	popa
     145:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     14a:	6c                   	ins    BYTE PTR es:[di],dx
     14b:	69 63 6b c8 09       	imul   sp,WORD PTR [bp+di+0x6b],0x9c8
     150:	62 01                	bound  ax,DWORD PTR [bx+di]
     152:	0d 41 70             	or     ax,0x7041
     155:	72 6f                	jb     0x1c6
     157:	70 6f                	jo     0x1c8
     159:	73 31                	jae    0x18c
     15b:	43                   	inc    bx
     15c:	6c                   	ins    BYTE PTR es:[di],dx
     15d:	69 63 6b 2e 09       	imul   sp,WORD PTR [bp+di+0x6b],0x92e
     162:	75 01                	jne    0x165
     164:	0e                   	push   cs
     165:	49                   	dec    cx
     166:	6e                   	outs   dx,BYTE PTR ds:[si]
     167:	66 6f                	outs   dx,DWORD PTR ds:[si]
     169:	73 4a                	jae    0x1b5
     16b:	65 75 31             	gs jne 0x19f
     16e:	43                   	inc    bx
     16f:	6c                   	ins    BYTE PTR es:[di],dx
     170:	69 63 6b 41 09       	imul   sp,WORD PTR [bp+di+0x6b],0x941
     175:	85 01                	test   WORD PTR [bx+di],ax
     177:	0b 46 69             	or     ax,WORD PTR [bp+0x69]
     17a:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     17d:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     180:	69 63 6b 36 0a       	imul   sp,WORD PTR [bp+di+0x6b],0xa36
     185:	9f                   	lahf
     186:	01 15                	add    WORD PTR [di],dx
     188:	44                   	inc    sp
     189:	61                   	popa
     18a:	74 61                	je     0x1ed
     18c:	53                   	push   bx
     18d:	6f                   	outs   dx,WORD PTR ds:[si]
     18e:	75 72                	jne    0x202
     190:	63 65 31             	arpl   WORD PTR [di+0x31],sp
     193:	44                   	inc    sp
     194:	61                   	popa
     195:	74 61                	je     0x1f8
     197:	43                   	inc    bx
     198:	68 61 6e             	push   0x6e61
     19b:	67 65 e5 09          	addr32 gs in ax,0x9
     19f:	b0 01                	mov    al,0x1
     1a1:	0c 50                	or     al,0x50
     1a3:	61                   	popa
     1a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     1a5:	65 6c                	gs ins BYTE PTR es:[di],dx
     1a7:	36 52                	ss push dx
     1a9:	65 73 69             	gs jae 0x215
     1ac:	7a 65                	jp     0x213
     1ae:	a2 0e c7             	mov    ds:0xc70e,al
     1b1:	01 12                	add    WORD PTR [bp+si],dx
     1b3:	53                   	push   bx
     1b4:	74 72                	je     0x228
     1b6:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     1bb:	69 64 31 4b 65       	imul   sp,WORD PTR [si+0x31],0x654b
     1c0:	79 44                	jns    0x206
     1c2:	6f                   	outs   dx,WORD PTR ds:[si]
     1c3:	77 6e                	ja     0x233
     1c5:	c3                   	ret
     1c6:	0e                   	push   cs
     1c7:	dc 01                	fadd   QWORD PTR [bx+di]
     1c9:	10 53 74             	adc    BYTE PTR [bp+di+0x74],dl
     1cc:	72 69                	jb     0x237
     1ce:	6e                   	outs   dx,BYTE PTR ds:[si]
     1cf:	67 47                	addr32 inc di
     1d1:	72 69                	jb     0x23c
     1d3:	64 31 4b 65          	xor    WORD PTR fs:[bp+di+0x65],cx
     1d7:	79 55                	jns    0x22e
     1d9:	70 61                	jo     0x23c
     1db:	0b f0                	or     si,ax
     1dd:	01 0f                	add    WORD PTR [bx],cx
     1df:	44                   	inc    sp
     1e0:	42                   	inc    dx
     1e1:	47                   	inc    di
     1e2:	72 69                	jb     0x24d
     1e4:	64 31 43 6f          	xor    WORD PTR fs:[bp+di+0x6f],ax
     1e8:	6c                   	ins    BYTE PTR es:[di],dx
     1e9:	45                   	inc    bp
     1ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     1eb:	74 65                	je     0x252
     1ed:	72 eb                	jb     0x1da
     1ef:	0e                   	push   cs
     1f0:	04 02                	add    al,0x2
     1f2:	0f 53 74 72          	rcpps  xmm6,XMMWORD PTR [si+0x72]
     1f6:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     1fb:	69 64 31 45 78       	imul   sp,WORD PTR [si+0x31],0x7845
     200:	69 74 0a 0f 19       	imul   si,WORD PTR [si+0xa],0x190f
     205:	02 10                	add    dl,BYTE PTR [bx+si]
     207:	53                   	push   bx
     208:	74 72                	je     0x27c
     20a:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     20f:	69 64 31 43 6c       	imul   sp,WORD PTR [si+0x31],0x6c43
     214:	69 63 6b 59 05       	imul   sp,WORD PTR [bp+di+0x6b],0x559
     219:	fa                   	cli
     21a:	03 08                	add    cx,WORD PTR [bx+si]
     21c:	46                   	inc    si
     21d:	6f                   	outs   dx,WORD PTR ds:[si]
     21e:	72 6d                	jb     0x28d
     220:	53                   	push   bx
     221:	68 6f 77             	push   0x776f
     224:	20 00                	and    BYTE PTR [bx+si],al
     226:	b9 03 7c             	mov    cx,0x7c03
     229:	01 00                	add    WORD PTR [bx+si],ax
     22b:	00 07                	add    BYTE PTR [bx],al
     22d:	44                   	inc    sp
     22e:	42                   	inc    dx
     22f:	47                   	inc    di
     230:	72 69                	jb     0x29b
     232:	64 31 80 01 04       	xor    WORD PTR fs:[bx+si+0x401],ax
     237:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     23b:	6e                   	outs   dx,BYTE PTR ds:[si]
     23c:	65 6c                	gs ins BYTE PTR es:[di],dx
     23e:	31 84 01 08          	xor    WORD PTR [si+0x801],ax
     242:	00 0b                	add    BYTE PTR [bp+di],cl
     244:	44                   	inc    sp
     245:	61                   	popa
     246:	74 61                	je     0x2a9
     248:	53                   	push   bx
     249:	6f                   	outs   dx,WORD PTR ds:[si]
     24a:	75 72                	jne    0x2be
     24c:	63 65 31             	arpl   WORD PTR [di+0x31],sp
     24f:	88 01                	mov    BYTE PTR [bx+di],al
     251:	04 00                	add    al,0x0
     253:	06                   	push   es
     254:	50                   	push   ax
     255:	61                   	popa
     256:	6e                   	outs   dx,BYTE PTR ds:[si]
     257:	65 6c                	gs ins BYTE PTR es:[di],dx
     259:	32 8c 01 0c          	xor    cl,BYTE PTR [si+0xc01]
     25d:	00 06 54 61          	add    BYTE PTR ds:0x6154,al
     261:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     264:	31 90 01 10          	xor    WORD PTR [bx+si+0x1001],dx
     268:	00 0b                	add    BYTE PTR [bp+di],cl
     26a:	4f                   	dec    di
     26b:	70 65                	jo     0x2d2
     26d:	6e                   	outs   dx,BYTE PTR ds:[si]
     26e:	44                   	inc    sp
     26f:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     274:	31 94 01 14          	xor    WORD PTR [si+0x1401],dx
     278:	00 09                	add    BYTE PTR [bx+di],cl
     27a:	4d                   	dec    bp
     27b:	61                   	popa
     27c:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     281:	75 31                	jne    0x2b4
     283:	98                   	cbw
     284:	01 18                	add    WORD PTR [bx+si],bx
     286:	00 08                	add    BYTE PTR [bx+si],cl
     288:	46                   	inc    si
     289:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     28e:	72 31                	jb     0x2c1
     290:	9c                   	pushf
     291:	01 18                	add    WORD PTR [bx+si],bx
     293:	00 07                	add    BYTE PTR [bx],al
     295:	4f                   	dec    di
     296:	75 76                	jne    0x30e
     298:	72 69                	jb     0x303
     29a:	72 31                	jb     0x2cd
     29c:	a0 01 18             	mov    al,ds:0x1801
     29f:	00 07                	add    BYTE PTR [bx],al
     2a1:	46                   	inc    si
     2a2:	65 72 6d             	gs jb  0x312
     2a5:	65 72 31             	gs jb  0x2d9
     2a8:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     2a9:	01 18                	add    WORD PTR [bx+si],bx
     2ab:	00 08                	add    BYTE PTR [bx+si],cl
     2ad:	45                   	inc    bp
     2ae:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     2b4:	31 a8 01 18          	xor    WORD PTR [bx+si+0x1801],bp
     2b8:	00 0b                	add    BYTE PTR [bp+di],cl
     2ba:	43                   	inc    bx
     2bb:	61                   	popa
     2bc:	72 61                	jb     0x31f
     2be:	63 74 65             	arpl   WORD PTR [si+0x65],si
     2c1:	72 65                	jb     0x328
     2c3:	73 31                	jae    0x2f6
     2c5:	ac                   	lods   al,BYTE PTR ds:[si]
     2c6:	01 1c                	add    WORD PTR [si],bx
     2c8:	00 0b                	add    BYTE PTR [bp+di],cl
     2ca:	46                   	inc    si
     2cb:	6f                   	outs   dx,WORD PTR ds:[si]
     2cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     2cd:	74 44                	je     0x313
     2cf:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     2d4:	31 b0 01 18          	xor    WORD PTR [bx+si+0x1801],si
     2d8:	00 02                	add    BYTE PTR [bp+si],al
     2da:	4e                   	dec    si
     2db:	31 b4 01 20          	xor    WORD PTR [si+0x2001],si
     2df:	00 05                	add    BYTE PTR [di],al
     2e1:	4d                   	dec    bp
     2e2:	65 6d                	gs ins WORD PTR es:[di],dx
     2e4:	6f                   	outs   dx,WORD PTR ds:[si]
     2e5:	31 b8 01 18          	xor    WORD PTR [bx+si+0x1801],di
     2e9:	00 07                	add    BYTE PTR [bx],al
     2eb:	46                   	inc    si
     2ec:	6f                   	outs   dx,WORD PTR ds:[si]
     2ed:	72 6d                	jb     0x35c
     2ef:	61                   	popa
     2f0:	74 31                	je     0x323
     2f2:	bc 01 18             	mov    sp,0x1801
     2f5:	00 07                	add    BYTE PTR [bx],al
     2f7:	43                   	inc    bx
     2f8:	6f                   	outs   dx,WORD PTR ds:[si]
     2f9:	70 69                	jo     0x364
     2fb:	65 72 31             	gs jb  0x32f
     2fe:	c0 01 18             	rol    BYTE PTR [bx+di],0x18
     301:	00 05                	add    BYTE PTR [di],al
     303:	41                   	inc    cx
     304:	69 64 65 31 c4       	imul   sp,WORD PTR [si+0x65],0xc431
     309:	01 18                	add    WORD PTR [bx+si],bx
     30b:	00 08                	add    BYTE PTR [bx+si],cl
     30d:	41                   	inc    cx
     30e:	70 72                	jo     0x382
     310:	6f                   	outs   dx,WORD PTR ds:[si]
     311:	70 6f                	jo     0x382
     313:	73 31                	jae    0x346
     315:	c8 01 18 00          	enter  0x1801,0x0
     319:	0e                   	push   cs
     31a:	55                   	push   bp
     31b:	74 69                	je     0x386
     31d:	6c                   	ins    BYTE PTR es:[di],dx
     31e:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     323:	61                   	popa
     324:	69 64 65 31 cc       	imul   sp,WORD PTR [si+0x65],0xcc31
     329:	01 18                	add    WORD PTR [bx+si],bx
     32b:	00 0b                	add    BYTE PTR [bp+di],cl
     32d:	52                   	push   dx
     32e:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     332:	72 63                	jb     0x397
     334:	68 65 72             	push   0x7265
     337:	31 d0                	xor    ax,dx
     339:	01 18                	add    WORD PTR [bx+si],bx
     33b:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     33f:	64 65 78 31          	fs gs js 0x374
     343:	d4 01                	aam    0x1
     345:	18 00                	sbb    BYTE PTR [bx+si],al
     347:	09 49 6e             	or     WORD PTR [bx+di+0x6e],cx
     34a:	66 6f                	outs   dx,DWORD PTR ds:[si]
     34c:	73 4a                	jae    0x398
     34e:	65 75 31             	gs jne 0x382
     351:	d8 01                	fadd   DWORD PTR [bx+di]
     353:	18 00                	sbb    BYTE PTR [bx+si],al
     355:	06                   	push   es
     356:	46                   	inc    si
     357:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     35c:	dc 01                	fadd   QWORD PTR [bx+di]
     35e:	18 00                	sbb    BYTE PTR [bx+si],al
     360:	02 4e 32             	add    cl,BYTE PTR [bp+0x32]
     363:	e0 01                	loopne 0x366
     365:	18 00                	sbb    BYTE PTR [bx+si],al
     367:	02 4e 33             	add    cl,BYTE PTR [bp+0x33]
     36a:	e4 01                	in     al,0x1
     36c:	24 00                	and    al,0x0
     36e:	0b 53 74             	or     dx,WORD PTR [bp+di+0x74]
     371:	72 69                	jb     0x3dc
     373:	6e                   	outs   dx,BYTE PTR ds:[si]
     374:	67 47                	addr32 inc di
     376:	72 69                	jb     0x3e1
     378:	64 31 e8             	fs xor ax,bp
     37b:	01 04                	add    WORD PTR [si],ax
     37d:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     381:	6e                   	outs   dx,BYTE PTR ds:[si]
     382:	65 6c                	gs ins BYTE PTR es:[di],dx
     384:	35 ec 01             	xor    ax,0x1ec
     387:	28 00                	sub    BYTE PTR [bx+si],al
     389:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     38c:	4e                   	dec    si
     38d:	61                   	popa
     38e:	76 69                	jbe    0x3f9
     390:	67 61                	addr32 popa
     392:	74 6f                	je     0x403
     394:	72 f0                	jb     0x386
     396:	01 04                	add    WORD PTR [si],ax
     398:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     39c:	6e                   	outs   dx,BYTE PTR ds:[si]
     39d:	65 6c                	gs ins BYTE PTR es:[di],dx
     39f:	36 f4                	ss hlt
     3a1:	01 2c                	add    WORD PTR [si],bp
     3a3:	00 05                	add    BYTE PTR [di],al
     3a5:	45                   	inc    bp
     3a6:	64 69 74 31 f8 01    	imul   si,WORD PTR fs:[si+0x31],0x1f8
     3ac:	04 00                	add    al,0x0
     3ae:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     3b1:	6e                   	outs   dx,BYTE PTR ds:[si]
     3b2:	65 6c                	gs ins BYTE PTR es:[di],dx
     3b4:	4c                   	dec    sp
     3b5:	4f                   	dec    di
     3b6:	55                   	push   bp
     3b7:	50                   	push   ax
     3b8:	45                   	inc    bp
     3b9:	0c 00                	or     al,0x0
     3bb:	48                   	dec    ax
     3bc:	03 0d                	add    cx,WORD PTR [di]
     3be:	0b ad 0d b0          	or     bp,WORD PTR [di-0x4ff3]
     3c2:	10 c8                	adc    al,cl
     3c4:	08 8b 05 38          	or     BYTE PTR [bp+di+0x3805],cl
     3c8:	01 36 06 c1          	add    WORD PTR ds:0xc106,si
     3cc:	02 d9                	add    bl,cl
     3ce:	03 ef                	add    bp,di
     3d0:	02 d5                	add    dl,ch
     3d2:	03 94 00 53          	add    dx,WORD PTR [si+0x5300]
     3d6:	05 de 05             	add    ax,0x5de
     3d9:	2b 05                	sub    ax,WORD PTR [di]
     3db:	91                   	xchg   cx,ax
     3dc:	12 e9                	adc    ch,cl
     3de:	03 4d 0e             	add    cx,WORD PTR [di+0xe]
     3e1:	c5 06 25 12          	lds    ax,DWORD PTR ds:0x1225
     3e5:	ff                   	(bad)
     3e6:	ff 90 0b b4          	call   WORD PTR [bx+si-0x4bf5]
     3ea:	10 07                	adc    BYTE PTR [bx],al
     3ec:	0b 54 46             	or     dx,WORD PTR [si+0x46]
     3ef:	6f                   	outs   dx,WORD PTR ds:[si]
     3f0:	72 6d                	jb     0x45f
     3f2:	54                   	push   sp
     3f3:	61                   	popa
     3f4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3f7:	73 22                	jae    0x41b
     3f9:	00 0f                	add    BYTE PTR [bx],cl
     3fb:	04 7b                	add    al,0x7b
     3fd:	06                   	push   es
     3fe:	35 04 38             	xor    ax,0x3804
     401:	00 06 54 61          	add    BYTE PTR ds:0x6154,al
     405:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     408:	73 00                	jae    0x40a
     40a:	00 00                	add    BYTE PTR [bx+si],al
     40c:	00 6d 04             	add    BYTE PTR [di+0x4],ch
     40f:	2e 04 55             	cs add al,0x55
     412:	89 e5                	mov    bp,sp
     414:	b8 04 00             	mov    ax,0x4
     417:	9a 44 04 93 04       	call   0x493:0x444
     41c:	83 ec 04             	sub    sp,0x4
     41f:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     423:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     427:	b0 01                	mov    al,0x1
     429:	50                   	push   ax
     42a:	b8 22 00             	mov    ax,0x22
     42d:	ba c8 08             	mov    dx,0x8c8
     430:	52                   	push   dx
     431:	50                   	push   ax
     432:	9a 53 25 55 04       	call   0x455:0x2553
     437:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     43a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     43d:	b8 0b 04             	mov    ax,0x40b
     440:	0e                   	push   cs
     441:	50                   	push   ax
     442:	55                   	push   bp
     443:	ff 36 58 18          	push   WORD PTR ds:0x1858
     447:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     44b:	6a 02                	push   0x2
     44d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     450:	06                   	push   es
     451:	57                   	push   di
     452:	9a 14 3a 5f 04       	call   0x45f:0x3a14
     457:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     45a:	06                   	push   es
     45b:	57                   	push   di
     45c:	9a 45 5d 75 04       	call   0x475:0x5d45
     461:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     465:	83 c4 06             	add    sp,0x6
     468:	b8 78 04             	mov    ax,0x478
     46b:	0e                   	push   cs
     46c:	50                   	push   ax
     46d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     470:	06                   	push   es
     471:	57                   	push   di
     472:	9a 1d 5f f1 04       	call   0x4f1:0x5f1d
     477:	cb                   	retf
     478:	c9                   	leave
     479:	cb                   	retf
     47a:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     47d:	6d                   	ins    WORD PTR es:[di],dx
     47e:	73 74                	jae    0x4f4
     480:	72 61                	jb     0x4e3
     482:	74 20                	je     0x4a4
     484:	2d 20 03             	sub    ax,0x320
     487:	20 2d                	and    BYTE PTR [di],ch
     489:	20 55 89             	and    BYTE PTR [di-0x77],dl
     48c:	e5 b8                	in     ax,0xb8
     48e:	00 02                	add    BYTE PTR [bp+si],al
     490:	9a 44 04 a7 04       	call   0x4a7:0x444
     495:	81 ec 00 02          	sub    sp,0x200
     499:	8d be 00 ff          	lea    di,[bp-0x100]
     49d:	16                   	push   ss
     49e:	57                   	push   di
     49f:	bf 7a 04             	mov    di,0x47a
     4a2:	0e                   	push   cs
     4a3:	57                   	push   di
     4a4:	9a cd 17 b1 04       	call   0x4b1:0x17cd
     4a9:	bf fa 1d             	mov    di,0x1dfa
     4ac:	1e                   	push   ds
     4ad:	57                   	push   di
     4ae:	9a 4c 18 bb 04       	call   0x4bb:0x184c
     4b3:	bf 86 04             	mov    di,0x486
     4b6:	0e                   	push   cs
     4b7:	57                   	push   di
     4b8:	9a 4c 18 d0 04       	call   0x4d0:0x184c
     4bd:	8d be 00 fe          	lea    di,[bp-0x200]
     4c1:	16                   	push   ss
     4c2:	57                   	push   di
     4c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     4c6:	06                   	push   es
     4c7:	57                   	push   di
     4c8:	9a 53 1d da 04       	call   0x4da:0x1d53
     4cd:	9a 4c 18 07 05       	call   0x507:0x184c
     4d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     4d5:	06                   	push   es
     4d6:	57                   	push   di
     4d7:	9a 8c 1d 5f 06       	call   0x65f:0x1d8c
     4dc:	8d be 00 fe          	lea    di,[bp-0x200]
     4e0:	16                   	push   ss
     4e1:	57                   	push   di
     4e2:	8d be 00 ff          	lea    di,[bp-0x100]
     4e6:	16                   	push   ss
     4e7:	57                   	push   di
     4e8:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     4ec:	06                   	push   es
     4ed:	57                   	push   di
     4ee:	9a d3 77 6e 05       	call   0x56e:0x77d3
     4f3:	9a 6e 0b ff 05       	call   0x5ff:0xb6e
     4f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     4fb:	81 c7 fc 01          	add    di,0x1fc
     4ff:	06                   	push   es
     500:	57                   	push   di
     501:	68 ff 00             	push   0xff
     504:	9a e7 17 61 05       	call   0x561:0x17e7
     509:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     50c:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     511:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     514:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     517:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
     51c:	74 11                	je     0x52f
     51e:	bf fa 19             	mov    di,0x19fa
     521:	1e                   	push   ds
     522:	57                   	push   di
     523:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     526:	06                   	push   es
     527:	57                   	push   di
     528:	9a 19 28 40 05       	call   0x540:0x2819
     52d:	eb 13                	jmp    0x542
     52f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     532:	81 c7 fc 01          	add    di,0x1fc
     536:	06                   	push   es
     537:	57                   	push   di
     538:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     53b:	06                   	push   es
     53c:	57                   	push   di
     53d:	9a 19 28 09 06       	call   0x609:0x2819
     542:	a0 4a 01             	mov    al,ds:0x14a
     545:	50                   	push   ax
     546:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     549:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
     54e:	06                   	push   es
     54f:	57                   	push   di
     550:	9a 9b 12 a7 08       	call   0x8a7:0x129b
     555:	c9                   	leave
     556:	ca 08 00             	retf   0x8
     559:	55                   	push   bp
     55a:	89 e5                	mov    bp,sp
     55c:	31 c0                	xor    ax,ax
     55e:	9a 44 04 7c 05       	call   0x57c:0x444
     563:	6a fe                	push   0xfffe
     565:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     569:	06                   	push   es
     56a:	57                   	push   di
     56b:	9a a9 63 aa 05       	call   0x5aa:0x63a9
     570:	c9                   	leave
     571:	ca 08 00             	retf   0x8
     574:	55                   	push   bp
     575:	89 e5                	mov    bp,sp
     577:	31 c0                	xor    ax,ax
     579:	9a 44 04 a0 05       	call   0x5a0:0x444
     57e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     581:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     586:	06                   	push   es
     587:	57                   	push   di
     588:	9a d2 31 1e 06       	call   0x61e:0x31d2
     58d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     590:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
     594:	c9                   	leave
     595:	ca 0c 00             	retf   0xc
     598:	55                   	push   bp
     599:	89 e5                	mov    bp,sp
     59b:	31 c0                	xor    ax,ax
     59d:	9a 44 04 c1 05       	call   0x5c1:0x444
     5a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5a5:	06                   	push   es
     5a6:	57                   	push   di
     5a7:	9a 56 55 63 09       	call   0x963:0x5556
     5ac:	c9                   	leave
     5ad:	ca 08 00             	retf   0x8
     5b0:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     5b4:	ff                   	(bad)
     5b5:	7f 00                	jg     0x5b7
     5b7:	00 55 89             	add    BYTE PTR [di-0x77],dl
     5ba:	e5 b8                	in     ax,0xb8
     5bc:	12 01                	adc    al,BYTE PTR [bx+di]
     5be:	9a 44 04 b8 06       	call   0x6b8:0x444
     5c3:	81 ec 12 01          	sub    sp,0x112
     5c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5ca:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     5cf:	06                   	push   es
     5d0:	57                   	push   di
     5d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
     5d4:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     5d8:	08 c0                	or     al,al
     5da:	75 03                	jne    0x5df
     5dc:	e9 eb 02             	jmp    0x8ca
     5df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5e2:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     5e7:	89 7e f4             	mov    WORD PTR [bp-0xc],di
     5ea:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
     5ed:	8d be f4 fe          	lea    di,[bp-0x10c]
     5f1:	16                   	push   ss
     5f2:	57                   	push   di
     5f3:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     5f6:	81 c7 3b 00          	add    di,0x3b
     5fa:	06                   	push   es
     5fb:	57                   	push   di
     5fc:	9a 6e 0b 28 13       	call   0x1328:0xb6e
     601:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     604:	06                   	push   es
     605:	57                   	push   di
     606:	9a 19 28 ed 08       	call   0x8ed:0x2819
     60b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     60e:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     613:	89 7e f4             	mov    WORD PTR [bp-0xc],di
     616:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
     619:	06                   	push   es
     61a:	57                   	push   di
     61b:	9a d2 31 69 06       	call   0x669:0x31d2
     620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     623:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     628:	81 c7 3b 00          	add    di,0x3b
     62c:	06                   	push   es
     62d:	57                   	push   di
     62e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     631:	06                   	push   es
     632:	57                   	push   di
     633:	9a 17 30 42 06       	call   0x642:0x3017
     638:	6a 01                	push   0x1
     63a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     63d:	06                   	push   es
     63e:	57                   	push   di
     63f:	9a fb 2f 4e 06       	call   0x64e:0x2ffb
     644:	6a 00                	push   0x0
     646:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     649:	06                   	push   es
     64a:	57                   	push   di
     64b:	9a d2 2e c4 10       	call   0x10c4:0x2ed2
     650:	6a 01                	push   0x1
     652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     655:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     65a:	06                   	push   es
     65b:	57                   	push   di
     65c:	9a 77 1c 81 06       	call   0x681:0x1c77
     661:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     664:	06                   	push   es
     665:	57                   	push   di
     666:	9a bf 31 ae 06       	call   0x6ae:0x31bf
     66b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     66e:	81 c7 84 01          	add    di,0x184
     672:	06                   	push   es
     673:	57                   	push   di
     674:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     677:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
     67c:	06                   	push   es
     67d:	57                   	push   di
     67e:	9a 8c 1d 98 06       	call   0x698:0x1d8c
     683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     686:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
     68b:	89 7e f0             	mov    WORD PTR [bp-0x10],di
     68e:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
     691:	6a 01                	push   0x1
     693:	06                   	push   es
     694:	57                   	push   di
     695:	9a 77 1c a4 06       	call   0x6a4:0x1c77
     69a:	6a 01                	push   0x1
     69c:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     69f:	06                   	push   es
     6a0:	57                   	push   di
     6a1:	9a b8 1c 89 08       	call   0x889:0x1cb8
     6a6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     6a9:	06                   	push   es
     6aa:	57                   	push   di
     6ab:	9a af 3d a8 07       	call   0x7a8:0x3daf
     6b0:	05 01 00             	add    ax,0x1
     6b3:	71 05                	jno    0x6ba
     6b5:	9a 3e 04 f4 06       	call   0x6f4:0x43e
     6ba:	99                   	cwd
     6bb:	52                   	push   dx
     6bc:	50                   	push   ax
     6bd:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     6c0:	06                   	push   es
     6c1:	57                   	push   di
     6c2:	9a 1b 70 07 07       	call   0x707:0x701b
     6c7:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     6ca:	26 83 bd e8 00 00    	cmp    WORD PTR es:[di+0xe8],0x0
     6d0:	7f 0a                	jg     0x6dc
     6d2:	7c 37                	jl     0x70b
     6d4:	26 83 bd e6 00 00    	cmp    WORD PTR es:[di+0xe6],0x0
     6da:	76 2f                	jbe    0x70b
     6dc:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     6df:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
     6e4:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
     6e9:	2d 01 00             	sub    ax,0x1
     6ec:	83 da 00             	sbb    dx,0x0
     6ef:	71 05                	jno    0x6f6
     6f1:	9a 3e 04 fc 06       	call   0x6fc:0x43e
     6f6:	bf b0 05             	mov    di,0x5b0
     6f9:	9a 16 04 42 07       	call   0x742:0x416
     6fe:	50                   	push   ax
     6ff:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     702:	06                   	push   es
     703:	57                   	push   di
     704:	9a 32 72 15 07       	call   0x715:0x7232
     709:	eb 0c                	jmp    0x717
     70b:	6a 00                	push   0x0
     70d:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     710:	06                   	push   es
     711:	57                   	push   di
     712:	9a 32 72 23 07       	call   0x723:0x7232
     717:	6a 00                	push   0x0
     719:	6a 02                	push   0x2
     71b:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     71e:	06                   	push   es
     71f:	57                   	push   di
     720:	9a 26 74 7b 07       	call   0x77b:0x7426
     725:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
     72a:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     72d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
     732:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
     737:	2d 01 00             	sub    ax,0x1
     73a:	83 da 00             	sbb    dx,0x0
     73d:	71 05                	jno    0x744
     73f:	9a 3e 04 4a 07       	call   0x74a:0x43e
     744:	bf b0 05             	mov    di,0x5b0
     747:	9a 16 04 06 08       	call   0x806:0x416
     74c:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
     74f:	31 c0                	xor    ax,ax
     751:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
     754:	7e 03                	jle    0x759
     756:	e9 c7 00             	jmp    0x820
     759:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     75c:	eb 03                	jmp    0x761
     75e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     761:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     764:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     767:	26 3b 85 fe 00       	cmp    ax,WORD PTR es:[di+0xfe]
     76c:	7d 11                	jge    0x77f
     76e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     771:	99                   	cwd
     772:	52                   	push   dx
     773:	50                   	push   ax
     774:	6a 40                	push   0x40
     776:	06                   	push   es
     777:	57                   	push   di
     778:	9a c9 70 90 07       	call   0x790:0x70c9
     77d:	eb 13                	jmp    0x792
     77f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     782:	99                   	cwd
     783:	52                   	push   dx
     784:	50                   	push   ax
     785:	68 80 00             	push   0x80
     788:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     78b:	06                   	push   es
     78c:	57                   	push   di
     78d:	9a c9 70 bd 07       	call   0x7bd:0x70c9
     792:	ff 76 fe             	push   WORD PTR [bp-0x2]
     795:	6a 00                	push   0x0
     797:	8d be ee fe          	lea    di,[bp-0x112]
     79b:	16                   	push   ss
     79c:	57                   	push   di
     79d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     7a0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     7a3:	06                   	push   es
     7a4:	57                   	push   di
     7a5:	9a 4b 3b b3 07       	call   0x7b3:0x3b4b
     7aa:	89 c7                	mov    di,ax
     7ac:	8e c2                	mov    es,dx
     7ae:	06                   	push   es
     7af:	57                   	push   di
     7b0:	9a 1f 69 d5 07       	call   0x7d5:0x691f
     7b5:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     7b8:	06                   	push   es
     7b9:	57                   	push   di
     7ba:	9a 08 9b ec 07       	call   0x7ec:0x9b08
     7bf:	ff 76 fe             	push   WORD PTR [bp-0x2]
     7c2:	6a 01                	push   0x1
     7c4:	8d be ee fe          	lea    di,[bp-0x112]
     7c8:	16                   	push   ss
     7c9:	57                   	push   di
     7ca:	ff 76 fe             	push   WORD PTR [bp-0x2]
     7cd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     7d0:	06                   	push   es
     7d1:	57                   	push   di
     7d2:	9a 4b 3b 60 0a       	call   0xa60:0x3b4b
     7d7:	89 c7                	mov    di,ax
     7d9:	8e c2                	mov    es,dx
     7db:	06                   	push   es
     7dc:	57                   	push   di
     7dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
     7e0:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
     7e4:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     7e7:	06                   	push   es
     7e8:	57                   	push   di
     7e9:	9a 08 9b fc 07       	call   0x7fc:0x9b08
     7ee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     7f1:	99                   	cwd
     7f2:	52                   	push   dx
     7f3:	50                   	push   ax
     7f4:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     7f7:	06                   	push   es
     7f8:	57                   	push   di
     7f9:	9a 30 6e 67 08       	call   0x867:0x6e30
     7fe:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
     801:	71 05                	jno    0x808
     803:	9a 3e 04 10 08       	call   0x810:0x43e
     808:	05 01 00             	add    ax,0x1
     80b:	71 05                	jno    0x812
     80d:	9a 3e 04 3d 08       	call   0x83d:0x43e
     812:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     815:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     818:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
     81b:	74 03                	je     0x820
     81d:	e9 3e ff             	jmp    0x75e
     820:	c7 46 f8 02 00       	mov    WORD PTR [bp-0x8],0x2
     825:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     828:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
     82d:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
     832:	2d 01 00             	sub    ax,0x1
     835:	83 da 00             	sbb    dx,0x0
     838:	71 05                	jno    0x83f
     83a:	9a 3e 04 45 08       	call   0x845:0x43e
     83f:	bf b0 05             	mov    di,0x5b0
     842:	9a 16 04 71 08       	call   0x871:0x416
     847:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
     84a:	31 c0                	xor    ax,ax
     84c:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
     84f:	7f 2d                	jg     0x87e
     851:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     854:	eb 03                	jmp    0x859
     856:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     859:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     85c:	99                   	cwd
     85d:	52                   	push   dx
     85e:	50                   	push   ax
     85f:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     862:	06                   	push   es
     863:	57                   	push   di
     864:	9a 8b 6e c6 0a       	call   0xac6:0x6e8b
     869:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
     86c:	71 05                	jno    0x873
     86e:	9a 3e 04 d6 08       	call   0x8d6:0x43e
     873:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     876:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     879:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
     87c:	75 d8                	jne    0x856
     87e:	ff 76 fa             	push   WORD PTR [bp-0x6]
     881:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     884:	06                   	push   es
     885:	57                   	push   di
     886:	9a bf 17 96 08       	call   0x896:0x17bf
     88b:	ff 76 f8             	push   WORD PTR [bp-0x8]
     88e:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
     891:	06                   	push   es
     892:	57                   	push   di
     893:	9a e1 17 1a 09       	call   0x91a:0x17e1
     898:	6a 01                	push   0x1
     89a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     89d:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     8a2:	06                   	push   es
     8a3:	57                   	push   di
     8a4:	9a 9b 12 dd 19       	call   0x19dd:0x129b
     8a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8ac:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     8b1:	06                   	push   es
     8b2:	57                   	push   di
     8b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
     8b6:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
     8ba:	ff 76 08             	push   WORD PTR [bp+0x8]
     8bd:	ff 76 06             	push   WORD PTR [bp+0x6]
     8c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8c3:	06                   	push   es
     8c4:	57                   	push   di
     8c5:	9a 61 0b 3b 09       	call   0x93b:0xb61
     8ca:	c9                   	leave
     8cb:	ca 08 00             	retf   0x8
     8ce:	55                   	push   bp
     8cf:	89 e5                	mov    bp,sp
     8d1:	31 c0                	xor    ax,ax
     8d3:	9a 44 04 28 09       	call   0x928:0x444
     8d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8db:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
     8df:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
     8e3:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
     8e8:	06                   	push   es
     8e9:	57                   	push   di
     8ea:	9a 93 2a fc 08       	call   0x8fc:0x2a93
     8ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8f2:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
     8f7:	06                   	push   es
     8f8:	57                   	push   di
     8f9:	9a 0d 2b ff ff       	call   0xffff:0x2b0d
     8fe:	08 c0                	or     al,al
     900:	74 1a                	je     0x91c
     902:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     905:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
     90a:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
     90e:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
     912:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     915:	06                   	push   es
     916:	57                   	push   di
     917:	9a eb 1d 12 0a       	call   0xa12:0x1deb
     91c:	c9                   	leave
     91d:	ca 08 00             	retf   0x8
     920:	55                   	push   bp
     921:	89 e5                	mov    bp,sp
     923:	31 c0                	xor    ax,ax
     925:	9a 44 04 36 09       	call   0x936:0x444
     92a:	c9                   	leave
     92b:	ca 08 00             	retf   0x8
     92e:	55                   	push   bp
     92f:	89 e5                	mov    bp,sp
     931:	31 c0                	xor    ax,ax
     933:	9a 44 04 49 09       	call   0x949:0x444
     938:	9a 3e 20 bd 0e       	call   0xebd:0x203e
     93d:	c9                   	leave
     93e:	ca 08 00             	retf   0x8
     941:	55                   	push   bp
     942:	89 e5                	mov    bp,sp
     944:	31 c0                	xor    ax,ax
     946:	9a 44 04 71 09       	call   0x971:0x444
     94b:	6a 01                	push   0x1
     94d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     950:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
     955:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
     95a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     95e:	06                   	push   es
     95f:	57                   	push   di
     960:	9a b2 77 82 09       	call   0x982:0x77b2
     965:	c9                   	leave
     966:	ca 08 00             	retf   0x8
     969:	55                   	push   bp
     96a:	89 e5                	mov    bp,sp
     96c:	31 c0                	xor    ax,ax
     96e:	9a 44 04 90 09       	call   0x990:0x444
     973:	6a 03                	push   0x3
     975:	6a 00                	push   0x0
     977:	6a 00                	push   0x0
     979:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     97d:	06                   	push   es
     97e:	57                   	push   di
     97f:	9a b2 77 a3 09       	call   0x9a3:0x77b2
     984:	c9                   	leave
     985:	ca 08 00             	retf   0x8
     988:	55                   	push   bp
     989:	89 e5                	mov    bp,sp
     98b:	31 c0                	xor    ax,ax
     98d:	9a 44 04 b1 09       	call   0x9b1:0x444
     992:	68 05 01             	push   0x105
     995:	bf 72 01             	mov    di,0x172
     998:	1e                   	push   ds
     999:	57                   	push   di
     99a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     99e:	06                   	push   es
     99f:	57                   	push   di
     9a0:	9a b2 77 c2 09       	call   0x9c2:0x77b2
     9a5:	c9                   	leave
     9a6:	ca 08 00             	retf   0x8
     9a9:	55                   	push   bp
     9aa:	89 e5                	mov    bp,sp
     9ac:	31 c0                	xor    ax,ax
     9ae:	9a 44 04 d1 09       	call   0x9d1:0x444
     9b3:	6a 04                	push   0x4
     9b5:	6a 00                	push   0x0
     9b7:	6a 00                	push   0x0
     9b9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     9bd:	06                   	push   es
     9be:	57                   	push   di
     9bf:	9a b2 77 df 09       	call   0x9df:0x77b2
     9c4:	c9                   	leave
     9c5:	ca 08 00             	retf   0x8
     9c8:	55                   	push   bp
     9c9:	89 e5                	mov    bp,sp
     9cb:	b8 04 00             	mov    ax,0x4
     9ce:	9a 44 04 ee 09       	call   0x9ee:0x444
     9d3:	83 ec 04             	sub    sp,0x4
     9d6:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
     9da:	06                   	push   es
     9db:	57                   	push   di
     9dc:	9a 45 5d 44 0d       	call   0xd44:0x5d45
     9e1:	c9                   	leave
     9e2:	ca 08 00             	retf   0x8
     9e5:	55                   	push   bp
     9e6:	89 e5                	mov    bp,sp
     9e8:	b8 04 00             	mov    ax,0x4
     9eb:	9a 44 04 3f 0a       	call   0xa3f:0x444
     9f0:	83 ec 04             	sub    sp,0x4
     9f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9f6:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
     9fb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     9fe:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     a01:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
     a05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a08:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
     a0d:	06                   	push   es
     a0e:	57                   	push   di
     a0f:	9a bf 17 28 0a       	call   0xa28:0x17bf
     a14:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     a17:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
     a1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a1e:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
     a23:	06                   	push   es
     a24:	57                   	push   di
     a25:	9a e1 17 d5 0c       	call   0xcd5:0x17e1
     a2a:	c9                   	leave
     a2b:	ca 08 00             	retf   0x8
     a2e:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     a32:	ff                   	(bad)
     a33:	7f 00                	jg     0xa35
     a35:	00 55 89             	add    BYTE PTR [di-0x77],dl
     a38:	e5 b8                	in     ax,0xb8
     a3a:	08 01                	or     BYTE PTR [bx+di],al
     a3c:	9a 44 04 80 0a       	call   0xa80:0x444
     a41:	81 ec 08 01          	sub    sp,0x108
     a45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a48:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
     a4d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     a50:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     a53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a56:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     a5b:	06                   	push   es
     a5c:	57                   	push   di
     a5d:	9a 02 32 76 0a       	call   0xa76:0x3202
     a62:	08 c0                	or     al,al
     a64:	75 03                	jne    0xa69
     a66:	e9 ec 00             	jmp    0xb55
     a69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a6c:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     a71:	06                   	push   es
     a72:	57                   	push   di
     a73:	9a af 3d af 0a       	call   0xaaf:0x3daf
     a78:	2d 01 00             	sub    ax,0x1
     a7b:	71 05                	jno    0xa82
     a7d:	9a 3e 04 e8 0a       	call   0xae8:0x43e
     a82:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a85:	31 c0                	xor    ax,ax
     a87:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     a8a:	7f 44                	jg     0xad0
     a8c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     a8f:	eb 03                	jmp    0xa94
     a91:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     a94:	ff 76 fe             	push   WORD PTR [bp-0x2]
     a97:	6a 01                	push   0x1
     a99:	8d be f8 fe          	lea    di,[bp-0x108]
     a9d:	16                   	push   ss
     a9e:	57                   	push   di
     a9f:	ff 76 fe             	push   WORD PTR [bp-0x2]
     aa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aa5:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     aaa:	06                   	push   es
     aab:	57                   	push   di
     aac:	9a fb 3c 18 0b       	call   0xb18:0x3cfb
     ab1:	89 c7                	mov    di,ax
     ab3:	8e c2                	mov    es,dx
     ab5:	06                   	push   es
     ab6:	57                   	push   di
     ab7:	26 c4 3d             	les    di,DWORD PTR es:[di]
     aba:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
     abe:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     ac1:	06                   	push   es
     ac2:	57                   	push   di
     ac3:	9a 08 9b 22 0b       	call   0xb22:0x9b08
     ac8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     acb:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     ace:	75 c1                	jne    0xa91
     ad0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     ad3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
     ad8:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
     add:	2d 01 00             	sub    ax,0x1
     ae0:	83 da 00             	sbb    dx,0x0
     ae3:	71 05                	jno    0xaea
     ae5:	9a 3e 04 f0 0a       	call   0xaf0:0x43e
     aea:	bf 2e 0a             	mov    di,0xa2e
     aed:	9a 16 04 6a 0b       	call   0xb6a:0x416
     af2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     af5:	ff 76 fe             	push   WORD PTR [bp-0x2]
     af8:	6a 00                	push   0x0
     afa:	8d be fa fe          	lea    di,[bp-0x106]
     afe:	16                   	push   ss
     aff:	57                   	push   di
     b00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b03:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     b08:	06                   	push   es
     b09:	57                   	push   di
     b0a:	9a 8f 19 3c 0b       	call   0xb3c:0x198f
     b0f:	89 c7                	mov    di,ax
     b11:	8e c2                	mov    es,dx
     b13:	06                   	push   es
     b14:	57                   	push   di
     b15:	9a d2 67 8b 0b       	call   0xb8b:0x67d2
     b1a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     b1d:	06                   	push   es
     b1e:	57                   	push   di
     b1f:	9a 08 9b 53 0b       	call   0xb53:0x9b08
     b24:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b27:	6a 01                	push   0x1
     b29:	8d be fa fe          	lea    di,[bp-0x106]
     b2d:	16                   	push   ss
     b2e:	57                   	push   di
     b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b32:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     b37:	06                   	push   es
     b38:	57                   	push   di
     b39:	9a 8f 19 d1 0b       	call   0xbd1:0x198f
     b3e:	89 c7                	mov    di,ax
     b40:	8e c2                	mov    es,dx
     b42:	06                   	push   es
     b43:	57                   	push   di
     b44:	26 c4 3d             	les    di,DWORD PTR es:[di]
     b47:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
     b4b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     b4e:	06                   	push   es
     b4f:	57                   	push   di
     b50:	9a 08 9b e6 0b       	call   0xbe6:0x9b08
     b55:	c9                   	leave
     b56:	ca 0c 00             	retf   0xc
     b59:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     b5d:	ff                   	(bad)
     b5e:	7f 00                	jg     0xb60
     b60:	00 55 89             	add    BYTE PTR [di-0x77],dl
     b63:	e5 b8                	in     ax,0xb8
     b65:	06                   	push   es
     b66:	01 9a 44 04          	add    WORD PTR [bp+si+0x444],bx
     b6a:	ac                   	lods   al,BYTE PTR ds:[si]
     b6b:	0b 81 ec 06          	or     ax,WORD PTR [bx+di+0x6ec]
     b6f:	01 c4                	add    sp,ax
     b71:	7e 06                	jle    0xb79
     b73:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
     b78:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     b7b:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     b7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b81:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     b86:	06                   	push   es
     b87:	57                   	push   di
     b88:	9a 02 32 dc 0b       	call   0xbdc:0x3202
     b8d:	08 c0                	or     al,al
     b8f:	75 03                	jne    0xb94
     b91:	e9 85 00             	jmp    0xc19
     b94:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     b97:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
     b9c:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
     ba1:	2d 01 00             	sub    ax,0x1
     ba4:	83 da 00             	sbb    dx,0x0
     ba7:	71 05                	jno    0xbae
     ba9:	9a 3e 04 b4 0b       	call   0xbb4:0x43e
     bae:	bf 59 0b             	mov    di,0xb59
     bb1:	9a 16 04 28 0c       	call   0xc28:0x416
     bb6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     bb9:	ff 76 fe             	push   WORD PTR [bp-0x2]
     bbc:	6a 00                	push   0x0
     bbe:	8d be fa fe          	lea    di,[bp-0x106]
     bc2:	16                   	push   ss
     bc3:	57                   	push   di
     bc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bc7:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     bcc:	06                   	push   es
     bcd:	57                   	push   di
     bce:	9a 8f 19 00 0c       	call   0xc00:0x198f
     bd3:	89 c7                	mov    di,ax
     bd5:	8e c2                	mov    es,dx
     bd7:	06                   	push   es
     bd8:	57                   	push   di
     bd9:	9a d2 67 4d 0c       	call   0xc4d:0x67d2
     bde:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     be1:	06                   	push   es
     be2:	57                   	push   di
     be3:	9a 08 9b 17 0c       	call   0xc17:0x9b08
     be8:	ff 76 fe             	push   WORD PTR [bp-0x2]
     beb:	6a 01                	push   0x1
     bed:	8d be fa fe          	lea    di,[bp-0x106]
     bf1:	16                   	push   ss
     bf2:	57                   	push   di
     bf3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bf6:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     bfb:	06                   	push   es
     bfc:	57                   	push   di
     bfd:	9a 8f 19 69 0c       	call   0xc69:0x198f
     c02:	89 c7                	mov    di,ax
     c04:	8e c2                	mov    es,dx
     c06:	06                   	push   es
     c07:	57                   	push   di
     c08:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c0b:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
     c0f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     c12:	06                   	push   es
     c13:	57                   	push   di
     c14:	9a 08 9b ff ff       	call   0xffff:0x9b08
     c19:	c9                   	leave
     c1a:	ca 08 00             	retf   0x8
     c1d:	01 20                	add    WORD PTR [bx+si],sp
     c1f:	55                   	push   bp
     c20:	89 e5                	mov    bp,sp
     c22:	b8 08 02             	mov    ax,0x208
     c25:	9a 44 04 84 0c       	call   0xc84:0x444
     c2a:	81 ec 08 02          	sub    sp,0x208
     c2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c31:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     c36:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
     c3b:	74 03                	je     0xc40
     c3d:	e9 5e 02             	jmp    0xe9e
     c40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c43:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     c48:	06                   	push   es
     c49:	57                   	push   di
     c4a:	9a 02 32 82 11       	call   0x1182:0x3202
     c4f:	08 c0                	or     al,al
     c51:	75 03                	jne    0xc56
     c53:	e9 48 02             	jmp    0xe9e
     c56:	8d be fc fd          	lea    di,[bp-0x204]
     c5a:	16                   	push   ss
     c5b:	57                   	push   di
     c5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c5f:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     c64:	06                   	push   es
     c65:	57                   	push   di
     c66:	9a 8f 19 ff ff       	call   0xffff:0x198f
     c6b:	89 c7                	mov    di,ax
     c6d:	8e c2                	mov    es,dx
     c6f:	06                   	push   es
     c70:	57                   	push   di
     c71:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c74:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
     c78:	8d be fc fe          	lea    di,[bp-0x104]
     c7c:	16                   	push   ss
     c7d:	57                   	push   di
     c7e:	68 ff 00             	push   0xff
     c81:	9a e7 17 ac 0c       	call   0xcac:0x17e7
     c86:	80 be fc fe 00       	cmp    BYTE PTR [bp-0x104],0x0
     c8b:	77 03                	ja     0xc90
     c8d:	e9 0e 02             	jmp    0xe9e
     c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c93:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
     c98:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     c9c:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     ca0:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
     ca4:	2d 04 00             	sub    ax,0x4
     ca7:	71 05                	jno    0xcae
     ca9:	9a 3e 04 c1 0c       	call   0xcc1:0x43e
     cae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cb1:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     cb5:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
     cb9:	2d 04 00             	sub    ax,0x4
     cbc:	71 05                	jno    0xcc3
     cbe:	9a 3e 04 01 0d       	call   0xd01:0x43e
     cc3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     cc6:	ff 76 fe             	push   WORD PTR [bp-0x2]
     cc9:	ff 76 fc             	push   WORD PTR [bp-0x4]
     ccc:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     cd0:	06                   	push   es
     cd1:	57                   	push   di
     cd2:	9a d4 19 eb 0c       	call   0xceb:0x19d4
     cd7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cda:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     cdd:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ce0:	ff 76 fc             	push   WORD PTR [bp-0x4]
     ce3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce6:	06                   	push   es
     ce7:	57                   	push   di
     ce8:	9a 06 1a 25 0d       	call   0xd25:0x1a06
     ced:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cf0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     cf3:	8d be fc fd          	lea    di,[bp-0x204]
     cf7:	16                   	push   ss
     cf8:	57                   	push   di
     cf9:	bf 1d 0c             	mov    di,0xc1d
     cfc:	0e                   	push   cs
     cfd:	57                   	push   di
     cfe:	9a cd 17 0c 0d       	call   0xd0c:0x17cd
     d03:	8d be fc fe          	lea    di,[bp-0x104]
     d07:	16                   	push   ss
     d08:	57                   	push   di
     d09:	9a 4c 18 16 0d       	call   0xd16:0x184c
     d0e:	bf 1d 0c             	mov    di,0xc1d
     d11:	0e                   	push   cs
     d12:	57                   	push   di
     d13:	9a 4c 18 c7 0d       	call   0xdc7:0x184c
     d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d1b:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     d20:	06                   	push   es
     d21:	57                   	push   di
     d22:	9a 8c 1d 80 0d       	call   0xd80:0x1d8c
     d27:	6a 18                	push   0x18
     d29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d2c:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     d31:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
     d35:	06                   	push   es
     d36:	57                   	push   di
     d37:	9a f5 11 6b 0d       	call   0xd6b:0x11f5
     d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d3f:	06                   	push   es
     d40:	57                   	push   di
     d41:	9a d5 33 b0 0f       	call   0xfb0:0x33d5
     d46:	89 c7                	mov    di,ax
     d48:	8e c2                	mov    es,dx
     d4a:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     d4e:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     d52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d55:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     d5a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
     d5e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
     d62:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     d66:	06                   	push   es
     d67:	57                   	push   di
     d68:	9a 99 20 8b 0d       	call   0xd8b:0x2099
     d6d:	8d be f8 fd          	lea    di,[bp-0x208]
     d71:	16                   	push   ss
     d72:	57                   	push   di
     d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d76:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     d7b:	06                   	push   es
     d7c:	57                   	push   di
     d7d:	9a 53 1d 9b 0d       	call   0xd9b:0x1d53
     d82:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     d86:	06                   	push   es
     d87:	57                   	push   di
     d88:	9a 03 20 bb 0d       	call   0xdbb:0x2003
     d8d:	50                   	push   ax
     d8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d91:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     d96:	06                   	push   es
     d97:	57                   	push   di
     d98:	9a bf 17 b0 0d       	call   0xdb0:0x17bf
     d9d:	8d be f8 fd          	lea    di,[bp-0x208]
     da1:	16                   	push   ss
     da2:	57                   	push   di
     da3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     da6:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     dab:	06                   	push   es
     dac:	57                   	push   di
     dad:	9a 53 1d dd 0d       	call   0xddd:0x1d53
     db2:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     db6:	06                   	push   es
     db7:	57                   	push   di
     db8:	9a 4e 20 00 1d       	call   0x1d00:0x204e
     dbd:	b9 03 00             	mov    cx,0x3
     dc0:	f7 e9                	imul   cx
     dc2:	71 05                	jno    0xdc9
     dc4:	9a 3e 04 24 0e       	call   0xe24:0x43e
     dc9:	99                   	cwd
     dca:	b9 02 00             	mov    cx,0x2
     dcd:	f7 f9                	idiv   cx
     dcf:	50                   	push   ax
     dd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dd3:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     dd8:	06                   	push   es
     dd9:	57                   	push   di
     dda:	9a e1 17 f7 0d       	call   0xdf7:0x17e1
     ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de2:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     de7:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     deb:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     def:	ff 76 fc             	push   WORD PTR [bp-0x4]
     df2:	06                   	push   es
     df3:	57                   	push   di
     df4:	9a 7b 17 05 0e       	call   0xe05:0x177b
     df9:	ff 76 fe             	push   WORD PTR [bp-0x2]
     dfc:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e00:	06                   	push   es
     e01:	57                   	push   di
     e02:	9a 9d 17 0f 0e       	call   0xe0f:0x179d
     e07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e0a:	06                   	push   es
     e0b:	57                   	push   di
     e0c:	9a a9 18 46 0e       	call   0xe46:0x18a9
     e11:	8b d0                	mov    dx,ax
     e13:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e17:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
     e1b:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
     e1f:	71 05                	jno    0xe26
     e21:	9a 3e 04 3a 0e       	call   0xe3a:0x43e
     e26:	3b c2                	cmp    ax,dx
     e28:	7e 20                	jle    0xe4a
     e2a:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e2e:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
     e32:	2d 08 00             	sub    ax,0x8
     e35:	71 05                	jno    0xe3c
     e37:	9a 3e 04 67 0e       	call   0xe67:0x43e
     e3c:	50                   	push   ax
     e3d:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e41:	06                   	push   es
     e42:	57                   	push   di
     e43:	9a 7b 17 52 0e       	call   0xe52:0x177b
     e48:	eb bd                	jmp    0xe07
     e4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e4d:	06                   	push   es
     e4e:	57                   	push   di
     e4f:	9a f4 18 89 0e       	call   0xe89:0x18f4
     e54:	8b d0                	mov    dx,ax
     e56:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e5a:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
     e5e:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
     e62:	71 05                	jno    0xe69
     e64:	9a 3e 04 7d 0e       	call   0xe7d:0x43e
     e69:	3b c2                	cmp    ax,dx
     e6b:	7e 20                	jle    0xe8d
     e6d:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e71:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
     e75:	2d 08 00             	sub    ax,0x8
     e78:	71 05                	jno    0xe7f
     e7a:	9a 3e 04 aa 0e       	call   0xeaa:0x43e
     e7f:	50                   	push   ax
     e80:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e84:	06                   	push   es
     e85:	57                   	push   di
     e86:	9a 9d 17 9c 0e       	call   0xe9c:0x179d
     e8b:	eb bd                	jmp    0xe4a
     e8d:	6a 01                	push   0x1
     e8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e92:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     e97:	06                   	push   es
     e98:	57                   	push   di
     e99:	9a 77 1c e5 0e       	call   0xee5:0x1c77
     e9e:	c9                   	leave
     e9f:	ca 04 00             	retf   0x4
     ea2:	55                   	push   bp
     ea3:	89 e5                	mov    bp,sp
     ea5:	31 c0                	xor    ax,ax
     ea7:	9a 44 04 cb 0e       	call   0xecb:0x444
     eac:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     eaf:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
     eb3:	75 0a                	jne    0xebf
     eb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb8:	06                   	push   es
     eb9:	57                   	push   di
     eba:	9a 1f 0c 1c 0f       	call   0xf1c:0xc1f
     ebf:	c9                   	leave
     ec0:	ca 0e 00             	retf   0xe
     ec3:	55                   	push   bp
     ec4:	89 e5                	mov    bp,sp
     ec6:	31 c0                	xor    ax,ax
     ec8:	9a 44 04 f3 0e       	call   0xef3:0x444
     ecd:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     ed0:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
     ed4:	75 11                	jne    0xee7
     ed6:	6a 00                	push   0x0
     ed8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     edb:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     ee0:	06                   	push   es
     ee1:	57                   	push   di
     ee2:	9a 77 1c 04 0f       	call   0xf04:0x1c77
     ee7:	c9                   	leave
     ee8:	ca 0e 00             	retf   0xe
     eeb:	55                   	push   bp
     eec:	89 e5                	mov    bp,sp
     eee:	31 c0                	xor    ax,ax
     ef0:	9a 44 04 12 0f       	call   0xf12:0x444
     ef5:	6a 00                	push   0x0
     ef7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     efa:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
     eff:	06                   	push   es
     f00:	57                   	push   di
     f01:	9a 77 1c 98 0f       	call   0xf98:0x1c77
     f06:	c9                   	leave
     f07:	ca 08 00             	retf   0x8
     f0a:	55                   	push   bp
     f0b:	89 e5                	mov    bp,sp
     f0d:	31 c0                	xor    ax,ax
     f0f:	9a 44 04 3c 0f       	call   0xf3c:0x444
     f14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f17:	06                   	push   es
     f18:	57                   	push   di
     f19:	9a 1f 0c d4 0f       	call   0xfd4:0xc1f
     f1e:	c9                   	leave
     f1f:	ca 08 00             	retf   0x8
     f22:	ca 10 13             	retf   0x1310
     f25:	10 d0                	adc    al,dl
     f27:	0f 00 00             	sldt   WORD PTR [bx+si]
     f2a:	be 0f ac             	mov    si,0xac0f
     f2d:	01 fb                	add    bx,di
     f2f:	04 e3                	add    al,0xe3
     f31:	10 39                	adc    BYTE PTR [bx+di],bh
     f33:	3f                   	aas
     f34:	48                   	dec    ax
     f35:	0f 9a 1f             	setp   BYTE PTR [bx]
     f38:	fd                   	std
     f39:	10 cb                	adc    bl,cl
     f3b:	1f                   	pop    ds
     f3c:	38 0f                	cmp    BYTE PTR [bx],cl
     f3e:	ad                   	lods   ax,WORD PTR ds:[si]
     f3f:	27                   	daa
     f40:	bc 0f cd             	mov    sp,0xcd0f
     f43:	11 4c 0f             	adc    WORD PTR [si+0xf],cx
     f46:	f7 2a                	imul   WORD PTR [bp+si]
     f48:	a8 0f                	test   al,0xf
     f4a:	fa                   	cli
     f4b:	10 ba 17 d6          	adc    BYTE PTR [bp+si-0x29e9],bh
     f4f:	14 80                	adc    al,0x80
     f51:	0f f4 4f 6c          	pmuludq mm1,QWORD PTR [bx+0x6c]
     f55:	0f 9a 28             	setp   BYTE PTR [bx+si]
     f58:	b4 0f                	mov    ah,0xf
     f5a:	85 29                	test   WORD PTR [bx+di],bp
     f5c:	60                   	pusha
     f5d:	0f 57 4d 64          	xorps  xmm1,XMMWORD PTR [di+0x64]
     f61:	0f 91 2f             	setno  BYTE PTR [bx]
     f64:	84 0f                	test   BYTE PTR [bx],cl
     f66:	63 31                	arpl   WORD PTR [bx+di],si
     f68:	88 0f                	mov    BYTE PTR [bx],cl
     f6a:	21 50 44             	and    WORD PTR [bx+si+0x44],dx
     f6d:	0f 53 25             	rcpps  xmm4,XMMWORD PTR [di]
     f70:	40                   	inc    ax
     f71:	0f d9 62 7c          	psubusw mm4,QWORD PTR [bp+si+0x7c]
     f75:	0f 55 2e 58 0f       	andnps xmm5,XMMWORD PTR ds:0xf58
     f7a:	8f                   	(bad)
     f7b:	60                   	pusha
     f7c:	b8 0f 3a             	mov    ax,0x3a0f
     f7f:	1c 08                	sbb    al,0x8
     f81:	13 e2                	adc    sp,dx
     f83:	2f                   	das
     f84:	70 0f                	jo     0xf95
     f86:	08 61 8c             	or     BYTE PTR [bx+di-0x74],ah
     f89:	0f 5c 61 90          	subps  xmm4,XMMWORD PTR [bx+di-0x70]
     f8d:	0f 62 5c 94          	punpckldq mm3,DWORD PTR [si-0x6c]
     f91:	0f 3a 61             	(bad)
     f94:	50                   	push   ax
     f95:	0f 72                	(bad)
     f97:	3f                   	aas
     f98:	ac                   	lods   al,BYTE PTR ds:[si]
     f99:	0f 58 3a             	addps  xmm7,XMMWORD PTR [bp+si]
     f9c:	a0 0f ec             	mov    al,ds:0xec0f
     f9f:	3d a4 0f             	cmp    ax,0xfa4
     fa2:	e4 3c                	in     al,0x3c
     fa4:	34 0f                	xor    al,0xf
     fa6:	ed                   	in     ax,dx
     fa7:	3e 78 0f             	ds js  0xfb9
     faa:	77 3e                	ja     0xfea
     fac:	74 0f                	je     0xfbd
     fae:	e6 31                	out    0x31,al
     fb0:	9c                   	pushf
     fb1:	0f 3c                	(bad)
     fb3:	47                   	inc    di
     fb4:	5c                   	pop    sp
     fb5:	0f ae 5f 68          	stmxcsr DWORD PTR [bx+0x68]
     fb9:	0f e9 5c 30          	psubsw mm3,QWORD PTR [si+0x30]
     fbd:	0f 11 54 46          	movups XMMWORD PTR [si+0x46],xmm2
     fc1:	6f                   	outs   dx,WORD PTR ds:[si]
     fc2:	72 6d                	jb     0x1031
     fc4:	53                   	push   bx
     fc5:	4a                   	dec    dx
     fc6:	44                   	inc    sp
     fc7:	52                   	push   dx
     fc8:	5f                   	pop    di
     fc9:	52                   	push   dx
     fca:	65 70 72             	gs jo  0x103f
     fcd:	69 73 65 04 00       	imul   si,WORD PTR [bp+di+0x65],0x4
     fd2:	c7                   	(bad)
     fd3:	12 e3                	adc    ah,bl
     fd5:	0f 0a                	(bad)
     fd7:	46                   	inc    si
     fd8:	6f                   	outs   dx,WORD PTR ds:[si]
     fd9:	72 6d                	jb     0x1048
     fdb:	43                   	inc    bx
     fdc:	72 65                	jb     0x1043
     fde:	61                   	popa
     fdf:	74 65                	je     0x1046
     fe1:	d2 13                	rcl    BYTE PTR [bp+di],cl
     fe3:	f4                   	hlt
     fe4:	0f 0c                	(bad)
     fe6:	42                   	inc    dx
     fe7:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     fec:	33 43 6c             	xor    ax,WORD PTR [bp+di+0x6c]
     fef:	69 63 6b fa 13       	imul   sp,WORD PTR [bp+di+0x6b],0x13fa
     ff4:	02 10                	add    dl,BYTE PTR [bx+si]
     ff6:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
     ff9:	72 6d                	jb     0x1068
     ffb:	43                   	inc    bx
     ffc:	6c                   	ins    BYTE PTR es:[di],dx
     ffd:	6f                   	outs   dx,WORD PTR ds:[si]
     ffe:	73 65                	jae    0x1065
    1000:	7d 14                	jge    0x1016
    1002:	df 10                	fist   WORD PTR [bx+si]
    1004:	0e                   	push   cs
    1005:	46                   	inc    si
    1006:	6f                   	outs   dx,WORD PTR ds:[si]
    1007:	72 6d                	jb     0x1076
    1009:	43                   	inc    bx
    100a:	6c                   	ins    BYTE PTR es:[di],dx
    100b:	6f                   	outs   dx,WORD PTR ds:[si]
    100c:	73 65                	jae    0x1073
    100e:	51                   	push   cx
    100f:	75 65                	jne    0x1076
    1011:	72 79                	jb     0x108c
    1013:	0c 00                	or     al,0x0
    1015:	ac                   	lods   al,BYTE PTR ds:[si]
    1016:	10 7c 01             	adc    BYTE PTR [si+0x1],bh
    1019:	00 00                	add    BYTE PTR [bx+si],al
    101b:	06                   	push   es
    101c:	50                   	push   ax
    101d:	61                   	popa
    101e:	6e                   	outs   dx,BYTE PTR ds:[si]
    101f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1021:	31 80 01 04          	xor    WORD PTR [bx+si+0x401],ax
    1025:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1029:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    102c:	31 84 01 08          	xor    WORD PTR [si+0x801],ax
    1030:	00 05                	add    BYTE PTR [di],al
    1032:	45                   	inc    bp
    1033:	64 69 74 31 88 01    	imul   si,WORD PTR fs:[si+0x31],0x188
    1039:	04 00                	add    al,0x0
    103b:	06                   	push   es
    103c:	4c                   	dec    sp
    103d:	61                   	popa
    103e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1041:	32 8c 01 0c          	xor    cl,BYTE PTR [si+0xc01]
    1045:	00 09                	add    BYTE PTR [bx+di],cl
    1047:	53                   	push   bx
    1048:	70 69                	jo     0x10b3
    104a:	6e                   	outs   dx,BYTE PTR ds:[si]
    104b:	45                   	inc    bp
    104c:	64 69 74 31 90 01    	imul   si,WORD PTR fs:[si+0x31],0x190
    1052:	10 00                	adc    BYTE PTR [bx+si],al
    1054:	07                   	pop    es
    1055:	42                   	inc    dx
    1056:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    105b:	31 94 01 10          	xor    WORD PTR [si+0x1001],dx
    105f:	00 07                	add    BYTE PTR [bx],al
    1061:	42                   	inc    dx
    1062:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1067:	32 98 01 10          	xor    bl,BYTE PTR [bx+si+0x1001]
    106b:	00 07                	add    BYTE PTR [bx],al
    106d:	42                   	inc    dx
    106e:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1073:	33 9c 01 14          	xor    bx,WORD PTR [si+0x1401]
    1077:	00 09                	add    BYTE PTR [bx+di],cl
    1079:	54                   	push   sp
    107a:	61                   	popa
    107b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    107e:	4d                   	dec    bp
    107f:	41                   	inc    cx
    1080:	49                   	dec    cx
    1081:	4e                   	dec    si
    1082:	a0 01 18             	mov    al,ds:0x1801
    1085:	00 0b                	add    BYTE PTR [bp+di],cl
    1087:	52                   	push   dx
    1088:	61                   	popa
    1089:	64 69 6f 47 72 6f    	imul   bp,WORD PTR fs:[bx+0x47],0x6f72
    108f:	75 70                	jne    0x1101
    1091:	31 a4 01 14          	xor    WORD PTR [si+0x1401],sp
    1095:	00 08                	add    BYTE PTR [bx+si],cl
    1097:	54                   	push   sp
    1098:	61                   	popa
    1099:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    109c:	41                   	inc    cx
    109d:	44                   	inc    sp
    109e:	47                   	inc    di
    109f:	a8 01                	test   al,0x1
    10a1:	14 00                	adc    al,0x0
    10a3:	08 54 61             	or     BYTE PTR [si+0x61],dl
    10a6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10a9:	45                   	inc    bp
    10aa:	44                   	inc    sp
    10ab:	47                   	inc    di
    10ac:	07                   	pop    es
    10ad:	00 ad 0d c8          	add    BYTE PTR [di-0x37f3],ch
    10b1:	10 17                	adc    BYTE PTR [bx],dl
    10b3:	06                   	push   es
    10b4:	b8 10 90             	mov    ax,0x9010
    10b7:	0b c1                	or     ax,cx
    10b9:	19 eb                	sbb    bx,bp
    10bb:	03 64 13             	add    sp,WORD PTR [si+0x13]
    10be:	ac                   	lods   al,BYTE PTR ds:[si]
    10bf:	04 d9                	add    al,0xd9
    10c1:	19 38                	sbb    WORD PTR [bx+si],di
    10c3:	01 8e 11 fb          	add    WORD PTR [bp-0x4ef],cx
    10c7:	13 bd 19 07          	adc    di,WORD PTR [di+0x719]
    10cb:	11 54 46             	adc    WORD PTR [si+0x46],dx
    10ce:	6f                   	outs   dx,WORD PTR ds:[si]
    10cf:	72 6d                	jb     0x113e
    10d1:	53                   	push   bx
    10d2:	4a                   	dec    dx
    10d3:	44                   	inc    sp
    10d4:	52                   	push   dx
    10d5:	5f                   	pop    di
    10d6:	52                   	push   dx
    10d7:	65 70 72             	gs jo  0x114c
    10da:	69 73 65 42 0f       	imul   si,WORD PTR [bp+di+0x65],0xf42
    10df:	f2 10 7b 06          	repnz adc BYTE PTR [bp+di+0x6],bh
    10e3:	18 11                	sbb    BYTE PTR [bx+di],dl
    10e5:	38 00                	cmp    BYTE PTR [bx+si],al
    10e7:	04 53                	add    al,0x53
    10e9:	6a 64                	push   0x64
    10eb:	72 00                	jb     0x10ed
    10ed:	00 00                	add    BYTE PTR [bx+si],al
    10ef:	00 54 11             	add    BYTE PTR [si+0x11],dl
    10f2:	11 11                	adc    WORD PTR [bx+di],dx
    10f4:	55                   	push   bp
    10f5:	89 e5                	mov    bp,sp
    10f7:	b8 08 00             	mov    ax,0x8
    10fa:	9a 44 04 6a 11       	call   0x116a:0x444
    10ff:	83 ec 08             	sub    sp,0x8
    1102:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1106:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    110a:	b0 01                	mov    al,0x1
    110c:	50                   	push   ax
    110d:	b8 42 0f             	mov    ax,0xf42
    1110:	ba 3c 11             	mov    dx,0x113c
    1113:	52                   	push   dx
    1114:	50                   	push   ax
    1115:	9a 53 25 46 11       	call   0x1146:0x2553
    111a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    111d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1120:	b8 ee 10             	mov    ax,0x10ee
    1123:	0e                   	push   cs
    1124:	50                   	push   ax
    1125:	55                   	push   bp
    1126:	ff 36 58 18          	push   WORD PTR ds:0x1858
    112a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    112e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1131:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1134:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1137:	06                   	push   es
    1138:	57                   	push   di
    1139:	9a 61 11 0c 14       	call   0x140c:0x1161
    113e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1141:	06                   	push   es
    1142:	57                   	push   di
    1143:	9a 45 5d 5c 11       	call   0x115c:0x5d45
    1148:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    114c:	83 c4 06             	add    sp,0x6
    114f:	b8 5f 11             	mov    ax,0x115f
    1152:	0e                   	push   cs
    1153:	50                   	push   ax
    1154:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1157:	06                   	push   es
    1158:	57                   	push   di
    1159:	9a 1d 5f f4 13       	call   0x13f4:0x5f1d
    115e:	cb                   	retf
    115f:	c9                   	leave
    1160:	cb                   	retf
    1161:	55                   	push   bp
    1162:	89 e5                	mov    bp,sp
    1164:	b8 04 00             	mov    ax,0x4
    1167:	9a 44 04 21 12       	call   0x1221:0x444
    116c:	83 ec 04             	sub    sp,0x4
    116f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1172:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    1177:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    117a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    117d:	06                   	push   es
    117e:	57                   	push   di
    117f:	9a d2 31 a4 11       	call   0x11a4:0x31d2
    1184:	6a 00                	push   0x0
    1186:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1189:	06                   	push   es
    118a:	57                   	push   di
    118b:	9a fb 2f 9a 11       	call   0x119a:0x2ffb
    1190:	6a 01                	push   0x1
    1192:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1195:	06                   	push   es
    1196:	57                   	push   di
    1197:	9a d2 2e c5 11       	call   0x11c5:0x2ed2
    119c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    119f:	06                   	push   es
    11a0:	57                   	push   di
    11a1:	9a bf 31 b9 11       	call   0x11b9:0x31bf
    11a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a9:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    11ae:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    11b1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    11b4:	06                   	push   es
    11b5:	57                   	push   di
    11b6:	9a d2 31 db 11       	call   0x11db:0x31d2
    11bb:	6a 00                	push   0x0
    11bd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11c0:	06                   	push   es
    11c1:	57                   	push   di
    11c2:	9a fb 2f d1 11       	call   0x11d1:0x2ffb
    11c7:	6a 01                	push   0x1
    11c9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11cc:	06                   	push   es
    11cd:	57                   	push   di
    11ce:	9a d2 2e fc 11       	call   0x11fc:0x2ed2
    11d3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11d6:	06                   	push   es
    11d7:	57                   	push   di
    11d8:	9a bf 31 f0 11       	call   0x11f0:0x31bf
    11dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e0:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    11e5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    11e8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    11eb:	06                   	push   es
    11ec:	57                   	push   di
    11ed:	9a d2 31 12 12       	call   0x1212:0x31d2
    11f2:	6a 00                	push   0x0
    11f4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11f7:	06                   	push   es
    11f8:	57                   	push   di
    11f9:	9a fb 2f 08 12       	call   0x1208:0x2ffb
    11fe:	6a 01                	push   0x1
    1200:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1203:	06                   	push   es
    1204:	57                   	push   di
    1205:	9a d2 2e 53 12       	call   0x1253:0x2ed2
    120a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    120d:	06                   	push   es
    120e:	57                   	push   di
    120f:	9a bf 31 39 12       	call   0x1239:0x31bf
    1214:	c9                   	leave
    1215:	ca 04 00             	retf   0x4
    1218:	55                   	push   bp
    1219:	89 e5                	mov    bp,sp
    121b:	b8 04 00             	mov    ax,0x4
    121e:	9a 44 04 d0 12       	call   0x12d0:0x444
    1223:	83 ec 04             	sub    sp,0x4
    1226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1229:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    122e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1231:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1234:	06                   	push   es
    1235:	57                   	push   di
    1236:	9a 02 32 47 12       	call   0x1247:0x3202
    123b:	08 c0                	or     al,al
    123d:	74 16                	je     0x1255
    123f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1242:	06                   	push   es
    1243:	57                   	push   di
    1244:	9a d2 31 68 12       	call   0x1268:0x31d2
    1249:	6a 00                	push   0x0
    124b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    124e:	06                   	push   es
    124f:	57                   	push   di
    1250:	9a d2 2e 82 12       	call   0x1282:0x2ed2
    1255:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1258:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    125d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1260:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1263:	06                   	push   es
    1264:	57                   	push   di
    1265:	9a 02 32 76 12       	call   0x1276:0x3202
    126a:	08 c0                	or     al,al
    126c:	74 16                	je     0x1284
    126e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1271:	06                   	push   es
    1272:	57                   	push   di
    1273:	9a d2 31 97 12       	call   0x1297:0x31d2
    1278:	6a 00                	push   0x0
    127a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    127d:	06                   	push   es
    127e:	57                   	push   di
    127f:	9a d2 2e b1 12       	call   0x12b1:0x2ed2
    1284:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1287:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    128c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    128f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1292:	06                   	push   es
    1293:	57                   	push   di
    1294:	9a 02 32 a5 12       	call   0x12a5:0x3202
    1299:	08 c0                	or     al,al
    129b:	74 16                	je     0x12b3
    129d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    12a0:	06                   	push   es
    12a1:	57                   	push   di
    12a2:	9a d2 31 65 14       	call   0x1465:0x31d2
    12a7:	6a 00                	push   0x0
    12a9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    12ac:	06                   	push   es
    12ad:	57                   	push   di
    12ae:	9a d2 2e a4 13       	call   0x13a4:0x2ed2
    12b3:	c9                   	leave
    12b4:	ca 04 00             	retf   0x4
    12b7:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    12ba:	6d                   	ins    WORD PTR es:[di],dx
    12bb:	73 74                	jae    0x1331
    12bd:	72 61                	jb     0x1320
    12bf:	74 20                	je     0x12e1
    12c1:	2d 20 03             	sub    ax,0x320
    12c4:	20 2d                	and    BYTE PTR [di],ch
    12c6:	20 55 89             	and    BYTE PTR [di-0x77],dl
    12c9:	e5 b8                	in     ax,0xb8
    12cb:	00 02                	add    BYTE PTR [bp+si],al
    12cd:	9a 44 04 e4 12       	call   0x12e4:0x444
    12d2:	81 ec 00 02          	sub    sp,0x200
    12d6:	8d be 00 ff          	lea    di,[bp-0x100]
    12da:	16                   	push   ss
    12db:	57                   	push   di
    12dc:	bf b7 12             	mov    di,0x12b7
    12df:	0e                   	push   cs
    12e0:	57                   	push   di
    12e1:	9a cd 17 ee 12       	call   0x12ee:0x17cd
    12e6:	bf fa 1d             	mov    di,0x1dfa
    12e9:	1e                   	push   ds
    12ea:	57                   	push   di
    12eb:	9a 4c 18 f8 12       	call   0x12f8:0x184c
    12f0:	bf c3 12             	mov    di,0x12c3
    12f3:	0e                   	push   cs
    12f4:	57                   	push   di
    12f5:	9a 4c 18 0d 13       	call   0x130d:0x184c
    12fa:	8d be 00 fe          	lea    di,[bp-0x200]
    12fe:	16                   	push   ss
    12ff:	57                   	push   di
    1300:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1303:	06                   	push   es
    1304:	57                   	push   di
    1305:	9a 53 1d 17 13       	call   0x1317:0x1d53
    130a:	9a 4c 18 da 13       	call   0x13da:0x184c
    130f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1312:	06                   	push   es
    1313:	57                   	push   di
    1314:	9a 8c 1d 37 13       	call   0x1337:0x1d8c
    1319:	8d be 00 ff          	lea    di,[bp-0x100]
    131d:	16                   	push   ss
    131e:	57                   	push   di
    131f:	a1 4c 01             	mov    ax,ds:0x14c
    1322:	99                   	cwd
    1323:	52                   	push   dx
    1324:	50                   	push   ax
    1325:	9a a9 08 6f 14       	call   0x146f:0x8a9
    132a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    132d:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    1332:	06                   	push   es
    1333:	57                   	push   di
    1334:	9a 8c 1d 90 13       	call   0x1390:0x1d8c
    1339:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    133c:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    1341:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1344:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1347:	a1 4c 01             	mov    ax,ds:0x14c
    134a:	99                   	cwd
    134b:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    1350:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
    1355:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    135a:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    135f:	06                   	push   es
    1360:	57                   	push   di
    1361:	9a 8b 17 b3 14       	call   0x14b3:0x178b
    1366:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1369:	26 8b 85 f0 00       	mov    ax,WORD PTR es:[di+0xf0]
    136e:	26 8b 95 f2 00       	mov    dx,WORD PTR es:[di+0xf2]
    1373:	26 3b 95 ee 00       	cmp    dx,WORD PTR es:[di+0xee]
    1378:	75 0b                	jne    0x1385
    137a:	26 3b 85 ec 00       	cmp    ax,WORD PTR es:[di+0xec]
    137f:	75 04                	jne    0x1385
    1381:	b0 00                	mov    al,0x0
    1383:	eb 02                	jmp    0x1387
    1385:	b0 01                	mov    al,0x1
    1387:	50                   	push   ax
    1388:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    138b:	06                   	push   es
    138c:	57                   	push   di
    138d:	9a b8 1c 1b 15       	call   0x151b:0x1cb8
    1392:	bf 08 1e             	mov    di,0x1e08
    1395:	1e                   	push   ds
    1396:	57                   	push   di
    1397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    139a:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    139f:	06                   	push   es
    13a0:	57                   	push   di
    13a1:	9a 17 30 b8 13       	call   0x13b8:0x3017
    13a6:	bf 32 1e             	mov    di,0x1e32
    13a9:	1e                   	push   ds
    13aa:	57                   	push   di
    13ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ae:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    13b3:	06                   	push   es
    13b4:	57                   	push   di
    13b5:	9a 17 30 cc 13       	call   0x13cc:0x3017
    13ba:	bf 4e 1e             	mov    di,0x1e4e
    13bd:	1e                   	push   ds
    13be:	57                   	push   di
    13bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13c2:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    13c7:	06                   	push   es
    13c8:	57                   	push   di
    13c9:	9a 17 30 a9 15       	call   0x15a9:0x3017
    13ce:	c9                   	leave
    13cf:	ca 08 00             	retf   0x8
    13d2:	55                   	push   bp
    13d3:	89 e5                	mov    bp,sp
    13d5:	31 c0                	xor    ax,ax
    13d7:	9a 44 04 02 14       	call   0x1402:0x444
    13dc:	6a 01                	push   0x1
    13de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e1:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    13e6:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    13eb:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    13ef:	06                   	push   es
    13f0:	57                   	push   di
    13f1:	9a b2 77 16 18       	call   0x1816:0x77b2
    13f6:	c9                   	leave
    13f7:	ca 08 00             	retf   0x8
    13fa:	55                   	push   bp
    13fb:	89 e5                	mov    bp,sp
    13fd:	31 c0                	xor    ax,ax
    13ff:	9a 44 04 86 14       	call   0x1486:0x444
    1404:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1407:	06                   	push   es
    1408:	57                   	push   di
    1409:	9a 18 12 69 14       	call   0x1469:0x1218
    140e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1411:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    1415:	c9                   	leave
    1416:	ca 0c 00             	retf   0xc
    1419:	23 43 6f             	and    ax,WORD PTR [bp+di+0x6f]
    141c:	6e                   	outs   dx,BYTE PTR ds:[si]
    141d:	66 69 72 6d 65 72 20 	imul   esi,DWORD PTR [bp+si+0x6d],0x6c207265
    1424:	6c 
    1425:	61                   	popa
    1426:	20 72 65             	and    BYTE PTR [bp+si+0x65],dh
    1429:	70 72                	jo     0x149d
    142b:	69 73 65 20 e0       	imul   si,WORD PTR [bp+di+0x65],0xe020
    1430:	20 6c 61             	and    BYTE PTR [si+0x61],ch
    1433:	20 70 e9             	and    BYTE PTR [bx+si-0x17],dh
    1436:	72 69                	jb     0x14a1
    1438:	6f                   	outs   dx,WORD PTR ds:[si]
    1439:	64 65 20 20          	fs and BYTE PTR gs:[bx+si],ah
    143d:	01 00                	add    WORD PTR [bx+si],ax
    143f:	0e                   	push   cs
    1440:	50                   	push   ax
    1441:	65 72 69             	gs jb  0x14ad
    1444:	6f                   	outs   dx,WORD PTR ds:[si]
    1445:	64 65 45             	fs gs inc bp
    1448:	6e                   	outs   dx,BYTE PTR ds:[si]
    1449:	43                   	inc    bx
    144a:	6f                   	outs   dx,WORD PTR ds:[si]
    144b:	75 72                	jne    0x14bf
    144d:	73 00                	jae    0x144f
    144f:	80 ff ff             	cmp    bh,0xff
    1452:	ff                   	(bad)
    1453:	7f 00                	jg     0x1455
    1455:	00 0a                	add    BYTE PTR [bp+si],cl
    1457:	56                   	push   si
    1458:	61                   	popa
    1459:	6c                   	ins    BYTE PTR es:[di],dx
    145a:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    145f:	6f                   	outs   dx,WORD PTR ds:[si]
    1460:	6e                   	outs   dx,BYTE PTR ds:[si]
    1461:	01 00                	add    WORD PTR [bx+si],ax
    1463:	2f                   	das
    1464:	00 b4 15 3d          	add    BYTE PTR [si+0x3d15],dh
    1468:	17                   	pop    ss
    1469:	73 14                	jae    0x147f
    146b:	02 00                	add    al,BYTE PTR [bx+si]
    146d:	d8 00                	fadd   DWORD PTR [bx+si]
    146f:	ee                   	out    dx,al
    1470:	14 65                	adc    al,0x65
    1472:	17                   	pop    ss
    1473:	7b 14                	jnp    0x1489
    1475:	00 00                	add    BYTE PTR [bx+si],al
    1477:	00 00                	add    BYTE PTR [bx+si],al
    1479:	6f                   	outs   dx,WORD PTR ds:[si]
    147a:	17                   	pop    ss
    147b:	3b 18                	cmp    bx,WORD PTR [bx+si]
    147d:	55                   	push   bp
    147e:	89 e5                	mov    bp,sp
    1480:	b8 06 04             	mov    ax,0x406
    1483:	9a 44 04 d6 14       	call   0x14d6:0x444
    1488:	81 ec 06 04          	sub    sp,0x406
    148c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    148f:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1496:	26 83 bd 04 01 01    	cmp    WORD PTR es:[di+0x104],0x1
    149c:	74 03                	je     0x14a1
    149e:	e9 e3 02             	jmp    0x1784
    14a1:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    14a6:	89 be fa fd          	mov    WORD PTR [bp-0x206],di
    14aa:	8c 86 fc fd          	mov    WORD PTR [bp-0x204],es
    14ae:	06                   	push   es
    14af:	57                   	push   di
    14b0:	9a 33 17 e7 14       	call   0x14e7:0x1733
    14b5:	8b c8                	mov    cx,ax
    14b7:	8b da                	mov    bx,dx
    14b9:	a1 4c 01             	mov    ax,ds:0x14c
    14bc:	99                   	cwd
    14bd:	3b d3                	cmp    dx,bx
    14bf:	75 07                	jne    0x14c8
    14c1:	3b c1                	cmp    ax,cx
    14c3:	75 03                	jne    0x14c8
    14c5:	e9 bc 02             	jmp    0x1784
    14c8:	8d be fa fb          	lea    di,[bp-0x406]
    14cc:	16                   	push   ss
    14cd:	57                   	push   di
    14ce:	bf 19 14             	mov    di,0x1419
    14d1:	0e                   	push   cs
    14d2:	57                   	push   di
    14d3:	9a cd 17 f3 14       	call   0x14f3:0x17cd
    14d8:	8d be fa fc          	lea    di,[bp-0x306]
    14dc:	16                   	push   ss
    14dd:	57                   	push   di
    14de:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    14e2:	06                   	push   es
    14e3:	57                   	push   di
    14e4:	9a 33 17 bf 15       	call   0x15bf:0x1733
    14e9:	52                   	push   dx
    14ea:	50                   	push   ax
    14eb:	9a a9 08 8e 21       	call   0x218e:0x8a9
    14f0:	9a 4c 18 fd 14       	call   0x14fd:0x184c
    14f5:	bf 3d 14             	mov    di,0x143d
    14f8:	0e                   	push   cs
    14f9:	57                   	push   di
    14fa:	9a 4c 18 0b 15       	call   0x150b:0x184c
    14ff:	8d be 00 fe          	lea    di,[bp-0x200]
    1503:	16                   	push   ss
    1504:	57                   	push   di
    1505:	68 ff 00             	push   0xff
    1508:	9a e7 17 25 15       	call   0x1525:0x17e7
    150d:	8d be fa fc          	lea    di,[bp-0x306]
    1511:	16                   	push   ss
    1512:	57                   	push   di
    1513:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1516:	06                   	push   es
    1517:	57                   	push   di
    1518:	9a 53 1d 3d 15       	call   0x153d:0x1d53
    151d:	bf 3d 14             	mov    di,0x143d
    1520:	0e                   	push   cs
    1521:	57                   	push   di
    1522:	9a 4c 18 33 15       	call   0x1533:0x184c
    1527:	8d be 00 ff          	lea    di,[bp-0x100]
    152b:	16                   	push   ss
    152c:	57                   	push   di
    152d:	68 ff 00             	push   0xff
    1530:	9a e7 17 fc 15       	call   0x15fc:0x17e7
    1535:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1538:	06                   	push   es
    1539:	57                   	push   di
    153a:	9a b9 62 fe 17       	call   0x17fe:0x62b9
    153f:	50                   	push   ax
    1540:	8d be 01 fe          	lea    di,[bp-0x1ff]
    1544:	16                   	push   ss
    1545:	57                   	push   di
    1546:	8d be 01 ff          	lea    di,[bp-0xff]
    154a:	16                   	push   ss
    154b:	57                   	push   di
    154c:	6a 34                	push   0x34
    154e:	9a ce 30 00 00       	call   0x0:0x30ce
    1553:	3d 06 00             	cmp    ax,0x6
    1556:	74 03                	je     0x155b
    1558:	e9 22 02             	jmp    0x177d
    155b:	b8 6b 14             	mov    ax,0x146b
    155e:	0e                   	push   cs
    155f:	50                   	push   ax
    1560:	55                   	push   bp
    1561:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1565:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1569:	b8 61 14             	mov    ax,0x1461
    156c:	0e                   	push   cs
    156d:	50                   	push   ax
    156e:	55                   	push   bp
    156f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1573:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1577:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    157a:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    157f:	89 be f6 fd          	mov    WORD PTR [bp-0x20a],di
    1583:	8c 86 f8 fd          	mov    WORD PTR [bp-0x208],es
    1587:	c7 86 ee fd 01 00    	mov    WORD PTR [bp-0x212],0x1
    158d:	c7 86 f0 fd 00 00    	mov    WORD PTR [bp-0x210],0x0
    1593:	c6 86 f2 fd 00       	mov    BYTE PTR [bp-0x20e],0x0
    1598:	8d be ee fd          	lea    di,[bp-0x212]
    159c:	16                   	push   ss
    159d:	57                   	push   di
    159e:	6a 00                	push   0x0
    15a0:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    15a4:	06                   	push   es
    15a5:	57                   	push   di
    15a6:	9a 95 28 54 16       	call   0x1654:0x2895
    15ab:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    15af:	06                   	push   es
    15b0:	57                   	push   di
    15b1:	9a 3c 53 d1 15       	call   0x15d1:0x533c
    15b6:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    15ba:	06                   	push   es
    15bb:	57                   	push   di
    15bc:	9a 33 17 f4 15       	call   0x15f4:0x1733
    15c1:	52                   	push   dx
    15c2:	50                   	push   ax
    15c3:	bf 3f 14             	mov    di,0x143f
    15c6:	0e                   	push   cs
    15c7:	57                   	push   di
    15c8:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    15cc:	06                   	push   es
    15cd:	57                   	push   di
    15ce:	9a 9b 3b e9 15       	call   0x15e9:0x3b9b
    15d3:	89 c7                	mov    di,ax
    15d5:	8e c2                	mov    es,dx
    15d7:	06                   	push   es
    15d8:	57                   	push   di
    15d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15dc:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    15e0:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    15e4:	06                   	push   es
    15e5:	57                   	push   di
    15e6:	9a a0 54 5f 16       	call   0x165f:0x54a0
    15eb:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    15ef:	06                   	push   es
    15f0:	57                   	push   di
    15f1:	9a 33 17 34 16       	call   0x1634:0x1733
    15f6:	bf 4e 14             	mov    di,0x144e
    15f9:	9a 16 04 55 17       	call   0x1755:0x416
    15fe:	a3 4c 01             	mov    ds:0x14c,ax
    1601:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1604:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1608:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    160b:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    1610:	26 83 bd e4 00 01    	cmp    WORD PTR es:[di+0xe4],0x1
    1616:	74 03                	je     0x161b
    1618:	e9 19 01             	jmp    0x1734
    161b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    161e:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    1623:	89 be f6 fd          	mov    WORD PTR [bp-0x20a],di
    1627:	8c 86 f8 fd          	mov    WORD PTR [bp-0x208],es
    162b:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    162f:	06                   	push   es
    1630:	57                   	push   di
    1631:	9a 33 17 c1 16       	call   0x16c1:0x1733
    1636:	89 86 ee fd          	mov    WORD PTR [bp-0x212],ax
    163a:	89 96 f0 fd          	mov    WORD PTR [bp-0x210],dx
    163e:	c6 86 f2 fd 00       	mov    BYTE PTR [bp-0x20e],0x0
    1643:	8d be ee fd          	lea    di,[bp-0x212]
    1647:	16                   	push   ss
    1648:	57                   	push   di
    1649:	6a 00                	push   0x0
    164b:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    164f:	06                   	push   es
    1650:	57                   	push   di
    1651:	9a 95 28 f3 16       	call   0x16f3:0x2895
    1656:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    165a:	06                   	push   es
    165b:	57                   	push   di
    165c:	9a 3c 53 71 16       	call   0x1671:0x533c
    1661:	6a 00                	push   0x0
    1663:	bf 56 14             	mov    di,0x1456
    1666:	0e                   	push   cs
    1667:	57                   	push   di
    1668:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    166c:	06                   	push   es
    166d:	57                   	push   di
    166e:	9a 9b 3b 89 16       	call   0x1689:0x3b9b
    1673:	89 c7                	mov    di,ax
    1675:	8e c2                	mov    es,dx
    1677:	06                   	push   es
    1678:	57                   	push   di
    1679:	26 c4 3d             	les    di,DWORD PTR es:[di]
    167c:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    1680:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    1684:	06                   	push   es
    1685:	57                   	push   di
    1686:	9a a0 54 fe 16       	call   0x16fe:0x54a0
    168b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    168e:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    1693:	89 be f6 fd          	mov    WORD PTR [bp-0x20a],di
    1697:	8c 86 f8 fd          	mov    WORD PTR [bp-0x208],es
    169b:	a1 4e 01             	mov    ax,ds:0x14e
    169e:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    16a2:	b8 01 00             	mov    ax,0x1
    16a5:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    16a9:	7e 03                	jle    0x16ae
    16ab:	e9 86 00             	jmp    0x1734
    16ae:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    16b2:	eb 04                	jmp    0x16b8
    16b4:	ff 86 fe fd          	inc    WORD PTR [bp-0x202]
    16b8:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    16bc:	06                   	push   es
    16bd:	57                   	push   di
    16be:	9a 33 17 3f 2b       	call   0x2b3f:0x1733
    16c3:	89 86 e4 fd          	mov    WORD PTR [bp-0x21c],ax
    16c7:	89 96 e6 fd          	mov    WORD PTR [bp-0x21a],dx
    16cb:	c6 86 e8 fd 00       	mov    BYTE PTR [bp-0x218],0x0
    16d0:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    16d4:	99                   	cwd
    16d5:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    16d9:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    16dd:	c6 86 f0 fd 00       	mov    BYTE PTR [bp-0x210],0x0
    16e2:	8d be e4 fd          	lea    di,[bp-0x21c]
    16e6:	16                   	push   ss
    16e7:	57                   	push   di
    16e8:	6a 01                	push   0x1
    16ea:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    16ee:	06                   	push   es
    16ef:	57                   	push   di
    16f0:	9a 95 28 ff ff       	call   0xffff:0x2895
    16f5:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    16f9:	06                   	push   es
    16fa:	57                   	push   di
    16fb:	9a 3c 53 10 17       	call   0x1710:0x533c
    1700:	6a 00                	push   0x0
    1702:	bf 56 14             	mov    di,0x1456
    1705:	0e                   	push   cs
    1706:	57                   	push   di
    1707:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    170b:	06                   	push   es
    170c:	57                   	push   di
    170d:	9a 9b 3b 28 17       	call   0x1728:0x3b9b
    1712:	89 c7                	mov    di,ax
    1714:	8e c2                	mov    es,dx
    1716:	06                   	push   es
    1717:	57                   	push   di
    1718:	26 c4 3d             	les    di,DWORD PTR es:[di]
    171b:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    171f:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    1723:	06                   	push   es
    1724:	57                   	push   di
    1725:	9a a0 54 ff ff       	call   0xffff:0x54a0
    172a:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    172e:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    1732:	75 80                	jne    0x16b4
    1734:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1738:	83 c4 06             	add    sp,0x6
    173b:	eb 1f                	jmp    0x175c
    173d:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    1741:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    1745:	ff b6 f8 fd          	push   WORD PTR [bp-0x208]
    1749:	ff b6 f6 fd          	push   WORD PTR [bp-0x20a]
    174d:	9a 2d 34 ff ff       	call   0xffff:0x342d
    1752:	ea 85 13 5a 17       	jmp    0x175a:0x1385
    1757:	9a 34 14 79 17       	call   0x1779:0x1434
    175c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1760:	83 c4 06             	add    sp,0x6
    1763:	eb 16                	jmp    0x177b
    1765:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    1769:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    176d:	eb 07                	jmp    0x1776
    176f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1772:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1776:	9a 34 14 a2 17       	call   0x17a2:0x1434
    177b:	eb 07                	jmp    0x1784
    177d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1780:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1784:	c9                   	leave
    1785:	ca 0c 00             	retf   0xc
    1788:	e7 19                	out    0x19,ax
    178a:	a2 18 37             	mov    ds:0x3718,al
    178d:	18 00                	sbb    BYTE PTR [bx+si],al
    178f:	00 24                	add    BYTE PTR [si],ah
    1791:	18 d4                	sbb    ah,dl
    1793:	01 fb                	add    bx,di
    1795:	04 01                	add    al,0x1
    1797:	1a 39                	sbb    bh,BYTE PTR [bx+di]
    1799:	3f                   	aas
    179a:	ae                   	scas   al,BYTE PTR es:[di]
    179b:	17                   	pop    ss
    179c:	9a 1f 1d 1a cb       	call   0xcb1a:0x1d1f
    17a1:	1f                   	pop    ds
    17a2:	9e                   	sahf
    17a3:	17                   	pop    ss
    17a4:	ad                   	lods   ax,WORD PTR ds:[si]
    17a5:	27                   	daa
    17a6:	22 18                	and    bl,BYTE PTR [bx+si]
    17a8:	cd 11                	int    0x11
    17aa:	b2 17                	mov    dl,0x17
    17ac:	f7 2a                	imul   WORD PTR [bp+si]
    17ae:	0e                   	push   cs
    17af:	18 fa                	sbb    dl,bh
    17b1:	10 68 1d             	adc    BYTE PTR [bx+si+0x1d],ch
    17b4:	d6                   	(bad)
    17b5:	14 e6                	adc    al,0xe6
    17b7:	17                   	pop    ss
    17b8:	f4                   	hlt
    17b9:	4f                   	dec    di
    17ba:	d2 17                	rcl    BYTE PTR [bx],cl
    17bc:	9a 28 1a 18 85       	call   0x8518:0x1a28
    17c1:	29 c6                	sub    si,ax
    17c3:	17                   	pop    ss
    17c4:	57                   	push   di
    17c5:	4d                   	dec    bp
    17c6:	ca 17 91             	retf   0x9117
    17c9:	2f                   	das
    17ca:	ea 17 63 31 ee       	jmp    0xee31:0x6317
    17cf:	17                   	pop    ss
    17d0:	21 50 aa             	and    WORD PTR [bx+si-0x56],dx
    17d3:	17                   	pop    ss
    17d4:	53                   	push   bx
    17d5:	25 a6 17             	and    ax,0x17a6
    17d8:	d9 62 e2             	fldenv [bp+si-0x1e]
    17db:	17                   	pop    ss
    17dc:	55                   	push   bp
    17dd:	2e be 17 8f          	cs mov si,0x8f17
    17e1:	60                   	pusha
    17e2:	1e                   	push   ds
    17e3:	18 3a                	sbb    BYTE PTR [bp+si],bh
    17e5:	1c f7                	sbb    al,0xf7
    17e7:	1a e2                	sbb    ah,dl
    17e9:	2f                   	das
    17ea:	d6                   	(bad)
    17eb:	17                   	pop    ss
    17ec:	08 61 f2             	or     BYTE PTR [bx+di-0xe],ah
    17ef:	17                   	pop    ss
    17f0:	5c                   	pop    sp
    17f1:	61                   	popa
    17f2:	f6 17                	not    BYTE PTR [bx]
    17f4:	62 5c fa             	bound  bx,DWORD PTR [si-0x6]
    17f7:	17                   	pop    ss
    17f8:	3a 61 b6             	cmp    ah,BYTE PTR [bx+di-0x4a]
    17fb:	17                   	pop    ss
    17fc:	72 3f                	jb     0x183d
    17fe:	12 18                	adc    bl,BYTE PTR [bx+si]
    1800:	58                   	pop    ax
    1801:	3a 06 18 ec          	cmp    al,BYTE PTR ds:0xec18
    1805:	3d 0a 18             	cmp    ax,0x180a
    1808:	e4 3c                	in     al,0x3c
    180a:	9a 17 ed 3e de       	call   0xde3e:0xed17
    180f:	17                   	pop    ss
    1810:	77 3e                	ja     0x1850
    1812:	da 17                	ficom  DWORD PTR [bx]
    1814:	e6 31                	out    0x31,al
    1816:	02 18                	add    bl,BYTE PTR [bx+si]
    1818:	3c 47                	cmp    al,0x47
    181a:	c2 17 ae             	ret    0xae17
    181d:	5f                   	pop    di
    181e:	ce                   	into
    181f:	17                   	pop    ss
    1820:	e9 5c 96             	jmp    0xae7f
    1823:	17                   	pop    ss
    1824:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
    1827:	6f                   	outs   dx,WORD PTR ds:[si]
    1828:	72 6d                	jb     0x1897
    182a:	53                   	push   bx
    182b:	4e                   	dec    si
    182c:	65 77 5f             	gs ja  0x188e
    182f:	43                   	inc    bx
    1830:	72 65                	jb     0x1897
    1832:	61                   	popa
    1833:	74 69                	je     0x189e
    1835:	6f                   	outs   dx,WORD PTR ds:[si]
    1836:	6e                   	outs   dx,BYTE PTR ds:[si]
    1837:	06                   	push   es
    1838:	00 14                	add    BYTE PTR [si],dl
    183a:	1a 54 18             	sbb    dl,BYTE PTR [si+0x18]
    183d:	14 44                	adc    al,0x44
    183f:	72 69                	jb     0x18aa
    1841:	76 65                	jbe    0x18a8
    1843:	43                   	inc    bx
    1844:	6f                   	outs   dx,WORD PTR ds:[si]
    1845:	6d                   	ins    WORD PTR es:[di],dx
    1846:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    1849:	6f                   	outs   dx,WORD PTR ds:[si]
    184a:	78 31                	js     0x187d
    184c:	43                   	inc    bx
    184d:	68 61 6e             	push   0x6e61
    1850:	67 65 aa             	gs stos BYTE PTR es:[edi],al
    1853:	1a 65 18             	sbb    ah,BYTE PTR [di+0x18]
    1856:	0c 42                	or     al,0x42
    1858:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    185d:	33 43 6c             	xor    ax,WORD PTR [bp+di+0x6c]
    1860:	69 63 6b d2 1a       	imul   sp,WORD PTR [bp+di+0x6b],0x1ad2
    1865:	74 18                	je     0x187f
    1867:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
    186a:	72 6d                	jb     0x18d9
    186c:	43                   	inc    bx
    186d:	72 65                	jb     0x18d4
    186f:	61                   	popa
    1870:	74 65                	je     0x18d7
    1872:	27                   	daa
    1873:	1b 85 18 0c          	sbb    ax,WORD PTR [di+0xc18]
    1877:	54                   	push   sp
    1878:	65 73 74             	gs jae 0x18ef
    187b:	42                   	inc    dx
    187c:	74 6e                	je     0x18ec
    187e:	43                   	inc    bx
    187f:	6c                   	ins    BYTE PTR es:[di],dx
    1880:	69 63 6b a1 1b       	imul   sp,WORD PTR [bp+di+0x6b],0x1ba1
    1885:	95                   	xchg   bp,ax
    1886:	18 0b                	sbb    BYTE PTR [bp+di],cl
    1888:	50                   	push   ax
    1889:	72 69                	jb     0x18f4
    188b:	6e                   	outs   dx,BYTE PTR ds:[si]
    188c:	74 31                	je     0x18bf
    188e:	43                   	inc    bx
    188f:	6c                   	ins    BYTE PTR es:[di],dx
    1890:	69 63 6b e4 1b       	imul   sp,WORD PTR [bp+di+0x6b],0x1be4
    1895:	fd                   	std
    1896:	19 0a                	sbb    WORD PTR [bp+si],cx
    1898:	43                   	inc    bx
    1899:	6f                   	outs   dx,WORD PTR ds:[si]
    189a:	70 79                	jo     0x1915
    189c:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
    189f:	69 63 6b 16 00       	imul   sp,WORD PTR [bp+di+0x6b],0x16
    18a4:	b9 19 7c             	mov    cx,0x7c19
    18a7:	01 00                	add    WORD PTR [bx+si],ax
    18a9:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    18ad:	6e                   	outs   dx,BYTE PTR ds:[si]
    18ae:	65 6c                	gs ins BYTE PTR es:[di],dx
    18b0:	31 80 01 04          	xor    WORD PTR [bx+si+0x401],ax
    18b4:	00 05                	add    BYTE PTR [di],al
    18b6:	4d                   	dec    bp
    18b7:	65 6d                	gs ins WORD PTR es:[di],dx
    18b9:	6f                   	outs   dx,WORD PTR ds:[si]
    18ba:	31 84 01 00          	xor    WORD PTR [si+0x1],ax
    18be:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    18c2:	6e                   	outs   dx,BYTE PTR ds:[si]
    18c3:	65 6c                	gs ins BYTE PTR es:[di],dx
    18c5:	32 88 01 00          	xor    cl,BYTE PTR [bx+si+0x1]
    18c9:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    18cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    18ce:	65 6c                	gs ins BYTE PTR es:[di],dx
    18d0:	33 8c 01 08          	xor    cx,WORD PTR [si+0x801]
    18d4:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    18d8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    18db:	31 90 01 0c          	xor    WORD PTR [bx+si+0xc01],dx
    18df:	00 09                	add    BYTE PTR [bx+di],cl
    18e1:	4d                   	dec    bp
    18e2:	61                   	popa
    18e3:	73 6b                	jae    0x1950
    18e5:	45                   	inc    bp
    18e6:	64 69 74 31 94 01    	imul   si,WORD PTR fs:[si+0x31],0x194
    18ec:	10 00                	adc    BYTE PTR [bx+si],al
    18ee:	0b 52 61             	or     dx,WORD PTR [bp+si+0x61]
    18f1:	64 69 6f 47 72 6f    	imul   bp,WORD PTR fs:[bx+0x47],0x6f72
    18f7:	75 70                	jne    0x1969
    18f9:	31 98 01 00          	xor    WORD PTR [bx+si+0x1],bx
    18fd:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    1901:	6e                   	outs   dx,BYTE PTR ds:[si]
    1902:	65 6c                	gs ins BYTE PTR es:[di],dx
    1904:	34 9c                	xor    al,0x9c
    1906:	01 08                	add    WORD PTR [bx+si],cx
    1908:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    190c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    190f:	32 a0 01 08          	xor    ah,BYTE PTR [bx+si+0x801]
    1913:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1917:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    191a:	33 a4 01 08          	xor    sp,WORD PTR [si+0x801]
    191e:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1922:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1925:	34 a8                	xor    al,0xa8
    1927:	01 14                	add    WORD PTR [si],dx
    1929:	00 11                	add    BYTE PTR [bx+di],dl
    192b:	44                   	inc    sp
    192c:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    1931:	6f                   	outs   dx,WORD PTR ds:[si]
    1932:	72 79                	jb     0x19ad
    1934:	4c                   	dec    sp
    1935:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    193a:	78 31                	js     0x196d
    193c:	ac                   	lods   al,BYTE PTR ds:[si]
    193d:	01 18                	add    WORD PTR [bx+si],bx
    193f:	00 0e 44 72          	add    BYTE PTR ds:0x7244,cl
    1943:	69 76 65 43 6f       	imul   si,WORD PTR [bp+0x65],0x6f43
    1948:	6d                   	ins    WORD PTR es:[di],dx
    1949:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    194c:	6f                   	outs   dx,WORD PTR ds:[si]
    194d:	78 31                	js     0x1980
    194f:	b0 01                	mov    al,0x1
    1951:	00 00                	add    BYTE PTR [bx+si],al
    1953:	06                   	push   es
    1954:	50                   	push   ax
    1955:	61                   	popa
    1956:	6e                   	outs   dx,BYTE PTR ds:[si]
    1957:	65 6c                	gs ins BYTE PTR es:[di],dx
    1959:	35 b4 01             	xor    ax,0x1b4
    195c:	1c 00                	sbb    al,0x0
    195e:	07                   	pop    es
    195f:	42                   	inc    dx
    1960:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1965:	31 b8 01 1c          	xor    WORD PTR [bx+si+0x1c01],di
    1969:	00 07                	add    BYTE PTR [bx],al
    196b:	42                   	inc    dx
    196c:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1971:	32 bc 01 1c          	xor    bh,BYTE PTR [si+0x1c01]
    1975:	00 07                	add    BYTE PTR [bx],al
    1977:	42                   	inc    dx
    1978:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    197d:	33 c0                	xor    ax,ax
    197f:	01 20                	add    WORD PTR [bx+si],sp
    1981:	00 0a                	add    BYTE PTR [bp+si],cl
    1983:	50                   	push   ax
    1984:	6f                   	outs   dx,WORD PTR ds:[si]
    1985:	70 75                	jo     0x19fc
    1987:	70 4d                	jo     0x19d6
    1989:	65 6e                	outs   dx,BYTE PTR gs:[si]
    198b:	75 31                	jne    0x19be
    198d:	c4 01                	les    ax,DWORD PTR [bx+di]
    198f:	24 00                	and    al,0x0
    1991:	06                   	push   es
    1992:	50                   	push   ax
    1993:	72 69                	jb     0x19fe
    1995:	6e                   	outs   dx,BYTE PTR ds:[si]
    1996:	74 31                	je     0x19c9
    1998:	c8 01 24 00          	enter  0x2401,0x0
    199c:	05 43 6f             	add    ax,0x6f43
    199f:	70 79                	jo     0x1a1a
    19a1:	31 cc                	xor    sp,cx
    19a3:	01 1c                	add    WORD PTR [si],bx
    19a5:	00 07                	add    BYTE PTR [bx],al
    19a7:	54                   	push   sp
    19a8:	65 73 74             	gs jae 0x1a1f
    19ab:	42                   	inc    dx
    19ac:	74 6e                	je     0x1a1c
    19ae:	d0 01                	rol    BYTE PTR [bx+di],1
    19b0:	28 00                	sub    BYTE PTR [bx+si],al
    19b2:	06                   	push   es
    19b3:	49                   	dec    cx
    19b4:	6d                   	ins    WORD PTR es:[di],dx
    19b5:	61                   	popa
    19b6:	67 65 31 0b          	xor    WORD PTR gs:[ebx],cx
    19ba:	00 ad 0d cd          	add    BYTE PTR [di-0x32f3],ch
    19be:	19 91 12 c5          	sbb    WORD PTR [bx+di-0x3aee],dx
    19c2:	19 17                	sbb    WORD PTR [bx],dx
    19c4:	06                   	push   es
    19c5:	00 20                	add    BYTE PTR [bx+si],ah
    19c7:	6f                   	outs   dx,WORD PTR ds:[si]
    19c8:	01 ff                	add    di,di
    19ca:	ff                   	(bad)
    19cb:	fb                   	sti
    19cc:	13 e5                	adc    sp,bp
    19ce:	19 fc                	sbb    sp,di
    19d0:	06                   	push   es
    19d1:	d5 19                	aad    0x19
    19d3:	c5 0c                	lds    cx,DWORD PTR [si]
    19d5:	75 1a                	jne    0x19f1
    19d7:	ac                   	lods   al,BYTE PTR ds:[si]
    19d8:	04 3f                	add    al,0x3f
    19da:	1b c6                	sbb    ax,si
    19dc:	03 e1                	add    sp,cx
    19de:	19 94 00 14          	sbb    WORD PTR [si+0x1400],dx
    19e2:	20 65 06             	and    BYTE PTR [di+0x6],ah
    19e5:	f5                   	cmc
    19e6:	1c 07                	sbb    al,0x7
    19e8:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
    19eb:	6f                   	outs   dx,WORD PTR ds:[si]
    19ec:	72 6d                	jb     0x1a5b
    19ee:	53                   	push   bx
    19ef:	4e                   	dec    si
    19f0:	65 77 5f             	gs ja  0x1a52
    19f3:	43                   	inc    bx
    19f4:	72 65                	jb     0x1a5b
    19f6:	61                   	popa
    19f7:	74 69                	je     0x1a62
    19f9:	6f                   	outs   dx,WORD PTR ds:[si]
    19fa:	6e                   	outs   dx,BYTE PTR ds:[si]
    19fb:	a8 17                	test   al,0x17
    19fd:	ae                   	scas   al,BYTE PTR es:[di]
    19fe:	1b 7b 06             	sbb    di,WORD PTR [bp+di+0x6]
    1a01:	cc                   	int3
    1a02:	1a 38                	sbb    bh,BYTE PTR [bx+si]
    1a04:	00 04                	add    BYTE PTR [si],al
    1a06:	53                   	push   bx
    1a07:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a08:	65 77 00             	gs ja  0x1a0b
    1a0b:	00 00                	add    BYTE PTR [bx+si],al
    1a0d:	00 00                	add    BYTE PTR [bx+si],al
    1a0f:	00 ff                	add    bh,bh
    1a11:	00 00                	add    BYTE PTR [bx+si],al
    1a13:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1a16:	e5 b8                	in     ax,0xb8
    1a18:	00 01                	add    BYTE PTR [bx+di],al
    1a1a:	9a 44 04 3a 1a       	call   0x1a3a:0x444
    1a1f:	81 ec 00 01          	sub    sp,0x100
    1a23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a26:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    1a2b:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1a30:	30 e4                	xor    ah,ah
    1a32:	2d 40 00             	sub    ax,0x40
    1a35:	71 05                	jno    0x1a3c
    1a37:	9a 3e 04 43 1a       	call   0x1a43:0x43e
    1a3c:	99                   	cwd
    1a3d:	bf 0c 1a             	mov    di,0x1a0c
    1a40:	9a 16 04 52 1a       	call   0x1a52:0x416
    1a45:	50                   	push   ax
    1a46:	8d be 00 ff          	lea    di,[bp-0x100]
    1a4a:	16                   	push   ss
    1a4b:	57                   	push   di
    1a4c:	68 ff 00             	push   0xff
    1a4f:	9a 58 0e 5d 1a       	call   0x1a5d:0xe58
    1a54:	8d be 00 ff          	lea    di,[bp-0x100]
    1a58:	16                   	push   ss
    1a59:	57                   	push   di
    1a5a:	9a b2 0e 62 1a       	call   0x1a62:0xeb2
    1a5f:	9a 01 04 b2 1a       	call   0x1ab2:0x401
    1a64:	09 c0                	or     ax,ax
    1a66:	74 21                	je     0x1a89
    1a68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a6b:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    1a70:	06                   	push   es
    1a71:	57                   	push   di
    1a72:	9a 4b 2f 85 1a       	call   0x1a85:0x2f4b
    1a77:	50                   	push   ax
    1a78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a7b:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    1a80:	06                   	push   es
    1a81:	57                   	push   di
    1a82:	9a a4 1c a4 1a       	call   0x1aa4:0x1ca4
    1a87:	eb 1d                	jmp    0x1aa6
    1a89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a8c:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    1a91:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1a96:	50                   	push   ax
    1a97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a9a:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    1a9f:	06                   	push   es
    1aa0:	57                   	push   di
    1aa1:	9a 65 2f ff ff       	call   0xffff:0x2f65
    1aa6:	c9                   	leave
    1aa7:	ca 08 00             	retf   0x8
    1aaa:	55                   	push   bp
    1aab:	89 e5                	mov    bp,sp
    1aad:	31 c0                	xor    ax,ax
    1aaf:	9a 44 04 da 1a       	call   0x1ada:0x444
    1ab4:	6a 01                	push   0x1
    1ab6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ab9:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    1abe:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    1ac3:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1ac7:	06                   	push   es
    1ac8:	57                   	push   di
    1ac9:	9a b2 77 21 1b       	call   0x1b21:0x77b2
    1ace:	c9                   	leave
    1acf:	ca 08 00             	retf   0x8
    1ad2:	55                   	push   bp
    1ad3:	89 e5                	mov    bp,sp
    1ad5:	31 c0                	xor    ax,ax
    1ad7:	9a 44 04 16 1b       	call   0x1b16:0x444
    1adc:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1ae0:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    1ae5:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
    1ae9:	50                   	push   ax
    1aea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aed:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    1af2:	06                   	push   es
    1af3:	57                   	push   di
    1af4:	9a 77 1c 71 1b       	call   0x1b71:0x1c77
    1af9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1afc:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    1b01:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1b05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b08:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    1b0d:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    1b11:	71 05                	jno    0x1b18
    1b13:	9a 3e 04 30 1b       	call   0x1b30:0x43e
    1b18:	50                   	push   ax
    1b19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b1c:	06                   	push   es
    1b1d:	57                   	push   di
    1b1e:	9a f1 2e cd 1b       	call   0x1bcd:0x2ef1
    1b23:	c9                   	leave
    1b24:	ca 08 00             	retf   0x8
    1b27:	55                   	push   bp
    1b28:	89 e5                	mov    bp,sp
    1b2a:	b8 08 00             	mov    ax,0x8
    1b2d:	9a 44 04 46 1b       	call   0x1b46:0x444
    1b32:	83 ec 08             	sub    sp,0x8
    1b35:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b38:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1b3b:	bf ac 04             	mov    di,0x4ac
    1b3e:	b8 0c 20             	mov    ax,0x200c
    1b41:	50                   	push   ax
    1b42:	57                   	push   di
    1b43:	9a 73 22 a9 1b       	call   0x1ba9:0x2273
    1b48:	89 c7                	mov    di,ax
    1b4a:	8e c2                	mov    es,dx
    1b4c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b50:	99                   	cwd
    1b51:	b9 02 00             	mov    cx,0x2
    1b54:	f7 f9                	idiv   cx
    1b56:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b59:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1b5d:	99                   	cwd
    1b5e:	b9 02 00             	mov    cx,0x2
    1b61:	f7 f9                	idiv   cx
    1b63:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b66:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b69:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b6c:	06                   	push   es
    1b6d:	57                   	push   di
    1b6e:	9a d4 19 c3 1b       	call   0x1bc3:0x19d4
    1b73:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b76:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1b79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b7c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1b81:	26 c6 45 25 00       	mov    BYTE PTR es:[di+0x25],0x0
    1b86:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b89:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b8f:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1b94:	06                   	push   es
    1b95:	57                   	push   di
    1b96:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b99:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    1b9d:	c9                   	leave
    1b9e:	ca 08 00             	retf   0x8
    1ba1:	55                   	push   bp
    1ba2:	89 e5                	mov    bp,sp
    1ba4:	31 c0                	xor    ax,ax
    1ba6:	9a 44 04 ed 1b       	call   0x1bed:0x444
    1bab:	9a c6 34 e8 1d       	call   0x1de8:0x34c6
    1bb0:	08 c0                	or     al,al
    1bb2:	74 2c                	je     0x1be0
    1bb4:	6a 00                	push   0x0
    1bb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb9:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    1bbe:	06                   	push   es
    1bbf:	57                   	push   di
    1bc0:	9a 77 1c de 1b       	call   0x1bde:0x1c77
    1bc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc8:	06                   	push   es
    1bc9:	57                   	push   di
    1bca:	9a 2d 5a df 1c       	call   0x1cdf:0x5a2d
    1bcf:	6a 01                	push   0x1
    1bd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bd4:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    1bd9:	06                   	push   es
    1bda:	57                   	push   di
    1bdb:	9a 77 1c 01 1c       	call   0x1c01:0x1c77
    1be0:	c9                   	leave
    1be1:	ca 08 00             	retf   0x8
    1be4:	55                   	push   bp
    1be5:	89 e5                	mov    bp,sp
    1be7:	b8 14 00             	mov    ax,0x14
    1bea:	9a 44 04 58 1c       	call   0x1c58:0x444
    1bef:	83 ec 14             	sub    sp,0x14
    1bf2:	6a 00                	push   0x0
    1bf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf7:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    1bfc:	06                   	push   es
    1bfd:	57                   	push   di
    1bfe:	9a 77 1c 14 1c       	call   0x1c14:0x1c77
    1c03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c06:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1c0a:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1c0f:	06                   	push   es
    1c10:	57                   	push   di
    1c11:	9a bf 17 27 1c       	call   0x1c27:0x17bf
    1c16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c19:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1c1d:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1c22:	06                   	push   es
    1c23:	57                   	push   di
    1c24:	9a e1 17 41 1c       	call   0x1c41:0x17e1
    1c29:	31 c0                	xor    ax,ax
    1c2b:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1c2e:	31 c0                	xor    ax,ax
    1c30:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1c33:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1c36:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1c39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c3c:	06                   	push   es
    1c3d:	57                   	push   di
    1c3e:	9a d4 19 d0 1c       	call   0x1cd0:0x19d4
    1c43:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1c46:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    1c49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c4c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    1c50:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    1c53:	71 05                	jno    0x1c5a
    1c55:	9a 3e 04 6c 1c       	call   0x1c6c:0x43e
    1c5a:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1c5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c60:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1c64:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    1c67:	71 05                	jno    0x1c6e
    1c69:	9a 3e 04 80 1c       	call   0x1c80:0x43e
    1c6e:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c74:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1c78:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    1c7b:	71 05                	jno    0x1c82
    1c7d:	9a 3e 04 94 1c       	call   0x1c94:0x43e
    1c82:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1c85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c88:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1c8c:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    1c8f:	71 05                	jno    0x1c96
    1c91:	9a 3e 04 50 1d       	call   0x1d50:0x43e
    1c96:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1c99:	31 c0                	xor    ax,ax
    1c9b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1c9e:	31 c0                	xor    ax,ax
    1ca0:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1ca3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca6:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1cab:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1caf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb5:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1cba:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1cbe:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1cc1:	6a 00                	push   0x0
    1cc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cc6:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1ccb:	06                   	push   es
    1ccc:	57                   	push   di
    1ccd:	9a 77 1c 30 1d       	call   0x1d30:0x1c77
    1cd2:	8d 7e f8             	lea    di,[bp-0x8]
    1cd5:	16                   	push   ss
    1cd6:	57                   	push   di
    1cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cda:	06                   	push   es
    1cdb:	57                   	push   di
    1cdc:	9a d5 33 c4 1d       	call   0x1dc4:0x33d5
    1ce1:	52                   	push   dx
    1ce2:	50                   	push   ax
    1ce3:	8d 7e f0             	lea    di,[bp-0x10]
    1ce6:	16                   	push   ss
    1ce7:	57                   	push   di
    1ce8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ceb:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1cf0:	06                   	push   es
    1cf1:	57                   	push   di
    1cf2:	9a 94 1f 10 20       	call   0x2010:0x1f94
    1cf7:	89 c7                	mov    di,ax
    1cf9:	8e c2                	mov    es,dx
    1cfb:	06                   	push   es
    1cfc:	57                   	push   di
    1cfd:	9a 10 1b 36 25       	call   0x2536:0x1b10
    1d02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d05:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1d0a:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    1d0f:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    1d14:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    1d18:	06                   	push   es
    1d19:	57                   	push   di
    1d1a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d1d:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1d21:	6a 01                	push   0x1
    1d23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d26:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    1d2b:	06                   	push   es
    1d2c:	57                   	push   di
    1d2d:	9a 77 1c ac 1d       	call   0x1dac:0x1c77
    1d32:	c9                   	leave
    1d33:	ca 08 00             	retf   0x8
    1d36:	1a 20                	sbb    ah,BYTE PTR [bx+si]
    1d38:	51                   	push   cx
    1d39:	1e                   	push   ds
    1d3a:	e4 1d                	in     al,0x1d
    1d3c:	00 00                	add    BYTE PTR [bx+si],al
    1d3e:	d2 1d                	rcr    BYTE PTR [di],cl
    1d40:	14 02                	adc    al,0x2
    1d42:	fb                   	sti
    1d43:	04 33                	add    al,0x33
    1d45:	20 39                	and    BYTE PTR [bx+di],bh
    1d47:	3f                   	aas
    1d48:	5c                   	pop    sp
    1d49:	1d 9a 1f             	sbb    ax,0x1f9a
    1d4c:	47                   	inc    di
    1d4d:	20 cb                	and    bl,cl
    1d4f:	1f                   	pop    ds
    1d50:	4c                   	dec    sp
    1d51:	1d ad 27             	sbb    ax,0x27ad
    1d54:	d0 1d                	rcr    BYTE PTR [di],1
    1d56:	cd 11                	int    0x11
    1d58:	60                   	pusha
    1d59:	1d f7 2a             	sbb    ax,0x2af7
    1d5c:	bc 1d fa             	mov    sp,0xfa1d
    1d5f:	10 c6                	adc    dh,al
    1d61:	25 d6 14             	and    ax,0x14d6
    1d64:	94                   	xchg   sp,ax
    1d65:	1d f4 4f             	sbb    ax,0x4ff4
    1d68:	80 1d 9a             	sbb    BYTE PTR [di],0x9a
    1d6b:	28 c8                	sub    al,cl
    1d6d:	1d 85 29             	sbb    ax,0x2985
    1d70:	74 1d                	je     0x1d8f
    1d72:	57                   	push   di
    1d73:	4d                   	dec    bp
    1d74:	78 1d                	js     0x1d93
    1d76:	91                   	xchg   cx,ax
    1d77:	2f                   	das
    1d78:	98                   	cbw
    1d79:	1d 63 31             	sbb    ax,0x3163
    1d7c:	9c                   	pushf
    1d7d:	1d 21 50             	sbb    ax,0x5021
    1d80:	58                   	pop    ax
    1d81:	1d 53 25             	sbb    ax,0x2553
    1d84:	54                   	push   sp
    1d85:	1d d9 62             	sbb    ax,0x62d9
    1d88:	90                   	nop
    1d89:	1d 55 2e             	sbb    ax,0x2e55
    1d8c:	6c                   	ins    BYTE PTR es:[di],dx
    1d8d:	1d 8f 60             	sbb    ax,0x608f
    1d90:	cc                   	int3
    1d91:	1d 3a 1c             	sbb    ax,0x1c3a
    1d94:	12 21                	adc    ah,BYTE PTR [bx+di]
    1d96:	e2 2f                	loop   0x1dc7
    1d98:	84 1d                	test   BYTE PTR [di],bl
    1d9a:	08 61 a0             	or     BYTE PTR [bx+di-0x60],ah
    1d9d:	1d 5c 61             	sbb    ax,0x615c
    1da0:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1da1:	1d 62 5c             	sbb    ax,0x5c62
    1da4:	a8 1d                	test   al,0x1d
    1da6:	3a 61 64             	cmp    ah,BYTE PTR [bx+di+0x64]
    1da9:	1d 72 3f             	sbb    ax,0x3f72
    1dac:	c0 1d 58             	rcr    BYTE PTR [di],0x58
    1daf:	3a b4 1d ec          	cmp    dh,BYTE PTR [si-0x13e3]
    1db3:	3d b8 1d             	cmp    ax,0x1db8
    1db6:	e4 3c                	in     al,0x3c
    1db8:	48                   	dec    ax
    1db9:	1d ed 3e             	sbb    ax,0x3eed
    1dbc:	8c 1d                	mov    WORD PTR [di],ds
    1dbe:	77 3e                	ja     0x1dfe
    1dc0:	88 1d                	mov    BYTE PTR [di],bl
    1dc2:	e6 31                	out    0x31,al
    1dc4:	b0 1d                	mov    al,0x1d
    1dc6:	3c 47                	cmp    al,0x47
    1dc8:	70 1d                	jo     0x1de7
    1dca:	ae                   	scas   al,BYTE PTR es:[di]
    1dcb:	5f                   	pop    di
    1dcc:	7c 1d                	jl     0x1deb
    1dce:	e9 5c 44             	jmp    0x622d
    1dd1:	1d 11 54             	sbb    ax,0x5411
    1dd4:	46                   	inc    si
    1dd5:	6f                   	outs   dx,WORD PTR ds:[si]
    1dd6:	72 6d                	jb     0x1e45
    1dd8:	53                   	push   bx
    1dd9:	4a                   	dec    dx
    1dda:	53                   	push   bx
    1ddb:	44                   	inc    sp
    1ddc:	5f                   	pop    di
    1ddd:	44                   	inc    sp
    1dde:	6f                   	outs   dx,WORD PTR ds:[si]
    1ddf:	63 49 6e             	arpl   WORD PTR [bx+di+0x6e],cx
    1de2:	66 6f                	outs   dx,DWORD PTR ds:[si]
    1de4:	07                   	pop    es
    1de5:	00 e8                	add    al,ch
    1de7:	20 f7                	and    bh,dh
    1de9:	1d 0a 46             	sbb    ax,0x460a
    1dec:	6f                   	outs   dx,WORD PTR ds:[si]
    1ded:	72 6d                	jb     0x1e5c
    1def:	43                   	inc    bx
    1df0:	72 65                	jb     0x1e57
    1df2:	61                   	popa
    1df3:	74 65                	je     0x1e5a
    1df5:	48                   	dec    ax
    1df6:	23 05                	and    ax,WORD PTR [di]
    1df8:	1e                   	push   ds
    1df9:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
    1dfc:	72 6d                	jb     0x1e6b
    1dfe:	43                   	inc    bx
    1dff:	6c                   	ins    BYTE PTR es:[di],dx
    1e00:	6f                   	outs   dx,WORD PTR ds:[si]
    1e01:	73 65                	jae    0x1e68
    1e03:	5d                   	pop    bp
    1e04:	23 16 1e 0c          	and    dx,WORD PTR ds:0xc1e
    1e08:	54                   	push   sp
    1e09:	65 73 74             	gs jae 0x1e80
    1e0c:	42                   	inc    dx
    1e0d:	74 6e                	je     0x1e7d
    1e0f:	43                   	inc    bx
    1e10:	6c                   	ins    BYTE PTR es:[di],dx
    1e11:	69 63 6b d7 23       	imul   sp,WORD PTR [bp+di+0x6b],0x23d7
    1e16:	26 1e                	es push ds
    1e18:	0b 50 72             	or     dx,WORD PTR [bx+si+0x72]
    1e1b:	69 6e 74 31 43       	imul   bp,WORD PTR [bp+0x74],0x4331
    1e20:	6c                   	ins    BYTE PTR es:[di],dx
    1e21:	69 63 6b 1a 24       	imul   sp,WORD PTR [bp+di+0x6b],0x241a
    1e26:	35 1e 0a             	xor    ax,0xa1e
    1e29:	43                   	inc    bx
    1e2a:	6f                   	outs   dx,WORD PTR ds:[si]
    1e2b:	70 79                	jo     0x1ea6
    1e2d:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
    1e30:	69 63 6b 6c 25       	imul   sp,WORD PTR [bp+di+0x6b],0x256c
    1e35:	46                   	inc    si
    1e36:	1e                   	push   ds
    1e37:	0c 42                	or     al,0x42
    1e39:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1e3e:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
    1e41:	69 63 6b 2d 23       	imul   sp,WORD PTR [bp+di+0x6b],0x232d
    1e46:	2f                   	das
    1e47:	20 08                	and    BYTE PTR [bx+si],cl
    1e49:	46                   	inc    si
    1e4a:	6f                   	outs   dx,WORD PTR ds:[si]
    1e4b:	72 6d                	jb     0x1eba
    1e4d:	53                   	push   bx
    1e4e:	68 6f 77             	push   0x776f
    1e51:	26 00 fc             	es add ah,bh
    1e54:	1f                   	pop    ds
    1e55:	7c 01                	jl     0x1e58
    1e57:	00 00                	add    BYTE PTR [bx+si],al
    1e59:	06                   	push   es
    1e5a:	4c                   	dec    sp
    1e5b:	61                   	popa
    1e5c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1e5f:	31 80 01 00          	xor    WORD PTR [bx+si+0x1],ax
    1e63:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1e67:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1e6a:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
    1e6e:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1e72:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1e75:	34 88                	xor    al,0x88
    1e77:	01 00                	add    WORD PTR [bx+si],ax
    1e79:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1e7d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1e80:	33 8c 01 04          	xor    cx,WORD PTR [si+0x401]
    1e84:	00 09                	add    BYTE PTR [bx+di],cl
    1e86:	47                   	inc    di
    1e87:	72 6f                	jb     0x1ef8
    1e89:	75 70                	jne    0x1efb
    1e8b:	42                   	inc    dx
    1e8c:	6f                   	outs   dx,WORD PTR ds:[si]
    1e8d:	78 31                	js     0x1ec0
    1e8f:	90                   	nop
    1e90:	01 00                	add    WORD PTR [bx+si],ax
    1e92:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1e96:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1e99:	35 94 01             	xor    ax,0x194
    1e9c:	00 00                	add    BYTE PTR [bx+si],al
    1e9e:	06                   	push   es
    1e9f:	4c                   	dec    sp
    1ea0:	61                   	popa
    1ea1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1ea4:	36 98                	ss cbw
    1ea6:	01 00                	add    WORD PTR [bx+si],ax
    1ea8:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1eac:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1eaf:	37                   	aaa
    1eb0:	9c                   	pushf
    1eb1:	01 00                	add    WORD PTR [bx+si],ax
    1eb3:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    1eb7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1eba:	38 a0 01 00          	cmp    BYTE PTR [bx+si+0x1],ah
    1ebe:	00 07                	add    BYTE PTR [bx],al
    1ec0:	4c                   	dec    sp
    1ec1:	61                   	popa
    1ec2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1ec5:	31 31                	xor    WORD PTR [bx+di],si
    1ec7:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1ec8:	01 00                	add    WORD PTR [bx+si],ax
    1eca:	00 07                	add    BYTE PTR [bx],al
    1ecc:	4c                   	dec    sp
    1ecd:	61                   	popa
    1ece:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1ed1:	31 35                	xor    WORD PTR [di],si
    1ed3:	a8 01                	test   al,0x1
    1ed5:	00 00                	add    BYTE PTR [bx+si],al
    1ed7:	06                   	push   es
    1ed8:	4c                   	dec    sp
    1ed9:	61                   	popa
    1eda:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1edd:	39 ac 01 08          	cmp    WORD PTR [si+0x801],bp
    1ee1:	00 05                	add    BYTE PTR [di],al
    1ee3:	45                   	inc    bp
    1ee4:	64 69 74 31 b0 01    	imul   si,WORD PTR fs:[si+0x31],0x1b0
    1eea:	08 00                	or     BYTE PTR [bx+si],al
    1eec:	05 45 64             	add    ax,0x6445
    1eef:	69 74 32 b4 01       	imul   si,WORD PTR [si+0x32],0x1b4
    1ef4:	08 00                	or     BYTE PTR [bx+si],al
    1ef6:	05 45 64             	add    ax,0x6445
    1ef9:	69 74 33 b8 01       	imul   si,WORD PTR [si+0x33],0x1b8
    1efe:	08 00                	or     BYTE PTR [bx+si],al
    1f00:	05 45 64             	add    ax,0x6445
    1f03:	69 74 34 bc 01       	imul   si,WORD PTR [si+0x34],0x1bc
    1f08:	08 00                	or     BYTE PTR [bx+si],al
    1f0a:	05 45 64             	add    ax,0x6445
    1f0d:	69 74 35 c0 01       	imul   si,WORD PTR [si+0x35],0x1c0
    1f12:	08 00                	or     BYTE PTR [bx+si],al
    1f14:	05 45 64             	add    ax,0x6445
    1f17:	69 74 36 c4 01       	imul   si,WORD PTR [si+0x36],0x1c4
    1f1c:	08 00                	or     BYTE PTR [bx+si],al
    1f1e:	05 45 64             	add    ax,0x6445
    1f21:	69 74 37 c8 01       	imul   si,WORD PTR [si+0x37],0x1c8
    1f26:	08 00                	or     BYTE PTR [bx+si],al
    1f28:	05 45 64             	add    ax,0x6445
    1f2b:	69 74 38 cc 01       	imul   si,WORD PTR [si+0x38],0x1cc
    1f30:	08 00                	or     BYTE PTR [bx+si],al
    1f32:	05 45 64             	add    ax,0x6445
    1f35:	69 74 39 d0 01       	imul   si,WORD PTR [si+0x39],0x1d0
    1f3a:	08 00                	or     BYTE PTR [bx+si],al
    1f3c:	06                   	push   es
    1f3d:	45                   	inc    bp
    1f3e:	64 69 74 31 30 d4    	imul   si,WORD PTR fs:[si+0x31],0xd430
    1f44:	01 08                	add    WORD PTR [bx+si],cx
    1f46:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
    1f4a:	69 74 31 31 d8       	imul   si,WORD PTR [si+0x31],0xd831
    1f4f:	01 08                	add    WORD PTR [bx+si],cx
    1f51:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
    1f55:	69 74 31 32 dc       	imul   si,WORD PTR [si+0x31],0xdc32
    1f5a:	01 08                	add    WORD PTR [bx+si],cx
    1f5c:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
    1f60:	69 74 31 33 e0       	imul   si,WORD PTR [si+0x31],0xe033
    1f65:	01 0c                	add    WORD PTR [si],cx
    1f67:	00 07                	add    BYTE PTR [bx],al
    1f69:	42                   	inc    dx
    1f6a:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1f6f:	31 e4                	xor    sp,sp
    1f71:	01 00                	add    WORD PTR [bx+si],ax
    1f73:	00 07                	add    BYTE PTR [bx],al
    1f75:	4c                   	dec    sp
    1f76:	61                   	popa
    1f77:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1f7a:	31 30                	xor    WORD PTR [bx+si],si
    1f7c:	e8 01 08             	call   0x2780
    1f7f:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
    1f83:	69 74 31 34 ec       	imul   si,WORD PTR [si+0x31],0xec34
    1f88:	01 00                	add    WORD PTR [bx+si],ax
    1f8a:	00 07                	add    BYTE PTR [bx],al
    1f8c:	4c                   	dec    sp
    1f8d:	61                   	popa
    1f8e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1f91:	31 32                	xor    WORD PTR [bp+si],si
    1f93:	f0 01 08             	lock add WORD PTR [bx+si],cx
    1f96:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
    1f9a:	69 74 31 35 f4       	imul   si,WORD PTR [si+0x31],0xf435
    1f9f:	01 00                	add    WORD PTR [bx+si],ax
    1fa1:	00 07                	add    BYTE PTR [bx],al
    1fa3:	4c                   	dec    sp
    1fa4:	61                   	popa
    1fa5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1fa8:	31 33                	xor    WORD PTR [bp+di],si
    1faa:	f8                   	clc
    1fab:	01 08                	add    WORD PTR [bx+si],cx
    1fad:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
    1fb1:	69 74 31 36 fc       	imul   si,WORD PTR [si+0x31],0xfc36
    1fb6:	01 0c                	add    WORD PTR [si],cx
    1fb8:	00 07                	add    BYTE PTR [bx],al
    1fba:	54                   	push   sp
    1fbb:	65 73 74             	gs jae 0x2032
    1fbe:	42                   	inc    dx
    1fbf:	74 6e                	je     0x202f
    1fc1:	00 02                	add    BYTE PTR [bp+si],al
    1fc3:	10 00                	adc    BYTE PTR [bx+si],al
    1fc5:	06                   	push   es
    1fc6:	49                   	dec    cx
    1fc7:	6d                   	ins    WORD PTR es:[di],dx
    1fc8:	61                   	popa
    1fc9:	67 65 31 04 02       	xor    WORD PTR gs:[edx+eax*1],ax
    1fce:	14 00                	adc    al,0x0
    1fd0:	0a 50 6f             	or     dl,BYTE PTR [bx+si+0x6f]
    1fd3:	70 75                	jo     0x204a
    1fd5:	70 4d                	jo     0x2024
    1fd7:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1fd9:	75 31                	jne    0x200c
    1fdb:	08 02                	or     BYTE PTR [bp+si],al
    1fdd:	18 00                	sbb    BYTE PTR [bx+si],al
    1fdf:	06                   	push   es
    1fe0:	50                   	push   ax
    1fe1:	72 69                	jb     0x204c
    1fe3:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fe4:	74 31                	je     0x2017
    1fe6:	0c 02                	or     al,0x2
    1fe8:	18 00                	sbb    BYTE PTR [bx+si],al
    1fea:	05 43 6f             	add    ax,0x6f43
    1fed:	70 79                	jo     0x2068
    1fef:	31 10                	xor    WORD PTR [bx+si],dx
    1ff1:	02 0c                	add    cl,BYTE PTR [si]
    1ff3:	00 07                	add    BYTE PTR [bx],al
    1ff5:	42                   	inc    dx
    1ff6:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    1ffb:	32 07                	xor    al,BYTE PTR [bx]
    1ffd:	00 17                	add    BYTE PTR [bx],dl
    1fff:	06                   	push   es
    2000:	04 20                	add    al,0x20
    2002:	0c 01                	or     al,0x1
    2004:	08 20                	or     BYTE PTR [bx+si],ah
    2006:	90                   	nop
    2007:	0b 3d                	or     di,WORD PTR [di]
    2009:	27                   	daa
    200a:	ac                   	lods   al,BYTE PTR ds:[si]
    200b:	04 75                	add    al,0x75
    200d:	23 65 06             	and    sp,WORD PTR [di+0x6]
    2010:	2b 25                	sub    sp,WORD PTR [di]
    2012:	c6 03 18             	mov    BYTE PTR [bp+di],0x18
    2015:	20 94 00 ff          	and    BYTE PTR [si-0x100],dl
    2019:	ff 07                	inc    WORD PTR [bx]
    201b:	11 54 46             	adc    WORD PTR [si+0x46],dx
    201e:	6f                   	outs   dx,WORD PTR ds:[si]
    201f:	72 6d                	jb     0x208e
    2021:	53                   	push   bx
    2022:	4a                   	dec    dx
    2023:	53                   	push   bx
    2024:	44                   	inc    sp
    2025:	5f                   	pop    di
    2026:	44                   	inc    sp
    2027:	6f                   	outs   dx,WORD PTR ds:[si]
    2028:	63 49 6e             	arpl   WORD PTR [bx+di+0x6e],cx
    202b:	66 6f                	outs   dx,DWORD PTR ds:[si]
    202d:	56                   	push   si
    202e:	1d 6f 20             	sbb    ax,0x206f
    2031:	7b 06                	jnp    0x2039
    2033:	5e                   	pop    si
    2034:	20 38                	and    BYTE PTR [bx+si],bh
    2036:	00 04                	add    BYTE PTR [si],al
    2038:	53                   	push   bx
    2039:	6a 73                	push   0x73
    203b:	64 00 00             	add    BYTE PTR fs:[bx+si],al
    203e:	55                   	push   bp
    203f:	89 e5                	mov    bp,sp
    2041:	b8 04 00             	mov    ax,0x4
    2044:	9a 44 04 95 20       	call   0x2095:0x444
    2049:	83 ec 04             	sub    sp,0x4
    204c:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    2051:	74 35                	je     0x2088
    2053:	6a f5                	push   0xfff5
    2055:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2059:	06                   	push   es
    205a:	57                   	push   di
    205b:	9a a9 63 76 20       	call   0x2076:0x63a9
    2060:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    2064:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    2068:	b0 01                	mov    al,0x1
    206a:	50                   	push   ax
    206b:	b8 56 1d             	mov    ax,0x1d56
    206e:	ba c1 21             	mov    dx,0x21c1
    2071:	52                   	push   dx
    2072:	50                   	push   ax
    2073:	9a 53 25 86 20       	call   0x2086:0x2553
    2078:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    207b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    207e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2081:	06                   	push   es
    2082:	57                   	push   di
    2083:	9a 45 5d 42 23       	call   0x2342:0x5d45
    2088:	c9                   	leave
    2089:	cb                   	retf
    208a:	01 2e 55 89          	add    WORD PTR ds:0x8955,bp
    208e:	e5 b8                	in     ax,0xb8
    2090:	00 01                	add    BYTE PTR [bx+di],al
    2092:	9a 44 04 b5 20       	call   0x20b5:0x444
    2097:	81 ec 00 01          	sub    sp,0x100
    209b:	8d be 00 ff          	lea    di,[bp-0x100]
    209f:	16                   	push   ss
    20a0:	57                   	push   di
    20a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a4:	06                   	push   es
    20a5:	57                   	push   di
    20a6:	6a 01                	push   0x1
    20a8:	bf 8a 20             	mov    di,0x208a
    20ab:	0e                   	push   cs
    20ac:	57                   	push   di
    20ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b0:	06                   	push   es
    20b1:	57                   	push   di
    20b2:	9a 78 18 bf 20       	call   0x20bf:0x1878
    20b7:	2d 01 00             	sub    ax,0x1
    20ba:	71 05                	jno    0x20c1
    20bc:	9a 3e 04 c5 20       	call   0x20c5:0x43e
    20c1:	50                   	push   ax
    20c2:	9a 0b 18 d2 20       	call   0x20d2:0x180b
    20c7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    20ca:	06                   	push   es
    20cb:	57                   	push   di
    20cc:	68 ff 00             	push   0xff
    20cf:	9a e7 17 f1 20       	call   0x20f1:0x17e7
    20d4:	c9                   	leave
    20d5:	ca 04 00             	retf   0x4
    20d8:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    20db:	6d                   	ins    WORD PTR es:[di],dx
    20dc:	73 74                	jae    0x2152
    20de:	72 61                	jb     0x2141
    20e0:	74 20                	je     0x2102
    20e2:	2d 20 03             	sub    ax,0x320
    20e5:	20 2d                	and    BYTE PTR [di],ch
    20e7:	20 55 89             	and    BYTE PTR [di-0x77],dl
    20ea:	e5 b8                	in     ax,0xb8
    20ec:	00 02                	add    BYTE PTR [bp+si],al
    20ee:	9a 44 04 22 21       	call   0x2122:0x444
    20f3:	81 ec 00 02          	sub    sp,0x200
    20f7:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    20fb:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2100:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
    2104:	50                   	push   ax
    2105:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2108:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    210d:	06                   	push   es
    210e:	57                   	push   di
    210f:	9a 77 1c 46 21       	call   0x2146:0x1c77
    2114:	8d be 00 ff          	lea    di,[bp-0x100]
    2118:	16                   	push   ss
    2119:	57                   	push   di
    211a:	bf d8 20             	mov    di,0x20d8
    211d:	0e                   	push   cs
    211e:	57                   	push   di
    211f:	9a cd 17 2c 21       	call   0x212c:0x17cd
    2124:	bf fa 1d             	mov    di,0x1dfa
    2127:	1e                   	push   ds
    2128:	57                   	push   di
    2129:	9a 4c 18 36 21       	call   0x2136:0x184c
    212e:	bf e4 20             	mov    di,0x20e4
    2131:	0e                   	push   cs
    2132:	57                   	push   di
    2133:	9a 4c 18 4b 21       	call   0x214b:0x184c
    2138:	8d be 00 fe          	lea    di,[bp-0x200]
    213c:	16                   	push   ss
    213d:	57                   	push   di
    213e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2141:	06                   	push   es
    2142:	57                   	push   di
    2143:	9a 53 1d 55 21       	call   0x2155:0x1d53
    2148:	9a 4c 18 35 23       	call   0x2335:0x184c
    214d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2150:	06                   	push   es
    2151:	57                   	push   di
    2152:	9a 8c 1d 69 21       	call   0x2169:0x1d8c
    2157:	bf fa 1d             	mov    di,0x1dfa
    215a:	1e                   	push   ds
    215b:	57                   	push   di
    215c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    215f:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    2164:	06                   	push   es
    2165:	57                   	push   di
    2166:	9a 8c 1d 7d 21       	call   0x217d:0x1d8c
    216b:	bf fa 1a             	mov    di,0x1afa
    216e:	1e                   	push   ds
    216f:	57                   	push   di
    2170:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2173:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    2178:	06                   	push   es
    2179:	57                   	push   di
    217a:	9a 8c 1d 9d 21       	call   0x219d:0x1d8c
    217f:	8d be 00 ff          	lea    di,[bp-0x100]
    2183:	16                   	push   ss
    2184:	57                   	push   di
    2185:	a1 4e 01             	mov    ax,ds:0x14e
    2188:	99                   	cwd
    2189:	52                   	push   dx
    218a:	50                   	push   ax
    218b:	9a a9 08 f8 22       	call   0x22f8:0x8a9
    2190:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2193:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2198:	06                   	push   es
    2199:	57                   	push   di
    219a:	9a 8c 1d b1 21       	call   0x21b1:0x1d8c
    219f:	bf fa 19             	mov    di,0x19fa
    21a2:	1e                   	push   ds
    21a3:	57                   	push   di
    21a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a7:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    21ac:	06                   	push   es
    21ad:	57                   	push   di
    21ae:	9a 8c 1d d0 21       	call   0x21d0:0x1d8c
    21b3:	8d be 00 ff          	lea    di,[bp-0x100]
    21b7:	16                   	push   ss
    21b8:	57                   	push   di
    21b9:	bf 16 1e             	mov    di,0x1e16
    21bc:	1e                   	push   ds
    21bd:	57                   	push   di
    21be:	9a 8c 20 e0 21       	call   0x21e0:0x208c
    21c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c6:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    21cb:	06                   	push   es
    21cc:	57                   	push   di
    21cd:	9a 8c 1d ef 21       	call   0x21ef:0x1d8c
    21d2:	8d be 00 ff          	lea    di,[bp-0x100]
    21d6:	16                   	push   ss
    21d7:	57                   	push   di
    21d8:	bf 24 1e             	mov    di,0x1e24
    21db:	1e                   	push   ds
    21dc:	57                   	push   di
    21dd:	9a 8c 20 ff 21       	call   0x21ff:0x208c
    21e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e5:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    21ea:	06                   	push   es
    21eb:	57                   	push   di
    21ec:	9a 8c 1d 0e 22       	call   0x220e:0x1d8c
    21f1:	8d be 00 ff          	lea    di,[bp-0x100]
    21f5:	16                   	push   ss
    21f6:	57                   	push   di
    21f7:	bf 32 1e             	mov    di,0x1e32
    21fa:	1e                   	push   ds
    21fb:	57                   	push   di
    21fc:	9a 8c 20 1e 22       	call   0x221e:0x208c
    2201:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2204:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2209:	06                   	push   es
    220a:	57                   	push   di
    220b:	9a 8c 1d 2d 22       	call   0x222d:0x1d8c
    2210:	8d be 00 ff          	lea    di,[bp-0x100]
    2214:	16                   	push   ss
    2215:	57                   	push   di
    2216:	bf 40 1e             	mov    di,0x1e40
    2219:	1e                   	push   ds
    221a:	57                   	push   di
    221b:	9a 8c 20 3d 22       	call   0x223d:0x208c
    2220:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2223:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    2228:	06                   	push   es
    2229:	57                   	push   di
    222a:	9a 8c 1d 4c 22       	call   0x224c:0x1d8c
    222f:	8d be 00 ff          	lea    di,[bp-0x100]
    2233:	16                   	push   ss
    2234:	57                   	push   di
    2235:	bf 4e 1e             	mov    di,0x1e4e
    2238:	1e                   	push   ds
    2239:	57                   	push   di
    223a:	9a 8c 20 5c 22       	call   0x225c:0x208c
    223f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2242:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    2247:	06                   	push   es
    2248:	57                   	push   di
    2249:	9a 8c 1d 6b 22       	call   0x226b:0x1d8c
    224e:	8d be 00 ff          	lea    di,[bp-0x100]
    2252:	16                   	push   ss
    2253:	57                   	push   di
    2254:	bf 5c 1e             	mov    di,0x1e5c
    2257:	1e                   	push   ds
    2258:	57                   	push   di
    2259:	9a 8c 20 7b 22       	call   0x227b:0x208c
    225e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2261:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    2266:	06                   	push   es
    2267:	57                   	push   di
    2268:	9a 8c 1d 8a 22       	call   0x228a:0x1d8c
    226d:	8d be 00 ff          	lea    di,[bp-0x100]
    2271:	16                   	push   ss
    2272:	57                   	push   di
    2273:	bf 6a 1e             	mov    di,0x1e6a
    2276:	1e                   	push   ds
    2277:	57                   	push   di
    2278:	9a 8c 20 9a 22       	call   0x229a:0x208c
    227d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2280:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    2285:	06                   	push   es
    2286:	57                   	push   di
    2287:	9a 8c 1d a9 22       	call   0x22a9:0x1d8c
    228c:	8d be 00 ff          	lea    di,[bp-0x100]
    2290:	16                   	push   ss
    2291:	57                   	push   di
    2292:	bf 78 1e             	mov    di,0x1e78
    2295:	1e                   	push   ds
    2296:	57                   	push   di
    2297:	9a 8c 20 b9 22       	call   0x22b9:0x208c
    229c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    229f:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    22a4:	06                   	push   es
    22a5:	57                   	push   di
    22a6:	9a 8c 1d c8 22       	call   0x22c8:0x1d8c
    22ab:	8d be 00 ff          	lea    di,[bp-0x100]
    22af:	16                   	push   ss
    22b0:	57                   	push   di
    22b1:	bf 86 1e             	mov    di,0x1e86
    22b4:	1e                   	push   ds
    22b5:	57                   	push   di
    22b6:	9a 8c 20 d8 22       	call   0x22d8:0x208c
    22bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22be:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    22c3:	06                   	push   es
    22c4:	57                   	push   di
    22c5:	9a 8c 1d e7 22       	call   0x22e7:0x1d8c
    22ca:	8d be 00 ff          	lea    di,[bp-0x100]
    22ce:	16                   	push   ss
    22cf:	57                   	push   di
    22d0:	bf 94 1e             	mov    di,0x1e94
    22d3:	1e                   	push   ds
    22d4:	57                   	push   di
    22d5:	9a 8c 20 e4 23       	call   0x23e4:0x208c
    22da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22dd:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    22e2:	06                   	push   es
    22e3:	57                   	push   di
    22e4:	9a 8c 1d 07 23       	call   0x2307:0x1d8c
    22e9:	8d be 00 ff          	lea    di,[bp-0x100]
    22ed:	16                   	push   ss
    22ee:	57                   	push   di
    22ef:	a1 4c 01             	mov    ax,ds:0x14c
    22f2:	99                   	cwd
    22f3:	52                   	push   dx
    22f4:	50                   	push   ax
    22f5:	9a a9 08 18 23       	call   0x2318:0x8a9
    22fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fd:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    2302:	06                   	push   es
    2303:	57                   	push   di
    2304:	9a 8c 1d 27 23       	call   0x2327:0x1d8c
    2309:	8d be 00 ff          	lea    di,[bp-0x100]
    230d:	16                   	push   ss
    230e:	57                   	push   di
    230f:	a1 06 1e             	mov    ax,ds:0x1e06
    2312:	99                   	cwd
    2313:	52                   	push   dx
    2314:	50                   	push   ax
    2315:	9a a9 08 7a 2b       	call   0x2b7a:0x8a9
    231a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    231d:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2322:	06                   	push   es
    2323:	57                   	push   di
    2324:	9a 8c 1d a7 23       	call   0x23a7:0x1d8c
    2329:	c9                   	leave
    232a:	ca 08 00             	retf   0x8
    232d:	55                   	push   bp
    232e:	89 e5                	mov    bp,sp
    2330:	31 c0                	xor    ax,ax
    2332:	9a 44 04 50 23       	call   0x2350:0x444
    2337:	6a 00                	push   0x0
    2339:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    233d:	06                   	push   es
    233e:	57                   	push   di
    233f:	9a a9 63 03 24       	call   0x2403:0x63a9
    2344:	c9                   	leave
    2345:	ca 08 00             	retf   0x8
    2348:	55                   	push   bp
    2349:	89 e5                	mov    bp,sp
    234b:	31 c0                	xor    ax,ax
    234d:	9a 44 04 66 23       	call   0x2366:0x444
    2352:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2355:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    2359:	c9                   	leave
    235a:	ca 0c 00             	retf   0xc
    235d:	55                   	push   bp
    235e:	89 e5                	mov    bp,sp
    2360:	b8 08 00             	mov    ax,0x8
    2363:	9a 44 04 7c 23       	call   0x237c:0x444
    2368:	83 ec 08             	sub    sp,0x8
    236b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    236e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2371:	bf ac 04             	mov    di,0x4ac
    2374:	b8 39 27             	mov    ax,0x2739
    2377:	50                   	push   ax
    2378:	57                   	push   di
    2379:	9a 73 22 df 23       	call   0x23df:0x2273
    237e:	89 c7                	mov    di,ax
    2380:	8e c2                	mov    es,dx
    2382:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2386:	99                   	cwd
    2387:	b9 02 00             	mov    cx,0x2
    238a:	f7 f9                	idiv   cx
    238c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    238f:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2393:	99                   	cwd
    2394:	b9 02 00             	mov    cx,0x2
    2397:	f7 f9                	idiv   cx
    2399:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    239c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    239f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    23a2:	06                   	push   es
    23a3:	57                   	push   di
    23a4:	9a d4 19 f9 23       	call   0x23f9:0x19d4
    23a9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    23ac:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    23af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b2:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    23b7:	26 c6 45 25 00       	mov    BYTE PTR es:[di+0x25],0x0
    23bc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    23bf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    23c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c5:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    23ca:	06                   	push   es
    23cb:	57                   	push   di
    23cc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23cf:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    23d3:	c9                   	leave
    23d4:	ca 08 00             	retf   0x8
    23d7:	55                   	push   bp
    23d8:	89 e5                	mov    bp,sp
    23da:	31 c0                	xor    ax,ax
    23dc:	9a 44 04 23 24       	call   0x2423:0x444
    23e1:	9a c6 34 42 26       	call   0x2642:0x34c6
    23e6:	08 c0                	or     al,al
    23e8:	74 2c                	je     0x2416
    23ea:	6a 00                	push   0x0
    23ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ef:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    23f4:	06                   	push   es
    23f5:	57                   	push   di
    23f6:	9a 77 1c 14 24       	call   0x2414:0x1c77
    23fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fe:	06                   	push   es
    23ff:	57                   	push   di
    2400:	9a 2d 5a 15 25       	call   0x2515:0x5a2d
    2405:	6a 01                	push   0x1
    2407:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240a:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    240f:	06                   	push   es
    2410:	57                   	push   di
    2411:	9a 77 1c 37 24       	call   0x2437:0x1c77
    2416:	c9                   	leave
    2417:	ca 08 00             	retf   0x8
    241a:	55                   	push   bp
    241b:	89 e5                	mov    bp,sp
    241d:	b8 14 00             	mov    ax,0x14
    2420:	9a 44 04 8e 24       	call   0x248e:0x444
    2425:	83 ec 14             	sub    sp,0x14
    2428:	6a 00                	push   0x0
    242a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242d:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2432:	06                   	push   es
    2433:	57                   	push   di
    2434:	9a 77 1c 4a 24       	call   0x244a:0x1c77
    2439:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    243c:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    2440:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    2445:	06                   	push   es
    2446:	57                   	push   di
    2447:	9a bf 17 5d 24       	call   0x245d:0x17bf
    244c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    244f:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    2453:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    2458:	06                   	push   es
    2459:	57                   	push   di
    245a:	9a e1 17 77 24       	call   0x2477:0x17e1
    245f:	31 c0                	xor    ax,ax
    2461:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2464:	31 c0                	xor    ax,ax
    2466:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2469:	ff 76 ee             	push   WORD PTR [bp-0x12]
    246c:	ff 76 ec             	push   WORD PTR [bp-0x14]
    246f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2472:	06                   	push   es
    2473:	57                   	push   di
    2474:	9a d4 19 06 25       	call   0x2506:0x19d4
    2479:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    247c:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    247f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2482:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2486:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    2489:	71 05                	jno    0x2490
    248b:	9a 3e 04 a2 24       	call   0x24a2:0x43e
    2490:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2496:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    249a:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    249d:	71 05                	jno    0x24a4
    249f:	9a 3e 04 b6 24       	call   0x24b6:0x43e
    24a4:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    24a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24aa:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    24ae:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    24b1:	71 05                	jno    0x24b8
    24b3:	9a 3e 04 ca 24       	call   0x24ca:0x43e
    24b8:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    24bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24be:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    24c2:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    24c5:	71 05                	jno    0x24cc
    24c7:	9a 3e 04 74 25       	call   0x2574:0x43e
    24cc:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    24cf:	31 c0                	xor    ax,ax
    24d1:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    24d4:	31 c0                	xor    ax,ax
    24d6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    24d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24dc:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    24e1:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    24e5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24eb:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    24f0:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    24f4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    24f7:	6a 00                	push   0x0
    24f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24fc:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    2501:	06                   	push   es
    2502:	57                   	push   di
    2503:	9a 77 1c 66 25       	call   0x2566:0x1c77
    2508:	8d 7e f8             	lea    di,[bp-0x8]
    250b:	16                   	push   ss
    250c:	57                   	push   di
    250d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2510:	06                   	push   es
    2511:	57                   	push   di
    2512:	9a d5 33 8e 25       	call   0x258e:0x33d5
    2517:	52                   	push   dx
    2518:	50                   	push   ax
    2519:	8d 7e f0             	lea    di,[bp-0x10]
    251c:	16                   	push   ss
    251d:	57                   	push   di
    251e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2521:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    2526:	06                   	push   es
    2527:	57                   	push   di
    2528:	9a 94 1f 35 27       	call   0x2735:0x1f94
    252d:	89 c7                	mov    di,ax
    252f:	8e c2                	mov    es,dx
    2531:	06                   	push   es
    2532:	57                   	push   di
    2533:	9a 10 1b 80 29       	call   0x2980:0x1b10
    2538:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    253b:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    2540:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    2545:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    254a:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    254e:	06                   	push   es
    254f:	57                   	push   di
    2550:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2553:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2557:	6a 01                	push   0x1
    2559:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    255c:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2561:	06                   	push   es
    2562:	57                   	push   di
    2563:	9a 77 1c 0a 26       	call   0x260a:0x1c77
    2568:	c9                   	leave
    2569:	ca 08 00             	retf   0x8
    256c:	55                   	push   bp
    256d:	89 e5                	mov    bp,sp
    256f:	31 c0                	xor    ax,ax
    2571:	9a 44 04 ae 25       	call   0x25ae:0x444
    2576:	6a 01                	push   0x1
    2578:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257b:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    2580:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    2585:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2589:	06                   	push   es
    258a:	57                   	push   di
    258b:	9a b2 77 22 26       	call   0x2622:0x77b2
    2590:	c9                   	leave
    2591:	ca 08 00             	retf   0x8
    2594:	43                   	inc    bx
    2595:	27                   	daa
    2596:	90                   	nop
    2597:	26 3e 26 00 00       	es ds add BYTE PTR es:[bx+si],al
    259c:	30 26 c2 02          	xor    BYTE PTR ds:0x2c2,ah
    25a0:	fb                   	sti
    25a1:	04 58                	add    al,0x58
    25a3:	27                   	daa
    25a4:	39 3f                	cmp    WORD PTR [bx],di
    25a6:	ba 25 9a             	mov    dx,0x9a25
    25a9:	1f                   	pop    ds
    25aa:	70 27                	jo     0x25d3
    25ac:	cb                   	retf
    25ad:	1f                   	pop    ds
    25ae:	aa                   	stos   BYTE PTR es:[di],al
    25af:	25 ad 27             	and    ax,0x27ad
    25b2:	2e 26 cd 11          	cs es int 0x11
    25b6:	be 25 f7             	mov    si,0xf725
    25b9:	2a 1a                	sub    bl,BYTE PTR [bp+si]
    25bb:	26 fa                	es cli
    25bd:	10 8a 2a d6          	adc    BYTE PTR [bp+si-0x29d6],cl
    25c1:	14 f2                	adc    al,0xf2
    25c3:	25 f4 4f             	and    ax,0x4ff4
    25c6:	de 25                	fisub  WORD PTR [di]
    25c8:	9a 28 26 26 85       	call   0x8526:0x2628
    25cd:	29 d2                	sub    dx,dx
    25cf:	25 57 4d             	and    ax,0x4d57
    25d2:	d6                   	(bad)
    25d3:	25 91 2f             	and    ax,0x2f91
    25d6:	f6 25                	mul    BYTE PTR [di]
    25d8:	63 31                	arpl   WORD PTR [bx+di],si
    25da:	fa                   	cli
    25db:	25 21 50             	and    ax,0x5021
    25de:	b6 25                	mov    dh,0x25
    25e0:	53                   	push   bx
    25e1:	25 b2 25             	and    ax,0x25b2
    25e4:	d9 62 ee             	fldenv [bp+si-0x12]
    25e7:	25 55 2e             	and    ax,0x2e55
    25ea:	ca 25 8f             	retf   0x8f25
    25ed:	60                   	pusha
    25ee:	2a 26 3a 1c          	sub    ah,BYTE PTR ds:0x1c3a
    25f2:	af                   	scas   ax,WORD PTR es:[di]
    25f3:	27                   	daa
    25f4:	e2 2f                	loop   0x2625
    25f6:	e2 25                	loop   0x261d
    25f8:	08 61 fe             	or     BYTE PTR [bx+di-0x2],ah
    25fb:	25 5c 61             	and    ax,0x615c
    25fe:	02 26 62 5c          	add    ah,BYTE PTR ds:0x5c62
    2602:	06                   	push   es
    2603:	26 3a 61 c2          	cmp    ah,BYTE PTR es:[bx+di-0x3e]
    2607:	25 72 3f             	and    ax,0x3f72
    260a:	1e                   	push   ds
    260b:	26 58                	es pop ax
    260d:	3a 12                	cmp    dl,BYTE PTR [bp+si]
    260f:	26 ec                	es in  al,dx
    2611:	3d 16 26             	cmp    ax,0x2616
    2614:	e4 3c                	in     al,0x3c
    2616:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    2617:	25 ed 3e             	and    ax,0x3eed
    261a:	ea 25 77 3e e6       	jmp    0xe63e:0x7725
    261f:	25 e6 31             	and    ax,0x31e6
    2622:	0e                   	push   cs
    2623:	26 3c 47             	es cmp al,0x47
    2626:	ce                   	into
    2627:	25 ae 5f             	and    ax,0x5fae
    262a:	da 25                	fisub  DWORD PTR [di]
    262c:	e9 5c a2             	jmp    0xc88b
    262f:	25 0d 54             	and    ax,0x540d
    2632:	46                   	inc    si
    2633:	6f                   	outs   dx,WORD PTR ds:[si]
    2634:	72 6d                	jb     0x26a3
    2636:	49                   	dec    cx
    2637:	6d                   	ins    WORD PTR es:[di],dx
    2638:	70 72                	jo     0x26ac
    263a:	69 6d 65 72 05       	imul   bp,WORD PTR [di+0x65],0x572
    263f:	00 17                	add    BYTE PTR [bx],dl
    2641:	2e 51                	cs push cx
    2643:	26 0a 46 6f          	or     al,BYTE PTR es:[bp+0x6f]
    2647:	72 6d                	jb     0x26b6
    2649:	43                   	inc    bx
    264a:	72 65                	jb     0x26b1
    264c:	61                   	popa
    264d:	74 65                	je     0x26b4
    264f:	26 30 62 26          	xor    BYTE PTR es:[bp+si+0x26],ah
    2653:	0c 42                	or     al,0x42
    2655:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    265a:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
    265d:	69 63 6b 2e 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2f2e
    2662:	75 26                	jne    0x268a
    2664:	0e                   	push   cs
    2665:	46                   	inc    si
    2666:	6f                   	outs   dx,WORD PTR ds:[si]
    2667:	72 6d                	jb     0x26d6
    2669:	43                   	inc    bx
    266a:	6c                   	ins    BYTE PTR es:[di],dx
    266b:	6f                   	outs   dx,WORD PTR ds:[si]
    266c:	73 65                	jae    0x26d3
    266e:	51                   	push   cx
    266f:	75 65                	jne    0x26d6
    2671:	72 79                	jb     0x26ec
    2673:	72 32                	jb     0x26a7
    2675:	85 26 0b 54          	test   WORD PTR ds:0x540b,sp
    2679:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
    267e:	54                   	push   sp
    267f:	69 6d 65 72 9b       	imul   bp,WORD PTR [di+0x65],0x9b72
    2684:	32 54 27             	xor    dl,BYTE PTR [si+0x27]
    2687:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
    268a:	72 6d                	jb     0x26f9
    268c:	53                   	push   bx
    268d:	68 6f 77             	push   0x776f
    2690:	0e                   	push   cs
    2691:	00 31                	add    BYTE PTR [bx+di],dh
    2693:	27                   	daa
    2694:	7c 01                	jl     0x2697
    2696:	00 00                	add    BYTE PTR [bx+si],al
    2698:	06                   	push   es
    2699:	50                   	push   ax
    269a:	61                   	popa
    269b:	6e                   	outs   dx,BYTE PTR ds:[si]
    269c:	65 6c                	gs ins BYTE PTR es:[di],dx
    269e:	31 80 01 04          	xor    WORD PTR [bx+si+0x401],ax
    26a2:	00 07                	add    BYTE PTR [bx],al
    26a4:	42                   	inc    dx
    26a5:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    26aa:	31 84 01 08          	xor    WORD PTR [si+0x801],ax
    26ae:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26b2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26b5:	31 88 01 08          	xor    WORD PTR [bx+si+0x801],cx
    26b9:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26bd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26c0:	32 8c 01 08          	xor    cl,BYTE PTR [si+0x801]
    26c4:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26c8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26cb:	33 90 01 08          	xor    dx,WORD PTR [bx+si+0x801]
    26cf:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26d3:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26d6:	34 94                	xor    al,0x94
    26d8:	01 08                	add    WORD PTR [bx+si],cx
    26da:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26de:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26e1:	35 98 01             	xor    ax,0x198
    26e4:	08 00                	or     BYTE PTR [bx+si],al
    26e6:	06                   	push   es
    26e7:	4c                   	dec    sp
    26e8:	61                   	popa
    26e9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26ec:	36 9c                	ss pushf
    26ee:	01 08                	add    WORD PTR [bx+si],cx
    26f0:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26f4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    26f7:	37                   	aaa
    26f8:	a0 01 08             	mov    al,ds:0x801
    26fb:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    26ff:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    2702:	38 a4 01 08          	cmp    BYTE PTR [si+0x801],ah
    2706:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    270a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    270d:	39 a8 01 08          	cmp    WORD PTR [bx+si+0x801],bp
    2711:	00 07                	add    BYTE PTR [bx],al
    2713:	4c                   	dec    sp
    2714:	61                   	popa
    2715:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    2718:	31 30                	xor    WORD PTR [bx+si],si
    271a:	ac                   	lods   al,BYTE PTR ds:[si]
    271b:	01 08                	add    WORD PTR [bx+si],cx
    271d:	00 07                	add    BYTE PTR [bx],al
    271f:	4c                   	dec    sp
    2720:	61                   	popa
    2721:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    2724:	31 31                	xor    WORD PTR [bx+di],si
    2726:	b0 01                	mov    al,0x1
    2728:	0c 00                	or     al,0x0
    272a:	06                   	push   es
    272b:	54                   	push   sp
    272c:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
    2731:	04 00                	add    al,0x0
    2733:	ad                   	lods   ax,WORD PTR ds:[si]
    2734:	0d 41 27             	or     ax,0x2741
    2737:	ac                   	lods   al,BYTE PTR ds:[si]
    2738:	04 8f                	add    al,0x8f
    273a:	34 17                	xor    al,0x17
    273c:	06                   	push   es
    273d:	97                   	xchg   di,ax
    273e:	34 8b                	xor    al,0x8b
    2740:	0b 8b 32 07          	or     cx,WORD PTR [bp+di+0x732]
    2744:	0d 54 46             	or     ax,0x4654
    2747:	6f                   	outs   dx,WORD PTR ds:[si]
    2748:	72 6d                	jb     0x27b7
    274a:	49                   	dec    cx
    274b:	6d                   	ins    WORD PTR es:[di],dx
    274c:	70 72                	jo     0x27c0
    274e:	69 6d 65 72 b4       	imul   bp,WORD PTR [di+0x65],0xb472
    2753:	25 81 28             	and    ax,0x2881
    2756:	7b 06                	jnp    0x275e
    2758:	00 2b                	add    BYTE PTR [bp+di],ch
    275a:	38 00                	cmp    BYTE PTR [bx+si],al
    275c:	08 49 6d             	or     BYTE PTR [bx+di+0x6d],cl
    275f:	70 72                	jo     0x27d3
    2761:	69 6d 65 72 00       	imul   bp,WORD PTR [di+0x65],0x72
    2766:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2769:	e5 b8                	in     ax,0xb8
    276b:	0c 00                	or     al,0x0
    276d:	9a 44 04 cf 27       	call   0x27cf:0x444
    2772:	83 ec 0c             	sub    sp,0xc
    2775:	ff 76 08             	push   WORD PTR [bp+0x8]
    2778:	9a ff ff 00 00       	call   0x0:0xffff
    277d:	09 c0                	or     ax,ax
    277f:	75 03                	jne    0x2784
    2781:	e9 0e 01             	jmp    0x2892
    2784:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2787:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    278b:	9a ff ff 00 00       	call   0x0:0xffff
    2790:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2793:	ff 76 08             	push   WORD PTR [bp+0x8]
    2796:	8d 7e f8             	lea    di,[bp-0x8]
    2799:	16                   	push   ss
    279a:	57                   	push   di
    279b:	9a ff ff 00 00       	call   0x0:0xffff
    27a0:	ff 76 08             	push   WORD PTR [bp+0x8]
    27a3:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    27a6:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    27aa:	06                   	push   es
    27ab:	57                   	push   di
    27ac:	9a b9 62 90 29       	call   0x2990:0x62b9
    27b1:	50                   	push   ax
    27b2:	8d 7e f8             	lea    di,[bp-0x8]
    27b5:	16                   	push   ss
    27b6:	57                   	push   di
    27b7:	6a 02                	push   0x2
    27b9:	9a ff ff 00 00       	call   0x0:0xffff
    27be:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    27c1:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    27c5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    27c8:	f7 d8                	neg    ax
    27ca:	71 05                	jno    0x27d1
    27cc:	9a 3e 04 dc 27       	call   0x27dc:0x43e
    27d1:	50                   	push   ax
    27d2:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    27d5:	f7 d8                	neg    ax
    27d7:	71 05                	jno    0x27de
    27d9:	9a 3e 04 fe 27       	call   0x27fe:0x43e
    27de:	50                   	push   ax
    27df:	6a 00                	push   0x0
    27e1:	6a 00                	push   0x0
    27e3:	9a ff ff 00 00       	call   0x0:0xffff
    27e8:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    27eb:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    27ef:	6a 00                	push   0x0
    27f1:	6a 00                	push   0x0
    27f3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    27f6:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    27f9:	71 05                	jno    0x2800
    27fb:	9a 3e 04 0c 28       	call   0x280c:0x43e
    2800:	50                   	push   ax
    2801:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2804:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    2807:	71 05                	jno    0x280e
    2809:	9a 3e 04 bb 28       	call   0x28bb:0x43e
    280e:	50                   	push   ax
    280f:	9a ff ff 00 00       	call   0x0:0xffff
    2814:	ff 76 08             	push   WORD PTR [bp+0x8]
    2817:	6a 14                	push   0x14
    2819:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    281c:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    2820:	6a 00                	push   0x0
    2822:	6a 00                	push   0x0
    2824:	9a 3e 28 00 00       	call   0x0:0x283e
    2829:	ff 76 08             	push   WORD PTR [bp+0x8]
    282c:	6a 0f                	push   0xf
    282e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2831:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    2835:	36 ff 75 f2          	push   WORD PTR ss:[di-0xe]
    2839:	36 ff 75 f0          	push   WORD PTR ss:[di-0x10]
    283d:	9a ff ff 00 00       	call   0x0:0xffff
    2842:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2845:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    2849:	ff 76 f4             	push   WORD PTR [bp-0xc]
    284c:	9a ff ff 00 00       	call   0x0:0xffff
    2851:	ff 76 08             	push   WORD PTR [bp+0x8]
    2854:	6a 05                	push   0x5
    2856:	9a 6a 28 00 00       	call   0x0:0x286a
    285b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    285e:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    2862:	74 2e                	je     0x2892
    2864:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2867:	6a 01                	push   0x1
    2869:	9a 89 28 00 00       	call   0x0:0x2889
    286e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2871:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    2875:	74 1b                	je     0x2892
    2877:	ff 76 f6             	push   WORD PTR [bp-0xa]
    287a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    287d:	57                   	push   di
    287e:	9a 67 27 9a 28       	call   0x289a:0x2767
    2883:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2886:	6a 03                	push   0x3
    2888:	9a ff ff 00 00       	call   0x0:0xffff
    288d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2890:	eb df                	jmp    0x2871
    2892:	c9                   	leave
    2893:	ca 04 00             	retf   0x4
    2896:	00 00                	add    BYTE PTR [bx+si],al
    2898:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    2899:	29 a4 28 01          	sub    WORD PTR [si+0x128],sp
    289d:	00 00                	add    BYTE PTR [bx+si],al
    289f:	00 00                	add    BYTE PTR [bx+si],al
    28a1:	00 e2                	add    dl,ah
    28a3:	29 aa 28 00          	sub    WORD PTR [bp+si+0x28],bp
    28a7:	00 10                	add    BYTE PTR [bx+si],dl
    28a9:	2a b0 28 00          	sub    dh,BYTE PTR [bx+si+0x28]
    28ad:	00 25                	add    BYTE PTR [di],ah
    28af:	2a 97 29 55          	sub    dl,BYTE PTR [bx+0x5529]
    28b3:	89 e5                	mov    bp,sp
    28b5:	b8 20 00             	mov    ax,0x20
    28b8:	9a 44 04 ea 29       	call   0x29ea:0x444
    28bd:	83 ec 20             	sub    sp,0x20
    28c0:	31 c0                	xor    ax,ax
    28c2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    28c5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    28c8:	6a 00                	push   0x0
    28ca:	9a ff ff 00 00       	call   0x0:0xffff
    28cf:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    28d2:	31 c0                	xor    ax,ax
    28d4:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    28d7:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    28da:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28dd:	89 7e e4             	mov    WORD PTR [bp-0x1c],di
    28e0:	8c 46 e6             	mov    WORD PTR [bp-0x1a],es
    28e3:	b8 ac 28             	mov    ax,0x28ac
    28e6:	0e                   	push   cs
    28e7:	50                   	push   ax
    28e8:	55                   	push   bp
    28e9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    28ed:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    28f1:	ff 76 fa             	push   WORD PTR [bp-0x6]
    28f4:	9a ff ff 00 00       	call   0x0:0xffff
    28f9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    28fc:	b8 a6 28             	mov    ax,0x28a6
    28ff:	0e                   	push   cs
    2900:	50                   	push   ax
    2901:	55                   	push   bp
    2902:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2906:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    290a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290d:	89 7e e0             	mov    WORD PTR [bp-0x20],di
    2910:	8c 46 e2             	mov    WORD PTR [bp-0x1e],es
    2913:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2916:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    291a:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    291e:	9a ff ff 00 00       	call   0x0:0xffff
    2923:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2926:	31 c0                	xor    ax,ax
    2928:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    292b:	31 c0                	xor    ax,ax
    292d:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    2930:	c4 7e e0             	les    di,DWORD PTR [bp-0x20]
    2933:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2937:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    293a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    293e:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2941:	b8 9c 28             	mov    ax,0x289c
    2944:	0e                   	push   cs
    2945:	50                   	push   ax
    2946:	55                   	push   bp
    2947:	ff 36 58 18          	push   WORD PTR ds:0x1858
    294b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    294f:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2952:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2955:	9a ac 29 00 00       	call   0x0:0x29ac
    295a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    295d:	b8 96 28             	mov    ax,0x2896
    2960:	0e                   	push   cs
    2961:	50                   	push   ax
    2962:	55                   	push   bp
    2963:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2967:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    296b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    296e:	8d 7e e8             	lea    di,[bp-0x18]
    2971:	16                   	push   ss
    2972:	57                   	push   di
    2973:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    2976:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    297b:	06                   	push   es
    297c:	57                   	push   di
    297d:	9a c0 16 b8 29       	call   0x29b8:0x16c0
    2982:	50                   	push   ax
    2983:	9a ff ff 00 00       	call   0x0:0xffff
    2988:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    298b:	06                   	push   es
    298c:	57                   	push   di
    298d:	9a b9 62 7a 2a       	call   0x2a7a:0x62b9
    2992:	50                   	push   ax
    2993:	55                   	push   bp
    2994:	9a 67 27 4e 2a       	call   0x2a4e:0x2767
    2999:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    299d:	83 c4 06             	add    sp,0x6
    29a0:	b8 b1 29             	mov    ax,0x29b1
    29a3:	0e                   	push   cs
    29a4:	50                   	push   ax
    29a5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    29a8:	ff 76 f6             	push   WORD PTR [bp-0xa]
    29ab:	9a ff ff 00 00       	call   0x0:0xffff
    29b0:	cb                   	retf
    29b1:	b0 01                	mov    al,0x1
    29b3:	50                   	push   ax
    29b4:	b8 3f 08             	mov    ax,0x83f
    29b7:	ba bf 29             	mov    dx,0x29bf
    29ba:	52                   	push   dx
    29bb:	50                   	push   ax
    29bc:	9a bd 56 d2 29       	call   0x29d2:0x56bd
    29c1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    29c4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    29c7:	ff 76 f4             	push   WORD PTR [bp-0xc]
    29ca:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    29cd:	06                   	push   es
    29ce:	57                   	push   di
    29cf:	9a 04 61 53 2b       	call   0x2b53:0x6104
    29d4:	31 c0                	xor    ax,ax
    29d6:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    29d9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    29dd:	83 c4 06             	add    sp,0x6
    29e0:	eb 22                	jmp    0x2a04
    29e2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    29e5:	06                   	push   es
    29e6:	57                   	push   di
    29e7:	9a 7f 1f fd 29       	call   0x29fd:0x1f7f
    29ec:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    29f0:	74 08                	je     0x29fa
    29f2:	ff 76 f4             	push   WORD PTR [bp-0xc]
    29f5:	9a ff ff 00 00       	call   0x0:0xffff
    29fa:	ea 85 13 02 2a       	jmp    0x2a02:0x1385
    29ff:	9a 34 14 6d 2a       	call   0x2a6d:0x1434
    2a04:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2a08:	83 c4 06             	add    sp,0x6
    2a0b:	b8 19 2a             	mov    ax,0x2a19
    2a0e:	0e                   	push   cs
    2a0f:	50                   	push   ax
    2a10:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2a13:	9a ff ff 00 00       	call   0x0:0xffff
    2a18:	cb                   	retf
    2a19:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2a1d:	83 c4 06             	add    sp,0x6
    2a20:	b8 30 2a             	mov    ax,0x2a30
    2a23:	0e                   	push   cs
    2a24:	50                   	push   ax
    2a25:	6a 00                	push   0x0
    2a27:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2a2a:	9a ff ff 00 00       	call   0x0:0xffff
    2a2f:	cb                   	retf
    2a30:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a33:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2a36:	c9                   	leave
    2a37:	ca 08 00             	retf   0x8
    2a3a:	00 00                	add    BYTE PTR [bx+si],al
    2a3c:	00 00                	add    BYTE PTR [bx+si],al
    2a3e:	ff                   	(bad)
    2a3f:	ff 00                	inc    WORD PTR [bx+si]
    2a41:	00 00                	add    BYTE PTR [bx+si],al
    2a43:	80 ff ff             	cmp    bh,0xff
    2a46:	ff                   	(bad)
    2a47:	7f 00                	jg     0x2a49
    2a49:	00 00                	add    BYTE PTR [bx+si],al
    2a4b:	00 b3 2d 5c          	add    BYTE PTR [bp+di+0x5c2d],dh
    2a4f:	2a 00                	sub    al,BYTE PTR [bx+si]
    2a51:	00 00                	add    BYTE PTR [bx+si],al
    2a53:	00 ff                	add    bh,bh
    2a55:	ff 00                	inc    WORD PTR [bx+si]
    2a57:	00 00                	add    BYTE PTR [bx+si],al
    2a59:	00 d0                	add    al,dl
    2a5b:	2d 62 2a             	sub    ax,0x2a62
    2a5e:	00 00                	add    BYTE PTR [bx+si],al
    2a60:	f5                   	cmc
    2a61:	2d 1a 2b             	sub    ax,0x2b1a
    2a64:	55                   	push   bp
    2a65:	89 e5                	mov    bp,sp
    2a67:	b8 38 00             	mov    ax,0x38
    2a6a:	9a 44 04 94 2a       	call   0x2a94:0x444
    2a6f:	83 ec 38             	sub    sp,0x38
    2a72:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a75:	06                   	push   es
    2a76:	57                   	push   di
    2a77:	9a 86 62 bb 2a       	call   0x2abb:0x6286
    2a7c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a7f:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    2a82:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    2a85:	06                   	push   es
    2a86:	57                   	push   di
    2a87:	9a 7d 52 b3 2a       	call   0x2ab3:0x527d
    2a8c:	2d 01 00             	sub    ax,0x1
    2a8f:	71 05                	jno    0x2a96
    2a91:	9a 3e 04 c2 2a       	call   0x2ac2:0x43e
    2a96:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    2a99:	31 c0                	xor    ax,ax
    2a9b:	3b 46 d2             	cmp    ax,WORD PTR [bp-0x2e]
    2a9e:	7f 57                	jg     0x2af7
    2aa0:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    2aa3:	eb 03                	jmp    0x2aa8
    2aa5:	ff 46 da             	inc    WORD PTR [bp-0x26]
    2aa8:	ff 76 da             	push   WORD PTR [bp-0x26]
    2aab:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    2aae:	06                   	push   es
    2aaf:	57                   	push   di
    2ab0:	9a 46 52 d3 2a       	call   0x2ad3:0x5246
    2ab5:	52                   	push   dx
    2ab6:	50                   	push   ax
    2ab7:	bf c1 05             	mov    di,0x5c1
    2aba:	b8 db 2a             	mov    ax,0x2adb
    2abd:	50                   	push   ax
    2abe:	57                   	push   di
    2abf:	9a 55 22 e2 2a       	call   0x2ae2:0x2255
    2ac4:	08 c0                	or     al,al
    2ac6:	74 27                	je     0x2aef
    2ac8:	ff 76 da             	push   WORD PTR [bp-0x26]
    2acb:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    2ace:	06                   	push   es
    2acf:	57                   	push   di
    2ad0:	9a 46 52 a5 33       	call   0x33a5:0x5246
    2ad5:	52                   	push   dx
    2ad6:	50                   	push   ax
    2ad7:	bf c1 05             	mov    di,0x5c1
    2ada:	b8 ed 2a             	mov    ax,0x2aed
    2add:	50                   	push   ax
    2ade:	57                   	push   di
    2adf:	9a 73 22 74 2b       	call   0x2b74:0x2273
    2ae4:	89 c7                	mov    di,ax
    2ae6:	8e c2                	mov    es,dx
    2ae8:	06                   	push   es
    2ae9:	57                   	push   di
    2aea:	9a 86 62 a3 2e       	call   0x2ea3:0x6286
    2aef:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    2af2:	3b 46 d2             	cmp    ax,WORD PTR [bp-0x2e]
    2af5:	75 ae                	jne    0x2aa5
    2af7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2afb:	06                   	push   es
    2afc:	57                   	push   di
    2afd:	9a 03 73 25 2c       	call   0x2c25:0x7303
    2b02:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b05:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    2b08:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    2b0b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b0e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b11:	ff 76 08             	push   WORD PTR [bp+0x8]
    2b14:	ff 76 06             	push   WORD PTR [bp+0x6]
    2b17:	9a b2 28 10 2f       	call   0x2f10:0x28b2
    2b1c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b1f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2b22:	b8 5e 2a             	mov    ax,0x2a5e
    2b25:	0e                   	push   cs
    2b26:	50                   	push   ax
    2b27:	55                   	push   bp
    2b28:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2b2c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2b30:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2b34:	89 7e d0             	mov    WORD PTR [bp-0x30],di
    2b37:	8c 46 d2             	mov    WORD PTR [bp-0x2e],es
    2b3a:	06                   	push   es
    2b3b:	57                   	push   di
    2b3c:	9a 04 2a 8e 2c       	call   0x2c8e:0x2a04
    2b41:	89 c7                	mov    di,ax
    2b43:	8e c2                	mov    es,dx
    2b45:	89 7e cc             	mov    WORD PTR [bp-0x34],di
    2b48:	8c 46 ce             	mov    WORD PTR [bp-0x32],es
    2b4b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b4e:	06                   	push   es
    2b4f:	57                   	push   di
    2b50:	9a 9e 5a 68 2b       	call   0x2b68:0x5a9e
    2b55:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2b58:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2b5b:	8d 7e f6             	lea    di,[bp-0xa]
    2b5e:	16                   	push   ss
    2b5f:	57                   	push   di
    2b60:	8d 7e ee             	lea    di,[bp-0x12]
    2b63:	16                   	push   ss
    2b64:	57                   	push   di
    2b65:	9a e4 37 ce 2b       	call   0x2bce:0x37e4
    2b6a:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2b6d:	99                   	cwd
    2b6e:	bf 3a 2a             	mov    di,0x2a3a
    2b71:	9a 16 04 07 2c       	call   0x2c07:0x416
    2b76:	50                   	push   ax
    2b77:	9a 76 04 94 2e       	call   0x2e94:0x476
    2b7c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2b7f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2b82:	b8 58 2a             	mov    ax,0x2a58
    2b85:	0e                   	push   cs
    2b86:	50                   	push   ax
    2b87:	55                   	push   bp
    2b88:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2b8c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2b90:	6a 00                	push   0x0
    2b92:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2b95:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2b98:	9a ff ff 00 00       	call   0x0:0xffff
    2b9d:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    2ba0:	ff 76 d8             	push   WORD PTR [bp-0x28]
    2ba3:	9a ff ff 00 00       	call   0x0:0xffff
    2ba8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2bab:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2bae:	b8 4a 2a             	mov    ax,0x2a4a
    2bb1:	0e                   	push   cs
    2bb2:	50                   	push   ax
    2bb3:	55                   	push   bp
    2bb4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2bb8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2bbc:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2bbf:	6a 00                	push   0x0
    2bc1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2bc4:	06                   	push   es
    2bc5:	57                   	push   di
    2bc6:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2bc9:	06                   	push   es
    2bca:	57                   	push   di
    2bcb:	9a b5 38 12 2c       	call   0x2c12:0x38b5
    2bd0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2bd3:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2bd7:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    2bdb:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2bde:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    2be1:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2be5:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    2be9:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2bec:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2bef:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    2bf2:	26 8a 85 f7 00       	mov    al,BYTE PTR es:[di+0xf7]
    2bf7:	3c 01                	cmp    al,0x1
    2bf9:	75 75                	jne    0x2c70
    2bfb:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    2bfe:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    2c01:	bf 42 2a             	mov    di,0x2a42
    2c04:	9a 16 04 40 2c       	call   0x2c40:0x416
    2c09:	50                   	push   ax
    2c0a:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    2c0d:	06                   	push   es
    2c0e:	57                   	push   di
    2c0f:	9a d2 21 4b 2c       	call   0x2c4b:0x21d2
    2c14:	50                   	push   ax
    2c15:	6a 58                	push   0x58
    2c17:	9a 51 2c 00 00       	call   0x0:0x2c51
    2c1c:	50                   	push   ax
    2c1d:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    2c20:	06                   	push   es
    2c21:	57                   	push   di
    2c22:	9a 11 38 5e 2c       	call   0x2c5e:0x3811
    2c27:	50                   	push   ax
    2c28:	9a 62 2c 00 00       	call   0x0:0x2c62
    2c2d:	99                   	cwd
    2c2e:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2c31:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2c34:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    2c37:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    2c3a:	bf 42 2a             	mov    di,0x2a42
    2c3d:	9a 16 04 83 2c       	call   0x2c83:0x416
    2c42:	50                   	push   ax
    2c43:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    2c46:	06                   	push   es
    2c47:	57                   	push   di
    2c48:	9a d2 21 49 2d       	call   0x2d49:0x21d2
    2c4d:	50                   	push   ax
    2c4e:	6a 5a                	push   0x5a
    2c50:	9a 7d 2e 00 00       	call   0x0:0x2e7d
    2c55:	50                   	push   ax
    2c56:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    2c59:	06                   	push   es
    2c5a:	57                   	push   di
    2c5b:	9a 11 38 09 2e       	call   0x2e09:0x3811
    2c60:	50                   	push   ax
    2c61:	9a a1 2c 00 00       	call   0x0:0x2ca1
    2c66:	99                   	cwd
    2c67:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2c6a:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2c6d:	e9 c6 00             	jmp    0x2d36
    2c70:	3c 02                	cmp    al,0x2
    2c72:	74 03                	je     0x2c77
    2c74:	e9 a7 00             	jmp    0x2d1e
    2c77:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    2c7a:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    2c7d:	bf 42 2a             	mov    di,0x2a42
    2c80:	9a 16 04 9d 2c       	call   0x2c9d:0x416
    2c85:	50                   	push   ax
    2c86:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    2c89:	06                   	push   es
    2c8a:	57                   	push   di
    2c8b:	9a 72 2a b4 2c       	call   0x2cb4:0x2a72
    2c90:	50                   	push   ax
    2c91:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    2c94:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    2c97:	bf 42 2a             	mov    di,0x2a42
    2c9a:	9a 16 04 f3 2c       	call   0x2cf3:0x416
    2c9f:	50                   	push   ax
    2ca0:	9a 11 2d 00 00       	call   0x0:0x2d11
    2ca5:	99                   	cwd
    2ca6:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2ca9:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2cac:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    2caf:	06                   	push   es
    2cb0:	57                   	push   di
    2cb1:	9a 9a 2a cb 2c       	call   0x2ccb:0x2a9a
    2cb6:	99                   	cwd
    2cb7:	3b 56 e2             	cmp    dx,WORD PTR [bp-0x1e]
    2cba:	7f 07                	jg     0x2cc3
    2cbc:	7c 18                	jl     0x2cd6
    2cbe:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    2cc1:	76 13                	jbe    0x2cd6
    2cc3:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    2cc6:	06                   	push   es
    2cc7:	57                   	push   di
    2cc8:	9a 72 2a de 2c       	call   0x2cde:0x2a72
    2ccd:	99                   	cwd
    2cce:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2cd1:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2cd4:	eb 46                	jmp    0x2d1c
    2cd6:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    2cd9:	06                   	push   es
    2cda:	57                   	push   di
    2cdb:	9a 9a 2a fe 2c       	call   0x2cfe:0x2a9a
    2ce0:	99                   	cwd
    2ce1:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2ce4:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2ce7:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    2cea:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    2ced:	bf 42 2a             	mov    di,0x2a42
    2cf0:	9a 16 04 0d 2d       	call   0x2d0d:0x416
    2cf5:	50                   	push   ax
    2cf6:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    2cf9:	06                   	push   es
    2cfa:	57                   	push   di
    2cfb:	9a 9a 2a 3e 2d       	call   0x2d3e:0x2a9a
    2d00:	50                   	push   ax
    2d01:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    2d04:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    2d07:	bf 42 2a             	mov    di,0x2a42
    2d0a:	9a 16 04 5c 2d       	call   0x2d5c:0x416
    2d0f:	50                   	push   ax
    2d10:	9a ff ff 00 00       	call   0x0:0xffff
    2d15:	99                   	cwd
    2d16:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2d19:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2d1c:	eb 18                	jmp    0x2d36
    2d1e:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    2d21:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    2d24:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2d27:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2d2a:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    2d2d:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    2d30:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2d33:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2d36:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    2d39:	06                   	push   es
    2d3a:	57                   	push   di
    2d3b:	9a 04 2a 6c 2e       	call   0x2e6c:0x2a04
    2d40:	89 c7                	mov    di,ax
    2d42:	8e c2                	mov    es,dx
    2d44:	06                   	push   es
    2d45:	57                   	push   di
    2d46:	9a d2 21 ff ff       	call   0xffff:0x21d2
    2d4b:	50                   	push   ax
    2d4c:	6a 00                	push   0x0
    2d4e:	6a 00                	push   0x0
    2d50:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    2d53:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    2d56:	bf 42 2a             	mov    di,0x2a42
    2d59:	9a 16 04 6b 2d       	call   0x2d6b:0x416
    2d5e:	50                   	push   ax
    2d5f:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    2d62:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    2d65:	bf 42 2a             	mov    di,0x2a42
    2d68:	9a 16 04 7e 2d       	call   0x2d7e:0x416
    2d6d:	50                   	push   ax
    2d6e:	6a 00                	push   0x0
    2d70:	6a 00                	push   0x0
    2d72:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    2d75:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    2d78:	bf 42 2a             	mov    di,0x2a42
    2d7b:	9a 16 04 8d 2d       	call   0x2d8d:0x416
    2d80:	50                   	push   ax
    2d81:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    2d84:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    2d87:	bf 42 2a             	mov    di,0x2a42
    2d8a:	9a 16 04 e0 2d       	call   0x2de0:0x416
    2d8f:	50                   	push   ax
    2d90:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2d93:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2d96:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2d99:	06                   	push   es
    2d9a:	57                   	push   di
    2d9b:	6a 00                	push   0x0
    2d9d:	68 cc 00             	push   0xcc
    2da0:	6a 20                	push   0x20
    2da2:	9a ff ff 00 00       	call   0x0:0xffff
    2da7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2dab:	83 c4 06             	add    sp,0x6
    2dae:	b8 c4 2d             	mov    ax,0x2dc4
    2db1:	0e                   	push   cs
    2db2:	50                   	push   ax
    2db3:	ff 76 d8             	push   WORD PTR [bp-0x28]
    2db6:	9a ff ff 00 00       	call   0x0:0xffff
    2dbb:	ff 76 d8             	push   WORD PTR [bp-0x28]
    2dbe:	9a ff ff 00 00       	call   0x0:0xffff
    2dc3:	cb                   	retf
    2dc4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2dc8:	83 c4 06             	add    sp,0x6
    2dcb:	b8 e9 2d             	mov    ax,0x2de9
    2dce:	0e                   	push   cs
    2dcf:	50                   	push   ax
    2dd0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2dd3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2dd6:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2dd9:	99                   	cwd
    2dda:	bf 50 2a             	mov    di,0x2a50
    2ddd:	9a 16 04 e6 2d       	call   0x2de6:0x416
    2de2:	50                   	push   ax
    2de3:	9a 9c 01 fd 2d       	call   0x2dfd:0x19c
    2de8:	cb                   	retf
    2de9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2ded:	83 c4 06             	add    sp,0x6
    2df0:	b8 00 2e             	mov    ax,0x2e00
    2df3:	0e                   	push   cs
    2df4:	50                   	push   ax
    2df5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2df8:	06                   	push   es
    2df9:	57                   	push   di
    2dfa:	9a 7f 1f 20 2e       	call   0x2e20:0x1f7f
    2dff:	cb                   	retf
    2e00:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2e04:	06                   	push   es
    2e05:	57                   	push   di
    2e06:	9a 03 73 f7 30       	call   0x30f7:0x7303
    2e0b:	c9                   	leave
    2e0c:	ca 08 00             	retf   0x8
    2e0f:	06                   	push   es
    2e10:	20 76 65             	and    BYTE PTR [bp+0x65],dh
    2e13:	72 2e                	jb     0x2e43
    2e15:	20 00                	and    BYTE PTR [bx+si],al
    2e17:	55                   	push   bp
    2e18:	89 e5                	mov    bp,sp
    2e1a:	b8 04 05             	mov    ax,0x504
    2e1d:	9a 44 04 be 2e       	call   0x2ebe:0x444
    2e22:	81 ec 04 05          	sub    sp,0x504
    2e26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e29:	31 c0                	xor    ax,ax
    2e2b:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    2e30:	26 89 85 bb 02       	mov    WORD PTR es:[di+0x2bb],ax
    2e35:	26 89 85 bd 02       	mov    WORD PTR es:[di+0x2bd],ax
    2e3a:	26 89 85 bf 02       	mov    WORD PTR es:[di+0x2bf],ax
    2e3f:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2e43:	89 be f8 fc          	mov    WORD PTR [bp-0x308],di
    2e47:	8c 86 fa fc          	mov    WORD PTR [bp-0x306],es
    2e4b:	8d be 00 ff          	lea    di,[bp-0x100]
    2e4f:	16                   	push   ss
    2e50:	57                   	push   di
    2e51:	8d be 00 fe          	lea    di,[bp-0x200]
    2e55:	16                   	push   ss
    2e56:	57                   	push   di
    2e57:	8d be 00 fd          	lea    di,[bp-0x300]
    2e5b:	16                   	push   ss
    2e5c:	57                   	push   di
    2e5d:	8d be fe fc          	lea    di,[bp-0x302]
    2e61:	16                   	push   ss
    2e62:	57                   	push   di
    2e63:	c4 be f8 fc          	les    di,DWORD PTR [bp-0x308]
    2e67:	06                   	push   es
    2e68:	57                   	push   di
    2e69:	9a de 26 77 2e       	call   0x2e77:0x26de
    2e6e:	c4 be f8 fc          	les    di,DWORD PTR [bp-0x308]
    2e72:	06                   	push   es
    2e73:	57                   	push   di
    2e74:	9a 51 2a 4e 30       	call   0x304e:0x2a51
    2e79:	50                   	push   ax
    2e7a:	6a 00                	push   0x0
    2e7c:	9a ff ff 00 00       	call   0x0:0xffff
    2e81:	89 86 fc fc          	mov    WORD PTR [bp-0x304],ax
    2e85:	8d be fc fb          	lea    di,[bp-0x404]
    2e89:	16                   	push   ss
    2e8a:	57                   	push   di
    2e8b:	8d be 00 ff          	lea    di,[bp-0x100]
    2e8f:	16                   	push   ss
    2e90:	57                   	push   di
    2e91:	9a 6e 0e b4 2e       	call   0x2eb4:0xe6e
    2e96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e99:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    2e9e:	06                   	push   es
    2e9f:	57                   	push   di
    2ea0:	9a 8c 1d e4 2e       	call   0x2ee4:0x1d8c
    2ea5:	8d be fc fb          	lea    di,[bp-0x404]
    2ea9:	16                   	push   ss
    2eaa:	57                   	push   di
    2eab:	8d be 00 fe          	lea    di,[bp-0x200]
    2eaf:	16                   	push   ss
    2eb0:	57                   	push   di
    2eb1:	9a 6e 0e d0 2e       	call   0x2ed0:0xe6e
    2eb6:	bf 0f 2e             	mov    di,0x2e0f
    2eb9:	0e                   	push   cs
    2eba:	57                   	push   di
    2ebb:	9a 4c 18 d5 2e       	call   0x2ed5:0x184c
    2ec0:	8d be fc fa          	lea    di,[bp-0x504]
    2ec4:	16                   	push   ss
    2ec5:	57                   	push   di
    2ec6:	8b 86 fc fc          	mov    ax,WORD PTR [bp-0x304]
    2eca:	99                   	cwd
    2ecb:	52                   	push   dx
    2ecc:	50                   	push   ax
    2ecd:	9a a9 08 f5 2e       	call   0x2ef5:0x8a9
    2ed2:	9a 4c 18 36 2f       	call   0x2f36:0x184c
    2ed7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eda:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2edf:	06                   	push   es
    2ee0:	57                   	push   di
    2ee1:	9a 8c 1d 04 2f       	call   0x2f04:0x1d8c
    2ee6:	8d be fc fb          	lea    di,[bp-0x404]
    2eea:	16                   	push   ss
    2eeb:	57                   	push   di
    2eec:	8d be 00 fd          	lea    di,[bp-0x300]
    2ef0:	16                   	push   ss
    2ef1:	57                   	push   di
    2ef2:	9a 6e 0e 78 2f       	call   0x2f78:0xe6e
    2ef7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2efa:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2eff:	06                   	push   es
    2f00:	57                   	push   di
    2f01:	9a 8c 1d 87 2f       	call   0x2f87:0x1d8c
    2f06:	6a 01                	push   0x1
    2f08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f0b:	06                   	push   es
    2f0c:	57                   	push   di
    2f0d:	9a 4a 2f 1f 2f       	call   0x2f1f:0x2f4a
    2f12:	bf 16 2e             	mov    di,0x2e16
    2f15:	0e                   	push   cs
    2f16:	57                   	push   di
    2f17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f1a:	06                   	push   es
    2f1b:	57                   	push   di
    2f1c:	9a d0 2f 3a 30       	call   0x303a:0x2fd0
    2f21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f24:	26 c6 85 c1 02 01    	mov    BYTE PTR es:[di+0x2c1],0x1
    2f2a:	c9                   	leave
    2f2b:	ca 08 00             	retf   0x8
    2f2e:	55                   	push   bp
    2f2f:	89 e5                	mov    bp,sp
    2f31:	31 c0                	xor    ax,ax
    2f33:	9a 44 04 53 2f       	call   0x2f53:0x444
    2f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f3b:	26 8a 85 b4 01       	mov    al,BYTE PTR es:[di+0x1b4]
    2f40:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f43:	26 88 05             	mov    BYTE PTR es:[di],al
    2f46:	c9                   	leave
    2f47:	ca 0c 00             	retf   0xc
    2f4a:	55                   	push   bp
    2f4b:	89 e5                	mov    bp,sp
    2f4d:	b8 00 01             	mov    ax,0x100
    2f50:	9a 44 04 96 2f       	call   0x2f96:0x444
    2f55:	81 ec 00 01          	sub    sp,0x100
    2f59:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2f5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f5f:	26 89 85 b7 01       	mov    WORD PTR es:[di+0x1b7],ax
    2f64:	8d be 00 ff          	lea    di,[bp-0x100]
    2f68:	16                   	push   ss
    2f69:	57                   	push   di
    2f6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6d:	26 8b 85 b7 01       	mov    ax,WORD PTR es:[di+0x1b7]
    2f72:	99                   	cwd
    2f73:	52                   	push   dx
    2f74:	50                   	push   ax
    2f75:	9a a9 08 bb 2f       	call   0x2fbb:0x8a9
    2f7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f7d:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2f82:	06                   	push   es
    2f83:	57                   	push   di
    2f84:	9a 8c 1d ca 2f       	call   0x2fca:0x1d8c
    2f89:	c9                   	leave
    2f8a:	ca 06 00             	retf   0x6
    2f8d:	55                   	push   bp
    2f8e:	89 e5                	mov    bp,sp
    2f90:	b8 00 01             	mov    ax,0x100
    2f93:	9a 44 04 d9 2f       	call   0x2fd9:0x444
    2f98:	81 ec 00 01          	sub    sp,0x100
    2f9c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2f9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa2:	26 89 85 b5 01       	mov    WORD PTR es:[di+0x1b5],ax
    2fa7:	8d be 00 ff          	lea    di,[bp-0x100]
    2fab:	16                   	push   ss
    2fac:	57                   	push   di
    2fad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb0:	26 8b 85 b5 01       	mov    ax,WORD PTR es:[di+0x1b5]
    2fb5:	99                   	cwd
    2fb6:	52                   	push   dx
    2fb7:	50                   	push   ax
    2fb8:	9a a9 08 0c 31       	call   0x310c:0x8a9
    2fbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc0:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2fc5:	06                   	push   es
    2fc6:	57                   	push   di
    2fc7:	9a 8c 1d 20 30       	call   0x3020:0x1d8c
    2fcc:	c9                   	leave
    2fcd:	ca 06 00             	retf   0x6
    2fd0:	55                   	push   bp
    2fd1:	89 e5                	mov    bp,sp
    2fd3:	b8 00 01             	mov    ax,0x100
    2fd6:	9a 44 04 0b 30       	call   0x300b:0x444
    2fdb:	81 ec 00 01          	sub    sp,0x100
    2fdf:	8c d3                	mov    bx,ss
    2fe1:	8e c3                	mov    es,bx
    2fe3:	8c db                	mov    bx,ds
    2fe5:	fc                   	cld
    2fe6:	8d be 00 ff          	lea    di,[bp-0x100]
    2fea:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2fed:	ac                   	lods   al,BYTE PTR ds:[si]
    2fee:	aa                   	stos   BYTE PTR es:[di],al
    2fef:	91                   	xchg   cx,ax
    2ff0:	30 ed                	xor    ch,ch
    2ff2:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2ff4:	8e db                	mov    ds,bx
    2ff6:	8d be 00 ff          	lea    di,[bp-0x100]
    2ffa:	16                   	push   ss
    2ffb:	57                   	push   di
    2ffc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fff:	81 c7 b9 01          	add    di,0x1b9
    3003:	06                   	push   es
    3004:	57                   	push   di
    3005:	68 ff 00             	push   0xff
    3008:	9a e7 17 2e 30       	call   0x302e:0x17e7
    300d:	8d be 00 ff          	lea    di,[bp-0x100]
    3011:	16                   	push   ss
    3012:	57                   	push   di
    3013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3016:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    301b:	06                   	push   es
    301c:	57                   	push   di
    301d:	9a 8c 1d a4 31       	call   0x31a4:0x1d8c
    3022:	c9                   	leave
    3023:	ca 08 00             	retf   0x8
    3026:	55                   	push   bp
    3027:	89 e5                	mov    bp,sp
    3029:	31 c0                	xor    ax,ax
    302b:	9a 44 04 6b 30       	call   0x306b:0x444
    3030:	6a 01                	push   0x1
    3032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3035:	06                   	push   es
    3036:	57                   	push   di
    3037:	9a 62 30 52 30       	call   0x3052:0x3062
    303c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303f:	26 c7 85 04 01 02 00 	mov    WORD PTR es:[di+0x104],0x2
    3046:	c9                   	leave
    3047:	ca 08 00             	retf   0x8
    304a:	02 00                	add    al,BYTE PTR [bx+si]
    304c:	a1 1a a4             	mov    ax,ds:0xa41a
    304f:	30 af 30 5a          	xor    BYTE PTR [bx+0x5a30],ch
    3053:	30 00                	xor    BYTE PTR [bx+si],al
    3055:	00 00                	add    BYTE PTR [bx+si],al
    3057:	00 be 30 60          	add    BYTE PTR [bp+0x6030],bh
    305b:	30 00                	xor    BYTE PTR [bx+si],al
    305d:	00 e3                	add    bl,ah
    305f:	30 08                	xor    BYTE PTR [bx+si],cl
    3061:	31 55 89             	xor    WORD PTR [di-0x77],dx
    3064:	e5 b8                	in     ax,0xb8
    3066:	04 00                	add    al,0x0
    3068:	9a 44 04 d5 30       	call   0x30d5:0x444
    306d:	83 ec 04             	sub    sp,0x4
    3070:	b8 5c 30             	mov    ax,0x305c
    3073:	0e                   	push   cs
    3074:	50                   	push   ax
    3075:	55                   	push   bp
    3076:	ff 36 58 18          	push   WORD PTR ds:0x1858
    307a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    307e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3081:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3085:	26 22 45 18          	and    al,BYTE PTR es:[di+0x18]
    3089:	08 c0                	or     al,al
    308b:	74 4a                	je     0x30d7
    308d:	b8 4a 30             	mov    ax,0x304a
    3090:	0e                   	push   cs
    3091:	50                   	push   ax
    3092:	55                   	push   bp
    3093:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3097:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    309b:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    309f:	06                   	push   es
    30a0:	57                   	push   di
    30a1:	9a 8d 25 04 31       	call   0x3104:0x258d
    30a6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    30aa:	83 c4 06             	add    sp,0x6
    30ad:	eb 28                	jmp    0x30d7
    30af:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    30b2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    30b5:	6a 00                	push   0x0
    30b7:	9a d2 35 00 00       	call   0x0:0x35d2
    30bc:	eb 14                	jmp    0x30d2
    30be:	6a 00                	push   0x0
    30c0:	bf a2 04             	mov    di,0x4a2
    30c3:	1e                   	push   ds
    30c4:	57                   	push   di
    30c5:	bf ae 04             	mov    di,0x4ae
    30c8:	1e                   	push   ds
    30c9:	57                   	push   di
    30ca:	68 00 20             	push   0x2000
    30cd:	9a 19 32 00 00       	call   0x0:0x3219
    30d2:	9a 34 14 23 31       	call   0x3123:0x1434
    30d7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    30db:	83 c4 06             	add    sp,0x6
    30de:	b8 fa 30             	mov    ax,0x30fa
    30e1:	0e                   	push   cs
    30e2:	50                   	push   ax
    30e3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    30e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e9:	26 88 85 b4 01       	mov    BYTE PTR es:[di+0x1b4],al
    30ee:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    30f2:	06                   	push   es
    30f3:	57                   	push   di
    30f4:	9a 03 73 32 31       	call   0x3132:0x7303
    30f9:	cb                   	retf
    30fa:	c9                   	leave
    30fb:	ca 06 00             	retf   0x6
    30fe:	01 00                	add    WORD PTR [bx+si],ax
    3100:	03 00                	add    ax,WORD PTR [bx+si]
    3102:	a1 1a 77             	mov    ax,ds:0x771a
    3105:	31 cb                	xor    bx,cx
    3107:	31 10                	xor    WORD PTR [bx+si],dx
    3109:	31 43 03             	xor    WORD PTR [bp+di+0x3],ax
    310c:	ee                   	out    dx,al
    310d:	31 1f                	xor    WORD PTR [bx],bx
    310f:	32 18                	xor    bl,BYTE PTR [bx+si]
    3111:	31 00                	xor    WORD PTR [bx+si],ax
    3113:	00 00                	add    BYTE PTR [bx+si],al
    3115:	00 49 32             	add    BYTE PTR [bx+di+0x32],cl
    3118:	94                   	xchg   sp,ax
    3119:	31 55 89             	xor    WORD PTR [di-0x77],dx
    311c:	e5 b8                	in     ax,0xb8
    311e:	04 02                	add    al,0x2
    3120:	9a 44 04 f8 31       	call   0x31f8:0x444
    3125:	81 ec 04 02          	sub    sp,0x204
    3129:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    312d:	06                   	push   es
    312e:	57                   	push   di
    312f:	9a 03 73 39 33       	call   0x3339:0x7303
    3134:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3137:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    313d:	b0 00                	mov    al,0x0
    313f:	75 01                	jne    0x3142
    3141:	40                   	inc    ax
    3142:	8a d0                	mov    dl,al
    3144:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    3147:	0b 46 10             	or     ax,WORD PTR [bp+0x10]
    314a:	b0 00                	mov    al,0x0
    314c:	74 01                	je     0x314f
    314e:	40                   	inc    ax
    314f:	22 c2                	and    al,dl
    3151:	08 c0                	or     al,al
    3153:	75 03                	jne    0x3158
    3155:	e9 16 01             	jmp    0x326e
    3158:	b8 00 31             	mov    ax,0x3100
    315b:	0e                   	push   cs
    315c:	50                   	push   ax
    315d:	55                   	push   bp
    315e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3162:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3166:	26 80 bd c1 02 00    	cmp    BYTE PTR es:[di+0x2c1],0x0
    316c:	75 0d                	jne    0x317b
    316e:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3172:	06                   	push   es
    3173:	57                   	push   di
    3174:	9a 9a 26 fc 32       	call   0x32fc:0x269a
    3179:	eb 09                	jmp    0x3184
    317b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    317e:	26 c6 85 c1 02 00    	mov    BYTE PTR es:[di+0x2c1],0x0
    3184:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3188:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    318c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    318f:	06                   	push   es
    3190:	57                   	push   di
    3191:	9a 4a 2f ae 31       	call   0x31ae:0x2f4a
    3196:	8d be 00 fe          	lea    di,[bp-0x200]
    319a:	16                   	push   ss
    319b:	57                   	push   di
    319c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    319f:	06                   	push   es
    31a0:	57                   	push   di
    31a1:	9a 53 1d e9 33       	call   0x33e9:0x1d53
    31a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31a9:	06                   	push   es
    31aa:	57                   	push   di
    31ab:	9a d0 2f bf 31       	call   0x31bf:0x2fd0
    31b0:	ff 76 10             	push   WORD PTR [bp+0x10]
    31b3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    31b6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    31b9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    31bc:	9a 64 2a dd 31       	call   0x31dd:0x2a64
    31c1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    31c5:	83 c4 06             	add    sp,0x6
    31c8:	e9 a3 00             	jmp    0x326e
    31cb:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    31cf:	89 96 fe fe          	mov    WORD PTR [bp-0x102],dx
    31d3:	6a 01                	push   0x1
    31d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31d8:	06                   	push   es
    31d9:	57                   	push   di
    31da:	9a 62 30 31 32       	call   0x3231:0x3062
    31df:	8d be fc fd          	lea    di,[bp-0x204]
    31e3:	16                   	push   ss
    31e4:	57                   	push   di
    31e5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    31e9:	06                   	push   es
    31ea:	57                   	push   di
    31eb:	9a e6 29 56 3d       	call   0x3d56:0x29e6
    31f0:	bf fe 30             	mov    di,0x30fe
    31f3:	0e                   	push   cs
    31f4:	57                   	push   di
    31f5:	9a 4c 18 06 32       	call   0x3206:0x184c
    31fa:	8d be 00 ff          	lea    di,[bp-0x100]
    31fe:	16                   	push   ss
    31ff:	57                   	push   di
    3200:	68 ff 00             	push   0xff
    3203:	9a e7 17 6c 32       	call   0x326c:0x17e7
    3208:	6a 00                	push   0x0
    320a:	8d be 01 ff          	lea    di,[bp-0xff]
    320e:	16                   	push   ss
    320f:	57                   	push   di
    3210:	bf b6 04             	mov    di,0x4b6
    3213:	1e                   	push   ds
    3214:	57                   	push   di
    3215:	68 00 20             	push   0x2000
    3218:	9a 43 32 00 00       	call   0x0:0x3243
    321d:	eb 4a                	jmp    0x3269
    321f:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    3223:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    3227:	6a 01                	push   0x1
    3229:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322c:	06                   	push   es
    322d:	57                   	push   di
    322e:	9a 62 30 53 32       	call   0x3253:0x3062
    3233:	6a 00                	push   0x0
    3235:	bf bd 04             	mov    di,0x4bd
    3238:	1e                   	push   ds
    3239:	57                   	push   di
    323a:	bf b6 04             	mov    di,0x4b6
    323d:	1e                   	push   ds
    323e:	57                   	push   di
    323f:	68 00 20             	push   0x2000
    3242:	9a 65 32 00 00       	call   0x0:0x3265
    3247:	eb 20                	jmp    0x3269
    3249:	6a 01                	push   0x1
    324b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    324e:	06                   	push   es
    324f:	57                   	push   di
    3250:	9a 62 30 95 32       	call   0x3295:0x3062
    3255:	6a 00                	push   0x0
    3257:	bf c6 04             	mov    di,0x4c6
    325a:	1e                   	push   ds
    325b:	57                   	push   di
    325c:	bf b6 04             	mov    di,0x4b6
    325f:	1e                   	push   ds
    3260:	57                   	push   di
    3261:	68 00 20             	push   0x2000
    3264:	9a e4 34 00 00       	call   0x0:0x34e4
    3269:	9a 34 14 7a 32       	call   0x327a:0x1434
    326e:	c9                   	leave
    326f:	ca 0c 00             	retf   0xc
    3272:	55                   	push   bp
    3273:	89 e5                	mov    bp,sp
    3275:	31 c0                	xor    ax,ax
    3277:	9a 44 04 a3 32       	call   0x32a3:0x444
    327c:	6a 00                	push   0x0
    327e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3281:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    3286:	06                   	push   es
    3287:	57                   	push   di
    3288:	9a 49 27 b4 32       	call   0x32b4:0x2749
    328d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3290:	06                   	push   es
    3291:	57                   	push   di
    3292:	9a c6 32 be 32       	call   0x32be:0x32c6
    3297:	c9                   	leave
    3298:	ca 08 00             	retf   0x8
    329b:	55                   	push   bp
    329c:	89 e5                	mov    bp,sp
    329e:	31 c0                	xor    ax,ax
    32a0:	9a 44 04 ce 32       	call   0x32ce:0x444
    32a5:	6a 01                	push   0x1
    32a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32aa:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    32af:	06                   	push   es
    32b0:	57                   	push   di
    32b1:	9a 49 27 93 34       	call   0x3493:0x2749
    32b6:	c9                   	leave
    32b7:	ca 08 00             	retf   0x8
    32ba:	00 00                	add    BYTE PTR [bx+si],al
    32bc:	30 33                	xor    BYTE PTR [bp+di],dh
    32be:	c4 32                	les    si,DWORD PTR [bp+si]
    32c0:	00 00                	add    BYTE PTR [bx+si],al
    32c2:	5e                   	pop    si
    32c3:	33 f1                	xor    si,cx
    32c5:	32 55 89             	xor    dl,BYTE PTR [di-0x77]
    32c8:	e5 31                	in     ax,0x31
    32ca:	c0 9a 44 04 8d       	rcr    BYTE PTR [bp+si+0x444],0x8d
    32cf:	33 b8 c0 32          	xor    di,WORD PTR [bx+si+0x32c0]
    32d3:	0e                   	push   cs
    32d4:	50                   	push   ax
    32d5:	55                   	push   bp
    32d6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    32da:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    32de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e1:	26 8b 85 bb 02       	mov    ax,WORD PTR es:[di+0x2bb]
    32e6:	09 c0                	or     ax,ax
    32e8:	74 68                	je     0x3352
    32ea:	6a 00                	push   0x0
    32ec:	06                   	push   es
    32ed:	57                   	push   di
    32ee:	9a 62 30 2e 34       	call   0x342e:0x3062
    32f3:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    32f7:	06                   	push   es
    32f8:	57                   	push   di
    32f9:	9a a8 25 4f 33       	call   0x334f:0x25a8
    32fe:	b8 ba 32             	mov    ax,0x32ba
    3301:	0e                   	push   cs
    3302:	50                   	push   ax
    3303:	55                   	push   bp
    3304:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3308:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    330c:	ff 76 08             	push   WORD PTR [bp+0x8]
    330f:	ff 76 06             	push   WORD PTR [bp+0x6]
    3312:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3315:	26 ff b5 bf 02       	push   WORD PTR es:[di+0x2bf]
    331a:	26 ff b5 bd 02       	push   WORD PTR es:[di+0x2bd]
    331f:	26 ff 9d b9 02       	call   DWORD PTR es:[di+0x2b9]
    3324:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3328:	83 c4 06             	add    sp,0x6
    332b:	b8 52 33             	mov    ax,0x3352
    332e:	0e                   	push   cs
    332f:	50                   	push   ax
    3330:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3334:	06                   	push   es
    3335:	57                   	push   di
    3336:	9a 03 73 01 34       	call   0x3401:0x7303
    333b:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    333f:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    3344:	74 0b                	je     0x3351
    3346:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    334a:	06                   	push   es
    334b:	57                   	push   di
    334c:	9a 55 26 ff ff       	call   0xffff:0x2655
    3351:	cb                   	retf
    3352:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3356:	83 c4 06             	add    sp,0x6
    3359:	b8 6f 33             	mov    ax,0x336f
    335c:	0e                   	push   cs
    335d:	50                   	push   ax
    335e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3361:	26 c6 85 b4 01 01    	mov    BYTE PTR es:[di+0x1b4],0x1
    3367:	26 c7 85 04 01 01 00 	mov    WORD PTR es:[di+0x104],0x1
    336e:	cb                   	retf
    336f:	c9                   	leave
    3370:	ca 04 00             	retf   0x4
    3373:	99                   	cwd
    3374:	34 66                	xor    al,0x66
    3376:	34 2a                	xor    al,0x2a
    3378:	34 00                	xor    al,0x0
    337a:	00 0f                	add    BYTE PTR [bx],cl
    337c:	34 89                	xor    al,0x89
    337e:	01 fb                	add    bx,di
    3380:	04 bb                	add    al,0xbb
    3382:	34 39                	xor    al,0x39
    3384:	3f                   	aas
    3385:	99                   	cwd
    3386:	33 9a 1f cf          	xor    bx,WORD PTR [bp+si-0x30e1]
    338a:	34 cb                	xor    al,0xcb
    338c:	1f                   	pop    ds
    338d:	89 33                	mov    WORD PTR [bp+di],si
    338f:	ad                   	lods   ax,WORD PTR ds:[si]
    3390:	27                   	daa
    3391:	0d 34 cd             	or     ax,0xcd34
    3394:	11 9d 33 f7          	adc    WORD PTR [di-0x8cd],bx
    3398:	2a f9                	sub    bh,cl
    339a:	33 fa                	xor    di,dx
    339c:	10 ff                	adc    bh,bh
    339e:	ff d6                	call   si
    33a0:	14 d1                	adc    al,0xd1
    33a2:	33 f4                	xor    si,sp
    33a4:	4f                   	dec    di
    33a5:	bd 33 9a             	mov    bp,0x9a33
    33a8:	28 05                	sub    BYTE PTR [di],al
    33aa:	34 85                	xor    al,0x85
    33ac:	29 b1 33 57          	sub    WORD PTR [bx+di+0x5733],si
    33b0:	4d                   	dec    bp
    33b1:	b5 33                	mov    ch,0x33
    33b3:	91                   	xchg   cx,ax
    33b4:	2f                   	das
    33b5:	d5 33                	aad    0x33
    33b7:	63 31                	arpl   WORD PTR [bx+di],si
    33b9:	d9 33                	fnstenv [bp+di]
    33bb:	21 50 95             	and    WORD PTR [bx+si-0x6b],dx
    33be:	33 53 25             	xor    dx,WORD PTR [bp+di+0x25]
    33c1:	91                   	xchg   cx,ax
    33c2:	33 d9                	xor    bx,cx
    33c4:	62 cd 33             	(bad)  {k5},{ru-bad}
    33c7:	55                   	push   bp
    33c8:	2e a9 33 8f          	cs test ax,0x8f33
    33cc:	60                   	pusha
    33cd:	09 34                	or     WORD PTR [si],si
    33cf:	3a 1c                	cmp    bl,BYTE PTR [si]
    33d1:	6d                   	ins    WORD PTR es:[di],dx
    33d2:	35 e2 2f             	xor    ax,0x2fe2
    33d5:	c1 33 08             	shl    WORD PTR [bp+di],0x8
    33d8:	61                   	popa
    33d9:	dd 33                	fnsave [bp+di]
    33db:	5c                   	pop    sp
    33dc:	61                   	popa
    33dd:	e1 33                	loope  0x3412
    33df:	62 5c e5             	bound  bx,DWORD PTR [si-0x1b]
    33e2:	33 3a                	xor    di,WORD PTR [bp+si]
    33e4:	61                   	popa
    33e5:	a1 33 72             	mov    ax,ds:0x7233
    33e8:	3f                   	aas
    33e9:	fd                   	std
    33ea:	33 58 3a             	xor    bx,WORD PTR [bx+si+0x3a]
    33ed:	f1                   	int1
    33ee:	33 ec                	xor    bp,sp
    33f0:	3d f5 33             	cmp    ax,0x33f5
    33f3:	e4 3c                	in     al,0x3c
    33f5:	85 33                	test   WORD PTR [bp+di],si
    33f7:	ed                   	in     ax,dx
    33f8:	3e c9                	ds leave
    33fa:	33 77 3e             	xor    si,WORD PTR [bx+0x3e]
    33fd:	c5 33                	lds    si,DWORD PTR [bp+di]
    33ff:	e6 31                	out    0x31,al
    3401:	ed                   	in     ax,dx
    3402:	33 3c                	xor    di,WORD PTR [si]
    3404:	47                   	inc    di
    3405:	ad                   	lods   ax,WORD PTR ds:[si]
    3406:	33 ae 5f b9          	xor    bp,WORD PTR [bp-0x46a1]
    340a:	33 e9                	xor    bp,cx
    340c:	5c                   	pop    sp
    340d:	81 33 1a 54          	xor    WORD PTR [bp+di],0x541a
    3411:	46                   	inc    si
    3412:	6f                   	outs   dx,WORD PTR ds:[si]
    3413:	72 6d                	jb     0x3482
    3415:	53                   	push   bx
    3416:	4d                   	dec    bp
    3417:	53                   	push   bx
    3418:	4d                   	dec    bp
    3419:	5f                   	pop    di
    341a:	4d                   	dec    bp
    341b:	65 73 73             	gs jae 0x3491
    341e:	61                   	popa
    341f:	67 65 41             	addr32 gs inc cx
    3422:	75 74                	jne    0x3498
    3424:	6f                   	outs   dx,WORD PTR ds:[si]
    3425:	43                   	inc    bx
    3426:	6c                   	ins    BYTE PTR es:[di],dx
    3427:	6f                   	outs   dx,WORD PTR ds:[si]
    3428:	73 65                	jae    0x348f
    342a:	04 00                	add    al,0x0
    342c:	37                   	aaa
    342d:	36 3e 34 0b          	ss ds xor al,0xb
    3431:	54                   	push   sp
    3432:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
    3437:	54                   	push   sp
    3438:	69 6d 65 72 14       	imul   bp,WORD PTR [di+0x65],0x1472
    343d:	36 4b                	ss dec bx
    343f:	34 08                	xor    al,0x8
    3441:	46                   	inc    si
    3442:	6f                   	outs   dx,WORD PTR ds:[si]
    3443:	72 6d                	jb     0x34b2
    3445:	53                   	push   bx
    3446:	68 6f 77             	push   0x776f
    3449:	e8 35 5a             	call   0x8e81
    344c:	34 0a                	xor    al,0xa
    344e:	46                   	inc    si
    344f:	6f                   	outs   dx,WORD PTR ds:[si]
    3450:	72 6d                	jb     0x34bf
    3452:	43                   	inc    bx
    3453:	72 65                	jb     0x34ba
    3455:	61                   	popa
    3456:	74 65                	je     0x34bd
    3458:	ff 35                	push   WORD PTR [di]
    345a:	b7 34                	mov    bh,0x34
    345c:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
    345f:	72 6d                	jb     0x34ce
    3461:	43                   	inc    bx
    3462:	6c                   	ins    BYTE PTR es:[di],dx
    3463:	6f                   	outs   dx,WORD PTR ds:[si]
    3464:	73 65                	jae    0x34cb
    3466:	03 00                	add    ax,WORD PTR [bx+si]
    3468:	8b 34                	mov    si,WORD PTR [si]
    346a:	7c 01                	jl     0x346d
    346c:	00 00                	add    BYTE PTR [bx+si],al
    346e:	07                   	pop    es
    346f:	42                   	inc    dx
    3470:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    3475:	31 80 01 04          	xor    WORD PTR [bx+si+0x401],ax
    3479:	00 06 54 69          	add    BYTE PTR ds:0x6954,al
    347d:	6d                   	ins    WORD PTR es:[di],dx
    347e:	65 72 31             	gs jb  0x34b2
    3481:	84 01                	test   BYTE PTR [bx+di],al
    3483:	08 00                	or     BYTE PTR [bx+si],al
    3485:	05 4d 65             	add    ax,0x654d
    3488:	6d                   	ins    WORD PTR es:[di],dx
    3489:	6f                   	outs   dx,WORD PTR ds:[si]
    348a:	31 03                	xor    WORD PTR [bp+di],ax
    348c:	00 ac 04 ff          	add    BYTE PTR [si-0xfc],ch
    3490:	ff 8b 0b 31          	dec    WORD PTR [bp+di+0x310b]
    3494:	36 91                	ss xchg cx,ax
    3496:	12 ff                	adc    bh,bh
    3498:	ff 07                	inc    WORD PTR [bx]
    349a:	1a 54 46             	sbb    dl,BYTE PTR [si+0x46]
    349d:	6f                   	outs   dx,WORD PTR ds:[si]
    349e:	72 6d                	jb     0x350d
    34a0:	53                   	push   bx
    34a1:	4d                   	dec    bp
    34a2:	53                   	push   bx
    34a3:	4d                   	dec    bp
    34a4:	5f                   	pop    di
    34a5:	4d                   	dec    bp
    34a6:	65 73 73             	gs jae 0x351c
    34a9:	61                   	popa
    34aa:	67 65 41             	addr32 gs inc cx
    34ad:	75 74                	jne    0x3523
    34af:	6f                   	outs   dx,WORD PTR ds:[si]
    34b0:	43                   	inc    bx
    34b1:	6c                   	ins    BYTE PTR es:[di],dx
    34b2:	6f                   	outs   dx,WORD PTR ds:[si]
    34b3:	73 65                	jae    0x351a
    34b5:	93                   	xchg   bx,ax
    34b6:	33 48 35             	xor    cx,WORD PTR [bx+si+0x35]
    34b9:	7b 06                	jnp    0x34c1
    34bb:	4f                   	dec    di
    34bc:	35 38 00             	xor    ax,0x38
    34bf:	04 53                	add    al,0x53
    34c1:	6d                   	ins    WORD PTR es:[di],dx
    34c2:	73 6d                	jae    0x3531
    34c4:	00 00                	add    BYTE PTR [bx+si],al
    34c6:	55                   	push   bp
    34c7:	89 e5                	mov    bp,sp
    34c9:	b8 02 00             	mov    ax,0x2
    34cc:	9a 44 04 34 35       	call   0x3534:0x444
    34d1:	83 ec 02             	sub    sp,0x2
    34d4:	6a 00                	push   0x0
    34d6:	bf d2 04             	mov    di,0x4d2
    34d9:	1e                   	push   ds
    34da:	57                   	push   di
    34db:	bf e4 04             	mov    di,0x4e4
    34de:	1e                   	push   ds
    34df:	57                   	push   di
    34e0:	68 41 10             	push   0x1041
    34e3:	9a ff ff 00 00       	call   0x0:0xffff
    34e8:	3d 01 00             	cmp    ax,0x1
    34eb:	b0 00                	mov    al,0x0
    34ed:	75 01                	jne    0x34f0
    34ef:	40                   	inc    ax
    34f0:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    34f3:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    34f6:	c9                   	leave
    34f7:	cb                   	retf
    34f8:	0f 56 65 72          	orps   xmm4,XMMWORD PTR [di+0x72]
    34fc:	73 69                	jae    0x3567
    34fe:	6f                   	outs   dx,WORD PTR ds:[si]
    34ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    3500:	20 6c 69             	and    BYTE PTR [si+0x69],ch
    3503:	6d                   	ins    WORD PTR es:[di],dx
    3504:	69 74 e9 65 00       	imul   si,WORD PTR [si-0x17],0x65
    3509:	21 4e 6f             	and    WORD PTR [bp+0x6f],cx
    350c:	6e                   	outs   dx,BYTE PTR ds:[si]
    350d:	20 64 69             	and    BYTE PTR [si+0x69],ah
    3510:	73 70                	jae    0x3582
    3512:	6f                   	outs   dx,WORD PTR ds:[si]
    3513:	6e                   	outs   dx,BYTE PTR ds:[si]
    3514:	69 62 6c 65 20       	imul   sp,WORD PTR [bp+si+0x6c],0x2065
    3519:	65 6e                	outs   dx,BYTE PTR gs:[si]
    351b:	20 76 65             	and    BYTE PTR [bp+0x65],dh
    351e:	72 73                	jb     0x3593
    3520:	69 6f 6e 20 6c       	imul   bp,WORD PTR [bx+0x6e],0x6c20
    3525:	69 6d 69 74 e9       	imul   bp,WORD PTR [di+0x69],0xe974
    352a:	65 55                	gs push bp
    352c:	89 e5                	mov    bp,sp
    352e:	b8 08 00             	mov    ax,0x8
    3531:	9a 44 04 f0 35       	call   0x35f0:0x444
    3536:	83 ec 08             	sub    sp,0x8
    3539:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    353d:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3541:	b0 01                	mov    al,0x1
    3543:	50                   	push   ax
    3544:	b8 93 33             	mov    ax,0x3393
    3547:	ba 92 36             	mov    dx,0x3692
    354a:	52                   	push   dx
    354b:	50                   	push   ax
    354c:	9a 53 25 e4 35       	call   0x35e4:0x2553
    3551:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3554:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3557:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    355a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    355d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3560:	bf f8 34             	mov    di,0x34f8
    3563:	0e                   	push   cs
    3564:	57                   	push   di
    3565:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3568:	06                   	push   es
    3569:	57                   	push   di
    356a:	9a 8c 1d cd 35       	call   0x35cd:0x1d8c
    356f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3572:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3577:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    357c:	06                   	push   es
    357d:	57                   	push   di
    357e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3581:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    3585:	bf 08 35             	mov    di,0x3508
    3588:	0e                   	push   cs
    3589:	57                   	push   di
    358a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    358d:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3592:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3597:	06                   	push   es
    3598:	57                   	push   di
    3599:	26 c4 3d             	les    di,DWORD PTR es:[di]
    359c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    35a0:	bf 09 35             	mov    di,0x3509
    35a3:	0e                   	push   cs
    35a4:	57                   	push   di
    35a5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35a8:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    35ad:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    35b2:	06                   	push   es
    35b3:	57                   	push   di
    35b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35b7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    35bb:	68 ff 00             	push   0xff
    35be:	6a ff                	push   0xffff
    35c0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35c3:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    35c8:	06                   	push   es
    35c9:	57                   	push   di
    35ca:	9a d5 1e b7 36       	call   0x36b7:0x1ed5
    35cf:	6a 30                	push   0x30
    35d1:	9a 58 37 00 00       	call   0x0:0x3758
    35d6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35d9:	26 c6 85 88 01 01    	mov    BYTE PTR es:[di+0x188],0x1
    35df:	06                   	push   es
    35e0:	57                   	push   di
    35e1:	9a 45 5d 5a 36       	call   0x365a:0x5d45
    35e6:	c9                   	leave
    35e7:	cb                   	retf
    35e8:	55                   	push   bp
    35e9:	89 e5                	mov    bp,sp
    35eb:	31 c0                	xor    ax,ax
    35ed:	9a 44 04 07 36       	call   0x3607:0x444
    35f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35f5:	26 c6 85 88 01 01    	mov    BYTE PTR es:[di+0x188],0x1
    35fb:	c9                   	leave
    35fc:	ca 08 00             	retf   0x8
    35ff:	55                   	push   bp
    3600:	89 e5                	mov    bp,sp
    3602:	31 c0                	xor    ax,ax
    3604:	9a 44 04 1c 36       	call   0x361c:0x444
    3609:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    360c:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    3610:	c9                   	leave
    3611:	ca 0c 00             	retf   0xc
    3614:	55                   	push   bp
    3615:	89 e5                	mov    bp,sp
    3617:	31 c0                	xor    ax,ax
    3619:	9a 44 04 3f 36       	call   0x363f:0x444
    361e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3621:	26 8a 85 88 01       	mov    al,BYTE PTR es:[di+0x188]
    3626:	50                   	push   ax
    3627:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    362c:	06                   	push   es
    362d:	57                   	push   di
    362e:	9a 49 27 50 36       	call   0x3650:0x2749
    3633:	c9                   	leave
    3634:	ca 08 00             	retf   0x8
    3637:	55                   	push   bp
    3638:	89 e5                	mov    bp,sp
    363a:	31 c0                	xor    ax,ax
    363c:	9a 44 04 7e 36       	call   0x367e:0x444
    3641:	6a 00                	push   0x0
    3643:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3646:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    364b:	06                   	push   es
    364c:	57                   	push   di
    364d:	9a 49 27 ff ff       	call   0xffff:0x2749
    3652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3655:	06                   	push   es
    3656:	57                   	push   di
    3657:	9a 56 55 99 36       	call   0x3699:0x5556
    365c:	c9                   	leave
    365d:	ca 08 00             	retf   0x8
    3660:	14 56                	adc    al,0x56
    3662:	e9 72 69             	jmp    0x9fd7
    3665:	66 69 63 61 74 69 6f 	imul   esp,DWORD PTR [bp+di+0x61],0x6e6f6974
    366c:	6e 
    366d:	73 20                	jae    0x368f
    366f:	2e 2e 2e 20 4f 4b    	cs cs and BYTE PTR cs:[bx+0x4b],cl
    3675:	55                   	push   bp
    3676:	89 e5                	mov    bp,sp
    3678:	b8 08 00             	mov    ax,0x8
    367b:	9a 44 04 04 37       	call   0x3704:0x444
    3680:	83 ec 08             	sub    sp,0x8
    3683:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3687:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    368b:	b0 01                	mov    al,0x1
    368d:	50                   	push   ax
    368e:	b8 93 33             	mov    ax,0x3393
    3691:	ba 18 37             	mov    dx,0x3718
    3694:	52                   	push   dx
    3695:	50                   	push   ax
    3696:	9a 53 25 dd 36       	call   0x36dd:0x2553
    369b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    369e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    36a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36a4:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    36a7:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    36aa:	bf 60 36             	mov    di,0x3660
    36ad:	0e                   	push   cs
    36ae:	57                   	push   di
    36af:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36b2:	06                   	push   es
    36b3:	57                   	push   di
    36b4:	9a 8c 1d 3d 37       	call   0x373d:0x1d8c
    36b9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36bc:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    36c1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    36c6:	06                   	push   es
    36c7:	57                   	push   di
    36c8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36cb:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    36cf:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36d2:	26 c6 85 88 01 01    	mov    BYTE PTR es:[di+0x188],0x1
    36d8:	06                   	push   es
    36d9:	57                   	push   di
    36da:	9a 45 5d 1f 37       	call   0x371f:0x5d45
    36df:	c9                   	leave
    36e0:	cb                   	retf
    36e1:	19 56 e9             	sbb    WORD PTR [bp-0x17],dx
    36e4:	72 69                	jb     0x374f
    36e6:	66 69 63 61 74 69 6f 	imul   esp,DWORD PTR [bp+di+0x61],0x6e6f6974
    36ed:	6e 
    36ee:	73 20                	jae    0x3710
    36f0:	2e 2e 2e 20 45 52    	cs cs and BYTE PTR cs:[di+0x52],al
    36f6:	52                   	push   dx
    36f7:	45                   	inc    bp
    36f8:	55                   	push   bp
    36f9:	52                   	push   dx
    36fa:	53                   	push   bx
    36fb:	55                   	push   bp
    36fc:	89 e5                	mov    bp,sp
    36fe:	b8 08 00             	mov    ax,0x8
    3701:	9a 44 04 da 37       	call   0x37da:0x444
    3706:	83 ec 08             	sub    sp,0x8
    3709:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    370d:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3711:	b0 01                	mov    al,0x1
    3713:	50                   	push   ax
    3714:	b8 93 33             	mov    ax,0x3393
    3717:	ba ee 37             	mov    dx,0x37ee
    371a:	52                   	push   dx
    371b:	50                   	push   ax
    371c:	9a 53 25 7e 37       	call   0x377e:0x2553
    3721:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3724:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3727:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    372a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    372d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3730:	bf e1 36             	mov    di,0x36e1
    3733:	0e                   	push   cs
    3734:	57                   	push   di
    3735:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3738:	06                   	push   es
    3739:	57                   	push   di
    373a:	9a 8c 1d 6e 37       	call   0x376e:0x1d8c
    373f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3742:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3747:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    374c:	06                   	push   es
    374d:	57                   	push   di
    374e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3751:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    3755:	6a 30                	push   0x30
    3757:	9a 64 38 00 00       	call   0x0:0x3864
    375c:	6a 00                	push   0x0
    375e:	68 ff 00             	push   0xff
    3761:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3764:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3769:	06                   	push   es
    376a:	57                   	push   di
    376b:	9a d5 1e 13 38       	call   0x3813:0x1ed5
    3770:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3773:	26 c6 85 88 01 00    	mov    BYTE PTR es:[di+0x188],0x0
    3779:	06                   	push   es
    377a:	57                   	push   di
    377b:	9a 45 5d f5 37       	call   0x37f5:0x5d45
    3780:	c9                   	leave
    3781:	cb                   	retf
    3782:	0e                   	push   cs
    3783:	49                   	dec    cx
    3784:	6d                   	ins    WORD PTR es:[di],dx
    3785:	70 72                	jo     0x37f9
    3787:	65 73 73             	gs jae 0x37fd
    378a:	69 6f 6e 20 2e       	imul   bp,WORD PTR [bx+0x6e],0x2e20
    378f:	2e 2e 21 44 6f       	cs and WORD PTR cs:[si+0x6f],ax
    3794:	6e                   	outs   dx,BYTE PTR ds:[si]
    3795:	6e                   	outs   dx,BYTE PTR ds:[si]
    3796:	e9 65 73             	jmp    0xaafe
    3799:	20 65 6e             	and    BYTE PTR [di+0x6e],ah
    379c:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
    379f:	75 72                	jne    0x3813
    37a1:	73 20                	jae    0x37c3
    37a3:	64 65 20 6d 6f       	fs and BYTE PTR gs:[di+0x6f],ch
    37a8:	64 69 66 69 63 61    	imul   sp,WORD PTR fs:[bp+0x69],0x6163
    37ae:	74 69                	je     0x3819
    37b0:	6f                   	outs   dx,WORD PTR ds:[si]
    37b1:	6e                   	outs   dx,BYTE PTR ds:[si]
    37b2:	2e 1d 45 6e          	cs sbb ax,0x6e45
    37b6:	72 65                	jb     0x381d
    37b8:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
    37be:	7a 20                	jp     0x37e0
    37c0:	61                   	popa
    37c1:	76 61                	jbe    0x3824
    37c3:	6e                   	outs   dx,BYTE PTR ds:[si]
    37c4:	74 20                	je     0x37e6
    37c6:	64 27                	fs daa
    37c8:	69 6d 70 72 69       	imul   bp,WORD PTR [di+0x70],0x6972
    37cd:	6d                   	ins    WORD PTR es:[di],dx
    37ce:	65 72 2e             	gs jb  0x37ff
    37d1:	55                   	push   bp
    37d2:	89 e5                	mov    bp,sp
    37d4:	b8 08 00             	mov    ax,0x8
    37d7:	9a 44 04 cb 38       	call   0x38cb:0x444
    37dc:	83 ec 08             	sub    sp,0x8
    37df:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    37e3:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    37e7:	b0 01                	mov    al,0x1
    37e9:	50                   	push   ax
    37ea:	b8 93 33             	mov    ax,0x3393
    37ed:	ba 0f 3e             	mov    dx,0x3e0f
    37f0:	52                   	push   dx
    37f1:	50                   	push   ax
    37f2:	9a 53 25 76 38       	call   0x3876:0x2553
    37f7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    37fa:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    37fd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3800:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3803:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3806:	bf 82 37             	mov    di,0x3782
    3809:	0e                   	push   cs
    380a:	57                   	push   di
    380b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    380e:	06                   	push   es
    380f:	57                   	push   di
    3810:	9a 8c 1d ff ff       	call   0xffff:0x1d8c
    3815:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3818:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    381d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3822:	06                   	push   es
    3823:	57                   	push   di
    3824:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3827:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    382b:	bf 91 37             	mov    di,0x3791
    382e:	0e                   	push   cs
    382f:	57                   	push   di
    3830:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3833:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3838:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    383d:	06                   	push   es
    383e:	57                   	push   di
    383f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3842:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3846:	bf b3 37             	mov    di,0x37b3
    3849:	0e                   	push   cs
    384a:	57                   	push   di
    384b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    384e:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3853:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3858:	06                   	push   es
    3859:	57                   	push   di
    385a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    385d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3861:	6a 30                	push   0x30
    3863:	9a 86 39 00 00       	call   0x0:0x3986
    3868:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    386b:	26 c6 85 88 01 01    	mov    BYTE PTR es:[di+0x188],0x1
    3871:	06                   	push   es
    3872:	57                   	push   di
    3873:	9a 45 5d a3 39       	call   0x39a3:0x5d45
    3878:	c9                   	leave
    3879:	cb                   	retf
    387a:	16                   	push   ss
    387b:	45                   	inc    bp
    387c:	72 72                	jb     0x38f0
    387e:	65 75 72             	gs jne 0x38f3
    3881:	20 42 61             	and    BYTE PTR [bp+si+0x61],al
    3884:	73 65                	jae    0x38eb
    3886:	20 64 65             	and    BYTE PTR [si+0x65],ah
    3889:	20 64 6f             	and    BYTE PTR [si+0x6f],ah
    388c:	6e                   	outs   dx,BYTE PTR ds:[si]
    388d:	6e                   	outs   dx,BYTE PTR ds:[si]
    388e:	e9 65 00             	jmp    0x38f6
    3891:	1a 45 6e             	sbb    al,BYTE PTR [di+0x6e]
    3894:	72 65                	jb     0x38fb
    3896:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
    389c:	6d                   	ins    WORD PTR es:[di],dx
    389d:	65 6e                	outs   dx,BYTE PTR gs:[si]
    389f:	74 20                	je     0x38c1
    38a1:	6e                   	outs   dx,BYTE PTR ds:[si]
    38a2:	6f                   	outs   dx,WORD PTR ds:[si]
    38a3:	6e                   	outs   dx,BYTE PTR ds:[si]
    38a4:	20 74 72             	and    BYTE PTR [si+0x72],dh
    38a7:	6f                   	outs   dx,WORD PTR ds:[si]
    38a8:	75 76                	jne    0x3920
    38aa:	e9 2e 01             	jmp    0x39db
    38ad:	0d 11 46             	or     ax,0x4611
    38b0:	65 72 6d             	gs jb  0x3920
    38b3:	65 74 75             	gs je  0x392b
    38b6:	72 65                	jb     0x391d
    38b8:	20 64 75             	and    BYTE PTR [si+0x75],ah
    38bb:	20 4a 65             	and    BYTE PTR [bp+si+0x65],cl
    38be:	75 2e                	jne    0x38ee
    38c0:	01 00                	add    WORD PTR [bx+si],ax
    38c2:	55                   	push   bp
    38c3:	89 e5                	mov    bp,sp
    38c5:	b8 02 03             	mov    ax,0x302
    38c8:	9a 44 04 e2 38       	call   0x38e2:0x444
    38cd:	81 ec 02 03          	sub    sp,0x302
    38d1:	bf 7a 38             	mov    di,0x387a
    38d4:	0e                   	push   cs
    38d5:	57                   	push   di
    38d6:	8d be 00 ff          	lea    di,[bp-0x100]
    38da:	16                   	push   ss
    38db:	57                   	push   di
    38dc:	68 ff 00             	push   0xff
    38df:	9a e7 17 f5 38       	call   0x38f5:0x17e7
    38e4:	bf 91 38             	mov    di,0x3891
    38e7:	0e                   	push   cs
    38e8:	57                   	push   di
    38e9:	8d be 00 fe          	lea    di,[bp-0x200]
    38ed:	16                   	push   ss
    38ee:	57                   	push   di
    38ef:	68 ff 00             	push   0xff
    38f2:	9a e7 17 0c 39       	call   0x390c:0x17e7
    38f7:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    38fb:	74 45                	je     0x3942
    38fd:	8d be fe fc          	lea    di,[bp-0x302]
    3901:	16                   	push   ss
    3902:	57                   	push   di
    3903:	8d be 00 fe          	lea    di,[bp-0x200]
    3907:	16                   	push   ss
    3908:	57                   	push   di
    3909:	9a cd 17 16 39       	call   0x3916:0x17cd
    390e:	bf ac 38             	mov    di,0x38ac
    3911:	0e                   	push   cs
    3912:	57                   	push   di
    3913:	9a 4c 18 20 39       	call   0x3920:0x184c
    3918:	bf ac 38             	mov    di,0x38ac
    391b:	0e                   	push   cs
    391c:	57                   	push   di
    391d:	9a 4c 18 2a 39       	call   0x392a:0x184c
    3922:	bf ae 38             	mov    di,0x38ae
    3925:	0e                   	push   cs
    3926:	57                   	push   di
    3927:	9a 4c 18 38 39       	call   0x3938:0x184c
    392c:	8d be 00 fe          	lea    di,[bp-0x200]
    3930:	16                   	push   ss
    3931:	57                   	push   di
    3932:	68 ff 00             	push   0xff
    3935:	9a e7 17 57 39       	call   0x3957:0x17e7
    393a:	c7 86 fe fd 10 00    	mov    WORD PTR [bp-0x202],0x10
    3940:	eb 06                	jmp    0x3948
    3942:	c7 86 fe fd 30 00    	mov    WORD PTR [bp-0x202],0x30
    3948:	8d be fe fc          	lea    di,[bp-0x302]
    394c:	16                   	push   ss
    394d:	57                   	push   di
    394e:	8d be 00 fe          	lea    di,[bp-0x200]
    3952:	16                   	push   ss
    3953:	57                   	push   di
    3954:	9a cd 17 61 39       	call   0x3961:0x17cd
    3959:	bf c0 38             	mov    di,0x38c0
    395c:	0e                   	push   cs
    395d:	57                   	push   di
    395e:	9a 4c 18 6f 39       	call   0x396f:0x184c
    3963:	8d be 00 fe          	lea    di,[bp-0x200]
    3967:	16                   	push   ss
    3968:	57                   	push   di
    3969:	68 ff 00             	push   0xff
    396c:	9a e7 17 7d 39       	call   0x397d:0x17e7
    3971:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    3975:	05 00 00             	add    ax,0x0
    3978:	73 05                	jae    0x397f
    397a:	9a 3e 04 d3 39       	call   0x39d3:0x43e
    397f:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    3983:	6a 30                	push   0x30
    3985:	9a 02 3a 00 00       	call   0x0:0x3a02
    398a:	8d be 01 fe          	lea    di,[bp-0x1ff]
    398e:	16                   	push   ss
    398f:	57                   	push   di
    3990:	8d be 01 ff          	lea    di,[bp-0xff]
    3994:	16                   	push   ss
    3995:	57                   	push   di
    3996:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    399a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    399e:	06                   	push   es
    399f:	57                   	push   di
    39a0:	9a f9 75 1d 3a       	call   0x3a1d:0x75f9
    39a5:	c9                   	leave
    39a6:	ca 02 00             	retf   0x2
    39a9:	09 43 72             	or     WORD PTR [bp+di+0x72],ax
    39ac:	e9 61 74             	jmp    0xae10
    39af:	69 6f 6e 00 16       	imul   bp,WORD PTR [bx+0x6e],0x1600
    39b4:	56                   	push   si
    39b5:	61                   	popa
    39b6:	6c                   	ins    BYTE PTR es:[di],dx
    39b7:	69 64 65 72 20       	imul   sp,WORD PTR [si+0x65],0x2072
    39bc:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    39bf:	20 64 6f             	and    BYTE PTR [si+0x6f],ah
    39c2:	6e                   	outs   dx,BYTE PTR ds:[si]
    39c3:	6e                   	outs   dx,BYTE PTR ds:[si]
    39c4:	e9 65 73             	jmp    0xad2c
    39c7:	20 3f                	and    BYTE PTR [bx],bh
    39c9:	00 55 89             	add    BYTE PTR [di-0x77],dl
    39cc:	e5 b8                	in     ax,0xb8
    39ce:	02 02                	add    al,BYTE PTR [bp+si]
    39d0:	9a 44 04 ea 39       	call   0x39ea:0x444
    39d5:	81 ec 02 02          	sub    sp,0x202
    39d9:	bf a9 39             	mov    di,0x39a9
    39dc:	0e                   	push   cs
    39dd:	57                   	push   di
    39de:	8d be fe fe          	lea    di,[bp-0x102]
    39e2:	16                   	push   ss
    39e3:	57                   	push   di
    39e4:	68 ff 00             	push   0xff
    39e7:	9a e7 17 fd 39       	call   0x39fd:0x17e7
    39ec:	bf b3 39             	mov    di,0x39b3
    39ef:	0e                   	push   cs
    39f0:	57                   	push   di
    39f1:	8d be fe fd          	lea    di,[bp-0x202]
    39f5:	16                   	push   ss
    39f6:	57                   	push   di
    39f7:	68 ff 00             	push   0xff
    39fa:	9a e7 17 51 3a       	call   0x3a51:0x17e7
    39ff:	6a 20                	push   0x20
    3a01:	9a 80 3a 00 00       	call   0x0:0x3a80
    3a06:	8d be ff fd          	lea    di,[bp-0x201]
    3a0a:	16                   	push   ss
    3a0b:	57                   	push   di
    3a0c:	8d be ff fe          	lea    di,[bp-0x101]
    3a10:	16                   	push   ss
    3a11:	57                   	push   di
    3a12:	6a 23                	push   0x23
    3a14:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3a18:	06                   	push   es
    3a19:	57                   	push   di
    3a1a:	9a f9 75 9b 3a       	call   0x3a9b:0x75f9
    3a1f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3a22:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a25:	c9                   	leave
    3a26:	cb                   	retf
    3a27:	09 43 72             	or     WORD PTR [bp+di+0x72],ax
    3a2a:	e9 61 74             	jmp    0xae8e
    3a2d:	69 6f 6e 00 16       	imul   bp,WORD PTR [bx+0x6e],0x1600
    3a32:	43                   	inc    bx
    3a33:	6f                   	outs   dx,WORD PTR ds:[si]
    3a34:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a35:	66 69 72 6d 65 72 20 	imul   esi,DWORD PTR [bp+si+0x6d],0x6c207265
    3a3c:	6c 
    3a3d:	27                   	daa
    3a3e:	61                   	popa
    3a3f:	62 61 6e             	bound  sp,DWORD PTR [bx+di+0x6e]
    3a42:	64 6f                	outs   dx,WORD PTR fs:[si]
    3a44:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a45:	20 3f                	and    BYTE PTR [bx],bh
    3a47:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3a4a:	e5 b8                	in     ax,0xb8
    3a4c:	02 02                	add    al,BYTE PTR [bp+si]
    3a4e:	9a 44 04 68 3a       	call   0x3a68:0x444
    3a53:	81 ec 02 02          	sub    sp,0x202
    3a57:	bf 27 3a             	mov    di,0x3a27
    3a5a:	0e                   	push   cs
    3a5b:	57                   	push   di
    3a5c:	8d be fe fe          	lea    di,[bp-0x102]
    3a60:	16                   	push   ss
    3a61:	57                   	push   di
    3a62:	68 ff 00             	push   0xff
    3a65:	9a e7 17 7b 3a       	call   0x3a7b:0x17e7
    3a6a:	bf 31 3a             	mov    di,0x3a31
    3a6d:	0e                   	push   cs
    3a6e:	57                   	push   di
    3a6f:	8d be fe fd          	lea    di,[bp-0x202]
    3a73:	16                   	push   ss
    3a74:	57                   	push   di
    3a75:	68 ff 00             	push   0xff
    3a78:	9a e7 17 43 3b       	call   0x3b43:0x17e7
    3a7d:	6a 20                	push   0x20
    3a7f:	9a 72 3b 00 00       	call   0x0:0x3b72
    3a84:	8d be ff fd          	lea    di,[bp-0x201]
    3a88:	16                   	push   ss
    3a89:	57                   	push   di
    3a8a:	8d be ff fe          	lea    di,[bp-0x101]
    3a8e:	16                   	push   ss
    3a8f:	57                   	push   di
    3a90:	6a 24                	push   0x24
    3a92:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3a96:	06                   	push   es
    3a97:	57                   	push   di
    3a98:	9a f9 75 8d 3b       	call   0x3b8d:0x75f9
    3a9d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3aa0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3aa3:	c9                   	leave
    3aa4:	cb                   	retf
    3aa5:	14 44                	adc    al,0x44
    3aa7:	e9 63 69             	jmp    0xa40d
    3aaa:	73 69                	jae    0x3b15
    3aac:	6f                   	outs   dx,WORD PTR ds:[si]
    3aad:	6e                   	outs   dx,BYTE PTR ds:[si]
    3aae:	73 20                	jae    0x3ad0
    3ab0:	41                   	inc    cx
    3ab1:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ab2:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
    3ab7:	75 72                	jne    0x3b2b
    3ab9:	00 7f 4c             	add    BYTE PTR [bx+0x4c],bh
    3abc:	65 73 20             	gs jae 0x3adf
    3abf:	64 e9 63 69          	fs jmp 0xa426
    3ac3:	73 69                	jae    0x3b2e
    3ac5:	6f                   	outs   dx,WORD PTR ds:[si]
    3ac6:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ac7:	73 20                	jae    0x3ae9
    3ac9:	6f                   	outs   dx,WORD PTR ds:[si]
    3aca:	6e                   	outs   dx,BYTE PTR ds:[si]
    3acb:	74 20                	je     0x3aed
    3acd:	e9 74 e9             	jmp    0x2444
    3ad0:	20 6d 6f             	and    BYTE PTR [di+0x6f],ch
    3ad3:	64 69 66 69 e9 65    	imul   sp,WORD PTR fs:[bp+0x69],0x65e9
    3ad9:	73 2c                	jae    0x3b07
    3adb:	0d 6e 65             	or     ax,0x656e
    3ade:	20 73 6f             	and    BYTE PTR [bp+di+0x6f],dh
    3ae1:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ae2:	74 20                	je     0x3b04
    3ae4:	70 61                	jo     0x3b47
    3ae6:	73 20                	jae    0x3b08
    3ae8:	76 e9                	jbe    0x3ad3
    3aea:	72 69                	jb     0x3b55
    3aec:	66 69 e9 65 73 20 6f 	imul   ebp,ecx,0x6f207365
    3af3:	75 20                	jne    0x3b15
    3af5:	6e                   	outs   dx,BYTE PTR ds:[si]
    3af6:	65 20 73 6f          	and    BYTE PTR gs:[bp+di+0x6f],dh
    3afa:	6e                   	outs   dx,BYTE PTR ds:[si]
    3afb:	74 20                	je     0x3b1d
    3afd:	70 61                	jo     0x3b60
    3aff:	73 20                	jae    0x3b21
    3b01:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3b03:	72 65                	jb     0x3b6a
    3b05:	67 69 73 74 72 e9    	imul   si,WORD PTR [ebx+0x74],0xe972
    3b0b:	65 73 2e             	gs jae 0x3b3c
    3b0e:	0d 0d 56             	or     ax,0x560d
    3b11:	e9 72 69             	jmp    0xa486
    3b14:	66 69 65 72 20 65 74 	imul   esp,DWORD PTR [di+0x72],0x20746520
    3b1b:	20 
    3b1c:	45                   	inc    bp
    3b1d:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b1e:	72 65                	jb     0x3b85
    3b20:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
    3b26:	72 20                	jb     0x3b48
    3b28:	61                   	popa
    3b29:	76 61                	jbe    0x3b8c
    3b2b:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b2c:	74 20                	je     0x3b4e
    3b2e:	64 65 20 66 65       	fs and BYTE PTR gs:[bp+0x65],ah
    3b33:	72 6d                	jb     0x3ba2
    3b35:	65 72 20             	gs jb  0x3b58
    3b38:	3f                   	aas
    3b39:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3b3c:	e5 b8                	in     ax,0xb8
    3b3e:	02 02                	add    al,BYTE PTR [bp+si]
    3b40:	9a 44 04 5a 3b       	call   0x3b5a:0x444
    3b45:	81 ec 02 02          	sub    sp,0x202
    3b49:	bf a5 3a             	mov    di,0x3aa5
    3b4c:	0e                   	push   cs
    3b4d:	57                   	push   di
    3b4e:	8d be fe fe          	lea    di,[bp-0x102]
    3b52:	16                   	push   ss
    3b53:	57                   	push   di
    3b54:	68 ff 00             	push   0xff
    3b57:	9a e7 17 6d 3b       	call   0x3b6d:0x17e7
    3b5c:	bf ba 3a             	mov    di,0x3aba
    3b5f:	0e                   	push   cs
    3b60:	57                   	push   di
    3b61:	8d be fe fd          	lea    di,[bp-0x202]
    3b65:	16                   	push   ss
    3b66:	57                   	push   di
    3b67:	68 ff 00             	push   0xff
    3b6a:	9a e7 17 e3 3b       	call   0x3be3:0x17e7
    3b6f:	6a 20                	push   0x20
    3b71:	9a 6a 3c 00 00       	call   0x0:0x3c6a
    3b76:	8d be ff fd          	lea    di,[bp-0x201]
    3b7a:	16                   	push   ss
    3b7b:	57                   	push   di
    3b7c:	8d be ff fe          	lea    di,[bp-0x101]
    3b80:	16                   	push   ss
    3b81:	57                   	push   di
    3b82:	6a 23                	push   0x23
    3b84:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3b88:	06                   	push   es
    3b89:	57                   	push   di
    3b8a:	9a f9 75 85 3c       	call   0x3c85:0x75f9
    3b8f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3b92:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b95:	c9                   	leave
    3b96:	cb                   	retf
    3b97:	14 44                	adc    al,0x44
    3b99:	e9 63 69             	jmp    0xa4ff
    3b9c:	73 69                	jae    0x3c07
    3b9e:	6f                   	outs   dx,WORD PTR ds:[si]
    3b9f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ba0:	73 20                	jae    0x3bc2
    3ba2:	41                   	inc    cx
    3ba3:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ba4:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
    3ba9:	75 72                	jne    0x3c1d
    3bab:	00 16 45 6e          	add    BYTE PTR ds:0x6e45,dl
    3baf:	72 65                	jb     0x3c16
    3bb1:	67 69 73 74 65 72    	imul   si,WORD PTR [ebx+0x74],0x7265
    3bb7:	20 65 6e             	and    BYTE PTR [di+0x6e],ah
    3bba:	20 6c 27             	and    BYTE PTR [si+0x27],ch
    3bbd:	e9 74 61             	jmp    0x9d34
    3bc0:	74 20                	je     0x3be2
    3bc2:	3f                   	aas
    3bc3:	14 20                	adc    al,0x20
    3bc5:	28 53 61             	sub    BYTE PTR [bp+di+0x61],dl
    3bc8:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bc9:	73 20                	jae    0x3beb
    3bcb:	76 e9                	jbe    0x3bb6
    3bcd:	72 69                	jb     0x3c38
    3bcf:	66 69 63 61 74 69 6f 	imul   esp,DWORD PTR [bp+di+0x61],0x6e6f6974
    3bd6:	6e 
    3bd7:	29 01                	sub    WORD PTR [bx+di],ax
    3bd9:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3bdc:	e5 b8                	in     ax,0xb8
    3bde:	02 03                	add    al,BYTE PTR [bp+di]
    3be0:	9a 44 04 fa 3b       	call   0x3bfa:0x444
    3be5:	81 ec 02 03          	sub    sp,0x302
    3be9:	bf 97 3b             	mov    di,0x3b97
    3bec:	0e                   	push   cs
    3bed:	57                   	push   di
    3bee:	8d be fe fd          	lea    di,[bp-0x202]
    3bf2:	16                   	push   ss
    3bf3:	57                   	push   di
    3bf4:	68 ff 00             	push   0xff
    3bf7:	9a e7 17 0d 3c       	call   0x3c0d:0x17e7
    3bfc:	bf ac 3b             	mov    di,0x3bac
    3bff:	0e                   	push   cs
    3c00:	57                   	push   di
    3c01:	8d be fe fe          	lea    di,[bp-0x102]
    3c05:	16                   	push   ss
    3c06:	57                   	push   di
    3c07:	68 ff 00             	push   0xff
    3c0a:	9a e7 17 24 3c       	call   0x3c24:0x17e7
    3c0f:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    3c13:	75 29                	jne    0x3c3e
    3c15:	8d be fe fc          	lea    di,[bp-0x302]
    3c19:	16                   	push   ss
    3c1a:	57                   	push   di
    3c1b:	8d be fe fe          	lea    di,[bp-0x102]
    3c1f:	16                   	push   ss
    3c20:	57                   	push   di
    3c21:	9a cd 17 2e 3c       	call   0x3c2e:0x17cd
    3c26:	bf c3 3b             	mov    di,0x3bc3
    3c29:	0e                   	push   cs
    3c2a:	57                   	push   di
    3c2b:	9a 4c 18 3c 3c       	call   0x3c3c:0x184c
    3c30:	8d be fe fe          	lea    di,[bp-0x102]
    3c34:	16                   	push   ss
    3c35:	57                   	push   di
    3c36:	68 ff 00             	push   0xff
    3c39:	9a e7 17 4d 3c       	call   0x3c4d:0x17e7
    3c3e:	8d be fe fc          	lea    di,[bp-0x302]
    3c42:	16                   	push   ss
    3c43:	57                   	push   di
    3c44:	8d be fe fe          	lea    di,[bp-0x102]
    3c48:	16                   	push   ss
    3c49:	57                   	push   di
    3c4a:	9a cd 17 57 3c       	call   0x3c57:0x17cd
    3c4f:	bf d8 3b             	mov    di,0x3bd8
    3c52:	0e                   	push   cs
    3c53:	57                   	push   di
    3c54:	9a 4c 18 65 3c       	call   0x3c65:0x184c
    3c59:	8d be fe fe          	lea    di,[bp-0x102]
    3c5d:	16                   	push   ss
    3c5e:	57                   	push   di
    3c5f:	68 ff 00             	push   0xff
    3c62:	9a e7 17 31 3d       	call   0x3d31:0x17e7
    3c67:	6a 20                	push   0x20
    3c69:	9a c8 3d 00 00       	call   0x0:0x3dc8
    3c6e:	8d be ff fe          	lea    di,[bp-0x101]
    3c72:	16                   	push   ss
    3c73:	57                   	push   di
    3c74:	8d be ff fd          	lea    di,[bp-0x201]
    3c78:	16                   	push   ss
    3c79:	57                   	push   di
    3c7a:	6a 24                	push   0x24
    3c7c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3c80:	06                   	push   es
    3c81:	57                   	push   di
    3c82:	9a f9 75 e3 3d       	call   0x3de3:0x75f9
    3c87:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c8a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3c8d:	c9                   	leave
    3c8e:	ca 02 00             	retf   0x2
    3c91:	1a 44 e9             	sbb    al,BYTE PTR [si-0x17]
    3c94:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
    3c97:	69 6f 6e 73 20       	imul   bp,WORD PTR [bx+0x6e],0x2073
    3c9c:	64 65 20 6c 27       	fs and BYTE PTR gs:[si+0x27],ch
    3ca1:	45                   	inc    bp
    3ca2:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ca3:	74 72                	je     0x3d17
    3ca5:	65 70 72             	gs jo  0x3d1a
    3ca8:	69 73 65 20 01       	imul   si,WORD PTR [bp+di+0x65],0x120
    3cad:	00 76 4c             	add    BYTE PTR [bp+0x4c],dh
    3cb0:	65 73 20             	gs jae 0x3cd3
    3cb3:	64 e9 63 69          	fs jmp 0xa61a
    3cb7:	73 69                	jae    0x3d22
    3cb9:	6f                   	outs   dx,WORD PTR ds:[si]
    3cba:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cbb:	73 20                	jae    0x3cdd
    3cbd:	6f                   	outs   dx,WORD PTR ds:[si]
    3cbe:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cbf:	74 20                	je     0x3ce1
    3cc1:	e9 74 e9             	jmp    0x2638
    3cc4:	20 6d 6f             	and    BYTE PTR [di+0x6f],ch
    3cc7:	64 69 66 69 e9 65    	imul   sp,WORD PTR fs:[bp+0x69],0x65e9
    3ccd:	73 2c                	jae    0x3cfb
    3ccf:	0d 6e 65             	or     ax,0x656e
    3cd2:	20 73 6f             	and    BYTE PTR [bp+di+0x6f],dh
    3cd5:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cd6:	74 20                	je     0x3cf8
    3cd8:	70 61                	jo     0x3d3b
    3cda:	73 20                	jae    0x3cfc
    3cdc:	76 e9                	jbe    0x3cc7
    3cde:	72 69                	jb     0x3d49
    3ce0:	66 69 e9 65 73 20 6f 	imul   ebp,ecx,0x6f207365
    3ce7:	75 20                	jne    0x3d09
    3ce9:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cea:	65 20 73 6f          	and    BYTE PTR gs:[bp+di+0x6f],dh
    3cee:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cef:	74 20                	je     0x3d11
    3cf1:	70 61                	jo     0x3d54
    3cf3:	73 20                	jae    0x3d15
    3cf5:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3cf7:	72 65                	jb     0x3d5e
    3cf9:	67 69 73 74 72 e9    	imul   si,WORD PTR [ebx+0x74],0xe972
    3cff:	65 73 2e             	gs jae 0x3d30
    3d02:	0d 0d 56             	or     ax,0x560d
    3d05:	e9 72 69             	jmp    0xa67a
    3d08:	66 69 65 72 20 65 74 	imul   esp,DWORD PTR [di+0x72],0x20746520
    3d0f:	20 
    3d10:	45                   	inc    bp
    3d11:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d12:	72 65                	jb     0x3d79
    3d14:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
    3d1a:	72 20                	jb     0x3d3c
    3d1c:	61                   	popa
    3d1d:	76 61                	jbe    0x3d80
    3d1f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d20:	74 20                	je     0x3d42
    3d22:	64 65 20 02          	fs and BYTE PTR gs:[bp+si],al
    3d26:	20 3f                	and    BYTE PTR [bx],bh
    3d28:	55                   	push   bp
    3d29:	89 e5                	mov    bp,sp
    3d2b:	b8 02 04             	mov    ax,0x402
    3d2e:	9a 44 04 45 3d       	call   0x3d45:0x444
    3d33:	81 ec 02 04          	sub    sp,0x402
    3d37:	8d be fe fb          	lea    di,[bp-0x402]
    3d3b:	16                   	push   ss
    3d3c:	57                   	push   di
    3d3d:	bf 91 3c             	mov    di,0x3c91
    3d40:	0e                   	push   cs
    3d41:	57                   	push   di
    3d42:	9a cd 17 5b 3d       	call   0x3d5b:0x17cd
    3d47:	8d be fe fc          	lea    di,[bp-0x302]
    3d4b:	16                   	push   ss
    3d4c:	57                   	push   di
    3d4d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3d50:	99                   	cwd
    3d51:	52                   	push   dx
    3d52:	50                   	push   ax
    3d53:	9a a9 08 bf 3e       	call   0x3ebf:0x8a9
    3d58:	9a 4c 18 65 3d       	call   0x3d65:0x184c
    3d5d:	bf ac 3c             	mov    di,0x3cac
    3d60:	0e                   	push   cs
    3d61:	57                   	push   di
    3d62:	9a 4c 18 73 3d       	call   0x3d73:0x184c
    3d67:	8d be fe fe          	lea    di,[bp-0x102]
    3d6b:	16                   	push   ss
    3d6c:	57                   	push   di
    3d6d:	68 ff 00             	push   0xff
    3d70:	9a e7 17 86 3d       	call   0x3d86:0x17e7
    3d75:	bf ae 3c             	mov    di,0x3cae
    3d78:	0e                   	push   cs
    3d79:	57                   	push   di
    3d7a:	8d be fe fd          	lea    di,[bp-0x202]
    3d7e:	16                   	push   ss
    3d7f:	57                   	push   di
    3d80:	68 ff 00             	push   0xff
    3d83:	9a e7 17 97 3d       	call   0x3d97:0x17e7
    3d88:	8d be fe fc          	lea    di,[bp-0x302]
    3d8c:	16                   	push   ss
    3d8d:	57                   	push   di
    3d8e:	8d be fe fd          	lea    di,[bp-0x202]
    3d92:	16                   	push   ss
    3d93:	57                   	push   di
    3d94:	9a cd 17 a1 3d       	call   0x3da1:0x17cd
    3d99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d9c:	06                   	push   es
    3d9d:	57                   	push   di
    3d9e:	9a 4c 18 ab 3d       	call   0x3dab:0x184c
    3da3:	bf 25 3d             	mov    di,0x3d25
    3da6:	0e                   	push   cs
    3da7:	57                   	push   di
    3da8:	9a 4c 18 b5 3d       	call   0x3db5:0x184c
    3dad:	bf ac 3c             	mov    di,0x3cac
    3db0:	0e                   	push   cs
    3db1:	57                   	push   di
    3db2:	9a 4c 18 c3 3d       	call   0x3dc3:0x184c
    3db7:	8d be fe fd          	lea    di,[bp-0x202]
    3dbb:	16                   	push   ss
    3dbc:	57                   	push   di
    3dbd:	68 ff 00             	push   0xff
    3dc0:	9a e7 17 ff 3d       	call   0x3dff:0x17e7
    3dc5:	6a 20                	push   0x20
    3dc7:	9a 4c 3f 00 00       	call   0x0:0x3f4c
    3dcc:	8d be ff fd          	lea    di,[bp-0x201]
    3dd0:	16                   	push   ss
    3dd1:	57                   	push   di
    3dd2:	8d be ff fe          	lea    di,[bp-0x101]
    3dd6:	16                   	push   ss
    3dd7:	57                   	push   di
    3dd8:	6a 23                	push   0x23
    3dda:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3dde:	06                   	push   es
    3ddf:	57                   	push   di
    3de0:	9a f9 75 67 3f       	call   0x3f67:0x75f9
    3de5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3de8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3deb:	c9                   	leave
    3dec:	ca 06 00             	retf   0x6
    3def:	06                   	push   es
    3df0:	66 65 72 6d          	data32 gs jb 0x3e61
    3df4:	65 72 55             	gs jb  0x3e4c
    3df7:	89 e5                	mov    bp,sp
    3df9:	b8 02 00             	mov    ax,0x2
    3dfc:	9a 44 04 2c 3e       	call   0x3e2c:0x444
    3e01:	83 ec 02             	sub    sp,0x2
    3e04:	ff 76 06             	push   WORD PTR [bp+0x6]
    3e07:	bf ef 3d             	mov    di,0x3def
    3e0a:	0e                   	push   cs
    3e0b:	57                   	push   di
    3e0c:	9a 28 3d 3c 3e       	call   0x3e3c:0x3d28
    3e11:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3e14:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3e17:	c9                   	leave
    3e18:	ca 02 00             	retf   0x2
    3e1b:	07                   	pop    es
    3e1c:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    3e1f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e20:	67 65 72 55          	addr32 gs jb 0x3e79
    3e24:	89 e5                	mov    bp,sp
    3e26:	b8 02 00             	mov    ax,0x2
    3e29:	9a 44 04 9a 3e       	call   0x3e9a:0x444
    3e2e:	83 ec 02             	sub    sp,0x2
    3e31:	ff 76 06             	push   WORD PTR [bp+0x6]
    3e34:	bf 1b 3e             	mov    di,0x3e1b
    3e37:	0e                   	push   cs
    3e38:	57                   	push   di
    3e39:	9a 28 3d ff ff       	call   0xffff:0x3d28
    3e3e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3e41:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3e44:	c9                   	leave
    3e45:	ca 02 00             	retf   0x2
    3e48:	1a 44 e9             	sbb    al,BYTE PTR [si-0x17]
    3e4b:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
    3e4e:	69 6f 6e 73 20       	imul   bp,WORD PTR [bx+0x6e],0x2073
    3e53:	64 65 20 6c 27       	fs and BYTE PTR gs:[si+0x27],ch
    3e58:	45                   	inc    bp
    3e59:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e5a:	74 72                	je     0x3ece
    3e5c:	65 70 72             	gs jo  0x3ed1
    3e5f:	69 73 65 20 01       	imul   si,WORD PTR [bp+di+0x65],0x120
    3e64:	00 16 45 6e          	add    BYTE PTR ds:0x6e45,dl
    3e68:	72 65                	jb     0x3ecf
    3e6a:	67 69 73 74 65 72    	imul   si,WORD PTR [ebx+0x74],0x7265
    3e70:	20 65 6e             	and    BYTE PTR [di+0x6e],ah
    3e73:	20 6c 27             	and    BYTE PTR [si+0x27],ch
    3e76:	e9 74 61             	jmp    0x9fed
    3e79:	74 20                	je     0x3e9b
    3e7b:	3f                   	aas
    3e7c:	14 20                	adc    al,0x20
    3e7e:	28 53 61             	sub    BYTE PTR [bp+di+0x61],dl
    3e81:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e82:	73 20                	jae    0x3ea4
    3e84:	76 e9                	jbe    0x3e6f
    3e86:	72 69                	jb     0x3ef1
    3e88:	66 69 63 61 74 69 6f 	imul   esp,DWORD PTR [bp+di+0x61],0x6e6f6974
    3e8f:	6e 
    3e90:	29 55 89             	sub    WORD PTR [di-0x77],dx
    3e93:	e5 b8                	in     ax,0xb8
    3e95:	02 04                	add    al,BYTE PTR [si]
    3e97:	9a 44 04 ae 3e       	call   0x3eae:0x444
    3e9c:	81 ec 02 04          	sub    sp,0x402
    3ea0:	8d be fe fb          	lea    di,[bp-0x402]
    3ea4:	16                   	push   ss
    3ea5:	57                   	push   di
    3ea6:	bf 48 3e             	mov    di,0x3e48
    3ea9:	0e                   	push   cs
    3eaa:	57                   	push   di
    3eab:	9a cd 17 c4 3e       	call   0x3ec4:0x17cd
    3eb0:	8d be fe fc          	lea    di,[bp-0x302]
    3eb4:	16                   	push   ss
    3eb5:	57                   	push   di
    3eb6:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    3eb9:	99                   	cwd
    3eba:	52                   	push   dx
    3ebb:	50                   	push   ax
    3ebc:	9a a9 08 ff ff       	call   0xffff:0x8a9
    3ec1:	9a 4c 18 ce 3e       	call   0x3ece:0x184c
    3ec6:	bf 63 3e             	mov    di,0x3e63
    3ec9:	0e                   	push   cs
    3eca:	57                   	push   di
    3ecb:	9a 4c 18 dc 3e       	call   0x3edc:0x184c
    3ed0:	8d be fe fe          	lea    di,[bp-0x102]
    3ed4:	16                   	push   ss
    3ed5:	57                   	push   di
    3ed6:	68 ff 00             	push   0xff
    3ed9:	9a e7 17 ef 3e       	call   0x3eef:0x17e7
    3ede:	bf 65 3e             	mov    di,0x3e65
    3ee1:	0e                   	push   cs
    3ee2:	57                   	push   di
    3ee3:	8d be fe fd          	lea    di,[bp-0x202]
    3ee7:	16                   	push   ss
    3ee8:	57                   	push   di
    3ee9:	68 ff 00             	push   0xff
    3eec:	9a e7 17 06 3f       	call   0x3f06:0x17e7
    3ef1:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    3ef5:	75 29                	jne    0x3f20
    3ef7:	8d be fe fc          	lea    di,[bp-0x302]
    3efb:	16                   	push   ss
    3efc:	57                   	push   di
    3efd:	8d be fe fd          	lea    di,[bp-0x202]
    3f01:	16                   	push   ss
    3f02:	57                   	push   di
    3f03:	9a cd 17 10 3f       	call   0x3f10:0x17cd
    3f08:	bf 7c 3e             	mov    di,0x3e7c
    3f0b:	0e                   	push   cs
    3f0c:	57                   	push   di
    3f0d:	9a 4c 18 1e 3f       	call   0x3f1e:0x184c
    3f12:	8d be fe fd          	lea    di,[bp-0x202]
    3f16:	16                   	push   ss
    3f17:	57                   	push   di
    3f18:	68 ff 00             	push   0xff
    3f1b:	9a e7 17 2f 3f       	call   0x3f2f:0x17e7
    3f20:	8d be fe fc          	lea    di,[bp-0x302]
    3f24:	16                   	push   ss
    3f25:	57                   	push   di
    3f26:	8d be fe fd          	lea    di,[bp-0x202]
    3f2a:	16                   	push   ss
    3f2b:	57                   	push   di
    3f2c:	9a cd 17 39 3f       	call   0x3f39:0x17cd
    3f31:	bf 63 3e             	mov    di,0x3e63
    3f34:	0e                   	push   cs
    3f35:	57                   	push   di
    3f36:	9a 4c 18 47 3f       	call   0x3f47:0x184c
    3f3b:	8d be fe fd          	lea    di,[bp-0x202]
    3f3f:	16                   	push   ss
    3f40:	57                   	push   di
    3f41:	68 ff 00             	push   0xff
    3f44:	9a e7 17 ff ff       	call   0xffff:0x17e7
    3f49:	6a 20                	push   0x20
    3f4b:	9a ff ff 00 00       	call   0x0:0xffff
    3f50:	8d be ff fd          	lea    di,[bp-0x201]
    3f54:	16                   	push   ss
    3f55:	57                   	push   di
    3f56:	8d be ff fe          	lea    di,[bp-0x101]
    3f5a:	16                   	push   ss
    3f5b:	57                   	push   di
    3f5c:	6a 24                	push   0x24
    3f5e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3f62:	06                   	push   es
    3f63:	57                   	push   di
    3f64:	9a f9 75 ff ff       	call   0xffff:0x75f9
    3f69:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f6c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f6f:	c9                   	leave
    3f70:	ca                   	.byte 0xca
    3f71:	04                   	.byte 0x4
