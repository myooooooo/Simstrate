; ================================================================
; seg36_CODE  (13616 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	24 00                	and    al,0x0
       2:	03 0a                	add    cx,WORD PTR [bp+si]
       4:	54                   	push   sp
       5:	53                   	push   bx
       6:	68 61 70             	push   0x7061
       9:	65 54                	gs push sp
       b:	79 70                	jns    0x7d
       d:	65 00 00             	add    BYTE PTR gs:[bx+si],al
      10:	00 00                	add    BYTE PTR [bx+si],al
      12:	00 05                	add    BYTE PTR [di],al
      14:	00 00                	add    BYTE PTR [bx+si],al
      16:	00 02                	add    BYTE PTR [bp+si],al
      18:	00 d3                	add    bl,dl
      1a:	00 0b                	add    BYTE PTR [bp+di],cl
      1c:	73 74                	jae    0x92
      1e:	52                   	push   dx
      1f:	65 63 74 61          	arpl   WORD PTR gs:[si+0x61],si
      23:	6e                   	outs   dx,BYTE PTR ds:[si]
      24:	67 6c                	ins    BYTE PTR es:[edi],dx
      26:	65 08 73 74          	or     BYTE PTR gs:[bp+di+0x74],dh
      2a:	53                   	push   bx
      2b:	71 75                	jno    0xa2
      2d:	61                   	popa
      2e:	72 65                	jb     0x95
      30:	0b 73 74             	or     si,WORD PTR [bp+di+0x74]
      33:	52                   	push   dx
      34:	6f                   	outs   dx,WORD PTR ds:[si]
      35:	75 6e                	jne    0xa5
      37:	64 52                	fs push dx
      39:	65 63 74 0d          	arpl   WORD PTR gs:[si+0xd],si
      3d:	73 74                	jae    0xb3
      3f:	52                   	push   dx
      40:	6f                   	outs   dx,WORD PTR ds:[si]
      41:	75 6e                	jne    0xb1
      43:	64 53                	fs push bx
      45:	71 75                	jno    0xbc
      47:	61                   	popa
      48:	72 65                	jb     0xaf
      4a:	09 73 74             	or     WORD PTR [bp+di+0x74],si
      4d:	45                   	inc    bp
      4e:	6c                   	ins    BYTE PTR es:[di],dx
      4f:	6c                   	ins    BYTE PTR es:[di],dx
      50:	69 70 73 65 08       	imul   si,WORD PTR [bx+si+0x73],0x865
      55:	73 74                	jae    0xcb
      57:	43                   	inc    bx
      58:	69 72 63 6c 65       	imul   si,WORD PTR [bp+si+0x63],0x656c
      5d:	ef                   	out    dx,ax
      5e:	00 00                	add    BYTE PTR [bx+si],al
      60:	00 dc                	add    ah,bl
      62:	00 00                	add    BYTE PTR [bx+si],al
      64:	00 d5                	add    ch,dl
      66:	00 98 00 3d          	add    BYTE PTR [bx+si+0x3d00],bl
      6a:	08 fd                	or     ch,bh
      6c:	00 10                	add    BYTE PTR [bx+si],dl
      6e:	26 83 00 9a          	add    WORD PTR es:[bx+si],0xff9a
      72:	1f                   	pop    ds
      73:	70 01                	jo     0x76
      75:	cb                   	retf
      76:	1f                   	pop    ds
      77:	73 00                	jae    0x79
      79:	fb                   	sti
      7a:	19 e0                	sbb    ax,sp
      7c:	00 cd                	add    ch,cl
      7e:	11 87 00 3a          	adc    WORD PTR [bx+0x3a00],ax
      82:	27                   	daa
      83:	af                   	scas   ax,WORD PTR es:[di]
      84:	00 fa                	add    dl,bh
      86:	10 34                	adc    BYTE PTR [si],dh
      88:	03 d6                	add    dx,si
      8a:	14 93                	adc    al,0x93
      8c:	00 f4                	add    ah,dh
      8e:	4f                   	dec    di
      8f:	9f                   	lahf
      90:	00 32                	add    BYTE PTR [bp+si],dh
      92:	16                   	push   ss
      93:	97                   	xchg   di,ax
      94:	00 98 15 bb          	add    BYTE PTR [bx+si-0x44eb],bl
      98:	00 51 1b             	add    BYTE PTR [bx+di+0x1b],dl
      9b:	bf 00 38             	mov    di,0x3800
      9e:	50                   	push   ax
      9f:	a3 00 1a             	mov    ds:0x1a00,ax
      a2:	50                   	push   ax
      a3:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
      a4:	00 21                	add    BYTE PTR [bx+di],ah
      a6:	50                   	push   ax
      a7:	7f 00                	jg     0xa9
      a9:	34 19                	xor    al,0x19
      ab:	7b 00                	jnp    0xad
      ad:	3f                   	aas
      ae:	19 b3 00 78          	sbb    WORD PTR [bp+di+0x7800],si
      b2:	18 b7 00 02          	sbb    BYTE PTR [bx+0x200],dh
      b6:	21 8b 00 3a          	and    WORD PTR [bp+di+0x3a00],cx
      ba:	1c 9b                	sbb    al,0x9b
      bc:	00 15                	add    BYTE PTR [di],dl
      be:	25 c3 00             	and    ax,0xc3
      c1:	37                   	aaa
      c2:	22 c7                	and    al,bh
      c4:	00 df                	add    bh,bl
      c6:	22 cb                	and    cl,bl
      c8:	00 f8                	add    al,bh
      ca:	16                   	push   ss
      cb:	cf                   	iret
      cc:	00 a5 22 6b          	add    BYTE PTR [di+0x6b22],ah
      d0:	00 44 1a             	add    BYTE PTR [si+0x1a],al
      d3:	ab                   	stos   WORD PTR es:[di],ax
      d4:	00 06 54 53          	add    BYTE PTR ds:0x5354,al
      d8:	68 61 70             	push   0x7061
      db:	65 01 00             	add    WORD PTR gs:[bx+si],ax
      de:	bb 1b f9             	mov    bx,0xf91b
      e1:	00 0c                	add    BYTE PTR [si],cl
      e3:	53                   	push   bx
      e4:	74 79                	je     0x15f
      e6:	6c                   	ins    BYTE PTR es:[di],dx
      e7:	65 43                	gs inc bx
      e9:	68 61 6e             	push   0x6e61
      ec:	67 65 64 07          	addr32 gs fs pop es
      f0:	06                   	push   es
      f1:	54                   	push   sp
      f2:	53                   	push   bx
      f3:	68 61 70             	push   0x7061
      f6:	65 7d 00             	gs jge 0xf9
      f9:	16                   	push   ss
      fa:	01 ad 08 2c          	add    WORD PTR [di+0x2c08],bp
      fe:	01 17                	add    WORD PTR [bx],dx
     100:	00 08                	add    BYTE PTR [bx+si],cl
     102:	45                   	inc    bp
     103:	78 74                	js     0x179
     105:	43                   	inc    bx
     106:	74 72                	je     0x17a
     108:	6c                   	ins    BYTE PTR es:[di],dx
     109:	73 0f                	jae    0x11a
     10b:	00 e7                	add    bh,ah
     10d:	04 b7                	add    al,0xb7
     10f:	01 94 00 ff          	add    WORD PTR [si-0x100],dx
     113:	ff ce                	dec    si
     115:	1b bf 01 01          	sbb    di,WORD PTR [bx+0x101]
     119:	00 00                	add    BYTE PTR [bx+si],al
     11b:	00 00                	add    BYTE PTR [bx+si],al
     11d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     120:	00 80 08 00          	add    BYTE PTR [bx+si+0x8],al
     124:	05 42 72             	add    ax,0x7242
     127:	75 73                	jne    0x19c
     129:	68 64 00             	push   0x64
     12c:	4f                   	dec    di
     12d:	01 3e 00 ff          	add    WORD PTR ds:0xff00,di
     131:	ff                   	(bad)
     132:	3e 00 ff             	ds add bh,bh
     135:	ff 01                	inc    WORD PTR [bx+di]
     137:	00 00                	add    BYTE PTR [bx+si],al
     139:	00 00                	add    BYTE PTR [bx+si],al
     13b:	80 f4 ff             	xor    ah,0xff
     13e:	ff                   	(bad)
     13f:	ff 09                	dec    WORD PTR [bx+di]
     141:	00 0a                	add    BYTE PTR [bp+si],cl
     143:	44                   	inc    sp
     144:	72 61                	jb     0x1a7
     146:	67 43                	addr32 inc bx
     148:	75 72                	jne    0x1bc
     14a:	73 6f                	jae    0x1bb
     14c:	72 25                	jb     0x173
     14e:	01 78 01             	add    WORD PTR [bx+si+0x1],di
     151:	2e 00 ff             	cs add bh,bh
     154:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     158:	ff 01                	inc    WORD PTR [bx+di]
     15a:	00 00                	add    BYTE PTR [bx+si],al
     15c:	00 00                	add    BYTE PTR [bx+si],al
     15e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     161:	00 00                	add    BYTE PTR [bx+si],al
     163:	0a 00                	or     al,BYTE PTR [bx+si]
     165:	08 44 72             	or     BYTE PTR [si+0x72],al
     168:	61                   	popa
     169:	67 4d                	addr32 dec bp
     16b:	6f                   	outs   dx,WORD PTR ds:[si]
     16c:	64 65 07             	fs gs pop es
     16f:	23 90 01 2a          	and    dx,WORD PTR [bx+si+0x2a01]
     173:	00 ff                	add    bh,bh
     175:	ff                   	(bad)
     176:	b8 1c 98             	mov    ax,0x981c
     179:	01 01                	add    WORD PTR [bx+di],ax
     17b:	00 00                	add    BYTE PTR [bx+si],al
     17d:	00 00                	add    BYTE PTR [bx+si],al
     17f:	80 01 00             	add    BYTE PTR [bx+di],0x0
     182:	00 00                	add    BYTE PTR [bx+si],al
     184:	0b 00                	or     ax,WORD PTR [bx+si]
     186:	07                   	pop    es
     187:	45                   	inc    bp
     188:	6e                   	outs   dx,BYTE PTR ds:[si]
     189:	61                   	popa
     18a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     18d:	64 07                	fs pop es
     18f:	23 f1                	and    si,cx
     191:	01 49 00             	add    WORD PTR [bx+di+0x0],cx
     194:	ff                   	(bad)
     195:	ff a1 1e f9          	jmp    WORD PTR [bx+di-0x6e2]
     199:	01 01                	add    WORD PTR [bx+di],ax
     19b:	00 00                	add    BYTE PTR [bx+si],al
     19d:	00 00                	add    BYTE PTR [bx+si],al
     19f:	80 01 00             	add    BYTE PTR [bx+di],0x0
     1a2:	00 00                	add    BYTE PTR [bx+si],al
     1a4:	0c 00                	or     al,0x0
     1a6:	0e                   	push   cs
     1a7:	50                   	push   ax
     1a8:	61                   	popa
     1a9:	72 65                	jb     0x210
     1ab:	6e                   	outs   dx,BYTE PTR ds:[si]
     1ac:	74 53                	je     0x201
     1ae:	68 6f 77             	push   0x776f
     1b1:	48                   	dec    ax
     1b2:	69 6e 74 22 04       	imul   bp,WORD PTR [bp+0x74],0x422
     1b7:	c4 03                	les    ax,DWORD PTR [bp+di]
     1b9:	90                   	nop
     1ba:	00 ff                	add    bh,bh
     1bc:	ff                   	jmp    (bad)
     1bd:	ec                   	in     al,dx
     1be:	1b d3                	sbb    dx,bx
     1c0:	01 01                	add    WORD PTR [bx+di],ax
     1c2:	00 00                	add    BYTE PTR [bx+si],al
     1c4:	00 00                	add    BYTE PTR [bx+si],al
     1c6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1c9:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     1cd:	03 50 65             	add    dx,WORD PTR [bx+si+0x65]
     1d0:	6e                   	outs   dx,BYTE PTR ds:[si]
     1d1:	02 00                	add    al,BYTE PTR [bx+si]
     1d3:	db 01                	fild   DWORD PTR [bx+di]
     1d5:	8e 00                	mov    es,WORD PTR [bx+si]
     1d7:	ff                   	(bad)
     1d8:	ff 0a                	dec    WORD PTR [bp+si]
     1da:	1c 78                	sbb    al,0x78
     1dc:	03 01                	add    ax,WORD PTR [bx+di]
     1de:	00 00                	add    BYTE PTR [bx+si],al
     1e0:	00 00                	add    BYTE PTR [bx+si],al
     1e2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1e5:	00 00                	add    BYTE PTR [bx+si],al
     1e7:	0e                   	push   cs
     1e8:	00 05                	add    BYTE PTR [di],al
     1ea:	53                   	push   bx
     1eb:	68 61 70             	push   0x7061
     1ee:	65 07                	gs pop es
     1f0:	23 12                	and    dx,WORD PTR [bp+si]
     1f2:	02 48 00             	add    cl,BYTE PTR [bx+si+0x0]
     1f5:	ff                   	(bad)
     1f6:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     1f9:	fd                   	std
     1fa:	01 23                	add    WORD PTR [bp+di],sp
     1fc:	1e                   	push   ds
     1fd:	1a 02                	sbb    al,BYTE PTR [bp+si]
     1ff:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     203:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     207:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     20a:	6f                   	outs   dx,WORD PTR ds:[si]
     20b:	77 48                	ja     0x255
     20d:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     212:	1c 03                	sbb    al,0x3
     214:	29 00                	sub    WORD PTR [bx+si],ax
     216:	ff                   	(bad)
     217:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     21a:	32 02                	xor    al,BYTE PTR [bp+si]
     21c:	01 00                	add    WORD PTR [bx+si],ax
     21e:	00 00                	add    BYTE PTR [bx+si],al
     220:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     224:	00 00                	add    BYTE PTR [bx+si],al
     226:	10 00                	adc    BYTE PTR [bx+si],al
     228:	07                   	pop    es
     229:	56                   	push   si
     22a:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     22f:	65 ea 02 55 02 62    	gs jmp 0x6202:0x5502
     235:	00 ff                	add    bh,bh
     237:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     23a:	ff                   	(bad)
     23b:	ff 01                	inc    WORD PTR [bx+di]
     23d:	00 00                	add    BYTE PTR [bx+si],al
     23f:	00 00                	add    BYTE PTR [bx+si],al
     241:	80 00 00             	add    BYTE PTR [bx+si],0x0
     244:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     248:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     24b:	44                   	inc    sp
     24c:	72 61                	jb     0x2af
     24e:	67 44                	addr32 inc sp
     250:	72 6f                	jb     0x2c1
     252:	70 80                	jo     0x1d4
     254:	02 78 02             	add    bh,BYTE PTR [bx+si+0x2]
     257:	6a 00                	push   0x0
     259:	ff                   	(bad)
     25a:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     25d:	ff                   	(bad)
     25e:	ff 01                	inc    WORD PTR [bx+di]
     260:	00 00                	add    BYTE PTR [bx+si],al
     262:	00 00                	add    BYTE PTR [bx+si],al
     264:	80 00 00             	add    BYTE PTR [bx+si],0x0
     267:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     26b:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     26e:	44                   	inc    sp
     26f:	72 61                	jb     0x2d2
     271:	67 4f                	addr32 dec di
     273:	76 65                	jbe    0x2da
     275:	72 32                	jb     0x2a9
     277:	03 9a 02 72          	add    bx,WORD PTR [bp+si+0x7202]
     27b:	00 ff                	add    bh,bh
     27d:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     280:	ff                   	(bad)
     281:	ff 01                	inc    WORD PTR [bx+di]
     283:	00 00                	add    BYTE PTR [bx+si],al
     285:	00 00                	add    BYTE PTR [bx+si],al
     287:	80 00 00             	add    BYTE PTR [bx+si],0x0
     28a:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     28e:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     291:	45                   	inc    bp
     292:	6e                   	outs   dx,BYTE PTR ds:[si]
     293:	64 44                	fs inc sp
     295:	72 61                	jb     0x2f8
     297:	67 71 01             	addr32 jno 0x29b
     29a:	be 02 4a             	mov    si,0x4a02
     29d:	00 ff                	add    bh,bh
     29f:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     2a2:	ff                   	(bad)
     2a3:	ff 01                	inc    WORD PTR [bx+di]
     2a5:	00 00                	add    BYTE PTR [bx+si],al
     2a7:	00 00                	add    BYTE PTR [bx+si],al
     2a9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2ac:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     2b0:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     2b3:	4d                   	dec    bp
     2b4:	6f                   	outs   dx,WORD PTR ds:[si]
     2b5:	75 73                	jne    0x32a
     2b7:	65 44                	gs inc sp
     2b9:	6f                   	outs   dx,WORD PTR ds:[si]
     2ba:	77 6e                	ja     0x32a
     2bc:	ce                   	into
     2bd:	01 e2                	add    dx,sp
     2bf:	02 52 00             	add    dl,BYTE PTR [bp+si+0x0]
     2c2:	ff                   	(bad)
     2c3:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     2c6:	ff                   	(bad)
     2c7:	ff 01                	inc    WORD PTR [bx+di]
     2c9:	00 00                	add    BYTE PTR [bx+si],al
     2cb:	00 00                	add    BYTE PTR [bx+si],al
     2cd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2d0:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     2d4:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     2d7:	4d                   	dec    bp
     2d8:	6f                   	outs   dx,WORD PTR ds:[si]
     2d9:	75 73                	jne    0x34e
     2db:	65 4d                	gs dec bp
     2dd:	6f                   	outs   dx,WORD PTR ds:[si]
     2de:	76 65                	jbe    0x345
     2e0:	71 01                	jno    0x2e3
     2e2:	20 03                	and    BYTE PTR [bp+di],al
     2e4:	5a                   	pop    dx
     2e5:	00 ff                	add    bh,bh
     2e7:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     2ea:	ff                   	(bad)
     2eb:	ff 01                	inc    WORD PTR [bx+di]
     2ed:	00 00                	add    BYTE PTR [bx+si],al
     2ef:	00 00                	add    BYTE PTR [bx+si],al
     2f1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2f4:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     2f8:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     2fb:	4d                   	dec    bp
     2fc:	6f                   	outs   dx,WORD PTR ds:[si]
     2fd:	75 73                	jne    0x372
     2ff:	65 55                	gs push bp
     301:	70 84                	jo     0x287
     303:	03 00                	add    ax,WORD PTR [bx+si]
     305:	00 00                	add    BYTE PTR [bx+si],al
     307:	00 00                	add    BYTE PTR [bx+si],al
     309:	00 7a 03             	add    BYTE PTR [bp+si+0x3],bh
     30c:	96                   	xchg   si,ax
     30d:	00 3d                	add    BYTE PTR [di],bh
     30f:	08 95 03 10          	or     BYTE PTR [di+0x1003],dl
     313:	26 28 03             	sub    BYTE PTR es:[bp+di],al
     316:	9a 1f 26 04 cb       	call   0xcb04:0x261f
     31b:	1f                   	pop    ds
     31c:	18 03                	sbb    BYTE PTR [bp+di],al
     31e:	f0 68 14 03          	lock push 0x314
     322:	cd 11                	int    0x11
     324:	2c 03                	sub    al,0x3
     326:	3a 27                	cmp    ah,BYTE PTR [bx]
     328:	54                   	push   sp
     329:	03 fa                	add    di,dx
     32b:	10 34                	adc    BYTE PTR [si],dh
     32d:	05 d6 14             	add    ax,0x14d6
     330:	38 03                	cmp    BYTE PTR [bp+di],al
     332:	f4                   	hlt
     333:	4f                   	dec    di
     334:	44                   	inc    sp
     335:	03 32                	add    si,WORD PTR [bp+si]
     337:	16                   	push   ss
     338:	3c 03                	cmp    al,0x3
     33a:	98                   	cbw
     33b:	15 60 03             	adc    ax,0x360
     33e:	51                   	push   cx
     33f:	1b 64 03             	sbb    sp,WORD PTR [si+0x3]
     342:	38 50 48             	cmp    BYTE PTR [bx+si+0x48],dl
     345:	03 1a                	add    bx,WORD PTR [bp+si]
     347:	50                   	push   ax
     348:	4c                   	dec    sp
     349:	03 21                	add    sp,WORD PTR [bx+di]
     34b:	50                   	push   ax
     34c:	24 03                	and    al,0x3
     34e:	2f                   	das
     34f:	1c 91                	sbb    al,0x91
     351:	03 3f                	add    di,WORD PTR [bx]
     353:	19 58 03             	sbb    WORD PTR [bx+si+0x3],bx
     356:	78 18                	js     0x370
     358:	5c                   	pop    sp
     359:	03 02                	add    ax,WORD PTR [bp+si]
     35b:	21 30                	and    WORD PTR [bx+si],si
     35d:	03 3a                	add    di,WORD PTR [bp+si]
     35f:	1c 40                	sbb    al,0x40
     361:	03 15                	add    dx,WORD PTR [di]
     363:	25 68 03             	and    ax,0x368
     366:	37                   	aaa
     367:	22 6c 03             	and    ch,BYTE PTR [si+0x3]
     36a:	df 22                	fbld   TBYTE PTR [bp+si]
     36c:	70 03                	jo     0x371
     36e:	f8                   	clc
     36f:	16                   	push   ss
     370:	74 03                	je     0x375
     372:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     373:	22 10                	and    dl,BYTE PTR [bx+si]
     375:	03 82 1c 50          	add    ax,WORD PTR [bp+si+0x501c]
     379:	03 09                	add    cx,WORD PTR [bx+di]
     37b:	54                   	push   sp
     37c:	50                   	push   ax
     37d:	61                   	popa
     37e:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     383:	78 07                	js     0x38c
     385:	09 54 50             	or     WORD PTR [si+0x50],dx
     388:	61                   	popa
     389:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     38e:	78 22                	js     0x3b2
     390:	03 bb 06 ad          	add    di,WORD PTR [bp+di-0x52fa]
     394:	08 a6 03 1c          	or     BYTE PTR [bp+0x1c03],ah
     398:	00 08                	add    BYTE PTR [bx+si],cl
     39a:	45                   	inc    bp
     39b:	78 74                	js     0x411
     39d:	43                   	inc    bx
     39e:	74 72                	je     0x412
     3a0:	6c                   	ins    BYTE PTR es:[di],dx
     3a1:	73 14                	jae    0x3b7
     3a3:	00 e2                	add    dl,ah
     3a5:	00 ae 03 2d          	add    BYTE PTR [bp+0x2d03],ch
     3a9:	00 ff                	add    bh,bh
     3ab:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     3ae:	cc                   	int3
     3af:	03 01                	add    ax,WORD PTR [bx+di]
     3b1:	00 00                	add    BYTE PTR [bx+si],al
     3b3:	00 00                	add    BYTE PTR [bx+si],al
     3b5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3b8:	00 00                	add    BYTE PTR [bx+si],al
     3ba:	08 00                	or     BYTE PTR [bx+si],al
     3bc:	05 41 6c             	add    ax,0x6c41
     3bf:	69 67 6e 02 00       	imul   sp,WORD PTR [bx+0x6e],0x2
     3c4:	46                   	inc    si
     3c5:	04 38                	add    al,0x38
     3c7:	00 ff                	add    bh,bh
     3c9:	ff d5                	call   bp
     3cb:	1e                   	push   ds
     3cc:	d0 03                	rol    BYTE PTR [bp+di],1
     3ce:	17                   	pop    ss
     3cf:	1f                   	pop    ds
     3d0:	e2 03                	loop   0x3d5
     3d2:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     3d6:	ff                   	(bad)
     3d7:	ff 09                	dec    WORD PTR [bx+di]
     3d9:	00 05                	add    BYTE PTR [di],al
     3db:	43                   	inc    bx
     3dc:	6f                   	outs   dx,WORD PTR ds:[si]
     3dd:	6c                   	ins    BYTE PTR es:[di],dx
     3de:	6f                   	outs   dx,WORD PTR ds:[si]
     3df:	72 64                	jb     0x445
     3e1:	00 05                	add    BYTE PTR [di],al
     3e3:	04 3e                	add    al,0x3e
     3e5:	00 ff                	add    bh,bh
     3e7:	ff                   	(bad)
     3e8:	3e 00 ff             	ds add bh,bh
     3eb:	ff 01                	inc    WORD PTR [bx+di]
     3ed:	00 00                	add    BYTE PTR [bx+si],al
     3ef:	00 00                	add    BYTE PTR [bx+si],al
     3f1:	80 f4 ff             	xor    ah,0xff
     3f4:	ff                   	(bad)
     3f5:	ff 0a                	dec    WORD PTR [bp+si]
     3f7:	00 0a                	add    BYTE PTR [bp+si],cl
     3f9:	44                   	inc    sp
     3fa:	72 61                	jb     0x45d
     3fc:	67 43                	addr32 inc bx
     3fe:	75 72                	jne    0x472
     400:	73 6f                	jae    0x471
     402:	72 25                	jb     0x429
     404:	01 2e 04 2e          	add    WORD PTR ds:0x2e04,bp
     408:	00 ff                	add    bh,bh
     40a:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     40e:	ff 01                	inc    WORD PTR [bx+di]
     410:	00 00                	add    BYTE PTR [bx+si],al
     412:	00 00                	add    BYTE PTR [bx+si],al
     414:	80 00 00             	add    BYTE PTR [bx+si],0x0
     417:	00 00                	add    BYTE PTR [bx+si],al
     419:	0b 00                	or     ax,WORD PTR [bx+si]
     41b:	08 44 72             	or     BYTE PTR [si+0x72],al
     41e:	61                   	popa
     41f:	67 4d                	addr32 dec bp
     421:	6f                   	outs   dx,WORD PTR ds:[si]
     422:	64 65 07             	fs gs pop es
     425:	23 63 04             	and    sp,WORD PTR [bp+di+0x4]
     428:	2a 00                	sub    al,BYTE PTR [bx+si]
     42a:	ff                   	(bad)
     42b:	ff                   	(bad)
     42c:	b8 1c 4e             	mov    ax,0x4e1c
     42f:	04 01                	add    al,0x1
     431:	00 00                	add    BYTE PTR [bx+si],al
     433:	00 00                	add    BYTE PTR [bx+si],al
     435:	80 01 00             	add    BYTE PTR [bx+di],0x0
     438:	00 00                	add    BYTE PTR [bx+si],al
     43a:	0c 00                	or     al,0x0
     43c:	07                   	pop    es
     43d:	45                   	inc    bp
     43e:	6e                   	outs   dx,BYTE PTR ds:[si]
     43f:	61                   	popa
     440:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     443:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     446:	d4 07                	aam    0x7
     448:	34 00                	xor    al,0x0
     44a:	ff                   	(bad)
     44b:	ff                   	jmp    (bad)
     44c:	eb 1d                	jmp    0x46b
     44e:	52                   	push   dx
     44f:	04 08                	add    al,0x8
     451:	1e                   	push   ds
     452:	6b 04 00             	imul   ax,WORD PTR [si],0x0
     455:	80 00 00             	add    BYTE PTR [bx+si],0x0
     458:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     45c:	04 46                	add    al,0x46
     45e:	6f                   	outs   dx,WORD PTR ds:[si]
     45f:	6e                   	outs   dx,BYTE PTR ds:[si]
     460:	74 07                	je     0x469
     462:	23 87 04 2c          	and    ax,WORD PTR [bx+0x2c04]
     466:	00 ff                	add    bh,bh
     468:	ff 32                	push   WORD PTR [bp+si]
     46a:	1f                   	pop    ds
     46b:	8f 04                	pop    WORD PTR [si]
     46d:	01 00                	add    WORD PTR [bx+si],ax
     46f:	00 00                	add    BYTE PTR [bx+si],al
     471:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     475:	00 00                	add    BYTE PTR [bx+si],al
     477:	0e                   	push   cs
     478:	00 0b                	add    BYTE PTR [bp+di],cl
     47a:	50                   	push   ax
     47b:	61                   	popa
     47c:	72 65                	jb     0x4e3
     47e:	6e                   	outs   dx,BYTE PTR ds:[si]
     47f:	74 43                	je     0x4c4
     481:	6f                   	outs   dx,WORD PTR ds:[si]
     482:	6c                   	ins    BYTE PTR es:[di],dx
     483:	6f                   	outs   dx,WORD PTR ds:[si]
     484:	72 07                	jb     0x48d
     486:	23 aa 04 2b          	and    bp,WORD PTR [bp+si+0x2b04]
     48a:	00 ff                	add    bh,bh
     48c:	ff                   	(bad)
     48d:	3e 1e                	ds push ds
     48f:	b2 04                	mov    dl,0x4
     491:	01 00                	add    WORD PTR [bx+si],ax
     493:	00 00                	add    BYTE PTR [bx+si],al
     495:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     499:	00 00                	add    BYTE PTR [bx+si],al
     49b:	0f 00 0a             	str    WORD PTR [bp+si]
     49e:	50                   	push   ax
     49f:	61                   	popa
     4a0:	72 65                	jb     0x507
     4a2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a3:	74 46                	je     0x4eb
     4a5:	6f                   	outs   dx,WORD PTR ds:[si]
     4a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a7:	74 07                	je     0x4b0
     4a9:	23 f3                	and    si,bx
     4ab:	04 49                	add    al,0x49
     4ad:	00 ff                	add    bh,bh
     4af:	ff a1 1e fb          	jmp    WORD PTR [bx+di-0x4e2]
     4b3:	04 01                	add    al,0x1
     4b5:	00 00                	add    BYTE PTR [bx+si],al
     4b7:	00 00                	add    BYTE PTR [bx+si],al
     4b9:	80 01 00             	add    BYTE PTR [bx+di],0x0
     4bc:	00 00                	add    BYTE PTR [bx+si],al
     4be:	10 00                	adc    BYTE PTR [bx+si],al
     4c0:	0e                   	push   cs
     4c1:	50                   	push   ax
     4c2:	61                   	popa
     4c3:	72 65                	jb     0x52a
     4c5:	6e                   	outs   dx,BYTE PTR ds:[si]
     4c6:	74 53                	je     0x51b
     4c8:	68 6f 77             	push   0x776f
     4cb:	48                   	dec    ax
     4cc:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     4d1:	f4                   	hlt
     4d2:	07                   	pop    es
     4d3:	40                   	inc    ax
     4d4:	00 ff                	add    bh,bh
     4d6:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     4d9:	ff                   	(bad)
     4da:	ff 01                	inc    WORD PTR [bx+di]
     4dc:	00 00                	add    BYTE PTR [bx+si],al
     4de:	00 00                	add    BYTE PTR [bx+si],al
     4e0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4e3:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     4e7:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     4ea:	70 75                	jo     0x561
     4ec:	70 4d                	jo     0x53b
     4ee:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4f0:	75 07                	jne    0x4f9
     4f2:	23 14                	and    dx,WORD PTR [si]
     4f4:	05 48 00             	add    ax,0x48
     4f7:	ff                   	(bad)
     4f8:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     4fb:	ff 04                	inc    WORD PTR [si]
     4fd:	23 1e 1c 05          	and    bx,WORD PTR ds:0x51c
     501:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     505:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     509:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     50c:	6f                   	outs   dx,WORD PTR ds:[si]
     50d:	77 48                	ja     0x557
     50f:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     514:	5f                   	pop    di
     515:	06                   	push   es
     516:	29 00                	sub    WORD PTR [bx+si],ax
     518:	ff                   	(bad)
     519:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     51c:	77 05                	ja     0x523
     51e:	01 00                	add    WORD PTR [bx+si],ax
     520:	00 00                	add    BYTE PTR [bx+si],al
     522:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     526:	00 00                	add    BYTE PTR [bx+si],al
     528:	13 00                	adc    ax,WORD PTR [bx+si]
     52a:	07                   	pop    es
     52b:	56                   	push   si
     52c:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     531:	65 71 00             	gs jno 0x534
     534:	54                   	push   sp
     535:	05 7a 00             	add    ax,0x7a
     538:	ff                   	(bad)
     539:	ff                   	(bad)
     53a:	7a 00                	jp     0x53c
     53c:	ff                   	(bad)
     53d:	ff 01                	inc    WORD PTR [bx+di]
     53f:	00 00                	add    BYTE PTR [bx+si],al
     541:	00 00                	add    BYTE PTR [bx+si],al
     543:	80 00 00             	add    BYTE PTR [bx+si],0x0
     546:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     54a:	07                   	pop    es
     54b:	4f                   	dec    di
     54c:	6e                   	outs   dx,BYTE PTR ds:[si]
     54d:	43                   	inc    bx
     54e:	6c                   	ins    BYTE PTR es:[di],dx
     54f:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     554:	27                   	daa
     555:	06                   	push   es
     556:	82 00 ff             	add    BYTE PTR [bx+si],0xff
     559:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     55d:	ff 01                	inc    WORD PTR [bx+di]
     55f:	00 00                	add    BYTE PTR [bx+si],al
     561:	00 00                	add    BYTE PTR [bx+si],al
     563:	80 00 00             	add    BYTE PTR [bx+si],0x0
     566:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     56a:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     56d:	44                   	inc    sp
     56e:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     571:	6c                   	ins    BYTE PTR es:[di],dx
     572:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     577:	9a 05 62 00 ff       	call   0xff00:0x6205
     57c:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     57f:	ff                   	(bad)
     580:	ff 01                	inc    WORD PTR [bx+di]
     582:	00 00                	add    BYTE PTR [bx+si],al
     584:	00 00                	add    BYTE PTR [bx+si],al
     586:	80 00 00             	add    BYTE PTR [bx+si],0x0
     589:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     58d:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     590:	44                   	inc    sp
     591:	72 61                	jb     0x5f4
     593:	67 44                	addr32 inc sp
     595:	72 6f                	jb     0x606
     597:	70 80                	jo     0x519
     599:	02 bd 05 6a          	add    bh,BYTE PTR [di+0x6a05]
     59d:	00 ff                	add    bh,bh
     59f:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     5a2:	ff                   	(bad)
     5a3:	ff 01                	inc    WORD PTR [bx+di]
     5a5:	00 00                	add    BYTE PTR [bx+si],al
     5a7:	00 00                	add    BYTE PTR [bx+si],al
     5a9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5ac:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     5b0:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     5b3:	44                   	inc    sp
     5b4:	72 61                	jb     0x617
     5b6:	67 4f                	addr32 dec di
     5b8:	76 65                	jbe    0x61f
     5ba:	72 71                	jb     0x62d
     5bc:	01 e1                	add    cx,sp
     5be:	05 4a 00             	add    ax,0x4a
     5c1:	ff                   	(bad)
     5c2:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     5c5:	ff                   	(bad)
     5c6:	ff 01                	inc    WORD PTR [bx+di]
     5c8:	00 00                	add    BYTE PTR [bx+si],al
     5ca:	00 00                	add    BYTE PTR [bx+si],al
     5cc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5cf:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     5d3:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     5d6:	4d                   	dec    bp
     5d7:	6f                   	outs   dx,WORD PTR ds:[si]
     5d8:	75 73                	jne    0x64d
     5da:	65 44                	gs inc sp
     5dc:	6f                   	outs   dx,WORD PTR ds:[si]
     5dd:	77 6e                	ja     0x64d
     5df:	ce                   	into
     5e0:	01 05                	add    WORD PTR [di],ax
     5e2:	06                   	push   es
     5e3:	52                   	push   dx
     5e4:	00 ff                	add    bh,bh
     5e6:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     5e9:	ff                   	(bad)
     5ea:	ff 01                	inc    WORD PTR [bx+di]
     5ec:	00 00                	add    BYTE PTR [bx+si],al
     5ee:	00 00                	add    BYTE PTR [bx+si],al
     5f0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5f3:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     5f7:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     5fa:	4d                   	dec    bp
     5fb:	6f                   	outs   dx,WORD PTR ds:[si]
     5fc:	75 73                	jne    0x671
     5fe:	65 4d                	gs dec bp
     600:	6f                   	outs   dx,WORD PTR ds:[si]
     601:	76 65                	jbe    0x668
     603:	71 01                	jno    0x606
     605:	57                   	push   di
     606:	06                   	push   es
     607:	5a                   	pop    dx
     608:	00 ff                	add    bh,bh
     60a:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     60d:	ff                   	(bad)
     60e:	ff 01                	inc    WORD PTR [bx+di]
     610:	00 00                	add    BYTE PTR [bx+si],al
     612:	00 00                	add    BYTE PTR [bx+si],al
     614:	80 00 00             	add    BYTE PTR [bx+si],0x0
     617:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     61b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     61e:	4d                   	dec    bp
     61f:	6f                   	outs   dx,WORD PTR ds:[si]
     620:	75 73                	jne    0x695
     622:	65 55                	gs push bp
     624:	70 71                	jo     0x697
     626:	00 77 06             	add    BYTE PTR [bx+0x6],dh
     629:	8e 00                	mov    es,WORD PTR [bx+si]
     62b:	ff                   	(bad)
     62c:	ff 8e 00 ff          	dec    WORD PTR [bp-0x100]
     630:	ff 01                	inc    WORD PTR [bx+di]
     632:	00 00                	add    BYTE PTR [bx+si],al
     634:	00 00                	add    BYTE PTR [bx+si],al
     636:	80 00 00             	add    BYTE PTR [bx+si],0x0
     639:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     63d:	07                   	pop    es
     63e:	4f                   	dec    di
     63f:	6e                   	outs   dx,BYTE PTR ds:[si]
     640:	50                   	push   ax
     641:	61                   	popa
     642:	69 6e 74 cc 06       	imul   bp,WORD PTR [bp+0x74],0x6cc
     647:	00 00                	add    BYTE PTR [bx+si],al
     649:	00 00                	add    BYTE PTR [bx+si],al
     64b:	c4 06 bd 06          	les    ax,DWORD PTR ds:0x6bd
     64f:	96                   	xchg   si,ax
     650:	00 3d                	add    BYTE PTR [di],bh
     652:	08 da                	or     dl,bl
     654:	06                   	push   es
     655:	10 26 6b 06          	adc    BYTE PTR ds:0x66b,ah
     659:	9a 1f 09 07 cb       	call   0xcb07:0x91f
     65e:	1f                   	pop    ds
     65f:	5b                   	pop    bx
     660:	06                   	push   es
     661:	b5 1d                	mov    ch,0x1d
     663:	ca 06 cd             	retf   0xcd06
     666:	11 6f 06             	adc    WORD PTR [bx+0x6],bp
     669:	3a 27                	cmp    ah,BYTE PTR [bx]
     66b:	97                   	xchg   di,ax
     66c:	06                   	push   es
     66d:	fa                   	cli
     66e:	10 77 08             	adc    BYTE PTR [bx+0x8],dh
     671:	d6                   	(bad)
     672:	14 7b                	adc    al,0x7b
     674:	06                   	push   es
     675:	f4                   	hlt
     676:	4f                   	dec    di
     677:	87 06 32 16          	xchg   WORD PTR ds:0x1632,ax
     67b:	7f 06                	jg     0x683
     67d:	98                   	cbw
     67e:	15 a3 06             	adc    ax,0x6a3
     681:	51                   	push   cx
     682:	1b a7 06 38          	sbb    sp,WORD PTR [bx+0x3806]
     686:	50                   	push   ax
     687:	8b 06 1a 50          	mov    ax,WORD PTR ds:0x501a
     68b:	8f 06 21 50          	pop    WORD PTR ds:0x5021
     68f:	67 06                	addr32 push es
     691:	28 1d                	sub    BYTE PTR [di],bl
     693:	63 06 3f 19          	arpl   WORD PTR ds:0x193f,ax
     697:	9b                   	fwait
     698:	06                   	push   es
     699:	78 18                	js     0x6b3
     69b:	9f                   	lahf
     69c:	06                   	push   es
     69d:	02 21                	add    ah,BYTE PTR [bx+di]
     69f:	73 06                	jae    0x6a7
     6a1:	3a 1c                	cmp    bl,BYTE PTR [si]
     6a3:	83 06 15 25 ab       	add    WORD PTR ds:0x2515,0xffab
     6a8:	06                   	push   es
     6a9:	37                   	aaa
     6aa:	22 af 06 df          	and    ch,BYTE PTR [bx-0x20fa]
     6ae:	22 b3 06 f8          	and    dh,BYTE PTR [bp+di-0x7fa]
     6b2:	16                   	push   ss
     6b3:	b7 06                	mov    bh,0x6
     6b5:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     6b6:	22 53 06             	and    dl,BYTE PTR [bp+di+0x6]
     6b9:	2a 1e 93 06          	sub    bl,BYTE PTR ds:0x693
     6bd:	06                   	push   es
     6be:	54                   	push   sp
     6bf:	49                   	dec    cx
     6c0:	6d                   	ins    WORD PTR es:[di],dx
     6c1:	61                   	popa
     6c2:	67 65 01 00          	add    WORD PTR gs:[eax],ax
     6c6:	fb                   	sti
     6c7:	ff e3                	jmp    bx
     6c9:	1d d6 06             	sbb    ax,0x6d6
     6cc:	07                   	pop    es
     6cd:	06                   	push   es
     6ce:	54                   	push   sp
     6cf:	49                   	dec    cx
     6d0:	6d                   	ins    WORD PTR es:[di],dx
     6d1:	61                   	popa
     6d2:	67 65 65 06          	addr32 gs gs push es
     6d6:	11 07                	adc    WORD PTR [bx],ax
     6d8:	ad                   	lods   ax,WORD PTR ds:[si]
     6d9:	08 eb                	or     bl,ch
     6db:	06                   	push   es
     6dc:	1c 00                	sbb    al,0x0
     6de:	08 45 78             	or     BYTE PTR [di+0x78],al
     6e1:	74 43                	je     0x726
     6e3:	74 72                	je     0x757
     6e5:	6c                   	ins    BYTE PTR es:[di],dx
     6e6:	73 14                	jae    0x6fc
     6e8:	00 e2                	add    dl,ah
     6ea:	00 f3                	add    bl,dh
     6ec:	06                   	push   es
     6ed:	2d 00 ff             	sub    ax,0xff00
     6f0:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     6f3:	49                   	dec    cx
     6f4:	07                   	pop    es
     6f5:	01 00                	add    WORD PTR [bx+si],ax
     6f7:	00 00                	add    BYTE PTR [bx+si],al
     6f9:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     6fd:	00 00                	add    BYTE PTR [bx+si],al
     6ff:	08 00                	or     BYTE PTR [bx+si],al
     701:	05 41 6c             	add    ax,0x6c41
     704:	69 67 6e 07 23       	imul   sp,WORD PTR [bx+0x6e],0x2307
     709:	2a 07                	sub    al,BYTE PTR [bx]
     70b:	92                   	xchg   dx,ax
     70c:	00 ff                	add    bh,bh
     70e:	ff 8b 20 32          	dec    WORD PTR [bp+di+0x3220]
     712:	07                   	pop    es
     713:	01 00                	add    WORD PTR [bx+si],ax
     715:	00 00                	add    BYTE PTR [bx+si],al
     717:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     71b:	00 00                	add    BYTE PTR [bx+si],al
     71d:	09 00                	or     WORD PTR [bx+si],ax
     71f:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     722:	74 6f                	je     0x793
     724:	53                   	push   bx
     725:	69 7a 65 07 23       	imul   di,WORD PTR [bp+si+0x65],0x2307
     72a:	8d 07                	lea    ax,[bx]
     72c:	94                   	xchg   sp,ax
     72d:	00 ff                	add    bh,bh
     72f:	ff aa 20 dc          	jmp    DWORD PTR [bp+si-0x23e0]
     733:	07                   	pop    es
     734:	01 00                	add    WORD PTR [bx+si],ax
     736:	00 00                	add    BYTE PTR [bx+si],al
     738:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     73c:	00 00                	add    BYTE PTR [bx+si],al
     73e:	0a 00                	or     al,BYTE PTR [bx+si]
     740:	06                   	push   es
     741:	43                   	inc    bx
     742:	65 6e                	outs   dx,BYTE PTR gs:[si]
     744:	74 65                	je     0x7ab
     746:	72 64                	jb     0x7ac
     748:	00 6c 07             	add    BYTE PTR [si+0x7],ch
     74b:	3e 00 ff             	ds add bh,bh
     74e:	ff                   	(bad)
     74f:	3e 00 ff             	ds add bh,bh
     752:	ff 01                	inc    WORD PTR [bx+di]
     754:	00 00                	add    BYTE PTR [bx+si],al
     756:	00 00                	add    BYTE PTR [bx+si],al
     758:	80 f4 ff             	xor    ah,0xff
     75b:	ff                   	(bad)
     75c:	ff 0b                	dec    WORD PTR [bp+di]
     75e:	00 0a                	add    BYTE PTR [bp+si],cl
     760:	44                   	inc    sp
     761:	72 61                	jb     0x7c4
     763:	67 43                	addr32 inc bx
     765:	75 72                	jne    0x7d9
     767:	73 6f                	jae    0x7d8
     769:	72 25                	jb     0x790
     76b:	01 95 07 2e          	add    WORD PTR [di+0x2e07],dx
     76f:	00 ff                	add    bh,bh
     771:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     775:	ff 01                	inc    WORD PTR [bx+di]
     777:	00 00                	add    BYTE PTR [bx+si],al
     779:	00 00                	add    BYTE PTR [bx+si],al
     77b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     77e:	00 00                	add    BYTE PTR [bx+si],al
     780:	0c 00                	or     al,0x0
     782:	08 44 72             	or     BYTE PTR [si+0x72],al
     785:	61                   	popa
     786:	67 4d                	addr32 dec bp
     788:	6f                   	outs   dx,WORD PTR ds:[si]
     789:	64 65 07             	fs gs pop es
     78c:	23 ad 07 2a          	and    bp,WORD PTR [di+0x2a07]
     790:	00 ff                	add    bh,bh
     792:	ff                   	(bad)
     793:	b8 1c b5             	mov    ax,0xb51c
     796:	07                   	pop    es
     797:	01 00                	add    WORD PTR [bx+si],ax
     799:	00 00                	add    BYTE PTR [bx+si],al
     79b:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     79f:	00 00                	add    BYTE PTR [bx+si],al
     7a1:	0d 00 07             	or     ax,0x700
     7a4:	45                   	inc    bp
     7a5:	6e                   	outs   dx,BYTE PTR ds:[si]
     7a6:	61                   	popa
     7a7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7aa:	64 07                	fs pop es
     7ac:	23 16 08 49          	and    dx,WORD PTR ds:0x4908
     7b0:	00 ff                	add    bh,bh
     7b2:	ff a1 1e 1e          	jmp    WORD PTR [bx+di+0x1e1e]
     7b6:	08 01                	or     BYTE PTR [bx+di],al
     7b8:	00 00                	add    BYTE PTR [bx+si],al
     7ba:	00 00                	add    BYTE PTR [bx+si],al
     7bc:	80 01 00             	add    BYTE PTR [bx+di],0x0
     7bf:	00 00                	add    BYTE PTR [bx+si],al
     7c1:	0e                   	push   cs
     7c2:	00 0e 50 61          	add    BYTE PTR ds:0x6150,cl
     7c6:	72 65                	jb     0x82d
     7c8:	6e                   	outs   dx,BYTE PTR ds:[si]
     7c9:	74 53                	je     0x81e
     7cb:	68 6f 77             	push   0x776f
     7ce:	48                   	dec    ax
     7cf:	69 6e 74 db 06       	imul   bp,WORD PTR [bp+0x74],0x6db
     7d4:	c8 0f 8e 00          	enter  0x8e0f,0x0
     7d8:	ff                   	(bad)
     7d9:	ff cf                	dec    di
     7db:	20 3f                	and    BYTE PTR [bx],bh
     7dd:	08 01                	or     BYTE PTR [bx+di],al
     7df:	00 00                	add    BYTE PTR [bx+si],al
     7e1:	00 00                	add    BYTE PTR [bx+si],al
     7e3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7e6:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     7ea:	07                   	pop    es
     7eb:	50                   	push   ax
     7ec:	69 63 74 75 72       	imul   sp,WORD PTR [bp+di+0x74],0x7275
     7f1:	65 0d 04 d2          	gs or  ax,0xd204
     7f5:	10 40 00             	adc    BYTE PTR [bx+si+0x0],al
     7f8:	ff                   	(bad)
     7f9:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     7fc:	ff                   	(bad)
     7fd:	ff 01                	inc    WORD PTR [bx+di]
     7ff:	00 00                	add    BYTE PTR [bx+si],al
     801:	00 00                	add    BYTE PTR [bx+si],al
     803:	80 00 00             	add    BYTE PTR [bx+si],0x0
     806:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     80a:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     80d:	70 75                	jo     0x884
     80f:	70 4d                	jo     0x85e
     811:	65 6e                	outs   dx,BYTE PTR gs:[si]
     813:	75 07                	jne    0x81c
     815:	23 37                	and    si,WORD PTR [bx]
     817:	08 48 00             	or     BYTE PTR [bx+si+0x0],cl
     81a:	ff                   	(bad)
     81b:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     81e:	22 08                	and    cl,BYTE PTR [bx+si]
     820:	23 1e 5f 08          	and    bx,WORD PTR ds:0x85f
     824:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     828:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     82c:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     82f:	6f                   	outs   dx,WORD PTR ds:[si]
     830:	77 48                	ja     0x87a
     832:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     837:	57                   	push   di
     838:	08 93 00 ff          	or     BYTE PTR [bp+di-0x100],dl
     83c:	ff                   	jmp    (bad)
     83d:	ed                   	in     ax,dx
     83e:	20 a2 09 01          	and    BYTE PTR [bp+si+0x109],ah
     842:	00 00                	add    BYTE PTR [bx+si],al
     844:	00 00                	add    BYTE PTR [bx+si],al
     846:	80 00 00             	add    BYTE PTR [bx+si],0x0
     849:	00 00                	add    BYTE PTR [bx+si],al
     84b:	12 00                	adc    al,BYTE PTR [bx+si]
     84d:	07                   	pop    es
     84e:	53                   	push   bx
     84f:	74 72                	je     0x8c3
     851:	65 74 63             	gs je  0x8b7
     854:	68 07 23             	push   0x2307
     857:	27                   	daa
     858:	0a 29                	or     ch,BYTE PTR [bx+di]
     85a:	00 ff                	add    bh,bh
     85c:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     85f:	ba 08 01             	mov    dx,0x108
     862:	00 00                	add    BYTE PTR [bx+si],al
     864:	00 00                	add    BYTE PTR [bx+si],al
     866:	80 01 00             	add    BYTE PTR [bx+di],0x0
     869:	00 00                	add    BYTE PTR [bx+si],al
     86b:	13 00                	adc    ax,WORD PTR [bx+si]
     86d:	07                   	pop    es
     86e:	56                   	push   si
     86f:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     874:	65 71 00             	gs jno 0x877
     877:	97                   	xchg   di,ax
     878:	08 7a 00             	or     BYTE PTR [bp+si+0x0],bh
     87b:	ff                   	(bad)
     87c:	ff                   	(bad)
     87d:	7a 00                	jp     0x87f
     87f:	ff                   	(bad)
     880:	ff 01                	inc    WORD PTR [bx+di]
     882:	00 00                	add    BYTE PTR [bx+si],al
     884:	00 00                	add    BYTE PTR [bx+si],al
     886:	80 00 00             	add    BYTE PTR [bx+si],0x0
     889:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     88d:	07                   	pop    es
     88e:	4f                   	dec    di
     88f:	6e                   	outs   dx,BYTE PTR ds:[si]
     890:	43                   	inc    bx
     891:	6c                   	ins    BYTE PTR es:[di],dx
     892:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     897:	3f                   	aas
     898:	0a 82 00 ff          	or     al,BYTE PTR [bp+si-0x100]
     89c:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     8a0:	ff 01                	inc    WORD PTR [bx+di]
     8a2:	00 00                	add    BYTE PTR [bx+si],al
     8a4:	00 00                	add    BYTE PTR [bx+si],al
     8a6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8a9:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     8ad:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     8b0:	44                   	inc    sp
     8b1:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     8b4:	6c                   	ins    BYTE PTR es:[di],dx
     8b5:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     8ba:	dd 08                	fisttp QWORD PTR [bx+si]
     8bc:	62 00                	bound  ax,DWORD PTR [bx+si]
     8be:	ff                   	(bad)
     8bf:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     8c2:	ff                   	(bad)
     8c3:	ff 01                	inc    WORD PTR [bx+di]
     8c5:	00 00                	add    BYTE PTR [bx+si],al
     8c7:	00 00                	add    BYTE PTR [bx+si],al
     8c9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8cc:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     8d0:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     8d3:	44                   	inc    sp
     8d4:	72 61                	jb     0x937
     8d6:	67 44                	addr32 inc sp
     8d8:	72 6f                	jb     0x949
     8da:	70 80                	jo     0x85c
     8dc:	02 00                	add    al,BYTE PTR [bx+si]
     8de:	09 6a 00             	or     WORD PTR [bp+si+0x0],bp
     8e1:	ff                   	(bad)
     8e2:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     8e5:	ff                   	(bad)
     8e6:	ff 01                	inc    WORD PTR [bx+di]
     8e8:	00 00                	add    BYTE PTR [bx+si],al
     8ea:	00 00                	add    BYTE PTR [bx+si],al
     8ec:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8ef:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     8f3:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     8f6:	44                   	inc    sp
     8f7:	72 61                	jb     0x95a
     8f9:	67 4f                	addr32 dec di
     8fb:	76 65                	jbe    0x962
     8fd:	72 32                	jb     0x931
     8ff:	03 22                	add    sp,WORD PTR [bp+si]
     901:	09 72 00             	or     WORD PTR [bp+si+0x0],si
     904:	ff                   	(bad)
     905:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     908:	ff                   	(bad)
     909:	ff 01                	inc    WORD PTR [bx+di]
     90b:	00 00                	add    BYTE PTR [bx+si],al
     90d:	00 00                	add    BYTE PTR [bx+si],al
     90f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     912:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     916:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     919:	45                   	inc    bp
     91a:	6e                   	outs   dx,BYTE PTR ds:[si]
     91b:	64 44                	fs inc sp
     91d:	72 61                	jb     0x980
     91f:	67 71 01             	addr32 jno 0x923
     922:	46                   	inc    si
     923:	09 4a 00             	or     WORD PTR [bp+si+0x0],cx
     926:	ff                   	(bad)
     927:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     92a:	ff                   	(bad)
     92b:	ff 01                	inc    WORD PTR [bx+di]
     92d:	00 00                	add    BYTE PTR [bx+si],al
     92f:	00 00                	add    BYTE PTR [bx+si],al
     931:	80 00 00             	add    BYTE PTR [bx+si],0x0
     934:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     938:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     93b:	4d                   	dec    bp
     93c:	6f                   	outs   dx,WORD PTR ds:[si]
     93d:	75 73                	jne    0x9b2
     93f:	65 44                	gs inc sp
     941:	6f                   	outs   dx,WORD PTR ds:[si]
     942:	77 6e                	ja     0x9b2
     944:	ce                   	into
     945:	01 6a 09             	add    WORD PTR [bp+si+0x9],bp
     948:	52                   	push   dx
     949:	00 ff                	add    bh,bh
     94b:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     94e:	ff                   	(bad)
     94f:	ff 01                	inc    WORD PTR [bx+di]
     951:	00 00                	add    BYTE PTR [bx+si],al
     953:	00 00                	add    BYTE PTR [bx+si],al
     955:	80 00 00             	add    BYTE PTR [bx+si],0x0
     958:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     95c:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     95f:	4d                   	dec    bp
     960:	6f                   	outs   dx,WORD PTR ds:[si]
     961:	75 73                	jne    0x9d6
     963:	65 4d                	gs dec bp
     965:	6f                   	outs   dx,WORD PTR ds:[si]
     966:	76 65                	jbe    0x9cd
     968:	71 01                	jno    0x96b
     96a:	2b 0a                	sub    cx,WORD PTR [bp+si]
     96c:	5a                   	pop    dx
     96d:	00 ff                	add    bh,bh
     96f:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     972:	ff                   	(bad)
     973:	ff 01                	inc    WORD PTR [bx+di]
     975:	00 00                	add    BYTE PTR [bx+si],al
     977:	00 00                	add    BYTE PTR [bx+si],al
     979:	80 00 00             	add    BYTE PTR [bx+si],0x0
     97c:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     980:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     983:	4d                   	dec    bp
     984:	6f                   	outs   dx,WORD PTR ds:[si]
     985:	75 73                	jne    0x9fa
     987:	65 55                	gs push bp
     989:	70 03                	jo     0x98e
     98b:	0b 54 42             	or     dx,WORD PTR [si+0x42]
     98e:	65 76 65             	gs jbe 0x9f6
     991:	6c                   	ins    BYTE PTR es:[di],dx
     992:	53                   	push   bx
     993:	74 79                	je     0xa0e
     995:	6c                   	ins    BYTE PTR es:[di],dx
     996:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     999:	00 00                	add    BYTE PTR [bx+si],al
     99b:	00 01                	add    BYTE PTR [bx+di],al
     99d:	00 00                	add    BYTE PTR [bx+si],al
     99f:	00 8a 09 cf          	add    BYTE PTR [bp+si-0x30f7],cl
     9a3:	09 09                	or     WORD PTR [bx+di],cx
     9a5:	62 73 4c             	bound  si,DWORD PTR [bp+di+0x4c]
     9a8:	6f                   	outs   dx,WORD PTR ds:[si]
     9a9:	77 65                	ja     0xa10
     9ab:	72 65                	jb     0xa12
     9ad:	64 08 62 73          	or     BYTE PTR fs:[bp+si+0x73],ah
     9b1:	52                   	push   dx
     9b2:	61                   	popa
     9b3:	69 73 65 64 03       	imul   si,WORD PTR [bp+di+0x65],0x364
     9b8:	0b 54 42             	or     dx,WORD PTR [si+0x42]
     9bb:	65 76 65             	gs jbe 0xa23
     9be:	6c                   	ins    BYTE PTR es:[di],dx
     9bf:	53                   	push   bx
     9c0:	68 61 70             	push   0x7061
     9c3:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     9c6:	00 00                	add    BYTE PTR [bx+si],al
     9c8:	00 05                	add    BYTE PTR [di],al
     9ca:	00 00                	add    BYTE PTR [bx+si],al
     9cc:	00 b7 09 83          	add    BYTE PTR [bx-0x7cf7],dh
     9d0:	0a 05                	or     al,BYTE PTR [di]
     9d2:	62 73 42             	bound  si,DWORD PTR [bp+di+0x42]
     9d5:	6f                   	outs   dx,WORD PTR ds:[si]
     9d6:	78 07                	js     0x9df
     9d8:	62 73 46             	bound  si,DWORD PTR [bp+di+0x46]
     9db:	72 61                	jb     0xa3e
     9dd:	6d                   	ins    WORD PTR es:[di],dx
     9de:	65 09 62 73          	or     WORD PTR gs:[bp+si+0x73],sp
     9e2:	54                   	push   sp
     9e3:	6f                   	outs   dx,WORD PTR ds:[si]
     9e4:	70 4c                	jo     0xa32
     9e6:	69 6e 65 0c 62       	imul   bp,WORD PTR [bp+0x65],0x620c
     9eb:	73 42                	jae    0xa2f
     9ed:	6f                   	outs   dx,WORD PTR ds:[si]
     9ee:	74 74                	je     0xa64
     9f0:	6f                   	outs   dx,WORD PTR ds:[si]
     9f1:	6d                   	ins    WORD PTR es:[di],dx
     9f2:	4c                   	dec    sp
     9f3:	69 6e 65 0a 62       	imul   bp,WORD PTR [bp+0x65],0x620a
     9f8:	73 4c                	jae    0xa46
     9fa:	65 66 74 4c          	gs data32 je 0xa4a
     9fe:	69 6e 65 0b 62       	imul   bp,WORD PTR [bp+0x65],0x620b
     a03:	73 52                	jae    0xa57
     a05:	69 67 68 74 4c       	imul   sp,WORD PTR [bx+0x68],0x4c74
     a0a:	69 6e 65 8c 0a       	imul   bp,WORD PTR [bp+0x65],0xa8c
     a0f:	00 00                	add    BYTE PTR [bx+si],al
     a11:	00 00                	add    BYTE PTR [bx+si],al
     a13:	00 00                	add    BYTE PTR [bx+si],al
     a15:	85 0a                	test   WORD PTR [bp+si],cx
     a17:	90                   	nop
     a18:	00 3d                	add    BYTE PTR [di],bh
     a1a:	08 9a 0a 10          	or     BYTE PTR [bp+si+0x100a],bl
     a1e:	26 33 0a             	xor    cx,WORD PTR es:[bp+si]
     a21:	9a 1f c9 0a cb       	call   0xcb0a:0xc91f
     a26:	1f                   	pop    ds
     a27:	23 0a                	and    cx,WORD PTR [bp+si]
     a29:	f0 68 1f 0a          	lock push 0xa1f
     a2d:	cd 11                	int    0x11
     a2f:	37                   	aaa
     a30:	0a 3a                	or     bh,BYTE PTR [bp+si]
     a32:	27                   	daa
     a33:	5f                   	pop    di
     a34:	0a fa                	or     bh,dl
     a36:	10 91 0b d6          	adc    BYTE PTR [bx+di-0x29f5],dl
     a3a:	14 43                	adc    al,0x43
     a3c:	0a f4                	or     dh,ah
     a3e:	4f                   	dec    di
     a3f:	4f                   	dec    di
     a40:	0a 32                	or     dh,BYTE PTR [bp+si]
     a42:	16                   	push   ss
     a43:	47                   	inc    di
     a44:	0a 98 15 6b          	or     bl,BYTE PTR [bx+si+0x6b15]
     a48:	0a 51 1b             	or     dl,BYTE PTR [bx+di+0x1b]
     a4b:	6f                   	outs   dx,WORD PTR ds:[si]
     a4c:	0a 38                	or     bh,BYTE PTR [bx+si]
     a4e:	50                   	push   ax
     a4f:	53                   	push   bx
     a50:	0a 1a                	or     bl,BYTE PTR [bp+si]
     a52:	50                   	push   ax
     a53:	57                   	push   di
     a54:	0a 21                	or     ah,BYTE PTR [bx+di]
     a56:	50                   	push   ax
     a57:	2f                   	das
     a58:	0a e6                	or     ah,dh
     a5a:	21 96 0a 3f          	and    WORD PTR [bp+0x3f0a],dx
     a5e:	19 63 0a             	sbb    WORD PTR [bp+di+0xa],sp
     a61:	78 18                	js     0xa7b
     a63:	67 0a 02             	or     al,BYTE PTR [edx]
     a66:	21 3b                	and    WORD PTR [bp+di],di
     a68:	0a 3a                	or     bh,BYTE PTR [bp+si]
     a6a:	1c 4b                	sbb    al,0x4b
     a6c:	0a 15                	or     dl,BYTE PTR [di]
     a6e:	25 73 0a             	and    ax,0xa73
     a71:	37                   	aaa
     a72:	22 77 0a             	and    dh,BYTE PTR [bx+0xa]
     a75:	df 22                	fbld   TBYTE PTR [bp+si]
     a77:	7b 0a                	jnp    0xa83
     a79:	f8                   	clc
     a7a:	16                   	push   ss
     a7b:	7f 0a                	jg     0xa87
     a7d:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     a7e:	22 1b                	and    bl,BYTE PTR [bp+di]
     a80:	0a d5                	or     dl,ch
     a82:	23 5b 0a             	and    bx,WORD PTR [bp+di+0xa]
     a85:	06                   	push   es
     a86:	54                   	push   sp
     a87:	42                   	inc    dx
     a88:	65 76 65             	gs jbe 0xaf0
     a8b:	6c                   	ins    BYTE PTR es:[di],dx
     a8c:	07                   	pop    es
     a8d:	06                   	push   es
     a8e:	54                   	push   sp
     a8f:	42                   	inc    dx
     a90:	65 76 65             	gs jbe 0xaf8
     a93:	6c                   	ins    BYTE PTR es:[di],dx
     a94:	2d 0a f0             	sub    ax,0xf00a
     a97:	0a ad 08 ab          	or     ch,BYTE PTR [di-0x54f8]
     a9b:	0a 0e 00 08          	or     cl,BYTE PTR ds:0x800
     a9f:	45                   	inc    bp
     aa0:	78 74                	js     0xb16
     aa2:	43                   	inc    bx
     aa3:	74 72                	je     0xb17
     aa5:	6c                   	ins    BYTE PTR es:[di],dx
     aa6:	73 06                	jae    0xaae
     aa8:	00 e2                	add    dl,ah
     aaa:	00 b3 0a 2d          	add    BYTE PTR [bp+di+0x2d0a],dh
     aae:	00 ff                	add    bh,bh
     ab0:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     ab3:	d1 0a                	ror    WORD PTR [bp+si],1
     ab5:	01 00                	add    WORD PTR [bx+si],ax
     ab7:	00 00                	add    BYTE PTR [bx+si],al
     ab9:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     abd:	00 00                	add    BYTE PTR [bx+si],al
     abf:	08 00                	or     BYTE PTR [bx+si],al
     ac1:	05 41 6c             	add    ax,0x6c41
     ac4:	69 67 6e 07 23       	imul   sp,WORD PTR [bx+0x6e],0x2307
     ac9:	0e                   	push   cs
     aca:	0b 49 00             	or     cx,WORD PTR [bx+di+0x0]
     acd:	ff                   	(bad)
     ace:	ff a1 1e 16          	jmp    WORD PTR [bx+di+0x161e]
     ad2:	0b 01                	or     ax,WORD PTR [bx+di]
     ad4:	00 00                	add    BYTE PTR [bx+si],al
     ad6:	00 00                	add    BYTE PTR [bx+si],al
     ad8:	80 01 00             	add    BYTE PTR [bx+di],0x0
     adb:	00 00                	add    BYTE PTR [bx+si],al
     add:	09 00                	or     WORD PTR [bx+si],ax
     adf:	0e                   	push   cs
     ae0:	50                   	push   ax
     ae1:	61                   	popa
     ae2:	72 65                	jb     0xb49
     ae4:	6e                   	outs   dx,BYTE PTR ds:[si]
     ae5:	74 53                	je     0xb3a
     ae7:	68 6f 77             	push   0x776f
     aea:	48                   	dec    ax
     aeb:	69 6e 74 b7 09       	imul   bp,WORD PTR [bp+0x74],0x9b7
     af0:	f8                   	clc
     af1:	0a 8f 00 ff          	or     cl,BYTE PTR [bx-0x100]
     af5:	ff 6a 22             	jmp    DWORD PTR [bp+si+0x22]
     af8:	2f                   	das
     af9:	0b 01                	or     ax,WORD PTR [bx+di]
     afb:	00 00                	add    BYTE PTR [bx+si],al
     afd:	00 00                	add    BYTE PTR [bx+si],al
     aff:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b02:	00 00                	add    BYTE PTR [bx+si],al
     b04:	0a 00                	or     al,BYTE PTR [bx+si]
     b06:	05 53 68             	add    ax,0x6853
     b09:	61                   	popa
     b0a:	70 65                	jo     0xb71
     b0c:	07                   	pop    es
     b0d:	23 4d 0b             	and    cx,WORD PTR [di+0xb]
     b10:	48                   	dec    ax
     b11:	00 ff                	add    bh,bh
     b13:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     b16:	1a 0b                	sbb    cl,BYTE PTR [bp+di]
     b18:	23 1e 55 0b          	and    bx,WORD PTR ds:0xb55
     b1c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     b20:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     b24:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     b27:	6f                   	outs   dx,WORD PTR ds:[si]
     b28:	77 48                	ja     0xb72
     b2a:	69 6e 74 8a 09       	imul   bp,WORD PTR [bp+0x74],0x98a
     b2f:	37                   	aaa
     b30:	0b 8e 00 ff          	or     cx,WORD PTR [bp-0x100]
     b34:	ff 45 22             	inc    WORD PTR [di+0x22]
     b37:	b9 0b 01             	mov    cx,0x10b
     b3a:	00 00                	add    BYTE PTR [bx+si],al
     b3c:	00 00                	add    BYTE PTR [bx+si],al
     b3e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b41:	00 00                	add    BYTE PTR [bx+si],al
     b43:	0c 00                	or     al,0x0
     b45:	05 53 74             	add    ax,0x7453
     b48:	79 6c                	jns    0xbb6
     b4a:	65 07                	gs pop es
     b4c:	23 85 0b 29          	and    ax,WORD PTR [di+0x290b]
     b50:	00 ff                	add    bh,bh
     b52:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     b55:	3b 0d                	cmp    cx,WORD PTR [di]
     b57:	01 00                	add    WORD PTR [bx+si],ax
     b59:	00 00                	add    BYTE PTR [bx+si],al
     b5b:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     b5f:	00 00                	add    BYTE PTR [bx+si],al
     b61:	0d 00 07             	or     ax,0x700
     b64:	56                   	push   si
     b65:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     b6a:	65 ca 0b 00          	gs retf 0xb
     b6e:	00 00                	add    BYTE PTR [bx+si],al
     b70:	00 c2                	add    dl,al
     b72:	0b bb 0b 28          	or     di,WORD PTR [bp+di+0x280b]
     b76:	00 da                	add    dl,bl
     b78:	05 d8 0b             	add    ax,0xbd8
     b7b:	64 20 e9             	fs and cl,ch
     b7e:	0b 9a 1f 7d          	or     bx,WORD PTR [bp+si+0x7d1f]
     b82:	0b cb                	or     cx,bx
     b84:	1f                   	pop    ds
     b85:	81 0b 1d 26          	or     WORD PTR [bp+di],0x261d
     b89:	c8 0b cd 11          	enter  0xcd0b,0x11
     b8d:	95                   	xchg   bp,ax
     b8e:	0b 6e 4f             	or     bp,WORD PTR [bp+0x4f]
     b91:	99                   	cwd
     b92:	0b fa                	or     di,dx
     b94:	10 79 0b             	adc    BYTE PTR [bx+di+0xb],bh
     b97:	e5 4f                	in     ax,0x4f
     b99:	9d                   	popf
     b9a:	0b f4                	or     si,sp
     b9c:	4f                   	dec    di
     b9d:	a1 0b 05             	mov    ax,ds:0x50b
     ba0:	4f                   	dec    di
     ba1:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     ba2:	0b 03                	or     ax,WORD PTR [bp+di]
     ba4:	50                   	push   ax
     ba5:	a9 0b 46             	test   ax,0x460b
     ba8:	51                   	push   cx
     ba9:	ad                   	lods   ax,WORD PTR ds:[si]
     baa:	0b 38                	or     di,WORD PTR [bx+si]
     bac:	50                   	push   ax
     bad:	b1 0b                	mov    cl,0xb
     baf:	1a 50 b5             	sbb    dl,BYTE PTR [bx+si-0x4b]
     bb2:	0b 21                	or     sp,WORD PTR [bx+di]
     bb4:	50                   	push   ax
     bb5:	8d 0b                	lea    cx,[bp+di]
     bb7:	be 25 89             	mov    si,0x8925
     bba:	0b 06 54 54          	or     ax,WORD PTR ds:0x5454
     bbe:	69 6d 65 72 01       	imul   bp,WORD PTR [di+0x65],0x172
     bc3:	00 ff                	add    bh,bh
     bc5:	ff b1 27 d4          	push   WORD PTR [bx+di-0x2bd9]
     bc9:	0b 07                	or     ax,WORD PTR [bx]
     bcb:	06                   	push   es
     bcc:	54                   	push   sp
     bcd:	54                   	push   sp
     bce:	69 6d 65 72 8b       	imul   bp,WORD PTR [di+0x65],0x8b72
     bd3:	0b f1                	or     si,cx
     bd5:	0b 15                	or     dx,WORD PTR [di]
     bd7:	06                   	push   es
     bd8:	2a 0c                	sub    cl,BYTE PTR [si]
     bda:	05 00 08             	add    ax,0x800
     bdd:	45                   	inc    bp
     bde:	78 74                	js     0xc54
     be0:	43                   	inc    bx
     be1:	74 72                	je     0xc55
     be3:	6c                   	ins    BYTE PTR es:[di],dx
     be4:	73 03                	jae    0xbe9
     be6:	00 07                	add    BYTE PTR [bx],al
     be8:	23 09                	and    cx,WORD PTR [bx+di]
     bea:	0c 1a                	or     al,0x1a
     bec:	00 ff                	add    bh,bh
     bee:	ff 49 27             	dec    WORD PTR [bx+di+0x27]
     bf1:	11 0c                	adc    WORD PTR [si],cx
     bf3:	01 00                	add    WORD PTR [bx+si],ax
     bf5:	00 00                	add    BYTE PTR [bx+si],al
     bf7:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     bfb:	00 00                	add    BYTE PTR [bx+si],al
     bfd:	02 00                	add    al,BYTE PTR [bx+si]
     bff:	07                   	pop    es
     c00:	45                   	inc    bp
     c01:	6e                   	outs   dx,BYTE PTR ds:[si]
     c02:	61                   	popa
     c03:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c06:	64 e6 22             	fs out 0x22,al
     c09:	c3                   	ret
     c0a:	0c 1c                	or     al,0x1c
     c0c:	00 ff                	add    bh,bh
     c0e:	ff 6a 27             	jmp    DWORD PTR [bp+si+0x27]
     c11:	32 0c                	xor    cl,BYTE PTR [si]
     c13:	01 00                	add    WORD PTR [bx+si],ax
     c15:	00 00                	add    BYTE PTR [bx+si],al
     c17:	00 80 e8 03          	add    BYTE PTR [bx+si+0x3e8],al
     c1b:	00 00                	add    BYTE PTR [bx+si],al
     c1d:	03 00                	add    ax,WORD PTR [bx+si]
     c1f:	08 49 6e             	or     BYTE PTR [bx+di+0x6e],cl
     c22:	74 65                	je     0xc89
     c24:	72 76                	jb     0xc9c
     c26:	61                   	popa
     c27:	6c                   	ins    BYTE PTR es:[di],dx
     c28:	71 00                	jno    0xc2a
     c2a:	db 0c                	fisttp DWORD PTR [si]
     c2c:	20 00                	and    BYTE PTR [bx+si],al
     c2e:	ff                   	(bad)
     c2f:	ff 8b 27 60          	dec    WORD PTR [bp+di+0x6027]
     c33:	0c 01                	or     al,0x1
     c35:	00 00                	add    BYTE PTR [bx+si],al
     c37:	00 00                	add    BYTE PTR [bx+si],al
     c39:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c3c:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     c40:	07                   	pop    es
     c41:	4f                   	dec    di
     c42:	6e                   	outs   dx,BYTE PTR ds:[si]
     c43:	54                   	push   sp
     c44:	69 6d 65 72 03       	imul   bp,WORD PTR [di+0x65],0x372
     c49:	0b 54 50             	or     dx,WORD PTR [si+0x50]
     c4c:	61                   	popa
     c4d:	6e                   	outs   dx,BYTE PTR ds:[si]
     c4e:	65 6c                	gs ins BYTE PTR es:[di],dx
     c50:	42                   	inc    dx
     c51:	65 76 65             	gs jbe 0xcb9
     c54:	6c                   	ins    BYTE PTR es:[di],dx
     c55:	00 00                	add    BYTE PTR [bx+si],al
     c57:	00 00                	add    BYTE PTR [bx+si],al
     c59:	00 02                	add    BYTE PTR [bp+si],al
     c5b:	00 00                	add    BYTE PTR [bx+si],al
     c5d:	00 48 0c             	add    BYTE PTR [bx+si+0xc],cl
     c60:	23 0d                	and    cx,WORD PTR [di]
     c62:	06                   	push   es
     c63:	62 76 4e             	bound  si,DWORD PTR [bp+0x4e]
     c66:	6f                   	outs   dx,WORD PTR ds:[si]
     c67:	6e                   	outs   dx,BYTE PTR ds:[si]
     c68:	65 09 62 76          	or     WORD PTR gs:[bp+si+0x76],sp
     c6c:	4c                   	dec    sp
     c6d:	6f                   	outs   dx,WORD PTR ds:[si]
     c6e:	77 65                	ja     0xcd5
     c70:	72 65                	jb     0xcd7
     c72:	64 08 62 76          	or     BYTE PTR fs:[bp+si+0x76],ah
     c76:	52                   	push   dx
     c77:	61                   	popa
     c78:	69 73 65 64 01       	imul   si,WORD PTR [bp+di+0x65],0x164
     c7d:	0b 54 42             	or     dx,WORD PTR [si+0x42]
     c80:	65 76 65             	gs jbe 0xce8
     c83:	6c                   	ins    BYTE PTR es:[di],dx
     c84:	57                   	push   di
     c85:	69 64 74 68 02       	imul   sp,WORD PTR [si+0x74],0x268
     c8a:	01 00                	add    WORD PTR [bx+si],ax
     c8c:	00 00                	add    BYTE PTR [bx+si],al
     c8e:	ff                   	(bad)
     c8f:	7f 00                	jg     0xc91
     c91:	00 01                	add    BYTE PTR [bx+di],al
     c93:	0c 54                	or     al,0x54
     c95:	42                   	inc    dx
     c96:	6f                   	outs   dx,WORD PTR ds:[si]
     c97:	72 64                	jb     0xcfd
     c99:	65 72 57             	gs jb  0xcf3
     c9c:	69 64 74 68 02       	imul   sp,WORD PTR [si+0x74],0x268
     ca1:	00 00                	add    BYTE PTR [bx+si],al
     ca3:	00 00                	add    BYTE PTR [bx+si],al
     ca5:	ff                   	(bad)
     ca6:	7f 00                	jg     0xca8
     ca8:	00 6a 0d             	add    BYTE PTR [bp+si+0xd],ch
     cab:	00 00                	add    BYTE PTR [bx+si],al
     cad:	00 00                	add    BYTE PTR [bx+si],al
     caf:	56                   	push   si
     cb0:	0d 49 0d             	or     ax,0xd49
     cb3:	ed                   	in     ax,dx
     cb4:	00 f3                	add    bl,dh
     cb6:	08 7e 0d             	or     BYTE PTR [bp+0xd],bh
     cb9:	fa                   	cli
     cba:	45                   	inc    bp
     cbb:	2f                   	das
     cbc:	0d 9a 1f             	or     ax,0x1f9a
     cbf:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     cc0:	0d cb 1f             	or     ax,0x1fcb
     cc3:	bf 0c dc             	mov    di,0xdc0c
     cc6:	6c                   	ins    BYTE PTR es:[di],dx
     cc7:	1f                   	pop    ds
     cc8:	0d cd 11             	or     ax,0x11cd
     ccb:	d3 0c                	ror    WORD PTR [si],cl
     ccd:	89 29                	mov    WORD PTR [bx+di],bp
     ccf:	47                   	inc    di
     cd0:	0d fa 10             	or     ax,0x10fa
     cd3:	bf 0d d6             	mov    di,0xd60d
     cd6:	14 df                	adc    al,0xdf
     cd8:	0c f4                	or     al,0xf4
     cda:	4f                   	dec    di
     cdb:	eb 0c                	jmp    0xce9
     cdd:	32 16 07 0d          	xor    dl,BYTE PTR ds:0xd07
     ce1:	ec                   	in     al,dx
     ce2:	30 3f                	xor    BYTE PTR [bx],bh
     ce4:	0d 51 1b             	or     ax,0x1b51
     ce7:	b7 0c                	mov    bh,0xc
     ce9:	38 50 f3             	cmp    BYTE PTR [bx+si-0xd],dl
     cec:	0c 63                	or     al,0x63
     cee:	31 0f                	xor    WORD PTR [bx],cx
     cf0:	0d 21 50             	or     ax,0x5021
     cf3:	cb                   	retf
     cf4:	0c d5                	or     al,0xd5
     cf6:	27                   	daa
     cf7:	60                   	pusha
     cf8:	0d d9 62             	or     ax,0x62d9
     cfb:	ff 0c                	dec    WORD PTR [si]
     cfd:	06                   	push   es
     cfe:	63 03                	arpl   WORD PTR [bp+di],ax
     d00:	0d 8f 60             	or     ax,0x608f
     d03:	e3 0c                	jcxz   0xd11
     d05:	3a 1c                	cmp    bl,BYTE PTR [si]
     d07:	e7 0c                	out    0xc,ax
     d09:	46                   	inc    si
     d0a:	44                   	inc    sp
     d0b:	ef                   	out    dx,ax
     d0c:	0c 08                	or     al,0x8
     d0e:	61                   	popa
     d0f:	13 0d                	adc    cx,WORD PTR [di]
     d11:	5c                   	pop    sp
     d12:	61                   	popa
     d13:	17                   	pop    ss
     d14:	0d 62 5c             	or     ax,0x5c62
     d17:	43                   	inc    bx
     d18:	0d 3a 61             	or     ax,0x613a
     d1b:	d7                   	xlat   BYTE PTR ds:[bx]
     d1c:	0c 72                	or     al,0x72
     d1e:	3f                   	aas
     d1f:	27                   	daa
     d20:	0d 61 28             	or     ax,0x2861
     d23:	37                   	aaa
     d24:	0d 17 3e             	or     ax,0x3e17
     d27:	2b 0d                	sub    cx,WORD PTR [di]
     d29:	88 3c                	mov    BYTE PTR [si],bh
     d2b:	bb 0c ed             	mov    bx,0xed0c
     d2e:	3e 33 0d             	xor    cx,WORD PTR ds:[di]
     d31:	77 3e                	ja     0xd71
     d33:	fb                   	sti
     d34:	0c 1e                	or     al,0x1e
     d36:	29 cf                	sub    di,cx
     d38:	0c 26                	or     al,0x26
     d3a:	6d                   	ins    WORD PTR es:[di],dx
     d3b:	c7                   	(bad)
     d3c:	0c ae                	or     al,0xae
     d3e:	5f                   	pop    di
     d3f:	0b 0d                	or     cx,WORD PTR [di]
     d41:	35 62 1b             	xor    ax,0x1b62
     d44:	0d 43 2a             	or     ax,0x2a43
     d47:	f7 0c 0c 54          	test   WORD PTR [si],0x540c
     d4b:	43                   	inc    bx
     d4c:	75 73                	jne    0xdc1
     d4e:	74 6f                	je     0xdbf
     d50:	6d                   	ins    WORD PTR es:[di],dx
     d51:	50                   	push   ax
     d52:	61                   	popa
     d53:	6e                   	outs   dx,BYTE PTR ds:[si]
     d54:	65 6c                	gs ins BYTE PTR es:[di],dx
     d56:	03 00                	add    ax,WORD PTR [bx+si]
     d58:	12 0f                	adc    cl,BYTE PTR [bx]
     d5a:	05 00 ee             	add    ax,0xee00
     d5d:	ff                   	(bad)
     d5e:	b8 28 64             	mov    ax,0x6428
     d61:	0d f3 28             	or     ax,0x28f3
     d64:	68 0d cb             	push   0xcb0d
     d67:	28 7a 0d             	sub    BYTE PTR [bp+si+0xd],bh
     d6a:	07                   	pop    es
     d6b:	0c 54                	or     al,0x54
     d6d:	43                   	inc    bx
     d6e:	75 73                	jne    0xde3
     d70:	74 6f                	je     0xde1
     d72:	6d                   	ins    WORD PTR es:[di],dx
     d73:	50                   	push   ax
     d74:	61                   	popa
     d75:	6e                   	outs   dx,BYTE PTR ds:[si]
     d76:	65 6c                	gs ins BYTE PTR es:[di],dx
     d78:	c9                   	leave
     d79:	0c 07                	or     al,0x7
     d7b:	0e                   	push   cs
     d7c:	8a 09                	mov    cl,BYTE PTR [bx+di]
     d7e:	1f                   	pop    ds
     d7f:	0e                   	push   cs
     d80:	09 00                	or     WORD PTR [bx+si],ax
     d82:	08 45 78             	or     BYTE PTR [di+0x78],al
     d85:	74 43                	je     0xdca
     d87:	74 72                	je     0xdfb
     d89:	6c                   	ins    BYTE PTR es:[di],dx
     d8a:	73 00                	jae    0xd8c
     d8c:	00 34                	add    BYTE PTR [si],dh
     d8e:	0e                   	push   cs
     d8f:	00 00                	add    BYTE PTR [bx+si],al
     d91:	00 00                	add    BYTE PTR [bx+si],al
     d93:	00 00                	add    BYTE PTR [bx+si],al
     d95:	2d 0e ed             	sub    ax,0xed0e
     d98:	00 c9                	add    cl,cl
     d9a:	0c 3e                	or     al,0x3e
     d9c:	0e                   	push   cs
     d9d:	fa                   	cli
     d9e:	45                   	inc    bp
     d9f:	13 0e 9a 1f          	adc    cx,WORD PTR ds:0x1f9a
     da3:	88 0f                	mov    BYTE PTR [bx],cl
     da5:	cb                   	retf
     da6:	1f                   	pop    ds
     da7:	a3 0d dc             	mov    ds:0xdc0d,ax
     daa:	6c                   	ins    BYTE PTR es:[di],dx
     dab:	03 0e cd 11          	add    cx,WORD PTR ds:0x11cd
     daf:	b7 0d                	mov    bh,0xd
     db1:	89 29                	mov    WORD PTR [bx+di],bp
     db3:	2b 0e fa 10          	sub    cx,WORD PTR ds:0x10fa
     db7:	71 0e                	jno    0xdc7
     db9:	d6                   	(bad)
     dba:	14 c3                	adc    al,0xc3
     dbc:	0d f4 4f             	or     ax,0x4ff4
     dbf:	cf                   	iret
     dc0:	0d 32 16             	or     ax,0x1632
     dc3:	eb 0d                	jmp    0xdd2
     dc5:	ec                   	in     al,dx
     dc6:	30 23                	xor    BYTE PTR [bp+di],ah
     dc8:	0e                   	push   cs
     dc9:	51                   	push   cx
     dca:	1b 53 0e             	sbb    dx,WORD PTR [bp+di+0xe]
     dcd:	38 50 d7             	cmp    BYTE PTR [bx+si-0x29],dl
     dd0:	0d 63 31             	or     ax,0x3163
     dd3:	f3 0d 21 50          	repz or ax,0x5021
     dd7:	af                   	scas   ax,WORD PTR es:[di]
     dd8:	0d d5 27             	or     ax,0x27d5
     ddb:	9b                   	fwait
     ddc:	0d d9 62             	or     ax,0x62d9
     ddf:	e3 0d                	jcxz   0xdee
     de1:	06                   	push   es
     de2:	63 e7                	arpl   di,sp
     de4:	0d 8f 60             	or     ax,0x608f
     de7:	c7                   	(bad)
     de8:	0d 3a 1c             	or     ax,0x1c3a
     deb:	cb                   	retf
     dec:	0d 46 44             	or     ax,0x4446
     def:	d3 0d                	ror    WORD PTR [di],cl
     df1:	08 61 f7             	or     BYTE PTR [bx+di-0x9],ah
     df4:	0d 5c 61             	or     ax,0x615c
     df7:	fb                   	sti
     df8:	0d 62 5c             	or     ax,0x5c62
     dfb:	27                   	daa
     dfc:	0e                   	push   cs
     dfd:	3a 61 bb             	cmp    ah,BYTE PTR [bx+di-0x45]
     e00:	0d 72 3f             	or     ax,0x3f72
     e03:	0b 0e 61 28          	or     cx,WORD PTR ds:0x2861
     e07:	1b 0e 17 3e          	sbb    cx,WORD PTR ds:0x3e17
     e0b:	0f 0e                	femms
     e0d:	88 3c                	mov    BYTE PTR [si],bh
     e0f:	9f                   	lahf
     e10:	0d ed 3e             	or     ax,0x3eed
     e13:	17                   	pop    ss
     e14:	0e                   	push   cs
     e15:	77 3e                	ja     0xe55
     e17:	df 0d                	fisttp WORD PTR [di]
     e19:	1e                   	push   ds
     e1a:	29 b3 0d 26          	sub    WORD PTR [bp+di+0x260d],si
     e1e:	6d                   	ins    WORD PTR es:[di],dx
     e1f:	ab                   	stos   WORD PTR es:[di],ax
     e20:	0d ae 5f             	or     ax,0x5fae
     e23:	ef                   	out    dx,ax
     e24:	0d 35 62             	or     ax,0x6235
     e27:	ff 0d                	dec    WORD PTR [di]
     e29:	43                   	inc    bx
     e2a:	2a db                	sub    bl,bl
     e2c:	0d 06 54             	or     ax,0x5406
     e2f:	50                   	push   ax
     e30:	61                   	popa
     e31:	6e                   	outs   dx,BYTE PTR ds:[si]
     e32:	65 6c                	gs ins BYTE PTR es:[di],dx
     e34:	07                   	pop    es
     e35:	06                   	push   es
     e36:	54                   	push   sp
     e37:	50                   	push   ax
     e38:	61                   	popa
     e39:	6e                   	outs   dx,BYTE PTR ds:[si]
     e3a:	65 6c                	gs ins BYTE PTR es:[di],dx
     e3c:	ad                   	lods   ax,WORD PTR ds:[si]
     e3d:	0d 42 0e             	or     ax,0xe42
     e40:	6a 0d                	push   0xd
     e42:	79 0e                	jns    0xe52
     e44:	2c 00                	sub    al,0x0
     e46:	08 45 78             	or     BYTE PTR [di+0x78],al
     e49:	74 43                	je     0xe8e
     e4b:	74 72                	je     0xebf
     e4d:	6c                   	ins    BYTE PTR es:[di],dx
     e4e:	73 23                	jae    0xe73
     e50:	00 e2                	add    dl,ah
     e52:	00 5b 0e             	add    BYTE PTR [bp+di+0xe],bl
     e55:	2d 00 ff             	sub    ax,0xff00
     e58:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     e5b:	44                   	inc    sp
     e5c:	0f 01 00             	sgdtw  [bx+si]
     e5f:	00 00                	add    BYTE PTR [bx+si],al
     e61:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     e65:	00 00                	add    BYTE PTR [bx+si],al
     e67:	09 00                	or     WORD PTR [bx+si],ax
     e69:	05 41 6c             	add    ax,0x6c41
     e6c:	69 67 6e 02 00       	imul   sp,WORD PTR [bx+0x6e],0x2
     e71:	76 11                	jbe    0xe84
     e73:	ec                   	in     al,dx
     e74:	00 ff                	add    bh,bh
     e76:	ff                   	(bad)
     e77:	fe                   	(bad)
     e78:	2b 93 0e 01          	sub    dx,WORD PTR [bp+di+0x10e]
     e7c:	00 00                	add    BYTE PTR [bx+si],al
     e7e:	00 00                	add    BYTE PTR [bx+si],al
     e80:	80 02 00             	add    BYTE PTR [bp+si],0x0
     e83:	00 00                	add    BYTE PTR [bx+si],al
     e85:	0a 00                	or     al,BYTE PTR [bx+si]
     e87:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     e8a:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     e8f:	6e                   	outs   dx,BYTE PTR ds:[si]
     e90:	74 48                	je     0xeda
     e92:	0c 9b                	or     al,0x9b
     e94:	0e                   	push   cs
     e95:	dc 00                	fadd   QWORD PTR [bx+si]
     e97:	ff                   	(bad)
     e98:	ff 19                	call   DWORD PTR [bx+di]
     e9a:	2c b6                	sub    al,0xb6
     e9c:	0e                   	push   cs
     e9d:	01 00                	add    WORD PTR [bx+si],ax
     e9f:	00 00                	add    BYTE PTR [bx+si],al
     ea1:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     ea5:	00 00                	add    BYTE PTR [bx+si],al
     ea7:	0b 00                	or     ax,WORD PTR [bx+si]
     ea9:	0a 42 65             	or     al,BYTE PTR [bp+si+0x65]
     eac:	76 65                	jbe    0xf13
     eae:	6c                   	ins    BYTE PTR es:[di],dx
     eaf:	49                   	dec    cx
     eb0:	6e                   	outs   dx,BYTE PTR ds:[si]
     eb1:	6e                   	outs   dx,BYTE PTR ds:[si]
     eb2:	65 72 48             	gs jb  0xefd
     eb5:	0c be                	or     al,0xbe
     eb7:	0e                   	push   cs
     eb8:	dd 00                	fld    QWORD PTR [bx+si]
     eba:	ff                   	(bad)
     ebb:	ff                   	(bad)
     ebc:	3e 2c d9             	ds sub al,0xd9
     ebf:	0e                   	push   cs
     ec0:	01 00                	add    WORD PTR [bx+si],ax
     ec2:	00 00                	add    BYTE PTR [bx+si],al
     ec4:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     ec8:	00 00                	add    BYTE PTR [bx+si],al
     eca:	0c 00                	or     al,0x0
     ecc:	0a 42 65             	or     al,BYTE PTR [bp+si+0x65]
     ecf:	76 65                	jbe    0xf36
     ed1:	6c                   	ins    BYTE PTR es:[di],dx
     ed2:	4f                   	dec    di
     ed3:	75 74                	jne    0xf49
     ed5:	65 72 7c             	gs jb  0xf54
     ed8:	0c e1                	or     al,0xe1
     eda:	0e                   	push   cs
     edb:	de 00                	fiadd  WORD PTR [bx+si]
     edd:	ff                   	(bad)
     ede:	ff 63 2c             	jmp    WORD PTR [bp+di+0x2c]
     ee1:	fc                   	cld
     ee2:	0e                   	push   cs
     ee3:	01 00                	add    WORD PTR [bx+si],ax
     ee5:	00 00                	add    BYTE PTR [bx+si],al
     ee7:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     eeb:	00 00                	add    BYTE PTR [bx+si],al
     eed:	0d 00 0a             	or     ax,0xa00
     ef0:	42                   	inc    dx
     ef1:	65 76 65             	gs jbe 0xf59
     ef4:	6c                   	ins    BYTE PTR es:[di],dx
     ef5:	57                   	push   di
     ef6:	69 64 74 68 92       	imul   sp,WORD PTR [si+0x74],0x9268
     efb:	0c 04                	or     al,0x4
     efd:	0f e0 00             	pavgb  mm0,QWORD PTR [bx+si]
     f00:	ff                   	(bad)
     f01:	ff 88 2c 28          	dec    WORD PTR [bx+si+0x282c]
     f05:	0f 01 00             	sgdtw  [bx+si]
     f08:	00 00                	add    BYTE PTR [bx+si],al
     f0a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     f0e:	00 00                	add    BYTE PTR [bx+si],al
     f10:	0e                   	push   cs
     f11:	00 0b                	add    BYTE PTR [bp+di],cl
     f13:	42                   	inc    dx
     f14:	6f                   	outs   dx,WORD PTR ds:[si]
     f15:	72 64                	jb     0xf7b
     f17:	65 72 57             	gs jb  0xf71
     f1a:	69 64 74 68 d4       	imul   sp,WORD PTR [si+0x74],0xd468
     f1f:	02 fd                	add    bh,ch
     f21:	25 e2 00             	and    ax,0xe2
     f24:	ff                   	(bad)
     f25:	ff ad 2c 23          	jmp    DWORD PTR [di+0x232c]
     f29:	13 01                	adc    ax,WORD PTR [bx+di]
     f2b:	00 00                	add    BYTE PTR [bx+si],al
     f2d:	00 00                	add    BYTE PTR [bx+si],al
     f2f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     f32:	00 00                	add    BYTE PTR [bx+si],al
     f34:	0f 00 0b             	str    WORD PTR [bp+di]
     f37:	42                   	inc    dx
     f38:	6f                   	outs   dx,WORD PTR ds:[si]
     f39:	72 64                	jb     0xf9f
     f3b:	65 72 53             	gs jb  0xf91
     f3e:	74 79                	je     0xfb9
     f40:	6c                   	ins    BYTE PTR es:[di],dx
     f41:	65 64 00 67 0f       	gs add BYTE PTR fs:[bx+0xf],ah
     f46:	3e 00 ff             	ds add bh,bh
     f49:	ff                   	(bad)
     f4a:	3e 00 ff             	ds add bh,bh
     f4d:	ff 01                	inc    WORD PTR [bx+di]
     f4f:	00 00                	add    BYTE PTR [bx+si],al
     f51:	00 00                	add    BYTE PTR [bx+si],al
     f53:	80 f4 ff             	xor    ah,0xff
     f56:	ff                   	(bad)
     f57:	ff 10                	call   WORD PTR [bx+si]
     f59:	00 0a                	add    BYTE PTR [bp+si],cl
     f5b:	44                   	inc    sp
     f5c:	72 61                	jb     0xfbf
     f5e:	67 43                	addr32 inc bx
     f60:	75 72                	jne    0xfd4
     f62:	73 6f                	jae    0xfd3
     f64:	72 25                	jb     0xf8b
     f66:	01 90 0f 2e          	add    WORD PTR [bx+si+0x2e0f],dx
     f6a:	00 ff                	add    bh,bh
     f6c:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     f70:	ff 01                	inc    WORD PTR [bx+di]
     f72:	00 00                	add    BYTE PTR [bx+si],al
     f74:	00 00                	add    BYTE PTR [bx+si],al
     f76:	80 00 00             	add    BYTE PTR [bx+si],0x0
     f79:	00 00                	add    BYTE PTR [bx+si],al
     f7b:	11 00                	adc    WORD PTR [bx+si],ax
     f7d:	08 44 72             	or     BYTE PTR [si+0x72],al
     f80:	61                   	popa
     f81:	67 4d                	addr32 dec bp
     f83:	6f                   	outs   dx,WORD PTR ds:[si]
     f84:	64 65 07             	fs gs pop es
     f87:	23 e6                	and    sp,si
     f89:	0f 2a 00             	cvtpi2ps xmm0,QWORD PTR [bx+si]
     f8c:	ff                   	(bad)
     f8d:	ff                   	(bad)
     f8e:	b8 1c a8             	mov    ax,0xa81c
     f91:	0f 01 00             	sgdtw  [bx+si]
     f94:	00 00                	add    BYTE PTR [bx+si],al
     f96:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     f9a:	00 00                	add    BYTE PTR [bx+si],al
     f9c:	12 00                	adc    al,BYTE PTR [bx+si]
     f9e:	07                   	pop    es
     f9f:	45                   	inc    bp
     fa0:	6e                   	outs   dx,BYTE PTR ds:[si]
     fa1:	61                   	popa
     fa2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fa5:	64 66 01 ac 0f 53    	add    DWORD PTR fs:[si+0x530f],ebp
     fab:	1d b0 0f             	sbb    ax,0xfb0
     fae:	8c 1d                	mov    WORD PTR [di],ds
     fb0:	d0 0f                	ror    BYTE PTR [bx],1
     fb2:	01 00                	add    WORD PTR [bx+si],ax
     fb4:	00 00                	add    BYTE PTR [bx+si],al
     fb6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     fba:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     fbe:	07                   	pop    es
     fbf:	43                   	inc    bx
     fc0:	61                   	popa
     fc1:	70 74                	jo     0x1037
     fc3:	69 6f 6e 02 00       	imul   bp,WORD PTR [bx+0x6e],0x2
     fc8:	04 10                	add    al,0x10
     fca:	38 00                	cmp    BYTE PTR [bx+si],al
     fcc:	ff                   	(bad)
     fcd:	ff d5                	call   bp
     fcf:	1e                   	push   ds
     fd0:	d4 0f                	aam    0xf
     fd2:	17                   	pop    ss
     fd3:	1f                   	pop    ds
     fd4:	ee                   	out    dx,al
     fd5:	0f 00 80 f0 ff       	sldt   WORD PTR [bx+si-0x10]
     fda:	ff                   	(bad)
     fdb:	ff 14                	call   WORD PTR [si]
     fdd:	00 05                	add    BYTE PTR [di],al
     fdf:	43                   	inc    bx
     fe0:	6f                   	outs   dx,WORD PTR ds:[si]
     fe1:	6c                   	ins    BYTE PTR es:[di],dx
     fe2:	6f                   	outs   dx,WORD PTR ds:[si]
     fe3:	72 07                	jb     0xfec
     fe5:	23 21                	and    sp,WORD PTR [bx+di]
     fe7:	10 a5 00 ff          	adc    BYTE PTR [di-0x100],ah
     feb:	ff 22                	jmp    WORD PTR [bp+si]
     fed:	63 f2                	arpl   dx,si
     fef:	0f 54 63 0c          	andps  xmm4,XMMWORD PTR [bp+di+0xc]
     ff3:	10 00                	adc    BYTE PTR [bx+si],al
     ff5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ff8:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     ffc:	05 43 74             	add    ax,0x7443
     fff:	6c                   	ins    BYTE PTR es:[di],dx
    1000:	33 44 22             	xor    ax,WORD PTR [si+0x22]
    1003:	03 ed                	add    bp,bp
    1005:	14 34                	adc    al,0x34
    1007:	00 ff                	add    bh,bh
    1009:	ff                   	jmp    (bad)
    100a:	eb 1d                	jmp    0x1029
    100c:	10 10                	adc    BYTE PTR [bx+si],dl
    100e:	08 1e 48 10          	or     BYTE PTR ds:0x1048,bl
    1012:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1016:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
    101a:	04 46                	add    al,0x46
    101c:	6f                   	outs   dx,WORD PTR ds:[si]
    101d:	6e                   	outs   dx,BYTE PTR ds:[si]
    101e:	74 07                	je     0x1027
    1020:	23 40 10             	and    ax,WORD PTR [bx+si+0x10]
    1023:	e3 00                	jcxz   0x1025
    1025:	ff                   	(bad)
    1026:	ff e3                	jmp    bx
    1028:	00 ff                	add    bh,bh
    102a:	ff 01                	inc    WORD PTR [bx+di]
    102c:	00 00                	add    BYTE PTR [bx+si],al
    102e:	00 00                	add    BYTE PTR [bx+si],al
    1030:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1033:	00 00                	add    BYTE PTR [bx+si],al
    1035:	17                   	pop    ss
    1036:	00 06 4c 6f          	add    BYTE PTR ds:0x6f4c,al
    103a:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
    103d:	64 07                	fs pop es
    103f:	23 64 10             	and    sp,WORD PTR [si+0x10]
    1042:	2c 00                	sub    al,0x0
    1044:	ff                   	(bad)
    1045:	ff 32                	push   WORD PTR [bp+si]
    1047:	1f                   	pop    ds
    1048:	6c                   	ins    BYTE PTR es:[di],dx
    1049:	10 01                	adc    BYTE PTR [bx+di],al
    104b:	00 00                	add    BYTE PTR [bx+si],al
    104d:	00 00                	add    BYTE PTR [bx+si],al
    104f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1052:	00 00                	add    BYTE PTR [bx+si],al
    1054:	18 00                	sbb    BYTE PTR [bx+si],al
    1056:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    1059:	72 65                	jb     0x10c0
    105b:	6e                   	outs   dx,BYTE PTR ds:[si]
    105c:	74 43                	je     0x10a1
    105e:	6f                   	outs   dx,WORD PTR ds:[si]
    105f:	6c                   	ins    BYTE PTR es:[di],dx
    1060:	6f                   	outs   dx,WORD PTR ds:[si]
    1061:	72 07                	jb     0x106a
    1063:	23 88 10 a6          	and    cx,WORD PTR [bx+si-0x59f0]
    1067:	00 ff                	add    bh,bh
    1069:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    106c:	90                   	nop
    106d:	10 01                	adc    BYTE PTR [bx+di],al
    106f:	00 00                	add    BYTE PTR [bx+si],al
    1071:	00 00                	add    BYTE PTR [bx+si],al
    1073:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1076:	00 00                	add    BYTE PTR [bx+si],al
    1078:	19 00                	sbb    WORD PTR [bx+si],ax
    107a:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    107d:	72 65                	jb     0x10e4
    107f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1080:	74 43                	je     0x10c5
    1082:	74 6c                	je     0x10f0
    1084:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    1087:	23 ab 10 2b          	and    bp,WORD PTR [bp+di+0x2b10]
    108b:	00 ff                	add    bh,bh
    108d:	ff                   	(bad)
    108e:	3e 1e                	ds push ds
    1090:	b3 10                	mov    bl,0x10
    1092:	01 00                	add    WORD PTR [bx+si],ax
    1094:	00 00                	add    BYTE PTR [bx+si],al
    1096:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    109a:	00 00                	add    BYTE PTR [bx+si],al
    109c:	1a 00                	sbb    al,BYTE PTR [bx+si]
    109e:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
    10a1:	72 65                	jb     0x1108
    10a3:	6e                   	outs   dx,BYTE PTR ds:[si]
    10a4:	74 46                	je     0x10ec
    10a6:	6f                   	outs   dx,WORD PTR ds:[si]
    10a7:	6e                   	outs   dx,BYTE PTR ds:[si]
    10a8:	74 07                	je     0x10b1
    10aa:	23 f4                	and    si,sp
    10ac:	10 49 00             	adc    BYTE PTR [bx+di+0x0],cl
    10af:	ff                   	(bad)
    10b0:	ff a1 1e fc          	jmp    WORD PTR [bx+di-0x3e2]
    10b4:	10 01                	adc    BYTE PTR [bx+di],al
    10b6:	00 00                	add    BYTE PTR [bx+si],al
    10b8:	00 00                	add    BYTE PTR [bx+si],al
    10ba:	80 01 00             	add    BYTE PTR [bx+di],0x0
    10bd:	00 00                	add    BYTE PTR [bx+si],al
    10bf:	1b 00                	sbb    ax,WORD PTR [bx+si]
    10c1:	0e                   	push   cs
    10c2:	50                   	push   ax
    10c3:	61                   	popa
    10c4:	72 65                	jb     0x112b
    10c6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10c7:	74 53                	je     0x111c
    10c9:	68 6f 77             	push   0x776f
    10cc:	48                   	dec    ax
    10cd:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    10d2:	9c                   	pushf
    10d3:	16                   	push   ss
    10d4:	40                   	inc    ax
    10d5:	00 ff                	add    bh,bh
    10d7:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    10da:	ff                   	(bad)
    10db:	ff 01                	inc    WORD PTR [bx+di]
    10dd:	00 00                	add    BYTE PTR [bx+si],al
    10df:	00 00                	add    BYTE PTR [bx+si],al
    10e1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10e4:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    10e8:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    10eb:	70 75                	jo     0x1162
    10ed:	70 4d                	jo     0x113c
    10ef:	65 6e                	outs   dx,BYTE PTR gs:[si]
    10f1:	75 07                	jne    0x10fa
    10f3:	23 36 11 48          	and    si,WORD PTR ds:0x4811
    10f7:	00 ff                	add    bh,bh
    10f9:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    10fc:	00 11                	add    BYTE PTR [bx+di],dl
    10fe:	23 1e 15 11          	and    bx,WORD PTR ds:0x1115
    1102:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1106:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    110a:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    110d:	6f                   	outs   dx,WORD PTR ds:[si]
    110e:	77 48                	ja     0x1158
    1110:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
    1115:	19 11                	sbb    WORD PTR [bx+di],dx
    1117:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    1118:	63 1d                	arpl   WORD PTR [di],bx
    111a:	11 60 64             	adc    WORD PTR [bx+si+0x64],sp
    111d:	3e 11 01             	adc    WORD PTR ds:[bx+di],ax
    1120:	00 00                	add    BYTE PTR [bx+si],al
    1122:	00 00                	add    BYTE PTR [bx+si],al
    1124:	80 ff ff             	cmp    bh,0xff
    1127:	ff                   	(bad)
    1128:	ff 1e 00 08          	call   DWORD PTR ds:0x800
    112c:	54                   	push   sp
    112d:	61                   	popa
    112e:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    1131:	64 65 72 07          	fs gs jb 0x113c
    1135:	23 56 11             	and    dx,WORD PTR [bp+0x11]
    1138:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1139:	00 ff                	add    bh,bh
    113b:	ff 88 64 5e          	dec    WORD PTR [bx+si+0x5e64]
    113f:	11 01                	adc    WORD PTR [bx+di],ax
    1141:	00 00                	add    BYTE PTR [bx+si],al
    1143:	00 00                	add    BYTE PTR [bx+si],al
    1145:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1148:	00 00                	add    BYTE PTR [bx+si],al
    114a:	1f                   	pop    ds
    114b:	00 07                	add    BYTE PTR [bx],al
    114d:	54                   	push   sp
    114e:	61                   	popa
    114f:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    1152:	6f                   	outs   dx,WORD PTR ds:[si]
    1153:	70 07                	jo     0x115c
    1155:	23 03                	and    ax,WORD PTR [bp+di]
    1157:	13 29                	adc    bp,WORD PTR [bx+di]
    1159:	00 ff                	add    bh,bh
    115b:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    115e:	b9 11 01             	mov    cx,0x111
    1161:	00 00                	add    BYTE PTR [bx+si],al
    1163:	00 00                	add    BYTE PTR [bx+si],al
    1165:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1168:	00 00                	add    BYTE PTR [bx+si],al
    116a:	20 00                	and    BYTE PTR [bx+si],al
    116c:	07                   	pop    es
    116d:	56                   	push   si
    116e:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    1173:	65 71 00             	gs jno 0x1176
    1176:	96                   	xchg   si,ax
    1177:	11 7a 00             	adc    WORD PTR [bp+si+0x0],di
    117a:	ff                   	(bad)
    117b:	ff                   	(bad)
    117c:	7a 00                	jp     0x117e
    117e:	ff                   	(bad)
    117f:	ff 01                	inc    WORD PTR [bx+di]
    1181:	00 00                	add    BYTE PTR [bx+si],al
    1183:	00 00                	add    BYTE PTR [bx+si],al
    1185:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1188:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    118c:	07                   	pop    es
    118d:	4f                   	dec    di
    118e:	6e                   	outs   dx,BYTE PTR ds:[si]
    118f:	43                   	inc    bx
    1190:	6c                   	ins    BYTE PTR es:[di],dx
    1191:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    1196:	21 12                	and    WORD PTR [bp+si],dx
    1198:	82 00 ff             	add    BYTE PTR [bx+si],0xff
    119b:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    119f:	ff 01                	inc    WORD PTR [bx+di]
    11a1:	00 00                	add    BYTE PTR [bx+si],al
    11a3:	00 00                	add    BYTE PTR [bx+si],al
    11a5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    11a8:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    11ac:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    11af:	44                   	inc    sp
    11b0:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    11b3:	6c                   	ins    BYTE PTR es:[di],dx
    11b4:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    11b9:	dc 11                	fcom   QWORD PTR [bx+di]
    11bb:	62 00                	bound  ax,DWORD PTR [bx+si]
    11bd:	ff                   	(bad)
    11be:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    11c1:	ff                   	(bad)
    11c2:	ff 01                	inc    WORD PTR [bx+di]
    11c4:	00 00                	add    BYTE PTR [bx+si],al
    11c6:	00 00                	add    BYTE PTR [bx+si],al
    11c8:	80 00 00             	add    BYTE PTR [bx+si],0x0
    11cb:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    11cf:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    11d2:	44                   	inc    sp
    11d3:	72 61                	jb     0x1236
    11d5:	67 44                	addr32 inc sp
    11d7:	72 6f                	jb     0x1248
    11d9:	70 80                	jo     0x115b
    11db:	02 ff                	add    bh,bh
    11dd:	11 6a 00             	adc    WORD PTR [bp+si+0x0],bp
    11e0:	ff                   	(bad)
    11e1:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    11e4:	ff                   	(bad)
    11e5:	ff 01                	inc    WORD PTR [bx+di]
    11e7:	00 00                	add    BYTE PTR [bx+si],al
    11e9:	00 00                	add    BYTE PTR [bx+si],al
    11eb:	80 00 00             	add    BYTE PTR [bx+si],0x0
    11ee:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    11f2:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    11f5:	44                   	inc    sp
    11f6:	72 61                	jb     0x1259
    11f8:	67 4f                	addr32 dec di
    11fa:	76 65                	jbe    0x1261
    11fc:	72 32                	jb     0x1230
    11fe:	03 60 12             	add    sp,WORD PTR [bx+si+0x12]
    1201:	72 00                	jb     0x1203
    1203:	ff                   	(bad)
    1204:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    1207:	ff                   	(bad)
    1208:	ff 01                	inc    WORD PTR [bx+di]
    120a:	00 00                	add    BYTE PTR [bx+si],al
    120c:	00 00                	add    BYTE PTR [bx+si],al
    120e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1211:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    1215:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    1218:	45                   	inc    bp
    1219:	6e                   	outs   dx,BYTE PTR ds:[si]
    121a:	64 44                	fs inc sp
    121c:	72 61                	jb     0x127f
    121e:	67 71 00             	addr32 jno 0x1221
    1221:	41                   	inc    cx
    1222:	12 c8                	adc    cl,al
    1224:	00 ff                	add    bh,bh
    1226:	ff c8                	dec    ax
    1228:	00 ff                	add    bh,bh
    122a:	ff 01                	inc    WORD PTR [bx+di]
    122c:	00 00                	add    BYTE PTR [bx+si],al
    122e:	00 00                	add    BYTE PTR [bx+si],al
    1230:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1233:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    1237:	07                   	pop    es
    1238:	4f                   	dec    di
    1239:	6e                   	outs   dx,BYTE PTR ds:[si]
    123a:	45                   	inc    bp
    123b:	6e                   	outs   dx,BYTE PTR ds:[si]
    123c:	74 65                	je     0x12a3
    123e:	72 71                	jb     0x12b1
    1240:	00 ca                	add    dl,cl
    1242:	12 d0                	adc    dl,al
    1244:	00 ff                	add    bh,bh
    1246:	ff d0                	call   ax
    1248:	00 ff                	add    bh,bh
    124a:	ff 01                	inc    WORD PTR [bx+di]
    124c:	00 00                	add    BYTE PTR [bx+si],al
    124e:	00 00                	add    BYTE PTR [bx+si],al
    1250:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1253:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    1257:	06                   	push   es
    1258:	4f                   	dec    di
    1259:	6e                   	outs   dx,BYTE PTR ds:[si]
    125a:	45                   	inc    bp
    125b:	78 69                	js     0x12c6
    125d:	74 71                	je     0x12d0
    125f:	01 84 12 4a          	add    WORD PTR [si+0x4a12],ax
    1263:	00 ff                	add    bh,bh
    1265:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    1268:	ff                   	(bad)
    1269:	ff 01                	inc    WORD PTR [bx+di]
    126b:	00 00                	add    BYTE PTR [bx+si],al
    126d:	00 00                	add    BYTE PTR [bx+si],al
    126f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1272:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    1276:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    1279:	4d                   	dec    bp
    127a:	6f                   	outs   dx,WORD PTR ds:[si]
    127b:	75 73                	jne    0x12f0
    127d:	65 44                	gs inc sp
    127f:	6f                   	outs   dx,WORD PTR ds:[si]
    1280:	77 6e                	ja     0x12f0
    1282:	ce                   	into
    1283:	01 a8 12 52          	add    WORD PTR [bx+si+0x5212],bp
    1287:	00 ff                	add    bh,bh
    1289:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    128c:	ff                   	(bad)
    128d:	ff 01                	inc    WORD PTR [bx+di]
    128f:	00 00                	add    BYTE PTR [bx+si],al
    1291:	00 00                	add    BYTE PTR [bx+si],al
    1293:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1296:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
    129a:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    129d:	4d                   	dec    bp
    129e:	6f                   	outs   dx,WORD PTR ds:[si]
    129f:	75 73                	jne    0x1314
    12a1:	65 4d                	gs dec bp
    12a3:	6f                   	outs   dx,WORD PTR ds:[si]
    12a4:	76 65                	jbe    0x130b
    12a6:	71 01                	jno    0x12a9
    12a8:	7b 13                	jnp    0x12bd
    12aa:	5a                   	pop    dx
    12ab:	00 ff                	add    bh,bh
    12ad:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    12b0:	ff                   	(bad)
    12b1:	ff 01                	inc    WORD PTR [bx+di]
    12b3:	00 00                	add    BYTE PTR [bx+si],al
    12b5:	00 00                	add    BYTE PTR [bx+si],al
    12b7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    12ba:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
    12be:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    12c1:	4d                   	dec    bp
    12c2:	6f                   	outs   dx,WORD PTR ds:[si]
    12c3:	75 73                	jne    0x1338
    12c5:	65 55                	gs push bp
    12c7:	70 71                	jo     0x133a
    12c9:	00 1b                	add    BYTE PTR [bp+di],bl
    12cb:	13 e4                	adc    sp,sp
    12cd:	00 ff                	add    bh,bh
    12cf:	ff e4                	jmp    sp
    12d1:	00 ff                	add    bh,bh
    12d3:	ff 01                	inc    WORD PTR [bx+di]
    12d5:	00 00                	add    BYTE PTR [bx+si],al
    12d7:	00 00                	add    BYTE PTR [bx+si],al
    12d9:	80 00 00             	add    BYTE PTR [bx+si],0x0
    12dc:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
    12e0:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
    12e3:	52                   	push   dx
    12e4:	65 73 69             	gs jae 0x1350
    12e7:	7a 65                	jp     0x134e
    12e9:	b3 13                	mov    bl,0x13
    12eb:	00 00                	add    BYTE PTR [bx+si],al
    12ed:	00 00                	add    BYTE PTR [bx+si],al
    12ef:	9f                   	lahf
    12f0:	13 8d 13 ea          	adc    cx,WORD PTR [di-0x15ed]
    12f4:	00 22                	add    BYTE PTR [bp+si],ah
    12f6:	00 cc                	add    ah,cl
    12f8:	13 fa                	adc    di,dx
    12fa:	45                   	inc    bp
    12fb:	6f                   	outs   dx,WORD PTR ds:[si]
    12fc:	13 9a 1f f5          	adc    bx,WORD PTR [bp+si-0xae1]
    1300:	13 cb                	adc    cx,bx
    1302:	1f                   	pop    ds
    1303:	ff 12                	call   WORD PTR [bp+si]
    1305:	04 30                	add    al,0x30
    1307:	a9 13 cd             	test   ax,0xcd13
    130a:	11 13                	adc    WORD PTR [bp+di],dx
    130c:	13 3a                	adc    di,WORD PTR [bp+si]
    130e:	27                   	daa
    130f:	17                   	pop    ss
    1310:	13 fa                	adc    di,dx
    1312:	10 0d                	adc    BYTE PTR [di],cl
    1314:	14 d6                	adc    al,0xd6
    1316:	14 1f                	adc    al,0x1f
    1318:	13 f4                	adc    si,sp
    131a:	4f                   	dec    di
    131b:	2b 13                	sub    dx,WORD PTR [bp+di]
    131d:	32 16 47 13          	xor    dl,BYTE PTR ds:0x1347
    1321:	2d 32 8b             	sub    ax,0x8b32
    1324:	13 51 1b             	adc    dx,WORD PTR [bx+di+0x1b]
    1327:	6d                   	ins    WORD PTR es:[di],dx
    1328:	14 38                	adc    al,0x38
    132a:	50                   	push   ax
    132b:	33 13                	xor    dx,WORD PTR [bp+di]
    132d:	63 31                	arpl   WORD PTR [bx+di],si
    132f:	4f                   	dec    di
    1330:	13 21                	adc    sp,WORD PTR [bx+di]
    1332:	50                   	push   ax
    1333:	0b 13                	or     dx,WORD PTR [bp+di]
    1335:	58                   	pop    ax
    1336:	2f                   	das
    1337:	07                   	pop    es
    1338:	13 d9                	adc    bx,cx
    133a:	62 3f                	bound  di,DWORD PTR [bx]
    133c:	13 06 63 43          	adc    ax,WORD PTR ds:0x4363
    1340:	13 8f 60 7f          	adc    cx,WORD PTR [bx+0x7f60]
    1344:	13 3a                	adc    di,WORD PTR [bp+si]
    1346:	1c 27                	sbb    al,0x27
    1348:	13 46 44             	adc    ax,WORD PTR [bp+0x44]
    134b:	2f                   	das
    134c:	13 08                	adc    cx,WORD PTR [bx+si]
    134e:	61                   	popa
    134f:	53                   	push   bx
    1350:	13 5c 61             	adc    bx,WORD PTR [si+0x61]
    1353:	57                   	push   di
    1354:	13 62 5c             	adc    sp,WORD PTR [bp+si+0x5c]
    1357:	83 13 3a             	adc    WORD PTR [bp+di],0x3a
    135a:	61                   	popa
    135b:	0f 13 72 3f          	movlps QWORD PTR [bp+si+0x3f],xmm6
    135f:	63 13                	arpl   WORD PTR [bp+di],dx
    1361:	29 3b                	sub    WORD PTR [bp+di],di
    1363:	67 13 17             	adc    dx,WORD PTR [edi]
    1366:	3e 6b 13 88          	imul   dx,WORD PTR ds:[bp+di],0xff88
    136a:	3c fb                	cmp    al,0xfb
    136c:	12 ed                	adc    ch,ch
    136e:	3e 73 13             	ds jae 0x1384
    1371:	77 3e                	ja     0x13b1
    1373:	3b 13                	cmp    dx,WORD PTR [bp+di]
    1375:	7c 3f                	jl     0x13b6
    1377:	87 13                	xchg   WORD PTR [bp+di],dx
    1379:	26 6d                	es ins WORD PTR es:[di],dx
    137b:	5f                   	pop    di
    137c:	13 ae 5f 4b          	adc    bp,WORD PTR [bp+0x4b5f]
    1380:	13 35                	adc    si,WORD PTR [di]
    1382:	62 5b 13             	bound  bx,DWORD PTR [bp+di+0x13]
    1385:	f0 3f                	lock aas
    1387:	f7 12                	not    WORD PTR [bp+si]
    1389:	22 35                	and    dh,BYTE PTR [di]
    138b:	37                   	aaa
    138c:	13 11                	adc    dx,WORD PTR [bx+di]
    138e:	54                   	push   sp
    138f:	43                   	inc    bx
    1390:	75 73                	jne    0x1405
    1392:	74 6f                	je     0x1403
    1394:	6d                   	ins    WORD PTR es:[di],dx
    1395:	52                   	push   dx
    1396:	61                   	popa
    1397:	64 69 6f 47 72 6f    	imul   bp,WORD PTR fs:[bx+0x47],0x6f72
    139d:	75 70                	jne    0x140f
    139f:	03 00                	add    ax,WORD PTR [bx+si]
    13a1:	0c 0f                	or     al,0xf
    13a3:	0e                   	push   cs
    13a4:	0f 05                	syscall
    13a6:	00 7f 34             	add    BYTE PTR [bx+0x34],bh
    13a9:	ad                   	lods   ax,WORD PTR ds:[si]
    13aa:	13 e0                	adc    sp,ax
    13ac:	34 b1                	xor    al,0xb1
    13ae:	13 01                	adc    ax,WORD PTR [bx+di]
    13b0:	35 c8 13             	xor    ax,0x13c8
    13b3:	07                   	pop    es
    13b4:	11 54 43             	adc    WORD PTR [si+0x43],dx
    13b7:	75 73                	jne    0x142c
    13b9:	74 6f                	je     0x142a
    13bb:	6d                   	ins    WORD PTR es:[di],dx
    13bc:	52                   	push   dx
    13bd:	61                   	popa
    13be:	64 69 6f 47 72 6f    	imul   bp,WORD PTR fs:[bx+0x47],0x6f72
    13c4:	75 70                	jne    0x1436
    13c6:	09 13                	or     WORD PTR [bp+di],dx
    13c8:	15 14 c6             	adc    ax,0xc614
    13cb:	00 69 14             	add    BYTE PTR [bx+di+0x14],ch
    13ce:	09 00                	or     WORD PTR [bx+si],ax
    13d0:	08 45 78             	or     BYTE PTR [di+0x78],al
    13d3:	74 43                	je     0x1418
    13d5:	74 72                	je     0x1449
    13d7:	6c                   	ins    BYTE PTR es:[di],dx
    13d8:	73 00                	jae    0x13da
    13da:	00 8b 14 00          	add    BYTE PTR [bp+di+0x14],cl
    13de:	00 00                	add    BYTE PTR [bx+si],al
    13e0:	00 00                	add    BYTE PTR [bx+si],al
    13e2:	00 7f 14             	add    BYTE PTR [bx+0x14],bh
    13e5:	ea 00 09 13 9a       	jmp    0x9a13:0x900
    13ea:	14 fa                	adc    al,0xfa
    13ec:	45                   	inc    bp
    13ed:	61                   	popa
    13ee:	14 9a                	adc    al,0x9a
    13f0:	1f                   	pop    ds
    13f1:	0b 15                	or     dx,WORD PTR [di]
    13f3:	cb                   	retf
    13f4:	1f                   	pop    ds
    13f5:	f1                   	int1
    13f6:	13 04                	adc    ax,WORD PTR [si]
    13f8:	30 e9                	xor    cl,ch
    13fa:	13 cd                	adc    cx,bp
    13fc:	11 05                	adc    WORD PTR [di],ax
    13fe:	14 3a                	adc    al,0x3a
    1400:	27                   	daa
    1401:	09 14                	or     WORD PTR [si],dx
    1403:	fa                   	cli
    1404:	10 ec                	adc    ah,ch
    1406:	15 d6 14             	adc    ax,0x14d6
    1409:	11 14                	adc    WORD PTR [si],dx
    140b:	f4                   	hlt
    140c:	4f                   	dec    di
    140d:	1d 14 32             	sbb    ax,0x3214
    1410:	16                   	push   ss
    1411:	39 14                	cmp    WORD PTR [si],dx
    1413:	2d 32 7d             	sub    ax,0x7d32
    1416:	14 51                	adc    al,0x51
    1418:	1b af 14 38          	sbb    bp,WORD PTR [bx+0x3814]
    141c:	50                   	push   ax
    141d:	25 14 63             	and    ax,0x6314
    1420:	31 41 14             	xor    WORD PTR [bx+di+0x14],ax
    1423:	21 50 fd             	and    WORD PTR [bx+si-0x3],dx
    1426:	13 58 2f             	adc    bx,WORD PTR [bx+si+0x2f]
    1429:	f9                   	stc
    142a:	13 d9                	adc    bx,cx
    142c:	62 31                	bound  si,DWORD PTR [bx+di]
    142e:	14 06                	adc    al,0x6
    1430:	63 35                	arpl   WORD PTR [di],si
    1432:	14 8f                	adc    al,0x8f
    1434:	60                   	pusha
    1435:	71 14                	jno    0x144b
    1437:	3a 1c                	cmp    bl,BYTE PTR [si]
    1439:	19 14                	sbb    WORD PTR [si],dx
    143b:	46                   	inc    si
    143c:	44                   	inc    sp
    143d:	21 14                	and    WORD PTR [si],dx
    143f:	08 61 45             	or     BYTE PTR [bx+di+0x45],ah
    1442:	14 5c                	adc    al,0x5c
    1444:	61                   	popa
    1445:	49                   	dec    cx
    1446:	14 62                	adc    al,0x62
    1448:	5c                   	pop    sp
    1449:	75 14                	jne    0x145f
    144b:	3a 61 01             	cmp    ah,BYTE PTR [bx+di+0x1]
    144e:	14 72                	adc    al,0x72
    1450:	3f                   	aas
    1451:	55                   	push   bp
    1452:	14 29                	adc    al,0x29
    1454:	3b 59 14             	cmp    bx,WORD PTR [bx+di+0x14]
    1457:	17                   	pop    ss
    1458:	3e 5d                	ds pop bp
    145a:	14 88                	adc    al,0x88
    145c:	3c ed                	cmp    al,0xed
    145e:	13 ed                	adc    bp,bp
    1460:	3e 65 14 77          	ds gs adc al,0x77
    1464:	3e 2d 14 7c          	ds sub ax,0x7c14
    1468:	3f                   	aas
    1469:	79 14                	jns    0x147f
    146b:	26 6d                	es ins WORD PTR es:[di],dx
    146d:	51                   	push   cx
    146e:	14 ae                	adc    al,0xae
    1470:	5f                   	pop    di
    1471:	3d 14 35             	cmp    ax,0x3514
    1474:	62 4d 14             	bound  cx,DWORD PTR [di+0x14]
    1477:	f0 3f                	lock aas
    1479:	4a                   	dec    dx
    147a:	2d 22 35             	sub    ax,0x3522
    147d:	29 14                	sub    WORD PTR [si],dx
    147f:	0b 54 52             	or     dx,WORD PTR [si+0x52]
    1482:	61                   	popa
    1483:	64 69 6f 47 72 6f    	imul   bp,WORD PTR fs:[bx+0x47],0x6f72
    1489:	75 70                	jne    0x14fb
    148b:	07                   	pop    es
    148c:	0b 54 52             	or     dx,WORD PTR [si+0x52]
    148f:	61                   	popa
    1490:	64 69 6f 47 72 6f    	imul   bp,WORD PTR fs:[bx+0x47],0x6f72
    1496:	75 70                	jne    0x1508
    1498:	fb                   	sti
    1499:	13 9e 14 b3          	adc    bx,WORD PTR [bp-0x4cec]
    149d:	13 13                	adc    dx,WORD PTR [bp+di]
    149f:	15 23 00             	adc    ax,0x23
    14a2:	08 45 78             	or     BYTE PTR [di+0x78],al
    14a5:	74 43                	je     0x14ea
    14a7:	74 72                	je     0x151b
    14a9:	6c                   	ins    BYTE PTR es:[di],dx
    14aa:	73 1a                	jae    0x14c6
    14ac:	00 e2                	add    dl,ah
    14ae:	00 b7 14 2d          	add    BYTE PTR [bx+0x2d14],dh
    14b2:	00 ff                	add    bh,bh
    14b4:	ff 72 16             	push   WORD PTR [bp+si+0x16]
    14b7:	cd 14                	int    0x14
    14b9:	01 00                	add    WORD PTR [bx+si],ax
    14bb:	00 00                	add    BYTE PTR [bx+si],al
    14bd:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    14c1:	00 00                	add    BYTE PTR [bx+si],al
    14c3:	09 00                	or     WORD PTR [bx+si],ax
    14c5:	05 41 6c             	add    ax,0x6c41
    14c8:	69 67 6e 66 01       	imul   sp,WORD PTR [bx+0x6e],0x166
    14cd:	d1 14                	rcl    WORD PTR [si],1
    14cf:	53                   	push   bx
    14d0:	1d d5 14             	sbb    ax,0x14d5
    14d3:	8c 1d                	mov    WORD PTR [di],ds
    14d5:	f5                   	cmc
    14d6:	14 01                	adc    al,0x1
    14d8:	00 00                	add    BYTE PTR [bx+si],al
    14da:	00 00                	add    BYTE PTR [bx+si],al
    14dc:	80 00 00             	add    BYTE PTR [bx+si],0x0
    14df:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
    14e3:	07                   	pop    es
    14e4:	43                   	inc    bx
    14e5:	61                   	popa
    14e6:	70 74                	jo     0x155c
    14e8:	69 6f 6e 02 00       	imul   bp,WORD PTR [bx+0x6e],0x2
    14ed:	ad                   	lods   ax,WORD PTR ds:[si]
    14ee:	15 38 00             	adc    ax,0x38
    14f1:	ff                   	(bad)
    14f2:	ff d5                	call   bp
    14f4:	1e                   	push   ds
    14f5:	f9                   	stc
    14f6:	14 17                	adc    al,0x17
    14f8:	1f                   	pop    ds
    14f9:	33 15                	xor    dx,WORD PTR [di]
    14fb:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
    14ff:	ff                   	(bad)
    1500:	ff 0b                	dec    WORD PTR [bp+di]
    1502:	00 05                	add    BYTE PTR [di],al
    1504:	43                   	inc    bx
    1505:	6f                   	outs   dx,WORD PTR ds:[si]
    1506:	6c                   	ins    BYTE PTR es:[di],dx
    1507:	6f                   	outs   dx,WORD PTR ds:[si]
    1508:	72 d4                	jb     0x14de
    150a:	22 2b                	and    ch,BYTE PTR [bp+di]
    150c:	15 e6 00             	adc    ax,0xe6
    150f:	ff                   	(bad)
    1510:	ff b7 32 d2          	push   WORD PTR [bx-0x2dce]
    1514:	15 01 00             	adc    ax,0x1
    1517:	00 00                	add    BYTE PTR [bx+si],al
    1519:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    151d:	00 00                	add    BYTE PTR [bx+si],al
    151f:	0c 00                	or     al,0x0
    1521:	07                   	pop    es
    1522:	43                   	inc    bx
    1523:	6f                   	outs   dx,WORD PTR ds:[si]
    1524:	6c                   	ins    BYTE PTR es:[di],dx
    1525:	75 6d                	jne    0x1594
    1527:	6e                   	outs   dx,BYTE PTR ds:[si]
    1528:	73 07                	jae    0x1531
    152a:	23 8d 15 a5          	and    cx,WORD PTR [di-0x5aeb]
    152e:	00 ff                	add    bh,bh
    1530:	ff 22                	jmp    WORD PTR [bp+si]
    1532:	63 37                	arpl   WORD PTR [bx],si
    1534:	15 54 63             	adc    ax,0x6354
    1537:	49                   	dec    cx
    1538:	15 00 80             	adc    ax,0x8000
    153b:	00 00                	add    BYTE PTR [bx+si],al
    153d:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
    1541:	05 43 74             	add    ax,0x7443
    1544:	6c                   	ins    BYTE PTR es:[di],dx
    1545:	33 44 64             	xor    ax,WORD PTR [si+0x64]
    1548:	00 6c 15             	add    BYTE PTR [si+0x15],ch
    154b:	3e 00 ff             	ds add bh,bh
    154e:	ff                   	(bad)
    154f:	3e 00 ff             	ds add bh,bh
    1552:	ff 01                	inc    WORD PTR [bx+di]
    1554:	00 00                	add    BYTE PTR [bx+si],al
    1556:	00 00                	add    BYTE PTR [bx+si],al
    1558:	80 f4 ff             	xor    ah,0xff
    155b:	ff                   	(bad)
    155c:	ff 0e 00 0a          	dec    WORD PTR ds:0xa00
    1560:	44                   	inc    sp
    1561:	72 61                	jb     0x15c4
    1563:	67 43                	addr32 inc bx
    1565:	75 72                	jne    0x15d9
    1567:	73 6f                	jae    0x15d8
    1569:	72 25                	jb     0x1590
    156b:	01 95 15 2e          	add    WORD PTR [di+0x2e15],dx
    156f:	00 ff                	add    bh,bh
    1571:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    1575:	ff 01                	inc    WORD PTR [bx+di]
    1577:	00 00                	add    BYTE PTR [bx+si],al
    1579:	00 00                	add    BYTE PTR [bx+si],al
    157b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    157e:	00 00                	add    BYTE PTR [bx+si],al
    1580:	0f 00 08             	str    WORD PTR [bx+si]
    1583:	44                   	inc    sp
    1584:	72 61                	jb     0x15e7
    1586:	67 4d                	addr32 dec bp
    1588:	6f                   	outs   dx,WORD PTR ds:[si]
    1589:	64 65 07             	fs gs pop es
    158c:	23 ca                	and    cx,dx
    158e:	15 2a 00             	adc    ax,0x2a
    1591:	ff                   	(bad)
    1592:	ff                   	(bad)
    1593:	b8 1c b5             	mov    ax,0xb51c
    1596:	15 01 00             	adc    ax,0x1
    1599:	00 00                	add    BYTE PTR [bx+si],al
    159b:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    159f:	00 00                	add    BYTE PTR [bx+si],al
    15a1:	10 00                	adc    BYTE PTR [bx+si],al
    15a3:	07                   	pop    es
    15a4:	45                   	inc    bp
    15a5:	6e                   	outs   dx,BYTE PTR ds:[si]
    15a6:	61                   	popa
    15a7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    15aa:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
    15ad:	55                   	push   bp
    15ae:	18 34                	sbb    BYTE PTR [si],dh
    15b0:	00 ff                	add    bh,bh
    15b2:	ff                   	jmp    (bad)
    15b3:	eb 1d                	jmp    0x15d2
    15b5:	b9 15 08             	mov    cx,0x815
    15b8:	1e                   	push   ds
    15b9:	12 16 00 80          	adc    dl,BYTE PTR ds:0x8000
    15bd:	00 00                	add    BYTE PTR [bx+si],al
    15bf:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
    15c3:	04 46                	add    al,0x46
    15c5:	6f                   	outs   dx,WORD PTR ds:[si]
    15c6:	6e                   	outs   dx,BYTE PTR ds:[si]
    15c7:	74 d4                	je     0x159d
    15c9:	22 0a                	and    cl,BYTE PTR [bp+si]
    15cb:	16                   	push   ss
    15cc:	e4 00                	in     al,0x0
    15ce:	ff                   	(bad)
    15cf:	ff f0                	push   ax
    15d1:	32 f4                	xor    dh,ah
    15d3:	15 01 00             	adc    ax,0x1
    15d6:	00 00                	add    BYTE PTR [bx+si],al
    15d8:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    15dc:	ff                   	(bad)
    15dd:	ff 12                	call   WORD PTR [bp+si]
    15df:	00 09                	add    BYTE PTR [bx+di],cl
    15e1:	49                   	dec    cx
    15e2:	74 65                	je     0x1649
    15e4:	6d                   	ins    WORD PTR es:[di],dx
    15e5:	49                   	dec    cx
    15e6:	6e                   	outs   dx,BYTE PTR ds:[si]
    15e7:	64 65 78 8b          	fs gs js 0x1576
    15eb:	03 40 17             	add    ax,WORD PTR [bx+si+0x17]
    15ee:	e0 00                	loopne 0x15f0
    15f0:	ff                   	(bad)
    15f1:	ff 9d 33 93          	call   DWORD PTR [di-0x6ccd]
    15f5:	19 01                	sbb    WORD PTR [bx+di],ax
    15f7:	00 00                	add    BYTE PTR [bx+si],al
    15f9:	00 00                	add    BYTE PTR [bx+si],al
    15fb:	80 00 00             	add    BYTE PTR [bx+si],0x0
    15fe:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    1602:	05 49 74             	add    ax,0x7449
    1605:	65 6d                	gs ins WORD PTR es:[di],dx
    1607:	73 07                	jae    0x1610
    1609:	23 2e 16 2c          	and    bp,WORD PTR ds:0x2c16
    160d:	00 ff                	add    bh,bh
    160f:	ff 32                	push   WORD PTR [bp+si]
    1611:	1f                   	pop    ds
    1612:	36 16                	ss push ss
    1614:	01 00                	add    WORD PTR [bx+si],ax
    1616:	00 00                	add    BYTE PTR [bx+si],al
    1618:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    161c:	00 00                	add    BYTE PTR [bx+si],al
    161e:	14 00                	adc    al,0x0
    1620:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    1623:	72 65                	jb     0x168a
    1625:	6e                   	outs   dx,BYTE PTR ds:[si]
    1626:	74 43                	je     0x166b
    1628:	6f                   	outs   dx,WORD PTR ds:[si]
    1629:	6c                   	ins    BYTE PTR es:[di],dx
    162a:	6f                   	outs   dx,WORD PTR ds:[si]
    162b:	72 07                	jb     0x1634
    162d:	23 52 16             	and    dx,WORD PTR [bp+si+0x16]
    1630:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    1631:	00 ff                	add    bh,bh
    1633:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    1636:	5a                   	pop    dx
    1637:	16                   	push   ss
    1638:	01 00                	add    WORD PTR [bx+si],ax
    163a:	00 00                	add    BYTE PTR [bx+si],al
    163c:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1640:	00 00                	add    BYTE PTR [bx+si],al
    1642:	15 00 0b             	adc    ax,0xb00
    1645:	50                   	push   ax
    1646:	61                   	popa
    1647:	72 65                	jb     0x16ae
    1649:	6e                   	outs   dx,BYTE PTR ds:[si]
    164a:	74 43                	je     0x168f
    164c:	74 6c                	je     0x16ba
    164e:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    1651:	23 75 16             	and    si,WORD PTR [di+0x16]
    1654:	2b 00                	sub    ax,WORD PTR [bx+si]
    1656:	ff                   	(bad)
    1657:	ff                   	(bad)
    1658:	3e 1e                	ds push ds
    165a:	7d 16                	jge    0x1672
    165c:	01 00                	add    WORD PTR [bx+si],ax
    165e:	00 00                	add    BYTE PTR [bx+si],al
    1660:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1664:	00 00                	add    BYTE PTR [bx+si],al
    1666:	16                   	push   ss
    1667:	00 0a                	add    BYTE PTR [bp+si],cl
    1669:	50                   	push   ax
    166a:	61                   	popa
    166b:	72 65                	jb     0x16d2
    166d:	6e                   	outs   dx,BYTE PTR ds:[si]
    166e:	74 46                	je     0x16b6
    1670:	6f                   	outs   dx,WORD PTR ds:[si]
    1671:	6e                   	outs   dx,BYTE PTR ds:[si]
    1672:	74 07                	je     0x167b
    1674:	23 be 16 49          	and    di,WORD PTR [bp+0x4916]
    1678:	00 ff                	add    bh,bh
    167a:	ff a1 1e c6          	jmp    WORD PTR [bx+di-0x39e2]
    167e:	16                   	push   ss
    167f:	01 00                	add    WORD PTR [bx+si],ax
    1681:	00 00                	add    BYTE PTR [bx+si],al
    1683:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1687:	00 00                	add    BYTE PTR [bx+si],al
    1689:	17                   	pop    ss
    168a:	00 0e 50 61          	add    BYTE PTR ds:0x6150,cl
    168e:	72 65                	jb     0x16f5
    1690:	6e                   	outs   dx,BYTE PTR ds:[si]
    1691:	74 53                	je     0x16e6
    1693:	68 6f 77             	push   0x776f
    1696:	48                   	dec    ax
    1697:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    169c:	ff                   	(bad)
    169d:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    16a0:	ff                   	(bad)
    16a1:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    16a4:	ff                   	(bad)
    16a5:	ff 01                	inc    WORD PTR [bx+di]
    16a7:	00 00                	add    BYTE PTR [bx+si],al
    16a9:	00 00                	add    BYTE PTR [bx+si],al
    16ab:	80 00 00             	add    BYTE PTR [bx+si],0x0
    16ae:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
    16b2:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    16b5:	70 75                	jo     0x172c
    16b7:	70 4d                	jo     0x1706
    16b9:	65 6e                	outs   dx,BYTE PTR gs:[si]
    16bb:	75 07                	jne    0x16c4
    16bd:	23 00                	and    ax,WORD PTR [bx+si]
    16bf:	17                   	pop    ss
    16c0:	48                   	dec    ax
    16c1:	00 ff                	add    bh,bh
    16c3:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    16c6:	ca 16 23             	retf   0x2316
    16c9:	1e                   	push   ds
    16ca:	df 16 00 80          	fist   WORD PTR ds:0x8000
    16ce:	00 00                	add    BYTE PTR [bx+si],al
    16d0:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
    16d4:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    16d7:	6f                   	outs   dx,WORD PTR ds:[si]
    16d8:	77 48                	ja     0x1722
    16da:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
    16df:	e3 16                	jcxz   0x16f7
    16e1:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    16e2:	63 e7                	arpl   di,sp
    16e4:	16                   	push   ss
    16e5:	60                   	pusha
    16e6:	64 08 17             	or     BYTE PTR fs:[bx],dl
    16e9:	01 00                	add    WORD PTR [bx+si],ax
    16eb:	00 00                	add    BYTE PTR [bx+si],al
    16ed:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    16f1:	ff                   	(bad)
    16f2:	ff 1a                	call   DWORD PTR [bp+si]
    16f4:	00 08                	add    BYTE PTR [bx+si],cl
    16f6:	54                   	push   sp
    16f7:	61                   	popa
    16f8:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    16fb:	64 65 72 07          	fs gs jb 0x1706
    16ff:	23 20                	and    sp,WORD PTR [bx+si]
    1701:	17                   	pop    ss
    1702:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1703:	00 ff                	add    bh,bh
    1705:	ff 88 64 28          	dec    WORD PTR [bx+si+0x2864]
    1709:	17                   	pop    ss
    170a:	01 00                	add    WORD PTR [bx+si],ax
    170c:	00 00                	add    BYTE PTR [bx+si],al
    170e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1712:	00 00                	add    BYTE PTR [bx+si],al
    1714:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1716:	07                   	pop    es
    1717:	54                   	push   sp
    1718:	61                   	popa
    1719:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    171c:	6f                   	outs   dx,WORD PTR ds:[si]
    171d:	70 07                	jo     0x1726
    171f:	23 43 19             	and    ax,WORD PTR [bp+di+0x19]
    1722:	29 00                	sub    WORD PTR [bx+si],ax
    1724:	ff                   	(bad)
    1725:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    1728:	60                   	pusha
    1729:	17                   	pop    ss
    172a:	01 00                	add    WORD PTR [bx+si],ax
    172c:	00 00                	add    BYTE PTR [bx+si],al
    172e:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1732:	00 00                	add    BYTE PTR [bx+si],al
    1734:	1c 00                	sbb    al,0x0
    1736:	07                   	pop    es
    1737:	56                   	push   si
    1738:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    173d:	65 71 00             	gs jno 0x1740
    1740:	c8 17 7a 00          	enter  0x7a17,0x0
    1744:	ff                   	(bad)
    1745:	ff                   	(bad)
    1746:	7a 00                	jp     0x1748
    1748:	ff                   	(bad)
    1749:	ff 01                	inc    WORD PTR [bx+di]
    174b:	00 00                	add    BYTE PTR [bx+si],al
    174d:	00 00                	add    BYTE PTR [bx+si],al
    174f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1752:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    1756:	07                   	pop    es
    1757:	4f                   	dec    di
    1758:	6e                   	outs   dx,BYTE PTR ds:[si]
    1759:	43                   	inc    bx
    175a:	6c                   	ins    BYTE PTR es:[di],dx
    175b:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    1760:	83 17 62             	adc    WORD PTR [bx],0x62
    1763:	00 ff                	add    bh,bh
    1765:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    1768:	ff                   	(bad)
    1769:	ff 01                	inc    WORD PTR [bx+di]
    176b:	00 00                	add    BYTE PTR [bx+si],al
    176d:	00 00                	add    BYTE PTR [bx+si],al
    176f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1772:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    1776:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1779:	44                   	inc    sp
    177a:	72 61                	jb     0x17dd
    177c:	67 44                	addr32 inc sp
    177e:	72 6f                	jb     0x17ef
    1780:	70 80                	jo     0x1702
    1782:	02 a6 17 6a          	add    ah,BYTE PTR [bp+0x6a17]
    1786:	00 ff                	add    bh,bh
    1788:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    178b:	ff                   	(bad)
    178c:	ff 01                	inc    WORD PTR [bx+di]
    178e:	00 00                	add    BYTE PTR [bx+si],al
    1790:	00 00                	add    BYTE PTR [bx+si],al
    1792:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1795:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    1799:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    179c:	44                   	inc    sp
    179d:	72 61                	jb     0x1800
    179f:	67 4f                	addr32 dec di
    17a1:	76 65                	jbe    0x1808
    17a3:	72 32                	jb     0x17d7
    17a5:	03 56 19             	add    dx,WORD PTR [bp+0x19]
    17a8:	72 00                	jb     0x17aa
    17aa:	ff                   	(bad)
    17ab:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    17ae:	ff                   	(bad)
    17af:	ff 01                	inc    WORD PTR [bx+di]
    17b1:	00 00                	add    BYTE PTR [bx+si],al
    17b3:	00 00                	add    BYTE PTR [bx+si],al
    17b5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    17b8:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    17bc:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    17bf:	45                   	inc    bp
    17c0:	6e                   	outs   dx,BYTE PTR ds:[si]
    17c1:	64 44                	fs inc sp
    17c3:	72 61                	jb     0x1826
    17c5:	67 71 00             	addr32 jno 0x17c8
    17c8:	e8 17 c8             	call   0xdfe2
    17cb:	00 ff                	add    bh,bh
    17cd:	ff c8                	dec    ax
    17cf:	00 ff                	add    bh,bh
    17d1:	ff 01                	inc    WORD PTR [bx+di]
    17d3:	00 00                	add    BYTE PTR [bx+si],al
    17d5:	00 00                	add    BYTE PTR [bx+si],al
    17d7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    17da:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    17de:	07                   	pop    es
    17df:	4f                   	dec    di
    17e0:	6e                   	outs   dx,BYTE PTR ds:[si]
    17e1:	45                   	inc    bp
    17e2:	6e                   	outs   dx,BYTE PTR ds:[si]
    17e3:	74 65                	je     0x184a
    17e5:	72 71                	jb     0x1858
    17e7:	00 13                	add    BYTE PTR [bp+di],dl
    17e9:	1f                   	pop    ds
    17ea:	d0 00                	rol    BYTE PTR [bx+si],1
    17ec:	ff                   	(bad)
    17ed:	ff d0                	call   ax
    17ef:	00 ff                	add    bh,bh
    17f1:	ff 01                	inc    WORD PTR [bx+di]
    17f3:	00 00                	add    BYTE PTR [bx+si],al
    17f5:	00 00                	add    BYTE PTR [bx+si],al
    17f7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    17fa:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    17fe:	06                   	push   es
    17ff:	4f                   	dec    di
    1800:	6e                   	outs   dx,BYTE PTR ds:[si]
    1801:	45                   	inc    bp
    1802:	78 69                	js     0x186d
    1804:	74 c8                	je     0x17ce
    1806:	1c 00                	sbb    al,0x0
    1808:	00 8b 7e 04          	add    BYTE PTR [bp+di+0x47e],cl
    180c:	36 c4 7d 14          	les    di,DWORD PTR ss:[di+0x14]
    1810:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1813:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1816:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1819:	36 c4 7d 10          	les    di,DWORD PTR ss:[di+0x10]
    181d:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    1820:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    1823:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1827:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    182a:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    182e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1831:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1834:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1837:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    183b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    183e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1841:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    1845:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    1849:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    184c:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1850:	06                   	push   es
    1851:	57                   	push   di
    1852:	9a da 13 8e 18       	call   0x188e:0x13da
    1857:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    185a:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    185d:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    1860:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    1863:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    1866:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1869:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    186d:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1870:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    1873:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1876:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1879:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    187c:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    187f:	8d 7e e4             	lea    di,[bp-0x1c]
    1882:	16                   	push   ss
    1883:	57                   	push   di
    1884:	6a 02                	push   0x2
    1886:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1889:	06                   	push   es
    188a:	57                   	push   di
    188b:	9a e1 1d a7 18       	call   0x18a7:0x1de1
    1890:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1893:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    1897:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    189b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    189e:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    18a2:	06                   	push   es
    18a3:	57                   	push   di
    18a4:	9a da 13 e4 18       	call   0x18e4:0x13da
    18a9:	ff 4e f8             	dec    WORD PTR [bp-0x8]
    18ac:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    18af:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    18b2:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    18b5:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    18b8:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    18bb:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    18bf:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    18c3:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    18c6:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    18c9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    18cc:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    18cf:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    18d2:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    18d5:	8d 7e e4             	lea    di,[bp-0x1c]
    18d8:	16                   	push   ss
    18d9:	57                   	push   di
    18da:	6a 02                	push   0x2
    18dc:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    18df:	06                   	push   es
    18e0:	57                   	push   di
    18e1:	9a e1 1d fb 18       	call   0x18fb:0x1de1
    18e6:	c9                   	leave
    18e7:	c2 02 00             	ret    0x2
    18ea:	55                   	push   bp
    18eb:	89 e5                	mov    bp,sp
    18ed:	6a 01                	push   0x1
    18ef:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    18f2:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    18f6:	06                   	push   es
    18f7:	57                   	push   di
    18f8:	9a f5 14 77 19       	call   0x1977:0x14f5
    18fd:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1900:	26 ff 4d 06          	dec    WORD PTR es:[di+0x6]
    1904:	26 ff 4d 04          	dec    WORD PTR es:[di+0x4]
    1908:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    190c:	7e 17                	jle    0x1925
    190e:	ff 4e 06             	dec    WORD PTR [bp+0x6]
    1911:	55                   	push   bp
    1912:	e8 f0 fe             	call   0x1805
    1915:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1918:	06                   	push   es
    1919:	57                   	push   di
    191a:	6a ff                	push   0xffff
    191c:	6a ff                	push   0xffff
    191e:	9a 62 29 00 00       	call   0x0:0x2962
    1923:	eb e3                	jmp    0x1908
    1925:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1928:	26 ff 45 06          	inc    WORD PTR es:[di+0x6]
    192c:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
    1930:	c9                   	leave
    1931:	ca 12 00             	retf   0x12
    1934:	55                   	push   bp
    1935:	89 e5                	mov    bp,sp
    1937:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    193b:	74 08                	je     0x1945
    193d:	83 ec 08             	sub    sp,0x8
    1940:	9a e2 1f 0b 1a       	call   0x1a0b:0x1fe2
    1945:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1948:	ff 76 0c             	push   WORD PTR [bp+0xc]
    194b:	31 c0                	xor    ax,ax
    194d:	50                   	push   ax
    194e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1951:	06                   	push   es
    1952:	57                   	push   di
    1953:	9a 86 68 62 19       	call   0x1962:0x6886
    1958:	6a 41                	push   0x41
    195a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    195d:	06                   	push   es
    195e:	57                   	push   di
    195f:	9a bf 17 6e 19       	call   0x196e:0x17bf
    1964:	6a 41                	push   0x41
    1966:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1969:	06                   	push   es
    196a:	57                   	push   di
    196b:	9a e1 17 27 1a       	call   0x1a27:0x17e1
    1970:	b0 01                	mov    al,0x1
    1972:	50                   	push   ax
    1973:	b8 11 04             	mov    ax,0x411
    1976:	ba 7e 19             	mov    dx,0x197e
    1979:	52                   	push   dx
    197a:	50                   	push   ax
    197b:	9a a4 12 b1 19       	call   0x19b1:0x12a4
    1980:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1983:	26 89 85 90 00       	mov    WORD PTR es:[di+0x90],ax
    1988:	26 89 95 92 00       	mov    WORD PTR es:[di+0x92],dx
    198d:	06                   	push   es
    198e:	57                   	push   di
    198f:	b8 bb 1b             	mov    ax,0x1bbb
    1992:	ba cd 19             	mov    dx,0x19cd
    1995:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    199a:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    199e:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    19a2:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    19a6:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    19aa:	b0 01                	mov    al,0x1
    19ac:	50                   	push   ax
    19ad:	b8 d4 04             	mov    ax,0x4d4
    19b0:	ba b8 19             	mov    dx,0x19b8
    19b3:	52                   	push   dx
    19b4:	50                   	push   ax
    19b5:	9a 27 15 6b 1a       	call   0x1a6b:0x1527
    19ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19bd:	26 89 85 94 00       	mov    WORD PTR es:[di+0x94],ax
    19c2:	26 89 95 96 00       	mov    WORD PTR es:[di+0x96],dx
    19c7:	06                   	push   es
    19c8:	57                   	push   di
    19c9:	b8 bb 1b             	mov    ax,0x1bbb
    19cc:	ba 6f 1d             	mov    dx,0x1d6f
    19cf:	26 c4 bd 94 00       	les    di,DWORD PTR es:[di+0x94]
    19d4:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    19d8:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    19dc:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    19e0:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    19e4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    19e8:	74 07                	je     0x19f1
    19ea:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    19ee:	83 c4 06             	add    sp,0x6
    19f1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    19f4:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    19f7:	c9                   	leave
    19f8:	ca 0a 00             	retf   0xa
    19fb:	55                   	push   bp
    19fc:	89 e5                	mov    bp,sp
    19fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a01:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    1a06:	06                   	push   es
    1a07:	57                   	push   di
    1a08:	9a 7f 1f 1a 1a       	call   0x1a1a:0x1f7f
    1a0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a10:	26 c4 bd 94 00       	les    di,DWORD PTR es:[di+0x94]
    1a15:	06                   	push   es
    1a16:	57                   	push   di
    1a17:	9a 7f 1f 32 1a       	call   0x1a32:0x1f7f
    1a1c:	31 c0                	xor    ax,ax
    1a1e:	50                   	push   ax
    1a1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a22:	06                   	push   es
    1a23:	57                   	push   di
    1a24:	9a f0 68 51 1c       	call   0x1c51:0x68f0
    1a29:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1a2d:	74 05                	je     0x1a34
    1a2f:	9a 0f 20 3e 1c       	call   0x1c3e:0x200f
    1a34:	c9                   	leave
    1a35:	ca 06 00             	retf   0x6
    1a38:	45                   	inc    bp
    1a39:	1b 45 1b             	sbb    ax,WORD PTR [di+0x1b]
    1a3c:	65 1b 65 1b          	sbb    sp,WORD PTR gs:[di+0x1b]
    1a40:	99                   	cwd
    1a41:	1b 99 1b c8          	sbb    bx,WORD PTR [bx+di-0x37e5]
    1a45:	0e                   	push   cs
    1a46:	00 00                	add    BYTE PTR [bx+si],al
    1a48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a4b:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1a50:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1a53:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    1a56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a59:	26 ff b5 92 00       	push   WORD PTR es:[di+0x92]
    1a5e:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    1a63:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1a66:	06                   	push   es
    1a67:	57                   	push   di
    1a68:	9a b6 20 82 1a       	call   0x1a82:0x20b6
    1a6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a70:	26 ff b5 96 00       	push   WORD PTR es:[di+0x96]
    1a75:	26 ff b5 94 00       	push   WORD PTR es:[di+0x94]
    1a7a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1a7d:	06                   	push   es
    1a7e:	57                   	push   di
    1a7f:	9a d3 20 90 1a       	call   0x1a90:0x20d3
    1a84:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1a87:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1a8b:	06                   	push   es
    1a8c:	57                   	push   di
    1a8d:	9a dc 14 ad 1a       	call   0x1aad:0x14dc
    1a92:	99                   	cwd
    1a93:	b9 02 00             	mov    cx,0x2
    1a96:	f7 f9                	idiv   cx
    1a98:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a9b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a9e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1aa1:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1aa4:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1aa8:	06                   	push   es
    1aa9:	57                   	push   di
    1aaa:	9a dc 14 ca 1a       	call   0x1aca:0x14dc
    1aaf:	8b d0                	mov    dx,ax
    1ab1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ab4:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1ab8:	2b c2                	sub    ax,dx
    1aba:	40                   	inc    ax
    1abb:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1abe:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1ac1:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1ac5:	06                   	push   es
    1ac6:	57                   	push   di
    1ac7:	9a dc 14 61 1b       	call   0x1b61:0x14dc
    1acc:	8b d0                	mov    dx,ax
    1ace:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad1:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1ad5:	2b c2                	sub    ax,dx
    1ad7:	40                   	inc    ax
    1ad8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1adb:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1ade:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1ae1:	7d 08                	jge    0x1aeb
    1ae3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1ae6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1ae9:	eb 06                	jmp    0x1af1
    1aeb:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1aee:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1af1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1af4:	26 8a 85 8e 00       	mov    al,BYTE PTR es:[di+0x8e]
    1af9:	3c 01                	cmp    al,0x1
    1afb:	74 08                	je     0x1b05
    1afd:	3c 03                	cmp    al,0x3
    1aff:	74 04                	je     0x1b05
    1b01:	3c 05                	cmp    al,0x5
    1b03:	75 2a                	jne    0x1b2f
    1b05:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b08:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    1b0b:	99                   	cwd
    1b0c:	b9 02 00             	mov    cx,0x2
    1b0f:	f7 f9                	idiv   cx
    1b11:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    1b14:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1b17:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    1b1a:	99                   	cwd
    1b1b:	b9 02 00             	mov    cx,0x2
    1b1e:	f7 f9                	idiv   cx
    1b20:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    1b23:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b26:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1b29:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b2c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b32:	26 8a 85 8e 00       	mov    al,BYTE PTR es:[di+0x8e]
    1b37:	3c 05                	cmp    al,0x5
    1b39:	77 7c                	ja     0x1bb7
    1b3b:	98                   	cbw
    1b3c:	89 c3                	mov    bx,ax
    1b3e:	d1 e3                	shl    bx,1
    1b40:	2e ff a7 38 1a       	jmp    WORD PTR cs:[bx+0x1a38]
    1b45:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b48:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b4b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b4e:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1b51:	50                   	push   ax
    1b52:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b55:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    1b58:	50                   	push   ax
    1b59:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b5c:	06                   	push   es
    1b5d:	57                   	push   di
    1b5e:	9a 22 1e 95 1b       	call   0x1b95:0x1e22
    1b63:	eb 52                	jmp    0x1bb7
    1b65:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b68:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b6b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b6e:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1b71:	50                   	push   ax
    1b72:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b75:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    1b78:	50                   	push   ax
    1b79:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b7c:	99                   	cwd
    1b7d:	b9 04 00             	mov    cx,0x4
    1b80:	f7 f9                	idiv   cx
    1b82:	50                   	push   ax
    1b83:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b86:	99                   	cwd
    1b87:	b9 04 00             	mov    cx,0x4
    1b8a:	f7 f9                	idiv   cx
    1b8c:	50                   	push   ax
    1b8d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b90:	06                   	push   es
    1b91:	57                   	push   di
    1b92:	9a 76 1e b5 1b       	call   0x1bb5:0x1e76
    1b97:	eb 1e                	jmp    0x1bb7
    1b99:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b9c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b9f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ba2:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1ba5:	50                   	push   ax
    1ba6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ba9:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    1bac:	50                   	push   ax
    1bad:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1bb0:	06                   	push   es
    1bb1:	57                   	push   di
    1bb2:	9a a2 1c 9b 1c       	call   0x1c9b:0x1ca2
    1bb7:	c9                   	leave
    1bb8:	ca 04 00             	retf   0x4
    1bbb:	55                   	push   bp
    1bbc:	89 e5                	mov    bp,sp
    1bbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc1:	06                   	push   es
    1bc2:	57                   	push   di
    1bc3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bc6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1bca:	c9                   	leave
    1bcb:	ca 08 00             	retf   0x8
    1bce:	55                   	push   bp
    1bcf:	89 e5                	mov    bp,sp
    1bd1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bd4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bda:	26 c4 bd 94 00       	les    di,DWORD PTR es:[di+0x94]
    1bdf:	06                   	push   es
    1be0:	57                   	push   di
    1be1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1be4:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1be8:	c9                   	leave
    1be9:	ca 08 00             	retf   0x8
    1bec:	55                   	push   bp
    1bed:	89 e5                	mov    bp,sp
    1bef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bf2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf8:	26 c4 bd 90 00       	les    di,DWORD PTR es:[di+0x90]
    1bfd:	06                   	push   es
    1bfe:	57                   	push   di
    1bff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c02:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1c06:	c9                   	leave
    1c07:	ca 08 00             	retf   0x8
    1c0a:	55                   	push   bp
    1c0b:	89 e5                	mov    bp,sp
    1c0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c10:	26 8a 85 8e 00       	mov    al,BYTE PTR es:[di+0x8e]
    1c15:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1c18:	74 11                	je     0x1c2b
    1c1a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1c1d:	26 88 85 8e 00       	mov    BYTE PTR es:[di+0x8e],al
    1c22:	06                   	push   es
    1c23:	57                   	push   di
    1c24:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c27:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1c2b:	c9                   	leave
    1c2c:	ca 06 00             	retf   0x6
    1c2f:	55                   	push   bp
    1c30:	89 e5                	mov    bp,sp
    1c32:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1c36:	74 08                	je     0x1c40
    1c38:	83 ec 08             	sub    sp,0x8
    1c3b:	9a e2 1f 37 1d       	call   0x1d37:0x1fe2
    1c40:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c43:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c46:	31 c0                	xor    ax,ax
    1c48:	50                   	push   ax
    1c49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c4c:	06                   	push   es
    1c4d:	57                   	push   di
    1c4e:	9a 86 68 5d 1c       	call   0x1c5d:0x6886
    1c53:	6a 69                	push   0x69
    1c55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c58:	06                   	push   es
    1c59:	57                   	push   di
    1c5a:	9a bf 17 69 1c       	call   0x1c69:0x17bf
    1c5f:	6a 69                	push   0x69
    1c61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c64:	06                   	push   es
    1c65:	57                   	push   di
    1c66:	9a e1 17 4a 1d       	call   0x1d4a:0x17e1
    1c6b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1c6f:	74 07                	je     0x1c78
    1c71:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1c75:	83 c4 06             	add    sp,0x6
    1c78:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1c7b:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1c7e:	c9                   	leave
    1c7f:	ca 0a 00             	retf   0xa
    1c82:	c8 04 00 00          	enter  0x4,0x0
    1c86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c89:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1c8d:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1c91:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1c96:	06                   	push   es
    1c97:	57                   	push   di
    1c98:	9a 99 20 b6 1c       	call   0x1cb6:0x2099
    1c9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca0:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    1ca4:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    1ca8:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1cad:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1cb1:	06                   	push   es
    1cb2:	57                   	push   di
    1cb3:	9a 84 16 d8 1c       	call   0x1cd8:0x1684
    1cb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cbb:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    1cc0:	74 41                	je     0x1d03
    1cc2:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1cc7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1cca:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1ccd:	6a 01                	push   0x1
    1ccf:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1cd3:	06                   	push   es
    1cd4:	57                   	push   di
    1cd5:	9a b0 14 e8 1c       	call   0x1ce8:0x14b0
    1cda:	6a 01                	push   0x1
    1cdc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1cdf:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1ce3:	06                   	push   es
    1ce4:	57                   	push   di
    1ce5:	9a 7c 17 01 1d       	call   0x1d01:0x177c
    1cea:	6a 00                	push   0x0
    1cec:	6a 00                	push   0x0
    1cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf1:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1cf5:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1cf9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1cfc:	06                   	push   es
    1cfd:	57                   	push   di
    1cfe:	9a 22 1e 53 1d       	call   0x1d53:0x1e22
    1d03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d06:	26 8b 85 90 00       	mov    ax,WORD PTR es:[di+0x90]
    1d0b:	09 c0                	or     ax,ax
    1d0d:	74 15                	je     0x1d24
    1d0f:	ff 76 08             	push   WORD PTR [bp+0x8]
    1d12:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d15:	26 ff b5 94 00       	push   WORD PTR es:[di+0x94]
    1d1a:	26 ff b5 92 00       	push   WORD PTR es:[di+0x92]
    1d1f:	26 ff 9d 8e 00       	call   DWORD PTR es:[di+0x8e]
    1d24:	c9                   	leave
    1d25:	ca 04 00             	retf   0x4
    1d28:	55                   	push   bp
    1d29:	89 e5                	mov    bp,sp
    1d2b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1d2f:	74 08                	je     0x1d39
    1d31:	83 ec 08             	sub    sp,0x8
    1d34:	9a e2 1f 5a 1d       	call   0x1d5a:0x1fe2
    1d39:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1d3c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d3f:	31 c0                	xor    ax,ax
    1d41:	50                   	push   ax
    1d42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d45:	06                   	push   es
    1d46:	57                   	push   di
    1d47:	9a 86 68 90 1d       	call   0x1d90:0x6886
    1d4c:	b0 01                	mov    al,0x1
    1d4e:	50                   	push   ax
    1d4f:	b8 c6 06             	mov    ax,0x6c6
    1d52:	ba 00 1e             	mov    dx,0x1e00
    1d55:	52                   	push   dx
    1d56:	50                   	push   ax
    1d57:	9a 50 1f c5 1d       	call   0x1dc5:0x1f50
    1d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d5f:	26 89 85 8e 00       	mov    WORD PTR es:[di+0x8e],ax
    1d64:	26 89 95 90 00       	mov    WORD PTR es:[di+0x90],dx
    1d69:	06                   	push   es
    1d6a:	57                   	push   di
    1d6b:	b8 08 21             	mov    ax,0x2108
    1d6e:	ba 92 1f             	mov    dx,0x1f92
    1d71:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1d76:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1d7a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    1d7e:	26 8f 45 0c          	pop    WORD PTR es:[di+0xc]
    1d82:	26 8f 45 0e          	pop    WORD PTR es:[di+0xe]
    1d86:	6a 69                	push   0x69
    1d88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d8b:	06                   	push   es
    1d8c:	57                   	push   di
    1d8d:	9a e1 17 9c 1d       	call   0x1d9c:0x17e1
    1d92:	6a 69                	push   0x69
    1d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d97:	06                   	push   es
    1d98:	57                   	push   di
    1d99:	9a bf 17 d2 1d       	call   0x1dd2:0x17bf
    1d9e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1da2:	74 07                	je     0x1dab
    1da4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1da8:	83 c4 06             	add    sp,0x6
    1dab:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1dae:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1db1:	c9                   	leave
    1db2:	ca 0a 00             	retf   0xa
    1db5:	55                   	push   bp
    1db6:	89 e5                	mov    bp,sp
    1db8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dbb:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1dc0:	06                   	push   es
    1dc1:	57                   	push   di
    1dc2:	9a 7f 1f dd 1d       	call   0x1ddd:0x1f7f
    1dc7:	31 c0                	xor    ax,ax
    1dc9:	50                   	push   ax
    1dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dcd:	06                   	push   es
    1dce:	57                   	push   di
    1dcf:	9a f0 68 71 20       	call   0x2071:0x68f0
    1dd4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1dd8:	74 05                	je     0x1ddf
    1dda:	9a 0f 20 07 1e       	call   0x1e07:0x200f
    1ddf:	c9                   	leave
    1de0:	ca 06 00             	retf   0x6
    1de3:	c8 02 00 00          	enter  0x2,0x0
    1de7:	31 c0                	xor    ax,ax
    1de9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1dec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1def:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1df4:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1df8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1dfc:	bf 3f 08             	mov    di,0x83f
    1dff:	b8 1e 1e             	mov    ax,0x1e1e
    1e02:	50                   	push   ax
    1e03:	57                   	push   di
    1e04:	9a 55 22 9f 1e       	call   0x1e9f:0x2255
    1e09:	08 c0                	or     al,al
    1e0b:	74 16                	je     0x1e23
    1e0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e10:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1e15:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1e19:	06                   	push   es
    1e1a:	57                   	push   di
    1e1b:	9a 0d 5b 4e 1e       	call   0x1e4e:0x5b0d
    1e20:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e23:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e26:	c9                   	leave
    1e27:	ca 04 00             	retf   0x4
    1e2a:	c8 10 00 00          	enter  0x10,0x0
    1e2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e31:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    1e36:	74 41                	je     0x1e79
    1e38:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1e3d:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1e40:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1e43:	6a 01                	push   0x1
    1e45:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1e49:	06                   	push   es
    1e4a:	57                   	push   di
    1e4b:	9a b0 14 5e 1e       	call   0x1e5e:0x14b0
    1e50:	6a 01                	push   0x1
    1e52:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1e55:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1e59:	06                   	push   es
    1e5a:	57                   	push   di
    1e5b:	9a 7c 17 77 1e       	call   0x1e77:0x177c
    1e60:	6a 00                	push   0x0
    1e62:	6a 00                	push   0x0
    1e64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e67:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1e6b:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1e6f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1e72:	06                   	push   es
    1e73:	57                   	push   di
    1e74:	9a 22 1e c1 1e       	call   0x1ec1:0x1e22
    1e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e7c:	26 80 bd 93 00 00    	cmp    BYTE PTR es:[di+0x93],0x0
    1e82:	74 20                	je     0x1ea4
    1e84:	8d 7e f0             	lea    di,[bp-0x10]
    1e87:	16                   	push   ss
    1e88:	57                   	push   di
    1e89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e8c:	06                   	push   es
    1e8d:	57                   	push   di
    1e8e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e91:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1e95:	8d 7e f8             	lea    di,[bp-0x8]
    1e98:	16                   	push   ss
    1e99:	57                   	push   di
    1e9a:	6a 08                	push   0x8
    1e9c:	9a 1b 16 1f 1f       	call   0x1f1f:0x161b
    1ea1:	e9 b9 00             	jmp    0x1f5d
    1ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ea7:	26 80 bd 94 00 00    	cmp    BYTE PTR es:[di+0x94],0x0
    1ead:	74 74                	je     0x1f23
    1eaf:	8d 7e f0             	lea    di,[bp-0x10]
    1eb2:	16                   	push   ss
    1eb3:	57                   	push   di
    1eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb7:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1ebc:	06                   	push   es
    1ebd:	57                   	push   di
    1ebe:	9a c5 47 df 1e       	call   0x1edf:0x47c5
    1ec3:	8b d0                	mov    dx,ax
    1ec5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec8:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1ecc:	2b c2                	sub    ax,dx
    1ece:	99                   	cwd
    1ecf:	b9 02 00             	mov    cx,0x2
    1ed2:	f7 f9                	idiv   cx
    1ed4:	50                   	push   ax
    1ed5:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1eda:	06                   	push   es
    1edb:	57                   	push   di
    1edc:	9a f2 47 fd 1e       	call   0x1efd:0x47f2
    1ee1:	8b d0                	mov    dx,ax
    1ee3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ee6:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1eea:	2b c2                	sub    ax,dx
    1eec:	99                   	cwd
    1eed:	b9 02 00             	mov    cx,0x2
    1ef0:	f7 f9                	idiv   cx
    1ef2:	50                   	push   ax
    1ef3:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1ef8:	06                   	push   es
    1ef9:	57                   	push   di
    1efa:	9a c5 47 0d 1f       	call   0x1f0d:0x47c5
    1eff:	50                   	push   ax
    1f00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f03:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1f08:	06                   	push   es
    1f09:	57                   	push   di
    1f0a:	9a f2 47 39 1f       	call   0x1f39:0x47f2
    1f0f:	50                   	push   ax
    1f10:	9a ae 06 4f 1f       	call   0x1f4f:0x6ae
    1f15:	8d 7e f8             	lea    di,[bp-0x8]
    1f18:	16                   	push   ss
    1f19:	57                   	push   di
    1f1a:	6a 08                	push   0x8
    1f1c:	9a 1b 16 5b 1f       	call   0x1f5b:0x161b
    1f21:	eb 3a                	jmp    0x1f5d
    1f23:	8d 7e f0             	lea    di,[bp-0x10]
    1f26:	16                   	push   ss
    1f27:	57                   	push   di
    1f28:	6a 00                	push   0x0
    1f2a:	6a 00                	push   0x0
    1f2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2f:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1f34:	06                   	push   es
    1f35:	57                   	push   di
    1f36:	9a c5 47 49 1f       	call   0x1f49:0x47c5
    1f3b:	50                   	push   ax
    1f3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3f:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1f44:	06                   	push   es
    1f45:	57                   	push   di
    1f46:	9a f2 47 88 1f       	call   0x1f88:0x47f2
    1f4b:	50                   	push   ax
    1f4c:	9a 88 06 cb 22       	call   0x22cb:0x688
    1f51:	8d 7e f8             	lea    di,[bp-0x8]
    1f54:	16                   	push   ss
    1f55:	57                   	push   di
    1f56:	6a 08                	push   0x8
    1f58:	9a 1b 16 1d 20       	call   0x201d:0x161b
    1f5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f60:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1f65:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1f68:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1f6b:	8d 7e f8             	lea    di,[bp-0x8]
    1f6e:	16                   	push   ss
    1f6f:	57                   	push   di
    1f70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f73:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1f78:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1f7c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1f80:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f83:	06                   	push   es
    1f84:	57                   	push   di
    1f85:	9a bf 1e b1 1f       	call   0x1fb1:0x1ebf
    1f8a:	c9                   	leave
    1f8b:	ca 04 00             	retf   0x4
    1f8e:	00 00                	add    BYTE PTR [bx+si],al
    1f90:	15 20 a4             	adc    ax,0xa420
    1f93:	20 c8                	and    al,cl
    1f95:	08 01                	or     BYTE PTR [bx+di],al
    1f97:	00 c4                	add    ah,al
    1f99:	7e 06                	jle    0x1fa1
    1f9b:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    1fa0:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1fa4:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    1fa8:	75 76                	jne    0x2020
    1faa:	b0 01                	mov    al,0x1
    1fac:	50                   	push   ax
    1fad:	b8 3f 08             	mov    ax,0x83f
    1fb0:	ba b8 1f             	mov    dx,0x1fb8
    1fb3:	52                   	push   dx
    1fb4:	50                   	push   ax
    1fb5:	9a bd 56 07 20       	call   0x2007:0x56bd
    1fba:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1fbd:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1fc0:	b8 8e 1f             	mov    ax,0x1f8e
    1fc3:	0e                   	push   cs
    1fc4:	50                   	push   ax
    1fc5:	55                   	push   bp
    1fc6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1fca:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1fce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd1:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1fd5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1fd8:	06                   	push   es
    1fd9:	57                   	push   di
    1fda:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fdd:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1fe1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe4:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1fe8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1feb:	06                   	push   es
    1fec:	57                   	push   di
    1fed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ff0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1ff4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1ff7:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1ffa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ffd:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2002:	06                   	push   es
    2003:	57                   	push   di
    2004:	9a f9 42 34 20       	call   0x2034:0x42f9
    2009:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    200d:	83 c4 06             	add    sp,0x6
    2010:	b8 20 20             	mov    ax,0x2020
    2013:	0e                   	push   cs
    2014:	50                   	push   ax
    2015:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2018:	06                   	push   es
    2019:	57                   	push   di
    201a:	9a 7f 1f 3b 20       	call   0x203b:0x1f7f
    201f:	cb                   	retf
    2020:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2023:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2028:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    202c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2030:	bf 3f 08             	mov    di,0x83f
    2033:	b8 52 20             	mov    ax,0x2052
    2036:	50                   	push   ax
    2037:	57                   	push   di
    2038:	9a 55 22 7f 20       	call   0x207f:0x2255
    203d:	08 c0                	or     al,al
    203f:	74 1b                	je     0x205c
    2041:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2044:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2049:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    204d:	06                   	push   es
    204e:	57                   	push   di
    204f:	9a 0f 5a 20 21       	call   0x2120:0x5a0f
    2054:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2057:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    205a:	eb 25                	jmp    0x2081
    205c:	8d be f8 fe          	lea    di,[bp-0x108]
    2060:	16                   	push   ss
    2061:	57                   	push   di
    2062:	68 3b f0             	push   0xf03b
    2065:	9a 2b 09 78 20       	call   0x2078:0x92b
    206a:	b0 01                	mov    al,0x1
    206c:	50                   	push   ax
    206d:	b8 52 00             	mov    ax,0x52
    2070:	ba 08 22             	mov    dx,0x2208
    2073:	52                   	push   dx
    2074:	50                   	push   ax
    2075:	9a e6 28 2c 27       	call   0x272c:0x28e6
    207a:	52                   	push   dx
    207b:	50                   	push   ax
    207c:	9a 99 13 88 21       	call   0x2188:0x1399
    2081:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2084:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2087:	c9                   	leave
    2088:	ca 04 00             	retf   0x4
    208b:	55                   	push   bp
    208c:	89 e5                	mov    bp,sp
    208e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2091:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2094:	26 88 85 92 00       	mov    BYTE PTR es:[di+0x92],al
    2099:	ff 76 08             	push   WORD PTR [bp+0x8]
    209c:	ff 76 06             	push   WORD PTR [bp+0x6]
    209f:	06                   	push   es
    20a0:	57                   	push   di
    20a1:	9a 08 21 f6 25       	call   0x25f6:0x2108
    20a6:	c9                   	leave
    20a7:	ca 06 00             	retf   0x6
    20aa:	55                   	push   bp
    20ab:	89 e5                	mov    bp,sp
    20ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b0:	26 8a 85 94 00       	mov    al,BYTE PTR es:[di+0x94]
    20b5:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    20b8:	74 11                	je     0x20cb
    20ba:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    20bd:	26 88 85 94 00       	mov    BYTE PTR es:[di+0x94],al
    20c2:	06                   	push   es
    20c3:	57                   	push   di
    20c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20c7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    20cb:	c9                   	leave
    20cc:	ca 06 00             	retf   0x6
    20cf:	55                   	push   bp
    20d0:	89 e5                	mov    bp,sp
    20d2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20d5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20db:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    20e0:	06                   	push   es
    20e1:	57                   	push   di
    20e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20e5:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    20e9:	c9                   	leave
    20ea:	ca 08 00             	retf   0x8
    20ed:	55                   	push   bp
    20ee:	89 e5                	mov    bp,sp
    20f0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    20f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f6:	26 88 85 93 00       	mov    BYTE PTR es:[di+0x93],al
    20fb:	06                   	push   es
    20fc:	57                   	push   di
    20fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2100:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2104:	c9                   	leave
    2105:	ca 06 00             	retf   0x6
    2108:	55                   	push   bp
    2109:	89 e5                	mov    bp,sp
    210b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    210e:	26 80 bd 92 00 00    	cmp    BYTE PTR es:[di+0x92],0x0
    2114:	74 57                	je     0x216d
    2116:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    211b:	06                   	push   es
    211c:	57                   	push   di
    211d:	9a c5 47 33 21       	call   0x2133:0x47c5
    2122:	09 c0                	or     ax,ax
    2124:	7e 47                	jle    0x216d
    2126:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2129:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    212e:	06                   	push   es
    212f:	57                   	push   di
    2130:	9a f2 47 4e 21       	call   0x214e:0x47f2
    2135:	09 c0                	or     ax,ax
    2137:	7e 34                	jle    0x216d
    2139:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213c:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    2140:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    2144:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2149:	06                   	push   es
    214a:	57                   	push   di
    214b:	9a c5 47 5e 21       	call   0x215e:0x47c5
    2150:	50                   	push   ax
    2151:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2154:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2159:	06                   	push   es
    215a:	57                   	push   di
    215b:	9a f2 47 81 21       	call   0x2181:0x47f2
    2160:	50                   	push   ax
    2161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2164:	06                   	push   es
    2165:	57                   	push   di
    2166:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2169:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    216d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2170:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2175:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2179:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    217d:	bf 3f 08             	mov    di,0x83f
    2180:	b8 9b 21             	mov    ax,0x219b
    2183:	50                   	push   ax
    2184:	57                   	push   di
    2185:	9a 55 22 f5 21       	call   0x21f5:0x2255
    218a:	08 c0                	or     al,al
    218c:	74 3a                	je     0x21c8
    218e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2191:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    2196:	06                   	push   es
    2197:	57                   	push   di
    2198:	9a c5 47 b0 21       	call   0x21b0:0x47c5
    219d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a0:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    21a4:	75 22                	jne    0x21c8
    21a6:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    21ab:	06                   	push   es
    21ac:	57                   	push   di
    21ad:	9a f2 47 bc 22       	call   0x22bc:0x47f2
    21b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b5:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    21b9:	75 0d                	jne    0x21c8
    21bb:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    21bf:	0d 40 00             	or     ax,0x40
    21c2:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    21c6:	eb 0e                	jmp    0x21d6
    21c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21cb:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    21cf:	25 bf ff             	and    ax,0xffbf
    21d2:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    21d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d9:	06                   	push   es
    21da:	57                   	push   di
    21db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21de:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    21e2:	c9                   	leave
    21e3:	ca 08 00             	retf   0x8
    21e6:	55                   	push   bp
    21e7:	89 e5                	mov    bp,sp
    21e9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    21ed:	74 08                	je     0x21f7
    21ef:	83 ec 08             	sub    sp,0x8
    21f2:	9a e2 1f cd 25       	call   0x25cd:0x1fe2
    21f7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    21fa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    21fd:	31 c0                	xor    ax,ax
    21ff:	50                   	push   ax
    2200:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2203:	06                   	push   es
    2204:	57                   	push   di
    2205:	9a 86 68 20 22       	call   0x2220:0x6886
    220a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    220d:	26 c6 85 8e 00 00    	mov    BYTE PTR es:[di+0x8e],0x0
    2213:	26 c6 85 8f 00 00    	mov    BYTE PTR es:[di+0x8f],0x0
    2219:	6a 32                	push   0x32
    221b:	06                   	push   es
    221c:	57                   	push   di
    221d:	9a bf 17 2c 22       	call   0x222c:0x17bf
    2222:	6a 32                	push   0x32
    2224:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2227:	06                   	push   es
    2228:	57                   	push   di
    2229:	9a e1 17 35 27       	call   0x2735:0x17e1
    222e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2232:	74 07                	je     0x223b
    2234:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2238:	83 c4 06             	add    sp,0x6
    223b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    223e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2241:	c9                   	leave
    2242:	ca 0a 00             	retf   0xa
    2245:	55                   	push   bp
    2246:	89 e5                	mov    bp,sp
    2248:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    224b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    224e:	26 3a 85 8e 00       	cmp    al,BYTE PTR es:[di+0x8e]
    2253:	74 11                	je     0x2266
    2255:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2258:	26 88 85 8e 00       	mov    BYTE PTR es:[di+0x8e],al
    225d:	06                   	push   es
    225e:	57                   	push   di
    225f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2262:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2266:	c9                   	leave
    2267:	ca 06 00             	retf   0x6
    226a:	55                   	push   bp
    226b:	89 e5                	mov    bp,sp
    226d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2270:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2273:	26 3a 85 8f 00       	cmp    al,BYTE PTR es:[di+0x8f]
    2278:	74 11                	je     0x228b
    227a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    227d:	26 88 85 8f 00       	mov    BYTE PTR es:[di+0x8f],al
    2282:	06                   	push   es
    2283:	57                   	push   di
    2284:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2287:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    228b:	c9                   	leave
    228c:	ca 06 00             	retf   0x6
    228f:	c8 10 00 00          	enter  0x10,0x0
    2293:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2296:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    229a:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    229f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22a2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22a5:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    22a8:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    22ac:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    22b0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22b3:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    22b7:	06                   	push   es
    22b8:	57                   	push   di
    22b9:	9a da 13 0d 23       	call   0x230d:0x13da
    22be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c1:	26 ff 35             	push   WORD PTR es:[di]
    22c4:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    22c8:	9a 6e 06 e0 22       	call   0x22e0:0x66e
    22cd:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    22d0:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    22d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22d6:	26 ff 35             	push   WORD PTR es:[di]
    22d9:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    22dd:	9a 6e 06 f6 22       	call   0x22f6:0x66e
    22e2:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    22e5:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    22e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22eb:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    22ef:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    22f3:	9a 6e 06 36 23       	call   0x2336:0x66e
    22f8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    22fb:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    22fe:	8d 7e f0             	lea    di,[bp-0x10]
    2301:	16                   	push   ss
    2302:	57                   	push   di
    2303:	6a 02                	push   0x2
    2305:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2308:	06                   	push   es
    2309:	57                   	push   di
    230a:	9a e1 1d 26 23       	call   0x2326:0x1de1
    230f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2312:	36 ff 75 fa          	push   WORD PTR ss:[di-0x6]
    2316:	36 ff 75 f8          	push   WORD PTR ss:[di-0x8]
    231a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    231d:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2321:	06                   	push   es
    2322:	57                   	push   di
    2323:	9a da 13 78 23       	call   0x2378:0x13da
    2328:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    232b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    232f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2333:	9a 6e 06 4c 23       	call   0x234c:0x66e
    2338:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    233b:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    233e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2341:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2345:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2349:	9a 6e 06 61 23       	call   0x2361:0x66e
    234e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2351:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    2354:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2357:	26 ff 35             	push   WORD PTR es:[di]
    235a:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    235e:	9a 6e 06 57 24       	call   0x2457:0x66e
    2363:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2366:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2369:	8d 7e f0             	lea    di,[bp-0x10]
    236c:	16                   	push   ss
    236d:	57                   	push   di
    236e:	6a 02                	push   0x2
    2370:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2373:	06                   	push   es
    2374:	57                   	push   di
    2375:	9a e1 1d a3 23       	call   0x23a3:0x1de1
    237a:	c9                   	leave
    237b:	c2 06 00             	ret    0x6
    237e:	c8 04 00 00          	enter  0x4,0x0
    2382:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2385:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2389:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    238e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2391:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2394:	ff 76 10             	push   WORD PTR [bp+0x10]
    2397:	ff 76 0e             	push   WORD PTR [bp+0xe]
    239a:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    239e:	06                   	push   es
    239f:	57                   	push   di
    23a0:	9a da 13 b3 23       	call   0x23b3:0x13da
    23a5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23a8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23ab:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23ae:	06                   	push   es
    23af:	57                   	push   di
    23b0:	9a b8 1d c3 23       	call   0x23c3:0x1db8
    23b5:	ff 76 08             	push   WORD PTR [bp+0x8]
    23b8:	ff 76 06             	push   WORD PTR [bp+0x6]
    23bb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23be:	06                   	push   es
    23bf:	57                   	push   di
    23c0:	9a 7b 1d ec 23       	call   0x23ec:0x1d7b
    23c5:	c9                   	leave
    23c6:	c2 0e 00             	ret    0xe
    23c9:	3c 24                	cmp    al,0x24
    23cb:	60                   	pusha
    23cc:	24 d7                	and    al,0xd7
    23ce:	24 08                	and    al,0x8
    23d0:	25 4a 25             	and    ax,0x254a
    23d3:	7a 25                	jp     0x23fa
    23d5:	c8 18 00 00          	enter  0x18,0x0
    23d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23dc:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    23e1:	6a 01                	push   0x1
    23e3:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    23e7:	06                   	push   es
    23e8:	57                   	push   di
    23e9:	9a f5 14 3c 2b       	call   0x2b3c:0x14f5
    23ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f1:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
    23f7:	75 16                	jne    0x240f
    23f9:	c7 46 fc ef ff       	mov    WORD PTR [bp-0x4],0xffef
    23fe:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    2403:	c7 46 f8 eb ff       	mov    WORD PTR [bp-0x8],0xffeb
    2408:	c7 46 fa ff ff       	mov    WORD PTR [bp-0x6],0xffff
    240d:	eb 14                	jmp    0x2423
    240f:	c7 46 fc eb ff       	mov    WORD PTR [bp-0x4],0xffeb
    2414:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    2419:	c7 46 f8 ef ff       	mov    WORD PTR [bp-0x8],0xffef
    241e:	c7 46 fa ff ff       	mov    WORD PTR [bp-0x6],0xffff
    2423:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2426:	26 8a 85 8f 00       	mov    al,BYTE PTR es:[di+0x8f]
    242b:	3c 05                	cmp    al,0x5
    242d:	76 03                	jbe    0x2432
    242f:	e9 88 01             	jmp    0x25ba
    2432:	98                   	cbw
    2433:	89 c3                	mov    bx,ax
    2435:	d1 e3                	shl    bx,1
    2437:	2e ff a7 c9 23       	jmp    WORD PTR cs:[bx+0x23c9]
    243c:	8d 7e e8             	lea    di,[bp-0x18]
    243f:	16                   	push   ss
    2440:	57                   	push   di
    2441:	6a 00                	push   0x0
    2443:	6a 00                	push   0x0
    2445:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2448:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    244c:	48                   	dec    ax
    244d:	50                   	push   ax
    244e:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2452:	48                   	dec    ax
    2453:	50                   	push   ax
    2454:	9a 88 06 93 24       	call   0x2493:0x688
    2459:	55                   	push   bp
    245a:	e8 32 fe             	call   0x228f
    245d:	e9 5a 01             	jmp    0x25ba
    2460:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2463:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2466:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2469:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    246c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    246f:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2472:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2475:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2478:	8d 7e e8             	lea    di,[bp-0x18]
    247b:	16                   	push   ss
    247c:	57                   	push   di
    247d:	6a 01                	push   0x1
    247f:	6a 01                	push   0x1
    2481:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2484:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2488:	48                   	dec    ax
    2489:	50                   	push   ax
    248a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    248e:	48                   	dec    ax
    248f:	50                   	push   ax
    2490:	9a 88 06 ce 24       	call   0x24ce:0x688
    2495:	55                   	push   bp
    2496:	e8 f6 fd             	call   0x228f
    2499:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    249c:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    249f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    24a2:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    24a5:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    24a8:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    24ab:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24ae:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    24b1:	8d 7e e8             	lea    di,[bp-0x18]
    24b4:	16                   	push   ss
    24b5:	57                   	push   di
    24b6:	6a 00                	push   0x0
    24b8:	6a 00                	push   0x0
    24ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24bd:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    24c1:	48                   	dec    ax
    24c2:	48                   	dec    ax
    24c3:	50                   	push   ax
    24c4:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    24c8:	48                   	dec    ax
    24c9:	48                   	dec    ax
    24ca:	50                   	push   ax
    24cb:	9a 88 06 e0 25       	call   0x25e0:0x688
    24d0:	55                   	push   bp
    24d1:	e8 bb fd             	call   0x228f
    24d4:	e9 e3 00             	jmp    0x25ba
    24d7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    24da:	ff 76 fc             	push   WORD PTR [bp-0x4]
    24dd:	6a 00                	push   0x0
    24df:	6a 00                	push   0x0
    24e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e4:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    24e8:	6a 00                	push   0x0
    24ea:	55                   	push   bp
    24eb:	e8 90 fe             	call   0x237e
    24ee:	ff 76 fa             	push   WORD PTR [bp-0x6]
    24f1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    24f4:	6a 00                	push   0x0
    24f6:	6a 01                	push   0x1
    24f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24fb:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    24ff:	6a 01                	push   0x1
    2501:	55                   	push   bp
    2502:	e8 79 fe             	call   0x237e
    2505:	e9 b2 00             	jmp    0x25ba
    2508:	ff 76 fe             	push   WORD PTR [bp-0x2]
    250b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    250e:	6a 00                	push   0x0
    2510:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2513:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2517:	48                   	dec    ax
    2518:	48                   	dec    ax
    2519:	50                   	push   ax
    251a:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    251e:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2522:	48                   	dec    ax
    2523:	48                   	dec    ax
    2524:	50                   	push   ax
    2525:	55                   	push   bp
    2526:	e8 55 fe             	call   0x237e
    2529:	ff 76 fa             	push   WORD PTR [bp-0x6]
    252c:	ff 76 f8             	push   WORD PTR [bp-0x8]
    252f:	6a 00                	push   0x0
    2531:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2534:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2538:	48                   	dec    ax
    2539:	50                   	push   ax
    253a:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    253e:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2542:	48                   	dec    ax
    2543:	50                   	push   ax
    2544:	55                   	push   bp
    2545:	e8 36 fe             	call   0x237e
    2548:	eb 70                	jmp    0x25ba
    254a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    254d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2550:	6a 00                	push   0x0
    2552:	6a 00                	push   0x0
    2554:	6a 00                	push   0x0
    2556:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2559:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    255d:	55                   	push   bp
    255e:	e8 1d fe             	call   0x237e
    2561:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2564:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2567:	6a 01                	push   0x1
    2569:	6a 00                	push   0x0
    256b:	6a 01                	push   0x1
    256d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2570:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    2574:	55                   	push   bp
    2575:	e8 06 fe             	call   0x237e
    2578:	eb 40                	jmp    0x25ba
    257a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    257d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2580:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2583:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2587:	48                   	dec    ax
    2588:	48                   	dec    ax
    2589:	50                   	push   ax
    258a:	6a 00                	push   0x0
    258c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2590:	48                   	dec    ax
    2591:	48                   	dec    ax
    2592:	50                   	push   ax
    2593:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    2597:	55                   	push   bp
    2598:	e8 e3 fd             	call   0x237e
    259b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    259e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    25a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a4:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    25a8:	48                   	dec    ax
    25a9:	50                   	push   ax
    25aa:	6a 00                	push   0x0
    25ac:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    25b0:	48                   	dec    ax
    25b1:	50                   	push   ax
    25b2:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    25b6:	55                   	push   bp
    25b7:	e8 c4 fd             	call   0x237e
    25ba:	c9                   	leave
    25bb:	ca 04 00             	retf   0x4
    25be:	55                   	push   bp
    25bf:	89 e5                	mov    bp,sp
    25c1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    25c5:	74 08                	je     0x25cf
    25c7:	83 ec 08             	sub    sp,0x8
    25ca:	9a e2 1f 51 26       	call   0x2651:0x1fe2
    25cf:	ff 76 0e             	push   WORD PTR [bp+0xe]
    25d2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    25d5:	31 c0                	xor    ax,ax
    25d7:	50                   	push   ax
    25d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25db:	06                   	push   es
    25dc:	57                   	push   di
    25dd:	9a d9 4b 46 26       	call   0x2646:0x4bd9
    25e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e5:	26 c6 45 1a 01       	mov    BYTE PTR es:[di+0x1a],0x1
    25ea:	26 c7 45 1c e8 03    	mov    WORD PTR es:[di+0x1c],0x3e8
    25f0:	06                   	push   es
    25f1:	57                   	push   di
    25f2:	bf 61 26             	mov    di,0x2661
    25f5:	b8 2d 26             	mov    ax,0x262d
    25f8:	50                   	push   ax
    25f9:	57                   	push   di
    25fa:	9a ed 15 39 26       	call   0x2639:0x15ed
    25ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2602:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    2606:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    260a:	74 07                	je     0x2613
    260c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2610:	83 c4 06             	add    sp,0x6
    2613:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2616:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2619:	c9                   	leave
    261a:	ca 0a 00             	retf   0xa
    261d:	55                   	push   bp
    261e:	89 e5                	mov    bp,sp
    2620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2623:	26 c6 45 1a 00       	mov    BYTE PTR es:[di+0x1a],0x0
    2628:	06                   	push   es
    2629:	57                   	push   di
    262a:	9a de 26 5f 26       	call   0x265f:0x26de
    262f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2632:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    2636:	9a 6c 16 a8 26       	call   0x26a8:0x166c
    263b:	31 c0                	xor    ax,ax
    263d:	50                   	push   ax
    263e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2641:	06                   	push   es
    2642:	57                   	push   di
    2643:	9a 2b 4c 96 29       	call   0x2996:0x4c2b
    2648:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    264c:	74 05                	je     0x2653
    264e:	9a 0f 20 8e 26       	call   0x268e:0x200f
    2653:	c9                   	leave
    2654:	ca 06 00             	retf   0x6
    2657:	01 00                	add    WORD PTR [bx+si],ax
    2659:	00 00                	add    BYTE PTR [bx+si],al
    265b:	00 00                	add    BYTE PTR [bx+si],al
    265d:	99                   	cwd
    265e:	26 64 27             	es fs daa
    2661:	c8 04 00 00          	enter  0x4,0x0
    2665:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2668:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    266b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    266e:	26 81 3d 13 01       	cmp    WORD PTR es:[di],0x113
    2673:	75 3c                	jne    0x26b1
    2675:	b8 57 26             	mov    ax,0x2657
    2678:	0e                   	push   cs
    2679:	50                   	push   ax
    267a:	55                   	push   bp
    267b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    267f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2686:	06                   	push   es
    2687:	57                   	push   di
    2688:	b8 ff ff             	mov    ax,0xffff
    268b:	9a 6a 20 ad 26       	call   0x26ad:0x206a
    2690:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2694:	83 c4 06             	add    sp,0x6
    2697:	eb 16                	jmp    0x26af
    2699:	ff 76 08             	push   WORD PTR [bp+0x8]
    269c:	ff 76 06             	push   WORD PTR [bp+0x6]
    269f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    26a3:	06                   	push   es
    26a4:	57                   	push   di
    26a5:	9a 51 75 ff ff       	call   0xffff:0x7551
    26aa:	9a 34 14 43 27       	call   0x2743:0x1434
    26af:	eb 29                	jmp    0x26da
    26b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b4:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    26b8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    26bb:	26 ff 35             	push   WORD PTR es:[di]
    26be:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    26c2:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    26c6:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    26ca:	9a ff ff 00 00       	call   0x0:0xffff
    26cf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    26d2:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    26d6:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    26da:	c9                   	leave
    26db:	ca 08 00             	retf   0x8
    26de:	c8 00 01 00          	enter  0x100,0x0
    26e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e5:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    26e9:	6a 01                	push   0x1
    26eb:	9a ff ff 00 00       	call   0x0:0xffff
    26f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f3:	26 83 7d 1c 00       	cmp    WORD PTR es:[di+0x1c],0x0
    26f8:	74 4b                	je     0x2745
    26fa:	26 80 7d 1a 00       	cmp    BYTE PTR es:[di+0x1a],0x0
    26ff:	74 44                	je     0x2745
    2701:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2705:	09 c0                	or     ax,ax
    2707:	74 3c                	je     0x2745
    2709:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    270d:	6a 01                	push   0x1
    270f:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    2713:	6a 00                	push   0x0
    2715:	6a 00                	push   0x0
    2717:	9a ff ff 00 00       	call   0x0:0xffff
    271c:	09 c0                	or     ax,ax
    271e:	75 25                	jne    0x2745
    2720:	8d be 00 ff          	lea    di,[bp-0x100]
    2724:	16                   	push   ss
    2725:	57                   	push   di
    2726:	68 32 f0             	push   0xf032
    2729:	9a 2b 09 3c 27       	call   0x273c:0x92b
    272e:	b0 01                	mov    al,0x1
    2730:	50                   	push   ax
    2731:	b8 22 00             	mov    ax,0x22
    2734:	ba f7 27             	mov    dx,0x27f7
    2737:	52                   	push   dx
    2738:	50                   	push   ax
    2739:	9a e6 28 bb 2b       	call   0x2bbb:0x28e6
    273e:	52                   	push   dx
    273f:	50                   	push   ax
    2740:	9a 99 13 a1 27       	call   0x27a1:0x1399
    2745:	c9                   	leave
    2746:	ca 04 00             	retf   0x4
    2749:	55                   	push   bp
    274a:	89 e5                	mov    bp,sp
    274c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    274f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2752:	26 3a 45 1a          	cmp    al,BYTE PTR es:[di+0x1a]
    2756:	74 0e                	je     0x2766
    2758:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    275b:	26 88 45 1a          	mov    BYTE PTR es:[di+0x1a],al
    275f:	06                   	push   es
    2760:	57                   	push   di
    2761:	9a de 26 85 27       	call   0x2785:0x26de
    2766:	c9                   	leave
    2767:	ca 06 00             	retf   0x6
    276a:	55                   	push   bp
    276b:	89 e5                	mov    bp,sp
    276d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2770:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2773:	26 3b 45 1c          	cmp    ax,WORD PTR es:[di+0x1c]
    2777:	74 0e                	je     0x2787
    2779:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    277c:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    2780:	06                   	push   es
    2781:	57                   	push   di
    2782:	9a de 26 ab 27       	call   0x27ab:0x26de
    2787:	c9                   	leave
    2788:	ca 06 00             	retf   0x6
    278b:	55                   	push   bp
    278c:	89 e5                	mov    bp,sp
    278e:	8d 7e 0a             	lea    di,[bp+0xa]
    2791:	16                   	push   ss
    2792:	57                   	push   di
    2793:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2796:	81 c7 20 00          	add    di,0x20
    279a:	06                   	push   es
    279b:	57                   	push   di
    279c:	6a 08                	push   0x8
    279e:	9a 1b 16 e4 27       	call   0x27e4:0x161b
    27a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a6:	06                   	push   es
    27a7:	57                   	push   di
    27a8:	9a de 26 28 28       	call   0x2828:0x26de
    27ad:	c9                   	leave
    27ae:	ca 0c 00             	retf   0xc
    27b1:	55                   	push   bp
    27b2:	89 e5                	mov    bp,sp
    27b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b7:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    27bb:	09 c0                	or     ax,ax
    27bd:	74 12                	je     0x27d1
    27bf:	ff 76 08             	push   WORD PTR [bp+0x8]
    27c2:	ff 76 06             	push   WORD PTR [bp+0x6]
    27c5:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    27c9:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    27cd:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    27d1:	c9                   	leave
    27d2:	ca 04 00             	retf   0x4
    27d5:	55                   	push   bp
    27d6:	89 e5                	mov    bp,sp
    27d8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    27dc:	74 08                	je     0x27e6
    27de:	83 ec 08             	sub    sp,0x8
    27e1:	9a e2 1f 18 29       	call   0x2918:0x1fe2
    27e6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    27e9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    27ec:	31 c0                	xor    ax,ax
    27ee:	50                   	push   ax
    27ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27f2:	06                   	push   es
    27f3:	57                   	push   di
    27f4:	9a 72 6c 0a 28       	call   0x280a:0x6c72
    27f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fc:	26 c7 45 26 eb 00    	mov    WORD PTR es:[di+0x26],0xeb
    2802:	68 b9 00             	push   0xb9
    2805:	06                   	push   es
    2806:	57                   	push   di
    2807:	9a bf 17 16 28       	call   0x2816:0x17bf
    280c:	6a 29                	push   0x29
    280e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2811:	06                   	push   es
    2812:	57                   	push   di
    2813:	9a e1 17 48 28       	call   0x2848:0x17e1
    2818:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    281b:	26 c6 85 ec 00 02    	mov    BYTE PTR es:[di+0xec],0x2
    2821:	6a 02                	push   0x2
    2823:	06                   	push   es
    2824:	57                   	push   di
    2825:	9a 3e 2c 34 28       	call   0x2834:0x2c3e
    282a:	6a 01                	push   0x1
    282c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    282f:	06                   	push   es
    2830:	57                   	push   di
    2831:	9a 63 2c c1 29       	call   0x29c1:0x2c63
    2836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2839:	26 c6 85 e2 00 00    	mov    BYTE PTR es:[di+0xe2],0x0
    283f:	6a ff                	push   0xffff
    2841:	6a f0                	push   0xfff0
    2843:	06                   	push   es
    2844:	57                   	push   di
    2845:	9a d5 1e 72 28       	call   0x2872:0x1ed5
    284a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    284e:	74 07                	je     0x2857
    2850:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2854:	83 c4 06             	add    sp,0x6
    2857:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    285a:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    285d:	c9                   	leave
    285e:	ca 0a 00             	retf   0xa
    2861:	c8 04 00 00          	enter  0x4,0x0
    2865:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2868:	06                   	push   es
    2869:	57                   	push   di
    286a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    286d:	06                   	push   es
    286e:	57                   	push   di
    286f:	9a 29 3b 04 29       	call   0x2904:0x3b29
    2874:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2877:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    287a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    287d:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2881:	0d 02 00             	or     ax,0x2
    2884:	0d 01 00             	or     ax,0x1
    2887:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    288b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    288e:	26 8a 85 e2 00       	mov    al,BYTE PTR es:[di+0xe2]
    2893:	98                   	cbw
    2894:	8b f8                	mov    di,ax
    2896:	c1 e7 02             	shl    di,0x2
    2899:	8b 85 50 0e          	mov    ax,WORD PTR [di+0xe50]
    289d:	8b 95 52 0e          	mov    dx,WORD PTR [di+0xe52]
    28a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    28a4:	26 0b 45 04          	or     ax,WORD PTR es:[di+0x4]
    28a8:	26 0b 55 06          	or     dx,WORD PTR es:[di+0x6]
    28ac:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    28b0:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    28b4:	c9                   	leave
    28b5:	ca 08 00             	retf   0x8
    28b8:	55                   	push   bp
    28b9:	89 e5                	mov    bp,sp
    28bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28be:	06                   	push   es
    28bf:	57                   	push   di
    28c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28c3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    28c7:	c9                   	leave
    28c8:	ca 08 00             	retf   0x8
    28cb:	55                   	push   bp
    28cc:	89 e5                	mov    bp,sp
    28ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d1:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    28d6:	09 c0                	or     ax,ax
    28d8:	74 15                	je     0x28ef
    28da:	ff 76 08             	push   WORD PTR [bp+0x8]
    28dd:	ff 76 06             	push   WORD PTR [bp+0x6]
    28e0:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    28e5:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    28ea:	26 ff 9d e4 00       	call   DWORD PTR es:[di+0xe4]
    28ef:	c9                   	leave
    28f0:	ca 04 00             	retf   0x4
    28f3:	55                   	push   bp
    28f4:	89 e5                	mov    bp,sp
    28f6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28f9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ff:	06                   	push   es
    2900:	57                   	push   di
    2901:	9a a8 4d 79 29       	call   0x2979:0x4da8
    2906:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2909:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    290e:	75 0a                	jne    0x291a
    2910:	06                   	push   es
    2911:	57                   	push   di
    2912:	b8 ee ff             	mov    ax,0xffee
    2915:	9a 6a 20 9d 29       	call   0x299d:0x206a
    291a:	c9                   	leave
    291b:	ca 08 00             	retf   0x8
    291e:	c8 02 00 00          	enter  0x2,0x0
    2922:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2925:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    292a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    292d:	26 80 bd dd 00 00    	cmp    BYTE PTR es:[di+0xdd],0x0
    2933:	74 08                	je     0x293d
    2935:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    293a:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    293d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2940:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    2946:	74 08                	je     0x2950
    2948:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    294d:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    2950:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2953:	06                   	push   es
    2954:	57                   	push   di
    2955:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2958:	f7 d8                	neg    ax
    295a:	50                   	push   ax
    295b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    295e:	f7 d8                	neg    ax
    2960:	50                   	push   ax
    2961:	9a ff ff 00 00       	call   0x0:0xffff
    2966:	ff 76 10             	push   WORD PTR [bp+0x10]
    2969:	ff 76 0e             	push   WORD PTR [bp+0xe]
    296c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    296f:	06                   	push   es
    2970:	57                   	push   di
    2971:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2974:	06                   	push   es
    2975:	57                   	push   di
    2976:	9a c2 35 b1 29       	call   0x29b1:0x35c2
    297b:	c9                   	leave
    297c:	ca 0c 00             	retf   0xc
    297f:	09 53 68             	or     WORD PTR [bp+di+0x68],dx
    2982:	6f                   	outs   dx,WORD PTR ds:[si]
    2983:	77 48                	ja     0x29cd
    2985:	69 6e 74 73 55       	imul   bp,WORD PTR [bp+0x74],0x5573
    298a:	89 e5                	mov    bp,sp
    298c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    298f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2992:	bf 8d 05             	mov    di,0x58d
    2995:	b8 e7 29             	mov    ax,0x29e7
    2998:	50                   	push   ax
    2999:	57                   	push   di
    299a:	9a 55 22 63 2a       	call   0x2a63:0x2255
    299f:	08 c0                	or     al,al
    29a1:	74 10                	je     0x29b3
    29a3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    29a6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    29a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ac:	06                   	push   es
    29ad:	57                   	push   di
    29ae:	9a 3a 27 f2 29       	call   0x29f2:0x273a
    29b3:	bf 7f 29             	mov    di,0x297f
    29b6:	0e                   	push   cs
    29b7:	57                   	push   di
    29b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29bb:	06                   	push   es
    29bc:	57                   	push   di
    29bd:	bf dc 29             	mov    di,0x29dc
    29c0:	b8 a3 2a             	mov    ax,0x2aa3
    29c3:	50                   	push   ax
    29c4:	57                   	push   di
    29c5:	31 c0                	xor    ax,ax
    29c7:	50                   	push   ax
    29c8:	50                   	push   ax
    29c9:	50                   	push   ax
    29ca:	50                   	push   ax
    29cb:	6a 00                	push   0x0
    29cd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29d0:	06                   	push   es
    29d1:	57                   	push   di
    29d2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29d5:	26 ff 1d             	call   DWORD PTR es:[di]
    29d8:	c9                   	leave
    29d9:	ca 08 00             	retf   0x8
    29dc:	55                   	push   bp
    29dd:	89 e5                	mov    bp,sp
    29df:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29e2:	06                   	push   es
    29e3:	57                   	push   di
    29e4:	9a 93 31 02 2d       	call   0x2d02:0x3193
    29e9:	50                   	push   ax
    29ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ed:	06                   	push   es
    29ee:	57                   	push   di
    29ef:	9a 72 1e b6 2b       	call   0x2bb6:0x1e72
    29f4:	c9                   	leave
    29f5:	ca 08 00             	retf   0x8
    29f8:	55                   	push   bp
    29f9:	89 e5                	mov    bp,sp
    29fb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    29fe:	36 c7 45 f4 eb ff    	mov    WORD PTR ss:[di-0xc],0xffeb
    2a04:	36 c7 45 f6 ff ff    	mov    WORD PTR ss:[di-0xa],0xffff
    2a0a:	80 7e 06 01          	cmp    BYTE PTR [bp+0x6],0x1
    2a0e:	75 0c                	jne    0x2a1c
    2a10:	36 c7 45 f4 ef ff    	mov    WORD PTR ss:[di-0xc],0xffef
    2a16:	36 c7 45 f6 ff ff    	mov    WORD PTR ss:[di-0xa],0xffff
    2a1c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2a1f:	36 c7 45 f0 ef ff    	mov    WORD PTR ss:[di-0x10],0xffef
    2a25:	36 c7 45 f2 ff ff    	mov    WORD PTR ss:[di-0xe],0xffff
    2a2b:	80 7e 06 01          	cmp    BYTE PTR [bp+0x6],0x1
    2a2f:	75 0c                	jne    0x2a3d
    2a31:	36 c7 45 f0 eb ff    	mov    WORD PTR ss:[di-0x10],0xffeb
    2a37:	36 c7 45 f2 ff ff    	mov    WORD PTR ss:[di-0xe],0xffff
    2a3d:	c9                   	leave
    2a3e:	c2 04 00             	ret    0x4
    2a41:	01 57 c8             	add    WORD PTR [bx-0x38],dx
    2a44:	16                   	push   ss
    2a45:	02 00                	add    al,BYTE PTR [bx+si]
    2a47:	8d be e6 fe          	lea    di,[bp-0x11a]
    2a4b:	16                   	push   ss
    2a4c:	57                   	push   di
    2a4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a50:	06                   	push   es
    2a51:	57                   	push   di
    2a52:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a55:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    2a59:	8d 7e f8             	lea    di,[bp-0x8]
    2a5c:	16                   	push   ss
    2a5d:	57                   	push   di
    2a5e:	6a 08                	push   0x8
    2a60:	9a 1b 16 ea 2c       	call   0x2cea:0x161b
    2a65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a68:	26 80 bd dd 00 00    	cmp    BYTE PTR es:[di+0xdd],0x0
    2a6e:	74 35                	je     0x2aa5
    2a70:	26 8a 85 dd 00       	mov    al,BYTE PTR es:[di+0xdd]
    2a75:	50                   	push   ax
    2a76:	55                   	push   bp
    2a77:	e8 7e ff             	call   0x29f8
    2a7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7d:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    2a82:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    2a87:	8d 7e f8             	lea    di,[bp-0x8]
    2a8a:	16                   	push   ss
    2a8b:	57                   	push   di
    2a8c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2a8f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2a92:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2a95:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2a98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9b:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    2aa0:	9a ea 18 d2 2a       	call   0x2ad2:0x18ea
    2aa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa8:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    2aad:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    2ab2:	8d 7e f8             	lea    di,[bp-0x8]
    2ab5:	16                   	push   ss
    2ab6:	57                   	push   di
    2ab7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aba:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2abe:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    2ac2:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2ac6:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    2aca:	26 ff b5 e0 00       	push   WORD PTR es:[di+0xe0]
    2acf:	9a ea 18 12 2b       	call   0x2b12:0x18ea
    2ad4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad7:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    2add:	74 35                	je     0x2b14
    2adf:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    2ae4:	50                   	push   ax
    2ae5:	55                   	push   bp
    2ae6:	e8 0f ff             	call   0x29f8
    2ae9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aec:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    2af1:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    2af6:	8d 7e f8             	lea    di,[bp-0x8]
    2af9:	16                   	push   ss
    2afa:	57                   	push   di
    2afb:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2afe:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2b01:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2b04:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2b07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b0a:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    2b0f:	9a ea 18 ee 2c       	call   0x2cee:0x18ea
    2b14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b17:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2b1c:	89 be ea fe          	mov    WORD PTR [bp-0x116],di
    2b20:	8c 86 ec fe          	mov    WORD PTR [bp-0x114],es
    2b24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b27:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2b2b:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    2b2f:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    2b33:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2b37:	06                   	push   es
    2b38:	57                   	push   di
    2b39:	9a 84 16 4c 2b       	call   0x2b4c:0x1684
    2b3e:	8d 7e f8             	lea    di,[bp-0x8]
    2b41:	16                   	push   ss
    2b42:	57                   	push   di
    2b43:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    2b47:	06                   	push   es
    2b48:	57                   	push   di
    2b49:	9a e5 1c 5d 2b       	call   0x2b5d:0x1ce5
    2b4e:	6a 01                	push   0x1
    2b50:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    2b54:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2b58:	06                   	push   es
    2b59:	57                   	push   di
    2b5a:	9a 7c 17 73 2b       	call   0x2b73:0x177c
    2b5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b62:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2b66:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2b6a:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    2b6e:	06                   	push   es
    2b6f:	57                   	push   di
    2b70:	9a 99 20 83 2b       	call   0x2b83:0x2099
    2b75:	bf 41 2a             	mov    di,0x2a41
    2b78:	0e                   	push   cs
    2b79:	57                   	push   di
    2b7a:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    2b7e:	06                   	push   es
    2b7f:	57                   	push   di
    2b80:	9a 4e 20 c6 2b       	call   0x2bc6:0x204e
    2b85:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    2b89:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b8c:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    2b8f:	2b 86 ee fe          	sub    ax,WORD PTR [bp-0x112]
    2b93:	d1 e8                	shr    ax,1
    2b95:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2b98:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2b9b:	03 86 ee fe          	add    ax,WORD PTR [bp-0x112]
    2b9f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ba2:	8d be f0 fe          	lea    di,[bp-0x110]
    2ba6:	16                   	push   ss
    2ba7:	57                   	push   di
    2ba8:	8d be ea fd          	lea    di,[bp-0x216]
    2bac:	16                   	push   ss
    2bad:	57                   	push   di
    2bae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb1:	06                   	push   es
    2bb2:	57                   	push   di
    2bb3:	9a 53 1d 2c 2c       	call   0x2c2c:0x1d53
    2bb8:	9a 4c 0d d8 2b       	call   0x2bd8:0xd4c
    2bbd:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    2bc1:	06                   	push   es
    2bc2:	57                   	push   di
    2bc3:	9a d2 21 a4 30       	call   0x30a4:0x21d2
    2bc8:	50                   	push   ax
    2bc9:	8d be f0 fe          	lea    di,[bp-0x110]
    2bcd:	16                   	push   ss
    2bce:	57                   	push   di
    2bcf:	8d be f0 fe          	lea    di,[bp-0x110]
    2bd3:	16                   	push   ss
    2bd4:	57                   	push   di
    2bd5:	9a 8c 0c ff ff       	call   0xffff:0xc8c
    2bda:	50                   	push   ax
    2bdb:	8d 7e f8             	lea    di,[bp-0x8]
    2bde:	16                   	push   ss
    2bdf:	57                   	push   di
    2be0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be3:	26 8a 85 ec 00       	mov    al,BYTE PTR es:[di+0xec]
    2be8:	98                   	cbw
    2be9:	8b f8                	mov    di,ax
    2beb:	d1 e7                	shl    di,1
    2bed:	8b 85 58 0e          	mov    ax,WORD PTR [di+0xe58]
    2bf1:	0d 44 00             	or     ax,0x44
    2bf4:	50                   	push   ax
    2bf5:	9a ff ff 00 00       	call   0x0:0xffff
    2bfa:	c9                   	leave
    2bfb:	ca 04 00             	retf   0x4
    2bfe:	55                   	push   bp
    2bff:	89 e5                	mov    bp,sp
    2c01:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2c04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c07:	26 88 85 ec 00       	mov    BYTE PTR es:[di+0xec],al
    2c0c:	06                   	push   es
    2c0d:	57                   	push   di
    2c0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c11:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c15:	c9                   	leave
    2c16:	ca 06 00             	retf   0x6
    2c19:	55                   	push   bp
    2c1a:	89 e5                	mov    bp,sp
    2c1c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2c1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c22:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    2c27:	06                   	push   es
    2c28:	57                   	push   di
    2c29:	9a f9 36 51 2c       	call   0x2c51:0x36f9
    2c2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c31:	06                   	push   es
    2c32:	57                   	push   di
    2c33:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c36:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c3a:	c9                   	leave
    2c3b:	ca 06 00             	retf   0x6
    2c3e:	55                   	push   bp
    2c3f:	89 e5                	mov    bp,sp
    2c41:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2c44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c47:	26 88 85 dd 00       	mov    BYTE PTR es:[di+0xdd],al
    2c4c:	06                   	push   es
    2c4d:	57                   	push   di
    2c4e:	9a f9 36 76 2c       	call   0x2c76:0x36f9
    2c53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c56:	06                   	push   es
    2c57:	57                   	push   di
    2c58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c5b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c5f:	c9                   	leave
    2c60:	ca 06 00             	retf   0x6
    2c63:	55                   	push   bp
    2c64:	89 e5                	mov    bp,sp
    2c66:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c6c:	26 89 85 de 00       	mov    WORD PTR es:[di+0xde],ax
    2c71:	06                   	push   es
    2c72:	57                   	push   di
    2c73:	9a f9 36 9b 2c       	call   0x2c9b:0x36f9
    2c78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c7b:	06                   	push   es
    2c7c:	57                   	push   di
    2c7d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c80:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2c84:	c9                   	leave
    2c85:	ca 06 00             	retf   0x6
    2c88:	55                   	push   bp
    2c89:	89 e5                	mov    bp,sp
    2c8b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c91:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
    2c96:	06                   	push   es
    2c97:	57                   	push   di
    2c98:	9a f9 36 ca 2c       	call   0x2cca:0x36f9
    2c9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ca0:	06                   	push   es
    2ca1:	57                   	push   di
    2ca2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ca5:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2ca9:	c9                   	leave
    2caa:	ca 06 00             	retf   0x6
    2cad:	55                   	push   bp
    2cae:	89 e5                	mov    bp,sp
    2cb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb3:	26 8a 85 e2 00       	mov    al,BYTE PTR es:[di+0xe2]
    2cb8:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2cbb:	74 0f                	je     0x2ccc
    2cbd:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2cc0:	26 88 85 e2 00       	mov    BYTE PTR es:[di+0xe2],al
    2cc5:	06                   	push   es
    2cc6:	57                   	push   di
    2cc7:	9a 5a 40 46 2d       	call   0x2d46:0x405a
    2ccc:	c9                   	leave
    2ccd:	ca 06 00             	retf   0x6
    2cd0:	8d 2d                	lea    bp,[di]
    2cd2:	00 00                	add    BYTE PTR [bx+si],al
    2cd4:	00 00                	add    BYTE PTR [bx+si],al
    2cd6:	79 2d                	jns    0x2d05
    2cd8:	6c                   	ins    BYTE PTR es:[di],dx
    2cd9:	2d dc 00             	sub    ax,0xdc
    2cdc:	19 2c                	sbb    WORD PTR [si],bp
    2cde:	a1 2d fa             	mov    ax,ds:0xfa2d
    2ce1:	45                   	inc    bp
    2ce2:	56                   	push   si
    2ce3:	2d 9a 1f             	sub    ax,0x1f9a
    2ce6:	bf 2d cb             	mov    di,0xcb2d
    2ce9:	1f                   	pop    ds
    2cea:	e6 2c                	out    0x2c,al
    2cec:	58                   	pop    ax
    2ced:	2e 83 2d cd          	sub    WORD PTR cs:[di],0xffcd
    2cf1:	11 fa                	adc    dx,di
    2cf3:	2c 3a                	sub    al,0x3a
    2cf5:	27                   	daa
    2cf6:	fe                   	(bad)
    2cf7:	2c fa                	sub    al,0xfa
    2cf9:	10 e7                	adc    bh,ah
    2cfb:	2d d6 14             	sub    ax,0x14d6
    2cfe:	06                   	push   es
    2cff:	2d f4 4f             	sub    ax,0x4ff4
    2d02:	12 2d                	adc    ch,BYTE PTR [di]
    2d04:	32 16 2e 2d          	xor    dl,BYTE PTR ds:0x2d2e
    2d08:	ec                   	in     al,dx
    2d09:	30 66 2d             	xor    BYTE PTR [bp+0x2d],ah
    2d0c:	51                   	push   cx
    2d0d:	1b f3                	sbb    si,bx
    2d0f:	2d 38 50             	sub    ax,0x5038
    2d12:	1a 2d                	sbb    ch,BYTE PTR [di]
    2d14:	63 31                	arpl   WORD PTR [bx+di],si
    2d16:	36 2d 21 50          	ss sub ax,0x5021
    2d1a:	f2 2c 37             	repnz sub al,0x37
    2d1d:	70 32                	jo     0x2d51
    2d1f:	2d d9 62             	sub    ax,0x62d9
    2d22:	26 2d 06 63          	es sub ax,0x6306
    2d26:	2a 2d                	sub    ch,BYTE PTR [di]
    2d28:	8f                   	(bad)
    2d29:	60                   	pusha
    2d2a:	62 2d                	bound  bp,DWORD PTR [di]
    2d2c:	3a 1c                	cmp    bl,BYTE PTR [si]
    2d2e:	0e                   	push   cs
    2d2f:	2d 35 69             	sub    ax,0x6935
    2d32:	de 2c                	fisubr WORD PTR [si]
    2d34:	08 61 3a             	or     BYTE PTR [bx+di+0x3a],ah
    2d37:	2d 5c 61             	sub    ax,0x615c
    2d3a:	3e 2d 62 5c          	ds sub ax,0x5c62
    2d3e:	6a 2d                	push   0x2d
    2d40:	3a 61 f6             	cmp    ah,BYTE PTR [bx+di-0xa]
    2d43:	2c 72                	sub    al,0x72
    2d45:	3f                   	aas
    2d46:	4e                   	dec    si
    2d47:	2d b9 71             	sub    ax,0x71b9
    2d4a:	52                   	push   dx
    2d4b:	2d 17 3e             	sub    ax,0x3e17
    2d4e:	e2 2c                	loop   0x2d7c
    2d50:	21 72 1e             	and    WORD PTR [bp+si+0x1e],si
    2d53:	2d ed 3e             	sub    ax,0x3eed
    2d56:	5a                   	pop    dx
    2d57:	2d 77 3e             	sub    ax,0x3e77
    2d5a:	5e                   	pop    si
    2d5b:	2d c2 35             	sub    ax,0x35c2
    2d5e:	22 2d                	and    ch,BYTE PTR [di]
    2d60:	1c 48                	sbb    al,0x48
    2d62:	0a 2d                	or     ch,BYTE PTR [di]
    2d64:	ae                   	scas   al,BYTE PTR es:[di]
    2d65:	5f                   	pop    di
    2d66:	16                   	push   ss
    2d67:	2d 35 62             	sub    ax,0x6235
    2d6a:	42                   	inc    dx
    2d6b:	2d 0c 54             	sub    ax,0x540c
    2d6e:	47                   	inc    di
    2d6f:	72 6f                	jb     0x2de0
    2d71:	75 70                	jne    0x2de3
    2d73:	42                   	inc    dx
    2d74:	75 74                	jne    0x2dea
    2d76:	74 6f                	je     0x2de7
    2d78:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d79:	03 00                	add    ax,WORD PTR [bx+si]
    2d7b:	11 21                	adc    WORD PTR [bx+di],sp
    2d7d:	f1                   	int1
    2d7e:	ff                   	jmp    (bad)
    2d7f:	ef                   	out    dx,ax
    2d80:	ff 90 2e 87          	call   WORD PTR [bx+si-0x78d2]
    2d84:	2d 24 2f             	sub    ax,0x2f24
    2d87:	8b 2d                	mov    bp,WORD PTR [di]
    2d89:	cd 2e                	int    0x2e
    2d8b:	9d                   	popf
    2d8c:	2d 07 0c             	sub    ax,0xc07
    2d8f:	54                   	push   sp
    2d90:	47                   	inc    di
    2d91:	72 6f                	jb     0x2e02
    2d93:	75 70                	jne    0x2e05
    2d95:	42                   	inc    dx
    2d96:	75 74                	jne    0x2e0c
    2d98:	74 6f                	je     0x2e09
    2d9a:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d9b:	f0 2c 1c             	lock sub al,0x1c
    2d9e:	2e bc 2c d2          	cs mov sp,0xd22c
    2da2:	2d 28 00             	sub    ax,0x28
    2da5:	08 45 78             	or     BYTE PTR [di+0x78],al
    2da8:	74 43                	je     0x2ded
    2daa:	74 72                	je     0x2e1e
    2dac:	6c                   	ins    BYTE PTR es:[di],dx
    2dad:	73 00                	jae    0x2daf
    2daf:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2db2:	e5 80                	in     ax,0x80
    2db4:	7e 0a                	jle    0x2dc0
    2db6:	00 74 08             	add    BYTE PTR [si+0x8],dh
    2db9:	83 ec 08             	sub    sp,0x8
    2dbc:	9a e2 1f 8a 2e       	call   0x2e8a:0x1fe2
    2dc1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2dc4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2dc7:	31 c0                	xor    ax,ax
    2dc9:	50                   	push   ax
    2dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dcd:	06                   	push   es
    2dce:	57                   	push   di
    2dcf:	9a 37 70 c7 2e       	call   0x2ec7:0x7037
    2dd4:	ff 76 08             	push   WORD PTR [bp+0x8]
    2dd7:	ff 76 06             	push   WORD PTR [bp+0x6]
    2dda:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2ddd:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2de2:	06                   	push   es
    2de3:	57                   	push   di
    2de4:	9a 2b 0c 72 2e       	call   0x2e72:0xc2b
    2de9:	6a 00                	push   0x0
    2deb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dee:	06                   	push   es
    2def:	57                   	push   di
    2df0:	9a 77 1c 05 2e       	call   0x2e05:0x1c77
    2df5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2df8:	26 8a 45 2a          	mov    al,BYTE PTR es:[di+0x2a]
    2dfc:	50                   	push   ax
    2dfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e00:	06                   	push   es
    2e01:	57                   	push   di
    2e02:	9a b8 1c 11 2e       	call   0x2e11:0x1cb8
    2e07:	6a 00                	push   0x0
    2e09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e0c:	06                   	push   es
    2e0d:	57                   	push   di
    2e0e:	9a a1 1e 7f 2e       	call   0x2e7f:0x1ea1
    2e13:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e16:	06                   	push   es
    2e17:	57                   	push   di
    2e18:	b8 ab 31             	mov    ax,0x31ab
    2e1b:	ba c5 2f             	mov    dx,0x2fc5
    2e1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e21:	26 89 45 7a          	mov    WORD PTR es:[di+0x7a],ax
    2e25:	26 89 55 7c          	mov    WORD PTR es:[di+0x7c],dx
    2e29:	26 8f 45 7e          	pop    WORD PTR es:[di+0x7e]
    2e2d:	26 8f 85 80 00       	pop    WORD PTR es:[di+0x80]
    2e32:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2e35:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e38:	06                   	push   es
    2e39:	57                   	push   di
    2e3a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e3d:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    2e41:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2e45:	74 07                	je     0x2e4e
    2e47:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e4b:	83 c4 06             	add    sp,0x6
    2e4e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2e51:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2e54:	c9                   	leave
    2e55:	ca 0a 00             	retf   0xa
    2e58:	55                   	push   bp
    2e59:	89 e5                	mov    bp,sp
    2e5b:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e5e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e64:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2e68:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2e6d:	06                   	push   es
    2e6e:	57                   	push   di
    2e6f:	9a a7 0f 8c 2f       	call   0x2f8c:0xfa7
    2e74:	31 c0                	xor    ax,ax
    2e76:	50                   	push   ax
    2e77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e7a:	06                   	push   es
    2e7b:	57                   	push   di
    2e7c:	9a fc 2e dd 2e       	call   0x2edd:0x2efc
    2e81:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2e85:	74 05                	je     0x2e8c
    2e87:	9a 0f 20 f3 2e       	call   0x2ef3:0x200f
    2e8c:	c9                   	leave
    2e8d:	ca 06 00             	retf   0x6
    2e90:	55                   	push   bp
    2e91:	89 e5                	mov    bp,sp
    2e93:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2e96:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    2e9b:	74 07                	je     0x2ea4
    2e9d:	26 83 7d 06 05       	cmp    WORD PTR es:[di+0x6],0x5
    2ea2:	75 25                	jne    0x2ec9
    2ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2eab:	06                   	push   es
    2eac:	57                   	push   di
    2ead:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2eb0:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    2eb5:	08 c0                	or     al,al
    2eb7:	74 10                	je     0x2ec9
    2eb9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ebc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec2:	06                   	push   es
    2ec3:	57                   	push   di
    2ec4:	9a 2f 73 7a 2f       	call   0x2f7a:0x732f
    2ec9:	c9                   	leave
    2eca:	ca 08 00             	retf   0x8
    2ecd:	55                   	push   bp
    2ece:	89 e5                	mov    bp,sp
    2ed0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ed3:	06                   	push   es
    2ed4:	57                   	push   di
    2ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed8:	06                   	push   es
    2ed9:	57                   	push   di
    2eda:	9a 1f 52 38 2f       	call   0x2f38:0x521f
    2edf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ee2:	06                   	push   es
    2ee3:	57                   	push   di
    2ee4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2eeb:	06                   	push   es
    2eec:	57                   	push   di
    2eed:	b8 ef ff             	mov    ax,0xffef
    2ef0:	9a 6a 20 52 2f       	call   0x2f52:0x206a
    2ef5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ef8:	26 80 3d 08          	cmp    BYTE PTR es:[di],0x8
    2efc:	74 06                	je     0x2f04
    2efe:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    2f02:	75 1c                	jne    0x2f20
    2f04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f07:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2f0b:	06                   	push   es
    2f0c:	57                   	push   di
    2f0d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f10:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    2f15:	08 c0                	or     al,al
    2f17:	75 07                	jne    0x2f20
    2f19:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f1c:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2f20:	c9                   	leave
    2f21:	ca 08 00             	retf   0x8
    2f24:	55                   	push   bp
    2f25:	89 e5                	mov    bp,sp
    2f27:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f2a:	06                   	push   es
    2f2b:	57                   	push   di
    2f2c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f2f:	50                   	push   ax
    2f30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f33:	06                   	push   es
    2f34:	57                   	push   di
    2f35:	9a 6a 4f 56 30       	call   0x3056:0x4f6a
    2f3a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f3d:	06                   	push   es
    2f3e:	57                   	push   di
    2f3f:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f42:	50                   	push   ax
    2f43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f46:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2f4a:	06                   	push   es
    2f4b:	57                   	push   di
    2f4c:	b8 f1 ff             	mov    ax,0xfff1
    2f4f:	9a 6a 20 67 2f       	call   0x2f67:0x206a
    2f54:	c9                   	leave
    2f55:	ca 0a 00             	retf   0xa
    2f58:	55                   	push   bp
    2f59:	89 e5                	mov    bp,sp
    2f5b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2f5f:	74 08                	je     0x2f69
    2f61:	83 ec 08             	sub    sp,0x8
    2f64:	9a e2 1f 93 2f       	call   0x2f93:0x1fe2
    2f69:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2f6c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f6f:	31 c0                	xor    ax,ax
    2f71:	50                   	push   ax
    2f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f75:	06                   	push   es
    2f76:	57                   	push   di
    2f77:	9a 20 3f 66 33       	call   0x3366:0x3f20
    2f7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f7f:	26 c7 45 26 a0 00    	mov    WORD PTR es:[di+0x26],0xa0
    2f85:	b0 01                	mov    al,0x1
    2f87:	50                   	push   ax
    2f88:	b8 a3 02             	mov    ax,0x2a3
    2f8b:	ba a9 2f             	mov    dx,0x2fa9
    2f8e:	52                   	push   dx
    2f8f:	50                   	push   ax
    2f90:	9a 50 1f 3a 30       	call   0x303a:0x1f50
    2f95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f98:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    2f9d:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
    2fa2:	b0 01                	mov    al,0x1
    2fa4:	50                   	push   ax
    2fa5:	b8 c9 03             	mov    ax,0x3c9
    2fa8:	ba b0 2f             	mov    dx,0x2fb0
    2fab:	52                   	push   dx
    2fac:	50                   	push   ax
    2fad:	9a 08 1d 5b 31       	call   0x315b:0x1d08
    2fb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb5:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
    2fba:	26 89 95 e2 00       	mov    WORD PTR es:[di+0xe2],dx
    2fbf:	06                   	push   es
    2fc0:	57                   	push   di
    2fc1:	b8 e1 31             	mov    ax,0x31e1
    2fc4:	ba 11 30             	mov    dx,0x3011
    2fc7:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    2fcc:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2fd0:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2fd4:	26 8f 45 10          	pop    WORD PTR es:[di+0x10]
    2fd8:	26 8f 45 12          	pop    WORD PTR es:[di+0x12]
    2fdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fdf:	26 c7 85 e4 00 ff ff 	mov    WORD PTR es:[di+0xe4],0xffff
    2fe6:	26 c7 85 e6 00 01 00 	mov    WORD PTR es:[di+0xe6],0x1
    2fed:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2ff1:	74 07                	je     0x2ffa
    2ff3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2ff7:	83 c4 06             	add    sp,0x6
    2ffa:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2ffd:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3000:	c9                   	leave
    3001:	ca 0a 00             	retf   0xa
    3004:	55                   	push   bp
    3005:	89 e5                	mov    bp,sp
    3007:	6a 00                	push   0x0
    3009:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300c:	06                   	push   es
    300d:	57                   	push   di
    300e:	9a 5a 32 27 32       	call   0x3227:0x325a
    3013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3016:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    301b:	31 c0                	xor    ax,ax
    301d:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    3021:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    3025:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    3029:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    302d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3030:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    3035:	06                   	push   es
    3036:	57                   	push   di
    3037:	9a 7f 1f 49 30       	call   0x3049:0x1f7f
    303c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303f:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3044:	06                   	push   es
    3045:	57                   	push   di
    3046:	9a 7f 1f 61 30       	call   0x3061:0x1f7f
    304b:	31 c0                	xor    ax,ax
    304d:	50                   	push   ax
    304e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3051:	06                   	push   es
    3052:	57                   	push   di
    3053:	9a dc 6c 9d 31       	call   0x319d:0x6cdc
    3058:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    305c:	74 05                	je     0x3063
    305e:	9a 0f 20 db 31       	call   0x31db:0x200f
    3063:	c9                   	leave
    3064:	ca 06 00             	retf   0x6
    3067:	c8 34 00 00          	enter  0x34,0x0
    306b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    306e:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3073:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    3078:	75 03                	jne    0x307d
    307a:	e9 2a 01             	jmp    0x31a7
    307d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3080:	26 80 bd e8 00 00    	cmp    BYTE PTR es:[di+0xe8],0x0
    3086:	74 03                	je     0x308b
    3088:	e9 1c 01             	jmp    0x31a7
    308b:	6a 00                	push   0x0
    308d:	9a ff ff 00 00       	call   0x0:0xffff
    3092:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3095:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3098:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    309b:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    309f:	06                   	push   es
    30a0:	57                   	push   di
    30a1:	9a 16 10 ff ff       	call   0xffff:0x1016
    30a6:	50                   	push   ax
    30a7:	9a c3 30 00 00       	call   0x0:0x30c3
    30ac:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    30af:	ff 76 f4             	push   WORD PTR [bp-0xc]
    30b2:	8d 7e d2             	lea    di,[bp-0x2e]
    30b5:	16                   	push   ss
    30b6:	57                   	push   di
    30b7:	9a ff ff 00 00       	call   0x0:0xffff
    30bc:	ff 76 f4             	push   WORD PTR [bp-0xc]
    30bf:	ff 76 f2             	push   WORD PTR [bp-0xe]
    30c2:	9a ff ff 00 00       	call   0x0:0xffff
    30c7:	6a 00                	push   0x0
    30c9:	ff 76 f4             	push   WORD PTR [bp-0xc]
    30cc:	9a ff ff 00 00       	call   0x0:0xffff
    30d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d4:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    30d9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    30dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e0:	26 03 85 e6 00       	add    ax,WORD PTR es:[di+0xe6]
    30e5:	48                   	dec    ax
    30e6:	99                   	cwd
    30e7:	26 f7 bd e6 00       	idiv   WORD PTR es:[di+0xe6]
    30ec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    30ef:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    30f3:	2d 0a 00             	sub    ax,0xa
    30f6:	99                   	cwd
    30f7:	26 f7 bd e6 00       	idiv   WORD PTR es:[di+0xe6]
    30fc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    30ff:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    3103:	2b 46 d2             	sub    ax,WORD PTR [bp-0x2e]
    3106:	2d 05 00             	sub    ax,0x5
    3109:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    310c:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    310f:	99                   	cwd
    3110:	f7 7e fe             	idiv   WORD PTR [bp-0x2]
    3113:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3116:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3119:	99                   	cwd
    311a:	f7 7e fe             	idiv   WORD PTR [bp-0x2]
    311d:	92                   	xchg   dx,ax
    311e:	99                   	cwd
    311f:	b9 02 00             	mov    cx,0x2
    3122:	f7 f9                	idiv   cx
    3124:	8b d0                	mov    dx,ax
    3126:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    3129:	40                   	inc    ax
    312a:	03 c2                	add    ax,dx
    312c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    312f:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3134:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3138:	48                   	dec    ax
    3139:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    313c:	31 c0                	xor    ax,ax
    313e:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
    3141:	7f 64                	jg     0x31a7
    3143:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3146:	eb 03                	jmp    0x314b
    3148:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    314b:	ff 76 f6             	push   WORD PTR [bp-0xa]
    314e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3151:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3156:	06                   	push   es
    3157:	57                   	push   di
    3158:	9a d0 0d c9 31       	call   0x31c9:0xdd0
    315d:	89 c7                	mov    di,ax
    315f:	8e c2                	mov    es,dx
    3161:	89 7e cc             	mov    WORD PTR [bp-0x34],di
    3164:	8c 46 ce             	mov    WORD PTR [bp-0x32],es
    3167:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    316a:	99                   	cwd
    316b:	f7 7e fe             	idiv   WORD PTR [bp-0x2]
    316e:	f7 66 fc             	mul    WORD PTR [bp-0x4]
    3171:	05 08 00             	add    ax,0x8
    3174:	50                   	push   ax
    3175:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3178:	99                   	cwd
    3179:	f7 7e fe             	idiv   WORD PTR [bp-0x2]
    317c:	92                   	xchg   dx,ax
    317d:	f7 66 fa             	mul    WORD PTR [bp-0x6]
    3180:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    3183:	50                   	push   ax
    3184:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3187:	ff 76 fa             	push   WORD PTR [bp-0x6]
    318a:	06                   	push   es
    318b:	57                   	push   di
    318c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    318f:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    3193:	6a 01                	push   0x1
    3195:	c4 7e cc             	les    di,DWORD PTR [bp-0x34]
    3198:	06                   	push   es
    3199:	57                   	push   di
    319a:	9a 77 1c 44 32       	call   0x3244:0x1c77
    319f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    31a2:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
    31a5:	75 a1                	jne    0x3148
    31a7:	c9                   	leave
    31a8:	ca 04 00             	retf   0x4
    31ab:	55                   	push   bp
    31ac:	89 e5                	mov    bp,sp
    31ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31b1:	26 80 bd e9 00 00    	cmp    BYTE PTR es:[di+0xe9],0x0
    31b7:	75 24                	jne    0x31dd
    31b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    31bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    31bf:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    31c4:	06                   	push   es
    31c5:	57                   	push   di
    31c6:	9a 58 0e a4 32       	call   0x32a4:0xe58
    31cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ce:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    31d3:	06                   	push   es
    31d4:	57                   	push   di
    31d5:	b8 fe ff             	mov    ax,0xfffe
    31d8:	9a 6a 20 af 32       	call   0x32af:0x206a
    31dd:	c9                   	leave
    31de:	ca 08 00             	retf   0x8
    31e1:	c8 04 00 00          	enter  0x4,0x0
    31e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e8:	26 80 bd e8 00 00    	cmp    BYTE PTR es:[di+0xe8],0x0
    31ee:	75 39                	jne    0x3229
    31f0:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    31f5:	06                   	push   es
    31f6:	57                   	push   di
    31f7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31fa:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    31fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3201:	26 3b 85 e4 00       	cmp    ax,WORD PTR es:[di+0xe4]
    3206:	7f 17                	jg     0x321f
    3208:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    320d:	06                   	push   es
    320e:	57                   	push   di
    320f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3212:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3216:	48                   	dec    ax
    3217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    321a:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    321f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3222:	06                   	push   es
    3223:	57                   	push   di
    3224:	9a bb 33 54 32       	call   0x3254:0x33bb
    3229:	c9                   	leave
    322a:	ca 08 00             	retf   0x8
    322d:	55                   	push   bp
    322e:	89 e5                	mov    bp,sp
    3230:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3233:	26 c6 85 e8 00 01    	mov    BYTE PTR es:[di+0xe8],0x1
    3239:	ff 76 0c             	push   WORD PTR [bp+0xc]
    323c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    323f:	06                   	push   es
    3240:	57                   	push   di
    3241:	9a ec 30 2f 34       	call   0x342f:0x30ec
    3246:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3249:	26 c6 85 e8 00 00    	mov    BYTE PTR es:[di+0xe8],0x0
    324f:	06                   	push   es
    3250:	57                   	push   di
    3251:	9a bb 33 7b 32       	call   0x327b:0x33bb
    3256:	c9                   	leave
    3257:	ca 08 00             	retf   0x8
    325a:	55                   	push   bp
    325b:	89 e5                	mov    bp,sp
    325d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3260:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3265:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3269:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    326c:	7d 18                	jge    0x3286
    326e:	ff 76 08             	push   WORD PTR [bp+0x8]
    3271:	ff 76 06             	push   WORD PTR [bp+0x6]
    3274:	b0 01                	mov    al,0x1
    3276:	50                   	push   ax
    3277:	b8 f0 2c             	mov    ax,0x2cf0
    327a:	ba 82 32             	mov    dx,0x3282
    327d:	52                   	push   dx
    327e:	50                   	push   ax
    327f:	9a b0 2d ea 32       	call   0x32ea:0x2db0
    3284:	eb d7                	jmp    0x325d
    3286:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3289:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    328e:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3292:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3295:	7e 1c                	jle    0x32b3
    3297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329a:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    329f:	06                   	push   es
    32a0:	57                   	push   di
    32a1:	9a 43 0f 5b 33       	call   0x335b:0xf43
    32a6:	89 c7                	mov    di,ax
    32a8:	8e c2                	mov    es,dx
    32aa:	06                   	push   es
    32ab:	57                   	push   di
    32ac:	9a 7f 1f ff ff       	call   0xffff:0x1f7f
    32b1:	eb d3                	jmp    0x3286
    32b3:	c9                   	leave
    32b4:	ca 06 00             	retf   0x6
    32b7:	55                   	push   bp
    32b8:	89 e5                	mov    bp,sp
    32ba:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    32be:	7d 05                	jge    0x32c5
    32c0:	c7 46 0a 01 00       	mov    WORD PTR [bp+0xa],0x1
    32c5:	83 7e 0a 10          	cmp    WORD PTR [bp+0xa],0x10
    32c9:	7e 05                	jle    0x32d0
    32cb:	c7 46 0a 10 00       	mov    WORD PTR [bp+0xa],0x10
    32d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32d3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    32d8:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    32db:	74 0f                	je     0x32ec
    32dd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    32e0:	26 89 85 e6 00       	mov    WORD PTR es:[di+0xe6],ax
    32e5:	06                   	push   es
    32e6:	57                   	push   di
    32e7:	9a 67 30 d9 33       	call   0x33d9:0x3067
    32ec:	c9                   	leave
    32ed:	ca 06 00             	retf   0x6
    32f0:	55                   	push   bp
    32f1:	89 e5                	mov    bp,sp
    32f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f6:	26 80 bd e8 00 00    	cmp    BYTE PTR es:[di+0xe8],0x0
    32fc:	74 0b                	je     0x3309
    32fe:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3301:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    3306:	e9 90 00             	jmp    0x3399
    3309:	83 7e 0a ff          	cmp    WORD PTR [bp+0xa],0xffff
    330d:	7d 05                	jge    0x3314
    330f:	c7 46 0a ff ff       	mov    WORD PTR [bp+0xa],0xffff
    3314:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3317:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    331a:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    331f:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    3323:	7c 10                	jl     0x3335
    3325:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3328:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    332d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3331:	48                   	dec    ax
    3332:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    3335:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3338:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    333d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3340:	74 57                	je     0x3399
    3342:	26 83 bd e4 00 00    	cmp    WORD PTR es:[di+0xe4],0x0
    3348:	7c 1e                	jl     0x3368
    334a:	6a 00                	push   0x0
    334c:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    3351:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3356:	06                   	push   es
    3357:	57                   	push   di
    3358:	9a d0 0d 8c 33       	call   0x338c:0xdd0
    335d:	89 c7                	mov    di,ax
    335f:	8e c2                	mov    es,dx
    3361:	06                   	push   es
    3362:	57                   	push   di
    3363:	9a 4c 71 97 33       	call   0x3397:0x714c
    3368:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    336b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    336e:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    3373:	26 83 bd e4 00 00    	cmp    WORD PTR es:[di+0xe4],0x0
    3379:	7c 1e                	jl     0x3399
    337b:	6a 01                	push   0x1
    337d:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    3382:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3387:	06                   	push   es
    3388:	57                   	push   di
    3389:	9a d0 0d 24 34       	call   0x3424:0xdd0
    338e:	89 c7                	mov    di,ax
    3390:	8e c2                	mov    es,dx
    3392:	06                   	push   es
    3393:	57                   	push   di
    3394:	9a 4c 71 66 34       	call   0x3466:0x714c
    3399:	c9                   	leave
    339a:	ca 06 00             	retf   0x6
    339d:	55                   	push   bp
    339e:	89 e5                	mov    bp,sp
    33a0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33a3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a9:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    33ae:	06                   	push   es
    33af:	57                   	push   di
    33b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33b3:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    33b7:	c9                   	leave
    33b8:	ca 08 00             	retf   0x8
    33bb:	c8 04 01 00          	enter  0x104,0x0
    33bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c2:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    33c7:	06                   	push   es
    33c8:	57                   	push   di
    33c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33cc:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    33d0:	50                   	push   ax
    33d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d4:	06                   	push   es
    33d5:	57                   	push   di
    33d6:	9a 5a 32 79 34       	call   0x3479:0x325a
    33db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33de:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    33e3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    33e7:	48                   	dec    ax
    33e8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    33eb:	31 c0                	xor    ax,ax
    33ed:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    33f0:	7f 47                	jg     0x3439
    33f2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    33f5:	eb 03                	jmp    0x33fa
    33f7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    33fa:	8d be fc fe          	lea    di,[bp-0x104]
    33fe:	16                   	push   ss
    33ff:	57                   	push   di
    3400:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3403:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3406:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
    340b:	06                   	push   es
    340c:	57                   	push   di
    340d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3410:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    3414:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3417:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341a:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    341f:	06                   	push   es
    3420:	57                   	push   di
    3421:	9a d0 0d 5b 34       	call   0x345b:0xdd0
    3426:	89 c7                	mov    di,ax
    3428:	8e c2                	mov    es,dx
    342a:	06                   	push   es
    342b:	57                   	push   di
    342c:	9a 8c 1d 91 34       	call   0x3491:0x1d8c
    3431:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3434:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3437:	75 be                	jne    0x33f7
    3439:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    343c:	26 83 bd e4 00 00    	cmp    WORD PTR es:[di+0xe4],0x0
    3442:	7c 2d                	jl     0x3471
    3444:	26 c6 85 e9 00 01    	mov    BYTE PTR es:[di+0xe9],0x1
    344a:	6a 01                	push   0x1
    344c:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    3451:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3456:	06                   	push   es
    3457:	57                   	push   di
    3458:	9a d0 0d c7 34       	call   0x34c7:0xdd0
    345d:	89 c7                	mov    di,ax
    345f:	8e c2                	mov    es,dx
    3461:	06                   	push   es
    3462:	57                   	push   di
    3463:	9a 4c 71 ff ff       	call   0xffff:0x714c
    3468:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    346b:	26 c6 85 e9 00 00    	mov    BYTE PTR es:[di+0xe9],0x0
    3471:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3474:	06                   	push   es
    3475:	57                   	push   di
    3476:	9a 67 30 fb 34       	call   0x34fb:0x3067
    347b:	c9                   	leave
    347c:	ca 04 00             	retf   0x4
    347f:	c8 04 00 00          	enter  0x4,0x0
    3483:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3486:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3489:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    348c:	06                   	push   es
    348d:	57                   	push   di
    348e:	9a b3 56 d2 34       	call   0x34d2:0x56b3
    3493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3496:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    349b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    349f:	48                   	dec    ax
    34a0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34a3:	31 c0                	xor    ax,ax
    34a5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    34a8:	7f 32                	jg     0x34dc
    34aa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    34ad:	eb 03                	jmp    0x34b2
    34af:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    34b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b5:	26 8a 45 2a          	mov    al,BYTE PTR es:[di+0x2a]
    34b9:	50                   	push   ax
    34ba:	ff 76 fe             	push   WORD PTR [bp-0x2]
    34bd:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    34c2:	06                   	push   es
    34c3:	57                   	push   di
    34c4:	9a d0 0d ff ff       	call   0xffff:0xdd0
    34c9:	89 c7                	mov    di,ax
    34cb:	8e c2                	mov    es,dx
    34cd:	06                   	push   es
    34ce:	57                   	push   di
    34cf:	9a b8 1c f1 34       	call   0x34f1:0x1cb8
    34d4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    34d7:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    34da:	75 d3                	jne    0x34af
    34dc:	c9                   	leave
    34dd:	ca 08 00             	retf   0x8
    34e0:	55                   	push   bp
    34e1:	89 e5                	mov    bp,sp
    34e3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    34e6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    34e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ec:	06                   	push   es
    34ed:	57                   	push   di
    34ee:	9a 3a 57 12 35       	call   0x3512:0x573a
    34f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34f6:	06                   	push   es
    34f7:	57                   	push   di
    34f8:	9a 67 30 1c 35       	call   0x351c:0x3067
    34fd:	c9                   	leave
    34fe:	ca 08 00             	retf   0x8
    3501:	55                   	push   bp
    3502:	89 e5                	mov    bp,sp
    3504:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3507:	ff 76 0a             	push   WORD PTR [bp+0xa]
    350a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    350d:	06                   	push   es
    350e:	57                   	push   di
    350f:	9a a8 4d ff ff       	call   0xffff:0x4da8
    3514:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3517:	06                   	push   es
    3518:	57                   	push   di
    3519:	9a 67 30 ff ff       	call   0xffff:0x3067
    351e:	c9                   	leave
    351f:	ca 08 00             	retf   0x8
    3522:	c8 02 00 00          	enter  0x2,0x0
    3526:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    352a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    352d:	c9                   	leave
    352e:	ca                   	.byte 0xca
    352f:	04                   	.byte 0x4
