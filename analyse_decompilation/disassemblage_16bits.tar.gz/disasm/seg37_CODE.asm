; ================================================================
; seg37_CODE  (34686 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	25 00 c6             	and    ax,0xc600
       3:	00 00                	add    BYTE PTR [bx+si],al
       5:	00 00                	add    BYTE PTR [bx+si],al
       7:	00 b2 00 a2          	add    BYTE PTR [bp+si-0x5e00],dh
       b:	00 dc                	add    ah,bl
       d:	00 f3                	add    bl,dh
       f:	08 dd                	or     ch,bl
      11:	00 fa                	add    dl,bh
      13:	45                   	inc    bp
      14:	88 00                	mov    BYTE PTR [bx+si],al
      16:	9a 1f 06 01 cb       	call   0xcb01:0x61f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	dc 6c 78             	fsubr  QWORD PTR [si+0x78]
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 3a                	add    BYTE PTR [bp+si],bh
      27:	27                   	daa
      28:	30 00                	xor    BYTE PTR [bx+si],al
      2a:	fa                   	cli
      2b:	10 1e 01 d6          	adc    BYTE PTR ds:0xd601,bl
      2f:	14 38                	adc    al,0x38
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	44                   	inc    sp
      35:	00 32                	add    BYTE PTR [bp+si],dh
      37:	16                   	push   ss
      38:	60                   	pusha
      39:	00 ec                	add    ah,ch
      3b:	30 98 00 51          	xor    BYTE PTR [bx+si+0x5100],bl
      3f:	1b 10                	sbb    dx,WORD PTR [bx+si]
      41:	00 38                	add    BYTE PTR [bx+si],bh
      43:	50                   	push   ax
      44:	4c                   	dec    sp
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	20 3f                	and    BYTE PTR [bx],bh
      50:	bc 00 d9             	mov    sp,0xd900
      53:	62 58 00             	bound  bx,DWORD PTR [bx+si+0x0]
      56:	06                   	push   es
      57:	63 5c 00             	arpl   WORD PTR [si+0x0],bx
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	3c 00                	cmp    al,0x0
      5e:	3a 1c                	cmp    bl,BYTE PTR [si]
      60:	40                   	inc    ax
      61:	00 46 44             	add    BYTE PTR [bp+0x44],al
      64:	48                   	dec    ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 9c             	bound  bx,DWORD PTR [si-0x64]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	28 00                	sub    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	7c 00                	jl     0x7a
      7a:	29 3b                	sub    WORD PTR [bp+di],di
      7c:	80 00 17             	add    BYTE PTR [bx+si],0x17
      7f:	3e 84 00             	test   BYTE PTR ds:[bx+si],al
      82:	88 3c                	mov    BYTE PTR [si],bh
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 8c 00             	mov    WORD PTR ds:[bx+si],es
      8a:	77 3e                	ja     0xca
      8c:	54                   	push   sp
      8d:	00 7c 3f             	add    BYTE PTR [si+0x3f],bh
      90:	a0 00 26             	mov    al,ds:0x2600
      93:	6d                   	ins    WORD PTR es:[di],dx
      94:	20 00                	and    BYTE PTR [bx+si],al
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	64 00 35             	add    BYTE PTR fs:[di],dh
      9b:	62 74 00             	bound  si,DWORD PTR [si+0x0]
      9e:	f0 3f                	lock aas
      a0:	50                   	push   ax
      a1:	00 0f                	add    BYTE PTR [bx],cl
      a3:	54                   	push   sp
      a4:	43                   	inc    bx
      a5:	75 73                	jne    0x11a
      a7:	74 6f                	je     0x118
      a9:	6d                   	ins    WORD PTR es:[di],dx
      aa:	47                   	inc    di
      ab:	72 6f                	jb     0x11c
      ad:	75 70                	jne    0x11f
      af:	42                   	inc    dx
      b0:	6f                   	outs   dx,WORD PTR ds:[si]
      b1:	78 03                	js     0xb6
      b3:	00 06 0f 12          	add    BYTE PTR ds:0x120f,al
      b7:	0f 10 0f             	movups xmm1,XMMWORD PTR [bx]
      ba:	a8 41                	test   al,0x41
      bc:	c0 00 0f             	rol    BYTE PTR [bx+si],0xf
      bf:	42                   	inc    dx
      c0:	c4 00                	les    ax,DWORD PTR [bx+si]
      c2:	2c 42                	sub    al,0x42
      c4:	d9 00                	fld    DWORD PTR [bx+si]
      c6:	07                   	pop    es
      c7:	0f 54 43 75          	andps  xmm0,XMMWORD PTR [bp+di+0x75]
      cb:	73 74                	jae    0x141
      cd:	6f                   	outs   dx,WORD PTR ds:[si]
      ce:	6d                   	ins    WORD PTR es:[di],dx
      cf:	47                   	inc    di
      d0:	72 6f                	jb     0x141
      d2:	75 70                	jne    0x144
      d4:	42                   	inc    dx
      d5:	6f                   	outs   dx,WORD PTR ds:[si]
      d6:	78 22                	js     0xfa
      d8:	00 7a 01             	add    BYTE PTR [bp+si+0x1],bh
      db:	8a 09                	mov    cl,BYTE PTR [bx+di]
      dd:	7e 01                	jle    0xe0
      df:	09 00                	or     WORD PTR [bx+si],ax
      e1:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
      e4:	64 43                	fs inc bx
      e6:	74 72                	je     0x15a
      e8:	6c                   	ins    BYTE PTR es:[di],dx
      e9:	73 00                	jae    0xeb
      eb:	00 96 01 00          	add    BYTE PTR [bp+0x1],dl
      ef:	00 00                	add    BYTE PTR [bx+si],al
      f1:	00 00                	add    BYTE PTR [bx+si],al
      f3:	00 8c 01 dc          	add    BYTE PTR [si-0x23ff],cl
      f7:	00 22                	add    BYTE PTR [bp+si],ah
      f9:	00 a3 01 fa          	add    BYTE PTR [bp+di-0x5ff],ah
      fd:	45                   	inc    bp
      fe:	72 01                	jb     0x101
     100:	9a 1f 14 02 cb       	call   0xcb02:0x141f
     105:	1f                   	pop    ds
     106:	02 01                	add    al,BYTE PTR [bx+di]
     108:	dc 6c 62             	fsubr  QWORD PTR [si+0x62]
     10b:	01 cd                	add    bp,cx
     10d:	11 16 01 3a          	adc    WORD PTR ds:0x3a01,dx
     111:	27                   	daa
     112:	1a 01                	sbb    al,BYTE PTR [bx+di]
     114:	fa                   	cli
     115:	10 e9                	adc    cl,ch
     117:	03 d6                	add    dx,si
     119:	14 22                	adc    al,0x22
     11b:	01 f4                	add    sp,si
     11d:	4f                   	dec    di
     11e:	2e 01 32             	add    WORD PTR cs:[bp+si],si
     121:	16                   	push   ss
     122:	4a                   	dec    dx
     123:	01 ec                	add    sp,bp
     125:	30 82 01 51          	xor    BYTE PTR [bp+si+0x5101],al
     129:	1b b8 01 38          	sbb    di,WORD PTR [bx+si+0x3801]
     12d:	50                   	push   ax
     12e:	36 01 63 31          	add    WORD PTR ss:[bp+di+0x31],sp
     132:	52                   	push   dx
     133:	01 21                	add    WORD PTR [bx+di],sp
     135:	50                   	push   ax
     136:	0e                   	push   cs
     137:	01 20                	add    WORD PTR [bx+si],sp
     139:	3f                   	aas
     13a:	fa                   	cli
     13b:	00 d9                	add    cl,bl
     13d:	62 42 01             	bound  ax,DWORD PTR [bp+si+0x1]
     140:	06                   	push   es
     141:	63 46 01             	arpl   WORD PTR [bp+0x1],ax
     144:	8f                   	(bad)
     145:	60                   	pusha
     146:	26 01 3a             	add    WORD PTR es:[bp+si],di
     149:	1c 2a                	sbb    al,0x2a
     14b:	01 46 44             	add    WORD PTR [bp+0x44],ax
     14e:	32 01                	xor    al,BYTE PTR [bx+di]
     150:	08 61 56             	or     BYTE PTR [bx+di+0x56],ah
     153:	01 5c 61             	add    WORD PTR [si+0x61],bx
     156:	5a                   	pop    dx
     157:	01 62 5c             	add    WORD PTR [bp+si+0x5c],sp
     15a:	86 01                	xchg   BYTE PTR [bx+di],al
     15c:	3a 61 12             	cmp    ah,BYTE PTR [bx+di+0x12]
     15f:	01 72 3f             	add    WORD PTR [bp+si+0x3f],si
     162:	66 01 29             	add    DWORD PTR [bx+di],ebp
     165:	3b 6a 01             	cmp    bp,WORD PTR [bp+si+0x1]
     168:	17                   	pop    ss
     169:	3e 6e                	outs   dx,BYTE PTR ds:[si]
     16b:	01 88 3c fe          	add    WORD PTR [bx+si-0x1c4],cx
     16f:	00 ed                	add    ch,ch
     171:	3e 76 01             	ds jbe 0x175
     174:	77 3e                	ja     0x1b4
     176:	3e 01 7c 3f          	add    WORD PTR ds:[si+0x3f],di
     17a:	8a 01                	mov    al,BYTE PTR [bx+di]
     17c:	26 6d                	es ins WORD PTR es:[di],dx
     17e:	0a 01                	or     al,BYTE PTR [bx+di]
     180:	ae                   	scas   al,BYTE PTR es:[di]
     181:	5f                   	pop    di
     182:	4e                   	dec    si
     183:	01 35                	add    WORD PTR [di],si
     185:	62 5e 01             	bound  bx,DWORD PTR [bp+0x1]
     188:	f0 3f                	lock aas
     18a:	3a 01                	cmp    al,BYTE PTR [bx+di]
     18c:	09 54 47             	or     WORD PTR [si+0x47],dx
     18f:	72 6f                	jb     0x200
     191:	75 70                	jne    0x203
     193:	42                   	inc    dx
     194:	6f                   	outs   dx,WORD PTR ds:[si]
     195:	78 07                	js     0x19e
     197:	09 54 47             	or     WORD PTR [si+0x47],dx
     19a:	72 6f                	jb     0x20b
     19c:	75 70                	jne    0x20e
     19e:	42                   	inc    dx
     19f:	6f                   	outs   dx,WORD PTR ds:[si]
     1a0:	78 0c                	js     0x1ae
     1a2:	01 a7 01 c6          	add    WORD PTR [bx-0x39ff],sp
     1a6:	00 71 05             	add    BYTE PTR [bx+di+0x5],dh
     1a9:	24 00                	and    al,0x0
     1ab:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
     1ae:	64 43                	fs inc bx
     1b0:	74 72                	je     0x224
     1b2:	6c                   	ins    BYTE PTR es:[di],dx
     1b3:	73 1b                	jae    0x1d0
     1b5:	00 e2                	add    dl,ah
     1b7:	00 c0                	add    al,al
     1b9:	01 2d                	add    WORD PTR [di],bp
     1bb:	00 ff                	add    bh,bh
     1bd:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     1c0:	d6                   	(bad)
     1c1:	01 01                	add    WORD PTR [bx+di],ax
     1c3:	00 00                	add    BYTE PTR [bx+si],al
     1c5:	00 00                	add    BYTE PTR [bx+si],al
     1c7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1ca:	00 00                	add    BYTE PTR [bx+si],al
     1cc:	09 00                	or     WORD PTR [bx+si],ax
     1ce:	05 41 6c             	add    ax,0x6c41
     1d1:	69 67 6e 66 01       	imul   sp,WORD PTR [bx+0x6e],0x166
     1d6:	da 01                	fiadd  DWORD PTR [bx+di]
     1d8:	53                   	push   bx
     1d9:	1d de 01             	sbb    ax,0x1de
     1dc:	8c 1d                	mov    WORD PTR [di],ds
     1de:	fe 01                	inc    BYTE PTR [bx+di]
     1e0:	01 00                	add    WORD PTR [bx+si],ax
     1e2:	00 00                	add    BYTE PTR [bx+si],al
     1e4:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     1e8:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     1ec:	07                   	pop    es
     1ed:	43                   	inc    bx
     1ee:	61                   	popa
     1ef:	70 74                	jo     0x265
     1f1:	69 6f 6e 02 00       	imul   bp,WORD PTR [bx+0x6e],0x2
     1f6:	96                   	xchg   si,ax
     1f7:	02 38                	add    bh,BYTE PTR [bx+si]
     1f9:	00 ff                	add    bh,bh
     1fb:	ff d5                	call   bp
     1fd:	1e                   	push   ds
     1fe:	02 02                	add    al,BYTE PTR [bp+si]
     200:	17                   	pop    ss
     201:	1f                   	pop    ds
     202:	1c 02                	sbb    al,0x2
     204:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     208:	ff                   	(bad)
     209:	ff 0b                	dec    WORD PTR [bp+di]
     20b:	00 05                	add    BYTE PTR [di],al
     20d:	43                   	inc    bx
     20e:	6f                   	outs   dx,WORD PTR ds:[si]
     20f:	6c                   	ins    BYTE PTR es:[di],dx
     210:	6f                   	outs   dx,WORD PTR ds:[si]
     211:	72 07                	jb     0x21a
     213:	23 76 02             	and    si,WORD PTR [bp+0x2]
     216:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     217:	00 ff                	add    bh,bh
     219:	ff 22                	jmp    WORD PTR [bp+si]
     21b:	63 20                	arpl   WORD PTR [bx+si],sp
     21d:	02 54 63             	add    dl,BYTE PTR [si+0x63]
     220:	32 02                	xor    al,BYTE PTR [bp+si]
     222:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     226:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     22a:	05 43 74             	add    ax,0x7443
     22d:	6c                   	ins    BYTE PTR es:[di],dx
     22e:	33 44 64             	xor    ax,WORD PTR [si+0x64]
     231:	00 55 02             	add    BYTE PTR [di+0x2],dl
     234:	3e 00 ff             	ds add bh,bh
     237:	ff                   	(bad)
     238:	3e 00 ff             	ds add bh,bh
     23b:	ff 01                	inc    WORD PTR [bx+di]
     23d:	00 00                	add    BYTE PTR [bx+si],al
     23f:	00 00                	add    BYTE PTR [bx+si],al
     241:	80 f4 ff             	xor    ah,0xff
     244:	ff                   	(bad)
     245:	ff 0d                	dec    WORD PTR [di]
     247:	00 0a                	add    BYTE PTR [bp+si],cl
     249:	44                   	inc    sp
     24a:	72 61                	jb     0x2ad
     24c:	67 43                	addr32 inc bx
     24e:	75 72                	jne    0x2c2
     250:	73 6f                	jae    0x2c1
     252:	72 25                	jb     0x279
     254:	01 7e 02             	add    WORD PTR [bp+0x2],di
     257:	2e 00 ff             	cs add bh,bh
     25a:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     25e:	ff 01                	inc    WORD PTR [bx+di]
     260:	00 00                	add    BYTE PTR [bx+si],al
     262:	00 00                	add    BYTE PTR [bx+si],al
     264:	80 00 00             	add    BYTE PTR [bx+si],0x0
     267:	00 00                	add    BYTE PTR [bx+si],al
     269:	0e                   	push   cs
     26a:	00 08                	add    BYTE PTR [bx+si],cl
     26c:	44                   	inc    sp
     26d:	72 61                	jb     0x2d0
     26f:	67 4d                	addr32 dec bp
     271:	6f                   	outs   dx,WORD PTR ds:[si]
     272:	64 65 07             	fs gs pop es
     275:	23 b3 02 2a          	and    si,WORD PTR [bp+di+0x2a02]
     279:	00 ff                	add    bh,bh
     27b:	ff                   	(bad)
     27c:	b8 1c 9e             	mov    ax,0x9e1c
     27f:	02 01                	add    al,BYTE PTR [bx+di]
     281:	00 00                	add    BYTE PTR [bx+si],al
     283:	00 00                	add    BYTE PTR [bx+si],al
     285:	80 01 00             	add    BYTE PTR [bx+di],0x0
     288:	00 00                	add    BYTE PTR [bx+si],al
     28a:	0f 00 07             	sldt   WORD PTR [bx]
     28d:	45                   	inc    bp
     28e:	6e                   	outs   dx,BYTE PTR ds:[si]
     28f:	61                   	popa
     290:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     293:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     296:	16                   	push   ss
     297:	07                   	pop    es
     298:	34 00                	xor    al,0x0
     29a:	ff                   	(bad)
     29b:	ff                   	jmp    (bad)
     29c:	eb 1d                	jmp    0x2bb
     29e:	a2 02 08             	mov    ds:0x802,al
     2a1:	1e                   	push   ds
     2a2:	bb 02 00             	mov    bx,0x2
     2a5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2a8:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     2ac:	04 46                	add    al,0x46
     2ae:	6f                   	outs   dx,WORD PTR ds:[si]
     2af:	6e                   	outs   dx,BYTE PTR ds:[si]
     2b0:	74 07                	je     0x2b9
     2b2:	23 d7                	and    dx,di
     2b4:	02 2c                	add    ch,BYTE PTR [si]
     2b6:	00 ff                	add    bh,bh
     2b8:	ff 32                	push   WORD PTR [bp+si]
     2ba:	1f                   	pop    ds
     2bb:	df 02                	fild   WORD PTR [bp+si]
     2bd:	01 00                	add    WORD PTR [bx+si],ax
     2bf:	00 00                	add    BYTE PTR [bx+si],al
     2c1:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     2c5:	00 00                	add    BYTE PTR [bx+si],al
     2c7:	11 00                	adc    WORD PTR [bx+si],ax
     2c9:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     2cc:	72 65                	jb     0x333
     2ce:	6e                   	outs   dx,BYTE PTR ds:[si]
     2cf:	74 43                	je     0x314
     2d1:	6f                   	outs   dx,WORD PTR ds:[si]
     2d2:	6c                   	ins    BYTE PTR es:[di],dx
     2d3:	6f                   	outs   dx,WORD PTR ds:[si]
     2d4:	72 07                	jb     0x2dd
     2d6:	23 fb                	and    di,bx
     2d8:	02 a6 00 ff          	add    ah,BYTE PTR [bp-0x100]
     2dc:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     2df:	03 03                	add    ax,WORD PTR [bp+di]
     2e1:	01 00                	add    WORD PTR [bx+si],ax
     2e3:	00 00                	add    BYTE PTR [bx+si],al
     2e5:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     2e9:	00 00                	add    BYTE PTR [bx+si],al
     2eb:	12 00                	adc    al,BYTE PTR [bx+si]
     2ed:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     2f0:	72 65                	jb     0x357
     2f2:	6e                   	outs   dx,BYTE PTR ds:[si]
     2f3:	74 43                	je     0x338
     2f5:	74 6c                	je     0x363
     2f7:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     2fa:	23 1e 03 2b          	and    bx,WORD PTR ds:0x2b03
     2fe:	00 ff                	add    bh,bh
     300:	ff                   	(bad)
     301:	3e 1e                	ds push ds
     303:	26 03 01             	add    ax,WORD PTR es:[bx+di]
     306:	00 00                	add    BYTE PTR [bx+si],al
     308:	00 00                	add    BYTE PTR [bx+si],al
     30a:	80 01 00             	add    BYTE PTR [bx+di],0x0
     30d:	00 00                	add    BYTE PTR [bx+si],al
     30f:	13 00                	adc    ax,WORD PTR [bx+si]
     311:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     314:	72 65                	jb     0x37b
     316:	6e                   	outs   dx,BYTE PTR ds:[si]
     317:	74 46                	je     0x35f
     319:	6f                   	outs   dx,WORD PTR ds:[si]
     31a:	6e                   	outs   dx,BYTE PTR ds:[si]
     31b:	74 07                	je     0x324
     31d:	23 67 03             	and    sp,WORD PTR [bx+0x3]
     320:	49                   	dec    cx
     321:	00 ff                	add    bh,bh
     323:	ff a1 1e 6f          	jmp    WORD PTR [bx+di+0x6f1e]
     327:	03 01                	add    ax,WORD PTR [bx+di]
     329:	00 00                	add    BYTE PTR [bx+si],al
     32b:	00 00                	add    BYTE PTR [bx+si],al
     32d:	80 01 00             	add    BYTE PTR [bx+di],0x0
     330:	00 00                	add    BYTE PTR [bx+si],al
     332:	14 00                	adc    al,0x0
     334:	0e                   	push   cs
     335:	50                   	push   ax
     336:	61                   	popa
     337:	72 65                	jb     0x39e
     339:	6e                   	outs   dx,BYTE PTR ds:[si]
     33a:	74 53                	je     0x38f
     33c:	68 6f 77             	push   0x776f
     33f:	48                   	dec    ax
     340:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     345:	48                   	dec    ax
     346:	08 40 00             	or     BYTE PTR [bx+si+0x0],al
     349:	ff                   	(bad)
     34a:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     34d:	ff                   	(bad)
     34e:	ff 01                	inc    WORD PTR [bx+di]
     350:	00 00                	add    BYTE PTR [bx+si],al
     352:	00 00                	add    BYTE PTR [bx+si],al
     354:	80 00 00             	add    BYTE PTR [bx+si],0x0
     357:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     35b:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     35e:	70 75                	jo     0x3d5
     360:	70 4d                	jo     0x3af
     362:	65 6e                	outs   dx,BYTE PTR gs:[si]
     364:	75 07                	jne    0x36d
     366:	23 a9 03 48          	and    bp,WORD PTR [bx+di+0x4803]
     36a:	00 ff                	add    bh,bh
     36c:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     36f:	73 03                	jae    0x374
     371:	23 1e 88 03          	and    bx,WORD PTR ds:0x388
     375:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     379:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     37d:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     380:	6f                   	outs   dx,WORD PTR ds:[si]
     381:	77 48                	ja     0x3cb
     383:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     388:	8c 03                	mov    WORD PTR [bp+di],es
     38a:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     38b:	63 90 03 60          	arpl   WORD PTR [bx+si+0x6003],dx
     38f:	64 b1 03             	fs mov cl,0x3
     392:	01 00                	add    WORD PTR [bx+si],ax
     394:	00 00                	add    BYTE PTR [bx+si],al
     396:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     39a:	ff                   	(bad)
     39b:	ff 17                	call   WORD PTR [bx]
     39d:	00 08                	add    BYTE PTR [bx+si],cl
     39f:	54                   	push   sp
     3a0:	61                   	popa
     3a1:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     3a4:	64 65 72 07          	fs gs jb 0x3af
     3a8:	23 c9                	and    cx,cx
     3aa:	03 a4 00 ff          	add    sp,WORD PTR [si-0x100]
     3ae:	ff 88 64 d1          	dec    WORD PTR [bx+si-0x2e9c]
     3b2:	03 01                	add    ax,WORD PTR [bx+di]
     3b4:	00 00                	add    BYTE PTR [bx+si],al
     3b6:	00 00                	add    BYTE PTR [bx+si],al
     3b8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3bb:	00 00                	add    BYTE PTR [bx+si],al
     3bd:	18 00                	sbb    BYTE PTR [bx+si],al
     3bf:	07                   	pop    es
     3c0:	54                   	push   sp
     3c1:	61                   	popa
     3c2:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     3c5:	6f                   	outs   dx,WORD PTR ds:[si]
     3c6:	70 07                	jo     0x3cf
     3c8:	23 55 05             	and    dx,WORD PTR [di+0x5]
     3cb:	29 00                	sub    WORD PTR [bx+si],ax
     3cd:	ff                   	(bad)
     3ce:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     3d1:	2c 04                	sub    al,0x4
     3d3:	01 00                	add    WORD PTR [bx+si],ax
     3d5:	00 00                	add    BYTE PTR [bx+si],al
     3d7:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     3db:	00 00                	add    BYTE PTR [bx+si],al
     3dd:	19 00                	sbb    WORD PTR [bx+si],ax
     3df:	07                   	pop    es
     3e0:	56                   	push   si
     3e1:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     3e6:	65 71 00             	gs jno 0x3e9
     3e9:	09 04                	or     WORD PTR [si],ax
     3eb:	7a 00                	jp     0x3ed
     3ed:	ff                   	(bad)
     3ee:	ff                   	(bad)
     3ef:	7a 00                	jp     0x3f1
     3f1:	ff                   	(bad)
     3f2:	ff 01                	inc    WORD PTR [bx+di]
     3f4:	00 00                	add    BYTE PTR [bx+si],al
     3f6:	00 00                	add    BYTE PTR [bx+si],al
     3f8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3fb:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     3ff:	07                   	pop    es
     400:	4f                   	dec    di
     401:	6e                   	outs   dx,BYTE PTR ds:[si]
     402:	43                   	inc    bx
     403:	6c                   	ins    BYTE PTR es:[di],dx
     404:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     409:	94                   	xchg   sp,ax
     40a:	04 82                	add    al,0x82
     40c:	00 ff                	add    bh,bh
     40e:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     412:	ff 01                	inc    WORD PTR [bx+di]
     414:	00 00                	add    BYTE PTR [bx+si],al
     416:	00 00                	add    BYTE PTR [bx+si],al
     418:	80 00 00             	add    BYTE PTR [bx+si],0x0
     41b:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     41f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     422:	44                   	inc    sp
     423:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     426:	6c                   	ins    BYTE PTR es:[di],dx
     427:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     42c:	4f                   	dec    di
     42d:	04 62                	add    al,0x62
     42f:	00 ff                	add    bh,bh
     431:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     434:	ff                   	(bad)
     435:	ff 01                	inc    WORD PTR [bx+di]
     437:	00 00                	add    BYTE PTR [bx+si],al
     439:	00 00                	add    BYTE PTR [bx+si],al
     43b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     43e:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     442:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     445:	44                   	inc    sp
     446:	72 61                	jb     0x4a9
     448:	67 44                	addr32 inc sp
     44a:	72 6f                	jb     0x4bb
     44c:	70 80                	jo     0x3ce
     44e:	02 72 04             	add    dh,BYTE PTR [bp+si+0x4]
     451:	6a 00                	push   0x0
     453:	ff                   	(bad)
     454:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     457:	ff                   	(bad)
     458:	ff 01                	inc    WORD PTR [bx+di]
     45a:	00 00                	add    BYTE PTR [bx+si],al
     45c:	00 00                	add    BYTE PTR [bx+si],al
     45e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     461:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     465:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     468:	44                   	inc    sp
     469:	72 61                	jb     0x4cc
     46b:	67 4f                	addr32 dec di
     46d:	76 65                	jbe    0x4d4
     46f:	72 32                	jb     0x4a3
     471:	03 d3                	add    dx,bx
     473:	04 72                	add    al,0x72
     475:	00 ff                	add    bh,bh
     477:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     47a:	ff                   	(bad)
     47b:	ff 01                	inc    WORD PTR [bx+di]
     47d:	00 00                	add    BYTE PTR [bx+si],al
     47f:	00 00                	add    BYTE PTR [bx+si],al
     481:	80 00 00             	add    BYTE PTR [bx+si],0x0
     484:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     488:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     48b:	45                   	inc    bp
     48c:	6e                   	outs   dx,BYTE PTR ds:[si]
     48d:	64 44                	fs inc sp
     48f:	72 61                	jb     0x4f2
     491:	67 71 00             	addr32 jno 0x494
     494:	b4 04                	mov    ah,0x4
     496:	c8 00 ff ff          	enter  0xff00,0xff
     49a:	c8 00 ff ff          	enter  0xff00,0xff
     49e:	01 00                	add    WORD PTR [bx+si],ax
     4a0:	00 00                	add    BYTE PTR [bx+si],al
     4a2:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     4a6:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     4aa:	07                   	pop    es
     4ab:	4f                   	dec    di
     4ac:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ad:	45                   	inc    bp
     4ae:	6e                   	outs   dx,BYTE PTR ds:[si]
     4af:	74 65                	je     0x516
     4b1:	72 71                	jb     0x524
     4b3:	00 6d 05             	add    BYTE PTR [di+0x5],ch
     4b6:	d0 00                	rol    BYTE PTR [bx+si],1
     4b8:	ff                   	(bad)
     4b9:	ff d0                	call   ax
     4bb:	00 ff                	add    bh,bh
     4bd:	ff 01                	inc    WORD PTR [bx+di]
     4bf:	00 00                	add    BYTE PTR [bx+si],al
     4c1:	00 00                	add    BYTE PTR [bx+si],al
     4c3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4c6:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     4ca:	06                   	push   es
     4cb:	4f                   	dec    di
     4cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     4cd:	45                   	inc    bp
     4ce:	78 69                	js     0x539
     4d0:	74 71                	je     0x543
     4d2:	01 f7                	add    di,si
     4d4:	04 4a                	add    al,0x4a
     4d6:	00 ff                	add    bh,bh
     4d8:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     4db:	ff                   	(bad)
     4dc:	ff 01                	inc    WORD PTR [bx+di]
     4de:	00 00                	add    BYTE PTR [bx+si],al
     4e0:	00 00                	add    BYTE PTR [bx+si],al
     4e2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4e5:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     4e9:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     4ec:	4d                   	dec    bp
     4ed:	6f                   	outs   dx,WORD PTR ds:[si]
     4ee:	75 73                	jne    0x563
     4f0:	65 44                	gs inc sp
     4f2:	6f                   	outs   dx,WORD PTR ds:[si]
     4f3:	77 6e                	ja     0x563
     4f5:	ce                   	into
     4f6:	01 1b                	add    WORD PTR [bp+di],bx
     4f8:	05 52 00             	add    ax,0x52
     4fb:	ff                   	(bad)
     4fc:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     4ff:	ff                   	(bad)
     500:	ff 01                	inc    WORD PTR [bx+di]
     502:	00 00                	add    BYTE PTR [bx+si],al
     504:	00 00                	add    BYTE PTR [bx+si],al
     506:	80 00 00             	add    BYTE PTR [bx+si],0x0
     509:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     50d:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     510:	4d                   	dec    bp
     511:	6f                   	outs   dx,WORD PTR ds:[si]
     512:	75 73                	jne    0x587
     514:	65 4d                	gs dec bp
     516:	6f                   	outs   dx,WORD PTR ds:[si]
     517:	76 65                	jbe    0x57e
     519:	71 01                	jno    0x51c
     51b:	59                   	pop    cx
     51c:	05 5a 00             	add    ax,0x5a
     51f:	ff                   	(bad)
     520:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     523:	ff                   	(bad)
     524:	ff 01                	inc    WORD PTR [bx+di]
     526:	00 00                	add    BYTE PTR [bx+si],al
     528:	00 00                	add    BYTE PTR [bx+si],al
     52a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     52d:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     531:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     534:	4d                   	dec    bp
     535:	6f                   	outs   dx,WORD PTR ds:[si]
     536:	75 73                	jne    0x5ab
     538:	65 55                	gs push bp
     53a:	70 d4                	jo     0x510
     53c:	05 00 00             	add    ax,0x0
     53f:	00 00                	add    BYTE PTR [bx+si],al
     541:	c0 05 b3             	rol    BYTE PTR [di],0xb3
     544:	05 96 00             	add    ax,0x96
     547:	3d 08 e8             	cmp    ax,0xe808
     54a:	05 10 26             	add    ax,0x2610
     54d:	61                   	popa
     54e:	05 9a 1f             	add    ax,0x1f9a
     551:	11 06 cb 1f          	adc    WORD PTR ds:0x1fcb,ax
     555:	51                   	push   cx
     556:	05 f0 68             	add    ax,0x68f0
     559:	4d                   	dec    bp
     55a:	05 cd 11             	add    ax,0x11cd
     55d:	65 05 3a 27          	gs add ax,0x273a
     561:	8d 05                	lea    ax,[di]
     563:	fa                   	cli
     564:	10 29                	adc    BYTE PTR [bx+di],ch
     566:	06                   	push   es
     567:	d6                   	(bad)
     568:	14 75                	adc    al,0x75
     56a:	05 f4 4f             	add    ax,0x4ff4
     56d:	7d 05                	jge    0x574
     56f:	0a 46 b1             	or     al,BYTE PTR [bp-0x4f]
     572:	05 98 15             	add    ax,0x1598
     575:	99                   	cwd
     576:	05 51 1b             	add    ax,0x1b51
     579:	9d                   	popf
     57a:	05 38 50             	add    ax,0x5038
     57d:	81 05 1a 50          	add    WORD PTR [di],0x501a
     581:	85 05                	test   WORD PTR [di],ax
     583:	21 50 5d             	and    WORD PTR [bx+si+0x5d],dx
     586:	05 59 42             	add    ax,0x4259
     589:	ca 05 3f             	retf   0x3f05
     58c:	19 91 05 78          	sbb    WORD PTR [bx+di+0x7805],dx
     590:	18 95 05 02          	sbb    BYTE PTR [di+0x205],dl
     594:	21 69 05             	and    WORD PTR [bx+di+0x5],bp
     597:	3a 1c                	cmp    bl,BYTE PTR [si]
     599:	79 05                	jns    0x5a0
     59b:	15 25 a1             	adc    ax,0xa125
     59e:	05 37 22             	add    ax,0x2237
     5a1:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     5a2:	05 df 22             	add    ax,0x22df
     5a5:	a9 05 f8             	test   ax,0xf805
     5a8:	16                   	push   ss
     5a9:	ad                   	lods   ax,WORD PTR ds:[si]
     5aa:	05 a5 22             	add    ax,0x22a5
     5ad:	49                   	dec    cx
     5ae:	05 93 43             	add    ax,0x4393
     5b1:	89 05                	mov    WORD PTR [di],ax
     5b3:	0c 54                	or     al,0x54
     5b5:	43                   	inc    bx
     5b6:	75 73                	jne    0x62b
     5b8:	74 6f                	je     0x629
     5ba:	6d                   	ins    WORD PTR es:[di],dx
     5bb:	4c                   	dec    sp
     5bc:	61                   	popa
     5bd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5c0:	03 00                	add    ax,WORD PTR [bx+si]
     5c2:	12 0f                	adc    cl,BYTE PTR [bx]
     5c4:	0e                   	push   cs
     5c5:	0f 06                	clts
     5c7:	0f 4e 46 ce          	cmovle ax,WORD PTR [bp-0x32]
     5cb:	05 6b 46             	add    ax,0x466b
     5ce:	d2 05                	rol    BYTE PTR [di],cl
     5d0:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
     5d3:	05 07 0c             	add    ax,0xc07
     5d6:	54                   	push   sp
     5d7:	43                   	inc    bx
     5d8:	75 73                	jne    0x64d
     5da:	74 6f                	je     0x64b
     5dc:	6d                   	ins    WORD PTR es:[di],dx
     5dd:	4c                   	dec    sp
     5de:	61                   	popa
     5df:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5e2:	5b                   	pop    bx
     5e3:	05 2d 06             	add    ax,0x62d
     5e6:	ad                   	lods   ax,WORD PTR ds:[si]
     5e7:	08 15                	or     BYTE PTR [di],dl
     5e9:	06                   	push   es
     5ea:	08 00                	or     BYTE PTR [bx+si],al
     5ec:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
     5ef:	64 43                	fs inc bx
     5f1:	74 72                	je     0x665
     5f3:	6c                   	ins    BYTE PTR es:[di],dx
     5f4:	73 00                	jae    0x5f6
     5f6:	00 76 06             	add    BYTE PTR [bp+0x6],dh
     5f9:	00 00                	add    BYTE PTR [bx+si],al
     5fb:	00 00                	add    BYTE PTR [bx+si],al
     5fd:	00 00                	add    BYTE PTR [bx+si],al
     5ff:	6f                   	outs   dx,WORD PTR ds:[si]
     600:	06                   	push   es
     601:	96                   	xchg   si,ax
     602:	00 5b 05             	add    BYTE PTR [bp+di+0x5],bl
     605:	80 06 10 26 1d       	add    BYTE PTR ds:0x2610,0x1d
     60a:	06                   	push   es
     60b:	9a 1f d5 06 cb       	call   0xcb06:0xd51f
     610:	1f                   	pop    ds
     611:	0d 06 f0             	or     ax,0xf006
     614:	68 09 06             	push   0x609
     617:	cd 11                	int    0x11
     619:	21 06 3a 27          	and    WORD PTR ds:0x273a,ax
     61d:	49                   	dec    cx
     61e:	06                   	push   es
     61f:	fa                   	cli
     620:	10 b3 06 d6          	adc    BYTE PTR [bp+di-0x29fa],dh
     624:	14 31                	adc    al,0x31
     626:	06                   	push   es
     627:	f4                   	hlt
     628:	4f                   	dec    di
     629:	39 06 0a 46          	cmp    WORD PTR ds:0x460a,ax
     62d:	6d                   	ins    WORD PTR es:[di],dx
     62e:	06                   	push   es
     62f:	98                   	cbw
     630:	15 55 06             	adc    ax,0x655
     633:	51                   	push   cx
     634:	1b 59 06             	sbb    bx,WORD PTR [bx+di+0x6]
     637:	38 50 3d             	cmp    BYTE PTR [bx+si+0x3d],dl
     63a:	06                   	push   es
     63b:	1a 50 41             	sbb    dl,BYTE PTR [bx+si+0x41]
     63e:	06                   	push   es
     63f:	21 50 19             	and    WORD PTR [bx+si+0x19],dx
     642:	06                   	push   es
     643:	59                   	pop    cx
     644:	42                   	inc    dx
     645:	05 06 3f             	add    ax,0x3f06
     648:	19 4d 06             	sbb    WORD PTR [di+0x6],cx
     64b:	78 18                	js     0x665
     64d:	51                   	push   cx
     64e:	06                   	push   es
     64f:	02 21                	add    ah,BYTE PTR [bx+di]
     651:	25 06 3a             	and    ax,0x3a06
     654:	1c 35                	sbb    al,0x35
     656:	06                   	push   es
     657:	15 25 5d             	adc    ax,0x5d25
     65a:	06                   	push   es
     65b:	37                   	aaa
     65c:	22 61 06             	and    ah,BYTE PTR [bx+di+0x6]
     65f:	df 22                	fbld   TBYTE PTR [bp+si]
     661:	65 06                	gs push es
     663:	f8                   	clc
     664:	16                   	push   ss
     665:	69 06 a5 22 95 06    	imul   ax,WORD PTR ds:0x22a5,0x695
     66b:	93                   	xchg   bx,ax
     66c:	43                   	inc    bx
     66d:	45                   	inc    bp
     66e:	06                   	push   es
     66f:	06                   	push   es
     670:	54                   	push   sp
     671:	4c                   	dec    sp
     672:	61                   	popa
     673:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     676:	07                   	pop    es
     677:	06                   	push   es
     678:	54                   	push   sp
     679:	4c                   	dec    sp
     67a:	61                   	popa
     67b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     67e:	17                   	pop    ss
     67f:	06                   	push   es
     680:	84 06 d4 05          	test   BYTE PTR ds:0x5d4,al
     684:	bb 06 23             	mov    bx,0x2306
     687:	00 08                	add    BYTE PTR [bx+si],cl
     689:	53                   	push   bx
     68a:	74 64                	je     0x6f0
     68c:	43                   	inc    bx
     68d:	74 72                	je     0x701
     68f:	6c                   	ins    BYTE PTR es:[di],dx
     690:	73 1b                	jae    0x6ad
     692:	00 e2                	add    dl,ah
     694:	00 9d 06 2d          	add    BYTE PTR [di+0x2d06],bl
     698:	00 ff                	add    bh,bh
     69a:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     69d:	f6 06 01 00 00       	test   BYTE PTR ds:0x1,0x0
     6a2:	00 00                	add    BYTE PTR [bx+si],al
     6a4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6a7:	00 00                	add    BYTE PTR [bx+si],al
     6a9:	08 00                	or     BYTE PTR [bx+si],al
     6ab:	05 41 6c             	add    ax,0x6c41
     6ae:	69 67 6e 02 00       	imul   sp,WORD PTR [bx+0x6e],0x2
     6b3:	16                   	push   ss
     6b4:	09 92 00 ff          	or     WORD PTR [bp+si-0x100],dx
     6b8:	ff 19                	call   DWORD PTR [bx+di]
     6ba:	45                   	inc    bp
     6bb:	dd 06 01 00          	fld    QWORD PTR ds:0x1
     6bf:	00 00                	add    BYTE PTR [bx+si],al
     6c1:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     6c5:	00 00                	add    BYTE PTR [bx+si],al
     6c7:	09 00                	or     WORD PTR [bx+si],ax
     6c9:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     6cc:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     6d1:	6e                   	outs   dx,BYTE PTR ds:[si]
     6d2:	74 07                	je     0x6db
     6d4:	23 78 07             	and    di,WORD PTR [bx+si+0x7]
     6d7:	93                   	xchg   bx,ax
     6d8:	00 ff                	add    bh,bh
     6da:	ff                   	(bad)
     6db:	3e 45                	ds inc bp
     6dd:	72 08                	jb     0x6e7
     6df:	01 00                	add    WORD PTR [bx+si],ax
     6e1:	00 00                	add    BYTE PTR [bx+si],al
     6e3:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6e7:	00 00                	add    BYTE PTR [bx+si],al
     6e9:	0a 00                	or     al,BYTE PTR [bx+si]
     6eb:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     6ee:	74 6f                	je     0x75f
     6f0:	53                   	push   bx
     6f1:	69 7a 65 66 01       	imul   di,WORD PTR [bp+si+0x65],0x166
     6f6:	fa                   	cli
     6f7:	06                   	push   es
     6f8:	53                   	push   bx
     6f9:	1d fe 06             	sbb    ax,0x6fe
     6fc:	8c 1d                	mov    WORD PTR [di],ds
     6fe:	1e                   	push   ds
     6ff:	07                   	pop    es
     700:	01 00                	add    WORD PTR [bx+si],ax
     702:	00 00                	add    BYTE PTR [bx+si],al
     704:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     708:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     70c:	07                   	pop    es
     70d:	43                   	inc    bx
     70e:	61                   	popa
     70f:	70 74                	jo     0x785
     711:	69 6f 6e 02 00       	imul   bp,WORD PTR [bx+0x6e],0x2
     716:	bd 07 38             	mov    bp,0x3807
     719:	00 ff                	add    bh,bh
     71b:	ff d5                	call   bp
     71d:	1e                   	push   ds
     71e:	22 07                	and    al,BYTE PTR [bx]
     720:	17                   	pop    ss
     721:	1f                   	pop    ds
     722:	34 07                	xor    al,0x7
     724:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     728:	ff                   	(bad)
     729:	ff 0c                	dec    WORD PTR [si]
     72b:	00 05                	add    BYTE PTR [di],al
     72d:	43                   	inc    bx
     72e:	6f                   	outs   dx,WORD PTR ds:[si]
     72f:	6c                   	ins    BYTE PTR es:[di],dx
     730:	6f                   	outs   dx,WORD PTR ds:[si]
     731:	72 64                	jb     0x797
     733:	00 57 07             	add    BYTE PTR [bx+0x7],dl
     736:	3e 00 ff             	ds add bh,bh
     739:	ff                   	(bad)
     73a:	3e 00 ff             	ds add bh,bh
     73d:	ff 01                	inc    WORD PTR [bx+di]
     73f:	00 00                	add    BYTE PTR [bx+si],al
     741:	00 00                	add    BYTE PTR [bx+si],al
     743:	80 f4 ff             	xor    ah,0xff
     746:	ff                   	(bad)
     747:	ff 0d                	dec    WORD PTR [di]
     749:	00 0a                	add    BYTE PTR [bp+si],cl
     74b:	44                   	inc    sp
     74c:	72 61                	jb     0x7af
     74e:	67 43                	addr32 inc bx
     750:	75 72                	jne    0x7c4
     752:	73 6f                	jae    0x7c3
     754:	72 25                	jb     0x77b
     756:	01 80 07 2e          	add    WORD PTR [bx+si+0x2e07],ax
     75a:	00 ff                	add    bh,bh
     75c:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     760:	ff 01                	inc    WORD PTR [bx+di]
     762:	00 00                	add    BYTE PTR [bx+si],al
     764:	00 00                	add    BYTE PTR [bx+si],al
     766:	80 00 00             	add    BYTE PTR [bx+si],0x0
     769:	00 00                	add    BYTE PTR [bx+si],al
     76b:	0e                   	push   cs
     76c:	00 08                	add    BYTE PTR [bx+si],cl
     76e:	44                   	inc    sp
     76f:	72 61                	jb     0x7d2
     771:	67 4d                	addr32 dec bp
     773:	6f                   	outs   dx,WORD PTR ds:[si]
     774:	64 65 07             	fs gs pop es
     777:	23 da                	and    bx,dx
     779:	07                   	pop    es
     77a:	2a 00                	sub    al,BYTE PTR [bx+si]
     77c:	ff                   	(bad)
     77d:	ff                   	(bad)
     77e:	b8 1c 98             	mov    ax,0x981c
     781:	07                   	pop    es
     782:	01 00                	add    WORD PTR [bx+si],ax
     784:	00 00                	add    BYTE PTR [bx+si],al
     786:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     78a:	00 00                	add    BYTE PTR [bx+si],al
     78c:	0f 00 07             	sldt   WORD PTR [bx]
     78f:	45                   	inc    bp
     790:	6e                   	outs   dx,BYTE PTR ds:[si]
     791:	61                   	popa
     792:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     795:	64 d7                	xlat   BYTE PTR fs:[bx]
     797:	07                   	pop    es
     798:	c5 07                	lds    ax,DWORD PTR [bx]
     79a:	8e 00                	mov    es,WORD PTR [bx+si]
     79c:	ff                   	(bad)
     79d:	ff 8e 00 ff          	dec    WORD PTR [bp-0x100]
     7a1:	ff 01                	inc    WORD PTR [bx+di]
     7a3:	00 00                	add    BYTE PTR [bx+si],al
     7a5:	00 00                	add    BYTE PTR [bx+si],al
     7a7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7aa:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     7ae:	0c 46                	or     al,0x46
     7b0:	6f                   	outs   dx,WORD PTR ds:[si]
     7b1:	63 75 73             	arpl   WORD PTR [di+0x73],si
     7b4:	43                   	inc    bx
     7b5:	6f                   	outs   dx,WORD PTR ds:[si]
     7b6:	6e                   	outs   dx,BYTE PTR ds:[si]
     7b7:	74 72                	je     0x82b
     7b9:	6f                   	outs   dx,WORD PTR ds:[si]
     7ba:	6c                   	ins    BYTE PTR es:[di],dx
     7bb:	22 03                	and    al,BYTE PTR [bp+di]
     7bd:	b9 0c 34             	mov    cx,0x340c
     7c0:	00 ff                	add    bh,bh
     7c2:	ff                   	jmp    (bad)
     7c3:	eb 1d                	jmp    0x7e2
     7c5:	c9                   	leave
     7c6:	07                   	pop    es
     7c7:	08 1e e2 07          	or     BYTE PTR ds:0x7e2,bl
     7cb:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     7cf:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     7d3:	04 46                	add    al,0x46
     7d5:	6f                   	outs   dx,WORD PTR ds:[si]
     7d6:	6e                   	outs   dx,BYTE PTR ds:[si]
     7d7:	74 07                	je     0x7e0
     7d9:	23 fe                	and    di,si
     7db:	07                   	pop    es
     7dc:	2c 00                	sub    al,0x0
     7de:	ff                   	(bad)
     7df:	ff 32                	push   WORD PTR [bp+si]
     7e1:	1f                   	pop    ds
     7e2:	06                   	push   es
     7e3:	08 01                	or     BYTE PTR [bx+di],al
     7e5:	00 00                	add    BYTE PTR [bx+si],al
     7e7:	00 00                	add    BYTE PTR [bx+si],al
     7e9:	80 01 00             	add    BYTE PTR [bx+di],0x0
     7ec:	00 00                	add    BYTE PTR [bx+si],al
     7ee:	12 00                	adc    al,BYTE PTR [bx+si]
     7f0:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     7f3:	72 65                	jb     0x85a
     7f5:	6e                   	outs   dx,BYTE PTR ds:[si]
     7f6:	74 43                	je     0x83b
     7f8:	6f                   	outs   dx,WORD PTR ds:[si]
     7f9:	6c                   	ins    BYTE PTR es:[di],dx
     7fa:	6f                   	outs   dx,WORD PTR ds:[si]
     7fb:	72 07                	jb     0x804
     7fd:	23 21                	and    sp,WORD PTR [bx+di]
     7ff:	08 2b                	or     BYTE PTR [bp+di],ch
     801:	00 ff                	add    bh,bh
     803:	ff                   	(bad)
     804:	3e 1e                	ds push ds
     806:	29 08                	sub    WORD PTR [bx+si],cx
     808:	01 00                	add    WORD PTR [bx+si],ax
     80a:	00 00                	add    BYTE PTR [bx+si],al
     80c:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     810:	00 00                	add    BYTE PTR [bx+si],al
     812:	13 00                	adc    ax,WORD PTR [bx+si]
     814:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     817:	72 65                	jb     0x87e
     819:	6e                   	outs   dx,BYTE PTR ds:[si]
     81a:	74 46                	je     0x862
     81c:	6f                   	outs   dx,WORD PTR ds:[si]
     81d:	6e                   	outs   dx,BYTE PTR ds:[si]
     81e:	74 07                	je     0x827
     820:	23 6a 08             	and    bp,WORD PTR [bp+si+0x8]
     823:	49                   	dec    cx
     824:	00 ff                	add    bh,bh
     826:	ff a1 1e 98          	jmp    WORD PTR [bx+di-0x67e2]
     82a:	08 01                	or     BYTE PTR [bx+di],al
     82c:	00 00                	add    BYTE PTR [bx+si],al
     82e:	00 00                	add    BYTE PTR [bx+si],al
     830:	80 01 00             	add    BYTE PTR [bx+di],0x0
     833:	00 00                	add    BYTE PTR [bx+si],al
     835:	14 00                	adc    al,0x0
     837:	0e                   	push   cs
     838:	50                   	push   ax
     839:	61                   	popa
     83a:	72 65                	jb     0x8a1
     83c:	6e                   	outs   dx,BYTE PTR ds:[si]
     83d:	74 53                	je     0x892
     83f:	68 6f 77             	push   0x776f
     842:	48                   	dec    ax
     843:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     848:	98                   	cbw
     849:	0e                   	push   cs
     84a:	40                   	inc    ax
     84b:	00 ff                	add    bh,bh
     84d:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     850:	ff                   	(bad)
     851:	ff 01                	inc    WORD PTR [bx+di]
     853:	00 00                	add    BYTE PTR [bx+si],al
     855:	00 00                	add    BYTE PTR [bx+si],al
     857:	80 00 00             	add    BYTE PTR [bx+si],0x0
     85a:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     85e:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     861:	70 75                	jo     0x8d8
     863:	70 4d                	jo     0x8b2
     865:	65 6e                	outs   dx,BYTE PTR gs:[si]
     867:	75 07                	jne    0x870
     869:	23 90 08 95          	and    dx,WORD PTR [bx+si-0x6af8]
     86d:	00 ff                	add    bh,bh
     86f:	ff                   	(bad)
     870:	7c 45                	jl     0x8b7
     872:	b5 08                	mov    ch,0x8
     874:	01 00                	add    WORD PTR [bx+si],ax
     876:	00 00                	add    BYTE PTR [bx+si],al
     878:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     87c:	00 00                	add    BYTE PTR [bx+si],al
     87e:	16                   	push   ss
     87f:	00 0d                	add    BYTE PTR [di],cl
     881:	53                   	push   bx
     882:	68 6f 77             	push   0x776f
     885:	41                   	inc    cx
     886:	63 63 65             	arpl   WORD PTR [bp+di+0x65],sp
     889:	6c                   	ins    BYTE PTR es:[di],dx
     88a:	43                   	inc    bx
     88b:	68 61 72             	push   0x7261
     88e:	07                   	pop    es
     88f:	23 b1 08 48          	and    si,WORD PTR [bx+di+0x4808]
     893:	00 ff                	add    bh,bh
     895:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     898:	9c                   	pushf
     899:	08 23                	or     BYTE PTR [bp+di],ah
     89b:	1e                   	push   ds
     89c:	dd 08                	fisttp QWORD PTR [bx+si]
     89e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     8a2:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     8a6:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     8a9:	6f                   	outs   dx,WORD PTR ds:[si]
     8aa:	77 48                	ja     0x8f4
     8ac:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     8b1:	d5 08                	aad    0x8
     8b3:	61                   	popa
     8b4:	45                   	inc    bp
     8b5:	b9 08 a1             	mov    cx,0xa108
     8b8:	45                   	inc    bp
     8b9:	fd                   	std
     8ba:	08 01                	or     BYTE PTR [bx+di],al
     8bc:	00 00                	add    BYTE PTR [bx+si],al
     8be:	00 00                	add    BYTE PTR [bx+si],al
     8c0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8c3:	00 00                	add    BYTE PTR [bx+si],al
     8c5:	18 00                	sbb    BYTE PTR [bx+si],al
     8c7:	0b 54 72             	or     dx,WORD PTR [si+0x72]
     8ca:	61                   	popa
     8cb:	6e                   	outs   dx,BYTE PTR ds:[si]
     8cc:	73 70                	jae    0x93e
     8ce:	61                   	popa
     8cf:	72 65                	jb     0x936
     8d1:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d2:	74 07                	je     0x8db
     8d4:	23 f5                	and    si,bp
     8d6:	08 29                	or     BYTE PTR [bx+di],ch
     8d8:	00 ff                	add    bh,bh
     8da:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     8dd:	59                   	pop    cx
     8de:	09 01                	or     WORD PTR [bx+di],ax
     8e0:	00 00                	add    BYTE PTR [bx+si],al
     8e2:	00 00                	add    BYTE PTR [bx+si],al
     8e4:	80 01 00             	add    BYTE PTR [bx+di],0x0
     8e7:	00 00                	add    BYTE PTR [bx+si],al
     8e9:	19 00                	sbb    WORD PTR [bx+si],ax
     8eb:	07                   	pop    es
     8ec:	56                   	push   si
     8ed:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     8f2:	65 07                	gs pop es
     8f4:	23 80 0a 94          	and    ax,WORD PTR [bx+si-0x6bf6]
     8f8:	00 ff                	add    bh,bh
     8fa:	ff e7                	jmp    di
     8fc:	45                   	inc    bp
     8fd:	43                   	inc    bx
     8fe:	0a 01                	or     al,BYTE PTR [bx+di]
     900:	00 00                	add    BYTE PTR [bx+si],al
     902:	00 00                	add    BYTE PTR [bx+si],al
     904:	80 00 00             	add    BYTE PTR [bx+si],0x0
     907:	00 00                	add    BYTE PTR [bx+si],al
     909:	1a 00                	sbb    al,BYTE PTR [bx+si]
     90b:	08 57 6f             	or     BYTE PTR [bx+0x6f],dl
     90e:	72 64                	jb     0x974
     910:	57                   	push   di
     911:	72 61                	jb     0x974
     913:	70 71                	jo     0x986
     915:	00 36 09 7a          	add    BYTE PTR ds:0x7a09,dh
     919:	00 ff                	add    bh,bh
     91b:	ff                   	(bad)
     91c:	7a 00                	jp     0x91e
     91e:	ff                   	(bad)
     91f:	ff 01                	inc    WORD PTR [bx+di]
     921:	00 00                	add    BYTE PTR [bx+si],al
     923:	00 00                	add    BYTE PTR [bx+si],al
     925:	80 00 00             	add    BYTE PTR [bx+si],0x0
     928:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     92c:	07                   	pop    es
     92d:	4f                   	dec    di
     92e:	6e                   	outs   dx,BYTE PTR ds:[si]
     92f:	43                   	inc    bx
     930:	6c                   	ins    BYTE PTR es:[di],dx
     931:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     936:	98                   	cbw
     937:	0a 82 00 ff          	or     al,BYTE PTR [bp+si-0x100]
     93b:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     93f:	ff 01                	inc    WORD PTR [bx+di]
     941:	00 00                	add    BYTE PTR [bx+si],al
     943:	00 00                	add    BYTE PTR [bx+si],al
     945:	80 00 00             	add    BYTE PTR [bx+si],0x0
     948:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     94c:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     94f:	44                   	inc    sp
     950:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     953:	6c                   	ins    BYTE PTR es:[di],dx
     954:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     959:	7c 09                	jl     0x964
     95b:	62 00                	bound  ax,DWORD PTR [bx+si]
     95d:	ff                   	(bad)
     95e:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     961:	ff                   	(bad)
     962:	ff 01                	inc    WORD PTR [bx+di]
     964:	00 00                	add    BYTE PTR [bx+si],al
     966:	00 00                	add    BYTE PTR [bx+si],al
     968:	80 00 00             	add    BYTE PTR [bx+si],0x0
     96b:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     96f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     972:	44                   	inc    sp
     973:	72 61                	jb     0x9d6
     975:	67 44                	addr32 inc sp
     977:	72 6f                	jb     0x9e8
     979:	70 80                	jo     0x8fb
     97b:	02 9f 09 6a          	add    bl,BYTE PTR [bx+0x6a09]
     97f:	00 ff                	add    bh,bh
     981:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     984:	ff                   	(bad)
     985:	ff 01                	inc    WORD PTR [bx+di]
     987:	00 00                	add    BYTE PTR [bx+si],al
     989:	00 00                	add    BYTE PTR [bx+si],al
     98b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     98e:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     992:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     995:	44                   	inc    sp
     996:	72 61                	jb     0x9f9
     998:	67 4f                	addr32 dec di
     99a:	76 65                	jbe    0xa01
     99c:	72 32                	jb     0x9d0
     99e:	03 c1                	add    ax,cx
     9a0:	09 72 00             	or     WORD PTR [bp+si+0x0],si
     9a3:	ff                   	(bad)
     9a4:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     9a7:	ff                   	(bad)
     9a8:	ff 01                	inc    WORD PTR [bx+di]
     9aa:	00 00                	add    BYTE PTR [bx+si],al
     9ac:	00 00                	add    BYTE PTR [bx+si],al
     9ae:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9b1:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     9b5:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     9b8:	45                   	inc    bp
     9b9:	6e                   	outs   dx,BYTE PTR ds:[si]
     9ba:	64 44                	fs inc sp
     9bc:	72 61                	jb     0xa1f
     9be:	67 71 01             	addr32 jno 0x9c2
     9c1:	e5 09                	in     ax,0x9
     9c3:	4a                   	dec    dx
     9c4:	00 ff                	add    bh,bh
     9c6:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     9c9:	ff                   	(bad)
     9ca:	ff 01                	inc    WORD PTR [bx+di]
     9cc:	00 00                	add    BYTE PTR [bx+si],al
     9ce:	00 00                	add    BYTE PTR [bx+si],al
     9d0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9d3:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     9d7:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     9da:	4d                   	dec    bp
     9db:	6f                   	outs   dx,WORD PTR ds:[si]
     9dc:	75 73                	jne    0xa51
     9de:	65 44                	gs inc sp
     9e0:	6f                   	outs   dx,WORD PTR ds:[si]
     9e1:	77 6e                	ja     0xa51
     9e3:	ce                   	into
     9e4:	01 09                	add    WORD PTR [bx+di],cx
     9e6:	0a 52 00             	or     dl,BYTE PTR [bp+si+0x0]
     9e9:	ff                   	(bad)
     9ea:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     9ed:	ff                   	(bad)
     9ee:	ff 01                	inc    WORD PTR [bx+di]
     9f0:	00 00                	add    BYTE PTR [bx+si],al
     9f2:	00 00                	add    BYTE PTR [bx+si],al
     9f4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9f7:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     9fb:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     9fe:	4d                   	dec    bp
     9ff:	6f                   	outs   dx,WORD PTR ds:[si]
     a00:	75 73                	jne    0xa75
     a02:	65 4d                	gs dec bp
     a04:	6f                   	outs   dx,WORD PTR ds:[si]
     a05:	76 65                	jbe    0xa6c
     a07:	71 01                	jno    0xa0a
     a09:	dc 0a                	fmul   QWORD PTR [bp+si]
     a0b:	5a                   	pop    dx
     a0c:	00 ff                	add    bh,bh
     a0e:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     a11:	ff                   	(bad)
     a12:	ff 01                	inc    WORD PTR [bx+di]
     a14:	00 00                	add    BYTE PTR [bx+si],al
     a16:	00 00                	add    BYTE PTR [bx+si],al
     a18:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a1b:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     a1f:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     a22:	4d                   	dec    bp
     a23:	6f                   	outs   dx,WORD PTR ds:[si]
     a24:	75 73                	jne    0xa99
     a26:	65 55                	gs push bp
     a28:	70 03                	jo     0xa2d
     a2a:	0d 54 45             	or     ax,0x4554
     a2d:	64 69 74 43 68 61    	imul   si,WORD PTR fs:[si+0x43],0x6168
     a33:	72 43                	jb     0xa78
     a35:	61                   	popa
     a36:	73 65                	jae    0xa9d
     a38:	00 00                	add    BYTE PTR [bx+si],al
     a3a:	00 00                	add    BYTE PTR [bx+si],al
     a3c:	00 02                	add    BYTE PTR [bp+si],al
     a3e:	00 00                	add    BYTE PTR [bx+si],al
     a40:	00 29                	add    BYTE PTR [bx+di],ch
     a42:	0a e0                	or     ah,al
     a44:	0a 08                	or     cl,BYTE PTR [bx+si]
     a46:	65 63 4e 6f          	arpl   WORD PTR gs:[bp+0x6f],cx
     a4a:	72 6d                	jb     0xab9
     a4c:	61                   	popa
     a4d:	6c                   	ins    BYTE PTR es:[di],dx
     a4e:	0b 65 63             	or     sp,WORD PTR [di+0x63]
     a51:	55                   	push   bp
     a52:	70 70                	jo     0xac4
     a54:	65 72 43             	gs jb  0xa9a
     a57:	61                   	popa
     a58:	73 65                	jae    0xabf
     a5a:	0b 65 63             	or     sp,WORD PTR [di+0x63]
     a5d:	4c                   	dec    sp
     a5e:	6f                   	outs   dx,WORD PTR ds:[si]
     a5f:	77 65                	ja     0xac6
     a61:	72 43                	jb     0xaa6
     a63:	61                   	popa
     a64:	73 65                	jae    0xacb
     a66:	2e 0b 00             	or     ax,WORD PTR cs:[bx+si]
     a69:	00 00                	add    BYTE PTR [bx+si],al
     a6b:	00 0e 0b 02          	add    BYTE PTR ds:0x20b,cl
     a6f:	0b ec                	or     bp,sp
     a71:	00 c1                	add    cl,al
     a73:	05 41 0b             	add    ax,0xb41
     a76:	fa                   	cli
     a77:	45                   	inc    bp
     a78:	ec                   	in     al,dx
     a79:	0a 9a 1f 52          	or     bl,BYTE PTR [bp+si+0x521f]
     a7d:	0b cb                	or     cx,bx
     a7f:	1f                   	pop    ds
     a80:	7c 0a                	jl     0xa8c
     a82:	fc                   	cld
     a83:	2e cc                	cs int3
     a85:	0a cd                	or     cl,ch
     a87:	11 90 0a 3a          	adc    WORD PTR [bx+si+0x3a0a],dx
     a8b:	27                   	daa
     a8c:	94                   	xchg   sp,ax
     a8d:	0a fa                	or     bh,dl
     a8f:	10 a2 0b d6          	adc    BYTE PTR [bp+si-0x29f5],ah
     a93:	14 9c                	adc    al,0x9c
     a95:	0a f4                	or     dh,ah
     a97:	4f                   	dec    di
     a98:	a8 0a                	test   al,0xa
     a9a:	32 16 c4 0a          	xor    dl,BYTE PTR ds:0xac4
     a9e:	ec                   	in     al,dx
     a9f:	30 fc                	xor    ah,bh
     aa1:	0a 51 1b             	or     dl,BYTE PTR [bx+di+0x1b]
     aa4:	74 0a                	je     0xab0
     aa6:	38 50 b0             	cmp    BYTE PTR [bx+si-0x50],dl
     aa9:	0a 63 31             	or     ah,BYTE PTR [bp+di+0x31]
     aac:	84 0a                	test   BYTE PTR [bp+si],cl
     aae:	21 50 88             	and    WORD PTR [bx+si-0x78],dx
     ab1:	0a 09                	or     cl,BYTE PTR [bx+di]
     ab3:	47                   	inc    di
     ab4:	1c 0b                	sbb    al,0xb
     ab6:	d9 62 bc             	fldenv [bp+si-0x44]
     ab9:	0a 06 63 c0          	or     al,BYTE PTR ds:0xc063
     abd:	0a 8f 60 f8          	or     cl,BYTE PTR [bx-0x7a0]
     ac1:	0a 3a                	or     bh,BYTE PTR [bp+si]
     ac3:	1c a4                	sbb    al,0xa4
     ac5:	0a 46 44             	or     al,BYTE PTR [bp+0x44]
     ac8:	ac                   	lods   al,BYTE PTR ds:[si]
     ac9:	0a 08                	or     cl,BYTE PTR [bx+si]
     acb:	61                   	popa
     acc:	d0 0a                	ror    BYTE PTR [bp+si],1
     ace:	5c                   	pop    sp
     acf:	61                   	popa
     ad0:	d4 0a                	aam    0xa
     ad2:	62 5c 00             	bound  bx,DWORD PTR [si+0x0]
     ad5:	0b 3a                	or     di,WORD PTR [bp+si]
     ad7:	61                   	popa
     ad8:	8c 0a                	mov    WORD PTR [bp+si],cs
     ada:	72 3f                	jb     0xb1b
     adc:	e4 0a                	in     al,0xa
     ade:	5f                   	pop    di
     adf:	4a                   	dec    dx
     ae0:	e8 0a 17             	call   0x21ed
     ae3:	3e 78 0a             	ds js  0xaf0
     ae6:	62 4b b4             	bound  cx,DWORD PTR [bp+di-0x4c]
     ae9:	0a ed                	or     ch,ch
     aeb:	3e f0 0a 77 3e       	lock or dh,BYTE PTR ds:[bx+0x3e]
     af0:	f4                   	hlt
     af1:	0a c2                	or     al,dl
     af3:	35 b8 0a             	xor    ax,0xab8
     af6:	1c 48                	sbb    al,0x48
     af8:	a0 0a ae             	mov    al,ds:0xae0a
     afb:	5f                   	pop    di
     afc:	c8 0a 35 62          	enter  0x350a,0x62
     b00:	d8 0a                	fmul   DWORD PTR [bp+si]
     b02:	0b 54 43             	or     dx,WORD PTR [si+0x43]
     b05:	75 73                	jne    0xb7a
     b07:	74 6f                	je     0xb78
     b09:	6d                   	ins    WORD PTR es:[di],dx
     b0a:	45                   	inc    bp
     b0b:	64 69 74 05 00 1a    	imul   si,WORD PTR fs:[si+0x5],0x1a00
     b11:	0f 0e                	femms
     b13:	0f 11 21             	movups XMMWORD PTR [bx+di],xmm4
     b16:	12 0f                	adc    cl,BYTE PTR [bx]
     b18:	ee                   	out    dx,al
     b19:	ff                   	(bad)
     b1a:	3e 4d                	ds dec bp
     b1c:	20 0b                	and    BYTE PTR [bp+di],cl
     b1e:	de 4c 24             	fimul  WORD PTR [si+0x24]
     b21:	0b 17                	or     dx,WORD PTR [bx]
     b23:	4d                   	dec    bp
     b24:	28 0b                	sub    BYTE PTR [bp+di],cl
     b26:	8b 4d 2c             	mov    cx,WORD PTR [di+0x2c]
     b29:	0b b6 4c 3d          	or     si,WORD PTR [bp+0x3d4c]
     b2d:	0b 07                	or     ax,WORD PTR [bx]
     b2f:	0b 54 43             	or     dx,WORD PTR [si+0x43]
     b32:	75 73                	jne    0xba7
     b34:	74 6f                	je     0xba5
     b36:	6d                   	ins    WORD PTR es:[di],dx
     b37:	45                   	inc    bp
     b38:	64 69 74 86 0a ea    	imul   si,WORD PTR fs:[si-0x7a],0xea0a
     b3e:	0b d7                	or     dx,di
     b40:	07                   	pop    es
     b41:	5a                   	pop    dx
     b42:	0b 0a                	or     cx,WORD PTR [bp+si]
     b44:	00 08                	add    BYTE PTR [bx+si],cl
     b46:	53                   	push   bx
     b47:	74 64                	je     0xbad
     b49:	43                   	inc    bx
     b4a:	74 72                	je     0xbbe
     b4c:	6c                   	ins    BYTE PTR es:[di],dx
     b4d:	73 01                	jae    0xb50
     b4f:	00 07                	add    BYTE PTR [bx],al
     b51:	23 8a 0b a4          	and    cx,WORD PTR [bp+si-0x5bf5]
     b55:	00 ff                	add    bh,bh
     b57:	ff 88 64 e6          	dec    WORD PTR [bx+si-0x199c]
     b5b:	0b 01                	or     ax,WORD PTR [bx+di]
     b5d:	00 00                	add    BYTE PTR [bx+si],al
     b5f:	00 00                	add    BYTE PTR [bx+si],al
     b61:	80 01 00             	add    BYTE PTR [bx+di],0x0
     b64:	00 00                	add    BYTE PTR [bx+si],al
     b66:	09 00                	or     WORD PTR [bx+si],ax
     b68:	07                   	pop    es
     b69:	54                   	push   sp
     b6a:	61                   	popa
     b6b:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     b6e:	6f                   	outs   dx,WORD PTR ds:[si]
     b6f:	70 12                	jo     0xb83
     b71:	0c 00                	or     al,0x0
     b73:	00 00                	add    BYTE PTR [bx+si],al
     b75:	00 00                	add    BYTE PTR [bx+si],al
     b77:	00 0c                	add    BYTE PTR [si],cl
     b79:	0c ec                	or     al,0xec
     b7b:	00 86 0a 1b          	add    BYTE PTR [bp+0x1b0a],al
     b7f:	0c fa                	or     al,0xfa
     b81:	45                   	inc    bp
     b82:	f6 0b 9a             	test   BYTE PTR [bp+di],0x9a
     b85:	1f                   	pop    ds
     b86:	30 0c                	xor    BYTE PTR [si],cl
     b88:	cb                   	retf
     b89:	1f                   	pop    ds
     b8a:	86 0b                	xchg   BYTE PTR [bp+di],cl
     b8c:	fc                   	cld
     b8d:	2e d6                	cs (bad)
     b8f:	0b cd                	or     cx,bp
     b91:	11 9a 0b 3a          	adc    WORD PTR [bp+si+0x3a0b],bx
     b95:	27                   	daa
     b96:	9e                   	sahf
     b97:	0b fa                	or     di,dx
     b99:	10 7a 0f             	adc    BYTE PTR [bp+si+0xf],bh
     b9c:	d6                   	(bad)
     b9d:	14 a6                	adc    al,0xa6
     b9f:	0b f4                	or     si,sp
     ba1:	4f                   	dec    di
     ba2:	b2 0b                	mov    dl,0xb
     ba4:	32 16 ce 0b          	xor    dl,BYTE PTR ds:0xbce
     ba8:	ec                   	in     al,dx
     ba9:	30 06 0c 51          	xor    BYTE PTR ds:0x510c,al
     bad:	1b c1                	sbb    ax,cx
     baf:	0c 38                	or     al,0x38
     bb1:	50                   	push   ax
     bb2:	ba 0b 63             	mov    dx,0x630b
     bb5:	31 8e 0b 21          	xor    WORD PTR [bp+0x210b],cx
     bb9:	50                   	push   ax
     bba:	92                   	xchg   dx,ax
     bbb:	0b 09                	or     cx,WORD PTR [bx+di]
     bbd:	47                   	inc    di
     bbe:	7e 0b                	jle    0xbcb
     bc0:	d9 62 c6             	fldenv [bp+si-0x3a]
     bc3:	0b 06 63 ca          	or     ax,WORD PTR ds:0xca63
     bc7:	0b 8f 60 02          	or     cx,WORD PTR [bx+0x260]
     bcb:	0c 3a                	or     al,0x3a
     bcd:	1c ae                	sbb    al,0xae
     bcf:	0b 46 44             	or     ax,WORD PTR [bp+0x44]
     bd2:	b6 0b                	mov    dh,0xb
     bd4:	08 61 da             	or     BYTE PTR [bx+di-0x26],ah
     bd7:	0b 5c 61             	or     bx,WORD PTR [si+0x61]
     bda:	de 0b                	fimul  WORD PTR [bp+di]
     bdc:	62 5c 0a             	bound  bx,DWORD PTR [si+0xa]
     bdf:	0c 3a                	or     al,0x3a
     be1:	61                   	popa
     be2:	96                   	xchg   si,ax
     be3:	0b 72 3f             	or     si,WORD PTR [bp+si+0x3f]
     be6:	ee                   	out    dx,al
     be7:	0b 5f 4a             	or     bx,WORD PTR [bx+0x4a]
     bea:	f2 0b 17             	repnz or dx,WORD PTR [bx]
     bed:	3e 82 0b 62          	or     BYTE PTR ds:[bp+di],0x62
     bf1:	4b                   	dec    bx
     bf2:	be 0b ed             	mov    si,0xed0b
     bf5:	3e fa                	ds cli
     bf7:	0b 77 3e             	or     si,WORD PTR [bx+0x3e]
     bfa:	fe 0b                	dec    BYTE PTR [bp+di]
     bfc:	c2 35 c2             	ret    0xc235
     bff:	0b 1c                	or     bx,WORD PTR [si]
     c01:	48                   	dec    ax
     c02:	aa                   	stos   BYTE PTR es:[di],al
     c03:	0b ae 5f d2          	or     bp,WORD PTR [bp-0x2da1]
     c07:	0b 35                	or     si,WORD PTR [di]
     c09:	62 e2 0b             	(bad)  {k5}
     c0c:	05 54 45             	add    ax,0x4554
     c0f:	64 69 74 07 05 54    	imul   si,WORD PTR fs:[si+0x7],0x5405
     c15:	45                   	inc    bp
     c16:	64 69 74 90 0b 1f    	imul   si,WORD PTR fs:[si-0x70],0x1f0b
     c1c:	0c 2e                	or     al,0x2e
     c1e:	0b 5b 0c             	or     bx,WORD PTR [bp+di+0xc]
     c21:	30 00                	xor    BYTE PTR [bx+si],al
     c23:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
     c26:	64 43                	fs inc bx
     c28:	74 72                	je     0xc9c
     c2a:	6c                   	ins    BYTE PTR es:[di],dx
     c2b:	73 27                	jae    0xc54
     c2d:	00 07                	add    BYTE PTR [bx],al
     c2f:	23 53 0c             	and    dx,WORD PTR [bp+di+0xc]
     c32:	de 00                	fiadd  WORD PTR [bx+si]
     c34:	ff                   	(bad)
     c35:	ff                   	call   (bad)
     c36:	de 00                	fiadd  WORD PTR [bx+si]
     c38:	ff                   	(bad)
     c39:	ff 01                	inc    WORD PTR [bx+di]
     c3b:	00 00                	add    BYTE PTR [bx+si],al
     c3d:	00 00                	add    BYTE PTR [bx+si],al
     c3f:	80 01 00             	add    BYTE PTR [bx+di],0x0
     c42:	00 00                	add    BYTE PTR [bx+si],al
     c44:	0a 00                	or     al,BYTE PTR [bx+si]
     c46:	0a 41 75             	or     al,BYTE PTR [bx+di+0x75]
     c49:	74 6f                	je     0xcba
     c4b:	53                   	push   bx
     c4c:	65 6c                	gs ins BYTE PTR es:[di],dx
     c4e:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
     c52:	23 d7                	and    dx,di
     c54:	0c dd                	or     al,0xdd
     c56:	00 ff                	add    bh,bh
     c58:	ff 9c 47 7c          	call   DWORD PTR [si+0x7c47]
     c5c:	0c 01                	or     al,0x1
     c5e:	00 00                	add    BYTE PTR [bx+si],al
     c60:	00 00                	add    BYTE PTR [bx+si],al
     c62:	80 01 00             	add    BYTE PTR [bx+di],0x0
     c65:	00 00                	add    BYTE PTR [bx+si],al
     c67:	0b 00                	or     ax,WORD PTR [bx+si]
     c69:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     c6c:	74 6f                	je     0xcdd
     c6e:	53                   	push   bx
     c6f:	69 7a 65 d4 02       	imul   di,WORD PTR [bp+si+0x65],0x2d4
     c74:	71 13                	jno    0xc89
     c76:	da 00                	fiadd  DWORD PTR [bx+si]
     c78:	ff                   	(bad)
     c79:	ff                   	(bad)
     c7a:	bf 47 98             	mov    di,0x9847
     c7d:	0c 01                	or     al,0x1
     c7f:	00 00                	add    BYTE PTR [bx+si],al
     c81:	00 00                	add    BYTE PTR [bx+si],al
     c83:	80 01 00             	add    BYTE PTR [bx+di],0x0
     c86:	00 00                	add    BYTE PTR [bx+si],al
     c88:	0c 00                	or     al,0x0
     c8a:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
     c8d:	72 64                	jb     0xcf3
     c8f:	65 72 53             	gs jb  0xce5
     c92:	74 79                	je     0xd0d
     c94:	6c                   	ins    BYTE PTR es:[di],dx
     c95:	65 29 0a             	sub    WORD PTR gs:[bp+si],cx
     c98:	a0 0c e1             	mov    al,ds:0xe10c
     c9b:	00 ff                	add    bh,bh
     c9d:	ff                   	jmp    (bad)
     c9e:	ec                   	in     al,dx
     c9f:	47                   	inc    di
     ca0:	7e 0d                	jle    0xcaf
     ca2:	01 00                	add    WORD PTR [bx+si],ax
     ca4:	00 00                	add    BYTE PTR [bx+si],al
     ca6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     caa:	00 00                	add    BYTE PTR [bx+si],al
     cac:	0d 00 08             	or     ax,0x800
     caf:	43                   	inc    bx
     cb0:	68 61 72             	push   0x7261
     cb3:	43                   	inc    bx
     cb4:	61                   	popa
     cb5:	73 65                	jae    0xd1c
     cb7:	02 00                	add    al,BYTE PTR [bx+si]
     cb9:	59                   	pop    cx
     cba:	0d 38 00             	or     ax,0x38
     cbd:	ff                   	(bad)
     cbe:	ff d5                	call   bp
     cc0:	1e                   	push   ds
     cc1:	c5 0c                	lds    cx,DWORD PTR [si]
     cc3:	17                   	pop    ss
     cc4:	1f                   	pop    ds
     cc5:	df 0c                	fisttp WORD PTR [si]
     cc7:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     ccb:	ff                   	(bad)
     ccc:	ff 0e 00 05          	dec    WORD PTR ds:0x500
     cd0:	43                   	inc    bx
     cd1:	6f                   	outs   dx,WORD PTR ds:[si]
     cd2:	6c                   	ins    BYTE PTR es:[di],dx
     cd3:	6f                   	outs   dx,WORD PTR ds:[si]
     cd4:	72 07                	jb     0xcdd
     cd6:	23 39                	and    di,WORD PTR [bx+di]
     cd8:	0d a5 00             	or     ax,0xa5
     cdb:	ff                   	(bad)
     cdc:	ff 22                	jmp    WORD PTR [bp+si]
     cde:	63 e3                	arpl   bx,sp
     ce0:	0c 54                	or     al,0x54
     ce2:	63 f5                	arpl   bp,si
     ce4:	0c 00                	or     al,0x0
     ce6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ce9:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     ced:	05 43 74             	add    ax,0x7443
     cf0:	6c                   	ins    BYTE PTR es:[di],dx
     cf1:	33 44 64             	xor    ax,WORD PTR [si+0x64]
     cf4:	00 18                	add    BYTE PTR [bx+si],bl
     cf6:	0d 3e 00             	or     ax,0x3e
     cf9:	ff                   	(bad)
     cfa:	ff                   	(bad)
     cfb:	3e 00 ff             	ds add bh,bh
     cfe:	ff 01                	inc    WORD PTR [bx+di]
     d00:	00 00                	add    BYTE PTR [bx+si],al
     d02:	00 00                	add    BYTE PTR [bx+si],al
     d04:	80 f4 ff             	xor    ah,0xff
     d07:	ff                   	(bad)
     d08:	ff 10                	call   WORD PTR [bx+si]
     d0a:	00 0a                	add    BYTE PTR [bp+si],cl
     d0c:	44                   	inc    sp
     d0d:	72 61                	jb     0xd70
     d0f:	67 43                	addr32 inc bx
     d11:	75 72                	jne    0xd85
     d13:	73 6f                	jae    0xd84
     d15:	72 25                	jb     0xd3c
     d17:	01 41 0d             	add    WORD PTR [bx+di+0xd],ax
     d1a:	2e 00 ff             	cs add bh,bh
     d1d:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     d21:	ff 01                	inc    WORD PTR [bx+di]
     d23:	00 00                	add    BYTE PTR [bx+si],al
     d25:	00 00                	add    BYTE PTR [bx+si],al
     d27:	80 00 00             	add    BYTE PTR [bx+si],0x0
     d2a:	00 00                	add    BYTE PTR [bx+si],al
     d2c:	11 00                	adc    WORD PTR [bx+si],ax
     d2e:	08 44 72             	or     BYTE PTR [si+0x72],al
     d31:	61                   	popa
     d32:	67 4d                	addr32 dec bp
     d34:	6f                   	outs   dx,WORD PTR ds:[si]
     d35:	64 65 07             	fs gs pop es
     d38:	23 76 0d             	and    si,WORD PTR [bp+0xd]
     d3b:	2a 00                	sub    al,BYTE PTR [bx+si]
     d3d:	ff                   	(bad)
     d3e:	ff                   	(bad)
     d3f:	b8 1c 61             	mov    ax,0x611c
     d42:	0d 01 00             	or     ax,0x1
     d45:	00 00                	add    BYTE PTR [bx+si],al
     d47:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     d4b:	00 00                	add    BYTE PTR [bx+si],al
     d4d:	12 00                	adc    al,BYTE PTR [bx+si]
     d4f:	07                   	pop    es
     d50:	45                   	inc    bp
     d51:	6e                   	outs   dx,BYTE PTR ds:[si]
     d52:	61                   	popa
     d53:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d56:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     d59:	95                   	xchg   bp,ax
     d5a:	13 34                	adc    si,WORD PTR [si]
     d5c:	00 ff                	add    bh,bh
     d5e:	ff                   	jmp    (bad)
     d5f:	eb 1d                	jmp    0xd7e
     d61:	65 0d 08 1e          	gs or  ax,0x1e08
     d65:	e9 0d 00             	jmp    0xd75
     d68:	80 00 00             	add    BYTE PTR [bx+si],0x0
     d6b:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     d6f:	04 46                	add    al,0x46
     d71:	6f                   	outs   dx,WORD PTR ds:[si]
     d72:	6e                   	outs   dx,BYTE PTR ds:[si]
     d73:	74 07                	je     0xd7c
     d75:	23 9c 0d df          	and    bx,WORD PTR [si-0x20f3]
     d79:	00 ff                	add    bh,bh
     d7b:	ff 0f                	dec    WORD PTR [bx]
     d7d:	48                   	dec    ax
     d7e:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     d7f:	0d 01 00             	or     ax,0x1
     d82:	00 00                	add    BYTE PTR [bx+si],al
     d84:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     d88:	00 00                	add    BYTE PTR [bx+si],al
     d8a:	14 00                	adc    al,0x0
     d8c:	0d 48 69             	or     ax,0x6948
     d8f:	64 65 53             	fs gs push bx
     d92:	65 6c                	gs ins BYTE PTR es:[di],dx
     d94:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
     d98:	6f                   	outs   dx,WORD PTR ds:[si]
     d99:	6e                   	outs   dx,BYTE PTR ds:[si]
     d9a:	d4 22                	aam    0x22
     d9c:	be 0d d8             	mov    si,0xd80d
     d9f:	00 ff                	add    bh,bh
     da1:	ff 32                	push   WORD PTR [bp+si]
     da3:	48                   	dec    ax
     da4:	c6                   	(bad)
     da5:	0d 01 00             	or     ax,0x1
     da8:	00 00                	add    BYTE PTR [bx+si],al
     daa:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     dae:	00 00                	add    BYTE PTR [bx+si],al
     db0:	15 00 09             	adc    ax,0x900
     db3:	4d                   	dec    bp
     db4:	61                   	popa
     db5:	78 4c                	js     0xe03
     db7:	65 6e                	outs   dx,BYTE PTR gs:[si]
     db9:	67 74 68             	addr32 je 0xe24
     dbc:	07                   	pop    es
     dbd:	23 e1                	and    sp,cx
     dbf:	0d e0 00             	or     ax,0xe0
     dc2:	ff                   	(bad)
     dc3:	ff 73 48             	push   WORD PTR [bp+di+0x48]
     dc6:	7b 0e                	jnp    0xdd6
     dc8:	01 00                	add    WORD PTR [bx+si],ax
     dca:	00 00                	add    BYTE PTR [bx+si],al
     dcc:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     dd0:	00 00                	add    BYTE PTR [bx+si],al
     dd2:	16                   	push   ss
     dd3:	00 0a                	add    BYTE PTR [bp+si],cl
     dd5:	4f                   	dec    di
     dd6:	45                   	inc    bp
     dd7:	4d                   	dec    bp
     dd8:	43                   	inc    bx
     dd9:	6f                   	outs   dx,WORD PTR ds:[si]
     dda:	6e                   	outs   dx,BYTE PTR ds:[si]
     ddb:	76 65                	jbe    0xe42
     ddd:	72 74                	jb     0xe53
     ddf:	07                   	pop    es
     de0:	23 05                	and    ax,WORD PTR [di]
     de2:	0e                   	push   cs
     de3:	2c 00                	sub    al,0x0
     de5:	ff                   	(bad)
     de6:	ff 32                	push   WORD PTR [bp+si]
     de8:	1f                   	pop    ds
     de9:	0d 0e 01             	or     ax,0x10e
     dec:	00 00                	add    BYTE PTR [bx+si],al
     dee:	00 00                	add    BYTE PTR [bx+si],al
     df0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     df3:	00 00                	add    BYTE PTR [bx+si],al
     df5:	17                   	pop    ss
     df6:	00 0b                	add    BYTE PTR [bp+di],cl
     df8:	50                   	push   ax
     df9:	61                   	popa
     dfa:	72 65                	jb     0xe61
     dfc:	6e                   	outs   dx,BYTE PTR ds:[si]
     dfd:	74 43                	je     0xe42
     dff:	6f                   	outs   dx,WORD PTR ds:[si]
     e00:	6c                   	ins    BYTE PTR es:[di],dx
     e01:	6f                   	outs   dx,WORD PTR ds:[si]
     e02:	72 07                	jb     0xe0b
     e04:	23 29                	and    bp,WORD PTR [bx+di]
     e06:	0e                   	push   cs
     e07:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     e08:	00 ff                	add    bh,bh
     e0a:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     e0d:	31 0e 01 00          	xor    WORD PTR ds:0x1,cx
     e11:	00 00                	add    BYTE PTR [bx+si],al
     e13:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e17:	00 00                	add    BYTE PTR [bx+si],al
     e19:	18 00                	sbb    BYTE PTR [bx+si],al
     e1b:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     e1e:	72 65                	jb     0xe85
     e20:	6e                   	outs   dx,BYTE PTR ds:[si]
     e21:	74 43                	je     0xe66
     e23:	74 6c                	je     0xe91
     e25:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     e28:	23 4c 0e             	and    cx,WORD PTR [si+0xe]
     e2b:	2b 00                	sub    ax,WORD PTR [bx+si]
     e2d:	ff                   	(bad)
     e2e:	ff                   	(bad)
     e2f:	3e 1e                	ds push ds
     e31:	54                   	push   sp
     e32:	0e                   	push   cs
     e33:	01 00                	add    WORD PTR [bx+si],ax
     e35:	00 00                	add    BYTE PTR [bx+si],al
     e37:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e3b:	00 00                	add    BYTE PTR [bx+si],al
     e3d:	19 00                	sbb    WORD PTR [bx+si],ax
     e3f:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     e42:	72 65                	jb     0xea9
     e44:	6e                   	outs   dx,BYTE PTR ds:[si]
     e45:	74 46                	je     0xe8d
     e47:	6f                   	outs   dx,WORD PTR ds:[si]
     e48:	6e                   	outs   dx,BYTE PTR ds:[si]
     e49:	74 07                	je     0xe52
     e4b:	23 73 0e             	and    si,WORD PTR [bp+di+0xe]
     e4e:	49                   	dec    cx
     e4f:	00 ff                	add    bh,bh
     e51:	ff a1 1e e3          	jmp    WORD PTR [bx+di-0x1ce2]
     e55:	0e                   	push   cs
     e56:	01 00                	add    WORD PTR [bx+si],ax
     e58:	00 00                	add    BYTE PTR [bx+si],al
     e5a:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e5e:	00 00                	add    BYTE PTR [bx+si],al
     e60:	1a 00                	sbb    al,BYTE PTR [bx+si]
     e62:	0e                   	push   cs
     e63:	50                   	push   ax
     e64:	61                   	popa
     e65:	72 65                	jb     0xecc
     e67:	6e                   	outs   dx,BYTE PTR ds:[si]
     e68:	74 53                	je     0xebd
     e6a:	68 6f 77             	push   0x776f
     e6d:	48                   	dec    ax
     e6e:	69 6e 74 28 23       	imul   bp,WORD PTR [bp+0x74],0x2328
     e73:	ba 0e db             	mov    dx,0xdb0e
     e76:	00 ff                	add    bh,bh
     e78:	ff 08                	dec    WORD PTR [bx+si]
     e7a:	49                   	dec    cx
     e7b:	c2 0e 01             	ret    0x10e
     e7e:	00 00                	add    BYTE PTR [bx+si],al
     e80:	00 00                	add    BYTE PTR [bx+si],al
     e82:	80 00 00             	add    BYTE PTR [bx+si],0x0
     e85:	00 00                	add    BYTE PTR [bx+si],al
     e87:	1b 00                	sbb    ax,WORD PTR [bx+si]
     e89:	0c 50                	or     al,0x50
     e8b:	61                   	popa
     e8c:	73 73                	jae    0xf01
     e8e:	77 6f                	ja     0xeff
     e90:	72 64                	jb     0xef6
     e92:	43                   	inc    bx
     e93:	68 61 72             	push   0x7261
     e96:	0d 04 6d             	or     ax,0x6d04
     e99:	15 40 00             	adc    ax,0x40
     e9c:	ff                   	(bad)
     e9d:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     ea0:	ff                   	(bad)
     ea1:	ff 01                	inc    WORD PTR [bx+di]
     ea3:	00 00                	add    BYTE PTR [bx+si],al
     ea5:	00 00                	add    BYTE PTR [bx+si],al
     ea7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     eaa:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     eae:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     eb1:	70 75                	jo     0xf28
     eb3:	70 4d                	jo     0xf02
     eb5:	65 6e                	outs   dx,BYTE PTR gs:[si]
     eb7:	75 07                	jne    0xec0
     eb9:	23 db                	and    bx,bx
     ebb:	0e                   	push   cs
     ebc:	dc 00                	fadd   QWORD PTR [bx+si]
     ebe:	ff                   	(bad)
     ebf:	ff                   	(bad)
     ec0:	79 49                	jns    0xf0b
     ec2:	6b 11 01             	imul   dx,WORD PTR [bx+di],0x1
     ec5:	00 00                	add    BYTE PTR [bx+si],al
     ec7:	00 00                	add    BYTE PTR [bx+si],al
     ec9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ecc:	00 00                	add    BYTE PTR [bx+si],al
     ece:	1d 00 08             	sbb    ax,0x800
     ed1:	52                   	push   dx
     ed2:	65 61                	gs popa
     ed4:	64 4f                	fs dec di
     ed6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ed7:	6c                   	ins    BYTE PTR es:[di],dx
     ed8:	79 07                	jns    0xee1
     eda:	23 1d                	and    bx,WORD PTR [di]
     edc:	0f 48 00             	cmovs  ax,WORD PTR [bx+si]
     edf:	ff                   	(bad)
     ee0:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     ee3:	e7 0e                	out    0xe,ax
     ee5:	23 1e fc 0e          	and    bx,WORD PTR ds:0xefc
     ee9:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     eed:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     ef1:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     ef4:	6f                   	outs   dx,WORD PTR ds:[si]
     ef5:	77 48                	ja     0xf3f
     ef7:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     efc:	00 0f                	add    BYTE PTR [bx],cl
     efe:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     eff:	63 04                	arpl   WORD PTR [si],ax
     f01:	0f 60 64 25          	punpcklbw mm4,DWORD PTR [si+0x25]
     f05:	0f 01 00             	sgdtw  [bx+si]
     f08:	00 00                	add    BYTE PTR [bx+si],al
     f0a:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     f0e:	ff                   	(bad)
     f0f:	ff 1f                	call   DWORD PTR [bx]
     f11:	00 08                	add    BYTE PTR [bx+si],cl
     f13:	54                   	push   sp
     f14:	61                   	popa
     f15:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     f18:	64 65 72 07          	fs gs jb 0xf23
     f1c:	23 5a 0f             	and    bx,WORD PTR [bp+si+0xf]
     f1f:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     f20:	00 ff                	add    bh,bh
     f22:	ff 88 64 3d          	dec    WORD PTR [bx+si+0x3d64]
     f26:	0f 01 00             	sgdtw  [bx+si]
     f29:	00 00                	add    BYTE PTR [bx+si],al
     f2b:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     f2f:	00 00                	add    BYTE PTR [bx+si],al
     f31:	09 00                	or     WORD PTR [bx+si],ax
     f33:	07                   	pop    es
     f34:	54                   	push   sp
     f35:	61                   	popa
     f36:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     f39:	6f                   	outs   dx,WORD PTR ds:[si]
     f3a:	70 66                	jo     0xfa2
     f3c:	01 41 0f             	add    WORD PTR [bx+di+0xf],ax
     f3f:	53                   	push   bx
     f40:	1d 45 0f             	sbb    ax,0xf45
     f43:	8c 1d                	mov    WORD PTR [di],ds
     f45:	62 0f                	bound  cx,DWORD PTR [bx]
     f47:	01 00                	add    WORD PTR [bx+si],ax
     f49:	00 00                	add    BYTE PTR [bx+si],al
     f4b:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     f4f:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     f53:	04 54                	add    al,0x54
     f55:	65 78 74             	gs js  0xfcc
     f58:	07                   	pop    es
     f59:	23 ad 11 29          	and    bp,WORD PTR [di+0x2911]
     f5d:	00 ff                	add    bh,bh
     f5f:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     f62:	de 0f                	fimul  WORD PTR [bx]
     f64:	01 00                	add    WORD PTR [bx+si],ax
     f66:	00 00                	add    BYTE PTR [bx+si],al
     f68:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     f6c:	00 00                	add    BYTE PTR [bx+si],al
     f6e:	21 00                	and    WORD PTR [bx+si],ax
     f70:	07                   	pop    es
     f71:	56                   	push   si
     f72:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     f77:	65 71 00             	gs jno 0xf7a
     f7a:	9b                   	fwait
     f7b:	0f e4 00             	pmulhuw mm0,QWORD PTR [bx+si]
     f7e:	ff                   	(bad)
     f7f:	ff e4                	jmp    sp
     f81:	00 ff                	add    bh,bh
     f83:	ff 01                	inc    WORD PTR [bx+di]
     f85:	00 00                	add    BYTE PTR [bx+si],al
     f87:	00 00                	add    BYTE PTR [bx+si],al
     f89:	80 00 00             	add    BYTE PTR [bx+si],0x0
     f8c:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     f90:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     f93:	43                   	inc    bx
     f94:	68 61 6e             	push   0x6e61
     f97:	67 65 71 00          	addr32 gs jno 0xf9b
     f9b:	bb 0f 7a             	mov    bx,0x7a0f
     f9e:	00 ff                	add    bh,bh
     fa0:	ff                   	(bad)
     fa1:	7a 00                	jp     0xfa3
     fa3:	ff                   	(bad)
     fa4:	ff 01                	inc    WORD PTR [bx+di]
     fa6:	00 00                	add    BYTE PTR [bx+si],al
     fa8:	00 00                	add    BYTE PTR [bx+si],al
     faa:	80 00 00             	add    BYTE PTR [bx+si],0x0
     fad:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     fb1:	07                   	pop    es
     fb2:	4f                   	dec    di
     fb3:	6e                   	outs   dx,BYTE PTR ds:[si]
     fb4:	43                   	inc    bx
     fb5:	6c                   	ins    BYTE PTR es:[di],dx
     fb6:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     fbb:	46                   	inc    si
     fbc:	10 82 00 ff          	adc    BYTE PTR [bp+si-0x100],al
     fc0:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     fc4:	ff 01                	inc    WORD PTR [bx+di]
     fc6:	00 00                	add    BYTE PTR [bx+si],al
     fc8:	00 00                	add    BYTE PTR [bx+si],al
     fca:	80 00 00             	add    BYTE PTR [bx+si],0x0
     fcd:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     fd1:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     fd4:	44                   	inc    sp
     fd5:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     fd8:	6c                   	ins    BYTE PTR es:[di],dx
     fd9:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     fde:	01 10                	add    WORD PTR [bx+si],dx
     fe0:	62 00                	bound  ax,DWORD PTR [bx+si]
     fe2:	ff                   	(bad)
     fe3:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     fe6:	ff                   	(bad)
     fe7:	ff 01                	inc    WORD PTR [bx+di]
     fe9:	00 00                	add    BYTE PTR [bx+si],al
     feb:	00 00                	add    BYTE PTR [bx+si],al
     fed:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ff0:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     ff4:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     ff7:	44                   	inc    sp
     ff8:	72 61                	jb     0x105b
     ffa:	67 44                	addr32 inc sp
     ffc:	72 6f                	jb     0x106d
     ffe:	70 80                	jo     0xf80
    1000:	02 24                	add    ah,BYTE PTR [si]
    1002:	10 6a 00             	adc    BYTE PTR [bp+si+0x0],ch
    1005:	ff                   	(bad)
    1006:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    1009:	ff                   	(bad)
    100a:	ff 01                	inc    WORD PTR [bx+di]
    100c:	00 00                	add    BYTE PTR [bx+si],al
    100e:	00 00                	add    BYTE PTR [bx+si],al
    1010:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1013:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    1017:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    101a:	44                   	inc    sp
    101b:	72 61                	jb     0x107e
    101d:	67 4f                	addr32 dec di
    101f:	76 65                	jbe    0x1086
    1021:	72 32                	jb     0x1055
    1023:	03 85 10 72          	add    ax,WORD PTR [di+0x7210]
    1027:	00 ff                	add    bh,bh
    1029:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    102c:	ff                   	(bad)
    102d:	ff 01                	inc    WORD PTR [bx+di]
    102f:	00 00                	add    BYTE PTR [bx+si],al
    1031:	00 00                	add    BYTE PTR [bx+si],al
    1033:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1036:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    103a:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    103d:	45                   	inc    bp
    103e:	6e                   	outs   dx,BYTE PTR ds:[si]
    103f:	64 44                	fs inc sp
    1041:	72 61                	jb     0x10a4
    1043:	67 71 00             	addr32 jno 0x1046
    1046:	66 10 c8             	data32 adc al,cl
    1049:	00 ff                	add    bh,bh
    104b:	ff c8                	dec    ax
    104d:	00 ff                	add    bh,bh
    104f:	ff 01                	inc    WORD PTR [bx+di]
    1051:	00 00                	add    BYTE PTR [bx+si],al
    1053:	00 00                	add    BYTE PTR [bx+si],al
    1055:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1058:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    105c:	07                   	pop    es
    105d:	4f                   	dec    di
    105e:	6e                   	outs   dx,BYTE PTR ds:[si]
    105f:	45                   	inc    bp
    1060:	6e                   	outs   dx,BYTE PTR ds:[si]
    1061:	74 65                	je     0x10c8
    1063:	72 71                	jb     0x10d6
    1065:	00 c5                	add    ch,al
    1067:	11 d0                	adc    ax,dx
    1069:	00 ff                	add    bh,bh
    106b:	ff d0                	call   ax
    106d:	00 ff                	add    bh,bh
    106f:	ff 01                	inc    WORD PTR [bx+di]
    1071:	00 00                	add    BYTE PTR [bx+si],al
    1073:	00 00                	add    BYTE PTR [bx+si],al
    1075:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1078:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
    107c:	06                   	push   es
    107d:	4f                   	dec    di
    107e:	6e                   	outs   dx,BYTE PTR ds:[si]
    107f:	45                   	inc    bp
    1080:	78 69                	js     0x10eb
    1082:	74 1a                	je     0x109e
    1084:	02 a7 10 b0          	add    ah,BYTE PTR [bx-0x4ff0]
    1088:	00 ff                	add    bh,bh
    108a:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    108e:	ff 01                	inc    WORD PTR [bx+di]
    1090:	00 00                	add    BYTE PTR [bx+si],al
    1092:	00 00                	add    BYTE PTR [bx+si],al
    1094:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1097:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
    109b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    109e:	4b                   	dec    bx
    109f:	65 79 44             	gs jns 0x10e6
    10a2:	6f                   	outs   dx,WORD PTR ds:[si]
    10a3:	77 6e                	ja     0x1113
    10a5:	54                   	push   sp
    10a6:	02 ca                	add    cl,dl
    10a8:	10 b8 00 ff          	adc    BYTE PTR [bx+si-0x100],bh
    10ac:	ff                   	(bad)
    10ad:	b8 00 ff             	mov    ax,0xff00
    10b0:	ff 01                	inc    WORD PTR [bx+di]
    10b2:	00 00                	add    BYTE PTR [bx+si],al
    10b4:	00 00                	add    BYTE PTR [bx+si],al
    10b6:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10b9:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
    10bd:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    10c0:	4b                   	dec    bx
    10c1:	65 79 50             	gs jns 0x1114
    10c4:	72 65                	jb     0x112b
    10c6:	73 73                	jae    0x113b
    10c8:	1a 02                	sbb    al,BYTE PTR [bp+si]
    10ca:	ea 10 c0 00 ff       	jmp    0xff00:0xc010
    10cf:	ff c0                	inc    ax
    10d1:	00 ff                	add    bh,bh
    10d3:	ff 01                	inc    WORD PTR [bx+di]
    10d5:	00 00                	add    BYTE PTR [bx+si],al
    10d7:	00 00                	add    BYTE PTR [bx+si],al
    10d9:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10dc:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
    10e0:	07                   	pop    es
    10e1:	4f                   	dec    di
    10e2:	6e                   	outs   dx,BYTE PTR ds:[si]
    10e3:	4b                   	dec    bx
    10e4:	65 79 55             	gs jns 0x113c
    10e7:	70 71                	jo     0x115a
    10e9:	01 0e 11 4a          	add    WORD PTR ds:0x4a11,cx
    10ed:	00 ff                	add    bh,bh
    10ef:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    10f2:	ff                   	(bad)
    10f3:	ff 01                	inc    WORD PTR [bx+di]
    10f5:	00 00                	add    BYTE PTR [bx+si],al
    10f7:	00 00                	add    BYTE PTR [bx+si],al
    10f9:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10fc:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
    1100:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    1103:	4d                   	dec    bp
    1104:	6f                   	outs   dx,WORD PTR ds:[si]
    1105:	75 73                	jne    0x117a
    1107:	65 44                	gs inc sp
    1109:	6f                   	outs   dx,WORD PTR ds:[si]
    110a:	77 6e                	ja     0x117a
    110c:	ce                   	into
    110d:	01 32                	add    WORD PTR [bp+si],si
    110f:	11 52 00             	adc    WORD PTR [bp+si+0x0],dx
    1112:	ff                   	(bad)
    1113:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    1116:	ff                   	(bad)
    1117:	ff 01                	inc    WORD PTR [bx+di]
    1119:	00 00                	add    BYTE PTR [bx+si],al
    111b:	00 00                	add    BYTE PTR [bx+si],al
    111d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1120:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
    1124:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    1127:	4d                   	dec    bp
    1128:	6f                   	outs   dx,WORD PTR ds:[si]
    1129:	75 73                	jne    0x119e
    112b:	65 4d                	gs dec bp
    112d:	6f                   	outs   dx,WORD PTR ds:[si]
    112e:	76 65                	jbe    0x1195
    1130:	71 01                	jno    0x1133
    1132:	09 12                	or     WORD PTR [bp+si],dx
    1134:	5a                   	pop    dx
    1135:	00 ff                	add    bh,bh
    1137:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    113a:	ff                   	(bad)
    113b:	ff 01                	inc    WORD PTR [bx+di]
    113d:	00 00                	add    BYTE PTR [bx+si],al
    113f:	00 00                	add    BYTE PTR [bx+si],al
    1141:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1144:	00 80 2f 00          	add    BYTE PTR [bx+si+0x2f],al
    1148:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    114b:	4d                   	dec    bp
    114c:	6f                   	outs   dx,WORD PTR ds:[si]
    114d:	75 73                	jne    0x11c2
    114f:	65 55                	gs push bp
    1151:	70 03                	jo     0x1156
    1153:	0c 54                	or     al,0x54
    1155:	53                   	push   bx
    1156:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    1159:	6c                   	ins    BYTE PTR es:[di],dx
    115a:	6c                   	ins    BYTE PTR es:[di],dx
    115b:	53                   	push   bx
    115c:	74 79                	je     0x11d7
    115e:	6c                   	ins    BYTE PTR es:[di],dx
    115f:	65 00 00             	add    BYTE PTR gs:[bx+si],al
    1162:	00 00                	add    BYTE PTR [bx+si],al
    1164:	00 03                	add    BYTE PTR [bp+di],al
    1166:	00 00                	add    BYTE PTR [bx+si],al
    1168:	00 52 11             	add    BYTE PTR [bp+si+0x11],dl
    116b:	0d 12 06             	or     ax,0x612
    116e:	73 73                	jae    0x11e3
    1170:	4e                   	dec    si
    1171:	6f                   	outs   dx,WORD PTR ds:[si]
    1172:	6e                   	outs   dx,BYTE PTR ds:[si]
    1173:	65 0c 73             	gs or  al,0x73
    1176:	73 48                	jae    0x11c0
    1178:	6f                   	outs   dx,WORD PTR ds:[si]
    1179:	72 69                	jb     0x11e4
    117b:	7a 6f                	jp     0x11ec
    117d:	6e                   	outs   dx,BYTE PTR ds:[si]
    117e:	74 61                	je     0x11e1
    1180:	6c                   	ins    BYTE PTR es:[di],dx
    1181:	0a 73 73             	or     dh,BYTE PTR [bp+di+0x73]
    1184:	56                   	push   si
    1185:	65 72 74             	gs jb  0x11fc
    1188:	69 63 61 6c 06       	imul   sp,WORD PTR [bp+di+0x61],0x66c
    118d:	73 73                	jae    0x1202
    118f:	42                   	inc    dx
    1190:	6f                   	outs   dx,WORD PTR ds:[si]
    1191:	74 68                	je     0x11fb
    1193:	4f                   	dec    di
    1194:	12 00                	adc    al,BYTE PTR [bx+si]
    1196:	00 00                	add    BYTE PTR [bx+si],al
    1198:	00 3b                	add    BYTE PTR [bp+di],bh
    119a:	12 2f                	adc    ch,BYTE PTR [bx]
    119c:	12 f8                	adc    bh,al
    119e:	00 86 0a 45          	add    BYTE PTR [bp+0x450a],al
    11a2:	12 fa                	adc    bh,dl
    11a4:	45                   	inc    bp
    11a5:	19 12                	sbb    WORD PTR [bp+si],dx
    11a7:	9a 1f 8b 12 cb       	call   0xcb12:0x8b1f
    11ac:	1f                   	pop    ds
    11ad:	a9 11 bb             	test   ax,0xbb11
    11b0:	54                   	push   sp
    11b1:	15 12 cd             	adc    ax,0xcd12
    11b4:	11 bd 11 3a          	adc    WORD PTR [di+0x3a11],di
    11b8:	27                   	daa
    11b9:	c1 11 fa             	rcl    WORD PTR [bx+di],0xfa
    11bc:	10 a3 12 d6          	adc    BYTE PTR [bp+di-0x29ee],ah
    11c0:	14 c9                	adc    al,0xc9
    11c2:	11 f4                	adc    sp,si
    11c4:	4f                   	dec    di
    11c5:	d5 11                	aad    0x11
    11c7:	32 16 f1 11          	xor    dl,BYTE PTR ds:0x11f1
    11cb:	ec                   	in     al,dx
    11cc:	30 29                	xor    BYTE PTR [bx+di],ch
    11ce:	12 51 1b             	adc    dl,BYTE PTR [bx+di+0x1b]
    11d1:	e7 12                	out    0x12,ax
    11d3:	38 50 dd             	cmp    BYTE PTR [bx+si-0x23],dl
    11d6:	11 63 31             	adc    WORD PTR [bp+di+0x31],sp
    11d9:	f9                   	stc
    11da:	11 21                	adc    WORD PTR [bx+di],sp
    11dc:	50                   	push   ax
    11dd:	b5 11                	mov    ch,0x11
    11df:	1c 54                	sbb    al,0x54
    11e1:	b1 11                	mov    cl,0x11
    11e3:	d9 62 e9             	fldenv [bp+si-0x17]
    11e6:	11 06 63 ed          	adc    WORD PTR ds:0xed63,ax
    11ea:	11 8f 60 25          	adc    WORD PTR [bx+0x2560],cx
    11ee:	12 3a                	adc    bh,BYTE PTR [bp+si]
    11f0:	1c d1                	sbb    al,0xd1
    11f2:	11 46 44             	adc    WORD PTR [bp+0x44],ax
    11f5:	d9 11                	fst    DWORD PTR [bx+di]
    11f7:	08 61 fd             	or     BYTE PTR [bx+di-0x3],ah
    11fa:	11 5c 61             	adc    WORD PTR [si+0x61],bx
    11fd:	01 12                	add    WORD PTR [bp+si],dx
    11ff:	62 5c 2d             	bound  bx,DWORD PTR [si+0x2d]
    1202:	12 3a                	adc    bh,BYTE PTR [bp+si]
    1204:	61                   	popa
    1205:	b9 11 72             	mov    cx,0x7211
    1208:	3f                   	aas
    1209:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    120a:	11 e9                	adc    cx,bp
    120c:	54                   	push   sp
    120d:	11 12                	adc    WORD PTR [bp+si],dx
    120f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1210:	55                   	push   bp
    1211:	e1 11                	loope  0x1224
    1213:	62 4b a1             	bound  cx,DWORD PTR [bp+di-0x5f]
    1216:	11 ed                	adc    bp,bp
    1218:	3e 1d 12 77          	ds sbb ax,0x7712
    121c:	3e 21 12             	and    WORD PTR ds:[bp+si],dx
    121f:	c2 35 e5             	ret    0xe535
    1222:	11 1c                	adc    WORD PTR [si],bx
    1224:	48                   	dec    ax
    1225:	cd 11                	int    0x11
    1227:	ae                   	scas   al,BYTE PTR es:[di]
    1228:	5f                   	pop    di
    1229:	f5                   	cmc
    122a:	11 35                	adc    WORD PTR [di],si
    122c:	62 05                	bound  ax,DWORD PTR [di]
    122e:	12 0b                	adc    cl,BYTE PTR [bp+di]
    1230:	54                   	push   sp
    1231:	43                   	inc    bx
    1232:	75 73                	jne    0x12a7
    1234:	74 6f                	je     0x12a5
    1236:	6d                   	ins    WORD PTR es:[di],dx
    1237:	4d                   	dec    bp
    1238:	65 6d                	gs ins WORD PTR es:[di],dx
    123a:	6f                   	outs   dx,WORD PTR ds:[si]
    123b:	03 00                	add    ax,WORD PTR [bx+si]
    123d:	87 00                	xchg   WORD PTR [bx+si],ax
    123f:	82 00 ef             	add    BYTE PTR [bx+si],0xef
    1242:	ff 97 56 49          	call   WORD PTR [bx+0x4956]
    1246:	12 fa                	adc    bh,dl
    1248:	56                   	push   si
    1249:	4d                   	dec    bp
    124a:	12 29                	adc    ch,BYTE PTR [bx+di]
    124c:	57                   	push   di
    124d:	5e                   	pop    si
    124e:	12 07                	adc    al,BYTE PTR [bx]
    1250:	0b 54 43             	or     dx,WORD PTR [si+0x43]
    1253:	75 73                	jne    0x12c8
    1255:	74 6f                	je     0x12c6
    1257:	6d                   	ins    WORD PTR es:[di],dx
    1258:	4d                   	dec    bp
    1259:	65 6d                	gs ins WORD PTR es:[di],dx
    125b:	6f                   	outs   dx,WORD PTR ds:[si]
    125c:	b3 11                	mov    bl,0x11
    125e:	62 12                	bound  dx,DWORD PTR [bp+si]
    1260:	2e 0b 97 12 0a       	or     dx,WORD PTR cs:[bx+0xa12]
    1265:	00 08                	add    BYTE PTR [bx+si],cl
    1267:	53                   	push   bx
    1268:	74 64                	je     0x12ce
    126a:	43                   	inc    bx
    126b:	74 72                	je     0x12df
    126d:	6c                   	ins    BYTE PTR es:[di],dx
    126e:	73 00                	jae    0x1270
    1270:	00 13                	add    BYTE PTR [bp+di],dl
    1272:	13 00                	adc    ax,WORD PTR [bx+si]
    1274:	00 00                	add    BYTE PTR [bx+si],al
    1276:	00 00                	add    BYTE PTR [bx+si],al
    1278:	00 0d                	add    BYTE PTR [di],cl
    127a:	13 f8                	adc    di,ax
    127c:	00 b3 11 1c          	add    BYTE PTR [bp+di+0x1c11],dh
    1280:	13 fa                	adc    di,dx
    1282:	45                   	inc    bp
    1283:	f7 12                	not    WORD PTR [bp+si]
    1285:	9a 1f b3 13 cb       	call   0xcb13:0xb31f
    128a:	1f                   	pop    ds
    128b:	87 12                	xchg   WORD PTR [bp+si],dx
    128d:	bb 54 f3             	mov    bx,0xf354
    1290:	12 cd                	adc    cl,ch
    1292:	11 9b 12 5f          	adc    WORD PTR [bp+di+0x5f12],bx
    1296:	57                   	push   di
    1297:	eb 12                	jmp    0x12ab
    1299:	fa                   	cli
    129a:	10 4f 13             	adc    BYTE PTR [bx+0x13],cl
    129d:	d6                   	(bad)
    129e:	14 a7                	adc    al,0xa7
    12a0:	12 f4                	adc    dh,ah
    12a2:	4f                   	dec    di
    12a3:	b3 12                	mov    bl,0x12
    12a5:	32 16 cf 12          	xor    dl,BYTE PTR ds:0x12cf
    12a9:	ec                   	in     al,dx
    12aa:	30 07                	xor    BYTE PTR [bx],al
    12ac:	13 51 1b             	adc    dx,WORD PTR [bx+di+0x1b]
    12af:	31 13                	xor    WORD PTR [bp+di],dx
    12b1:	38 50 bb             	cmp    BYTE PTR [bx+si-0x45],dl
    12b4:	12 63 31             	adc    ah,BYTE PTR [bp+di+0x31]
    12b7:	d7                   	xlat   BYTE PTR ds:[bx]
    12b8:	12 21                	adc    ah,BYTE PTR [bx+di]
    12ba:	50                   	push   ax
    12bb:	93                   	xchg   bx,ax
    12bc:	12 1c                	adc    bl,BYTE PTR [si]
    12be:	54                   	push   sp
    12bf:	8f                   	(bad)
    12c0:	12 d9                	adc    bl,cl
    12c2:	62 c7 12             	(bad)  {k6}
    12c5:	06                   	push   es
    12c6:	63 cb                	arpl   bx,cx
    12c8:	12 8f 60 03          	adc    cl,BYTE PTR [bx+0x360]
    12cc:	13 3a                	adc    di,WORD PTR [bp+si]
    12ce:	1c af                	sbb    al,0xaf
    12d0:	12 46 44             	adc    al,BYTE PTR [bp+0x44]
    12d3:	b7 12                	mov    bh,0x12
    12d5:	08 61 db             	or     BYTE PTR [bx+di-0x25],ah
    12d8:	12 5c 61             	adc    bl,BYTE PTR [si+0x61]
    12db:	df 12                	fist   WORD PTR [bp+si]
    12dd:	62 5c 0b             	bound  bx,DWORD PTR [si+0xb]
    12e0:	13 3a                	adc    di,WORD PTR [bp+si]
    12e2:	61                   	popa
    12e3:	9f                   	lahf
    12e4:	12 72 3f             	adc    dh,BYTE PTR [bp+si+0x3f]
    12e7:	83 12 e9             	adc    WORD PTR [bp+si],0xffe9
    12ea:	54                   	push   sp
    12eb:	ef                   	out    dx,ax
    12ec:	12 6e 55             	adc    ch,BYTE PTR [bp+0x55]
    12ef:	bf 12 62             	mov    di,0x6212
    12f2:	4b                   	dec    bx
    12f3:	7f 12                	jg     0x1307
    12f5:	ed                   	in     ax,dx
    12f6:	3e fb                	ds sti
    12f8:	12 77 3e             	adc    dh,BYTE PTR [bx+0x3e]
    12fb:	ff 12                	call   WORD PTR [bp+si]
    12fd:	c2 35 c3             	ret    0xc335
    1300:	12 1c                	adc    bl,BYTE PTR [si]
    1302:	48                   	dec    ax
    1303:	ab                   	stos   WORD PTR es:[di],ax
    1304:	12 ae 5f d3          	adc    ch,BYTE PTR [bp-0x2ca1]
    1308:	12 35                	adc    dh,BYTE PTR [di]
    130a:	62 e3 12             	(bad)  {k5}
    130d:	05 54 4d             	add    ax,0x4d54
    1310:	65 6d                	gs ins WORD PTR es:[di],dx
    1312:	6f                   	outs   dx,WORD PTR ds:[si]
    1313:	07                   	pop    es
    1314:	05 54 4d             	add    ax,0x4d54
    1317:	65 6d                	gs ins WORD PTR es:[di],dx
    1319:	6f                   	outs   dx,WORD PTR ds:[si]
    131a:	91                   	xchg   cx,ax
    131b:	12 20                	adc    ah,BYTE PTR [bx+si]
    131d:	13 4f 12             	adc    cx,WORD PTR [bx+0x12]
    1320:	57                   	push   di
    1321:	13 32                	adc    si,WORD PTR [bp+si]
    1323:	00 08                	add    BYTE PTR [bx+si],cl
    1325:	53                   	push   bx
    1326:	74 64                	je     0x138c
    1328:	43                   	inc    bx
    1329:	74 72                	je     0x139d
    132b:	6c                   	ins    BYTE PTR es:[di],dx
    132c:	73 29                	jae    0x1357
    132e:	00 e2                	add    dl,ah
    1330:	00 39                	add    BYTE PTR [bx+di],bh
    1332:	13 2d                	adc    bp,WORD PTR [di]
    1334:	00 ff                	add    bh,bh
    1336:	ff 72 16             	push   WORD PTR [bp+si+0x16]
    1339:	9d                   	popf
    133a:	13 01                	adc    ax,WORD PTR [bx+di]
    133c:	00 00                	add    BYTE PTR [bx+si],al
    133e:	00 00                	add    BYTE PTR [bx+si],al
    1340:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1343:	00 00                	add    BYTE PTR [bx+si],al
    1345:	0a 00                	or     al,BYTE PTR [bx+si]
    1347:	05 41 6c             	add    ax,0x6c41
    134a:	69 67 6e 02 00       	imul   sp,WORD PTR [bx+0x6e],0x2
    134f:	78 14                	js     0x1365
    1351:	f0 00 ff             	lock add bh,bh
    1354:	ff 10                	call   WORD PTR [bx+si]
    1356:	56                   	push   si
    1357:	79 13                	jns    0x136c
    1359:	01 00                	add    WORD PTR [bx+si],ax
    135b:	00 00                	add    BYTE PTR [bx+si],al
    135d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1361:	00 00                	add    BYTE PTR [bx+si],al
    1363:	0b 00                	or     ax,WORD PTR [bx+si]
    1365:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
    1368:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
    136d:	6e                   	outs   dx,BYTE PTR ds:[si]
    136e:	74 d4                	je     0x1344
    1370:	02 10                	add    dl,BYTE PTR [bx+si]
    1372:	23 da                	and    bx,dx
    1374:	00 ff                	add    bh,bh
    1376:	ff                   	(bad)
    1377:	bf 47 5a             	mov    di,0x5a47
    137a:	14 01                	adc    al,0x1
    137c:	00 00                	add    BYTE PTR [bx+si],al
    137e:	00 00                	add    BYTE PTR [bx+si],al
    1380:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1383:	00 00                	add    BYTE PTR [bx+si],al
    1385:	0c 00                	or     al,0x0
    1387:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
    138a:	72 64                	jb     0x13f0
    138c:	65 72 53             	gs jb  0x13e2
    138f:	74 79                	je     0x140a
    1391:	6c                   	ins    BYTE PTR es:[di],dx
    1392:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
    1395:	35 14 38             	xor    ax,0x3814
    1398:	00 ff                	add    bh,bh
    139a:	ff d5                	call   bp
    139c:	1e                   	push   ds
    139d:	a1 13 17             	mov    ax,ds:0x1713
    13a0:	1f                   	pop    ds
    13a1:	bb 13 00             	mov    bx,0x13
    13a4:	80 fa ff             	cmp    dl,0xff
    13a7:	ff                   	(bad)
    13a8:	ff 0d                	dec    WORD PTR [di]
    13aa:	00 05                	add    BYTE PTR [di],al
    13ac:	43                   	inc    bx
    13ad:	6f                   	outs   dx,WORD PTR ds:[si]
    13ae:	6c                   	ins    BYTE PTR es:[di],dx
    13af:	6f                   	outs   dx,WORD PTR ds:[si]
    13b0:	72 07                	jb     0x13b9
    13b2:	23 15                	and    dx,WORD PTR [di]
    13b4:	14 a5                	adc    al,0xa5
    13b6:	00 ff                	add    bh,bh
    13b8:	ff 22                	jmp    WORD PTR [bp+si]
    13ba:	63 bf 13 54          	arpl   WORD PTR [bx+0x5413],di
    13be:	63 d1                	arpl   cx,dx
    13c0:	13 00                	adc    ax,WORD PTR [bx+si]
    13c2:	80 00 00             	add    BYTE PTR [bx+si],0x0
    13c5:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
    13c9:	05 43 74             	add    ax,0x7443
    13cc:	6c                   	ins    BYTE PTR es:[di],dx
    13cd:	33 44 64             	xor    ax,WORD PTR [si+0x64]
    13d0:	00 f4                	add    ah,dh
    13d2:	13 3e 00 ff          	adc    di,WORD PTR ds:0xff00
    13d6:	ff                   	(bad)
    13d7:	3e 00 ff             	ds add bh,bh
    13da:	ff 01                	inc    WORD PTR [bx+di]
    13dc:	00 00                	add    BYTE PTR [bx+si],al
    13de:	00 00                	add    BYTE PTR [bx+si],al
    13e0:	80 f4 ff             	xor    ah,0xff
    13e3:	ff                   	(bad)
    13e4:	ff 0f                	dec    WORD PTR [bx]
    13e6:	00 0a                	add    BYTE PTR [bp+si],cl
    13e8:	44                   	inc    sp
    13e9:	72 61                	jb     0x144c
    13eb:	67 43                	addr32 inc bx
    13ed:	75 72                	jne    0x1461
    13ef:	73 6f                	jae    0x1460
    13f1:	72 25                	jb     0x1418
    13f3:	01 1d                	add    WORD PTR [di],bx
    13f5:	14 2e                	adc    al,0x2e
    13f7:	00 ff                	add    bh,bh
    13f9:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    13fd:	ff 01                	inc    WORD PTR [bx+di]
    13ff:	00 00                	add    BYTE PTR [bx+si],al
    1401:	00 00                	add    BYTE PTR [bx+si],al
    1403:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1406:	00 00                	add    BYTE PTR [bx+si],al
    1408:	10 00                	adc    BYTE PTR [bx+si],al
    140a:	08 44 72             	or     BYTE PTR [si+0x72],al
    140d:	61                   	popa
    140e:	67 4d                	addr32 dec bp
    1410:	6f                   	outs   dx,WORD PTR ds:[si]
    1411:	64 65 07             	fs gs pop es
    1414:	23 52 14             	and    dx,WORD PTR [bp+si+0x14]
    1417:	2a 00                	sub    al,BYTE PTR [bx+si]
    1419:	ff                   	(bad)
    141a:	ff                   	(bad)
    141b:	b8 1c 3d             	mov    ax,0x3d1c
    141e:	14 01                	adc    al,0x1
    1420:	00 00                	add    BYTE PTR [bx+si],al
    1422:	00 00                	add    BYTE PTR [bx+si],al
    1424:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1427:	00 00                	add    BYTE PTR [bx+si],al
    1429:	11 00                	adc    WORD PTR [bx+si],ax
    142b:	07                   	pop    es
    142c:	45                   	inc    bp
    142d:	6e                   	outs   dx,BYTE PTR ds:[si]
    142e:	61                   	popa
    142f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1432:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
    1435:	e6 1b                	out    0x1b,al
    1437:	34 00                	xor    al,0x0
    1439:	ff                   	(bad)
    143a:	ff                   	jmp    (bad)
    143b:	eb 1d                	jmp    0x145a
    143d:	41                   	inc    cx
    143e:	14 08                	adc    al,0x8
    1440:	1e                   	push   ds
    1441:	e3 14                	jcxz   0x1457
    1443:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1447:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
    144b:	04 46                	add    al,0x46
    144d:	6f                   	outs   dx,WORD PTR ds:[si]
    144e:	6e                   	outs   dx,BYTE PTR ds:[si]
    144f:	74 07                	je     0x1458
    1451:	23 96 14 df          	and    dx,WORD PTR [bp-0x20ec]
    1455:	00 ff                	add    bh,bh
    1457:	ff 0f                	dec    WORD PTR [bx]
    1459:	48                   	dec    ax
    145a:	80 14 01             	adc    BYTE PTR [si],0x1
    145d:	00 00                	add    BYTE PTR [bx+si],al
    145f:	00 00                	add    BYTE PTR [bx+si],al
    1461:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1464:	00 00                	add    BYTE PTR [bx+si],al
    1466:	13 00                	adc    ax,WORD PTR [bx+si]
    1468:	0d 48 69             	or     ax,0x6948
    146b:	64 65 53             	fs gs push bx
    146e:	65 6c                	gs ins BYTE PTR es:[di],dx
    1470:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
    1474:	6f                   	outs   dx,WORD PTR ds:[si]
    1475:	6e                   	outs   dx,BYTE PTR ds:[si]
    1476:	8b 03                	mov    ax,WORD PTR [bp+di]
    1478:	bb 16 ec             	mov    bx,0xec16
    147b:	00 ff                	add    bh,bh
    147d:	ff 33                	push   WORD PTR [bp+di]
    147f:	56                   	push   si
    1480:	9e                   	sahf
    1481:	14 01                	adc    al,0x1
    1483:	00 00                	add    BYTE PTR [bx+si],al
    1485:	00 00                	add    BYTE PTR [bx+si],al
    1487:	80 00 00             	add    BYTE PTR [bx+si],0x0
    148a:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
    148e:	05 4c 69             	add    ax,0x694c
    1491:	6e                   	outs   dx,BYTE PTR ds:[si]
    1492:	65 73 d4             	gs jae 0x1469
    1495:	22 b8 14 d8          	and    bh,BYTE PTR [bx+si-0x27ec]
    1499:	00 ff                	add    bh,bh
    149b:	ff 32                	push   WORD PTR [bp+si]
    149d:	48                   	dec    ax
    149e:	c0 14 01             	rcl    BYTE PTR [si],0x1
    14a1:	00 00                	add    BYTE PTR [bx+si],al
    14a3:	00 00                	add    BYTE PTR [bx+si],al
    14a5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    14a8:	00 00                	add    BYTE PTR [bx+si],al
    14aa:	15 00 09             	adc    ax,0x900
    14ad:	4d                   	dec    bp
    14ae:	61                   	popa
    14af:	78 4c                	js     0x14fd
    14b1:	65 6e                	outs   dx,BYTE PTR gs:[si]
    14b3:	67 74 68             	addr32 je 0x151e
    14b6:	07                   	pop    es
    14b7:	23 db                	and    bx,bx
    14b9:	14 e0                	adc    al,0xe0
    14bb:	00 ff                	add    bh,bh
    14bd:	ff 73 48             	push   WORD PTR [bp+di+0x48]
    14c0:	97                   	xchg   di,ax
    14c1:	15 01 00             	adc    ax,0x1
    14c4:	00 00                	add    BYTE PTR [bx+si],al
    14c6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    14ca:	00 00                	add    BYTE PTR [bx+si],al
    14cc:	16                   	push   ss
    14cd:	00 0a                	add    BYTE PTR [bp+si],cl
    14cf:	4f                   	dec    di
    14d0:	45                   	inc    bp
    14d1:	4d                   	dec    bp
    14d2:	43                   	inc    bx
    14d3:	6f                   	outs   dx,WORD PTR ds:[si]
    14d4:	6e                   	outs   dx,BYTE PTR ds:[si]
    14d5:	76 65                	jbe    0x153c
    14d7:	72 74                	jb     0x154d
    14d9:	07                   	pop    es
    14da:	23 ff                	and    di,di
    14dc:	14 2c                	adc    al,0x2c
    14de:	00 ff                	add    bh,bh
    14e0:	ff 32                	push   WORD PTR [bp+si]
    14e2:	1f                   	pop    ds
    14e3:	07                   	pop    es
    14e4:	15 01 00             	adc    ax,0x1
    14e7:	00 00                	add    BYTE PTR [bx+si],al
    14e9:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    14ed:	00 00                	add    BYTE PTR [bx+si],al
    14ef:	17                   	pop    ss
    14f0:	00 0b                	add    BYTE PTR [bp+di],cl
    14f2:	50                   	push   ax
    14f3:	61                   	popa
    14f4:	72 65                	jb     0x155b
    14f6:	6e                   	outs   dx,BYTE PTR ds:[si]
    14f7:	74 43                	je     0x153c
    14f9:	6f                   	outs   dx,WORD PTR ds:[si]
    14fa:	6c                   	ins    BYTE PTR es:[di],dx
    14fb:	6f                   	outs   dx,WORD PTR ds:[si]
    14fc:	72 07                	jb     0x1505
    14fe:	23 23                	and    sp,WORD PTR [bp+di]
    1500:	15 a6 00             	adc    ax,0xa6
    1503:	ff                   	(bad)
    1504:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    1507:	2b 15                	sub    dx,WORD PTR [di]
    1509:	01 00                	add    WORD PTR [bx+si],ax
    150b:	00 00                	add    BYTE PTR [bx+si],al
    150d:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1511:	00 00                	add    BYTE PTR [bx+si],al
    1513:	18 00                	sbb    BYTE PTR [bx+si],al
    1515:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    1518:	72 65                	jb     0x157f
    151a:	6e                   	outs   dx,BYTE PTR ds:[si]
    151b:	74 43                	je     0x1560
    151d:	74 6c                	je     0x158b
    151f:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    1522:	23 46 15             	and    ax,WORD PTR [bp+0x15]
    1525:	2b 00                	sub    ax,WORD PTR [bx+si]
    1527:	ff                   	(bad)
    1528:	ff                   	(bad)
    1529:	3e 1e                	ds push ds
    152b:	4e                   	dec    si
    152c:	15 01 00             	adc    ax,0x1
    152f:	00 00                	add    BYTE PTR [bx+si],al
    1531:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1535:	00 00                	add    BYTE PTR [bx+si],al
    1537:	19 00                	sbb    WORD PTR [bx+si],ax
    1539:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
    153c:	72 65                	jb     0x15a3
    153e:	6e                   	outs   dx,BYTE PTR ds:[si]
    153f:	74 46                	je     0x1587
    1541:	6f                   	outs   dx,WORD PTR ds:[si]
    1542:	6e                   	outs   dx,BYTE PTR ds:[si]
    1543:	74 07                	je     0x154c
    1545:	23 8f 15 49          	and    cx,WORD PTR [bx+0x4915]
    1549:	00 ff                	add    bh,bh
    154b:	ff a1 1e db          	jmp    WORD PTR [bx+di-0x24e2]
    154f:	15 01 00             	adc    ax,0x1
    1552:	00 00                	add    BYTE PTR [bx+si],al
    1554:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1558:	00 00                	add    BYTE PTR [bx+si],al
    155a:	1a 00                	sbb    al,BYTE PTR [bx+si]
    155c:	0e                   	push   cs
    155d:	50                   	push   ax
    155e:	61                   	popa
    155f:	72 65                	jb     0x15c6
    1561:	6e                   	outs   dx,BYTE PTR ds:[si]
    1562:	74 53                	je     0x15b7
    1564:	68 6f 77             	push   0x776f
    1567:	48                   	dec    ax
    1568:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    156d:	be 1d 40             	mov    si,0x401d
    1570:	00 ff                	add    bh,bh
    1572:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    1575:	ff                   	(bad)
    1576:	ff 01                	inc    WORD PTR [bx+di]
    1578:	00 00                	add    BYTE PTR [bx+si],al
    157a:	00 00                	add    BYTE PTR [bx+si],al
    157c:	80 00 00             	add    BYTE PTR [bx+si],0x0
    157f:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
    1583:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    1586:	70 75                	jo     0x15fd
    1588:	70 4d                	jo     0x15d7
    158a:	65 6e                	outs   dx,BYTE PTR gs:[si]
    158c:	75 07                	jne    0x1595
    158e:	23 d3                	and    dx,bx
    1590:	15 dc 00             	adc    ax,0xdc
    1593:	ff                   	(bad)
    1594:	ff                   	(bad)
    1595:	79 49                	jns    0x15e0
    1597:	b0 15                	mov    al,0x15
    1599:	01 00                	add    WORD PTR [bx+si],ax
    159b:	00 00                	add    BYTE PTR [bx+si],al
    159d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    15a1:	00 00                	add    BYTE PTR [bx+si],al
    15a3:	1c 00                	sbb    al,0x0
    15a5:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    15a8:	61                   	popa
    15a9:	64 4f                	fs dec di
    15ab:	6e                   	outs   dx,BYTE PTR ds:[si]
    15ac:	6c                   	ins    BYTE PTR es:[di],dx
    15ad:	79 52                	jns    0x1601
    15af:	11 b8 15 f1          	adc    WORD PTR [bx+si-0xeeb],di
    15b3:	00 ff                	add    bh,bh
    15b5:	ff 51 56             	call   WORD PTR [bx+di+0x56]
    15b8:	a2 16 01             	mov    ds:0x116,al
    15bb:	00 00                	add    BYTE PTR [bx+si],al
    15bd:	00 00                	add    BYTE PTR [bx+si],al
    15bf:	80 00 00             	add    BYTE PTR [bx+si],0x0
    15c2:	00 00                	add    BYTE PTR [bx+si],al
    15c4:	1d 00 0a             	sbb    ax,0xa00
    15c7:	53                   	push   bx
    15c8:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    15cb:	6c                   	ins    BYTE PTR es:[di],dx
    15cc:	6c                   	ins    BYTE PTR es:[di],dx
    15cd:	42                   	inc    dx
    15ce:	61                   	popa
    15cf:	72 73                	jb     0x1644
    15d1:	07                   	pop    es
    15d2:	23 15                	and    dx,WORD PTR [di]
    15d4:	16                   	push   ss
    15d5:	48                   	dec    ax
    15d6:	00 ff                	add    bh,bh
    15d8:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    15db:	df 15                	fist   WORD PTR [di]
    15dd:	23 1e f4 15          	and    bx,WORD PTR ds:0x15f4
    15e1:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    15e5:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    15e9:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    15ec:	6f                   	outs   dx,WORD PTR ds:[si]
    15ed:	77 48                	ja     0x1637
    15ef:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
    15f4:	f8                   	clc
    15f5:	15 a6 63             	adc    ax,0x63a6
    15f8:	fc                   	cld
    15f9:	15 60 64             	adc    ax,0x6460
    15fc:	1d 16 01             	sbb    ax,0x116
    15ff:	00 00                	add    BYTE PTR [bx+si],al
    1601:	00 00                	add    BYTE PTR [bx+si],al
    1603:	80 ff ff             	cmp    bh,0xff
    1606:	ff                   	(bad)
    1607:	ff 1f                	call   DWORD PTR [bx]
    1609:	00 08                	add    BYTE PTR [bx+si],cl
    160b:	54                   	push   sp
    160c:	61                   	popa
    160d:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    1610:	64 65 72 07          	fs gs jb 0x161b
    1614:	23 35                	and    si,WORD PTR [di]
    1616:	16                   	push   ss
    1617:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1618:	00 ff                	add    bh,bh
    161a:	ff 88 64 3d          	dec    WORD PTR [bx+si+0x3d64]
    161e:	16                   	push   ss
    161f:	01 00                	add    WORD PTR [bx+si],ax
    1621:	00 00                	add    BYTE PTR [bx+si],al
    1623:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1627:	00 00                	add    BYTE PTR [bx+si],al
    1629:	09 00                	or     WORD PTR [bx+si],ax
    162b:	07                   	pop    es
    162c:	54                   	push   sp
    162d:	61                   	popa
    162e:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    1631:	6f                   	outs   dx,WORD PTR ds:[si]
    1632:	70 07                	jo     0x163b
    1634:	23 55 16             	and    dx,WORD PTR [di+0x16]
    1637:	29 00                	sub    WORD PTR [bx+si],ax
    1639:	ff                   	(bad)
    163a:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    163d:	1f                   	pop    ds
    163e:	17                   	pop    ss
    163f:	01 00                	add    WORD PTR [bx+si],ax
    1641:	00 00                	add    BYTE PTR [bx+si],al
    1643:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1647:	00 00                	add    BYTE PTR [bx+si],al
    1649:	20 00                	and    BYTE PTR [bx+si],al
    164b:	07                   	pop    es
    164c:	56                   	push   si
    164d:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    1652:	65 07                	gs pop es
    1654:	23 79 16             	and    di,WORD PTR [bx+di+0x16]
    1657:	f3 00 ff             	repz add bh,bh
    165a:	ff f3                	push   bx
    165c:	00 ff                	add    bh,bh
    165e:	ff 01                	inc    WORD PTR [bx+di]
    1660:	00 00                	add    BYTE PTR [bx+si],al
    1662:	00 00                	add    BYTE PTR [bx+si],al
    1664:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1667:	00 00                	add    BYTE PTR [bx+si],al
    1669:	21 00                	and    WORD PTR [bx+si],ax
    166b:	0b 57 61             	or     dx,WORD PTR [bx+0x61]
    166e:	6e                   	outs   dx,BYTE PTR ds:[si]
    166f:	74 52                	je     0x16c3
    1671:	65 74 75             	gs je  0x16e9
    1674:	72 6e                	jb     0x16e4
    1676:	73 07                	jae    0x167f
    1678:	23 9a 16 f4          	and    bx,WORD PTR [bp+si-0xbea]
    167c:	00 ff                	add    bh,bh
    167e:	ff f4                	push   sp
    1680:	00 ff                	add    bh,bh
    1682:	ff 01                	inc    WORD PTR [bx+di]
    1684:	00 00                	add    BYTE PTR [bx+si],al
    1686:	00 00                	add    BYTE PTR [bx+si],al
    1688:	80 00 00             	add    BYTE PTR [bx+si],0x0
    168b:	00 00                	add    BYTE PTR [bx+si],al
    168d:	22 00                	and    al,BYTE PTR [bx+si]
    168f:	08 57 61             	or     BYTE PTR [bx+0x61],dl
    1692:	6e                   	outs   dx,BYTE PTR ds:[si]
    1693:	74 54                	je     0x16e9
    1695:	61                   	popa
    1696:	62 73 07             	bound  si,DWORD PTR [bp+di+0x7]
    1699:	23 b4 19 f2          	and    si,WORD PTR [si-0xde7]
    169d:	00 ff                	add    bh,bh
    169f:	ff 74 56             	push   WORD PTR [si+0x56]
    16a2:	ae                   	scas   al,BYTE PTR es:[di]
    16a3:	18 01                	sbb    BYTE PTR [bx+di],al
    16a5:	00 00                	add    BYTE PTR [bx+si],al
    16a7:	00 00                	add    BYTE PTR [bx+si],al
    16a9:	80 01 00             	add    BYTE PTR [bx+di],0x0
    16ac:	00 00                	add    BYTE PTR [bx+si],al
    16ae:	23 00                	and    ax,WORD PTR [bx+si]
    16b0:	08 57 6f             	or     BYTE PTR [bx+0x6f],dl
    16b3:	72 64                	jb     0x1719
    16b5:	57                   	push   di
    16b6:	72 61                	jb     0x1719
    16b8:	70 71                	jo     0x172b
    16ba:	00 dc                	add    ah,bl
    16bc:	16                   	push   ss
    16bd:	e4 00                	in     al,0x0
    16bf:	ff                   	(bad)
    16c0:	ff e4                	jmp    sp
    16c2:	00 ff                	add    bh,bh
    16c4:	ff 01                	inc    WORD PTR [bx+di]
    16c6:	00 00                	add    BYTE PTR [bx+si],al
    16c8:	00 00                	add    BYTE PTR [bx+si],al
    16ca:	80 00 00             	add    BYTE PTR [bx+si],0x0
    16cd:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    16d1:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
    16d4:	43                   	inc    bx
    16d5:	68 61 6e             	push   0x6e61
    16d8:	67 65 71 00          	addr32 gs jno 0x16dc
    16dc:	fc                   	cld
    16dd:	16                   	push   ss
    16de:	7a 00                	jp     0x16e0
    16e0:	ff                   	(bad)
    16e1:	ff                   	(bad)
    16e2:	7a 00                	jp     0x16e4
    16e4:	ff                   	(bad)
    16e5:	ff 01                	inc    WORD PTR [bx+di]
    16e7:	00 00                	add    BYTE PTR [bx+si],al
    16e9:	00 00                	add    BYTE PTR [bx+si],al
    16eb:	80 00 00             	add    BYTE PTR [bx+si],0x0
    16ee:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    16f2:	07                   	pop    es
    16f3:	4f                   	dec    di
    16f4:	6e                   	outs   dx,BYTE PTR ds:[si]
    16f5:	43                   	inc    bx
    16f6:	6c                   	ins    BYTE PTR es:[di],dx
    16f7:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    16fc:	87 17                	xchg   WORD PTR [bx],dx
    16fe:	82 00 ff             	add    BYTE PTR [bx+si],0xff
    1701:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    1705:	ff 01                	inc    WORD PTR [bx+di]
    1707:	00 00                	add    BYTE PTR [bx+si],al
    1709:	00 00                	add    BYTE PTR [bx+si],al
    170b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    170e:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    1712:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1715:	44                   	inc    sp
    1716:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    1719:	6c                   	ins    BYTE PTR es:[di],dx
    171a:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    171f:	42                   	inc    dx
    1720:	17                   	pop    ss
    1721:	62 00                	bound  ax,DWORD PTR [bx+si]
    1723:	ff                   	(bad)
    1724:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    1727:	ff                   	(bad)
    1728:	ff 01                	inc    WORD PTR [bx+di]
    172a:	00 00                	add    BYTE PTR [bx+si],al
    172c:	00 00                	add    BYTE PTR [bx+si],al
    172e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1731:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    1735:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1738:	44                   	inc    sp
    1739:	72 61                	jb     0x179c
    173b:	67 44                	addr32 inc sp
    173d:	72 6f                	jb     0x17ae
    173f:	70 80                	jo     0x16c1
    1741:	02 65 17             	add    ah,BYTE PTR [di+0x17]
    1744:	6a 00                	push   0x0
    1746:	ff                   	(bad)
    1747:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    174a:	ff                   	(bad)
    174b:	ff 01                	inc    WORD PTR [bx+di]
    174d:	00 00                	add    BYTE PTR [bx+si],al
    174f:	00 00                	add    BYTE PTR [bx+si],al
    1751:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1754:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    1758:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    175b:	44                   	inc    sp
    175c:	72 61                	jb     0x17bf
    175e:	67 4f                	addr32 dec di
    1760:	76 65                	jbe    0x17c7
    1762:	72 32                	jb     0x1796
    1764:	03 c6                	add    ax,si
    1766:	17                   	pop    ss
    1767:	72 00                	jb     0x1769
    1769:	ff                   	(bad)
    176a:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    176d:	ff                   	(bad)
    176e:	ff 01                	inc    WORD PTR [bx+di]
    1770:	00 00                	add    BYTE PTR [bx+si],al
    1772:	00 00                	add    BYTE PTR [bx+si],al
    1774:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1777:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
    177b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    177e:	45                   	inc    bp
    177f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1780:	64 44                	fs inc sp
    1782:	72 61                	jb     0x17e5
    1784:	67 71 00             	addr32 jno 0x1787
    1787:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    1788:	17                   	pop    ss
    1789:	c8 00 ff ff          	enter  0xff00,0xff
    178d:	c8 00 ff ff          	enter  0xff00,0xff
    1791:	01 00                	add    WORD PTR [bx+si],ax
    1793:	00 00                	add    BYTE PTR [bx+si],al
    1795:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1799:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
    179d:	07                   	pop    es
    179e:	4f                   	dec    di
    179f:	6e                   	outs   dx,BYTE PTR ds:[si]
    17a0:	45                   	inc    bp
    17a1:	6e                   	outs   dx,BYTE PTR ds:[si]
    17a2:	74 65                	je     0x1809
    17a4:	72 71                	jb     0x1817
    17a6:	00 cc                	add    ah,cl
    17a8:	19 d0                	sbb    ax,dx
    17aa:	00 ff                	add    bh,bh
    17ac:	ff d0                	call   ax
    17ae:	00 ff                	add    bh,bh
    17b0:	ff 01                	inc    WORD PTR [bx+di]
    17b2:	00 00                	add    BYTE PTR [bx+si],al
    17b4:	00 00                	add    BYTE PTR [bx+si],al
    17b6:	80 00 00             	add    BYTE PTR [bx+si],0x0
    17b9:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
    17bd:	06                   	push   es
    17be:	4f                   	dec    di
    17bf:	6e                   	outs   dx,BYTE PTR ds:[si]
    17c0:	45                   	inc    bp
    17c1:	78 69                	js     0x182c
    17c3:	74 1a                	je     0x17df
    17c5:	02 e8                	add    ch,al
    17c7:	17                   	pop    ss
    17c8:	b0 00                	mov    al,0x0
    17ca:	ff                   	(bad)
    17cb:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    17cf:	ff 01                	inc    WORD PTR [bx+di]
    17d1:	00 00                	add    BYTE PTR [bx+si],al
    17d3:	00 00                	add    BYTE PTR [bx+si],al
    17d5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    17d8:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
    17dc:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    17df:	4b                   	dec    bx
    17e0:	65 79 44             	gs jns 0x1827
    17e3:	6f                   	outs   dx,WORD PTR ds:[si]
    17e4:	77 6e                	ja     0x1854
    17e6:	54                   	push   sp
    17e7:	02 0b                	add    cl,BYTE PTR [bp+di]
    17e9:	18 b8 00 ff          	sbb    BYTE PTR [bx+si-0x100],bh
    17ed:	ff                   	(bad)
    17ee:	b8 00 ff             	mov    ax,0xff00
    17f1:	ff 01                	inc    WORD PTR [bx+di]
    17f3:	00 00                	add    BYTE PTR [bx+si],al
    17f5:	00 00                	add    BYTE PTR [bx+si],al
    17f7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    17fa:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
    17fe:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1801:	4b                   	dec    bx
    1802:	65 79 50             	gs jns 0x1855
    1805:	72 65                	jb     0x186c
    1807:	73 73                	jae    0x187c
    1809:	1a 02                	sbb    al,BYTE PTR [bp+si]
    180b:	2b 18                	sub    bx,WORD PTR [bx+si]
    180d:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
    1810:	ff c0                	inc    ax
    1812:	00 ff                	add    bh,bh
    1814:	ff 01                	inc    WORD PTR [bx+di]
    1816:	00 00                	add    BYTE PTR [bx+si],al
    1818:	00 00                	add    BYTE PTR [bx+si],al
    181a:	80 00 00             	add    BYTE PTR [bx+si],0x0
    181d:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
    1821:	07                   	pop    es
    1822:	4f                   	dec    di
    1823:	6e                   	outs   dx,BYTE PTR ds:[si]
    1824:	4b                   	dec    bx
    1825:	65 79 55             	gs jns 0x187d
    1828:	70 71                	jo     0x189b
    182a:	01 4f 18             	add    WORD PTR [bx+0x18],cx
    182d:	4a                   	dec    dx
    182e:	00 ff                	add    bh,bh
    1830:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    1833:	ff                   	(bad)
    1834:	ff 01                	inc    WORD PTR [bx+di]
    1836:	00 00                	add    BYTE PTR [bx+si],al
    1838:	00 00                	add    BYTE PTR [bx+si],al
    183a:	80 00 00             	add    BYTE PTR [bx+si],0x0
    183d:	00 80 2f 00          	add    BYTE PTR [bx+si+0x2f],al
    1841:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    1844:	4d                   	dec    bp
    1845:	6f                   	outs   dx,WORD PTR ds:[si]
    1846:	75 73                	jne    0x18bb
    1848:	65 44                	gs inc sp
    184a:	6f                   	outs   dx,WORD PTR ds:[si]
    184b:	77 6e                	ja     0x18bb
    184d:	ce                   	into
    184e:	01 73 18             	add    WORD PTR [bp+di+0x18],si
    1851:	52                   	push   dx
    1852:	00 ff                	add    bh,bh
    1854:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    1857:	ff                   	(bad)
    1858:	ff 01                	inc    WORD PTR [bx+di]
    185a:	00 00                	add    BYTE PTR [bx+si],al
    185c:	00 00                	add    BYTE PTR [bx+si],al
    185e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1861:	00 80 30 00          	add    BYTE PTR [bx+si+0x30],al
    1865:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    1868:	4d                   	dec    bp
    1869:	6f                   	outs   dx,WORD PTR ds:[si]
    186a:	75 73                	jne    0x18df
    186c:	65 4d                	gs dec bp
    186e:	6f                   	outs   dx,WORD PTR ds:[si]
    186f:	76 65                	jbe    0x18d6
    1871:	71 01                	jno    0x1874
    1873:	10 1a                	adc    BYTE PTR [bp+si],bl
    1875:	5a                   	pop    dx
    1876:	00 ff                	add    bh,bh
    1878:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    187b:	ff                   	(bad)
    187c:	ff 01                	inc    WORD PTR [bx+di]
    187e:	00 00                	add    BYTE PTR [bx+si],al
    1880:	00 00                	add    BYTE PTR [bx+si],al
    1882:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1885:	00 80 31 00          	add    BYTE PTR [bx+si+0x31],al
    1889:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    188c:	4d                   	dec    bp
    188d:	6f                   	outs   dx,WORD PTR ds:[si]
    188e:	75 73                	jne    0x1903
    1890:	65 55                	gs push bp
    1892:	70 03                	jo     0x1897
    1894:	0e                   	push   cs
    1895:	54                   	push   sp
    1896:	43                   	inc    bx
    1897:	6f                   	outs   dx,WORD PTR ds:[si]
    1898:	6d                   	ins    WORD PTR es:[di],dx
    1899:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    189c:	6f                   	outs   dx,WORD PTR ds:[si]
    189d:	78 53                	js     0x18f2
    189f:	74 79                	je     0x191a
    18a1:	6c                   	ins    BYTE PTR es:[di],dx
    18a2:	65 00 00             	add    BYTE PTR gs:[bx+si],al
    18a5:	00 00                	add    BYTE PTR [bx+si],al
    18a7:	00 04                	add    BYTE PTR [si],al
    18a9:	00 00                	add    BYTE PTR [bx+si],al
    18ab:	00 93 18 38          	add    BYTE PTR [bp+di+0x3818],dl
    18af:	1a 0a                	sbb    cl,BYTE PTR [bp+si]
    18b1:	63 73 44             	arpl   WORD PTR [bp+di+0x44],si
    18b4:	72 6f                	jb     0x1925
    18b6:	70 44                	jo     0x18fc
    18b8:	6f                   	outs   dx,WORD PTR ds:[si]
    18b9:	77 6e                	ja     0x1929
    18bb:	08 63 73             	or     BYTE PTR [bp+di+0x73],ah
    18be:	53                   	push   bx
    18bf:	69 6d 70 6c 65       	imul   bp,WORD PTR [di+0x70],0x656c
    18c4:	0e                   	push   cs
    18c5:	63 73 44             	arpl   WORD PTR [bp+di+0x44],si
    18c8:	72 6f                	jb     0x1939
    18ca:	70 44                	jo     0x1910
    18cc:	6f                   	outs   dx,WORD PTR ds:[si]
    18cd:	77 6e                	ja     0x193d
    18cf:	4c                   	dec    sp
    18d0:	69 73 74 10 63       	imul   si,WORD PTR [bp+di+0x74],0x6310
    18d5:	73 4f                	jae    0x1926
    18d7:	77 6e                	ja     0x1947
    18d9:	65 72 44             	gs jb  0x1920
    18dc:	72 61                	jb     0x193f
    18de:	77 46                	ja     0x1926
    18e0:	69 78 65 64 13       	imul   di,WORD PTR [bx+si+0x65],0x1364
    18e5:	63 73 4f             	arpl   WORD PTR [bp+di+0x4f],si
    18e8:	77 6e                	ja     0x1958
    18ea:	65 72 44             	gs jb  0x1931
    18ed:	72 61                	jb     0x1950
    18ef:	77 56                	ja     0x1947
    18f1:	61                   	popa
    18f2:	72 69                	jb     0x195d
    18f4:	61                   	popa
    18f5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    18f8:	08 0e 54 44          	or     BYTE PTR ds:0x4454,cl
    18fc:	72 61                	jb     0x195f
    18fe:	77 49                	ja     0x1949
    1900:	74 65                	je     0x1967
    1902:	6d                   	ins    WORD PTR es:[di],dx
    1903:	45                   	inc    bp
    1904:	76 65                	jbe    0x196b
    1906:	6e                   	outs   dx,BYTE PTR ds:[si]
    1907:	74 00                	je     0x1909
    1909:	04 00                	add    al,0x0
    190b:	07                   	pop    es
    190c:	43                   	inc    bx
    190d:	6f                   	outs   dx,WORD PTR ds:[si]
    190e:	6e                   	outs   dx,BYTE PTR ds:[si]
    190f:	74 72                	je     0x1983
    1911:	6f                   	outs   dx,WORD PTR ds:[si]
    1912:	6c                   	ins    BYTE PTR es:[di],dx
    1913:	0b 54 57             	or     dx,WORD PTR [si+0x57]
    1916:	69 6e 43 6f 6e       	imul   bp,WORD PTR [bp+0x43],0x6e6f
    191b:	74 72                	je     0x198f
    191d:	6f                   	outs   dx,WORD PTR ds:[si]
    191e:	6c                   	ins    BYTE PTR es:[di],dx
    191f:	00 05                	add    BYTE PTR [di],al
    1921:	49                   	dec    cx
    1922:	6e                   	outs   dx,BYTE PTR ds:[si]
    1923:	64 65 78 07          	fs gs js 0x192e
    1927:	49                   	dec    cx
    1928:	6e                   	outs   dx,BYTE PTR ds:[si]
    1929:	74 65                	je     0x1990
    192b:	67 65 72 00          	addr32 gs jb 0x192f
    192f:	04 52                	add    al,0x52
    1931:	65 63 74 05          	arpl   WORD PTR gs:[si+0x5],si
    1935:	54                   	push   sp
    1936:	52                   	push   dx
    1937:	65 63 74 00          	arpl   WORD PTR gs:[si+0x0],si
    193b:	05 53 74             	add    ax,0x7453
    193e:	61                   	popa
    193f:	74 65                	je     0x19a6
    1941:	0f 54 4f 77          	andps  xmm1,XMMWORD PTR [bx+0x77]
    1945:	6e                   	outs   dx,BYTE PTR ds:[si]
    1946:	65 72 44             	gs jb  0x198d
    1949:	72 61                	jb     0x19ac
    194b:	77 53                	ja     0x19a0
    194d:	74 61                	je     0x19b0
    194f:	74 65                	je     0x19b6
    1951:	08 11                	or     BYTE PTR [bx+di],dl
    1953:	54                   	push   sp
    1954:	4d                   	dec    bp
    1955:	65 61                	gs popa
    1957:	73 75                	jae    0x19ce
    1959:	72 65                	jb     0x19c0
    195b:	49                   	dec    cx
    195c:	74 65                	je     0x19c3
    195e:	6d                   	ins    WORD PTR es:[di],dx
    195f:	45                   	inc    bp
    1960:	76 65                	jbe    0x19c7
    1962:	6e                   	outs   dx,BYTE PTR ds:[si]
    1963:	74 00                	je     0x1965
    1965:	03 00                	add    ax,WORD PTR [bx+si]
    1967:	07                   	pop    es
    1968:	43                   	inc    bx
    1969:	6f                   	outs   dx,WORD PTR ds:[si]
    196a:	6e                   	outs   dx,BYTE PTR ds:[si]
    196b:	74 72                	je     0x19df
    196d:	6f                   	outs   dx,WORD PTR ds:[si]
    196e:	6c                   	ins    BYTE PTR es:[di],dx
    196f:	0b 54 57             	or     dx,WORD PTR [si+0x57]
    1972:	69 6e 43 6f 6e       	imul   bp,WORD PTR [bp+0x43],0x6e6f
    1977:	74 72                	je     0x19eb
    1979:	6f                   	outs   dx,WORD PTR ds:[si]
    197a:	6c                   	ins    BYTE PTR es:[di],dx
    197b:	00 05                	add    BYTE PTR [di],al
    197d:	49                   	dec    cx
    197e:	6e                   	outs   dx,BYTE PTR ds:[si]
    197f:	64 65 78 07          	fs gs js 0x198a
    1983:	49                   	dec    cx
    1984:	6e                   	outs   dx,BYTE PTR ds:[si]
    1985:	74 65                	je     0x19ec
    1987:	67 65 72 01          	addr32 gs jb 0x198c
    198b:	06                   	push   es
    198c:	48                   	dec    ax
    198d:	65 69 67 68 74 07    	imul   sp,WORD PTR gs:[bx+0x68],0x774
    1993:	49                   	dec    cx
    1994:	6e                   	outs   dx,BYTE PTR ds:[si]
    1995:	74 65                	je     0x19fc
    1997:	67 65 72 ae          	addr32 gs jb 0x1949
    199b:	1a 00                	sbb    al,BYTE PTR [bx+si]
    199d:	00 00                	add    BYTE PTR [bx+si],al
    199f:	00 52 1a             	add    BYTE PTR [bp+si+0x1a],dl
    19a2:	42                   	inc    dx
    19a3:	1a 22                	sbb    ah,BYTE PTR [bp+si]
    19a5:	01 c1                	add    cx,ax
    19a7:	05 c5 1a             	add    ax,0x1ac5
    19aa:	fa                   	cli
    19ab:	45                   	inc    bp
    19ac:	20 1a                	and    BYTE PTR [bp+si],bl
    19ae:	9a 1f d6 1a cb       	call   0xcb1a:0xd61f
    19b3:	1f                   	pop    ds
    19b4:	b0 19                	mov    al,0x19
    19b6:	36 5b                	ss pop bx
    19b8:	74 1a                	je     0x19d4
    19ba:	cd 11                	int    0x11
    19bc:	c4 19                	les    bx,DWORD PTR [bx+di]
    19be:	3a 27                	cmp    ah,BYTE PTR [bx]
    19c0:	c8 19 fa 10          	enter  0xfa19,0x10
    19c4:	26 1b d6             	es sbb dx,si
    19c7:	14 d0                	adc    al,0xd0
    19c9:	19 f4                	sbb    sp,si
    19cb:	4f                   	dec    di
    19cc:	dc 19                	fcomp  QWORD PTR [bx+di]
    19ce:	32 16 f8 19          	xor    dl,BYTE PTR ds:0x19f8
    19d2:	ec                   	in     al,dx
    19d3:	30 30                	xor    BYTE PTR [bx+si],dh
    19d5:	1a 51 1b             	sbb    dl,BYTE PTR [bx+di+0x1b]
    19d8:	a8 19                	test   al,0x19
    19da:	38 50 e4             	cmp    BYTE PTR [bx+si-0x1c],dl
    19dd:	19 63 31             	sbb    WORD PTR [bp+di+0x31],sp
    19e0:	00 1a                	add    BYTE PTR [bp+si],bl
    19e2:	21 50 bc             	and    WORD PTR [bx+si-0x44],dx
    19e5:	19 20                	sbb    WORD PTR [bx+si],sp
    19e7:	5a                   	pop    dx
    19e8:	b8 19 d9             	mov    ax,0xd919
    19eb:	62                   	(bad)
    19ec:	f0 19 06 63 f4       	lock sbb WORD PTR ds:0xf463,ax
    19f1:	19 8f 60 2c          	sbb    WORD PTR [bx+0x2c60],cx
    19f5:	1a 3a                	sbb    bh,BYTE PTR [bp+si]
    19f7:	1c d8                	sbb    al,0xd8
    19f9:	19 15                	sbb    WORD PTR [di],dx
    19fb:	64 14 1a             	fs adc al,0x1a
    19fe:	08 61 04             	or     BYTE PTR [bx+di+0x4],ah
    1a01:	1a 5c 61             	sbb    bl,BYTE PTR [si+0x61]
    1a04:	08 1a                	or     BYTE PTR [bp+si],bl
    1a06:	62 5c 34             	bound  bx,DWORD PTR [si+0x34]
    1a09:	1a 3a                	sbb    bh,BYTE PTR [bp+si]
    1a0b:	61                   	popa
    1a0c:	c0 19 72             	rcr    BYTE PTR [bx+di],0x72
    1a0f:	3f                   	aas
    1a10:	18 1a                	sbb    BYTE PTR [bp+si],bl
    1a12:	6b 5d 1c 1a          	imul   bx,WORD PTR [di+0x1c],0x1a
    1a16:	17                   	pop    ss
    1a17:	3e ac                	lods   al,BYTE PTR ds:[si]
    1a19:	19 f4                	sbb    sp,si
    1a1b:	5d                   	pop    bp
    1a1c:	24 1a                	and    al,0x1a
    1a1e:	ed                   	in     ax,dx
    1a1f:	3e 28 1a             	sub    BYTE PTR ds:[bp+si],bl
    1a22:	43                   	inc    bx
    1a23:	5f                   	pop    di
    1a24:	3c 1a                	cmp    al,0x1a
    1a26:	c2 35 ec             	ret    0xec35
    1a29:	19 1c                	sbb    WORD PTR [si],bx
    1a2b:	48                   	dec    ax
    1a2c:	d4 19                	aam    0x19
    1a2e:	ae                   	scas   al,BYTE PTR es:[di]
    1a2f:	5f                   	pop    di
    1a30:	e0 19                	loopne 0x1a4b
    1a32:	35 62 0c             	xor    ax,0xc62
    1a35:	1a 72 62             	sbb    dh,BYTE PTR [bp+si+0x62]
    1a38:	fc                   	cld
    1a39:	19 9a 66 40          	sbb    WORD PTR [bp+si+0x4066],bx
    1a3d:	1a 56 67             	sbb    dl,BYTE PTR [bp+0x67]
    1a40:	e8 19 0f             	call   0x295c
    1a43:	54                   	push   sp
    1a44:	43                   	inc    bx
    1a45:	75 73                	jne    0x1aba
    1a47:	74 6f                	je     0x1ab8
    1a49:	6d                   	ins    WORD PTR es:[di],dx
    1a4a:	43                   	inc    bx
    1a4b:	6f                   	outs   dx,WORD PTR ds:[si]
    1a4c:	6d                   	ins    WORD PTR es:[di],dx
    1a4d:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    1a50:	6f                   	outs   dx,WORD PTR ds:[si]
    1a51:	78 0f                	js     0x1a62
    1a53:	00 01                	add    BYTE PTR [bx+di],al
    1a55:	00 14                	add    BYTE PTR [si],dl
    1a57:	00 19                	add    BYTE PTR [bx+di],bl
    1a59:	00 04                	add    BYTE PTR [si],al
    1a5b:	0f 09                	wbinvd
    1a5d:	0f 11 21             	movups XMMWORD PTR [bx+di],xmm4
    1a60:	19 20                	sbb    WORD PTR [bx+si],sp
    1a62:	2b 20                	sub    sp,WORD PTR [bx+si]
    1a64:	2c 20                	sub    al,0x20
    1a66:	01 02                	add    WORD PTR [bp+si],ax
    1a68:	2b 00                	sub    ax,WORD PTR [bx+si]
    1a6a:	2c 00                	sub    al,0x0
    1a6c:	2d 00 ee             	sub    ax,0xee00
    1a6f:	ff                   	jmp    (bad)
    1a70:	ed                   	in     ax,dx
    1a71:	ff 9e 5f 78          	call   DWORD PTR [bp+0x785f]
    1a75:	1a d2                	sbb    dl,dl
    1a77:	5f                   	pop    di
    1a78:	7c 1a                	jl     0x1a94
    1a7a:	6d                   	ins    WORD PTR es:[di],dx
    1a7b:	60                   	pusha
    1a7c:	80 1a dd             	sbb    BYTE PTR [bp+si],0xdd
    1a7f:	60                   	pusha
    1a80:	84 1a                	test   BYTE PTR [bp+si],bl
    1a82:	0c 61                	or     al,0x61
    1a84:	88 1a                	mov    BYTE PTR [bp+si],bl
    1a86:	67 65 8c 1a          	mov    WORD PTR gs:[edx],ds
    1a8a:	37                   	aaa
    1a8b:	61                   	popa
    1a8c:	90                   	nop
    1a8d:	1a 89 67 94          	sbb    cl,BYTE PTR [bx+di-0x6b99]
    1a91:	1a 8e 68 98          	sbb    cl,BYTE PTR [bp-0x6798]
    1a95:	1a d7                	sbb    dl,bh
    1a97:	68 9c 1a             	push   0x1a9c
    1a9a:	25 60 a0             	and    ax,0xa060
    1a9d:	1a 3d                	sbb    bh,BYTE PTR [di]
    1a9f:	60                   	pusha
    1aa0:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1aa1:	1a 55 60             	sbb    dl,BYTE PTR [di+0x60]
    1aa4:	a8 1a                	test   al,0x1a
    1aa6:	72 66                	jb     0x1b0e
    1aa8:	ac                   	lods   al,BYTE PTR ds:[si]
    1aa9:	1a 2e 67 c1          	sbb    ch,BYTE PTR ds:0xc167
    1aad:	1a 07                	sbb    al,BYTE PTR [bx]
    1aaf:	0f 54 43 75          	andps  xmm0,XMMWORD PTR [bp+di+0x75]
    1ab3:	73 74                	jae    0x1b29
    1ab5:	6f                   	outs   dx,WORD PTR ds:[si]
    1ab6:	6d                   	ins    WORD PTR es:[di],dx
    1ab7:	43                   	inc    bx
    1ab8:	6f                   	outs   dx,WORD PTR ds:[si]
    1ab9:	6d                   	ins    WORD PTR es:[di],dx
    1aba:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    1abd:	6f                   	outs   dx,WORD PTR ds:[si]
    1abe:	78 ba                	js     0x1a7a
    1ac0:	19 92 1b d7          	sbb    WORD PTR [bp+si-0x28e5],dx
    1ac4:	07                   	pop    es
    1ac5:	de 1a                	ficomp WORD PTR [bp+si]
    1ac7:	0a 00                	or     al,BYTE PTR [bx+si]
    1ac9:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
    1acc:	64 43                	fs inc bx
    1ace:	74 72                	je     0x1b42
    1ad0:	6c                   	ins    BYTE PTR es:[di],dx
    1ad1:	73 01                	jae    0x1ad4
    1ad3:	00 07                	add    BYTE PTR [bx],al
    1ad5:	23 0e 1b a4          	and    cx,WORD PTR ds:0xa41b
    1ad9:	00 ff                	add    bh,bh
    1adb:	ff 88 64 6a          	dec    WORD PTR [bx+si+0x6a64]
    1adf:	1b 01                	sbb    ax,WORD PTR [bx+di]
    1ae1:	00 00                	add    BYTE PTR [bx+si],al
    1ae3:	00 00                	add    BYTE PTR [bx+si],al
    1ae5:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1ae8:	00 00                	add    BYTE PTR [bx+si],al
    1aea:	09 00                	or     WORD PTR [bx+si],ax
    1aec:	07                   	pop    es
    1aed:	54                   	push   sp
    1aee:	61                   	popa
    1aef:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    1af2:	6f                   	outs   dx,WORD PTR ds:[si]
    1af3:	70 a6                	jo     0x1a9b
    1af5:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1af7:	00 00                	add    BYTE PTR [bx+si],al
    1af9:	00 00                	add    BYTE PTR [bx+si],al
    1afb:	00 9c 1b 22          	add    BYTE PTR [si+0x221b],bl
    1aff:	01 ba 19 b3          	add    WORD PTR [bp+si-0x4ce7],di
    1b03:	1b fa                	sbb    di,dx
    1b05:	45                   	inc    bp
    1b06:	7a 1b                	jp     0x1b23
    1b08:	9a 1f 04 1c cb       	call   0xcb1c:0x41f
    1b0d:	1f                   	pop    ds
    1b0e:	0a 1b                	or     bl,BYTE PTR [bp+di]
    1b10:	36 5b                	ss pop bx
    1b12:	02 1b                	add    bl,BYTE PTR [bp+di]
    1b14:	cd 11                	int    0x11
    1b16:	1e                   	push   ds
    1b17:	1b 3a                	sbb    di,WORD PTR [bp+si]
    1b19:	27                   	daa
    1b1a:	22 1b                	and    bl,BYTE PTR [bp+di]
    1b1c:	fa                   	cli
    1b1d:	10 ec                	adc    ah,ch
    1b1f:	1c d6                	sbb    al,0xd6
    1b21:	14 2a                	adc    al,0x2a
    1b23:	1b f4                	sbb    si,sp
    1b25:	4f                   	dec    di
    1b26:	36 1b 32             	sbb    si,WORD PTR ss:[bp+si]
    1b29:	16                   	push   ss
    1b2a:	52                   	push   dx
    1b2b:	1b ec                	sbb    bp,sp
    1b2d:	30 8a 1b 51          	xor    BYTE PTR [bp+si+0x511b],cl
    1b31:	1b ee                	sbb    bp,si
    1b33:	1b 38                	sbb    di,WORD PTR [bx+si]
    1b35:	50                   	push   ax
    1b36:	3e 1b 63 31          	sbb    sp,WORD PTR ds:[bp+di+0x31]
    1b3a:	5a                   	pop    dx
    1b3b:	1b 21                	sbb    sp,WORD PTR [bx+di]
    1b3d:	50                   	push   ax
    1b3e:	16                   	push   ss
    1b3f:	1b 20                	sbb    sp,WORD PTR [bx+si]
    1b41:	5a                   	pop    dx
    1b42:	12 1b                	adc    bl,BYTE PTR [bp+di]
    1b44:	d9 62 4a             	fldenv [bp+si+0x4a]
    1b47:	1b 06 63 4e          	sbb    ax,WORD PTR ds:0x4e63
    1b4b:	1b 8f 60 86          	sbb    cx,WORD PTR [bx-0x79a0]
    1b4f:	1b 3a                	sbb    di,WORD PTR [bp+si]
    1b51:	1c 32                	sbb    al,0x32
    1b53:	1b 15                	sbb    dx,WORD PTR [di]
    1b55:	64 6e                	outs   dx,BYTE PTR fs:[si]
    1b57:	1b 08                	sbb    cx,WORD PTR [bx+si]
    1b59:	61                   	popa
    1b5a:	5e                   	pop    si
    1b5b:	1b 5c 61             	sbb    bx,WORD PTR [si+0x61]
    1b5e:	62 1b                	bound  bx,DWORD PTR [bp+di]
    1b60:	62 5c 8e             	bound  bx,DWORD PTR [si-0x72]
    1b63:	1b 3a                	sbb    di,WORD PTR [bp+si]
    1b65:	61                   	popa
    1b66:	1a 1b                	sbb    bl,BYTE PTR [bp+di]
    1b68:	72 3f                	jb     0x1ba9
    1b6a:	72 1b                	jb     0x1b87
    1b6c:	6b 5d 76 1b          	imul   bx,WORD PTR [di+0x76],0x1b
    1b70:	17                   	pop    ss
    1b71:	3e 06                	ds push es
    1b73:	1b f4                	sbb    si,sp
    1b75:	5d                   	pop    bp
    1b76:	7e 1b                	jle    0x1b93
    1b78:	ed                   	in     ax,dx
    1b79:	3e 82 1b 43          	sbb    BYTE PTR ds:[bp+di],0x43
    1b7d:	5f                   	pop    di
    1b7e:	96                   	xchg   si,ax
    1b7f:	1b c2                	sbb    ax,dx
    1b81:	35 46 1b             	xor    ax,0x1b46
    1b84:	1c 48                	sbb    al,0x48
    1b86:	2e 1b ae 5f 3a       	sbb    bp,WORD PTR cs:[bp+0x3a5f]
    1b8b:	1b 35                	sbb    si,WORD PTR [di]
    1b8d:	62 66 1b             	bound  sp,DWORD PTR [bp+0x1b]
    1b90:	72 62                	jb     0x1bf4
    1b92:	56                   	push   si
    1b93:	1b 9a 66 9a          	sbb    bx,WORD PTR [bp+si-0x659a]
    1b97:	1b 56 67             	sbb    dx,WORD PTR [bp+0x67]
    1b9a:	42                   	inc    dx
    1b9b:	1b 09                	sbb    cx,WORD PTR [bx+di]
    1b9d:	54                   	push   sp
    1b9e:	43                   	inc    bx
    1b9f:	6f                   	outs   dx,WORD PTR ds:[si]
    1ba0:	6d                   	ins    WORD PTR es:[di],dx
    1ba1:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    1ba4:	6f                   	outs   dx,WORD PTR ds:[si]
    1ba5:	78 07                	js     0x1bae
    1ba7:	09 54 43             	or     WORD PTR [si+0x43],dx
    1baa:	6f                   	outs   dx,WORD PTR ds:[si]
    1bab:	6d                   	ins    WORD PTR es:[di],dx
    1bac:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    1baf:	6f                   	outs   dx,WORD PTR ds:[si]
    1bb0:	78 14                	js     0x1bc6
    1bb2:	1b b7 1b ae          	sbb    si,WORD PTR [bx-0x51e5]
    1bb6:	1a c8                	sbb    cl,al
    1bb8:	1b 2d                	sbb    bp,WORD PTR [di]
    1bba:	00 08                	add    BYTE PTR [bx+si],cl
    1bbc:	53                   	push   bx
    1bbd:	74 64                	je     0x1c23
    1bbf:	43                   	inc    bx
    1bc0:	74 72                	je     0x1c34
    1bc2:	6c                   	ins    BYTE PTR es:[di],dx
    1bc3:	73 24                	jae    0x1be9
    1bc5:	00 93 18 d0          	add    BYTE PTR [bp+di-0x2fe8],dl
    1bc9:	1b e1                	sbb    sp,cx
    1bcb:	00 ff                	add    bh,bh
    1bcd:	ff b3 5c cd          	push   WORD PTR [bp+di-0x32a4]
    1bd1:	1c 01                	sbb    al,0x1
    1bd3:	00 00                	add    BYTE PTR [bx+si],al
    1bd5:	00 00                	add    BYTE PTR [bx+si],al
    1bd7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1bda:	00 00                	add    BYTE PTR [bx+si],al
    1bdc:	0a 00                	or     al,BYTE PTR [bx+si]
    1bde:	05 53 74             	add    ax,0x7453
    1be1:	79 6c                	jns    0x1c4f
    1be3:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
    1be6:	ac                   	lods   al,BYTE PTR ds:[si]
    1be7:	1c 38                	sbb    al,0x38
    1be9:	00 ff                	add    bh,bh
    1beb:	ff d5                	call   bp
    1bed:	1e                   	push   ds
    1bee:	f2 1b 17             	repnz sbb dx,WORD PTR [bx]
    1bf1:	1f                   	pop    ds
    1bf2:	0c 1c                	or     al,0x1c
    1bf4:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
    1bf8:	ff                   	(bad)
    1bf9:	ff 0b                	dec    WORD PTR [bp+di]
    1bfb:	00 05                	add    BYTE PTR [di],al
    1bfd:	43                   	inc    bx
    1bfe:	6f                   	outs   dx,WORD PTR ds:[si]
    1bff:	6c                   	ins    BYTE PTR es:[di],dx
    1c00:	6f                   	outs   dx,WORD PTR ds:[si]
    1c01:	72 07                	jb     0x1c0a
    1c03:	23 66 1c             	and    sp,WORD PTR [bp+0x1c]
    1c06:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    1c07:	00 ff                	add    bh,bh
    1c09:	ff 22                	jmp    WORD PTR [bp+si]
    1c0b:	63 10                	arpl   WORD PTR [bx+si],dx
    1c0d:	1c 54                	sbb    al,0x54
    1c0f:	63 22                	arpl   WORD PTR [bp+si],sp
    1c11:	1c 00                	sbb    al,0x0
    1c13:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1c16:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
    1c1a:	05 43 74             	add    ax,0x7443
    1c1d:	6c                   	ins    BYTE PTR es:[di],dx
    1c1e:	33 44 25             	xor    ax,WORD PTR [si+0x25]
    1c21:	01 43 1c             	add    WORD PTR [bp+di+0x1c],ax
    1c24:	2e 00 ff             	cs add bh,bh
    1c27:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    1c2b:	ff 01                	inc    WORD PTR [bx+di]
    1c2d:	00 00                	add    BYTE PTR [bx+si],al
    1c2f:	00 00                	add    BYTE PTR [bx+si],al
    1c31:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1c34:	00 00                	add    BYTE PTR [bx+si],al
    1c36:	0d 00 08             	or     ax,0x800
    1c39:	44                   	inc    sp
    1c3a:	72 61                	jb     0x1c9d
    1c3c:	67 4d                	addr32 dec bp
    1c3e:	6f                   	outs   dx,WORD PTR ds:[si]
    1c3f:	64 65 64 00 94 1c 3e 	fs gs add BYTE PTR fs:[si+0x3e1c],dl
    1c46:	00 ff                	add    bh,bh
    1c48:	ff                   	(bad)
    1c49:	3e 00 ff             	ds add bh,bh
    1c4c:	ff 01                	inc    WORD PTR [bx+di]
    1c4e:	00 00                	add    BYTE PTR [bx+si],al
    1c50:	00 00                	add    BYTE PTR [bx+si],al
    1c52:	80 f4 ff             	xor    ah,0xff
    1c55:	ff                   	(bad)
    1c56:	ff 0e 00 0a          	dec    WORD PTR ds:0xa00
    1c5a:	44                   	inc    sp
    1c5b:	72 61                	jb     0x1cbe
    1c5d:	67 43                	addr32 inc bx
    1c5f:	75 72                	jne    0x1cd3
    1c61:	73 6f                	jae    0x1cd2
    1c63:	72 d4                	jb     0x1c39
    1c65:	22 8c 1c e6          	and    cl,BYTE PTR [si-0x19e4]
    1c69:	00 ff                	add    bh,bh
    1c6b:	ff e6                	jmp    si
    1c6d:	00 ff                	add    bh,bh
    1c6f:	ff 01                	inc    WORD PTR [bx+di]
    1c71:	00 00                	add    BYTE PTR [bx+si],al
    1c73:	00 00                	add    BYTE PTR [bx+si],al
    1c75:	80 08 00             	or     BYTE PTR [bx+si],0x0
    1c78:	00 00                	add    BYTE PTR [bx+si],al
    1c7a:	0f 00 0d             	str    WORD PTR [di]
    1c7d:	44                   	inc    sp
    1c7e:	72 6f                	jb     0x1cef
    1c80:	70 44                	jo     0x1cc6
    1c82:	6f                   	outs   dx,WORD PTR ds:[si]
    1c83:	77 6e                	ja     0x1cf3
    1c85:	43                   	inc    bx
    1c86:	6f                   	outs   dx,WORD PTR ds:[si]
    1c87:	75 6e                	jne    0x1cf7
    1c89:	74 07                	je     0x1c92
    1c8b:	23 c9                	and    cx,cx
    1c8d:	1c 2a                	sbb    al,0x2a
    1c8f:	00 ff                	add    bh,bh
    1c91:	ff                   	(bad)
    1c92:	b8 1c b4             	mov    ax,0xb41c
    1c95:	1c 01                	sbb    al,0x1
    1c97:	00 00                	add    BYTE PTR [bx+si],al
    1c99:	00 00                	add    BYTE PTR [bx+si],al
    1c9b:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1c9e:	00 00                	add    BYTE PTR [bx+si],al
    1ca0:	10 00                	adc    BYTE PTR [bx+si],al
    1ca2:	07                   	pop    es
    1ca3:	45                   	inc    bp
    1ca4:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ca5:	61                   	popa
    1ca6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1ca9:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
    1cac:	f3 22 34             	repz and dh,BYTE PTR [si]
    1caf:	00 ff                	add    bh,bh
    1cb1:	ff                   	jmp    (bad)
    1cb2:	eb 1d                	jmp    0x1cd1
    1cb4:	b8 1c 08             	mov    ax,0x81c
    1cb7:	1e                   	push   ds
    1cb8:	34 1d                	xor    al,0x1d
    1cba:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1cbe:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
    1cc2:	04 46                	add    al,0x46
    1cc4:	6f                   	outs   dx,WORD PTR ds:[si]
    1cc5:	6e                   	outs   dx,BYTE PTR ds:[si]
    1cc6:	74 d4                	je     0x1c9c
    1cc8:	22 0a                	and    cl,BYTE PTR [bp+si]
    1cca:	1d fa 5c             	sbb    ax,0x5cfa
    1ccd:	d1 1c                	rcr    WORD PTR [si],1
    1ccf:	35 5d f4             	xor    ax,0xf45d
    1cd2:	1c 01                	sbb    al,0x1
    1cd4:	00 00                	add    BYTE PTR [bx+si],al
    1cd6:	00 00                	add    BYTE PTR [bx+si],al
    1cd8:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1cdb:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
    1cdf:	0a 49 74             	or     cl,BYTE PTR [bx+di+0x74]
    1ce2:	65 6d                	gs ins WORD PTR es:[di],dx
    1ce4:	48                   	dec    ax
    1ce5:	65 69 67 68 74 8b    	imul   sp,WORD PTR gs:[bx+0x68],0x8b74
    1ceb:	03 9e 1e d8          	add    bx,WORD PTR [bp-0x27e2]
    1cef:	00 ff                	add    bh,bh
    1cf1:	ff 4d 5d             	dec    WORD PTR [di+0x5d]
    1cf4:	12 1d                	adc    bl,BYTE PTR [di]
    1cf6:	01 00                	add    WORD PTR [bx+si],ax
    1cf8:	00 00                	add    BYTE PTR [bx+si],al
    1cfa:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1cfe:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    1d02:	05 49 74             	add    ax,0x7449
    1d05:	65 6d                	gs ins WORD PTR es:[di],dx
    1d07:	73 d4                	jae    0x1cdd
    1d09:	22 2c                	and    ch,BYTE PTR [si]
    1d0b:	1d e4 00             	sbb    ax,0xe4
    1d0e:	ff                   	(bad)
    1d0f:	ff 4f 5c             	dec    WORD PTR [bx+0x5c]
    1d12:	09 1e 01 00          	or     WORD PTR ds:0x1,bx
    1d16:	00 00                	add    BYTE PTR [bx+si],al
    1d18:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1d1c:	00 00                	add    BYTE PTR [bx+si],al
    1d1e:	14 00                	adc    al,0x0
    1d20:	09 4d 61             	or     WORD PTR [di+0x61],cx
    1d23:	78 4c                	js     0x1d71
    1d25:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1d27:	67 74 68             	addr32 je 0x1d92
    1d2a:	07                   	pop    es
    1d2b:	23 50 1d             	and    dx,WORD PTR [bx+si+0x1d]
    1d2e:	2c 00                	sub    al,0x0
    1d30:	ff                   	(bad)
    1d31:	ff 32                	push   WORD PTR [bp+si]
    1d33:	1f                   	pop    ds
    1d34:	58                   	pop    ax
    1d35:	1d 01 00             	sbb    ax,0x1
    1d38:	00 00                	add    BYTE PTR [bx+si],al
    1d3a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1d3e:	00 00                	add    BYTE PTR [bx+si],al
    1d40:	15 00 0b             	adc    ax,0xb00
    1d43:	50                   	push   ax
    1d44:	61                   	popa
    1d45:	72 65                	jb     0x1dac
    1d47:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d48:	74 43                	je     0x1d8d
    1d4a:	6f                   	outs   dx,WORD PTR ds:[si]
    1d4b:	6c                   	ins    BYTE PTR es:[di],dx
    1d4c:	6f                   	outs   dx,WORD PTR ds:[si]
    1d4d:	72 07                	jb     0x1d56
    1d4f:	23 74 1d             	and    si,WORD PTR [si+0x1d]
    1d52:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    1d53:	00 ff                	add    bh,bh
    1d55:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    1d58:	7c 1d                	jl     0x1d77
    1d5a:	01 00                	add    WORD PTR [bx+si],ax
    1d5c:	00 00                	add    BYTE PTR [bx+si],al
    1d5e:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1d62:	00 00                	add    BYTE PTR [bx+si],al
    1d64:	16                   	push   ss
    1d65:	00 0b                	add    BYTE PTR [bp+di],cl
    1d67:	50                   	push   ax
    1d68:	61                   	popa
    1d69:	72 65                	jb     0x1dd0
    1d6b:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d6c:	74 43                	je     0x1db1
    1d6e:	74 6c                	je     0x1ddc
    1d70:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    1d73:	23 97 1d 2b          	and    dx,WORD PTR [bx+0x2b1d]
    1d77:	00 ff                	add    bh,bh
    1d79:	ff                   	(bad)
    1d7a:	3e 1e                	ds push ds
    1d7c:	9f                   	lahf
    1d7d:	1d 01 00             	sbb    ax,0x1
    1d80:	00 00                	add    BYTE PTR [bx+si],al
    1d82:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1d86:	00 00                	add    BYTE PTR [bx+si],al
    1d88:	17                   	pop    ss
    1d89:	00 0a                	add    BYTE PTR [bp+si],cl
    1d8b:	50                   	push   ax
    1d8c:	61                   	popa
    1d8d:	72 65                	jb     0x1df4
    1d8f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d90:	74 46                	je     0x1dd8
    1d92:	6f                   	outs   dx,WORD PTR ds:[si]
    1d93:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d94:	74 07                	je     0x1d9d
    1d96:	23 e0                	and    sp,ax
    1d98:	1d 49 00             	sbb    ax,0x49
    1d9b:	ff                   	(bad)
    1d9c:	ff a1 1e e8          	jmp    WORD PTR [bx+di-0x17e2]
    1da0:	1d 01 00             	sbb    ax,0x1
    1da3:	00 00                	add    BYTE PTR [bx+si],al
    1da5:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1da9:	00 00                	add    BYTE PTR [bx+si],al
    1dab:	18 00                	sbb    BYTE PTR [bx+si],al
    1dad:	0e                   	push   cs
    1dae:	50                   	push   ax
    1daf:	61                   	popa
    1db0:	72 65                	jb     0x1e17
    1db2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1db3:	74 53                	je     0x1e08
    1db5:	68 6f 77             	push   0x776f
    1db8:	48                   	dec    ax
    1db9:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    1dbe:	7e 23                	jle    0x1de3
    1dc0:	40                   	inc    ax
    1dc1:	00 ff                	add    bh,bh
    1dc3:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    1dc6:	ff                   	(bad)
    1dc7:	ff 01                	inc    WORD PTR [bx+di]
    1dc9:	00 00                	add    BYTE PTR [bx+si],al
    1dcb:	00 00                	add    BYTE PTR [bx+si],al
    1dcd:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1dd0:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
    1dd4:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    1dd7:	70 75                	jo     0x1e4e
    1dd9:	70 4d                	jo     0x1e28
    1ddb:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1ddd:	75 07                	jne    0x1de6
    1ddf:	23 01                	and    ax,WORD PTR [bx+di]
    1de1:	1e                   	push   ds
    1de2:	48                   	dec    ax
    1de3:	00 ff                	add    bh,bh
    1de5:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    1de8:	ec                   	in     al,dx
    1de9:	1d 23 1e             	sbb    ax,0x1e23
    1dec:	20 1e 00 80          	and    BYTE PTR ds:0x8000,bl
    1df0:	00 00                	add    BYTE PTR [bx+si],al
    1df2:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
    1df6:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    1df9:	6f                   	outs   dx,WORD PTR ds:[si]
    1dfa:	77 48                	ja     0x1e44
    1dfc:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
    1e01:	41                   	inc    cx
    1e02:	1e                   	push   ds
    1e03:	e0 00                	loopne 0x1e05
    1e05:	ff                   	(bad)
    1e06:	ff 90 5c 48          	call   WORD PTR [bx+si+0x485c]
    1e0a:	1f                   	pop    ds
    1e0b:	01 00                	add    WORD PTR [bx+si],ax
    1e0d:	00 00                	add    BYTE PTR [bx+si],al
    1e0f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1e13:	00 00                	add    BYTE PTR [bx+si],al
    1e15:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1e17:	06                   	push   es
    1e18:	53                   	push   bx
    1e19:	6f                   	outs   dx,WORD PTR ds:[si]
    1e1a:	72 74                	jb     0x1e90
    1e1c:	65 64 52             	gs fs push dx
    1e1f:	01 24                	add    WORD PTR [si],sp
    1e21:	1e                   	push   ds
    1e22:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    1e23:	63 28                	arpl   WORD PTR [bx+si],bp
    1e25:	1e                   	push   ds
    1e26:	60                   	pusha
    1e27:	64 49                	fs dec cx
    1e29:	1e                   	push   ds
    1e2a:	01 00                	add    WORD PTR [bx+si],ax
    1e2c:	00 00                	add    BYTE PTR [bx+si],al
    1e2e:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1e32:	ff                   	(bad)
    1e33:	ff 1c                	call   DWORD PTR [si]
    1e35:	00 08                	add    BYTE PTR [bx+si],cl
    1e37:	54                   	push   sp
    1e38:	61                   	popa
    1e39:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    1e3c:	64 65 72 07          	fs gs jb 0x1e47
    1e40:	23 7e 1e             	and    di,WORD PTR [bp+0x1e]
    1e43:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1e44:	00 ff                	add    bh,bh
    1e46:	ff 88 64 61          	dec    WORD PTR [bx+si+0x6164]
    1e4a:	1e                   	push   ds
    1e4b:	01 00                	add    WORD PTR [bx+si],ax
    1e4d:	00 00                	add    BYTE PTR [bx+si],al
    1e4f:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1e53:	00 00                	add    BYTE PTR [bx+si],al
    1e55:	09 00                	or     WORD PTR [bx+si],ax
    1e57:	07                   	pop    es
    1e58:	54                   	push   sp
    1e59:	61                   	popa
    1e5a:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    1e5d:	6f                   	outs   dx,WORD PTR ds:[si]
    1e5e:	70 66                	jo     0x1ec6
    1e60:	01 65 1e             	add    WORD PTR [di+0x1e],sp
    1e63:	53                   	push   bx
    1e64:	1d 69 1e             	sbb    ax,0x1e69
    1e67:	8c 1d                	mov    WORD PTR [di],ds
    1e69:	86 1e 01 00          	xchg   BYTE PTR ds:0x1,bl
    1e6d:	00 00                	add    BYTE PTR [bx+si],al
    1e6f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1e73:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    1e77:	04 54                	add    al,0x54
    1e79:	65 78 74             	gs js  0x1ef0
    1e7c:	07                   	pop    es
    1e7d:	23 92 20 29          	and    dx,WORD PTR [bp+si+0x2920]
    1e81:	00 ff                	add    bh,bh
    1e83:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    1e86:	02 1f                	add    bl,BYTE PTR [bx]
    1e88:	01 00                	add    WORD PTR [bx+si],ax
    1e8a:	00 00                	add    BYTE PTR [bx+si],al
    1e8c:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1e90:	00 00                	add    BYTE PTR [bx+si],al
    1e92:	1e                   	push   ds
    1e93:	00 07                	add    BYTE PTR [bx],al
    1e95:	56                   	push   si
    1e96:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    1e9b:	65 71 00             	gs jno 0x1e9e
    1e9e:	bf 1e 1a             	mov    di,0x1a1e
    1ea1:	01 ff                	add    di,di
    1ea3:	ff 1a                	call   DWORD PTR [bp+si]
    1ea5:	01 ff                	add    di,di
    1ea7:	ff 01                	inc    WORD PTR [bx+di]
    1ea9:	00 00                	add    BYTE PTR [bx+si],al
    1eab:	00 00                	add    BYTE PTR [bx+si],al
    1ead:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1eb0:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    1eb4:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
    1eb7:	43                   	inc    bx
    1eb8:	68 61 6e             	push   0x6e61
    1ebb:	67 65 71 00          	addr32 gs jno 0x1ebf
    1ebf:	df 1e 7a 00          	fistp  WORD PTR ds:0x7a
    1ec3:	ff                   	(bad)
    1ec4:	ff                   	(bad)
    1ec5:	7a 00                	jp     0x1ec7
    1ec7:	ff                   	(bad)
    1ec8:	ff 01                	inc    WORD PTR [bx+di]
    1eca:	00 00                	add    BYTE PTR [bx+si],al
    1ecc:	00 00                	add    BYTE PTR [bx+si],al
    1ece:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1ed1:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    1ed5:	07                   	pop    es
    1ed6:	4f                   	dec    di
    1ed7:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ed8:	43                   	inc    bx
    1ed9:	6c                   	ins    BYTE PTR es:[di],dx
    1eda:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    1edf:	6b 1f 82             	imul   bx,WORD PTR [bx],0xff82
    1ee2:	00 ff                	add    bh,bh
    1ee4:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    1ee8:	ff 01                	inc    WORD PTR [bx+di]
    1eea:	00 00                	add    BYTE PTR [bx+si],al
    1eec:	00 00                	add    BYTE PTR [bx+si],al
    1eee:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1ef1:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    1ef5:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1ef8:	44                   	inc    sp
    1ef9:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    1efc:	6c                   	ins    BYTE PTR es:[di],dx
    1efd:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    1f02:	25 1f 62             	and    ax,0x621f
    1f05:	00 ff                	add    bh,bh
    1f07:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    1f0a:	ff                   	(bad)
    1f0b:	ff 01                	inc    WORD PTR [bx+di]
    1f0d:	00 00                	add    BYTE PTR [bx+si],al
    1f0f:	00 00                	add    BYTE PTR [bx+si],al
    1f11:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1f14:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    1f18:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1f1b:	44                   	inc    sp
    1f1c:	72 61                	jb     0x1f7f
    1f1e:	67 44                	addr32 inc sp
    1f20:	72 6f                	jb     0x1f91
    1f22:	70 80                	jo     0x1ea4
    1f24:	02 8e 1f 6a          	add    cl,BYTE PTR [bp+0x6a1f]
    1f28:	00 ff                	add    bh,bh
    1f2a:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    1f2d:	ff                   	(bad)
    1f2e:	ff 01                	inc    WORD PTR [bx+di]
    1f30:	00 00                	add    BYTE PTR [bx+si],al
    1f32:	00 00                	add    BYTE PTR [bx+si],al
    1f34:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1f37:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    1f3b:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1f3e:	44                   	inc    sp
    1f3f:	72 61                	jb     0x1fa2
    1f41:	67 4f                	addr32 dec di
    1f43:	76 65                	jbe    0x1faa
    1f45:	72 f8                	jb     0x1f3f
    1f47:	18 54 20             	sbb    BYTE PTR [si+0x20],dl
    1f4a:	06                   	push   es
    1f4b:	01 ff                	add    di,di
    1f4d:	ff 06 01 ff          	inc    WORD PTR ds:0xff01
    1f51:	ff 01                	inc    WORD PTR [bx+di]
    1f53:	00 00                	add    BYTE PTR [bx+si],al
    1f55:	00 00                	add    BYTE PTR [bx+si],al
    1f57:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1f5a:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    1f5e:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1f61:	44                   	inc    sp
    1f62:	72 61                	jb     0x1fc5
    1f64:	77 49                	ja     0x1faf
    1f66:	74 65                	je     0x1fcd
    1f68:	6d                   	ins    WORD PTR es:[di],dx
    1f69:	71 00                	jno    0x1f6b
    1f6b:	b0 1f                	mov    al,0x1f
    1f6d:	fe 00                	inc    BYTE PTR [bx+si]
    1f6f:	ff                   	(bad)
    1f70:	ff                   	(bad)
    1f71:	fe 00                	inc    BYTE PTR [bx+si]
    1f73:	ff                   	(bad)
    1f74:	ff 01                	inc    WORD PTR [bx+di]
    1f76:	00 00                	add    BYTE PTR [bx+si],al
    1f78:	00 00                	add    BYTE PTR [bx+si],al
    1f7a:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1f7d:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    1f81:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1f84:	44                   	inc    sp
    1f85:	72 6f                	jb     0x1ff6
    1f87:	70 44                	jo     0x1fcd
    1f89:	6f                   	outs   dx,WORD PTR ds:[si]
    1f8a:	77 6e                	ja     0x1ffa
    1f8c:	32 03                	xor    al,BYTE PTR [bp+di]
    1f8e:	ef                   	out    dx,ax
    1f8f:	1f                   	pop    ds
    1f90:	72 00                	jb     0x1f92
    1f92:	ff                   	(bad)
    1f93:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    1f96:	ff                   	(bad)
    1f97:	ff 01                	inc    WORD PTR [bx+di]
    1f99:	00 00                	add    BYTE PTR [bx+si],al
    1f9b:	00 00                	add    BYTE PTR [bx+si],al
    1f9d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1fa0:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    1fa4:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    1fa7:	45                   	inc    bp
    1fa8:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fa9:	64 44                	fs inc sp
    1fab:	72 61                	jb     0x200e
    1fad:	67 71 00             	addr32 jno 0x1fb0
    1fb0:	d0 1f                	rcr    BYTE PTR [bx],1
    1fb2:	c8 00 ff ff          	enter  0xff00,0xff
    1fb6:	c8 00 ff ff          	enter  0xff00,0xff
    1fba:	01 00                	add    WORD PTR [bx+si],ax
    1fbc:	00 00                	add    BYTE PTR [bx+si],al
    1fbe:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1fc2:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    1fc6:	07                   	pop    es
    1fc7:	4f                   	dec    di
    1fc8:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fc9:	45                   	inc    bp
    1fca:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fcb:	74 65                	je     0x2032
    1fcd:	72 71                	jb     0x2040
    1fcf:	00 aa 20 d0          	add    BYTE PTR [bp+si-0x2fe0],ch
    1fd3:	00 ff                	add    bh,bh
    1fd5:	ff d0                	call   ax
    1fd7:	00 ff                	add    bh,bh
    1fd9:	ff 01                	inc    WORD PTR [bx+di]
    1fdb:	00 00                	add    BYTE PTR [bx+si],al
    1fdd:	00 00                	add    BYTE PTR [bx+si],al
    1fdf:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1fe2:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    1fe6:	06                   	push   es
    1fe7:	4f                   	dec    di
    1fe8:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fe9:	45                   	inc    bp
    1fea:	78 69                	js     0x2055
    1fec:	74 1a                	je     0x2008
    1fee:	02 11                	add    dl,BYTE PTR [bx+di]
    1ff0:	20 b0 00 ff          	and    BYTE PTR [bx+si-0x100],dh
    1ff4:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    1ff8:	ff 01                	inc    WORD PTR [bx+di]
    1ffa:	00 00                	add    BYTE PTR [bx+si],al
    1ffc:	00 00                	add    BYTE PTR [bx+si],al
    1ffe:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2001:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
    2005:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    2008:	4b                   	dec    bx
    2009:	65 79 44             	gs jns 0x2050
    200c:	6f                   	outs   dx,WORD PTR ds:[si]
    200d:	77 6e                	ja     0x207d
    200f:	54                   	push   sp
    2010:	02 34                	add    dh,BYTE PTR [si]
    2012:	20 b8 00 ff          	and    BYTE PTR [bx+si-0x100],bh
    2016:	ff                   	(bad)
    2017:	b8 00 ff             	mov    ax,0xff00
    201a:	ff 01                	inc    WORD PTR [bx+di]
    201c:	00 00                	add    BYTE PTR [bx+si],al
    201e:	00 00                	add    BYTE PTR [bx+si],al
    2020:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2023:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
    2027:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    202a:	4b                   	dec    bx
    202b:	65 79 50             	gs jns 0x207e
    202e:	72 65                	jb     0x2095
    2030:	73 73                	jae    0x20a5
    2032:	1a 02                	sbb    al,BYTE PTR [bp+si]
    2034:	ee                   	out    dx,al
    2035:	20 c0                	and    al,al
    2037:	00 ff                	add    bh,bh
    2039:	ff c0                	inc    ax
    203b:	00 ff                	add    bh,bh
    203d:	ff 01                	inc    WORD PTR [bx+di]
    203f:	00 00                	add    BYTE PTR [bx+si],al
    2041:	00 00                	add    BYTE PTR [bx+si],al
    2043:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2046:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
    204a:	07                   	pop    es
    204b:	4f                   	dec    di
    204c:	6e                   	outs   dx,BYTE PTR ds:[si]
    204d:	4b                   	dec    bx
    204e:	65 79 55             	gs jns 0x20a6
    2051:	70 51                	jo     0x20a4
    2053:	19 da                	sbb    dx,bx
    2055:	20 0e 01 ff          	and    BYTE PTR ds:0xff01,cl
    2059:	ff 0e 01 ff          	dec    WORD PTR ds:0xff01
    205d:	ff 01                	inc    WORD PTR [bx+di]
    205f:	00 00                	add    BYTE PTR [bx+si],al
    2061:	00 00                	add    BYTE PTR [bx+si],al
    2063:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2066:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
    206a:	0d 4f 6e             	or     ax,0x6e4f
    206d:	4d                   	dec    bp
    206e:	65 61                	gs popa
    2070:	73 75                	jae    0x20e7
    2072:	72 65                	jb     0x20d9
    2074:	49                   	dec    cx
    2075:	74 65                	je     0x20dc
    2077:	6d                   	ins    WORD PTR es:[di],dx
    2078:	23 21                	and    sp,WORD PTR [bx+di]
    207a:	00 00                	add    BYTE PTR [bx+si],al
    207c:	00 00                	add    BYTE PTR [bx+si],al
    207e:	00 00                	add    BYTE PTR [bx+si],al
    2080:	14 21                	adc    al,0x21
    2082:	da 00                	fiadd  DWORD PTR [bx+si]
    2084:	c1 05 39             	rol    WORD PTR [di],0x39
    2087:	21 fa                	and    dx,di
    2089:	45                   	inc    bp
    208a:	fe                   	(bad)
    208b:	20 9a 1f 62          	and    BYTE PTR [bp+si+0x621f],bl
    208f:	21 cb                	and    bx,cx
    2091:	1f                   	pop    ds
    2092:	8e 20                	mov    fs,WORD PTR [bx+si]
    2094:	fc                   	cld
    2095:	2e de 20             	fisub  WORD PTR cs:[bx+si]
    2098:	cd 11                	int    0x11
    209a:	a2 20 3a             	mov    ds:0x3a20,al
    209d:	27                   	daa
    209e:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    209f:	20 fa                	and    dl,bh
    20a1:	10 7a 21             	adc    BYTE PTR [bp+si+0x21],bh
    20a4:	d6                   	(bad)
    20a5:	14 ae                	adc    al,0xae
    20a7:	20 f4                	and    ah,dh
    20a9:	4f                   	dec    di
    20aa:	ba 20 32             	mov    dx,0x3220
    20ad:	16                   	push   ss
    20ae:	d6                   	(bad)
    20af:	20 ec                	and    ah,ch
    20b1:	30 0e 21 51          	xor    BYTE PTR ds:0x5121,cl
    20b5:	1b 86 20 38          	sbb    ax,WORD PTR [bp+0x3820]
    20b9:	50                   	push   ax
    20ba:	c2 20 63             	ret    0x6320
    20bd:	31 c6                	xor    si,ax
    20bf:	20 21                	and    BYTE PTR [bx+di],ah
    20c1:	50                   	push   ax
    20c2:	9a 20 61 2e 96       	call   0x962e:0x6120
    20c7:	20 d9                	and    cl,bl
    20c9:	62 ce 20             	(bad)  {k6}
    20cc:	06                   	push   es
    20cd:	63 d2                	arpl   dx,dx
    20cf:	20 8f 60 0a          	and    BYTE PTR [bx+0xa60],cl
    20d3:	21 3a                	and    WORD PTR [bp+si],di
    20d5:	1c b6                	sbb    al,0xb6
    20d7:	20 35                	and    BYTE PTR [di],dh
    20d9:	69 35 21 08          	imul   si,WORD PTR [di],0x821
    20dd:	61                   	popa
    20de:	e2 20                	loop   0x2100
    20e0:	5c                   	pop    sp
    20e1:	61                   	popa
    20e2:	e6 20                	out    0x20,al
    20e4:	62 5c 12             	bound  bx,DWORD PTR [si+0x12]
    20e7:	21 3a                	and    WORD PTR [bp+si],di
    20e9:	61                   	popa
    20ea:	9e                   	sahf
    20eb:	20 72 3f             	and    BYTE PTR [bp+si+0x3f],dh
    20ee:	f2 20 29             	repnz and BYTE PTR [bx+di],ch
    20f1:	3b f6                	cmp    si,si
    20f3:	20 17                	and    BYTE PTR [bx],dl
    20f5:	3e fa                	ds cli
    20f7:	20 88 3c 8a          	and    BYTE PTR [bx+si-0x75c4],cl
    20fb:	20 ed                	and    ch,ch
    20fd:	3e 02 21             	add    ah,BYTE PTR ds:[bx+di]
    2100:	77 3e                	ja     0x2140
    2102:	06                   	push   es
    2103:	21 c2                	and    dx,ax
    2105:	35 ca 20             	xor    ax,0x20ca
    2108:	1c 48                	sbb    al,0x48
    210a:	b2 20                	mov    dl,0x20
    210c:	ae                   	scas   al,BYTE PTR es:[di]
    210d:	5f                   	pop    di
    210e:	be 20 35             	mov    si,0x3520
    2111:	62 ea 20             	(bad)  {k6}
    2114:	0e                   	push   cs
    2115:	54                   	push   sp
    2116:	42                   	inc    dx
    2117:	75 74                	jne    0x218d
    2119:	74 6f                	je     0x218a
    211b:	6e                   	outs   dx,BYTE PTR ds:[si]
    211c:	43                   	inc    bx
    211d:	6f                   	outs   dx,WORD PTR ds:[si]
    211e:	6e                   	outs   dx,BYTE PTR ds:[si]
    211f:	74 72                	je     0x2193
    2121:	6f                   	outs   dx,WORD PTR ds:[si]
    2122:	6c                   	ins    BYTE PTR es:[di],dx
    2123:	07                   	pop    es
    2124:	0e                   	push   cs
    2125:	54                   	push   sp
    2126:	42                   	inc    dx
    2127:	75 74                	jne    0x219d
    2129:	74 6f                	je     0x219a
    212b:	6e                   	outs   dx,BYTE PTR ds:[si]
    212c:	43                   	inc    bx
    212d:	6f                   	outs   dx,WORD PTR ds:[si]
    212e:	6e                   	outs   dx,BYTE PTR ds:[si]
    212f:	74 72                	je     0x21a3
    2131:	6f                   	outs   dx,WORD PTR ds:[si]
    2132:	6c                   	ins    BYTE PTR es:[di],dx
    2133:	98                   	cbw
    2134:	20 c2                	and    dl,al
    2136:	21 d7                	and    di,dx
    2138:	07                   	pop    es
    2139:	be 21 09             	mov    si,0x921
    213c:	00 08                	add    BYTE PTR [bx+si],cl
    213e:	53                   	push   bx
    213f:	74 64                	je     0x21a5
    2141:	43                   	inc    bx
    2142:	74 72                	je     0x21b6
    2144:	6c                   	ins    BYTE PTR es:[di],dx
    2145:	73 00                	jae    0x2147
    2147:	00 10                	add    BYTE PTR [bx+si],dl
    2149:	22 00                	and    al,BYTE PTR [bx+si]
    214b:	00 00                	add    BYTE PTR [bx+si],al
    214d:	00 f0                	add    al,dh
    214f:	21 e8                	and    ax,bp
    2151:	21 e0                	and    ax,sp
    2153:	00 98 20 fe          	add    BYTE PTR [bx+si-0x1e0],bl
    2157:	21 fa                	and    dx,di
    2159:	45                   	inc    bp
    215a:	ce                   	into
    215b:	21 9a 1f 30          	and    WORD PTR [bp+si+0x301f],bx
    215f:	22 cb                	and    cl,bl
    2161:	1f                   	pop    ds
    2162:	5e                   	pop    si
    2163:	21 fc                	and    sp,di
    2165:	2e ae                	cs scas al,BYTE PTR es:[di]
    2167:	21 cd                	and    bp,cx
    2169:	11 72 21             	adc    WORD PTR [bp+si+0x21],si
    216c:	3a 27                	cmp    ah,BYTE PTR [bx]
    216e:	76 21                	jbe    0x2191
    2170:	fa                   	cli
    2171:	10 22                	adc    BYTE PTR [bp+si],ah
    2173:	24 d6                	and    al,0xd6
    2175:	14 7e                	adc    al,0x7e
    2177:	21 f4                	and    sp,si
    2179:	4f                   	dec    di
    217a:	8a 21                	mov    ah,BYTE PTR [bx+di]
    217c:	32 16 a6 21          	xor    dl,BYTE PTR ds:0x21a6
    2180:	ec                   	in     al,dx
    2181:	30 de                	xor    dh,bl
    2183:	21 51 1b             	and    WORD PTR [bx+di+0x1b],dx
    2186:	4f                   	dec    di
    2187:	22 38                	and    bh,BYTE PTR [bx+si]
    2189:	50                   	push   ax
    218a:	92                   	xchg   dx,ax
    218b:	21 63 31             	and    WORD PTR [bp+di+0x31],sp
    218e:	66 21 21             	and    DWORD PTR [bx+di],esp
    2191:	50                   	push   ax
    2192:	6a 21                	push   0x21
    2194:	b0 69                	mov    al,0x69
    2196:	aa                   	stos   BYTE PTR es:[di],al
    2197:	21 d9                	and    cx,bx
    2199:	62 9e 21 06          	bound  bx,DWORD PTR [bp+0x621]
    219d:	63 a2 21 8f          	arpl   WORD PTR [bp+si-0x70df],sp
    21a1:	60                   	pusha
    21a2:	da 21                	fisub  DWORD PTR [bx+di]
    21a4:	3a 1c                	cmp    bl,BYTE PTR [si]
    21a6:	86 21                	xchg   BYTE PTR [bx+di],ah
    21a8:	35 69 56             	xor    ax,0x5669
    21ab:	21 08                	and    WORD PTR [bx+si],cx
    21ad:	61                   	popa
    21ae:	b2 21                	mov    dl,0x21
    21b0:	5c                   	pop    sp
    21b1:	61                   	popa
    21b2:	b6 21                	mov    dh,0x21
    21b4:	62 5c e2             	bound  bx,DWORD PTR [si-0x1e]
    21b7:	21 3a                	and    WORD PTR [bp+si],di
    21b9:	61                   	popa
    21ba:	6e                   	outs   dx,BYTE PTR ds:[si]
    21bb:	21 72 3f             	and    WORD PTR [bp+si+0x3f],si
    21be:	c6                   	(bad)
    21bf:	21 ff                	and    di,di
    21c1:	6a ca                	push   0xffca
    21c3:	21 17                	and    WORD PTR [bx],dx
    21c5:	3e 5a                	ds pop dx
    21c7:	21 5c 6b             	and    WORD PTR [si+0x6b],bx
    21ca:	e6 21                	out    0x21,al
    21cc:	ed                   	in     ax,dx
    21cd:	3e d2 21             	shl    BYTE PTR ds:[bx+di],cl
    21d0:	77 3e                	ja     0x2210
    21d2:	d6                   	(bad)
    21d3:	21 c2                	and    dx,ax
    21d5:	35 9a 21             	xor    ax,0x219a
    21d8:	1c 48                	sbb    al,0x48
    21da:	82 21 ae             	and    BYTE PTR [bx+di],0xae
    21dd:	5f                   	pop    di
    21de:	8e 21                	mov    fs,WORD PTR [bx+di]
    21e0:	35 62 ba             	xor    ax,0xba62
    21e3:	21 50 6a             	and    WORD PTR [bx+si+0x6a],dx
    21e6:	96                   	xchg   si,ax
    21e7:	21 07                	and    WORD PTR [bx],ax
    21e9:	54                   	push   sp
    21ea:	42                   	inc    dx
    21eb:	75 74                	jne    0x2261
    21ed:	74 6f                	je     0x225e
    21ef:	6e                   	outs   dx,BYTE PTR ds:[si]
    21f0:	05 00 05             	add    ax,0x500
    21f3:	0f 06                	clts
    21f5:	0f 07                	sysret
    21f7:	0f 11 21             	movups XMMWORD PTR [bx+di],xmm4
    21fa:	fe                   	(bad)
    21fb:	ff 98 6b 02          	call   DWORD PTR [bx+si+0x26b]
    21ff:	22 20                	and    ah,BYTE PTR [bx+si]
    2201:	6c                   	ins    BYTE PTR es:[di],dx
    2202:	06                   	push   es
    2203:	22 8a 6c 0a          	and    cl,BYTE PTR [bp+si+0xa6c]
    2207:	22 7a 6b             	and    bh,BYTE PTR [bp+si+0x6b]
    220a:	0e                   	push   cs
    220b:	22 15                	and    dl,BYTE PTR [di]
    220d:	6a 1b                	push   0x1b
    220f:	22 07                	and    al,BYTE PTR [bx]
    2211:	07                   	pop    es
    2212:	54                   	push   sp
    2213:	42                   	inc    dx
    2214:	75 74                	jne    0x228a
    2216:	74 6f                	je     0x2287
    2218:	6e                   	outs   dx,BYTE PTR ds:[si]
    2219:	68 21 1f             	push   0x1f21
    221c:	22 23                	and    ah,BYTE PTR [bp+di]
    221e:	21 77 22             	and    WORD PTR [bx+0x22],si
    2221:	24 00                	and    al,0x0
    2223:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
    2226:	64 43                	fs inc bx
    2228:	74 72                	je     0x229c
    222a:	6c                   	ins    BYTE PTR es:[di],dx
    222b:	73 1b                	jae    0x2248
    222d:	00 07                	add    BYTE PTR [bx],al
    222f:	23 6f 22             	and    bp,WORD PTR [bx+0x22]
    2232:	db 00                	fild   DWORD PTR [bx+si]
    2234:	ff                   	(bad)
    2235:	ff                   	call   (bad)
    2236:	db 00                	fild   DWORD PTR [bx+si]
    2238:	ff                   	(bad)
    2239:	ff 01                	inc    WORD PTR [bx+di]
    223b:	00 00                	add    BYTE PTR [bx+si],al
    223d:	00 00                	add    BYTE PTR [bx+si],al
    223f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2242:	00 00                	add    BYTE PTR [bx+si],al
    2244:	09 00                	or     WORD PTR [bx+si],ax
    2246:	06                   	push   es
    2247:	43                   	inc    bx
    2248:	61                   	popa
    2249:	6e                   	outs   dx,BYTE PTR ds:[si]
    224a:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
    224d:	66 01 53 22          	add    DWORD PTR [bp+di+0x22],edx
    2251:	53                   	push   bx
    2252:	1d 57 22             	sbb    ax,0x2257
    2255:	8c 1d                	mov    WORD PTR [di],ds
    2257:	8f                   	(bad)
    2258:	22 01                	and    al,BYTE PTR [bx+di]
    225a:	00 00                	add    BYTE PTR [bx+si],al
    225c:	00 00                	add    BYTE PTR [bx+si],al
    225e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2261:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
    2265:	07                   	pop    es
    2266:	43                   	inc    bx
    2267:	61                   	popa
    2268:	70 74                	jo     0x22de
    226a:	69 6f 6e 07 23       	imul   bp,WORD PTR [bx+0x6e],0x2307
    226f:	d3 22                	shl    WORD PTR [bp+si],cl
    2271:	da 00                	fiadd  DWORD PTR [bx+si]
    2273:	ff                   	(bad)
    2274:	ff                   	(bad)
    2275:	bc 6a d1             	mov    sp,0xd16a
    2278:	25 01 00             	and    ax,0x1
    227b:	00 00                	add    BYTE PTR [bx+si],al
    227d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2281:	00 00                	add    BYTE PTR [bx+si],al
    2283:	0b 00                	or     ax,WORD PTR [bx+si]
    2285:	07                   	pop    es
    2286:	44                   	inc    sp
    2287:	65 66 61             	gs popad
    228a:	75 6c                	jne    0x22f8
    228c:	74 64                	je     0x22f2
    228e:	00 b2 22 3e          	add    BYTE PTR [bp+si+0x3e22],dh
    2292:	00 ff                	add    bh,bh
    2294:	ff                   	(bad)
    2295:	3e 00 ff             	ds add bh,bh
    2298:	ff 01                	inc    WORD PTR [bx+di]
    229a:	00 00                	add    BYTE PTR [bx+si],al
    229c:	00 00                	add    BYTE PTR [bx+si],al
    229e:	80 f4 ff             	xor    ah,0xff
    22a1:	ff                   	(bad)
    22a2:	ff 0c                	dec    WORD PTR [si]
    22a4:	00 0a                	add    BYTE PTR [bp+si],cl
    22a6:	44                   	inc    sp
    22a7:	72 61                	jb     0x230a
    22a9:	67 43                	addr32 inc bx
    22ab:	75 72                	jne    0x231f
    22ad:	73 6f                	jae    0x231e
    22af:	72 25                	jb     0x22d6
    22b1:	01 db                	add    bx,bx
    22b3:	22 2e 00 ff          	and    ch,BYTE PTR ds:0xff00
    22b7:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    22bb:	ff 01                	inc    WORD PTR [bx+di]
    22bd:	00 00                	add    BYTE PTR [bx+si],al
    22bf:	00 00                	add    BYTE PTR [bx+si],al
    22c1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    22c4:	00 00                	add    BYTE PTR [bx+si],al
    22c6:	0d 00 08             	or     ax,0x800
    22c9:	44                   	inc    sp
    22ca:	72 61                	jb     0x232d
    22cc:	67 4d                	addr32 dec bp
    22ce:	6f                   	outs   dx,WORD PTR ds:[si]
    22cf:	64 65 07             	fs gs pop es
    22d2:	23 34                	and    si,WORD PTR [si]
    22d4:	23 2a                	and    bp,WORD PTR [bp+si]
    22d6:	00 ff                	add    bh,bh
    22d8:	ff                   	(bad)
    22d9:	b8 1c fb             	mov    ax,0xfb1c
    22dc:	22 01                	and    al,BYTE PTR [bx+di]
    22de:	00 00                	add    BYTE PTR [bx+si],al
    22e0:	00 00                	add    BYTE PTR [bx+si],al
    22e2:	80 01 00             	add    BYTE PTR [bx+di],0x0
    22e5:	00 00                	add    BYTE PTR [bx+si],al
    22e7:	0e                   	push   cs
    22e8:	00 07                	add    BYTE PTR [bx],al
    22ea:	45                   	inc    bp
    22eb:	6e                   	outs   dx,BYTE PTR ds:[si]
    22ec:	61                   	popa
    22ed:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    22f0:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
    22f3:	54                   	push   sp
    22f4:	28 34                	sub    BYTE PTR [si],dh
    22f6:	00 ff                	add    bh,bh
    22f8:	ff                   	jmp    (bad)
    22f9:	eb 1d                	jmp    0x2318
    22fb:	ff 22                	jmp    WORD PTR [bp+si]
    22fd:	08 1e 3c 23          	or     BYTE PTR ds:0x233c,bl
    2301:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2305:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
    2309:	04 46                	add    al,0x46
    230b:	6f                   	outs   dx,WORD PTR ds:[si]
    230c:	6e                   	outs   dx,BYTE PTR ds:[si]
    230d:	74 5a                	je     0x2369
    230f:	04 49                	add    al,0x49
    2311:	33 de                	xor    bx,si
    2313:	00 ff                	add    bh,bh
    2315:	ff                   	call   (bad)
    2316:	de 00                	fiadd  WORD PTR [bx+si]
    2318:	ff                   	(bad)
    2319:	ff 01                	inc    WORD PTR [bx+di]
    231b:	00 00                	add    BYTE PTR [bx+si],al
    231d:	00 00                	add    BYTE PTR [bx+si],al
    231f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2322:	00 00                	add    BYTE PTR [bx+si],al
    2324:	10 00                	adc    BYTE PTR [bx+si],al
    2326:	0b 4d 6f             	or     cx,WORD PTR [di+0x6f]
    2329:	64 61                	fs popa
    232b:	6c                   	ins    BYTE PTR es:[di],dx
    232c:	52                   	push   dx
    232d:	65 73 75             	gs jae 0x23a5
    2330:	6c                   	ins    BYTE PTR es:[di],dx
    2331:	74 07                	je     0x233a
    2333:	23 57 23             	and    dx,WORD PTR [bx+0x23]
    2336:	2b 00                	sub    ax,WORD PTR [bx+si]
    2338:	ff                   	(bad)
    2339:	ff                   	(bad)
    233a:	3e 1e                	ds push ds
    233c:	5f                   	pop    di
    233d:	23 01                	and    ax,WORD PTR [bx+di]
    233f:	00 00                	add    BYTE PTR [bx+si],al
    2341:	00 00                	add    BYTE PTR [bx+si],al
    2343:	80 01 00             	add    BYTE PTR [bx+di],0x0
    2346:	00 00                	add    BYTE PTR [bx+si],al
    2348:	11 00                	adc    WORD PTR [bx+si],ax
    234a:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
    234d:	72 65                	jb     0x23b4
    234f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2350:	74 46                	je     0x2398
    2352:	6f                   	outs   dx,WORD PTR ds:[si]
    2353:	6e                   	outs   dx,BYTE PTR ds:[si]
    2354:	74 07                	je     0x235d
    2356:	23 a0 23 49          	and    sp,WORD PTR [bx+si+0x4923]
    235a:	00 ff                	add    bh,bh
    235c:	ff a1 1e a8          	jmp    WORD PTR [bx+di-0x57e2]
    2360:	23 01                	and    ax,WORD PTR [bx+di]
    2362:	00 00                	add    BYTE PTR [bx+si],al
    2364:	00 00                	add    BYTE PTR [bx+si],al
    2366:	80 01 00             	add    BYTE PTR [bx+di],0x0
    2369:	00 00                	add    BYTE PTR [bx+si],al
    236b:	12 00                	adc    al,BYTE PTR [bx+si]
    236d:	0e                   	push   cs
    236e:	50                   	push   ax
    236f:	61                   	popa
    2370:	72 65                	jb     0x23d7
    2372:	6e                   	outs   dx,BYTE PTR ds:[si]
    2373:	74 53                	je     0x23c8
    2375:	68 6f 77             	push   0x776f
    2378:	48                   	dec    ax
    2379:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    237e:	a3 29 40             	mov    ds:0x4029,ax
    2381:	00 ff                	add    bh,bh
    2383:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    2386:	ff                   	(bad)
    2387:	ff 01                	inc    WORD PTR [bx+di]
    2389:	00 00                	add    BYTE PTR [bx+si],al
    238b:	00 00                	add    BYTE PTR [bx+si],al
    238d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2390:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    2394:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    2397:	70 75                	jo     0x240e
    2399:	70 4d                	jo     0x23e8
    239b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    239d:	75 07                	jne    0x23a6
    239f:	23 e2                	and    sp,dx
    23a1:	23 48 00             	and    cx,WORD PTR [bx+si+0x0]
    23a4:	ff                   	(bad)
    23a5:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    23a8:	ac                   	lods   al,BYTE PTR ds:[si]
    23a9:	23 23                	and    sp,WORD PTR [bp+di]
    23ab:	1e                   	push   ds
    23ac:	c1 23 00             	shl    WORD PTR [bp+di],0x0
    23af:	80 00 00             	add    BYTE PTR [bx+si],0x0
    23b2:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
    23b6:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    23b9:	6f                   	outs   dx,WORD PTR ds:[si]
    23ba:	77 48                	ja     0x2404
    23bc:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
    23c1:	c5 23                	lds    sp,DWORD PTR [bp+di]
    23c3:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    23c4:	63 c9                	arpl   cx,cx
    23c6:	23 60 64             	and    sp,WORD PTR [bx+si+0x64]
    23c9:	ea 23 01 00 00       	jmp    0x0:0x123
    23ce:	00 00                	add    BYTE PTR [bx+si],al
    23d0:	80 ff ff             	cmp    bh,0xff
    23d3:	ff                   	(bad)
    23d4:	ff 15                	call   WORD PTR [di]
    23d6:	00 08                	add    BYTE PTR [bx+si],cl
    23d8:	54                   	push   sp
    23d9:	61                   	popa
    23da:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    23dd:	64 65 72 07          	fs gs jb 0x23e8
    23e1:	23 02                	and    ax,WORD PTR [bp+si]
    23e3:	24 a4                	and    al,0xa4
    23e5:	00 ff                	add    bh,bh
    23e7:	ff 88 64 0a          	dec    WORD PTR [bx+si+0xa64]
    23eb:	24 01                	and    al,0x1
    23ed:	00 00                	add    BYTE PTR [bx+si],al
    23ef:	00 00                	add    BYTE PTR [bx+si],al
    23f1:	80 01 00             	add    BYTE PTR [bx+di],0x0
    23f4:	00 00                	add    BYTE PTR [bx+si],al
    23f6:	16                   	push   ss
    23f7:	00 07                	add    BYTE PTR [bx],al
    23f9:	54                   	push   sp
    23fa:	61                   	popa
    23fb:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    23fe:	6f                   	outs   dx,WORD PTR ds:[si]
    23ff:	70 07                	jo     0x2408
    2401:	23 0c                	and    cx,WORD PTR [si]
    2403:	26 29 00             	sub    WORD PTR es:[bx+si],ax
    2406:	ff                   	(bad)
    2407:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    240a:	42                   	inc    dx
    240b:	24 01                	and    al,0x1
    240d:	00 00                	add    BYTE PTR [bx+si],al
    240f:	00 00                	add    BYTE PTR [bx+si],al
    2411:	80 01 00             	add    BYTE PTR [bx+di],0x0
    2414:	00 00                	add    BYTE PTR [bx+si],al
    2416:	17                   	pop    ss
    2417:	00 07                	add    BYTE PTR [bx],al
    2419:	56                   	push   si
    241a:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    241f:	65 71 00             	gs jno 0x2422
    2422:	aa                   	stos   BYTE PTR es:[di],al
    2423:	24 7a                	and    al,0x7a
    2425:	00 ff                	add    bh,bh
    2427:	ff                   	(bad)
    2428:	7a 00                	jp     0x242a
    242a:	ff                   	(bad)
    242b:	ff 01                	inc    WORD PTR [bx+di]
    242d:	00 00                	add    BYTE PTR [bx+si],al
    242f:	00 00                	add    BYTE PTR [bx+si],al
    2431:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2434:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
    2438:	07                   	pop    es
    2439:	4f                   	dec    di
    243a:	6e                   	outs   dx,BYTE PTR ds:[si]
    243b:	43                   	inc    bx
    243c:	6c                   	ins    BYTE PTR es:[di],dx
    243d:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    2442:	65 24 62             	gs and al,0x62
    2445:	00 ff                	add    bh,bh
    2447:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    244a:	ff                   	(bad)
    244b:	ff 01                	inc    WORD PTR [bx+di]
    244d:	00 00                	add    BYTE PTR [bx+si],al
    244f:	00 00                	add    BYTE PTR [bx+si],al
    2451:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2454:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
    2458:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    245b:	44                   	inc    sp
    245c:	72 61                	jb     0x24bf
    245e:	67 44                	addr32 inc sp
    2460:	72 6f                	jb     0x24d1
    2462:	70 80                	jo     0x23e4
    2464:	02 88 24 6a          	add    cl,BYTE PTR [bx+si+0x6a24]
    2468:	00 ff                	add    bh,bh
    246a:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    246d:	ff                   	(bad)
    246e:	ff 01                	inc    WORD PTR [bx+di]
    2470:	00 00                	add    BYTE PTR [bx+si],al
    2472:	00 00                	add    BYTE PTR [bx+si],al
    2474:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2477:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
    247b:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    247e:	44                   	inc    sp
    247f:	72 61                	jb     0x24e2
    2481:	67 4f                	addr32 dec di
    2483:	76 65                	jbe    0x24ea
    2485:	72 32                	jb     0x24b9
    2487:	03 e9                	add    bp,cx
    2489:	24 72                	and    al,0x72
    248b:	00 ff                	add    bh,bh
    248d:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    2490:	ff                   	(bad)
    2491:	ff 01                	inc    WORD PTR [bx+di]
    2493:	00 00                	add    BYTE PTR [bx+si],al
    2495:	00 00                	add    BYTE PTR [bx+si],al
    2497:	80 00 00             	add    BYTE PTR [bx+si],0x0
    249a:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
    249e:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    24a1:	45                   	inc    bp
    24a2:	6e                   	outs   dx,BYTE PTR ds:[si]
    24a3:	64 44                	fs inc sp
    24a5:	72 61                	jb     0x2508
    24a7:	67 71 00             	addr32 jno 0x24aa
    24aa:	ca 24 c8             	retf   0xc824
    24ad:	00 ff                	add    bh,bh
    24af:	ff c8                	dec    ax
    24b1:	00 ff                	add    bh,bh
    24b3:	ff 01                	inc    WORD PTR [bx+di]
    24b5:	00 00                	add    BYTE PTR [bx+si],al
    24b7:	00 00                	add    BYTE PTR [bx+si],al
    24b9:	80 00 00             	add    BYTE PTR [bx+si],0x0
    24bc:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    24c0:	07                   	pop    es
    24c1:	4f                   	dec    di
    24c2:	6e                   	outs   dx,BYTE PTR ds:[si]
    24c3:	45                   	inc    bp
    24c4:	6e                   	outs   dx,BYTE PTR ds:[si]
    24c5:	74 65                	je     0x252c
    24c7:	72 71                	jb     0x253a
    24c9:	00 24                	add    BYTE PTR [si],ah
    24cb:	26 d0 00             	rol    BYTE PTR es:[bx+si],1
    24ce:	ff                   	(bad)
    24cf:	ff d0                	call   ax
    24d1:	00 ff                	add    bh,bh
    24d3:	ff 01                	inc    WORD PTR [bx+di]
    24d5:	00 00                	add    BYTE PTR [bx+si],al
    24d7:	00 00                	add    BYTE PTR [bx+si],al
    24d9:	80 00 00             	add    BYTE PTR [bx+si],0x0
    24dc:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    24e0:	06                   	push   es
    24e1:	4f                   	dec    di
    24e2:	6e                   	outs   dx,BYTE PTR ds:[si]
    24e3:	45                   	inc    bp
    24e4:	78 69                	js     0x254f
    24e6:	74 1a                	je     0x2502
    24e8:	02 0b                	add    cl,BYTE PTR [bp+di]
    24ea:	25 b0 00             	and    ax,0xb0
    24ed:	ff                   	(bad)
    24ee:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    24f2:	ff 01                	inc    WORD PTR [bx+di]
    24f4:	00 00                	add    BYTE PTR [bx+si],al
    24f6:	00 00                	add    BYTE PTR [bx+si],al
    24f8:	80 00 00             	add    BYTE PTR [bx+si],0x0
    24fb:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    24ff:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    2502:	4b                   	dec    bx
    2503:	65 79 44             	gs jns 0x254a
    2506:	6f                   	outs   dx,WORD PTR ds:[si]
    2507:	77 6e                	ja     0x2577
    2509:	54                   	push   sp
    250a:	02 2e 25 b8          	add    ch,BYTE PTR ds:0xb825
    250e:	00 ff                	add    bh,bh
    2510:	ff                   	(bad)
    2511:	b8 00 ff             	mov    ax,0xff00
    2514:	ff 01                	inc    WORD PTR [bx+di]
    2516:	00 00                	add    BYTE PTR [bx+si],al
    2518:	00 00                	add    BYTE PTR [bx+si],al
    251a:	80 00 00             	add    BYTE PTR [bx+si],0x0
    251d:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    2521:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2524:	4b                   	dec    bx
    2525:	65 79 50             	gs jns 0x2578
    2528:	72 65                	jb     0x258f
    252a:	73 73                	jae    0x259f
    252c:	1a 02                	sbb    al,BYTE PTR [bp+si]
    252e:	4e                   	dec    si
    252f:	25 c0 00             	and    ax,0xc0
    2532:	ff                   	(bad)
    2533:	ff c0                	inc    ax
    2535:	00 ff                	add    bh,bh
    2537:	ff 01                	inc    WORD PTR [bx+di]
    2539:	00 00                	add    BYTE PTR [bx+si],al
    253b:	00 00                	add    BYTE PTR [bx+si],al
    253d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2540:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    2544:	07                   	pop    es
    2545:	4f                   	dec    di
    2546:	6e                   	outs   dx,BYTE PTR ds:[si]
    2547:	4b                   	dec    bx
    2548:	65 79 55             	gs jns 0x25a0
    254b:	70 71                	jo     0x25be
    254d:	01 72 25             	add    WORD PTR [bp+si+0x25],si
    2550:	4a                   	dec    dx
    2551:	00 ff                	add    bh,bh
    2553:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    2556:	ff                   	(bad)
    2557:	ff 01                	inc    WORD PTR [bx+di]
    2559:	00 00                	add    BYTE PTR [bx+si],al
    255b:	00 00                	add    BYTE PTR [bx+si],al
    255d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2560:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    2564:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    2567:	4d                   	dec    bp
    2568:	6f                   	outs   dx,WORD PTR ds:[si]
    2569:	75 73                	jne    0x25de
    256b:	65 44                	gs inc sp
    256d:	6f                   	outs   dx,WORD PTR ds:[si]
    256e:	77 6e                	ja     0x25de
    2570:	ce                   	into
    2571:	01 96 25 52          	add    WORD PTR [bp+0x5225],dx
    2575:	00 ff                	add    bh,bh
    2577:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    257a:	ff                   	(bad)
    257b:	ff 01                	inc    WORD PTR [bx+di]
    257d:	00 00                	add    BYTE PTR [bx+si],al
    257f:	00 00                	add    BYTE PTR [bx+si],al
    2581:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2584:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    2588:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    258b:	4d                   	dec    bp
    258c:	6f                   	outs   dx,WORD PTR ds:[si]
    258d:	75 73                	jne    0x2602
    258f:	65 4d                	gs dec bp
    2591:	6f                   	outs   dx,WORD PTR ds:[si]
    2592:	76 65                	jbe    0x25f9
    2594:	71 01                	jno    0x2597
    2596:	68 26 5a             	push   0x5a26
    2599:	00 ff                	add    bh,bh
    259b:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    259e:	ff                   	(bad)
    259f:	ff 01                	inc    WORD PTR [bx+di]
    25a1:	00 00                	add    BYTE PTR [bx+si],al
    25a3:	00 00                	add    BYTE PTR [bx+si],al
    25a5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    25a8:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    25ac:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    25af:	4d                   	dec    bp
    25b0:	6f                   	outs   dx,WORD PTR ds:[si]
    25b1:	75 73                	jne    0x2626
    25b3:	65 55                	gs push bp
    25b5:	70 03                	jo     0x25ba
    25b7:	0e                   	push   cs
    25b8:	54                   	push   sp
    25b9:	43                   	inc    bx
    25ba:	68 65 63             	push   0x6365
    25bd:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
    25c1:	53                   	push   bx
    25c2:	74 61                	je     0x2625
    25c4:	74 65                	je     0x262b
    25c6:	00 00                	add    BYTE PTR [bx+si],al
    25c8:	00 00                	add    BYTE PTR [bx+si],al
    25ca:	00 02                	add    BYTE PTR [bp+si],al
    25cc:	00 00                	add    BYTE PTR [bx+si],al
    25ce:	00 b6 25 90          	add    BYTE PTR [bp-0x6fdb],dh
    25d2:	26 0b 63 62          	or     sp,WORD PTR es:[bp+di+0x62]
    25d6:	55                   	push   bp
    25d7:	6e                   	outs   dx,BYTE PTR ds:[si]
    25d8:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    25db:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
    25de:	64 09 63 62          	or     WORD PTR fs:[bp+di+0x62],sp
    25e2:	43                   	inc    bx
    25e3:	68 65 63             	push   0x6365
    25e6:	6b 65 64 08          	imul   sp,WORD PTR [di+0x64],0x8
    25ea:	63 62 47             	arpl   WORD PTR [bp+si+0x47],sp
    25ed:	72 61                	jb     0x2650
    25ef:	79 65                	jns    0x2656
    25f1:	64 bc 26 00          	fs mov sp,0x26
    25f5:	00 00                	add    BYTE PTR [bx+si],al
    25f7:	00 a2 26 92          	add    BYTE PTR [bp+si-0x6dda],ah
    25fb:	26 de 00             	fiadd  WORD PTR es:[bx+si]
    25fe:	98                   	cbw
    25ff:	20 ae 26 fa          	and    BYTE PTR [bp-0x5da],ch
    2603:	45                   	inc    bp
    2604:	78 26                	js     0x262c
    2606:	9a 1f e4 26 cb       	call   0xcb26:0xe41f
    260b:	1f                   	pop    ds
    260c:	08 26 fc 2e          	or     BYTE PTR ds:0x2efc,ah
    2610:	58                   	pop    ax
    2611:	26 cd 11             	es int 0x11
    2614:	1c 26                	sbb    al,0x26
    2616:	3a 27                	cmp    ah,BYTE PTR [bx]
    2618:	20 26 fa 10          	and    BYTE PTR ds:0x10fa,ah
    261c:	34 27                	xor    al,0x27
    261e:	d6                   	(bad)
    261f:	14 28                	adc    al,0x28
    2621:	26 f4                	es hlt
    2623:	4f                   	dec    di
    2624:	34 26                	xor    al,0x26
    2626:	32 16 50 26          	xor    dl,BYTE PTR ds:0x2650
    262a:	ec                   	in     al,dx
    262b:	30 88 26 51          	xor    BYTE PTR [bx+si+0x5126],cl
    262f:	1b ec                	sbb    bp,sp
    2631:	26 38 50 3c          	cmp    BYTE PTR es:[bx+si+0x3c],dl
    2635:	26 63 31             	arpl   WORD PTR es:[bx+di],si
    2638:	10 26 21 50          	adc    BYTE PTR ds:0x5021,ah
    263c:	14 26                	adc    al,0x26
    263e:	08 6d 54             	or     BYTE PTR [di+0x54],ch
    2641:	26 d9 62 48          	fldenv es:[bp+si+0x48]
    2645:	26 06                	es push es
    2647:	63 4c 26             	arpl   WORD PTR [si+0x26],cx
    264a:	8f                   	(bad)
    264b:	60                   	pusha
    264c:	84 26 3a 1c          	test   BYTE PTR ds:0x1c3a,ah
    2650:	30 26 35 69          	xor    BYTE PTR ds:0x6935,ah
    2654:	00 26 08 61          	add    BYTE PTR ds:0x6108,ah
    2658:	5c                   	pop    sp
    2659:	26 5c                	es pop sp
    265b:	61                   	popa
    265c:	60                   	pusha
    265d:	26 62 5c 8c          	bound  bx,DWORD PTR es:[si-0x74]
    2661:	26 3a 61 18          	cmp    ah,BYTE PTR es:[bx+di+0x18]
    2665:	26 72 3f             	es jb  0x26a7
    2668:	70 26                	jo     0x2690
    266a:	8d 6e 74             	lea    bp,[bp+0x74]
    266d:	26 17                	es pop ss
    266f:	3e 04 26             	ds add al,0x26
    2672:	f5                   	cmc
    2673:	6e                   	outs   dx,BYTE PTR ds:[si]
    2674:	40                   	inc    ax
    2675:	26 ed                	es in  ax,dx
    2677:	3e 7c 26             	ds jl  0x26a0
    267a:	77 3e                	ja     0x26ba
    267c:	80 26 c2 35 44       	and    BYTE PTR ds:0x35c2,0x44
    2681:	26 1c 48             	es sbb al,0x48
    2684:	2c 26                	sub    al,0x26
    2686:	ae                   	scas   al,BYTE PTR es:[di]
    2687:	5f                   	pop    di
    2688:	38 26 35 62          	cmp    BYTE PTR ds:0x6235,ah
    268c:	64 26 7c 6d          	fs es jl 0x26fd
    2690:	6c                   	ins    BYTE PTR es:[di],dx
    2691:	26 0f 54 43 75       	andps  xmm0,XMMWORD PTR es:[bp+di+0x75]
    2696:	73 74                	jae    0x270c
    2698:	6f                   	outs   dx,WORD PTR ds:[si]
    2699:	6d                   	ins    WORD PTR es:[di],dx
    269a:	43                   	inc    bx
    269b:	68 65 63             	push   0x6365
    269e:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
    26a2:	04 00                	add    al,0x0
    26a4:	07                   	pop    es
    26a5:	00 10                	add    BYTE PTR [bx+si],dl
    26a7:	0f 06                	clts
    26a9:	0f 11 21             	movups XMMWORD PTR [bx+di],xmm4
    26ac:	4c                   	dec    sp
    26ad:	6f                   	outs   dx,WORD PTR ds:[si]
    26ae:	b2 26                	mov    dl,0x26
    26b0:	86 6f b6             	xchg   BYTE PTR [bx-0x4a],ch
    26b3:	26 97                	es xchg di,ax
    26b5:	6f                   	outs   dx,WORD PTR ds:[si]
    26b6:	ba 26 1a             	mov    dx,0x1a26
    26b9:	70 cf                	jo     0x268a
    26bb:	26 07                	es pop es
    26bd:	0f 54 43 75          	andps  xmm0,XMMWORD PTR [bp+di+0x75]
    26c1:	73 74                	jae    0x2737
    26c3:	6f                   	outs   dx,WORD PTR ds:[si]
    26c4:	6d                   	ins    WORD PTR es:[di],dx
    26c5:	43                   	inc    bx
    26c6:	68 65 63             	push   0x6365
    26c9:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
    26cd:	12 26 d3 26          	adc    ah,BYTE PTR ds:0x26d3
    26d1:	23 21                	and    sp,WORD PTR [bx+di]
    26d3:	a0 27 0a             	mov    al,ds:0xa27
    26d6:	00 08                	add    BYTE PTR [bx+si],cl
    26d8:	53                   	push   bx
    26d9:	74 64                	je     0x273f
    26db:	43                   	inc    bx
    26dc:	74 72                	je     0x2750
    26de:	6c                   	ins    BYTE PTR es:[di],dx
    26df:	73 01                	jae    0x26e2
    26e1:	00 07                	add    BYTE PTR [bx],al
    26e3:	23 1c                	and    bx,WORD PTR [si]
    26e5:	27                   	daa
    26e6:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    26e7:	00 ff                	add    bh,bh
    26e9:	ff 88 64 78          	dec    WORD PTR [bx+si+0x7864]
    26ed:	27                   	daa
    26ee:	01 00                	add    WORD PTR [bx+si],ax
    26f0:	00 00                	add    BYTE PTR [bx+si],al
    26f2:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    26f6:	00 00                	add    BYTE PTR [bx+si],al
    26f8:	09 00                	or     WORD PTR [bx+si],ax
    26fa:	07                   	pop    es
    26fb:	54                   	push   sp
    26fc:	61                   	popa
    26fd:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    2700:	6f                   	outs   dx,WORD PTR ds:[si]
    2701:	70 ac                	jo     0x26af
    2703:	27                   	daa
    2704:	00 00                	add    BYTE PTR [bx+si],al
    2706:	00 00                	add    BYTE PTR [bx+si],al
    2708:	00 00                	add    BYTE PTR [bx+si],al
    270a:	a2 27 de             	mov    ds:0xde27,al
    270d:	00 12                	add    BYTE PTR [bp+si],dl
    270f:	26 b9 27 fa          	es mov cx,0xfa27
    2713:	45                   	inc    bp
    2714:	88 27                	mov    BYTE PTR [bx],ah
    2716:	9a 1f f0 27 cb       	call   0xcb27:0xf01f
    271b:	1f                   	pop    ds
    271c:	18 27                	sbb    BYTE PTR [bx],ah
    271e:	fc                   	cld
    271f:	2e 68 27 cd          	cs push 0xcd27
    2723:	11 2c                	adc    WORD PTR [si],bp
    2725:	27                   	daa
    2726:	3a 27                	cmp    ah,BYTE PTR [bx]
    2728:	30 27                	xor    BYTE PTR [bx],ah
    272a:	fa                   	cli
    272b:	10 ce                	adc    dh,cl
    272d:	27                   	daa
    272e:	d6                   	(bad)
    272f:	14 38                	adc    al,0x38
    2731:	27                   	daa
    2732:	f4                   	hlt
    2733:	4f                   	dec    di
    2734:	44                   	inc    sp
    2735:	27                   	daa
    2736:	32 16 60 27          	xor    dl,BYTE PTR ds:0x2760
    273a:	ec                   	in     al,dx
    273b:	30 98 27 51          	xor    BYTE PTR [bx+si+0x5127],bl
    273f:	1b 14                	sbb    dx,WORD PTR [si]
    2741:	28 38                	sub    BYTE PTR [bx+si],bh
    2743:	50                   	push   ax
    2744:	4c                   	dec    sp
    2745:	27                   	daa
    2746:	63 31                	arpl   WORD PTR [bx+di],si
    2748:	20 27                	and    BYTE PTR [bx],ah
    274a:	21 50 24             	and    WORD PTR [bx+si+0x24],dx
    274d:	27                   	daa
    274e:	08 6d 64             	or     BYTE PTR [di+0x64],ch
    2751:	27                   	daa
    2752:	d9 62 58             	fldenv [bp+si+0x58]
    2755:	27                   	daa
    2756:	06                   	push   es
    2757:	63 5c 27             	arpl   WORD PTR [si+0x27],bx
    275a:	8f                   	(bad)
    275b:	60                   	pusha
    275c:	94                   	xchg   sp,ax
    275d:	27                   	daa
    275e:	3a 1c                	cmp    bl,BYTE PTR [si]
    2760:	40                   	inc    ax
    2761:	27                   	daa
    2762:	35 69 10             	xor    ax,0x1069
    2765:	27                   	daa
    2766:	08 61 6c             	or     BYTE PTR [bx+di+0x6c],ah
    2769:	27                   	daa
    276a:	5c                   	pop    sp
    276b:	61                   	popa
    276c:	70 27                	jo     0x2795
    276e:	62 5c 9c             	bound  bx,DWORD PTR [si-0x64]
    2771:	27                   	daa
    2772:	3a 61 28             	cmp    ah,BYTE PTR [bx+di+0x28]
    2775:	27                   	daa
    2776:	72 3f                	jb     0x27b7
    2778:	80 27 8d             	and    BYTE PTR [bx],0x8d
    277b:	6e                   	outs   dx,BYTE PTR ds:[si]
    277c:	84 27                	test   BYTE PTR [bx],ah
    277e:	17                   	pop    ss
    277f:	3e 14 27             	ds adc al,0x27
    2782:	f5                   	cmc
    2783:	6e                   	outs   dx,BYTE PTR ds:[si]
    2784:	50                   	push   ax
    2785:	27                   	daa
    2786:	ed                   	in     ax,dx
    2787:	3e 8c 27             	mov    WORD PTR ds:[bx],fs
    278a:	77 3e                	ja     0x27ca
    278c:	90                   	nop
    278d:	27                   	daa
    278e:	c2 35 54             	ret    0x5435
    2791:	27                   	daa
    2792:	1c 48                	sbb    al,0x48
    2794:	3c 27                	cmp    al,0x27
    2796:	ae                   	scas   al,BYTE PTR es:[di]
    2797:	5f                   	pop    di
    2798:	48                   	dec    ax
    2799:	27                   	daa
    279a:	35 62 74             	xor    ax,0x7462
    279d:	27                   	daa
    279e:	7c 6d                	jl     0x280d
    27a0:	7c 27                	jl     0x27c9
    27a2:	09 54 43             	or     WORD PTR [si+0x43],dx
    27a5:	68 65 63             	push   0x6365
    27a8:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
    27ac:	07                   	pop    es
    27ad:	09 54 43             	or     WORD PTR [si+0x43],dx
    27b0:	68 65 63             	push   0x6365
    27b3:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
    27b7:	22 27                	and    ah,BYTE PTR [bx]
    27b9:	bd 27 bc             	mov    bp,0xbc27
    27bc:	26 d6                	es (bad)
    27be:	27                   	daa
    27bf:	29 00                	sub    WORD PTR [bx+si],ax
    27c1:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
    27c4:	64 43                	fs inc bx
    27c6:	74 72                	je     0x283a
    27c8:	6c                   	ins    BYTE PTR es:[di],dx
    27c9:	73 20                	jae    0x27eb
    27cb:	00 41 00             	add    BYTE PTR [bx+di+0x0],al
    27ce:	65 2a da             	gs sub bl,dl
    27d1:	00 ff                	add    bh,bh
    27d3:	ff                   	jmp    (bad)
    27d4:	ee                   	out    dx,al
    27d5:	6d                   	ins    WORD PTR es:[di],dx
    27d6:	38 28                	cmp    BYTE PTR [bx+si],ch
    27d8:	01 00                	add    WORD PTR [bx+si],ax
    27da:	00 00                	add    BYTE PTR [bx+si],al
    27dc:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    27e0:	00 00                	add    BYTE PTR [bx+si],al
    27e2:	0a 00                	or     al,BYTE PTR [bx+si]
    27e4:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
    27e7:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
    27ec:	6e                   	outs   dx,BYTE PTR ds:[si]
    27ed:	74 07                	je     0x27f6
    27ef:	23 34                	and    si,WORD PTR [si]
    27f1:	28 db                	sub    bl,bl
    27f3:	00 ff                	add    bh,bh
    27f5:	ff                   	call   (bad)
    27f6:	db 00                	fild   DWORD PTR [bx+si]
    27f8:	ff                   	(bad)
    27f9:	ff 01                	inc    WORD PTR [bx+di]
    27fb:	00 00                	add    BYTE PTR [bx+si],al
    27fd:	00 00                	add    BYTE PTR [bx+si],al
    27ff:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2802:	00 00                	add    BYTE PTR [bx+si],al
    2804:	0b 00                	or     ax,WORD PTR [bx+si]
    2806:	0b 41 6c             	or     ax,WORD PTR [bx+di+0x6c]
    2809:	6c                   	ins    BYTE PTR es:[di],dx
    280a:	6f                   	outs   dx,WORD PTR ds:[si]
    280b:	77 47                	ja     0x2854
    280d:	72 61                	jb     0x2870
    280f:	79 65                	jns    0x2876
    2811:	64 66 01 18          	add    DWORD PTR fs:[bx+si],ebx
    2815:	28 53 1d             	sub    BYTE PTR [bp+di+0x1d],dl
    2818:	1c 28                	sbb    al,0x28
    281a:	8c 1d                	mov    WORD PTR [di],ds
    281c:	5c                   	pop    sp
    281d:	28 01                	sub    BYTE PTR [bx+di],al
    281f:	00 00                	add    BYTE PTR [bx+si],al
    2821:	00 00                	add    BYTE PTR [bx+si],al
    2823:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2826:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
    282a:	07                   	pop    es
    282b:	43                   	inc    bx
    282c:	61                   	popa
    282d:	70 74                	jo     0x28a3
    282f:	69 6f 6e 07 23       	imul   bp,WORD PTR [bx+0x6e],0x2307
    2834:	72 28                	jb     0x285e
    2836:	d2 6d 3c             	shr    BYTE PTR [di+0x3c],cl
    2839:	28 11                	sub    BYTE PTR [bx+di],dl
    283b:	6e                   	outs   dx,BYTE PTR ds:[si]
    283c:	e6 29                	out    0x29,al
    283e:	00 00                	add    BYTE PTR [bx+si],al
    2840:	00 00                	add    BYTE PTR [bx+si],al
    2842:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2846:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
    284a:	07                   	pop    es
    284b:	43                   	inc    bx
    284c:	68 65 63             	push   0x6365
    284f:	6b 65 64 02          	imul   sp,WORD PTR [di+0x64],0x2
    2853:	00 f4                	add    ah,dh
    2855:	28 38                	sub    BYTE PTR [bx+si],bh
    2857:	00 ff                	add    bh,bh
    2859:	ff d5                	call   bp
    285b:	1e                   	push   ds
    285c:	60                   	pusha
    285d:	28 17                	sub    BYTE PTR [bx],dl
    285f:	1f                   	pop    ds
    2860:	7a 28                	jp     0x288a
    2862:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
    2866:	ff                   	(bad)
    2867:	ff 0e 00 05          	dec    WORD PTR ds:0x500
    286b:	43                   	inc    bx
    286c:	6f                   	outs   dx,WORD PTR ds:[si]
    286d:	6c                   	ins    BYTE PTR es:[di],dx
    286e:	6f                   	outs   dx,WORD PTR ds:[si]
    286f:	72 07                	jb     0x2878
    2871:	23 d4                	and    dx,sp
    2873:	28 a5 00 ff          	sub    BYTE PTR [di-0x100],ah
    2877:	ff 22                	jmp    WORD PTR [bp+si]
    2879:	63 7e 28             	arpl   WORD PTR [bp+0x28],di
    287c:	54                   	push   sp
    287d:	63 90 28 00          	arpl   WORD PTR [bx+si+0x28],dx
    2881:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2884:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
    2888:	05 43 74             	add    ax,0x7443
    288b:	6c                   	ins    BYTE PTR es:[di],dx
    288c:	33 44 64             	xor    ax,WORD PTR [si+0x64]
    288f:	00 b3 28 3e          	add    BYTE PTR [bp+di+0x3e28],dh
    2893:	00 ff                	add    bh,bh
    2895:	ff                   	(bad)
    2896:	3e 00 ff             	ds add bh,bh
    2899:	ff 01                	inc    WORD PTR [bx+di]
    289b:	00 00                	add    BYTE PTR [bx+si],al
    289d:	00 00                	add    BYTE PTR [bx+si],al
    289f:	80 f4 ff             	xor    ah,0xff
    28a2:	ff                   	(bad)
    28a3:	ff 10                	call   WORD PTR [bx+si]
    28a5:	00 0a                	add    BYTE PTR [bp+si],cl
    28a7:	44                   	inc    sp
    28a8:	72 61                	jb     0x290b
    28aa:	67 43                	addr32 inc bx
    28ac:	75 72                	jne    0x2920
    28ae:	73 6f                	jae    0x291f
    28b0:	72 25                	jb     0x28d7
    28b2:	01 dc                	add    sp,bx
    28b4:	28 2e 00 ff          	sub    BYTE PTR ds:0xff00,ch
    28b8:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    28bc:	ff 01                	inc    WORD PTR [bx+di]
    28be:	00 00                	add    BYTE PTR [bx+si],al
    28c0:	00 00                	add    BYTE PTR [bx+si],al
    28c2:	80 00 00             	add    BYTE PTR [bx+si],0x0
    28c5:	00 00                	add    BYTE PTR [bx+si],al
    28c7:	11 00                	adc    WORD PTR [bx+si],ax
    28c9:	08 44 72             	or     BYTE PTR [si+0x72],al
    28cc:	61                   	popa
    28cd:	67 4d                	addr32 dec bp
    28cf:	6f                   	outs   dx,WORD PTR ds:[si]
    28d0:	64 65 07             	fs gs pop es
    28d3:	23 11                	and    dx,WORD PTR [bx+di]
    28d5:	29 2a                	sub    WORD PTR [bp+si],bp
    28d7:	00 ff                	add    bh,bh
    28d9:	ff                   	(bad)
    28da:	b8 1c fc             	mov    ax,0xfc1c
    28dd:	28 01                	sub    BYTE PTR [bx+di],al
    28df:	00 00                	add    BYTE PTR [bx+si],al
    28e1:	00 00                	add    BYTE PTR [bx+si],al
    28e3:	80 01 00             	add    BYTE PTR [bx+di],0x0
    28e6:	00 00                	add    BYTE PTR [bx+si],al
    28e8:	12 00                	adc    al,BYTE PTR [bx+si]
    28ea:	07                   	pop    es
    28eb:	45                   	inc    bp
    28ec:	6e                   	outs   dx,BYTE PTR ds:[si]
    28ed:	61                   	popa
    28ee:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    28f1:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
    28f4:	43                   	inc    bx
    28f5:	2d 34 00             	sub    ax,0x34
    28f8:	ff                   	(bad)
    28f9:	ff                   	jmp    (bad)
    28fa:	eb 1d                	jmp    0x2919
    28fc:	00 29                	add    BYTE PTR [bx+di],ch
    28fe:	08 1e 19 29          	or     BYTE PTR ds:0x2919,bl
    2902:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2906:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    290a:	04 46                	add    al,0x46
    290c:	6f                   	outs   dx,WORD PTR ds:[si]
    290d:	6e                   	outs   dx,BYTE PTR ds:[si]
    290e:	74 07                	je     0x2917
    2910:	23 35                	and    si,WORD PTR [di]
    2912:	29 2c                	sub    WORD PTR [si],bp
    2914:	00 ff                	add    bh,bh
    2916:	ff 32                	push   WORD PTR [bp+si]
    2918:	1f                   	pop    ds
    2919:	3d 29 01             	cmp    ax,0x129
    291c:	00 00                	add    BYTE PTR [bx+si],al
    291e:	00 00                	add    BYTE PTR [bx+si],al
    2920:	80 01 00             	add    BYTE PTR [bx+di],0x0
    2923:	00 00                	add    BYTE PTR [bx+si],al
    2925:	14 00                	adc    al,0x0
    2927:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    292a:	72 65                	jb     0x2991
    292c:	6e                   	outs   dx,BYTE PTR ds:[si]
    292d:	74 43                	je     0x2972
    292f:	6f                   	outs   dx,WORD PTR ds:[si]
    2930:	6c                   	ins    BYTE PTR es:[di],dx
    2931:	6f                   	outs   dx,WORD PTR ds:[si]
    2932:	72 07                	jb     0x293b
    2934:	23 59 29             	and    bx,WORD PTR [bx+di+0x29]
    2937:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    2938:	00 ff                	add    bh,bh
    293a:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    293d:	61                   	popa
    293e:	29 01                	sub    WORD PTR [bx+di],ax
    2940:	00 00                	add    BYTE PTR [bx+si],al
    2942:	00 00                	add    BYTE PTR [bx+si],al
    2944:	80 01 00             	add    BYTE PTR [bx+di],0x0
    2947:	00 00                	add    BYTE PTR [bx+si],al
    2949:	15 00 0b             	adc    ax,0xb00
    294c:	50                   	push   ax
    294d:	61                   	popa
    294e:	72 65                	jb     0x29b5
    2950:	6e                   	outs   dx,BYTE PTR ds:[si]
    2951:	74 43                	je     0x2996
    2953:	74 6c                	je     0x29c1
    2955:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    2958:	23 7c 29             	and    di,WORD PTR [si+0x29]
    295b:	2b 00                	sub    ax,WORD PTR [bx+si]
    295d:	ff                   	(bad)
    295e:	ff                   	(bad)
    295f:	3e 1e                	ds push ds
    2961:	84 29                	test   BYTE PTR [bx+di],ch
    2963:	01 00                	add    WORD PTR [bx+si],ax
    2965:	00 00                	add    BYTE PTR [bx+si],al
    2967:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    296b:	00 00                	add    BYTE PTR [bx+si],al
    296d:	16                   	push   ss
    296e:	00 0a                	add    BYTE PTR [bp+si],cl
    2970:	50                   	push   ax
    2971:	61                   	popa
    2972:	72 65                	jb     0x29d9
    2974:	6e                   	outs   dx,BYTE PTR ds:[si]
    2975:	74 46                	je     0x29bd
    2977:	6f                   	outs   dx,WORD PTR ds:[si]
    2978:	6e                   	outs   dx,BYTE PTR ds:[si]
    2979:	74 07                	je     0x2982
    297b:	23 c5                	and    ax,bp
    297d:	29 49 00             	sub    WORD PTR [bx+di+0x0],cx
    2980:	ff                   	(bad)
    2981:	ff a1 1e cd          	jmp    WORD PTR [bx+di-0x32e2]
    2985:	29 01                	sub    WORD PTR [bx+di],ax
    2987:	00 00                	add    BYTE PTR [bx+si],al
    2989:	00 00                	add    BYTE PTR [bx+si],al
    298b:	80 01 00             	add    BYTE PTR [bx+di],0x0
    298e:	00 00                	add    BYTE PTR [bx+si],al
    2990:	17                   	pop    ss
    2991:	00 0e 50 61          	add    BYTE PTR ds:0x6150,cl
    2995:	72 65                	jb     0x29fc
    2997:	6e                   	outs   dx,BYTE PTR ds:[si]
    2998:	74 53                	je     0x29ed
    299a:	68 6f 77             	push   0x776f
    299d:	48                   	dec    ax
    299e:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    29a3:	92                   	xchg   dx,ax
    29a4:	2e 40                	cs inc ax
    29a6:	00 ff                	add    bh,bh
    29a8:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    29ab:	ff                   	(bad)
    29ac:	ff 01                	inc    WORD PTR [bx+di]
    29ae:	00 00                	add    BYTE PTR [bx+si],al
    29b0:	00 00                	add    BYTE PTR [bx+si],al
    29b2:	80 00 00             	add    BYTE PTR [bx+si],0x0
    29b5:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
    29b9:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    29bc:	70 75                	jo     0x2a33
    29be:	70 4d                	jo     0x2a0d
    29c0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    29c2:	75 07                	jne    0x29cb
    29c4:	23 25                	and    sp,WORD PTR [di]
    29c6:	2a 48 00             	sub    cl,BYTE PTR [bx+si+0x0]
    29c9:	ff                   	(bad)
    29ca:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    29cd:	d1 29                	shr    WORD PTR [bx+di],1
    29cf:	23 1e 04 2a          	and    bx,WORD PTR ds:0x2a04
    29d3:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    29d7:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
    29db:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    29de:	6f                   	outs   dx,WORD PTR ds:[si]
    29df:	77 48                	ja     0x2a29
    29e1:	69 6e 74 b6 25       	imul   bp,WORD PTR [bp+0x74],0x25b6
    29e6:	ee                   	out    dx,al
    29e7:	29 dc                	sub    sp,bx
    29e9:	00 ff                	add    bh,bh
    29eb:	ff                   	(bad)
    29ec:	38 6e 73             	cmp    BYTE PTR [bp+0x73],ch
    29ef:	2c 01                	sub    al,0x1
    29f1:	00 00                	add    BYTE PTR [bx+si],al
    29f3:	00 00                	add    BYTE PTR [bx+si],al
    29f5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    29f8:	00 00                	add    BYTE PTR [bx+si],al
    29fa:	1a 00                	sbb    al,BYTE PTR [bx+si]
    29fc:	05 53 74             	add    ax,0x7453
    29ff:	61                   	popa
    2a00:	74 65                	je     0x2a67
    2a02:	52                   	push   dx
    2a03:	01 08                	add    WORD PTR [bx+si],cx
    2a05:	2a a6 63 0c          	sub    ah,BYTE PTR [bp+0xc63]
    2a09:	2a 60 64             	sub    ah,BYTE PTR [bx+si+0x64]
    2a0c:	2d 2a 01             	sub    ax,0x12a
    2a0f:	00 00                	add    BYTE PTR [bx+si],al
    2a11:	00 00                	add    BYTE PTR [bx+si],al
    2a13:	80 ff ff             	cmp    bh,0xff
    2a16:	ff                   	(bad)
    2a17:	ff 1b                	call   DWORD PTR [bp+di]
    2a19:	00 08                	add    BYTE PTR [bx+si],cl
    2a1b:	54                   	push   sp
    2a1c:	61                   	popa
    2a1d:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    2a20:	64 65 72 07          	fs gs jb 0x2a2b
    2a24:	23 45 2a             	and    ax,WORD PTR [di+0x2a]
    2a27:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    2a28:	00 ff                	add    bh,bh
    2a2a:	ff 88 64 4d          	dec    WORD PTR [bx+si+0x4d64]
    2a2e:	2a 01                	sub    al,BYTE PTR [bx+di]
    2a30:	00 00                	add    BYTE PTR [bx+si],al
    2a32:	00 00                	add    BYTE PTR [bx+si],al
    2a34:	80 01 00             	add    BYTE PTR [bx+di],0x0
    2a37:	00 00                	add    BYTE PTR [bx+si],al
    2a39:	09 00                	or     WORD PTR [bx+si],ax
    2a3b:	07                   	pop    es
    2a3c:	54                   	push   sp
    2a3d:	61                   	popa
    2a3e:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    2a41:	6f                   	outs   dx,WORD PTR ds:[si]
    2a42:	70 07                	jo     0x2a4b
    2a44:	23 13                	and    dx,WORD PTR [bp+di]
    2a46:	2c 29                	sub    al,0x29
    2a48:	00 ff                	add    bh,bh
    2a4a:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    2a4d:	85 2a                	test   WORD PTR [bp+si],bp
    2a4f:	01 00                	add    WORD PTR [bx+si],ax
    2a51:	00 00                	add    BYTE PTR [bx+si],al
    2a53:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2a57:	00 00                	add    BYTE PTR [bx+si],al
    2a59:	1c 00                	sbb    al,0x0
    2a5b:	07                   	pop    es
    2a5c:	56                   	push   si
    2a5d:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    2a62:	65 71 00             	gs jno 0x2a65
    2a65:	ed                   	in     ax,dx
    2a66:	2a 7a 00             	sub    bh,BYTE PTR [bp+si+0x0]
    2a69:	ff                   	(bad)
    2a6a:	ff                   	(bad)
    2a6b:	7a 00                	jp     0x2a6d
    2a6d:	ff                   	(bad)
    2a6e:	ff 01                	inc    WORD PTR [bx+di]
    2a70:	00 00                	add    BYTE PTR [bx+si],al
    2a72:	00 00                	add    BYTE PTR [bx+si],al
    2a74:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2a77:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    2a7b:	07                   	pop    es
    2a7c:	4f                   	dec    di
    2a7d:	6e                   	outs   dx,BYTE PTR ds:[si]
    2a7e:	43                   	inc    bx
    2a7f:	6c                   	ins    BYTE PTR es:[di],dx
    2a80:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    2a85:	a8 2a                	test   al,0x2a
    2a87:	62 00                	bound  ax,DWORD PTR [bx+si]
    2a89:	ff                   	(bad)
    2a8a:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    2a8d:	ff                   	(bad)
    2a8e:	ff 01                	inc    WORD PTR [bx+di]
    2a90:	00 00                	add    BYTE PTR [bx+si],al
    2a92:	00 00                	add    BYTE PTR [bx+si],al
    2a94:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2a97:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    2a9b:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2a9e:	44                   	inc    sp
    2a9f:	72 61                	jb     0x2b02
    2aa1:	67 44                	addr32 inc sp
    2aa3:	72 6f                	jb     0x2b14
    2aa5:	70 80                	jo     0x2a27
    2aa7:	02 cb                	add    cl,bl
    2aa9:	2a 6a 00             	sub    ch,BYTE PTR [bp+si+0x0]
    2aac:	ff                   	(bad)
    2aad:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    2ab0:	ff                   	(bad)
    2ab1:	ff 01                	inc    WORD PTR [bx+di]
    2ab3:	00 00                	add    BYTE PTR [bx+si],al
    2ab5:	00 00                	add    BYTE PTR [bx+si],al
    2ab7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2aba:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    2abe:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2ac1:	44                   	inc    sp
    2ac2:	72 61                	jb     0x2b25
    2ac4:	67 4f                	addr32 dec di
    2ac6:	76 65                	jbe    0x2b2d
    2ac8:	72 32                	jb     0x2afc
    2aca:	03 2c                	add    bp,WORD PTR [si]
    2acc:	2b 72 00             	sub    si,WORD PTR [bp+si+0x0]
    2acf:	ff                   	(bad)
    2ad0:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    2ad3:	ff                   	(bad)
    2ad4:	ff 01                	inc    WORD PTR [bx+di]
    2ad6:	00 00                	add    BYTE PTR [bx+si],al
    2ad8:	00 00                	add    BYTE PTR [bx+si],al
    2ada:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2add:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    2ae1:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    2ae4:	45                   	inc    bp
    2ae5:	6e                   	outs   dx,BYTE PTR ds:[si]
    2ae6:	64 44                	fs inc sp
    2ae8:	72 61                	jb     0x2b4b
    2aea:	67 71 00             	addr32 jno 0x2aed
    2aed:	0d 2b c8             	or     ax,0xc82b
    2af0:	00 ff                	add    bh,bh
    2af2:	ff c8                	dec    ax
    2af4:	00 ff                	add    bh,bh
    2af6:	ff 01                	inc    WORD PTR [bx+di]
    2af8:	00 00                	add    BYTE PTR [bx+si],al
    2afa:	00 00                	add    BYTE PTR [bx+si],al
    2afc:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2aff:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    2b03:	07                   	pop    es
    2b04:	4f                   	dec    di
    2b05:	6e                   	outs   dx,BYTE PTR ds:[si]
    2b06:	45                   	inc    bp
    2b07:	6e                   	outs   dx,BYTE PTR ds:[si]
    2b08:	74 65                	je     0x2b6f
    2b0a:	72 71                	jb     0x2b7d
    2b0c:	00 2b                	add    BYTE PTR [bp+di],ch
    2b0e:	2c d0                	sub    al,0xd0
    2b10:	00 ff                	add    bh,bh
    2b12:	ff d0                	call   ax
    2b14:	00 ff                	add    bh,bh
    2b16:	ff 01                	inc    WORD PTR [bx+di]
    2b18:	00 00                	add    BYTE PTR [bx+si],al
    2b1a:	00 00                	add    BYTE PTR [bx+si],al
    2b1c:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2b1f:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    2b23:	06                   	push   es
    2b24:	4f                   	dec    di
    2b25:	6e                   	outs   dx,BYTE PTR ds:[si]
    2b26:	45                   	inc    bp
    2b27:	78 69                	js     0x2b92
    2b29:	74 1a                	je     0x2b45
    2b2b:	02 4e 2b             	add    cl,BYTE PTR [bp+0x2b]
    2b2e:	b0 00                	mov    al,0x0
    2b30:	ff                   	(bad)
    2b31:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    2b35:	ff 01                	inc    WORD PTR [bx+di]
    2b37:	00 00                	add    BYTE PTR [bx+si],al
    2b39:	00 00                	add    BYTE PTR [bx+si],al
    2b3b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2b3e:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    2b42:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    2b45:	4b                   	dec    bx
    2b46:	65 79 44             	gs jns 0x2b8d
    2b49:	6f                   	outs   dx,WORD PTR ds:[si]
    2b4a:	77 6e                	ja     0x2bba
    2b4c:	54                   	push   sp
    2b4d:	02 71 2b             	add    dh,BYTE PTR [bx+di+0x2b]
    2b50:	b8 00 ff             	mov    ax,0xff00
    2b53:	ff                   	(bad)
    2b54:	b8 00 ff             	mov    ax,0xff00
    2b57:	ff 01                	inc    WORD PTR [bx+di]
    2b59:	00 00                	add    BYTE PTR [bx+si],al
    2b5b:	00 00                	add    BYTE PTR [bx+si],al
    2b5d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2b60:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    2b64:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2b67:	4b                   	dec    bx
    2b68:	65 79 50             	gs jns 0x2bbb
    2b6b:	72 65                	jb     0x2bd2
    2b6d:	73 73                	jae    0x2be2
    2b6f:	1a 02                	sbb    al,BYTE PTR [bp+si]
    2b71:	91                   	xchg   cx,ax
    2b72:	2b c0                	sub    ax,ax
    2b74:	00 ff                	add    bh,bh
    2b76:	ff c0                	inc    ax
    2b78:	00 ff                	add    bh,bh
    2b7a:	ff 01                	inc    WORD PTR [bx+di]
    2b7c:	00 00                	add    BYTE PTR [bx+si],al
    2b7e:	00 00                	add    BYTE PTR [bx+si],al
    2b80:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2b83:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    2b87:	07                   	pop    es
    2b88:	4f                   	dec    di
    2b89:	6e                   	outs   dx,BYTE PTR ds:[si]
    2b8a:	4b                   	dec    bx
    2b8b:	65 79 55             	gs jns 0x2be3
    2b8e:	70 71                	jo     0x2c01
    2b90:	01 b5 2b 4a          	add    WORD PTR [di+0x4a2b],si
    2b94:	00 ff                	add    bh,bh
    2b96:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    2b99:	ff                   	(bad)
    2b9a:	ff 01                	inc    WORD PTR [bx+di]
    2b9c:	00 00                	add    BYTE PTR [bx+si],al
    2b9e:	00 00                	add    BYTE PTR [bx+si],al
    2ba0:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2ba3:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    2ba7:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    2baa:	4d                   	dec    bp
    2bab:	6f                   	outs   dx,WORD PTR ds:[si]
    2bac:	75 73                	jne    0x2c21
    2bae:	65 44                	gs inc sp
    2bb0:	6f                   	outs   dx,WORD PTR ds:[si]
    2bb1:	77 6e                	ja     0x2c21
    2bb3:	ce                   	into
    2bb4:	01 d9                	add    cx,bx
    2bb6:	2b 52 00             	sub    dx,WORD PTR [bp+si+0x0]
    2bb9:	ff                   	(bad)
    2bba:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    2bbd:	ff                   	(bad)
    2bbe:	ff 01                	inc    WORD PTR [bx+di]
    2bc0:	00 00                	add    BYTE PTR [bx+si],al
    2bc2:	00 00                	add    BYTE PTR [bx+si],al
    2bc4:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2bc7:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    2bcb:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    2bce:	4d                   	dec    bp
    2bcf:	6f                   	outs   dx,WORD PTR ds:[si]
    2bd0:	75 73                	jne    0x2c45
    2bd2:	65 4d                	gs dec bp
    2bd4:	6f                   	outs   dx,WORD PTR ds:[si]
    2bd5:	76 65                	jbe    0x2c3c
    2bd7:	71 01                	jno    0x2bda
    2bd9:	6f                   	outs   dx,WORD PTR ds:[si]
    2bda:	2c 5a                	sub    al,0x5a
    2bdc:	00 ff                	add    bh,bh
    2bde:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    2be1:	ff                   	(bad)
    2be2:	ff 01                	inc    WORD PTR [bx+di]
    2be4:	00 00                	add    BYTE PTR [bx+si],al
    2be6:	00 00                	add    BYTE PTR [bx+si],al
    2be8:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2beb:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    2bef:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    2bf2:	4d                   	dec    bp
    2bf3:	6f                   	outs   dx,WORD PTR ds:[si]
    2bf4:	75 73                	jne    0x2c69
    2bf6:	65 55                	gs push bp
    2bf8:	70 bc                	jo     0x2bb6
    2bfa:	2c 00                	sub    al,0x0
    2bfc:	00 00                	add    BYTE PTR [bx+si],al
    2bfe:	00 a2 2c 95          	add    BYTE PTR [bp+si-0x6ad4],ah
    2c02:	2c dc                	sub    al,0xdc
    2c04:	00 98 20 ae          	add    BYTE PTR [bx+si-0x51e0],bl
    2c08:	2c fa                	sub    al,0xfa
    2c0a:	45                   	inc    bp
    2c0b:	7f 2c                	jg     0x2c39
    2c0d:	9a 1f 23 2d cb       	call   0xcb2d:0x231f
    2c12:	1f                   	pop    ds
    2c13:	0f 2c fc             	cvttps2pi mm7,xmm4
    2c16:	2e 5f                	cs pop di
    2c18:	2c cd                	sub    al,0xcd
    2c1a:	11 23                	adc    WORD PTR [bp+di],sp
    2c1c:	2c 3a                	sub    al,0x3a
    2c1e:	27                   	daa
    2c1f:	27                   	daa
    2c20:	2c fa                	sub    al,0xfa
    2c22:	10 e1                	adc    cl,ah
    2c24:	2c d6                	sub    al,0xd6
    2c26:	14 2f                	adc    al,0x2f
    2c28:	2c f4                	sub    al,0xf4
    2c2a:	4f                   	dec    di
    2c2b:	3b 2c                	cmp    bp,WORD PTR [si]
    2c2d:	32 16 57 2c          	xor    dl,BYTE PTR ds:0x2c57
    2c31:	ec                   	in     al,dx
    2c32:	30 8f 2c 51          	xor    BYTE PTR [bx+0x512c],cl
    2c36:	1b 03                	sbb    ax,WORD PTR [bp+di]
    2c38:	2d 38 50             	sub    ax,0x5038
    2c3b:	43                   	inc    bx
    2c3c:	2c 63                	sub    al,0x63
    2c3e:	31 17                	xor    WORD PTR [bx],dx
    2c40:	2c 21                	sub    al,0x21
    2c42:	50                   	push   ax
    2c43:	1b 2c                	sbb    bp,WORD PTR [si]
    2c45:	37                   	aaa
    2c46:	70 5b                	jo     0x2ca3
    2c48:	2c d9                	sub    al,0xd9
    2c4a:	62 4f 2c             	bound  cx,DWORD PTR [bx+0x2c]
    2c4d:	06                   	push   es
    2c4e:	63 53 2c             	arpl   WORD PTR [bp+di+0x2c],dx
    2c51:	8f                   	(bad)
    2c52:	60                   	pusha
    2c53:	8b 2c                	mov    bp,WORD PTR [si]
    2c55:	3a 1c                	cmp    bl,BYTE PTR [si]
    2c57:	37                   	aaa
    2c58:	2c 35                	sub    al,0x35
    2c5a:	69 07 2c 08          	imul   ax,WORD PTR [bx],0x82c
    2c5e:	61                   	popa
    2c5f:	63 2c                	arpl   WORD PTR [si],bp
    2c61:	5c                   	pop    sp
    2c62:	61                   	popa
    2c63:	67 2c 62             	addr32 sub al,0x62
    2c66:	5c                   	pop    sp
    2c67:	93                   	xchg   bx,ax
    2c68:	2c 3a                	sub    al,0x3a
    2c6a:	61                   	popa
    2c6b:	1f                   	pop    ds
    2c6c:	2c 72                	sub    al,0x72
    2c6e:	3f                   	aas
    2c6f:	77 2c                	ja     0x2c9d
    2c71:	b9 71 7b             	mov    cx,0x7b71
    2c74:	2c 17                	sub    al,0x17
    2c76:	3e 0b 2c             	or     bp,WORD PTR ds:[si]
    2c79:	21 72 47             	and    WORD PTR [bp+si+0x47],si
    2c7c:	2c ed                	sub    al,0xed
    2c7e:	3e 83 2c 77          	sub    WORD PTR ds:[si],0x77
    2c82:	3e 87 2c             	xchg   WORD PTR ds:[si],bp
    2c85:	c2 35 4b             	ret    0x4b35
    2c88:	2c 1c                	sub    al,0x1c
    2c8a:	48                   	dec    ax
    2c8b:	33 2c                	xor    bp,WORD PTR [si]
    2c8d:	ae                   	scas   al,BYTE PTR es:[di]
    2c8e:	5f                   	pop    di
    2c8f:	3f                   	aas
    2c90:	2c 35                	sub    al,0x35
    2c92:	62 6b 2c             	bound  bp,DWORD PTR [bp+di+0x2c]
    2c95:	0c 54                	or     al,0x54
    2c97:	52                   	push   dx
    2c98:	61                   	popa
    2c99:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
    2c9f:	74 6f                	je     0x2d10
    2ca1:	6e                   	outs   dx,BYTE PTR ds:[si]
    2ca2:	04 00                	add    al,0x0
    2ca4:	07                   	pop    es
    2ca5:	00 10                	add    BYTE PTR [bx+si],dl
    2ca7:	0f 06                	clts
    2ca9:	0f 11 21             	movups XMMWORD PTR [bx+di],xmm4
    2cac:	78 72                	js     0x2d20
    2cae:	b2 2c                	mov    dl,0x2c
    2cb0:	b2 72                	mov    dl,0x72
    2cb2:	b6 2c                	mov    dh,0x2c
    2cb4:	c3                   	ret
    2cb5:	72 ba                	jb     0x2c71
    2cb7:	2c 2f                	sub    al,0x2f
    2cb9:	73 cc                	jae    0x2c87
    2cbb:	2c 07                	sub    al,0x7
    2cbd:	0c 54                	or     al,0x54
    2cbf:	52                   	push   dx
    2cc0:	61                   	popa
    2cc1:	64 69 6f 42 75 74    	imul   bp,WORD PTR fs:[bx+0x42],0x7475
    2cc7:	74 6f                	je     0x2d38
    2cc9:	6e                   	outs   dx,BYTE PTR ds:[si]
    2cca:	19 2c                	sbb    WORD PTR [si],bp
    2ccc:	d0 2c                	shr    BYTE PTR [si],1
    2cce:	23 21                	and    sp,WORD PTR [bx+di]
    2cd0:	e9 2c 28             	jmp    0x54ff
    2cd3:	00 08                	add    BYTE PTR [bx+si],cl
    2cd5:	53                   	push   bx
    2cd6:	74 64                	je     0x2d3c
    2cd8:	43                   	inc    bx
    2cd9:	74 72                	je     0x2d4d
    2cdb:	6c                   	ins    BYTE PTR es:[di],dx
    2cdc:	73 1f                	jae    0x2cfd
    2cde:	00 41 00             	add    BYTE PTR [bx+di+0x0],al
    2ce1:	36 2f                	ss das
    2ce3:	da 00                	fiadd  DWORD PTR [bx+si]
    2ce5:	ff                   	(bad)
    2ce6:	ff 99 70 2b          	call   DWORD PTR [bx+di+0x2b70]
    2cea:	2d 01 00             	sub    ax,0x1
    2ced:	00 00                	add    BYTE PTR [bx+si],al
    2cef:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2cf3:	00 00                	add    BYTE PTR [bx+si],al
    2cf5:	09 00                	or     WORD PTR [bx+si],ax
    2cf7:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
    2cfa:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
    2cff:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d00:	74 66                	je     0x2d68
    2d02:	01 07                	add    WORD PTR [bx],ax
    2d04:	2d 53 1d             	sub    ax,0x1d53
    2d07:	0b 2d                	or     bp,WORD PTR [di]
    2d09:	8c 1d                	mov    WORD PTR [di],ds
    2d0b:	4b                   	dec    bx
    2d0c:	2d 01 00             	sub    ax,0x1
    2d0f:	00 00                	add    BYTE PTR [bx+si],al
    2d11:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2d15:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
    2d19:	07                   	pop    es
    2d1a:	43                   	inc    bx
    2d1b:	61                   	popa
    2d1c:	70 74                	jo     0x2d92
    2d1e:	69 6f 6e 07 23       	imul   bp,WORD PTR [bx+0x6e],0x2307
    2d23:	61                   	popa
    2d24:	2d db 00             	sub    ax,0xdb
    2d27:	ff                   	(bad)
    2d28:	ff 4c 71             	dec    WORD PTR [si+0x71]
    2d2b:	07                   	pop    es
    2d2c:	31 01                	xor    WORD PTR [bx+di],ax
    2d2e:	00 00                	add    BYTE PTR [bx+si],al
    2d30:	00 00                	add    BYTE PTR [bx+si],al
    2d32:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2d35:	00 00                	add    BYTE PTR [bx+si],al
    2d37:	0b 00                	or     ax,WORD PTR [bx+si]
    2d39:	07                   	pop    es
    2d3a:	43                   	inc    bx
    2d3b:	68 65 63             	push   0x6365
    2d3e:	6b 65 64 02          	imul   sp,WORD PTR [di+0x64],0x2
    2d42:	00 e3                	add    bl,ah
    2d44:	2d 38 00             	sub    ax,0x38
    2d47:	ff                   	(bad)
    2d48:	ff d5                	call   bp
    2d4a:	1e                   	push   ds
    2d4b:	4f                   	dec    di
    2d4c:	2d 17 1f             	sub    ax,0x1f17
    2d4f:	69 2d 00 80          	imul   bp,WORD PTR [di],0x8000
    2d53:	fa                   	cli
    2d54:	ff                   	(bad)
    2d55:	ff                   	(bad)
    2d56:	ff 0c                	dec    WORD PTR [si]
    2d58:	00 05                	add    BYTE PTR [di],al
    2d5a:	43                   	inc    bx
    2d5b:	6f                   	outs   dx,WORD PTR ds:[si]
    2d5c:	6c                   	ins    BYTE PTR es:[di],dx
    2d5d:	6f                   	outs   dx,WORD PTR ds:[si]
    2d5e:	72 07                	jb     0x2d67
    2d60:	23 c3                	and    ax,bx
    2d62:	2d a5 00             	sub    ax,0xa5
    2d65:	ff                   	(bad)
    2d66:	ff 22                	jmp    WORD PTR [bp+si]
    2d68:	63 6d 2d             	arpl   WORD PTR [di+0x2d],bp
    2d6b:	54                   	push   sp
    2d6c:	63 7f 2d             	arpl   WORD PTR [bx+0x2d],di
    2d6f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2d73:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
    2d77:	05 43 74             	add    ax,0x7443
    2d7a:	6c                   	ins    BYTE PTR es:[di],dx
    2d7b:	33 44 64             	xor    ax,WORD PTR [si+0x64]
    2d7e:	00 a2 2d 3e          	add    BYTE PTR [bp+si+0x3e2d],ah
    2d82:	00 ff                	add    bh,bh
    2d84:	ff                   	(bad)
    2d85:	3e 00 ff             	ds add bh,bh
    2d88:	ff 01                	inc    WORD PTR [bx+di]
    2d8a:	00 00                	add    BYTE PTR [bx+si],al
    2d8c:	00 00                	add    BYTE PTR [bx+si],al
    2d8e:	80 f4 ff             	xor    ah,0xff
    2d91:	ff                   	(bad)
    2d92:	ff 0e 00 0a          	dec    WORD PTR ds:0xa00
    2d96:	44                   	inc    sp
    2d97:	72 61                	jb     0x2dfa
    2d99:	67 43                	addr32 inc bx
    2d9b:	75 72                	jne    0x2e0f
    2d9d:	73 6f                	jae    0x2e0e
    2d9f:	72 25                	jb     0x2dc6
    2da1:	01 cb                	add    bx,cx
    2da3:	2d 2e 00             	sub    ax,0x2e
    2da6:	ff                   	(bad)
    2da7:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    2dab:	ff 01                	inc    WORD PTR [bx+di]
    2dad:	00 00                	add    BYTE PTR [bx+si],al
    2daf:	00 00                	add    BYTE PTR [bx+si],al
    2db1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2db4:	00 00                	add    BYTE PTR [bx+si],al
    2db6:	0f 00 08             	str    WORD PTR [bx+si]
    2db9:	44                   	inc    sp
    2dba:	72 61                	jb     0x2e1d
    2dbc:	67 4d                	addr32 dec bp
    2dbe:	6f                   	outs   dx,WORD PTR ds:[si]
    2dbf:	64 65 07             	fs gs pop es
    2dc2:	23 00                	and    ax,WORD PTR [bx+si]
    2dc4:	2e 2a 00             	sub    al,BYTE PTR cs:[bx+si]
    2dc7:	ff                   	(bad)
    2dc8:	ff                   	(bad)
    2dc9:	b8 1c eb             	mov    ax,0xeb1c
    2dcc:	2d 01 00             	sub    ax,0x1
    2dcf:	00 00                	add    BYTE PTR [bx+si],al
    2dd1:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2dd5:	00 00                	add    BYTE PTR [bx+si],al
    2dd7:	10 00                	adc    BYTE PTR [bx+si],al
    2dd9:	07                   	pop    es
    2dda:	45                   	inc    bp
    2ddb:	6e                   	outs   dx,BYTE PTR ds:[si]
    2ddc:	61                   	popa
    2ddd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    2de0:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
    2de3:	6d                   	ins    WORD PTR es:[di],dx
    2de4:	33 34                	xor    si,WORD PTR [si]
    2de6:	00 ff                	add    bh,bh
    2de8:	ff                   	jmp    (bad)
    2de9:	eb 1d                	jmp    0x2e08
    2deb:	ef                   	out    dx,ax
    2dec:	2d 08 1e             	sub    ax,0x1e08
    2def:	08 2e 00 80          	or     BYTE PTR ds:0x8000,ch
    2df3:	00 00                	add    BYTE PTR [bx+si],al
    2df5:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
    2df9:	04 46                	add    al,0x46
    2dfb:	6f                   	outs   dx,WORD PTR ds:[si]
    2dfc:	6e                   	outs   dx,BYTE PTR ds:[si]
    2dfd:	74 07                	je     0x2e06
    2dff:	23 24                	and    sp,WORD PTR [si]
    2e01:	2e 2c 00             	cs sub al,0x0
    2e04:	ff                   	(bad)
    2e05:	ff 32                	push   WORD PTR [bp+si]
    2e07:	1f                   	pop    ds
    2e08:	2c 2e                	sub    al,0x2e
    2e0a:	01 00                	add    WORD PTR [bx+si],ax
    2e0c:	00 00                	add    BYTE PTR [bx+si],al
    2e0e:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2e12:	00 00                	add    BYTE PTR [bx+si],al
    2e14:	12 00                	adc    al,BYTE PTR [bx+si]
    2e16:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    2e19:	72 65                	jb     0x2e80
    2e1b:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e1c:	74 43                	je     0x2e61
    2e1e:	6f                   	outs   dx,WORD PTR ds:[si]
    2e1f:	6c                   	ins    BYTE PTR es:[di],dx
    2e20:	6f                   	outs   dx,WORD PTR ds:[si]
    2e21:	72 07                	jb     0x2e2a
    2e23:	23 48 2e             	and    cx,WORD PTR [bx+si+0x2e]
    2e26:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    2e27:	00 ff                	add    bh,bh
    2e29:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    2e2c:	50                   	push   ax
    2e2d:	2e 01 00             	add    WORD PTR cs:[bx+si],ax
    2e30:	00 00                	add    BYTE PTR [bx+si],al
    2e32:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2e36:	00 00                	add    BYTE PTR [bx+si],al
    2e38:	13 00                	adc    ax,WORD PTR [bx+si]
    2e3a:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    2e3d:	72 65                	jb     0x2ea4
    2e3f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e40:	74 43                	je     0x2e85
    2e42:	74 6c                	je     0x2eb0
    2e44:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    2e47:	23 6b 2e             	and    bp,WORD PTR [bp+di+0x2e]
    2e4a:	2b 00                	sub    ax,WORD PTR [bx+si]
    2e4c:	ff                   	(bad)
    2e4d:	ff                   	(bad)
    2e4e:	3e 1e                	ds push ds
    2e50:	73 2e                	jae    0x2e80
    2e52:	01 00                	add    WORD PTR [bx+si],ax
    2e54:	00 00                	add    BYTE PTR [bx+si],al
    2e56:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2e5a:	00 00                	add    BYTE PTR [bx+si],al
    2e5c:	14 00                	adc    al,0x0
    2e5e:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
    2e61:	72 65                	jb     0x2ec8
    2e63:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e64:	74 46                	je     0x2eac
    2e66:	6f                   	outs   dx,WORD PTR ds:[si]
    2e67:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e68:	74 07                	je     0x2e71
    2e6a:	23 b4 2e 49          	and    si,WORD PTR [si+0x492e]
    2e6e:	00 ff                	add    bh,bh
    2e70:	ff a1 1e bc          	jmp    WORD PTR [bx+di-0x43e2]
    2e74:	2e 01 00             	add    WORD PTR cs:[bx+si],ax
    2e77:	00 00                	add    BYTE PTR [bx+si],al
    2e79:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2e7d:	00 00                	add    BYTE PTR [bx+si],al
    2e7f:	15 00 0e             	adc    ax,0xe00
    2e82:	50                   	push   ax
    2e83:	61                   	popa
    2e84:	72 65                	jb     0x2eeb
    2e86:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e87:	74 53                	je     0x2edc
    2e89:	68 6f 77             	push   0x776f
    2e8c:	48                   	dec    ax
    2e8d:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    2e92:	8f                   	(bad)
    2e93:	35 40 00             	xor    ax,0x40
    2e96:	ff                   	(bad)
    2e97:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    2e9a:	ff                   	(bad)
    2e9b:	ff 01                	inc    WORD PTR [bx+di]
    2e9d:	00 00                	add    BYTE PTR [bx+si],al
    2e9f:	00 00                	add    BYTE PTR [bx+si],al
    2ea1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2ea4:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
    2ea8:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    2eab:	70 75                	jo     0x2f22
    2ead:	70 4d                	jo     0x2efc
    2eaf:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2eb1:	75 07                	jne    0x2eba
    2eb3:	23 f6                	and    si,si
    2eb5:	2e 48                	cs dec ax
    2eb7:	00 ff                	add    bh,bh
    2eb9:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    2ebc:	c0 2e 23 1e d5       	shr    BYTE PTR ds:0x1e23,0xd5
    2ec1:	2e 00 80 00 00       	add    BYTE PTR cs:[bx+si+0x0],al
    2ec6:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
    2eca:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    2ecd:	6f                   	outs   dx,WORD PTR ds:[si]
    2ece:	77 48                	ja     0x2f18
    2ed0:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
    2ed5:	d9 2e a6 63          	fldcw  WORD PTR ds:0x63a6
    2ed9:	dd 2e 60 64          	(bad)  ds:0x6460
    2edd:	fe                   	(bad)
    2ede:	2e 01 00             	add    WORD PTR cs:[bx+si],ax
    2ee1:	00 00                	add    BYTE PTR [bx+si],al
    2ee3:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2ee7:	ff                   	(bad)
    2ee8:	ff 18                	call   DWORD PTR [bx+si]
    2eea:	00 08                	add    BYTE PTR [bx+si],cl
    2eec:	54                   	push   sp
    2eed:	61                   	popa
    2eee:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    2ef1:	64 65 72 07          	fs gs jb 0x2efc
    2ef5:	23 16 2f a4          	and    dx,WORD PTR ds:0xa42f
    2ef9:	00 ff                	add    bh,bh
    2efb:	ff 88 64 1e          	dec    WORD PTR [bx+si+0x1e64]
    2eff:	2f                   	das
    2f00:	01 00                	add    WORD PTR [bx+si],ax
    2f02:	00 00                	add    BYTE PTR [bx+si],al
    2f04:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2f08:	00 00                	add    BYTE PTR [bx+si],al
    2f0a:	19 00                	sbb    WORD PTR [bx+si],ax
    2f0c:	07                   	pop    es
    2f0d:	54                   	push   sp
    2f0e:	61                   	popa
    2f0f:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    2f12:	6f                   	outs   dx,WORD PTR ds:[si]
    2f13:	70 07                	jo     0x2f1c
    2f15:	23 53 31             	and    dx,WORD PTR [bp+di+0x31]
    2f18:	29 00                	sub    WORD PTR [bx+si],ax
    2f1a:	ff                   	(bad)
    2f1b:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    2f1e:	79 2f                	jns    0x2f4f
    2f20:	01 00                	add    WORD PTR [bx+si],ax
    2f22:	00 00                	add    BYTE PTR [bx+si],al
    2f24:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    2f28:	00 00                	add    BYTE PTR [bx+si],al
    2f2a:	1a 00                	sbb    al,BYTE PTR [bx+si]
    2f2c:	07                   	pop    es
    2f2d:	56                   	push   si
    2f2e:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    2f33:	65 71 00             	gs jno 0x2f36
    2f36:	56                   	push   si
    2f37:	2f                   	das
    2f38:	7a 00                	jp     0x2f3a
    2f3a:	ff                   	(bad)
    2f3b:	ff                   	(bad)
    2f3c:	7a 00                	jp     0x2f3e
    2f3e:	ff                   	(bad)
    2f3f:	ff 01                	inc    WORD PTR [bx+di]
    2f41:	00 00                	add    BYTE PTR [bx+si],al
    2f43:	00 00                	add    BYTE PTR [bx+si],al
    2f45:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2f48:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
    2f4c:	07                   	pop    es
    2f4d:	4f                   	dec    di
    2f4e:	6e                   	outs   dx,BYTE PTR ds:[si]
    2f4f:	43                   	inc    bx
    2f50:	6c                   	ins    BYTE PTR es:[di],dx
    2f51:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    2f56:	e1 2f                	loope  0x2f87
    2f58:	82 00 ff             	add    BYTE PTR [bx+si],0xff
    2f5b:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    2f5f:	ff 01                	inc    WORD PTR [bx+di]
    2f61:	00 00                	add    BYTE PTR [bx+si],al
    2f63:	00 00                	add    BYTE PTR [bx+si],al
    2f65:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2f68:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    2f6c:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2f6f:	44                   	inc    sp
    2f70:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    2f73:	6c                   	ins    BYTE PTR es:[di],dx
    2f74:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    2f79:	9c                   	pushf
    2f7a:	2f                   	das
    2f7b:	62 00                	bound  ax,DWORD PTR [bx+si]
    2f7d:	ff                   	(bad)
    2f7e:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    2f81:	ff                   	(bad)
    2f82:	ff 01                	inc    WORD PTR [bx+di]
    2f84:	00 00                	add    BYTE PTR [bx+si],al
    2f86:	00 00                	add    BYTE PTR [bx+si],al
    2f88:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2f8b:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    2f8f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2f92:	44                   	inc    sp
    2f93:	72 61                	jb     0x2ff6
    2f95:	67 44                	addr32 inc sp
    2f97:	72 6f                	jb     0x3008
    2f99:	70 80                	jo     0x2f1b
    2f9b:	02 bf 2f 6a          	add    bh,BYTE PTR [bx+0x6a2f]
    2f9f:	00 ff                	add    bh,bh
    2fa1:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    2fa4:	ff                   	(bad)
    2fa5:	ff 01                	inc    WORD PTR [bx+di]
    2fa7:	00 00                	add    BYTE PTR [bx+si],al
    2fa9:	00 00                	add    BYTE PTR [bx+si],al
    2fab:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2fae:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    2fb2:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    2fb5:	44                   	inc    sp
    2fb6:	72 61                	jb     0x3019
    2fb8:	67 4f                	addr32 dec di
    2fba:	76 65                	jbe    0x3021
    2fbc:	72 32                	jb     0x2ff0
    2fbe:	03 20                	add    sp,WORD PTR [bx+si]
    2fc0:	30 72 00             	xor    BYTE PTR [bp+si+0x0],dh
    2fc3:	ff                   	(bad)
    2fc4:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    2fc7:	ff                   	(bad)
    2fc8:	ff 01                	inc    WORD PTR [bx+di]
    2fca:	00 00                	add    BYTE PTR [bx+si],al
    2fcc:	00 00                	add    BYTE PTR [bx+si],al
    2fce:	80 00 00             	add    BYTE PTR [bx+si],0x0
    2fd1:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    2fd5:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    2fd8:	45                   	inc    bp
    2fd9:	6e                   	outs   dx,BYTE PTR ds:[si]
    2fda:	64 44                	fs inc sp
    2fdc:	72 61                	jb     0x303f
    2fde:	67 71 00             	addr32 jno 0x2fe1
    2fe1:	01 30                	add    WORD PTR [bx+si],si
    2fe3:	c8 00 ff ff          	enter  0xff00,0xff
    2fe7:	c8 00 ff ff          	enter  0xff00,0xff
    2feb:	01 00                	add    WORD PTR [bx+si],ax
    2fed:	00 00                	add    BYTE PTR [bx+si],al
    2fef:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    2ff3:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    2ff7:	07                   	pop    es
    2ff8:	4f                   	dec    di
    2ff9:	6e                   	outs   dx,BYTE PTR ds:[si]
    2ffa:	45                   	inc    bp
    2ffb:	6e                   	outs   dx,BYTE PTR ds:[si]
    2ffc:	74 65                	je     0x3063
    2ffe:	72 71                	jb     0x3071
    3000:	00 6b 31             	add    BYTE PTR [bp+di+0x31],ch
    3003:	d0 00                	rol    BYTE PTR [bx+si],1
    3005:	ff                   	(bad)
    3006:	ff d0                	call   ax
    3008:	00 ff                	add    bh,bh
    300a:	ff 01                	inc    WORD PTR [bx+di]
    300c:	00 00                	add    BYTE PTR [bx+si],al
    300e:	00 00                	add    BYTE PTR [bx+si],al
    3010:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3013:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    3017:	06                   	push   es
    3018:	4f                   	dec    di
    3019:	6e                   	outs   dx,BYTE PTR ds:[si]
    301a:	45                   	inc    bp
    301b:	78 69                	js     0x3086
    301d:	74 1a                	je     0x3039
    301f:	02 42 30             	add    al,BYTE PTR [bp+si+0x30]
    3022:	b0 00                	mov    al,0x0
    3024:	ff                   	(bad)
    3025:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    3029:	ff 01                	inc    WORD PTR [bx+di]
    302b:	00 00                	add    BYTE PTR [bx+si],al
    302d:	00 00                	add    BYTE PTR [bx+si],al
    302f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3032:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    3036:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    3039:	4b                   	dec    bx
    303a:	65 79 44             	gs jns 0x3081
    303d:	6f                   	outs   dx,WORD PTR ds:[si]
    303e:	77 6e                	ja     0x30ae
    3040:	54                   	push   sp
    3041:	02 65 30             	add    ah,BYTE PTR [di+0x30]
    3044:	b8 00 ff             	mov    ax,0xff00
    3047:	ff                   	(bad)
    3048:	b8 00 ff             	mov    ax,0xff00
    304b:	ff 01                	inc    WORD PTR [bx+di]
    304d:	00 00                	add    BYTE PTR [bx+si],al
    304f:	00 00                	add    BYTE PTR [bx+si],al
    3051:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3054:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    3058:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    305b:	4b                   	dec    bx
    305c:	65 79 50             	gs jns 0x30af
    305f:	72 65                	jb     0x30c6
    3061:	73 73                	jae    0x30d6
    3063:	1a 02                	sbb    al,BYTE PTR [bp+si]
    3065:	85 30                	test   WORD PTR [bx+si],si
    3067:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
    306a:	ff c0                	inc    ax
    306c:	00 ff                	add    bh,bh
    306e:	ff 01                	inc    WORD PTR [bx+di]
    3070:	00 00                	add    BYTE PTR [bx+si],al
    3072:	00 00                	add    BYTE PTR [bx+si],al
    3074:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3077:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    307b:	07                   	pop    es
    307c:	4f                   	dec    di
    307d:	6e                   	outs   dx,BYTE PTR ds:[si]
    307e:	4b                   	dec    bx
    307f:	65 79 55             	gs jns 0x30d7
    3082:	70 71                	jo     0x30f5
    3084:	01 a9 30 4a          	add    WORD PTR [bx+di+0x4a30],bp
    3088:	00 ff                	add    bh,bh
    308a:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    308d:	ff                   	(bad)
    308e:	ff 01                	inc    WORD PTR [bx+di]
    3090:	00 00                	add    BYTE PTR [bx+si],al
    3092:	00 00                	add    BYTE PTR [bx+si],al
    3094:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3097:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    309b:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    309e:	4d                   	dec    bp
    309f:	6f                   	outs   dx,WORD PTR ds:[si]
    30a0:	75 73                	jne    0x3115
    30a2:	65 44                	gs inc sp
    30a4:	6f                   	outs   dx,WORD PTR ds:[si]
    30a5:	77 6e                	ja     0x3115
    30a7:	ce                   	into
    30a8:	01 cd                	add    bp,cx
    30aa:	30 52 00             	xor    BYTE PTR [bp+si+0x0],dl
    30ad:	ff                   	(bad)
    30ae:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    30b1:	ff                   	(bad)
    30b2:	ff 01                	inc    WORD PTR [bx+di]
    30b4:	00 00                	add    BYTE PTR [bx+si],al
    30b6:	00 00                	add    BYTE PTR [bx+si],al
    30b8:	80 00 00             	add    BYTE PTR [bx+si],0x0
    30bb:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    30bf:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    30c2:	4d                   	dec    bp
    30c3:	6f                   	outs   dx,WORD PTR ds:[si]
    30c4:	75 73                	jne    0x3139
    30c6:	65 4d                	gs dec bp
    30c8:	6f                   	outs   dx,WORD PTR ds:[si]
    30c9:	76 65                	jbe    0x3130
    30cb:	71 01                	jno    0x30ce
    30cd:	af                   	scas   ax,WORD PTR es:[di]
    30ce:	31 5a 00             	xor    WORD PTR [bp+si+0x0],bx
    30d1:	ff                   	(bad)
    30d2:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    30d5:	ff                   	(bad)
    30d6:	ff 01                	inc    WORD PTR [bx+di]
    30d8:	00 00                	add    BYTE PTR [bx+si],al
    30da:	00 00                	add    BYTE PTR [bx+si],al
    30dc:	80 00 00             	add    BYTE PTR [bx+si],0x0
    30df:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    30e3:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    30e6:	4d                   	dec    bp
    30e7:	6f                   	outs   dx,WORD PTR ds:[si]
    30e8:	75 73                	jne    0x315d
    30ea:	65 55                	gs push bp
    30ec:	70 03                	jo     0x30f1
    30ee:	0d 54 4c             	or     ax,0x4c54
    30f1:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    30f6:	78 53                	js     0x314b
    30f8:	74 79                	je     0x3173
    30fa:	6c                   	ins    BYTE PTR es:[di],dx
    30fb:	65 00 00             	add    BYTE PTR gs:[bx+si],al
    30fe:	00 00                	add    BYTE PTR [bx+si],al
    3100:	00 02                	add    BYTE PTR [bp+si],al
    3102:	00 00                	add    BYTE PTR [bx+si],al
    3104:	00 ed                	add    ch,ch
    3106:	30 b3 31 0a          	xor    BYTE PTR [bp+di+0xa31],dh
    310a:	6c                   	ins    BYTE PTR es:[di],dx
    310b:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    310e:	61                   	popa
    310f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3110:	64 61                	fs popa
    3112:	72 64                	jb     0x3178
    3114:	10 6c 62             	adc    BYTE PTR [si+0x62],ch
    3117:	4f                   	dec    di
    3118:	77 6e                	ja     0x3188
    311a:	65 72 44             	gs jb  0x3161
    311d:	72 61                	jb     0x3180
    311f:	77 46                	ja     0x3167
    3121:	69 78 65 64 13       	imul   di,WORD PTR [bx+si+0x65],0x1364
    3126:	6c                   	ins    BYTE PTR es:[di],dx
    3127:	62 4f 77             	bound  cx,DWORD PTR [bx+0x77]
    312a:	6e                   	outs   dx,BYTE PTR ds:[si]
    312b:	65 72 44             	gs jb  0x3172
    312e:	72 61                	jb     0x3191
    3130:	77 56                	ja     0x3188
    3132:	61                   	popa
    3133:	72 69                	jb     0x319e
    3135:	61                   	popa
    3136:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    3139:	18 32                	sbb    BYTE PTR [bp+si],dh
    313b:	00 00                	add    BYTE PTR [bx+si],al
    313d:	00 00                	add    BYTE PTR [bx+si],al
    313f:	ec                   	in     al,dx
    3140:	31 dd                	xor    bp,bx
    3142:	31 02                	xor    WORD PTR [bp+si],ax
    3144:	01 c1                	add    cx,ax
    3146:	05 2e 32             	add    ax,0x322e
    3149:	fa                   	cli
    314a:	45                   	inc    bp
    314b:	bf 31 9a             	mov    di,0x9a31
    314e:	1f                   	pop    ds
    314f:	3f                   	aas
    3150:	32 cb                	xor    cl,bl
    3152:	1f                   	pop    ds
    3153:	4f                   	dec    di
    3154:	31 c5                	xor    bp,ax
    3156:	76 fe                	jbe    0x3156
    3158:	31 cd                	xor    bp,cx
    315a:	11 63 31             	adc    WORD PTR [bp+di+0x31],sp
    315d:	3a 27                	cmp    ah,BYTE PTR [bx]
    315f:	67 31 fa             	addr32 xor dx,di
    3162:	10 8f 32 d6          	adc    BYTE PTR [bx-0x29ce],cl
    3166:	14 6f                	adc    al,0x6f
    3168:	31 f4                	xor    sp,si
    316a:	4f                   	dec    di
    316b:	7b 31                	jnp    0x319e
    316d:	32 16 97 31          	xor    dl,BYTE PTR ds:0x3197
    3171:	ec                   	in     al,dx
    3172:	30 cf                	xor    bh,cl
    3174:	31 51 1b             	xor    WORD PTR [bx+di+0x1b],dx
    3177:	47                   	inc    di
    3178:	31 38                	xor    WORD PTR [bx+si],di
    317a:	50                   	push   ax
    317b:	83 31 63             	xor    WORD PTR [bx+di],0x63
    317e:	31 9f 31 21          	xor    WORD PTR [bx+0x2131],bx
    3182:	50                   	push   ax
    3183:	5b                   	pop    bx
    3184:	31 dc                	xor    sp,bx
    3186:	75 57                	jne    0x31df
    3188:	31 d9                	xor    cx,bx
    318a:	62 8f 31 06          	bound  cx,DWORD PTR [bx+0x631]
    318e:	63 93 31 8f          	arpl   WORD PTR [bp+di-0x70cf],dx
    3192:	60                   	pusha
    3193:	cb                   	retf
    3194:	31 3a                	xor    WORD PTR [bp+si],di
    3196:	1c 77                	sbb    al,0x77
    3198:	31 f1                	xor    cx,si
    319a:	7c d7                	jl     0x3173
    319c:	31 08                	xor    WORD PTR [bx+si],cx
    319e:	61                   	popa
    319f:	a3 31 5c             	mov    ds:0x5c31,ax
    31a2:	61                   	popa
    31a3:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    31a4:	31 62 5c             	xor    WORD PTR [bp+si+0x5c],sp
    31a7:	d3 31                	shl    WORD PTR [bx+di],cl
    31a9:	3a 61 5f             	cmp    ah,BYTE PTR [bx+di+0x5f]
    31ac:	31 72 3f             	xor    WORD PTR [bp+si+0x3f],si
    31af:	b7 31                	mov    bh,0x31
    31b1:	bb 7a bb             	mov    bx,0xbb7a
    31b4:	31 17                	xor    WORD PTR [bx],dx
    31b6:	3e 4b                	ds dec bx
    31b8:	31 f7                	xor    di,si
    31ba:	7b c3                	jnp    0x317f
    31bc:	31 ed                	xor    bp,bp
    31be:	3e c7                	ds (bad)
    31c0:	31 75 7c             	xor    WORD PTR [di+0x7c],si
    31c3:	9b                   	fwait
    31c4:	31 c2                	xor    dx,ax
    31c6:	35 8b 31             	xor    ax,0x318b
    31c9:	1c 48                	sbb    al,0x48
    31cb:	73 31                	jae    0x31fe
    31cd:	ae                   	scas   al,BYTE PTR es:[di]
    31ce:	5f                   	pop    di
    31cf:	7f 31                	jg     0x3202
    31d1:	35 62 ab             	xor    ax,0xab62
    31d4:	31 c5                	xor    bp,ax
    31d6:	80 db 31             	sbb    bl,0x31
    31d9:	6f                   	outs   dx,WORD PTR ds:[si]
    31da:	81 87 31 0e 54 43    	add    WORD PTR [bx+0xe31],0x4354
    31e0:	75 73                	jne    0x3255
    31e2:	74 6f                	je     0x3253
    31e4:	6d                   	ins    WORD PTR es:[di],dx
    31e5:	4c                   	dec    sp
    31e6:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    31eb:	78 07                	js     0x31f4
    31ed:	00 0f                	add    BYTE PTR [bx],cl
    31ef:	00 05                	add    BYTE PTR [di],al
    31f1:	00 11                	add    BYTE PTR [bx+di],dl
    31f3:	21 2b                	and    WORD PTR [bp+di],bp
    31f5:	20 2c                	and    BYTE PTR [si],ch
    31f7:	20 01                	and    BYTE PTR [bx+di],al
    31f9:	02 fc                	add    bh,ah
    31fb:	ff 1c                	call   DWORD PTR [si]
    31fd:	80 02 32             	add    BYTE PTR [bp+si],0x32
    3200:	43                   	inc    bx
    3201:	80 06 32 1b 7e       	add    BYTE PTR ds:0x1b32,0x7e
    3206:	0a 32                	or     dh,BYTE PTR [bp+si]
    3208:	a2 81 0e             	mov    ds:0xe81,al
    320b:	32 a6 82 12          	xor    ah,BYTE PTR [bp+0x1282]
    320f:	32 6d 7d             	xor    ch,BYTE PTR [di+0x7d]
    3212:	16                   	push   ss
    3213:	32 64 80             	xor    ah,BYTE PTR [si-0x80]
    3216:	2a 32                	sub    dh,BYTE PTR [bp+si]
    3218:	07                   	pop    es
    3219:	0e                   	push   cs
    321a:	54                   	push   sp
    321b:	43                   	inc    bx
    321c:	75 73                	jne    0x3291
    321e:	74 6f                	je     0x328f
    3220:	6d                   	ins    WORD PTR es:[di],dx
    3221:	4c                   	dec    sp
    3222:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    3227:	78 59                	js     0x3282
    3229:	31 d7                	xor    di,dx
    322b:	32 d7                	xor    dl,bh
    322d:	07                   	pop    es
    322e:	47                   	inc    di
    322f:	32 0a                	xor    cl,BYTE PTR [bp+si]
    3231:	00 08                	add    BYTE PTR [bx+si],cl
    3233:	53                   	push   bx
    3234:	74 64                	je     0x329a
    3236:	43                   	inc    bx
    3237:	74 72                	je     0x32ab
    3239:	6c                   	ins    BYTE PTR es:[di],dx
    323a:	73 01                	jae    0x323d
    323c:	00 07                	add    BYTE PTR [bx],al
    323e:	23 77 32             	and    si,WORD PTR [bx+0x32]
    3241:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    3242:	00 ff                	add    bh,bh
    3244:	ff 88 64 d3          	dec    WORD PTR [bx+si-0x2c9c]
    3248:	32 01                	xor    al,BYTE PTR [bx+di]
    324a:	00 00                	add    BYTE PTR [bx+si],al
    324c:	00 00                	add    BYTE PTR [bx+si],al
    324e:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3251:	00 00                	add    BYTE PTR [bx+si],al
    3253:	09 00                	or     WORD PTR [bx+si],ax
    3255:	07                   	pop    es
    3256:	54                   	push   sp
    3257:	61                   	popa
    3258:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    325b:	6f                   	outs   dx,WORD PTR ds:[si]
    325c:	70 0a                	jo     0x3268
    325e:	33 00                	xor    ax,WORD PTR [bx+si]
    3260:	00 00                	add    BYTE PTR [bx+si],al
    3262:	00 00                	add    BYTE PTR [bx+si],al
    3264:	00 01                	add    BYTE PTR [bx+di],al
    3266:	33 02                	xor    ax,WORD PTR [bp+si]
    3268:	01 59 31             	add    WORD PTR [bx+di+0x31],bx
    326b:	16                   	push   ss
    326c:	33 fa                	xor    di,dx
    326e:	45                   	inc    bp
    326f:	e3 32                	jcxz   0x32a3
    3271:	9a 1f 8b 33 cb       	call   0xcb33:0x8b1f
    3276:	1f                   	pop    ds
    3277:	73 32                	jae    0x32ab
    3279:	c5 76 6b             	lds    si,DWORD PTR [bp+0x6b]
    327c:	32 cd                	xor    cl,ch
    327e:	11 87 32 3a          	adc    WORD PTR [bx+0x3a32],ax
    3282:	27                   	daa
    3283:	8b 32                	mov    si,WORD PTR [bp+si]
    3285:	fa                   	cli
    3286:	10 bb 34 d6          	adc    BYTE PTR [bp+di-0x29cc],bh
    328a:	14 93                	adc    al,0x93
    328c:	32 f4                	xor    dh,ah
    328e:	4f                   	dec    di
    328f:	9f                   	lahf
    3290:	32 32                	xor    dh,BYTE PTR [bp+si]
    3292:	16                   	push   ss
    3293:	bb 32 ec             	mov    bx,0xec32
    3296:	30 f3                	xor    bl,dh
    3298:	32 51 1b             	xor    dl,BYTE PTR [bx+di+0x1b]
    329b:	2b 33                	sub    si,WORD PTR [bp+di]
    329d:	38 50 a7             	cmp    BYTE PTR [bx+si-0x59],dl
    32a0:	32 63 31             	xor    ah,BYTE PTR [bp+di+0x31]
    32a3:	c3                   	ret
    32a4:	32 21                	xor    ah,BYTE PTR [bx+di]
    32a6:	50                   	push   ax
    32a7:	7f 32                	jg     0x32db
    32a9:	dc 75 7b             	fdiv   QWORD PTR [di+0x7b]
    32ac:	32 d9                	xor    bl,cl
    32ae:	62 b3 32 06          	bound  si,DWORD PTR [bp+di+0x632]
    32b2:	63 b7 32 8f          	arpl   WORD PTR [bx-0x70ce],si
    32b6:	60                   	pusha
    32b7:	ef                   	out    dx,ax
    32b8:	32 3a                	xor    bh,BYTE PTR [bp+si]
    32ba:	1c 9b                	sbb    al,0x9b
    32bc:	32 f1                	xor    dh,cl
    32be:	7c fb                	jl     0x32bb
    32c0:	32 08                	xor    cl,BYTE PTR [bx+si]
    32c2:	61                   	popa
    32c3:	c7                   	(bad)
    32c4:	32 5c 61             	xor    bl,BYTE PTR [si+0x61]
    32c7:	cb                   	retf
    32c8:	32 62 5c             	xor    ah,BYTE PTR [bp+si+0x5c]
    32cb:	f7 32                	div    WORD PTR [bp+si]
    32cd:	3a 61 83             	cmp    ah,BYTE PTR [bx+di-0x7d]
    32d0:	32 72 3f             	xor    dh,BYTE PTR [bp+si+0x3f]
    32d3:	db 32                	(bad)  [bp+si]
    32d5:	bb 7a df             	mov    bx,0xdf7a
    32d8:	32 17                	xor    dl,BYTE PTR [bx]
    32da:	3e 6f                	outs   dx,WORD PTR ds:[si]
    32dc:	32 f7                	xor    dh,bh
    32de:	7b e7                	jnp    0x32c7
    32e0:	32 ed                	xor    ch,ch
    32e2:	3e eb 32             	ds jmp 0x3317
    32e5:	75 7c                	jne    0x3363
    32e7:	bf 32 c2             	mov    di,0xc232
    32ea:	35 af 32             	xor    ax,0x32af
    32ed:	1c 48                	sbb    al,0x48
    32ef:	97                   	xchg   di,ax
    32f0:	32 ae 5f a3          	xor    ch,BYTE PTR [bp-0x5ca1]
    32f4:	32 35                	xor    dh,BYTE PTR [di]
    32f6:	62 cf 32             	(bad)  {k5}{z}
    32f9:	c5 80 ff 32          	lds    ax,DWORD PTR [bx+si+0x32ff]
    32fd:	6f                   	outs   dx,WORD PTR ds:[si]
    32fe:	81 ab 32 08 54 4c    	sub    WORD PTR [bp+di+0x832],0x4c54
    3304:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    3309:	78 07                	js     0x3312
    330b:	08 54 4c             	or     BYTE PTR [si+0x4c],dl
    330e:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    3313:	78 7d                	js     0x3392
    3315:	32 1a                	xor    bl,BYTE PTR [bp+si]
    3317:	33 18                	xor    bx,WORD PTR [bx+si]
    3319:	32 51 33             	xor    dl,BYTE PTR [bx+di+0x33]
    331c:	31 00                	xor    WORD PTR [bx+si],ax
    331e:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
    3321:	64 43                	fs inc bx
    3323:	74 72                	je     0x3397
    3325:	6c                   	ins    BYTE PTR es:[di],dx
    3326:	73 28                	jae    0x3350
    3328:	00 e2                	add    dl,ah
    332a:	00 33                	add    BYTE PTR [bp+di],dh
    332c:	33 2d                	xor    bp,WORD PTR [di]
    332e:	00 ff                	add    bh,bh
    3330:	ff 72 16             	push   WORD PTR [bp+si+0x16]
    3333:	75 33                	jne    0x3368
    3335:	01 00                	add    WORD PTR [bx+si],ax
    3337:	00 00                	add    BYTE PTR [bx+si],al
    3339:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    333d:	00 00                	add    BYTE PTR [bx+si],al
    333f:	0a 00                	or     al,BYTE PTR [bx+si]
    3341:	05 41 6c             	add    ax,0x6c41
    3344:	69 67 6e d4 02       	imul   sp,WORD PTR [bx+0x6e],0x2d4
    3349:	21 3a                	and    WORD PTR [bp+si],di
    334b:	dc 00                	fadd   QWORD PTR [bx+si]
    334d:	ff                   	(bad)
    334e:	ff                   	(bad)
    334f:	b9 79 93             	mov    cx,0x9379
    3352:	33 01                	xor    ax,WORD PTR [bx+di]
    3354:	00 00                	add    BYTE PTR [bx+si],al
    3356:	00 00                	add    BYTE PTR [bx+si],al
    3358:	80 01 00             	add    BYTE PTR [bx+di],0x0
    335b:	00 00                	add    BYTE PTR [bx+si],al
    335d:	0b 00                	or     ax,WORD PTR [bx+si]
    335f:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
    3362:	72 64                	jb     0x33c8
    3364:	65 72 53             	gs jb  0x33ba
    3367:	74 79                	je     0x33e2
    3369:	6c                   	ins    BYTE PTR es:[di],dx
    336a:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
    336d:	54                   	push   sp
    336e:	34 38                	xor    al,0x38
    3370:	00 ff                	add    bh,bh
    3372:	ff d5                	call   bp
    3374:	1e                   	push   ds
    3375:	79 33                	jns    0x33aa
    3377:	17                   	pop    ss
    3378:	1f                   	pop    ds
    3379:	b3 33                	mov    bl,0x33
    337b:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
    337f:	ff                   	(bad)
    3380:	ff 0c                	dec    WORD PTR [si]
    3382:	00 05                	add    BYTE PTR [di],al
    3384:	43                   	inc    bx
    3385:	6f                   	outs   dx,WORD PTR ds:[si]
    3386:	6c                   	ins    BYTE PTR es:[di],dx
    3387:	6f                   	outs   dx,WORD PTR ds:[si]
    3388:	72 d4                	jb     0x335e
    338a:	22 ab 33 e1          	and    ch,BYTE PTR [bp+di-0x1ecd]
    338e:	00 ff                	add    bh,bh
    3390:	ff 65 77             	jmp    WORD PTR [di+0x77]
    3393:	35 34 01             	xor    ax,0x134
    3396:	00 00                	add    BYTE PTR [bx+si],al
    3398:	00 00                	add    BYTE PTR [bx+si],al
    339a:	80 00 00             	add    BYTE PTR [bx+si],0x0
    339d:	00 00                	add    BYTE PTR [bx+si],al
    339f:	0d 00 07             	or     ax,0x700
    33a2:	43                   	inc    bx
    33a3:	6f                   	outs   dx,WORD PTR ds:[si]
    33a4:	6c                   	ins    BYTE PTR es:[di],dx
    33a5:	75 6d                	jne    0x3414
    33a7:	6e                   	outs   dx,BYTE PTR ds:[si]
    33a8:	73 07                	jae    0x33b1
    33aa:	23 0d                	and    cx,WORD PTR [di]
    33ac:	34 a5                	xor    al,0xa5
    33ae:	00 ff                	add    bh,bh
    33b0:	ff 22                	jmp    WORD PTR [bp+si]
    33b2:	63 b7 33 54          	arpl   WORD PTR [bx+0x5433],si
    33b6:	63 c9                	arpl   cx,cx
    33b8:	33 00                	xor    ax,WORD PTR [bx+si]
    33ba:	80 00 00             	add    BYTE PTR [bx+si],0x0
    33bd:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
    33c1:	05 43 74             	add    ax,0x7443
    33c4:	6c                   	ins    BYTE PTR es:[di],dx
    33c5:	33 44 64             	xor    ax,WORD PTR [si+0x64]
    33c8:	00 ec                	add    ah,ch
    33ca:	33 3e 00 ff          	xor    di,WORD PTR ds:0xff00
    33ce:	ff                   	(bad)
    33cf:	3e 00 ff             	ds add bh,bh
    33d2:	ff 01                	inc    WORD PTR [bx+di]
    33d4:	00 00                	add    BYTE PTR [bx+si],al
    33d6:	00 00                	add    BYTE PTR [bx+si],al
    33d8:	80 f4 ff             	xor    ah,0xff
    33db:	ff                   	(bad)
    33dc:	ff 0f                	dec    WORD PTR [bx]
    33de:	00 0a                	add    BYTE PTR [bp+si],cl
    33e0:	44                   	inc    sp
    33e1:	72 61                	jb     0x3444
    33e3:	67 43                	addr32 inc bx
    33e5:	75 72                	jne    0x3459
    33e7:	73 6f                	jae    0x3458
    33e9:	72 25                	jb     0x3410
    33eb:	01 15                	add    WORD PTR [di],dx
    33ed:	34 2e                	xor    al,0x2e
    33ef:	00 ff                	add    bh,bh
    33f1:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    33f5:	ff 01                	inc    WORD PTR [bx+di]
    33f7:	00 00                	add    BYTE PTR [bx+si],al
    33f9:	00 00                	add    BYTE PTR [bx+si],al
    33fb:	80 00 00             	add    BYTE PTR [bx+si],0x0
    33fe:	00 00                	add    BYTE PTR [bx+si],al
    3400:	10 00                	adc    BYTE PTR [bx+si],al
    3402:	08 44 72             	or     BYTE PTR [si+0x72],al
    3405:	61                   	popa
    3406:	67 4d                	addr32 dec bp
    3408:	6f                   	outs   dx,WORD PTR ds:[si]
    3409:	64 65 07             	fs gs pop es
    340c:	23 2d                	and    bp,WORD PTR [di]
    340e:	34 2a                	xor    al,0x2a
    3410:	00 ff                	add    bh,bh
    3412:	ff                   	(bad)
    3413:	b8 1c 5c             	mov    ax,0x5c1c
    3416:	34 01                	xor    al,0x1
    3418:	00 00                	add    BYTE PTR [bx+si],al
    341a:	00 00                	add    BYTE PTR [bx+si],al
    341c:	80 01 00             	add    BYTE PTR [bx+di],0x0
    341f:	00 00                	add    BYTE PTR [bx+si],al
    3421:	11 00                	adc    WORD PTR [bx+si],ax
    3423:	07                   	pop    es
    3424:	45                   	inc    bp
    3425:	6e                   	outs   dx,BYTE PTR ds:[si]
    3426:	61                   	popa
    3427:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    342a:	64 07                	fs pop es
    342c:	23 71 34             	and    si,WORD PTR [bx+di+0x34]
    342f:	e9 00 ff             	jmp    0x3332
    3432:	ff 12                	call   WORD PTR [bp+si]
    3434:	78 79                	js     0x34af
    3436:	34 01                	xor    al,0x1
    3438:	00 00                	add    BYTE PTR [bx+si],al
    343a:	00 00                	add    BYTE PTR [bx+si],al
    343c:	80 01 00             	add    BYTE PTR [bx+di],0x0
    343f:	00 00                	add    BYTE PTR [bx+si],al
    3441:	12 00                	adc    al,BYTE PTR [bx+si]
    3443:	0e                   	push   cs
    3444:	45                   	inc    bp
    3445:	78 74                	js     0x34bb
    3447:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3449:	64 65 64 53          	fs gs fs push bx
    344d:	65 6c                	gs ins BYTE PTR es:[di],dx
    344f:	65 63 74 22          	arpl   WORD PTR gs:[si+0x22],si
    3453:	03 94 3f 34          	add    dx,WORD PTR [si+0x343f]
    3457:	00 ff                	add    bh,bh
    3459:	ff                   	jmp    (bad)
    345a:	eb 1d                	jmp    0x3479
    345c:	60                   	pusha
    345d:	34 08                	xor    al,0x8
    345f:	1e                   	push   ds
    3460:	05 35 00             	add    ax,0x35
    3463:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3466:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    346a:	04 46                	add    al,0x46
    346c:	6f                   	outs   dx,WORD PTR ds:[si]
    346d:	6e                   	outs   dx,BYTE PTR ds:[si]
    346e:	74 07                	je     0x3477
    3470:	23 98 34 e6          	and    bx,WORD PTR [bx+si-0x19cc]
    3474:	00 ff                	add    bh,bh
    3476:	ff 35                	push   WORD PTR [di]
    3478:	78 9c                	js     0x3416
    347a:	34 01                	xor    al,0x1
    347c:	00 00                	add    BYTE PTR [bx+si],al
    347e:	00 00                	add    BYTE PTR [bx+si],al
    3480:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3483:	00 00                	add    BYTE PTR [bx+si],al
    3485:	14 00                	adc    al,0x0
    3487:	0e                   	push   cs
    3488:	49                   	dec    cx
    3489:	6e                   	outs   dx,BYTE PTR ds:[si]
    348a:	74 65                	je     0x34f1
    348c:	67 72 61             	addr32 jb 0x34f0
    348f:	6c                   	ins    BYTE PTR es:[di],dx
    3490:	48                   	dec    ax
    3491:	65 69 67 68 74 d4    	imul   sp,WORD PTR gs:[bx+0x68],0xd474
    3497:	22 d9                	and    bl,cl
    3499:	34 58                	xor    al,0x58
    349b:	78 a0                	js     0x343d
    349d:	34 93                	xor    al,0x93
    349f:	78 c3                	js     0x3464
    34a1:	34 01                	xor    al,0x1
    34a3:	00 00                	add    BYTE PTR [bx+si],al
    34a5:	00 00                	add    BYTE PTR [bx+si],al
    34a7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    34aa:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
    34ae:	0a 49 74             	or     cl,BYTE PTR [bx+di+0x74]
    34b1:	65 6d                	gs ins WORD PTR es:[di],dx
    34b3:	48                   	dec    ax
    34b4:	65 69 67 68 74 8b    	imul   sp,WORD PTR gs:[bx+0x68],0x8b74
    34ba:	03 70 36             	add    si,WORD PTR [bx+si+0x36]
    34bd:	d8 00                	fadd   DWORD PTR [bx+si]
    34bf:	ff                   	(bad)
    34c0:	ff 0c                	dec    WORD PTR [si]
    34c2:	7a e1                	jp     0x34a5
    34c4:	34 01                	xor    al,0x1
    34c6:	00 00                	add    BYTE PTR [bx+si],al
    34c8:	00 00                	add    BYTE PTR [bx+si],al
    34ca:	80 00 00             	add    BYTE PTR [bx+si],0x0
    34cd:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
    34d1:	05 49 74             	add    ax,0x7449
    34d4:	65 6d                	gs ins WORD PTR es:[di],dx
    34d6:	73 07                	jae    0x34df
    34d8:	23 fd                	and    di,bp
    34da:	34 e7                	xor    al,0xe7
    34dc:	00 ff                	add    bh,bh
    34de:	ff                   	(bad)
    34df:	bc 78 da             	mov    sp,0xda78
    34e2:	35 01 00             	xor    ax,0x1
    34e5:	00 00                	add    BYTE PTR [bx+si],al
    34e7:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    34eb:	00 00                	add    BYTE PTR [bx+si],al
    34ed:	17                   	pop    ss
    34ee:	00 0b                	add    BYTE PTR [bp+di],cl
    34f0:	4d                   	dec    bp
    34f1:	75 6c                	jne    0x355f
    34f3:	74 69                	je     0x355e
    34f5:	53                   	push   bx
    34f6:	65 6c                	gs ins BYTE PTR es:[di],dx
    34f8:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
    34fc:	23 21                	and    sp,WORD PTR [bx+di]
    34fe:	35 2c 00             	xor    ax,0x2c
    3501:	ff                   	(bad)
    3502:	ff 32                	push   WORD PTR [bp+si]
    3504:	1f                   	pop    ds
    3505:	29 35                	sub    WORD PTR [di],si
    3507:	01 00                	add    WORD PTR [bx+si],ax
    3509:	00 00                	add    BYTE PTR [bx+si],al
    350b:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    350f:	00 00                	add    BYTE PTR [bx+si],al
    3511:	18 00                	sbb    BYTE PTR [bx+si],al
    3513:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    3516:	72 65                	jb     0x357d
    3518:	6e                   	outs   dx,BYTE PTR ds:[si]
    3519:	74 43                	je     0x355e
    351b:	6f                   	outs   dx,WORD PTR ds:[si]
    351c:	6c                   	ins    BYTE PTR es:[di],dx
    351d:	6f                   	outs   dx,WORD PTR ds:[si]
    351e:	72 07                	jb     0x3527
    3520:	23 45 35             	and    ax,WORD PTR [di+0x35]
    3523:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    3524:	00 ff                	add    bh,bh
    3526:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    3529:	4d                   	dec    bp
    352a:	35 01 00             	xor    ax,0x1
    352d:	00 00                	add    BYTE PTR [bx+si],al
    352f:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    3533:	00 00                	add    BYTE PTR [bx+si],al
    3535:	19 00                	sbb    WORD PTR [bx+si],ax
    3537:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    353a:	72 65                	jb     0x35a1
    353c:	6e                   	outs   dx,BYTE PTR ds:[si]
    353d:	74 43                	je     0x3582
    353f:	74 6c                	je     0x35ad
    3541:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    3544:	23 68 35             	and    bp,WORD PTR [bx+si+0x35]
    3547:	2b 00                	sub    ax,WORD PTR [bx+si]
    3549:	ff                   	(bad)
    354a:	ff                   	(bad)
    354b:	3e 1e                	ds push ds
    354d:	70 35                	jo     0x3584
    354f:	01 00                	add    WORD PTR [bx+si],ax
    3551:	00 00                	add    BYTE PTR [bx+si],al
    3553:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    3557:	00 00                	add    BYTE PTR [bx+si],al
    3559:	1a 00                	sbb    al,BYTE PTR [bx+si]
    355b:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
    355e:	72 65                	jb     0x35c5
    3560:	6e                   	outs   dx,BYTE PTR ds:[si]
    3561:	74 46                	je     0x35a9
    3563:	6f                   	outs   dx,WORD PTR ds:[si]
    3564:	6e                   	outs   dx,BYTE PTR ds:[si]
    3565:	74 07                	je     0x356e
    3567:	23 b1 35 49          	and    si,WORD PTR [bx+di+0x4935]
    356b:	00 ff                	add    bh,bh
    356d:	ff a1 1e b9          	jmp    WORD PTR [bx+di-0x46e2]
    3571:	35 01 00             	xor    ax,0x1
    3574:	00 00                	add    BYTE PTR [bx+si],al
    3576:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    357a:	00 00                	add    BYTE PTR [bx+si],al
    357c:	1b 00                	sbb    ax,WORD PTR [bx+si]
    357e:	0e                   	push   cs
    357f:	50                   	push   ax
    3580:	61                   	popa
    3581:	72 65                	jb     0x35e8
    3583:	6e                   	outs   dx,BYTE PTR ds:[si]
    3584:	74 53                	je     0x35d9
    3586:	68 6f 77             	push   0x776f
    3589:	48                   	dec    ax
    358a:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    358f:	e5 3a                	in     ax,0x3a
    3591:	40                   	inc    ax
    3592:	00 ff                	add    bh,bh
    3594:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    3597:	ff                   	(bad)
    3598:	ff 01                	inc    WORD PTR [bx+di]
    359a:	00 00                	add    BYTE PTR [bx+si],al
    359c:	00 00                	add    BYTE PTR [bx+si],al
    359e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    35a1:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    35a5:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    35a8:	70 75                	jo     0x361f
    35aa:	70 4d                	jo     0x35f9
    35ac:	65 6e                	outs   dx,BYTE PTR gs:[si]
    35ae:	75 07                	jne    0x35b7
    35b0:	23 d2                	and    dx,dx
    35b2:	35 48 00             	xor    ax,0x48
    35b5:	ff                   	(bad)
    35b6:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    35b9:	bd 35 23             	mov    bp,0x2335
    35bc:	1e                   	push   ds
    35bd:	0f 36                	(bad)
    35bf:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    35c3:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    35c7:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    35ca:	6f                   	outs   dx,WORD PTR ds:[si]
    35cb:	77 48                	ja     0x3615
    35cd:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
    35d2:	30 36 e8 00          	xor    BYTE PTR ds:0xe8,dh
    35d6:	ff                   	(bad)
    35d7:	ff 4c 79             	dec    WORD PTR [si+0x79]
    35da:	f1                   	int1
    35db:	35 01 00             	xor    ax,0x1
    35de:	00 00                	add    BYTE PTR [bx+si],al
    35e0:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    35e4:	00 00                	add    BYTE PTR [bx+si],al
    35e6:	1e                   	push   ds
    35e7:	00 06 53 6f          	add    BYTE PTR ds:0x6f53,al
    35eb:	72 74                	jb     0x3661
    35ed:	65 64 ed             	gs fs in ax,dx
    35f0:	30 f9                	xor    cl,bh
    35f2:	35 e5 00             	xor    ax,0xe5
    35f5:	ff                   	(bad)
    35f6:	ff 6f 79             	jmp    DWORD PTR [bx+0x79]
    35f9:	f9                   	stc
    35fa:	36 01 00             	add    WORD PTR ss:[bx+si],ax
    35fd:	00 00                	add    BYTE PTR [bx+si],al
    35ff:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    3603:	00 00                	add    BYTE PTR [bx+si],al
    3605:	1f                   	pop    ds
    3606:	00 05                	add    BYTE PTR [di],al
    3608:	53                   	push   bx
    3609:	74 79                	je     0x3684
    360b:	6c                   	ins    BYTE PTR es:[di],dx
    360c:	65 52                	gs push dx
    360e:	01 13                	add    WORD PTR [bp+di],dx
    3610:	36 a6                	cmps   BYTE PTR ss:[si],BYTE PTR es:[di]
    3612:	63 17                	arpl   WORD PTR [bx],dx
    3614:	36 60                	ss pusha
    3616:	64 38 36 01 00       	cmp    BYTE PTR fs:0x1,dh
    361b:	00 00                	add    BYTE PTR [bx+si],al
    361d:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    3621:	ff                   	(bad)
    3622:	ff 20                	jmp    WORD PTR [bx+si]
    3624:	00 08                	add    BYTE PTR [bx+si],cl
    3626:	54                   	push   sp
    3627:	61                   	popa
    3628:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    362b:	64 65 72 07          	fs gs jb 0x3636
    362f:	23 50 36             	and    dx,WORD PTR [bx+si+0x36]
    3632:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    3633:	00 ff                	add    bh,bh
    3635:	ff 88 64 58          	dec    WORD PTR [bx+si+0x5864]
    3639:	36 01 00             	add    WORD PTR ss:[bx+si],ax
    363c:	00 00                	add    BYTE PTR [bx+si],al
    363e:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    3642:	00 00                	add    BYTE PTR [bx+si],al
    3644:	09 00                	or     WORD PTR [bx+si],ax
    3646:	07                   	pop    es
    3647:	54                   	push   sp
    3648:	61                   	popa
    3649:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    364c:	6f                   	outs   dx,WORD PTR ds:[si]
    364d:	70 07                	jo     0x3656
    364f:	23 d5                	and    dx,bp
    3651:	38 29                	cmp    BYTE PTR [bx+di],ch
    3653:	00 ff                	add    bh,bh
    3655:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    3658:	b3 36                	mov    bl,0x36
    365a:	01 00                	add    WORD PTR [bx+si],ax
    365c:	00 00                	add    BYTE PTR [bx+si],al
    365e:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    3662:	00 00                	add    BYTE PTR [bx+si],al
    3664:	21 00                	and    WORD PTR [bx+si],ax
    3666:	07                   	pop    es
    3667:	56                   	push   si
    3668:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    366d:	65 71 00             	gs jno 0x3670
    3670:	90                   	nop
    3671:	36 7a 00             	ss jp  0x3674
    3674:	ff                   	(bad)
    3675:	ff                   	(bad)
    3676:	7a 00                	jp     0x3678
    3678:	ff                   	(bad)
    3679:	ff 01                	inc    WORD PTR [bx+di]
    367b:	00 00                	add    BYTE PTR [bx+si],al
    367d:	00 00                	add    BYTE PTR [bx+si],al
    367f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3682:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    3686:	07                   	pop    es
    3687:	4f                   	dec    di
    3688:	6e                   	outs   dx,BYTE PTR ds:[si]
    3689:	43                   	inc    bx
    368a:	6c                   	ins    BYTE PTR es:[di],dx
    368b:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    3690:	3e 37                	ds aaa
    3692:	82 00 ff             	add    BYTE PTR [bx+si],0xff
    3695:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    3699:	ff 01                	inc    WORD PTR [bx+di]
    369b:	00 00                	add    BYTE PTR [bx+si],al
    369d:	00 00                	add    BYTE PTR [bx+si],al
    369f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    36a2:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    36a6:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    36a9:	44                   	inc    sp
    36aa:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    36ad:	6c                   	ins    BYTE PTR es:[di],dx
    36ae:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    36b3:	d6                   	(bad)
    36b4:	36 62 00             	bound  ax,DWORD PTR ss:[bx+si]
    36b7:	ff                   	(bad)
    36b8:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    36bb:	ff                   	(bad)
    36bc:	ff 01                	inc    WORD PTR [bx+di]
    36be:	00 00                	add    BYTE PTR [bx+si],al
    36c0:	00 00                	add    BYTE PTR [bx+si],al
    36c2:	80 00 00             	add    BYTE PTR [bx+si],0x0
    36c5:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    36c9:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    36cc:	44                   	inc    sp
    36cd:	72 61                	jb     0x3730
    36cf:	67 44                	addr32 inc sp
    36d1:	72 6f                	jb     0x3742
    36d3:	70 80                	jo     0x3655
    36d5:	02 1c                	add    bl,BYTE PTR [si]
    36d7:	37                   	aaa
    36d8:	6a 00                	push   0x0
    36da:	ff                   	(bad)
    36db:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    36de:	ff                   	(bad)
    36df:	ff 01                	inc    WORD PTR [bx+di]
    36e1:	00 00                	add    BYTE PTR [bx+si],al
    36e3:	00 00                	add    BYTE PTR [bx+si],al
    36e5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    36e8:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    36ec:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    36ef:	44                   	inc    sp
    36f0:	72 61                	jb     0x3753
    36f2:	67 4f                	addr32 dec di
    36f4:	76 65                	jbe    0x375b
    36f6:	72 f8                	jb     0x36f0
    36f8:	18 e2                	sbb    dl,ah
    36fa:	37                   	aaa
    36fb:	f2 00 ff             	repnz add bh,bh
    36fe:	ff f2                	push   dx
    3700:	00 ff                	add    bh,bh
    3702:	ff 01                	inc    WORD PTR [bx+di]
    3704:	00 00                	add    BYTE PTR [bx+si],al
    3706:	00 00                	add    BYTE PTR [bx+si],al
    3708:	80 00 00             	add    BYTE PTR [bx+si],0x0
    370b:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    370f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    3712:	44                   	inc    sp
    3713:	72 61                	jb     0x3776
    3715:	77 49                	ja     0x3760
    3717:	74 65                	je     0x377e
    3719:	6d                   	ins    WORD PTR es:[di],dx
    371a:	32 03                	xor    al,BYTE PTR [bp+di]
    371c:	7d 37                	jge    0x3755
    371e:	72 00                	jb     0x3720
    3720:	ff                   	(bad)
    3721:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    3724:	ff                   	(bad)
    3725:	ff 01                	inc    WORD PTR [bx+di]
    3727:	00 00                	add    BYTE PTR [bx+si],al
    3729:	00 00                	add    BYTE PTR [bx+si],al
    372b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    372e:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    3732:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    3735:	45                   	inc    bp
    3736:	6e                   	outs   dx,BYTE PTR ds:[si]
    3737:	64 44                	fs inc sp
    3739:	72 61                	jb     0x379c
    373b:	67 71 00             	addr32 jno 0x373e
    373e:	5e                   	pop    si
    373f:	37                   	aaa
    3740:	c8 00 ff ff          	enter  0xff00,0xff
    3744:	c8 00 ff ff          	enter  0xff00,0xff
    3748:	01 00                	add    WORD PTR [bx+si],ax
    374a:	00 00                	add    BYTE PTR [bx+si],al
    374c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    3750:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    3754:	07                   	pop    es
    3755:	4f                   	dec    di
    3756:	6e                   	outs   dx,BYTE PTR ds:[si]
    3757:	45                   	inc    bp
    3758:	6e                   	outs   dx,BYTE PTR ds:[si]
    3759:	74 65                	je     0x37c0
    375b:	72 71                	jb     0x37ce
    375d:	00 ed                	add    ch,ch
    375f:	38 d0                	cmp    al,dl
    3761:	00 ff                	add    bh,bh
    3763:	ff d0                	call   ax
    3765:	00 ff                	add    bh,bh
    3767:	ff 01                	inc    WORD PTR [bx+di]
    3769:	00 00                	add    BYTE PTR [bx+si],al
    376b:	00 00                	add    BYTE PTR [bx+si],al
    376d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3770:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
    3774:	06                   	push   es
    3775:	4f                   	dec    di
    3776:	6e                   	outs   dx,BYTE PTR ds:[si]
    3777:	45                   	inc    bp
    3778:	78 69                	js     0x37e3
    377a:	74 1a                	je     0x3796
    377c:	02 9f 37 b0          	add    bl,BYTE PTR [bx-0x4fc9]
    3780:	00 ff                	add    bh,bh
    3782:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    3786:	ff 01                	inc    WORD PTR [bx+di]
    3788:	00 00                	add    BYTE PTR [bx+si],al
    378a:	00 00                	add    BYTE PTR [bx+si],al
    378c:	80 00 00             	add    BYTE PTR [bx+si],0x0
    378f:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
    3793:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    3796:	4b                   	dec    bx
    3797:	65 79 44             	gs jns 0x37de
    379a:	6f                   	outs   dx,WORD PTR ds:[si]
    379b:	77 6e                	ja     0x380b
    379d:	54                   	push   sp
    379e:	02 c2                	add    al,dl
    37a0:	37                   	aaa
    37a1:	b8 00 ff             	mov    ax,0xff00
    37a4:	ff                   	(bad)
    37a5:	b8 00 ff             	mov    ax,0xff00
    37a8:	ff 01                	inc    WORD PTR [bx+di]
    37aa:	00 00                	add    BYTE PTR [bx+si],al
    37ac:	00 00                	add    BYTE PTR [bx+si],al
    37ae:	80 00 00             	add    BYTE PTR [bx+si],0x0
    37b1:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
    37b5:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    37b8:	4b                   	dec    bx
    37b9:	65 79 50             	gs jns 0x380c
    37bc:	72 65                	jb     0x3823
    37be:	73 73                	jae    0x3833
    37c0:	1a 02                	sbb    al,BYTE PTR [bp+si]
    37c2:	08 38                	or     BYTE PTR [bx+si],bh
    37c4:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
    37c7:	ff c0                	inc    ax
    37c9:	00 ff                	add    bh,bh
    37cb:	ff 01                	inc    WORD PTR [bx+di]
    37cd:	00 00                	add    BYTE PTR [bx+si],al
    37cf:	00 00                	add    BYTE PTR [bx+si],al
    37d1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    37d4:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
    37d8:	07                   	pop    es
    37d9:	4f                   	dec    di
    37da:	6e                   	outs   dx,BYTE PTR ds:[si]
    37db:	4b                   	dec    bx
    37dc:	65 79 55             	gs jns 0x3834
    37df:	70 51                	jo     0x3832
    37e1:	19 35                	sbb    WORD PTR [di],si
    37e3:	39 fa                	cmp    dx,di
    37e5:	00 ff                	add    bh,bh
    37e7:	ff                   	(bad)
    37e8:	fa                   	cli
    37e9:	00 ff                	add    bh,bh
    37eb:	ff 01                	inc    WORD PTR [bx+di]
    37ed:	00 00                	add    BYTE PTR [bx+si],al
    37ef:	00 00                	add    BYTE PTR [bx+si],al
    37f1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    37f4:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
    37f8:	0d 4f 6e             	or     ax,0x6e4f
    37fb:	4d                   	dec    bp
    37fc:	65 61                	gs popa
    37fe:	73 75                	jae    0x3875
    3800:	72 65                	jb     0x3867
    3802:	49                   	dec    cx
    3803:	74 65                	je     0x386a
    3805:	6d                   	ins    WORD PTR es:[di],dx
    3806:	71 01                	jno    0x3809
    3808:	2c 38                	sub    al,0x38
    380a:	4a                   	dec    dx
    380b:	00 ff                	add    bh,bh
    380d:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
    3810:	ff                   	(bad)
    3811:	ff 01                	inc    WORD PTR [bx+di]
    3813:	00 00                	add    BYTE PTR [bx+si],al
    3815:	00 00                	add    BYTE PTR [bx+si],al
    3817:	80 00 00             	add    BYTE PTR [bx+si],0x0
    381a:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
    381e:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    3821:	4d                   	dec    bp
    3822:	6f                   	outs   dx,WORD PTR ds:[si]
    3823:	75 73                	jne    0x3898
    3825:	65 44                	gs inc sp
    3827:	6f                   	outs   dx,WORD PTR ds:[si]
    3828:	77 6e                	ja     0x3898
    382a:	ce                   	into
    382b:	01 50 38             	add    WORD PTR [bx+si+0x38],dx
    382e:	52                   	push   dx
    382f:	00 ff                	add    bh,bh
    3831:	ff 52 00             	call   WORD PTR [bp+si+0x0]
    3834:	ff                   	(bad)
    3835:	ff 01                	inc    WORD PTR [bx+di]
    3837:	00 00                	add    BYTE PTR [bx+si],al
    3839:	00 00                	add    BYTE PTR [bx+si],al
    383b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    383e:	00 80 2f 00          	add    BYTE PTR [bx+si+0x2f],al
    3842:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
    3845:	4d                   	dec    bp
    3846:	6f                   	outs   dx,WORD PTR ds:[si]
    3847:	75 73                	jne    0x38bc
    3849:	65 4d                	gs dec bp
    384b:	6f                   	outs   dx,WORD PTR ds:[si]
    384c:	76 65                	jbe    0x38b3
    384e:	71 01                	jno    0x3851
    3850:	31 39                	xor    WORD PTR [bx+di],di
    3852:	5a                   	pop    dx
    3853:	00 ff                	add    bh,bh
    3855:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
    3858:	ff                   	(bad)
    3859:	ff 01                	inc    WORD PTR [bx+di]
    385b:	00 00                	add    BYTE PTR [bx+si],al
    385d:	00 00                	add    BYTE PTR [bx+si],al
    385f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3862:	00 80 30 00          	add    BYTE PTR [bx+si+0x30],al
    3866:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    3869:	4d                   	dec    bp
    386a:	6f                   	outs   dx,WORD PTR ds:[si]
    386b:	75 73                	jne    0x38e0
    386d:	65 55                	gs push bp
    386f:	70 08                	jo     0x3879
    3871:	0c 54                	or     al,0x54
    3873:	53                   	push   bx
    3874:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    3877:	6c                   	ins    BYTE PTR es:[di],dx
    3878:	6c                   	ins    BYTE PTR es:[di],dx
    3879:	45                   	inc    bp
    387a:	76 65                	jbe    0x38e1
    387c:	6e                   	outs   dx,BYTE PTR ds:[si]
    387d:	74 00                	je     0x387f
    387f:	03 00                	add    ax,WORD PTR [bx+si]
    3881:	06                   	push   es
    3882:	53                   	push   bx
    3883:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3885:	64 65 72 07          	fs gs jb 0x3890
    3889:	54                   	push   sp
    388a:	4f                   	dec    di
    388b:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
    388e:	63 74 00             	arpl   WORD PTR [si+0x0],si
    3891:	0a 53 63             	or     dl,BYTE PTR [bp+di+0x63]
    3894:	72 6f                	jb     0x3905
    3896:	6c                   	ins    BYTE PTR es:[di],dx
    3897:	6c                   	ins    BYTE PTR es:[di],dx
    3898:	43                   	inc    bx
    3899:	6f                   	outs   dx,WORD PTR ds:[si]
    389a:	64 65 0b 54 53       	fs or  dx,WORD PTR gs:[si+0x53]
    389f:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    38a2:	6c                   	ins    BYTE PTR es:[di],dx
    38a3:	6c                   	ins    BYTE PTR es:[di],dx
    38a4:	43                   	inc    bx
    38a5:	6f                   	outs   dx,WORD PTR ds:[si]
    38a6:	64 65 01 09          	fs add WORD PTR gs:[bx+di],cx
    38aa:	53                   	push   bx
    38ab:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    38ae:	6c                   	ins    BYTE PTR es:[di],dx
    38af:	6c                   	ins    BYTE PTR es:[di],dx
    38b0:	50                   	push   ax
    38b1:	6f                   	outs   dx,WORD PTR ds:[si]
    38b2:	73 07                	jae    0x38bb
    38b4:	49                   	dec    cx
    38b5:	6e                   	outs   dx,BYTE PTR ds:[si]
    38b6:	74 65                	je     0x391d
    38b8:	67 65 72 7c          	addr32 gs jb 0x3938
    38bc:	39 00                	cmp    WORD PTR [bx+si],ax
    38be:	00 00                	add    BYTE PTR [bx+si],al
    38c0:	00 62 39             	add    BYTE PTR [bp+si+0x39],ah
    38c3:	57                   	push   di
    38c4:	39 f4                	cmp    sp,si
    38c6:	00 c1                	add    cl,al
    38c8:	05 8e 39             	add    ax,0x398e
    38cb:	fa                   	cli
    38cc:	45                   	inc    bp
    38cd:	41                   	inc    cx
    38ce:	39 9a 1f 9f          	cmp    WORD PTR [bp+si-0x60e1],bx
    38d2:	39 cb                	cmp    bx,cx
    38d4:	1f                   	pop    ds
    38d5:	d1 38                	sar    WORD PTR [bx+si],1
    38d7:	fc                   	cld
    38d8:	2e 21 39             	and    WORD PTR cs:[bx+di],di
    38db:	cd 11                	int    0x11
    38dd:	e5 38                	in     ax,0x38
    38df:	3a 27                	cmp    ah,BYTE PTR [bx]
    38e1:	e9 38 fa             	jmp    0x331c
    38e4:	10 ce                	adc    dh,cl
    38e6:	3b d6                	cmp    dx,si
    38e8:	14 f1                	adc    al,0xf1
    38ea:	38 f4                	cmp    ah,dh
    38ec:	4f                   	dec    di
    38ed:	fd                   	std
    38ee:	38 32                	cmp    BYTE PTR [bp+si],dh
    38f0:	16                   	push   ss
    38f1:	19 39                	sbb    WORD PTR [bx+di],di
    38f3:	ec                   	in     al,dx
    38f4:	30 51 39             	xor    BYTE PTR [bx+di+0x39],dl
    38f7:	51                   	push   cx
    38f8:	1b c9                	sbb    cx,cx
    38fa:	38 38                	cmp    BYTE PTR [bx+si],bh
    38fc:	50                   	push   ax
    38fd:	05 39 63             	add    ax,0x6339
    3900:	31 d9                	xor    cx,bx
    3902:	38 21                	cmp    BYTE PTR [bx+di],ah
    3904:	50                   	push   ax
    3905:	dd 38                	fnstsw WORD PTR [bx+si]
    3907:	ef                   	out    dx,ax
    3908:	82 6e 39 d9          	sub    BYTE PTR [bp+0x39],0xd9
    390c:	62 11                	bound  dx,DWORD PTR [bx+di]
    390e:	39 06 63 15          	cmp    WORD PTR ds:0x1563,ax
    3912:	39 8f 60 4d          	cmp    WORD PTR [bx+0x4d60],cx
    3916:	39 3a                	cmp    WORD PTR [bp+si],di
    3918:	1c f9                	sbb    al,0xf9
    391a:	38 46 44             	cmp    BYTE PTR [bp+0x44],al
    391d:	01 39                	add    WORD PTR [bx+di],di
    391f:	08 61 25             	or     BYTE PTR [bx+di+0x25],ah
    3922:	39 5c 61             	cmp    WORD PTR [si+0x61],bx
    3925:	29 39                	sub    WORD PTR [bx+di],di
    3927:	62 5c 55             	bound  bx,DWORD PTR [si+0x55]
    392a:	39 3a                	cmp    WORD PTR [bp+si],di
    392c:	61                   	popa
    392d:	e1 38                	loope  0x3967
    392f:	72 3f                	jb     0x3970
    3931:	39 39                	cmp    WORD PTR [bx+di],di
    3933:	86 83 3d 39          	xchg   BYTE PTR [bp+di+0x393d],al
    3937:	17                   	pop    ss
    3938:	3e cd 38             	ds int 0x38
    393b:	e3 83                	jcxz   0x38c0
    393d:	09 39                	or     WORD PTR [bx+di],di
    393f:	ed                   	in     ax,dx
    3940:	3e 45                	ds inc bp
    3942:	39 77 3e             	cmp    WORD PTR [bx+0x3e],si
    3945:	49                   	dec    cx
    3946:	39 c2                	cmp    dx,ax
    3948:	35 0d 39             	xor    ax,0x390d
    394b:	1c 48                	sbb    al,0x48
    394d:	f5                   	cmc
    394e:	38 ae 5f 1d          	cmp    BYTE PTR [bp+0x1d5f],ch
    3952:	39 35                	cmp    WORD PTR [di],si
    3954:	62 2d                	bound  bp,DWORD PTR [di]
    3956:	39 0a                	cmp    WORD PTR [bp+si],cx
    3958:	54                   	push   sp
    3959:	53                   	push   bx
    395a:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    395d:	6c                   	ins    BYTE PTR es:[di],dx
    395e:	6c                   	ins    BYTE PTR es:[di],dx
    395f:	42                   	inc    dx
    3960:	61                   	popa
    3961:	72 04                	jb     0x3967
    3963:	00 14                	add    BYTE PTR [si],dl
    3965:	21 15                	and    WORD PTR [di],dx
    3967:	21 ee                	and    si,bp
    3969:	ff                   	jmp    (bad)
    396a:	ed                   	in     ax,dx
    396b:	ff 53 87             	call   WORD PTR [bp+di-0x79]
    396e:	72 39                	jb     0x39a9
    3970:	69 87 76 39 c6 85    	imul   ax,WORD PTR [bx+0x3976],0x85c6
    3976:	7a 39                	jp     0x39b1
    3978:	ee                   	out    dx,al
    3979:	85 8a 39 07          	test   WORD PTR [bp+si+0x739],cx
    397d:	0a 54 53             	or     dl,BYTE PTR [si+0x53]
    3980:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    3983:	6c                   	ins    BYTE PTR es:[di],dx
    3984:	6c                   	ins    BYTE PTR es:[di],dx
    3985:	42                   	inc    dx
    3986:	61                   	popa
    3987:	72 db                	jb     0x3964
    3989:	38 29                	cmp    BYTE PTR [bx+di],ch
    398b:	3a d7                	cmp    dl,bh
    398d:	07                   	pop    es
    398e:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    398f:	39 24                	cmp    WORD PTR [si],sp
    3991:	00 08                	add    BYTE PTR [bx+si],cl
    3993:	53                   	push   bx
    3994:	74 64                	je     0x39fa
    3996:	43                   	inc    bx
    3997:	74 72                	je     0x3a0b
    3999:	6c                   	ins    BYTE PTR es:[di],dx
    399a:	73 1b                	jae    0x39b7
    399c:	00 07                	add    BYTE PTR [bx],al
    399e:	23 01                	and    ax,WORD PTR [bx+di]
    39a0:	3a a5 00 ff          	cmp    ah,BYTE PTR [di-0x100]
    39a4:	ff 22                	jmp    WORD PTR [bp+si]
    39a6:	63 ab 39 54          	arpl   WORD PTR [bp+di+0x5439],bp
    39aa:	63 bd 39 00          	arpl   WORD PTR [di+0x39],di
    39ae:	80 00 00             	add    BYTE PTR [bx+si],0x0
    39b1:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
    39b5:	05 43 74             	add    ax,0x7443
    39b8:	6c                   	ins    BYTE PTR es:[di],dx
    39b9:	33 44 64             	xor    ax,WORD PTR [si+0x64]
    39bc:	00 e0                	add    al,ah
    39be:	39 3e 00 ff          	cmp    WORD PTR ds:0xff00,di
    39c2:	ff                   	(bad)
    39c3:	3e 00 ff             	ds add bh,bh
    39c6:	ff 01                	inc    WORD PTR [bx+di]
    39c8:	00 00                	add    BYTE PTR [bx+si],al
    39ca:	00 00                	add    BYTE PTR [bx+si],al
    39cc:	80 f4 ff             	xor    ah,0xff
    39cf:	ff                   	(bad)
    39d0:	ff 0a                	dec    WORD PTR [bp+si]
    39d2:	00 0a                	add    BYTE PTR [bp+si],cl
    39d4:	44                   	inc    sp
    39d5:	72 61                	jb     0x3a38
    39d7:	67 43                	addr32 inc bx
    39d9:	75 72                	jne    0x3a4d
    39db:	73 6f                	jae    0x3a4c
    39dd:	72 25                	jb     0x3a04
    39df:	01 09                	add    WORD PTR [bx+di],cx
    39e1:	3a 2e 00 ff          	cmp    ch,BYTE PTR ds:0xff00
    39e5:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    39e9:	ff 01                	inc    WORD PTR [bx+di]
    39eb:	00 00                	add    BYTE PTR [bx+si],al
    39ed:	00 00                	add    BYTE PTR [bx+si],al
    39ef:	80 00 00             	add    BYTE PTR [bx+si],0x0
    39f2:	00 00                	add    BYTE PTR [bx+si],al
    39f4:	0b 00                	or     ax,WORD PTR [bx+si]
    39f6:	08 44 72             	or     BYTE PTR [si+0x72],al
    39f9:	61                   	popa
    39fa:	67 4d                	addr32 dec bp
    39fc:	6f                   	outs   dx,WORD PTR ds:[si]
    39fd:	64 65 07             	fs gs pop es
    3a00:	23 62 3a             	and    sp,WORD PTR [bp+si+0x3a]
    3a03:	2a 00                	sub    al,BYTE PTR [bx+si]
    3a05:	ff                   	(bad)
    3a06:	ff                   	(bad)
    3a07:	b8 1c a2             	mov    ax,0xa21c
    3a0a:	3a 01                	cmp    al,BYTE PTR [bx+di]
    3a0c:	00 00                	add    BYTE PTR [bx+si],al
    3a0e:	00 00                	add    BYTE PTR [bx+si],al
    3a10:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3a13:	00 00                	add    BYTE PTR [bx+si],al
    3a15:	0c 00                	or     al,0x0
    3a17:	07                   	pop    es
    3a18:	45                   	inc    bp
    3a19:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a1a:	61                   	popa
    3a1b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    3a1e:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
    3a21:	3e 3a d8             	ds cmp bl,al
    3a24:	00 ff                	add    bh,bh
    3a26:	ff 31                	push   WORD PTR [bx+di]
    3a28:	84 6a 3a             	test   BYTE PTR [bp+si+0x3a],ch
    3a2b:	01 00                	add    WORD PTR [bx+si],ax
    3a2d:	00 00                	add    BYTE PTR [bx+si],al
    3a2f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    3a33:	00 00                	add    BYTE PTR [bx+si],al
    3a35:	0d 00 04             	or     ax,0x400
    3a38:	4b                   	dec    bx
    3a39:	69 6e 64 37 00       	imul   bp,WORD PTR [bp+0x64],0x37
    3a3e:	49                   	dec    cx
    3a3f:	3b e2                	cmp    sp,dx
    3a41:	00 ff                	add    bh,bh
    3a43:	ff e2                	jmp    dx
    3a45:	00 ff                	add    bh,bh
    3a47:	ff 01                	inc    WORD PTR [bx+di]
    3a49:	00 00                	add    BYTE PTR [bx+si],al
    3a4b:	00 00                	add    BYTE PTR [bx+si],al
    3a4d:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3a50:	00 00                	add    BYTE PTR [bx+si],al
    3a52:	0e                   	push   cs
    3a53:	00 0b                	add    BYTE PTR [bp+di],cl
    3a55:	4c                   	dec    sp
    3a56:	61                   	popa
    3a57:	72 67                	jb     0x3ac0
    3a59:	65 43                	gs inc bx
    3a5b:	68 61 6e             	push   0x6e61
    3a5e:	67 65 d4 22          	addr32 gs aam 0x22
    3a62:	7e 3a                	jle    0x3a9e
    3a64:	de 00                	fiadd  WORD PTR [bx+si]
    3a66:	ff                   	(bad)
    3a67:	ff a8 85 86          	jmp    DWORD PTR [bx+si-0x797b]
    3a6b:	3a 01                	cmp    al,BYTE PTR [bx+di]
    3a6d:	00 00                	add    BYTE PTR [bx+si],al
    3a6f:	00 00                	add    BYTE PTR [bx+si],al
    3a71:	80 64 00 00          	and    BYTE PTR [si+0x0],0x0
    3a75:	00 0f                	add    BYTE PTR [bx],cl
    3a77:	00 03                	add    BYTE PTR [bp+di],al
    3a79:	4d                   	dec    bp
    3a7a:	61                   	popa
    3a7b:	78 d4                	js     0x3a51
    3a7d:	22 9a 3a dc          	and    bl,BYTE PTR [bp+si-0x23c6]
    3a81:	00 ff                	add    bh,bh
    3a83:	ff 8a 85 0f          	dec    WORD PTR [bp+si+0xf85]
    3a87:	3b 01                	cmp    ax,WORD PTR [bx+di]
    3a89:	00 00                	add    BYTE PTR [bx+si],al
    3a8b:	00 00                	add    BYTE PTR [bx+si],al
    3a8d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3a90:	00 00                	add    BYTE PTR [bx+si],al
    3a92:	10 00                	adc    BYTE PTR [bx+si],al
    3a94:	03 4d 69             	add    cx,WORD PTR [di+0x69]
    3a97:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a98:	07                   	pop    es
    3a99:	23 be 3a a6          	and    di,WORD PTR [bp-0x59c6]
    3a9d:	00 ff                	add    bh,bh
    3a9f:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    3aa2:	c6                   	(bad)
    3aa3:	3a 01                	cmp    al,BYTE PTR [bx+di]
    3aa5:	00 00                	add    BYTE PTR [bx+si],al
    3aa7:	00 00                	add    BYTE PTR [bx+si],al
    3aa9:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3aac:	00 00                	add    BYTE PTR [bx+si],al
    3aae:	11 00                	adc    WORD PTR [bx+si],ax
    3ab0:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    3ab3:	72 65                	jb     0x3b1a
    3ab5:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ab6:	74 43                	je     0x3afb
    3ab8:	74 6c                	je     0x3b26
    3aba:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    3abd:	23 07                	and    ax,WORD PTR [bx]
    3abf:	3b 49 00             	cmp    cx,WORD PTR [bx+di+0x0]
    3ac2:	ff                   	(bad)
    3ac3:	ff a1 1e 30          	jmp    WORD PTR [bx+di+0x301e]
    3ac7:	3b 01                	cmp    ax,WORD PTR [bx+di]
    3ac9:	00 00                	add    BYTE PTR [bx+si],al
    3acb:	00 00                	add    BYTE PTR [bx+si],al
    3acd:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3ad0:	00 00                	add    BYTE PTR [bx+si],al
    3ad2:	12 00                	adc    al,BYTE PTR [bx+si]
    3ad4:	0e                   	push   cs
    3ad5:	50                   	push   ax
    3ad6:	61                   	popa
    3ad7:	72 65                	jb     0x3b3e
    3ad9:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ada:	74 53                	je     0x3b2f
    3adc:	68 6f 77             	push   0x776f
    3adf:	48                   	dec    ax
    3ae0:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    3ae5:	ff                   	(bad)
    3ae6:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    3ae9:	ff                   	(bad)
    3aea:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    3aed:	ff                   	(bad)
    3aee:	ff 01                	inc    WORD PTR [bx+di]
    3af0:	00 00                	add    BYTE PTR [bx+si],al
    3af2:	00 00                	add    BYTE PTR [bx+si],al
    3af4:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3af7:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    3afb:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    3afe:	70 75                	jo     0x3b75
    3b00:	70 4d                	jo     0x3b4f
    3b02:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3b04:	75 d4                	jne    0x3ada
    3b06:	22 28                	and    ch,BYTE PTR [bx+si]
    3b08:	3b da                	cmp    bx,dx
    3b0a:	00 ff                	add    bh,bh
    3b0c:	ff 6c 85             	jmp    DWORD PTR [si-0x7b]
    3b0f:	fb                   	sti
    3b10:	3c 01                	cmp    al,0x1
    3b12:	00 00                	add    BYTE PTR [bx+si],al
    3b14:	00 00                	add    BYTE PTR [bx+si],al
    3b16:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3b19:	00 00                	add    BYTE PTR [bx+si],al
    3b1b:	14 00                	adc    al,0x0
    3b1d:	08 50 6f             	or     BYTE PTR [bx+si+0x6f],dl
    3b20:	73 69                	jae    0x3b8b
    3b22:	74 69                	je     0x3b8d
    3b24:	6f                   	outs   dx,WORD PTR ds:[si]
    3b25:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b26:	07                   	pop    es
    3b27:	23 8e 3b 48          	and    cx,WORD PTR [bp+0x483b]
    3b2b:	00 ff                	add    bh,bh
    3b2d:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    3b30:	34 3b                	xor    al,0x3b
    3b32:	23 1e 6d 3b          	and    bx,WORD PTR ds:0x3b6d
    3b36:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    3b3a:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
    3b3e:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    3b41:	6f                   	outs   dx,WORD PTR ds:[si]
    3b42:	77 48                	ja     0x3b8c
    3b44:	69 6e 74 37 00       	imul   bp,WORD PTR [bp+0x74],0x37
    3b49:	cc                   	int3
    3b4a:	41                   	inc    cx
    3b4b:	e0 00                	loopne 0x3b4d
    3b4d:	ff                   	(bad)
    3b4e:	ff e0                	jmp    ax
    3b50:	00 ff                	add    bh,bh
    3b52:	ff 01                	inc    WORD PTR [bx+di]
    3b54:	00 00                	add    BYTE PTR [bx+si],al
    3b56:	00 00                	add    BYTE PTR [bx+si],al
    3b58:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3b5b:	00 00                	add    BYTE PTR [bx+si],al
    3b5d:	16                   	push   ss
    3b5e:	00 0b                	add    BYTE PTR [bp+di],cl
    3b60:	53                   	push   bx
    3b61:	6d                   	ins    WORD PTR es:[di],dx
    3b62:	61                   	popa
    3b63:	6c                   	ins    BYTE PTR es:[di],dx
    3b64:	6c                   	ins    BYTE PTR es:[di],dx
    3b65:	43                   	inc    bx
    3b66:	68 61 6e             	push   0x6e61
    3b69:	67 65 52             	addr32 gs push dx
    3b6c:	01 71 3b             	add    WORD PTR [bx+di+0x3b],si
    3b6f:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    3b70:	63 75 3b             	arpl   WORD PTR [di+0x3b],si
    3b73:	60                   	pusha
    3b74:	64 96                	fs xchg si,ax
    3b76:	3b 01                	cmp    ax,WORD PTR [bx+di]
    3b78:	00 00                	add    BYTE PTR [bx+si],al
    3b7a:	00 00                	add    BYTE PTR [bx+si],al
    3b7c:	80 ff ff             	cmp    bh,0xff
    3b7f:	ff                   	(bad)
    3b80:	ff 17                	call   WORD PTR [bx]
    3b82:	00 08                	add    BYTE PTR [bx+si],cl
    3b84:	54                   	push   sp
    3b85:	61                   	popa
    3b86:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    3b89:	64 65 72 07          	fs gs jb 0x3b94
    3b8d:	23 ae 3b a4          	and    bp,WORD PTR [bp-0x5bc5]
    3b91:	00 ff                	add    bh,bh
    3b93:	ff 88 64 b6          	dec    WORD PTR [bx+si-0x499c]
    3b97:	3b 01                	cmp    ax,WORD PTR [bx+di]
    3b99:	00 00                	add    BYTE PTR [bx+si],al
    3b9b:	00 00                	add    BYTE PTR [bx+si],al
    3b9d:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3ba0:	00 00                	add    BYTE PTR [bx+si],al
    3ba2:	18 00                	sbb    BYTE PTR [bx+si],al
    3ba4:	07                   	pop    es
    3ba5:	54                   	push   sp
    3ba6:	61                   	popa
    3ba7:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    3baa:	6f                   	outs   dx,WORD PTR ds:[si]
    3bab:	70 07                	jo     0x3bb4
    3bad:	23 38                	and    di,WORD PTR [bx+si]
    3baf:	3d 29 00             	cmp    ax,0x29
    3bb2:	ff                   	(bad)
    3bb3:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    3bb6:	ef                   	out    dx,ax
    3bb7:	3b 01                	cmp    ax,WORD PTR [bx+di]
    3bb9:	00 00                	add    BYTE PTR [bx+si],al
    3bbb:	00 00                	add    BYTE PTR [bx+si],al
    3bbd:	80 01 00             	add    BYTE PTR [bx+di],0x0
    3bc0:	00 00                	add    BYTE PTR [bx+si],al
    3bc2:	19 00                	sbb    WORD PTR [bx+si],ax
    3bc4:	07                   	pop    es
    3bc5:	56                   	push   si
    3bc6:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    3bcb:	65 71 00             	gs jno 0x3bce
    3bce:	57                   	push   di
    3bcf:	3c e4                	cmp    al,0xe4
    3bd1:	00 ff                	add    bh,bh
    3bd3:	ff e4                	jmp    sp
    3bd5:	00 ff                	add    bh,bh
    3bd7:	ff 01                	inc    WORD PTR [bx+di]
    3bd9:	00 00                	add    BYTE PTR [bx+si],al
    3bdb:	00 00                	add    BYTE PTR [bx+si],al
    3bdd:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3be0:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
    3be4:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
    3be7:	43                   	inc    bx
    3be8:	68 61 6e             	push   0x6e61
    3beb:	67 65 ea 02 12 3c 62 	addr32 gs jmp 0x623c:0x1202
    3bf2:	00 ff                	add    bh,bh
    3bf4:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    3bf7:	ff                   	(bad)
    3bf8:	ff 01                	inc    WORD PTR [bx+di]
    3bfa:	00 00                	add    BYTE PTR [bx+si],al
    3bfc:	00 00                	add    BYTE PTR [bx+si],al
    3bfe:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3c01:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
    3c05:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    3c08:	44                   	inc    sp
    3c09:	72 61                	jb     0x3c6c
    3c0b:	67 44                	addr32 inc sp
    3c0d:	72 6f                	jb     0x3c7e
    3c0f:	70 80                	jo     0x3b91
    3c11:	02 35                	add    dh,BYTE PTR [di]
    3c13:	3c 6a                	cmp    al,0x6a
    3c15:	00 ff                	add    bh,bh
    3c17:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    3c1a:	ff                   	(bad)
    3c1b:	ff 01                	inc    WORD PTR [bx+di]
    3c1d:	00 00                	add    BYTE PTR [bx+si],al
    3c1f:	00 00                	add    BYTE PTR [bx+si],al
    3c21:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3c24:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    3c28:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    3c2b:	44                   	inc    sp
    3c2c:	72 61                	jb     0x3c8f
    3c2e:	67 4f                	addr32 dec di
    3c30:	76 65                	jbe    0x3c97
    3c32:	72 32                	jb     0x3c66
    3c34:	03 96 3c 72          	add    dx,WORD PTR [bp+0x723c]
    3c38:	00 ff                	add    bh,bh
    3c3a:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    3c3d:	ff                   	(bad)
    3c3e:	ff 01                	inc    WORD PTR [bx+di]
    3c40:	00 00                	add    BYTE PTR [bx+si],al
    3c42:	00 00                	add    BYTE PTR [bx+si],al
    3c44:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3c47:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    3c4b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    3c4e:	45                   	inc    bp
    3c4f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c50:	64 44                	fs inc sp
    3c52:	72 61                	jb     0x3cb5
    3c54:	67 71 00             	addr32 jno 0x3c57
    3c57:	77 3c                	ja     0x3c95
    3c59:	c8 00 ff ff          	enter  0xff00,0xff
    3c5d:	c8 00 ff ff          	enter  0xff00,0xff
    3c61:	01 00                	add    WORD PTR [bx+si],ax
    3c63:	00 00                	add    BYTE PTR [bx+si],al
    3c65:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    3c69:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    3c6d:	07                   	pop    es
    3c6e:	4f                   	dec    di
    3c6f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c70:	45                   	inc    bp
    3c71:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c72:	74 65                	je     0x3cd9
    3c74:	72 71                	jb     0x3ce7
    3c76:	00 40 3d             	add    BYTE PTR [bx+si+0x3d],al
    3c79:	d0 00                	rol    BYTE PTR [bx+si],1
    3c7b:	ff                   	(bad)
    3c7c:	ff d0                	call   ax
    3c7e:	00 ff                	add    bh,bh
    3c80:	ff 01                	inc    WORD PTR [bx+di]
    3c82:	00 00                	add    BYTE PTR [bx+si],al
    3c84:	00 00                	add    BYTE PTR [bx+si],al
    3c86:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3c89:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    3c8d:	06                   	push   es
    3c8e:	4f                   	dec    di
    3c8f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c90:	45                   	inc    bp
    3c91:	78 69                	js     0x3cfc
    3c93:	74 1a                	je     0x3caf
    3c95:	02 b8 3c b0          	add    bh,BYTE PTR [bx+si-0x4fc4]
    3c99:	00 ff                	add    bh,bh
    3c9b:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    3c9f:	ff 01                	inc    WORD PTR [bx+di]
    3ca1:	00 00                	add    BYTE PTR [bx+si],al
    3ca3:	00 00                	add    BYTE PTR [bx+si],al
    3ca5:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3ca8:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    3cac:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    3caf:	4b                   	dec    bx
    3cb0:	65 79 44             	gs jns 0x3cf7
    3cb3:	6f                   	outs   dx,WORD PTR ds:[si]
    3cb4:	77 6e                	ja     0x3d24
    3cb6:	54                   	push   sp
    3cb7:	02 db                	add    bl,bl
    3cb9:	3c b8                	cmp    al,0xb8
    3cbb:	00 ff                	add    bh,bh
    3cbd:	ff                   	(bad)
    3cbe:	b8 00 ff             	mov    ax,0xff00
    3cc1:	ff 01                	inc    WORD PTR [bx+di]
    3cc3:	00 00                	add    BYTE PTR [bx+si],al
    3cc5:	00 00                	add    BYTE PTR [bx+si],al
    3cc7:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3cca:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    3cce:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    3cd1:	4b                   	dec    bx
    3cd2:	65 79 50             	gs jns 0x3d25
    3cd5:	72 65                	jb     0x3d3c
    3cd7:	73 73                	jae    0x3d4c
    3cd9:	1a 02                	sbb    al,BYTE PTR [bp+si]
    3cdb:	42                   	inc    dx
    3cdc:	3f                   	aas
    3cdd:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
    3ce0:	ff c0                	inc    ax
    3ce2:	00 ff                	add    bh,bh
    3ce4:	ff 01                	inc    WORD PTR [bx+di]
    3ce6:	00 00                	add    BYTE PTR [bx+si],al
    3ce8:	00 00                	add    BYTE PTR [bx+si],al
    3cea:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3ced:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    3cf1:	07                   	pop    es
    3cf2:	4f                   	dec    di
    3cf3:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cf4:	4b                   	dec    bx
    3cf5:	65 79 55             	gs jns 0x3d4d
    3cf8:	70 70                	jo     0x3d6a
    3cfa:	38 48 3d             	cmp    BYTE PTR [bx+si+0x3d],cl
    3cfd:	ec                   	in     al,dx
    3cfe:	00 ff                	add    bh,bh
    3d00:	ff                   	jmp    (bad)
    3d01:	ec                   	in     al,dx
    3d02:	00 ff                	add    bh,bh
    3d04:	ff 01                	inc    WORD PTR [bx+di]
    3d06:	00 00                	add    BYTE PTR [bx+si],al
    3d08:	00 00                	add    BYTE PTR [bx+si],al
    3d0a:	80 00 00             	add    BYTE PTR [bx+si],0x0
    3d0d:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    3d11:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
    3d14:	53                   	push   bx
    3d15:	63 72 6f             	arpl   WORD PTR [bp+si+0x6f],si
    3d18:	6c                   	ins    BYTE PTR es:[di],dx
    3d19:	6c                   	ins    BYTE PTR es:[di],dx
    3d1a:	9f                   	lahf
    3d1b:	3d 00 00             	cmp    ax,0x0
    3d1e:	00 00                	add    BYTE PTR [bx+si],al
    3d20:	00 00                	add    BYTE PTR [bx+si],al
    3d22:	92                   	xchg   dx,ax
    3d23:	3d 0a 00             	cmp    ax,0xa
    3d26:	2a 03                	sub    al,BYTE PTR [bp+di]
    3d28:	b3 3d                	mov    bl,0x3d
    3d2a:	64 20 e0             	fs and al,ah
    3d2d:	3d 9a 1f             	cmp    ax,0x1f9a
    3d30:	2c 3d                	sub    al,0x3d
    3d32:	cb                   	retf
    3d33:	1f                   	pop    ds
    3d34:	30 3d                	xor    BYTE PTR [di],bh
    3d36:	66 1f                	popd   ds
    3d38:	34 3d                	xor    al,0x3d
    3d3a:	cd 11                	int    0x11
    3d3c:	28 3d                	sub    BYTE PTR [di],bh
    3d3e:	f0 13 50 3d          	lock adc dx,WORD PTR [bx+si+0x3d]
    3d42:	48                   	dec    ax
    3d43:	13 74 3d             	adc    si,WORD PTR [si+0x3d]
    3d46:	4a                   	dec    dx
    3d47:	4e                   	dec    si
    3d48:	4c                   	dec    sp
    3d49:	3d dc 4d             	cmp    ax,0x4ddc
    3d4c:	54                   	push   sp
    3d4d:	3d 03 15             	cmp    ax,0x1503
    3d50:	58                   	pop    ax
    3d51:	3d 83 4e             	cmp    ax,0x4e83
    3d54:	5c                   	pop    sp
    3d55:	3d d8 19             	cmp    ax,0x19d8
    3d58:	60                   	pusha
    3d59:	3d 77 51             	cmp    ax,0x5177
    3d5c:	6c                   	ins    BYTE PTR es:[di],dx
    3d5d:	3d 4a 12             	cmp    ax,0x124a
    3d60:	64 3d 78 12          	fs cmp ax,0x1278
    3d64:	68 3d b2             	push   0xb23d
    3d67:	12 44 3d             	adc    al,BYTE PTR [si+0x3d]
    3d6a:	62 51 70             	bound  dx,DWORD PTR [bx+di+0x70]
    3d6d:	3d 91 50             	cmp    ax,0x5091
    3d70:	80 3d 55             	cmp    BYTE PTR [di],0x55
    3d73:	14 78                	adc    al,0x78
    3d75:	3d 13 16             	cmp    ax,0x1613
    3d78:	7c 3d                	jl     0x3db7
    3d7a:	e0 16                	loopne 0x3d92
    3d7c:	88 3d                	mov    BYTE PTR [di],bh
    3d7e:	32 4f 84             	xor    cl,BYTE PTR [bx-0x7c]
    3d81:	3d 08 52             	cmp    ax,0x5208
    3d84:	8c 3d                	mov    WORD PTR [di],?
    3d86:	24 19                	and    al,0x19
    3d88:	90                   	nop
    3d89:	3d 9c 53             	cmp    ax,0x539c
    3d8c:	af                   	scas   ax,WORD PTR es:[di]
    3d8d:	3d ac 1b             	cmp    ax,0x1bac
    3d90:	3c 3d                	cmp    al,0x3d
    3d92:	0c 54                	or     al,0x54
    3d94:	4d                   	dec    bp
    3d95:	65 6d                	gs ins WORD PTR es:[di],dx
    3d97:	6f                   	outs   dx,WORD PTR ds:[si]
    3d98:	53                   	push   bx
    3d99:	74 72                	je     0x3e0d
    3d9b:	69 6e 67 73 07       	imul   bp,WORD PTR [bp+0x67],0x773
    3da0:	0c 54                	or     al,0x54
    3da2:	4d                   	dec    bp
    3da3:	65 6d                	gs ins WORD PTR es:[di],dx
    3da5:	6f                   	outs   dx,WORD PTR ds:[si]
    3da6:	53                   	push   bx
    3da7:	74 72                	je     0x3e1b
    3da9:	69 6e 67 73 3a       	imul   bp,WORD PTR [bp+0x67],0x3a73
    3dae:	3d f0 3d             	cmp    ax,0x3df0
    3db1:	8b 03                	mov    ax,WORD PTR [bp+di]
    3db3:	e8 3d 00             	call   0x3df3
    3db6:	00 08                	add    BYTE PTR [bx+si],cl
    3db8:	53                   	push   bx
    3db9:	74 64                	je     0x3e1f
    3dbb:	43                   	inc    bx
    3dbc:	74 72                	je     0x3e30
    3dbe:	6c                   	ins    BYTE PTR es:[di],dx
    3dbf:	73 00                	jae    0x3dc1
    3dc1:	00 4b 3e             	add    BYTE PTR [bp+di+0x3e],cl
    3dc4:	00 00                	add    BYTE PTR [bx+si],al
    3dc6:	00 00                	add    BYTE PTR [bx+si],al
    3dc8:	00 00                	add    BYTE PTR [bx+si],al
    3dca:	3a 3e 0a 00          	cmp    bh,BYTE PTR ds:0xa
    3dce:	2a 03                	sub    al,BYTE PTR [bp+di]
    3dd0:	63 3e 64 20          	arpl   WORD PTR ds:0x2064,di
    3dd4:	90                   	nop
    3dd5:	3e 9a 1f d4 3d cb    	ds call 0xcb3d:0xd41f
    3ddb:	1f                   	pop    ds
    3ddc:	d8 3d                	fdivr  DWORD PTR [di]
    3dde:	66 1f                	popd   ds
    3de0:	dc 3d                	fdivr  QWORD PTR [di]
    3de2:	cd 11                	int    0x11
    3de4:	d0 3d                	sar    BYTE PTR [di],1
    3de6:	f0 13 fc             	lock adc di,sp
    3de9:	3d 48 13             	cmp    ax,0x1348
    3dec:	1c 3e                	sbb    al,0x3e
    3dee:	f8                   	clc
    3def:	57                   	push   di
    3df0:	f4                   	hlt
    3df1:	3d cd 57             	cmp    ax,0x57cd
    3df4:	f8                   	clc
    3df5:	3d 49 58             	cmp    ax,0x5849
    3df8:	00 3e 94 19          	add    BYTE PTR ds:0x1994,bh
    3dfc:	0c 3e                	or     al,0x3e
    3dfe:	7b 58                	jnp    0x3e58
    3e00:	04 3e                	add    al,0x3e
    3e02:	e0 59                	loopne 0x3e5d
    3e04:	08 3e a2 58          	or     BYTE PTR ds:0x58a2,bh
    3e08:	14 3e                	adc    al,0x3e
    3e0a:	78 12                	js     0x3e1e
    3e0c:	10 3e b2 12          	adc    BYTE PTR ds:0x12b2,bh
    3e10:	ec                   	in     al,dx
    3e11:	3d 90 59             	cmp    ax,0x5990
    3e14:	18 3e 6b 59          	sbb    BYTE PTR ds:0x596b,bh
    3e18:	28 3e 55 14          	sub    BYTE PTR ds:0x1455,bh
    3e1c:	20 3e 13 16          	and    BYTE PTR ds:0x1613,bh
    3e20:	24 3e                	and    al,0x3e
    3e22:	e0 16                	loopne 0x3e3a
    3e24:	2c 3e                	sub    al,0x3e
    3e26:	06                   	push   es
    3e27:	59                   	pop    cx
    3e28:	5f                   	pop    di
    3e29:	3e 78 17             	ds js  0x3e43
    3e2c:	30 3e 24 19          	xor    BYTE PTR ds:0x1924,bh
    3e30:	34 3e                	xor    al,0x3e
    3e32:	39 1a                	cmp    WORD PTR [bp+si],bx
    3e34:	38 3e ac 1b          	cmp    BYTE PTR ds:0x1bac,bh
    3e38:	e4 3d                	in     al,0x3d
    3e3a:	10 54 43             	adc    BYTE PTR [si+0x43],dl
    3e3d:	6f                   	outs   dx,WORD PTR ds:[si]
    3e3e:	6d                   	ins    WORD PTR es:[di],dx
    3e3f:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    3e42:	6f                   	outs   dx,WORD PTR ds:[si]
    3e43:	78 53                	js     0x3e98
    3e45:	74 72                	je     0x3eb9
    3e47:	69 6e 67 73 07       	imul   bp,WORD PTR [bp+0x67],0x773
    3e4c:	10 54 43             	adc    BYTE PTR [si+0x43],dl
    3e4f:	6f                   	outs   dx,WORD PTR ds:[si]
    3e50:	6d                   	ins    WORD PTR es:[di],dx
    3e51:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
    3e54:	6f                   	outs   dx,WORD PTR ds:[si]
    3e55:	78 53                	js     0x3eaa
    3e57:	74 72                	je     0x3ecb
    3e59:	69 6e 67 73 e2       	imul   bp,WORD PTR [bp+0x67],0xe273
    3e5e:	3d a0 3e             	cmp    ax,0x3ea0
    3e61:	8b 03                	mov    ax,WORD PTR [bp+di]
    3e63:	98                   	cbw
    3e64:	3e 00 00             	add    BYTE PTR ds:[bx+si],al
    3e67:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
    3e6a:	64 43                	fs inc bx
    3e6c:	74 72                	je     0x3ee0
    3e6e:	6c                   	ins    BYTE PTR es:[di],dx
    3e6f:	73 00                	jae    0x3e71
    3e71:	00 fa                	add    dl,bh
    3e73:	3e 00 00             	add    BYTE PTR ds:[bx+si],al
    3e76:	00 00                	add    BYTE PTR [bx+si],al
    3e78:	00 00                	add    BYTE PTR [bx+si],al
    3e7a:	ea 3e 0a 00 2a       	jmp    0x2a00:0xa3e
    3e7f:	03 11                	add    dx,WORD PTR [bx+di]
    3e81:	3f                   	aas
    3e82:	64 20 2f             	and    BYTE PTR fs:[bx],ch
    3e85:	3f                   	aas
    3e86:	9a 1f 84 3e cb       	call   0xcb3e:0x841f
    3e8b:	1f                   	pop    ds
    3e8c:	88 3e 66 1f          	mov    BYTE PTR ds:0x1f66,bh
    3e90:	8c 3e cd 11          	mov    WORD PTR ds:0x11cd,?
    3e94:	80 3e f0 13 ac       	cmp    BYTE PTR ds:0x13f0,0xac
    3e99:	3e 48                	ds dec ax
    3e9b:	13 cc                	adc    cx,sp
    3e9d:	3e 8d 73 a4          	lea    si,ds:[bp+di-0x5c]
    3ea1:	3e 62 73 a8          	bound  si,DWORD PTR ds:[bp+di-0x58]
    3ea5:	3e 00 74 b0          	add    BYTE PTR ds:[si-0x50],dh
    3ea9:	3e 94                	ds xchg sp,ax
    3eab:	19 bc 3e 63          	sbb    WORD PTR [si+0x633e],di
    3eaf:	74 b4                	je     0x3e65
    3eb1:	3e 9c                	ds pushf
    3eb3:	75 b8                	jne    0x3e6d
    3eb5:	3e 8a 74 c4          	mov    dh,BYTE PTR ds:[si-0x3c]
    3eb9:	3e 78 12             	ds js  0x3ece
    3ebc:	c0 3e b2 12 9c       	sar    BYTE PTR ds:0x12b2,0x9c
    3ec1:	3e 78 75             	ds js  0x3f39
    3ec4:	c8 3e 53 75          	enter  0x533e,0x75
    3ec8:	d8 3e 55 14          	fdivr  DWORD PTR ds:0x1455
    3ecc:	d0 3e 13 16          	sar    BYTE PTR ds:0x1613,1
    3ed0:	d4 3e                	aam    0x3e
    3ed2:	e0 16                	loopne 0x3eea
    3ed4:	dc 3e ee 74          	fdivr  QWORD PTR ds:0x74ee
    3ed8:	0d 3f 78             	or     ax,0x783f
    3edb:	17                   	pop    ss
    3edc:	e0 3e                	loopne 0x3f1c
    3ede:	24 19                	and    al,0x19
    3ee0:	e4 3e                	in     al,0x3e
    3ee2:	39 1a                	cmp    WORD PTR [bp+si],bx
    3ee4:	e8 3e ac             	call   0xeb25
    3ee7:	1b 94 3e 0f          	sbb    dx,WORD PTR [si+0xf3e]
    3eeb:	54                   	push   sp
    3eec:	4c                   	dec    sp
    3eed:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
    3ef2:	78 53                	js     0x3f47
    3ef4:	74 72                	je     0x3f68
    3ef6:	69 6e 67 73 07       	imul   bp,WORD PTR [bp+0x67],0x773
    3efb:	0f 54 4c 69          	andps  xmm1,XMMWORD PTR [si+0x69]
    3eff:	73 74                	jae    0x3f75
    3f01:	42                   	inc    dx
    3f02:	6f                   	outs   dx,WORD PTR ds:[si]
    3f03:	78 53                	js     0x3f58
    3f05:	74 72                	je     0x3f79
    3f07:	69 6e 67 73 92       	imul   bp,WORD PTR [bp+0x67],0x9273
    3f0c:	3e ad                	lods   ax,WORD PTR ds:[si]
    3f0e:	43                   	inc    bx
    3f0f:	8b 03                	mov    ax,WORD PTR [bp+di]
    3f11:	4e                   	dec    si
    3f12:	40                   	inc    ax
    3f13:	00 00                	add    BYTE PTR [bx+si],al
    3f15:	08 53 74             	or     BYTE PTR [bp+di+0x74],dl
    3f18:	64 43                	fs inc bx
    3f1a:	74 72                	je     0x3f8e
    3f1c:	6c                   	ins    BYTE PTR es:[di],dx
    3f1d:	73 00                	jae    0x3f1f
    3f1f:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3f22:	e5 80                	in     ax,0x80
    3f24:	7e 0a                	jle    0x3f30
    3f26:	00 74 08             	add    BYTE PTR [si+0x8],dh
    3f29:	83 ec 08             	sub    sp,0x8
    3f2c:	9a e2 1f 5a 40       	call   0x405a:0x1fe2
    3f31:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3f34:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3f37:	31 c0                	xor    ax,ax
    3f39:	50                   	push   ax
    3f3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f3d:	06                   	push   es
    3f3e:	57                   	push   di
    3f3f:	9a 72 6c 55 3f       	call   0x3f55:0x6c72
    3f44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f47:	26 c7 45 26 ab 00    	mov    WORD PTR es:[di+0x26],0xab
    3f4d:	68 b9 00             	push   0xb9
    3f50:	06                   	push   es
    3f51:	57                   	push   di
    3f52:	9a bf 17 61 3f       	call   0x3f61:0x17bf
    3f57:	6a 69                	push   0x69
    3f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f5c:	06                   	push   es
    3f5d:	57                   	push   di
    3f5e:	9a e1 17 e8 3f       	call   0x3fe8:0x17e1
    3f63:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3f67:	74 07                	je     0x3f70
    3f69:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3f6d:	83 c4 06             	add    sp,0x6
    3f70:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3f73:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3f76:	c9                   	leave
    3f77:	ca 0a 00             	retf   0xa
    3f7a:	01 30                	add    WORD PTR [bx+si],si
    3f7c:	55                   	push   bp
    3f7d:	89 e5                	mov    bp,sp
    3f7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f82:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3f86:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3f8a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3f8f:	06                   	push   es
    3f90:	57                   	push   di
    3f91:	9a 99 20 a8 3f       	call   0x3fa8:0x2099
    3f96:	bf 7a 3f             	mov    di,0x3f7a
    3f99:	0e                   	push   cs
    3f9a:	57                   	push   di
    3f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f9e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3fa3:	06                   	push   es
    3fa4:	57                   	push   di
    3fa5:	9a 4e 20 18 40       	call   0x4018:0x204e
    3faa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fad:	26 01 45 02          	add    WORD PTR es:[di+0x2],ax
    3fb1:	06                   	push   es
    3fb2:	57                   	push   di
    3fb3:	6a ff                	push   0xffff
    3fb5:	6a ff                	push   0xffff
    3fb7:	9a d1 3f 00 00       	call   0x0:0x3fd1
    3fbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fbf:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    3fc5:	74 0e                	je     0x3fd5
    3fc7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fca:	06                   	push   es
    3fcb:	57                   	push   di
    3fcc:	6a ff                	push   0xffff
    3fce:	6a ff                	push   0xffff
    3fd0:	9a ff ff 00 00       	call   0x0:0xffff
    3fd5:	ff 76 10             	push   WORD PTR [bp+0x10]
    3fd8:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3fdb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fde:	06                   	push   es
    3fdf:	57                   	push   di
    3fe0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fe3:	06                   	push   es
    3fe4:	57                   	push   di
    3fe5:	9a c2 35 ea 40       	call   0x40ea:0x35c2
    3fea:	c9                   	leave
    3feb:	ca 0c 00             	retf   0xc
    3fee:	01 30                	add    WORD PTR [bx+si],si
    3ff0:	c8 10 02 00          	enter  0x210,0x0
    3ff4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ff7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3ffc:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    4000:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    4004:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4007:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    400b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    400f:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4013:	06                   	push   es
    4014:	57                   	push   di
    4015:	9a 99 20 28 40       	call   0x4028:0x2099
    401a:	bf ee 3f             	mov    di,0x3fee
    401d:	0e                   	push   cs
    401e:	57                   	push   di
    401f:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4023:	06                   	push   es
    4024:	57                   	push   di
    4025:	9a 4e 20 7e 40       	call   0x407e:0x204e
    402a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    402d:	8d be e8 fe          	lea    di,[bp-0x118]
    4031:	16                   	push   ss
    4032:	57                   	push   di
    4033:	6a 00                	push   0x0
    4035:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4038:	99                   	cwd
    4039:	b9 02 00             	mov    cx,0x2
    403c:	f7 f9                	idiv   cx
    403e:	48                   	dec    ax
    403f:	50                   	push   ax
    4040:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4043:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    4047:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    404b:	9a 88 06 37 41       	call   0x4137:0x688
    4050:	8d 7e f6             	lea    di,[bp-0xa]
    4053:	16                   	push   ss
    4054:	57                   	push   di
    4055:	6a 08                	push   0x8
    4057:	9a 1b 16 43 41       	call   0x4143:0x161b
    405c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    405f:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    4065:	74 4c                	je     0x40b3
    4067:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    406a:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    406d:	6a ff                	push   0xffff
    406f:	6a eb                	push   0xffeb
    4071:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4075:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    4079:	06                   	push   es
    407a:	57                   	push   di
    407b:	9a 84 16 8e 40       	call   0x408e:0x1684
    4080:	8d 7e f6             	lea    di,[bp-0xa]
    4083:	16                   	push   ss
    4084:	57                   	push   di
    4085:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4089:	06                   	push   es
    408a:	57                   	push   di
    408b:	9a 30 1d af 40       	call   0x40af:0x1d30
    4090:	8d 7e f6             	lea    di,[bp-0xa]
    4093:	16                   	push   ss
    4094:	57                   	push   di
    4095:	6a ff                	push   0xffff
    4097:	6a ff                	push   0xffff
    4099:	9a ff ff 00 00       	call   0x0:0xffff
    409e:	6a ff                	push   0xffff
    40a0:	6a ef                	push   0xffef
    40a2:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    40a6:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    40aa:	06                   	push   es
    40ab:	57                   	push   di
    40ac:	9a 84 16 c4 40       	call   0x40c4:0x1684
    40b1:	eb 13                	jmp    0x40c6
    40b3:	6a ff                	push   0xffff
    40b5:	6a f9                	push   0xfff9
    40b7:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    40bb:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    40bf:	06                   	push   es
    40c0:	57                   	push   di
    40c1:	9a 84 16 d4 40       	call   0x40d4:0x1684
    40c6:	8d 7e f6             	lea    di,[bp-0xa]
    40c9:	16                   	push   ss
    40ca:	57                   	push   di
    40cb:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    40cf:	06                   	push   es
    40d0:	57                   	push   di
    40d1:	9a 30 1d 4e 41       	call   0x414e:0x1d30
    40d6:	8d be f6 fe          	lea    di,[bp-0x10a]
    40da:	16                   	push   ss
    40db:	57                   	push   di
    40dc:	8d be f0 fd          	lea    di,[bp-0x210]
    40e0:	16                   	push   ss
    40e1:	57                   	push   di
    40e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e5:	06                   	push   es
    40e6:	57                   	push   di
    40e7:	9a 53 1d 0f 41       	call   0x410f:0x1d53
    40ec:	9a 4c 0d 14 41       	call   0x4114:0xd4c
    40f1:	80 be f6 fe 00       	cmp    BYTE PTR [bp-0x10a],0x0
    40f6:	75 03                	jne    0x40fb
    40f8:	e9 a9 00             	jmp    0x41a4
    40fb:	8d be f6 fe          	lea    di,[bp-0x10a]
    40ff:	16                   	push   ss
    4100:	57                   	push   di
    4101:	8d be f0 fd          	lea    di,[bp-0x210]
    4105:	16                   	push   ss
    4106:	57                   	push   di
    4107:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    410a:	06                   	push   es
    410b:	57                   	push   di
    410c:	9a 53 1d c7 41       	call   0x41c7:0x1d53
    4111:	9a 4c 0d 1f 41       	call   0x411f:0xd4c
    4116:	8d be f6 fe          	lea    di,[bp-0x10a]
    411a:	16                   	push   ss
    411b:	57                   	push   di
    411c:	9a 8c 0c 15 43       	call   0x4315:0xc8c
    4121:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    4125:	8d be e8 fe          	lea    di,[bp-0x118]
    4129:	16                   	push   ss
    412a:	57                   	push   di
    412b:	6a 08                	push   0x8
    412d:	6a 00                	push   0x0
    412f:	6a 00                	push   0x0
    4131:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4134:	9a 88 06 14 52       	call   0x5214:0x688
    4139:	8d 7e f6             	lea    di,[bp-0xa]
    413c:	16                   	push   ss
    413d:	57                   	push   di
    413e:	6a 08                	push   0x8
    4140:	9a 1b 16 68 42       	call   0x4268:0x161b
    4145:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4149:	06                   	push   es
    414a:	57                   	push   di
    414b:	9a d2 21 80 41       	call   0x4180:0x21d2
    4150:	50                   	push   ax
    4151:	8d be f6 fe          	lea    di,[bp-0x10a]
    4155:	16                   	push   ss
    4156:	57                   	push   di
    4157:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    415b:	8d 7e f6             	lea    di,[bp-0xa]
    415e:	16                   	push   ss
    415f:	57                   	push   di
    4160:	68 20 04             	push   0x420
    4163:	9a a0 41 00 00       	call   0x0:0x41a0
    4168:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    416b:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    416f:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    4173:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4177:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    417b:	06                   	push   es
    417c:	57                   	push   di
    417d:	9a 84 16 8b 41       	call   0x418b:0x1684
    4182:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    4186:	06                   	push   es
    4187:	57                   	push   di
    4188:	9a d2 21 40 43       	call   0x4340:0x21d2
    418d:	50                   	push   ax
    418e:	8d be f6 fe          	lea    di,[bp-0x10a]
    4192:	16                   	push   ss
    4193:	57                   	push   di
    4194:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    4198:	8d 7e f6             	lea    di,[bp-0xa]
    419b:	16                   	push   ss
    419c:	57                   	push   di
    419d:	6a 20                	push   0x20
    419f:	9a 8b 43 00 00       	call   0x0:0x438b
    41a4:	c9                   	leave
    41a5:	ca 04 00             	retf   0x4
    41a8:	c8 04 01 00          	enter  0x104,0x0
    41ac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    41af:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    41b2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    41b5:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    41b9:	8d be fc fe          	lea    di,[bp-0x104]
    41bd:	16                   	push   ss
    41be:	57                   	push   di
    41bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41c2:	06                   	push   es
    41c3:	57                   	push   di
    41c4:	9a 53 1d da 41       	call   0x41da:0x1d53
    41c9:	9a 3f 17 c8 46       	call   0x46c8:0x173f
    41ce:	08 c0                	or     al,al
    41d0:	74 29                	je     0x41fb
    41d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41d5:	06                   	push   es
    41d6:	57                   	push   di
    41d7:	9a c4 61 e8 41       	call   0x41e8:0x61c4
    41dc:	08 c0                	or     al,al
    41de:	74 1b                	je     0x41fb
    41e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41e3:	06                   	push   es
    41e4:	57                   	push   di
    41e5:	9a 11 68 09 42       	call   0x4209:0x6811
    41ea:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    41ed:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    41f3:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    41f9:	eb 10                	jmp    0x420b
    41fb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    41fe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4201:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4204:	06                   	push   es
    4205:	57                   	push   di
    4206:	9a 26 56 26 42       	call   0x4226:0x5626
    420b:	c9                   	leave
    420c:	ca 08 00             	retf   0x8
    420f:	55                   	push   bp
    4210:	89 e5                	mov    bp,sp
    4212:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4215:	06                   	push   es
    4216:	57                   	push   di
    4217:	26 c4 3d             	les    di,DWORD PTR es:[di]
    421a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    421e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4221:	06                   	push   es
    4222:	57                   	push   di
    4223:	9a f9 36 3d 42       	call   0x423d:0x36f9
    4228:	c9                   	leave
    4229:	ca 08 00             	retf   0x8
    422c:	55                   	push   bp
    422d:	89 e5                	mov    bp,sp
    422f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4232:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4238:	06                   	push   es
    4239:	57                   	push   di
    423a:	9a d8 57 53 42       	call   0x4253:0x57d8
    423f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4242:	06                   	push   es
    4243:	57                   	push   di
    4244:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4247:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    424b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    424e:	06                   	push   es
    424f:	57                   	push   di
    4250:	9a f9 36 7b 42       	call   0x427b:0x36f9
    4255:	c9                   	leave
    4256:	ca 08 00             	retf   0x8
    4259:	55                   	push   bp
    425a:	89 e5                	mov    bp,sp
    425c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4260:	74 08                	je     0x426a
    4262:	83 ec 08             	sub    sp,0x8
    4265:	9a e2 1f 22 44       	call   0x4422:0x1fe2
    426a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    426d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4270:	31 c0                	xor    ax,ax
    4272:	50                   	push   ax
    4273:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4276:	06                   	push   es
    4277:	57                   	push   di
    4278:	9a 86 68 92 42       	call   0x4292:0x6886
    427d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4280:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    4284:	0d 40 00             	or     ax,0x40
    4287:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    428b:	6a 41                	push   0x41
    428d:	06                   	push   es
    428e:	57                   	push   di
    428f:	9a bf 17 9e 42       	call   0x429e:0x17bf
    4294:	6a 11                	push   0x11
    4296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4299:	06                   	push   es
    429a:	57                   	push   di
    429b:	9a e1 17 db 42       	call   0x42db:0x17e1
    42a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42a3:	26 c6 85 93 00 01    	mov    BYTE PTR es:[di+0x93],0x1
    42a9:	26 c6 85 95 00 01    	mov    BYTE PTR es:[di+0x95],0x1
    42af:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    42b3:	74 07                	je     0x42bc
    42b5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    42b9:	83 c4 06             	add    sp,0x6
    42bc:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    42bf:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    42c2:	c9                   	leave
    42c3:	ca 0a 00             	retf   0xa
    42c6:	c8 00 01 00          	enter  0x100,0x0
    42ca:	8d be 00 ff          	lea    di,[bp-0x100]
    42ce:	16                   	push   ss
    42cf:	57                   	push   di
    42d0:	68 00 01             	push   0x100
    42d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42d6:	06                   	push   es
    42d7:	57                   	push   di
    42d8:	9a 02 1d 1f 46       	call   0x461f:0x1d02
    42dd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    42e0:	25 00 04             	and    ax,0x400
    42e3:	09 c0                	or     ax,ax
    42e5:	74 30                	je     0x4317
    42e7:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    42ec:	74 19                	je     0x4307
    42ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42f1:	26 80 bd 95 00 00    	cmp    BYTE PTR es:[di+0x95],0x0
    42f7:	74 1e                	je     0x4317
    42f9:	80 be 00 ff 26       	cmp    BYTE PTR [bp-0x100],0x26
    42fe:	75 17                	jne    0x4317
    4300:	80 be 01 ff 00       	cmp    BYTE PTR [bp-0xff],0x0
    4305:	75 10                	jne    0x4317
    4307:	8d be 00 ff          	lea    di,[bp-0x100]
    430b:	16                   	push   ss
    430c:	57                   	push   di
    430d:	bf 66 0e             	mov    di,0xe66
    4310:	1e                   	push   ds
    4311:	57                   	push   di
    4312:	9a df 0c 7f 43       	call   0x437f:0xcdf
    4317:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    431a:	26 80 bd 95 00 00    	cmp    BYTE PTR es:[di+0x95],0x0
    4320:	75 09                	jne    0x432b
    4322:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4325:	0d 00 08             	or     ax,0x800
    4328:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    432b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    432e:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4332:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4336:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    433b:	06                   	push   es
    433c:	57                   	push   di
    433d:	9a 99 20 5e 43       	call   0x435e:0x2099
    4342:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4345:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    434a:	75 14                	jne    0x4360
    434c:	6a ff                	push   0xffff
    434e:	6a ee                	push   0xffee
    4350:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    4355:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4359:	06                   	push   es
    435a:	57                   	push   di
    435b:	9a df 0f 6d 43       	call   0x436d:0xfdf
    4360:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4363:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    4368:	06                   	push   es
    4369:	57                   	push   di
    436a:	9a d2 21 ca 43       	call   0x43ca:0x21d2
    436f:	50                   	push   ax
    4370:	8d be 00 ff          	lea    di,[bp-0x100]
    4374:	16                   	push   ss
    4375:	57                   	push   di
    4376:	8d be 00 ff          	lea    di,[bp-0x100]
    437a:	16                   	push   ss
    437b:	57                   	push   di
    437c:	9a 8c 0c 67 49       	call   0x4967:0xc8c
    4381:	50                   	push   ax
    4382:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4385:	06                   	push   es
    4386:	57                   	push   di
    4387:	ff 76 0a             	push   WORD PTR [bp+0xa]
    438a:	9a ff ff 00 00       	call   0x0:0xffff
    438f:	c9                   	leave
    4390:	ca 0a 00             	retf   0xa
    4393:	c8 14 00 00          	enter  0x14,0x0
    4397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    439a:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    439f:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    43a2:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    43a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43a8:	06                   	push   es
    43a9:	57                   	push   di
    43aa:	9a 61 45 46 44       	call   0x4446:0x4561
    43af:	08 c0                	or     al,al
    43b1:	75 44                	jne    0x43f7
    43b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43b6:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    43ba:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    43be:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    43c1:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    43c5:	06                   	push   es
    43c6:	57                   	push   di
    43c7:	9a 84 16 da 43       	call   0x43da:0x1684
    43cc:	6a 00                	push   0x0
    43ce:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    43d1:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    43d5:	06                   	push   es
    43d6:	57                   	push   di
    43d7:	9a 7c 17 f5 43       	call   0x43f5:0x177c
    43dc:	8d 7e ec             	lea    di,[bp-0x14]
    43df:	16                   	push   ss
    43e0:	57                   	push   di
    43e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43e4:	06                   	push   es
    43e5:	57                   	push   di
    43e6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43e9:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    43ed:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    43f0:	06                   	push   es
    43f1:	57                   	push   di
    43f2:	9a e5 1c 05 44       	call   0x4405:0x1ce5
    43f7:	6a 01                	push   0x1
    43f9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    43fc:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    4400:	06                   	push   es
    4401:	57                   	push   di
    4402:	9a 7c 17 9f 44       	call   0x449f:0x177c
    4407:	8d 7e ec             	lea    di,[bp-0x14]
    440a:	16                   	push   ss
    440b:	57                   	push   di
    440c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    440f:	06                   	push   es
    4410:	57                   	push   di
    4411:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4414:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    4418:	8d 7e f8             	lea    di,[bp-0x8]
    441b:	16                   	push   ss
    441c:	57                   	push   di
    441d:	6a 08                	push   0x8
    441f:	9a 1b 16 83 44       	call   0x4483:0x161b
    4424:	8d 7e f8             	lea    di,[bp-0x8]
    4427:	16                   	push   ss
    4428:	57                   	push   di
    4429:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    442c:	26 8a 85 92 00       	mov    al,BYTE PTR es:[di+0x92]
    4431:	98                   	cbw
    4432:	8b f8                	mov    di,ax
    4434:	d1 e7                	shl    di,1
    4436:	8b 85 68 0e          	mov    ax,WORD PTR [di+0xe68]
    443a:	0d 50 00             	or     ax,0x50
    443d:	50                   	push   ax
    443e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4441:	06                   	push   es
    4442:	57                   	push   di
    4443:	9a c6 42 c3 44       	call   0x44c3:0x42c6
    4448:	c9                   	leave
    4449:	ca 04 00             	retf   0x4
    444c:	c8 14 00 00          	enter  0x14,0x0
    4450:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4453:	26 f6 45 18 02       	test   BYTE PTR es:[di+0x18],0x2
    4458:	74 03                	je     0x445d
    445a:	e9 b8 00             	jmp    0x4515
    445d:	26 80 bd 93 00 00    	cmp    BYTE PTR es:[di+0x93],0x0
    4463:	75 03                	jne    0x4468
    4465:	e9 ad 00             	jmp    0x4515
    4468:	8d 7e ec             	lea    di,[bp-0x14]
    446b:	16                   	push   ss
    446c:	57                   	push   di
    446d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4470:	06                   	push   es
    4471:	57                   	push   di
    4472:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4475:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    4479:	8d 7e f4             	lea    di,[bp-0xc]
    447c:	16                   	push   ss
    447d:	57                   	push   di
    447e:	6a 08                	push   0x8
    4480:	9a 1b 16 18 47       	call   0x4718:0x161b
    4485:	6a 00                	push   0x0
    4487:	9a 29 4c 00 00       	call   0x0:0x4c29
    448c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    448f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4495:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    449a:	06                   	push   es
    449b:	57                   	push   di
    449c:	9a 5d 22 d4 44       	call   0x44d4:0x225d
    44a1:	8d 7e f4             	lea    di,[bp-0xc]
    44a4:	16                   	push   ss
    44a5:	57                   	push   di
    44a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44a9:	26 8a 85 94 00       	mov    al,BYTE PTR es:[di+0x94]
    44ae:	98                   	cbw
    44af:	8b f8                	mov    di,ax
    44b1:	d1 e7                	shl    di,1
    44b3:	8b 85 6e 0e          	mov    ax,WORD PTR [di+0xe6e]
    44b7:	0d 40 04             	or     ax,0x440
    44ba:	50                   	push   ax
    44bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44be:	06                   	push   es
    44bf:	57                   	push   di
    44c0:	9a c6 42 5b 45       	call   0x455b:0x42c6
    44c5:	6a 00                	push   0x0
    44c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ca:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    44cf:	06                   	push   es
    44d0:	57                   	push   di
    44d1:	9a 5d 22 4c 4c       	call   0x4c4c:0x225d
    44d6:	6a 00                	push   0x0
    44d8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    44db:	9a 75 4c 00 00       	call   0x0:0x4c75
    44e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44e3:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    44e7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    44ea:	26 80 bd 92 00 01    	cmp    BYTE PTR es:[di+0x92],0x1
    44f0:	75 0a                	jne    0x44fc
    44f2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    44f6:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    44f9:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    44fc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    44ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4502:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    4506:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4509:	ff 76 fa             	push   WORD PTR [bp-0x6]
    450c:	06                   	push   es
    450d:	57                   	push   di
    450e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4511:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    4515:	c9                   	leave
    4516:	ca 04 00             	retf   0x4
    4519:	55                   	push   bp
    451a:	89 e5                	mov    bp,sp
    451c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    451f:	26 8a 85 92 00       	mov    al,BYTE PTR es:[di+0x92]
    4524:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    4527:	74 11                	je     0x453a
    4529:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    452c:	26 88 85 92 00       	mov    BYTE PTR es:[di+0x92],al
    4531:	06                   	push   es
    4532:	57                   	push   di
    4533:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4536:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    453a:	c9                   	leave
    453b:	ca 06 00             	retf   0x6
    453e:	55                   	push   bp
    453f:	89 e5                	mov    bp,sp
    4541:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4544:	26 8a 85 93 00       	mov    al,BYTE PTR es:[di+0x93]
    4549:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    454c:	74 0f                	je     0x455d
    454e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4551:	26 88 85 93 00       	mov    BYTE PTR es:[di+0x93],al
    4556:	06                   	push   es
    4557:	57                   	push   di
    4558:	9a 4c 44 ac 45       	call   0x45ac:0x444c
    455d:	c9                   	leave
    455e:	ca 06 00             	retf   0x6
    4561:	c8 02 00 00          	enter  0x2,0x0
    4565:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4568:	26 f6 45 26 40       	test   BYTE PTR es:[di+0x26],0x40
    456d:	b0 00                	mov    al,0x0
    456f:	75 01                	jne    0x4572
    4571:	40                   	inc    ax
    4572:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4575:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4578:	c9                   	leave
    4579:	ca 04 00             	retf   0x4
    457c:	55                   	push   bp
    457d:	89 e5                	mov    bp,sp
    457f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4582:	26 8a 85 95 00       	mov    al,BYTE PTR es:[di+0x95]
    4587:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    458a:	74 11                	je     0x459d
    458c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    458f:	26 88 85 95 00       	mov    BYTE PTR es:[di+0x95],al
    4594:	06                   	push   es
    4595:	57                   	push   di
    4596:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4599:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    459d:	c9                   	leave
    459e:	ca 06 00             	retf   0x6
    45a1:	55                   	push   bp
    45a2:	89 e5                	mov    bp,sp
    45a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45a7:	06                   	push   es
    45a8:	57                   	push   di
    45a9:	9a 61 45 04 46       	call   0x4604:0x4561
    45ae:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    45b1:	74 30                	je     0x45e3
    45b3:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    45b7:	74 10                	je     0x45c9
    45b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45bc:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    45c0:	25 bf ff             	and    ax,0xffbf
    45c3:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    45c7:	eb 0e                	jmp    0x45d7
    45c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45cc:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    45d0:	0d 40 00             	or     ax,0x40
    45d3:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    45d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45da:	06                   	push   es
    45db:	57                   	push   di
    45dc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45df:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    45e3:	c9                   	leave
    45e4:	ca 06 00             	retf   0x6
    45e7:	55                   	push   bp
    45e8:	89 e5                	mov    bp,sp
    45ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45ed:	26 8a 85 94 00       	mov    al,BYTE PTR es:[di+0x94]
    45f2:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    45f5:	74 0f                	je     0x4606
    45f7:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    45fa:	26 88 85 94 00       	mov    BYTE PTR es:[di+0x94],al
    45ff:	06                   	push   es
    4600:	57                   	push   di
    4601:	9a 4c 44 65 46       	call   0x4665:0x444c
    4606:	c9                   	leave
    4607:	ca 06 00             	retf   0x6
    460a:	55                   	push   bp
    460b:	89 e5                	mov    bp,sp
    460d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4610:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4613:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4616:	50                   	push   ax
    4617:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    461a:	06                   	push   es
    461b:	57                   	push   di
    461c:	9a 32 16 7c 46       	call   0x467c:0x1632
    4621:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    4625:	75 23                	jne    0x464a
    4627:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    462a:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    462d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4630:	26 3b 95 90 00       	cmp    dx,WORD PTR es:[di+0x90]
    4635:	75 13                	jne    0x464a
    4637:	26 3b 85 8e 00       	cmp    ax,WORD PTR es:[di+0x8e]
    463c:	75 0c                	jne    0x464a
    463e:	31 c0                	xor    ax,ax
    4640:	26 89 85 8e 00       	mov    WORD PTR es:[di+0x8e],ax
    4645:	26 89 85 90 00       	mov    WORD PTR es:[di+0x90],ax
    464a:	c9                   	leave
    464b:	ca 0a 00             	retf   0xa
    464e:	55                   	push   bp
    464f:	89 e5                	mov    bp,sp
    4651:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4654:	06                   	push   es
    4655:	57                   	push   di
    4656:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4659:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    465d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4660:	06                   	push   es
    4661:	57                   	push   di
    4662:	9a 4c 44 86 46       	call   0x4686:0x444c
    4667:	c9                   	leave
    4668:	ca 08 00             	retf   0x8
    466b:	55                   	push   bp
    466c:	89 e5                	mov    bp,sp
    466e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4671:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4674:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4677:	06                   	push   es
    4678:	57                   	push   di
    4679:	9a 33 2d c3 46       	call   0x46c3:0x2d33
    467e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4681:	06                   	push   es
    4682:	57                   	push   di
    4683:	9a 4c 44 83 47       	call   0x4783:0x444c
    4688:	c9                   	leave
    4689:	ca 08 00             	retf   0x8
    468c:	c8 04 01 00          	enter  0x104,0x0
    4690:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4693:	26 8b 85 8e 00       	mov    ax,WORD PTR es:[di+0x8e]
    4698:	26 0b 85 90 00       	or     ax,WORD PTR es:[di+0x90]
    469d:	74 66                	je     0x4705
    469f:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    46a4:	74 5f                	je     0x4705
    46a6:	26 80 bd 95 00 00    	cmp    BYTE PTR es:[di+0x95],0x0
    46ac:	74 57                	je     0x4705
    46ae:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    46b1:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    46b5:	8d be 00 ff          	lea    di,[bp-0x100]
    46b9:	16                   	push   ss
    46ba:	57                   	push   di
    46bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46be:	06                   	push   es
    46bf:	57                   	push   di
    46c0:	9a 53 1d e3 46       	call   0x46e3:0x1d53
    46c5:	9a 3f 17 ed 5a       	call   0x5aed:0x173f
    46ca:	08 c0                	or     al,al
    46cc:	74 37                	je     0x4705
    46ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46d1:	26 c4 bd 8e 00       	les    di,DWORD PTR es:[di+0x8e]
    46d6:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    46da:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    46de:	06                   	push   es
    46df:	57                   	push   di
    46e0:	9a c4 61 2b 47       	call   0x472b:0x61c4
    46e5:	08 c0                	or     al,al
    46e7:	74 1c                	je     0x4705
    46e9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    46ed:	06                   	push   es
    46ee:	57                   	push   di
    46ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46f2:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    46f6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    46f9:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    46ff:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    4705:	c9                   	leave
    4706:	ca 08 00             	retf   0x8
    4709:	55                   	push   bp
    470a:	89 e5                	mov    bp,sp
    470c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4710:	74 08                	je     0x471a
    4712:	83 ec 08             	sub    sp,0x8
    4715:	9a e2 1f 38 4d       	call   0x4d38:0x1fe2
    471a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    471d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4720:	31 c0                	xor    ax,ax
    4722:	50                   	push   ax
    4723:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4726:	06                   	push   es
    4727:	57                   	push   di
    4728:	9a 61 2e 3d 47       	call   0x473d:0x2e61
    472d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4730:	26 c7 45 26 b8 02    	mov    WORD PTR es:[di+0x26],0x2b8
    4736:	6a 79                	push   0x79
    4738:	06                   	push   es
    4739:	57                   	push   di
    473a:	9a bf 17 49 47       	call   0x4749:0x17bf
    473f:	6a 19                	push   0x19
    4741:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4744:	06                   	push   es
    4745:	57                   	push   di
    4746:	9a e1 17 55 47       	call   0x4755:0x17e1
    474b:	6a 01                	push   0x1
    474d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4750:	06                   	push   es
    4751:	57                   	push   di
    4752:	9a 88 64 61 47       	call   0x4761:0x6488
    4757:	6a 00                	push   0x0
    4759:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    475c:	06                   	push   es
    475d:	57                   	push   di
    475e:	9a 32 1f e6 47       	call   0x47e6:0x1f32
    4763:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4766:	26 c6 85 da 00 01    	mov    BYTE PTR es:[di+0xda],0x1
    476c:	26 c6 85 dd 00 01    	mov    BYTE PTR es:[di+0xdd],0x1
    4772:	26 c6 85 de 00 01    	mov    BYTE PTR es:[di+0xde],0x1
    4778:	26 c6 85 df 00 01    	mov    BYTE PTR es:[di+0xdf],0x1
    477e:	06                   	push   es
    477f:	57                   	push   di
    4780:	9a 22 4c b9 47       	call   0x47b9:0x4c22
    4785:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4789:	74 07                	je     0x4792
    478b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    478f:	83 c4 06             	add    sp,0x6
    4792:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4795:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4798:	c9                   	leave
    4799:	ca 0a 00             	retf   0xa
    479c:	55                   	push   bp
    479d:	89 e5                	mov    bp,sp
    479f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47a2:	26 8a 85 dd 00       	mov    al,BYTE PTR es:[di+0xdd]
    47a7:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    47aa:	74 0f                	je     0x47bb
    47ac:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    47af:	26 88 85 dd 00       	mov    BYTE PTR es:[di+0xdd],al
    47b4:	06                   	push   es
    47b5:	57                   	push   di
    47b6:	9a e6 4b dc 47       	call   0x47dc:0x4be6
    47bb:	c9                   	leave
    47bc:	ca 06 00             	retf   0x6
    47bf:	55                   	push   bp
    47c0:	89 e5                	mov    bp,sp
    47c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47c5:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    47ca:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    47cd:	74 19                	je     0x47e8
    47cf:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    47d2:	26 88 85 da 00       	mov    BYTE PTR es:[di+0xda],al
    47d7:	06                   	push   es
    47d8:	57                   	push   di
    47d9:	9a e6 4b 60 4b       	call   0x4b60:0x4be6
    47de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47e1:	06                   	push   es
    47e2:	57                   	push   di
    47e3:	9a 5a 40 09 48       	call   0x4809:0x405a
    47e8:	c9                   	leave
    47e9:	ca 06 00             	retf   0x6
    47ec:	55                   	push   bp
    47ed:	89 e5                	mov    bp,sp
    47ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47f2:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    47f7:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    47fa:	74 0f                	je     0x480b
    47fc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    47ff:	26 88 85 e1 00       	mov    BYTE PTR es:[di+0xe1],al
    4804:	06                   	push   es
    4805:	57                   	push   di
    4806:	9a 5a 40 2c 48       	call   0x482c:0x405a
    480b:	c9                   	leave
    480c:	ca 06 00             	retf   0x6
    480f:	55                   	push   bp
    4810:	89 e5                	mov    bp,sp
    4812:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4815:	26 8a 85 df 00       	mov    al,BYTE PTR es:[di+0xdf]
    481a:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    481d:	74 0f                	je     0x482e
    481f:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4822:	26 88 85 df 00       	mov    BYTE PTR es:[di+0xdf],al
    4827:	06                   	push   es
    4828:	57                   	push   di
    4829:	9a 5a 40 4f 48       	call   0x484f:0x405a
    482e:	c9                   	leave
    482f:	ca 06 00             	retf   0x6
    4832:	55                   	push   bp
    4833:	89 e5                	mov    bp,sp
    4835:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4838:	26 8b 85 d8 00       	mov    ax,WORD PTR es:[di+0xd8]
    483d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    4840:	74 2d                	je     0x486f
    4842:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4845:	26 89 85 d8 00       	mov    WORD PTR es:[di+0xd8],ax
    484a:	06                   	push   es
    484b:	57                   	push   di
    484c:	9a fa 64 5d 48       	call   0x485d:0x64fa
    4851:	08 c0                	or     al,al
    4853:	74 1a                	je     0x486f
    4855:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4858:	06                   	push   es
    4859:	57                   	push   di
    485a:	9a b9 62 90 48       	call   0x4890:0x62b9
    485f:	50                   	push   ax
    4860:	68 15 04             	push   0x415
    4863:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4866:	6a 00                	push   0x0
    4868:	6a 00                	push   0x0
    486a:	9a c1 48 00 00       	call   0x0:0x48c1
    486f:	c9                   	leave
    4870:	ca 06 00             	retf   0x6
    4873:	55                   	push   bp
    4874:	89 e5                	mov    bp,sp
    4876:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4879:	26 8a 85 e0 00       	mov    al,BYTE PTR es:[di+0xe0]
    487e:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    4881:	74 0f                	je     0x4892
    4883:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4886:	26 88 85 e0 00       	mov    BYTE PTR es:[di+0xe0],al
    488b:	06                   	push   es
    488c:	57                   	push   di
    488d:	9a 5a 40 a6 48       	call   0x48a6:0x405a
    4892:	c9                   	leave
    4893:	ca 06 00             	retf   0x6
    4896:	c8 02 00 00          	enter  0x2,0x0
    489a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    489e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48a1:	06                   	push   es
    48a2:	57                   	push   di
    48a3:	9a fa 64 b4 48       	call   0x48b4:0x64fa
    48a8:	08 c0                	or     al,al
    48aa:	74 23                	je     0x48cf
    48ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48af:	06                   	push   es
    48b0:	57                   	push   di
    48b1:	9a b9 62 e1 48       	call   0x48e1:0x62b9
    48b6:	50                   	push   ax
    48b7:	68 08 04             	push   0x408
    48ba:	6a 00                	push   0x0
    48bc:	6a 00                	push   0x0
    48be:	6a 00                	push   0x0
    48c0:	9a 00 49 00 00       	call   0x0:0x4900
    48c5:	09 d0                	or     ax,dx
    48c7:	b0 00                	mov    al,0x0
    48c9:	74 01                	je     0x48cc
    48cb:	40                   	inc    ax
    48cc:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    48cf:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    48d2:	c9                   	leave
    48d3:	ca 04 00             	retf   0x4
    48d6:	55                   	push   bp
    48d7:	89 e5                	mov    bp,sp
    48d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48dc:	06                   	push   es
    48dd:	57                   	push   di
    48de:	9a fa 64 ef 48       	call   0x48ef:0x64fa
    48e3:	08 c0                	or     al,al
    48e5:	74 1d                	je     0x4904
    48e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48ea:	06                   	push   es
    48eb:	57                   	push   di
    48ec:	9a b9 62 26 49       	call   0x4926:0x62b9
    48f1:	50                   	push   ax
    48f2:	68 09 04             	push   0x409
    48f5:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    48f8:	30 e4                	xor    ah,ah
    48fa:	50                   	push   ax
    48fb:	6a 00                	push   0x0
    48fd:	6a 00                	push   0x0
    48ff:	9a 4a 49 00 00       	call   0x0:0x494a
    4904:	c9                   	leave
    4905:	ca 06 00             	retf   0x6
    4908:	c8 00 02 00          	enter  0x200,0x0
    490c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    490f:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    4914:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    4917:	74 5c                	je     0x4975
    4919:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    491c:	26 88 85 db 00       	mov    BYTE PTR es:[di+0xdb],al
    4921:	06                   	push   es
    4922:	57                   	push   di
    4923:	9a fa 64 34 49       	call   0x4934:0x64fa
    4928:	08 c0                	or     al,al
    492a:	74 49                	je     0x4975
    492c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    492f:	06                   	push   es
    4930:	57                   	push   di
    4931:	9a b9 62 62 49       	call   0x4962:0x62b9
    4936:	50                   	push   ax
    4937:	68 1c 04             	push   0x41c
    493a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    493d:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    4942:	30 e4                	xor    ah,ah
    4944:	50                   	push   ax
    4945:	6a 00                	push   0x0
    4947:	6a 00                	push   0x0
    4949:	9a b4 49 00 00       	call   0x0:0x49b4
    494e:	8d be 00 ff          	lea    di,[bp-0x100]
    4952:	16                   	push   ss
    4953:	57                   	push   di
    4954:	8d be 00 fe          	lea    di,[bp-0x200]
    4958:	16                   	push   ss
    4959:	57                   	push   di
    495a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    495d:	06                   	push   es
    495e:	57                   	push   di
    495f:	9a 53 1d 73 49       	call   0x4973:0x1d53
    4964:	9a 4c 0d 25 4f       	call   0x4f25:0xd4c
    4969:	52                   	push   dx
    496a:	50                   	push   ax
    496b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    496e:	06                   	push   es
    496f:	57                   	push   di
    4970:	9a 25 1d 96 49       	call   0x4996:0x1d25
    4975:	c9                   	leave
    4976:	ca 06 00             	retf   0x6
    4979:	55                   	push   bp
    497a:	89 e5                	mov    bp,sp
    497c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    497f:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    4984:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    4987:	74 2f                	je     0x49b8
    4989:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    498c:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    4991:	06                   	push   es
    4992:	57                   	push   di
    4993:	9a fa 64 a4 49       	call   0x49a4:0x64fa
    4998:	08 c0                	or     al,al
    499a:	74 1c                	je     0x49b8
    499c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    499f:	06                   	push   es
    49a0:	57                   	push   di
    49a1:	9a b9 62 c8 49       	call   0x49c8:0x62b9
    49a6:	50                   	push   ax
    49a7:	68 1f 04             	push   0x41f
    49aa:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    49ad:	98                   	cbw
    49ae:	50                   	push   ax
    49af:	6a 00                	push   0x0
    49b1:	6a 00                	push   0x0
    49b3:	9a d5 49 00 00       	call   0x0:0x49d5
    49b8:	c9                   	leave
    49b9:	ca 06 00             	retf   0x6
    49bc:	c8 02 00 00          	enter  0x2,0x0
    49c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49c3:	06                   	push   es
    49c4:	57                   	push   di
    49c5:	9a b9 62 ee 49       	call   0x49ee:0x62b9
    49ca:	50                   	push   ax
    49cb:	68 00 04             	push   0x400
    49ce:	6a 00                	push   0x0
    49d0:	6a 00                	push   0x0
    49d2:	6a 00                	push   0x0
    49d4:	9a 17 4a 00 00       	call   0x0:0x4a17
    49d9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    49dc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    49df:	c9                   	leave
    49e0:	ca 04 00             	retf   0x4
    49e3:	55                   	push   bp
    49e4:	89 e5                	mov    bp,sp
    49e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49e9:	06                   	push   es
    49ea:	57                   	push   di
    49eb:	9a b9 62 0a 4a       	call   0x4a0a:0x62b9
    49f0:	50                   	push   ax
    49f1:	bf 72 0e             	mov    di,0xe72
    49f4:	1e                   	push   ds
    49f5:	57                   	push   di
    49f6:	9a ca 5f 00 00       	call   0x0:0x5fca
    49fb:	c9                   	leave
    49fc:	ca 04 00             	retf   0x4
    49ff:	55                   	push   bp
    4a00:	89 e5                	mov    bp,sp
    4a02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a05:	06                   	push   es
    4a06:	57                   	push   di
    4a07:	9a b9 62 2a 4a       	call   0x4a2a:0x62b9
    4a0c:	50                   	push   ax
    4a0d:	68 01 03             	push   0x301
    4a10:	6a 00                	push   0x0
    4a12:	6a 00                	push   0x0
    4a14:	6a 00                	push   0x0
    4a16:	9a 37 4a 00 00       	call   0x0:0x4a37
    4a1b:	c9                   	leave
    4a1c:	ca 04 00             	retf   0x4
    4a1f:	55                   	push   bp
    4a20:	89 e5                	mov    bp,sp
    4a22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a25:	06                   	push   es
    4a26:	57                   	push   di
    4a27:	9a b9 62 4a 4a       	call   0x4a4a:0x62b9
    4a2c:	50                   	push   ax
    4a2d:	68 02 03             	push   0x302
    4a30:	6a 00                	push   0x0
    4a32:	6a 00                	push   0x0
    4a34:	6a 00                	push   0x0
    4a36:	9a 57 4a 00 00       	call   0x0:0x4a57
    4a3b:	c9                   	leave
    4a3c:	ca 04 00             	retf   0x4
    4a3f:	55                   	push   bp
    4a40:	89 e5                	mov    bp,sp
    4a42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a45:	06                   	push   es
    4a46:	57                   	push   di
    4a47:	9a b9 62 6f 4a       	call   0x4a6f:0x62b9
    4a4c:	50                   	push   ax
    4a4d:	68 01 04             	push   0x401
    4a50:	6a 01                	push   0x1
    4a52:	6a ff                	push   0xffff
    4a54:	6a 00                	push   0x0
    4a56:	9a b4 4b 00 00       	call   0x0:0x4bb4
    4a5b:	c9                   	leave
    4a5c:	ca 04 00             	retf   0x4
    4a5f:	55                   	push   bp
    4a60:	89 e5                	mov    bp,sp
    4a62:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a65:	06                   	push   es
    4a66:	57                   	push   di
    4a67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a6a:	06                   	push   es
    4a6b:	57                   	push   di
    4a6c:	9a 29 3b 83 4a       	call   0x4a83:0x3b29
    4a71:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a74:	06                   	push   es
    4a75:	57                   	push   di
    4a76:	bf a0 0e             	mov    di,0xea0
    4a79:	1e                   	push   ds
    4a7a:	57                   	push   di
    4a7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a7e:	06                   	push   es
    4a7f:	57                   	push   di
    4a80:	9a d0 3a 81 4b       	call   0x4b81:0x3ad0
    4a85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a88:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    4a8d:	98                   	cbw
    4a8e:	8b f8                	mov    di,ax
    4a90:	c1 e7 02             	shl    di,0x2
    4a93:	8b 8d 5e 0e          	mov    cx,WORD PTR [di+0xe5e]
    4a97:	8b 9d 60 0e          	mov    bx,WORD PTR [di+0xe60]
    4a9b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a9e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4aa2:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    4aa6:	0d c0 00             	or     ax,0xc0
    4aa9:	81 ca 00 00          	or     dx,0x0
    4aad:	0b c1                	or     ax,cx
    4aaf:	0b d3                	or     dx,bx
    4ab1:	8b c8                	mov    cx,ax
    4ab3:	8b da                	mov    bx,dx
    4ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ab8:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    4abe:	b0 00                	mov    al,0x0
    4ac0:	74 01                	je     0x4ac3
    4ac2:	40                   	inc    ax
    4ac3:	98                   	cbw
    4ac4:	8b f8                	mov    di,ax
    4ac6:	c1 e7 02             	shl    di,0x2
    4ac9:	8b 85 74 0e          	mov    ax,WORD PTR [di+0xe74]
    4acd:	8b 95 76 0e          	mov    dx,WORD PTR [di+0xe76]
    4ad1:	0b c1                	or     ax,cx
    4ad3:	0b d3                	or     dx,bx
    4ad5:	8b c8                	mov    cx,ax
    4ad7:	8b da                	mov    bx,dx
    4ad9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4adc:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    4ae1:	98                   	cbw
    4ae2:	8b f8                	mov    di,ax
    4ae4:	c1 e7 02             	shl    di,0x2
    4ae7:	8b 85 7c 0e          	mov    ax,WORD PTR [di+0xe7c]
    4aeb:	8b 95 7e 0e          	mov    dx,WORD PTR [di+0xe7e]
    4aef:	0b c1                	or     ax,cx
    4af1:	0b d3                	or     dx,bx
    4af3:	8b c8                	mov    cx,ax
    4af5:	8b da                	mov    bx,dx
    4af7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4afa:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    4aff:	98                   	cbw
    4b00:	8b f8                	mov    di,ax
    4b02:	c1 e7 02             	shl    di,0x2
    4b05:	8b 85 84 0e          	mov    ax,WORD PTR [di+0xe84]
    4b09:	8b 95 86 0e          	mov    dx,WORD PTR [di+0xe86]
    4b0d:	0b c1                	or     ax,cx
    4b0f:	0b d3                	or     dx,bx
    4b11:	8b c8                	mov    cx,ax
    4b13:	8b da                	mov    bx,dx
    4b15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b18:	26 8a 85 df 00       	mov    al,BYTE PTR es:[di+0xdf]
    4b1d:	98                   	cbw
    4b1e:	8b f8                	mov    di,ax
    4b20:	c1 e7 02             	shl    di,0x2
    4b23:	8b 85 90 0e          	mov    ax,WORD PTR [di+0xe90]
    4b27:	8b 95 92 0e          	mov    dx,WORD PTR [di+0xe92]
    4b2b:	0b c1                	or     ax,cx
    4b2d:	0b d3                	or     dx,bx
    4b2f:	8b c8                	mov    cx,ax
    4b31:	8b da                	mov    bx,dx
    4b33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b36:	26 8a 85 e0 00       	mov    al,BYTE PTR es:[di+0xe0]
    4b3b:	98                   	cbw
    4b3c:	8b f8                	mov    di,ax
    4b3e:	c1 e7 02             	shl    di,0x2
    4b41:	8b 85 98 0e          	mov    ax,WORD PTR [di+0xe98]
    4b45:	8b 95 9a 0e          	mov    dx,WORD PTR [di+0xe9a]
    4b49:	0b c1                	or     ax,cx
    4b4b:	0b d3                	or     dx,bx
    4b4d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b50:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4b54:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4b58:	c9                   	leave
    4b59:	ca 08 00             	retf   0x8
    4b5c:	00 00                	add    BYTE PTR [bx+si],al
    4b5e:	8f                   	(bad)
    4b5f:	4b                   	dec    bx
    4b60:	0c 4c                	or     al,0x4c
    4b62:	55                   	push   bp
    4b63:	89 e5                	mov    bp,sp
    4b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b68:	26 c6 85 e2 00 01    	mov    BYTE PTR es:[di+0xe2],0x1
    4b6e:	b8 5c 4b             	mov    ax,0x4b5c
    4b71:	0e                   	push   cs
    4b72:	50                   	push   ax
    4b73:	55                   	push   bp
    4b74:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4b78:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4b7c:	06                   	push   es
    4b7d:	57                   	push   di
    4b7e:	9a 88 3c a1 4b       	call   0x4ba1:0x3c88
    4b83:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4b87:	83 c4 06             	add    sp,0x6
    4b8a:	b8 99 4b             	mov    ax,0x4b99
    4b8d:	0e                   	push   cs
    4b8e:	50                   	push   ax
    4b8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b92:	26 c6 85 e2 00 00    	mov    BYTE PTR es:[di+0xe2],0x0
    4b98:	cb                   	retf
    4b99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b9c:	06                   	push   es
    4b9d:	57                   	push   di
    4b9e:	9a b9 62 c8 4b       	call   0x4bc8:0x62b9
    4ba3:	50                   	push   ax
    4ba4:	68 15 04             	push   0x415
    4ba7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4baa:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    4baf:	6a 00                	push   0x0
    4bb1:	6a 00                	push   0x0
    4bb3:	9a de 4b 00 00       	call   0x0:0x4bde
    4bb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bbb:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    4bc1:	74 1f                	je     0x4be2
    4bc3:	06                   	push   es
    4bc4:	57                   	push   di
    4bc5:	9a b9 62 b0 4c       	call   0x4cb0:0x62b9
    4bca:	50                   	push   ax
    4bcb:	68 1c 04             	push   0x41c
    4bce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bd1:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    4bd6:	30 e4                	xor    ah,ah
    4bd8:	50                   	push   ax
    4bd9:	6a 00                	push   0x0
    4bdb:	6a 00                	push   0x0
    4bdd:	9a f9 4d 00 00       	call   0x0:0x4df9
    4be2:	c9                   	leave
    4be3:	ca 04 00             	retf   0x4
    4be6:	55                   	push   bp
    4be7:	89 e5                	mov    bp,sp
    4be9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bec:	26 80 bd dd 00 00    	cmp    BYTE PTR es:[di+0xdd],0x0
    4bf2:	74 1c                	je     0x4c10
    4bf4:	26 80 bd da 00 01    	cmp    BYTE PTR es:[di+0xda],0x1
    4bfa:	75 14                	jne    0x4c10
    4bfc:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    4c00:	0d 00 02             	or     ax,0x200
    4c03:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    4c07:	06                   	push   es
    4c08:	57                   	push   di
    4c09:	9a 22 4c 11 4d       	call   0x4d11:0x4c22
    4c0e:	eb 0e                	jmp    0x4c1e
    4c10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c13:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    4c17:	25 ff fd             	and    ax,0xfdff
    4c1a:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    4c1e:	c9                   	leave
    4c1f:	ca 04 00             	retf   0x4
    4c22:	c8 46 00 00          	enter  0x46,0x0
    4c26:	6a 00                	push   0x0
    4c28:	9a ff ff 00 00       	call   0x0:0xffff
    4c2d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c30:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4c33:	8d 7e da             	lea    di,[bp-0x26]
    4c36:	16                   	push   ss
    4c37:	57                   	push   di
    4c38:	9a 60 4c 00 00       	call   0x0:0x4c60
    4c3d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4c40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c43:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    4c47:	06                   	push   es
    4c48:	57                   	push   di
    4c49:	9a 16 10 b3 5a       	call   0x5ab3:0x1016
    4c4e:	50                   	push   ax
    4c4f:	9a 6b 4c 00 00       	call   0x0:0x4c6b
    4c54:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4c57:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4c5a:	8d 7e ba             	lea    di,[bp-0x46]
    4c5d:	16                   	push   ss
    4c5e:	57                   	push   di
    4c5f:	9a c2 64 00 00       	call   0x0:0x64c2
    4c64:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4c67:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4c6a:	9a b2 64 00 00       	call   0x0:0x64b2
    4c6f:	6a 00                	push   0x0
    4c71:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4c74:	9a ff ff 00 00       	call   0x0:0xffff
    4c79:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4c7c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4c7f:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4c82:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    4c85:	7e 06                	jle    0x4c8d
    4c87:	8b 46 ba             	mov    ax,WORD PTR [bp-0x46]
    4c8a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4c8d:	6a 06                	push   0x6
    4c8f:	9a ef 68 00 00       	call   0x0:0x68ef
    4c94:	c1 e0 02             	shl    ax,0x2
    4c97:	8b d8                	mov    bx,ax
    4c99:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4c9c:	99                   	cwd
    4c9d:	b9 04 00             	mov    cx,0x4
    4ca0:	f7 f9                	idiv   cx
    4ca2:	03 46 ba             	add    ax,WORD PTR [bp-0x46]
    4ca5:	03 c3                	add    ax,bx
    4ca7:	50                   	push   ax
    4ca8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cab:	06                   	push   es
    4cac:	57                   	push   di
    4cad:	9a e1 17 ef 4c       	call   0x4cef:0x17e1
    4cb2:	c9                   	leave
    4cb3:	ca 04 00             	retf   0x4
    4cb6:	55                   	push   bp
    4cb7:	89 e5                	mov    bp,sp
    4cb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cbc:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    4cc1:	09 c0                	or     ax,ax
    4cc3:	74 15                	je     0x4cda
    4cc5:	ff 76 08             	push   WORD PTR [bp+0x8]
    4cc8:	ff 76 06             	push   WORD PTR [bp+0x6]
    4ccb:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    4cd0:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    4cd5:	26 ff 9d e4 00       	call   DWORD PTR es:[di+0xe4]
    4cda:	c9                   	leave
    4cdb:	ca 04 00             	retf   0x4
    4cde:	55                   	push   bp
    4cdf:	89 e5                	mov    bp,sp
    4ce1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ce4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ce7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cea:	06                   	push   es
    4ceb:	57                   	push   di
    4cec:	9a 3a 57 58 4d       	call   0x4d58:0x573a
    4cf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cf4:	26 f6 45 27 02       	test   BYTE PTR es:[di+0x27],0x2
    4cf9:	74 18                	je     0x4d13
    4cfb:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4d00:	74 07                	je     0x4d09
    4d02:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    4d07:	75 0a                	jne    0x4d13
    4d09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d0c:	06                   	push   es
    4d0d:	57                   	push   di
    4d0e:	9a 22 4c 75 4d       	call   0x4d75:0x4c22
    4d13:	c9                   	leave
    4d14:	ca 08 00             	retf   0x8
    4d17:	55                   	push   bp
    4d18:	89 e5                	mov    bp,sp
    4d1a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d1d:	26 81 7d 06 00 03    	cmp    WORD PTR es:[di+0x6],0x300
    4d23:	75 15                	jne    0x4d3a
    4d25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d28:	26 80 bd e2 00 00    	cmp    BYTE PTR es:[di+0xe2],0x0
    4d2e:	75 0a                	jne    0x4d3a
    4d30:	06                   	push   es
    4d31:	57                   	push   di
    4d32:	b8 ee ff             	mov    ax,0xffee
    4d35:	9a 6a 20 d6 4d       	call   0x4dd6:0x206a
    4d3a:	c9                   	leave
    4d3b:	ca 08 00             	retf   0x8
    4d3e:	55                   	push   bp
    4d3f:	89 e5                	mov    bp,sp
    4d41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d44:	26 80 bd de 00 00    	cmp    BYTE PTR es:[di+0xde],0x0
    4d4a:	74 2b                	je     0x4d77
    4d4c:	26 f6 45 28 01       	test   BYTE PTR es:[di+0x28],0x1
    4d51:	75 24                	jne    0x4d77
    4d53:	06                   	push   es
    4d54:	57                   	push   di
    4d55:	9a b9 62 85 4d       	call   0x4d85:0x62b9
    4d5a:	50                   	push   ax
    4d5b:	6a f0                	push   0xfff0
    4d5d:	9a bc 4d 00 00       	call   0x0:0x4dbc
    4d62:	25 04 00             	and    ax,0x4
    4d65:	81 e2 00 00          	and    dx,0x0
    4d69:	09 d0                	or     ax,dx
    4d6b:	75 0a                	jne    0x4d77
    4d6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d70:	06                   	push   es
    4d71:	57                   	push   di
    4d72:	9a 3f 4a 53 50       	call   0x5053:0x4a3f
    4d77:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d7a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d80:	06                   	push   es
    4d81:	57                   	push   di
    4d82:	9a be 55 a8 4d       	call   0x4da8:0x55be
    4d87:	c9                   	leave
    4d88:	ca 08 00             	retf   0x8
    4d8b:	55                   	push   bp
    4d8c:	89 e5                	mov    bp,sp
    4d8e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d91:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d97:	06                   	push   es
    4d98:	57                   	push   di
    4d99:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d9c:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    4da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4da3:	06                   	push   es
    4da4:	57                   	push   di
    4da5:	9a fa 64 b6 4d       	call   0x4db6:0x64fa
    4daa:	08 c0                	or     al,al
    4dac:	74 1d                	je     0x4dcb
    4dae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4db1:	06                   	push   es
    4db2:	57                   	push   di
    4db3:	9a b9 62 ec 4d       	call   0x4dec:0x62b9
    4db8:	50                   	push   ax
    4db9:	6a f0                	push   0xfff0
    4dbb:	9a d1 5e 00 00       	call   0x0:0x5ed1
    4dc0:	25 04 00             	and    ax,0x4
    4dc3:	81 e2 00 00          	and    dx,0x0
    4dc7:	09 d0                	or     ax,dx
    4dc9:	74 0d                	je     0x4dd8
    4dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dce:	06                   	push   es
    4dcf:	57                   	push   di
    4dd0:	b8 ee ff             	mov    ax,0xffee
    4dd3:	9a 6a 20 8b 50       	call   0x508b:0x206a
    4dd8:	c9                   	leave
    4dd9:	ca 08 00             	retf   0x8
    4ddc:	c8 02 00 00          	enter  0x2,0x0
    4de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4de3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4de7:	06                   	push   es
    4de8:	57                   	push   di
    4de9:	9a b9 62 0c 4e       	call   0x4e0c:0x62b9
    4dee:	50                   	push   ax
    4def:	68 0a 04             	push   0x40a
    4df2:	6a 00                	push   0x0
    4df4:	6a 00                	push   0x0
    4df6:	6a 00                	push   0x0
    4df8:	9a 2e 4e 00 00       	call   0x0:0x4e2e
    4dfd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e03:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4e07:	06                   	push   es
    4e08:	57                   	push   di
    4e09:	9a b9 62 1e 4e       	call   0x4e1e:0x62b9
    4e0e:	50                   	push   ax
    4e0f:	68 11 04             	push   0x411
    4e12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e15:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4e19:	06                   	push   es
    4e1a:	57                   	push   di
    4e1b:	9a b9 62 62 4e       	call   0x4e62:0x62b9
    4e20:	50                   	push   ax
    4e21:	68 0b 04             	push   0x40b
    4e24:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e27:	48                   	dec    ax
    4e28:	50                   	push   ax
    4e29:	6a 00                	push   0x0
    4e2b:	6a 00                	push   0x0
    4e2d:	9a 38 4e 00 00       	call   0x0:0x4e38
    4e32:	50                   	push   ax
    4e33:	6a 00                	push   0x0
    4e35:	6a 00                	push   0x0
    4e37:	9a 75 4e 00 00       	call   0x0:0x4e75
    4e3c:	09 d0                	or     ax,dx
    4e3e:	75 03                	jne    0x4e43
    4e40:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    4e43:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e46:	c9                   	leave
    4e47:	ca 04 00             	retf   0x4
    4e4a:	55                   	push   bp
    4e4b:	89 e5                	mov    bp,sp
    4e4d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4e50:	26 c7 45 01 ff 00    	mov    WORD PTR es:[di+0x1],0xff
    4e56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e59:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4e5d:	06                   	push   es
    4e5e:	57                   	push   di
    4e5f:	9a b9 62 9c 4e       	call   0x4e9c:0x62b9
    4e64:	50                   	push   ax
    4e65:	68 14 04             	push   0x414
    4e68:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e6b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4e6e:	81 c7 01 00          	add    di,0x1
    4e72:	06                   	push   es
    4e73:	57                   	push   di
    4e74:	9a aa 4e 00 00       	call   0x0:0x4eaa
    4e79:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4e7c:	26 88 05             	mov    BYTE PTR es:[di],al
    4e7f:	c9                   	leave
    4e80:	ca 06 00             	retf   0x6
    4e83:	c8 04 01 00          	enter  0x104,0x0
    4e87:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    4e8b:	7d 03                	jge    0x4e90
    4e8d:	e9 9e 00             	jmp    0x4f2e
    4e90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e93:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4e97:	06                   	push   es
    4e98:	57                   	push   di
    4e99:	9a b9 62 c3 4e       	call   0x4ec3:0x62b9
    4e9e:	50                   	push   ax
    4e9f:	68 0b 04             	push   0x40b
    4ea2:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4ea5:	6a 00                	push   0x0
    4ea7:	6a 00                	push   0x0
    4ea9:	9a d1 4e 00 00       	call   0x0:0x4ed1
    4eae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4eb1:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    4eb5:	74 77                	je     0x4f2e
    4eb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eba:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4ebe:	06                   	push   es
    4ebf:	57                   	push   di
    4ec0:	9a b9 62 f0 4e       	call   0x4ef0:0x62b9
    4ec5:	50                   	push   ax
    4ec6:	68 11 04             	push   0x411
    4ec9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4ecc:	6a 00                	push   0x0
    4ece:	6a 00                	push   0x0
    4ed0:	9a ff 4e 00 00       	call   0x0:0x4eff
    4ed5:	8b c8                	mov    cx,ax
    4ed7:	8b da                	mov    bx,dx
    4ed9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4edc:	99                   	cwd
    4edd:	03 c1                	add    ax,cx
    4edf:	13 d3                	adc    dx,bx
    4ee1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ee4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ee7:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4eeb:	06                   	push   es
    4eec:	57                   	push   di
    4eed:	9a b9 62 0f 4f       	call   0x4f0f:0x62b9
    4ef2:	50                   	push   ax
    4ef3:	68 01 04             	push   0x401
    4ef6:	6a 01                	push   0x1
    4ef8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4efb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4efe:	9a 2a 4f 00 00       	call   0x0:0x4f2a
    4f03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f06:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4f0a:	06                   	push   es
    4f0b:	57                   	push   di
    4f0c:	9a b9 62 4b 4f       	call   0x4f4b:0x62b9
    4f11:	50                   	push   ax
    4f12:	68 12 04             	push   0x412
    4f15:	6a 00                	push   0x0
    4f17:	8d be fc fe          	lea    di,[bp-0x104]
    4f1b:	16                   	push   ss
    4f1c:	57                   	push   di
    4f1d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4f20:	06                   	push   es
    4f21:	57                   	push   di
    4f22:	9a 4c 0d 3e 50       	call   0x503e:0xd4c
    4f27:	52                   	push   dx
    4f28:	50                   	push   ax
    4f29:	9a 59 4f 00 00       	call   0x0:0x4f59
    4f2e:	c9                   	leave
    4f2f:	ca 0a 00             	retf   0xa
    4f32:	c8 0c 02 00          	enter  0x20c,0x0
    4f36:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    4f3a:	7d 03                	jge    0x4f3f
    4f3c:	e9 4e 01             	jmp    0x508d
    4f3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f42:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4f46:	06                   	push   es
    4f47:	57                   	push   di
    4f48:	9a b9 62 7f 4f       	call   0x4f7f:0x62b9
    4f4d:	50                   	push   ax
    4f4e:	68 0b 04             	push   0x40b
    4f51:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4f54:	6a 00                	push   0x0
    4f56:	6a 00                	push   0x0
    4f58:	9a 8f 4f 00 00       	call   0x0:0x4f8f
    4f5d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4f60:	83 7e fa ff          	cmp    WORD PTR [bp-0x6],0xffff
    4f64:	74 0d                	je     0x4f73
    4f66:	b8 a6 0e             	mov    ax,0xea6
    4f69:	8c da                	mov    dx,ds
    4f6b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4f6e:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4f71:	eb 67                	jmp    0x4fda
    4f73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f76:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4f7a:	06                   	push   es
    4f7b:	57                   	push   di
    4f7c:	9a b9 62 ab 4f       	call   0x4fab:0x62b9
    4f81:	50                   	push   ax
    4f82:	68 0b 04             	push   0x40b
    4f85:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    4f88:	48                   	dec    ax
    4f89:	50                   	push   ax
    4f8a:	6a 00                	push   0x0
    4f8c:	6a 00                	push   0x0
    4f8e:	9a b9 4f 00 00       	call   0x0:0x4fb9
    4f93:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4f96:	83 7e fa ff          	cmp    WORD PTR [bp-0x6],0xffff
    4f9a:	75 03                	jne    0x4f9f
    4f9c:	e9 ee 00             	jmp    0x508d
    4f9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fa2:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4fa6:	06                   	push   es
    4fa7:	57                   	push   di
    4fa8:	9a b9 62 ec 4f       	call   0x4fec:0x62b9
    4fad:	50                   	push   ax
    4fae:	68 11 04             	push   0x411
    4fb1:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4fb4:	6a 00                	push   0x0
    4fb6:	6a 00                	push   0x0
    4fb8:	9a fb 4f 00 00       	call   0x0:0x4ffb
    4fbd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4fc0:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4fc4:	75 03                	jne    0x4fc9
    4fc6:	e9 c4 00             	jmp    0x508d
    4fc9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4fcc:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    4fcf:	b8 ab 0e             	mov    ax,0xeab
    4fd2:	8c da                	mov    dx,ds
    4fd4:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4fd7:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4fda:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4fdd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4fe0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fe3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    4fe7:	06                   	push   es
    4fe8:	57                   	push   di
    4fe9:	9a b9 62 0b 50       	call   0x500b:0x62b9
    4fee:	50                   	push   ax
    4fef:	68 01 04             	push   0x401
    4ff2:	6a 01                	push   0x1
    4ff4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4ff7:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4ffa:	9a 43 50 00 00       	call   0x0:0x5043
    4fff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5002:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5006:	06                   	push   es
    5007:	57                   	push   di
    5008:	9a b9 62 7d 50       	call   0x507d:0x62b9
    500d:	50                   	push   ax
    500e:	68 12 04             	push   0x412
    5011:	6a 00                	push   0x0
    5013:	8d be f4 fe          	lea    di,[bp-0x10c]
    5017:	16                   	push   ss
    5018:	57                   	push   di
    5019:	ff 76 f8             	push   WORD PTR [bp-0x8]
    501c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    501f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5022:	89 f8                	mov    ax,di
    5024:	8c c2                	mov    dx,es
    5026:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    502a:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    502e:	c6 86 f0 fe 04       	mov    BYTE PTR [bp-0x110],0x4
    5033:	8d be ec fe          	lea    di,[bp-0x114]
    5037:	16                   	push   ss
    5038:	57                   	push   di
    5039:	6a 00                	push   0x0
    503b:	9a a3 0f 74 50       	call   0x5074:0xfa3
    5040:	52                   	push   dx
    5041:	50                   	push   ax
    5042:	9a b8 50 00 00       	call   0x0:0x50b8
    5047:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    504a:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    504e:	06                   	push   es
    504f:	57                   	push   di
    5050:	9a bc 49 71 51       	call   0x5171:0x49bc
    5055:	8b d0                	mov    dx,ax
    5057:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    505a:	26 8a 05             	mov    al,BYTE PTR es:[di]
    505d:	30 e4                	xor    ah,ah
    505f:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    5062:	40                   	inc    ax
    5063:	40                   	inc    ax
    5064:	3b c2                	cmp    ax,dx
    5066:	74 25                	je     0x508d
    5068:	8d be f4 fd          	lea    di,[bp-0x20c]
    506c:	16                   	push   ss
    506d:	57                   	push   di
    506e:	68 9d f0             	push   0xf09d
    5071:	9a 2b 09 84 50       	call   0x5084:0x92b
    5076:	b0 01                	mov    al,0x1
    5078:	50                   	push   ax
    5079:	b8 22 00             	mov    ax,0x22
    507c:	ba aa 50             	mov    dx,0x50aa
    507f:	52                   	push   dx
    5080:	50                   	push   ax
    5081:	9a e6 28 49 52       	call   0x5249:0x28e6
    5086:	52                   	push   dx
    5087:	50                   	push   ax
    5088:	9a 99 13 60 52       	call   0x5260:0x1399
    508d:	c9                   	leave
    508e:	ca 0a 00             	retf   0xa
    5091:	c8 04 00 00          	enter  0x4,0x0
    5095:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    5099:	7d 03                	jge    0x509e
    509b:	e9 c0 00             	jmp    0x515e
    509e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50a1:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    50a5:	06                   	push   es
    50a6:	57                   	push   di
    50a7:	9a b9 62 d4 50       	call   0x50d4:0x62b9
    50ac:	50                   	push   ax
    50ad:	68 0b 04             	push   0x40b
    50b0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    50b3:	6a 00                	push   0x0
    50b5:	6a 00                	push   0x0
    50b7:	9a e4 50 00 00       	call   0x0:0x50e4
    50bc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    50bf:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    50c3:	75 03                	jne    0x50c8
    50c5:	e9 96 00             	jmp    0x515e
    50c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50cb:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    50cf:	06                   	push   es
    50d0:	57                   	push   di
    50d1:	9a b9 62 fd 50       	call   0x50fd:0x62b9
    50d6:	50                   	push   ax
    50d7:	68 0b 04             	push   0x40b
    50da:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    50dd:	40                   	inc    ax
    50de:	50                   	push   ax
    50df:	6a 00                	push   0x0
    50e1:	6a 00                	push   0x0
    50e3:	9a 0b 51 00 00       	call   0x0:0x510b
    50e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    50eb:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    50ef:	75 2d                	jne    0x511e
    50f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50f4:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    50f8:	06                   	push   es
    50f9:	57                   	push   di
    50fa:	9a b9 62 2a 51       	call   0x512a:0x62b9
    50ff:	50                   	push   ax
    5100:	68 11 04             	push   0x411
    5103:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5106:	6a 00                	push   0x0
    5108:	6a 00                	push   0x0
    510a:	9a 39 51 00 00       	call   0x0:0x5139
    510f:	8b c8                	mov    cx,ax
    5111:	8b da                	mov    bx,dx
    5113:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5116:	99                   	cwd
    5117:	03 c1                	add    ax,cx
    5119:	13 d3                	adc    dx,bx
    511b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    511e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5121:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5125:	06                   	push   es
    5126:	57                   	push   di
    5127:	9a b9 62 49 51       	call   0x5149:0x62b9
    512c:	50                   	push   ax
    512d:	68 01 04             	push   0x401
    5130:	6a 01                	push   0x1
    5132:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5135:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5138:	9a 5a 51 00 00       	call   0x0:0x515a
    513d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5140:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5144:	06                   	push   es
    5145:	57                   	push   di
    5146:	9a b9 62 86 51       	call   0x5186:0x62b9
    514b:	50                   	push   ax
    514c:	68 12 04             	push   0x412
    514f:	6a 00                	push   0x0
    5151:	ff 36 b2 0e          	push   WORD PTR ds:0xeb2
    5155:	ff 36 b0 0e          	push   WORD PTR ds:0xeb0
    5159:	9a 9b 51 00 00       	call   0x0:0x519b
    515e:	c9                   	leave
    515f:	ca 06 00             	retf   0x6
    5162:	55                   	push   bp
    5163:	89 e5                	mov    bp,sp
    5165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5168:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    516c:	06                   	push   es
    516d:	57                   	push   di
    516e:	9a e3 49 00 52       	call   0x5200:0x49e3
    5173:	c9                   	leave
    5174:	ca 04 00             	retf   0x4
    5177:	55                   	push   bp
    5178:	89 e5                	mov    bp,sp
    517a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    517d:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5181:	06                   	push   es
    5182:	57                   	push   di
    5183:	9a b9 62 b1 51       	call   0x51b1:0x62b9
    5188:	50                   	push   ax
    5189:	6a 0b                	push   0xb
    518b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    518f:	b0 00                	mov    al,0x0
    5191:	75 01                	jne    0x5194
    5193:	40                   	inc    ax
    5194:	98                   	cbw
    5195:	50                   	push   ax
    5196:	6a 00                	push   0x0
    5198:	6a 00                	push   0x0
    519a:	9a 08 56 00 00       	call   0x0:0x5608
    519f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    51a3:	75 0e                	jne    0x51b3
    51a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51a8:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    51ac:	06                   	push   es
    51ad:	57                   	push   di
    51ae:	9a c6 22 52 52       	call   0x5252:0x22c6
    51b3:	c9                   	leave
    51b4:	ca 06 00             	retf   0x6
    51b7:	55                   	push   bp
    51b8:	89 e5                	mov    bp,sp
    51ba:	1e                   	push   ds
    51bb:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    51be:	c5 76 04             	lds    si,DWORD PTR [bp+0x4]
    51c1:	fc                   	cld
    51c2:	ac                   	lods   al,BYTE PTR ds:[si]
    51c3:	08 c0                	or     al,al
    51c5:	74 29                	je     0x51f0
    51c7:	3c 0a                	cmp    al,0xa
    51c9:	74 13                	je     0x51de
    51cb:	3c ec                	cmp    al,0xec
    51cd:	74 15                	je     0x51e4
    51cf:	aa                   	stos   BYTE PTR es:[di],al
    51d0:	3c 0d                	cmp    al,0xd
    51d2:	75 ee                	jne    0x51c2
    51d4:	b0 0a                	mov    al,0xa
    51d6:	aa                   	stos   BYTE PTR es:[di],al
    51d7:	ac                   	lods   al,BYTE PTR ds:[si]
    51d8:	3c 0a                	cmp    al,0xa
    51da:	74 e6                	je     0x51c2
    51dc:	eb e5                	jmp    0x51c3
    51de:	b8 0d 0a             	mov    ax,0xa0d
    51e1:	ab                   	stos   WORD PTR es:[di],ax
    51e2:	eb de                	jmp    0x51c2
    51e4:	ac                   	lods   al,BYTE PTR ds:[si]
    51e5:	3c 0a                	cmp    al,0xa
    51e7:	74 d9                	je     0x51c2
    51e9:	26 c6 05 ec          	mov    BYTE PTR es:[di],0xec
    51ed:	47                   	inc    di
    51ee:	eb d3                	jmp    0x51c3
    51f0:	aa                   	stos   BYTE PTR es:[di],al
    51f1:	8d 45 ff             	lea    ax,[di-0x1]
    51f4:	2b 46 08             	sub    ax,WORD PTR [bp+0x8]
    51f7:	1f                   	pop    ds
    51f8:	c9                   	leave
    51f9:	c2 08 00             	ret    0x8
    51fc:	00 00                	add    BYTE PTR [bx+si],al
    51fe:	54                   	push   sp
    51ff:	53                   	push   bx
    5200:	06                   	push   es
    5201:	52                   	push   dx
    5202:	00 00                	add    BYTE PTR [bx+si],al
    5204:	86 53 9a             	xchg   BYTE PTR [bp+di-0x66],dl
    5207:	53                   	push   bx
    5208:	c8 10 01 00          	enter  0x110,0x0
    520c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    520f:	06                   	push   es
    5210:	57                   	push   di
    5211:	9a 7e 23 20 52       	call   0x5220:0x237e
    5216:	52                   	push   dx
    5217:	50                   	push   ax
    5218:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    521b:	06                   	push   es
    521c:	57                   	push   di
    521d:	9a bf 23 6c 57       	call   0x576c:0x23bf
    5222:	59                   	pop    cx
    5223:	5b                   	pop    bx
    5224:	2b c1                	sub    ax,cx
    5226:	1b d3                	sbb    dx,bx
    5228:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    522b:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    522e:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
    5232:	7f 09                	jg     0x523d
    5234:	7c 2c                	jl     0x5262
    5236:	81 7e f0 f6 7f       	cmp    WORD PTR [bp-0x10],0x7ff6
    523b:	76 25                	jbe    0x5262
    523d:	8d be f0 fe          	lea    di,[bp-0x110]
    5241:	16                   	push   ss
    5242:	57                   	push   di
    5243:	68 aa f0             	push   0xf0aa
    5246:	9a 2b 09 59 52       	call   0x5259:0x92b
    524b:	b0 01                	mov    al,0x1
    524d:	50                   	push   ax
    524e:	b8 22 00             	mov    ax,0x22
    5251:	ba e2 52             	mov    dx,0x52e2
    5254:	52                   	push   dx
    5255:	50                   	push   ax
    5256:	9a e6 28 7c 52       	call   0x527c:0x28e6
    525b:	52                   	push   dx
    525c:	50                   	push   ax
    525d:	9a 99 13 70 52       	call   0x5270:0x1399
    5262:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    5265:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    5268:	b9 02 00             	mov    cx,0x2
    526b:	31 db                	xor    bx,bx
    526d:	9a 33 16 2b 54       	call   0x542b:0x1633
    5272:	05 01 00             	add    ax,0x1
    5275:	83 d2 00             	adc    dx,0x0
    5278:	50                   	push   ax
    5279:	9a 8f 0e fe 52       	call   0x52fe:0xe8f
    527e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5281:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5284:	b8 02 52             	mov    ax,0x5202
    5287:	0e                   	push   cs
    5288:	50                   	push   ax
    5289:	55                   	push   bp
    528a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    528e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5292:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5295:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5298:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    529b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    529e:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    52a1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    52a4:	06                   	push   es
    52a5:	57                   	push   di
    52a6:	ff 76 f2             	push   WORD PTR [bp-0xe]
    52a9:	ff 76 f0             	push   WORD PTR [bp-0x10]
    52ac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    52af:	06                   	push   es
    52b0:	57                   	push   di
    52b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52b4:	26 ff 1d             	call   DWORD PTR es:[di]
    52b7:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    52ba:	03 f8                	add    di,ax
    52bc:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    52c0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    52c3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    52c6:	ff 76 f6             	push   WORD PTR [bp-0xa]
    52c9:	ff 76 f4             	push   WORD PTR [bp-0xc]
    52cc:	e8 e8 fe             	call   0x51b7
    52cf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    52d2:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    52d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52d9:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    52dd:	06                   	push   es
    52de:	57                   	push   di
    52df:	9a e2 1c 2b 53       	call   0x532b:0x1ce2
    52e4:	99                   	cwd
    52e5:	8b c8                	mov    cx,ax
    52e7:	8b da                	mov    bx,dx
    52e9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    52ec:	31 d2                	xor    dx,dx
    52ee:	3b d3                	cmp    dx,bx
    52f0:	75 6e                	jne    0x5360
    52f2:	3b c1                	cmp    ax,cx
    52f4:	75 6a                	jne    0x5360
    52f6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    52f9:	40                   	inc    ax
    52fa:	50                   	push   ax
    52fb:	9a 8f 0e 3c 53       	call   0x533c:0xe8f
    5300:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5303:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    5306:	b8 fc 51             	mov    ax,0x51fc
    5309:	0e                   	push   cs
    530a:	50                   	push   ax
    530b:	55                   	push   bp
    530c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5310:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5314:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5317:	ff 76 f4             	push   WORD PTR [bp-0xc]
    531a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    531d:	40                   	inc    ax
    531e:	50                   	push   ax
    531f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5322:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5326:	06                   	push   es
    5327:	57                   	push   di
    5328:	9a 02 1d 78 53       	call   0x5378:0x1d02
    532d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5330:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5333:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5336:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5339:	9a b2 0d 5d 53       	call   0x535d:0xdb2
    533e:	09 c0                	or     ax,ax
    5340:	b0 00                	mov    al,0x0
    5342:	75 01                	jne    0x5345
    5344:	40                   	inc    ax
    5345:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5348:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    534c:	83 c4 06             	add    sp,0x6
    534f:	b8 60 53             	mov    ax,0x5360
    5352:	0e                   	push   cs
    5353:	50                   	push   ax
    5354:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5357:	ff 76 f4             	push   WORD PTR [bp-0xc]
    535a:	9a 23 0f 8f 53       	call   0x538f:0xf23
    535f:	cb                   	retf
    5360:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5364:	75 14                	jne    0x537a
    5366:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5369:	ff 76 f8             	push   WORD PTR [bp-0x8]
    536c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    536f:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5373:	06                   	push   es
    5374:	57                   	push   di
    5375:	9a 25 1d ac 53       	call   0x53ac:0x1d25
    537a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    537e:	83 c4 06             	add    sp,0x6
    5381:	b8 92 53             	mov    ax,0x5392
    5384:	0e                   	push   cs
    5385:	50                   	push   ax
    5386:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5389:	ff 76 f8             	push   WORD PTR [bp-0x8]
    538c:	9a 23 0f b9 53       	call   0x53b9:0xf23
    5391:	cb                   	retf
    5392:	c9                   	leave
    5393:	ca 08 00             	retf   0x8
    5396:	00 00                	add    BYTE PTR [bx+si],al
    5398:	0c 54                	or     al,0x54
    539a:	3e 54                	ds push sp
    539c:	c8 06 00 00          	enter  0x6,0x0
    53a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53a3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    53a7:	06                   	push   es
    53a8:	57                   	push   di
    53a9:	9a e2 1c e6 53       	call   0x53e6:0x1ce2
    53ae:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    53b1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    53b4:	40                   	inc    ax
    53b5:	50                   	push   ax
    53b6:	9a 8f 0e 15 54       	call   0x5415:0xe8f
    53bb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    53be:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    53c1:	b8 96 53             	mov    ax,0x5396
    53c4:	0e                   	push   cs
    53c5:	50                   	push   ax
    53c6:	55                   	push   bp
    53c7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    53cb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    53cf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    53d2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    53d5:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    53d8:	40                   	inc    ax
    53d9:	50                   	push   ax
    53da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53dd:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    53e1:	06                   	push   es
    53e2:	57                   	push   di
    53e3:	9a 02 1d 4b 54       	call   0x544b:0x1d02
    53e8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    53eb:	06                   	push   es
    53ec:	57                   	push   di
    53ed:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    53f0:	31 d2                	xor    dx,dx
    53f2:	52                   	push   dx
    53f3:	50                   	push   ax
    53f4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    53f7:	06                   	push   es
    53f8:	57                   	push   di
    53f9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53fc:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    5400:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5404:	83 c4 06             	add    sp,0x6
    5407:	b8 18 54             	mov    ax,0x5418
    540a:	0e                   	push   cs
    540b:	50                   	push   ax
    540c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    540f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5412:	9a 23 0f c8 58       	call   0x58c8:0xf23
    5417:	cb                   	retf
    5418:	c9                   	leave
    5419:	ca 08 00             	retf   0x8
    541c:	55                   	push   bp
    541d:	89 e5                	mov    bp,sp
    541f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5423:	74 08                	je     0x542d
    5425:	83 ec 08             	sub    sp,0x8
    5428:	9a e2 1f 82 54       	call   0x5482:0x1fe2
    542d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5430:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5433:	31 c0                	xor    ax,ax
    5435:	50                   	push   ax
    5436:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5439:	06                   	push   es
    543a:	57                   	push   di
    543b:	9a 09 47 63 54       	call   0x5463:0x4709
    5440:	68 b9 00             	push   0xb9
    5443:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5446:	06                   	push   es
    5447:	57                   	push   di
    5448:	9a bf 17 57 54       	call   0x5457:0x17bf
    544d:	6a 59                	push   0x59
    544f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5452:	06                   	push   es
    5453:	57                   	push   di
    5454:	9a e1 17 d8 54       	call   0x54d8:0x17e1
    5459:	6a 00                	push   0x0
    545b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    545e:	06                   	push   es
    545f:	57                   	push   di
    5460:	9a 9c 47 7b 54       	call   0x547b:0x479c
    5465:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5468:	26 c6 85 f2 00 01    	mov    BYTE PTR es:[di+0xf2],0x1
    546e:	26 c6 85 f3 00 01    	mov    BYTE PTR es:[di+0xf3],0x1
    5474:	b0 01                	mov    al,0x1
    5476:	50                   	push   ax
    5477:	b8 3a 3d             	mov    ax,0x3d3a
    547a:	ba f9 54             	mov    dx,0x54f9
    547d:	52                   	push   dx
    547e:	50                   	push   ax
    547f:	9a 50 1f cb 54       	call   0x54cb:0x1f50
    5484:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5487:	26 89 85 ec 00       	mov    WORD PTR es:[di+0xec],ax
    548c:	26 89 95 ee 00       	mov    WORD PTR es:[di+0xee],dx
    5491:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5494:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5497:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    549c:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    54a0:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    54a4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    54a8:	74 07                	je     0x54b1
    54aa:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    54ae:	83 c4 06             	add    sp,0x6
    54b1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    54b4:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    54b7:	c9                   	leave
    54b8:	ca 0a 00             	retf   0xa
    54bb:	55                   	push   bp
    54bc:	89 e5                	mov    bp,sp
    54be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54c1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    54c6:	06                   	push   es
    54c7:	57                   	push   di
    54c8:	9a 7f 1f e3 54       	call   0x54e3:0x1f7f
    54cd:	31 c0                	xor    ax,ax
    54cf:	50                   	push   ax
    54d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54d3:	06                   	push   es
    54d4:	57                   	push   di
    54d5:	9a fc 2e 2d 56       	call   0x562d:0x2efc
    54da:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    54de:	74 05                	je     0x54e5
    54e0:	9a 0f 20 73 57       	call   0x5773:0x200f
    54e5:	c9                   	leave
    54e6:	ca 06 00             	retf   0x6
    54e9:	55                   	push   bp
    54ea:	89 e5                	mov    bp,sp
    54ec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    54ef:	06                   	push   es
    54f0:	57                   	push   di
    54f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54f4:	06                   	push   es
    54f5:	57                   	push   di
    54f6:	9a 5f 4a 97 57       	call   0x5797:0x4a5f
    54fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54fe:	26 8a 85 f0 00       	mov    al,BYTE PTR es:[di+0xf0]
    5503:	98                   	cbw
    5504:	8b f8                	mov    di,ax
    5506:	c1 e7 02             	shl    di,0x2
    5509:	8b 8d b6 0e          	mov    cx,WORD PTR [di+0xeb6]
    550d:	8b 9d b8 0e          	mov    bx,WORD PTR [di+0xeb8]
    5511:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5514:	26 8a 85 f2 00       	mov    al,BYTE PTR es:[di+0xf2]
    5519:	98                   	cbw
    551a:	8b f8                	mov    di,ax
    551c:	c1 e7 02             	shl    di,0x2
    551f:	8b 85 d2 0e          	mov    ax,WORD PTR [di+0xed2]
    5523:	8b 95 d4 0e          	mov    dx,WORD PTR [di+0xed4]
    5527:	f7 d0                	not    ax
    5529:	f7 d2                	not    dx
    552b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    552e:	26 23 45 04          	and    ax,WORD PTR es:[di+0x4]
    5532:	26 23 55 06          	and    dx,WORD PTR es:[di+0x6]
    5536:	0d 04 00             	or     ax,0x4
    5539:	81 ca 00 00          	or     dx,0x0
    553d:	0b c1                	or     ax,cx
    553f:	0b d3                	or     dx,bx
    5541:	8b c8                	mov    cx,ax
    5543:	8b da                	mov    bx,dx
    5545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5548:	26 8a 85 f1 00       	mov    al,BYTE PTR es:[di+0xf1]
    554d:	98                   	cbw
    554e:	8b f8                	mov    di,ax
    5550:	c1 e7 02             	shl    di,0x2
    5553:	8b 85 c2 0e          	mov    ax,WORD PTR [di+0xec2]
    5557:	8b 95 c4 0e          	mov    dx,WORD PTR [di+0xec4]
    555b:	0b c1                	or     ax,cx
    555d:	0b d3                	or     dx,bx
    555f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5562:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5566:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    556a:	c9                   	leave
    556b:	ca 08 00             	retf   0x8
    556e:	c8 04 00 00          	enter  0x4,0x0
    5572:	68 42 20             	push   0x2042
    5575:	6a 00                	push   0x0
    5577:	68 00 01             	push   0x100
    557a:	9a ff ff 00 00       	call   0x0:0xffff
    557f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5582:	26 89 85 f6 00       	mov    WORD PTR es:[di+0xf6],ax
    5587:	26 83 bd f6 00 00    	cmp    WORD PTR es:[di+0xf6],0x0
    558d:	75 08                	jne    0x5597
    558f:	a1 8c 18             	mov    ax,ds:0x188c
    5592:	26 89 85 f6 00       	mov    WORD PTR es:[di+0xf6],ax
    5597:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    559a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    559d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    55a0:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    55a4:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    55a8:	81 c7 34 00          	add    di,0x34
    55ac:	06                   	push   es
    55ad:	57                   	push   di
    55ae:	bf da 0e             	mov    di,0xeda
    55b1:	1e                   	push   ds
    55b2:	57                   	push   di
    55b3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55b6:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    55ba:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    55be:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    55c2:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    55c6:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    55ca:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    55ce:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    55d2:	6a 00                	push   0x0
    55d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55d7:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    55dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55df:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    55e3:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    55e7:	9a ff ff 00 00       	call   0x0:0xffff
    55ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55ef:	26 89 85 a2 00       	mov    WORD PTR es:[di+0xa2],ax
    55f4:	26 ff b5 a2 00       	push   WORD PTR es:[di+0xa2]
    55f9:	6a 0c                	push   0xc
    55fb:	6a 00                	push   0x0
    55fd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5600:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5604:	26 ff 35             	push   WORD PTR es:[di]
    5607:	9a ea 57 00 00       	call   0x0:0x57ea
    560c:	c9                   	leave
    560d:	ca 08 00             	retf   0x8
    5610:	55                   	push   bp
    5611:	89 e5                	mov    bp,sp
    5613:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5616:	26 8a 85 f0 00       	mov    al,BYTE PTR es:[di+0xf0]
    561b:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    561e:	74 0f                	je     0x562f
    5620:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5623:	26 88 85 f0 00       	mov    BYTE PTR es:[di+0xf0],al
    5628:	06                   	push   es
    5629:	57                   	push   di
    562a:	9a 5a 40 6e 56       	call   0x566e:0x405a
    562f:	c9                   	leave
    5630:	ca 06 00             	retf   0x6
    5633:	55                   	push   bp
    5634:	89 e5                	mov    bp,sp
    5636:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5639:	ff 76 0a             	push   WORD PTR [bp+0xa]
    563c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    563f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5644:	06                   	push   es
    5645:	57                   	push   di
    5646:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5649:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    564d:	c9                   	leave
    564e:	ca 08 00             	retf   0x8
    5651:	55                   	push   bp
    5652:	89 e5                	mov    bp,sp
    5654:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5657:	26 8a 85 f1 00       	mov    al,BYTE PTR es:[di+0xf1]
    565c:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    565f:	74 0f                	je     0x5670
    5661:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5664:	26 88 85 f1 00       	mov    BYTE PTR es:[di+0xf1],al
    5669:	06                   	push   es
    566a:	57                   	push   di
    566b:	9a 5a 40 91 56       	call   0x5691:0x405a
    5670:	c9                   	leave
    5671:	ca 06 00             	retf   0x6
    5674:	55                   	push   bp
    5675:	89 e5                	mov    bp,sp
    5677:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    567a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    567d:	26 3a 85 f2 00       	cmp    al,BYTE PTR es:[di+0xf2]
    5682:	74 0f                	je     0x5693
    5684:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5687:	26 88 85 f2 00       	mov    BYTE PTR es:[di+0xf2],al
    568c:	06                   	push   es
    568d:	57                   	push   di
    568e:	9a 5a 40 0b 57       	call   0x570b:0x405a
    5693:	c9                   	leave
    5694:	ca 06 00             	retf   0x6
    5697:	55                   	push   bp
    5698:	89 e5                	mov    bp,sp
    569a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    569d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    56a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56a3:	06                   	push   es
    56a4:	57                   	push   di
    56a5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56a8:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    56ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56af:	26 80 bd f4 00 00    	cmp    BYTE PTR es:[di+0xf4],0x0
    56b5:	74 1a                	je     0x56d1
    56b7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    56ba:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    56be:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    56c2:	0d 02 00             	or     ax,0x2
    56c5:	81 ca 00 00          	or     dx,0x0
    56c9:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    56cd:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    56d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d4:	26 80 bd f3 00 00    	cmp    BYTE PTR es:[di+0xf3],0x0
    56da:	75 1a                	jne    0x56f6
    56dc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    56df:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    56e3:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    56e7:	25 fb ff             	and    ax,0xfffb
    56ea:	81 e2 ff ff          	and    dx,0xffff
    56ee:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    56f2:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    56f6:	c9                   	leave
    56f7:	ca 08 00             	retf   0x8
    56fa:	55                   	push   bp
    56fb:	89 e5                	mov    bp,sp
    56fd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5700:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5703:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5706:	06                   	push   es
    5707:	57                   	push   di
    5708:	9a 63 54 39 57       	call   0x5739:0x5463
    570d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5710:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    5715:	3b 06 8c 18          	cmp    ax,WORD PTR ds:0x188c
    5719:	74 0a                	je     0x5725
    571b:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    5720:	9a ff ff 00 00       	call   0x0:0xffff
    5725:	c9                   	leave
    5726:	ca 08 00             	retf   0x8
    5729:	55                   	push   bp
    572a:	89 e5                	mov    bp,sp
    572c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    572f:	06                   	push   es
    5730:	57                   	push   di
    5731:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5734:	06                   	push   es
    5735:	57                   	push   di
    5736:	9a 1f 52 87 57       	call   0x5787:0x521f
    573b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    573e:	26 80 3d 0d          	cmp    BYTE PTR es:[di],0xd
    5742:	75 12                	jne    0x5756
    5744:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5747:	26 80 bd f3 00 00    	cmp    BYTE PTR es:[di+0xf3],0x0
    574d:	75 07                	jne    0x5756
    574f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5752:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    5756:	c9                   	leave
    5757:	ca 08 00             	retf   0x8
    575a:	04 54                	add    al,0x54
    575c:	65 78 74             	gs js  0x57d3
    575f:	55                   	push   bp
    5760:	89 e5                	mov    bp,sp
    5762:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5765:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5768:	bf 8d 05             	mov    di,0x58d
    576b:	b8 c4 57             	mov    ax,0x57c4
    576e:	50                   	push   ax
    576f:	57                   	push   di
    5770:	9a 55 22 3a 58       	call   0x583a:0x2255
    5775:	08 c0                	or     al,al
    5777:	74 10                	je     0x5789
    5779:	ff 76 0c             	push   WORD PTR [bp+0xc]
    577c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    577f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5782:	06                   	push   es
    5783:	57                   	push   di
    5784:	9a 3a 27 dd 57       	call   0x57dd:0x273a
    5789:	bf 5a 57             	mov    di,0x575a
    578c:	0e                   	push   cs
    578d:	57                   	push   di
    578e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5791:	06                   	push   es
    5792:	57                   	push   di
    5793:	bf b2 57             	mov    di,0x57b2
    5796:	b8 7c 5a             	mov    ax,0x5a7c
    5799:	50                   	push   ax
    579a:	57                   	push   di
    579b:	31 c0                	xor    ax,ax
    579d:	50                   	push   ax
    579e:	50                   	push   ax
    579f:	50                   	push   ax
    57a0:	50                   	push   ax
    57a1:	6a 00                	push   0x0
    57a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    57a6:	06                   	push   es
    57a7:	57                   	push   di
    57a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57ab:	26 ff 1d             	call   DWORD PTR es:[di]
    57ae:	c9                   	leave
    57af:	ca 08 00             	retf   0x8
    57b2:	c8 00 01 00          	enter  0x100,0x0
    57b6:	8d be 00 ff          	lea    di,[bp-0x100]
    57ba:	16                   	push   ss
    57bb:	57                   	push   di
    57bc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    57bf:	06                   	push   es
    57c0:	57                   	push   di
    57c1:	9a 74 3f 62 5f       	call   0x5f62:0x3f74
    57c6:	83 c4 04             	add    sp,0x4
    57c9:	c9                   	leave
    57ca:	ca 08 00             	retf   0x8
    57cd:	c8 02 00 00          	enter  0x2,0x0
    57d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57d4:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    57d8:	06                   	push   es
    57d9:	57                   	push   di
    57da:	9a b9 62 08 58       	call   0x5808:0x62b9
    57df:	50                   	push   ax
    57e0:	68 06 04             	push   0x406
    57e3:	6a 00                	push   0x0
    57e5:	6a 00                	push   0x0
    57e7:	6a 00                	push   0x0
    57e9:	9a 17 58 00 00       	call   0x0:0x5817
    57ee:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    57f1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    57f4:	c9                   	leave
    57f5:	ca 04 00             	retf   0x4
    57f8:	c8 02 00 00          	enter  0x2,0x0
    57fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57ff:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5803:	06                   	push   es
    5804:	57                   	push   di
    5805:	9a b9 62 59 58       	call   0x5859:0x62b9
    580a:	50                   	push   ax
    580b:	68 08 04             	push   0x408
    580e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5811:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5814:	06                   	push   es
    5815:	57                   	push   di
    5816:	9a 67 58 00 00       	call   0x0:0x5867
    581b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    581e:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    5822:	75 05                	jne    0x5829
    5824:	31 c0                	xor    ax,ax
    5826:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5829:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    582c:	06                   	push   es
    582d:	57                   	push   di
    582e:	81 c7 01 00          	add    di,0x1
    5832:	06                   	push   es
    5833:	57                   	push   di
    5834:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5837:	9a c1 1e fd 58       	call   0x58fd:0x1ec1
    583c:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    583f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5842:	26 88 05             	mov    BYTE PTR es:[di],al
    5845:	c9                   	leave
    5846:	ca 06 00             	retf   0x6
    5849:	c8 04 00 00          	enter  0x4,0x0
    584d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5850:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5854:	06                   	push   es
    5855:	57                   	push   di
    5856:	9a b9 62 8a 58       	call   0x588a:0x62b9
    585b:	50                   	push   ax
    585c:	68 10 04             	push   0x410
    585f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5862:	6a 00                	push   0x0
    5864:	6a 00                	push   0x0
    5866:	9a 9a 58 00 00       	call   0x0:0x589a
    586b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    586e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5871:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5874:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5877:	c9                   	leave
    5878:	ca 06 00             	retf   0x6
    587b:	55                   	push   bp
    587c:	89 e5                	mov    bp,sp
    587e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5881:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5885:	06                   	push   es
    5886:	57                   	push   di
    5887:	9a b9 62 b2 58       	call   0x58b2:0x62b9
    588c:	50                   	push   ax
    588d:	68 11 04             	push   0x411
    5890:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5893:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5896:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5899:	9a cd 58 00 00       	call   0x0:0x58cd
    589e:	c9                   	leave
    589f:	ca 0a 00             	retf   0xa
    58a2:	c8 02 02 00          	enter  0x202,0x0
    58a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58a9:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    58ad:	06                   	push   es
    58ae:	57                   	push   di
    58af:	9a b9 62 ef 58       	call   0x58ef:0x62b9
    58b4:	50                   	push   ax
    58b5:	68 03 04             	push   0x403
    58b8:	6a 00                	push   0x0
    58ba:	8d be fe fe          	lea    di,[bp-0x102]
    58be:	16                   	push   ss
    58bf:	57                   	push   di
    58c0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    58c3:	06                   	push   es
    58c4:	57                   	push   di
    58c5:	9a 4c 0d e6 58       	call   0x58e6:0xd4c
    58ca:	52                   	push   dx
    58cb:	50                   	push   ax
    58cc:	9a 32 59 00 00       	call   0x0:0x5932
    58d1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    58d4:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    58d8:	7d 25                	jge    0x58ff
    58da:	8d be fe fd          	lea    di,[bp-0x202]
    58de:	16                   	push   ss
    58df:	57                   	push   di
    58e0:	68 9d f0             	push   0xf09d
    58e3:	9a 2b 09 f6 58       	call   0x58f6:0x92b
    58e8:	b0 01                	mov    al,0x1
    58ea:	50                   	push   ax
    58eb:	b8 22 00             	mov    ax,0x22
    58ee:	ba 16 59             	mov    dx,0x5916
    58f1:	52                   	push   dx
    58f2:	50                   	push   ax
    58f3:	9a e6 28 2d 59       	call   0x592d:0x28e6
    58f8:	52                   	push   dx
    58f9:	50                   	push   ax
    58fa:	9a 99 13 65 59       	call   0x5965:0x1399
    58ff:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5902:	c9                   	leave
    5903:	ca 08 00             	retf   0x8
    5906:	c8 00 02 00          	enter  0x200,0x0
    590a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    590d:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5911:	06                   	push   es
    5912:	57                   	push   di
    5913:	9a b9 62 57 59       	call   0x5957:0x62b9
    5918:	50                   	push   ax
    5919:	68 0a 04             	push   0x40a
    591c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    591f:	8d be 00 ff          	lea    di,[bp-0x100]
    5923:	16                   	push   ss
    5924:	57                   	push   di
    5925:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5928:	06                   	push   es
    5929:	57                   	push   di
    592a:	9a 4c 0d 4e 59       	call   0x594e:0xd4c
    592f:	52                   	push   dx
    5930:	50                   	push   ax
    5931:	9a 88 59 00 00       	call   0x0:0x5988
    5936:	83 fa 00             	cmp    dx,0x0
    5939:	7c 07                	jl     0x5942
    593b:	7f 2a                	jg     0x5967
    593d:	3d 00 00             	cmp    ax,0x0
    5940:	73 25                	jae    0x5967
    5942:	8d be 00 fe          	lea    di,[bp-0x200]
    5946:	16                   	push   ss
    5947:	57                   	push   di
    5948:	68 9d f0             	push   0xf09d
    594b:	9a 2b 09 5e 59       	call   0x595e:0x92b
    5950:	b0 01                	mov    al,0x1
    5952:	50                   	push   ax
    5953:	b8 22 00             	mov    ax,0x22
    5956:	ba 7a 59             	mov    dx,0x597a
    5959:	52                   	push   dx
    595a:	50                   	push   ax
    595b:	9a e6 28 c5 73       	call   0x73c5:0x28e6
    5960:	52                   	push   dx
    5961:	50                   	push   ax
    5962:	9a 99 13 2f 5a       	call   0x5a2f:0x1399
    5967:	c9                   	leave
    5968:	ca 0a 00             	retf   0xa
    596b:	55                   	push   bp
    596c:	89 e5                	mov    bp,sp
    596e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5971:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5975:	06                   	push   es
    5976:	57                   	push   di
    5977:	9a b9 62 a9 59       	call   0x59a9:0x62b9
    597c:	50                   	push   ax
    597d:	68 04 04             	push   0x404
    5980:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5983:	6a 00                	push   0x0
    5985:	6a 00                	push   0x0
    5987:	9a c4 59 00 00       	call   0x0:0x59c4
    598c:	c9                   	leave
    598d:	ca 06 00             	retf   0x6
    5990:	c8 00 01 00          	enter  0x100,0x0
    5994:	8d be 00 ff          	lea    di,[bp-0x100]
    5998:	16                   	push   ss
    5999:	57                   	push   di
    599a:	68 00 01             	push   0x100
    599d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59a0:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    59a4:	06                   	push   es
    59a5:	57                   	push   di
    59a6:	9a 02 1d b7 59       	call   0x59b7:0x1d02
    59ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59ae:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    59b2:	06                   	push   es
    59b3:	57                   	push   di
    59b4:	9a b9 62 da 59       	call   0x59da:0x62b9
    59b9:	50                   	push   ax
    59ba:	68 0b 04             	push   0x40b
    59bd:	6a 00                	push   0x0
    59bf:	6a 00                	push   0x0
    59c1:	6a 00                	push   0x0
    59c3:	9a 04 5a 00 00       	call   0x0:0x5a04
    59c8:	8d be 00 ff          	lea    di,[bp-0x100]
    59cc:	16                   	push   ss
    59cd:	57                   	push   di
    59ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59d1:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    59d5:	06                   	push   es
    59d6:	57                   	push   di
    59d7:	9a 25 1d ef 59       	call   0x59ef:0x1d25
    59dc:	c9                   	leave
    59dd:	ca 04 00             	retf   0x4
    59e0:	55                   	push   bp
    59e1:	89 e5                	mov    bp,sp
    59e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59e6:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    59ea:	06                   	push   es
    59eb:	57                   	push   di
    59ec:	9a b9 62 1a 5a       	call   0x5a1a:0x62b9
    59f1:	50                   	push   ax
    59f2:	6a 0b                	push   0xb
    59f4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    59f8:	b0 00                	mov    al,0x0
    59fa:	75 01                	jne    0x59fd
    59fc:	40                   	inc    ax
    59fd:	98                   	cbw
    59fe:	50                   	push   ax
    59ff:	6a 00                	push   0x0
    5a01:	6a 00                	push   0x0
    5a03:	9a ff 5b 00 00       	call   0x0:0x5bff
    5a08:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5a0c:	75 0e                	jne    0x5a1c
    5a0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a11:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5a15:	06                   	push   es
    5a16:	57                   	push   di
    5a17:	9a c6 22 42 5a       	call   0x5a42:0x22c6
    5a1c:	c9                   	leave
    5a1d:	ca 06 00             	retf   0x6
    5a20:	55                   	push   bp
    5a21:	89 e5                	mov    bp,sp
    5a23:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5a27:	74 08                	je     0x5a31
    5a29:	83 ec 08             	sub    sp,0x8
    5a2c:	9a e2 1f 83 5a       	call   0x5a83:0x1fe2
    5a31:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5a34:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5a37:	31 c0                	xor    ax,ax
    5a39:	50                   	push   ax
    5a3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a3d:	06                   	push   es
    5a3e:	57                   	push   di
    5a3f:	9a 61 2e 4f 5a       	call   0x5a4f:0x2e61
    5a44:	68 91 00             	push   0x91
    5a47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a4a:	06                   	push   es
    5a4b:	57                   	push   di
    5a4c:	9a bf 17 5b 5a       	call   0x5a5b:0x17bf
    5a51:	6a 19                	push   0x19
    5a53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a56:	06                   	push   es
    5a57:	57                   	push   di
    5a58:	9a e1 17 67 5a       	call   0x5a67:0x17e1
    5a5d:	6a 01                	push   0x1
    5a5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a62:	06                   	push   es
    5a63:	57                   	push   di
    5a64:	9a 88 64 73 5a       	call   0x5a73:0x6488
    5a69:	6a 00                	push   0x0
    5a6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a6e:	06                   	push   es
    5a6f:	57                   	push   di
    5a70:	9a 32 1f ac 5a       	call   0x5aac:0x1f32
    5a75:	b0 01                	mov    al,0x1
    5a77:	50                   	push   ax
    5a78:	b8 e2 3d             	mov    ax,0x3de2
    5a7b:	ba e6 5a             	mov    dx,0x5ae6
    5a7e:	52                   	push   dx
    5a7f:	50                   	push   ax
    5a80:	9a 50 1f 84 5b       	call   0x5b84:0x1f50
    5a85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a88:	26 89 85 d8 00       	mov    WORD PTR es:[di+0xd8],ax
    5a8d:	26 89 95 da 00       	mov    WORD PTR es:[di+0xda],dx
    5a92:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5a95:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5a98:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5a9d:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    5aa1:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    5aa5:	b0 01                	mov    al,0x1
    5aa7:	50                   	push   ax
    5aa8:	b8 96 00             	mov    ax,0x96
    5aab:	ba 41 5b             	mov    dx,0x5b41
    5aae:	52                   	push   dx
    5aaf:	50                   	push   ax
    5ab0:	9a b8 17 0a 60       	call   0x600a:0x17b8
    5ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ab8:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    5abd:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
    5ac2:	26 c7 85 e2 00 10 00 	mov    WORD PTR es:[di+0xe2],0x10
    5ac9:	26 c6 85 e1 00 00    	mov    BYTE PTR es:[di+0xe1],0x0
    5acf:	26 c7 45 26 a2 02    	mov    WORD PTR es:[di+0x26],0x2a2
    5ad5:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    5ad9:	0d 10 00             	or     ax,0x10
    5adc:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    5ae0:	06                   	push   es
    5ae1:	57                   	push   di
    5ae2:	bf 78 61             	mov    di,0x6178
    5ae5:	b8 02 5b             	mov    ax,0x5b02
    5ae8:	50                   	push   ax
    5ae9:	57                   	push   di
    5aea:	9a 89 14 09 5b       	call   0x5b09:0x1489
    5aef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5af2:	26 89 85 e8 00       	mov    WORD PTR es:[di+0xe8],ax
    5af7:	26 89 95 ea 00       	mov    WORD PTR es:[di+0xea],dx
    5afc:	06                   	push   es
    5afd:	57                   	push   di
    5afe:	bf 41 62             	mov    di,0x6241
    5b01:	b8 70 62             	mov    ax,0x6270
    5b04:	50                   	push   ax
    5b05:	57                   	push   di
    5b06:	9a 89 14 63 5b       	call   0x5b63:0x1489
    5b0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b0e:	26 89 85 ec 00       	mov    WORD PTR es:[di+0xec],ax
    5b13:	26 89 95 ee 00       	mov    WORD PTR es:[di+0xee],dx
    5b18:	26 c7 85 e6 00 08 00 	mov    WORD PTR es:[di+0xe6],0x8
    5b1f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5b23:	74 07                	je     0x5b2c
    5b25:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5b29:	83 c4 06             	add    sp,0x6
    5b2c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5b2f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5b32:	c9                   	leave
    5b33:	ca 0a 00             	retf   0xa
    5b36:	55                   	push   bp
    5b37:	89 e5                	mov    bp,sp
    5b39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b3c:	06                   	push   es
    5b3d:	57                   	push   di
    5b3e:	9a fa 64 af 5b       	call   0x5baf:0x64fa
    5b43:	08 c0                	or     al,al
    5b45:	74 0c                	je     0x5b53
    5b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b4a:	06                   	push   es
    5b4b:	57                   	push   di
    5b4c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b4f:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    5b53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b56:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    5b5b:	26 ff b5 ec 00       	push   WORD PTR es:[di+0xec]
    5b60:	9a a5 15 75 5b       	call   0x5b75:0x15a5
    5b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b68:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    5b6d:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    5b72:	9a a5 15 a4 62       	call   0x62a4:0x15a5
    5b77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b7a:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    5b7f:	06                   	push   es
    5b80:	57                   	push   di
    5b81:	9a 7f 1f 93 5b       	call   0x5b93:0x1f7f
    5b86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b89:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5b8e:	06                   	push   es
    5b8f:	57                   	push   di
    5b90:	9a 7f 1f a2 5b       	call   0x5ba2:0x1f7f
    5b95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b98:	26 c4 bd fa 00       	les    di,DWORD PTR es:[di+0xfa]
    5b9d:	06                   	push   es
    5b9e:	57                   	push   di
    5b9f:	9a 7f 1f ba 5b       	call   0x5bba:0x1f7f
    5ba4:	31 c0                	xor    ax,ax
    5ba6:	50                   	push   ax
    5ba7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5baa:	06                   	push   es
    5bab:	57                   	push   di
    5bac:	9a fc 2e d0 5b       	call   0x5bd0:0x2efc
    5bb1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5bb5:	74 05                	je     0x5bbc
    5bb7:	9a 0f 20 6d 5e       	call   0x5e6d:0x200f
    5bbc:	c9                   	leave
    5bbd:	ca 06 00             	retf   0x6
    5bc0:	55                   	push   bp
    5bc1:	89 e5                	mov    bp,sp
    5bc3:	bf dc 0e             	mov    di,0xedc
    5bc6:	1e                   	push   ds
    5bc7:	57                   	push   di
    5bc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bcb:	06                   	push   es
    5bcc:	57                   	push   di
    5bcd:	9a 25 1d f2 5b       	call   0x5bf2:0x1d25
    5bd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bd5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5bda:	06                   	push   es
    5bdb:	57                   	push   di
    5bdc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5bdf:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    5be3:	c9                   	leave
    5be4:	ca 04 00             	retf   0x4
    5be7:	55                   	push   bp
    5be8:	89 e5                	mov    bp,sp
    5bea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bed:	06                   	push   es
    5bee:	57                   	push   di
    5bef:	9a b9 62 13 5c       	call   0x5c13:0x62b9
    5bf4:	50                   	push   ax
    5bf5:	68 02 04             	push   0x402
    5bf8:	6a 01                	push   0x1
    5bfa:	6a ff                	push   0xffff
    5bfc:	6a 00                	push   0x0
    5bfe:	9a 20 5c 00 00       	call   0x0:0x5c20
    5c03:	c9                   	leave
    5c04:	ca 04 00             	retf   0x4
    5c07:	c8 02 00 00          	enter  0x2,0x0
    5c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c0e:	06                   	push   es
    5c0f:	57                   	push   di
    5c10:	9a b9 62 39 5c       	call   0x5c39:0x62b9
    5c15:	50                   	push   ax
    5c16:	68 07 04             	push   0x407
    5c19:	6a 00                	push   0x0
    5c1b:	6a 00                	push   0x0
    5c1d:	6a 00                	push   0x0
    5c1f:	9a 47 5c 00 00       	call   0x0:0x5c47
    5c24:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5c27:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5c2a:	c9                   	leave
    5c2b:	ca 04 00             	retf   0x4
    5c2e:	55                   	push   bp
    5c2f:	89 e5                	mov    bp,sp
    5c31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c34:	06                   	push   es
    5c35:	57                   	push   di
    5c36:	9a b9 62 6c 5c       	call   0x5c6c:0x62b9
    5c3b:	50                   	push   ax
    5c3c:	68 0e 04             	push   0x40e
    5c3f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c42:	6a 00                	push   0x0
    5c44:	6a 00                	push   0x0
    5c46:	9a 88 5c 00 00       	call   0x0:0x5c88
    5c4b:	c9                   	leave
    5c4c:	ca 06 00             	retf   0x6
    5c4f:	55                   	push   bp
    5c50:	89 e5                	mov    bp,sp
    5c52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c55:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    5c5a:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    5c5d:	74 2d                	je     0x5c8c
    5c5f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5c62:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    5c67:	06                   	push   es
    5c68:	57                   	push   di
    5c69:	9a fa 64 7a 5c       	call   0x5c7a:0x64fa
    5c6e:	08 c0                	or     al,al
    5c70:	74 1a                	je     0x5c8c
    5c72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c75:	06                   	push   es
    5c76:	57                   	push   di
    5c77:	9a b9 62 ad 5c       	call   0x5cad:0x62b9
    5c7c:	50                   	push   ax
    5c7d:	68 01 04             	push   0x401
    5c80:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c83:	6a 00                	push   0x0
    5c85:	6a 00                	push   0x0
    5c87:	9a 35 5e 00 00       	call   0x0:0x5e35
    5c8c:	c9                   	leave
    5c8d:	ca 06 00             	retf   0x6
    5c90:	55                   	push   bp
    5c91:	89 e5                	mov    bp,sp
    5c93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c96:	26 8a 85 e0 00       	mov    al,BYTE PTR es:[di+0xe0]
    5c9b:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    5c9e:	74 0f                	je     0x5caf
    5ca0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5ca3:	26 88 85 e0 00       	mov    BYTE PTR es:[di+0xe0],al
    5ca8:	06                   	push   es
    5ca9:	57                   	push   di
    5caa:	9a 5a 40 f4 5c       	call   0x5cf4:0x405a
    5caf:	c9                   	leave
    5cb0:	ca 06 00             	retf   0x6
    5cb3:	55                   	push   bp
    5cb4:	89 e5                	mov    bp,sp
    5cb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cb9:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    5cbe:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    5cc1:	74 33                	je     0x5cf6
    5cc3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5cc6:	26 88 85 e1 00       	mov    BYTE PTR es:[di+0xe1],al
    5ccb:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    5ccf:	75 0d                	jne    0x5cde
    5cd1:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    5cd5:	25 ff fd             	and    ax,0xfdff
    5cd8:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    5cdc:	eb 0e                	jmp    0x5cec
    5cde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ce1:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    5ce5:	0d 00 02             	or     ax,0x200
    5ce8:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    5cec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cef:	06                   	push   es
    5cf0:	57                   	push   di
    5cf1:	9a 5a 40 29 5d       	call   0x5d29:0x405a
    5cf6:	c9                   	leave
    5cf7:	ca 06 00             	retf   0x6
    5cfa:	c8 02 00 00          	enter  0x2,0x0
    5cfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d01:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    5d06:	3c 03                	cmp    al,0x3
    5d08:	72 0e                	jb     0x5d18
    5d0a:	3c 04                	cmp    al,0x4
    5d0c:	77 0a                	ja     0x5d18
    5d0e:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    5d13:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5d16:	eb 16                	jmp    0x5d2e
    5d18:	68 14 04             	push   0x414
    5d1b:	6a 00                	push   0x0
    5d1d:	6a 00                	push   0x0
    5d1f:	6a 00                	push   0x0
    5d21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d24:	06                   	push   es
    5d25:	57                   	push   di
    5d26:	9a bb 24 7c 5d       	call   0x5d7c:0x24bb
    5d2b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5d2e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5d31:	c9                   	leave
    5d32:	ca 04 00             	retf   0x4
    5d35:	55                   	push   bp
    5d36:	89 e5                	mov    bp,sp
    5d38:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    5d3c:	7e 0b                	jle    0x5d49
    5d3e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5d41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d44:	26 89 85 e2 00       	mov    WORD PTR es:[di+0xe2],ax
    5d49:	c9                   	leave
    5d4a:	ca 06 00             	retf   0x6
    5d4d:	55                   	push   bp
    5d4e:	89 e5                	mov    bp,sp
    5d50:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5d53:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d59:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5d5e:	06                   	push   es
    5d5f:	57                   	push   di
    5d60:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d63:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    5d67:	c9                   	leave
    5d68:	ca 08 00             	retf   0x8
    5d6b:	c8 04 00 00          	enter  0x4,0x0
    5d6f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5d72:	06                   	push   es
    5d73:	57                   	push   di
    5d74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d77:	06                   	push   es
    5d78:	57                   	push   di
    5d79:	9a 29 3b 90 5d       	call   0x5d90:0x3b29
    5d7e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5d81:	06                   	push   es
    5d82:	57                   	push   di
    5d83:	bf fa 0e             	mov    di,0xefa
    5d86:	1e                   	push   ds
    5d87:	57                   	push   di
    5d88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d8b:	06                   	push   es
    5d8c:	57                   	push   di
    5d8d:	9a d0 3a 00 5e       	call   0x5e00:0x3ad0
    5d92:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5d95:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5d98:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5d9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d9e:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    5da3:	98                   	cbw
    5da4:	8b f8                	mov    di,ax
    5da6:	c1 e7 02             	shl    di,0x2
    5da9:	8b 8d de 0e          	mov    cx,WORD PTR [di+0xede]
    5dad:	8b 9d e0 0e          	mov    bx,WORD PTR [di+0xee0]
    5db1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5db4:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5db8:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    5dbc:	0d 40 02             	or     ax,0x240
    5dbf:	81 ca 20 00          	or     dx,0x20
    5dc3:	0b c1                	or     ax,cx
    5dc5:	0b d3                	or     dx,bx
    5dc7:	8b c8                	mov    cx,ax
    5dc9:	8b da                	mov    bx,dx
    5dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dce:	26 8a 85 e0 00       	mov    al,BYTE PTR es:[di+0xe0]
    5dd3:	98                   	cbw
    5dd4:	8b f8                	mov    di,ax
    5dd6:	c1 e7 02             	shl    di,0x2
    5dd9:	8b 85 f2 0e          	mov    ax,WORD PTR [di+0xef2]
    5ddd:	8b 95 f4 0e          	mov    dx,WORD PTR [di+0xef4]
    5de1:	0b c1                	or     ax,cx
    5de3:	0b d3                	or     dx,bx
    5de5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5de8:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    5dec:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    5df0:	c9                   	leave
    5df1:	ca 08 00             	retf   0x8
    5df4:	c8 04 00 00          	enter  0x4,0x0
    5df8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dfb:	06                   	push   es
    5dfc:	57                   	push   di
    5dfd:	9a 88 3c 27 5e       	call   0x5e27:0x3c88
    5e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e05:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    5e0a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5e0d:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5e11:	7e 07                	jle    0x5e1a
    5e13:	81 7e fc ff 00       	cmp    WORD PTR [bp-0x4],0xff
    5e18:	7e 05                	jle    0x5e1f
    5e1a:	c7 46 fc ff 00       	mov    WORD PTR [bp-0x4],0xff
    5e1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e22:	06                   	push   es
    5e23:	57                   	push   di
    5e24:	9a b9 62 a0 5e       	call   0x5ea0:0x62b9
    5e29:	50                   	push   ax
    5e2a:	68 01 04             	push   0x401
    5e2d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5e30:	6a 00                	push   0x0
    5e32:	6a 00                	push   0x0
    5e34:	9a 2d 62 00 00       	call   0x0:0x622d
    5e39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e3c:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    5e41:	26 0b 85 fc 00       	or     ax,WORD PTR es:[di+0xfc]
    5e46:	74 36                	je     0x5e7e
    5e48:	26 ff b5 fc 00       	push   WORD PTR es:[di+0xfc]
    5e4d:	26 ff b5 fa 00       	push   WORD PTR es:[di+0xfa]
    5e52:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5e57:	06                   	push   es
    5e58:	57                   	push   di
    5e59:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e5c:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    5e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e63:	26 c4 bd fa 00       	les    di,DWORD PTR es:[di+0xfa]
    5e68:	06                   	push   es
    5e69:	57                   	push   di
    5e6a:	9a 7f 1f b8 62       	call   0x62b8:0x1f7f
    5e6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e72:	31 c0                	xor    ax,ax
    5e74:	26 89 85 fa 00       	mov    WORD PTR es:[di+0xfa],ax
    5e79:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    5e7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e81:	31 c0                	xor    ax,ax
    5e83:	26 89 85 16 01       	mov    WORD PTR es:[di+0x116],ax
    5e88:	31 c0                	xor    ax,ax
    5e8a:	26 89 85 18 01       	mov    WORD PTR es:[di+0x118],ax
    5e8f:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    5e94:	3c 01                	cmp    al,0x1
    5e96:	76 03                	jbe    0x5e9b
    5e98:	e9 a4 00             	jmp    0x5f3f
    5e9b:	06                   	push   es
    5e9c:	57                   	push   di
    5e9d:	9a b9 62 98 5f       	call   0x5f98:0x62b9
    5ea2:	50                   	push   ax
    5ea3:	6a 05                	push   0x5
    5ea5:	9a fe 5e 00 00       	call   0x0:0x5efe
    5eaa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5ead:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    5eb1:	75 03                	jne    0x5eb6
    5eb3:	e9 89 00             	jmp    0x5f3f
    5eb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5eb9:	26 80 bd e1 00 01    	cmp    BYTE PTR es:[di+0xe1],0x1
    5ebf:	75 44                	jne    0x5f05
    5ec1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5ec4:	26 89 85 18 01       	mov    WORD PTR es:[di+0x118],ax
    5ec9:	26 ff b5 18 01       	push   WORD PTR es:[di+0x118]
    5ece:	6a fc                	push   0xfffc
    5ed0:	9a 18 5f 00 00       	call   0x0:0x5f18
    5ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ed8:	26 89 85 f4 00       	mov    WORD PTR es:[di+0xf4],ax
    5edd:	26 89 95 f6 00       	mov    WORD PTR es:[di+0xf6],dx
    5ee2:	26 ff b5 18 01       	push   WORD PTR es:[di+0x118]
    5ee7:	6a fc                	push   0xfffc
    5ee9:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    5eee:	26 ff b5 ec 00       	push   WORD PTR es:[di+0xec]
    5ef3:	9a 3b 5f 00 00       	call   0x0:0x5f3b
    5ef8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5efb:	6a 02                	push   0x2
    5efd:	9a ff ff 00 00       	call   0x0:0xffff
    5f02:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5f05:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5f08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f0b:	26 89 85 16 01       	mov    WORD PTR es:[di+0x116],ax
    5f10:	26 ff b5 16 01       	push   WORD PTR es:[di+0x116]
    5f15:	6a fc                	push   0xfffc
    5f17:	9a 82 6a 00 00       	call   0x0:0x6a82
    5f1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f1f:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    5f24:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
    5f29:	26 ff b5 16 01       	push   WORD PTR es:[di+0x116]
    5f2e:	6a fc                	push   0xfffc
    5f30:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    5f35:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    5f3a:	9a ff ff 00 00       	call   0x0:0xffff
    5f3f:	c9                   	leave
    5f40:	ca 04 00             	retf   0x4
    5f43:	55                   	push   bp
    5f44:	89 e5                	mov    bp,sp
    5f46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f49:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5f4e:	06                   	push   es
    5f4f:	57                   	push   di
    5f50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f53:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    5f57:	09 c0                	or     ax,ax
    5f59:	7e 35                	jle    0x5f90
    5f5b:	b0 01                	mov    al,0x1
    5f5d:	50                   	push   ax
    5f5e:	b8 c9 03             	mov    ax,0x3c9
    5f61:	ba 69 5f             	mov    dx,0x5f69
    5f64:	52                   	push   dx
    5f65:	50                   	push   ax
    5f66:	9a 08 1d ce 73       	call   0x73ce:0x1d08
    5f6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f6e:	26 89 85 fa 00       	mov    WORD PTR es:[di+0xfa],ax
    5f73:	26 89 95 fc 00       	mov    WORD PTR es:[di+0xfc],dx
    5f78:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    5f7d:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    5f82:	26 c4 bd fa 00       	les    di,DWORD PTR es:[di+0xfa]
    5f87:	06                   	push   es
    5f88:	57                   	push   di
    5f89:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f8c:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    5f90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f93:	06                   	push   es
    5f94:	57                   	push   di
    5f95:	9a 77 3e bb 5f       	call   0x5fbb:0x3e77
    5f9a:	c9                   	leave
    5f9b:	ca 04 00             	retf   0x4
    5f9e:	55                   	push   bp
    5f9f:	89 e5                	mov    bp,sp
    5fa1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5fa4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5fa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5faa:	06                   	push   es
    5fab:	57                   	push   di
    5fac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5faf:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    5fb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fb6:	06                   	push   es
    5fb7:	57                   	push   di
    5fb8:	9a b9 62 06 61       	call   0x6106:0x62b9
    5fbd:	50                   	push   ax
    5fbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc1:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    5fc5:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    5fc9:	9a ff ff 00 00       	call   0x0:0xffff
    5fce:	c9                   	leave
    5fcf:	ca 08 00             	retf   0x8
    5fd2:	c8 08 00 00          	enter  0x8,0x0
    5fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fd9:	26 80 bd e1 00 02    	cmp    BYTE PTR es:[di+0xe1],0x2
    5fdf:	7d 40                	jge    0x6021
    5fe1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5fe4:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5fe8:	8d 7e f8             	lea    di,[bp-0x8]
    5feb:	16                   	push   ss
    5fec:	57                   	push   di
    5fed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ff0:	06                   	push   es
    5ff1:	57                   	push   di
    5ff2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ff5:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    5ff9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ffc:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6000:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    6005:	06                   	push   es
    6006:	57                   	push   di
    6007:	9a c0 16 90 60       	call   0x6090:0x16c0
    600c:	50                   	push   ax
    600d:	9a ff ff 00 00       	call   0x0:0xffff
    6012:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6015:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    601b:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    6021:	c9                   	leave
    6022:	ca 08 00             	retf   0x8
    6025:	55                   	push   bp
    6026:	89 e5                	mov    bp,sp
    6028:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    602b:	06                   	push   es
    602c:	57                   	push   di
    602d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6030:	06                   	push   es
    6031:	57                   	push   di
    6032:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6035:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    6039:	c9                   	leave
    603a:	ca 08 00             	retf   0x8
    603d:	55                   	push   bp
    603e:	89 e5                	mov    bp,sp
    6040:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6043:	06                   	push   es
    6044:	57                   	push   di
    6045:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6048:	06                   	push   es
    6049:	57                   	push   di
    604a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    604d:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    6051:	c9                   	leave
    6052:	ca 08 00             	retf   0x8
    6055:	55                   	push   bp
    6056:	89 e5                	mov    bp,sp
    6058:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    605b:	06                   	push   es
    605c:	57                   	push   di
    605d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6060:	06                   	push   es
    6061:	57                   	push   di
    6062:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6065:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    6069:	c9                   	leave
    606a:	ca 08 00             	retf   0x8
    606d:	c8 04 00 00          	enter  0x4,0x0
    6071:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6074:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6077:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    607a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    607e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6081:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    6085:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    6089:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    608d:	9a a5 0c ad 60       	call   0x60ad:0xca5
    6092:	52                   	push   dx
    6093:	50                   	push   ax
    6094:	9a ff ff 00 00       	call   0x0:0xffff
    6099:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    609c:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    60a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60a3:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    60a8:	06                   	push   es
    60a9:	57                   	push   di
    60aa:	9a 61 16 b4 60       	call   0x60b4:0x1661
    60af:	52                   	push   dx
    60b0:	50                   	push   ax
    60b1:	9a a5 0c ca 60       	call   0x60ca:0xca5
    60b6:	52                   	push   dx
    60b7:	50                   	push   ax
    60b8:	9a ff ff 00 00       	call   0x0:0xffff
    60bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60c0:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    60c5:	06                   	push   es
    60c6:	57                   	push   di
    60c7:	9a c0 16 53 61       	call   0x6153:0x16c0
    60cc:	31 d2                	xor    dx,dx
    60ce:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    60d1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    60d5:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    60d9:	c9                   	leave
    60da:	ca 08 00             	retf   0x8
    60dd:	55                   	push   bp
    60de:	89 e5                	mov    bp,sp
    60e0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    60e3:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    60e7:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    60eb:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    60ee:	75 05                	jne    0x60f5
    60f0:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    60f3:	74 13                	je     0x6108
    60f5:	68 0f 04             	push   0x40f
    60f8:	6a 00                	push   0x0
    60fa:	6a 00                	push   0x0
    60fc:	6a 00                	push   0x0
    60fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6101:	06                   	push   es
    6102:	57                   	push   di
    6103:	9a bb 24 1d 61       	call   0x611d:0x24bb
    6108:	c9                   	leave
    6109:	ca 08 00             	retf   0x8
    610c:	55                   	push   bp
    610d:	89 e5                	mov    bp,sp
    610f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6112:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6115:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6118:	06                   	push   es
    6119:	57                   	push   di
    611a:	9a 59 2d 72 61       	call   0x6172:0x2d59
    611f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6122:	26 80 bd e1 00 02    	cmp    BYTE PTR es:[di+0xe1],0x2
    6128:	7d 09                	jge    0x6133
    612a:	06                   	push   es
    612b:	57                   	push   di
    612c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    612f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6133:	c9                   	leave
    6134:	ca 08 00             	retf   0x8
    6137:	55                   	push   bp
    6138:	89 e5                	mov    bp,sp
    613a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    613d:	26 80 bd e1 00 02    	cmp    BYTE PTR es:[di+0xe1],0x2
    6143:	7d 1f                	jge    0x6164
    6145:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6149:	26 c4 bd 9e 00       	les    di,DWORD PTR es:[di+0x9e]
    614e:	06                   	push   es
    614f:	57                   	push   di
    6150:	9a c0 16 ae 64       	call   0x64ae:0x16c0
    6155:	31 d2                	xor    dx,dx
    6157:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    615a:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    615e:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    6162:	eb 10                	jmp    0x6174
    6164:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6167:	ff 76 0a             	push   WORD PTR [bp+0xa]
    616a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616d:	06                   	push   es
    616e:	57                   	push   di
    616f:	9a ca 58 95 61       	call   0x6195:0x58ca
    6174:	c9                   	leave
    6175:	ca 08 00             	retf   0x8
    6178:	c8 04 00 00          	enter  0x4,0x0
    617c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    617f:	26 81 3d 00 02       	cmp    WORD PTR es:[di],0x200
    6184:	72 1f                	jb     0x61a5
    6186:	26 81 3d 09 02       	cmp    WORD PTR es:[di],0x209
    618b:	77 18                	ja     0x61a5
    618d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6190:	06                   	push   es
    6191:	57                   	push   di
    6192:	9a 96 24 a3 61       	call   0x61a3:0x2496
    6197:	08 c0                	or     al,al
    6199:	74 0a                	je     0x61a5
    619b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    619e:	06                   	push   es
    619f:	57                   	push   di
    61a0:	9a 65 11 11 62       	call   0x6211:0x1165
    61a5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    61a8:	26 81 3d 12 01       	cmp    WORD PTR es:[di],0x112
    61ad:	75 10                	jne    0x61bf
    61af:	06                   	push   es
    61b0:	57                   	push   di
    61b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61b4:	06                   	push   es
    61b5:	57                   	push   di
    61b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61b9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    61bd:	eb 7e                	jmp    0x623d
    61bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    61c2:	06                   	push   es
    61c3:	57                   	push   di
    61c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61c7:	26 ff b5 16 01       	push   WORD PTR es:[di+0x116]
    61cc:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    61d1:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    61d6:	06                   	push   es
    61d7:	57                   	push   di
    61d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61db:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    61df:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    61e2:	26 8b 05             	mov    ax,WORD PTR es:[di]
    61e5:	3d 01 02             	cmp    ax,0x201
    61e8:	74 05                	je     0x61ef
    61ea:	3d 03 02             	cmp    ax,0x203
    61ed:	75 4e                	jne    0x623d
    61ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61f2:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    61f7:	75 44                	jne    0x623d
    61f9:	8d 7e fc             	lea    di,[bp-0x4]
    61fc:	16                   	push   ss
    61fd:	57                   	push   di
    61fe:	9a 73 80 00 00       	call   0x0:0x8073
    6203:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6206:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6209:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    620c:	06                   	push   es
    620d:	57                   	push   di
    620e:	9a 06 1a 3b 62       	call   0x623b:0x1a06
    6213:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6216:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6219:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    621c:	26 ff b5 16 01       	push   WORD PTR es:[di+0x116]
    6221:	68 02 02             	push   0x202
    6224:	6a 00                	push   0x0
    6226:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6229:	ff 76 fc             	push   WORD PTR [bp-0x4]
    622c:	9a b4 6a 00 00       	call   0x0:0x6ab4
    6231:	6a 00                	push   0x0
    6233:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6236:	06                   	push   es
    6237:	57                   	push   di
    6238:	9a c6 23 fe 62       	call   0x62fe:0x23c6
    623d:	c9                   	leave
    623e:	ca 08 00             	retf   0x8
    6241:	55                   	push   bp
    6242:	89 e5                	mov    bp,sp
    6244:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6247:	06                   	push   es
    6248:	57                   	push   di
    6249:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    624c:	26 ff b5 18 01       	push   WORD PTR es:[di+0x118]
    6251:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    6256:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    625b:	06                   	push   es
    625c:	57                   	push   di
    625d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6260:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    6264:	c9                   	leave
    6265:	ca 08 00             	retf   0x8
    6268:	01 00                	add    WORD PTR [bx+si],ax
    626a:	00 00                	add    BYTE PTR [bx+si],al
    626c:	00 00                	add    BYTE PTR [bx+si],al
    626e:	fb                   	sti
    626f:	63 c1                	arpl   cx,ax
    6271:	65 c8 04 00 00       	gs enter 0x4,0x0
    6276:	b8 68 62             	mov    ax,0x6268
    6279:	0e                   	push   cs
    627a:	50                   	push   ax
    627b:	55                   	push   bp
    627c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6280:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6284:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    6287:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    628a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    628d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6290:	3d 07 00             	cmp    ax,0x7
    6293:	75 2b                	jne    0x62c0
    6295:	ff 76 08             	push   WORD PTR [bp+0x8]
    6298:	ff 76 06             	push   WORD PTR [bp+0x6]
    629b:	ff 76 08             	push   WORD PTR [bp+0x8]
    629e:	ff 76 06             	push   WORD PTR [bp+0x6]
    62a1:	9a a8 17 af 62       	call   0x62af:0x17a8
    62a6:	89 c7                	mov    di,ax
    62a8:	8e c2                	mov    es,dx
    62aa:	06                   	push   es
    62ab:	57                   	push   di
    62ac:	9a 22 41 0a 64       	call   0x640a:0x4122
    62b1:	08 c0                	or     al,al
    62b3:	75 08                	jne    0x62bd
    62b5:	9a 6a 14 d2 62       	call   0x62d2:0x146a
    62ba:	e9 54 01             	jmp    0x6411
    62bd:	e9 07 01             	jmp    0x63c7
    62c0:	3d 08 00             	cmp    ax,0x8
    62c3:	75 15                	jne    0x62da
    62c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62c8:	26 f6 45 28 20       	test   BYTE PTR es:[di+0x28],0x20
    62cd:	74 08                	je     0x62d7
    62cf:	9a 6a 14 07 63       	call   0x6307:0x146a
    62d4:	e9 3a 01             	jmp    0x6411
    62d7:	e9 ed 00             	jmp    0x63c7
    62da:	3d 00 01             	cmp    ax,0x100
    62dd:	74 05                	je     0x62e4
    62df:	3d 04 01             	cmp    ax,0x104
    62e2:	75 2b                	jne    0x630f
    62e4:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    62e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ea:	26 3b 85 18 01       	cmp    ax,WORD PTR es:[di+0x118]
    62ef:	74 1b                	je     0x630c
    62f1:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    62f4:	06                   	push   es
    62f5:	57                   	push   di
    62f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62f9:	06                   	push   es
    62fa:	57                   	push   di
    62fb:	9a 9e 4f 21 63       	call   0x6321:0x4f9e
    6300:	08 c0                	or     al,al
    6302:	74 08                	je     0x630c
    6304:	9a 6a 14 2a 63       	call   0x632a:0x146a
    6309:	e9 05 01             	jmp    0x6411
    630c:	e9 b8 00             	jmp    0x63c7
    630f:	3d 02 01             	cmp    ax,0x102
    6312:	75 1e                	jne    0x6332
    6314:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    6317:	06                   	push   es
    6318:	57                   	push   di
    6319:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    631c:	06                   	push   es
    631d:	57                   	push   di
    631e:	9a 4f 52 49 63       	call   0x6349:0x524f
    6323:	08 c0                	or     al,al
    6325:	74 08                	je     0x632f
    6327:	9a 6a 14 52 63       	call   0x6352:0x146a
    632c:	e9 e2 00             	jmp    0x6411
    632f:	e9 95 00             	jmp    0x63c7
    6332:	3d 01 01             	cmp    ax,0x101
    6335:	74 05                	je     0x633c
    6337:	3d 05 01             	cmp    ax,0x105
    633a:	75 1d                	jne    0x6359
    633c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    633f:	06                   	push   es
    6340:	57                   	push   di
    6341:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6344:	06                   	push   es
    6345:	57                   	push   di
    6346:	9a 32 51 3b 64       	call   0x643b:0x5132
    634b:	08 c0                	or     al,al
    634d:	74 08                	je     0x6357
    634f:	9a 6a 14 70 63       	call   0x6370:0x146a
    6354:	e9 ba 00             	jmp    0x6411
    6357:	eb 6e                	jmp    0x63c7
    6359:	3d 03 02             	cmp    ax,0x203
    635c:	75 16                	jne    0x6374
    635e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6361:	26 f6 45 26 80       	test   BYTE PTR es:[di+0x26],0x80
    6366:	74 0a                	je     0x6372
    6368:	06                   	push   es
    6369:	57                   	push   di
    636a:	b8 fd ff             	mov    ax,0xfffd
    636d:	9a 6a 20 95 63       	call   0x6395:0x206a
    6372:	eb 53                	jmp    0x63c7
    6374:	3d 84 00             	cmp    ax,0x84
    6377:	75 22                	jne    0x639b
    6379:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    637c:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    6381:	74 16                	je     0x6399
    6383:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6386:	26 c7 45 08 ff ff    	mov    WORD PTR es:[di+0x8],0xffff
    638c:	26 c7 45 0a ff ff    	mov    WORD PTR es:[di+0xa],0xffff
    6392:	9a 6a 14 c3 63       	call   0x63c3:0x146a
    6397:	eb 78                	jmp    0x6411
    6399:	eb 2c                	jmp    0x63c7
    639b:	3d 00 21             	cmp    ax,0x2100
    639e:	74 0f                	je     0x63af
    63a0:	3d 02 21             	cmp    ax,0x2102
    63a3:	74 0a                	je     0x63af
    63a5:	3d 04 21             	cmp    ax,0x2104
    63a8:	74 05                	je     0x63af
    63aa:	3d 06 21             	cmp    ax,0x2106
    63ad:	75 18                	jne    0x63c7
    63af:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    63b2:	06                   	push   es
    63b3:	57                   	push   di
    63b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63b7:	06                   	push   es
    63b8:	57                   	push   di
    63b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    63bc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    63c0:	9a 6a 14 0f 64       	call   0x640f:0x146a
    63c5:	eb 4a                	jmp    0x6411
    63c7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    63ca:	ff 76 0a             	push   WORD PTR [bp+0xa]
    63cd:	ff 76 0e             	push   WORD PTR [bp+0xe]
    63d0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    63d3:	26 ff 35             	push   WORD PTR es:[di]
    63d6:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    63da:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    63de:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    63e2:	9a ff ff 00 00       	call   0x0:0xffff
    63e7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    63ea:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    63ee:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    63f2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    63f6:	83 c4 06             	add    sp,0x6
    63f9:	eb 16                	jmp    0x6411
    63fb:	ff 76 08             	push   WORD PTR [bp+0x8]
    63fe:	ff 76 06             	push   WORD PTR [bp+0x6]
    6401:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6405:	06                   	push   es
    6406:	57                   	push   di
    6407:	9a 51 75 22 6a       	call   0x6a22:0x7551
    640c:	9a 34 14 7a 64       	call   0x647a:0x1434
    6411:	c9                   	leave
    6412:	ca 0e 00             	retf   0xe
    6415:	55                   	push   bp
    6416:	89 e5                	mov    bp,sp
    6418:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    641b:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    6420:	75 5c                	jne    0x647e
    6422:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6425:	26 81 3d 01 02       	cmp    WORD PTR es:[di],0x201
    642a:	74 07                	je     0x6433
    642c:	26 81 3d 03 02       	cmp    WORD PTR es:[di],0x203
    6431:	75 4b                	jne    0x647e
    6433:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6436:	06                   	push   es
    6437:	57                   	push   di
    6438:	9a 96 24 58 64       	call   0x6458:0x2496
    643d:	08 c0                	or     al,al
    643f:	75 3d                	jne    0x647e
    6441:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6444:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    6449:	75 33                	jne    0x647e
    644b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    644e:	06                   	push   es
    644f:	57                   	push   di
    6450:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6453:	06                   	push   es
    6454:	57                   	push   di
    6455:	9a 87 43 8b 64       	call   0x648b:0x4387
    645a:	08 c0                	or     al,al
    645c:	74 02                	je     0x6460
    645e:	eb 2d                	jmp    0x648d
    6460:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6463:	26 8a 45 28          	mov    al,BYTE PTR es:[di+0x28]
    6467:	0c 01                	or     al,0x1
    6469:	26 88 45 28          	mov    BYTE PTR es:[di+0x28],al
    646d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6470:	06                   	push   es
    6471:	57                   	push   di
    6472:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6475:	06                   	push   es
    6476:	57                   	push   di
    6477:	9a 38 20 91 65       	call   0x6591:0x2038
    647c:	eb 0f                	jmp    0x648d
    647e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6481:	06                   	push   es
    6482:	57                   	push   di
    6483:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6486:	06                   	push   es
    6487:	57                   	push   di
    6488:	9a 46 44 15 65       	call   0x6515:0x4446
    648d:	c9                   	leave
    648e:	ca 08 00             	retf   0x8
    6491:	c8 26 00 00          	enter  0x26,0x0
    6495:	6a 00                	push   0x0
    6497:	9a ff ff 00 00       	call   0x0:0xffff
    649c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    649f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    64a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64a5:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    64a9:	06                   	push   es
    64aa:	57                   	push   di
    64ab:	9a 16 10 f6 66       	call   0x66f6:0x1016
    64b0:	50                   	push   ax
    64b1:	9a cd 64 00 00       	call   0x0:0x64cd
    64b6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    64b9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    64bc:	8d 7e da             	lea    di,[bp-0x26]
    64bf:	16                   	push   ss
    64c0:	57                   	push   di
    64c1:	9a ff ff 00 00       	call   0x0:0xffff
    64c6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    64c9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    64cc:	9a ff ff 00 00       	call   0x0:0xffff
    64d1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    64d4:	9a ff ff 00 00       	call   0x0:0xffff
    64d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64dc:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    64e1:	06                   	push   es
    64e2:	57                   	push   di
    64e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    64e6:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    64ea:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    64ed:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    64f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64f3:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    64f8:	7e 08                	jle    0x6502
    64fa:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    64ff:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6502:	83 7e fa 01          	cmp    WORD PTR [bp-0x6],0x1
    6506:	7d 05                	jge    0x650d
    6508:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    650d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6510:	06                   	push   es
    6511:	57                   	push   di
    6512:	9a b9 62 41 65       	call   0x6541:0x62b9
    6517:	50                   	push   ax
    6518:	6a 00                	push   0x0
    651a:	6a 00                	push   0x0
    651c:	6a 00                	push   0x0
    651e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6521:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    6525:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    6528:	f7 66 fa             	mul    WORD PTR [bp-0x6]
    652b:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    652f:	40                   	inc    ax
    6530:	50                   	push   ax
    6531:	68 9e 00             	push   0x9e
    6534:	9a 51 65 00 00       	call   0x0:0x6551
    6539:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    653c:	06                   	push   es
    653d:	57                   	push   di
    653e:	9a b9 62 d3 65       	call   0x65d3:0x62b9
    6543:	50                   	push   ax
    6544:	6a 00                	push   0x0
    6546:	6a 00                	push   0x0
    6548:	6a 00                	push   0x0
    654a:	6a 00                	push   0x0
    654c:	6a 00                	push   0x0
    654e:	6a 5f                	push   0x5f
    6550:	9a ff ff 00 00       	call   0x0:0xffff
    6555:	c9                   	leave
    6556:	ca 04 00             	retf   0x4
    6559:	06                   	push   es
    655a:	66 86 65 4e          	data32 xchg BYTE PTR [di+0x4e],ah
    655e:	66 5f                	pop    edi
    6560:	66 96                	xchg   esi,eax
    6562:	65 6e                	outs   dx,BYTE PTR gs:[si]
    6564:	66 a6                	data32 cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    6566:	65 c8 00 01 00       	gs enter 0x100,0x0
    656b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    656e:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    6572:	2d 01 00             	sub    ax,0x1
    6575:	3d 06 00             	cmp    ax,0x6
    6578:	76 03                	jbe    0x657d
    657a:	e9 f1 00             	jmp    0x666e
    657d:	89 c3                	mov    bx,ax
    657f:	d1 e3                	shl    bx,1
    6581:	2e ff a7 59 65       	jmp    WORD PTR cs:[bx+0x6559]
    6586:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6589:	06                   	push   es
    658a:	57                   	push   di
    658b:	b8 fd ff             	mov    ax,0xfffd
    658e:	9a 6a 20 a1 65       	call   0x65a1:0x206a
    6593:	e9 d8 00             	jmp    0x666e
    6596:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6599:	06                   	push   es
    659a:	57                   	push   di
    659b:	b8 ee ff             	mov    ax,0xffee
    659e:	9a 6a 20 b7 65       	call   0x65b7:0x206a
    65a3:	e9 c8 00             	jmp    0x666e
    65a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a9:	26 c6 85 f9 00 00    	mov    BYTE PTR es:[di+0xf9],0x0
    65af:	06                   	push   es
    65b0:	57                   	push   di
    65b1:	b8 ed ff             	mov    ax,0xffed
    65b4:	9a 6a 20 3d 66       	call   0x663d:0x206a
    65b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65bc:	06                   	push   es
    65bd:	57                   	push   di
    65be:	9a 91 64 14 66       	call   0x6614:0x6491
    65c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65c6:	26 80 bd f9 00 00    	cmp    BYTE PTR es:[di+0xf9],0x0
    65cc:	74 36                	je     0x6604
    65ce:	06                   	push   es
    65cf:	57                   	push   di
    65d0:	9a b9 62 f3 65       	call   0x65f3:0x62b9
    65d5:	50                   	push   ax
    65d6:	6a 1f                	push   0x1f
    65d8:	6a 00                	push   0x0
    65da:	6a 00                	push   0x0
    65dc:	6a 00                	push   0x0
    65de:	9a 00 66 00 00       	call   0x0:0x6600
    65e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65e6:	26 80 bd f8 00 00    	cmp    BYTE PTR es:[di+0xf8],0x0
    65ec:	75 16                	jne    0x6604
    65ee:	06                   	push   es
    65ef:	57                   	push   di
    65f0:	9a b9 62 30 66       	call   0x6630:0x62b9
    65f5:	50                   	push   ax
    65f6:	68 0f 04             	push   0x40f
    65f9:	6a 00                	push   0x0
    65fb:	6a 00                	push   0x0
    65fd:	6a 00                	push   0x0
    65ff:	9a ff ff 00 00       	call   0x0:0xffff
    6604:	eb 68                	jmp    0x666e
    6606:	8d be 00 ff          	lea    di,[bp-0x100]
    660a:	16                   	push   ss
    660b:	57                   	push   di
    660c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    660f:	06                   	push   es
    6610:	57                   	push   di
    6611:	9a 07 5c a3 6c       	call   0x6ca3:0x5c07
    6616:	50                   	push   ax
    6617:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    661a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    661f:	06                   	push   es
    6620:	57                   	push   di
    6621:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6624:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    6628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    662b:	06                   	push   es
    662c:	57                   	push   di
    662d:	9a 8c 1d 1d 69       	call   0x691d:0x1d8c
    6632:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6635:	06                   	push   es
    6636:	57                   	push   di
    6637:	b8 fe ff             	mov    ax,0xfffe
    663a:	9a 6a 20 4a 66       	call   0x664a:0x206a
    663f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6642:	06                   	push   es
    6643:	57                   	push   di
    6644:	b8 ee ff             	mov    ax,0xffee
    6647:	9a 6a 20 bf 69       	call   0x69bf:0x206a
    664c:	eb 20                	jmp    0x666e
    664e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6651:	26 c6 85 f8 00 01    	mov    BYTE PTR es:[di+0xf8],0x1
    6657:	26 c6 85 f9 00 01    	mov    BYTE PTR es:[di+0xf9],0x1
    665d:	eb 0f                	jmp    0x666e
    665f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6662:	26 c6 85 f8 00 00    	mov    BYTE PTR es:[di+0xf8],0x0
    6668:	26 c6 85 f9 00 01    	mov    BYTE PTR es:[di+0xf9],0x1
    666e:	c9                   	leave
    666f:	ca 08 00             	retf   0x8
    6672:	55                   	push   bp
    6673:	89 e5                	mov    bp,sp
    6675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6678:	26 8b 85 1c 01       	mov    ax,WORD PTR es:[di+0x11c]
    667d:	09 c0                	or     ax,ax
    667f:	74 15                	je     0x6696
    6681:	ff 76 08             	push   WORD PTR [bp+0x8]
    6684:	ff 76 06             	push   WORD PTR [bp+0x6]
    6687:	26 ff b5 20 01       	push   WORD PTR es:[di+0x120]
    668c:	26 ff b5 1e 01       	push   WORD PTR es:[di+0x11e]
    6691:	26 ff 9d 1a 01       	call   DWORD PTR es:[di+0x11a]
    6696:	c9                   	leave
    6697:	ca 04 00             	retf   0x4
    669a:	c8 08 01 00          	enter  0x108,0x0
    669e:	8c d3                	mov    bx,ss
    66a0:	8e c3                	mov    es,bx
    66a2:	8c db                	mov    bx,ds
    66a4:	fc                   	cld
    66a5:	8d 7e f8             	lea    di,[bp-0x8]
    66a8:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    66ab:	b9 08 00             	mov    cx,0x8
    66ae:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    66b0:	8e db                	mov    ds,bx
    66b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66b5:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    66ba:	09 c0                	or     ax,ax
    66bc:	74 26                	je     0x66e4
    66be:	ff 76 08             	push   WORD PTR [bp+0x8]
    66c1:	ff 76 06             	push   WORD PTR [bp+0x6]
    66c4:	ff 76 10             	push   WORD PTR [bp+0x10]
    66c7:	8d 7e f8             	lea    di,[bp-0x8]
    66ca:	16                   	push   ss
    66cb:	57                   	push   di
    66cc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    66cf:	50                   	push   ax
    66d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66d3:	26 ff b5 0c 01       	push   WORD PTR es:[di+0x10c]
    66d8:	26 ff b5 0a 01       	push   WORD PTR es:[di+0x10a]
    66dd:	26 ff 9d 06 01       	call   DWORD PTR es:[di+0x106]
    66e2:	eb 46                	jmp    0x672a
    66e4:	8d 7e f8             	lea    di,[bp-0x8]
    66e7:	16                   	push   ss
    66e8:	57                   	push   di
    66e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66ec:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    66f1:	06                   	push   es
    66f2:	57                   	push   di
    66f3:	9a e5 1c 28 67       	call   0x6728:0x1ce5
    66f8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    66fb:	40                   	inc    ax
    66fc:	40                   	inc    ax
    66fd:	50                   	push   ax
    66fe:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6701:	8d be f8 fe          	lea    di,[bp-0x108]
    6705:	16                   	push   ss
    6706:	57                   	push   di
    6707:	ff 76 10             	push   WORD PTR [bp+0x10]
    670a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    670d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    6712:	06                   	push   es
    6713:	57                   	push   di
    6714:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6717:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    671b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    671e:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    6723:	06                   	push   es
    6724:	57                   	push   di
    6725:	9a 09 1f b2 67       	call   0x67b2:0x1f09
    672a:	c9                   	leave
    672b:	ca 0c 00             	retf   0xc
    672e:	55                   	push   bp
    672f:	89 e5                	mov    bp,sp
    6731:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6734:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    6739:	09 c0                	or     ax,ax
    673b:	74 15                	je     0x6752
    673d:	ff 76 08             	push   WORD PTR [bp+0x8]
    6740:	ff 76 06             	push   WORD PTR [bp+0x6]
    6743:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    6748:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    674d:	26 ff 9d fe 00       	call   DWORD PTR es:[di+0xfe]
    6752:	c9                   	leave
    6753:	ca 04 00             	retf   0x4
    6756:	55                   	push   bp
    6757:	89 e5                	mov    bp,sp
    6759:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    675c:	26 8b 85 10 01       	mov    ax,WORD PTR es:[di+0x110]
    6761:	09 c0                	or     ax,ax
    6763:	74 20                	je     0x6785
    6765:	ff 76 08             	push   WORD PTR [bp+0x8]
    6768:	ff 76 06             	push   WORD PTR [bp+0x6]
    676b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    676e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6771:	06                   	push   es
    6772:	57                   	push   di
    6773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6776:	26 ff b5 14 01       	push   WORD PTR es:[di+0x114]
    677b:	26 ff b5 12 01       	push   WORD PTR es:[di+0x112]
    6780:	26 ff 9d 0e 01       	call   DWORD PTR es:[di+0x10e]
    6785:	c9                   	leave
    6786:	ca 0a 00             	retf   0xa
    6789:	c8 06 00 00          	enter  0x6,0x0
    678d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6790:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    6794:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6797:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    679a:	26 8a 45 08          	mov    al,BYTE PTR es:[di+0x8]
    679e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    67a1:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    67a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67a8:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    67ad:	06                   	push   es
    67ae:	57                   	push   di
    67af:	9a 5d 22 c9 67       	call   0x67c9:0x225d
    67b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67b7:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    67bb:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    67bf:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    67c4:	06                   	push   es
    67c5:	57                   	push   di
    67c6:	9a 99 20 e2 67       	call   0x67e2:0x2099
    67cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67ce:	26 ff b5 a0 00       	push   WORD PTR es:[di+0xa0]
    67d3:	26 ff b5 9e 00       	push   WORD PTR es:[di+0x9e]
    67d8:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    67dd:	06                   	push   es
    67de:	57                   	push   di
    67df:	9a d3 20 09 68       	call   0x6809:0x20d3
    67e4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    67e7:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    67ec:	7c 34                	jl     0x6822
    67ee:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
    67f2:	74 2e                	je     0x6822
    67f4:	6a ff                	push   0xffff
    67f6:	6a f2                	push   0xfff2
    67f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67fb:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    6800:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    6804:	06                   	push   es
    6805:	57                   	push   di
    6806:	9a 84 16 20 68       	call   0x6820:0x1684
    680b:	6a ff                	push   0xffff
    680d:	6a f1                	push   0xfff1
    680f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6812:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    6817:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    681b:	06                   	push   es
    681c:	57                   	push   di
    681d:	9a df 0f 5f 68       	call   0x685f:0xfdf
    6822:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6825:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    682a:	7c 1d                	jl     0x6849
    682c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6830:	81 c7 0e 00          	add    di,0xe
    6834:	06                   	push   es
    6835:	57                   	push   di
    6836:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6839:	50                   	push   ax
    683a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    683d:	06                   	push   es
    683e:	57                   	push   di
    683f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6842:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    6847:	eb 18                	jmp    0x6861
    6849:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    684c:	81 c7 0e 00          	add    di,0xe
    6850:	06                   	push   es
    6851:	57                   	push   di
    6852:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6855:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    685a:	06                   	push   es
    685b:	57                   	push   di
    685c:	9a e5 1c 88 68       	call   0x6888:0x1ce5
    6861:	f6 46 ff 10          	test   BYTE PTR [bp-0x1],0x10
    6865:	74 12                	je     0x6879
    6867:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    686a:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    686e:	81 c7 0e 00          	add    di,0xe
    6872:	06                   	push   es
    6873:	57                   	push   di
    6874:	9a 8d 82 00 00       	call   0x0:0x828d
    6879:	6a 00                	push   0x0
    687b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    687e:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    6883:	06                   	push   es
    6884:	57                   	push   di
    6885:	9a 5d 22 77 76       	call   0x7677:0x225d
    688a:	c9                   	leave
    688b:	ca 08 00             	retf   0x8
    688e:	c8 04 00 00          	enter  0x4,0x0
    6892:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6895:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    6899:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    689c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    689f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68a2:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    68a7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    68aa:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    68ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68b1:	26 80 bd e1 00 04    	cmp    BYTE PTR es:[di+0xe1],0x4
    68b7:	75 1a                	jne    0x68d3
    68b9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    68bc:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    68c0:	81 c7 08 00          	add    di,0x8
    68c4:	06                   	push   es
    68c5:	57                   	push   di
    68c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68c9:	06                   	push   es
    68ca:	57                   	push   di
    68cb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    68ce:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    68d3:	c9                   	leave
    68d4:	ca 08 00             	retf   0x8
    68d7:	55                   	push   bp
    68d8:	89 e5                	mov    bp,sp
    68da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68dd:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    68e2:	75 3d                	jne    0x6921
    68e4:	26 80 bd e1 00 02    	cmp    BYTE PTR es:[di+0xe1],0x2
    68ea:	75 35                	jne    0x6921
    68ec:	6a 15                	push   0x15
    68ee:	9a 22 83 00 00       	call   0x0:0x8322
    68f3:	8b d0                	mov    dx,ax
    68f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68f8:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    68fc:	2b c2                	sub    ax,dx
    68fe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6901:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    6905:	7e 1a                	jle    0x6921
    6907:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    690a:	06                   	push   es
    690b:	57                   	push   di
    690c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    690f:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    6913:	6a 00                	push   0x0
    6915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6918:	06                   	push   es
    6919:	57                   	push   di
    691a:	9a c6 23 2f 69       	call   0x692f:0x23c6
    691f:	eb 10                	jmp    0x6931
    6921:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6924:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6927:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    692a:	06                   	push   es
    692b:	57                   	push   di
    692c:	9a 2c 28 57 69       	call   0x6957:0x282c
    6931:	c9                   	leave
    6932:	ca 08 00             	retf   0x8
    6935:	55                   	push   bp
    6936:	89 e5                	mov    bp,sp
    6938:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    693b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    693e:	3d 01 02             	cmp    ax,0x201
    6941:	74 05                	je     0x6948
    6943:	3d 03 02             	cmp    ax,0x203
    6946:	75 43                	jne    0x698b
    6948:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    694b:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    6950:	75 37                	jne    0x6989
    6952:	06                   	push   es
    6953:	57                   	push   di
    6954:	9a 58 62 6b 69       	call   0x696b:0x6258
    6959:	08 c0                	or     al,al
    695b:	75 2c                	jne    0x6989
    695d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6960:	26 c6 85 d8 00 01    	mov    BYTE PTR es:[di+0xd8],0x1
    6966:	06                   	push   es
    6967:	57                   	push   di
    6968:	9a b9 62 81 69       	call   0x6981:0x62b9
    696d:	50                   	push   ax
    696e:	9a ff ff 00 00       	call   0x0:0xffff
    6973:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6976:	26 c6 85 d8 00 00    	mov    BYTE PTR es:[di+0xd8],0x0
    697c:	06                   	push   es
    697d:	57                   	push   di
    697e:	9a 58 62 aa 69       	call   0x69aa:0x6258
    6983:	08 c0                	or     al,al
    6985:	75 02                	jne    0x6989
    6987:	eb 23                	jmp    0x69ac
    6989:	eb 12                	jmp    0x699d
    698b:	3d 11 21             	cmp    ax,0x2111
    698e:	75 0d                	jne    0x699d
    6990:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6993:	26 80 bd d8 00 00    	cmp    BYTE PTR es:[di+0xd8],0x0
    6999:	74 02                	je     0x699d
    699b:	eb 0f                	jmp    0x69ac
    699d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    69a0:	06                   	push   es
    69a1:	57                   	push   di
    69a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69a5:	06                   	push   es
    69a6:	57                   	push   di
    69a7:	9a 46 44 d2 69       	call   0x69d2:0x4446
    69ac:	c9                   	leave
    69ad:	ca 08 00             	retf   0x8
    69b0:	55                   	push   bp
    69b1:	89 e5                	mov    bp,sp
    69b3:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    69b7:	74 08                	je     0x69c1
    69b9:	83 ec 08             	sub    sp,0x8
    69bc:	9a e2 1f 92 6b       	call   0x6b92:0x1fe2
    69c1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    69c4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    69c7:	31 c0                	xor    ax,ax
    69c9:	50                   	push   ax
    69ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69cd:	06                   	push   es
    69ce:	57                   	push   di
    69cf:	9a 61 2e e4 69       	call   0x69e4:0x2e61
    69d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69d7:	26 c7 45 26 e0 00    	mov    WORD PTR es:[di+0x26],0xe0
    69dd:	6a 59                	push   0x59
    69df:	06                   	push   es
    69e0:	57                   	push   di
    69e1:	9a bf 17 f0 69       	call   0x69f0:0x17bf
    69e6:	6a 21                	push   0x21
    69e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69eb:	06                   	push   es
    69ec:	57                   	push   di
    69ed:	9a e1 17 fc 69       	call   0x69fc:0x17e1
    69f2:	6a 01                	push   0x1
    69f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69f7:	06                   	push   es
    69f8:	57                   	push   di
    69f9:	9a 88 64 4a 6a       	call   0x6a4a:0x6488
    69fe:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6a02:	74 07                	je     0x6a0b
    6a04:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6a08:	83 c4 06             	add    sp,0x6
    6a0b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6a0e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6a11:	c9                   	leave
    6a12:	ca 0a 00             	retf   0xa
    6a15:	c8 04 00 00          	enter  0x4,0x0
    6a19:	ff 76 08             	push   WORD PTR [bp+0x8]
    6a1c:	ff 76 06             	push   WORD PTR [bp+0x6]
    6a1f:	9a a8 17 df 6a       	call   0x6adf:0x17a8
    6a24:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6a27:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6a2a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6a2d:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    6a30:	74 10                	je     0x6a42
    6a32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a35:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    6a3a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6a3d:	26 89 85 04 01       	mov    WORD PTR es:[di+0x104],ax
    6a42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a45:	06                   	push   es
    6a46:	57                   	push   di
    6a47:	9a 73 27 5c 6a       	call   0x6a5c:0x2773
    6a4c:	c9                   	leave
    6a4d:	ca 04 00             	retf   0x4
    6a50:	c8 02 00 00          	enter  0x2,0x0
    6a54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a57:	06                   	push   es
    6a58:	57                   	push   di
    6a59:	9a fa 64 7c 6a       	call   0x6a7c:0x64fa
    6a5e:	08 c0                	or     al,al
    6a60:	74 56                	je     0x6ab8
    6a62:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6a66:	74 07                	je     0x6a6f
    6a68:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    6a6d:	eb 05                	jmp    0x6a74
    6a6f:	31 c0                	xor    ax,ax
    6a71:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6a74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a77:	06                   	push   es
    6a78:	57                   	push   di
    6a79:	9a b9 62 a6 6a       	call   0x6aa6:0x62b9
    6a7e:	50                   	push   ax
    6a7f:	6a f0                	push   0xfff0
    6a81:	9a ff ff 00 00       	call   0x0:0xffff
    6a86:	25 0f 00             	and    ax,0xf
    6a89:	81 e2 00 00          	and    dx,0x0
    6a8d:	8b c8                	mov    cx,ax
    6a8f:	8b da                	mov    bx,dx
    6a91:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6a94:	31 d2                	xor    dx,dx
    6a96:	3b d3                	cmp    dx,bx
    6a98:	75 04                	jne    0x6a9e
    6a9a:	3b c1                	cmp    ax,cx
    6a9c:	74 1a                	je     0x6ab8
    6a9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aa1:	06                   	push   es
    6aa2:	57                   	push   di
    6aa3:	9a b9 62 d0 6a       	call   0x6ad0:0x62b9
    6aa8:	50                   	push   ax
    6aa9:	68 04 04             	push   0x404
    6aac:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6aaf:	6a 00                	push   0x0
    6ab1:	6a 01                	push   0x1
    6ab3:	9a 78 6e 00 00       	call   0x0:0x6e78
    6ab8:	c9                   	leave
    6ab9:	ca 06 00             	retf   0x6
    6abc:	c8 04 00 00          	enter  0x4,0x0
    6ac0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6ac3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ac6:	26 88 85 da 00       	mov    BYTE PTR es:[di+0xda],al
    6acb:	06                   	push   es
    6acc:	57                   	push   di
    6acd:	9a fa 64 f9 6a       	call   0x6af9:0x64fa
    6ad2:	08 c0                	or     al,al
    6ad4:	74 25                	je     0x6afb
    6ad6:	ff 76 08             	push   WORD PTR [bp+0x8]
    6ad9:	ff 76 06             	push   WORD PTR [bp+0x6]
    6adc:	9a a8 17 da 6b       	call   0x6bda:0x17a8
    6ae1:	89 c7                	mov    di,ax
    6ae3:	8e c2                	mov    es,dx
    6ae5:	68 07 0f             	push   0xf07
    6ae8:	6a 00                	push   0x0
    6aea:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    6aef:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    6af4:	06                   	push   es
    6af5:	57                   	push   di
    6af6:	9a bb 24 10 6b       	call   0x6b10:0x24bb
    6afb:	c9                   	leave
    6afc:	ca 06 00             	retf   0x6
    6aff:	c8 04 00 00          	enter  0x4,0x0
    6b03:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b06:	06                   	push   es
    6b07:	57                   	push   di
    6b08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b0b:	06                   	push   es
    6b0c:	57                   	push   di
    6b0d:	9a 29 3b 24 6b       	call   0x6b24:0x3b29
    6b12:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b15:	06                   	push   es
    6b16:	57                   	push   di
    6b17:	bf 0c 0f             	mov    di,0xf0c
    6b1a:	1e                   	push   ds
    6b1b:	57                   	push   di
    6b1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b1f:	06                   	push   es
    6b20:	57                   	push   di
    6b21:	9a d0 3a 67 6b       	call   0x6b67:0x3ad0
    6b26:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b29:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6b2c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b32:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    6b37:	98                   	cbw
    6b38:	8b f8                	mov    di,ax
    6b3a:	c1 e7 02             	shl    di,0x2
    6b3d:	8b 85 04 0f          	mov    ax,WORD PTR [di+0xf04]
    6b41:	8b 95 06 0f          	mov    dx,WORD PTR [di+0xf06]
    6b45:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6b48:	26 0b 45 04          	or     ax,WORD PTR es:[di+0x4]
    6b4c:	26 0b 55 06          	or     dx,WORD PTR es:[di+0x6]
    6b50:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    6b54:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    6b58:	c9                   	leave
    6b59:	ca 08 00             	retf   0x8
    6b5c:	55                   	push   bp
    6b5d:	89 e5                	mov    bp,sp
    6b5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b62:	06                   	push   es
    6b63:	57                   	push   di
    6b64:	9a 88 3c e8 6b       	call   0x6be8:0x3c88
    6b69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b6c:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    6b71:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    6b76:	c9                   	leave
    6b77:	ca 04 00             	retf   0x4
    6b7a:	55                   	push   bp
    6b7b:	89 e5                	mov    bp,sp
    6b7d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b80:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    6b85:	75 0d                	jne    0x6b94
    6b87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b8a:	06                   	push   es
    6b8b:	57                   	push   di
    6b8c:	b8 fe ff             	mov    ax,0xfffe
    6b8f:	9a 6a 20 f9 6b       	call   0x6bf9:0x206a
    6b94:	c9                   	leave
    6b95:	ca 08 00             	retf   0x8
    6b98:	c8 04 00 00          	enter  0x4,0x0
    6b9c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b9f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6ba2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6ba5:	26 83 7d 02 0d       	cmp    WORD PTR es:[di+0x2],0xd
    6baa:	75 0b                	jne    0x6bb7
    6bac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6baf:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    6bb5:	75 15                	jne    0x6bcc
    6bb7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6bba:	26 83 7d 02 1b       	cmp    WORD PTR es:[di+0x2],0x1b
    6bbf:	75 4b                	jne    0x6c0c
    6bc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bc4:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    6bca:	74 40                	je     0x6c0c
    6bcc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6bcf:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6bd3:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6bd7:	9a fb 16 44 6c       	call   0x6c44:0x16fb
    6bdc:	08 c0                	or     al,al
    6bde:	75 2c                	jne    0x6c0c
    6be0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6be3:	06                   	push   es
    6be4:	57                   	push   di
    6be5:	9a c4 61 1a 6c       	call   0x6c1a:0x61c4
    6bea:	08 c0                	or     al,al
    6bec:	74 1e                	je     0x6c0c
    6bee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bf1:	06                   	push   es
    6bf2:	57                   	push   di
    6bf3:	b8 fe ff             	mov    ax,0xfffe
    6bf6:	9a 6a 20 63 6c       	call   0x6c63:0x206a
    6bfb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6bfe:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    6c04:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    6c0a:	eb 10                	jmp    0x6c1c
    6c0c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6c0f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6c12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c15:	06                   	push   es
    6c16:	57                   	push   di
    6c17:	9a 10 56 3f 6c       	call   0x6c3f:0x5610
    6c1c:	c9                   	leave
    6c1d:	ca 08 00             	retf   0x8
    6c20:	c8 04 01 00          	enter  0x104,0x0
    6c24:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6c27:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6c2a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6c2d:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6c31:	8d be fc fe          	lea    di,[bp-0x104]
    6c35:	16                   	push   ss
    6c36:	57                   	push   di
    6c37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c3a:	06                   	push   es
    6c3b:	57                   	push   di
    6c3c:	9a 53 1d 52 6c       	call   0x6c52:0x1d53
    6c41:	9a 3f 17 bb 6f       	call   0x6fbb:0x173f
    6c46:	08 c0                	or     al,al
    6c48:	74 2c                	je     0x6c76
    6c4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c4d:	06                   	push   es
    6c4e:	57                   	push   di
    6c4f:	9a c4 61 84 6c       	call   0x6c84:0x61c4
    6c54:	08 c0                	or     al,al
    6c56:	74 1e                	je     0x6c76
    6c58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c5b:	06                   	push   es
    6c5c:	57                   	push   di
    6c5d:	b8 fe ff             	mov    ax,0xfffe
    6c60:	9a 6a 20 aa 6c       	call   0x6caa:0x206a
    6c65:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6c68:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    6c6e:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    6c74:	eb 10                	jmp    0x6c86
    6c76:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6c79:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6c7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c7f:	06                   	push   es
    6c80:	57                   	push   di
    6c81:	9a 26 56 02 6d       	call   0x6d02:0x5626
    6c86:	c9                   	leave
    6c87:	ca 08 00             	retf   0x8
    6c8a:	c8 04 00 00          	enter  0x4,0x0
    6c8e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6c91:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6c94:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6c97:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6c9b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    6c9f:	bf 68 21             	mov    di,0x2168
    6ca2:	b8 9a 6d             	mov    ax,0x6d9a
    6ca5:	50                   	push   ax
    6ca6:	57                   	push   di
    6ca7:	9a 55 22 17 6d       	call   0x6d17:0x2255
    6cac:	08 c0                	or     al,al
    6cae:	74 25                	je     0x6cd5
    6cb0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6cb3:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    6cb7:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    6cbb:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    6cbe:	75 05                	jne    0x6cc5
    6cc0:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    6cc3:	74 04                	je     0x6cc9
    6cc5:	b0 00                	mov    al,0x0
    6cc7:	eb 02                	jmp    0x6ccb
    6cc9:	b0 01                	mov    al,0x1
    6ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cce:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    6cd3:	eb 0d                	jmp    0x6ce2
    6cd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cd8:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    6cdd:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    6ce2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ce5:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    6cea:	50                   	push   ax
    6ceb:	06                   	push   es
    6cec:	57                   	push   di
    6ced:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6cf0:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    6cf4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6cf7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6cfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cfd:	06                   	push   es
    6cfe:	57                   	push   di
    6cff:	9a 3c 56 2a 6d       	call   0x6d2a:0x563c
    6d04:	c9                   	leave
    6d05:	ca 08 00             	retf   0x8
    6d08:	55                   	push   bp
    6d09:	89 e5                	mov    bp,sp
    6d0b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6d0f:	74 08                	je     0x6d19
    6d11:	83 ec 08             	sub    sp,0x8
    6d14:	9a e2 1f 87 6e       	call   0x6e87:0x1fe2
    6d19:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6d1c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6d1f:	31 c0                	xor    ax,ax
    6d21:	50                   	push   ax
    6d22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d25:	06                   	push   es
    6d26:	57                   	push   di
    6d27:	9a 61 2e 36 6d       	call   0x6d36:0x2e61
    6d2c:	6a 61                	push   0x61
    6d2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d31:	06                   	push   es
    6d32:	57                   	push   di
    6d33:	9a bf 17 42 6d       	call   0x6d42:0x17bf
    6d38:	6a 11                	push   0x11
    6d3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d3d:	06                   	push   es
    6d3e:	57                   	push   di
    6d3f:	9a e1 17 4e 6d       	call   0x6d4e:0x17e1
    6d44:	6a 01                	push   0x1
    6d46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d49:	06                   	push   es
    6d4a:	57                   	push   di
    6d4b:	9a 88 64 0b 6e       	call   0x6e0b:0x6488
    6d50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d53:	26 c7 45 26 a0 00    	mov    WORD PTR es:[di+0x26],0xa0
    6d59:	26 c6 85 da 00 01    	mov    BYTE PTR es:[di+0xda],0x1
    6d5f:	26 c6 85 dc 00 00    	mov    BYTE PTR es:[di+0xdc],0x0
    6d65:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6d69:	74 07                	je     0x6d72
    6d6b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6d6f:	83 c4 06             	add    sp,0x6
    6d72:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6d75:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6d78:	c9                   	leave
    6d79:	ca 0a 00             	retf   0xa
    6d7c:	55                   	push   bp
    6d7d:	89 e5                	mov    bp,sp
    6d7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d82:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    6d87:	3c 00                	cmp    al,0x0
    6d89:	75 21                	jne    0x6dac
    6d8b:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    6d91:	74 0b                	je     0x6d9e
    6d93:	6a 02                	push   0x2
    6d95:	06                   	push   es
    6d96:	57                   	push   di
    6d97:	9a 38 6e a8 6d       	call   0x6da8:0x6e38
    6d9c:	eb 0c                	jmp    0x6daa
    6d9e:	6a 01                	push   0x1
    6da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6da3:	06                   	push   es
    6da4:	57                   	push   di
    6da5:	9a 38 6e ba 6d       	call   0x6dba:0x6e38
    6daa:	eb 22                	jmp    0x6dce
    6dac:	3c 01                	cmp    al,0x1
    6dae:	75 0e                	jne    0x6dbe
    6db0:	6a 00                	push   0x0
    6db2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6db5:	06                   	push   es
    6db6:	57                   	push   di
    6db7:	9a 38 6e cc 6d       	call   0x6dcc:0x6e38
    6dbc:	eb 10                	jmp    0x6dce
    6dbe:	3c 02                	cmp    al,0x2
    6dc0:	75 0c                	jne    0x6dce
    6dc2:	6a 01                	push   0x1
    6dc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dc7:	06                   	push   es
    6dc8:	57                   	push   di
    6dc9:	9a 38 6e 24 6e       	call   0x6e24:0x6e38
    6dce:	c9                   	leave
    6dcf:	ca 04 00             	retf   0x4
    6dd2:	c8 02 00 00          	enter  0x2,0x0
    6dd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dd9:	26 80 bd dc 00 01    	cmp    BYTE PTR es:[di+0xdc],0x1
    6ddf:	b0 00                	mov    al,0x0
    6de1:	75 01                	jne    0x6de4
    6de3:	40                   	inc    ax
    6de4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6de7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6dea:	c9                   	leave
    6deb:	ca 04 00             	retf   0x4
    6dee:	55                   	push   bp
    6def:	89 e5                	mov    bp,sp
    6df1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6df4:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    6df9:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6dfc:	74 0f                	je     0x6e0d
    6dfe:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6e01:	26 88 85 da 00       	mov    BYTE PTR es:[di+0xda],al
    6e06:	06                   	push   es
    6e07:	57                   	push   di
    6e08:	9a 5a 40 55 6e       	call   0x6e55:0x405a
    6e0d:	c9                   	leave
    6e0e:	ca 06 00             	retf   0x6
    6e11:	55                   	push   bp
    6e12:	89 e5                	mov    bp,sp
    6e14:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6e18:	74 0e                	je     0x6e28
    6e1a:	6a 01                	push   0x1
    6e1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e1f:	06                   	push   es
    6e20:	57                   	push   di
    6e21:	9a 38 6e 32 6e       	call   0x6e32:0x6e38
    6e26:	eb 0c                	jmp    0x6e34
    6e28:	6a 00                	push   0x0
    6e2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e2d:	06                   	push   es
    6e2e:	57                   	push   di
    6e2f:	9a 38 6e 27 71       	call   0x7127:0x6e38
    6e34:	c9                   	leave
    6e35:	ca 06 00             	retf   0x6
    6e38:	55                   	push   bp
    6e39:	89 e5                	mov    bp,sp
    6e3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e3e:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    6e43:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6e46:	74 41                	je     0x6e89
    6e48:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6e4b:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    6e50:	06                   	push   es
    6e51:	57                   	push   di
    6e52:	9a fa 64 63 6e       	call   0x6e63:0x64fa
    6e57:	08 c0                	or     al,al
    6e59:	74 21                	je     0x6e7c
    6e5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e5e:	06                   	push   es
    6e5f:	57                   	push   di
    6e60:	9a b9 62 9e 6e       	call   0x6e9e:0x62b9
    6e65:	50                   	push   ax
    6e66:	68 01 04             	push   0x401
    6e69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e6c:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    6e71:	98                   	cbw
    6e72:	50                   	push   ax
    6e73:	6a 00                	push   0x0
    6e75:	6a 00                	push   0x0
    6e77:	9a 1f 6f 00 00       	call   0x0:0x6f1f
    6e7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e7f:	06                   	push   es
    6e80:	57                   	push   di
    6e81:	b8 fe ff             	mov    ax,0xfffe
    6e84:	9a 6a 20 46 70       	call   0x7046:0x206a
    6e89:	c9                   	leave
    6e8a:	ca 06 00             	retf   0x6
    6e8d:	c8 04 00 00          	enter  0x4,0x0
    6e91:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6e94:	06                   	push   es
    6e95:	57                   	push   di
    6e96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e99:	06                   	push   es
    6e9a:	57                   	push   di
    6e9b:	9a 29 3b b2 6e       	call   0x6eb2:0x3b29
    6ea0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6ea3:	06                   	push   es
    6ea4:	57                   	push   di
    6ea5:	bf 1c 0f             	mov    di,0xf1c
    6ea8:	1e                   	push   ds
    6ea9:	57                   	push   di
    6eaa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ead:	06                   	push   es
    6eae:	57                   	push   di
    6eaf:	9a d0 3a 00 6f       	call   0x6f00:0x3ad0
    6eb4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6eb7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6eba:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6ebd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ec0:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    6ec5:	98                   	cbw
    6ec6:	8b f8                	mov    di,ax
    6ec8:	c1 e7 02             	shl    di,0x2
    6ecb:	8b 8d 14 0f          	mov    cx,WORD PTR [di+0xf14]
    6ecf:	8b 9d 16 0f          	mov    bx,WORD PTR [di+0xf16]
    6ed3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6ed6:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    6eda:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    6ede:	0d 05 00             	or     ax,0x5
    6ee1:	81 ca 00 00          	or     dx,0x0
    6ee5:	0b c1                	or     ax,cx
    6ee7:	0b d3                	or     dx,bx
    6ee9:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    6eed:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    6ef1:	c9                   	leave
    6ef2:	ca 08 00             	retf   0x8
    6ef5:	55                   	push   bp
    6ef6:	89 e5                	mov    bp,sp
    6ef8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6efb:	06                   	push   es
    6efc:	57                   	push   di
    6efd:	9a 88 3c 0a 6f       	call   0x6f0a:0x3c88
    6f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f05:	06                   	push   es
    6f06:	57                   	push   di
    6f07:	9a b9 62 68 6f       	call   0x6f68:0x62b9
    6f0c:	50                   	push   ax
    6f0d:	68 01 04             	push   0x401
    6f10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f13:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    6f18:	98                   	cbw
    6f19:	50                   	push   ax
    6f1a:	6a 00                	push   0x0
    6f1c:	6a 00                	push   0x0
    6f1e:	9a 9a 71 00 00       	call   0x0:0x719a
    6f23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f26:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    6f2c:	74 1a                	je     0x6f48
    6f2e:	a1 22 15             	mov    ax,ds:0x1522
    6f31:	0b 06 24 15          	or     ax,WORD PTR ds:0x1524
    6f35:	74 11                	je     0x6f48
    6f37:	a1 22 15             	mov    ax,ds:0x1522
    6f3a:	8b 16 24 15          	mov    dx,WORD PTR ds:0x1524
    6f3e:	26 89 85 8e 00       	mov    WORD PTR es:[di+0x8e],ax
    6f43:	26 89 95 90 00       	mov    WORD PTR es:[di+0x90],dx
    6f48:	c9                   	leave
    6f49:	ca 04 00             	retf   0x4
    6f4c:	55                   	push   bp
    6f4d:	89 e5                	mov    bp,sp
    6f4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f52:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    6f58:	74 16                	je     0x6f70
    6f5a:	a1 22 15             	mov    ax,ds:0x1522
    6f5d:	0b 06 24 15          	or     ax,WORD PTR ds:0x1524
    6f61:	74 0d                	je     0x6f70
    6f63:	06                   	push   es
    6f64:	57                   	push   di
    6f65:	9a b9 62 91 6f       	call   0x6f91:0x62b9
    6f6a:	50                   	push   ax
    6f6b:	9a 98 72 00 00       	call   0x0:0x7298
    6f70:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6f73:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6f76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f79:	06                   	push   es
    6f7a:	57                   	push   di
    6f7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f7e:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    6f82:	c9                   	leave
    6f83:	ca 08 00             	retf   0x8
    6f86:	55                   	push   bp
    6f87:	89 e5                	mov    bp,sp
    6f89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f8c:	06                   	push   es
    6f8d:	57                   	push   di
    6f8e:	9a 5a 40 b6 6f       	call   0x6fb6:0x405a
    6f93:	c9                   	leave
    6f94:	ca 08 00             	retf   0x8
    6f97:	c8 04 01 00          	enter  0x104,0x0
    6f9b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f9e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6fa1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6fa4:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6fa8:	8d be fc fe          	lea    di,[bp-0x104]
    6fac:	16                   	push   ss
    6fad:	57                   	push   di
    6fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fb1:	06                   	push   es
    6fb2:	57                   	push   di
    6fb3:	9a 53 1d c9 6f       	call   0x6fc9:0x1d53
    6fb8:	9a 3f 17 ea 72       	call   0x72ea:0x173f
    6fbd:	08 c0                	or     al,al
    6fbf:	74 45                	je     0x7006
    6fc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fc4:	06                   	push   es
    6fc5:	57                   	push   di
    6fc6:	9a c4 61 e3 6f       	call   0x6fe3:0x61c4
    6fcb:	08 c0                	or     al,al
    6fcd:	74 37                	je     0x7006
    6fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fd2:	06                   	push   es
    6fd3:	57                   	push   di
    6fd4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6fd7:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    6fdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fde:	06                   	push   es
    6fdf:	57                   	push   di
    6fe0:	9a 58 62 14 70       	call   0x7014:0x6258
    6fe5:	08 c0                	or     al,al
    6fe7:	74 0c                	je     0x6ff5
    6fe9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fec:	06                   	push   es
    6fed:	57                   	push   di
    6fee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6ff1:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    6ff5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6ff8:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    6ffe:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    7004:	eb 10                	jmp    0x7016
    7006:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7009:	ff 76 0a             	push   WORD PTR [bp+0xa]
    700c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    700f:	06                   	push   es
    7010:	57                   	push   di
    7011:	9a 26 56 59 70       	call   0x7059:0x5626
    7016:	c9                   	leave
    7017:	ca 08 00             	retf   0x8
    701a:	55                   	push   bp
    701b:	89 e5                	mov    bp,sp
    701d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7020:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    7025:	75 0c                	jne    0x7033
    7027:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    702a:	06                   	push   es
    702b:	57                   	push   di
    702c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    702f:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    7033:	c9                   	leave
    7034:	ca 08 00             	retf   0x8
    7037:	55                   	push   bp
    7038:	89 e5                	mov    bp,sp
    703a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    703e:	74 08                	je     0x7048
    7040:	83 ec 08             	sub    sp,0x8
    7043:	9a e2 1f 2e 71       	call   0x712e:0x1fe2
    7048:	ff 76 0e             	push   WORD PTR [bp+0xe]
    704b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    704e:	31 c0                	xor    ax,ax
    7050:	50                   	push   ax
    7051:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7054:	06                   	push   es
    7055:	57                   	push   di
    7056:	9a 61 2e 65 70       	call   0x7065:0x2e61
    705b:	6a 71                	push   0x71
    705d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7060:	06                   	push   es
    7061:	57                   	push   di
    7062:	9a bf 17 71 70       	call   0x7071:0x17bf
    7067:	6a 11                	push   0x11
    7069:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    706c:	06                   	push   es
    706d:	57                   	push   di
    706e:	9a e1 17 b6 70       	call   0x70b6:0x17e1
    7073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7076:	26 c7 45 26 a0 00    	mov    WORD PTR es:[di+0x26],0xa0
    707c:	26 c6 85 da 00 01    	mov    BYTE PTR es:[di+0xda],0x1
    7082:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7086:	74 07                	je     0x708f
    7088:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    708c:	83 c4 06             	add    sp,0x6
    708f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7092:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7095:	c9                   	leave
    7096:	ca 0a 00             	retf   0xa
    7099:	55                   	push   bp
    709a:	89 e5                	mov    bp,sp
    709c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    709f:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    70a4:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    70a7:	74 0f                	je     0x70b8
    70a9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    70ac:	26 88 85 da 00       	mov    BYTE PTR es:[di+0xda],al
    70b1:	06                   	push   es
    70b2:	57                   	push   di
    70b3:	9a 5a 40 e0 70       	call   0x70e0:0x405a
    70b8:	c9                   	leave
    70b9:	ca 06 00             	retf   0x6
    70bc:	c8 0c 00 00          	enter  0xc,0x0
    70c0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    70c3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    70c7:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    70cb:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    70cf:	74 77                	je     0x7148
    70d1:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    70d5:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    70d8:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    70db:	06                   	push   es
    70dc:	57                   	push   di
    70dd:	9a fd 39 00 71       	call   0x7100:0x39fd
    70e2:	48                   	dec    ax
    70e3:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    70e6:	31 c0                	xor    ax,ax
    70e8:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    70eb:	7f 5b                	jg     0x7148
    70ed:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    70f0:	eb 03                	jmp    0x70f5
    70f2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    70f5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    70f8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    70fb:	06                   	push   es
    70fc:	57                   	push   di
    70fd:	9a 8f 39 6d 71       	call   0x716d:0x398f
    7102:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7105:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    7108:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    710b:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    710e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7111:	36 3b 55 08          	cmp    dx,WORD PTR ss:[di+0x8]
    7115:	75 06                	jne    0x711d
    7117:	36 3b 45 06          	cmp    ax,WORD PTR ss:[di+0x6]
    711b:	74 23                	je     0x7140
    711d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7120:	ff 76 fa             	push   WORD PTR [bp-0x6]
    7123:	bf 19 2c             	mov    di,0x2c19
    7126:	b8 3e 71             	mov    ax,0x713e
    7129:	50                   	push   ax
    712a:	57                   	push   di
    712b:	9a 55 22 b3 71       	call   0x71b3:0x2255
    7130:	08 c0                	or     al,al
    7132:	74 0c                	je     0x7140
    7134:	6a 00                	push   0x0
    7136:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    7139:	06                   	push   es
    713a:	57                   	push   di
    713b:	9a 4c 71 48 73       	call   0x7348:0x714c
    7140:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7143:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    7146:	75 aa                	jne    0x70f2
    7148:	c9                   	leave
    7149:	c2 02 00             	ret    0x2
    714c:	55                   	push   bp
    714d:	89 e5                	mov    bp,sp
    714f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7152:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7157:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    715a:	74 59                	je     0x71b5
    715c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    715f:	26 88 85 db 00       	mov    BYTE PTR es:[di+0xdb],al
    7164:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7167:	50                   	push   ax
    7168:	06                   	push   es
    7169:	57                   	push   di
    716a:	9a 88 64 77 71       	call   0x7177:0x6488
    716f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7172:	06                   	push   es
    7173:	57                   	push   di
    7174:	9a fa 64 85 71       	call   0x7185:0x64fa
    7179:	08 c0                	or     al,al
    717b:	74 21                	je     0x719e
    717d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7180:	06                   	push   es
    7181:	57                   	push   di
    7182:	9a b9 62 ca 71       	call   0x71ca:0x62b9
    7187:	50                   	push   ax
    7188:	68 01 04             	push   0x401
    718b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    718e:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7193:	98                   	cbw
    7194:	50                   	push   ax
    7195:	6a 00                	push   0x0
    7197:	6a 00                	push   0x0
    7199:	9a 4b 72 00 00       	call   0x0:0x724b
    719e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    71a2:	74 11                	je     0x71b5
    71a4:	55                   	push   bp
    71a5:	e8 14 ff             	call   0x70bc
    71a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71ab:	06                   	push   es
    71ac:	57                   	push   di
    71ad:	b8 fe ff             	mov    ax,0xfffe
    71b0:	9a 6a 20 5c 73       	call   0x735c:0x206a
    71b5:	c9                   	leave
    71b6:	ca 06 00             	retf   0x6
    71b9:	c8 04 00 00          	enter  0x4,0x0
    71bd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    71c0:	06                   	push   es
    71c1:	57                   	push   di
    71c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71c5:	06                   	push   es
    71c6:	57                   	push   di
    71c7:	9a 29 3b de 71       	call   0x71de:0x3b29
    71cc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    71cf:	06                   	push   es
    71d0:	57                   	push   di
    71d1:	bf 2c 0f             	mov    di,0xf2c
    71d4:	1e                   	push   ds
    71d5:	57                   	push   di
    71d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71d9:	06                   	push   es
    71da:	57                   	push   di
    71db:	9a d0 3a 2c 72       	call   0x722c:0x3ad0
    71e0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    71e3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    71e6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    71e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71ec:	26 8a 85 da 00       	mov    al,BYTE PTR es:[di+0xda]
    71f1:	98                   	cbw
    71f2:	8b f8                	mov    di,ax
    71f4:	c1 e7 02             	shl    di,0x2
    71f7:	8b 8d 24 0f          	mov    cx,WORD PTR [di+0xf24]
    71fb:	8b 9d 26 0f          	mov    bx,WORD PTR [di+0xf26]
    71ff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7202:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    7206:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    720a:	0d 04 00             	or     ax,0x4
    720d:	81 ca 00 00          	or     dx,0x0
    7211:	0b c1                	or     ax,cx
    7213:	0b d3                	or     dx,bx
    7215:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    7219:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    721d:	c9                   	leave
    721e:	ca 08 00             	retf   0x8
    7221:	55                   	push   bp
    7222:	89 e5                	mov    bp,sp
    7224:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7227:	06                   	push   es
    7228:	57                   	push   di
    7229:	9a 88 3c 36 72       	call   0x7236:0x3c88
    722e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7231:	06                   	push   es
    7232:	57                   	push   di
    7233:	9a b9 62 94 72       	call   0x7294:0x62b9
    7238:	50                   	push   ax
    7239:	68 01 04             	push   0x401
    723c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    723f:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    7244:	98                   	cbw
    7245:	50                   	push   ax
    7246:	6a 00                	push   0x0
    7248:	6a 00                	push   0x0
    724a:	9a 7f 73 00 00       	call   0x0:0x737f
    724f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7252:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    7258:	74 1a                	je     0x7274
    725a:	a1 22 15             	mov    ax,ds:0x1522
    725d:	0b 06 24 15          	or     ax,WORD PTR ds:0x1524
    7261:	74 11                	je     0x7274
    7263:	a1 22 15             	mov    ax,ds:0x1522
    7266:	8b 16 24 15          	mov    dx,WORD PTR ds:0x1524
    726a:	26 89 85 8e 00       	mov    WORD PTR es:[di+0x8e],ax
    726f:	26 89 95 90 00       	mov    WORD PTR es:[di+0x90],dx
    7274:	c9                   	leave
    7275:	ca 04 00             	retf   0x4
    7278:	55                   	push   bp
    7279:	89 e5                	mov    bp,sp
    727b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    727e:	26 80 bd a5 00 00    	cmp    BYTE PTR es:[di+0xa5],0x0
    7284:	74 16                	je     0x729c
    7286:	a1 22 15             	mov    ax,ds:0x1522
    7289:	0b 06 24 15          	or     ax,WORD PTR ds:0x1524
    728d:	74 0d                	je     0x729c
    728f:	06                   	push   es
    7290:	57                   	push   di
    7291:	9a b9 62 bd 72       	call   0x72bd:0x62b9
    7296:	50                   	push   ax
    7297:	9a ff ff 00 00       	call   0x0:0xffff
    729c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    729f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    72a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72a5:	06                   	push   es
    72a6:	57                   	push   di
    72a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    72aa:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    72ae:	c9                   	leave
    72af:	ca 08 00             	retf   0x8
    72b2:	55                   	push   bp
    72b3:	89 e5                	mov    bp,sp
    72b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72b8:	06                   	push   es
    72b9:	57                   	push   di
    72ba:	9a 5a 40 e5 72       	call   0x72e5:0x405a
    72bf:	c9                   	leave
    72c0:	ca 08 00             	retf   0x8
    72c3:	c8 04 01 00          	enter  0x104,0x0
    72c7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    72ca:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    72cd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    72d0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    72d3:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    72d7:	8d be fc fe          	lea    di,[bp-0x104]
    72db:	16                   	push   ss
    72dc:	57                   	push   di
    72dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72e0:	06                   	push   es
    72e1:	57                   	push   di
    72e2:	9a 53 1d f8 72       	call   0x72f8:0x1d53
    72e7:	9a 3f 17 7b 7d       	call   0x7d7b:0x173f
    72ec:	08 c0                	or     al,al
    72ee:	74 2b                	je     0x731b
    72f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72f3:	06                   	push   es
    72f4:	57                   	push   di
    72f5:	9a c4 61 29 73       	call   0x7329:0x61c4
    72fa:	08 c0                	or     al,al
    72fc:	74 1d                	je     0x731b
    72fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7301:	06                   	push   es
    7302:	57                   	push   di
    7303:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7306:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    730a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    730d:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    7313:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    7319:	eb 10                	jmp    0x732b
    731b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    731e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7321:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7324:	06                   	push   es
    7325:	57                   	push   di
    7326:	9a 26 56 72 73       	call   0x7372:0x5626
    732b:	c9                   	leave
    732c:	ca 08 00             	retf   0x8
    732f:	55                   	push   bp
    7330:	89 e5                	mov    bp,sp
    7332:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7335:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    7339:	3d 00 00             	cmp    ax,0x0
    733c:	75 0e                	jne    0x734c
    733e:	6a 01                	push   0x1
    7340:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7343:	06                   	push   es
    7344:	57                   	push   di
    7345:	9a 4c 71 40 76       	call   0x7640:0x714c
    734a:	eb 12                	jmp    0x735e
    734c:	3d 05 00             	cmp    ax,0x5
    734f:	75 0d                	jne    0x735e
    7351:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7354:	06                   	push   es
    7355:	57                   	push   di
    7356:	b8 fd ff             	mov    ax,0xfffd
    7359:	9a 6a 20 dc 73       	call   0x73dc:0x206a
    735e:	c9                   	leave
    735f:	ca 08 00             	retf   0x8
    7362:	c8 02 00 00          	enter  0x2,0x0
    7366:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7369:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    736d:	06                   	push   es
    736e:	57                   	push   di
    736f:	9a b9 62 9d 73       	call   0x739d:0x62b9
    7374:	50                   	push   ax
    7375:	68 0c 04             	push   0x40c
    7378:	6a 00                	push   0x0
    737a:	6a 00                	push   0x0
    737c:	6a 00                	push   0x0
    737e:	9a ac 73 00 00       	call   0x0:0x73ac
    7383:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7386:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7389:	c9                   	leave
    738a:	ca 04 00             	retf   0x4
    738d:	c8 02 01 00          	enter  0x102,0x0
    7391:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7394:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    7398:	06                   	push   es
    7399:	57                   	push   di
    739a:	9a b9 62 10 74       	call   0x7410:0x62b9
    739f:	50                   	push   ax
    73a0:	68 0a 04             	push   0x40a
    73a3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    73a6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    73a9:	06                   	push   es
    73aa:	57                   	push   di
    73ab:	9a 1e 74 00 00       	call   0x0:0x741e
    73b0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    73b3:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    73b7:	7d 27                	jge    0x73e0
    73b9:	8d be fe fe          	lea    di,[bp-0x102]
    73bd:	16                   	push   ss
    73be:	57                   	push   di
    73bf:	68 0b f0             	push   0xf00b
    73c2:	9a 2b 09 d5 73       	call   0x73d5:0x92b
    73c7:	b0 01                	mov    al,0x1
    73c9:	50                   	push   ax
    73ca:	b8 42 02             	mov    ax,0x242
    73cd:	ba 49 74             	mov    dx,0x7449
    73d0:	52                   	push   dx
    73d1:	50                   	push   ax
    73d2:	9a e6 28 40 74       	call   0x7440:0x28e6
    73d7:	52                   	push   dx
    73d8:	50                   	push   ax
    73d9:	9a 99 13 f1 73       	call   0x73f1:0x1399
    73de:	eb 1c                	jmp    0x73fc
    73e0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    73e3:	06                   	push   es
    73e4:	57                   	push   di
    73e5:	81 c7 01 00          	add    di,0x1
    73e9:	06                   	push   es
    73ea:	57                   	push   di
    73eb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    73ee:	9a c1 1e 57 74       	call   0x7457:0x1ec1
    73f3:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    73f6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    73f9:	26 88 05             	mov    BYTE PTR es:[di],al
    73fc:	c9                   	leave
    73fd:	ca 06 00             	retf   0x6
    7400:	c8 04 01 00          	enter  0x104,0x0
    7404:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7407:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    740b:	06                   	push   es
    740c:	57                   	push   di
    740d:	9a b9 62 72 74       	call   0x7472:0x62b9
    7412:	50                   	push   ax
    7413:	68 1a 04             	push   0x41a
    7416:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7419:	6a 00                	push   0x0
    741b:	6a 00                	push   0x0
    741d:	9a 82 74 00 00       	call   0x0:0x7482
    7422:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7425:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7428:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    742c:	75 2b                	jne    0x7459
    742e:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    7432:	75 25                	jne    0x7459
    7434:	8d be fc fe          	lea    di,[bp-0x104]
    7438:	16                   	push   ss
    7439:	57                   	push   di
    743a:	68 0b f0             	push   0xf00b
    743d:	9a 2b 09 50 74       	call   0x7450:0x92b
    7442:	b0 01                	mov    al,0x1
    7444:	50                   	push   ax
    7445:	b8 42 02             	mov    ax,0x242
    7448:	ba 24 79             	mov    dx,0x7924
    744b:	52                   	push   dx
    744c:	50                   	push   ax
    744d:	9a e6 28 b0 74       	call   0x74b0:0x28e6
    7452:	52                   	push   dx
    7453:	50                   	push   ax
    7454:	9a 99 13 e5 74       	call   0x74e5:0x1399
    7459:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    745c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    745f:	c9                   	leave
    7460:	ca 06 00             	retf   0x6
    7463:	55                   	push   bp
    7464:	89 e5                	mov    bp,sp
    7466:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7469:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    746d:	06                   	push   es
    746e:	57                   	push   di
    746f:	9a b9 62 9a 74       	call   0x749a:0x62b9
    7474:	50                   	push   ax
    7475:	68 1b 04             	push   0x41b
    7478:	ff 76 0e             	push   WORD PTR [bp+0xe]
    747b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    747e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7481:	9a b5 74 00 00       	call   0x0:0x74b5
    7486:	c9                   	leave
    7487:	ca 0a 00             	retf   0xa
    748a:	c8 02 02 00          	enter  0x202,0x0
    748e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7491:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    7495:	06                   	push   es
    7496:	57                   	push   di
    7497:	9a b9 62 d7 74       	call   0x74d7:0x62b9
    749c:	50                   	push   ax
    749d:	68 01 04             	push   0x401
    74a0:	6a 00                	push   0x0
    74a2:	8d be fe fe          	lea    di,[bp-0x102]
    74a6:	16                   	push   ss
    74a7:	57                   	push   di
    74a8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    74ab:	06                   	push   es
    74ac:	57                   	push   di
    74ad:	9a 4c 0d ce 74       	call   0x74ce:0xd4c
    74b2:	52                   	push   dx
    74b3:	50                   	push   ax
    74b4:	9a 1a 75 00 00       	call   0x0:0x751a
    74b9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    74bc:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    74c0:	7d 25                	jge    0x74e7
    74c2:	8d be fe fd          	lea    di,[bp-0x202]
    74c6:	16                   	push   ss
    74c7:	57                   	push   di
    74c8:	68 9d f0             	push   0xf09d
    74cb:	9a 2b 09 de 74       	call   0x74de:0x92b
    74d0:	b0 01                	mov    al,0x1
    74d2:	50                   	push   ax
    74d3:	b8 22 00             	mov    ax,0x22
    74d6:	ba fe 74             	mov    dx,0x74fe
    74d9:	52                   	push   dx
    74da:	50                   	push   ax
    74db:	9a e6 28 15 75       	call   0x7515:0x28e6
    74e0:	52                   	push   dx
    74e1:	50                   	push   ax
    74e2:	9a 99 13 4d 75       	call   0x754d:0x1399
    74e7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    74ea:	c9                   	leave
    74eb:	ca 08 00             	retf   0x8
    74ee:	c8 00 02 00          	enter  0x200,0x0
    74f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74f5:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    74f9:	06                   	push   es
    74fa:	57                   	push   di
    74fb:	9a b9 62 3f 75       	call   0x753f:0x62b9
    7500:	50                   	push   ax
    7501:	68 02 04             	push   0x402
    7504:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7507:	8d be 00 ff          	lea    di,[bp-0x100]
    750b:	16                   	push   ss
    750c:	57                   	push   di
    750d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7510:	06                   	push   es
    7511:	57                   	push   di
    7512:	9a 4c 0d 36 75       	call   0x7536:0xd4c
    7517:	52                   	push   dx
    7518:	50                   	push   ax
    7519:	9a 70 75 00 00       	call   0x0:0x7570
    751e:	83 fa 00             	cmp    dx,0x0
    7521:	7c 07                	jl     0x752a
    7523:	7f 2a                	jg     0x754f
    7525:	3d 00 00             	cmp    ax,0x0
    7528:	73 25                	jae    0x754f
    752a:	8d be 00 fe          	lea    di,[bp-0x200]
    752e:	16                   	push   ss
    752f:	57                   	push   di
    7530:	68 9d f0             	push   0xf09d
    7533:	9a 2b 09 46 75       	call   0x7546:0x92b
    7538:	b0 01                	mov    al,0x1
    753a:	50                   	push   ax
    753b:	b8 22 00             	mov    ax,0x22
    753e:	ba 62 75             	mov    dx,0x7562
    7541:	52                   	push   dx
    7542:	50                   	push   ax
    7543:	9a e6 28 1b 79       	call   0x791b:0x28e6
    7548:	52                   	push   dx
    7549:	50                   	push   ax
    754a:	9a 99 13 eb 75       	call   0x75eb:0x1399
    754f:	c9                   	leave
    7550:	ca 0a 00             	retf   0xa
    7553:	55                   	push   bp
    7554:	89 e5                	mov    bp,sp
    7556:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7559:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    755d:	06                   	push   es
    755e:	57                   	push   di
    755f:	9a b9 62 87 75       	call   0x7587:0x62b9
    7564:	50                   	push   ax
    7565:	68 03 04             	push   0x403
    7568:	ff 76 0a             	push   WORD PTR [bp+0xa]
    756b:	6a 00                	push   0x0
    756d:	6a 00                	push   0x0
    756f:	9a 94 75 00 00       	call   0x0:0x7594
    7574:	c9                   	leave
    7575:	ca 06 00             	retf   0x6
    7578:	55                   	push   bp
    7579:	89 e5                	mov    bp,sp
    757b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    757e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    7582:	06                   	push   es
    7583:	57                   	push   di
    7584:	9a b9 62 ab 75       	call   0x75ab:0x62b9
    7589:	50                   	push   ax
    758a:	68 05 04             	push   0x405
    758d:	6a 00                	push   0x0
    758f:	6a 00                	push   0x0
    7591:	6a 00                	push   0x0
    7593:	9a c0 75 00 00       	call   0x0:0x75c0
    7598:	c9                   	leave
    7599:	ca 04 00             	retf   0x4
    759c:	55                   	push   bp
    759d:	89 e5                	mov    bp,sp
    759f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75a2:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    75a6:	06                   	push   es
    75a7:	57                   	push   di
    75a8:	9a b9 62 d6 75       	call   0x75d6:0x62b9
    75ad:	50                   	push   ax
    75ae:	6a 0b                	push   0xb
    75b0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    75b4:	b0 00                	mov    al,0x0
    75b6:	75 01                	jne    0x75b9
    75b8:	40                   	inc    ax
    75b9:	98                   	cbw
    75ba:	50                   	push   ax
    75bb:	6a 00                	push   0x0
    75bd:	6a 00                	push   0x0
    75bf:	9a 5d 77 00 00       	call   0x0:0x775d
    75c4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    75c8:	75 0e                	jne    0x75d8
    75ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75cd:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    75d1:	06                   	push   es
    75d2:	57                   	push   di
    75d3:	9a c6 22 fe 75       	call   0x75fe:0x22c6
    75d8:	c9                   	leave
    75d9:	ca 06 00             	retf   0x6
    75dc:	55                   	push   bp
    75dd:	89 e5                	mov    bp,sp
    75df:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    75e3:	74 08                	je     0x75ed
    75e5:	83 ec 08             	sub    sp,0x8
    75e8:	9a e2 1f 47 76       	call   0x7647:0x1fe2
    75ed:	ff 76 0e             	push   WORD PTR [bp+0xe]
    75f0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    75f3:	31 c0                	xor    ax,ax
    75f5:	50                   	push   ax
    75f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75f9:	06                   	push   es
    75fa:	57                   	push   di
    75fb:	9a 61 2e 0a 76       	call   0x760a:0x2e61
    7600:	6a 79                	push   0x79
    7602:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7605:	06                   	push   es
    7606:	57                   	push   di
    7607:	9a bf 17 16 76       	call   0x7616:0x17bf
    760c:	6a 61                	push   0x61
    760e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7611:	06                   	push   es
    7612:	57                   	push   di
    7613:	9a e1 17 22 76       	call   0x7622:0x17e1
    7618:	6a 01                	push   0x1
    761a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    761d:	06                   	push   es
    761e:	57                   	push   di
    761f:	9a 88 64 2e 76       	call   0x762e:0x6488
    7624:	6a 00                	push   0x0
    7626:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7629:	06                   	push   es
    762a:	57                   	push   di
    762b:	9a 32 1f 70 76       	call   0x7670:0x1f32
    7630:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7633:	26 c7 45 26 b0 00    	mov    WORD PTR es:[di+0x26],0xb0
    7639:	b0 01                	mov    al,0x1
    763b:	50                   	push   ax
    763c:	b8 92 3e             	mov    ax,0x3e92
    763f:	ba b5 77             	mov    dx,0x77b5
    7642:	52                   	push   dx
    7643:	50                   	push   ax
    7644:	9a 50 1f d5 76       	call   0x76d5:0x1f50
    7649:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    764c:	26 89 85 d8 00       	mov    WORD PTR es:[di+0xd8],ax
    7651:	26 89 95 da 00       	mov    WORD PTR es:[di+0xda],dx
    7656:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7659:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    765c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7661:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    7665:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    7669:	b0 01                	mov    al,0x1
    766b:	50                   	push   ax
    766c:	b8 96 00             	mov    ax,0x96
    766f:	ba 96 76             	mov    dx,0x7696
    7672:	52                   	push   dx
    7673:	50                   	push   ax
    7674:	9a b8 17 21 81       	call   0x8121:0x17b8
    7679:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    767c:	26 89 85 dd 00       	mov    WORD PTR es:[di+0xdd],ax
    7681:	26 89 95 df 00       	mov    WORD PTR es:[di+0xdf],dx
    7686:	ff 76 08             	push   WORD PTR [bp+0x8]
    7689:	ff 76 06             	push   WORD PTR [bp+0x6]
    768c:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    7691:	06                   	push   es
    7692:	57                   	push   di
    7693:	9a 64 13 00 77       	call   0x7700:0x1364
    7698:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    769b:	26 c7 85 e3 00 10 00 	mov    WORD PTR es:[di+0xe3],0x10
    76a2:	26 c6 85 dc 00 01    	mov    BYTE PTR es:[di+0xdc],0x1
    76a8:	26 c6 85 e9 00 01    	mov    BYTE PTR es:[di+0xe9],0x1
    76ae:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    76b2:	74 07                	je     0x76bb
    76b4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    76b8:	83 c4 06             	add    sp,0x6
    76bb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    76be:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    76c1:	c9                   	leave
    76c2:	ca 0a 00             	retf   0xa
    76c5:	55                   	push   bp
    76c6:	89 e5                	mov    bp,sp
    76c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76cb:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    76d0:	06                   	push   es
    76d1:	57                   	push   di
    76d2:	9a 7f 1f e4 76       	call   0x76e4:0x1f7f
    76d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76da:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    76df:	06                   	push   es
    76e0:	57                   	push   di
    76e1:	9a 7f 1f f3 76       	call   0x76f3:0x1f7f
    76e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76e9:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    76ee:	06                   	push   es
    76ef:	57                   	push   di
    76f0:	9a 7f 1f 0b 77       	call   0x770b:0x1f7f
    76f5:	31 c0                	xor    ax,ax
    76f7:	50                   	push   ax
    76f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76fb:	06                   	push   es
    76fc:	57                   	push   di
    76fd:	9a fc 2e 3c 77       	call   0x773c:0x2efc
    7702:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7706:	74 05                	je     0x770d
    7708:	9a 0f 20 32 79       	call   0x7932:0x200f
    770d:	c9                   	leave
    770e:	ca 06 00             	retf   0x6
    7711:	55                   	push   bp
    7712:	89 e5                	mov    bp,sp
    7714:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7717:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    771c:	06                   	push   es
    771d:	57                   	push   di
    771e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7721:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    7725:	c9                   	leave
    7726:	ca 04 00             	retf   0x4
    7729:	55                   	push   bp
    772a:	89 e5                	mov    bp,sp
    772c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    772f:	26 83 bd e1 00 00    	cmp    WORD PTR es:[di+0xe1],0x0
    7735:	74 2a                	je     0x7761
    7737:	06                   	push   es
    7738:	57                   	push   di
    7739:	9a b9 62 93 77       	call   0x7793:0x62b9
    773e:	50                   	push   ax
    773f:	68 16 04             	push   0x416
    7742:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7745:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7749:	26 03 85 e1 00       	add    ax,WORD PTR es:[di+0xe1]
    774e:	2d 03 00             	sub    ax,0x3
    7751:	99                   	cwd
    7752:	26 f7 bd e1 00       	idiv   WORD PTR es:[di+0xe1]
    7757:	50                   	push   ax
    7758:	6a 00                	push   0x0
    775a:	6a 00                	push   0x0
    775c:	9a d4 77 00 00       	call   0x0:0x77d4
    7761:	c9                   	leave
    7762:	ca 04 00             	retf   0x4
    7765:	55                   	push   bp
    7766:	89 e5                	mov    bp,sp
    7768:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    776b:	26 8b 85 e1 00       	mov    ax,WORD PTR es:[di+0xe1]
    7770:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7773:	74 42                	je     0x77b7
    7775:	26 83 bd e1 00 00    	cmp    WORD PTR es:[di+0xe1],0x0
    777b:	74 06                	je     0x7783
    777d:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    7781:	75 14                	jne    0x7797
    7783:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7786:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7789:	26 89 85 e1 00       	mov    WORD PTR es:[di+0xe1],ax
    778e:	06                   	push   es
    778f:	57                   	push   di
    7790:	9a 5a 40 a7 77       	call   0x77a7:0x405a
    7795:	eb 20                	jmp    0x77b7
    7797:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    779a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    779d:	26 89 85 e1 00       	mov    WORD PTR es:[di+0xe1],ax
    77a2:	06                   	push   es
    77a3:	57                   	push   di
    77a4:	9a fa 64 c7 77       	call   0x77c7:0x64fa
    77a9:	08 c0                	or     al,al
    77ab:	74 0a                	je     0x77b7
    77ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77b0:	06                   	push   es
    77b1:	57                   	push   di
    77b2:	9a 29 77 ed 77       	call   0x77ed:0x7729
    77b7:	c9                   	leave
    77b8:	ca 06 00             	retf   0x6
    77bb:	c8 02 00 00          	enter  0x2,0x0
    77bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c2:	06                   	push   es
    77c3:	57                   	push   di
    77c4:	9a b9 62 fc 77       	call   0x77fc:0x62b9
    77c9:	50                   	push   ax
    77ca:	68 09 04             	push   0x409
    77cd:	6a 00                	push   0x0
    77cf:	6a 00                	push   0x0
    77d1:	6a 00                	push   0x0
    77d3:	9a 0a 78 00 00       	call   0x0:0x780a
    77d8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    77db:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    77de:	c9                   	leave
    77df:	ca 04 00             	retf   0x4
    77e2:	55                   	push   bp
    77e3:	89 e5                	mov    bp,sp
    77e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77e8:	06                   	push   es
    77e9:	57                   	push   di
    77ea:	9a bb 77 e7 79       	call   0x79e7:0x77bb
    77ef:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    77f2:	74 1a                	je     0x780e
    77f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77f7:	06                   	push   es
    77f8:	57                   	push   di
    77f9:	9a b9 62 2f 78       	call   0x782f:0x62b9
    77fe:	50                   	push   ax
    77ff:	68 07 04             	push   0x407
    7802:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7805:	6a 00                	push   0x0
    7807:	6a 00                	push   0x0
    7809:	9a f9 78 00 00       	call   0x0:0x78f9
    780e:	c9                   	leave
    780f:	ca 06 00             	retf   0x6
    7812:	55                   	push   bp
    7813:	89 e5                	mov    bp,sp
    7815:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7818:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    781b:	26 3a 85 e9 00       	cmp    al,BYTE PTR es:[di+0xe9]
    7820:	74 0f                	je     0x7831
    7822:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7825:	26 88 85 e9 00       	mov    BYTE PTR es:[di+0xe9],al
    782a:	06                   	push   es
    782b:	57                   	push   di
    782c:	9a 5a 40 52 78       	call   0x7852:0x405a
    7831:	c9                   	leave
    7832:	ca 06 00             	retf   0x6
    7835:	55                   	push   bp
    7836:	89 e5                	mov    bp,sp
    7838:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    783b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    783e:	26 3a 85 e6 00       	cmp    al,BYTE PTR es:[di+0xe6]
    7843:	74 0f                	je     0x7854
    7845:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7848:	26 88 85 e6 00       	mov    BYTE PTR es:[di+0xe6],al
    784d:	06                   	push   es
    784e:	57                   	push   di
    784f:	9a 5a 40 81 78       	call   0x7881:0x405a
    7854:	c9                   	leave
    7855:	ca 06 00             	retf   0x6
    7858:	c8 0a 00 00          	enter  0xa,0x0
    785c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    785f:	26 8b 85 e3 00       	mov    ax,WORD PTR es:[di+0xe3]
    7864:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7867:	26 80 bd e5 00 00    	cmp    BYTE PTR es:[di+0xe5],0x0
    786d:	75 1d                	jne    0x788c
    786f:	68 19 04             	push   0x419
    7872:	6a 00                	push   0x0
    7874:	8d 7e f6             	lea    di,[bp-0xa]
    7877:	16                   	push   ss
    7878:	57                   	push   di
    7879:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    787c:	06                   	push   es
    787d:	57                   	push   di
    787e:	9a bb 24 b6 78       	call   0x78b6:0x24bb
    7883:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7886:	2b 46 f8             	sub    ax,WORD PTR [bp-0x8]
    7889:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    788c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    788f:	c9                   	leave
    7890:	ca 04 00             	retf   0x4
    7893:	55                   	push   bp
    7894:	89 e5                	mov    bp,sp
    7896:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7899:	26 8b 85 e3 00       	mov    ax,WORD PTR es:[di+0xe3]
    789e:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    78a1:	74 15                	je     0x78b8
    78a3:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    78a7:	7e 0f                	jle    0x78b8
    78a9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    78ac:	26 89 85 e3 00       	mov    WORD PTR es:[di+0xe3],ax
    78b1:	06                   	push   es
    78b2:	57                   	push   di
    78b3:	9a 5a 40 d9 78       	call   0x78d9:0x405a
    78b8:	c9                   	leave
    78b9:	ca 06 00             	retf   0x6
    78bc:	55                   	push   bp
    78bd:	89 e5                	mov    bp,sp
    78bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78c2:	26 8a 85 e7 00       	mov    al,BYTE PTR es:[di+0xe7]
    78c7:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    78ca:	74 0f                	je     0x78db
    78cc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    78cf:	26 88 85 e7 00       	mov    BYTE PTR es:[di+0xe7],al
    78d4:	06                   	push   es
    78d5:	57                   	push   di
    78d6:	9a 5a 40 eb 78       	call   0x78eb:0x405a
    78db:	c9                   	leave
    78dc:	ca 06 00             	retf   0x6
    78df:	c8 06 01 00          	enter  0x106,0x0
    78e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78e6:	06                   	push   es
    78e7:	57                   	push   di
    78e8:	9a b9 62 69 79       	call   0x7969:0x62b9
    78ed:	50                   	push   ax
    78ee:	68 08 04             	push   0x408
    78f1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    78f4:	6a 00                	push   0x0
    78f6:	6a 00                	push   0x0
    78f8:	9a ab 79 00 00       	call   0x0:0x79ab
    78fd:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7900:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    7903:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    7907:	75 2b                	jne    0x7934
    7909:	83 7e fa ff          	cmp    WORD PTR [bp-0x6],0xffff
    790d:	75 25                	jne    0x7934
    790f:	8d be fa fe          	lea    di,[bp-0x106]
    7913:	16                   	push   ss
    7914:	57                   	push   di
    7915:	68 0b f0             	push   0xf00b
    7918:	9a 2b 09 2b 79       	call   0x792b:0x92b
    791d:	b0 01                	mov    al,0x1
    791f:	50                   	push   ax
    7920:	b8 17 02             	mov    ax,0x217
    7923:	ba 94 7c             	mov    dx,0x7c94
    7926:	52                   	push   dx
    7927:	50                   	push   ax
    7928:	9a e6 28 90 84       	call   0x8490:0x28e6
    792d:	52                   	push   dx
    792e:	50                   	push   ax
    792f:	9a 99 13 60 7c       	call   0x7c60:0x1399
    7934:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7937:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    793a:	09 d0                	or     ax,dx
    793c:	f7 d8                	neg    ax
    793e:	18 c0                	sbb    al,al
    7940:	f6 d8                	neg    al
    7942:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    7945:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    7948:	c9                   	leave
    7949:	ca 06 00             	retf   0x6
    794c:	55                   	push   bp
    794d:	89 e5                	mov    bp,sp
    794f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7952:	26 8a 85 e8 00       	mov    al,BYTE PTR es:[di+0xe8]
    7957:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    795a:	74 0f                	je     0x796b
    795c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    795f:	26 88 85 e8 00       	mov    BYTE PTR es:[di+0xe8],al
    7964:	06                   	push   es
    7965:	57                   	push   di
    7966:	9a 5a 40 8c 79       	call   0x798c:0x405a
    796b:	c9                   	leave
    796c:	ca 06 00             	retf   0x6
    796f:	55                   	push   bp
    7970:	89 e5                	mov    bp,sp
    7972:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7975:	26 8a 85 e5 00       	mov    al,BYTE PTR es:[di+0xe5]
    797a:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    797d:	74 0f                	je     0x798e
    797f:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7982:	26 88 85 e5 00       	mov    BYTE PTR es:[di+0xe5],al
    7987:	06                   	push   es
    7988:	57                   	push   di
    7989:	9a 5a 40 9e 79       	call   0x799e:0x405a
    798e:	c9                   	leave
    798f:	ca 06 00             	retf   0x6
    7992:	c8 02 00 00          	enter  0x2,0x0
    7996:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7999:	06                   	push   es
    799a:	57                   	push   di
    799b:	9a b9 62 d6 79       	call   0x79d6:0x62b9
    79a0:	50                   	push   ax
    79a1:	68 0f 04             	push   0x40f
    79a4:	6a 00                	push   0x0
    79a6:	6a 00                	push   0x0
    79a8:	6a 00                	push   0x0
    79aa:	9a 04 7a 00 00       	call   0x0:0x7a04
    79af:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    79b2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    79b5:	c9                   	leave
    79b6:	ca 04 00             	retf   0x4
    79b9:	55                   	push   bp
    79ba:	89 e5                	mov    bp,sp
    79bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79bf:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    79c4:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    79c7:	74 0f                	je     0x79d8
    79c9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    79cc:	26 88 85 dc 00       	mov    BYTE PTR es:[di+0xdc],al
    79d1:	06                   	push   es
    79d2:	57                   	push   di
    79d3:	9a 5a 40 f6 79       	call   0x79f6:0x405a
    79d8:	c9                   	leave
    79d9:	ca 06 00             	retf   0x6
    79dc:	55                   	push   bp
    79dd:	89 e5                	mov    bp,sp
    79df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79e2:	06                   	push   es
    79e3:	57                   	push   di
    79e4:	9a 92 79 56 7a       	call   0x7a56:0x7992
    79e9:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    79ec:	74 1a                	je     0x7a08
    79ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79f1:	06                   	push   es
    79f2:	57                   	push   di
    79f3:	9a b9 62 8a 7a       	call   0x7a8a:0x62b9
    79f8:	50                   	push   ax
    79f9:	68 18 04             	push   0x418
    79fc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    79ff:	6a 00                	push   0x0
    7a01:	6a 00                	push   0x0
    7a03:	9a ff ff 00 00       	call   0x0:0xffff
    7a08:	c9                   	leave
    7a09:	ca 06 00             	retf   0x6
    7a0c:	55                   	push   bp
    7a0d:	89 e5                	mov    bp,sp
    7a0f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7a12:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7a15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a18:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7a1d:	06                   	push   es
    7a1e:	57                   	push   di
    7a1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a22:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    7a26:	c9                   	leave
    7a27:	ca 08 00             	retf   0x8
    7a2a:	c8 1c 00 00          	enter  0x1c,0x0
    7a2e:	8d 7e e4             	lea    di,[bp-0x1c]
    7a31:	16                   	push   ss
    7a32:	57                   	push   di
    7a33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a36:	06                   	push   es
    7a37:	57                   	push   di
    7a38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a3b:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    7a3f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7a42:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7a45:	9a 98 7a 00 00       	call   0x0:0x7a98
    7a4a:	09 c0                	or     ax,ax
    7a4c:	74 61                	je     0x7aaf
    7a4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a51:	06                   	push   es
    7a52:	57                   	push   di
    7a53:	9a 92 79 0c 7c       	call   0x7c0c:0x7992
    7a58:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7a5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a5e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7a63:	06                   	push   es
    7a64:	57                   	push   di
    7a65:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a68:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    7a6c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7a6f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7a72:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    7a75:	7d 30                	jge    0x7aa7
    7a77:	68 19 04             	push   0x419
    7a7a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7a7d:	8d 7e ec             	lea    di,[bp-0x14]
    7a80:	16                   	push   ss
    7a81:	57                   	push   di
    7a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a85:	06                   	push   es
    7a86:	57                   	push   di
    7a87:	9a bb 24 cc 7a       	call   0x7acc:0x24bb
    7a8c:	8d 7e ec             	lea    di,[bp-0x14]
    7a8f:	16                   	push   ss
    7a90:	57                   	push   di
    7a91:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7a94:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7a97:	9a ff ff 00 00       	call   0x0:0xffff
    7a9c:	09 c0                	or     ax,ax
    7a9e:	74 02                	je     0x7aa2
    7aa0:	eb 12                	jmp    0x7ab4
    7aa2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    7aa5:	eb c8                	jmp    0x7a6f
    7aa7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7aab:	75 02                	jne    0x7aaf
    7aad:	eb 05                	jmp    0x7ab4
    7aaf:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    7ab4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7ab7:	c9                   	leave
    7ab8:	ca 0a 00             	retf   0xa
    7abb:	c8 08 00 00          	enter  0x8,0x0
    7abf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7ac2:	06                   	push   es
    7ac3:	57                   	push   di
    7ac4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ac7:	06                   	push   es
    7ac8:	57                   	push   di
    7ac9:	9a 29 3b e0 7a       	call   0x7ae0:0x3b29
    7ace:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7ad1:	06                   	push   es
    7ad2:	57                   	push   di
    7ad3:	bf 68 0f             	mov    di,0xf68
    7ad6:	1e                   	push   ds
    7ad7:	57                   	push   di
    7ad8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7adb:	06                   	push   es
    7adc:	57                   	push   di
    7add:	9a d0 3a 02 7c       	call   0x7c02:0x3ad0
    7ae2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7ae5:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    7ae8:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    7aeb:	26 ff 45 0c          	inc    WORD PTR es:[di+0xc]
    7aef:	26 ff 45 0e          	inc    WORD PTR es:[di+0xe]
    7af3:	26 83 6d 10 02       	sub    WORD PTR es:[di+0x10],0x2
    7af8:	26 83 6d 12 02       	sub    WORD PTR es:[di+0x12],0x2
    7afd:	b8 48 0f             	mov    ax,0xf48
    7b00:	8c da                	mov    dx,ds
    7b02:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7b05:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7b08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b0b:	26 80 bd e9 00 00    	cmp    BYTE PTR es:[di+0xe9],0x0
    7b11:	74 0b                	je     0x7b1e
    7b13:	b8 50 0f             	mov    ax,0xf50
    7b16:	8c da                	mov    dx,ds
    7b18:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7b1b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b21:	26 8a 85 e5 00       	mov    al,BYTE PTR es:[di+0xe5]
    7b26:	98                   	cbw
    7b27:	8b f8                	mov    di,ax
    7b29:	c1 e7 02             	shl    di,0x2
    7b2c:	8b 8d 34 0f          	mov    cx,WORD PTR [di+0xf34]
    7b30:	8b 9d 36 0f          	mov    bx,WORD PTR [di+0xf36]
    7b34:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7b37:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    7b3b:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    7b3f:	0d 41 00             	or     ax,0x41
    7b42:	81 ca 10 00          	or     dx,0x10
    7b46:	0b c1                	or     ax,cx
    7b48:	0b d3                	or     dx,bx
    7b4a:	8b c8                	mov    cx,ax
    7b4c:	8b da                	mov    bx,dx
    7b4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b51:	26 8a 85 e8 00       	mov    al,BYTE PTR es:[di+0xe8]
    7b56:	98                   	cbw
    7b57:	8b f8                	mov    di,ax
    7b59:	c1 e7 02             	shl    di,0x2
    7b5c:	8b 85 40 0f          	mov    ax,WORD PTR [di+0xf40]
    7b60:	8b 95 42 0f          	mov    dx,WORD PTR [di+0xf42]
    7b64:	0b c1                	or     ax,cx
    7b66:	0b d3                	or     dx,bx
    7b68:	8b c8                	mov    cx,ax
    7b6a:	8b da                	mov    bx,dx
    7b6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b6f:	26 8a 85 e7 00       	mov    al,BYTE PTR es:[di+0xe7]
    7b74:	98                   	cbw
    7b75:	c1 e0 02             	shl    ax,0x2
    7b78:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7b7b:	03 f8                	add    di,ax
    7b7d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    7b80:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    7b84:	0b c1                	or     ax,cx
    7b86:	0b d3                	or     dx,bx
    7b88:	8b c8                	mov    cx,ax
    7b8a:	8b da                	mov    bx,dx
    7b8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b8f:	26 8a 85 e6 00       	mov    al,BYTE PTR es:[di+0xe6]
    7b94:	98                   	cbw
    7b95:	8b f8                	mov    di,ax
    7b97:	c1 e7 02             	shl    di,0x2
    7b9a:	8b 85 58 0f          	mov    ax,WORD PTR [di+0xf58]
    7b9e:	8b 95 5a 0f          	mov    dx,WORD PTR [di+0xf5a]
    7ba2:	0b c1                	or     ax,cx
    7ba4:	0b d3                	or     dx,bx
    7ba6:	8b c8                	mov    cx,ax
    7ba8:	8b da                	mov    bx,dx
    7baa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bad:	26 83 bd e1 00 00    	cmp    WORD PTR es:[di+0xe1],0x0
    7bb3:	b0 00                	mov    al,0x0
    7bb5:	74 01                	je     0x7bb8
    7bb7:	40                   	inc    ax
    7bb8:	98                   	cbw
    7bb9:	8b f8                	mov    di,ax
    7bbb:	c1 e7 02             	shl    di,0x2
    7bbe:	8b 85 60 0f          	mov    ax,WORD PTR [di+0xf60]
    7bc2:	8b 95 62 0f          	mov    dx,WORD PTR [di+0xf62]
    7bc6:	0b c1                	or     ax,cx
    7bc8:	0b d3                	or     dx,bx
    7bca:	8b c8                	mov    cx,ax
    7bcc:	8b da                	mov    bx,dx
    7bce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bd1:	26 8a 85 dc 00       	mov    al,BYTE PTR es:[di+0xdc]
    7bd6:	98                   	cbw
    7bd7:	8b f8                	mov    di,ax
    7bd9:	c1 e7 02             	shl    di,0x2
    7bdc:	8b 85 5e 0e          	mov    ax,WORD PTR [di+0xe5e]
    7be0:	8b 95 60 0e          	mov    dx,WORD PTR [di+0xe60]
    7be4:	0b c1                	or     ax,cx
    7be6:	0b d3                	or     dx,bx
    7be8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    7beb:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    7bef:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    7bf3:	c9                   	leave
    7bf4:	ca 08 00             	retf   0x8
    7bf7:	55                   	push   bp
    7bf8:	89 e5                	mov    bp,sp
    7bfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bfd:	06                   	push   es
    7bfe:	57                   	push   di
    7bff:	9a 88 3c eb 7c       	call   0x7ceb:0x3c88
    7c04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c07:	06                   	push   es
    7c08:	57                   	push   di
    7c09:	9a 29 77 42 7c       	call   0x7c42:0x7729
    7c0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c11:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    7c16:	26 0b 85 ec 00       	or     ax,WORD PTR es:[di+0xec]
    7c1b:	74 54                	je     0x7c71
    7c1d:	26 ff b5 ec 00       	push   WORD PTR es:[di+0xec]
    7c22:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    7c27:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7c2c:	06                   	push   es
    7c2d:	57                   	push   di
    7c2e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7c31:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    7c35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c38:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    7c3d:	06                   	push   es
    7c3e:	57                   	push   di
    7c3f:	9a dc 79 51 7c       	call   0x7c51:0x79dc
    7c44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c47:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    7c4c:	06                   	push   es
    7c4d:	57                   	push   di
    7c4e:	9a e2 77 ca 7c       	call   0x7cca:0x77e2
    7c53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c56:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    7c5b:	06                   	push   es
    7c5c:	57                   	push   di
    7c5d:	9a 7f 1f 56 7d       	call   0x7d56:0x1f7f
    7c62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c65:	31 c0                	xor    ax,ax
    7c67:	26 89 85 ea 00       	mov    WORD PTR es:[di+0xea],ax
    7c6c:	26 89 85 ec 00       	mov    WORD PTR es:[di+0xec],ax
    7c71:	c9                   	leave
    7c72:	ca 04 00             	retf   0x4
    7c75:	55                   	push   bp
    7c76:	89 e5                	mov    bp,sp
    7c78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c7b:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7c80:	06                   	push   es
    7c81:	57                   	push   di
    7c82:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7c85:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    7c89:	09 c0                	or     ax,ax
    7c8b:	7e 56                	jle    0x7ce3
    7c8d:	b0 01                	mov    al,0x1
    7c8f:	50                   	push   ax
    7c90:	b8 c9 03             	mov    ax,0x3c9
    7c93:	ba 9b 7c             	mov    dx,0x7c9b
    7c96:	52                   	push   dx
    7c97:	50                   	push   ax
    7c98:	9a 08 1d cf 7f       	call   0x7fcf:0x1d08
    7c9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ca0:	26 89 85 ea 00       	mov    WORD PTR es:[di+0xea],ax
    7ca5:	26 89 95 ec 00       	mov    WORD PTR es:[di+0xec],dx
    7caa:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    7caf:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    7cb4:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    7cb9:	06                   	push   es
    7cba:	57                   	push   di
    7cbb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7cbe:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    7cc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cc5:	06                   	push   es
    7cc6:	57                   	push   di
    7cc7:	9a 92 79 d9 7c       	call   0x7cd9:0x7992
    7ccc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ccf:	26 89 85 ee 00       	mov    WORD PTR es:[di+0xee],ax
    7cd4:	06                   	push   es
    7cd5:	57                   	push   di
    7cd6:	9a bb 77 b3 7d       	call   0x7db3:0x77bb
    7cdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cde:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    7ce3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ce6:	06                   	push   es
    7ce7:	57                   	push   di
    7ce8:	9a 77 3e 17 7d       	call   0x7d17:0x3e77
    7ced:	c9                   	leave
    7cee:	ca 04 00             	retf   0x4
    7cf1:	55                   	push   bp
    7cf2:	89 e5                	mov    bp,sp
    7cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cf7:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    7cfc:	75 5c                	jne    0x7d5a
    7cfe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d01:	26 81 3d 01 02       	cmp    WORD PTR es:[di],0x201
    7d06:	74 07                	je     0x7d0f
    7d08:	26 81 3d 03 02       	cmp    WORD PTR es:[di],0x203
    7d0d:	75 4b                	jne    0x7d5a
    7d0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d12:	06                   	push   es
    7d13:	57                   	push   di
    7d14:	9a 96 24 34 7d       	call   0x7d34:0x2496
    7d19:	08 c0                	or     al,al
    7d1b:	75 3d                	jne    0x7d5a
    7d1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d20:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    7d25:	75 33                	jne    0x7d5a
    7d27:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d2a:	06                   	push   es
    7d2b:	57                   	push   di
    7d2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d2f:	06                   	push   es
    7d30:	57                   	push   di
    7d31:	9a 87 43 67 7d       	call   0x7d67:0x4387
    7d36:	08 c0                	or     al,al
    7d38:	74 02                	je     0x7d3c
    7d3a:	eb 2d                	jmp    0x7d69
    7d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d3f:	26 8a 45 28          	mov    al,BYTE PTR es:[di+0x28]
    7d43:	0c 01                	or     al,0x1
    7d45:	26 88 45 28          	mov    BYTE PTR es:[di+0x28],al
    7d49:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d4c:	06                   	push   es
    7d4d:	57                   	push   di
    7d4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d51:	06                   	push   es
    7d52:	57                   	push   di
    7d53:	9a 38 20 35 7e       	call   0x7e35:0x2038
    7d58:	eb 0f                	jmp    0x7d69
    7d5a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d5d:	06                   	push   es
    7d5e:	57                   	push   di
    7d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d62:	06                   	push   es
    7d63:	57                   	push   di
    7d64:	9a 46 44 d9 7d       	call   0x7dd9:0x4446
    7d69:	c9                   	leave
    7d6a:	ca 08 00             	retf   0x8
    7d6d:	c8 04 00 00          	enter  0x4,0x0
    7d71:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7d74:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    7d78:	9a 97 16 ff ff       	call   0xffff:0x1697
    7d7d:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    7d80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d83:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    7d88:	75 53                	jne    0x7ddd
    7d8a:	26 80 bd e7 00 00    	cmp    BYTE PTR es:[di+0xe7],0x0
    7d90:	74 4b                	je     0x7ddd
    7d92:	f6 46 fd 01          	test   BYTE PTR [bp-0x3],0x1
    7d96:	74 06                	je     0x7d9e
    7d98:	f6 46 fd 04          	test   BYTE PTR [bp-0x3],0x4
    7d9c:	74 3f                	je     0x7ddd
    7d9e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7da1:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    7da5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    7da9:	6a 01                	push   0x1
    7dab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dae:	06                   	push   es
    7daf:	57                   	push   di
    7db0:	9a 2a 7a c9 7d       	call   0x7dc9:0x7a2a
    7db5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7db8:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    7dbc:	7c 1f                	jl     0x7ddd
    7dbe:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7dc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dc4:	06                   	push   es
    7dc5:	57                   	push   di
    7dc6:	9a df 78 fb 7e       	call   0x7efb:0x78df
    7dcb:	08 c0                	or     al,al
    7dcd:	74 0e                	je     0x7ddd
    7dcf:	6a 00                	push   0x0
    7dd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dd4:	06                   	push   es
    7dd5:	57                   	push   di
    7dd6:	9a c6 23 eb 7d       	call   0x7deb:0x23c6
    7ddb:	eb 3a                	jmp    0x7e17
    7ddd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7de0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7de3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7de6:	06                   	push   es
    7de7:	57                   	push   di
    7de8:	9a 2c 28 15 7e       	call   0x7e15:0x282c
    7ded:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7df0:	26 80 7d 2e 01       	cmp    BYTE PTR es:[di+0x2e],0x1
    7df5:	75 20                	jne    0x7e17
    7df7:	26 80 bd e7 00 00    	cmp    BYTE PTR es:[di+0xe7],0x0
    7dfd:	74 0c                	je     0x7e0b
    7dff:	f6 46 fd 04          	test   BYTE PTR [bp-0x3],0x4
    7e03:	75 12                	jne    0x7e17
    7e05:	f6 46 fd 01          	test   BYTE PTR [bp-0x3],0x1
    7e09:	75 0c                	jne    0x7e17
    7e0b:	6a 00                	push   0x0
    7e0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e10:	06                   	push   es
    7e11:	57                   	push   di
    7e12:	9a c6 23 6f 7e       	call   0x7e6f:0x23c6
    7e17:	c9                   	leave
    7e18:	ca 08 00             	retf   0x8
    7e1b:	55                   	push   bp
    7e1c:	89 e5                	mov    bp,sp
    7e1e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7e21:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    7e25:	3d 01 00             	cmp    ax,0x1
    7e28:	75 0f                	jne    0x7e39
    7e2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e2d:	06                   	push   es
    7e2e:	57                   	push   di
    7e2f:	b8 fe ff             	mov    ax,0xfffe
    7e32:	9a 6a 20 49 7e       	call   0x7e49:0x206a
    7e37:	eb 12                	jmp    0x7e4b
    7e39:	3d 02 00             	cmp    ax,0x2
    7e3c:	75 0d                	jne    0x7e4b
    7e3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e41:	06                   	push   es
    7e42:	57                   	push   di
    7e43:	b8 fd ff             	mov    ax,0xfffd
    7e46:	9a 6a 20 ab 7f       	call   0x7fab:0x206a
    7e4b:	c9                   	leave
    7e4c:	ca 08 00             	retf   0x8
    7e4f:	c8 58 00 00          	enter  0x58,0x0
    7e53:	c7 46 f4 2b 20       	mov    WORD PTR [bp-0xc],0x202b
    7e58:	8d 46 ce             	lea    ax,[bp-0x32]
    7e5b:	8c d2                	mov    dx,ss
    7e5d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7e60:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    7e63:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7e66:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7e6a:	06                   	push   es
    7e6b:	57                   	push   di
    7e6c:	9a b9 62 9d 7e       	call   0x7e9d:0x62b9
    7e71:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    7e74:	c7 46 ce 02 00       	mov    WORD PTR [bp-0x32],0x2
    7e79:	c7 46 d4 01 00       	mov    WORD PTR [bp-0x2c],0x1
    7e7e:	31 c0                	xor    ax,ax
    7e80:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    7e83:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7e86:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    7e8a:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    7e8e:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    7e91:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7e94:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7e98:	06                   	push   es
    7e99:	57                   	push   di
    7e9a:	9a b9 62 ae 7e       	call   0x7eae:0x62b9
    7e9f:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    7ea2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7ea5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7ea9:	06                   	push   es
    7eaa:	57                   	push   di
    7eab:	9a b9 62 c4 7e       	call   0x7ec4:0x62b9
    7eb0:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    7eb3:	c7 46 e8 2c 20       	mov    WORD PTR [bp-0x18],0x202c
    7eb8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7ebb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7ebf:	06                   	push   es
    7ec0:	57                   	push   di
    7ec1:	9a b9 62 e5 7e       	call   0x7ee5:0x62b9
    7ec6:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    7ec9:	8d 46 c0             	lea    ax,[bp-0x40]
    7ecc:	8c d2                	mov    dx,ss
    7ece:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    7ed1:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    7ed4:	c7 46 c0 02 00       	mov    WORD PTR [bp-0x40],0x2
    7ed9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7edc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7ee0:	06                   	push   es
    7ee1:	57                   	push   di
    7ee2:	9a b9 62 3d 80       	call   0x803d:0x62b9
    7ee7:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    7eea:	31 c0                	xor    ax,ax
    7eec:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    7eef:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7ef2:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7ef6:	06                   	push   es
    7ef7:	57                   	push   di
    7ef8:	9a 92 79 5e 80       	call   0x805e:0x7992
    7efd:	89 46 b4             	mov    WORD PTR [bp-0x4c],ax
    7f00:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7f03:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    7f07:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    7f0b:	8d 7e b8             	lea    di,[bp-0x48]
    7f0e:	16                   	push   ss
    7f0f:	57                   	push   di
    7f10:	9a ff ff 00 00       	call   0x0:0xffff
    7f15:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7f18:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7f1c:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7f20:	89 46 b2             	mov    WORD PTR [bp-0x4e],ax
    7f23:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7f27:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    7f2a:	8b 46 b6             	mov    ax,WORD PTR [bp-0x4a]
    7f2d:	3b 46 b2             	cmp    ax,WORD PTR [bp-0x4e]
    7f30:	7c 03                	jl     0x7f35
    7f32:	e9 e3 00             	jmp    0x8018
    7f35:	8b 46 b4             	mov    ax,WORD PTR [bp-0x4c]
    7f38:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    7f3b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7f3e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7f42:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7f47:	06                   	push   es
    7f48:	57                   	push   di
    7f49:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7f4c:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    7f50:	3b 46 b4             	cmp    ax,WORD PTR [bp-0x4c]
    7f53:	7e 1e                	jle    0x7f73
    7f55:	ff 76 b4             	push   WORD PTR [bp-0x4c]
    7f58:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7f5b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7f5f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    7f64:	06                   	push   es
    7f65:	57                   	push   di
    7f66:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7f69:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    7f6d:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    7f70:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    7f73:	8b 46 b0             	mov    ax,WORD PTR [bp-0x50]
    7f76:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    7f79:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7f7c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7f80:	26 8b 85 e3 00       	mov    ax,WORD PTR es:[di+0xe3]
    7f85:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    7f88:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    7f8b:	8b 56 cc             	mov    dx,WORD PTR [bp-0x34]
    7f8e:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    7f91:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    7f94:	8b 46 b4             	mov    ax,WORD PTR [bp-0x4c]
    7f97:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    7f9a:	8d 7e e8             	lea    di,[bp-0x18]
    7f9d:	16                   	push   ss
    7f9e:	57                   	push   di
    7f9f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7fa2:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7fa6:	06                   	push   es
    7fa7:	57                   	push   di
    7fa8:	9a 38 20 db 7f       	call   0x7fdb:0x2038
    7fad:	8d 7e a8             	lea    di,[bp-0x58]
    7fb0:	16                   	push   ss
    7fb1:	57                   	push   di
    7fb2:	6a 00                	push   0x0
    7fb4:	ff 76 b6             	push   WORD PTR [bp-0x4a]
    7fb7:	ff 76 c6             	push   WORD PTR [bp-0x3a]
    7fba:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    7fbd:	31 d2                	xor    dx,dx
    7fbf:	8b c8                	mov    cx,ax
    7fc1:	8b da                	mov    bx,dx
    7fc3:	8b 46 b6             	mov    ax,WORD PTR [bp-0x4a]
    7fc6:	99                   	cwd
    7fc7:	03 c1                	add    ax,cx
    7fc9:	13 d3                	adc    dx,bx
    7fcb:	50                   	push   ax
    7fcc:	9a 88 06 ff ff       	call   0xffff:0x688
    7fd1:	8d 7e dc             	lea    di,[bp-0x24]
    7fd4:	16                   	push   ss
    7fd5:	57                   	push   di
    7fd6:	6a 08                	push   0x8
    7fd8:	9a 1b 16 ee 7f       	call   0x7fee:0x161b
    7fdd:	8d 7e f4             	lea    di,[bp-0xc]
    7fe0:	16                   	push   ss
    7fe1:	57                   	push   di
    7fe2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7fe5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    7fe9:	06                   	push   es
    7fea:	57                   	push   di
    7feb:	9a 38 20 fe 82       	call   0x82fe:0x2038
    7ff0:	8b 46 c8             	mov    ax,WORD PTR [bp-0x38]
    7ff3:	01 46 b6             	add    WORD PTR [bp-0x4a],ax
    7ff6:	ff 46 b4             	inc    WORD PTR [bp-0x4c]
    7ff9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    7ffc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    8000:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    8005:	06                   	push   es
    8006:	57                   	push   di
    8007:	26 c4 3d             	les    di,DWORD PTR es:[di]
    800a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    800e:	3b 46 b4             	cmp    ax,WORD PTR [bp-0x4c]
    8011:	7f 02                	jg     0x8015
    8013:	eb 03                	jmp    0x8018
    8015:	e9 12 ff             	jmp    0x7f2a
    8018:	c9                   	leave
    8019:	c2 02 00             	ret    0x2
    801c:	55                   	push   bp
    801d:	89 e5                	mov    bp,sp
    801f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8022:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    8027:	74 06                	je     0x802f
    8029:	55                   	push   bp
    802a:	e8 22 fe             	call   0x7e4f
    802d:	eb 10                	jmp    0x803f
    802f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8032:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8035:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8038:	06                   	push   es
    8039:	57                   	push   di
    803a:	9a 8c 4a 54 80       	call   0x8054:0x4a8c
    803f:	c9                   	leave
    8040:	ca 08 00             	retf   0x8
    8043:	55                   	push   bp
    8044:	89 e5                	mov    bp,sp
    8046:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8049:	ff 76 0a             	push   WORD PTR [bp+0xa]
    804c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    804f:	06                   	push   es
    8050:	57                   	push   di
    8051:	9a a8 4d 85 80       	call   0x8085:0x4da8
    8056:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8059:	06                   	push   es
    805a:	57                   	push   di
    805b:	9a 29 77 84 85       	call   0x8584:0x7729
    8060:	c9                   	leave
    8061:	ca 08 00             	retf   0x8
    8064:	c8 0c 00 00          	enter  0xc,0x0
    8068:	c7 46 f4 01 02       	mov    WORD PTR [bp-0xc],0x201
    806d:	8d 7e f8             	lea    di,[bp-0x8]
    8070:	16                   	push   ss
    8071:	57                   	push   di
    8072:	9a ff ff 00 00       	call   0x0:0xffff
    8077:	ff 76 fa             	push   WORD PTR [bp-0x6]
    807a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    807d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8080:	06                   	push   es
    8081:	57                   	push   di
    8082:	9a 06 1a 11 83       	call   0x8311:0x1a06
    8087:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    808a:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    808d:	31 c0                	xor    ax,ax
    808f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    8092:	31 c0                	xor    ax,ax
    8094:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    8097:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    809a:	8d 7e f4             	lea    di,[bp-0xc]
    809d:	16                   	push   ss
    809e:	57                   	push   di
    809f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80a2:	06                   	push   es
    80a3:	57                   	push   di
    80a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80a7:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    80ab:	c7 46 f4 02 02       	mov    WORD PTR [bp-0xc],0x202
    80b0:	8d 7e f4             	lea    di,[bp-0xc]
    80b3:	16                   	push   ss
    80b4:	57                   	push   di
    80b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80b8:	06                   	push   es
    80b9:	57                   	push   di
    80ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80bd:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    80c1:	c9                   	leave
    80c2:	ca 04 00             	retf   0x4
    80c5:	c8 08 01 00          	enter  0x108,0x0
    80c9:	8c d3                	mov    bx,ss
    80cb:	8e c3                	mov    es,bx
    80cd:	8c db                	mov    bx,ds
    80cf:	fc                   	cld
    80d0:	8d 7e f8             	lea    di,[bp-0x8]
    80d3:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    80d6:	b9 08 00             	mov    cx,0x8
    80d9:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    80db:	8e db                	mov    ds,bx
    80dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80e0:	26 8b 85 f4 00       	mov    ax,WORD PTR es:[di+0xf4]
    80e5:	09 c0                	or     ax,ax
    80e7:	74 26                	je     0x810f
    80e9:	ff 76 08             	push   WORD PTR [bp+0x8]
    80ec:	ff 76 06             	push   WORD PTR [bp+0x6]
    80ef:	ff 76 10             	push   WORD PTR [bp+0x10]
    80f2:	8d 7e f8             	lea    di,[bp-0x8]
    80f5:	16                   	push   ss
    80f6:	57                   	push   di
    80f7:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    80fa:	50                   	push   ax
    80fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80fe:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    8103:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    8108:	26 ff 9d f2 00       	call   DWORD PTR es:[di+0xf2]
    810d:	eb 5c                	jmp    0x816b
    810f:	8d 7e f8             	lea    di,[bp-0x8]
    8112:	16                   	push   ss
    8113:	57                   	push   di
    8114:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8117:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    811c:	06                   	push   es
    811d:	57                   	push   di
    811e:	9a e5 1c 69 81       	call   0x8169:0x1ce5
    8123:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8126:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    812b:	06                   	push   es
    812c:	57                   	push   di
    812d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8130:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    8134:	3b 46 10             	cmp    ax,WORD PTR [bp+0x10]
    8137:	7e 32                	jle    0x816b
    8139:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    813c:	40                   	inc    ax
    813d:	40                   	inc    ax
    813e:	50                   	push   ax
    813f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    8142:	8d be f8 fe          	lea    di,[bp-0x108]
    8146:	16                   	push   ss
    8147:	57                   	push   di
    8148:	ff 76 10             	push   WORD PTR [bp+0x10]
    814b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    814e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    8153:	06                   	push   es
    8154:	57                   	push   di
    8155:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8158:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    815c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    815f:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    8164:	06                   	push   es
    8165:	57                   	push   di
    8166:	9a 09 1f cb 81       	call   0x81cb:0x1f09
    816b:	c9                   	leave
    816c:	ca 0c 00             	retf   0xc
    816f:	55                   	push   bp
    8170:	89 e5                	mov    bp,sp
    8172:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8175:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    817a:	09 c0                	or     ax,ax
    817c:	74 20                	je     0x819e
    817e:	ff 76 08             	push   WORD PTR [bp+0x8]
    8181:	ff 76 06             	push   WORD PTR [bp+0x6]
    8184:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8187:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    818a:	06                   	push   es
    818b:	57                   	push   di
    818c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    818f:	26 ff b5 00 01       	push   WORD PTR es:[di+0x100]
    8194:	26 ff b5 fe 00       	push   WORD PTR es:[di+0xfe]
    8199:	26 ff 9d fa 00       	call   DWORD PTR es:[di+0xfa]
    819e:	c9                   	leave
    819f:	ca 0a 00             	retf   0xa
    81a2:	c8 06 00 00          	enter  0x6,0x0
    81a6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    81a9:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    81ad:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    81b0:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    81b3:	26 8a 45 08          	mov    al,BYTE PTR es:[di+0x8]
    81b7:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    81ba:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    81be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81c1:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    81c6:	06                   	push   es
    81c7:	57                   	push   di
    81c8:	9a 5d 22 e2 81       	call   0x81e2:0x225d
    81cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81d0:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    81d4:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    81d8:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    81dd:	06                   	push   es
    81de:	57                   	push   di
    81df:	9a 99 20 fb 81       	call   0x81fb:0x2099
    81e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81e7:	26 ff b5 a0 00       	push   WORD PTR es:[di+0xa0]
    81ec:	26 ff b5 9e 00       	push   WORD PTR es:[di+0x9e]
    81f1:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    81f6:	06                   	push   es
    81f7:	57                   	push   di
    81f8:	9a d3 20 22 82       	call   0x8222:0x20d3
    81fd:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    8200:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    8205:	7c 34                	jl     0x823b
    8207:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
    820b:	74 2e                	je     0x823b
    820d:	6a ff                	push   0xffff
    820f:	6a f2                	push   0xfff2
    8211:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8214:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    8219:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    821d:	06                   	push   es
    821e:	57                   	push   di
    821f:	9a 84 16 39 82       	call   0x8239:0x1684
    8224:	6a ff                	push   0xffff
    8226:	6a f1                	push   0xfff1
    8228:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    822b:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    8230:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    8234:	06                   	push   es
    8235:	57                   	push   di
    8236:	9a df 0f 77 82       	call   0x8277:0xfdf
    823b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    823e:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    8243:	7c 1c                	jl     0x8261
    8245:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    8249:	81 c7 0e 00          	add    di,0xe
    824d:	06                   	push   es
    824e:	57                   	push   di
    824f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    8252:	50                   	push   ax
    8253:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8256:	06                   	push   es
    8257:	57                   	push   di
    8258:	26 c4 3d             	les    di,DWORD PTR es:[di]
    825b:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    825f:	eb 18                	jmp    0x8279
    8261:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    8264:	81 c7 0e 00          	add    di,0xe
    8268:	06                   	push   es
    8269:	57                   	push   di
    826a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    826d:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    8272:	06                   	push   es
    8273:	57                   	push   di
    8274:	9a e5 1c a0 82       	call   0x82a0:0x1ce5
    8279:	f6 46 ff 10          	test   BYTE PTR [bp-0x1],0x10
    827d:	74 12                	je     0x8291
    827f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    8282:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    8286:	81 c7 0e 00          	add    di,0xe
    828a:	06                   	push   es
    828b:	57                   	push   di
    828c:	9a ff ff 00 00       	call   0x0:0xffff
    8291:	6a 00                	push   0x0
    8293:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8296:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    829b:	06                   	push   es
    829c:	57                   	push   di
    829d:	9a 5d 22 ff ff       	call   0xffff:0x225d
    82a2:	c9                   	leave
    82a3:	ca 08 00             	retf   0x8
    82a6:	c8 04 00 00          	enter  0x4,0x0
    82aa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    82ad:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    82b1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    82b4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    82b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82ba:	26 8b 85 e3 00       	mov    ax,WORD PTR es:[di+0xe3]
    82bf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    82c2:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    82c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82c9:	26 80 bd e5 00 02    	cmp    BYTE PTR es:[di+0xe5],0x2
    82cf:	75 1a                	jne    0x82eb
    82d1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    82d4:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    82d8:	81 c7 08 00          	add    di,0x8
    82dc:	06                   	push   es
    82dd:	57                   	push   di
    82de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82e1:	06                   	push   es
    82e2:	57                   	push   di
    82e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    82e6:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    82eb:	c9                   	leave
    82ec:	ca 08 00             	retf   0x8
    82ef:	55                   	push   bp
    82f0:	89 e5                	mov    bp,sp
    82f2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    82f6:	74 08                	je     0x8300
    82f8:	83 ec 08             	sub    sp,0x8
    82fb:	9a e2 1f a7 84       	call   0x84a7:0x1fe2
    8300:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8303:	ff 76 0c             	push   WORD PTR [bp+0xc]
    8306:	31 c0                	xor    ax,ax
    8308:	50                   	push   ax
    8309:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    830c:	06                   	push   es
    830d:	57                   	push   di
    830e:	9a 61 2e 1d 83       	call   0x831d:0x2e61
    8313:	6a 79                	push   0x79
    8315:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8318:	06                   	push   es
    8319:	57                   	push   di
    831a:	9a bf 17 2f 83       	call   0x832f:0x17bf
    831f:	6a 03                	push   0x3
    8321:	9a ff ff 00 00       	call   0x0:0xffff
    8326:	50                   	push   ax
    8327:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    832a:	06                   	push   es
    832b:	57                   	push   di
    832c:	9a e1 17 3b 83       	call   0x833b:0x17e1
    8331:	6a 01                	push   0x1
    8333:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8336:	06                   	push   es
    8337:	57                   	push   di
    8338:	9a 88 64 97 83       	call   0x8397:0x6488
    833d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8340:	26 c7 45 26 90 00    	mov    WORD PTR es:[di+0x26],0x90
    8346:	26 c6 85 d8 00 00    	mov    BYTE PTR es:[di+0xd8],0x0
    834c:	31 c0                	xor    ax,ax
    834e:	26 89 85 da 00       	mov    WORD PTR es:[di+0xda],ax
    8353:	31 c0                	xor    ax,ax
    8355:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    835a:	26 c7 85 de 00 64 00 	mov    WORD PTR es:[di+0xde],0x64
    8361:	26 c7 85 e0 00 01 00 	mov    WORD PTR es:[di+0xe0],0x1
    8368:	26 c7 85 e2 00 01 00 	mov    WORD PTR es:[di+0xe2],0x1
    836f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    8373:	74 07                	je     0x837c
    8375:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8379:	83 c4 06             	add    sp,0x6
    837c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    837f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    8382:	c9                   	leave
    8383:	ca 0a 00             	retf   0xa
    8386:	c8 04 00 00          	enter  0x4,0x0
    838a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    838d:	06                   	push   es
    838e:	57                   	push   di
    838f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8392:	06                   	push   es
    8393:	57                   	push   di
    8394:	9a 29 3b ab 83       	call   0x83ab:0x3b29
    8399:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    839c:	06                   	push   es
    839d:	57                   	push   di
    839e:	bf 78 0f             	mov    di,0xf78
    83a1:	1e                   	push   ds
    83a2:	57                   	push   di
    83a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    83a6:	06                   	push   es
    83a7:	57                   	push   di
    83a8:	9a d0 3a ee 83       	call   0x83ee:0x3ad0
    83ad:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    83b0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    83b3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    83b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    83b9:	26 8a 85 d8 00       	mov    al,BYTE PTR es:[di+0xd8]
    83be:	98                   	cbw
    83bf:	8b f8                	mov    di,ax
    83c1:	c1 e7 02             	shl    di,0x2
    83c4:	8b 85 70 0f          	mov    ax,WORD PTR [di+0xf70]
    83c8:	8b 95 72 0f          	mov    dx,WORD PTR [di+0xf72]
    83cc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    83cf:	26 0b 45 04          	or     ax,WORD PTR es:[di+0x4]
    83d3:	26 0b 55 06          	or     dx,WORD PTR es:[di+0x6]
    83d7:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    83db:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    83df:	c9                   	leave
    83e0:	ca 08 00             	retf   0x8
    83e3:	55                   	push   bp
    83e4:	89 e5                	mov    bp,sp
    83e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    83e9:	06                   	push   es
    83ea:	57                   	push   di
    83eb:	9a 88 3c f8 83       	call   0x83f8:0x3c88
    83f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    83f3:	06                   	push   es
    83f4:	57                   	push   di
    83f5:	9a b9 62 19 84       	call   0x8419:0x62b9
    83fa:	50                   	push   ax
    83fb:	6a 02                	push   0x2
    83fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8400:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
    8405:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    840a:	6a 00                	push   0x0
    840c:	9a 20 85 00 00       	call   0x0:0x8520
    8411:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8414:	06                   	push   es
    8415:	57                   	push   di
    8416:	9a b9 62 72 84       	call   0x8472:0x62b9
    841b:	50                   	push   ax
    841c:	6a 02                	push   0x2
    841e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8421:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    8426:	6a 01                	push   0x1
    8428:	9a 57 85 00 00       	call   0x0:0x8557
    842d:	c9                   	leave
    842e:	ca 04 00             	retf   0x4
    8431:	c8 02 00 00          	enter  0x2,0x0
    8435:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8438:	26 8a 85 d8 00       	mov    al,BYTE PTR es:[di+0xd8]
    843d:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    8440:	74 32                	je     0x8474
    8442:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    8445:	26 88 85 d8 00       	mov    BYTE PTR es:[di+0xd8],al
    844a:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    844f:	75 19                	jne    0x846a
    8451:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    8455:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    8459:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    845d:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    8461:	06                   	push   es
    8462:	57                   	push   di
    8463:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8466:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    846a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    846d:	06                   	push   es
    846e:	57                   	push   di
    846f:	9a 5a 40 99 84       	call   0x8499:0x405a
    8474:	c9                   	leave
    8475:	ca 06 00             	retf   0x6
    8478:	c8 00 01 00          	enter  0x100,0x0
    847c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    847f:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    8482:	7d 25                	jge    0x84a9
    8484:	8d be 00 ff          	lea    di,[bp-0x100]
    8488:	16                   	push   ss
    8489:	57                   	push   di
    848a:	68 2e f0             	push   0xf02e
    848d:	9a 2b 09 a0 84       	call   0x84a0:0x92b
    8492:	b0 01                	mov    al,0x1
    8494:	50                   	push   ax
    8495:	b8 52 00             	mov    ax,0x52
    8498:	ba f4 84             	mov    dx,0x84f4
    849b:	52                   	push   dx
    849c:	50                   	push   ax
    849d:	9a e6 28 ff ff       	call   0xffff:0x28e6
    84a2:	52                   	push   dx
    84a3:	50                   	push   ax
    84a4:	9a 99 13 66 85       	call   0x8566:0x1399
    84a9:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    84ac:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    84af:	7d 06                	jge    0x84b7
    84b1:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    84b4:	89 46 0e             	mov    WORD PTR [bp+0xe],ax
    84b7:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    84ba:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    84bd:	7e 06                	jle    0x84c5
    84bf:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    84c2:	89 46 0e             	mov    WORD PTR [bp+0xe],ax
    84c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84c8:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    84cd:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    84d0:	75 0a                	jne    0x84dc
    84d2:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    84d7:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    84da:	74 48                	je     0x8524
    84dc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    84df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84e2:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    84e7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    84ea:	26 89 85 de 00       	mov    WORD PTR es:[di+0xde],ax
    84ef:	06                   	push   es
    84f0:	57                   	push   di
    84f1:	9a fa 64 02 85       	call   0x8502:0x64fa
    84f6:	08 c0                	or     al,al
    84f8:	74 2a                	je     0x8524
    84fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    84fd:	06                   	push   es
    84fe:	57                   	push   di
    84ff:	9a b9 62 3e 85       	call   0x853e:0x62b9
    8504:	50                   	push   ax
    8505:	6a 02                	push   0x2
    8507:	ff 76 0c             	push   WORD PTR [bp+0xc]
    850a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    850d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8510:	26 8b 85 da 00       	mov    ax,WORD PTR es:[di+0xda]
    8515:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    8518:	b0 00                	mov    al,0x0
    851a:	75 01                	jne    0x851d
    851c:	40                   	inc    ax
    851d:	98                   	cbw
    851e:	50                   	push   ax
    851f:	9a ff ff 00 00       	call   0x0:0xffff
    8524:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8527:	26 8b 85 da 00       	mov    ax,WORD PTR es:[di+0xda]
    852c:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    852f:	74 37                	je     0x8568
    8531:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    8534:	26 89 85 da 00       	mov    WORD PTR es:[di+0xda],ax
    8539:	06                   	push   es
    853a:	57                   	push   di
    853b:	9a fa 64 4c 85       	call   0x854c:0x64fa
    8540:	08 c0                	or     al,al
    8542:	74 17                	je     0x855b
    8544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8547:	06                   	push   es
    8548:	57                   	push   di
    8549:	9a b9 62 ff ff       	call   0xffff:0x62b9
    854e:	50                   	push   ax
    854f:	6a 02                	push   0x2
    8551:	ff 76 0e             	push   WORD PTR [bp+0xe]
    8554:	6a 01                	push   0x1
    8556:	9a ff ff 00 00       	call   0x0:0xffff
    855b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    855e:	06                   	push   es
    855f:	57                   	push   di
    8560:	b8 ee ff             	mov    ax,0xffee
    8563:	9a 6a 20 40 87       	call   0x8740:0x206a
    8568:	c9                   	leave
    8569:	ca 0a 00             	retf   0xa
    856c:	55                   	push   bp
    856d:	89 e5                	mov    bp,sp
    856f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8572:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8575:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
    857a:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    857f:	06                   	push   es
    8580:	57                   	push   di
    8581:	9a 78 84 a2 85       	call   0x85a2:0x8478
    8586:	c9                   	leave
    8587:	ca 06 00             	retf   0x6
    858a:	55                   	push   bp
    858b:	89 e5                	mov    bp,sp
    858d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8590:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    8595:	ff 76 0a             	push   WORD PTR [bp+0xa]
    8598:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    859d:	06                   	push   es
    859e:	57                   	push   di
    859f:	9a 78 84 c0 85       	call   0x85c0:0x8478
    85a4:	c9                   	leave
    85a5:	ca 06 00             	retf   0x6
    85a8:	55                   	push   bp
    85a9:	89 e5                	mov    bp,sp
    85ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    85ae:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    85b3:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
    85b8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    85bb:	06                   	push   es
    85bc:	57                   	push   di
    85bd:	9a 78 84 4d 87       	call   0x874d:0x8478
    85c2:	c9                   	leave
    85c3:	ca 06 00             	retf   0x6
    85c6:	55                   	push   bp
    85c7:	89 e5                	mov    bp,sp
    85c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    85cc:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    85d1:	09 c0                	or     ax,ax
    85d3:	74 15                	je     0x85ea
    85d5:	ff 76 08             	push   WORD PTR [bp+0x8]
    85d8:	ff 76 06             	push   WORD PTR [bp+0x6]
    85db:	26 ff b5 ea 00       	push   WORD PTR es:[di+0xea]
    85e0:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    85e5:	26 ff 9d e4 00       	call   DWORD PTR es:[di+0xe4]
    85ea:	c9                   	leave
    85eb:	ca 04 00             	retf   0x4
    85ee:	55                   	push   bp
    85ef:	89 e5                	mov    bp,sp
    85f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    85f4:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    85f9:	09 c0                	or     ax,ax
    85fb:	74 21                	je     0x861e
    85fd:	ff 76 08             	push   WORD PTR [bp+0x8]
    8600:	ff 76 06             	push   WORD PTR [bp+0x6]
    8603:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    8606:	50                   	push   ax
    8607:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    860a:	06                   	push   es
    860b:	57                   	push   di
    860c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    860f:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    8614:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    8619:	26 ff 9d ec 00       	call   DWORD PTR es:[di+0xec]
    861e:	c9                   	leave
    861f:	ca 0a 00             	retf   0xa
    8622:	66 86 77 86          	data32 xchg BYTE PTR [bx-0x7a],dh
    8626:	88 86 99 86          	mov    BYTE PTR [bp-0x7967],al
    862a:	aa                   	stos   BYTE PTR es:[di],al
    862b:	86 aa 86 ba          	xchg   BYTE PTR [bp+si-0x457a],ch
    862f:	86 cb                	xchg   bl,cl
    8631:	86 c8                	xchg   al,cl
    8633:	0a 00                	or     al,BYTE PTR [bx+si]
    8635:	00 c4                	add    ah,al
    8637:	7e 0a                	jle    0x8643
    8639:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    863c:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    863f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8642:	26 8b 85 da 00       	mov    ax,WORD PTR es:[di+0xda]
    8647:	99                   	cwd
    8648:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    864b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    864e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    8651:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
    8655:	3c 07                	cmp    al,0x7
    8657:	76 03                	jbe    0x865c
    8659:	e9 7e 00             	jmp    0x86da
    865c:	98                   	cbw
    865d:	89 c3                	mov    bx,ax
    865f:	d1 e3                	shl    bx,1
    8661:	2e ff a7 22 86       	jmp    WORD PTR cs:[bx-0x79de]
    8666:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8669:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    866e:	99                   	cwd
    866f:	29 46 fa             	sub    WORD PTR [bp-0x6],ax
    8672:	19 56 fc             	sbb    WORD PTR [bp-0x4],dx
    8675:	eb 63                	jmp    0x86da
    8677:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    867a:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    867f:	99                   	cwd
    8680:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    8683:	11 56 fc             	adc    WORD PTR [bp-0x4],dx
    8686:	eb 52                	jmp    0x86da
    8688:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    868b:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    8690:	99                   	cwd
    8691:	29 46 fa             	sub    WORD PTR [bp-0x6],ax
    8694:	19 56 fc             	sbb    WORD PTR [bp-0x4],dx
    8697:	eb 41                	jmp    0x86da
    8699:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    869c:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    86a1:	99                   	cwd
    86a2:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    86a5:	11 56 fc             	adc    WORD PTR [bp-0x4],dx
    86a8:	eb 30                	jmp    0x86da
    86aa:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    86ad:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    86b1:	99                   	cwd
    86b2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    86b5:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    86b8:	eb 20                	jmp    0x86da
    86ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86bd:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    86c2:	99                   	cwd
    86c3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    86c6:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    86c9:	eb 0f                	jmp    0x86da
    86cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86ce:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    86d3:	99                   	cwd
    86d4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    86d7:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    86da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86dd:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    86e2:	99                   	cwd
    86e3:	3b 56 fc             	cmp    dx,WORD PTR [bp-0x4]
    86e6:	7f 07                	jg     0x86ef
    86e8:	7c 14                	jl     0x86fe
    86ea:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    86ed:	76 0f                	jbe    0x86fe
    86ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    86f2:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    86f7:	99                   	cwd
    86f8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    86fb:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    86fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8701:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    8706:	99                   	cwd
    8707:	3b 56 fc             	cmp    dx,WORD PTR [bp-0x4]
    870a:	7c 07                	jl     0x8713
    870c:	7f 14                	jg     0x8722
    870e:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    8711:	73 0f                	jae    0x8722
    8713:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8716:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    871b:	99                   	cwd
    871c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    871f:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    8722:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    8725:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    8728:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    872b:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
    872f:	50                   	push   ax
    8730:	8d 7e fe             	lea    di,[bp-0x2]
    8733:	16                   	push   ss
    8734:	57                   	push   di
    8735:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8738:	06                   	push   es
    8739:	57                   	push   di
    873a:	b8 ed ff             	mov    ax,0xffed
    873d:	9a 6a 20 ff ff       	call   0xffff:0x206a
    8742:	ff 76 fe             	push   WORD PTR [bp-0x2]
    8745:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8748:	06                   	push   es
    8749:	57                   	push   di
    874a:	9a 6c 85 63 87       	call   0x8763:0x856c
    874f:	c9                   	leave
    8750:	ca 08 00             	retf   0x8
    8753:	55                   	push   bp
    8754:	89 e5                	mov    bp,sp
    8756:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8759:	06                   	push   es
    875a:	57                   	push   di
    875b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    875e:	06                   	push   es
    875f:	57                   	push   di
    8760:	9a 32 86 79 87       	call   0x8779:0x8632
    8765:	c9                   	leave
    8766:	ca 08 00             	retf   0x8
    8769:	55                   	push   bp
    876a:	89 e5                	mov    bp,sp
    876c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    876f:	06                   	push   es
    8770:	57                   	push   di
    8771:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8774:	06                   	push   es
    8775:	57                   	push   di
    8776:	9a 32 86 ff ff       	call   0xffff:0x8632
    877b:	c9                   	leave
    877c:	ca                   	.byte 0xca
    877d:	08                   	.byte 0x8
