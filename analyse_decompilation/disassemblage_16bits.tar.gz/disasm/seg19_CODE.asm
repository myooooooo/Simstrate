; ================================================================
; seg19_CODE  (15805 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	13 00                	adc    ax,WORD PTR [bx+si]
       2:	96                   	xchg   si,ax
       3:	09 cd                	or     bp,cx
       5:	00 ae 00 00          	add    BYTE PTR [bp+0x0],ch
       9:	00 9e 00 3a          	add    BYTE PTR [bp+0x3a00],bl
       d:	05 fb 04             	add    ax,0x4fb
      10:	ad                   	lods   ax,WORD PTR ds:[si]
      11:	09 39                	or     WORD PTR [bx+di],di
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f c0 09 cb       	call   0xcb09:0xc01f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 91 0a d6          	adc    BYTE PTR [bx+di-0x29f6],dl
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 34                	sbb    al,0x34
      61:	0a e2                	or     ah,dl
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	41                   	inc    cx
      a6:	44                   	inc    sp
      a7:	49                   	dec    cx
      a8:	5f                   	pop    di
      a9:	50                   	push   ax
      aa:	72 69                	jb     0x115
      ac:	6e                   	outs   dx,BYTE PTR ds:[si]
      ad:	74 02                	je     0xb1
      af:	00 53 0d             	add    BYTE PTR [bp+di+0xd],dl
      b2:	c0 00 09             	rol    BYTE PTR [bx+si],0x9
      b5:	46                   	inc    si
      b6:	6f                   	outs   dx,WORD PTR ds:[si]
      b7:	72 6d                	jb     0x126
      b9:	43                   	inc    bx
      ba:	6c                   	ins    BYTE PTR es:[di],dx
      bb:	6f                   	outs   dx,WORD PTR ds:[si]
      bc:	73 65                	jae    0x123
      be:	f3 09 a9 09 0a       	repz or WORD PTR [bx+di+0xa09],bp
      c3:	46                   	inc    si
      c4:	6f                   	outs   dx,WORD PTR ds:[si]
      c5:	72 6d                	jb     0x134
      c7:	43                   	inc    bx
      c8:	72 65                	jb     0x12f
      ca:	61                   	popa
      cb:	74 65                	je     0x132
      cd:	af                   	scas   ax,WORD PTR es:[di]
      ce:	00 74 09             	add    BYTE PTR [si+0x9],dh
      d1:	7c 01                	jl     0xd4
      d3:	00 00                	add    BYTE PTR [bx+si],al
      d5:	06                   	push   es
      d6:	50                   	push   ax
      d7:	61                   	popa
      d8:	6e                   	outs   dx,BYTE PTR ds:[si]
      d9:	65 6c                	gs ins BYTE PTR es:[di],dx
      db:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
      df:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
      e3:	6e                   	outs   dx,BYTE PTR ds:[si]
      e4:	65 6c                	gs ins BYTE PTR es:[di],dx
      e6:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
      ea:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
      ee:	6e                   	outs   dx,BYTE PTR ds:[si]
      ef:	65 6c                	gs ins BYTE PTR es:[di],dx
      f1:	35 88 01             	xor    ax,0x188
      f4:	00 00                	add    BYTE PTR [bx+si],al
      f6:	06                   	push   es
      f7:	50                   	push   ax
      f8:	61                   	popa
      f9:	6e                   	outs   dx,BYTE PTR ds:[si]
      fa:	65 6c                	gs ins BYTE PTR es:[di],dx
      fc:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     100:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     104:	6e                   	outs   dx,BYTE PTR ds:[si]
     105:	65 6c                	gs ins BYTE PTR es:[di],dx
     107:	36 90                	ss nop
     109:	01 00                	add    WORD PTR [bx+si],ax
     10b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     10f:	6e                   	outs   dx,BYTE PTR ds:[si]
     110:	65 6c                	gs ins BYTE PTR es:[di],dx
     112:	38 94 01 00          	cmp    BYTE PTR [si+0x1],dl
     116:	00 07                	add    BYTE PTR [bx],al
     118:	50                   	push   ax
     119:	61                   	popa
     11a:	6e                   	outs   dx,BYTE PTR ds:[si]
     11b:	65 6c                	gs ins BYTE PTR es:[di],dx
     11d:	33 37                	xor    si,WORD PTR [bx]
     11f:	98                   	cbw
     120:	01 00                	add    WORD PTR [bx+si],ax
     122:	00 07                	add    BYTE PTR [bx],al
     124:	50                   	push   ax
     125:	61                   	popa
     126:	6e                   	outs   dx,BYTE PTR ds:[si]
     127:	65 6c                	gs ins BYTE PTR es:[di],dx
     129:	33 38                	xor    di,WORD PTR [bx+si]
     12b:	9c                   	pushf
     12c:	01 04                	add    WORD PTR [si],ax
     12e:	00 07                	add    BYTE PTR [bx],al
     130:	54                   	push   sp
     131:	61                   	popa
     132:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     135:	44                   	inc    sp
     136:	47                   	inc    di
     137:	a0 01 08             	mov    al,ds:0x801
     13a:	00 0c                	add    BYTE PTR [si],cl
     13c:	44                   	inc    sp
     13d:	61                   	popa
     13e:	74 61                	je     0x1a1
     140:	53                   	push   bx
     141:	6f                   	outs   dx,WORD PTR ds:[si]
     142:	75 72                	jne    0x1b6
     144:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     147:	47                   	inc    di
     148:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     149:	01 08                	add    WORD PTR [bx+si],cx
     14b:	00 0d                	add    BYTE PTR [di],cl
     14d:	44                   	inc    sp
     14e:	61                   	popa
     14f:	74 61                	je     0x1b2
     151:	53                   	push   bx
     152:	6f                   	outs   dx,WORD PTR ds:[si]
     153:	75 72                	jne    0x1c7
     155:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     158:	50                   	push   ax
     159:	31 a8 01 08          	xor    WORD PTR [bx+si+0x801],bp
     15d:	00 0d                	add    BYTE PTR [di],cl
     15f:	44                   	inc    sp
     160:	61                   	popa
     161:	74 61                	je     0x1c4
     163:	53                   	push   bx
     164:	6f                   	outs   dx,WORD PTR ds:[si]
     165:	75 72                	jne    0x1d9
     167:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     16a:	50                   	push   ax
     16b:	32 ac 01 04          	xor    ch,BYTE PTR [si+0x401]
     16f:	00 08                	add    BYTE PTR [bx+si],cl
     171:	54                   	push   sp
     172:	61                   	popa
     173:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     176:	44                   	inc    sp
     177:	50                   	push   ax
     178:	31 b0 01 04          	xor    WORD PTR [bx+si+0x401],si
     17c:	00 08                	add    BYTE PTR [bx+si],cl
     17e:	54                   	push   sp
     17f:	61                   	popa
     180:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     183:	44                   	inc    sp
     184:	50                   	push   ax
     185:	32 b4 01 00          	xor    dh,BYTE PTR [si+0x1]
     189:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     18d:	6e                   	outs   dx,BYTE PTR ds:[si]
     18e:	65 6c                	gs ins BYTE PTR es:[di],dx
     190:	34 b8                	xor    al,0xb8
     192:	01 0c                	add    WORD PTR [si],cx
     194:	00 09                	add    BYTE PTR [bx+di],cl
     196:	47                   	inc    di
     197:	72 6f                	jb     0x208
     199:	75 70                	jne    0x20b
     19b:	42                   	inc    dx
     19c:	6f                   	outs   dx,WORD PTR ds:[si]
     19d:	78 31                	js     0x1d0
     19f:	bc 01 0c             	mov    sp,0xc01
     1a2:	00 09                	add    BYTE PTR [bx+di],cl
     1a4:	47                   	inc    di
     1a5:	72 6f                	jb     0x216
     1a7:	75 70                	jne    0x219
     1a9:	42                   	inc    dx
     1aa:	6f                   	outs   dx,WORD PTR ds:[si]
     1ab:	78 34                	js     0x1e1
     1ad:	c0 01 10             	rol    BYTE PTR [bx+di],0x10
     1b0:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     1b4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1b7:	31 c4                	xor    sp,ax
     1b9:	01 10                	add    WORD PTR [bx+si],dx
     1bb:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     1bf:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1c2:	34 c8                	xor    al,0xc8
     1c4:	01 10                	add    WORD PTR [bx+si],dx
     1c6:	00 07                	add    BYTE PTR [bx],al
     1c8:	4c                   	dec    sp
     1c9:	61                   	popa
     1ca:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1cd:	31 30                	xor    WORD PTR [bx+si],si
     1cf:	cc                   	int3
     1d0:	01 10                	add    WORD PTR [bx+si],dx
     1d2:	00 07                	add    BYTE PTR [bx],al
     1d4:	4c                   	dec    sp
     1d5:	61                   	popa
     1d6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1d9:	33 30                	xor    si,WORD PTR [bx+si]
     1db:	d0 01                	rol    BYTE PTR [bx+di],1
     1dd:	10 00                	adc    BYTE PTR [bx+si],al
     1df:	06                   	push   es
     1e0:	4c                   	dec    sp
     1e1:	61                   	popa
     1e2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1e5:	32 d4                	xor    dl,ah
     1e7:	01 10                	add    WORD PTR [bx+si],dx
     1e9:	00 07                	add    BYTE PTR [bx],al
     1eb:	4c                   	dec    sp
     1ec:	61                   	popa
     1ed:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1f0:	31 36 d8 01          	xor    WORD PTR ds:0x1d8,si
     1f4:	10 00                	adc    BYTE PTR [bx+si],al
     1f6:	06                   	push   es
     1f7:	4c                   	dec    sp
     1f8:	61                   	popa
     1f9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1fc:	33 dc                	xor    bx,sp
     1fe:	01 14                	add    WORD PTR [si],dx
     200:	00 07                	add    BYTE PTR [bx],al
     202:	44                   	inc    sp
     203:	42                   	inc    dx
     204:	45                   	inc    bp
     205:	64 69 74 31 e0 01    	imul   si,WORD PTR fs:[si+0x31],0x1e0
     20b:	14 00                	adc    al,0x0
     20d:	07                   	pop    es
     20e:	44                   	inc    sp
     20f:	42                   	inc    dx
     210:	45                   	inc    bp
     211:	64 69 74 34 e4 01    	imul   si,WORD PTR fs:[si+0x34],0x1e4
     217:	14 00                	adc    al,0x0
     219:	08 44 42             	or     BYTE PTR [si+0x42],al
     21c:	45                   	inc    bp
     21d:	64 69 74 31 32 e8    	imul   si,WORD PTR fs:[si+0x31],0xe832
     223:	01 14                	add    WORD PTR [si],dx
     225:	00 08                	add    BYTE PTR [bx+si],cl
     227:	44                   	inc    sp
     228:	42                   	inc    dx
     229:	45                   	inc    bp
     22a:	64 69 74 33 32 ec    	imul   si,WORD PTR fs:[si+0x33],0xec32
     230:	01 14                	add    WORD PTR [si],dx
     232:	00 07                	add    BYTE PTR [bx],al
     234:	44                   	inc    sp
     235:	42                   	inc    dx
     236:	45                   	inc    bp
     237:	64 69 74 32 f0 01    	imul   si,WORD PTR fs:[si+0x32],0x1f0
     23d:	14 00                	adc    al,0x0
     23f:	08 44 42             	or     BYTE PTR [si+0x42],al
     242:	45                   	inc    bp
     243:	64 69 74 33 31 f4    	imul   si,WORD PTR fs:[si+0x33],0xf431
     249:	01 14                	add    WORD PTR [si],dx
     24b:	00 07                	add    BYTE PTR [bx],al
     24d:	44                   	inc    sp
     24e:	42                   	inc    dx
     24f:	45                   	inc    bp
     250:	64 69 74 33 f8 01    	imul   si,WORD PTR fs:[si+0x33],0x1f8
     256:	0c 00                	or     al,0x0
     258:	09 47 72             	or     WORD PTR [bx+0x72],ax
     25b:	6f                   	outs   dx,WORD PTR ds:[si]
     25c:	75 70                	jne    0x2ce
     25e:	42                   	inc    dx
     25f:	6f                   	outs   dx,WORD PTR ds:[si]
     260:	78 37                	js     0x299
     262:	fc                   	cld
     263:	01 10                	add    WORD PTR [bx+si],dx
     265:	00 07                	add    BYTE PTR [bx],al
     267:	4c                   	dec    sp
     268:	61                   	popa
     269:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     26c:	31 34                	xor    WORD PTR [si],si
     26e:	00 02                	add    BYTE PTR [bp+si],al
     270:	10 00                	adc    BYTE PTR [bx+si],al
     272:	07                   	pop    es
     273:	4c                   	dec    sp
     274:	61                   	popa
     275:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     278:	33 31                	xor    si,WORD PTR [bx+di]
     27a:	04 02                	add    al,0x2
     27c:	14 00                	adc    al,0x0
     27e:	08 44 42             	or     BYTE PTR [si+0x42],al
     281:	45                   	inc    bp
     282:	64 69 74 31 36 08    	imul   si,WORD PTR fs:[si+0x31],0x836
     288:	02 14                	add    dl,BYTE PTR [si]
     28a:	00 08                	add    BYTE PTR [bx+si],cl
     28c:	44                   	inc    sp
     28d:	42                   	inc    dx
     28e:	45                   	inc    bp
     28f:	64 69 74 33 33 0c    	imul   si,WORD PTR fs:[si+0x33],0xc33
     295:	02 0c                	add    cl,BYTE PTR [si]
     297:	00 09                	add    BYTE PTR [bx+di],cl
     299:	47                   	inc    di
     29a:	72 6f                	jb     0x30b
     29c:	75 70                	jne    0x30e
     29e:	42                   	inc    dx
     29f:	6f                   	outs   dx,WORD PTR ds:[si]
     2a0:	78 35                	js     0x2d7
     2a2:	10 02                	adc    BYTE PTR [bp+si],al
     2a4:	00 00                	add    BYTE PTR [bx+si],al
     2a6:	06                   	push   es
     2a7:	50                   	push   ax
     2a8:	61                   	popa
     2a9:	6e                   	outs   dx,BYTE PTR ds:[si]
     2aa:	65 6c                	gs ins BYTE PTR es:[di],dx
     2ac:	37                   	aaa
     2ad:	14 02                	adc    al,0x2
     2af:	10 00                	adc    BYTE PTR [bx+si],al
     2b1:	06                   	push   es
     2b2:	4c                   	dec    sp
     2b3:	61                   	popa
     2b4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2b7:	35 18 02             	xor    ax,0x218
     2ba:	10 00                	adc    BYTE PTR [bx+si],al
     2bc:	06                   	push   es
     2bd:	4c                   	dec    sp
     2be:	61                   	popa
     2bf:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2c2:	39 1c                	cmp    WORD PTR [si],bx
     2c4:	02 10                	add    dl,BYTE PTR [bx+si]
     2c6:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     2ca:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2cd:	38 20                	cmp    BYTE PTR [bx+si],ah
     2cf:	02 10                	add    dl,BYTE PTR [bx+si]
     2d1:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     2d5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2d8:	37                   	aaa
     2d9:	24 02                	and    al,0x2
     2db:	14 00                	adc    al,0x0
     2dd:	07                   	pop    es
     2de:	44                   	inc    sp
     2df:	42                   	inc    dx
     2e0:	45                   	inc    bp
     2e1:	64 69 74 35 28 02    	imul   si,WORD PTR fs:[si+0x35],0x228
     2e7:	14 00                	adc    al,0x0
     2e9:	07                   	pop    es
     2ea:	44                   	inc    sp
     2eb:	42                   	inc    dx
     2ec:	45                   	inc    bp
     2ed:	64 69 74 37 2c 02    	imul   si,WORD PTR fs:[si+0x37],0x22c
     2f3:	14 00                	adc    al,0x0
     2f5:	07                   	pop    es
     2f6:	44                   	inc    sp
     2f7:	42                   	inc    dx
     2f8:	45                   	inc    bp
     2f9:	64 69 74 39 30 02    	imul   si,WORD PTR fs:[si+0x39],0x230
     2ff:	00 00                	add    BYTE PTR [bx+si],al
     301:	07                   	pop    es
     302:	50                   	push   ax
     303:	61                   	popa
     304:	6e                   	outs   dx,BYTE PTR ds:[si]
     305:	65 6c                	gs ins BYTE PTR es:[di],dx
     307:	31 35                	xor    WORD PTR [di],si
     309:	34 02                	xor    al,0x2
     30b:	10 00                	adc    BYTE PTR [bx+si],al
     30d:	06                   	push   es
     30e:	4c                   	dec    sp
     30f:	61                   	popa
     310:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     313:	36 38 02             	cmp    BYTE PTR ss:[bp+si],al
     316:	14 00                	adc    al,0x0
     318:	07                   	pop    es
     319:	44                   	inc    sp
     31a:	42                   	inc    dx
     31b:	45                   	inc    bp
     31c:	64 69 74 36 3c 02    	imul   si,WORD PTR fs:[si+0x36],0x23c
     322:	14 00                	adc    al,0x0
     324:	07                   	pop    es
     325:	44                   	inc    sp
     326:	42                   	inc    dx
     327:	45                   	inc    bp
     328:	64 69 74 38 40 02    	imul   si,WORD PTR fs:[si+0x38],0x240
     32e:	14 00                	adc    al,0x0
     330:	08 44 42             	or     BYTE PTR [si+0x42],al
     333:	45                   	inc    bp
     334:	64 69 74 31 30 44    	imul   si,WORD PTR fs:[si+0x31],0x4430
     33a:	02 00                	add    al,BYTE PTR [bx+si]
     33c:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     340:	6e                   	outs   dx,BYTE PTR ds:[si]
     341:	65 6c                	gs ins BYTE PTR es:[di],dx
     343:	39 48 02             	cmp    WORD PTR [bx+si+0x2],cx
     346:	0c 00                	or     al,0x0
     348:	09 47 72             	or     WORD PTR [bx+0x72],ax
     34b:	6f                   	outs   dx,WORD PTR ds:[si]
     34c:	75 70                	jne    0x3be
     34e:	42                   	inc    dx
     34f:	6f                   	outs   dx,WORD PTR ds:[si]
     350:	78 32                	js     0x384
     352:	4c                   	dec    sp
     353:	02 0c                	add    cl,BYTE PTR [si]
     355:	00 09                	add    BYTE PTR [bx+di],cl
     357:	47                   	inc    di
     358:	72 6f                	jb     0x3c9
     35a:	75 70                	jne    0x3cc
     35c:	42                   	inc    dx
     35d:	6f                   	outs   dx,WORD PTR ds:[si]
     35e:	78 36                	js     0x396
     360:	50                   	push   ax
     361:	02 10                	add    dl,BYTE PTR [bx+si]
     363:	00 07                	add    BYTE PTR [bx],al
     365:	4c                   	dec    sp
     366:	61                   	popa
     367:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     36a:	31 32                	xor    WORD PTR [bp+si],si
     36c:	54                   	push   sp
     36d:	02 10                	add    dl,BYTE PTR [bx+si]
     36f:	00 07                	add    BYTE PTR [bx],al
     371:	4c                   	dec    sp
     372:	61                   	popa
     373:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     376:	31 33                	xor    WORD PTR [bp+di],si
     378:	58                   	pop    ax
     379:	02 14                	add    dl,BYTE PTR [si]
     37b:	00 08                	add    BYTE PTR [bx+si],cl
     37d:	44                   	inc    sp
     37e:	42                   	inc    dx
     37f:	45                   	inc    bp
     380:	64 69 74 31 34 5c    	imul   si,WORD PTR fs:[si+0x31],0x5c34
     386:	02 14                	add    dl,BYTE PTR [si]
     388:	00 08                	add    BYTE PTR [bx+si],cl
     38a:	44                   	inc    sp
     38b:	42                   	inc    dx
     38c:	45                   	inc    bp
     38d:	64 69 74 31 35 60    	imul   si,WORD PTR fs:[si+0x31],0x6035
     393:	02 0c                	add    cl,BYTE PTR [si]
     395:	00 09                	add    BYTE PTR [bx+di],cl
     397:	47                   	inc    di
     398:	72 6f                	jb     0x409
     39a:	75 70                	jne    0x40c
     39c:	42                   	inc    dx
     39d:	6f                   	outs   dx,WORD PTR ds:[si]
     39e:	78 38                	js     0x3d8
     3a0:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     3a3:	00 07                	add    BYTE PTR [bx],al
     3a5:	50                   	push   ax
     3a6:	61                   	popa
     3a7:	6e                   	outs   dx,BYTE PTR ds:[si]
     3a8:	65 6c                	gs ins BYTE PTR es:[di],dx
     3aa:	31 30                	xor    WORD PTR [bx+si],si
     3ac:	68 02 10             	push   0x1002
     3af:	00 07                	add    BYTE PTR [bx],al
     3b1:	4c                   	dec    sp
     3b2:	61                   	popa
     3b3:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3b6:	31 37                	xor    WORD PTR [bx],si
     3b8:	6c                   	ins    BYTE PTR es:[di],dx
     3b9:	02 10                	add    dl,BYTE PTR [bx+si]
     3bb:	00 07                	add    BYTE PTR [bx],al
     3bd:	4c                   	dec    sp
     3be:	61                   	popa
     3bf:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3c2:	31 39                	xor    WORD PTR [bx+di],di
     3c4:	70 02                	jo     0x3c8
     3c6:	14 00                	adc    al,0x0
     3c8:	08 44 42             	or     BYTE PTR [si+0x42],al
     3cb:	45                   	inc    bp
     3cc:	64 69 74 31 37 74    	imul   si,WORD PTR fs:[si+0x31],0x7437
     3d2:	02 00                	add    al,BYTE PTR [bx+si]
     3d4:	00 07                	add    BYTE PTR [bx],al
     3d6:	50                   	push   ax
     3d7:	61                   	popa
     3d8:	6e                   	outs   dx,BYTE PTR ds:[si]
     3d9:	65 6c                	gs ins BYTE PTR es:[di],dx
     3db:	31 36 78 02          	xor    WORD PTR ds:0x278,si
     3df:	10 00                	adc    BYTE PTR [bx+si],al
     3e1:	07                   	pop    es
     3e2:	4c                   	dec    sp
     3e3:	61                   	popa
     3e4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3e7:	31 38                	xor    WORD PTR [bx+si],di
     3e9:	7c 02                	jl     0x3ed
     3eb:	14 00                	adc    al,0x0
     3ed:	08 44 42             	or     BYTE PTR [si+0x42],al
     3f0:	45                   	inc    bp
     3f1:	64 69 74 31 39 80    	imul   si,WORD PTR fs:[si+0x31],0x8039
     3f7:	02 0c                	add    cl,BYTE PTR [si]
     3f9:	00 0a                	add    BYTE PTR [bp+si],cl
     3fb:	47                   	inc    di
     3fc:	72 6f                	jb     0x46d
     3fe:	75 70                	jne    0x470
     400:	42                   	inc    dx
     401:	6f                   	outs   dx,WORD PTR ds:[si]
     402:	78 31                	js     0x435
     404:	30 84 02 10          	xor    BYTE PTR [si+0x1002],al
     408:	00 07                	add    BYTE PTR [bx],al
     40a:	4c                   	dec    sp
     40b:	61                   	popa
     40c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     40f:	33 34                	xor    si,WORD PTR [si]
     411:	88 02                	mov    BYTE PTR [bp+si],al
     413:	10 00                	adc    BYTE PTR [bx+si],al
     415:	07                   	pop    es
     416:	4c                   	dec    sp
     417:	61                   	popa
     418:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     41b:	31 31                	xor    WORD PTR [bx+di],si
     41d:	8c 02                	mov    WORD PTR [bp+si],es
     41f:	10 00                	adc    BYTE PTR [bx+si],al
     421:	07                   	pop    es
     422:	4c                   	dec    sp
     423:	61                   	popa
     424:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     427:	33 35                	xor    si,WORD PTR [di]
     429:	90                   	nop
     42a:	02 10                	add    dl,BYTE PTR [bx+si]
     42c:	00 07                	add    BYTE PTR [bx],al
     42e:	4c                   	dec    sp
     42f:	61                   	popa
     430:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     433:	33 37                	xor    si,WORD PTR [bx]
     435:	94                   	xchg   sp,ax
     436:	02 10                	add    dl,BYTE PTR [bx+si]
     438:	00 07                	add    BYTE PTR [bx],al
     43a:	4c                   	dec    sp
     43b:	61                   	popa
     43c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     43f:	32 30                	xor    dh,BYTE PTR [bx+si]
     441:	98                   	cbw
     442:	02 10                	add    dl,BYTE PTR [bx+si]
     444:	00 07                	add    BYTE PTR [bx],al
     446:	4c                   	dec    sp
     447:	61                   	popa
     448:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     44b:	33 38                	xor    di,WORD PTR [bx+si]
     44d:	9c                   	pushf
     44e:	02 14                	add    dl,BYTE PTR [si]
     450:	00 08                	add    BYTE PTR [bx+si],cl
     452:	44                   	inc    sp
     453:	42                   	inc    dx
     454:	45                   	inc    bp
     455:	64 69 74 33 36 a0    	imul   si,WORD PTR fs:[si+0x33],0xa036
     45b:	02 14                	add    dl,BYTE PTR [si]
     45d:	00 08                	add    BYTE PTR [bx+si],cl
     45f:	44                   	inc    sp
     460:	42                   	inc    dx
     461:	45                   	inc    bp
     462:	64 69 74 31 33 a4    	imul   si,WORD PTR fs:[si+0x31],0xa433
     468:	02 14                	add    dl,BYTE PTR [si]
     46a:	00 08                	add    BYTE PTR [bx+si],cl
     46c:	44                   	inc    sp
     46d:	42                   	inc    dx
     46e:	45                   	inc    bp
     46f:	64 69 74 33 37 a8    	imul   si,WORD PTR fs:[si+0x33],0xa837
     475:	02 14                	add    dl,BYTE PTR [si]
     477:	00 08                	add    BYTE PTR [bx+si],cl
     479:	44                   	inc    sp
     47a:	42                   	inc    dx
     47b:	45                   	inc    bp
     47c:	64 69 74 33 39 ac    	imul   si,WORD PTR fs:[si+0x33],0xac39
     482:	02 14                	add    dl,BYTE PTR [si]
     484:	00 08                	add    BYTE PTR [bx+si],cl
     486:	44                   	inc    sp
     487:	42                   	inc    dx
     488:	45                   	inc    bp
     489:	64 69 74 31 38 b0    	imul   si,WORD PTR fs:[si+0x31],0xb038
     48f:	02 14                	add    dl,BYTE PTR [si]
     491:	00 08                	add    BYTE PTR [bx+si],cl
     493:	44                   	inc    sp
     494:	42                   	inc    dx
     495:	45                   	inc    bp
     496:	64 69 74 34 30 b4    	imul   si,WORD PTR fs:[si+0x34],0xb430
     49c:	02 0c                	add    cl,BYTE PTR [si]
     49e:	00 09                	add    BYTE PTR [bx+di],cl
     4a0:	47                   	inc    di
     4a1:	72 6f                	jb     0x512
     4a3:	75 70                	jne    0x515
     4a5:	42                   	inc    dx
     4a6:	6f                   	outs   dx,WORD PTR ds:[si]
     4a7:	78 39                	js     0x4e2
     4a9:	b8 02 10             	mov    ax,0x1002
     4ac:	00 07                	add    BYTE PTR [bx],al
     4ae:	4c                   	dec    sp
     4af:	61                   	popa
     4b0:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4b3:	31 35                	xor    WORD PTR [di],si
     4b5:	bc 02 10             	mov    sp,0x1002
     4b8:	00 07                	add    BYTE PTR [bx],al
     4ba:	4c                   	dec    sp
     4bb:	61                   	popa
     4bc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4bf:	33 32                	xor    si,WORD PTR [bp+si]
     4c1:	c0 02 10             	rol    BYTE PTR [bp+si],0x10
     4c4:	00 07                	add    BYTE PTR [bx],al
     4c6:	4c                   	dec    sp
     4c7:	61                   	popa
     4c8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4cb:	33 33                	xor    si,WORD PTR [bp+di]
     4cd:	c4 02                	les    ax,DWORD PTR [bp+si]
     4cf:	14 00                	adc    al,0x0
     4d1:	08 44 42             	or     BYTE PTR [si+0x42],al
     4d4:	45                   	inc    bp
     4d5:	64 69 74 31 31 c8    	imul   si,WORD PTR fs:[si+0x31],0xc831
     4db:	02 14                	add    dl,BYTE PTR [si]
     4dd:	00 08                	add    BYTE PTR [bx+si],cl
     4df:	44                   	inc    sp
     4e0:	42                   	inc    dx
     4e1:	45                   	inc    bp
     4e2:	64 69 74 33 34 cc    	imul   si,WORD PTR fs:[si+0x33],0xcc34
     4e8:	02 14                	add    dl,BYTE PTR [si]
     4ea:	00 08                	add    BYTE PTR [bx+si],cl
     4ec:	44                   	inc    sp
     4ed:	42                   	inc    dx
     4ee:	45                   	inc    bp
     4ef:	64 69 74 33 35 d0    	imul   si,WORD PTR fs:[si+0x33],0xd035
     4f5:	02 0c                	add    cl,BYTE PTR [si]
     4f7:	00 0a                	add    BYTE PTR [bp+si],cl
     4f9:	47                   	inc    di
     4fa:	72 6f                	jb     0x56b
     4fc:	75 70                	jne    0x56e
     4fe:	42                   	inc    dx
     4ff:	6f                   	outs   dx,WORD PTR ds:[si]
     500:	78 31                	js     0x533
     502:	32 d4                	xor    dl,ah
     504:	02 10                	add    dl,BYTE PTR [bx+si]
     506:	00 07                	add    BYTE PTR [bx],al
     508:	4c                   	dec    sp
     509:	61                   	popa
     50a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     50d:	34 36                	xor    al,0x36
     50f:	d8 02                	fadd   DWORD PTR [bp+si]
     511:	14 00                	adc    al,0x0
     513:	08 44 42             	or     BYTE PTR [si+0x42],al
     516:	45                   	inc    bp
     517:	64 69 74 32 30 dc    	imul   si,WORD PTR fs:[si+0x32],0xdc30
     51d:	02 0c                	add    cl,BYTE PTR [si]
     51f:	00 0a                	add    BYTE PTR [bp+si],cl
     521:	47                   	inc    di
     522:	72 6f                	jb     0x593
     524:	75 70                	jne    0x596
     526:	42                   	inc    dx
     527:	6f                   	outs   dx,WORD PTR ds:[si]
     528:	78 31                	js     0x55b
     52a:	31 e0                	xor    ax,sp
     52c:	02 10                	add    dl,BYTE PTR [bx+si]
     52e:	00 07                	add    BYTE PTR [bx],al
     530:	4c                   	dec    sp
     531:	61                   	popa
     532:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     535:	33 36 e4 02          	xor    si,WORD PTR ds:0x2e4
     539:	14 00                	adc    al,0x0
     53b:	08 44 42             	or     BYTE PTR [si+0x42],al
     53e:	45                   	inc    bp
     53f:	64 69 74 33 38 e8    	imul   si,WORD PTR fs:[si+0x33],0xe838
     545:	02 00                	add    al,BYTE PTR [bx+si]
     547:	00 07                	add    BYTE PTR [bx],al
     549:	50                   	push   ax
     54a:	61                   	popa
     54b:	6e                   	outs   dx,BYTE PTR ds:[si]
     54c:	65 6c                	gs ins BYTE PTR es:[di],dx
     54e:	31 31                	xor    WORD PTR [bx+di],si
     550:	ec                   	in     al,dx
     551:	02 0c                	add    cl,BYTE PTR [si]
     553:	00 09                	add    BYTE PTR [bx+di],cl
     555:	47                   	inc    di
     556:	72 6f                	jb     0x5c7
     558:	75 70                	jne    0x5ca
     55a:	42                   	inc    dx
     55b:	6f                   	outs   dx,WORD PTR ds:[si]
     55c:	78 33                	js     0x591
     55e:	f0 02 0c             	lock add cl,BYTE PTR [si]
     561:	00 0a                	add    BYTE PTR [bp+si],cl
     563:	47                   	inc    di
     564:	72 6f                	jb     0x5d5
     566:	75 70                	jne    0x5d8
     568:	42                   	inc    dx
     569:	6f                   	outs   dx,WORD PTR ds:[si]
     56a:	78 31                	js     0x59d
     56c:	33 f4                	xor    si,sp
     56e:	02 00                	add    al,BYTE PTR [bx+si]
     570:	00 07                	add    BYTE PTR [bx],al
     572:	50                   	push   ax
     573:	61                   	popa
     574:	6e                   	outs   dx,BYTE PTR ds:[si]
     575:	65 6c                	gs ins BYTE PTR es:[di],dx
     577:	31 32                	xor    WORD PTR [bp+si],si
     579:	f8                   	clc
     57a:	02 10                	add    dl,BYTE PTR [bx+si]
     57c:	00 07                	add    BYTE PTR [bx],al
     57e:	4c                   	dec    sp
     57f:	61                   	popa
     580:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     583:	32 36 fc 02          	xor    dh,BYTE PTR ds:0x2fc
     587:	10 00                	adc    BYTE PTR [bx+si],al
     589:	07                   	pop    es
     58a:	4c                   	dec    sp
     58b:	61                   	popa
     58c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     58f:	33 39                	xor    di,WORD PTR [bx+di]
     591:	00 03                	add    BYTE PTR [bp+di],al
     593:	10 00                	adc    BYTE PTR [bx+si],al
     595:	07                   	pop    es
     596:	4c                   	dec    sp
     597:	61                   	popa
     598:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     59b:	32 33                	xor    dh,BYTE PTR [bp+di]
     59d:	04 03                	add    al,0x3
     59f:	10 00                	adc    BYTE PTR [bx+si],al
     5a1:	07                   	pop    es
     5a2:	4c                   	dec    sp
     5a3:	61                   	popa
     5a4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5a7:	32 32                	xor    dh,BYTE PTR [bp+si]
     5a9:	08 03                	or     BYTE PTR [bp+di],al
     5ab:	10 00                	adc    BYTE PTR [bx+si],al
     5ad:	07                   	pop    es
     5ae:	4c                   	dec    sp
     5af:	61                   	popa
     5b0:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5b3:	32 31                	xor    dh,BYTE PTR [bx+di]
     5b5:	0c 03                	or     al,0x3
     5b7:	10 00                	adc    BYTE PTR [bx+si],al
     5b9:	07                   	pop    es
     5ba:	4c                   	dec    sp
     5bb:	61                   	popa
     5bc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5bf:	32 34                	xor    dh,BYTE PTR [si]
     5c1:	10 03                	adc    BYTE PTR [bp+di],al
     5c3:	14 00                	adc    al,0x0
     5c5:	08 44 42             	or     BYTE PTR [si+0x42],al
     5c8:	45                   	inc    bp
     5c9:	64 69 74 32 31 14    	imul   si,WORD PTR fs:[si+0x32],0x1431
     5cf:	03 14                	add    dx,WORD PTR [si]
     5d1:	00 08                	add    BYTE PTR [bx+si],cl
     5d3:	44                   	inc    sp
     5d4:	42                   	inc    dx
     5d5:	45                   	inc    bp
     5d6:	64 69 74 32 32 18    	imul   si,WORD PTR fs:[si+0x32],0x1832
     5dc:	03 14                	add    dx,WORD PTR [si]
     5de:	00 08                	add    BYTE PTR [bx+si],cl
     5e0:	44                   	inc    sp
     5e1:	42                   	inc    dx
     5e2:	45                   	inc    bp
     5e3:	64 69 74 32 33 1c    	imul   si,WORD PTR fs:[si+0x32],0x1c33
     5e9:	03 14                	add    dx,WORD PTR [si]
     5eb:	00 08                	add    BYTE PTR [bx+si],cl
     5ed:	44                   	inc    sp
     5ee:	42                   	inc    dx
     5ef:	45                   	inc    bp
     5f0:	64 69 74 34 31 20    	imul   si,WORD PTR fs:[si+0x34],0x2031
     5f6:	03 14                	add    dx,WORD PTR [si]
     5f8:	00 08                	add    BYTE PTR [bx+si],cl
     5fa:	44                   	inc    sp
     5fb:	42                   	inc    dx
     5fc:	45                   	inc    bp
     5fd:	64 69 74 32 34 24    	imul   si,WORD PTR fs:[si+0x32],0x2434
     603:	03 00                	add    ax,WORD PTR [bx+si]
     605:	00 07                	add    BYTE PTR [bx],al
     607:	50                   	push   ax
     608:	61                   	popa
     609:	6e                   	outs   dx,BYTE PTR ds:[si]
     60a:	65 6c                	gs ins BYTE PTR es:[di],dx
     60c:	31 37                	xor    WORD PTR [bx],si
     60e:	28 03                	sub    BYTE PTR [bp+di],al
     610:	10 00                	adc    BYTE PTR [bx+si],al
     612:	07                   	pop    es
     613:	4c                   	dec    sp
     614:	61                   	popa
     615:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     618:	32 37                	xor    dh,BYTE PTR [bx]
     61a:	2c 03                	sub    al,0x3
     61c:	14 00                	adc    al,0x0
     61e:	08 44 42             	or     BYTE PTR [si+0x42],al
     621:	45                   	inc    bp
     622:	64 69 74 32 36 30    	imul   si,WORD PTR fs:[si+0x32],0x3036
     628:	03 14                	add    dx,WORD PTR [si]
     62a:	00 08                	add    BYTE PTR [bx+si],cl
     62c:	44                   	inc    sp
     62d:	42                   	inc    dx
     62e:	45                   	inc    bp
     62f:	64 69 74 32 37 34    	imul   si,WORD PTR fs:[si+0x32],0x3437
     635:	03 14                	add    dx,WORD PTR [si]
     637:	00 08                	add    BYTE PTR [bx+si],cl
     639:	44                   	inc    sp
     63a:	42                   	inc    dx
     63b:	45                   	inc    bp
     63c:	64 69 74 32 38 38    	imul   si,WORD PTR fs:[si+0x32],0x3838
     642:	03 14                	add    dx,WORD PTR [si]
     644:	00 08                	add    BYTE PTR [bx+si],cl
     646:	44                   	inc    sp
     647:	42                   	inc    dx
     648:	45                   	inc    bp
     649:	64 69 74 34 32 3c    	imul   si,WORD PTR fs:[si+0x34],0x3c32
     64f:	03 14                	add    dx,WORD PTR [si]
     651:	00 08                	add    BYTE PTR [bx+si],cl
     653:	44                   	inc    sp
     654:	42                   	inc    dx
     655:	45                   	inc    bp
     656:	64 69 74 32 39 40    	imul   si,WORD PTR fs:[si+0x32],0x4039
     65c:	03 0c                	add    cx,WORD PTR [si]
     65e:	00 0a                	add    BYTE PTR [bp+si],cl
     660:	47                   	inc    di
     661:	72 6f                	jb     0x6d2
     663:	75 70                	jne    0x6d5
     665:	42                   	inc    dx
     666:	6f                   	outs   dx,WORD PTR ds:[si]
     667:	78 31                	js     0x69a
     669:	35 44 03             	xor    ax,0x344
     66c:	10 00                	adc    BYTE PTR [bx+si],al
     66e:	07                   	pop    es
     66f:	4c                   	dec    sp
     670:	61                   	popa
     671:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     674:	34 30                	xor    al,0x30
     676:	48                   	dec    ax
     677:	03 18                	add    bx,WORD PTR [bx+si]
     679:	00 0b                	add    BYTE PTR [bp+di],cl
     67b:	44                   	inc    sp
     67c:	42                   	inc    dx
     67d:	43                   	inc    bx
     67e:	68 65 63             	push   0x6365
     681:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     685:	31 4c 03             	xor    WORD PTR [si+0x3],cx
     688:	14 00                	adc    al,0x0
     68a:	08 44 42             	or     BYTE PTR [si+0x42],al
     68d:	45                   	inc    bp
     68e:	64 69 74 34 33 50    	imul   si,WORD PTR fs:[si+0x34],0x5033
     694:	03 0c                	add    cx,WORD PTR [si]
     696:	00 0a                	add    BYTE PTR [bp+si],cl
     698:	47                   	inc    di
     699:	72 6f                	jb     0x70a
     69b:	75 70                	jne    0x70d
     69d:	42                   	inc    dx
     69e:	6f                   	outs   dx,WORD PTR ds:[si]
     69f:	78 31                	js     0x6d2
     6a1:	37                   	aaa
     6a2:	54                   	push   sp
     6a3:	03 10                	add    dx,WORD PTR [bx+si]
     6a5:	00 07                	add    BYTE PTR [bx],al
     6a7:	4c                   	dec    sp
     6a8:	61                   	popa
     6a9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6ac:	32 35                	xor    dh,BYTE PTR [di]
     6ae:	58                   	pop    ax
     6af:	03 10                	add    dx,WORD PTR [bx+si]
     6b1:	00 07                	add    BYTE PTR [bx],al
     6b3:	4c                   	dec    sp
     6b4:	61                   	popa
     6b5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6b8:	32 38                	xor    bh,BYTE PTR [bx+si]
     6ba:	5c                   	pop    sp
     6bb:	03 14                	add    dx,WORD PTR [si]
     6bd:	00 08                	add    BYTE PTR [bx+si],cl
     6bf:	44                   	inc    sp
     6c0:	42                   	inc    dx
     6c1:	45                   	inc    bp
     6c2:	64 69 74 32 35 60    	imul   si,WORD PTR fs:[si+0x32],0x6035
     6c8:	03 14                	add    dx,WORD PTR [si]
     6ca:	00 08                	add    BYTE PTR [bx+si],cl
     6cc:	44                   	inc    sp
     6cd:	42                   	inc    dx
     6ce:	45                   	inc    bp
     6cf:	64 69 74 33 30 64    	imul   si,WORD PTR fs:[si+0x33],0x6430
     6d5:	03 0c                	add    cx,WORD PTR [si]
     6d7:	00 0a                	add    BYTE PTR [bp+si],cl
     6d9:	47                   	inc    di
     6da:	72 6f                	jb     0x74b
     6dc:	75 70                	jne    0x74e
     6de:	42                   	inc    dx
     6df:	6f                   	outs   dx,WORD PTR ds:[si]
     6e0:	78 31                	js     0x713
     6e2:	36 68 03 10          	ss push 0x1003
     6e6:	00 07                	add    BYTE PTR [bx],al
     6e8:	4c                   	dec    sp
     6e9:	61                   	popa
     6ea:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6ed:	34 31                	xor    al,0x31
     6ef:	6c                   	ins    BYTE PTR es:[di],dx
     6f0:	03 14                	add    dx,WORD PTR [si]
     6f2:	00 08                	add    BYTE PTR [bx+si],cl
     6f4:	44                   	inc    sp
     6f5:	42                   	inc    dx
     6f6:	45                   	inc    bp
     6f7:	64 69 74 34 34 70    	imul   si,WORD PTR fs:[si+0x34],0x7034
     6fd:	03 00                	add    ax,WORD PTR [bx+si]
     6ff:	00 07                	add    BYTE PTR [bx],al
     701:	50                   	push   ax
     702:	61                   	popa
     703:	6e                   	outs   dx,BYTE PTR ds:[si]
     704:	65 6c                	gs ins BYTE PTR es:[di],dx
     706:	31 33                	xor    WORD PTR [bp+di],si
     708:	74 03                	je     0x70d
     70a:	0c 00                	or     al,0x0
     70c:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     70f:	6f                   	outs   dx,WORD PTR ds:[si]
     710:	75 70                	jne    0x782
     712:	42                   	inc    dx
     713:	6f                   	outs   dx,WORD PTR ds:[si]
     714:	78 31                	js     0x747
     716:	34 78                	xor    al,0x78
     718:	03 0c                	add    cx,WORD PTR [si]
     71a:	00 0a                	add    BYTE PTR [bp+si],cl
     71c:	47                   	inc    di
     71d:	72 6f                	jb     0x78e
     71f:	75 70                	jne    0x791
     721:	42                   	inc    dx
     722:	6f                   	outs   dx,WORD PTR ds:[si]
     723:	78 31                	js     0x756
     725:	38 7c 03             	cmp    BYTE PTR [si+0x3],bh
     728:	00 00                	add    BYTE PTR [bx+si],al
     72a:	07                   	pop    es
     72b:	50                   	push   ax
     72c:	61                   	popa
     72d:	6e                   	outs   dx,BYTE PTR ds:[si]
     72e:	65 6c                	gs ins BYTE PTR es:[di],dx
     730:	31 34                	xor    WORD PTR [si],si
     732:	80 03 10             	add    BYTE PTR [bp+di],0x10
     735:	00 07                	add    BYTE PTR [bx],al
     737:	4c                   	dec    sp
     738:	61                   	popa
     739:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     73c:	34 32                	xor    al,0x32
     73e:	84 03                	test   BYTE PTR [bp+di],al
     740:	10 00                	adc    BYTE PTR [bx+si],al
     742:	07                   	pop    es
     743:	4c                   	dec    sp
     744:	61                   	popa
     745:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     748:	34 35                	xor    al,0x35
     74a:	88 03                	mov    BYTE PTR [bp+di],al
     74c:	10 00                	adc    BYTE PTR [bx+si],al
     74e:	07                   	pop    es
     74f:	4c                   	dec    sp
     750:	61                   	popa
     751:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     754:	34 34                	xor    al,0x34
     756:	8c 03                	mov    WORD PTR [bp+di],es
     758:	14 00                	adc    al,0x0
     75a:	08 44 42             	or     BYTE PTR [si+0x42],al
     75d:	45                   	inc    bp
     75e:	64 69 74 34 35 90    	imul   si,WORD PTR fs:[si+0x34],0x9035
     764:	03 14                	add    dx,WORD PTR [si]
     766:	00 08                	add    BYTE PTR [bx+si],cl
     768:	44                   	inc    sp
     769:	42                   	inc    dx
     76a:	45                   	inc    bp
     76b:	64 69 74 34 37 94    	imul   si,WORD PTR fs:[si+0x34],0x9437
     771:	03 00                	add    ax,WORD PTR [bx+si]
     773:	00 07                	add    BYTE PTR [bx],al
     775:	50                   	push   ax
     776:	61                   	popa
     777:	6e                   	outs   dx,BYTE PTR ds:[si]
     778:	65 6c                	gs ins BYTE PTR es:[di],dx
     77a:	31 38                	xor    WORD PTR [bx+si],di
     77c:	98                   	cbw
     77d:	03 10                	add    dx,WORD PTR [bx+si]
     77f:	00 07                	add    BYTE PTR [bx],al
     781:	4c                   	dec    sp
     782:	61                   	popa
     783:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     786:	34 33                	xor    al,0x33
     788:	9c                   	pushf
     789:	03 14                	add    dx,WORD PTR [si]
     78b:	00 08                	add    BYTE PTR [bx+si],cl
     78d:	44                   	inc    sp
     78e:	42                   	inc    dx
     78f:	45                   	inc    bp
     790:	64 69 74 34 36 a0    	imul   si,WORD PTR fs:[si+0x34],0xa036
     796:	03 14                	add    dx,WORD PTR [si]
     798:	00 08                	add    BYTE PTR [bx+si],cl
     79a:	44                   	inc    sp
     79b:	42                   	inc    dx
     79c:	45                   	inc    bp
     79d:	64 69 74 34 38 a4    	imul   si,WORD PTR fs:[si+0x34],0xa438
     7a3:	03 00                	add    ax,WORD PTR [bx+si]
     7a5:	00 07                	add    BYTE PTR [bx],al
     7a7:	50                   	push   ax
     7a8:	61                   	popa
     7a9:	6e                   	outs   dx,BYTE PTR ds:[si]
     7aa:	65 6c                	gs ins BYTE PTR es:[di],dx
     7ac:	34 34                	xor    al,0x34
     7ae:	a8 03                	test   al,0x3
     7b0:	10 00                	adc    BYTE PTR [bx+si],al
     7b2:	07                   	pop    es
     7b3:	4c                   	dec    sp
     7b4:	61                   	popa
     7b5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7b8:	55                   	push   bp
     7b9:	30 ac 03 10          	xor    BYTE PTR [si+0x1003],ch
     7bd:	00 07                	add    BYTE PTR [bx],al
     7bf:	4c                   	dec    sp
     7c0:	61                   	popa
     7c1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7c4:	55                   	push   bp
     7c5:	31 b0 03 10          	xor    WORD PTR [bx+si+0x1003],si
     7c9:	00 07                	add    BYTE PTR [bx],al
     7cb:	4c                   	dec    sp
     7cc:	61                   	popa
     7cd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7d0:	55                   	push   bp
     7d1:	32 b4 03 10          	xor    dh,BYTE PTR [si+0x1003]
     7d5:	00 07                	add    BYTE PTR [bx],al
     7d7:	4c                   	dec    sp
     7d8:	61                   	popa
     7d9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7dc:	55                   	push   bp
     7dd:	33 b8 03 10          	xor    di,WORD PTR [bx+si+0x1003]
     7e1:	00 07                	add    BYTE PTR [bx],al
     7e3:	4c                   	dec    sp
     7e4:	61                   	popa
     7e5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7e8:	34 38                	xor    al,0x38
     7ea:	bc 03 14             	mov    sp,0x1403
     7ed:	00 08                	add    BYTE PTR [bx+si],cl
     7ef:	44                   	inc    sp
     7f0:	42                   	inc    dx
     7f1:	45                   	inc    bp
     7f2:	64 69 74 34 39 c0    	imul   si,WORD PTR fs:[si+0x34],0xc039
     7f8:	03 0c                	add    cx,WORD PTR [si]
     7fa:	00 0a                	add    BYTE PTR [bp+si],cl
     7fc:	47                   	inc    di
     7fd:	72 6f                	jb     0x86e
     7ff:	75 70                	jne    0x871
     801:	42                   	inc    dx
     802:	6f                   	outs   dx,WORD PTR ds:[si]
     803:	78 31                	js     0x836
     805:	39 c4                	cmp    sp,ax
     807:	03 10                	add    dx,WORD PTR [bx+si]
     809:	00 07                	add    BYTE PTR [bx],al
     80b:	4c                   	dec    sp
     80c:	61                   	popa
     80d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     810:	34 39                	xor    al,0x39
     812:	c8 03 10 00          	enter  0x1003,0x0
     816:	07                   	pop    es
     817:	4c                   	dec    sp
     818:	61                   	popa
     819:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     81c:	35 30 cc             	xor    ax,0xcc30
     81f:	03 14                	add    dx,WORD PTR [si]
     821:	00 08                	add    BYTE PTR [bx+si],cl
     823:	44                   	inc    sp
     824:	42                   	inc    dx
     825:	45                   	inc    bp
     826:	64 69 74 35 30 d0    	imul   si,WORD PTR fs:[si+0x35],0xd030
     82c:	03 14                	add    dx,WORD PTR [si]
     82e:	00 08                	add    BYTE PTR [bx+si],cl
     830:	44                   	inc    sp
     831:	42                   	inc    dx
     832:	45                   	inc    bp
     833:	64 69 74 35 31 d4    	imul   si,WORD PTR fs:[si+0x35],0xd431
     839:	03 00                	add    ax,WORD PTR [bx+si]
     83b:	00 07                	add    BYTE PTR [bx],al
     83d:	50                   	push   ax
     83e:	61                   	popa
     83f:	6e                   	outs   dx,BYTE PTR ds:[si]
     840:	65 6c                	gs ins BYTE PTR es:[di],dx
     842:	32 38                	xor    bh,BYTE PTR [bx+si]
     844:	d8 03                	fadd   DWORD PTR [bp+di]
     846:	0c 00                	or     al,0x0
     848:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     84b:	6f                   	outs   dx,WORD PTR ds:[si]
     84c:	75 70                	jne    0x8be
     84e:	42                   	inc    dx
     84f:	6f                   	outs   dx,WORD PTR ds:[si]
     850:	78 32                	js     0x884
     852:	30 dc                	xor    ah,bl
     854:	03 0c                	add    cx,WORD PTR [si]
     856:	00 0a                	add    BYTE PTR [bp+si],cl
     858:	47                   	inc    di
     859:	72 6f                	jb     0x8ca
     85b:	75 70                	jne    0x8cd
     85d:	42                   	inc    dx
     85e:	6f                   	outs   dx,WORD PTR ds:[si]
     85f:	78 32                	js     0x893
     861:	31 e0                	xor    ax,sp
     863:	03 00                	add    ax,WORD PTR [bx+si]
     865:	00 07                	add    BYTE PTR [bx],al
     867:	50                   	push   ax
     868:	61                   	popa
     869:	6e                   	outs   dx,BYTE PTR ds:[si]
     86a:	65 6c                	gs ins BYTE PTR es:[di],dx
     86c:	32 30                	xor    dh,BYTE PTR [bx+si]
     86e:	e4 03                	in     al,0x3
     870:	14 00                	adc    al,0x0
     872:	08 44 42             	or     BYTE PTR [si+0x42],al
     875:	45                   	inc    bp
     876:	64 69 74 35 32 e8    	imul   si,WORD PTR fs:[si+0x35],0xe832
     87c:	03 00                	add    ax,WORD PTR [bx+si]
     87e:	00 07                	add    BYTE PTR [bx],al
     880:	50                   	push   ax
     881:	61                   	popa
     882:	6e                   	outs   dx,BYTE PTR ds:[si]
     883:	65 6c                	gs ins BYTE PTR es:[di],dx
     885:	32 31                	xor    dh,BYTE PTR [bx+di]
     887:	ec                   	in     al,dx
     888:	03 14                	add    dx,WORD PTR [si]
     88a:	00 08                	add    BYTE PTR [bx+si],cl
     88c:	44                   	inc    sp
     88d:	42                   	inc    dx
     88e:	45                   	inc    bp
     88f:	64 69 74 35 33 f0    	imul   si,WORD PTR fs:[si+0x35],0xf033
     895:	03 00                	add    ax,WORD PTR [bx+si]
     897:	00 07                	add    BYTE PTR [bx],al
     899:	50                   	push   ax
     89a:	61                   	popa
     89b:	6e                   	outs   dx,BYTE PTR ds:[si]
     89c:	65 6c                	gs ins BYTE PTR es:[di],dx
     89e:	32 32                	xor    dh,BYTE PTR [bp+si]
     8a0:	f4                   	hlt
     8a1:	03 14                	add    dx,WORD PTR [si]
     8a3:	00 08                	add    BYTE PTR [bx+si],cl
     8a5:	44                   	inc    sp
     8a6:	42                   	inc    dx
     8a7:	45                   	inc    bp
     8a8:	64 69 74 35 34 f8    	imul   si,WORD PTR fs:[si+0x35],0xf834
     8ae:	03 00                	add    ax,WORD PTR [bx+si]
     8b0:	00 07                	add    BYTE PTR [bx],al
     8b2:	50                   	push   ax
     8b3:	61                   	popa
     8b4:	6e                   	outs   dx,BYTE PTR ds:[si]
     8b5:	65 6c                	gs ins BYTE PTR es:[di],dx
     8b7:	32 33                	xor    dh,BYTE PTR [bp+di]
     8b9:	fc                   	cld
     8ba:	03 14                	add    dx,WORD PTR [si]
     8bc:	00 08                	add    BYTE PTR [bx+si],cl
     8be:	44                   	inc    sp
     8bf:	42                   	inc    dx
     8c0:	45                   	inc    bp
     8c1:	64 69 74 35 35 00    	imul   si,WORD PTR fs:[si+0x35],0x35
     8c7:	04 00                	add    al,0x0
     8c9:	00 07                	add    BYTE PTR [bx],al
     8cb:	50                   	push   ax
     8cc:	61                   	popa
     8cd:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ce:	65 6c                	gs ins BYTE PTR es:[di],dx
     8d0:	32 34                	xor    dh,BYTE PTR [si]
     8d2:	04 04                	add    al,0x4
     8d4:	14 00                	adc    al,0x0
     8d6:	08 44 42             	or     BYTE PTR [si+0x42],al
     8d9:	45                   	inc    bp
     8da:	64 69 74 35 36 08    	imul   si,WORD PTR fs:[si+0x35],0x836
     8e0:	04 00                	add    al,0x0
     8e2:	00 07                	add    BYTE PTR [bx],al
     8e4:	50                   	push   ax
     8e5:	61                   	popa
     8e6:	6e                   	outs   dx,BYTE PTR ds:[si]
     8e7:	65 6c                	gs ins BYTE PTR es:[di],dx
     8e9:	32 35                	xor    dh,BYTE PTR [di]
     8eb:	0c 04                	or     al,0x4
     8ed:	14 00                	adc    al,0x0
     8ef:	08 44 42             	or     BYTE PTR [si+0x42],al
     8f2:	45                   	inc    bp
     8f3:	64 69 74 35 37 10    	imul   si,WORD PTR fs:[si+0x35],0x1037
     8f9:	04 00                	add    al,0x0
     8fb:	00 07                	add    BYTE PTR [bx],al
     8fd:	50                   	push   ax
     8fe:	61                   	popa
     8ff:	6e                   	outs   dx,BYTE PTR ds:[si]
     900:	65 6c                	gs ins BYTE PTR es:[di],dx
     902:	32 36 14 04          	xor    dh,BYTE PTR ds:0x414
     906:	14 00                	adc    al,0x0
     908:	08 44 42             	or     BYTE PTR [si+0x42],al
     90b:	45                   	inc    bp
     90c:	64 69 74 35 38 18    	imul   si,WORD PTR fs:[si+0x35],0x1838
     912:	04 00                	add    al,0x0
     914:	00 07                	add    BYTE PTR [bx],al
     916:	50                   	push   ax
     917:	61                   	popa
     918:	6e                   	outs   dx,BYTE PTR ds:[si]
     919:	65 6c                	gs ins BYTE PTR es:[di],dx
     91b:	32 37                	xor    dh,BYTE PTR [bx]
     91d:	1c 04                	sbb    al,0x4
     91f:	14 00                	adc    al,0x0
     921:	08 44 42             	or     BYTE PTR [si+0x42],al
     924:	45                   	inc    bp
     925:	64 69 74 35 39 20    	imul   si,WORD PTR fs:[si+0x35],0x2039
     92b:	04 0c                	add    al,0xc
     92d:	00 0a                	add    BYTE PTR [bp+si],cl
     92f:	47                   	inc    di
     930:	72 6f                	jb     0x9a1
     932:	75 70                	jne    0x9a4
     934:	42                   	inc    dx
     935:	6f                   	outs   dx,WORD PTR ds:[si]
     936:	78 32                	js     0x96a
     938:	32 24                	xor    ah,BYTE PTR [si]
     93a:	04 00                	add    al,0x0
     93c:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     940:	6e                   	outs   dx,BYTE PTR ds:[si]
     941:	65 6c                	gs ins BYTE PTR es:[di],dx
     943:	31 28                	xor    WORD PTR [bx+si],bp
     945:	04 14                	add    al,0x14
     947:	00 08                	add    BYTE PTR [bx+si],cl
     949:	44                   	inc    sp
     94a:	42                   	inc    dx
     94b:	45                   	inc    bp
     94c:	64 69 74 36 30 2c    	imul   si,WORD PTR fs:[si+0x36],0x2c30
     952:	04 00                	add    al,0x0
     954:	00 07                	add    BYTE PTR [bx],al
     956:	50                   	push   ax
     957:	61                   	popa
     958:	6e                   	outs   dx,BYTE PTR ds:[si]
     959:	65 6c                	gs ins BYTE PTR es:[di],dx
     95b:	31 39                	xor    WORD PTR [bx+di],di
     95d:	30 04                	xor    BYTE PTR [si],al
     95f:	14 00                	adc    al,0x0
     961:	08 44 42             	or     BYTE PTR [si+0x42],al
     964:	45                   	inc    bp
     965:	64 69 74 36 31 34    	imul   si,WORD PTR fs:[si+0x36],0x3431
     96b:	04 1c                	add    al,0x1c
     96d:	00 05                	add    BYTE PTR [di],al
     96f:	4d                   	dec    bp
     970:	65 6d                	gs ins WORD PTR es:[di],dx
     972:	6f                   	outs   dx,WORD PTR ds:[si]
     973:	31 08                	xor    WORD PTR [bx+si],cx
     975:	00 ad 0d 65          	add    BYTE PTR [di+0x650d],ch
     979:	1b 38                	sbb    di,WORD PTR [bx+si]
     97b:	01 25                	add    WORD PTR [di],sp
     97d:	0d c8 08             	or     ax,0x8c8
     980:	d0 0d                	ror    BYTE PTR [di],1
     982:	0c 01                	or     al,0x1
     984:	88 09                	mov    BYTE PTR [bx+di],cl
     986:	17                   	pop    ss
     987:	06                   	push   es
     988:	94                   	xchg   sp,ax
     989:	09 22                	or     WORD PTR [bp+si],sp
     98b:	00 90 09 26          	add    BYTE PTR [bx+si+0x2609],dl
     98f:	06                   	push   es
     990:	b6 0d                	mov    dh,0xd
     992:	91                   	xchg   cx,ax
     993:	12 4b 1a             	adc    cl,BYTE PTR [bp+di+0x1a]
     996:	07                   	pop    es
     997:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
     99b:	72 6d                	jb     0xa0a
     99d:	53                   	push   bx
     99e:	41                   	inc    cx
     99f:	44                   	inc    sp
     9a0:	49                   	dec    cx
     9a1:	5f                   	pop    di
     9a2:	50                   	push   ax
     9a3:	72 69                	jb     0xa0e
     9a5:	6e                   	outs   dx,BYTE PTR ds:[si]
     9a6:	74 22                	je     0x9ca
     9a8:	00 65 0d             	add    BYTE PTR [di+0xd],ah
     9ab:	7b 06                	jnp    0x9b3
     9ad:	d8 09                	fmul   DWORD PTR [bx+di]
     9af:	38 00                	cmp    BYTE PTR [bx+si],al
     9b1:	04 53                	add    al,0x53
     9b3:	61                   	popa
     9b4:	64 69 00 00 55       	imul   ax,WORD PTR fs:[bx+si],0x5500
     9b9:	89 e5                	mov    bp,sp
     9bb:	31 c0                	xor    ax,ax
     9bd:	9a 44 04 fc 09       	call   0x9fc:0x444
     9c2:	6a 00                	push   0x0
     9c4:	9a c2 38 c3 14       	call   0x14c3:0x38c2
     9c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9cc:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     9d3:	06                   	push   es
     9d4:	57                   	push   di
     9d5:	9a 56 55 6f 0a       	call   0xa6f:0x5556
     9da:	9a c3 28 b9 0c       	call   0xcb9:0x28c3
     9df:	c9                   	leave
     9e0:	ca 04 00             	retf   0x4
     9e3:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     9e6:	6d                   	ins    WORD PTR es:[di],dx
     9e7:	73 74                	jae    0xa5d
     9e9:	72 61                	jb     0xa4c
     9eb:	74 20                	je     0xa0d
     9ed:	2d 20 03             	sub    ax,0x320
     9f0:	20 2d                	and    BYTE PTR [di],ch
     9f2:	20 55 89             	and    BYTE PTR [di-0x77],dl
     9f5:	e5 b8                	in     ax,0xb8
     9f7:	02 03                	add    al,BYTE PTR [bp+di]
     9f9:	9a 44 04 10 0a       	call   0xa10:0x444
     9fe:	81 ec 02 03          	sub    sp,0x302
     a02:	8d be fe fe          	lea    di,[bp-0x102]
     a06:	16                   	push   ss
     a07:	57                   	push   di
     a08:	bf e3 09             	mov    di,0x9e3
     a0b:	0e                   	push   cs
     a0c:	57                   	push   di
     a0d:	9a cd 17 1a 0a       	call   0xa1a:0x17cd
     a12:	bf fa 1d             	mov    di,0x1dfa
     a15:	1e                   	push   ds
     a16:	57                   	push   di
     a17:	9a 4c 18 24 0a       	call   0xa24:0x184c
     a1c:	bf ef 09             	mov    di,0x9ef
     a1f:	0e                   	push   cs
     a20:	57                   	push   di
     a21:	9a 4c 18 39 0a       	call   0xa39:0x184c
     a26:	8d be fe fd          	lea    di,[bp-0x202]
     a2a:	16                   	push   ss
     a2b:	57                   	push   di
     a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a2f:	06                   	push   es
     a30:	57                   	push   di
     a31:	9a 53 1d 5e 0a       	call   0xa5e:0x1d53
     a36:	9a 4c 18 4a 0a       	call   0xa4a:0x184c
     a3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a3e:	81 c7 3a 04          	add    di,0x43a
     a42:	06                   	push   es
     a43:	57                   	push   di
     a44:	68 ff 00             	push   0xff
     a47:	9a e7 17 9b 0a       	call   0xa9b:0x17e7
     a4c:	bf fa 1d             	mov    di,0x1dfa
     a4f:	1e                   	push   ds
     a50:	57                   	push   di
     a51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a54:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     a59:	06                   	push   es
     a5a:	57                   	push   di
     a5b:	9a 8c 1d c5 0a       	call   0xac5:0x1d8c
     a60:	6a 00                	push   0x0
     a62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a65:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     a6a:	06                   	push   es
     a6b:	57                   	push   di
     a6c:	9a d0 1c 80 0a       	call   0xa80:0x1cd0
     a71:	6a 00                	push   0x0
     a73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a76:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     a7b:	06                   	push   es
     a7c:	57                   	push   di
     a7d:	9a d0 1c 44 0e       	call   0xe44:0x1cd0
     a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a85:	26 c7 85 38 04 01 00 	mov    WORD PTR es:[di+0x438],0x1
     a8c:	06                   	push   es
     a8d:	57                   	push   di
     a8e:	9a 7d 52 bd 0a       	call   0xabd:0x527d
     a93:	2d 01 00             	sub    ax,0x1
     a96:	71 05                	jno    0xa9d
     a98:	9a 3e 04 cc 0a       	call   0xacc:0x43e
     a9d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     aa0:	31 c0                	xor    ax,ax
     aa2:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     aa5:	7e 03                	jle    0xaaa
     aa7:	e9 a7 00             	jmp    0xb51
     aaa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     aad:	eb 03                	jmp    0xab2
     aaf:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     ab2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ab8:	06                   	push   es
     ab9:	57                   	push   di
     aba:	9a 46 52 dd 0a       	call   0xadd:0x5246
     abf:	52                   	push   dx
     ac0:	50                   	push   ax
     ac1:	bf 99 03             	mov    di,0x399
     ac4:	b8 e5 0a             	mov    ax,0xae5
     ac7:	50                   	push   ax
     ac8:	57                   	push   di
     ac9:	9a 55 22 ec 0a       	call   0xaec:0x2255
     ace:	08 c0                	or     al,al
     ad0:	74 74                	je     0xb46
     ad2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ad8:	06                   	push   es
     ad9:	57                   	push   di
     ada:	9a 46 52 78 0f       	call   0xf78:0x5246
     adf:	52                   	push   dx
     ae0:	50                   	push   ax
     ae1:	bf 99 03             	mov    di,0x399
     ae4:	b8 44 0b             	mov    ax,0xb44
     ae7:	50                   	push   ax
     ae8:	57                   	push   di
     ae9:	9a 73 22 29 0b       	call   0xb29:0x2273
     aee:	89 c7                	mov    di,ax
     af0:	8e c2                	mov    es,dx
     af2:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     af5:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     af8:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
     afd:	74 47                	je     0xb46
     aff:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     b03:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
     b07:	74 3d                	je     0xb46
     b09:	a1 06 1e             	mov    ax,ds:0x1e06
     b0c:	99                   	cwd
     b0d:	8b c8                	mov    cx,ax
     b0f:	8b da                	mov    bx,dx
     b11:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     b15:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     b19:	09 d2                	or     dx,dx
     b1b:	79 07                	jns    0xb24
     b1d:	f7 d2                	not    dx
     b1f:	f7 d8                	neg    ax
     b21:	83 da ff             	sbb    dx,0xffff
     b24:	71 05                	jno    0xb2b
     b26:	9a 3e 04 ae 0c       	call   0xcae:0x43e
     b2b:	3b d3                	cmp    dx,bx
     b2d:	7c 0a                	jl     0xb39
     b2f:	7f 04                	jg     0xb35
     b31:	3b c1                	cmp    ax,cx
     b33:	76 04                	jbe    0xb39
     b35:	b0 00                	mov    al,0x0
     b37:	eb 02                	jmp    0xb3b
     b39:	b0 01                	mov    al,0x1
     b3b:	50                   	push   ax
     b3c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     b3f:	06                   	push   es
     b40:	57                   	push   di
     b41:	9a 77 1c 69 0b       	call   0xb69:0x1c77
     b46:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b49:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     b4c:	74 03                	je     0xb51
     b4e:	e9 5e ff             	jmp    0xaaf
     b51:	83 3e 4e 01 00       	cmp    WORD PTR ds:0x14e,0x0
     b56:	b0 00                	mov    al,0x0
     b58:	7e 01                	jle    0xb5b
     b5a:	40                   	inc    ax
     b5b:	50                   	push   ax
     b5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b5f:	26 c4 bd e0 03       	les    di,DWORD PTR es:[di+0x3e0]
     b64:	06                   	push   es
     b65:	57                   	push   di
     b66:	9a 77 1c 83 0b       	call   0xb83:0x1c77
     b6b:	83 3e 4e 01 01       	cmp    WORD PTR ds:0x14e,0x1
     b70:	b0 00                	mov    al,0x0
     b72:	7e 01                	jle    0xb75
     b74:	40                   	inc    ax
     b75:	50                   	push   ax
     b76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b79:	26 c4 bd e8 03       	les    di,DWORD PTR es:[di+0x3e8]
     b7e:	06                   	push   es
     b7f:	57                   	push   di
     b80:	9a 77 1c 9d 0b       	call   0xb9d:0x1c77
     b85:	83 3e 4e 01 02       	cmp    WORD PTR ds:0x14e,0x2
     b8a:	b0 00                	mov    al,0x0
     b8c:	7e 01                	jle    0xb8f
     b8e:	40                   	inc    ax
     b8f:	50                   	push   ax
     b90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b93:	26 c4 bd f0 03       	les    di,DWORD PTR es:[di+0x3f0]
     b98:	06                   	push   es
     b99:	57                   	push   di
     b9a:	9a 77 1c b7 0b       	call   0xbb7:0x1c77
     b9f:	83 3e 4e 01 03       	cmp    WORD PTR ds:0x14e,0x3
     ba4:	b0 00                	mov    al,0x0
     ba6:	7e 01                	jle    0xba9
     ba8:	40                   	inc    ax
     ba9:	50                   	push   ax
     baa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bad:	26 c4 bd f8 03       	les    di,DWORD PTR es:[di+0x3f8]
     bb2:	06                   	push   es
     bb3:	57                   	push   di
     bb4:	9a 77 1c d1 0b       	call   0xbd1:0x1c77
     bb9:	83 3e 4e 01 04       	cmp    WORD PTR ds:0x14e,0x4
     bbe:	b0 00                	mov    al,0x0
     bc0:	7e 01                	jle    0xbc3
     bc2:	40                   	inc    ax
     bc3:	50                   	push   ax
     bc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bc7:	26 c4 bd 00 04       	les    di,DWORD PTR es:[di+0x400]
     bcc:	06                   	push   es
     bcd:	57                   	push   di
     bce:	9a 77 1c eb 0b       	call   0xbeb:0x1c77
     bd3:	83 3e 4e 01 05       	cmp    WORD PTR ds:0x14e,0x5
     bd8:	b0 00                	mov    al,0x0
     bda:	7e 01                	jle    0xbdd
     bdc:	40                   	inc    ax
     bdd:	50                   	push   ax
     bde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     be1:	26 c4 bd 08 04       	les    di,DWORD PTR es:[di+0x408]
     be6:	06                   	push   es
     be7:	57                   	push   di
     be8:	9a 77 1c 05 0c       	call   0xc05:0x1c77
     bed:	83 3e 4e 01 06       	cmp    WORD PTR ds:0x14e,0x6
     bf2:	b0 00                	mov    al,0x0
     bf4:	7e 01                	jle    0xbf7
     bf6:	40                   	inc    ax
     bf7:	50                   	push   ax
     bf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bfb:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
     c00:	06                   	push   es
     c01:	57                   	push   di
     c02:	9a 77 1c 1f 0c       	call   0xc1f:0x1c77
     c07:	83 3e 4e 01 06       	cmp    WORD PTR ds:0x14e,0x6
     c0c:	b0 00                	mov    al,0x0
     c0e:	7e 01                	jle    0xc11
     c10:	40                   	inc    ax
     c11:	50                   	push   ax
     c12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c15:	26 c4 bd 18 04       	les    di,DWORD PTR es:[di+0x418]
     c1a:	06                   	push   es
     c1b:	57                   	push   di
     c1c:	9a 77 1c 35 0c       	call   0xc35:0x1c77
     c21:	8d be fe fe          	lea    di,[bp-0x102]
     c25:	16                   	push   ss
     c26:	57                   	push   di
     c27:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     c2b:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
     c30:	06                   	push   es
     c31:	57                   	push   di
     c32:	9a 53 1d 44 0c       	call   0xc44:0x1d53
     c37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c3a:	26 c4 bd a8 03       	les    di,DWORD PTR es:[di+0x3a8]
     c3f:	06                   	push   es
     c40:	57                   	push   di
     c41:	9a 8c 1d 5a 0c       	call   0xc5a:0x1d8c
     c46:	8d be fe fe          	lea    di,[bp-0x102]
     c4a:	16                   	push   ss
     c4b:	57                   	push   di
     c4c:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     c50:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
     c55:	06                   	push   es
     c56:	57                   	push   di
     c57:	9a 53 1d 69 0c       	call   0xc69:0x1d53
     c5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c5f:	26 c4 bd ac 03       	les    di,DWORD PTR es:[di+0x3ac]
     c64:	06                   	push   es
     c65:	57                   	push   di
     c66:	9a 8c 1d 7f 0c       	call   0xc7f:0x1d8c
     c6b:	8d be fe fe          	lea    di,[bp-0x102]
     c6f:	16                   	push   ss
     c70:	57                   	push   di
     c71:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     c75:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
     c7a:	06                   	push   es
     c7b:	57                   	push   di
     c7c:	9a 53 1d 8e 0c       	call   0xc8e:0x1d53
     c81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c84:	26 c4 bd b0 03       	les    di,DWORD PTR es:[di+0x3b0]
     c89:	06                   	push   es
     c8a:	57                   	push   di
     c8b:	9a 8c 1d a4 0c       	call   0xca4:0x1d8c
     c90:	8d be fe fe          	lea    di,[bp-0x102]
     c94:	16                   	push   ss
     c95:	57                   	push   di
     c96:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     c9a:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
     c9f:	06                   	push   es
     ca0:	57                   	push   di
     ca1:	9a 53 1d 11 0d       	call   0xd11:0x1d53
     ca6:	bf ef 09             	mov    di,0x9ef
     ca9:	0e                   	push   cs
     caa:	57                   	push   di
     cab:	9a 4c 18 ce 0c       	call   0xcce:0x184c
     cb0:	8d be fe fd          	lea    di,[bp-0x202]
     cb4:	16                   	push   ss
     cb5:	57                   	push   di
     cb6:	9a fe 15 c9 0c       	call   0xcc9:0x15fe
     cbb:	83 ec 08             	sub    sp,0x8
     cbe:	89 e3                	mov    bx,sp
     cc0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     cc4:	90                   	nop
     cc5:	9b                   	fwait
     cc6:	9a bf 1c e3 0c       	call   0xce3:0x1cbf
     ccb:	9a 4c 18 d8 0c       	call   0xcd8:0x184c
     cd0:	bf ef 09             	mov    di,0x9ef
     cd3:	0e                   	push   cs
     cd4:	57                   	push   di
     cd5:	9a 4c 18 f8 0c       	call   0xcf8:0x184c
     cda:	8d be fe fc          	lea    di,[bp-0x302]
     cde:	16                   	push   ss
     cdf:	57                   	push   di
     ce0:	9a fe 15 f3 0c       	call   0xcf3:0x15fe
     ce5:	83 ec 08             	sub    sp,0x8
     ce8:	89 e3                	mov    bx,sp
     cea:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     cee:	90                   	nop
     cef:	9b                   	fwait
     cf0:	9a e4 1c d9 11       	call   0x11d9:0x1ce4
     cf5:	9a 4c 18 02 0d       	call   0xd02:0x184c
     cfa:	bf ef 09             	mov    di,0x9ef
     cfd:	0e                   	push   cs
     cfe:	57                   	push   di
     cff:	9a 4c 18 5b 0d       	call   0xd5b:0x184c
     d04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d07:	26 c4 bd b4 03       	les    di,DWORD PTR es:[di+0x3b4]
     d0c:	06                   	push   es
     d0d:	57                   	push   di
     d0e:	9a 8c 1d 6a 11       	call   0x116a:0x1d8c
     d13:	bf 32 1e             	mov    di,0x1e32
     d16:	1e                   	push   ds
     d17:	57                   	push   di
     d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d1b:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
     d20:	06                   	push   es
     d21:	57                   	push   di
     d22:	9a 17 30 39 0d       	call   0xd39:0x3017
     d27:	bf 40 1e             	mov    di,0x1e40
     d2a:	1e                   	push   ds
     d2b:	57                   	push   di
     d2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d2f:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
     d34:	06                   	push   es
     d35:	57                   	push   di
     d36:	9a 17 30 4d 0d       	call   0xd4d:0x3017
     d3b:	bf 40 1e             	mov    di,0x1e40
     d3e:	1e                   	push   ds
     d3f:	57                   	push   di
     d40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d43:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
     d48:	06                   	push   es
     d49:	57                   	push   di
     d4a:	9a 17 30 e2 0d       	call   0xde2:0x3017
     d4f:	c9                   	leave
     d50:	ca 08 00             	retf   0x8
     d53:	55                   	push   bp
     d54:	89 e5                	mov    bp,sp
     d56:	31 c0                	xor    ax,ax
     d58:	9a 44 04 96 0d       	call   0xd96:0x444
     d5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d60:	06                   	push   es
     d61:	57                   	push   di
     d62:	9a 0a 10 dc 0f       	call   0xfdc:0x100a
     d67:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d6a:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
     d6e:	c9                   	leave
     d6f:	ca 0c 00             	retf   0xc
     d72:	07                   	pop    es
     d73:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
     d77:	2b 30                	sub    si,WORD PTR [bx+si]
     d79:	30 01                	xor    BYTE PTR [bx+di],al
     d7b:	30 0a                	xor    BYTE PTR [bp+si],cl
     d7d:	23 2c                	and    bp,WORD PTR [si]
     d7f:	23 23                	and    sp,WORD PTR [bp+di]
     d81:	30 2e 30 30          	xor    BYTE PTR ds:0x3030,ch
     d85:	23 23                	and    sp,WORD PTR [bp+di]
     d87:	05 23 2c             	add    ax,0x2c23
     d8a:	23 23                	and    sp,WORD PTR [bp+di]
     d8c:	30 55 89             	xor    BYTE PTR [di-0x77],dl
     d8f:	e5 b8                	in     ax,0xb8
     d91:	0c 02                	or     al,0x2
     d93:	9a 44 04 e9 0d       	call   0xde9:0x444
     d98:	81 ec 0c 02          	sub    sp,0x20c
     d9c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d9f:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     da3:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     da7:	8d be f8 fd          	lea    di,[bp-0x208]
     dab:	16                   	push   ss
     dac:	57                   	push   di
     dad:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     db1:	06                   	push   es
     db2:	57                   	push   di
     db3:	9a 9f 1a c1 0d       	call   0xdc1:0x1a9f
     db8:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     dbc:	06                   	push   es
     dbd:	57                   	push   di
     dbe:	9a 5f 1a a9 0f       	call   0xfa9:0x1a5f
     dc3:	89 c7                	mov    di,ax
     dc5:	8e c2                	mov    es,dx
     dc7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     dcb:	06                   	push   es
     dcc:	57                   	push   di
     dcd:	9a 9b 3b 20 0e       	call   0xe20:0x3b9b
     dd2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     dd5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     dd8:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ddb:	ff 76 fc             	push   WORD PTR [bp-0x4]
     dde:	bf 58 0a             	mov    di,0xa58
     de1:	b8 fc 0d             	mov    ax,0xdfc
     de4:	50                   	push   ax
     de5:	57                   	push   di
     de6:	9a 55 22 03 0e       	call   0xe03:0x2255
     deb:	08 c0                	or     al,al
     ded:	75 03                	jne    0xdf2
     def:	e9 26 01             	jmp    0xf18
     df2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     df5:	ff 76 fc             	push   WORD PTR [bp-0x4]
     df8:	bf 58 0a             	mov    di,0xa58
     dfb:	b8 02 0f             	mov    ax,0xf02
     dfe:	50                   	push   ax
     dff:	57                   	push   di
     e00:	9a 73 22 2e 0e       	call   0xe2e:0x2273
     e05:	89 c7                	mov    di,ax
     e07:	8e c2                	mov    es,dx
     e09:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
     e0d:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
     e11:	8d be f4 fd          	lea    di,[bp-0x20c]
     e15:	16                   	push   ss
     e16:	57                   	push   di
     e17:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     e1b:	06                   	push   es
     e1c:	57                   	push   di
     e1d:	9a cf 68 21 10       	call   0x1021:0x68cf
     e22:	8d be fc fe          	lea    di,[bp-0x104]
     e26:	16                   	push   ss
     e27:	57                   	push   di
     e28:	68 ff 00             	push   0xff
     e2b:	9a e7 17 8a 0e       	call   0xe8a:0x17e7
     e30:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e34:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
     e38:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
     e3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e3f:	06                   	push   es
     e40:	57                   	push   di
     e41:	9a d5 33 5f 0e       	call   0xe5f:0x33d5
     e46:	89 c7                	mov    di,ax
     e48:	8e c2                	mov    es,dx
     e4a:	06                   	push   es
     e4b:	57                   	push   di
     e4c:	9a 99 20 6a 0e       	call   0xe6a:0x2099
     e51:	8d be fc fe          	lea    di,[bp-0x104]
     e55:	16                   	push   ss
     e56:	57                   	push   di
     e57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e5a:	06                   	push   es
     e5b:	57                   	push   di
     e5c:	9a d5 33 9a 0e       	call   0xe9a:0x33d5
     e61:	89 c7                	mov    di,ax
     e63:	8e c2                	mov    es,dx
     e65:	06                   	push   es
     e66:	57                   	push   di
     e67:	9a 03 20 a5 0e       	call   0xea5:0x2003
     e6c:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     e70:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     e74:	7d 03                	jge    0xe79
     e76:	e9 8d 00             	jmp    0xf06
     e79:	bf 72 0d             	mov    di,0xd72
     e7c:	0e                   	push   cs
     e7d:	57                   	push   di
     e7e:	8d be fc fe          	lea    di,[bp-0x104]
     e82:	16                   	push   ss
     e83:	57                   	push   di
     e84:	68 ff 00             	push   0xff
     e87:	9a e7 17 d9 0e       	call   0xed9:0x17e7
     e8c:	8d be fc fe          	lea    di,[bp-0x104]
     e90:	16                   	push   ss
     e91:	57                   	push   di
     e92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e95:	06                   	push   es
     e96:	57                   	push   di
     e97:	9a d5 33 cd 13       	call   0x13cd:0x33d5
     e9c:	89 c7                	mov    di,ax
     e9e:	8e c2                	mov    es,dx
     ea0:	06                   	push   es
     ea1:	57                   	push   di
     ea2:	9a 03 20 bc 15       	call   0x15bc:0x2003
     ea7:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     eab:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     eaf:	b0 00                	mov    al,0x0
     eb1:	7d 01                	jge    0xeb4
     eb3:	40                   	inc    ax
     eb4:	8a d0                	mov    dl,al
     eb6:	80 be fc fe 0c       	cmp    BYTE PTR [bp-0x104],0xc
     ebb:	b0 00                	mov    al,0x0
     ebd:	73 01                	jae    0xec0
     ebf:	40                   	inc    ax
     ec0:	22 c2                	and    al,dl
     ec2:	08 c0                	or     al,al
     ec4:	74 17                	je     0xedd
     ec6:	bf 7a 0d             	mov    di,0xd7a
     ec9:	0e                   	push   cs
     eca:	57                   	push   di
     ecb:	8d be fc fe          	lea    di,[bp-0x104]
     ecf:	16                   	push   ss
     ed0:	57                   	push   di
     ed1:	68 ff 00             	push   0xff
     ed4:	6a 03                	push   0x3
     ed6:	9a 16 19 f1 0e       	call   0xef1:0x1916
     edb:	eb af                	jmp    0xe8c
     edd:	80 be fc fe 07       	cmp    BYTE PTR [bp-0x104],0x7
     ee2:	76 0f                	jbe    0xef3
     ee4:	8d be fc fe          	lea    di,[bp-0x104]
     ee8:	16                   	push   ss
     ee9:	57                   	push   di
     eea:	6a 03                	push   0x3
     eec:	6a 01                	push   0x1
     eee:	9a 75 19 29 0f       	call   0xf29:0x1975
     ef3:	8d be fc fe          	lea    di,[bp-0x104]
     ef7:	16                   	push   ss
     ef8:	57                   	push   di
     ef9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     efd:	06                   	push   es
     efe:	57                   	push   di
     eff:	9a f9 60 14 0f       	call   0xf14:0x60f9
     f04:	eb 10                	jmp    0xf16
     f06:	bf 7c 0d             	mov    di,0xd7c
     f09:	0e                   	push   cs
     f0a:	57                   	push   di
     f0b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     f0f:	06                   	push   es
     f10:	57                   	push   di
     f11:	9a f9 60 22 0f       	call   0xf22:0x60f9
     f16:	eb 46                	jmp    0xf5e
     f18:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f1b:	ff 76 fc             	push   WORD PTR [bp-0x4]
     f1e:	bf c8 07             	mov    di,0x7c8
     f21:	b8 39 0f             	mov    ax,0xf39
     f24:	50                   	push   ax
     f25:	57                   	push   di
     f26:	9a 55 22 40 0f       	call   0xf40:0x2255
     f2b:	08 c0                	or     al,al
     f2d:	74 2f                	je     0xf5e
     f2f:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f32:	ff 76 fc             	push   WORD PTR [bp-0x4]
     f35:	bf c8 07             	mov    di,0x7c8
     f38:	b8 5c 0f             	mov    ax,0xf5c
     f3b:	50                   	push   ax
     f3c:	57                   	push   di
     f3d:	9a 73 22 6b 0f       	call   0xf6b:0x2273
     f42:	89 c7                	mov    di,ax
     f44:	8e c2                	mov    es,dx
     f46:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
     f4a:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
     f4e:	bf 87 0d             	mov    di,0xd87
     f51:	0e                   	push   cs
     f52:	57                   	push   di
     f53:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     f57:	06                   	push   es
     f58:	57                   	push   di
     f59:	9a f9 60 72 10       	call   0x1072:0x60f9
     f5e:	c9                   	leave
     f5f:	ca 08 00             	retf   0x8
     f62:	55                   	push   bp
     f63:	89 e5                	mov    bp,sp
     f65:	b8 04 00             	mov    ax,0x4
     f68:	9a 44 04 82 0f       	call   0xf82:0x444
     f6d:	83 ec 04             	sub    sp,0x4
     f70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f73:	06                   	push   es
     f74:	57                   	push   di
     f75:	9a 7d 52 a1 0f       	call   0xfa1:0x527d
     f7a:	2d 01 00             	sub    ax,0x1
     f7d:	71 05                	jno    0xf84
     f7f:	9a 3e 04 b0 0f       	call   0xfb0:0x43e
     f84:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f87:	31 c0                	xor    ax,ax
     f89:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     f8c:	7f 58                	jg     0xfe6
     f8e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     f91:	eb 03                	jmp    0xf96
     f93:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     f96:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f9c:	06                   	push   es
     f9d:	57                   	push   di
     f9e:	9a 46 52 c1 0f       	call   0xfc1:0x5246
     fa3:	52                   	push   dx
     fa4:	50                   	push   ax
     fa5:	bf 22 00             	mov    di,0x22
     fa8:	b8 c9 0f             	mov    ax,0xfc9
     fab:	50                   	push   ax
     fac:	57                   	push   di
     fad:	9a 55 22 d0 0f       	call   0xfd0:0x2255
     fb2:	08 c0                	or     al,al
     fb4:	74 28                	je     0xfde
     fb6:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fbc:	06                   	push   es
     fbd:	57                   	push   di
     fbe:	9a 46 52 6a 36       	call   0x366a:0x5246
     fc3:	52                   	push   dx
     fc4:	50                   	push   ax
     fc5:	bf 22 00             	mov    di,0x22
     fc8:	b8 64 1c             	mov    ax,0x1c64
     fcb:	50                   	push   ax
     fcc:	57                   	push   di
     fcd:	9a 73 22 f2 0f       	call   0xff2:0x2273
     fd2:	52                   	push   dx
     fd3:	50                   	push   ax
     fd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd7:	06                   	push   es
     fd8:	57                   	push   di
     fd9:	9a 8d 0d 04 10       	call   0x1004:0xd8d
     fde:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     fe1:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     fe4:	75 ad                	jne    0xf93
     fe6:	c9                   	leave
     fe7:	ca 04 00             	retf   0x4
     fea:	55                   	push   bp
     feb:	89 e5                	mov    bp,sp
     fed:	31 c0                	xor    ax,ax
     fef:	9a 44 04 12 10       	call   0x1012:0x444
     ff4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ff7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ffa:	26 89 85 38 04       	mov    WORD PTR es:[di+0x438],ax
     fff:	06                   	push   es
    1000:	57                   	push   di
    1001:	9a b6 11 b4 11       	call   0x11b4:0x11b6
    1006:	c9                   	leave
    1007:	ca 06 00             	retf   0x6
    100a:	55                   	push   bp
    100b:	89 e5                	mov    bp,sp
    100d:	31 c0                	xor    ax,ax
    100f:	9a 44 04 4e 10       	call   0x104e:0x444
    1014:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1017:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    101c:	06                   	push   es
    101d:	57                   	push   di
    101e:	9a d2 31 30 10       	call   0x1030:0x31d2
    1023:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1026:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    102b:	06                   	push   es
    102c:	57                   	push   di
    102d:	9a d2 31 3f 10       	call   0x103f:0x31d2
    1032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1035:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    103a:	06                   	push   es
    103b:	57                   	push   di
    103c:	9a d2 31 66 10       	call   0x1066:0x31d2
    1041:	c9                   	leave
    1042:	ca 04 00             	retf   0x4
    1045:	55                   	push   bp
    1046:	89 e5                	mov    bp,sp
    1048:	b8 04 00             	mov    ax,0x4
    104b:	9a 44 04 17 11       	call   0x1117:0x444
    1050:	83 ec 04             	sub    sp,0x4
    1053:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1056:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    105b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    105e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1061:	06                   	push   es
    1062:	57                   	push   di
    1063:	9a d2 31 88 10       	call   0x1088:0x31d2
    1068:	6a 01                	push   0x1
    106a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    106d:	06                   	push   es
    106e:	57                   	push   di
    106f:	9a fb 2f 7e 10       	call   0x107e:0x2ffb
    1074:	6a 00                	push   0x0
    1076:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1079:	06                   	push   es
    107a:	57                   	push   di
    107b:	9a d2 2e a9 10       	call   0x10a9:0x2ed2
    1080:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1083:	06                   	push   es
    1084:	57                   	push   di
    1085:	9a bf 31 9d 10       	call   0x109d:0x31bf
    108a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    108d:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    1092:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1095:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1098:	06                   	push   es
    1099:	57                   	push   di
    109a:	9a d2 31 bf 10       	call   0x10bf:0x31d2
    109f:	6a 01                	push   0x1
    10a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10a4:	06                   	push   es
    10a5:	57                   	push   di
    10a6:	9a fb 2f b5 10       	call   0x10b5:0x2ffb
    10ab:	6a 00                	push   0x0
    10ad:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10b0:	06                   	push   es
    10b1:	57                   	push   di
    10b2:	9a d2 2e e0 10       	call   0x10e0:0x2ed2
    10b7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10ba:	06                   	push   es
    10bb:	57                   	push   di
    10bc:	9a bf 31 d4 10       	call   0x10d4:0x31bf
    10c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10c4:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    10c9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    10cc:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    10cf:	06                   	push   es
    10d0:	57                   	push   di
    10d1:	9a d2 31 f6 10       	call   0x10f6:0x31d2
    10d6:	6a 01                	push   0x1
    10d8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10db:	06                   	push   es
    10dc:	57                   	push   di
    10dd:	9a fb 2f ec 10       	call   0x10ec:0x2ffb
    10e2:	6a 00                	push   0x0
    10e4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10e7:	06                   	push   es
    10e8:	57                   	push   di
    10e9:	9a d2 2e b5 12       	call   0x12b5:0x2ed2
    10ee:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    10f1:	06                   	push   es
    10f2:	57                   	push   di
    10f3:	9a bf 31 37 11       	call   0x1137:0x31bf
    10f8:	c9                   	leave
    10f9:	ca 04 00             	retf   0x4
    10fc:	09 43 61             	or     WORD PTR [bp+di+0x61],ax
    10ff:	74 61                	je     0x1162
    1101:	53                   	push   bx
    1102:	74 79                	je     0x117d
    1104:	6c                   	ins    BYTE PTR es:[di],dx
    1105:	65 00 80 ff ff       	add    BYTE PTR gs:[bx+si-0x1],al
    110a:	ff                   	(bad)
    110b:	7f 00                	jg     0x110d
    110d:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1110:	e5 b8                	in     ax,0xb8
    1112:	06                   	push   es
    1113:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    1117:	4c                   	dec    sp
    1118:	11 83 ec 06          	adc    WORD PTR [bp+di+0x6ec],ax
    111c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    111f:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    1124:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    1127:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    112a:	bf fc 10             	mov    di,0x10fc
    112d:	0e                   	push   cs
    112e:	57                   	push   di
    112f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1132:	06                   	push   es
    1133:	57                   	push   di
    1134:	9a 9b 3b b0 11       	call   0x11b0:0x3b9b
    1139:	89 c7                	mov    di,ax
    113b:	8e c2                	mov    es,dx
    113d:	06                   	push   es
    113e:	57                   	push   di
    113f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1142:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1146:	bf 06 11             	mov    di,0x1106
    1149:	9a 16 04 bf 11       	call   0x11bf:0x416
    114e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1151:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1154:	26 c4 bd dc 03       	les    di,DWORD PTR es:[di+0x3dc]
    1159:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    115d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1160:	26 c4 bd 20 04       	les    di,DWORD PTR es:[di+0x420]
    1165:	06                   	push   es
    1166:	57                   	push   di
    1167:	9a 7b 17 83 11       	call   0x1183:0x177b
    116c:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    1170:	b0 00                	mov    al,0x0
    1172:	75 01                	jne    0x1175
    1174:	40                   	inc    ax
    1175:	50                   	push   ax
    1176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1179:	26 c4 bd 20 04       	les    di,DWORD PTR es:[di+0x420]
    117e:	06                   	push   es
    117f:	57                   	push   di
    1180:	9a 77 1c 9c 11       	call   0x119c:0x1c77
    1185:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
    1189:	b0 00                	mov    al,0x0
    118b:	75 01                	jne    0x118e
    118d:	40                   	inc    ax
    118e:	50                   	push   ax
    118f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1192:	26 c4 bd dc 03       	les    di,DWORD PTR es:[di+0x3dc]
    1197:	06                   	push   es
    1198:	57                   	push   di
    1199:	9a 77 1c e8 11       	call   0x11e8:0x1c77
    119e:	c9                   	leave
    119f:	ca 04 00             	retf   0x4
    11a2:	01 23                	add    WORD PTR [bp+di],sp
    11a4:	00 00                	add    BYTE PTR [bx+si],al
    11a6:	00 00                	add    BYTE PTR [bx+si],al
    11a8:	ff 00                	inc    WORD PTR [bx+si]
    11aa:	00 00                	add    BYTE PTR [bx+si],al
    11ac:	01 00                	add    WORD PTR [bx+si],ax
    11ae:	2f                   	das
    11af:	00 ff                	add    bh,bh
    11b1:	ff 88 13 c3          	dec    WORD PTR [bx+si-0x3ced]
    11b5:	12 55 89             	adc    dl,BYTE PTR [di-0x77]
    11b8:	e5 b8                	in     ax,0xb8
    11ba:	02 02                	add    al,BYTE PTR [bp+si]
    11bc:	9a 44 04 ff 11       	call   0x11ff:0x444
    11c1:	81 ec 02 02          	sub    sp,0x202
    11c5:	8d be fe fd          	lea    di,[bp-0x202]
    11c9:	16                   	push   ss
    11ca:	57                   	push   di
    11cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11ce:	26 8b 85 38 04       	mov    ax,WORD PTR es:[di+0x438]
    11d3:	99                   	cwd
    11d4:	52                   	push   dx
    11d5:	50                   	push   ax
    11d6:	9a a9 08 4a 12       	call   0x124a:0x8a9
    11db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11de:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    11e3:	06                   	push   es
    11e4:	57                   	push   di
    11e5:	9a 8c 1d 6e 12       	call   0x126e:0x1d8c
    11ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11ed:	81 c7 3a 04          	add    di,0x43a
    11f1:	06                   	push   es
    11f2:	57                   	push   di
    11f3:	8d be fe fe          	lea    di,[bp-0x102]
    11f7:	16                   	push   ss
    11f8:	57                   	push   di
    11f9:	68 ff 00             	push   0xff
    11fc:	9a e7 17 0f 12       	call   0x120f:0x17e7
    1201:	bf a2 11             	mov    di,0x11a2
    1204:	0e                   	push   cs
    1205:	57                   	push   di
    1206:	8d be fe fe          	lea    di,[bp-0x102]
    120a:	16                   	push   ss
    120b:	57                   	push   di
    120c:	9a 78 18 18 12       	call   0x1218:0x1878
    1211:	99                   	cwd
    1212:	bf a4 11             	mov    di,0x11a4
    1215:	9a 16 04 34 12       	call   0x1234:0x416
    121a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    121d:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1221:	76 3d                	jbe    0x1260
    1223:	8d be fe fe          	lea    di,[bp-0x102]
    1227:	16                   	push   ss
    1228:	57                   	push   di
    1229:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    122c:	30 e4                	xor    ah,ah
    122e:	50                   	push   ax
    122f:	6a 01                	push   0x1
    1231:	9a 75 19 5e 12       	call   0x125e:0x1975
    1236:	8d be fe fd          	lea    di,[bp-0x202]
    123a:	16                   	push   ss
    123b:	57                   	push   di
    123c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    123f:	26 8b 85 38 04       	mov    ax,WORD PTR es:[di+0x438]
    1244:	99                   	cwd
    1245:	52                   	push   dx
    1246:	50                   	push   ax
    1247:	9a a9 08 61 39       	call   0x3961:0x8a9
    124c:	8d be fe fe          	lea    di,[bp-0x102]
    1250:	16                   	push   ss
    1251:	57                   	push   di
    1252:	68 ff 00             	push   0xff
    1255:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1258:	30 e4                	xor    ah,ah
    125a:	50                   	push   ax
    125b:	9a 16 19 a0 13       	call   0x13a0:0x1916
    1260:	8d be fe fe          	lea    di,[bp-0x102]
    1264:	16                   	push   ss
    1265:	57                   	push   di
    1266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1269:	06                   	push   es
    126a:	57                   	push   di
    126b:	9a 8c 1d 50 14       	call   0x1450:0x1d8c
    1270:	b8 ac 11             	mov    ax,0x11ac
    1273:	0e                   	push   cs
    1274:	50                   	push   ax
    1275:	55                   	push   bp
    1276:	ff 36 58 18          	push   WORD PTR ds:0x1858
    127a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    127e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1281:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    1286:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    128a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    128e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1291:	26 8b 85 38 04       	mov    ax,WORD PTR es:[di+0x438]
    1296:	99                   	cwd
    1297:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    129b:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    129f:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    12a4:	8d be f2 fe          	lea    di,[bp-0x10e]
    12a8:	16                   	push   ss
    12a9:	57                   	push   di
    12aa:	6a 00                	push   0x0
    12ac:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    12b0:	06                   	push   es
    12b1:	57                   	push   di
    12b2:	9a 95 28 17 13       	call   0x1317:0x2895
    12b7:	08 c0                	or     al,al
    12b9:	75 0a                	jne    0x12c5
    12bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12be:	06                   	push   es
    12bf:	57                   	push   di
    12c0:	9a b8 09 cd 12       	call   0x12cd:0x9b8
    12c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c8:	06                   	push   es
    12c9:	57                   	push   di
    12ca:	9a 0e 11 25 13       	call   0x1325:0x110e
    12cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12d2:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    12d7:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    12db:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    12df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e2:	26 8b 85 38 04       	mov    ax,WORD PTR es:[di+0x438]
    12e7:	99                   	cwd
    12e8:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    12ec:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    12f0:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    12f5:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    12fb:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    1301:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1306:	8d be ea fe          	lea    di,[bp-0x116]
    130a:	16                   	push   ss
    130b:	57                   	push   di
    130c:	6a 01                	push   0x1
    130e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1312:	06                   	push   es
    1313:	57                   	push   di
    1314:	9a 95 28 6f 13       	call   0x136f:0x2895
    1319:	08 c0                	or     al,al
    131b:	75 0a                	jne    0x1327
    131d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1320:	06                   	push   es
    1321:	57                   	push   di
    1322:	9a b8 09 7d 13       	call   0x137d:0x9b8
    1327:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    132a:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    132f:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1333:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1337:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    133a:	26 8b 85 38 04       	mov    ax,WORD PTR es:[di+0x438]
    133f:	99                   	cwd
    1340:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1344:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1348:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    134d:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    1353:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    1359:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    135e:	8d be ea fe          	lea    di,[bp-0x116]
    1362:	16                   	push   ss
    1363:	57                   	push   di
    1364:	6a 01                	push   0x1
    1366:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    136a:	06                   	push   es
    136b:	57                   	push   di
    136c:	9a 95 28 ff ff       	call   0xffff:0x2895
    1371:	08 c0                	or     al,al
    1373:	75 0a                	jne    0x137f
    1375:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1378:	06                   	push   es
    1379:	57                   	push   di
    137a:	9a b8 09 aa 13       	call   0x13aa:0x9b8
    137f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1383:	83 c4 06             	add    sp,0x6
    1386:	eb 1a                	jmp    0x13a2
    1388:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    138c:	89 96 fc fe          	mov    WORD PTR [bp-0x104],dx
    1390:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    1394:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    1398:	9a 2d 34 ff ff       	call   0xffff:0x342d
    139d:	9a 34 14 bf 13       	call   0x13bf:0x1434
    13a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13a5:	06                   	push   es
    13a6:	57                   	push   di
    13a7:	9a 62 0f b4 13       	call   0x13b4:0xf62
    13ac:	c9                   	leave
    13ad:	ca 04 00             	retf   0x4
    13b0:	00 00                	add    BYTE PTR [bx+si],al
    13b2:	dc 14                	fcom   QWORD PTR [si]
    13b4:	09 14                	or     WORD PTR [si],dx
    13b6:	55                   	push   bp
    13b7:	89 e5                	mov    bp,sp
    13b9:	b8 0a 00             	mov    ax,0xa
    13bc:	9a 44 04 fa 14       	call   0x14fa:0x444
    13c1:	83 ec 0a             	sub    sp,0xa
    13c4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    13c8:	06                   	push   es
    13c9:	57                   	push   di
    13ca:	9a 03 73 10 14       	call   0x1410:0x7303
    13cf:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    13d3:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    13d7:	75 14                	jne    0x13ed
    13d9:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    13dd:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    13e3:	b0 00                	mov    al,0x0
    13e5:	75 01                	jne    0x13e8
    13e7:	40                   	inc    ax
    13e8:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    13eb:	eb 04                	jmp    0x13f1
    13ed:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    13f1:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    13f5:	75 03                	jne    0x13fa
    13f7:	e9 ed 00             	jmp    0x14e7
    13fa:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    13fe:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1402:	b0 01                	mov    al,0x1
    1404:	50                   	push   ax
    1405:	b8 22 00             	mov    ax,0x22
    1408:	ba 34 14             	mov    dx,0x1434
    140b:	52                   	push   dx
    140c:	50                   	push   ax
    140d:	9a 53 25 5e 14       	call   0x145e:0x2553
    1412:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1415:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1418:	b8 b0 13             	mov    ax,0x13b0
    141b:	0e                   	push   cs
    141c:	50                   	push   ax
    141d:	55                   	push   bp
    141e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1422:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1426:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1429:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    142c:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    142f:	06                   	push   es
    1430:	57                   	push   di
    1431:	9a 45 10 41 14       	call   0x1441:0x1045
    1436:	ff 76 08             	push   WORD PTR [bp+0x8]
    1439:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    143c:	06                   	push   es
    143d:	57                   	push   di
    143e:	9a ea 0f a3 14       	call   0x14a3:0xfea
    1443:	68 ff 00             	push   0xff
    1446:	6a ff                	push   0xffff
    1448:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    144b:	06                   	push   es
    144c:	57                   	push   di
    144d:	9a d5 1e 80 14       	call   0x1480:0x1ed5
    1452:	6a 00                	push   0x0
    1454:	6a 00                	push   0x0
    1456:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1459:	06                   	push   es
    145a:	57                   	push   di
    145b:	9a b2 36 6a 14       	call   0x146a:0x36b2
    1460:	6a 02                	push   0x2
    1462:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1465:	06                   	push   es
    1466:	57                   	push   di
    1467:	9a 14 3a 76 14       	call   0x1476:0x3a14
    146c:	6a 01                	push   0x1
    146e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1471:	06                   	push   es
    1472:	57                   	push   di
    1473:	9a e5 34 93 14       	call   0x1493:0x34e5
    1478:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    147b:	06                   	push   es
    147c:	57                   	push   di
    147d:	9a b9 62 5f 15       	call   0x155f:0x62b9
    1482:	50                   	push   ax
    1483:	6a 04                	push   0x4
    1485:	9a ff ff 00 00       	call   0x0:0xffff
    148a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    148e:	06                   	push   es
    148f:	57                   	push   di
    1490:	9a 03 73 ce 14       	call   0x14ce:0x7303
    1495:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1499:	74 0c                	je     0x14a7
    149b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    149e:	06                   	push   es
    149f:	57                   	push   di
    14a0:	9a f6 15 ef 14       	call   0x14ef:0x15f6
    14a5:	eb 1e                	jmp    0x14c5
    14a7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14aa:	ff 76 fc             	push   WORD PTR [bp-0x4]
    14ad:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14b0:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    14b5:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    14ba:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    14be:	06                   	push   es
    14bf:	57                   	push   di
    14c0:	9a 1a 31 ff ff       	call   0xffff:0x311a
    14c5:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    14c9:	06                   	push   es
    14ca:	57                   	push   di
    14cb:	9a 03 73 e4 14       	call   0x14e4:0x7303
    14d0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    14d4:	83 c4 06             	add    sp,0x6
    14d7:	b8 e7 14             	mov    ax,0x14e7
    14da:	0e                   	push   cs
    14db:	50                   	push   ax
    14dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14df:	06                   	push   es
    14e0:	57                   	push   di
    14e1:	9a 1d 5f 08 15       	call   0x1508:0x5f1d
    14e6:	cb                   	retf
    14e7:	c9                   	leave
    14e8:	ca 04 00             	retf   0x4
    14eb:	00 00                	add    BYTE PTR [bx+si],al
    14ed:	83 15 19             	adc    WORD PTR [di],0x19
    14f0:	15 55 89             	adc    ax,0x8955
    14f3:	e5 b8                	in     ax,0xb8
    14f5:	08 00                	or     BYTE PTR [bx+si],al
    14f7:	9a 44 04 a3 15       	call   0x15a3:0x444
    14fc:	83 ec 08             	sub    sp,0x8
    14ff:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1503:	06                   	push   es
    1504:	57                   	push   di
    1505:	9a 03 73 20 15       	call   0x1520:0x7303
    150a:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    150e:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1512:	b0 01                	mov    al,0x1
    1514:	50                   	push   ax
    1515:	b8 22 00             	mov    ax,0x22
    1518:	ba 44 15             	mov    dx,0x1544
    151b:	52                   	push   dx
    151c:	50                   	push   ax
    151d:	9a 53 25 6b 15       	call   0x156b:0x2553
    1522:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1525:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1528:	b8 eb 14             	mov    ax,0x14eb
    152b:	0e                   	push   cs
    152c:	50                   	push   ax
    152d:	55                   	push   bp
    152e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1532:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1536:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1539:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    153c:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    153f:	06                   	push   es
    1540:	57                   	push   di
    1541:	9a 45 10 51 15       	call   0x1551:0x1045
    1546:	ff 76 06             	push   WORD PTR [bp+0x6]
    1549:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    154c:	06                   	push   es
    154d:	57                   	push   di
    154e:	9a ea 0f f4 15       	call   0x15f4:0xfea
    1553:	6a ff                	push   0xffff
    1555:	6a f0                	push   0xfff0
    1557:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    155a:	06                   	push   es
    155b:	57                   	push   di
    155c:	9a d5 1e 51 18       	call   0x1851:0x1ed5
    1561:	6a 02                	push   0x2
    1563:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1566:	06                   	push   es
    1567:	57                   	push   di
    1568:	9a 14 3a 75 15       	call   0x1575:0x3a14
    156d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1570:	06                   	push   es
    1571:	57                   	push   di
    1572:	9a 45 5d 8b 15       	call   0x158b:0x5d45
    1577:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    157b:	83 c4 06             	add    sp,0x6
    157e:	b8 8e 15             	mov    ax,0x158e
    1581:	0e                   	push   cs
    1582:	50                   	push   ax
    1583:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1586:	06                   	push   es
    1587:	57                   	push   di
    1588:	9a 1d 5f 36 37       	call   0x3736:0x5f1d
    158d:	cb                   	retf
    158e:	c9                   	leave
    158f:	ca 02 00             	retf   0x2
    1592:	00 00                	add    BYTE PTR [bx+si],al
    1594:	00 00                	add    BYTE PTR [bx+si],al
    1596:	ff                   	(bad)
    1597:	ff 00                	inc    WORD PTR [bx+si]
    1599:	00 55 89             	add    BYTE PTR [di-0x77],dl
    159c:	e5 b8                	in     ax,0xb8
    159e:	22 00                	and    al,BYTE PTR [bx+si]
    15a0:	9a 44 04 d3 15       	call   0x15d3:0x444
    15a5:	83 ec 22             	sub    sp,0x22
    15a8:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    15ac:	06                   	push   es
    15ad:	57                   	push   di
    15ae:	9a 04 2a 1a 16       	call   0x161a:0x2a04
    15b3:	89 c7                	mov    di,ax
    15b5:	8e c2                	mov    es,dx
    15b7:	06                   	push   es
    15b8:	57                   	push   di
    15b9:	9a d2 21 6b 16       	call   0x166b:0x21d2
    15be:	50                   	push   ax
    15bf:	8d 7e de             	lea    di,[bp-0x22]
    15c2:	16                   	push   ss
    15c3:	57                   	push   di
    15c4:	9a ff ff 00 00       	call   0x0:0xffff
    15c9:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    15cc:	99                   	cwd
    15cd:	bf 92 15             	mov    di,0x1592
    15d0:	9a 16 04 ff 15       	call   0x15ff:0x416
    15d5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    15d8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    15db:	c9                   	leave
    15dc:	ca 02 00             	retf   0x2
    15df:	00 01                	add    BYTE PTR [bx+di],al
    15e1:	09 01                	or     WORD PTR [bx+di],ax
    15e3:	20 03                	and    BYTE PTR [bp+di],al
    15e5:	20 20                	and    BYTE PTR [bx+si],ah
    15e7:	20 00                	and    BYTE PTR [bx+si],al
    15e9:	80 ff ff             	cmp    bh,0xff
    15ec:	ff                   	(bad)
    15ed:	7f 00                	jg     0x15ef
    15ef:	00 00                	add    BYTE PTR [bx+si],al
    15f1:	00 2e 1a 0f          	add    BYTE PTR ds:0xf1a,ch
    15f5:	16                   	push   ss
    15f6:	55                   	push   bp
    15f7:	89 e5                	mov    bp,sp
    15f9:	b8 0e 04             	mov    ax,0x40e
    15fc:	9a 44 04 25 16       	call   0x1625:0x444
    1601:	81 ec 0e 04          	sub    sp,0x40e
    1605:	6a 01                	push   0x1
    1607:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    160a:	06                   	push   es
    160b:	57                   	push   di
    160c:	9a 21 1e 14 18       	call   0x1814:0x1e21
    1611:	8d be fc fe          	lea    di,[bp-0x104]
    1615:	16                   	push   ss
    1616:	57                   	push   di
    1617:	9a 4e 20 43 16       	call   0x1643:0x204e
    161c:	8d be fc fe          	lea    di,[bp-0x104]
    1620:	16                   	push   ss
    1621:	57                   	push   di
    1622:	9a f5 09 2a 16       	call   0x162a:0x9f5
    1627:	9a 08 04 bf 16       	call   0x16bf:0x408
    162c:	b8 f0 15             	mov    ax,0x15f0
    162f:	0e                   	push   cs
    1630:	50                   	push   ax
    1631:	55                   	push   bp
    1632:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1636:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    163a:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    163e:	06                   	push   es
    163f:	57                   	push   di
    1640:	9a 04 2a 78 16       	call   0x1678:0x2a04
    1645:	89 c7                	mov    di,ax
    1647:	8e c2                	mov    es,dx
    1649:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    164d:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    1651:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1655:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    165a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    165e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1662:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1666:	06                   	push   es
    1667:	57                   	push   di
    1668:	9a 99 20 87 16       	call   0x1687:0x2099
    166d:	6a 0a                	push   0xa
    166f:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1673:	06                   	push   es
    1674:	57                   	push   di
    1675:	9a 04 2a 94 16       	call   0x1694:0x2a04
    167a:	89 c7                	mov    di,ax
    167c:	8e c2                	mov    es,dx
    167e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1682:	06                   	push   es
    1683:	57                   	push   di
    1684:	9a f5 11 a3 16       	call   0x16a3:0x11f5
    1689:	6a 02                	push   0x2
    168b:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    168f:	06                   	push   es
    1690:	57                   	push   di
    1691:	9a 04 2a e3 17       	call   0x17e3:0x2a04
    1696:	89 c7                	mov    di,ax
    1698:	8e c2                	mov    es,dx
    169a:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    169e:	06                   	push   es
    169f:	57                   	push   di
    16a0:	9a 78 12 f2 17       	call   0x17f2:0x1278
    16a5:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    16aa:	eb 03                	jmp    0x16af
    16ac:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    16af:	8d be fc fe          	lea    di,[bp-0x104]
    16b3:	16                   	push   ss
    16b4:	57                   	push   di
    16b5:	bf df 15             	mov    di,0x15df
    16b8:	0e                   	push   cs
    16b9:	57                   	push   di
    16ba:	6a 00                	push   0x0
    16bc:	9a b5 0d c4 16       	call   0x16c4:0xdb5
    16c1:	9a 78 0c c9 16       	call   0x16c9:0xc78
    16c6:	9a 08 04 f7 16       	call   0x16f7:0x408
    16cb:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    16cf:	75 db                	jne    0x16ac
    16d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16d4:	26 c4 bd 34 04       	les    di,DWORD PTR es:[di+0x434]
    16d9:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    16dd:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    16e1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    16e6:	06                   	push   es
    16e7:	57                   	push   di
    16e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16eb:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    16ef:	2d 01 00             	sub    ax,0x1
    16f2:	71 05                	jno    0x16f9
    16f4:	9a 3e 04 37 17       	call   0x1737:0x43e
    16f9:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    16fd:	31 c0                	xor    ax,ax
    16ff:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1703:	7e 03                	jle    0x1708
    1705:	e9 c8 00             	jmp    0x17d0
    1708:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    170b:	eb 03                	jmp    0x1710
    170d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1710:	8d be f0 fc          	lea    di,[bp-0x310]
    1714:	16                   	push   ss
    1715:	57                   	push   di
    1716:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1719:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    171d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1722:	06                   	push   es
    1723:	57                   	push   di
    1724:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1727:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    172b:	8d be fc fd          	lea    di,[bp-0x204]
    172f:	16                   	push   ss
    1730:	57                   	push   di
    1731:	68 ff 00             	push   0xff
    1734:	9a e7 17 47 17       	call   0x1747:0x17e7
    1739:	bf e0 15             	mov    di,0x15e0
    173c:	0e                   	push   cs
    173d:	57                   	push   di
    173e:	8d be fc fd          	lea    di,[bp-0x204]
    1742:	16                   	push   ss
    1743:	57                   	push   di
    1744:	9a 78 18 60 17       	call   0x1760:0x1878
    1749:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    174c:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1750:	7e 26                	jle    0x1778
    1752:	8d be fc fd          	lea    di,[bp-0x204]
    1756:	16                   	push   ss
    1757:	57                   	push   di
    1758:	ff 76 fc             	push   WORD PTR [bp-0x4]
    175b:	6a 01                	push   0x1
    175d:	9a 75 19 76 17       	call   0x1776:0x1975
    1762:	bf e2 15             	mov    di,0x15e2
    1765:	0e                   	push   cs
    1766:	57                   	push   di
    1767:	8d be fc fd          	lea    di,[bp-0x204]
    176b:	16                   	push   ss
    176c:	57                   	push   di
    176d:	68 ff 00             	push   0xff
    1770:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1773:	9a 16 19 8c 17       	call   0x178c:0x1916
    1778:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    177c:	75 bb                	jne    0x1739
    177e:	8d be f0 fc          	lea    di,[bp-0x310]
    1782:	16                   	push   ss
    1783:	57                   	push   di
    1784:	bf e4 15             	mov    di,0x15e4
    1787:	0e                   	push   cs
    1788:	57                   	push   di
    1789:	9a cd 17 97 17       	call   0x1797:0x17cd
    178e:	8d be fc fd          	lea    di,[bp-0x204]
    1792:	16                   	push   ss
    1793:	57                   	push   di
    1794:	9a 4c 18 a5 17       	call   0x17a5:0x184c
    1799:	8d be fc fd          	lea    di,[bp-0x204]
    179d:	16                   	push   ss
    179e:	57                   	push   di
    179f:	68 ff 00             	push   0xff
    17a2:	9a e7 17 b8 17       	call   0x17b8:0x17e7
    17a7:	8d be fc fe          	lea    di,[bp-0x104]
    17ab:	16                   	push   ss
    17ac:	57                   	push   di
    17ad:	8d be fc fd          	lea    di,[bp-0x204]
    17b1:	16                   	push   ss
    17b2:	57                   	push   di
    17b3:	6a 00                	push   0x0
    17b5:	9a b5 0d bd 17       	call   0x17bd:0xdb5
    17ba:	9a 78 0c c2 17       	call   0x17c2:0xc78
    17bf:	9a 08 04 1e 18       	call   0x181e:0x408
    17c4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    17c7:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    17cb:	74 03                	je     0x17d0
    17cd:	e9 3d ff             	jmp    0x170d
    17d0:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    17d4:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    17d8:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    17dc:	6a 06                	push   0x6
    17de:	06                   	push   es
    17df:	57                   	push   di
    17e0:	9a 04 2a ff 17       	call   0x17ff:0x2a04
    17e5:	89 c7                	mov    di,ax
    17e7:	8e c2                	mov    es,dx
    17e9:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    17ed:	06                   	push   es
    17ee:	57                   	push   di
    17ef:	9a f5 11 0e 18       	call   0x180e:0x11f5
    17f4:	6a 00                	push   0x0
    17f6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    17fa:	06                   	push   es
    17fb:	57                   	push   di
    17fc:	9a 04 2a 82 18       	call   0x1882:0x2a04
    1801:	89 c7                	mov    di,ax
    1803:	8e c2                	mov    es,dx
    1805:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1809:	06                   	push   es
    180a:	57                   	push   di
    180b:	9a 78 12 a9 18       	call   0x18a9:0x1278
    1810:	55                   	push   bp
    1811:	9a 9a 15 6a 1e       	call   0x1e6a:0x159a
    1816:	05 02 00             	add    ax,0x2
    1819:	73 05                	jae    0x1820
    181b:	9a 3e 04 28 18       	call   0x1828:0x43e
    1820:	31 d2                	xor    dx,dx
    1822:	bf e8 15             	mov    di,0x15e8
    1825:	9a 16 04 3c 18       	call   0x183c:0x416
    182a:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    182e:	8d be f2 fb          	lea    di,[bp-0x40e]
    1832:	16                   	push   ss
    1833:	57                   	push   di
    1834:	bf e4 15             	mov    di,0x15e4
    1837:	0e                   	push   cs
    1838:	57                   	push   di
    1839:	9a cd 17 56 18       	call   0x1856:0x17cd
    183e:	8d be f2 fc          	lea    di,[bp-0x30e]
    1842:	16                   	push   ss
    1843:	57                   	push   di
    1844:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1847:	26 c4 bd a8 03       	les    di,DWORD PTR es:[di+0x3a8]
    184c:	06                   	push   es
    184d:	57                   	push   di
    184e:	9a 53 1d ce 18       	call   0x18ce:0x1d53
    1853:	9a 4c 18 64 18       	call   0x1864:0x184c
    1858:	8d be fc fd          	lea    di,[bp-0x204]
    185c:	16                   	push   ss
    185d:	57                   	push   di
    185e:	68 ff 00             	push   0xff
    1861:	9a e7 17 76 18       	call   0x1876:0x17e7
    1866:	6a 00                	push   0x0
    1868:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    186c:	b9 05 00             	mov    cx,0x5
    186f:	f7 e9                	imul   cx
    1871:	71 05                	jno    0x1878
    1873:	9a 3e 04 8c 18       	call   0x188c:0x43e
    1878:	50                   	push   ax
    1879:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    187d:	06                   	push   es
    187e:	57                   	push   di
    187f:	9a 72 2a 9e 18       	call   0x189e:0x2a72
    1884:	5a                   	pop    dx
    1885:	2b c2                	sub    ax,dx
    1887:	71 05                	jno    0x188e
    1889:	9a 3e 04 b9 18       	call   0x18b9:0x43e
    188e:	50                   	push   ax
    188f:	8d be fc fd          	lea    di,[bp-0x204]
    1893:	16                   	push   ss
    1894:	57                   	push   di
    1895:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1899:	06                   	push   es
    189a:	57                   	push   di
    189b:	9a 04 2a ff 18       	call   0x18ff:0x2a04
    18a0:	89 c7                	mov    di,ax
    18a2:	8e c2                	mov    es,dx
    18a4:	06                   	push   es
    18a5:	57                   	push   di
    18a6:	9a 09 1f 26 19       	call   0x1926:0x1f09
    18ab:	8d be f2 fb          	lea    di,[bp-0x40e]
    18af:	16                   	push   ss
    18b0:	57                   	push   di
    18b1:	bf e4 15             	mov    di,0x15e4
    18b4:	0e                   	push   cs
    18b5:	57                   	push   di
    18b6:	9a cd 17 d3 18       	call   0x18d3:0x17cd
    18bb:	8d be f2 fc          	lea    di,[bp-0x30e]
    18bf:	16                   	push   ss
    18c0:	57                   	push   di
    18c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c4:	26 c4 bd ac 03       	les    di,DWORD PTR es:[di+0x3ac]
    18c9:	06                   	push   es
    18ca:	57                   	push   di
    18cb:	9a 53 1d 4b 19       	call   0x194b:0x1d53
    18d0:	9a 4c 18 e1 18       	call   0x18e1:0x184c
    18d5:	8d be fc fd          	lea    di,[bp-0x204]
    18d9:	16                   	push   ss
    18da:	57                   	push   di
    18db:	68 ff 00             	push   0xff
    18de:	9a e7 17 f3 18       	call   0x18f3:0x17e7
    18e3:	6a 00                	push   0x0
    18e5:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    18e9:	b9 04 00             	mov    cx,0x4
    18ec:	f7 e9                	imul   cx
    18ee:	71 05                	jno    0x18f5
    18f0:	9a 3e 04 09 19       	call   0x1909:0x43e
    18f5:	50                   	push   ax
    18f6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    18fa:	06                   	push   es
    18fb:	57                   	push   di
    18fc:	9a 72 2a 1b 19       	call   0x191b:0x2a72
    1901:	5a                   	pop    dx
    1902:	2b c2                	sub    ax,dx
    1904:	71 05                	jno    0x190b
    1906:	9a 3e 04 36 19       	call   0x1936:0x43e
    190b:	50                   	push   ax
    190c:	8d be fc fd          	lea    di,[bp-0x204]
    1910:	16                   	push   ss
    1911:	57                   	push   di
    1912:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1916:	06                   	push   es
    1917:	57                   	push   di
    1918:	9a 04 2a 7c 19       	call   0x197c:0x2a04
    191d:	89 c7                	mov    di,ax
    191f:	8e c2                	mov    es,dx
    1921:	06                   	push   es
    1922:	57                   	push   di
    1923:	9a 09 1f a3 19       	call   0x19a3:0x1f09
    1928:	8d be f2 fb          	lea    di,[bp-0x40e]
    192c:	16                   	push   ss
    192d:	57                   	push   di
    192e:	bf e4 15             	mov    di,0x15e4
    1931:	0e                   	push   cs
    1932:	57                   	push   di
    1933:	9a cd 17 50 19       	call   0x1950:0x17cd
    1938:	8d be f2 fc          	lea    di,[bp-0x30e]
    193c:	16                   	push   ss
    193d:	57                   	push   di
    193e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1941:	26 c4 bd b0 03       	les    di,DWORD PTR es:[di+0x3b0]
    1946:	06                   	push   es
    1947:	57                   	push   di
    1948:	9a 53 1d c8 19       	call   0x19c8:0x1d53
    194d:	9a 4c 18 5e 19       	call   0x195e:0x184c
    1952:	8d be fc fd          	lea    di,[bp-0x204]
    1956:	16                   	push   ss
    1957:	57                   	push   di
    1958:	68 ff 00             	push   0xff
    195b:	9a e7 17 70 19       	call   0x1970:0x17e7
    1960:	6a 00                	push   0x0
    1962:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    1966:	b9 03 00             	mov    cx,0x3
    1969:	f7 e9                	imul   cx
    196b:	71 05                	jno    0x1972
    196d:	9a 3e 04 86 19       	call   0x1986:0x43e
    1972:	50                   	push   ax
    1973:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1977:	06                   	push   es
    1978:	57                   	push   di
    1979:	9a 72 2a 98 19       	call   0x1998:0x2a72
    197e:	5a                   	pop    dx
    197f:	2b c2                	sub    ax,dx
    1981:	71 05                	jno    0x1988
    1983:	9a 3e 04 b3 19       	call   0x19b3:0x43e
    1988:	50                   	push   ax
    1989:	8d be fc fd          	lea    di,[bp-0x204]
    198d:	16                   	push   ss
    198e:	57                   	push   di
    198f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1993:	06                   	push   es
    1994:	57                   	push   di
    1995:	9a 04 2a f9 19       	call   0x19f9:0x2a04
    199a:	89 c7                	mov    di,ax
    199c:	8e c2                	mov    es,dx
    199e:	06                   	push   es
    199f:	57                   	push   di
    19a0:	9a 09 1f 20 1a       	call   0x1a20:0x1f09
    19a5:	8d be f2 fb          	lea    di,[bp-0x40e]
    19a9:	16                   	push   ss
    19aa:	57                   	push   di
    19ab:	bf e4 15             	mov    di,0x15e4
    19ae:	0e                   	push   cs
    19af:	57                   	push   di
    19b0:	9a cd 17 cd 19       	call   0x19cd:0x17cd
    19b5:	8d be f2 fc          	lea    di,[bp-0x30e]
    19b9:	16                   	push   ss
    19ba:	57                   	push   di
    19bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19be:	26 c4 bd b4 03       	les    di,DWORD PTR es:[di+0x3b4]
    19c3:	06                   	push   es
    19c4:	57                   	push   di
    19c5:	9a 53 1d 4b 1b       	call   0x1b4b:0x1d53
    19ca:	9a 4c 18 db 19       	call   0x19db:0x184c
    19cf:	8d be fc fd          	lea    di,[bp-0x204]
    19d3:	16                   	push   ss
    19d4:	57                   	push   di
    19d5:	68 ff 00             	push   0xff
    19d8:	9a e7 17 ed 19       	call   0x19ed:0x17e7
    19dd:	6a 00                	push   0x0
    19df:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    19e3:	b9 02 00             	mov    cx,0x2
    19e6:	f7 e9                	imul   cx
    19e8:	71 05                	jno    0x19ef
    19ea:	9a 3e 04 03 1a       	call   0x1a03:0x43e
    19ef:	50                   	push   ax
    19f0:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    19f4:	06                   	push   es
    19f5:	57                   	push   di
    19f6:	9a 72 2a 15 1a       	call   0x1a15:0x2a72
    19fb:	5a                   	pop    dx
    19fc:	2b c2                	sub    ax,dx
    19fe:	71 05                	jno    0x1a05
    1a00:	9a 3e 04 37 1a       	call   0x1a37:0x43e
    1a05:	50                   	push   ax
    1a06:	8d be fc fd          	lea    di,[bp-0x204]
    1a0a:	16                   	push   ss
    1a0b:	57                   	push   di
    1a0c:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1a10:	06                   	push   es
    1a11:	57                   	push   di
    1a12:	9a 04 2a ff ff       	call   0xffff:0x2a04
    1a17:	89 c7                	mov    di,ax
    1a19:	8e c2                	mov    es,dx
    1a1b:	06                   	push   es
    1a1c:	57                   	push   di
    1a1d:	9a 09 1f 1a 3a       	call   0x3a1a:0x1f09
    1a22:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1a26:	83 c4 06             	add    sp,0x6
    1a29:	b8 4e 1a             	mov    ax,0x1a4e
    1a2c:	0e                   	push   cs
    1a2d:	50                   	push   ax
    1a2e:	8d be fc fe          	lea    di,[bp-0x104]
    1a32:	16                   	push   ss
    1a33:	57                   	push   di
    1a34:	9a 4f 0a 3c 1a       	call   0x1a3c:0xa4f
    1a39:	9a 08 04 67 1a       	call   0x1a67:0x408
    1a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a41:	26 c4 bd 34 04       	les    di,DWORD PTR es:[di+0x434]
    1a46:	06                   	push   es
    1a47:	57                   	push   di
    1a48:	9a e3 49 10 1b       	call   0x1b10:0x49e3
    1a4d:	cb                   	retf
    1a4e:	c9                   	leave
    1a4f:	ca 04 00             	retf   0x4
    1a52:	01 09                	add    WORD PTR [bx+di],cx
    1a54:	01 20                	add    WORD PTR [bx+si],sp
    1a56:	03 6f 75             	add    bp,WORD PTR [bx+0x75]
    1a59:	69 03 6e 6f          	imul   ax,WORD PTR [bp+di],0x6f6e
    1a5d:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a5e:	55                   	push   bp
    1a5f:	89 e5                	mov    bp,sp
    1a61:	b8 06 02             	mov    ax,0x206
    1a64:	9a 44 04 a2 1a       	call   0x1aa2:0x444
    1a69:	81 ec 06 02          	sub    sp,0x206
    1a6d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1a70:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1a75:	75 03                	jne    0x1a7a
    1a77:	e9 9b 03             	jmp    0x1e15
    1a7a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1a7f:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    1a82:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    1a86:	3d 00 00             	cmp    ax,0x0
    1a89:	75 32                	jne    0x1abd
    1a8b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1a8e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1a92:	76 27                	jbe    0x1abb
    1a94:	8d be fe fd          	lea    di,[bp-0x202]
    1a98:	16                   	push   ss
    1a99:	57                   	push   di
    1a9a:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1a9d:	06                   	push   es
    1a9e:	57                   	push   di
    1a9f:	9a cd 17 ac 1a       	call   0x1aac:0x17cd
    1aa4:	bf 52 1a             	mov    di,0x1a52
    1aa7:	0e                   	push   cs
    1aa8:	57                   	push   di
    1aa9:	9a 4c 18 b9 1a       	call   0x1ab9:0x184c
    1aae:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1ab1:	06                   	push   es
    1ab2:	57                   	push   di
    1ab3:	ff 76 10             	push   WORD PTR [bp+0x10]
    1ab6:	9a e7 17 e9 1a       	call   0x1ae9:0x17e7
    1abb:	eb 49                	jmp    0x1b06
    1abd:	3d 01 00             	cmp    ax,0x1
    1ac0:	75 44                	jne    0x1b06
    1ac2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1ac5:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1ac8:	30 e4                	xor    ah,ah
    1aca:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1ace:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    1ad2:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    1ad5:	7d 2d                	jge    0x1b04
    1ad7:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    1adb:	8d be fe fd          	lea    di,[bp-0x202]
    1adf:	16                   	push   ss
    1ae0:	57                   	push   di
    1ae1:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1ae4:	06                   	push   es
    1ae5:	57                   	push   di
    1ae6:	9a cd 17 f3 1a       	call   0x1af3:0x17cd
    1aeb:	bf 54 1a             	mov    di,0x1a54
    1aee:	0e                   	push   cs
    1aef:	57                   	push   di
    1af0:	9a 4c 18 00 1b       	call   0x1b00:0x184c
    1af5:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1af8:	06                   	push   es
    1af9:	57                   	push   di
    1afa:	ff 76 10             	push   WORD PTR [bp+0x10]
    1afd:	9a e7 17 17 1b       	call   0x1b17:0x17e7
    1b02:	eb ca                	jmp    0x1ace
    1b04:	eb 00                	jmp    0x1b06
    1b06:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b09:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b0c:	bf 0c 01             	mov    di,0x10c
    1b0f:	b8 27 1b             	mov    ax,0x1b27
    1b12:	50                   	push   ax
    1b13:	57                   	push   di
    1b14:	9a 55 22 2e 1b       	call   0x1b2e:0x2255
    1b19:	08 c0                	or     al,al
    1b1b:	74 3e                	je     0x1b5b
    1b1d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b20:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b23:	bf 0c 01             	mov    di,0x10c
    1b26:	b8 ba 1b             	mov    ax,0x1bba
    1b29:	50                   	push   ax
    1b2a:	57                   	push   di
    1b2b:	9a 73 22 59 1b       	call   0x1b59:0x2273
    1b30:	89 c7                	mov    di,ax
    1b32:	8e c2                	mov    es,dx
    1b34:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1b38:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1b3c:	8d be fa fd          	lea    di,[bp-0x206]
    1b40:	16                   	push   ss
    1b41:	57                   	push   di
    1b42:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1b46:	06                   	push   es
    1b47:	57                   	push   di
    1b48:	9a 53 1d a0 1b       	call   0x1ba0:0x1d53
    1b4d:	8d be 00 ff          	lea    di,[bp-0x100]
    1b51:	16                   	push   ss
    1b52:	57                   	push   di
    1b53:	68 ff 00             	push   0xff
    1b56:	9a e7 17 6c 1b       	call   0x1b6c:0x17e7
    1b5b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b5e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b61:	bf ad 0d             	mov    di,0xdad
    1b64:	b8 7c 1b             	mov    ax,0x1b7c
    1b67:	50                   	push   ax
    1b68:	57                   	push   di
    1b69:	9a 55 22 83 1b       	call   0x1b83:0x2255
    1b6e:	08 c0                	or     al,al
    1b70:	74 3e                	je     0x1bb0
    1b72:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1b75:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b78:	bf ad 0d             	mov    di,0xdad
    1b7b:	b8 ff ff             	mov    ax,0xffff
    1b7e:	50                   	push   ax
    1b7f:	57                   	push   di
    1b80:	9a 73 22 ae 1b       	call   0x1bae:0x2273
    1b85:	89 c7                	mov    di,ax
    1b87:	8e c2                	mov    es,dx
    1b89:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1b8d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1b91:	8d be fa fd          	lea    di,[bp-0x206]
    1b95:	16                   	push   ss
    1b96:	57                   	push   di
    1b97:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1b9b:	06                   	push   es
    1b9c:	57                   	push   di
    1b9d:	9a 53 1d f5 1b       	call   0x1bf5:0x1d53
    1ba2:	8d be 00 ff          	lea    di,[bp-0x100]
    1ba6:	16                   	push   ss
    1ba7:	57                   	push   di
    1ba8:	68 ff 00             	push   0xff
    1bab:	9a e7 17 c1 1b       	call   0x1bc1:0x17e7
    1bb0:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1bb3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bb6:	bf 17 06             	mov    di,0x617
    1bb9:	b8 d1 1b             	mov    ax,0x1bd1
    1bbc:	50                   	push   ax
    1bbd:	57                   	push   di
    1bbe:	9a 55 22 d8 1b       	call   0x1bd8:0x2255
    1bc3:	08 c0                	or     al,al
    1bc5:	74 3e                	je     0x1c05
    1bc7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1bca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bcd:	bf 17 06             	mov    di,0x617
    1bd0:	b8 0f 1c             	mov    ax,0x1c0f
    1bd3:	50                   	push   ax
    1bd4:	57                   	push   di
    1bd5:	9a 73 22 03 1c       	call   0x1c03:0x2273
    1bda:	89 c7                	mov    di,ax
    1bdc:	8e c2                	mov    es,dx
    1bde:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1be2:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1be6:	8d be fa fd          	lea    di,[bp-0x206]
    1bea:	16                   	push   ss
    1beb:	57                   	push   di
    1bec:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1bf0:	06                   	push   es
    1bf1:	57                   	push   di
    1bf2:	9a 53 1d 4a 1c       	call   0x1c4a:0x1d53
    1bf7:	8d be 00 ff          	lea    di,[bp-0x100]
    1bfb:	16                   	push   ss
    1bfc:	57                   	push   di
    1bfd:	68 ff 00             	push   0xff
    1c00:	9a e7 17 16 1c       	call   0x1c16:0x17e7
    1c05:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c08:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c0b:	bf 19 2c             	mov    di,0x2c19
    1c0e:	b8 26 1c             	mov    ax,0x1c26
    1c11:	50                   	push   ax
    1c12:	57                   	push   di
    1c13:	9a 55 22 2d 1c       	call   0x1c2d:0x2255
    1c18:	08 c0                	or     al,al
    1c1a:	74 3e                	je     0x1c5a
    1c1c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c1f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c22:	bf 19 2c             	mov    di,0x2c19
    1c25:	b8 b9 1c             	mov    ax,0x1cb9
    1c28:	50                   	push   ax
    1c29:	57                   	push   di
    1c2a:	9a 73 22 58 1c       	call   0x1c58:0x2273
    1c2f:	89 c7                	mov    di,ax
    1c31:	8e c2                	mov    es,dx
    1c33:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1c37:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1c3b:	8d be fa fd          	lea    di,[bp-0x206]
    1c3f:	16                   	push   ss
    1c40:	57                   	push   di
    1c41:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1c45:	06                   	push   es
    1c46:	57                   	push   di
    1c47:	9a 53 1d f4 1c       	call   0x1cf4:0x1d53
    1c4c:	8d be 00 ff          	lea    di,[bp-0x100]
    1c50:	16                   	push   ss
    1c51:	57                   	push   di
    1c52:	68 ff 00             	push   0xff
    1c55:	9a e7 17 6b 1c       	call   0x1c6b:0x17e7
    1c5a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c5d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c60:	bf 22 00             	mov    di,0x22
    1c63:	b8 7b 1c             	mov    ax,0x1c7b
    1c66:	50                   	push   ax
    1c67:	57                   	push   di
    1c68:	9a 55 22 82 1c       	call   0x1c82:0x2255
    1c6d:	08 c0                	or     al,al
    1c6f:	74 3e                	je     0x1caf
    1c71:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c74:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c77:	bf 22 00             	mov    di,0x22
    1c7a:	b8 0e 1d             	mov    ax,0x1d0e
    1c7d:	50                   	push   ax
    1c7e:	57                   	push   di
    1c7f:	9a 73 22 ad 1c       	call   0x1cad:0x2273
    1c84:	89 c7                	mov    di,ax
    1c86:	8e c2                	mov    es,dx
    1c88:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1c8c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1c90:	8d be fa fd          	lea    di,[bp-0x206]
    1c94:	16                   	push   ss
    1c95:	57                   	push   di
    1c96:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1c9a:	06                   	push   es
    1c9b:	57                   	push   di
    1c9c:	9a 24 15 ff ff       	call   0xffff:0x1524
    1ca1:	8d be 00 ff          	lea    di,[bp-0x100]
    1ca5:	16                   	push   ss
    1ca6:	57                   	push   di
    1ca7:	68 ff 00             	push   0xff
    1caa:	9a e7 17 c0 1c       	call   0x1cc0:0x17e7
    1caf:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1cb2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cb5:	bf 90 0b             	mov    di,0xb90
    1cb8:	b8 d0 1c             	mov    ax,0x1cd0
    1cbb:	50                   	push   ax
    1cbc:	57                   	push   di
    1cbd:	9a 55 22 d7 1c       	call   0x1cd7:0x2255
    1cc2:	08 c0                	or     al,al
    1cc4:	74 3e                	je     0x1d04
    1cc6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1cc9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ccc:	bf 90 0b             	mov    di,0xb90
    1ccf:	b8 37 1d             	mov    ax,0x1d37
    1cd2:	50                   	push   ax
    1cd3:	57                   	push   di
    1cd4:	9a 73 22 02 1d       	call   0x1d02:0x2273
    1cd9:	89 c7                	mov    di,ax
    1cdb:	8e c2                	mov    es,dx
    1cdd:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1ce1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1ce5:	8d be fa fd          	lea    di,[bp-0x206]
    1ce9:	16                   	push   ss
    1cea:	57                   	push   di
    1ceb:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1cef:	06                   	push   es
    1cf0:	57                   	push   di
    1cf1:	9a 53 1d 9a 1e       	call   0x1e9a:0x1d53
    1cf6:	8d be 00 ff          	lea    di,[bp-0x100]
    1cfa:	16                   	push   ss
    1cfb:	57                   	push   di
    1cfc:	68 ff 00             	push   0xff
    1cff:	9a e7 17 15 1d       	call   0x1d15:0x17e7
    1d04:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1d07:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d0a:	bf 26 06             	mov    di,0x626
    1d0d:	b8 25 1d             	mov    ax,0x1d25
    1d10:	50                   	push   ax
    1d11:	57                   	push   di
    1d12:	9a 55 22 2c 1d       	call   0x1d2c:0x2255
    1d17:	08 c0                	or     al,al
    1d19:	74 4a                	je     0x1d65
    1d1b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1d1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d21:	bf 26 06             	mov    di,0x626
    1d24:	b8 ff ff             	mov    ax,0xffff
    1d27:	50                   	push   ax
    1d28:	57                   	push   di
    1d29:	9a 73 22 4e 1d       	call   0x1d4e:0x2273
    1d2e:	89 c7                	mov    di,ax
    1d30:	8e c2                	mov    es,dx
    1d32:	06                   	push   es
    1d33:	57                   	push   di
    1d34:	9a d2 6d 45 1e       	call   0x1e45:0x6dd2
    1d39:	08 c0                	or     al,al
    1d3b:	74 15                	je     0x1d52
    1d3d:	bf 56 1a             	mov    di,0x1a56
    1d40:	0e                   	push   cs
    1d41:	57                   	push   di
    1d42:	8d be 00 ff          	lea    di,[bp-0x100]
    1d46:	16                   	push   ss
    1d47:	57                   	push   di
    1d48:	68 ff 00             	push   0xff
    1d4b:	9a e7 17 63 1d       	call   0x1d63:0x17e7
    1d50:	eb 13                	jmp    0x1d65
    1d52:	bf 5a 1a             	mov    di,0x1a5a
    1d55:	0e                   	push   cs
    1d56:	57                   	push   di
    1d57:	8d be 00 ff          	lea    di,[bp-0x100]
    1d5b:	16                   	push   ss
    1d5c:	57                   	push   di
    1d5d:	68 ff 00             	push   0xff
    1d60:	9a e7 17 6c 1d       	call   0x1d6c:0x17e7
    1d65:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    1d68:	50                   	push   ax
    1d69:	9a f9 1e 9b 1d       	call   0x1d9b:0x1ef9
    1d6e:	3c 47                	cmp    al,0x47
    1d70:	75 2f                	jne    0x1da1
    1d72:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1d77:	b0 00                	mov    al,0x0
    1d79:	76 01                	jbe    0x1d7c
    1d7b:	40                   	inc    ax
    1d7c:	8a d0                	mov    dl,al
    1d7e:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    1d83:	b0 00                	mov    al,0x0
    1d85:	75 01                	jne    0x1d88
    1d87:	40                   	inc    ax
    1d88:	22 c2                	and    al,dl
    1d8a:	08 c0                	or     al,al
    1d8c:	74 11                	je     0x1d9f
    1d8e:	8d be 00 ff          	lea    di,[bp-0x100]
    1d92:	16                   	push   ss
    1d93:	57                   	push   di
    1d94:	6a 01                	push   0x1
    1d96:	6a 01                	push   0x1
    1d98:	9a 75 19 c8 1d       	call   0x1dc8:0x1975
    1d9d:	eb d3                	jmp    0x1d72
    1d9f:	eb 4c                	jmp    0x1ded
    1da1:	3c 44                	cmp    al,0x44
    1da3:	75 42                	jne    0x1de7
    1da5:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    1da9:	30 e4                	xor    ah,ah
    1dab:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1daf:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    1db4:	7d 2f                	jge    0x1de5
    1db6:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    1dba:	8d be fe fd          	lea    di,[bp-0x202]
    1dbe:	16                   	push   ss
    1dbf:	57                   	push   di
    1dc0:	bf 54 1a             	mov    di,0x1a54
    1dc3:	0e                   	push   cs
    1dc4:	57                   	push   di
    1dc5:	9a cd 17 d3 1d       	call   0x1dd3:0x17cd
    1dca:	8d be 00 ff          	lea    di,[bp-0x100]
    1dce:	16                   	push   ss
    1dcf:	57                   	push   di
    1dd0:	9a 4c 18 e1 1d       	call   0x1de1:0x184c
    1dd5:	8d be 00 ff          	lea    di,[bp-0x100]
    1dd9:	16                   	push   ss
    1dda:	57                   	push   di
    1ddb:	68 ff 00             	push   0xff
    1dde:	9a e7 17 fb 1d       	call   0x1dfb:0x17e7
    1de3:	eb ca                	jmp    0x1daf
    1de5:	eb 06                	jmp    0x1ded
    1de7:	3c 43                	cmp    al,0x43
    1de9:	75 02                	jne    0x1ded
    1deb:	eb 00                	jmp    0x1ded
    1ded:	8d be fe fd          	lea    di,[bp-0x202]
    1df1:	16                   	push   ss
    1df2:	57                   	push   di
    1df3:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1df6:	06                   	push   es
    1df7:	57                   	push   di
    1df8:	9a cd 17 06 1e       	call   0x1e06:0x17cd
    1dfd:	8d be 00 ff          	lea    di,[bp-0x100]
    1e01:	16                   	push   ss
    1e02:	57                   	push   di
    1e03:	9a 4c 18 13 1e       	call   0x1e13:0x184c
    1e08:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1e0b:	06                   	push   es
    1e0c:	57                   	push   di
    1e0d:	ff 76 10             	push   WORD PTR [bp+0x10]
    1e10:	9a e7 17 2a 1e       	call   0x1e2a:0x17e7
    1e15:	c9                   	leave
    1e16:	ca 10 00             	retf   0x10
    1e19:	01 09                	add    WORD PTR [bx+di],cx
    1e1b:	00 01                	add    BYTE PTR [bx+di],al
    1e1d:	20 02                	and    BYTE PTR [bp+si],al
    1e1f:	3a 20                	cmp    ah,BYTE PTR [bx+si]
    1e21:	55                   	push   bp
    1e22:	89 e5                	mov    bp,sp
    1e24:	b8 06 03             	mov    ax,0x306
    1e27:	9a 44 04 7b 1e       	call   0x1e7b:0x444
    1e2c:	81 ec 06 03          	sub    sp,0x306
    1e30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e33:	26 c4 bd 34 04       	les    di,DWORD PTR es:[di+0x434]
    1e38:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1e3c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1e40:	06                   	push   es
    1e41:	57                   	push   di
    1e42:	9a e3 49 ff ff       	call   0xffff:0x49e3
    1e47:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1e4c:	8d be 00 ff          	lea    di,[bp-0x100]
    1e50:	16                   	push   ss
    1e51:	57                   	push   di
    1e52:	68 ff 00             	push   0xff
    1e55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e58:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    1e5d:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    1e62:	6a 00                	push   0x0
    1e64:	6a 67                	push   0x67
    1e66:	55                   	push   bp
    1e67:	9a 5e 1a 07 1f       	call   0x1f07:0x1a5e
    1e6c:	8d be fa fd          	lea    di,[bp-0x206]
    1e70:	16                   	push   ss
    1e71:	57                   	push   di
    1e72:	8d be 00 ff          	lea    di,[bp-0x100]
    1e76:	16                   	push   ss
    1e77:	57                   	push   di
    1e78:	9a cd 17 85 1e       	call   0x1e85:0x17cd
    1e7d:	bf 19 1e             	mov    di,0x1e19
    1e80:	0e                   	push   cs
    1e81:	57                   	push   di
    1e82:	9a 4c 18 9f 1e       	call   0x1e9f:0x184c
    1e87:	8d be fa fc          	lea    di,[bp-0x306]
    1e8b:	16                   	push   ss
    1e8c:	57                   	push   di
    1e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e90:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    1e95:	06                   	push   es
    1e96:	57                   	push   di
    1e97:	9a 53 1d 77 1f       	call   0x1f77:0x1d53
    1e9c:	9a 4c 18 ad 1e       	call   0x1ead:0x184c
    1ea1:	8d be 00 ff          	lea    di,[bp-0x100]
    1ea5:	16                   	push   ss
    1ea6:	57                   	push   di
    1ea7:	68 ff 00             	push   0xff
    1eaa:	9a e7 17 58 1f       	call   0x1f58:0x17e7
    1eaf:	8d be 00 ff          	lea    di,[bp-0x100]
    1eb3:	16                   	push   ss
    1eb4:	57                   	push   di
    1eb5:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1eb9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1ebe:	06                   	push   es
    1ebf:	57                   	push   di
    1ec0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ec3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1ec7:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1ecb:	75 17                	jne    0x1ee4
    1ecd:	bf 1b 1e             	mov    di,0x1e1b
    1ed0:	0e                   	push   cs
    1ed1:	57                   	push   di
    1ed2:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1ed6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1edb:	06                   	push   es
    1edc:	57                   	push   di
    1edd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ee0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1ee4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1ee9:	8d be 00 ff          	lea    di,[bp-0x100]
    1eed:	16                   	push   ss
    1eee:	57                   	push   di
    1eef:	68 ff 00             	push   0xff
    1ef2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ef5:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    1efa:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    1eff:	6a 0a                	push   0xa
    1f01:	6a 67                	push   0x67
    1f03:	55                   	push   bp
    1f04:	9a 5e 1a 27 1f       	call   0x1f27:0x1a5e
    1f09:	8d be 00 ff          	lea    di,[bp-0x100]
    1f0d:	16                   	push   ss
    1f0e:	57                   	push   di
    1f0f:	68 ff 00             	push   0xff
    1f12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f15:	26 ff b5 9a 01       	push   WORD PTR es:[di+0x19a]
    1f1a:	26 ff b5 98 01       	push   WORD PTR es:[di+0x198]
    1f1f:	6a 23                	push   0x23
    1f21:	6a 67                	push   0x67
    1f23:	55                   	push   bp
    1f24:	9a 5e 1a 47 1f       	call   0x1f47:0x1a5e
    1f29:	8d be 00 ff          	lea    di,[bp-0x100]
    1f2d:	16                   	push   ss
    1f2e:	57                   	push   di
    1f2f:	68 ff 00             	push   0xff
    1f32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f35:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    1f3a:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    1f3f:	6a 46                	push   0x46
    1f41:	6a 67                	push   0x67
    1f43:	55                   	push   bp
    1f44:	9a 5e 1a e6 1f       	call   0x1fe6:0x1a5e
    1f49:	8d be fa fd          	lea    di,[bp-0x206]
    1f4d:	16                   	push   ss
    1f4e:	57                   	push   di
    1f4f:	8d be 00 ff          	lea    di,[bp-0x100]
    1f53:	16                   	push   ss
    1f54:	57                   	push   di
    1f55:	9a cd 17 62 1f       	call   0x1f62:0x17cd
    1f5a:	bf 1c 1e             	mov    di,0x1e1c
    1f5d:	0e                   	push   cs
    1f5e:	57                   	push   di
    1f5f:	9a 4c 18 7c 1f       	call   0x1f7c:0x184c
    1f64:	8d be fa fc          	lea    di,[bp-0x306]
    1f68:	16                   	push   ss
    1f69:	57                   	push   di
    1f6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6d:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    1f72:	06                   	push   es
    1f73:	57                   	push   di
    1f74:	9a 53 1d 15 2d       	call   0x2d15:0x1d53
    1f79:	9a 4c 18 8a 1f       	call   0x1f8a:0x184c
    1f7e:	8d be 00 ff          	lea    di,[bp-0x100]
    1f82:	16                   	push   ss
    1f83:	57                   	push   di
    1f84:	68 ff 00             	push   0xff
    1f87:	9a e7 17 f6 2c       	call   0x2cf6:0x17e7
    1f8c:	8d be 00 ff          	lea    di,[bp-0x100]
    1f90:	16                   	push   ss
    1f91:	57                   	push   di
    1f92:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1f96:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1f9b:	06                   	push   es
    1f9c:	57                   	push   di
    1f9d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fa0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1fa4:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1fa8:	75 17                	jne    0x1fc1
    1faa:	bf 1b 1e             	mov    di,0x1e1b
    1fad:	0e                   	push   cs
    1fae:	57                   	push   di
    1faf:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1fb3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1fb8:	06                   	push   es
    1fb9:	57                   	push   di
    1fba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fbd:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1fc1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1fc6:	8d be 00 ff          	lea    di,[bp-0x100]
    1fca:	16                   	push   ss
    1fcb:	57                   	push   di
    1fcc:	68 ff 00             	push   0xff
    1fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd2:	26 ff b5 be 01       	push   WORD PTR es:[di+0x1be]
    1fd7:	26 ff b5 bc 01       	push   WORD PTR es:[di+0x1bc]
    1fdc:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    1fe0:	6a 67                	push   0x67
    1fe2:	55                   	push   bp
    1fe3:	9a 5e 1a 25 20       	call   0x2025:0x1a5e
    1fe8:	8d be 00 ff          	lea    di,[bp-0x100]
    1fec:	16                   	push   ss
    1fed:	57                   	push   di
    1fee:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1ff2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1ff7:	06                   	push   es
    1ff8:	57                   	push   di
    1ff9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ffc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2000:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2005:	8d be 00 ff          	lea    di,[bp-0x100]
    2009:	16                   	push   ss
    200a:	57                   	push   di
    200b:	68 ff 00             	push   0xff
    200e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2011:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    2016:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    201b:	ff 36 80 04          	push   WORD PTR ds:0x480
    201f:	6a 67                	push   0x67
    2021:	55                   	push   bp
    2022:	9a 5e 1a 47 20       	call   0x2047:0x1a5e
    2027:	8d be 00 ff          	lea    di,[bp-0x100]
    202b:	16                   	push   ss
    202c:	57                   	push   di
    202d:	68 ff 00             	push   0xff
    2030:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2033:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    2038:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    203d:	ff 36 84 04          	push   WORD PTR ds:0x484
    2041:	6a 64                	push   0x64
    2043:	55                   	push   bp
    2044:	9a 5e 1a 8d 20       	call   0x208d:0x1a5e
    2049:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    204e:	76 18                	jbe    0x2068
    2050:	8d be 00 ff          	lea    di,[bp-0x100]
    2054:	16                   	push   ss
    2055:	57                   	push   di
    2056:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    205a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    205f:	06                   	push   es
    2060:	57                   	push   di
    2061:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2064:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2068:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    206d:	8d be 00 ff          	lea    di,[bp-0x100]
    2071:	16                   	push   ss
    2072:	57                   	push   di
    2073:	68 ff 00             	push   0xff
    2076:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2079:	26 ff b5 d6 01       	push   WORD PTR es:[di+0x1d6]
    207e:	26 ff b5 d4 01       	push   WORD PTR es:[di+0x1d4]
    2083:	ff 36 80 04          	push   WORD PTR ds:0x480
    2087:	6a 67                	push   0x67
    2089:	55                   	push   bp
    208a:	9a 5e 1a af 20       	call   0x20af:0x1a5e
    208f:	8d be 00 ff          	lea    di,[bp-0x100]
    2093:	16                   	push   ss
    2094:	57                   	push   di
    2095:	68 ff 00             	push   0xff
    2098:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    209b:	26 ff b5 f2 01       	push   WORD PTR es:[di+0x1f2]
    20a0:	26 ff b5 f0 01       	push   WORD PTR es:[di+0x1f0]
    20a5:	ff 36 84 04          	push   WORD PTR ds:0x484
    20a9:	6a 64                	push   0x64
    20ab:	55                   	push   bp
    20ac:	9a 5e 1a f5 20       	call   0x20f5:0x1a5e
    20b1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    20b6:	76 18                	jbe    0x20d0
    20b8:	8d be 00 ff          	lea    di,[bp-0x100]
    20bc:	16                   	push   ss
    20bd:	57                   	push   di
    20be:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    20c2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    20c7:	06                   	push   es
    20c8:	57                   	push   di
    20c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20cc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    20d0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    20d5:	8d be 00 ff          	lea    di,[bp-0x100]
    20d9:	16                   	push   ss
    20da:	57                   	push   di
    20db:	68 ff 00             	push   0xff
    20de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20e1:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    20e6:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    20eb:	ff 36 80 04          	push   WORD PTR ds:0x480
    20ef:	6a 67                	push   0x67
    20f1:	55                   	push   bp
    20f2:	9a 5e 1a 17 21       	call   0x2117:0x1a5e
    20f7:	8d be 00 ff          	lea    di,[bp-0x100]
    20fb:	16                   	push   ss
    20fc:	57                   	push   di
    20fd:	68 ff 00             	push   0xff
    2100:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2103:	26 ff b5 f6 01       	push   WORD PTR es:[di+0x1f6]
    2108:	26 ff b5 f4 01       	push   WORD PTR es:[di+0x1f4]
    210d:	ff 36 84 04          	push   WORD PTR ds:0x484
    2111:	6a 64                	push   0x64
    2113:	55                   	push   bp
    2114:	9a 5e 1a 5d 21       	call   0x215d:0x1a5e
    2119:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    211e:	76 18                	jbe    0x2138
    2120:	8d be 00 ff          	lea    di,[bp-0x100]
    2124:	16                   	push   ss
    2125:	57                   	push   di
    2126:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    212a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    212f:	06                   	push   es
    2130:	57                   	push   di
    2131:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2134:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2138:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    213d:	8d be 00 ff          	lea    di,[bp-0x100]
    2141:	16                   	push   ss
    2142:	57                   	push   di
    2143:	68 ff 00             	push   0xff
    2146:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2149:	26 ff b5 d2 01       	push   WORD PTR es:[di+0x1d2]
    214e:	26 ff b5 d0 01       	push   WORD PTR es:[di+0x1d0]
    2153:	ff 36 80 04          	push   WORD PTR ds:0x480
    2157:	6a 67                	push   0x67
    2159:	55                   	push   bp
    215a:	9a 5e 1a 7f 21       	call   0x217f:0x1a5e
    215f:	8d be 00 ff          	lea    di,[bp-0x100]
    2163:	16                   	push   ss
    2164:	57                   	push   di
    2165:	68 ff 00             	push   0xff
    2168:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    216b:	26 ff b5 ee 01       	push   WORD PTR es:[di+0x1ee]
    2170:	26 ff b5 ec 01       	push   WORD PTR es:[di+0x1ec]
    2175:	ff 36 84 04          	push   WORD PTR ds:0x484
    2179:	6a 64                	push   0x64
    217b:	55                   	push   bp
    217c:	9a 5e 1a c5 21       	call   0x21c5:0x1a5e
    2181:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2186:	76 18                	jbe    0x21a0
    2188:	8d be 00 ff          	lea    di,[bp-0x100]
    218c:	16                   	push   ss
    218d:	57                   	push   di
    218e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2192:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2197:	06                   	push   es
    2198:	57                   	push   di
    2199:	26 c4 3d             	les    di,DWORD PTR es:[di]
    219c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    21a0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    21a5:	8d be 00 ff          	lea    di,[bp-0x100]
    21a9:	16                   	push   ss
    21aa:	57                   	push   di
    21ab:	68 ff 00             	push   0xff
    21ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b1:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    21b6:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    21bb:	ff 36 80 04          	push   WORD PTR ds:0x480
    21bf:	6a 67                	push   0x67
    21c1:	55                   	push   bp
    21c2:	9a 5e 1a e7 21       	call   0x21e7:0x1a5e
    21c7:	8d be 00 ff          	lea    di,[bp-0x100]
    21cb:	16                   	push   ss
    21cc:	57                   	push   di
    21cd:	68 ff 00             	push   0xff
    21d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d3:	26 ff b5 e6 01       	push   WORD PTR es:[di+0x1e6]
    21d8:	26 ff b5 e4 01       	push   WORD PTR es:[di+0x1e4]
    21dd:	ff 36 84 04          	push   WORD PTR ds:0x484
    21e1:	6a 64                	push   0x64
    21e3:	55                   	push   bp
    21e4:	9a 5e 1a 2d 22       	call   0x222d:0x1a5e
    21e9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    21ee:	76 18                	jbe    0x2208
    21f0:	8d be 00 ff          	lea    di,[bp-0x100]
    21f4:	16                   	push   ss
    21f5:	57                   	push   di
    21f6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    21fa:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    21ff:	06                   	push   es
    2200:	57                   	push   di
    2201:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2204:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2208:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    220d:	8d be 00 ff          	lea    di,[bp-0x100]
    2211:	16                   	push   ss
    2212:	57                   	push   di
    2213:	68 ff 00             	push   0xff
    2216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2219:	26 ff b5 c6 01       	push   WORD PTR es:[di+0x1c6]
    221e:	26 ff b5 c4 01       	push   WORD PTR es:[di+0x1c4]
    2223:	ff 36 80 04          	push   WORD PTR ds:0x480
    2227:	6a 67                	push   0x67
    2229:	55                   	push   bp
    222a:	9a 5e 1a 4f 22       	call   0x224f:0x1a5e
    222f:	8d be 00 ff          	lea    di,[bp-0x100]
    2233:	16                   	push   ss
    2234:	57                   	push   di
    2235:	68 ff 00             	push   0xff
    2238:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223b:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    2240:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    2245:	ff 36 84 04          	push   WORD PTR ds:0x484
    2249:	6a 64                	push   0x64
    224b:	55                   	push   bp
    224c:	9a 5e 1a 95 22       	call   0x2295:0x1a5e
    2251:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2256:	76 18                	jbe    0x2270
    2258:	8d be 00 ff          	lea    di,[bp-0x100]
    225c:	16                   	push   ss
    225d:	57                   	push   di
    225e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2262:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2267:	06                   	push   es
    2268:	57                   	push   di
    2269:	26 c4 3d             	les    di,DWORD PTR es:[di]
    226c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2270:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2275:	8d be 00 ff          	lea    di,[bp-0x100]
    2279:	16                   	push   ss
    227a:	57                   	push   di
    227b:	68 ff 00             	push   0xff
    227e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2281:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    2286:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    228b:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    228f:	6a 67                	push   0x67
    2291:	55                   	push   bp
    2292:	9a 5e 1a d4 22       	call   0x22d4:0x1a5e
    2297:	8d be 00 ff          	lea    di,[bp-0x100]
    229b:	16                   	push   ss
    229c:	57                   	push   di
    229d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    22a1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    22a6:	06                   	push   es
    22a7:	57                   	push   di
    22a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22ab:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    22af:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    22b4:	8d be 00 ff          	lea    di,[bp-0x100]
    22b8:	16                   	push   ss
    22b9:	57                   	push   di
    22ba:	68 ff 00             	push   0xff
    22bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c0:	26 ff b5 fe 01       	push   WORD PTR es:[di+0x1fe]
    22c5:	26 ff b5 fc 01       	push   WORD PTR es:[di+0x1fc]
    22ca:	ff 36 80 04          	push   WORD PTR ds:0x480
    22ce:	6a 67                	push   0x67
    22d0:	55                   	push   bp
    22d1:	9a 5e 1a f6 22       	call   0x22f6:0x1a5e
    22d6:	8d be 00 ff          	lea    di,[bp-0x100]
    22da:	16                   	push   ss
    22db:	57                   	push   di
    22dc:	68 ff 00             	push   0xff
    22df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e2:	26 ff b5 06 02       	push   WORD PTR es:[di+0x206]
    22e7:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    22ec:	ff 36 84 04          	push   WORD PTR ds:0x484
    22f0:	6a 64                	push   0x64
    22f2:	55                   	push   bp
    22f3:	9a 5e 1a 3c 23       	call   0x233c:0x1a5e
    22f8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    22fd:	76 18                	jbe    0x2317
    22ff:	8d be 00 ff          	lea    di,[bp-0x100]
    2303:	16                   	push   ss
    2304:	57                   	push   di
    2305:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2309:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    230e:	06                   	push   es
    230f:	57                   	push   di
    2310:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2313:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2317:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    231c:	8d be 00 ff          	lea    di,[bp-0x100]
    2320:	16                   	push   ss
    2321:	57                   	push   di
    2322:	68 ff 00             	push   0xff
    2325:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2328:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    232d:	26 ff b5 00 02       	push   WORD PTR es:[di+0x200]
    2332:	ff 36 80 04          	push   WORD PTR ds:0x480
    2336:	6a 67                	push   0x67
    2338:	55                   	push   bp
    2339:	9a 5e 1a 5e 23       	call   0x235e:0x1a5e
    233e:	8d be 00 ff          	lea    di,[bp-0x100]
    2342:	16                   	push   ss
    2343:	57                   	push   di
    2344:	68 ff 00             	push   0xff
    2347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234a:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    234f:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    2354:	ff 36 84 04          	push   WORD PTR ds:0x484
    2358:	6a 64                	push   0x64
    235a:	55                   	push   bp
    235b:	9a 5e 1a a4 23       	call   0x23a4:0x1a5e
    2360:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2365:	76 18                	jbe    0x237f
    2367:	8d be 00 ff          	lea    di,[bp-0x100]
    236b:	16                   	push   ss
    236c:	57                   	push   di
    236d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2371:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2376:	06                   	push   es
    2377:	57                   	push   di
    2378:	26 c4 3d             	les    di,DWORD PTR es:[di]
    237b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    237f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2384:	8d be 00 ff          	lea    di,[bp-0x100]
    2388:	16                   	push   ss
    2389:	57                   	push   di
    238a:	68 ff 00             	push   0xff
    238d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2390:	26 ff b5 0e 02       	push   WORD PTR es:[di+0x20e]
    2395:	26 ff b5 0c 02       	push   WORD PTR es:[di+0x20c]
    239a:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    239e:	6a 67                	push   0x67
    23a0:	55                   	push   bp
    23a1:	9a 5e 1a c6 23       	call   0x23c6:0x1a5e
    23a6:	8d be 00 ff          	lea    di,[bp-0x100]
    23aa:	16                   	push   ss
    23ab:	57                   	push   di
    23ac:	68 ff 00             	push   0xff
    23af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b2:	26 ff b5 16 02       	push   WORD PTR es:[di+0x216]
    23b7:	26 ff b5 14 02       	push   WORD PTR es:[di+0x214]
    23bc:	ff 36 84 04          	push   WORD PTR ds:0x484
    23c0:	6a 64                	push   0x64
    23c2:	55                   	push   bp
    23c3:	9a 5e 1a e8 23       	call   0x23e8:0x1a5e
    23c8:	8d be 00 ff          	lea    di,[bp-0x100]
    23cc:	16                   	push   ss
    23cd:	57                   	push   di
    23ce:	68 ff 00             	push   0xff
    23d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d4:	26 ff b5 36 02       	push   WORD PTR es:[di+0x236]
    23d9:	26 ff b5 34 02       	push   WORD PTR es:[di+0x234]
    23de:	ff 36 86 04          	push   WORD PTR ds:0x486
    23e2:	6a 64                	push   0x64
    23e4:	55                   	push   bp
    23e5:	9a 5e 1a 2e 24       	call   0x242e:0x1a5e
    23ea:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    23ef:	76 18                	jbe    0x2409
    23f1:	8d be 00 ff          	lea    di,[bp-0x100]
    23f5:	16                   	push   ss
    23f6:	57                   	push   di
    23f7:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    23fb:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2400:	06                   	push   es
    2401:	57                   	push   di
    2402:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2405:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2409:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    240e:	8d be 00 ff          	lea    di,[bp-0x100]
    2412:	16                   	push   ss
    2413:	57                   	push   di
    2414:	68 ff 00             	push   0xff
    2417:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    241a:	26 ff b5 22 02       	push   WORD PTR es:[di+0x222]
    241f:	26 ff b5 20 02       	push   WORD PTR es:[di+0x220]
    2424:	ff 36 80 04          	push   WORD PTR ds:0x480
    2428:	6a 67                	push   0x67
    242a:	55                   	push   bp
    242b:	9a 5e 1a 50 24       	call   0x2450:0x1a5e
    2430:	8d be 00 ff          	lea    di,[bp-0x100]
    2434:	16                   	push   ss
    2435:	57                   	push   di
    2436:	68 ff 00             	push   0xff
    2439:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    243c:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    2441:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    2446:	ff 36 84 04          	push   WORD PTR ds:0x484
    244a:	6a 64                	push   0x64
    244c:	55                   	push   bp
    244d:	9a 5e 1a 72 24       	call   0x2472:0x1a5e
    2452:	8d be 00 ff          	lea    di,[bp-0x100]
    2456:	16                   	push   ss
    2457:	57                   	push   di
    2458:	68 ff 00             	push   0xff
    245b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    245e:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    2463:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    2468:	ff 36 86 04          	push   WORD PTR ds:0x486
    246c:	6a 64                	push   0x64
    246e:	55                   	push   bp
    246f:	9a 5e 1a b8 24       	call   0x24b8:0x1a5e
    2474:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2479:	76 18                	jbe    0x2493
    247b:	8d be 00 ff          	lea    di,[bp-0x100]
    247f:	16                   	push   ss
    2480:	57                   	push   di
    2481:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2485:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    248a:	06                   	push   es
    248b:	57                   	push   di
    248c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    248f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2493:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2498:	8d be 00 ff          	lea    di,[bp-0x100]
    249c:	16                   	push   ss
    249d:	57                   	push   di
    249e:	68 ff 00             	push   0xff
    24a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a4:	26 ff b5 1e 02       	push   WORD PTR es:[di+0x21e]
    24a9:	26 ff b5 1c 02       	push   WORD PTR es:[di+0x21c]
    24ae:	ff 36 80 04          	push   WORD PTR ds:0x480
    24b2:	6a 67                	push   0x67
    24b4:	55                   	push   bp
    24b5:	9a 5e 1a da 24       	call   0x24da:0x1a5e
    24ba:	8d be 00 ff          	lea    di,[bp-0x100]
    24be:	16                   	push   ss
    24bf:	57                   	push   di
    24c0:	68 ff 00             	push   0xff
    24c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c6:	26 ff b5 2a 02       	push   WORD PTR es:[di+0x22a]
    24cb:	26 ff b5 28 02       	push   WORD PTR es:[di+0x228]
    24d0:	ff 36 84 04          	push   WORD PTR ds:0x484
    24d4:	6a 64                	push   0x64
    24d6:	55                   	push   bp
    24d7:	9a 5e 1a fc 24       	call   0x24fc:0x1a5e
    24dc:	8d be 00 ff          	lea    di,[bp-0x100]
    24e0:	16                   	push   ss
    24e1:	57                   	push   di
    24e2:	68 ff 00             	push   0xff
    24e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e8:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    24ed:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    24f2:	ff 36 86 04          	push   WORD PTR ds:0x486
    24f6:	6a 64                	push   0x64
    24f8:	55                   	push   bp
    24f9:	9a 5e 1a 42 25       	call   0x2542:0x1a5e
    24fe:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2503:	76 18                	jbe    0x251d
    2505:	8d be 00 ff          	lea    di,[bp-0x100]
    2509:	16                   	push   ss
    250a:	57                   	push   di
    250b:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    250f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2514:	06                   	push   es
    2515:	57                   	push   di
    2516:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2519:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    251d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2522:	8d be 00 ff          	lea    di,[bp-0x100]
    2526:	16                   	push   ss
    2527:	57                   	push   di
    2528:	68 ff 00             	push   0xff
    252b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    252e:	26 ff b5 1a 02       	push   WORD PTR es:[di+0x21a]
    2533:	26 ff b5 18 02       	push   WORD PTR es:[di+0x218]
    2538:	ff 36 80 04          	push   WORD PTR ds:0x480
    253c:	6a 67                	push   0x67
    253e:	55                   	push   bp
    253f:	9a 5e 1a 64 25       	call   0x2564:0x1a5e
    2544:	8d be 00 ff          	lea    di,[bp-0x100]
    2548:	16                   	push   ss
    2549:	57                   	push   di
    254a:	68 ff 00             	push   0xff
    254d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2550:	26 ff b5 2e 02       	push   WORD PTR es:[di+0x22e]
    2555:	26 ff b5 2c 02       	push   WORD PTR es:[di+0x22c]
    255a:	ff 36 84 04          	push   WORD PTR ds:0x484
    255e:	6a 64                	push   0x64
    2560:	55                   	push   bp
    2561:	9a 5e 1a 86 25       	call   0x2586:0x1a5e
    2566:	8d be 00 ff          	lea    di,[bp-0x100]
    256a:	16                   	push   ss
    256b:	57                   	push   di
    256c:	68 ff 00             	push   0xff
    256f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2572:	26 ff b5 42 02       	push   WORD PTR es:[di+0x242]
    2577:	26 ff b5 40 02       	push   WORD PTR es:[di+0x240]
    257c:	ff 36 86 04          	push   WORD PTR ds:0x486
    2580:	6a 64                	push   0x64
    2582:	55                   	push   bp
    2583:	9a 5e 1a cc 25       	call   0x25cc:0x1a5e
    2588:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    258d:	76 18                	jbe    0x25a7
    258f:	8d be 00 ff          	lea    di,[bp-0x100]
    2593:	16                   	push   ss
    2594:	57                   	push   di
    2595:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2599:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    259e:	06                   	push   es
    259f:	57                   	push   di
    25a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25a3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    25a7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    25ac:	8d be 00 ff          	lea    di,[bp-0x100]
    25b0:	16                   	push   ss
    25b1:	57                   	push   di
    25b2:	68 ff 00             	push   0xff
    25b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b8:	26 ff b5 4e 02       	push   WORD PTR es:[di+0x24e]
    25bd:	26 ff b5 4c 02       	push   WORD PTR es:[di+0x24c]
    25c2:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    25c6:	6a 67                	push   0x67
    25c8:	55                   	push   bp
    25c9:	9a 5e 1a 0b 26       	call   0x260b:0x1a5e
    25ce:	8d be 00 ff          	lea    di,[bp-0x100]
    25d2:	16                   	push   ss
    25d3:	57                   	push   di
    25d4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    25d8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    25dd:	06                   	push   es
    25de:	57                   	push   di
    25df:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25e2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    25e6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    25eb:	8d be 00 ff          	lea    di,[bp-0x100]
    25ef:	16                   	push   ss
    25f0:	57                   	push   di
    25f1:	68 ff 00             	push   0xff
    25f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f7:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    25fc:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    2601:	ff 36 80 04          	push   WORD PTR ds:0x480
    2605:	6a 67                	push   0x67
    2607:	55                   	push   bp
    2608:	9a 5e 1a 2d 26       	call   0x262d:0x1a5e
    260d:	8d be 00 ff          	lea    di,[bp-0x100]
    2611:	16                   	push   ss
    2612:	57                   	push   di
    2613:	68 ff 00             	push   0xff
    2616:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2619:	26 ff b5 5e 02       	push   WORD PTR es:[di+0x25e]
    261e:	26 ff b5 5c 02       	push   WORD PTR es:[di+0x25c]
    2623:	ff 36 84 04          	push   WORD PTR ds:0x484
    2627:	6a 64                	push   0x64
    2629:	55                   	push   bp
    262a:	9a 5e 1a 73 26       	call   0x2673:0x1a5e
    262f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2634:	76 18                	jbe    0x264e
    2636:	8d be 00 ff          	lea    di,[bp-0x100]
    263a:	16                   	push   ss
    263b:	57                   	push   di
    263c:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2640:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2645:	06                   	push   es
    2646:	57                   	push   di
    2647:	26 c4 3d             	les    di,DWORD PTR es:[di]
    264a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    264e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2653:	8d be 00 ff          	lea    di,[bp-0x100]
    2657:	16                   	push   ss
    2658:	57                   	push   di
    2659:	68 ff 00             	push   0xff
    265c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    265f:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    2664:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    2669:	ff 36 80 04          	push   WORD PTR ds:0x480
    266d:	6a 67                	push   0x67
    266f:	55                   	push   bp
    2670:	9a 5e 1a 95 26       	call   0x2695:0x1a5e
    2675:	8d be 00 ff          	lea    di,[bp-0x100]
    2679:	16                   	push   ss
    267a:	57                   	push   di
    267b:	68 ff 00             	push   0xff
    267e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2681:	26 ff b5 5a 02       	push   WORD PTR es:[di+0x25a]
    2686:	26 ff b5 58 02       	push   WORD PTR es:[di+0x258]
    268b:	ff 36 84 04          	push   WORD PTR ds:0x484
    268f:	6a 64                	push   0x64
    2691:	55                   	push   bp
    2692:	9a 5e 1a db 26       	call   0x26db:0x1a5e
    2697:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    269c:	76 18                	jbe    0x26b6
    269e:	8d be 00 ff          	lea    di,[bp-0x100]
    26a2:	16                   	push   ss
    26a3:	57                   	push   di
    26a4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    26a8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    26ad:	06                   	push   es
    26ae:	57                   	push   di
    26af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26b2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    26b6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    26bb:	8d be 00 ff          	lea    di,[bp-0x100]
    26bf:	16                   	push   ss
    26c0:	57                   	push   di
    26c1:	68 ff 00             	push   0xff
    26c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c7:	26 ff b5 ba 03       	push   WORD PTR es:[di+0x3ba]
    26cc:	26 ff b5 b8 03       	push   WORD PTR es:[di+0x3b8]
    26d1:	ff 36 80 04          	push   WORD PTR ds:0x480
    26d5:	6a 67                	push   0x67
    26d7:	55                   	push   bp
    26d8:	9a 5e 1a fd 26       	call   0x26fd:0x1a5e
    26dd:	8d be 00 ff          	lea    di,[bp-0x100]
    26e1:	16                   	push   ss
    26e2:	57                   	push   di
    26e3:	68 ff 00             	push   0xff
    26e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e9:	26 ff b5 be 03       	push   WORD PTR es:[di+0x3be]
    26ee:	26 ff b5 bc 03       	push   WORD PTR es:[di+0x3bc]
    26f3:	ff 36 84 04          	push   WORD PTR ds:0x484
    26f7:	6a 64                	push   0x64
    26f9:	55                   	push   bp
    26fa:	9a 5e 1a 43 27       	call   0x2743:0x1a5e
    26ff:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2704:	76 18                	jbe    0x271e
    2706:	8d be 00 ff          	lea    di,[bp-0x100]
    270a:	16                   	push   ss
    270b:	57                   	push   di
    270c:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2710:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2715:	06                   	push   es
    2716:	57                   	push   di
    2717:	26 c4 3d             	les    di,DWORD PTR es:[di]
    271a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    271e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2723:	8d be 00 ff          	lea    di,[bp-0x100]
    2727:	16                   	push   ss
    2728:	57                   	push   di
    2729:	68 ff 00             	push   0xff
    272c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    272f:	26 ff b5 62 02       	push   WORD PTR es:[di+0x262]
    2734:	26 ff b5 60 02       	push   WORD PTR es:[di+0x260]
    2739:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    273d:	6a 67                	push   0x67
    273f:	55                   	push   bp
    2740:	9a 5e 1a 65 27       	call   0x2765:0x1a5e
    2745:	8d be 00 ff          	lea    di,[bp-0x100]
    2749:	16                   	push   ss
    274a:	57                   	push   di
    274b:	68 ff 00             	push   0xff
    274e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2751:	26 ff b5 6a 02       	push   WORD PTR es:[di+0x26a]
    2756:	26 ff b5 68 02       	push   WORD PTR es:[di+0x268]
    275b:	ff 36 84 04          	push   WORD PTR ds:0x484
    275f:	6a 64                	push   0x64
    2761:	55                   	push   bp
    2762:	9a 5e 1a 87 27       	call   0x2787:0x1a5e
    2767:	8d be 00 ff          	lea    di,[bp-0x100]
    276b:	16                   	push   ss
    276c:	57                   	push   di
    276d:	68 ff 00             	push   0xff
    2770:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2773:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    2778:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    277d:	ff 36 86 04          	push   WORD PTR ds:0x486
    2781:	6a 64                	push   0x64
    2783:	55                   	push   bp
    2784:	9a 5e 1a cd 27       	call   0x27cd:0x1a5e
    2789:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    278e:	76 18                	jbe    0x27a8
    2790:	8d be 00 ff          	lea    di,[bp-0x100]
    2794:	16                   	push   ss
    2795:	57                   	push   di
    2796:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    279a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    279f:	06                   	push   es
    27a0:	57                   	push   di
    27a1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27a4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    27a8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    27ad:	8d be 00 ff          	lea    di,[bp-0x100]
    27b1:	16                   	push   ss
    27b2:	57                   	push   di
    27b3:	68 ff 00             	push   0xff
    27b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b9:	26 ff b5 6e 02       	push   WORD PTR es:[di+0x26e]
    27be:	26 ff b5 6c 02       	push   WORD PTR es:[di+0x26c]
    27c3:	ff 36 80 04          	push   WORD PTR ds:0x480
    27c7:	6a 67                	push   0x67
    27c9:	55                   	push   bp
    27ca:	9a 5e 1a ef 27       	call   0x27ef:0x1a5e
    27cf:	8d be 00 ff          	lea    di,[bp-0x100]
    27d3:	16                   	push   ss
    27d4:	57                   	push   di
    27d5:	68 ff 00             	push   0xff
    27d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27db:	26 ff b5 72 02       	push   WORD PTR es:[di+0x272]
    27e0:	26 ff b5 70 02       	push   WORD PTR es:[di+0x270]
    27e5:	ff 36 84 04          	push   WORD PTR ds:0x484
    27e9:	6a 64                	push   0x64
    27eb:	55                   	push   bp
    27ec:	9a 5e 1a 11 28       	call   0x2811:0x1a5e
    27f1:	8d be 00 ff          	lea    di,[bp-0x100]
    27f5:	16                   	push   ss
    27f6:	57                   	push   di
    27f7:	68 ff 00             	push   0xff
    27fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fd:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    2802:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    2807:	ff 36 86 04          	push   WORD PTR ds:0x486
    280b:	6a 64                	push   0x64
    280d:	55                   	push   bp
    280e:	9a 5e 1a 57 28       	call   0x2857:0x1a5e
    2813:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2818:	76 18                	jbe    0x2832
    281a:	8d be 00 ff          	lea    di,[bp-0x100]
    281e:	16                   	push   ss
    281f:	57                   	push   di
    2820:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2824:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2829:	06                   	push   es
    282a:	57                   	push   di
    282b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    282e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2832:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2837:	8d be 00 ff          	lea    di,[bp-0x100]
    283b:	16                   	push   ss
    283c:	57                   	push   di
    283d:	68 ff 00             	push   0xff
    2840:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2843:	26 ff b5 b6 02       	push   WORD PTR es:[di+0x2b6]
    2848:	26 ff b5 b4 02       	push   WORD PTR es:[di+0x2b4]
    284d:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    2851:	6a 67                	push   0x67
    2853:	55                   	push   bp
    2854:	9a 5e 1a 96 28       	call   0x2896:0x1a5e
    2859:	8d be 00 ff          	lea    di,[bp-0x100]
    285d:	16                   	push   ss
    285e:	57                   	push   di
    285f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2863:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2868:	06                   	push   es
    2869:	57                   	push   di
    286a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    286d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2871:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2876:	8d be 00 ff          	lea    di,[bp-0x100]
    287a:	16                   	push   ss
    287b:	57                   	push   di
    287c:	68 ff 00             	push   0xff
    287f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2882:	26 ff b5 ba 02       	push   WORD PTR es:[di+0x2ba]
    2887:	26 ff b5 b8 02       	push   WORD PTR es:[di+0x2b8]
    288c:	ff 36 80 04          	push   WORD PTR ds:0x480
    2890:	6a 67                	push   0x67
    2892:	55                   	push   bp
    2893:	9a 5e 1a b8 28       	call   0x28b8:0x1a5e
    2898:	8d be 00 ff          	lea    di,[bp-0x100]
    289c:	16                   	push   ss
    289d:	57                   	push   di
    289e:	68 ff 00             	push   0xff
    28a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28a4:	26 ff b5 c6 02       	push   WORD PTR es:[di+0x2c6]
    28a9:	26 ff b5 c4 02       	push   WORD PTR es:[di+0x2c4]
    28ae:	ff 36 84 04          	push   WORD PTR ds:0x484
    28b2:	6a 64                	push   0x64
    28b4:	55                   	push   bp
    28b5:	9a 5e 1a fe 28       	call   0x28fe:0x1a5e
    28ba:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    28bf:	76 18                	jbe    0x28d9
    28c1:	8d be 00 ff          	lea    di,[bp-0x100]
    28c5:	16                   	push   ss
    28c6:	57                   	push   di
    28c7:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    28cb:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    28d0:	06                   	push   es
    28d1:	57                   	push   di
    28d2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28d5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    28d9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    28de:	8d be 00 ff          	lea    di,[bp-0x100]
    28e2:	16                   	push   ss
    28e3:	57                   	push   di
    28e4:	68 ff 00             	push   0xff
    28e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ea:	26 ff b5 be 02       	push   WORD PTR es:[di+0x2be]
    28ef:	26 ff b5 bc 02       	push   WORD PTR es:[di+0x2bc]
    28f4:	ff 36 80 04          	push   WORD PTR ds:0x480
    28f8:	6a 67                	push   0x67
    28fa:	55                   	push   bp
    28fb:	9a 5e 1a 20 29       	call   0x2920:0x1a5e
    2900:	8d be 00 ff          	lea    di,[bp-0x100]
    2904:	16                   	push   ss
    2905:	57                   	push   di
    2906:	68 ff 00             	push   0xff
    2909:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290c:	26 ff b5 ca 02       	push   WORD PTR es:[di+0x2ca]
    2911:	26 ff b5 c8 02       	push   WORD PTR es:[di+0x2c8]
    2916:	ff 36 84 04          	push   WORD PTR ds:0x484
    291a:	6a 64                	push   0x64
    291c:	55                   	push   bp
    291d:	9a 5e 1a 66 29       	call   0x2966:0x1a5e
    2922:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2927:	76 18                	jbe    0x2941
    2929:	8d be 00 ff          	lea    di,[bp-0x100]
    292d:	16                   	push   ss
    292e:	57                   	push   di
    292f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2933:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2938:	06                   	push   es
    2939:	57                   	push   di
    293a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    293d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2941:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2946:	8d be 00 ff          	lea    di,[bp-0x100]
    294a:	16                   	push   ss
    294b:	57                   	push   di
    294c:	68 ff 00             	push   0xff
    294f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2952:	26 ff b5 c2 02       	push   WORD PTR es:[di+0x2c2]
    2957:	26 ff b5 c0 02       	push   WORD PTR es:[di+0x2c0]
    295c:	ff 36 80 04          	push   WORD PTR ds:0x480
    2960:	6a 67                	push   0x67
    2962:	55                   	push   bp
    2963:	9a 5e 1a 88 29       	call   0x2988:0x1a5e
    2968:	8d be 00 ff          	lea    di,[bp-0x100]
    296c:	16                   	push   ss
    296d:	57                   	push   di
    296e:	68 ff 00             	push   0xff
    2971:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2974:	26 ff b5 ce 02       	push   WORD PTR es:[di+0x2ce]
    2979:	26 ff b5 cc 02       	push   WORD PTR es:[di+0x2cc]
    297e:	ff 36 84 04          	push   WORD PTR ds:0x484
    2982:	6a 64                	push   0x64
    2984:	55                   	push   bp
    2985:	9a 5e 1a ce 29       	call   0x29ce:0x1a5e
    298a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    298f:	76 18                	jbe    0x29a9
    2991:	8d be 00 ff          	lea    di,[bp-0x100]
    2995:	16                   	push   ss
    2996:	57                   	push   di
    2997:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    299b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    29a0:	06                   	push   es
    29a1:	57                   	push   di
    29a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29a5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    29a9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    29ae:	8d be 00 ff          	lea    di,[bp-0x100]
    29b2:	16                   	push   ss
    29b3:	57                   	push   di
    29b4:	68 ff 00             	push   0xff
    29b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ba:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    29bf:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    29c4:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    29c8:	6a 67                	push   0x67
    29ca:	55                   	push   bp
    29cb:	9a 5e 1a 0d 2a       	call   0x2a0d:0x1a5e
    29d0:	8d be 00 ff          	lea    di,[bp-0x100]
    29d4:	16                   	push   ss
    29d5:	57                   	push   di
    29d6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    29da:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    29df:	06                   	push   es
    29e0:	57                   	push   di
    29e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29e4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    29e8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    29ed:	8d be 00 ff          	lea    di,[bp-0x100]
    29f1:	16                   	push   ss
    29f2:	57                   	push   di
    29f3:	68 ff 00             	push   0xff
    29f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f9:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    29fe:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    2a03:	ff 36 80 04          	push   WORD PTR ds:0x480
    2a07:	6a 67                	push   0x67
    2a09:	55                   	push   bp
    2a0a:	9a 5e 1a 2f 2a       	call   0x2a2f:0x1a5e
    2a0f:	8d be 00 ff          	lea    di,[bp-0x100]
    2a13:	16                   	push   ss
    2a14:	57                   	push   di
    2a15:	68 ff 00             	push   0xff
    2a18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a1b:	26 ff b5 9e 02       	push   WORD PTR es:[di+0x29e]
    2a20:	26 ff b5 9c 02       	push   WORD PTR es:[di+0x29c]
    2a25:	ff 36 84 04          	push   WORD PTR ds:0x484
    2a29:	6a 64                	push   0x64
    2a2b:	55                   	push   bp
    2a2c:	9a 5e 1a 75 2a       	call   0x2a75:0x1a5e
    2a31:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2a36:	76 18                	jbe    0x2a50
    2a38:	8d be 00 ff          	lea    di,[bp-0x100]
    2a3c:	16                   	push   ss
    2a3d:	57                   	push   di
    2a3e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a42:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a47:	06                   	push   es
    2a48:	57                   	push   di
    2a49:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a4c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2a50:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2a55:	8d be 00 ff          	lea    di,[bp-0x100]
    2a59:	16                   	push   ss
    2a5a:	57                   	push   di
    2a5b:	68 ff 00             	push   0xff
    2a5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a61:	26 ff b5 8a 02       	push   WORD PTR es:[di+0x28a]
    2a66:	26 ff b5 88 02       	push   WORD PTR es:[di+0x288]
    2a6b:	ff 36 80 04          	push   WORD PTR ds:0x480
    2a6f:	6a 67                	push   0x67
    2a71:	55                   	push   bp
    2a72:	9a 5e 1a 97 2a       	call   0x2a97:0x1a5e
    2a77:	8d be 00 ff          	lea    di,[bp-0x100]
    2a7b:	16                   	push   ss
    2a7c:	57                   	push   di
    2a7d:	68 ff 00             	push   0xff
    2a80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a83:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    2a88:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    2a8d:	ff 36 84 04          	push   WORD PTR ds:0x484
    2a91:	6a 64                	push   0x64
    2a93:	55                   	push   bp
    2a94:	9a 5e 1a dd 2a       	call   0x2add:0x1a5e
    2a99:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2a9e:	76 18                	jbe    0x2ab8
    2aa0:	8d be 00 ff          	lea    di,[bp-0x100]
    2aa4:	16                   	push   ss
    2aa5:	57                   	push   di
    2aa6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2aaa:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2aaf:	06                   	push   es
    2ab0:	57                   	push   di
    2ab1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ab4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2ab8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2abd:	8d be 00 ff          	lea    di,[bp-0x100]
    2ac1:	16                   	push   ss
    2ac2:	57                   	push   di
    2ac3:	68 ff 00             	push   0xff
    2ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac9:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    2ace:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    2ad3:	ff 36 80 04          	push   WORD PTR ds:0x480
    2ad7:	6a 67                	push   0x67
    2ad9:	55                   	push   bp
    2ada:	9a 5e 1a ff 2a       	call   0x2aff:0x1a5e
    2adf:	8d be 00 ff          	lea    di,[bp-0x100]
    2ae3:	16                   	push   ss
    2ae4:	57                   	push   di
    2ae5:	68 ff 00             	push   0xff
    2ae8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aeb:	26 ff b5 a6 02       	push   WORD PTR es:[di+0x2a6]
    2af0:	26 ff b5 a4 02       	push   WORD PTR es:[di+0x2a4]
    2af5:	ff 36 84 04          	push   WORD PTR ds:0x484
    2af9:	6a 64                	push   0x64
    2afb:	55                   	push   bp
    2afc:	9a 5e 1a 45 2b       	call   0x2b45:0x1a5e
    2b01:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2b06:	76 18                	jbe    0x2b20
    2b08:	8d be 00 ff          	lea    di,[bp-0x100]
    2b0c:	16                   	push   ss
    2b0d:	57                   	push   di
    2b0e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2b12:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b17:	06                   	push   es
    2b18:	57                   	push   di
    2b19:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b1c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b20:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2b25:	8d be 00 ff          	lea    di,[bp-0x100]
    2b29:	16                   	push   ss
    2b2a:	57                   	push   di
    2b2b:	68 ff 00             	push   0xff
    2b2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b31:	26 ff b5 9a 02       	push   WORD PTR es:[di+0x29a]
    2b36:	26 ff b5 98 02       	push   WORD PTR es:[di+0x298]
    2b3b:	ff 36 80 04          	push   WORD PTR ds:0x480
    2b3f:	6a 67                	push   0x67
    2b41:	55                   	push   bp
    2b42:	9a 5e 1a 67 2b       	call   0x2b67:0x1a5e
    2b47:	8d be 00 ff          	lea    di,[bp-0x100]
    2b4b:	16                   	push   ss
    2b4c:	57                   	push   di
    2b4d:	68 ff 00             	push   0xff
    2b50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b53:	26 ff b5 b2 02       	push   WORD PTR es:[di+0x2b2]
    2b58:	26 ff b5 b0 02       	push   WORD PTR es:[di+0x2b0]
    2b5d:	ff 36 84 04          	push   WORD PTR ds:0x484
    2b61:	6a 64                	push   0x64
    2b63:	55                   	push   bp
    2b64:	9a 5e 1a ad 2b       	call   0x2bad:0x1a5e
    2b69:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2b6e:	76 18                	jbe    0x2b88
    2b70:	8d be 00 ff          	lea    di,[bp-0x100]
    2b74:	16                   	push   ss
    2b75:	57                   	push   di
    2b76:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2b7a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b7f:	06                   	push   es
    2b80:	57                   	push   di
    2b81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b84:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b88:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2b8d:	8d be 00 ff          	lea    di,[bp-0x100]
    2b91:	16                   	push   ss
    2b92:	57                   	push   di
    2b93:	68 ff 00             	push   0xff
    2b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b99:	26 ff b5 92 02       	push   WORD PTR es:[di+0x292]
    2b9e:	26 ff b5 90 02       	push   WORD PTR es:[di+0x290]
    2ba3:	ff 36 80 04          	push   WORD PTR ds:0x480
    2ba7:	6a 67                	push   0x67
    2ba9:	55                   	push   bp
    2baa:	9a 5e 1a cf 2b       	call   0x2bcf:0x1a5e
    2baf:	8d be 00 ff          	lea    di,[bp-0x100]
    2bb3:	16                   	push   ss
    2bb4:	57                   	push   di
    2bb5:	68 ff 00             	push   0xff
    2bb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bbb:	26 ff b5 aa 02       	push   WORD PTR es:[di+0x2aa]
    2bc0:	26 ff b5 a8 02       	push   WORD PTR es:[di+0x2a8]
    2bc5:	ff 36 84 04          	push   WORD PTR ds:0x484
    2bc9:	6a 64                	push   0x64
    2bcb:	55                   	push   bp
    2bcc:	9a 5e 1a 15 2c       	call   0x2c15:0x1a5e
    2bd1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2bd6:	76 18                	jbe    0x2bf0
    2bd8:	8d be 00 ff          	lea    di,[bp-0x100]
    2bdc:	16                   	push   ss
    2bdd:	57                   	push   di
    2bde:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2be2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2be7:	06                   	push   es
    2be8:	57                   	push   di
    2be9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bec:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2bf0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2bf5:	8d be 00 ff          	lea    di,[bp-0x100]
    2bf9:	16                   	push   ss
    2bfa:	57                   	push   di
    2bfb:	68 ff 00             	push   0xff
    2bfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c01:	26 ff b5 96 02       	push   WORD PTR es:[di+0x296]
    2c06:	26 ff b5 94 02       	push   WORD PTR es:[di+0x294]
    2c0b:	ff 36 80 04          	push   WORD PTR ds:0x480
    2c0f:	6a 67                	push   0x67
    2c11:	55                   	push   bp
    2c12:	9a 5e 1a 37 2c       	call   0x2c37:0x1a5e
    2c17:	8d be 00 ff          	lea    di,[bp-0x100]
    2c1b:	16                   	push   ss
    2c1c:	57                   	push   di
    2c1d:	68 ff 00             	push   0xff
    2c20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c23:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    2c28:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    2c2d:	ff 36 84 04          	push   WORD PTR ds:0x484
    2c31:	6a 64                	push   0x64
    2c33:	55                   	push   bp
    2c34:	9a 5e 1a 7d 2c       	call   0x2c7d:0x1a5e
    2c39:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2c3e:	76 18                	jbe    0x2c58
    2c40:	8d be 00 ff          	lea    di,[bp-0x100]
    2c44:	16                   	push   ss
    2c45:	57                   	push   di
    2c46:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2c4a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2c4f:	06                   	push   es
    2c50:	57                   	push   di
    2c51:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c54:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2c58:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2c5d:	8d be 00 ff          	lea    di,[bp-0x100]
    2c61:	16                   	push   ss
    2c62:	57                   	push   di
    2c63:	68 ff 00             	push   0xff
    2c66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c69:	26 ff b5 d6 02       	push   WORD PTR es:[di+0x2d6]
    2c6e:	26 ff b5 d4 02       	push   WORD PTR es:[di+0x2d4]
    2c73:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    2c77:	6a 67                	push   0x67
    2c79:	55                   	push   bp
    2c7a:	9a 5e 1a 9f 2c       	call   0x2c9f:0x1a5e
    2c7f:	8d be 00 ff          	lea    di,[bp-0x100]
    2c83:	16                   	push   ss
    2c84:	57                   	push   di
    2c85:	68 ff 00             	push   0xff
    2c88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c8b:	26 ff b5 da 02       	push   WORD PTR es:[di+0x2da]
    2c90:	26 ff b5 d8 02       	push   WORD PTR es:[di+0x2d8]
    2c95:	ff 36 84 04          	push   WORD PTR ds:0x484
    2c99:	6a 64                	push   0x64
    2c9b:	55                   	push   bp
    2c9c:	9a 5e 1a e5 2c       	call   0x2ce5:0x1a5e
    2ca1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2ca6:	76 18                	jbe    0x2cc0
    2ca8:	8d be 00 ff          	lea    di,[bp-0x100]
    2cac:	16                   	push   ss
    2cad:	57                   	push   di
    2cae:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2cb2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2cb7:	06                   	push   es
    2cb8:	57                   	push   di
    2cb9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cbc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2cc0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2cc5:	8d be 00 ff          	lea    di,[bp-0x100]
    2cc9:	16                   	push   ss
    2cca:	57                   	push   di
    2ccb:	68 ff 00             	push   0xff
    2cce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cd1:	26 ff b5 de 02       	push   WORD PTR es:[di+0x2de]
    2cd6:	26 ff b5 dc 02       	push   WORD PTR es:[di+0x2dc]
    2cdb:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    2cdf:	6a 67                	push   0x67
    2ce1:	55                   	push   bp
    2ce2:	9a 5e 1a 4a 2d       	call   0x2d4a:0x1a5e
    2ce7:	8d be fa fd          	lea    di,[bp-0x206]
    2ceb:	16                   	push   ss
    2cec:	57                   	push   di
    2ced:	8d be 00 ff          	lea    di,[bp-0x100]
    2cf1:	16                   	push   ss
    2cf2:	57                   	push   di
    2cf3:	9a cd 17 00 2d       	call   0x2d00:0x17cd
    2cf8:	bf 1e 1e             	mov    di,0x1e1e
    2cfb:	0e                   	push   cs
    2cfc:	57                   	push   di
    2cfd:	9a 4c 18 1a 2d       	call   0x2d1a:0x184c
    2d02:	8d be fa fc          	lea    di,[bp-0x306]
    2d06:	16                   	push   ss
    2d07:	57                   	push   di
    2d08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d0b:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    2d10:	06                   	push   es
    2d11:	57                   	push   di
    2d12:	9a 53 1d dd 2d       	call   0x2ddd:0x1d53
    2d17:	9a 4c 18 28 2d       	call   0x2d28:0x184c
    2d1c:	8d be 00 ff          	lea    di,[bp-0x100]
    2d20:	16                   	push   ss
    2d21:	57                   	push   di
    2d22:	68 ff 00             	push   0xff
    2d25:	9a e7 17 be 2d       	call   0x2dbe:0x17e7
    2d2a:	8d be 00 ff          	lea    di,[bp-0x100]
    2d2e:	16                   	push   ss
    2d2f:	57                   	push   di
    2d30:	68 ff 00             	push   0xff
    2d33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d36:	26 ff b5 e6 02       	push   WORD PTR es:[di+0x2e6]
    2d3b:	26 ff b5 e4 02       	push   WORD PTR es:[di+0x2e4]
    2d40:	ff 36 84 04          	push   WORD PTR ds:0x484
    2d44:	6a 64                	push   0x64
    2d46:	55                   	push   bp
    2d47:	9a 5e 1a ad 2d       	call   0x2dad:0x1a5e
    2d4c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2d51:	76 18                	jbe    0x2d6b
    2d53:	8d be 00 ff          	lea    di,[bp-0x100]
    2d57:	16                   	push   ss
    2d58:	57                   	push   di
    2d59:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2d5d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2d62:	06                   	push   es
    2d63:	57                   	push   di
    2d64:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d67:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2d6b:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2d6f:	75 17                	jne    0x2d88
    2d71:	bf 1b 1e             	mov    di,0x1e1b
    2d74:	0e                   	push   cs
    2d75:	57                   	push   di
    2d76:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2d7a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2d7f:	06                   	push   es
    2d80:	57                   	push   di
    2d81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d84:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2d88:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2d8d:	8d be 00 ff          	lea    di,[bp-0x100]
    2d91:	16                   	push   ss
    2d92:	57                   	push   di
    2d93:	68 ff 00             	push   0xff
    2d96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d99:	26 ff b5 66 03       	push   WORD PTR es:[di+0x366]
    2d9e:	26 ff b5 64 03       	push   WORD PTR es:[di+0x364]
    2da3:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    2da7:	6a 67                	push   0x67
    2da9:	55                   	push   bp
    2daa:	9a 5e 1a 12 2e       	call   0x2e12:0x1a5e
    2daf:	8d be fa fd          	lea    di,[bp-0x206]
    2db3:	16                   	push   ss
    2db4:	57                   	push   di
    2db5:	8d be 00 ff          	lea    di,[bp-0x100]
    2db9:	16                   	push   ss
    2dba:	57                   	push   di
    2dbb:	9a cd 17 c8 2d       	call   0x2dc8:0x17cd
    2dc0:	bf 1e 1e             	mov    di,0x1e1e
    2dc3:	0e                   	push   cs
    2dc4:	57                   	push   di
    2dc5:	9a 4c 18 e2 2d       	call   0x2de2:0x184c
    2dca:	8d be fa fc          	lea    di,[bp-0x306]
    2dce:	16                   	push   ss
    2dcf:	57                   	push   di
    2dd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd3:	26 c4 bd 68 03       	les    di,DWORD PTR es:[di+0x368]
    2dd8:	06                   	push   es
    2dd9:	57                   	push   di
    2dda:	9a 53 1d 8d 32       	call   0x328d:0x1d53
    2ddf:	9a 4c 18 f0 2d       	call   0x2df0:0x184c
    2de4:	8d be 00 ff          	lea    di,[bp-0x100]
    2de8:	16                   	push   ss
    2de9:	57                   	push   di
    2dea:	68 ff 00             	push   0xff
    2ded:	9a e7 17 9b 32       	call   0x329b:0x17e7
    2df2:	8d be 00 ff          	lea    di,[bp-0x100]
    2df6:	16                   	push   ss
    2df7:	57                   	push   di
    2df8:	68 ff 00             	push   0xff
    2dfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dfe:	26 ff b5 6e 03       	push   WORD PTR es:[di+0x36e]
    2e03:	26 ff b5 6c 03       	push   WORD PTR es:[di+0x36c]
    2e08:	ff 36 84 04          	push   WORD PTR ds:0x484
    2e0c:	6a 64                	push   0x64
    2e0e:	55                   	push   bp
    2e0f:	9a 5e 1a 58 2e       	call   0x2e58:0x1a5e
    2e14:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2e19:	76 18                	jbe    0x2e33
    2e1b:	8d be 00 ff          	lea    di,[bp-0x100]
    2e1f:	16                   	push   ss
    2e20:	57                   	push   di
    2e21:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e25:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2e2a:	06                   	push   es
    2e2b:	57                   	push   di
    2e2c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e2f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2e33:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2e38:	8d be 00 ff          	lea    di,[bp-0x100]
    2e3c:	16                   	push   ss
    2e3d:	57                   	push   di
    2e3e:	68 ff 00             	push   0xff
    2e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e44:	26 ff b5 56 03       	push   WORD PTR es:[di+0x356]
    2e49:	26 ff b5 54 03       	push   WORD PTR es:[di+0x354]
    2e4e:	ff 36 84 04          	push   WORD PTR ds:0x484
    2e52:	6a 64                	push   0x64
    2e54:	55                   	push   bp
    2e55:	9a 5e 1a 7a 2e       	call   0x2e7a:0x1a5e
    2e5a:	8d be 00 ff          	lea    di,[bp-0x100]
    2e5e:	16                   	push   ss
    2e5f:	57                   	push   di
    2e60:	68 ff 00             	push   0xff
    2e63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e66:	26 ff b5 5a 03       	push   WORD PTR es:[di+0x35a]
    2e6b:	26 ff b5 58 03       	push   WORD PTR es:[di+0x358]
    2e70:	ff 36 86 04          	push   WORD PTR ds:0x486
    2e74:	6a 64                	push   0x64
    2e76:	55                   	push   bp
    2e77:	9a 5e 1a c0 2e       	call   0x2ec0:0x1a5e
    2e7c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2e81:	76 18                	jbe    0x2e9b
    2e83:	8d be 00 ff          	lea    di,[bp-0x100]
    2e87:	16                   	push   ss
    2e88:	57                   	push   di
    2e89:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e8d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2e92:	06                   	push   es
    2e93:	57                   	push   di
    2e94:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e97:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2e9b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2ea0:	8d be 00 ff          	lea    di,[bp-0x100]
    2ea4:	16                   	push   ss
    2ea5:	57                   	push   di
    2ea6:	68 ff 00             	push   0xff
    2ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eac:	26 ff b5 52 03       	push   WORD PTR es:[di+0x352]
    2eb1:	26 ff b5 50 03       	push   WORD PTR es:[di+0x350]
    2eb6:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    2eba:	6a 67                	push   0x67
    2ebc:	55                   	push   bp
    2ebd:	9a 5e 1a e2 2e       	call   0x2ee2:0x1a5e
    2ec2:	8d be 00 ff          	lea    di,[bp-0x100]
    2ec6:	16                   	push   ss
    2ec7:	57                   	push   di
    2ec8:	68 ff 00             	push   0xff
    2ecb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ece:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    2ed3:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    2ed8:	ff 36 84 04          	push   WORD PTR ds:0x484
    2edc:	6a 64                	push   0x64
    2ede:	55                   	push   bp
    2edf:	9a 5e 1a 04 2f       	call   0x2f04:0x1a5e
    2ee4:	8d be 00 ff          	lea    di,[bp-0x100]
    2ee8:	16                   	push   ss
    2ee9:	57                   	push   di
    2eea:	68 ff 00             	push   0xff
    2eed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef0:	26 ff b5 62 03       	push   WORD PTR es:[di+0x362]
    2ef5:	26 ff b5 60 03       	push   WORD PTR es:[di+0x360]
    2efa:	ff 36 86 04          	push   WORD PTR ds:0x486
    2efe:	6a 64                	push   0x64
    2f00:	55                   	push   bp
    2f01:	9a 5e 1a 4a 2f       	call   0x2f4a:0x1a5e
    2f06:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2f0b:	76 18                	jbe    0x2f25
    2f0d:	8d be 00 ff          	lea    di,[bp-0x100]
    2f11:	16                   	push   ss
    2f12:	57                   	push   di
    2f13:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f17:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2f1c:	06                   	push   es
    2f1d:	57                   	push   di
    2f1e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f21:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2f25:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2f2a:	8d be 00 ff          	lea    di,[bp-0x100]
    2f2e:	16                   	push   ss
    2f2f:	57                   	push   di
    2f30:	68 ff 00             	push   0xff
    2f33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f36:	26 ff b5 f2 02       	push   WORD PTR es:[di+0x2f2]
    2f3b:	26 ff b5 f0 02       	push   WORD PTR es:[di+0x2f0]
    2f40:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    2f44:	6a 67                	push   0x67
    2f46:	55                   	push   bp
    2f47:	9a 5e 1a 90 2f       	call   0x2f90:0x1a5e
    2f4c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2f51:	76 18                	jbe    0x2f6b
    2f53:	8d be 00 ff          	lea    di,[bp-0x100]
    2f57:	16                   	push   ss
    2f58:	57                   	push   di
    2f59:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f5d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2f62:	06                   	push   es
    2f63:	57                   	push   di
    2f64:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f67:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2f6b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2f70:	8d be 00 ff          	lea    di,[bp-0x100]
    2f74:	16                   	push   ss
    2f75:	57                   	push   di
    2f76:	68 ff 00             	push   0xff
    2f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f7c:	26 ff b5 0a 03       	push   WORD PTR es:[di+0x30a]
    2f81:	26 ff b5 08 03       	push   WORD PTR es:[di+0x308]
    2f86:	ff 36 80 04          	push   WORD PTR ds:0x480
    2f8a:	6a 67                	push   0x67
    2f8c:	55                   	push   bp
    2f8d:	9a 5e 1a b2 2f       	call   0x2fb2:0x1a5e
    2f92:	8d be 00 ff          	lea    di,[bp-0x100]
    2f96:	16                   	push   ss
    2f97:	57                   	push   di
    2f98:	68 ff 00             	push   0xff
    2f9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f9e:	26 ff b5 12 03       	push   WORD PTR es:[di+0x312]
    2fa3:	26 ff b5 10 03       	push   WORD PTR es:[di+0x310]
    2fa8:	ff 36 84 04          	push   WORD PTR ds:0x484
    2fac:	6a 64                	push   0x64
    2fae:	55                   	push   bp
    2faf:	9a 5e 1a d4 2f       	call   0x2fd4:0x1a5e
    2fb4:	8d be 00 ff          	lea    di,[bp-0x100]
    2fb8:	16                   	push   ss
    2fb9:	57                   	push   di
    2fba:	68 ff 00             	push   0xff
    2fbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc0:	26 ff b5 2e 03       	push   WORD PTR es:[di+0x32e]
    2fc5:	26 ff b5 2c 03       	push   WORD PTR es:[di+0x32c]
    2fca:	ff 36 86 04          	push   WORD PTR ds:0x486
    2fce:	6a 64                	push   0x64
    2fd0:	55                   	push   bp
    2fd1:	9a 5e 1a 1a 30       	call   0x301a:0x1a5e
    2fd6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2fdb:	76 18                	jbe    0x2ff5
    2fdd:	8d be 00 ff          	lea    di,[bp-0x100]
    2fe1:	16                   	push   ss
    2fe2:	57                   	push   di
    2fe3:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2fe7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2fec:	06                   	push   es
    2fed:	57                   	push   di
    2fee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ff1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2ff5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2ffa:	8d be 00 ff          	lea    di,[bp-0x100]
    2ffe:	16                   	push   ss
    2fff:	57                   	push   di
    3000:	68 ff 00             	push   0xff
    3003:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3006:	26 ff b5 06 03       	push   WORD PTR es:[di+0x306]
    300b:	26 ff b5 04 03       	push   WORD PTR es:[di+0x304]
    3010:	ff 36 80 04          	push   WORD PTR ds:0x480
    3014:	6a 67                	push   0x67
    3016:	55                   	push   bp
    3017:	9a 5e 1a 3c 30       	call   0x303c:0x1a5e
    301c:	8d be 00 ff          	lea    di,[bp-0x100]
    3020:	16                   	push   ss
    3021:	57                   	push   di
    3022:	68 ff 00             	push   0xff
    3025:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3028:	26 ff b5 16 03       	push   WORD PTR es:[di+0x316]
    302d:	26 ff b5 14 03       	push   WORD PTR es:[di+0x314]
    3032:	ff 36 84 04          	push   WORD PTR ds:0x484
    3036:	6a 64                	push   0x64
    3038:	55                   	push   bp
    3039:	9a 5e 1a 5e 30       	call   0x305e:0x1a5e
    303e:	8d be 00 ff          	lea    di,[bp-0x100]
    3042:	16                   	push   ss
    3043:	57                   	push   di
    3044:	68 ff 00             	push   0xff
    3047:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    304a:	26 ff b5 32 03       	push   WORD PTR es:[di+0x332]
    304f:	26 ff b5 30 03       	push   WORD PTR es:[di+0x330]
    3054:	ff 36 86 04          	push   WORD PTR ds:0x486
    3058:	6a 64                	push   0x64
    305a:	55                   	push   bp
    305b:	9a 5e 1a a4 30       	call   0x30a4:0x1a5e
    3060:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3065:	76 18                	jbe    0x307f
    3067:	8d be 00 ff          	lea    di,[bp-0x100]
    306b:	16                   	push   ss
    306c:	57                   	push   di
    306d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3071:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3076:	06                   	push   es
    3077:	57                   	push   di
    3078:	26 c4 3d             	les    di,DWORD PTR es:[di]
    307b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    307f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3084:	8d be 00 ff          	lea    di,[bp-0x100]
    3088:	16                   	push   ss
    3089:	57                   	push   di
    308a:	68 ff 00             	push   0xff
    308d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3090:	26 ff b5 02 03       	push   WORD PTR es:[di+0x302]
    3095:	26 ff b5 00 03       	push   WORD PTR es:[di+0x300]
    309a:	ff 36 80 04          	push   WORD PTR ds:0x480
    309e:	6a 67                	push   0x67
    30a0:	55                   	push   bp
    30a1:	9a 5e 1a c6 30       	call   0x30c6:0x1a5e
    30a6:	8d be 00 ff          	lea    di,[bp-0x100]
    30aa:	16                   	push   ss
    30ab:	57                   	push   di
    30ac:	68 ff 00             	push   0xff
    30af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b2:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
    30b7:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    30bc:	ff 36 84 04          	push   WORD PTR ds:0x484
    30c0:	6a 64                	push   0x64
    30c2:	55                   	push   bp
    30c3:	9a 5e 1a e8 30       	call   0x30e8:0x1a5e
    30c8:	8d be 00 ff          	lea    di,[bp-0x100]
    30cc:	16                   	push   ss
    30cd:	57                   	push   di
    30ce:	68 ff 00             	push   0xff
    30d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d4:	26 ff b5 36 03       	push   WORD PTR es:[di+0x336]
    30d9:	26 ff b5 34 03       	push   WORD PTR es:[di+0x334]
    30de:	ff 36 86 04          	push   WORD PTR ds:0x486
    30e2:	6a 64                	push   0x64
    30e4:	55                   	push   bp
    30e5:	9a 5e 1a 2e 31       	call   0x312e:0x1a5e
    30ea:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    30ef:	76 18                	jbe    0x3109
    30f1:	8d be 00 ff          	lea    di,[bp-0x100]
    30f5:	16                   	push   ss
    30f6:	57                   	push   di
    30f7:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    30fb:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3100:	06                   	push   es
    3101:	57                   	push   di
    3102:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3105:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3109:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    310e:	8d be 00 ff          	lea    di,[bp-0x100]
    3112:	16                   	push   ss
    3113:	57                   	push   di
    3114:	68 ff 00             	push   0xff
    3117:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    311a:	26 ff b5 fe 02       	push   WORD PTR es:[di+0x2fe]
    311f:	26 ff b5 fc 02       	push   WORD PTR es:[di+0x2fc]
    3124:	ff 36 80 04          	push   WORD PTR ds:0x480
    3128:	6a 67                	push   0x67
    312a:	55                   	push   bp
    312b:	9a 5e 1a 50 31       	call   0x3150:0x1a5e
    3130:	8d be 00 ff          	lea    di,[bp-0x100]
    3134:	16                   	push   ss
    3135:	57                   	push   di
    3136:	68 ff 00             	push   0xff
    3139:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    313c:	26 ff b5 1e 03       	push   WORD PTR es:[di+0x31e]
    3141:	26 ff b5 1c 03       	push   WORD PTR es:[di+0x31c]
    3146:	ff 36 84 04          	push   WORD PTR ds:0x484
    314a:	6a 64                	push   0x64
    314c:	55                   	push   bp
    314d:	9a 5e 1a 72 31       	call   0x3172:0x1a5e
    3152:	8d be 00 ff          	lea    di,[bp-0x100]
    3156:	16                   	push   ss
    3157:	57                   	push   di
    3158:	68 ff 00             	push   0xff
    315b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    315e:	26 ff b5 3a 03       	push   WORD PTR es:[di+0x33a]
    3163:	26 ff b5 38 03       	push   WORD PTR es:[di+0x338]
    3168:	ff 36 86 04          	push   WORD PTR ds:0x486
    316c:	6a 64                	push   0x64
    316e:	55                   	push   bp
    316f:	9a 5e 1a b8 31       	call   0x31b8:0x1a5e
    3174:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3179:	76 18                	jbe    0x3193
    317b:	8d be 00 ff          	lea    di,[bp-0x100]
    317f:	16                   	push   ss
    3180:	57                   	push   di
    3181:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3185:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    318a:	06                   	push   es
    318b:	57                   	push   di
    318c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    318f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3193:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3198:	8d be 00 ff          	lea    di,[bp-0x100]
    319c:	16                   	push   ss
    319d:	57                   	push   di
    319e:	68 ff 00             	push   0xff
    31a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31a4:	26 ff b5 0e 03       	push   WORD PTR es:[di+0x30e]
    31a9:	26 ff b5 0c 03       	push   WORD PTR es:[di+0x30c]
    31ae:	ff 36 80 04          	push   WORD PTR ds:0x480
    31b2:	6a 67                	push   0x67
    31b4:	55                   	push   bp
    31b5:	9a 5e 1a da 31       	call   0x31da:0x1a5e
    31ba:	8d be 00 ff          	lea    di,[bp-0x100]
    31be:	16                   	push   ss
    31bf:	57                   	push   di
    31c0:	68 ff 00             	push   0xff
    31c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31c6:	26 ff b5 22 03       	push   WORD PTR es:[di+0x322]
    31cb:	26 ff b5 20 03       	push   WORD PTR es:[di+0x320]
    31d0:	ff 36 84 04          	push   WORD PTR ds:0x484
    31d4:	6a 64                	push   0x64
    31d6:	55                   	push   bp
    31d7:	9a 5e 1a fc 31       	call   0x31fc:0x1a5e
    31dc:	8d be 00 ff          	lea    di,[bp-0x100]
    31e0:	16                   	push   ss
    31e1:	57                   	push   di
    31e2:	68 ff 00             	push   0xff
    31e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e8:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    31ed:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    31f2:	ff 36 86 04          	push   WORD PTR ds:0x486
    31f6:	6a 64                	push   0x64
    31f8:	55                   	push   bp
    31f9:	9a 5e 1a 42 32       	call   0x3242:0x1a5e
    31fe:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3203:	76 18                	jbe    0x321d
    3205:	8d be 00 ff          	lea    di,[bp-0x100]
    3209:	16                   	push   ss
    320a:	57                   	push   di
    320b:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    320f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3214:	06                   	push   es
    3215:	57                   	push   di
    3216:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3219:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    321d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3222:	8d be 00 ff          	lea    di,[bp-0x100]
    3226:	16                   	push   ss
    3227:	57                   	push   di
    3228:	68 ff 00             	push   0xff
    322b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322e:	26 ff b5 42 03       	push   WORD PTR es:[di+0x342]
    3233:	26 ff b5 40 03       	push   WORD PTR es:[di+0x340]
    3238:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    323c:	6a 67                	push   0x67
    323e:	55                   	push   bp
    323f:	9a 5e 1a 0a 33       	call   0x330a:0x1a5e
    3244:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3249:	76 18                	jbe    0x3263
    324b:	8d be 00 ff          	lea    di,[bp-0x100]
    324f:	16                   	push   ss
    3250:	57                   	push   di
    3251:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3255:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    325a:	06                   	push   es
    325b:	57                   	push   di
    325c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    325f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3263:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3268:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    326b:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    3270:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3275:	75 03                	jne    0x327a
    3277:	e9 92 00             	jmp    0x330c
    327a:	8d be fa fd          	lea    di,[bp-0x206]
    327e:	16                   	push   ss
    327f:	57                   	push   di
    3280:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3283:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    3288:	06                   	push   es
    3289:	57                   	push   di
    328a:	9a 53 1d ff ff       	call   0xffff:0x1d53
    328f:	8d be 00 ff          	lea    di,[bp-0x100]
    3293:	16                   	push   ss
    3294:	57                   	push   di
    3295:	68 ff 00             	push   0xff
    3298:	9a e7 17 c5 32       	call   0x32c5:0x17e7
    329d:	a1 80 04             	mov    ax,ds:0x480
    32a0:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    32a4:	b8 01 00             	mov    ax,0x1
    32a7:	3b 86 f8 fe          	cmp    ax,WORD PTR [bp-0x108]
    32ab:	7f 3d                	jg     0x32ea
    32ad:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    32b1:	eb 04                	jmp    0x32b7
    32b3:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    32b7:	8d be f8 fd          	lea    di,[bp-0x208]
    32bb:	16                   	push   ss
    32bc:	57                   	push   di
    32bd:	bf 1c 1e             	mov    di,0x1e1c
    32c0:	0e                   	push   cs
    32c1:	57                   	push   di
    32c2:	9a cd 17 d0 32       	call   0x32d0:0x17cd
    32c7:	8d be 00 ff          	lea    di,[bp-0x100]
    32cb:	16                   	push   ss
    32cc:	57                   	push   di
    32cd:	9a 4c 18 de 32       	call   0x32de:0x184c
    32d2:	8d be 00 ff          	lea    di,[bp-0x100]
    32d6:	16                   	push   ss
    32d7:	57                   	push   di
    32d8:	68 ff 00             	push   0xff
    32db:	9a e7 17 62 36       	call   0x3662:0x17e7
    32e0:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    32e4:	3b 86 f8 fe          	cmp    ax,WORD PTR [bp-0x108]
    32e8:	75 c9                	jne    0x32b3
    32ea:	8d be 00 ff          	lea    di,[bp-0x100]
    32ee:	16                   	push   ss
    32ef:	57                   	push   di
    32f0:	68 ff 00             	push   0xff
    32f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f6:	26 ff b5 4a 03       	push   WORD PTR es:[di+0x34a]
    32fb:	26 ff b5 48 03       	push   WORD PTR es:[di+0x348]
    3300:	ff 36 84 04          	push   WORD PTR ds:0x484
    3304:	6a 64                	push   0x64
    3306:	55                   	push   bp
    3307:	9a 5e 1a 50 33       	call   0x3350:0x1a5e
    330c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3311:	76 18                	jbe    0x332b
    3313:	8d be 00 ff          	lea    di,[bp-0x100]
    3317:	16                   	push   ss
    3318:	57                   	push   di
    3319:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    331d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3322:	06                   	push   es
    3323:	57                   	push   di
    3324:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3327:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    332b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3330:	8d be 00 ff          	lea    di,[bp-0x100]
    3334:	16                   	push   ss
    3335:	57                   	push   di
    3336:	68 ff 00             	push   0xff
    3339:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    333c:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    3341:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    3346:	ff 36 80 04          	push   WORD PTR ds:0x480
    334a:	6a 67                	push   0x67
    334c:	55                   	push   bp
    334d:	9a 5e 1a 72 33       	call   0x3372:0x1a5e
    3352:	8d be 00 ff          	lea    di,[bp-0x100]
    3356:	16                   	push   ss
    3357:	57                   	push   di
    3358:	68 ff 00             	push   0xff
    335b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    335e:	26 ff b5 4e 03       	push   WORD PTR es:[di+0x34e]
    3363:	26 ff b5 4c 03       	push   WORD PTR es:[di+0x34c]
    3368:	ff 36 84 04          	push   WORD PTR ds:0x484
    336c:	6a 64                	push   0x64
    336e:	55                   	push   bp
    336f:	9a 5e 1a b8 33       	call   0x33b8:0x1a5e
    3374:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3379:	76 18                	jbe    0x3393
    337b:	8d be 00 ff          	lea    di,[bp-0x100]
    337f:	16                   	push   ss
    3380:	57                   	push   di
    3381:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3385:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    338a:	06                   	push   es
    338b:	57                   	push   di
    338c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    338f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3393:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3398:	8d be 00 ff          	lea    di,[bp-0x100]
    339c:	16                   	push   ss
    339d:	57                   	push   di
    339e:	68 ff 00             	push   0xff
    33a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a4:	26 ff b5 7a 03       	push   WORD PTR es:[di+0x37a]
    33a9:	26 ff b5 78 03       	push   WORD PTR es:[di+0x378]
    33ae:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    33b2:	6a 67                	push   0x67
    33b4:	55                   	push   bp
    33b5:	9a 5e 1a da 33       	call   0x33da:0x1a5e
    33ba:	8d be 00 ff          	lea    di,[bp-0x100]
    33be:	16                   	push   ss
    33bf:	57                   	push   di
    33c0:	68 ff 00             	push   0xff
    33c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c6:	26 ff b5 82 03       	push   WORD PTR es:[di+0x382]
    33cb:	26 ff b5 80 03       	push   WORD PTR es:[di+0x380]
    33d0:	ff 36 84 04          	push   WORD PTR ds:0x484
    33d4:	6a 64                	push   0x64
    33d6:	55                   	push   bp
    33d7:	9a 5e 1a fc 33       	call   0x33fc:0x1a5e
    33dc:	8d be 00 ff          	lea    di,[bp-0x100]
    33e0:	16                   	push   ss
    33e1:	57                   	push   di
    33e2:	68 ff 00             	push   0xff
    33e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e8:	26 ff b5 9a 03       	push   WORD PTR es:[di+0x39a]
    33ed:	26 ff b5 98 03       	push   WORD PTR es:[di+0x398]
    33f2:	ff 36 86 04          	push   WORD PTR ds:0x486
    33f6:	6a 64                	push   0x64
    33f8:	55                   	push   bp
    33f9:	9a 5e 1a 42 34       	call   0x3442:0x1a5e
    33fe:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3403:	76 18                	jbe    0x341d
    3405:	8d be 00 ff          	lea    di,[bp-0x100]
    3409:	16                   	push   ss
    340a:	57                   	push   di
    340b:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    340f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3414:	06                   	push   es
    3415:	57                   	push   di
    3416:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3419:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    341d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3422:	8d be 00 ff          	lea    di,[bp-0x100]
    3426:	16                   	push   ss
    3427:	57                   	push   di
    3428:	68 ff 00             	push   0xff
    342b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    342e:	26 ff b5 8a 03       	push   WORD PTR es:[di+0x38a]
    3433:	26 ff b5 88 03       	push   WORD PTR es:[di+0x388]
    3438:	ff 36 80 04          	push   WORD PTR ds:0x480
    343c:	6a 67                	push   0x67
    343e:	55                   	push   bp
    343f:	9a 5e 1a 64 34       	call   0x3464:0x1a5e
    3444:	8d be 00 ff          	lea    di,[bp-0x100]
    3448:	16                   	push   ss
    3449:	57                   	push   di
    344a:	68 ff 00             	push   0xff
    344d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3450:	26 ff b5 8e 03       	push   WORD PTR es:[di+0x38e]
    3455:	26 ff b5 8c 03       	push   WORD PTR es:[di+0x38c]
    345a:	ff 36 84 04          	push   WORD PTR ds:0x484
    345e:	6a 64                	push   0x64
    3460:	55                   	push   bp
    3461:	9a 5e 1a 86 34       	call   0x3486:0x1a5e
    3466:	8d be 00 ff          	lea    di,[bp-0x100]
    346a:	16                   	push   ss
    346b:	57                   	push   di
    346c:	68 ff 00             	push   0xff
    346f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3472:	26 ff b5 9e 03       	push   WORD PTR es:[di+0x39e]
    3477:	26 ff b5 9c 03       	push   WORD PTR es:[di+0x39c]
    347c:	ff 36 86 04          	push   WORD PTR ds:0x486
    3480:	6a 64                	push   0x64
    3482:	55                   	push   bp
    3483:	9a 5e 1a cc 34       	call   0x34cc:0x1a5e
    3488:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    348d:	76 18                	jbe    0x34a7
    348f:	8d be 00 ff          	lea    di,[bp-0x100]
    3493:	16                   	push   ss
    3494:	57                   	push   di
    3495:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3499:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    349e:	06                   	push   es
    349f:	57                   	push   di
    34a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34a3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    34a7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    34ac:	8d be 00 ff          	lea    di,[bp-0x100]
    34b0:	16                   	push   ss
    34b1:	57                   	push   di
    34b2:	68 ff 00             	push   0xff
    34b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b8:	26 ff b5 86 03       	push   WORD PTR es:[di+0x386]
    34bd:	26 ff b5 84 03       	push   WORD PTR es:[di+0x384]
    34c2:	ff 36 80 04          	push   WORD PTR ds:0x480
    34c6:	6a 67                	push   0x67
    34c8:	55                   	push   bp
    34c9:	9a 5e 1a ee 34       	call   0x34ee:0x1a5e
    34ce:	8d be 00 ff          	lea    di,[bp-0x100]
    34d2:	16                   	push   ss
    34d3:	57                   	push   di
    34d4:	68 ff 00             	push   0xff
    34d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34da:	26 ff b5 92 03       	push   WORD PTR es:[di+0x392]
    34df:	26 ff b5 90 03       	push   WORD PTR es:[di+0x390]
    34e4:	ff 36 84 04          	push   WORD PTR ds:0x484
    34e8:	6a 64                	push   0x64
    34ea:	55                   	push   bp
    34eb:	9a 5e 1a 10 35       	call   0x3510:0x1a5e
    34f0:	8d be 00 ff          	lea    di,[bp-0x100]
    34f4:	16                   	push   ss
    34f5:	57                   	push   di
    34f6:	68 ff 00             	push   0xff
    34f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34fc:	26 ff b5 a2 03       	push   WORD PTR es:[di+0x3a2]
    3501:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3506:	ff 36 86 04          	push   WORD PTR ds:0x486
    350a:	6a 64                	push   0x64
    350c:	55                   	push   bp
    350d:	9a 5e 1a 56 35       	call   0x3556:0x1a5e
    3512:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3517:	76 18                	jbe    0x3531
    3519:	8d be 00 ff          	lea    di,[bp-0x100]
    351d:	16                   	push   ss
    351e:	57                   	push   di
    351f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3523:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3528:	06                   	push   es
    3529:	57                   	push   di
    352a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    352d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3531:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3536:	8d be 00 ff          	lea    di,[bp-0x100]
    353a:	16                   	push   ss
    353b:	57                   	push   di
    353c:	68 ff 00             	push   0xff
    353f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3542:	26 ff b5 c2 03       	push   WORD PTR es:[di+0x3c2]
    3547:	26 ff b5 c0 03       	push   WORD PTR es:[di+0x3c0]
    354c:	ff 36 7e 04          	push   WORD PTR ds:0x47e
    3550:	6a 67                	push   0x67
    3552:	55                   	push   bp
    3553:	9a 5e 1a 95 35       	call   0x3595:0x1a5e
    3558:	8d be 00 ff          	lea    di,[bp-0x100]
    355c:	16                   	push   ss
    355d:	57                   	push   di
    355e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3562:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3567:	06                   	push   es
    3568:	57                   	push   di
    3569:	26 c4 3d             	les    di,DWORD PTR es:[di]
    356c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3570:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3575:	8d be 00 ff          	lea    di,[bp-0x100]
    3579:	16                   	push   ss
    357a:	57                   	push   di
    357b:	68 ff 00             	push   0xff
    357e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3581:	26 ff b5 c6 03       	push   WORD PTR es:[di+0x3c6]
    3586:	26 ff b5 c4 03       	push   WORD PTR es:[di+0x3c4]
    358b:	ff 36 80 04          	push   WORD PTR ds:0x480
    358f:	6a 67                	push   0x67
    3591:	55                   	push   bp
    3592:	9a 5e 1a b7 35       	call   0x35b7:0x1a5e
    3597:	8d be 00 ff          	lea    di,[bp-0x100]
    359b:	16                   	push   ss
    359c:	57                   	push   di
    359d:	68 ff 00             	push   0xff
    35a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35a3:	26 ff b5 ce 03       	push   WORD PTR es:[di+0x3ce]
    35a8:	26 ff b5 cc 03       	push   WORD PTR es:[di+0x3cc]
    35ad:	ff 36 84 04          	push   WORD PTR ds:0x484
    35b1:	6a 64                	push   0x64
    35b3:	55                   	push   bp
    35b4:	9a 5e 1a fd 35       	call   0x35fd:0x1a5e
    35b9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    35be:	76 18                	jbe    0x35d8
    35c0:	8d be 00 ff          	lea    di,[bp-0x100]
    35c4:	16                   	push   ss
    35c5:	57                   	push   di
    35c6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    35ca:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    35cf:	06                   	push   es
    35d0:	57                   	push   di
    35d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35d4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    35d8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    35dd:	8d be 00 ff          	lea    di,[bp-0x100]
    35e1:	16                   	push   ss
    35e2:	57                   	push   di
    35e3:	68 ff 00             	push   0xff
    35e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35e9:	26 ff b5 ca 03       	push   WORD PTR es:[di+0x3ca]
    35ee:	26 ff b5 c8 03       	push   WORD PTR es:[di+0x3c8]
    35f3:	ff 36 80 04          	push   WORD PTR ds:0x480
    35f7:	6a 67                	push   0x67
    35f9:	55                   	push   bp
    35fa:	9a 5e 1a 1f 36       	call   0x361f:0x1a5e
    35ff:	8d be 00 ff          	lea    di,[bp-0x100]
    3603:	16                   	push   ss
    3604:	57                   	push   di
    3605:	68 ff 00             	push   0xff
    3608:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    360b:	26 ff b5 d2 03       	push   WORD PTR es:[di+0x3d2]
    3610:	26 ff b5 d0 03       	push   WORD PTR es:[di+0x3d0]
    3615:	ff 36 84 04          	push   WORD PTR ds:0x484
    3619:	6a 64                	push   0x64
    361b:	55                   	push   bp
    361c:	9a 5e 1a 66 36       	call   0x3666:0x1a5e
    3621:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3626:	76 18                	jbe    0x3640
    3628:	8d be 00 ff          	lea    di,[bp-0x100]
    362c:	16                   	push   ss
    362d:	57                   	push   di
    362e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3632:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3637:	06                   	push   es
    3638:	57                   	push   di
    3639:	26 c4 3d             	les    di,DWORD PTR es:[di]
    363c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3640:	c9                   	leave
    3641:	ca 06 00             	retf   0x6
    3644:	7b 36                	jnp    0x367c
    3646:	00 00                	add    BYTE PTR [bx+si],al
    3648:	00 00                	add    BYTE PTR [bx+si],al
    364a:	00 00                	add    BYTE PTR [bx+si],al
    364c:	70 36                	jo     0x3684
    364e:	0a 00                	or     al,BYTE PTR [bx+si]
    3650:	d1 02                	rol    WORD PTR [bp+si],1
    3652:	8d 36 64 20          	lea    si,ds:0x2064
    3656:	58                   	pop    ax
    3657:	38 9a 1f 56          	cmp    BYTE PTR [bp+si+0x561f],bl
    365b:	36 cb                	ss retf
    365d:	1f                   	pop    ds
    365e:	5a                   	pop    dx
    365f:	36 66 1f             	ss popd ds
    3662:	5e                   	pop    si
    3663:	36 6d                	ss ins WORD PTR es:[di],dx
    3665:	3b 6e 36             	cmp    bp,WORD PTR [bp+0x36]
    3668:	e4 11                	in     al,0x11
    366a:	52                   	push   dx
    366b:	36 01 3d             	add    WORD PTR ss:[di],di
    366e:	89 36 0a 54          	mov    WORD PTR ds:0x540a,si
    3672:	43                   	inc    bx
    3673:	6c                   	ins    BYTE PTR es:[di],dx
    3674:	69 70 62 6f 61       	imul   si,WORD PTR [bx+si+0x62],0x616f
    3679:	72 64                	jb     0x36df
    367b:	07                   	pop    es
    367c:	0a 54 43             	or     dl,BYTE PTR [si+0x43]
    367f:	6c                   	ins    BYTE PTR es:[di],dx
    3680:	69 70 62 6f 61       	imul   si,WORD PTR [bx+si+0x62],0x616f
    3685:	72 64                	jb     0x36eb
    3687:	64 36 9f             	fs ss lahf
    368a:	36 e9 02 f9          	ss jmp 0x2f90
    368e:	3b 00                	cmp    ax,WORD PTR [bx+si]
    3690:	00 07                	add    BYTE PTR [bx],al
    3692:	43                   	inc    bx
    3693:	6c                   	ins    BYTE PTR es:[di],dx
    3694:	69 70 62 72 64       	imul   si,WORD PTR [bx+si+0x62],0x6472
    3699:	00 00                	add    BYTE PTR [bx+si],al
    369b:	00 00                	add    BYTE PTR [bx+si],al
    369d:	cd 36                	int    0x36
    369f:	ac                   	lods   al,BYTE PTR ds:[si]
    36a0:	36 55                	ss push bp
    36a2:	89 e5                	mov    bp,sp
    36a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36a7:	06                   	push   es
    36a8:	57                   	push   di
    36a9:	9a 45 37 d5 36       	call   0x36d5:0x3745
    36ae:	b8 9b 36             	mov    ax,0x369b
    36b1:	0e                   	push   cs
    36b2:	50                   	push   ax
    36b3:	55                   	push   bp
    36b4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    36b8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    36bc:	9a ff ff 00 00       	call   0x0:0xffff
    36c1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    36c5:	83 c4 06             	add    sp,0x6
    36c8:	b8 d8 36             	mov    ax,0x36d8
    36cb:	0e                   	push   cs
    36cc:	50                   	push   ax
    36cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36d0:	06                   	push   es
    36d1:	57                   	push   di
    36d2:	9a 03 37 f5 36       	call   0x36f5:0x3703
    36d7:	cb                   	retf
    36d8:	c9                   	leave
    36d9:	ca 04 00             	retf   0x4
    36dc:	55                   	push   bp
    36dd:	89 e5                	mov    bp,sp
    36df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36e2:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    36e7:	74 16                	je     0x36ff
    36e9:	26 80 7d 09 00       	cmp    BYTE PTR es:[di+0x9],0x0
    36ee:	75 0f                	jne    0x36ff
    36f0:	06                   	push   es
    36f1:	57                   	push   di
    36f2:	9a a1 36 6e 37       	call   0x376e:0x36a1
    36f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36fa:	26 c6 45 09 01       	mov    BYTE PTR es:[di+0x9],0x1
    36ff:	c9                   	leave
    3700:	ca 04 00             	retf   0x4
    3703:	55                   	push   bp
    3704:	89 e5                	mov    bp,sp
    3706:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3709:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    370e:	75 02                	jne    0x3712
    3710:	eb 2f                	jmp    0x3741
    3712:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3715:	26 ff 4d 04          	dec    WORD PTR es:[di+0x4]
    3719:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    371e:	75 21                	jne    0x3741
    3720:	9a ff ff 00 00       	call   0x0:0xffff
    3725:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3728:	26 80 7d 08 00       	cmp    BYTE PTR es:[di+0x8],0x0
    372d:	74 09                	je     0x3738
    372f:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3733:	9a 6c 16 75 37       	call   0x3775:0x166c
    3738:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    373b:	31 c0                	xor    ax,ax
    373d:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    3741:	c9                   	leave
    3742:	ca 04 00             	retf   0x4
    3745:	55                   	push   bp
    3746:	89 e5                	mov    bp,sp
    3748:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    374b:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    3750:	75 45                	jne    0x3797
    3752:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3756:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    375a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    375d:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    3761:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    3766:	75 1b                	jne    0x3783
    3768:	06                   	push   es
    3769:	57                   	push   di
    376a:	bf a2 37             	mov    di,0x37a2
    376d:	b8 e0 37             	mov    ax,0x37e0
    3770:	50                   	push   ax
    3771:	57                   	push   di
    3772:	9a ed 15 ff ff       	call   0xffff:0x15ed
    3777:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    377a:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    377e:	26 c6 45 08 01       	mov    BYTE PTR es:[di+0x8],0x1
    3783:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3786:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    378a:	9a ff ff 00 00       	call   0x0:0xffff
    378f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3792:	26 c6 45 09 00       	mov    BYTE PTR es:[di+0x9],0x0
    3797:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    379a:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
    379e:	c9                   	leave
    379f:	ca 04 00             	retf   0x4
    37a2:	c8 04 00 00          	enter  0x4,0x0
    37a6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37a9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    37ac:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    37af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b2:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    37b6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    37b9:	26 ff 35             	push   WORD PTR es:[di]
    37bc:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    37c0:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    37c4:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    37c8:	9a ff ff 00 00       	call   0x0:0xffff
    37cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    37d0:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    37d4:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    37d8:	c9                   	leave
    37d9:	ca 08 00             	retf   0x8
    37dc:	00 00                	add    BYTE PTR [bx+si],al
    37de:	7b 38                	jnp    0x3818
    37e0:	ea 37 01 00 00       	jmp    0x0:0x137
    37e5:	00 00                	add    BYTE PTR [bx+si],al
    37e7:	00 8d 38 f0          	add    BYTE PTR [di-0xfc8],cl
    37eb:	37                   	aaa
    37ec:	00 00                	add    BYTE PTR [bx+si],al
    37ee:	ab                   	stos   WORD PTR es:[di],ax
    37ef:	38 fe                	cmp    dh,bh
    37f1:	37                   	aaa
    37f2:	c8 06 00 00          	enter  0x6,0x0
    37f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f9:	06                   	push   es
    37fa:	57                   	push   di
    37fb:	9a 45 37 62 38       	call   0x3862:0x3745
    3800:	b8 ec 37             	mov    ax,0x37ec
    3803:	0e                   	push   cs
    3804:	50                   	push   ax
    3805:	55                   	push   bp
    3806:	ff 36 58 18          	push   WORD PTR ds:0x1858
    380a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    380e:	6a 02                	push   0x2
    3810:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3813:	99                   	cwd
    3814:	52                   	push   dx
    3815:	50                   	push   ax
    3816:	9a ff ff 00 00       	call   0x0:0xffff
    381b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    381e:	b8 e2 37             	mov    ax,0x37e2
    3821:	0e                   	push   cs
    3822:	50                   	push   ax
    3823:	55                   	push   bp
    3824:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3828:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    382c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    382f:	9a 03 39 00 00       	call   0x0:0x3903
    3834:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3837:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    383a:	b8 dc 37             	mov    ax,0x37dc
    383d:	0e                   	push   cs
    383e:	50                   	push   ax
    383f:	55                   	push   bp
    3840:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3844:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3848:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    384b:	06                   	push   es
    384c:	57                   	push   di
    384d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3850:	06                   	push   es
    3851:	57                   	push   di
    3852:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3855:	9a c1 1e 98 38       	call   0x3898:0x1ec1
    385a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    385d:	06                   	push   es
    385e:	57                   	push   di
    385f:	9a dc 36 b3 38       	call   0x38b3:0x36dc
    3864:	ff 76 10             	push   WORD PTR [bp+0x10]
    3867:	ff 76 fe             	push   WORD PTR [bp-0x2]
    386a:	9a 50 3c 00 00       	call   0x0:0x3c50
    386f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3873:	83 c4 06             	add    sp,0x6
    3876:	b8 84 38             	mov    ax,0x3884
    3879:	0e                   	push   cs
    387a:	50                   	push   ax
    387b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    387e:	9a 76 39 00 00       	call   0x0:0x3976
    3883:	cb                   	retf
    3884:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3888:	83 c4 06             	add    sp,0x6
    388b:	eb 12                	jmp    0x389f
    388d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3890:	9a ff ff 00 00       	call   0x0:0xffff
    3895:	ea 85 13 9d 38       	jmp    0x389d:0x1385
    389a:	9a 34 14 fa 38       	call   0x38fa:0x1434
    389f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    38a3:	83 c4 06             	add    sp,0x6
    38a6:	b8 b6 38             	mov    ax,0x38b6
    38a9:	0e                   	push   cs
    38aa:	50                   	push   ax
    38ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ae:	06                   	push   es
    38af:	57                   	push   di
    38b0:	9a 03 37 be 38       	call   0x38be:0x3703
    38b5:	cb                   	retf
    38b6:	c9                   	leave
    38b7:	ca 0c 00             	retf   0xc
    38ba:	00 00                	add    BYTE PTR [bx+si],al
    38bc:	72 39                	jb     0x38f7
    38be:	c4 38                	les    di,DWORD PTR [bx+si]
    38c0:	00 00                	add    BYTE PTR [bx+si],al
    38c2:	87 39                	xchg   WORD PTR [bx+di],di
    38c4:	d7                   	xlat   BYTE PTR ds:[bx]
    38c5:	38 c8                	cmp    al,cl
    38c7:	0a 00                	or     al,BYTE PTR [bx+si]
    38c9:	00 31                	add    BYTE PTR [bx+di],dh
    38cb:	c0 89 46 fe c4       	ror    BYTE PTR [bx+di-0x1ba],0xc4
    38d0:	7e 06                	jle    0x38d8
    38d2:	06                   	push   es
    38d3:	57                   	push   di
    38d4:	9a 45 37 8f 39       	call   0x398f:0x3745
    38d9:	b8 c0 38             	mov    ax,0x38c0
    38dc:	0e                   	push   cs
    38dd:	50                   	push   ax
    38de:	55                   	push   bp
    38df:	ff 36 58 18          	push   WORD PTR ds:0x1858
    38e3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    38e7:	6a 01                	push   0x1
    38e9:	9a 2b 3a 00 00       	call   0x0:0x3a2b
    38ee:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    38f1:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    38f5:	75 08                	jne    0x38ff
    38f7:	9a 6a 14 56 39       	call   0x3956:0x146a
    38fc:	e9 93 00             	jmp    0x3992
    38ff:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3902:	9a ff ff 00 00       	call   0x0:0xffff
    3907:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    390a:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    390d:	b8 ba 38             	mov    ax,0x38ba
    3910:	0e                   	push   cs
    3911:	50                   	push   ax
    3912:	55                   	push   bp
    3913:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3917:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    391b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    391e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3921:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3924:	9a 3f 39 00 00       	call   0x0:0x393f
    3929:	8b c8                	mov    cx,ax
    392b:	8b da                	mov    bx,dx
    392d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3930:	99                   	cwd
    3931:	3b d3                	cmp    dx,bx
    3933:	7f 06                	jg     0x393b
    3935:	7c 0f                	jl     0x3946
    3937:	3b c1                	cmp    ax,cx
    3939:	76 0b                	jbe    0x3946
    393b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    393e:	9a ff ff 00 00       	call   0x0:0xffff
    3943:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3946:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3949:	06                   	push   es
    394a:	57                   	push   di
    394b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    394e:	06                   	push   es
    394f:	57                   	push   di
    3950:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3953:	9a c1 1e 52 3a       	call   0x3a52:0x1ec1
    3958:	ff 76 0e             	push   WORD PTR [bp+0xe]
    395b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    395e:	9a 8c 0c ac 39       	call   0x39ac:0xc8c
    3963:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3966:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    396a:	83 c4 06             	add    sp,0x6
    396d:	b8 7b 39             	mov    ax,0x397b
    3970:	0e                   	push   cs
    3971:	50                   	push   ax
    3972:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3975:	9a ff ff 00 00       	call   0x0:0xffff
    397a:	cb                   	retf
    397b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    397f:	83 c4 06             	add    sp,0x6
    3982:	b8 92 39             	mov    ax,0x3992
    3985:	0e                   	push   cs
    3986:	50                   	push   ax
    3987:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    398a:	06                   	push   es
    398b:	57                   	push   di
    398c:	9a 03 37 b8 39       	call   0x39b8:0x3703
    3991:	cb                   	retf
    3992:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3995:	c9                   	leave
    3996:	ca 0a 00             	retf   0xa
    3999:	55                   	push   bp
    399a:	89 e5                	mov    bp,sp
    399c:	6a 01                	push   0x1
    399e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    39a1:	06                   	push   es
    39a2:	57                   	push   di
    39a3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    39a6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    39a9:	9a 8c 0c 6f 3a       	call   0x3a6f:0xc8c
    39ae:	40                   	inc    ax
    39af:	50                   	push   ax
    39b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39b3:	06                   	push   es
    39b4:	57                   	push   di
    39b5:	9a f2 37 d5 39       	call   0x39d5:0x37f2
    39ba:	c9                   	leave
    39bb:	ca 08 00             	retf   0x8
    39be:	55                   	push   bp
    39bf:	89 e5                	mov    bp,sp
    39c1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    39c4:	81 c7 01 00          	add    di,0x1
    39c8:	06                   	push   es
    39c9:	57                   	push   di
    39ca:	68 ff 00             	push   0xff
    39cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39d0:	06                   	push   es
    39d1:	57                   	push   di
    39d2:	9a c6 38 e5 39       	call   0x39e5:0x38c6
    39d7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    39da:	26 88 05             	mov    BYTE PTR es:[di],al
    39dd:	c9                   	leave
    39de:	ca 04 00             	retf   0x4
    39e1:	00 00                	add    BYTE PTR [bx+si],al
    39e3:	94                   	xchg   sp,ax
    39e4:	3a f3                	cmp    dh,bl
    39e6:	39 c8                	cmp    ax,cx
    39e8:	06                   	push   es
    39e9:	01 00                	add    WORD PTR [bx+si],ax
    39eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39ee:	06                   	push   es
    39ef:	57                   	push   di
    39f0:	9a 45 37 9c 3a       	call   0x3a9c:0x3745
    39f5:	b8 e1 39             	mov    ax,0x39e1
    39f8:	0e                   	push   cs
    39f9:	50                   	push   ax
    39fa:	55                   	push   bp
    39fb:	ff 36 58 18          	push   WORD PTR ds:0x1858
    39ff:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3a03:	6a 00                	push   0x0
    3a05:	9a 5a 3a 00 00       	call   0x0:0x3a5a
    3a0a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a0d:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3a11:	74 50                	je     0x3a63
    3a13:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a16:	b8 c6 06             	mov    ax,0x6c6
    3a19:	ba 21 3a             	mov    dx,0x3a21
    3a1c:	52                   	push   dx
    3a1d:	50                   	push   ax
    3a1e:	9a e1 44 4d 3a       	call   0x3a4d:0x44e1
    3a23:	08 c0                	or     al,al
    3a25:	74 2f                	je     0x3a56
    3a27:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a2a:	9a 35 3a 00 00       	call   0x0:0x3a35
    3a2f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3a32:	6a 09                	push   0x9
    3a34:	9a c8 3a 00 00       	call   0x0:0x3ac8
    3a39:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3a3c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a3f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3a42:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3a45:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a48:	06                   	push   es
    3a49:	57                   	push   di
    3a4a:	9a c0 43 7a 3b       	call   0x3b7a:0x43c0
    3a4f:	9a 6a 14 86 3a       	call   0x3a86:0x146a
    3a54:	eb 49                	jmp    0x3a9f
    3a56:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a59:	9a ff ff 00 00       	call   0x0:0xffff
    3a5e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a61:	eb aa                	jmp    0x3a0d
    3a63:	8d be fa fe          	lea    di,[bp-0x106]
    3a67:	16                   	push   ss
    3a68:	57                   	push   di
    3a69:	68 a7 f0             	push   0xf0a7
    3a6c:	9a 2b 09 78 3a       	call   0x3a78:0x92b
    3a71:	b0 01                	mov    al,0x1
    3a73:	50                   	push   ax
    3a74:	b8 2e 00             	mov    ax,0x2e
    3a77:	ba 7f 3a             	mov    dx,0x3a7f
    3a7a:	52                   	push   dx
    3a7b:	50                   	push   ax
    3a7c:	9a e6 28 b9 3d       	call   0x3db9:0x28e6
    3a81:	52                   	push   dx
    3a82:	50                   	push   ax
    3a83:	9a 99 13 81 3b       	call   0x3b81:0x1399
    3a88:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3a8c:	83 c4 06             	add    sp,0x6
    3a8f:	b8 9f 3a             	mov    ax,0x3a9f
    3a92:	0e                   	push   cs
    3a93:	50                   	push   ax
    3a94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a97:	06                   	push   es
    3a98:	57                   	push   di
    3a99:	9a 03 37 a7 3a       	call   0x3aa7:0x3703
    3a9e:	cb                   	retf
    3a9f:	c9                   	leave
    3aa0:	ca 08 00             	retf   0x8
    3aa3:	00 00                	add    BYTE PTR [bx+si],al
    3aa5:	f9                   	stc
    3aa6:	3a b5 3a c8          	cmp    dh,BYTE PTR [di-0x37c6]
    3aaa:	06                   	push   es
    3aab:	00 00                	add    BYTE PTR [bx+si],al
    3aad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ab0:	06                   	push   es
    3ab1:	57                   	push   di
    3ab2:	9a 45 37 01 3b       	call   0x3b01:0x3745
    3ab7:	b8 a3 3a             	mov    ax,0x3aa3
    3aba:	0e                   	push   cs
    3abb:	50                   	push   ax
    3abc:	55                   	push   bp
    3abd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3ac1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3ac5:	6a 02                	push   0x2
    3ac7:	9a d2 3a 00 00       	call   0x0:0x3ad2
    3acc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3acf:	6a 09                	push   0x9
    3ad1:	9a 2d 3b 00 00       	call   0x0:0x3b2d
    3ad6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3ad9:	6a 02                	push   0x2
    3adb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3ade:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3ae1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ae4:	06                   	push   es
    3ae5:	57                   	push   di
    3ae6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ae9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3aed:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3af1:	83 c4 06             	add    sp,0x6
    3af4:	b8 04 3b             	mov    ax,0x3b04
    3af7:	0e                   	push   cs
    3af8:	50                   	push   ax
    3af9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afc:	06                   	push   es
    3afd:	57                   	push   di
    3afe:	9a 03 37 0c 3b       	call   0x3b0c:0x3703
    3b03:	cb                   	retf
    3b04:	c9                   	leave
    3b05:	ca 08 00             	retf   0x8
    3b08:	00 00                	add    BYTE PTR [bx+si],al
    3b0a:	5e                   	pop    si
    3b0b:	3b 1a                	cmp    bx,WORD PTR [bp+si]
    3b0d:	3b c8                	cmp    cx,ax
    3b0f:	06                   	push   es
    3b10:	00 00                	add    BYTE PTR [bx+si],al
    3b12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b15:	06                   	push   es
    3b16:	57                   	push   di
    3b17:	9a 45 37 66 3b       	call   0x3b66:0x3745
    3b1c:	b8 08 3b             	mov    ax,0x3b08
    3b1f:	0e                   	push   cs
    3b20:	50                   	push   ax
    3b21:	55                   	push   bp
    3b22:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3b26:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3b2a:	6a 03                	push   0x3
    3b2c:	9a 37 3b 00 00       	call   0x0:0x3b37
    3b31:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3b34:	6a 09                	push   0x9
    3b36:	9a ff ff 00 00       	call   0x0:0xffff
    3b3b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3b3e:	6a 03                	push   0x3
    3b40:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3b43:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3b46:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3b49:	06                   	push   es
    3b4a:	57                   	push   di
    3b4b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b4e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3b52:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3b56:	83 c4 06             	add    sp,0x6
    3b59:	b8 69 3b             	mov    ax,0x3b69
    3b5c:	0e                   	push   cs
    3b5d:	50                   	push   ax
    3b5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b61:	06                   	push   es
    3b62:	57                   	push   di
    3b63:	9a 03 37 95 3b       	call   0x3b95:0x3703
    3b68:	cb                   	retf
    3b69:	c9                   	leave
    3b6a:	ca 08 00             	retf   0x8
    3b6d:	55                   	push   bp
    3b6e:	89 e5                	mov    bp,sp
    3b70:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b73:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b76:	bf c6 06             	mov    di,0x6c6
    3b79:	b8 a3 3b             	mov    ax,0x3ba3
    3b7c:	50                   	push   ax
    3b7d:	57                   	push   di
    3b7e:	9a 55 22 aa 3b       	call   0x3baa:0x2255
    3b83:	08 c0                	or     al,al
    3b85:	74 12                	je     0x3b99
    3b87:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b8a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b90:	06                   	push   es
    3b91:	57                   	push   di
    3b92:	9a e7 39 be 3b       	call   0x3bbe:0x39e7
    3b97:	eb 62                	jmp    0x3bfb
    3b99:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b9c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b9f:	bf 3f 08             	mov    di,0x83f
    3ba2:	b8 cc 3b             	mov    ax,0x3bcc
    3ba5:	50                   	push   ax
    3ba6:	57                   	push   di
    3ba7:	9a 55 22 d3 3b       	call   0x3bd3:0x2255
    3bac:	08 c0                	or     al,al
    3bae:	74 12                	je     0x3bc2
    3bb0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bb3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb9:	06                   	push   es
    3bba:	57                   	push   di
    3bbb:	9a a9 3a e7 3b       	call   0x3be7:0x3aa9
    3bc0:	eb 39                	jmp    0x3bfb
    3bc2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bc5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bc8:	bf 49 07             	mov    di,0x749
    3bcb:	b8 47 3c             	mov    ax,0x3c47
    3bce:	50                   	push   ax
    3bcf:	57                   	push   di
    3bd0:	9a 55 22 15 3d       	call   0x3d15:0x2255
    3bd5:	08 c0                	or     al,al
    3bd7:	74 12                	je     0x3beb
    3bd9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bdc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3be2:	06                   	push   es
    3be3:	57                   	push   di
    3be4:	9a 0e 3b 03 3c       	call   0x3c03:0x3b0e
    3be9:	eb 10                	jmp    0x3bfb
    3beb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bee:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bf4:	06                   	push   es
    3bf5:	57                   	push   di
    3bf6:	9a cd 11 64 3d       	call   0x3d64:0x11cd
    3bfb:	c9                   	leave
    3bfc:	ca 08 00             	retf   0x8
    3bff:	00 00                	add    BYTE PTR [bx+si],al
    3c01:	70 3c                	jo     0x3c3f
    3c03:	11 3c                	adc    WORD PTR [si],di
    3c05:	c8 06 00 00          	enter  0x6,0x0
    3c09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c0c:	06                   	push   es
    3c0d:	57                   	push   di
    3c0e:	9a 45 37 29 3c       	call   0x3c29:0x3745
    3c13:	b8 ff 3b             	mov    ax,0x3bff
    3c16:	0e                   	push   cs
    3c17:	50                   	push   ax
    3c18:	55                   	push   bp
    3c19:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c1d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c24:	06                   	push   es
    3c25:	57                   	push   di
    3c26:	9a dc 36 78 3c       	call   0x3c78:0x36dc
    3c2b:	31 c0                	xor    ax,ax
    3c2d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3c30:	8d 7e fc             	lea    di,[bp-0x4]
    3c33:	16                   	push   ss
    3c34:	57                   	push   di
    3c35:	8d 7e fe             	lea    di,[bp-0x2]
    3c38:	16                   	push   ss
    3c39:	57                   	push   di
    3c3a:	8d 7e fa             	lea    di,[bp-0x6]
    3c3d:	16                   	push   ss
    3c3e:	57                   	push   di
    3c3f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c42:	06                   	push   es
    3c43:	57                   	push   di
    3c44:	9a ae 44 0e 3d       	call   0x3d0e:0x44ae
    3c49:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3c4c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3c4f:	9a 60 3c 00 00       	call   0x0:0x3c60
    3c54:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    3c58:	74 0a                	je     0x3c64
    3c5a:	6a 09                	push   0x9
    3c5c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3c5f:	9a d2 3c 00 00       	call   0x0:0x3cd2
    3c64:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3c68:	83 c4 06             	add    sp,0x6
    3c6b:	b8 7b 3c             	mov    ax,0x3c7b
    3c6e:	0e                   	push   cs
    3c6f:	50                   	push   ax
    3c70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c73:	06                   	push   es
    3c74:	57                   	push   di
    3c75:	9a 03 37 83 3c       	call   0x3c83:0x3703
    3c7a:	cb                   	retf
    3c7b:	c9                   	leave
    3c7c:	ca 08 00             	retf   0x8
    3c7f:	00 00                	add    BYTE PTR [bx+si],al
    3c81:	f2 3c 91             	repnz cmp al,0x91
    3c84:	3c c8                	cmp    al,0xc8
    3c86:	06                   	push   es
    3c87:	00 00                	add    BYTE PTR [bx+si],al
    3c89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c8c:	06                   	push   es
    3c8d:	57                   	push   di
    3c8e:	9a 45 37 a9 3c       	call   0x3ca9:0x3745
    3c93:	b8 7f 3c             	mov    ax,0x3c7f
    3c96:	0e                   	push   cs
    3c97:	50                   	push   ax
    3c98:	55                   	push   bp
    3c99:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c9d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3ca1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca4:	06                   	push   es
    3ca5:	57                   	push   di
    3ca6:	9a dc 36 fa 3c       	call   0x3cfa:0x36dc
    3cab:	31 c0                	xor    ax,ax
    3cad:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3cb0:	8d 7e fc             	lea    di,[bp-0x4]
    3cb3:	16                   	push   ss
    3cb4:	57                   	push   di
    3cb5:	8d 7e fe             	lea    di,[bp-0x2]
    3cb8:	16                   	push   ss
    3cb9:	57                   	push   di
    3cba:	8d 7e fa             	lea    di,[bp-0x6]
    3cbd:	16                   	push   ss
    3cbe:	57                   	push   di
    3cbf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3cc2:	06                   	push   es
    3cc3:	57                   	push   di
    3cc4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cc7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3ccb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3cce:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3cd1:	9a e2 3c 00 00       	call   0x0:0x3ce2
    3cd6:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    3cda:	74 0a                	je     0x3ce6
    3cdc:	6a 09                	push   0x9
    3cde:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3ce1:	9a ff ff 00 00       	call   0x0:0xffff
    3ce6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3cea:	83 c4 06             	add    sp,0x6
    3ced:	b8 fd 3c             	mov    ax,0x3cfd
    3cf0:	0e                   	push   cs
    3cf1:	50                   	push   ax
    3cf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf5:	06                   	push   es
    3cf6:	57                   	push   di
    3cf7:	9a 03 37 29 3d       	call   0x3d29:0x3703
    3cfc:	cb                   	retf
    3cfd:	c9                   	leave
    3cfe:	ca 08 00             	retf   0x8
    3d01:	55                   	push   bp
    3d02:	89 e5                	mov    bp,sp
    3d04:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d07:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d0a:	bf c6 06             	mov    di,0x6c6
    3d0d:	b8 37 3d             	mov    ax,0x3d37
    3d10:	50                   	push   ax
    3d11:	57                   	push   di
    3d12:	9a 55 22 3e 3d       	call   0x3d3e:0x2255
    3d17:	08 c0                	or     al,al
    3d19:	74 12                	je     0x3d2d
    3d1b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d1e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d24:	06                   	push   es
    3d25:	57                   	push   di
    3d26:	9a 05 3c 52 3d       	call   0x3d52:0x3c05
    3d2b:	eb 39                	jmp    0x3d66
    3d2d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d30:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d33:	bf 36 06             	mov    di,0x636
    3d36:	b8 ff ff             	mov    ax,0xffff
    3d39:	50                   	push   ax
    3d3a:	57                   	push   di
    3d3b:	9a 55 22 76 3d       	call   0x3d76:0x2255
    3d40:	08 c0                	or     al,al
    3d42:	74 12                	je     0x3d56
    3d44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d47:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d4d:	06                   	push   es
    3d4e:	57                   	push   di
    3d4f:	9a 85 3c 9e 3d       	call   0x3d9e:0x3c85
    3d54:	eb 10                	jmp    0x3d66
    3d56:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d59:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d5f:	06                   	push   es
    3d60:	57                   	push   di
    3d61:	9a fa 10 ff ff       	call   0xffff:0x10fa
    3d66:	c9                   	leave
    3d67:	ca 08 00             	retf   0x8
    3d6a:	55                   	push   bp
    3d6b:	89 e5                	mov    bp,sp
    3d6d:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    3d71:	06                   	push   es
    3d72:	57                   	push   di
    3d73:	9a 7f 1f a5 3d       	call   0x3da5:0x1f7f
    3d78:	c9                   	leave
    3d79:	cb                   	retf
    3d7a:	55                   	push   bp
    3d7b:	89 e5                	mov    bp,sp
    3d7d:	bf fe 0b             	mov    di,0xbfe
    3d80:	1e                   	push   ds
    3d81:	57                   	push   di
    3d82:	9a 90 3d 00 00       	call   0x0:0x3d90
    3d87:	a3 cc 2a             	mov    ds:0x2acc,ax
    3d8a:	bf 0d 0c             	mov    di,0xc0d
    3d8d:	1e                   	push   ds
    3d8e:	57                   	push   di
    3d8f:	9a ff ff 00 00       	call   0x0:0xffff
    3d94:	a3 ce 2a             	mov    ds:0x2ace,ax
    3d97:	b0 01                	mov    al,0x1
    3d99:	50                   	push   ax
    3d9a:	b8 64 36             	mov    ax,0x3664
    3d9d:	ba b2 3d             	mov    dx,0x3db2
    3da0:	52                   	push   dx
    3da1:	50                   	push   ax
    3da2:	9a 50 1f ff ff       	call   0xffff:0x1f50
    3da7:	a3 d0 2a             	mov    ds:0x2ad0,ax
    3daa:	89 16 d2 2a          	mov    WORD PTR ds:0x2ad2,dx
    3dae:	bf 6a 3d             	mov    di,0x3d6a
    3db1:	b8 ff ff             	mov    ax,0xffff
    3db4:	50                   	push   ax
    3db5:	57                   	push   di
    3db6:	9a 74 05 ff ff       	call   0xffff:0x574
    3dbb:	c9                   	leave
    3dbc:	cb                   	retf
