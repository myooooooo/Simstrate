; ================================================================
; seg43_CODE  (14761 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	2b 00                	sub    ax,WORD PTR [bx+si]
       2:	05 09 54             	add    ax,0x5409
       5:	46                   	inc    si
       6:	69 6c 65 4e 61       	imul   bp,WORD PTR [si+0x65],0x614e
       b:	6d                   	ins    WORD PTR es:[di],dx
       c:	65 4f                	gs dec di
	...
      16:	2e 00 0c             	add    BYTE PTR cs:[si],cl
      19:	00 2c                	add    BYTE PTR [si],ch
      1b:	1f                   	pop    ds
      1c:	52                   	push   dx
      1d:	00 64 20             	add    BYTE PTR [si+0x20],ah
      20:	1c 00                	sbb    al,0x0
      22:	9a 1f 20 00 cb       	call   0xcb00:0x201f
      27:	1f                   	pop    ds
      28:	24 00                	and    al,0x0
      2a:	c4 29                	les    bp,DWORD PTR [bx+di]
      2c:	56                   	push   si
      2d:	00 09                	add    BYTE PTR [bx+di],cl
      2f:	45                   	inc    bp
      30:	78 63                	js     0x95
      32:	65 70 74             	gs jo  0xa9
      35:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
      3a:	00 00                	add    BYTE PTR [bx+si],al
      3c:	00 00                	add    BYTE PTR [bx+si],al
      3e:	00 00                	add    BYTE PTR [bx+si],al
      40:	58                   	pop    ax
      41:	00 0c                	add    BYTE PTR [si],cl
      43:	00 2e 00 7d          	add    BYTE PTR ds:0x7d00,ch
      47:	00 64 20             	add    BYTE PTR [si+0x20],ah
      4a:	75 00                	jne    0x4c
      4c:	9a 1f 4a 00 cb       	call   0xcb00:0x4a1f
      51:	1f                   	pop    ds
      52:	4e                   	dec    si
      53:	00 c4                	add    ah,al
      55:	29 46 00             	sub    WORD PTR [bp+0x0],ax
      58:	06                   	push   es
      59:	45                   	inc    bp
      5a:	41                   	inc    cx
      5b:	62 6f 72             	bound  bp,DWORD PTR [bx+0x72]
      5e:	74 00                	je     0x60
      60:	00 00                	add    BYTE PTR [bx+si],al
      62:	00 00                	add    BYTE PTR [bx+si],al
      64:	00 00                	add    BYTE PTR [bx+si],al
      66:	00 7f 00             	add    BYTE PTR [bx+0x0],bh
      69:	0c 00                	or     al,0x0
      6b:	2e 00 aa 00 64       	add    BYTE PTR cs:[bp+si+0x6400],ch
      70:	20 a6 00 9a          	and    BYTE PTR [bp-0x6600],ah
      74:	1f                   	pop    ds
      75:	71 00                	jno    0x77
      77:	2f                   	das
      78:	2a 6d 00             	sub    ch,BYTE PTR [di+0x0]
      7b:	1d 2a 79             	sbb    ax,0x792a
      7e:	00 0c                	add    BYTE PTR [si],cl
      80:	45                   	inc    bp
      81:	4f                   	dec    di
      82:	75 74                	jne    0xf8
      84:	4f                   	dec    di
      85:	66 4d                	dec    ebp
      87:	65 6d                	gs ins WORD PTR es:[di],dx
      89:	6f                   	outs   dx,WORD PTR ds:[si]
      8a:	72 79                	jb     0x105
	...
      94:	ac                   	lods   al,BYTE PTR ds:[si]
      95:	00 0e 00 2e          	add    BYTE PTR ds:0x2e00,cl
      99:	00 d6                	add    dh,dl
      9b:	00 64 20             	add    BYTE PTR [si+0x20],ah
      9e:	d2 00                	rol    BYTE PTR [bx+si],cl
      a0:	9a 1f 9e 00 cb       	call   0xcb00:0x9e1f
      a5:	1f                   	pop    ds
      a6:	a2 00 c4             	mov    ds:0xc400,al
      a9:	29 9a 00 0b          	sub    WORD PTR [bp+si+0xb00],bx
      ad:	45                   	inc    bp
      ae:	49                   	dec    cx
      af:	6e                   	outs   dx,BYTE PTR ds:[si]
      b0:	4f                   	dec    di
      b1:	75 74                	jne    0x127
      b3:	45                   	inc    bp
      b4:	72 72                	jb     0x128
      b6:	6f                   	outs   dx,WORD PTR ds:[si]
      b7:	72 00                	jb     0xb9
      b9:	00 00                	add    BYTE PTR [bx+si],al
      bb:	00 00                	add    BYTE PTR [bx+si],al
      bd:	00 00                	add    BYTE PTR [bx+si],al
      bf:	00 d8                	add    al,bl
      c1:	00 0c                	add    BYTE PTR [si],cl
      c3:	00 2e 00 00          	add    BYTE PTR ds:0x0,ch
      c7:	01 64 20             	add    WORD PTR [si+0x20],sp
      ca:	fc                   	cld
      cb:	00 9a 1f ca          	add    BYTE PTR [bp+si-0x35e1],bl
      cf:	00 cb                	add    bl,cl
      d1:	1f                   	pop    ds
      d2:	ce                   	into
      d3:	00 c4                	add    ah,al
      d5:	29 c6                	sub    si,ax
      d7:	00 09                	add    BYTE PTR [bx+di],cl
      d9:	45                   	inc    bp
      da:	49                   	dec    cx
      db:	6e                   	outs   dx,BYTE PTR ds:[si]
      dc:	74 45                	je     0x123
      de:	72 72                	jb     0x152
      e0:	6f                   	outs   dx,WORD PTR ds:[si]
      e1:	72 00                	jb     0xe3
      e3:	00 00                	add    BYTE PTR [bx+si],al
      e5:	00 00                	add    BYTE PTR [bx+si],al
      e7:	00 00                	add    BYTE PTR [bx+si],al
      e9:	00 02                	add    BYTE PTR [bp+si],al
      eb:	01 0c                	add    WORD PTR [si],cx
      ed:	00 d8                	add    al,bl
      ef:	00 2b                	add    BYTE PTR [bp+di],ch
      f1:	01 64 20             	add    WORD PTR [si+0x20],sp
      f4:	27                   	daa
      f5:	01 9a 1f f4          	add    WORD PTR [bp+si-0xbe1],bx
      f9:	00 cb                	add    bl,cl
      fb:	1f                   	pop    ds
      fc:	f8                   	clc
      fd:	00 c4                	add    ah,al
      ff:	29 f0                	sub    ax,si
     101:	00 0a                	add    BYTE PTR [bp+si],cl
     103:	45                   	inc    bp
     104:	44                   	inc    sp
     105:	69 76 42 79 5a       	imul   si,WORD PTR [bp+0x42],0x5a79
     10a:	65 72 6f             	gs jb  0x17c
	...
     115:	2d 01 0c             	sub    ax,0xc01
     118:	00 d8                	add    al,bl
     11a:	00 57 01             	add    BYTE PTR [bx+0x1],dl
     11d:	64 20 53 01          	and    BYTE PTR fs:[bp+di+0x1],dl
     121:	9a 1f 1f 01 cb       	call   0xcb01:0x1f1f
     126:	1f                   	pop    ds
     127:	23 01                	and    ax,WORD PTR [bx+di]
     129:	c4 29                	les    bp,DWORD PTR [bx+di]
     12b:	1b 01                	sbb    ax,WORD PTR [bx+di]
     12d:	0b 45 52             	or     ax,WORD PTR [di+0x52]
     130:	61                   	popa
     131:	6e                   	outs   dx,BYTE PTR ds:[si]
     132:	67 65 45             	addr32 gs inc bp
     135:	72 72                	jb     0x1a9
     137:	6f                   	outs   dx,WORD PTR ds:[si]
     138:	72 00                	jb     0x13a
     13a:	00 00                	add    BYTE PTR [bx+si],al
     13c:	00 00                	add    BYTE PTR [bx+si],al
     13e:	00 00                	add    BYTE PTR [bx+si],al
     140:	00 59 01             	add    BYTE PTR [bx+di+0x1],bl
     143:	0c 00                	or     al,0x0
     145:	d8 00                	fadd   DWORD PTR [bx+si]
     147:	84 01                	test   BYTE PTR [bx+di],al
     149:	64 20 80 01 9a       	and    BYTE PTR fs:[bx+si-0x65ff],al
     14e:	1f                   	pop    ds
     14f:	4b                   	dec    bx
     150:	01 cb                	add    bx,cx
     152:	1f                   	pop    ds
     153:	4f                   	dec    di
     154:	01 c4                	add    sp,ax
     156:	29 47 01             	sub    WORD PTR [bx+0x1],ax
     159:	0c 45                	or     al,0x45
     15b:	49                   	dec    cx
     15c:	6e                   	outs   dx,BYTE PTR ds:[si]
     15d:	74 4f                	je     0x1ae
     15f:	76 65                	jbe    0x1c6
     161:	72 66                	jb     0x1c9
     163:	6c                   	ins    BYTE PTR es:[di],dx
     164:	6f                   	outs   dx,WORD PTR ds:[si]
     165:	77 00                	ja     0x167
     167:	00 00                	add    BYTE PTR [bx+si],al
     169:	00 00                	add    BYTE PTR [bx+si],al
     16b:	00 00                	add    BYTE PTR [bx+si],al
     16d:	00 86 01 0c          	add    BYTE PTR [bp+0xc01],al
     171:	00 2e 00 af          	add    BYTE PTR ds:0xaf00,ch
     175:	01 64 20             	add    WORD PTR [si+0x20],sp
     178:	ab                   	stos   WORD PTR es:[di],ax
     179:	01 9a 1f 78          	add    WORD PTR [bp+si+0x781f],bx
     17d:	01 cb                	add    bx,cx
     17f:	1f                   	pop    ds
     180:	7c 01                	jl     0x183
     182:	c4 29                	les    bp,DWORD PTR [bx+di]
     184:	74 01                	je     0x187
     186:	0a 45 4d             	or     al,BYTE PTR [di+0x4d]
     189:	61                   	popa
     18a:	74 68                	je     0x1f4
     18c:	45                   	inc    bp
     18d:	72 72                	jb     0x201
     18f:	6f                   	outs   dx,WORD PTR ds:[si]
     190:	72 00                	jb     0x192
     192:	00 00                	add    BYTE PTR [bx+si],al
     194:	00 00                	add    BYTE PTR [bx+si],al
     196:	00 00                	add    BYTE PTR [bx+si],al
     198:	00 b1 01 0c          	add    BYTE PTR [bx+di+0xc01],dh
     19c:	00 86 01 da          	add    BYTE PTR [bp-0x25ff],al
     1a0:	01 64 20             	add    WORD PTR [si+0x20],sp
     1a3:	d6                   	(bad)
     1a4:	01 9a 1f a3          	add    WORD PTR [bp+si-0x5ce1],bx
     1a8:	01 cb                	add    bx,cx
     1aa:	1f                   	pop    ds
     1ab:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     1ac:	01 c4                	add    sp,ax
     1ae:	29 9f 01 0a          	sub    WORD PTR [bx+0xa01],bx
     1b2:	45                   	inc    bp
     1b3:	49                   	dec    cx
     1b4:	6e                   	outs   dx,BYTE PTR ds:[si]
     1b5:	76 61                	jbe    0x218
     1b7:	6c                   	ins    BYTE PTR es:[di],dx
     1b8:	69 64 4f 70 00       	imul   sp,WORD PTR [si+0x4f],0x70
     1bd:	00 00                	add    BYTE PTR [bx+si],al
     1bf:	00 00                	add    BYTE PTR [bx+si],al
     1c1:	00 00                	add    BYTE PTR [bx+si],al
     1c3:	00 dc                	add    ah,bl
     1c5:	01 0c                	add    WORD PTR [si],cx
     1c7:	00 86 01 06          	add    BYTE PTR [bp+0x601],al
     1cb:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     1ce:	02 02                	add    al,BYTE PTR [bp+si]
     1d0:	9a 1f ce 01 cb       	call   0xcb01:0xce1f
     1d5:	1f                   	pop    ds
     1d6:	d2 01                	rol    BYTE PTR [bx+di],cl
     1d8:	c4 29                	les    bp,DWORD PTR [bx+di]
     1da:	ca 01 0b             	retf   0xb01
     1dd:	45                   	inc    bp
     1de:	5a                   	pop    dx
     1df:	65 72 6f             	gs jb  0x251
     1e2:	44                   	inc    sp
     1e3:	69 76 69 64 65       	imul   si,WORD PTR [bp+0x69],0x6564
	...
     1f0:	08 02                	or     BYTE PTR [bp+si],al
     1f2:	0c 00                	or     al,0x0
     1f4:	86 01                	xchg   BYTE PTR [bx+di],al
     1f6:	30 02                	xor    BYTE PTR [bp+si],al
     1f8:	64 20 2c             	and    BYTE PTR fs:[si],ch
     1fb:	02 9a 1f fa          	add    bl,BYTE PTR [bp+si-0x5e1]
     1ff:	01 cb                	add    bx,cx
     201:	1f                   	pop    ds
     202:	fe 01                	inc    BYTE PTR [bx+di]
     204:	c4 29                	les    bp,DWORD PTR [bx+di]
     206:	f6 01 09             	test   BYTE PTR [bx+di],0x9
     209:	45                   	inc    bp
     20a:	4f                   	dec    di
     20b:	76 65                	jbe    0x272
     20d:	72 66                	jb     0x275
     20f:	6c                   	ins    BYTE PTR es:[di],dx
     210:	6f                   	outs   dx,WORD PTR ds:[si]
     211:	77 00                	ja     0x213
     213:	00 00                	add    BYTE PTR [bx+si],al
     215:	00 00                	add    BYTE PTR [bx+si],al
     217:	00 00                	add    BYTE PTR [bx+si],al
     219:	00 32                	add    BYTE PTR [bp+si],dh
     21b:	02 0c                	add    cl,BYTE PTR [si]
     21d:	00 86 01 5b          	add    BYTE PTR [bp+0x5b01],al
     221:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     224:	57                   	push   di
     225:	02 9a 1f 24          	add    bl,BYTE PTR [bp+si+0x241f]
     229:	02 cb                	add    cl,bl
     22b:	1f                   	pop    ds
     22c:	28 02                	sub    BYTE PTR [bp+si],al
     22e:	c4 29                	les    bp,DWORD PTR [bx+di]
     230:	20 02                	and    BYTE PTR [bp+si],al
     232:	0a 45 55             	or     al,BYTE PTR [di+0x55]
     235:	6e                   	outs   dx,BYTE PTR ds:[si]
     236:	64 65 72 66          	fs gs jb 0x2a0
     23a:	6c                   	ins    BYTE PTR es:[di],dx
     23b:	6f                   	outs   dx,WORD PTR ds:[si]
     23c:	77 00                	ja     0x23e
     23e:	00 00                	add    BYTE PTR [bx+si],al
     240:	00 00                	add    BYTE PTR [bx+si],al
     242:	00 00                	add    BYTE PTR [bx+si],al
     244:	00 5d 02             	add    BYTE PTR [di+0x2],bl
     247:	0c 00                	or     al,0x0
     249:	2e 00 8b 02 64       	add    BYTE PTR cs:[bp+di+0x6402],cl
     24e:	20 87 02 9a          	and    BYTE PTR [bx-0x65fe],al
     252:	1f                   	pop    ds
     253:	4f                   	dec    di
     254:	02 cb                	add    cl,bl
     256:	1f                   	pop    ds
     257:	53                   	push   bx
     258:	02 c4                	add    al,ah
     25a:	29 4b 02             	sub    WORD PTR [bp+di+0x2],cx
     25d:	0f 45 49 6e          	cmovne cx,WORD PTR [bx+di+0x6e]
     261:	76 61                	jbe    0x2c4
     263:	6c                   	ins    BYTE PTR es:[di],dx
     264:	69 64 50 6f 69       	imul   sp,WORD PTR [si+0x50],0x696f
     269:	6e                   	outs   dx,BYTE PTR ds:[si]
     26a:	74 65                	je     0x2d1
     26c:	72 00                	jb     0x26e
     26e:	00 00                	add    BYTE PTR [bx+si],al
     270:	00 00                	add    BYTE PTR [bx+si],al
     272:	00 00                	add    BYTE PTR [bx+si],al
     274:	00 8d 02 0c          	add    BYTE PTR [di+0xc02],cl
     278:	00 2e 00 b8          	add    BYTE PTR ds:0xb800,ch
     27c:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     27f:	b4 02                	mov    ah,0x2
     281:	9a 1f 7f 02 cb       	call   0xcb02:0x7f1f
     286:	1f                   	pop    ds
     287:	83 02 c4             	add    WORD PTR [bp+si],0xffc4
     28a:	29 7b 02             	sub    WORD PTR [bp+di+0x2],di
     28d:	0c 45                	or     al,0x45
     28f:	49                   	dec    cx
     290:	6e                   	outs   dx,BYTE PTR ds:[si]
     291:	76 61                	jbe    0x2f4
     293:	6c                   	ins    BYTE PTR es:[di],dx
     294:	69 64 43 61 73       	imul   sp,WORD PTR [si+0x43],0x7361
     299:	74 00                	je     0x29b
     29b:	00 00                	add    BYTE PTR [bx+si],al
     29d:	00 00                	add    BYTE PTR [bx+si],al
     29f:	00 00                	add    BYTE PTR [bx+si],al
     2a1:	00 ba 02 0c          	add    BYTE PTR [bp+si+0xc02],bh
     2a5:	00 2e 00 e6          	add    BYTE PTR ds:0xe600,ch
     2a9:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     2ac:	e2 02                	loop   0x2b0
     2ae:	9a 1f ac 02 cb       	call   0xcb02:0xac1f
     2b3:	1f                   	pop    ds
     2b4:	b0 02                	mov    al,0x2
     2b6:	c4 29                	les    bp,DWORD PTR [bx+di]
     2b8:	a8 02                	test   al,0x2
     2ba:	0d 45 43             	or     ax,0x4345
     2bd:	6f                   	outs   dx,WORD PTR ds:[si]
     2be:	6e                   	outs   dx,BYTE PTR ds:[si]
     2bf:	76 65                	jbe    0x326
     2c1:	72 74                	jb     0x337
     2c3:	45                   	inc    bp
     2c4:	72 72                	jb     0x338
     2c6:	6f                   	outs   dx,WORD PTR ds:[si]
     2c7:	72 00                	jb     0x2c9
     2c9:	00 00                	add    BYTE PTR [bx+si],al
     2cb:	00 00                	add    BYTE PTR [bx+si],al
     2cd:	00 00                	add    BYTE PTR [bx+si],al
     2cf:	00 e8                	add    al,ch
     2d1:	02 0c                	add    cl,BYTE PTR [si]
     2d3:	00 2e 00 1a          	add    BYTE PTR ds:0x1a00,ch
     2d7:	03 64 20             	add    sp,WORD PTR [si+0x20]
     2da:	16                   	push   ss
     2db:	03 9a 1f da          	add    bx,WORD PTR [bp+si-0x25e1]
     2df:	02 cb                	add    cl,bl
     2e1:	1f                   	pop    ds
     2e2:	de 02                	fiadd  WORD PTR [bp+si]
     2e4:	c4 29                	les    bp,DWORD PTR [bx+di]
     2e6:	d6                   	(bad)
     2e7:	02 13                	add    dl,BYTE PTR [bp+di]
     2e9:	45                   	inc    bp
     2ea:	50                   	push   ax
     2eb:	72 6f                	jb     0x35c
     2ed:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     2f0:	73 6f                	jae    0x361
     2f2:	72 45                	jb     0x339
     2f4:	78 63                	js     0x359
     2f6:	65 70 74             	gs jo  0x36d
     2f9:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
     2fe:	00 00                	add    BYTE PTR [bx+si],al
     300:	00 00                	add    BYTE PTR [bx+si],al
     302:	00 00                	add    BYTE PTR [bx+si],al
     304:	1c 03                	sbb    al,0x3
     306:	0c 00                	or     al,0x0
     308:	e8 02 41             	call   0x440d
     30b:	03 64 20             	add    sp,WORD PTR [si+0x20]
     30e:	3d 03 9a             	cmp    ax,0x9a03
     311:	1f                   	pop    ds
     312:	0e                   	push   cs
     313:	03 cb                	add    cx,bx
     315:	1f                   	pop    ds
     316:	12 03                	adc    al,BYTE PTR [bp+di]
     318:	c4 29                	les    bp,DWORD PTR [bx+di]
     31a:	0a 03                	or     al,BYTE PTR [bp+di]
     31c:	06                   	push   es
     31d:	45                   	inc    bp
     31e:	46                   	inc    si
     31f:	61                   	popa
     320:	75 6c                	jne    0x38e
     322:	74 00                	je     0x324
     324:	00 00                	add    BYTE PTR [bx+si],al
     326:	00 00                	add    BYTE PTR [bx+si],al
     328:	00 00                	add    BYTE PTR [bx+si],al
     32a:	00 43 03             	add    BYTE PTR [bp+di+0x3],al
     32d:	0c 00                	or     al,0x0
     32f:	1c 03                	sbb    al,0x3
     331:	6a 03                	push   0x3
     333:	64 20 66 03          	and    BYTE PTR fs:[bp+0x3],ah
     337:	9a 1f 35 03 cb       	call   0xcb03:0x351f
     33c:	1f                   	pop    ds
     33d:	39 03                	cmp    WORD PTR [bp+di],ax
     33f:	c4 29                	les    bp,DWORD PTR [bx+di]
     341:	31 03                	xor    WORD PTR [bp+di],ax
     343:	08 45 47             	or     BYTE PTR [di+0x47],al
     346:	50                   	push   ax
     347:	46                   	inc    si
     348:	61                   	popa
     349:	75 6c                	jne    0x3b7
     34b:	74 00                	je     0x34d
     34d:	00 00                	add    BYTE PTR [bx+si],al
     34f:	00 00                	add    BYTE PTR [bx+si],al
     351:	00 00                	add    BYTE PTR [bx+si],al
     353:	00 6c 03             	add    BYTE PTR [si+0x3],ch
     356:	0c 00                	or     al,0x0
     358:	1c 03                	sbb    al,0x3
     35a:	96                   	xchg   si,ax
     35b:	03 64 20             	add    sp,WORD PTR [si+0x20]
     35e:	92                   	xchg   dx,ax
     35f:	03 9a 1f 5e          	add    bx,WORD PTR [bp+si+0x5e1f]
     363:	03 cb                	add    cx,bx
     365:	1f                   	pop    ds
     366:	62 03                	bound  ax,DWORD PTR [bp+di]
     368:	c4 29                	les    bp,DWORD PTR [bx+di]
     36a:	5a                   	pop    dx
     36b:	03 0b                	add    cx,WORD PTR [bp+di]
     36d:	45                   	inc    bp
     36e:	53                   	push   bx
     36f:	74 61                	je     0x3d2
     371:	63 6b 46             	arpl   WORD PTR [bp+di+0x46],bp
     374:	61                   	popa
     375:	75 6c                	jne    0x3e3
     377:	74 00                	je     0x379
     379:	00 00                	add    BYTE PTR [bx+si],al
     37b:	00 00                	add    BYTE PTR [bx+si],al
     37d:	00 00                	add    BYTE PTR [bx+si],al
     37f:	00 98 03 0c          	add    BYTE PTR [bx+si+0xc03],bl
     383:	00 1c                	add    BYTE PTR [si],bl
     385:	03 c1                	add    ax,cx
     387:	03 64 20             	add    sp,WORD PTR [si+0x20]
     38a:	bd 03 9a             	mov    bp,0x9a03
     38d:	1f                   	pop    ds
     38e:	8a 03                	mov    al,BYTE PTR [bp+di]
     390:	cb                   	retf
     391:	1f                   	pop    ds
     392:	8e 03                	mov    es,WORD PTR [bp+di]
     394:	c4 29                	les    bp,DWORD PTR [bx+di]
     396:	86 03                	xchg   BYTE PTR [bp+di],al
     398:	0a 45 50             	or     al,BYTE PTR [di+0x50]
     39b:	61                   	popa
     39c:	67 65 46             	addr32 gs inc si
     39f:	61                   	popa
     3a0:	75 6c                	jne    0x40e
     3a2:	74 00                	je     0x3a4
     3a4:	00 00                	add    BYTE PTR [bx+si],al
     3a6:	00 00                	add    BYTE PTR [bx+si],al
     3a8:	00 00                	add    BYTE PTR [bx+si],al
     3aa:	00 c3                	add    bl,al
     3ac:	03 0c                	add    cx,WORD PTR [si]
     3ae:	00 1c                	add    BYTE PTR [si],bl
     3b0:	03 f0                	add    si,ax
     3b2:	03 64 20             	add    sp,WORD PTR [si+0x20]
     3b5:	ec                   	in     al,dx
     3b6:	03 9a 1f b5          	add    bx,WORD PTR [bp+si-0x4ae1]
     3ba:	03 cb                	add    cx,bx
     3bc:	1f                   	pop    ds
     3bd:	b9 03 c4             	mov    cx,0xc403
     3c0:	29 b1 03 0e          	sub    WORD PTR [bx+di+0xe03],si
     3c4:	45                   	inc    bp
     3c5:	49                   	dec    cx
     3c6:	6e                   	outs   dx,BYTE PTR ds:[si]
     3c7:	76 61                	jbe    0x42a
     3c9:	6c                   	ins    BYTE PTR es:[di],dx
     3ca:	69 64 4f 70 43       	imul   sp,WORD PTR [si+0x4f],0x4370
     3cf:	6f                   	outs   dx,WORD PTR ds:[si]
     3d0:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
     3d4:	00 00                	add    BYTE PTR [bx+si],al
     3d6:	00 00                	add    BYTE PTR [bx+si],al
     3d8:	00 00                	add    BYTE PTR [bx+si],al
     3da:	f2 03 0c             	repnz add cx,WORD PTR [si]
     3dd:	00 e8                	add    al,ch
     3df:	02 1c                	add    bl,BYTE PTR [si]
     3e1:	04 64                	add    al,0x64
     3e3:	20 18                	and    BYTE PTR [bx+si],bl
     3e5:	04 9a                	add    al,0x9a
     3e7:	1f                   	pop    ds
     3e8:	e4 03                	in     al,0x3
     3ea:	cb                   	retf
     3eb:	1f                   	pop    ds
     3ec:	e8 03 c4             	call   0xc7f2
     3ef:	29 e0                	sub    ax,sp
     3f1:	03 0b                	add    cx,WORD PTR [bp+di]
     3f3:	45                   	inc    bp
     3f4:	42                   	inc    dx
     3f5:	72 65                	jb     0x45c
     3f7:	61                   	popa
     3f8:	6b 70 6f 69          	imul   si,WORD PTR [bx+si+0x6f],0x69
     3fc:	6e                   	outs   dx,BYTE PTR ds:[si]
     3fd:	74 00                	je     0x3ff
     3ff:	00 00                	add    BYTE PTR [bx+si],al
     401:	00 00                	add    BYTE PTR [bx+si],al
     403:	00 00                	add    BYTE PTR [bx+si],al
     405:	00 1e 04 0c          	add    BYTE PTR ds:0xc04,bl
     409:	00 e8                	add    al,ch
     40b:	02 62 04             	add    ah,BYTE PTR [bp+si+0x4]
     40e:	64 20 70 04          	and    BYTE PTR fs:[bx+si+0x4],dh
     412:	9a 1f 10 04 cb       	call   0xcb04:0x101f
     417:	1f                   	pop    ds
     418:	14 04                	adc    al,0x4
     41a:	c4 29                	les    bp,DWORD PTR [bx+di]
     41c:	0c 04                	or     al,0x4
     41e:	0b 45 53             	or     ax,WORD PTR [di+0x53]
     421:	69 6e 67 6c 65       	imul   bp,WORD PTR [bp+0x67],0x656c
     426:	53                   	push   bx
     427:	74 65                	je     0x48e
     429:	70 55                	jo     0x480
     42b:	89 e5                	mov    bp,sp
     42d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     430:	f7 66 04             	mul    WORD PTR [bp+0x4]
     433:	c9                   	leave
     434:	c2 04 00             	ret    0x4
     437:	55                   	push   bp
     438:	89 e5                	mov    bp,sp
     43a:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     43d:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
     440:	f7 76 0c             	div    WORD PTR [bp+0xc]
     443:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     446:	26 89 05             	mov    WORD PTR es:[di],ax
     449:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     44c:	26 89 15             	mov    WORD PTR es:[di],dx
     44f:	c9                   	leave
     450:	c2 0e 00             	ret    0xe
     453:	55                   	push   bp
     454:	89 e5                	mov    bp,sp
     456:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     459:	06                   	push   es
     45a:	57                   	push   di
     45b:	b0 01                	mov    al,0x1
     45d:	50                   	push   ax
     45e:	b8 ba 02             	mov    ax,0x2ba
     461:	ba 69 04             	mov    dx,0x469
     464:	52                   	push   dx
     465:	50                   	push   ax
     466:	9a e6 28 ca 05       	call   0x5ca:0x28e6
     46b:	52                   	push   dx
     46c:	50                   	push   ax
     46d:	9a 99 13 80 04       	call   0x480:0x1399
     472:	c9                   	leave
     473:	c2 04 00             	ret    0x4
     476:	c8 04 00 00          	enter  0x4,0x0
     47a:	ff 76 06             	push   WORD PTR [bp+0x6]
     47d:	9a 82 01 95 04       	call   0x495:0x182
     482:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     485:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     488:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     48b:	06                   	push   es
     48c:	57                   	push   di
     48d:	ff 76 06             	push   WORD PTR [bp+0x6]
     490:	6a 00                	push   0x0
     492:	9a e5 1e b9 04       	call   0x4b9:0x1ee5
     497:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     49a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     49d:	c9                   	leave
     49e:	ca 02 00             	retf   0x2
     4a1:	c8 04 00 00          	enter  0x4,0x0
     4a5:	31 c0                	xor    ax,ax
     4a7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     4aa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     4ad:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     4b1:	74 4c                	je     0x4ff
     4b3:	ff 76 06             	push   WORD PTR [bp+0x6]
     4b6:	9a 82 01 df 04       	call   0x4df:0x182
     4bb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     4be:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     4c1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     4c4:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
     4c7:	76 1e                	jbe    0x4e7
     4c9:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     4cc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     4cf:	03 f8                	add    di,ax
     4d1:	06                   	push   es
     4d2:	57                   	push   di
     4d3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     4d6:	2b 46 08             	sub    ax,WORD PTR [bp+0x8]
     4d9:	50                   	push   ax
     4da:	6a 00                	push   0x0
     4dc:	9a e5 1e fd 04       	call   0x4fd:0x1ee5
     4e1:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     4e4:	89 46 06             	mov    WORD PTR [bp+0x6],ax
     4e7:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     4eb:	74 12                	je     0x4ff
     4ed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     4f0:	06                   	push   es
     4f1:	57                   	push   di
     4f2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     4f5:	06                   	push   es
     4f6:	57                   	push   di
     4f7:	ff 76 06             	push   WORD PTR [bp+0x6]
     4fa:	9a c1 1e 11 05       	call   0x511:0x1ec1
     4ff:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
     503:	74 0e                	je     0x513
     505:	ff 76 0c             	push   WORD PTR [bp+0xc]
     508:	ff 76 0a             	push   WORD PTR [bp+0xa]
     50b:	ff 76 08             	push   WORD PTR [bp+0x8]
     50e:	9a 9c 01 6d 05       	call   0x56d:0x19c
     513:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     516:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     519:	c9                   	leave
     51a:	ca 08 00             	retf   0x8
     51d:	c8 08 00 00          	enter  0x8,0x0
     521:	a1 1a 17             	mov    ax,ds:0x171a
     524:	8b 16 1c 17          	mov    dx,WORD PTR ds:0x171c
     528:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     52b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     52e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     531:	26 8b 05             	mov    ax,WORD PTR es:[di]
     534:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     538:	a3 1a 17             	mov    ds:0x171a,ax
     53b:	89 16 1c 17          	mov    WORD PTR ds:0x171c,dx
     53f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     542:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     546:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     54a:	a3 6c 18             	mov    ds:0x186c,ax
     54d:	89 16 6e 18          	mov    WORD PTR ds:0x186e,dx
     551:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     554:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     558:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
     55c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     55f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     562:	ff 76 fe             	push   WORD PTR [bp-0x2]
     565:	ff 76 fc             	push   WORD PTR [bp-0x4]
     568:	6a 0c                	push   0xc
     56a:	9a 9c 01 7d 05       	call   0x57d:0x19c
     56f:	ff 5e f8             	call   DWORD PTR [bp-0x8]
     572:	c9                   	leave
     573:	cb                   	retf
     574:	c8 04 00 00          	enter  0x4,0x0
     578:	6a 0c                	push   0xc
     57a:	9a 82 01 00 06       	call   0x600:0x182
     57f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     582:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     585:	a1 1a 17             	mov    ax,ds:0x171a
     588:	8b 16 1c 17          	mov    dx,WORD PTR ds:0x171c
     58c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     58f:	26 89 05             	mov    WORD PTR es:[di],ax
     592:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     596:	a1 6c 18             	mov    ax,ds:0x186c
     599:	8b 16 6e 18          	mov    dx,WORD PTR ds:0x186e
     59d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5a0:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     5a4:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     5a8:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     5ab:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     5ae:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5b1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     5b5:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     5b9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     5bc:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     5bf:	a3 1a 17             	mov    ds:0x171a,ax
     5c2:	89 16 1c 17          	mov    WORD PTR ds:0x171c,dx
     5c6:	b8 1d 05             	mov    ax,0x51d
     5c9:	ba 6d 06             	mov    dx,0x66d
     5cc:	a3 6c 18             	mov    ds:0x186c,ax
     5cf:	89 16 6e 18          	mov    WORD PTR ds:0x186e,dx
     5d3:	c9                   	leave
     5d4:	ca 04 00             	retf   0x4
     5d7:	c8 04 00 00          	enter  0x4,0x0
     5db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5de:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     5e2:	75 0f                	jne    0x5f3
     5e4:	a1 16 17             	mov    ax,ds:0x1716
     5e7:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
     5eb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     5ee:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     5f1:	eb 27                	jmp    0x61a
     5f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5f6:	26 8a 05             	mov    al,BYTE PTR es:[di]
     5f9:	30 e4                	xor    ah,ah
     5fb:	40                   	inc    ax
     5fc:	50                   	push   ax
     5fd:	9a 82 01 18 06       	call   0x618:0x182
     602:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     605:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     608:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     60b:	06                   	push   es
     60c:	57                   	push   di
     60d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     610:	06                   	push   es
     611:	57                   	push   di
     612:	68 ff 00             	push   0xff
     615:	9a e7 17 4b 06       	call   0x64b:0x17e7
     61a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     61d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     620:	c9                   	leave
     621:	ca 04 00             	retf   0x4
     624:	55                   	push   bp
     625:	89 e5                	mov    bp,sp
     627:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     62a:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
     62d:	74 1e                	je     0x64d
     62f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     632:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     636:	74 15                	je     0x64d
     638:	ff 76 08             	push   WORD PTR [bp+0x8]
     63b:	ff 76 06             	push   WORD PTR [bp+0x6]
     63e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     641:	26 8a 05             	mov    al,BYTE PTR es:[di]
     644:	30 e4                	xor    ah,ah
     646:	40                   	inc    ax
     647:	50                   	push   ax
     648:	9a 9c 01 94 07       	call   0x794:0x19c
     64d:	c9                   	leave
     64e:	ca 04 00             	retf   0x4
     651:	c8 04 00 00          	enter  0x4,0x0
     655:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     658:	26 8b 05             	mov    ax,WORD PTR es:[di]
     65b:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     65f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     662:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     665:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     668:	06                   	push   es
     669:	57                   	push   di
     66a:	9a d7 05 82 06       	call   0x682:0x5d7
     66f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     672:	26 89 05             	mov    WORD PTR es:[di],ax
     675:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     679:	ff 76 fe             	push   WORD PTR [bp-0x2]
     67c:	ff 76 fc             	push   WORD PTR [bp-0x4]
     67f:	9a 24 06 ff 07       	call   0x7ff:0x624
     684:	c9                   	leave
     685:	ca 08 00             	retf   0x8
     688:	55                   	push   bp
     689:	89 e5                	mov    bp,sp
     68b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     68e:	26 8a 1d             	mov    bl,BYTE PTR es:[di]
     691:	30 ff                	xor    bh,bh
     693:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
     696:	29 d9                	sub    cx,bx
     698:	76 17                	jbe    0x6b1
     69a:	1e                   	push   ds
     69b:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     69e:	fc                   	cld
     69f:	ac                   	lods   al,BYTE PTR ds:[si]
     6a0:	30 e4                	xor    ah,ah
     6a2:	39 c1                	cmp    cx,ax
     6a4:	72 02                	jb     0x6a8
     6a6:	89 c1                	mov    cx,ax
     6a8:	26 00 0d             	add    BYTE PTR es:[di],cl
     6ab:	8d 79 01             	lea    di,[bx+di+0x1]
     6ae:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     6b0:	1f                   	pop    ds
     6b1:	c9                   	leave
     6b2:	ca 0a 00             	retf   0xa
     6b5:	55                   	push   bp
     6b6:	89 e5                	mov    bp,sp
     6b8:	1e                   	push   ds
     6b9:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     6bc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     6bf:	fc                   	cld
     6c0:	ac                   	lods   al,BYTE PTR ds:[si]
     6c1:	aa                   	stos   BYTE PTR es:[di],al
     6c2:	88 c1                	mov    cl,al
     6c4:	30 ed                	xor    ch,ch
     6c6:	e3 0e                	jcxz   0x6d6
     6c8:	ac                   	lods   al,BYTE PTR ds:[si]
     6c9:	3c 61                	cmp    al,0x61
     6cb:	72 06                	jb     0x6d3
     6cd:	3c 7a                	cmp    al,0x7a
     6cf:	77 02                	ja     0x6d3
     6d1:	2c 20                	sub    al,0x20
     6d3:	aa                   	stos   BYTE PTR es:[di],al
     6d4:	e2 f2                	loop   0x6c8
     6d6:	1f                   	pop    ds
     6d7:	c9                   	leave
     6d8:	ca 04 00             	retf   0x4
     6db:	55                   	push   bp
     6dc:	89 e5                	mov    bp,sp
     6de:	1e                   	push   ds
     6df:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     6e2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     6e5:	fc                   	cld
     6e6:	ac                   	lods   al,BYTE PTR ds:[si]
     6e7:	aa                   	stos   BYTE PTR es:[di],al
     6e8:	88 c1                	mov    cl,al
     6ea:	30 ed                	xor    ch,ch
     6ec:	e3 0e                	jcxz   0x6fc
     6ee:	ac                   	lods   al,BYTE PTR ds:[si]
     6ef:	3c 41                	cmp    al,0x41
     6f1:	72 06                	jb     0x6f9
     6f3:	3c 5a                	cmp    al,0x5a
     6f5:	77 02                	ja     0x6f9
     6f7:	04 20                	add    al,0x20
     6f9:	aa                   	stos   BYTE PTR es:[di],al
     6fa:	e2 f2                	loop   0x6ee
     6fc:	1f                   	pop    ds
     6fd:	c9                   	leave
     6fe:	ca 04 00             	retf   0x4
     701:	55                   	push   bp
     702:	89 e5                	mov    bp,sp
     704:	1e                   	push   ds
     705:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
     708:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     70b:	ac                   	lods   al,BYTE PTR ds:[si]
     70c:	30 e4                	xor    ah,ah
     70e:	26 8a 15             	mov    dl,BYTE PTR es:[di]
     711:	30 f6                	xor    dh,dh
     713:	47                   	inc    di
     714:	88 c1                	mov    cl,al
     716:	38 d1                	cmp    cl,dl
     718:	76 02                	jbe    0x71c
     71a:	88 d1                	mov    cl,dl
     71c:	30 ed                	xor    ch,ch
     71e:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
     720:	74 07                	je     0x729
     722:	8a 44 ff             	mov    al,BYTE PTR [si-0x1]
     725:	26 8a 55 ff          	mov    dl,BYTE PTR es:[di-0x1]
     729:	29 d0                	sub    ax,dx
     72b:	1f                   	pop    ds
     72c:	c9                   	leave
     72d:	ca 08 00             	retf   0x8
     730:	55                   	push   bp
     731:	89 e5                	mov    bp,sp
     733:	1e                   	push   ds
     734:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
     737:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     73a:	ac                   	lods   al,BYTE PTR ds:[si]
     73b:	30 e4                	xor    ah,ah
     73d:	26 8a 15             	mov    dl,BYTE PTR es:[di]
     740:	30 f6                	xor    dh,dh
     742:	47                   	inc    di
     743:	88 c1                	mov    cl,al
     745:	38 d1                	cmp    cl,dl
     747:	76 02                	jbe    0x74b
     749:	88 d1                	mov    cl,dl
     74b:	30 ed                	xor    ch,ch
     74d:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
     74f:	74 29                	je     0x77a
     751:	8a 5c ff             	mov    bl,BYTE PTR [si-0x1]
     754:	80 fb 61             	cmp    bl,0x61
     757:	72 08                	jb     0x761
     759:	80 fb 7a             	cmp    bl,0x7a
     75c:	77 03                	ja     0x761
     75e:	80 eb 20             	sub    bl,0x20
     761:	26 8a 7d ff          	mov    bh,BYTE PTR es:[di-0x1]
     765:	80 ff 61             	cmp    bh,0x61
     768:	72 08                	jb     0x772
     76a:	80 ff 7a             	cmp    bh,0x7a
     76d:	77 03                	ja     0x772
     76f:	80 ef 20             	sub    bh,0x20
     772:	38 fb                	cmp    bl,bh
     774:	74 d7                	je     0x74d
     776:	88 d8                	mov    al,bl
     778:	88 fa                	mov    dl,bh
     77a:	29 d0                	sub    ax,dx
     77c:	1f                   	pop    ds
     77d:	c9                   	leave
     77e:	ca 08 00             	retf   0x8
     781:	55                   	push   bp
     782:	89 e5                	mov    bp,sp
     784:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     787:	06                   	push   es
     788:	57                   	push   di
     789:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     78c:	06                   	push   es
     78d:	57                   	push   di
     78e:	68 ff 00             	push   0xff
     791:	9a e7 17 ca 07       	call   0x7ca:0x17e7
     796:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     799:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     79d:	74 14                	je     0x7b3
     79f:	81 c7 01 00          	add    di,0x1
     7a3:	06                   	push   es
     7a4:	57                   	push   di
     7a5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     7a8:	26 8a 05             	mov    al,BYTE PTR es:[di]
     7ab:	30 e4                	xor    ah,ah
     7ad:	50                   	push   ax
     7ae:	9a ff ff 00 00       	call   0x0:0xffff
     7b3:	c9                   	leave
     7b4:	ca 04 00             	retf   0x4
     7b7:	55                   	push   bp
     7b8:	89 e5                	mov    bp,sp
     7ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7bd:	06                   	push   es
     7be:	57                   	push   di
     7bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     7c2:	06                   	push   es
     7c3:	57                   	push   di
     7c4:	68 ff 00             	push   0xff
     7c7:	9a e7 17 eb 08       	call   0x8eb:0x17e7
     7cc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     7cf:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     7d3:	74 14                	je     0x7e9
     7d5:	81 c7 01 00          	add    di,0x1
     7d9:	06                   	push   es
     7da:	57                   	push   di
     7db:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     7de:	26 8a 05             	mov    al,BYTE PTR es:[di]
     7e1:	30 e4                	xor    ah,ah
     7e3:	50                   	push   ax
     7e4:	9a ff ff 00 00       	call   0x0:0xffff
     7e9:	c9                   	leave
     7ea:	ca 04 00             	retf   0x4
     7ed:	c8 02 02 00          	enter  0x202,0x0
     7f1:	8d be fe fe          	lea    di,[bp-0x102]
     7f5:	16                   	push   ss
     7f6:	57                   	push   di
     7f7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     7fa:	06                   	push   es
     7fb:	57                   	push   di
     7fc:	9a 4c 0d 11 08       	call   0x811:0xd4c
     801:	52                   	push   dx
     802:	50                   	push   ax
     803:	8d be fe fd          	lea    di,[bp-0x202]
     807:	16                   	push   ss
     808:	57                   	push   di
     809:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     80c:	06                   	push   es
     80d:	57                   	push   di
     80e:	9a 4c 0d d4 08       	call   0x8d4:0xd4c
     813:	52                   	push   dx
     814:	50                   	push   ax
     815:	9a ff ff 00 00       	call   0x0:0xffff
     81a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     81d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     820:	c9                   	leave
     821:	ca 08 00             	retf   0x8
     824:	c8 06 00 00          	enter  0x6,0x0
     828:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     82c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     82f:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     833:	74 18                	je     0x84d
     835:	26 8a 45 01          	mov    al,BYTE PTR es:[di+0x1]
     839:	3c 41                	cmp    al,0x41
     83b:	72 10                	jb     0x84d
     83d:	3c 5a                	cmp    al,0x5a
     83f:	76 0e                	jbe    0x84f
     841:	3c 5f                	cmp    al,0x5f
     843:	74 0a                	je     0x84f
     845:	3c 61                	cmp    al,0x61
     847:	72 04                	jb     0x84d
     849:	3c 7a                	cmp    al,0x7a
     84b:	76 02                	jbe    0x84f
     84d:	eb 50                	jmp    0x89f
     84f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     852:	26 8a 05             	mov    al,BYTE PTR es:[di]
     855:	30 e4                	xor    ah,ah
     857:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     85a:	b8 02 00             	mov    ax,0x2
     85d:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
     860:	7f 39                	jg     0x89b
     862:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     865:	eb 03                	jmp    0x86a
     867:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     86a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     86d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     870:	03 f8                	add    di,ax
     872:	26 8a 05             	mov    al,BYTE PTR es:[di]
     875:	3c 30                	cmp    al,0x30
     877:	72 18                	jb     0x891
     879:	3c 39                	cmp    al,0x39
     87b:	76 16                	jbe    0x893
     87d:	3c 41                	cmp    al,0x41
     87f:	72 10                	jb     0x891
     881:	3c 5a                	cmp    al,0x5a
     883:	76 0e                	jbe    0x893
     885:	3c 5f                	cmp    al,0x5f
     887:	74 0a                	je     0x893
     889:	3c 61                	cmp    al,0x61
     88b:	72 04                	jb     0x891
     88d:	3c 7a                	cmp    al,0x7a
     88f:	76 02                	jbe    0x893
     891:	eb 0c                	jmp    0x89f
     893:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     896:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
     899:	75 cc                	jne    0x867
     89b:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     89f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     8a2:	c9                   	leave
     8a3:	ca 04 00             	retf   0x4
     8a6:	02 25                	add    ah,BYTE PTR [di]
     8a8:	64 c8 08 00 00       	fs enter 0x8,0x0
     8ad:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     8b0:	06                   	push   es
     8b1:	57                   	push   di
     8b2:	68 ff 00             	push   0xff
     8b5:	bf a6 08             	mov    di,0x8a6
     8b8:	0e                   	push   cs
     8b9:	57                   	push   di
     8ba:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     8bd:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     8c0:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     8c3:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     8c6:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
     8ca:	8d 7e f8             	lea    di,[bp-0x8]
     8cd:	16                   	push   ss
     8ce:	57                   	push   di
     8cf:	6a 00                	push   0x0
     8d1:	9a 6c 10 1c 09       	call   0x91c:0x106c
     8d6:	c9                   	leave
     8d7:	ca 04 00             	retf   0x4
     8da:	c8 0e 01 00          	enter  0x10e,0x0
     8de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8e1:	06                   	push   es
     8e2:	57                   	push   di
     8e3:	8d 7e fa             	lea    di,[bp-0x6]
     8e6:	16                   	push   ss
     8e7:	57                   	push   di
     8e8:	9a fb 1d 7f 0a       	call   0xa7f:0x1dfb
     8ed:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     8f0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     8f3:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     8f7:	74 28                	je     0x921
     8f9:	8d be f2 fe          	lea    di,[bp-0x10e]
     8fd:	16                   	push   ss
     8fe:	57                   	push   di
     8ff:	6a 80                	push   0xff80
     901:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     904:	89 f8                	mov    ax,di
     906:	8c c2                	mov    dx,es
     908:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     90b:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     90e:	c6 46 f6 04          	mov    BYTE PTR [bp-0xa],0x4
     912:	8d 7e f2             	lea    di,[bp-0xe]
     915:	16                   	push   ss
     916:	57                   	push   di
     917:	6a 00                	push   0x0
     919:	9a 50 09 68 09       	call   0x968:0x950
     91e:	e8 32 fb             	call   0x453
     921:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     924:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     927:	c9                   	leave
     928:	ca 04 00             	retf   0x4
     92b:	55                   	push   bp
     92c:	89 e5                	mov    bp,sp
     92e:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     932:	ff 76 06             	push   WORD PTR [bp+0x6]
     935:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     938:	81 c7 01 00          	add    di,0x1
     93c:	06                   	push   es
     93d:	57                   	push   di
     93e:	68 fe 00             	push   0xfe
     941:	9a 17 28 00 00       	call   0x0:0x2817
     946:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     949:	26 88 05             	mov    BYTE PTR es:[di],al
     94c:	c9                   	leave
     94d:	ca 02 00             	retf   0x2
     950:	c8 00 01 00          	enter  0x100,0x0
     954:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     957:	06                   	push   es
     958:	57                   	push   di
     959:	68 ff 00             	push   0xff
     95c:	8d be 00 ff          	lea    di,[bp-0x100]
     960:	16                   	push   ss
     961:	57                   	push   di
     962:	ff 76 0c             	push   WORD PTR [bp+0xc]
     965:	9a 2b 09 75 09       	call   0x975:0x92b
     96a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     96d:	06                   	push   es
     96e:	57                   	push   di
     96f:	ff 76 06             	push   WORD PTR [bp+0x6]
     972:	9a 6c 10 8e 09       	call   0x98e:0x106c
     977:	c9                   	leave
     978:	ca 08 00             	retf   0x8
     97b:	55                   	push   bp
     97c:	89 e5                	mov    bp,sp
     97e:	ff 76 0a             	push   WORD PTR [bp+0xa]
     981:	ff 76 08             	push   WORD PTR [bp+0x8]
     984:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     987:	06                   	push   es
     988:	57                   	push   di
     989:	6a 4f                	push   0x4f
     98b:	9a 6a 0d 32 0a       	call   0xa32:0xd6a
     990:	52                   	push   dx
     991:	50                   	push   ax
     992:	ff 76 0a             	push   WORD PTR [bp+0xa]
     995:	ff 76 08             	push   WORD PTR [bp+0x8]
     998:	9a ff ff 00 00       	call   0x0:0xffff
     99d:	c9                   	leave
     99e:	c2 08 00             	ret    0x8
     9a1:	c8 50 00 00          	enter  0x50,0x0
     9a5:	8d 7e b0             	lea    di,[bp-0x50]
     9a8:	16                   	push   ss
     9a9:	57                   	push   di
     9aa:	ff 76 0a             	push   WORD PTR [bp+0xa]
     9ad:	ff 76 08             	push   WORD PTR [bp+0x8]
     9b0:	e8 c8 ff             	call   0x97b
     9b3:	1e                   	push   ds
     9b4:	8d 56 b0             	lea    dx,[bp-0x50]
     9b7:	16                   	push   ss
     9b8:	1f                   	pop    ds
     9b9:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     9bc:	b4 3d                	mov    ah,0x3d
     9be:	cd 21                	int    0x21
     9c0:	1f                   	pop    ds
     9c1:	73 02                	jae    0x9c5
     9c3:	f7 d8                	neg    ax
     9c5:	c9                   	leave
     9c6:	ca 06 00             	retf   0x6
     9c9:	c8 50 00 00          	enter  0x50,0x0
     9cd:	8d 7e b0             	lea    di,[bp-0x50]
     9d0:	16                   	push   ss
     9d1:	57                   	push   di
     9d2:	ff 76 08             	push   WORD PTR [bp+0x8]
     9d5:	ff 76 06             	push   WORD PTR [bp+0x6]
     9d8:	e8 a0 ff             	call   0x97b
     9db:	1e                   	push   ds
     9dc:	8d 56 b0             	lea    dx,[bp-0x50]
     9df:	16                   	push   ss
     9e0:	1f                   	pop    ds
     9e1:	31 c9                	xor    cx,cx
     9e3:	b4 3c                	mov    ah,0x3c
     9e5:	cd 21                	int    0x21
     9e7:	1f                   	pop    ds
     9e8:	73 02                	jae    0x9ec
     9ea:	f7 d8                	neg    ax
     9ec:	c9                   	leave
     9ed:	ca 04 00             	retf   0x4
     9f0:	c8 80 00 00          	enter  0x80,0x0
     9f4:	8d 7e b0             	lea    di,[bp-0x50]
     9f7:	16                   	push   ss
     9f8:	57                   	push   di
     9f9:	ff 76 08             	push   WORD PTR [bp+0x8]
     9fc:	ff 76 06             	push   WORD PTR [bp+0x6]
     9ff:	e8 79 ff             	call   0x97b
     a02:	1e                   	push   ds
     a03:	16                   	push   ss
     a04:	1f                   	pop    ds
     a05:	8d 56 80             	lea    dx,[bp-0x80]
     a08:	b4 1a                	mov    ah,0x1a
     a0a:	cd 21                	int    0x21
     a0c:	8d 56 b0             	lea    dx,[bp-0x50]
     a0f:	31 c9                	xor    cx,cx
     a11:	b4 4e                	mov    ah,0x4e
     a13:	cd 21                	int    0x21
     a15:	1f                   	pop    ds
     a16:	8b 46 96             	mov    ax,WORD PTR [bp-0x6a]
     a19:	8b 56 98             	mov    dx,WORD PTR [bp-0x68]
     a1c:	73 04                	jae    0xa22
     a1e:	b8 ff ff             	mov    ax,0xffff
     a21:	99                   	cwd
     a22:	c9                   	leave
     a23:	ca 04 00             	retf   0x4
     a26:	c8 02 00 00          	enter  0x2,0x0
     a2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a2d:	06                   	push   es
     a2e:	57                   	push   di
     a2f:	9a f0 09 72 0a       	call   0xa72:0x9f0
     a34:	83 fa ff             	cmp    dx,0xffff
     a37:	75 09                	jne    0xa42
     a39:	3d ff ff             	cmp    ax,0xffff
     a3c:	75 04                	jne    0xa42
     a3e:	b0 00                	mov    al,0x0
     a40:	eb 02                	jmp    0xa44
     a42:	b0 01                	mov    al,0x1
     a44:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     a47:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     a4a:	c9                   	leave
     a4b:	ca 04 00             	retf   0x4
     a4e:	c8 00 01 00          	enter  0x100,0x0
     a52:	ff 76 06             	push   WORD PTR [bp+0x6]
     a55:	ff 76 04             	push   WORD PTR [bp+0x4]
     a58:	ff 76 06             	push   WORD PTR [bp+0x6]
     a5b:	ff 76 04             	push   WORD PTR [bp+0x4]
     a5e:	9a ff ff 00 00       	call   0x0:0xffff
     a63:	8d be 00 ff          	lea    di,[bp-0x100]
     a67:	16                   	push   ss
     a68:	57                   	push   di
     a69:	ff 76 06             	push   WORD PTR [bp+0x6]
     a6c:	ff 76 04             	push   WORD PTR [bp+0x4]
     a6f:	9a 6e 0e f5 0e       	call   0xef5:0xe6e
     a74:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     a77:	06                   	push   es
     a78:	57                   	push   di
     a79:	68 ff 00             	push   0xff
     a7c:	9a e7 17 51 0b       	call   0xb51:0x17e7
     a81:	c9                   	leave
     a82:	c2 04 00             	ret    0x4
     a85:	c8 50 00 00          	enter  0x50,0x0
     a89:	1e                   	push   ds
     a8a:	c5 56 06             	lds    dx,DWORD PTR [bp+0x6]
     a8d:	b4 1a                	mov    ah,0x1a
     a8f:	cd 21                	int    0x21
     a91:	1f                   	pop    ds
     a92:	8d 7e b0             	lea    di,[bp-0x50]
     a95:	16                   	push   ss
     a96:	57                   	push   di
     a97:	ff 76 0e             	push   WORD PTR [bp+0xe]
     a9a:	ff 76 0c             	push   WORD PTR [bp+0xc]
     a9d:	e8 db fe             	call   0x97b
     aa0:	1e                   	push   ds
     aa1:	16                   	push   ss
     aa2:	1f                   	pop    ds
     aa3:	8d 56 b0             	lea    dx,[bp-0x50]
     aa6:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
     aa9:	b4 4e                	mov    ah,0x4e
     aab:	cd 21                	int    0x21
     aad:	1f                   	pop    ds
     aae:	72 12                	jb     0xac2
     ab0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ab3:	83 c7 1e             	add    di,0x1e
     ab6:	06                   	push   es
     ab7:	57                   	push   di
     ab8:	06                   	push   es
     ab9:	57                   	push   di
     aba:	e8 91 ff             	call   0xa4e
     abd:	83 c4 04             	add    sp,0x4
     ac0:	31 c0                	xor    ax,ax
     ac2:	f7 d8                	neg    ax
     ac4:	c9                   	leave
     ac5:	ca 0a 00             	retf   0xa
     ac8:	55                   	push   bp
     ac9:	89 e5                	mov    bp,sp
     acb:	1e                   	push   ds
     acc:	c5 56 06             	lds    dx,DWORD PTR [bp+0x6]
     acf:	b4 1a                	mov    ah,0x1a
     ad1:	cd 21                	int    0x21
     ad3:	1f                   	pop    ds
     ad4:	b4 4f                	mov    ah,0x4f
     ad6:	cd 21                	int    0x21
     ad8:	72 12                	jb     0xaec
     ada:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     add:	83 c7 1e             	add    di,0x1e
     ae0:	06                   	push   es
     ae1:	57                   	push   di
     ae2:	06                   	push   es
     ae3:	57                   	push   di
     ae4:	e8 67 ff             	call   0xa4e
     ae7:	83 c4 04             	add    sp,0x4
     aea:	31 c0                	xor    ax,ax
     aec:	f7 d8                	neg    ax
     aee:	c9                   	leave
     aef:	ca 04 00             	retf   0x4
     af2:	c8 02 01 00          	enter  0x102,0x0
     af6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     af9:	26 8a 05             	mov    al,BYTE PTR es:[di]
     afc:	30 e4                	xor    ah,ah
     afe:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     b01:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     b05:	7e 1c                	jle    0xb23
     b07:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b0a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b0d:	03 f8                	add    di,ax
     b0f:	26 8a 05             	mov    al,BYTE PTR es:[di]
     b12:	3c 2e                	cmp    al,0x2e
     b14:	74 0d                	je     0xb23
     b16:	3c 3a                	cmp    al,0x3a
     b18:	74 09                	je     0xb23
     b1a:	3c 5c                	cmp    al,0x5c
     b1c:	74 05                	je     0xb23
     b1e:	ff 4e fe             	dec    WORD PTR [bp-0x2]
     b21:	eb de                	jmp    0xb01
     b23:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     b27:	74 0e                	je     0xb37
     b29:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b2c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b2f:	03 f8                	add    di,ax
     b31:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
     b35:	74 05                	je     0xb3c
     b37:	c7 46 fe 00 01       	mov    WORD PTR [bp-0x2],0x100
     b3c:	8d be fe fe          	lea    di,[bp-0x102]
     b40:	16                   	push   ss
     b41:	57                   	push   di
     b42:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b45:	06                   	push   es
     b46:	57                   	push   di
     b47:	6a 01                	push   0x1
     b49:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b4c:	48                   	dec    ax
     b4d:	50                   	push   ax
     b4e:	9a 0b 18 5b 0b       	call   0xb5b:0x180b
     b53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b56:	06                   	push   es
     b57:	57                   	push   di
     b58:	9a 4c 18 68 0b       	call   0xb68:0x184c
     b5d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     b60:	06                   	push   es
     b61:	57                   	push   di
     b62:	68 ff 00             	push   0xff
     b65:	9a e7 17 ae 0b       	call   0xbae:0x17e7
     b6a:	c9                   	leave
     b6b:	ca 08 00             	retf   0x8
     b6e:	c8 02 01 00          	enter  0x102,0x0
     b72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b75:	26 8a 05             	mov    al,BYTE PTR es:[di]
     b78:	30 e4                	xor    ah,ah
     b7a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     b7d:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     b81:	7e 18                	jle    0xb9b
     b83:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b89:	03 f8                	add    di,ax
     b8b:	26 8a 05             	mov    al,BYTE PTR es:[di]
     b8e:	3c 3a                	cmp    al,0x3a
     b90:	74 09                	je     0xb9b
     b92:	3c 5c                	cmp    al,0x5c
     b94:	74 05                	je     0xb9b
     b96:	ff 4e fe             	dec    WORD PTR [bp-0x2]
     b99:	eb e2                	jmp    0xb7d
     b9b:	8d be fe fe          	lea    di,[bp-0x102]
     b9f:	16                   	push   ss
     ba0:	57                   	push   di
     ba1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ba4:	06                   	push   es
     ba5:	57                   	push   di
     ba6:	6a 01                	push   0x1
     ba8:	ff 76 fe             	push   WORD PTR [bp-0x2]
     bab:	9a 0b 18 bb 0b       	call   0xbbb:0x180b
     bb0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     bb3:	06                   	push   es
     bb4:	57                   	push   di
     bb5:	68 ff 00             	push   0xff
     bb8:	9a e7 17 04 0c       	call   0xc04:0x17e7
     bbd:	c9                   	leave
     bbe:	ca 04 00             	retf   0x4
     bc1:	c8 02 01 00          	enter  0x102,0x0
     bc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bc8:	26 8a 05             	mov    al,BYTE PTR es:[di]
     bcb:	30 e4                	xor    ah,ah
     bcd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     bd0:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     bd4:	7e 18                	jle    0xbee
     bd6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     bd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bdc:	03 f8                	add    di,ax
     bde:	26 8a 05             	mov    al,BYTE PTR es:[di]
     be1:	3c 3a                	cmp    al,0x3a
     be3:	74 09                	je     0xbee
     be5:	3c 5c                	cmp    al,0x5c
     be7:	74 05                	je     0xbee
     be9:	ff 4e fe             	dec    WORD PTR [bp-0x2]
     bec:	eb e2                	jmp    0xbd0
     bee:	8d be fe fe          	lea    di,[bp-0x102]
     bf2:	16                   	push   ss
     bf3:	57                   	push   di
     bf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bf7:	06                   	push   es
     bf8:	57                   	push   di
     bf9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     bfc:	40                   	inc    ax
     bfd:	50                   	push   ax
     bfe:	68 ff 00             	push   0xff
     c01:	9a 0b 18 11 0c       	call   0xc11:0x180b
     c06:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c09:	06                   	push   es
     c0a:	57                   	push   di
     c0b:	68 ff 00             	push   0xff
     c0e:	9a e7 17 70 0c       	call   0xc70:0x17e7
     c13:	c9                   	leave
     c14:	ca 04 00             	retf   0x4
     c17:	c8 02 01 00          	enter  0x102,0x0
     c1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c1e:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c21:	30 e4                	xor    ah,ah
     c23:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c26:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     c2a:	7e 1c                	jle    0xc48
     c2c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c32:	03 f8                	add    di,ax
     c34:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c37:	3c 2e                	cmp    al,0x2e
     c39:	74 0d                	je     0xc48
     c3b:	3c 3a                	cmp    al,0x3a
     c3d:	74 09                	je     0xc48
     c3f:	3c 5c                	cmp    al,0x5c
     c41:	74 05                	je     0xc48
     c43:	ff 4e fe             	dec    WORD PTR [bp-0x2]
     c46:	eb de                	jmp    0xc26
     c48:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
     c4c:	7e 33                	jle    0xc81
     c4e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     c51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c54:	03 f8                	add    di,ax
     c56:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
     c5a:	75 25                	jne    0xc81
     c5c:	8d be fe fe          	lea    di,[bp-0x102]
     c60:	16                   	push   ss
     c61:	57                   	push   di
     c62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c65:	06                   	push   es
     c66:	57                   	push   di
     c67:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c6a:	68 ff 00             	push   0xff
     c6d:	9a 0b 18 7d 0c       	call   0xc7d:0x180b
     c72:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c75:	06                   	push   es
     c76:	57                   	push   di
     c77:	68 ff 00             	push   0xff
     c7a:	9a e7 17 9d 0e       	call   0xe9d:0x17e7
     c7f:	eb 07                	jmp    0xc88
     c81:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c84:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     c88:	c9                   	leave
     c89:	ca 04 00             	retf   0x4
     c8c:	55                   	push   bp
     c8d:	89 e5                	mov    bp,sp
     c8f:	fc                   	cld
     c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c93:	b9 ff ff             	mov    cx,0xffff
     c96:	30 c0                	xor    al,al
     c98:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     c9a:	b8 fe ff             	mov    ax,0xfffe
     c9d:	29 c8                	sub    ax,cx
     c9f:	c9                   	leave
     ca0:	ca 04 00             	retf   0x4
     ca3:	55                   	push   bp
     ca4:	89 e5                	mov    bp,sp
     ca6:	fc                   	cld
     ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     caa:	b9 ff ff             	mov    cx,0xffff
     cad:	30 c0                	xor    al,al
     caf:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     cb1:	89 f8                	mov    ax,di
     cb3:	8c c2                	mov    dx,es
     cb5:	48                   	dec    ax
     cb6:	c9                   	leave
     cb7:	ca 04 00             	retf   0x4
     cba:	55                   	push   bp
     cbb:	89 e5                	mov    bp,sp
     cbd:	1e                   	push   ds
     cbe:	fc                   	cld
     cbf:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
     cc2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     cc5:	89 f8                	mov    ax,di
     cc7:	8c c2                	mov    dx,es
     cc9:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     ccc:	39 fe                	cmp    si,di
     cce:	73 07                	jae    0xcd7
     cd0:	fd                   	std
     cd1:	01 ce                	add    si,cx
     cd3:	01 cf                	add    di,cx
     cd5:	4e                   	dec    si
     cd6:	4f                   	dec    di
     cd7:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     cd9:	fc                   	cld
     cda:	1f                   	pop    ds
     cdb:	c9                   	leave
     cdc:	ca 0a 00             	retf   0xa
     cdf:	55                   	push   bp
     ce0:	89 e5                	mov    bp,sp
     ce2:	1e                   	push   ds
     ce3:	fc                   	cld
     ce4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce7:	b9 ff ff             	mov    cx,0xffff
     cea:	30 c0                	xor    al,al
     cec:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     cee:	f7 d1                	not    cx
     cf0:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     cf3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     cf6:	89 f8                	mov    ax,di
     cf8:	8c c2                	mov    dx,es
     cfa:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     cfc:	1f                   	pop    ds
     cfd:	c9                   	leave
     cfe:	ca 08 00             	retf   0x8
     d01:	55                   	push   bp
     d02:	89 e5                	mov    bp,sp
     d04:	1e                   	push   ds
     d05:	fc                   	cld
     d06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d09:	b9 ff ff             	mov    cx,0xffff
     d0c:	30 c0                	xor    al,al
     d0e:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     d10:	f7 d1                	not    cx
     d12:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     d15:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d18:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     d1a:	89 f8                	mov    ax,di
     d1c:	8c c2                	mov    dx,es
     d1e:	48                   	dec    ax
     d1f:	1f                   	pop    ds
     d20:	c9                   	leave
     d21:	ca 08 00             	retf   0x8
     d24:	55                   	push   bp
     d25:	89 e5                	mov    bp,sp
     d27:	1e                   	push   ds
     d28:	fc                   	cld
     d29:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     d2c:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     d2f:	89 cb                	mov    bx,cx
     d31:	30 c0                	xor    al,al
     d33:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     d35:	29 cb                	sub    bx,cx
     d37:	89 d9                	mov    cx,bx
     d39:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
     d3c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     d3f:	89 fb                	mov    bx,di
     d41:	8c c2                	mov    dx,es
     d43:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     d45:	aa                   	stos   BYTE PTR es:[di],al
     d46:	93                   	xchg   bx,ax
     d47:	1f                   	pop    ds
     d48:	c9                   	leave
     d49:	ca 0a 00             	retf   0xa
     d4c:	55                   	push   bp
     d4d:	89 e5                	mov    bp,sp
     d4f:	1e                   	push   ds
     d50:	fc                   	cld
     d51:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     d54:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d57:	89 fb                	mov    bx,di
     d59:	8c c2                	mov    dx,es
     d5b:	ac                   	lods   al,BYTE PTR ds:[si]
     d5c:	30 e4                	xor    ah,ah
     d5e:	91                   	xchg   cx,ax
     d5f:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     d61:	30 c0                	xor    al,al
     d63:	aa                   	stos   BYTE PTR es:[di],al
     d64:	93                   	xchg   bx,ax
     d65:	1f                   	pop    ds
     d66:	c9                   	leave
     d67:	ca 08 00             	retf   0x8
     d6a:	55                   	push   bp
     d6b:	89 e5                	mov    bp,sp
     d6d:	1e                   	push   ds
     d6e:	fc                   	cld
     d6f:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
     d72:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     d75:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     d78:	89 fb                	mov    bx,di
     d7a:	8c c2                	mov    dx,es
     d7c:	ac                   	lods   al,BYTE PTR ds:[si]
     d7d:	30 e4                	xor    ah,ah
     d7f:	39 c8                	cmp    ax,cx
     d81:	77 01                	ja     0xd84
     d83:	91                   	xchg   cx,ax
     d84:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     d86:	30 c0                	xor    al,al
     d88:	aa                   	stos   BYTE PTR es:[di],al
     d89:	93                   	xchg   bx,ax
     d8a:	1f                   	pop    ds
     d8b:	c9                   	leave
     d8c:	ca 0a 00             	retf   0xa
     d8f:	55                   	push   bp
     d90:	89 e5                	mov    bp,sp
     d92:	ff 76 0c             	push   WORD PTR [bp+0xc]
     d95:	ff 76 0a             	push   WORD PTR [bp+0xa]
     d98:	0e                   	push   cs
     d99:	e8 07 ff             	call   0xca3
     d9c:	52                   	push   dx
     d9d:	50                   	push   ax
     d9e:	ff 76 08             	push   WORD PTR [bp+0x8]
     da1:	ff 76 06             	push   WORD PTR [bp+0x6]
     da4:	0e                   	push   cs
     da5:	e8 37 ff             	call   0xcdf
     da8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     dab:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     dae:	c9                   	leave
     daf:	ca 08 00             	retf   0x8
     db2:	55                   	push   bp
     db3:	89 e5                	mov    bp,sp
     db5:	1e                   	push   ds
     db6:	fc                   	cld
     db7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dba:	89 fe                	mov    si,di
     dbc:	b9 ff ff             	mov    cx,0xffff
     dbf:	31 c0                	xor    ax,ax
     dc1:	99                   	cwd
     dc2:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     dc4:	f7 d1                	not    cx
     dc6:	89 f7                	mov    di,si
     dc8:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
     dcb:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
     dcd:	8a 44 ff             	mov    al,BYTE PTR [si-0x1]
     dd0:	26 8a 55 ff          	mov    dl,BYTE PTR es:[di-0x1]
     dd4:	29 d0                	sub    ax,dx
     dd6:	1f                   	pop    ds
     dd7:	c9                   	leave
     dd8:	ca 08 00             	retf   0x8
     ddb:	55                   	push   bp
     ddc:	89 e5                	mov    bp,sp
     dde:	1e                   	push   ds
     ddf:	fc                   	cld
     de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de3:	89 fe                	mov    si,di
     de5:	b9 ff ff             	mov    cx,0xffff
     de8:	31 c0                	xor    ax,ax
     dea:	99                   	cwd
     deb:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     ded:	f7 d1                	not    cx
     def:	89 f7                	mov    di,si
     df1:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
     df4:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
     df6:	74 22                	je     0xe1a
     df8:	8a 44 ff             	mov    al,BYTE PTR [si-0x1]
     dfb:	3c 61                	cmp    al,0x61
     dfd:	72 06                	jb     0xe05
     dff:	3c 7a                	cmp    al,0x7a
     e01:	77 02                	ja     0xe05
     e03:	2c 20                	sub    al,0x20
     e05:	26 8a 55 ff          	mov    dl,BYTE PTR es:[di-0x1]
     e09:	80 fa 61             	cmp    dl,0x61
     e0c:	72 08                	jb     0xe16
     e0e:	80 fa 7a             	cmp    dl,0x7a
     e11:	77 03                	ja     0xe16
     e13:	80 ea 20             	sub    dl,0x20
     e16:	29 d0                	sub    ax,dx
     e18:	74 da                	je     0xdf4
     e1a:	1f                   	pop    ds
     e1b:	c9                   	leave
     e1c:	ca 08 00             	retf   0x8
     e1f:	55                   	push   bp
     e20:	89 e5                	mov    bp,sp
     e22:	fc                   	cld
     e23:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     e26:	89 fe                	mov    si,di
     e28:	b9 ff ff             	mov    cx,0xffff
     e2b:	30 c0                	xor    al,al
     e2d:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     e2f:	f7 d1                	not    cx
     e31:	89 f7                	mov    di,si
     e33:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     e36:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     e38:	b8 00 00             	mov    ax,0x0
     e3b:	99                   	cwd
     e3c:	75 05                	jne    0xe43
     e3e:	89 f8                	mov    ax,di
     e40:	8c c2                	mov    dx,es
     e42:	48                   	dec    ax
     e43:	c9                   	leave
     e44:	ca 06 00             	retf   0x6
     e47:	55                   	push   bp
     e48:	89 e5                	mov    bp,sp
     e4a:	fc                   	cld
     e4b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     e4e:	b9 ff ff             	mov    cx,0xffff
     e51:	30 c0                	xor    al,al
     e53:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     e55:	f7 d1                	not    cx
     e57:	fd                   	std
     e58:	4f                   	dec    di
     e59:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     e5c:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     e5e:	b8 00 00             	mov    ax,0x0
     e61:	99                   	cwd
     e62:	75 05                	jne    0xe69
     e64:	89 f8                	mov    ax,di
     e66:	8c c2                	mov    dx,es
     e68:	40                   	inc    ax
     e69:	fc                   	cld
     e6a:	c9                   	leave
     e6b:	ca 06 00             	retf   0x6
     e6e:	55                   	push   bp
     e6f:	89 e5                	mov    bp,sp
     e71:	1e                   	push   ds
     e72:	fc                   	cld
     e73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e76:	b9 00 01             	mov    cx,0x100
     e79:	30 c0                	xor    al,al
     e7b:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     e7d:	f6 d1                	not    cl
     e7f:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     e82:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     e85:	88 c8                	mov    al,cl
     e87:	aa                   	stos   BYTE PTR es:[di],al
     e88:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     e8a:	1f                   	pop    ds
     e8b:	c9                   	leave
     e8c:	ca 04 00             	retf   0x4
     e8f:	c8 04 00 00          	enter  0x4,0x0
     e93:	83 46 06 02          	add    WORD PTR [bp+0x6],0x2
     e97:	ff 76 06             	push   WORD PTR [bp+0x6]
     e9a:	9a 82 01 41 0f       	call   0xf41:0x182
     e9f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ea2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ea5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ea8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     eab:	26 89 05             	mov    WORD PTR es:[di],ax
     eae:	83 46 fc 02          	add    WORD PTR [bp-0x4],0x2
     eb2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     eb5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     eb8:	c9                   	leave
     eb9:	ca 02 00             	retf   0x2
     ebc:	c8 02 00 00          	enter  0x2,0x0
     ec0:	83 6e 06 02          	sub    WORD PTR [bp+0x6],0x2
     ec4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ec7:	26 8b 05             	mov    ax,WORD PTR es:[di]
     eca:	48                   	dec    ax
     ecb:	48                   	dec    ax
     ecc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ecf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ed2:	c9                   	leave
     ed3:	ca 04 00             	retf   0x4
     ed6:	c8 06 00 00          	enter  0x6,0x0
     eda:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     edd:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
     ee0:	75 0a                	jne    0xeec
     ee2:	31 c0                	xor    ax,ax
     ee4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ee7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     eea:	eb 2d                	jmp    0xf19
     eec:	ff 76 08             	push   WORD PTR [bp+0x8]
     eef:	ff 76 06             	push   WORD PTR [bp+0x6]
     ef2:	9a 8c 0c 01 0f       	call   0xf01:0xc8c
     ef7:	40                   	inc    ax
     ef8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     efb:	ff 76 fa             	push   WORD PTR [bp-0x6]
     efe:	9a 8f 0e 11 0f       	call   0xf11:0xe8f
     f03:	52                   	push   dx
     f04:	50                   	push   ax
     f05:	ff 76 08             	push   WORD PTR [bp+0x8]
     f08:	ff 76 06             	push   WORD PTR [bp+0x6]
     f0b:	ff 76 fa             	push   WORD PTR [bp-0x6]
     f0e:	9a ba 0c 67 0f       	call   0xf67:0xcba
     f13:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f16:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f19:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f1c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     f1f:	c9                   	leave
     f20:	ca 04 00             	retf   0x4
     f23:	55                   	push   bp
     f24:	89 e5                	mov    bp,sp
     f26:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     f29:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
     f2c:	74 15                	je     0xf43
     f2e:	83 6e 06 02          	sub    WORD PTR [bp+0x6],0x2
     f32:	ff 76 08             	push   WORD PTR [bp+0x8]
     f35:	ff 76 06             	push   WORD PTR [bp+0x6]
     f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f3b:	26 ff 35             	push   WORD PTR es:[di]
     f3e:	9a 9c 01 cd 11       	call   0x11cd:0x19c
     f43:	c9                   	leave
     f44:	ca 04 00             	retf   0x4
     f47:	c8 28 01 00          	enter  0x128,0x0
     f4b:	83 7e 04 1f          	cmp    WORD PTR [bp+0x4],0x1f
     f4f:	76 05                	jbe    0xf56
     f51:	c7 46 04 1f 00       	mov    WORD PTR [bp+0x4],0x1f
     f56:	8d 7e e0             	lea    di,[bp-0x20]
     f59:	16                   	push   ss
     f5a:	57                   	push   di
     f5b:	ff 76 08             	push   WORD PTR [bp+0x8]
     f5e:	ff 76 06             	push   WORD PTR [bp+0x6]
     f61:	ff 76 04             	push   WORD PTR [bp+0x4]
     f64:	9a ba 0c 9a 0f       	call   0xf9a:0xcba
     f69:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
     f6c:	c6 43 e0 00          	mov    BYTE PTR [bp+di-0x20],0x0
     f70:	8d be d8 fe          	lea    di,[bp-0x128]
     f74:	16                   	push   ss
     f75:	57                   	push   di
     f76:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     f79:	99                   	cwd
     f7a:	05 a5 ff             	add    ax,0xffa5
     f7d:	83 d2 00             	adc    dx,0x0
     f80:	50                   	push   ax
     f81:	8d 46 e0             	lea    ax,[bp-0x20]
     f84:	8c d2                	mov    dx,ss
     f86:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     f89:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     f8c:	c6 46 dc 06          	mov    BYTE PTR [bp-0x24],0x6
     f90:	8d 7e d8             	lea    di,[bp-0x28]
     f93:	16                   	push   ss
     f94:	57                   	push   di
     f95:	6a 00                	push   0x0
     f97:	9a 50 09 bc 0f       	call   0xfbc:0x950
     f9c:	e8 b4 f4             	call   0x453
     f9f:	c9                   	leave
     fa0:	c2 08 00             	ret    0x8
     fa3:	c8 04 00 00          	enter  0x4,0x0
     fa7:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     faa:	06                   	push   es
     fab:	57                   	push   di
     fac:	6a ff                	push   0xffff
     fae:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     fb1:	06                   	push   es
     fb2:	57                   	push   di
     fb3:	ff 76 0e             	push   WORD PTR [bp+0xe]
     fb6:	ff 76 0c             	push   WORD PTR [bp+0xc]
     fb9:	9a 8c 0c ca 0f       	call   0xfca:0xc8c
     fbe:	50                   	push   ax
     fbf:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     fc2:	06                   	push   es
     fc3:	57                   	push   di
     fc4:	ff 76 06             	push   WORD PTR [bp+0x6]
     fc7:	9a 50 2e 05 10       	call   0x1005:0x2e50
     fcc:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     fcf:	03 f8                	add    di,ax
     fd1:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     fd5:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
     fd8:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
     fdb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     fde:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     fe1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     fe4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     fe7:	c9                   	leave
     fe8:	ca 0e 00             	retf   0xe
     feb:	c8 04 00 00          	enter  0x4,0x0
     fef:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     ff2:	06                   	push   es
     ff3:	57                   	push   di
     ff4:	ff 76 10             	push   WORD PTR [bp+0x10]
     ff7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     ffa:	06                   	push   es
     ffb:	57                   	push   di
     ffc:	ff 76 0e             	push   WORD PTR [bp+0xe]
     fff:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1002:	9a 8c 0c 13 10       	call   0x1013:0xc8c
    1007:	50                   	push   ax
    1008:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    100b:	06                   	push   es
    100c:	57                   	push   di
    100d:	ff 76 06             	push   WORD PTR [bp+0x6]
    1010:	9a 50 2e 60 10       	call   0x1060:0x2e50
    1015:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1018:	03 f8                	add    di,ax
    101a:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    101e:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    1021:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    1024:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1027:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    102a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    102d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1030:	c9                   	leave
    1031:	ca 10 00             	retf   0x10
    1034:	55                   	push   bp
    1035:	89 e5                	mov    bp,sp
    1037:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    103a:	81 c7 01 00          	add    di,0x1
    103e:	06                   	push   es
    103f:	57                   	push   di
    1040:	68 ff 00             	push   0xff
    1043:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1046:	81 c7 01 00          	add    di,0x1
    104a:	06                   	push   es
    104b:	57                   	push   di
    104c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    104f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1052:	30 e4                	xor    ah,ah
    1054:	50                   	push   ax
    1055:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1058:	06                   	push   es
    1059:	57                   	push   di
    105a:	ff 76 06             	push   WORD PTR [bp+0x6]
    105d:	9a 50 2e 98 10       	call   0x1098:0x2e50
    1062:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1065:	26 88 05             	mov    BYTE PTR es:[di],al
    1068:	c9                   	leave
    1069:	ca 0a 00             	retf   0xa
    106c:	55                   	push   bp
    106d:	89 e5                	mov    bp,sp
    106f:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1072:	81 c7 01 00          	add    di,0x1
    1076:	06                   	push   es
    1077:	57                   	push   di
    1078:	ff 76 10             	push   WORD PTR [bp+0x10]
    107b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    107e:	81 c7 01 00          	add    di,0x1
    1082:	06                   	push   es
    1083:	57                   	push   di
    1084:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1087:	26 8a 05             	mov    al,BYTE PTR es:[di]
    108a:	30 e4                	xor    ah,ah
    108c:	50                   	push   ax
    108d:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1090:	06                   	push   es
    1091:	57                   	push   di
    1092:	ff 76 06             	push   WORD PTR [bp+0x6]
    1095:	9a 50 2e c8 10       	call   0x10c8:0x2e50
    109a:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    109d:	26 88 05             	mov    BYTE PTR es:[di],al
    10a0:	c9                   	leave
    10a1:	ca 10 00             	retf   0x10
    10a4:	55                   	push   bp
    10a5:	89 e5                	mov    bp,sp
    10a7:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    10aa:	81 c7 01 00          	add    di,0x1
    10ae:	06                   	push   es
    10af:	57                   	push   di
    10b0:	ff 76 0e             	push   WORD PTR [bp+0xe]
    10b3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    10b6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10b9:	ff 76 08             	push   WORD PTR [bp+0x8]
    10bc:	ff 76 06             	push   WORD PTR [bp+0x6]
    10bf:	6a 00                	push   0x0
    10c1:	6a 0f                	push   0xf
    10c3:	6a 00                	push   0x0
    10c5:	9a a0 31 01 11       	call   0x1101:0x31a0
    10ca:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    10cd:	26 88 05             	mov    BYTE PTR es:[di],al
    10d0:	c9                   	leave
    10d1:	ca 0a 00             	retf   0xa
    10d4:	c8 e0 00 00          	enter  0xe0,0x0
    10d8:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    10db:	81 c7 01 00          	add    di,0x1
    10df:	06                   	push   es
    10e0:	57                   	push   di
    10e1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    10e4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    10e7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10ea:	ff 76 08             	push   WORD PTR [bp+0x8]
    10ed:	ff 76 06             	push   WORD PTR [bp+0x6]
    10f0:	8d be 20 ff          	lea    di,[bp-0xe0]
    10f4:	16                   	push   ss
    10f5:	57                   	push   di
    10f6:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    10f9:	06                   	push   es
    10fa:	57                   	push   di
    10fb:	68 df 00             	push   0xdf
    10fe:	9a 6a 0d 08 11       	call   0x1108:0xd6a
    1103:	52                   	push   dx
    1104:	50                   	push   ax
    1105:	9a 19 34 27 11       	call   0x1127:0x3419
    110a:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    110d:	26 88 05             	mov    BYTE PTR es:[di],al
    1110:	c9                   	leave
    1111:	ca 0e 00             	retf   0xe
    1114:	c8 52 01 00          	enter  0x152,0x0
    1118:	8d 7e b6             	lea    di,[bp-0x4a]
    111b:	16                   	push   ss
    111c:	57                   	push   di
    111d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1120:	06                   	push   es
    1121:	57                   	push   di
    1122:	6a 3f                	push   0x3f
    1124:	9a 6a 0d 33 11       	call   0x1133:0xd6a
    1129:	52                   	push   dx
    112a:	50                   	push   ax
    112b:	8d 7e f6             	lea    di,[bp-0xa]
    112e:	16                   	push   ss
    112f:	57                   	push   di
    1130:	9a e9 37 5c 11       	call   0x115c:0x37e9
    1135:	08 c0                	or     al,al
    1137:	75 28                	jne    0x1161
    1139:	8d be ae fe          	lea    di,[bp-0x152]
    113d:	16                   	push   ss
    113e:	57                   	push   di
    113f:	6a 81                	push   0xff81
    1141:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1144:	89 f8                	mov    ax,di
    1146:	8c c2                	mov    dx,es
    1148:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    114b:	89 56 b0             	mov    WORD PTR [bp-0x50],dx
    114e:	c6 46 b2 04          	mov    BYTE PTR [bp-0x4e],0x4
    1152:	8d 7e ae             	lea    di,[bp-0x52]
    1155:	16                   	push   ss
    1156:	57                   	push   di
    1157:	6a 00                	push   0x0
    1159:	9a 50 09 0a 12       	call   0x120a:0x950
    115e:	e8 f2 f2             	call   0x453
    1161:	9b db 6e f6          	fld    TBYTE PTR [bp-0xa]
    1165:	90                   	nop
    1166:	9b                   	fwait
    1167:	c9                   	leave
    1168:	ca 04 00             	retf   0x4
    116b:	80 cb a4             	or     bl,0xa4
    116e:	4c                   	dec    sp
    116f:	c8 06 00 00          	enter  0x6,0x0
    1173:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1177:	83 7e 0e 18          	cmp    WORD PTR [bp+0xe],0x18
    117b:	73 5f                	jae    0x11dc
    117d:	83 7e 0c 3c          	cmp    WORD PTR [bp+0xc],0x3c
    1181:	73 59                	jae    0x11dc
    1183:	83 7e 0a 3c          	cmp    WORD PTR [bp+0xa],0x3c
    1187:	73 53                	jae    0x11dc
    1189:	81 7e 08 e8 03       	cmp    WORD PTR [bp+0x8],0x3e8
    118e:	73 4c                	jae    0x11dc
    1190:	6b 46 0e 3c          	imul   ax,WORD PTR [bp+0xe],0x3c
    1194:	03 46 0c             	add    ax,WORD PTR [bp+0xc]
    1197:	50                   	push   ax
    1198:	68 60 ea             	push   0xea60
    119b:	e8 8c f2             	call   0x42a
    119e:	8b c8                	mov    cx,ax
    11a0:	8b da                	mov    bx,dx
    11a2:	69 46 0a e8 03       	imul   ax,WORD PTR [bp+0xa],0x3e8
    11a7:	31 d2                	xor    dx,dx
    11a9:	03 c1                	add    ax,cx
    11ab:	13 d3                	adc    dx,bx
    11ad:	8b c8                	mov    cx,ax
    11af:	8b da                	mov    bx,dx
    11b1:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    11b4:	31 d2                	xor    dx,dx
    11b6:	03 c1                	add    ax,cx
    11b8:	13 d3                	adc    dx,bx
    11ba:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    11bd:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    11c0:	9b db 46 fa          	fild   DWORD PTR [bp-0x6]
    11c4:	9b 2e d9 06 6b 11    	fld    DWORD PTR cs:0x116b
    11ca:	9a b2 04 38 12       	call   0x1238:0x4b2
    11cf:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    11d2:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    11d6:	90                   	nop
    11d7:	9b                   	fwait
    11d8:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    11dc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    11df:	c9                   	leave
    11e0:	c2 0c 00             	ret    0xc
    11e3:	c8 08 01 00          	enter  0x108,0x0
    11e7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    11ea:	ff 76 0a             	push   WORD PTR [bp+0xa]
    11ed:	ff 76 08             	push   WORD PTR [bp+0x8]
    11f0:	ff 76 06             	push   WORD PTR [bp+0x6]
    11f3:	8d 7e f8             	lea    di,[bp-0x8]
    11f6:	16                   	push   ss
    11f7:	57                   	push   di
    11f8:	e8 74 ff             	call   0x116f
    11fb:	08 c0                	or     al,al
    11fd:	75 10                	jne    0x120f
    11ff:	8d be f8 fe          	lea    di,[bp-0x108]
    1203:	16                   	push   ss
    1204:	57                   	push   di
    1205:	6a 85                	push   0xff85
    1207:	9a 2b 09 fa 13       	call   0x13fa:0x92b
    120c:	e8 44 f2             	call   0x453
    120f:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    1213:	90                   	nop
    1214:	9b                   	fwait
    1215:	c9                   	leave
    1216:	ca 08 00             	retf   0x8
    1219:	0f b9 67 fa          	ud1    sp,WORD PTR [bx-0x6]
    121d:	eb 50                	jmp    0x126f
    121f:	d7                   	xlat   BYTE PTR ds:[bx]
    1220:	c6                   	(bad)
    1221:	e3 3f                	jcxz   0x1262
    1223:	80 cb a4             	or     bl,0xa4
    1226:	4c                   	dec    sp
    1227:	c8 04 00 00          	enter  0x4,0x0
    122b:	9b 2e db 2e 19 12    	fld    TBYTE PTR cs:0x1219
    1231:	9b dc 46 16          	fadd   QWORD PTR [bp+0x16]
    1235:	9a 57 10 43 12       	call   0x1243:0x1057
    123a:	9b 2e d8 0e 23 12    	fmul   DWORD PTR cs:0x1223
    1240:	9a 0e 10 24 14       	call   0x1424:0x100e
    1245:	52                   	push   dx
    1246:	50                   	push   ax
    1247:	68 60 ea             	push   0xea60
    124a:	8d 7e fe             	lea    di,[bp-0x2]
    124d:	16                   	push   ss
    124e:	57                   	push   di
    124f:	8d 7e fc             	lea    di,[bp-0x4]
    1252:	16                   	push   ss
    1253:	57                   	push   di
    1254:	e8 e0 f1             	call   0x437
    1257:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    125a:	31 d2                	xor    dx,dx
    125c:	52                   	push   dx
    125d:	50                   	push   ax
    125e:	6a 3c                	push   0x3c
    1260:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1263:	06                   	push   es
    1264:	57                   	push   di
    1265:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1268:	06                   	push   es
    1269:	57                   	push   di
    126a:	e8 ca f1             	call   0x437
    126d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1270:	31 d2                	xor    dx,dx
    1272:	52                   	push   dx
    1273:	50                   	push   ax
    1274:	68 e8 03             	push   0x3e8
    1277:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    127a:	06                   	push   es
    127b:	57                   	push   di
    127c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    127f:	06                   	push   es
    1280:	57                   	push   di
    1281:	e8 b3 f1             	call   0x437
    1284:	c9                   	leave
    1285:	ca 18 00             	retf   0x18
    1288:	c8 02 00 00          	enter  0x2,0x0
    128c:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    128f:	31 d2                	xor    dx,dx
    1291:	b9 04 00             	mov    cx,0x4
    1294:	f7 f1                	div    cx
    1296:	92                   	xchg   dx,ax
    1297:	09 c0                	or     ax,ax
    1299:	75 1e                	jne    0x12b9
    129b:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    129e:	31 d2                	xor    dx,dx
    12a0:	b9 64 00             	mov    cx,0x64
    12a3:	f7 f1                	div    cx
    12a5:	92                   	xchg   dx,ax
    12a6:	09 c0                	or     ax,ax
    12a8:	75 13                	jne    0x12bd
    12aa:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    12ad:	31 d2                	xor    dx,dx
    12af:	b9 90 01             	mov    cx,0x190
    12b2:	f7 f1                	div    cx
    12b4:	92                   	xchg   dx,ax
    12b5:	09 c0                	or     ax,ax
    12b7:	74 04                	je     0x12bd
    12b9:	b0 00                	mov    al,0x0
    12bb:	eb 02                	jmp    0x12bf
    12bd:	b0 01                	mov    al,0x1
    12bf:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    12c2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    12c5:	c9                   	leave
    12c6:	c2 02 00             	ret    0x2
    12c9:	c8 04 00 00          	enter  0x4,0x0
    12cd:	ff 76 04             	push   WORD PTR [bp+0x4]
    12d0:	e8 b5 ff             	call   0x1288
    12d3:	98                   	cbw
    12d4:	8b f8                	mov    di,ax
    12d6:	c1 e7 02             	shl    di,0x2
    12d9:	8b 85 4e 17          	mov    ax,WORD PTR [di+0x174e]
    12dd:	8b 95 50 17          	mov    dx,WORD PTR [di+0x1750]
    12e1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    12e4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    12e7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    12ea:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    12ed:	c9                   	leave
    12ee:	c2 02 00             	ret    0x2
    12f1:	c8 0c 00 00          	enter  0xc,0x0
    12f5:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    12f9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    12fc:	e8 ca ff             	call   0x12c9
    12ff:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1302:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1305:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    1309:	73 03                	jae    0x130e
    130b:	e9 c1 00             	jmp    0x13cf
    130e:	81 7e 0c 0f 27       	cmp    WORD PTR [bp+0xc],0x270f
    1313:	76 03                	jbe    0x1318
    1315:	e9 b7 00             	jmp    0x13cf
    1318:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    131c:	73 03                	jae    0x1321
    131e:	e9 ae 00             	jmp    0x13cf
    1321:	83 7e 0a 0c          	cmp    WORD PTR [bp+0xa],0xc
    1325:	76 03                	jbe    0x132a
    1327:	e9 a5 00             	jmp    0x13cf
    132a:	83 7e 08 01          	cmp    WORD PTR [bp+0x8],0x1
    132e:	73 03                	jae    0x1333
    1330:	e9 9c 00             	jmp    0x13cf
    1333:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1336:	d1 e0                	shl    ax,1
    1338:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    133b:	03 f8                	add    di,ax
    133d:	26 8b 45 fe          	mov    ax,WORD PTR es:[di-0x2]
    1341:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    1344:	73 03                	jae    0x1349
    1346:	e9 86 00             	jmp    0x13cf
    1349:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    134c:	48                   	dec    ax
    134d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1350:	b8 01 00             	mov    ax,0x1
    1353:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1356:	77 21                	ja     0x1379
    1358:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    135b:	eb 03                	jmp    0x1360
    135d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1360:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1363:	d1 e0                	shl    ax,1
    1365:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1368:	03 f8                	add    di,ax
    136a:	26 8b 45 fe          	mov    ax,WORD PTR es:[di-0x2]
    136e:	01 46 08             	add    WORD PTR [bp+0x8],ax
    1371:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1374:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1377:	75 e4                	jne    0x135d
    1379:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    137c:	48                   	dec    ax
    137d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1380:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1383:	31 d2                	xor    dx,dx
    1385:	b9 90 01             	mov    cx,0x190
    1388:	f7 f1                	div    cx
    138a:	8b d8                	mov    bx,ax
    138c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    138f:	31 d2                	xor    dx,dx
    1391:	b9 64 00             	mov    cx,0x64
    1394:	f7 f1                	div    cx
    1396:	8b d0                	mov    dx,ax
    1398:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    139b:	c1 e8 02             	shr    ax,0x2
    139e:	03 46 08             	add    ax,WORD PTR [bp+0x8]
    13a1:	2b c2                	sub    ax,dx
    13a3:	03 c3                	add    ax,bx
    13a5:	31 d2                	xor    dx,dx
    13a7:	52                   	push   dx
    13a8:	50                   	push   ax
    13a9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    13ac:	68 6d 01             	push   0x16d
    13af:	e8 78 f0             	call   0x42a
    13b2:	59                   	pop    cx
    13b3:	5b                   	pop    bx
    13b4:	03 c1                	add    ax,cx
    13b6:	13 d3                	adc    dx,bx
    13b8:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    13bb:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    13be:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    13c2:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    13c5:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    13c9:	90                   	nop
    13ca:	9b                   	fwait
    13cb:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    13cf:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    13d2:	c9                   	leave
    13d3:	c2 0a 00             	ret    0xa
    13d6:	c8 08 01 00          	enter  0x108,0x0
    13da:	ff 76 0a             	push   WORD PTR [bp+0xa]
    13dd:	ff 76 08             	push   WORD PTR [bp+0x8]
    13e0:	ff 76 06             	push   WORD PTR [bp+0x6]
    13e3:	8d 7e f8             	lea    di,[bp-0x8]
    13e6:	16                   	push   ss
    13e7:	57                   	push   di
    13e8:	e8 06 ff             	call   0x12f1
    13eb:	08 c0                	or     al,al
    13ed:	75 10                	jne    0x13ff
    13ef:	8d be f8 fe          	lea    di,[bp-0x108]
    13f3:	16                   	push   ss
    13f4:	57                   	push   di
    13f5:	6a 86                	push   0xff86
    13f7:	9a 2b 09 ac 15       	call   0x15ac:0x92b
    13fc:	e8 54 f0             	call   0x453
    13ff:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    1403:	90                   	nop
    1404:	9b                   	fwait
    1405:	c9                   	leave
    1406:	ca 06 00             	retf   0x6
    1409:	0f b9 67 fa          	ud1    sp,WORD PTR [bx-0x6]
    140d:	eb 50                	jmp    0x145f
    140f:	d7                   	xlat   BYTE PTR ds:[bx]
    1410:	c6                   	(bad)
    1411:	e3 3f                	jcxz   0x1452
    1413:	c8 10 00 00          	enter  0x10,0x0
    1417:	9b 2e db 2e 09 14    	fld    TBYTE PTR cs:0x1409
    141d:	9b dc 46 12          	fadd   QWORD PTR [bp+0x12]
    1421:	9a 0e 10 69 15       	call   0x1569:0x100e
    1426:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1429:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    142c:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    1430:	7c 08                	jl     0x143a
    1432:	7f 21                	jg     0x1455
    1434:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    1438:	77 1b                	ja     0x1455
    143a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    143d:	31 c0                	xor    ax,ax
    143f:	26 89 05             	mov    WORD PTR es:[di],ax
    1442:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1445:	31 c0                	xor    ax,ax
    1447:	26 89 05             	mov    WORD PTR es:[di],ax
    144a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    144d:	31 c0                	xor    ax,ax
    144f:	26 89 05             	mov    WORD PTR es:[di],ax
    1452:	e9 f5 00             	jmp    0x154a
    1455:	83 6e f4 01          	sub    WORD PTR [bp-0xc],0x1
    1459:	83 5e f6 00          	sbb    WORD PTR [bp-0xa],0x0
    145d:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    1462:	83 7e f6 02          	cmp    WORD PTR [bp-0xa],0x2
    1466:	7f 09                	jg     0x1471
    1468:	7c 17                	jl     0x1481
    146a:	81 7e f4 b1 3a       	cmp    WORD PTR [bp-0xc],0x3ab1
    146f:	72 10                	jb     0x1481
    1471:	81 6e f4 b1 3a       	sub    WORD PTR [bp-0xc],0x3ab1
    1476:	83 5e f6 02          	sbb    WORD PTR [bp-0xa],0x2
    147a:	81 46 fe 90 01       	add    WORD PTR [bp-0x2],0x190
    147f:	eb e1                	jmp    0x1462
    1481:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1484:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1487:	68 ac 8e             	push   0x8eac
    148a:	8d 7e f8             	lea    di,[bp-0x8]
    148d:	16                   	push   ss
    148e:	57                   	push   di
    148f:	8d 7e fa             	lea    di,[bp-0x6]
    1492:	16                   	push   ss
    1493:	57                   	push   di
    1494:	e8 a0 ef             	call   0x437
    1497:	83 7e f8 04          	cmp    WORD PTR [bp-0x8],0x4
    149b:	75 08                	jne    0x14a5
    149d:	ff 4e f8             	dec    WORD PTR [bp-0x8]
    14a0:	81 46 fa ac 8e       	add    WORD PTR [bp-0x6],0x8eac
    14a5:	6b 46 f8 64          	imul   ax,WORD PTR [bp-0x8],0x64
    14a9:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    14ac:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    14af:	31 d2                	xor    dx,dx
    14b1:	52                   	push   dx
    14b2:	50                   	push   ax
    14b3:	68 b5 05             	push   0x5b5
    14b6:	8d 7e f8             	lea    di,[bp-0x8]
    14b9:	16                   	push   ss
    14ba:	57                   	push   di
    14bb:	8d 7e fa             	lea    di,[bp-0x6]
    14be:	16                   	push   ss
    14bf:	57                   	push   di
    14c0:	e8 74 ef             	call   0x437
    14c3:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    14c6:	c1 e0 02             	shl    ax,0x2
    14c9:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    14cc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    14cf:	31 d2                	xor    dx,dx
    14d1:	52                   	push   dx
    14d2:	50                   	push   ax
    14d3:	68 6d 01             	push   0x16d
    14d6:	8d 7e f8             	lea    di,[bp-0x8]
    14d9:	16                   	push   ss
    14da:	57                   	push   di
    14db:	8d 7e fa             	lea    di,[bp-0x6]
    14de:	16                   	push   ss
    14df:	57                   	push   di
    14e0:	e8 54 ef             	call   0x437
    14e3:	83 7e f8 04          	cmp    WORD PTR [bp-0x8],0x4
    14e7:	75 08                	jne    0x14f1
    14e9:	ff 4e f8             	dec    WORD PTR [bp-0x8]
    14ec:	81 46 fa 6d 01       	add    WORD PTR [bp-0x6],0x16d
    14f1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    14f4:	01 46 fe             	add    WORD PTR [bp-0x2],ax
    14f7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14fa:	e8 cc fd             	call   0x12c9
    14fd:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1500:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    1503:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    1508:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    150b:	d1 e0                	shl    ax,1
    150d:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    1510:	03 f8                	add    di,ax
    1512:	26 8b 45 fe          	mov    ax,WORD PTR es:[di-0x2]
    1516:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1519:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    151c:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    151f:	73 02                	jae    0x1523
    1521:	eb 0b                	jmp    0x152e
    1523:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1526:	29 46 fa             	sub    WORD PTR [bp-0x6],ax
    1529:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    152c:	eb da                	jmp    0x1508
    152e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1531:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1534:	26 89 05             	mov    WORD PTR es:[di],ax
    1537:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    153a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    153d:	26 89 05             	mov    WORD PTR es:[di],ax
    1540:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1543:	40                   	inc    ax
    1544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1547:	26 89 05             	mov    WORD PTR es:[di],ax
    154a:	c9                   	leave
    154b:	ca 14 00             	retf   0x14
    154e:	0f b9 67 fa          	ud1    sp,WORD PTR [bx-0x6]
    1552:	eb 50                	jmp    0x15a4
    1554:	d7                   	xlat   BYTE PTR ds:[bx]
    1555:	c6                   	(bad)
    1556:	e3 3f                	jcxz   0x1597
    1558:	c8 02 00 00          	enter  0x2,0x0
    155c:	9b 2e db 2e 4e 15    	fld    TBYTE PTR cs:0x154e
    1562:	9b dc 46 06          	fadd   QWORD PTR [bp+0x6]
    1566:	9a 0e 10 73 15       	call   0x1573:0x100e
    156b:	b9 07 00             	mov    cx,0x7
    156e:	31 db                	xor    bx,bx
    1570:	9a 70 16 cb 1a       	call   0x1acb:0x1670
    1575:	89 c8                	mov    ax,cx
    1577:	89 da                	mov    dx,bx
    1579:	05 01 00             	add    ax,0x1
    157c:	83 d2 00             	adc    dx,0x0
    157f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1582:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1585:	c9                   	leave
    1586:	ca 08 00             	retf   0x8
    1589:	c8 0c 00 00          	enter  0xc,0x0
    158d:	b4 2a                	mov    ah,0x2a
    158f:	cd 21                	int    0x21
    1591:	89 4e f6             	mov    WORD PTR [bp-0xa],cx
    1594:	88 76 f5             	mov    BYTE PTR [bp-0xb],dh
    1597:	88 56 f4             	mov    BYTE PTR [bp-0xc],dl
    159a:	ff 76 f6             	push   WORD PTR [bp-0xa]
    159d:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
    15a0:	30 e4                	xor    ah,ah
    15a2:	50                   	push   ax
    15a3:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    15a6:	30 e4                	xor    ah,ah
    15a8:	50                   	push   ax
    15a9:	9a d6 13 ee 15       	call   0x15ee:0x13d6
    15ae:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    15b2:	90                   	nop
    15b3:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    15b8:	90                   	nop
    15b9:	9b                   	fwait
    15ba:	c9                   	leave
    15bb:	cb                   	retf
    15bc:	c8 0c 00 00          	enter  0xc,0x0
    15c0:	b4 2c                	mov    ah,0x2c
    15c2:	cd 21                	int    0x21
    15c4:	88 6e f7             	mov    BYTE PTR [bp-0x9],ch
    15c7:	88 4e f6             	mov    BYTE PTR [bp-0xa],cl
    15ca:	88 76 f5             	mov    BYTE PTR [bp-0xb],dh
    15cd:	88 56 f4             	mov    BYTE PTR [bp-0xc],dl
    15d0:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    15d3:	30 e4                	xor    ah,ah
    15d5:	50                   	push   ax
    15d6:	8a 46 f6             	mov    al,BYTE PTR [bp-0xa]
    15d9:	30 e4                	xor    ah,ah
    15db:	50                   	push   ax
    15dc:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
    15df:	30 e4                	xor    ah,ah
    15e1:	50                   	push   ax
    15e2:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    15e5:	30 e4                	xor    ah,ah
    15e7:	6b c0 0a             	imul   ax,ax,0xa
    15ea:	50                   	push   ax
    15eb:	9a e3 11 05 16       	call   0x1605:0x11e3
    15f0:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    15f4:	90                   	nop
    15f5:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    15fa:	90                   	nop
    15fb:	9b                   	fwait
    15fc:	c9                   	leave
    15fd:	cb                   	retf
    15fe:	c8 12 00 00          	enter  0x12,0x0
    1602:	9a 89 15 0e 16       	call   0x160e:0x1589
    1607:	9b db 7e ee          	fstp   TBYTE PTR [bp-0x12]
    160b:	9a bc 15 47 16       	call   0x1647:0x15bc
    1610:	9b db 6e ee          	fld    TBYTE PTR [bp-0x12]
    1614:	9b de c1             	faddp  st(1),st
    1617:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    161b:	90                   	nop
    161c:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1621:	90                   	nop
    1622:	9b                   	fwait
    1623:	c9                   	leave
    1624:	cb                   	retf
    1625:	b4 2a                	mov    ah,0x2a
    1627:	cd 21                	int    0x21
    1629:	89 c8                	mov    ax,cx
    162b:	c3                   	ret
    162c:	55                   	push   bp
    162d:	89 e5                	mov    bp,sp
    162f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1632:	36 c4 7d 14          	les    di,DWORD PTR ss:[di+0x14]
    1636:	06                   	push   es
    1637:	57                   	push   di
    1638:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    163b:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    163f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1642:	06                   	push   es
    1643:	57                   	push   di
    1644:	9a 88 06 bb 16       	call   0x16bb:0x688
    1649:	c9                   	leave
    164a:	c2 06 00             	ret    0x6
    164d:	55                   	push   bp
    164e:	89 e5                	mov    bp,sp
    1650:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1653:	36 c4 7d 14          	les    di,DWORD PTR ss:[di+0x14]
    1657:	26 80 3d ff          	cmp    BYTE PTR es:[di],0xff
    165b:	73 10                	jae    0x166d
    165d:	26 fe 05             	inc    BYTE PTR es:[di]
    1660:	8a 56 06             	mov    dl,BYTE PTR [bp+0x6]
    1663:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1666:	30 e4                	xor    ah,ah
    1668:	03 f8                	add    di,ax
    166a:	26 88 15             	mov    BYTE PTR es:[di],dl
    166d:	c9                   	leave
    166e:	c2 04 00             	ret    0x4
    1671:	04 25                	add    al,0x25
    1673:	2e 2a 64 c8          	sub    ah,BYTE PTR cs:[si-0x38]
    1677:	10 01                	adc    BYTE PTR [bx+di],al
    1679:	00 8b 7e 04          	add    BYTE PTR [bp+di+0x47e],cl
    167d:	36 c4 7d 14          	les    di,DWORD PTR ss:[di+0x14]
    1681:	06                   	push   es
    1682:	57                   	push   di
    1683:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1686:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    168a:	8d be f0 fe          	lea    di,[bp-0x110]
    168e:	16                   	push   ss
    168f:	57                   	push   di
    1690:	bf 71 16             	mov    di,0x1671
    1693:	0e                   	push   cs
    1694:	57                   	push   di
    1695:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1698:	99                   	cwd
    1699:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    169c:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    169f:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    16a3:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    16a6:	99                   	cwd
    16a7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    16aa:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    16ad:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
    16b1:	8d 7e f0             	lea    di,[bp-0x10]
    16b4:	16                   	push   ss
    16b5:	57                   	push   di
    16b6:	6a 01                	push   0x1
    16b8:	9a 34 10 c0 16       	call   0x16c0:0x1034
    16bd:	9a 88 06 55 17       	call   0x1755:0x688
    16c2:	c9                   	leave
    16c3:	c2 06 00             	ret    0x6
    16c6:	c8 02 00 00          	enter  0x2,0x0
    16ca:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    16cd:	36 8b 45 f4          	mov    ax,WORD PTR ss:[di-0xc]
    16d1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    16d4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    16d7:	36 8b 45 f4          	mov    ax,WORD PTR ss:[di-0xc]
    16db:	36 3b 45 f2          	cmp    ax,WORD PTR ss:[di-0xe]
    16df:	7f 1f                	jg     0x1700
    16e1:	36 8b 45 f4          	mov    ax,WORD PTR ss:[di-0xc]
    16e5:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    16e8:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    16ec:	03 f8                	add    di,ax
    16ee:	26 8a 05             	mov    al,BYTE PTR es:[di]
    16f1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    16f4:	36 3a 45 ff          	cmp    al,BYTE PTR ss:[di-0x1]
    16f8:	75 06                	jne    0x1700
    16fa:	36 ff 45 f4          	inc    WORD PTR ss:[di-0xc]
    16fe:	eb d4                	jmp    0x16d4
    1700:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1703:	36 8b 45 f4          	mov    ax,WORD PTR ss:[di-0xc]
    1707:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    170a:	40                   	inc    ax
    170b:	36 89 45 f0          	mov    WORD PTR ss:[di-0x10],ax
    170f:	c9                   	leave
    1710:	c2 02 00             	ret    0x2
    1713:	55                   	push   bp
    1714:	89 e5                	mov    bp,sp
    1716:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1719:	36 80 7d fc 00       	cmp    BYTE PTR ss:[di-0x4],0x0
    171e:	75 3f                	jne    0x175f
    1720:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1723:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    1727:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    172b:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    172f:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    1733:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    1737:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    173a:	81 c7 ee ff          	add    di,0xffee
    173e:	16                   	push   ss
    173f:	57                   	push   di
    1740:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1743:	81 c7 ec ff          	add    di,0xffec
    1747:	16                   	push   ss
    1748:	57                   	push   di
    1749:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    174c:	81 c7 ea ff          	add    di,0xffea
    1750:	16                   	push   ss
    1751:	57                   	push   di
    1752:	9a 13 14 ae 17       	call   0x17ae:0x1413
    1757:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    175a:	36 c6 45 fc 01       	mov    BYTE PTR ss:[di-0x4],0x1
    175f:	c9                   	leave
    1760:	c2 02 00             	ret    0x2
    1763:	55                   	push   bp
    1764:	89 e5                	mov    bp,sp
    1766:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1769:	36 80 7d fb 00       	cmp    BYTE PTR ss:[di-0x5],0x0
    176e:	75 48                	jne    0x17b8
    1770:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1773:	36 8b 7d 04          	mov    di,WORD PTR ss:[di+0x4]
    1777:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    177b:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    177f:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    1783:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    1787:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    178a:	81 c7 e8 ff          	add    di,0xffe8
    178e:	16                   	push   ss
    178f:	57                   	push   di
    1790:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1793:	81 c7 e6 ff          	add    di,0xffe6
    1797:	16                   	push   ss
    1798:	57                   	push   di
    1799:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    179c:	81 c7 e4 ff          	add    di,0xffe4
    17a0:	16                   	push   ss
    17a1:	57                   	push   di
    17a2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    17a5:	81 c7 e2 ff          	add    di,0xffe2
    17a9:	16                   	push   ss
    17aa:	57                   	push   di
    17ab:	9a 27 12 25 19       	call   0x1925:0x1227
    17b0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    17b3:	36 c6 45 fb 01       	mov    BYTE PTR ss:[di-0x5],0x1
    17b8:	c9                   	leave
    17b9:	c2 02 00             	ret    0x2
    17bc:	fc                   	cld
    17bd:	18 fc                	sbb    ah,bh
    17bf:	18 0f                	sbb    BYTE PTR [bx],cl
    17c1:	19 3b                	sbb    WORD PTR [bp+di],di
    17c3:	19 67 19             	sbb    WORD PTR [bx+0x19],sp
    17c6:	05 41 4d             	add    ax,0x4d41
    17c9:	2f                   	das
    17ca:	50                   	push   ax
    17cb:	4d                   	dec    bp
    17cc:	03 41 2f             	add    ax,WORD PTR [bx+di+0x2f]
    17cf:	50                   	push   ax
    17d0:	04 41                	add    al,0x41
    17d2:	4d                   	dec    bp
    17d3:	50                   	push   ax
    17d4:	4d                   	dec    bp
    17d5:	c8 20 03 00          	enter  0x320,0x0
    17d9:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    17de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e1:	26 8a 05             	mov    al,BYTE PTR es:[di]
    17e4:	30 e4                	xor    ah,ah
    17e6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    17e9:	c6 46 fd 20          	mov    BYTE PTR [bp-0x3],0x20
    17ed:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
    17f1:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    17f5:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    17f8:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    17fb:	7e 03                	jle    0x1800
    17fd:	e9 40 04             	jmp    0x1c40
    1800:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1803:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1806:	03 f8                	add    di,ax
    1808:	26 8a 05             	mov    al,BYTE PTR es:[di]
    180b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    180e:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    1811:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1814:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    1817:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    181a:	3c 61                	cmp    al,0x61
    181c:	72 08                	jb     0x1826
    181e:	3c 7a                	cmp    al,0x7a
    1820:	77 04                	ja     0x1826
    1822:	80 6e fe 20          	sub    BYTE PTR [bp-0x2],0x20
    1826:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    1829:	3c 41                	cmp    al,0x41
    182b:	72 1a                	jb     0x1847
    182d:	3c 5a                	cmp    al,0x5a
    182f:	77 16                	ja     0x1847
    1831:	80 7e fe 4d          	cmp    BYTE PTR [bp-0x2],0x4d
    1835:	75 0a                	jne    0x1841
    1837:	80 7e fd 48          	cmp    BYTE PTR [bp-0x3],0x48
    183b:	75 04                	jne    0x1841
    183d:	c6 46 fe 4e          	mov    BYTE PTR [bp-0x2],0x4e
    1841:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    1844:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1847:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    184a:	3c 59                	cmp    al,0x59
    184c:	75 34                	jne    0x1882
    184e:	55                   	push   bp
    184f:	e8 74 fe             	call   0x16c6
    1852:	55                   	push   bp
    1853:	e8 bd fe             	call   0x1713
    1856:	83 7e f0 02          	cmp    WORD PTR [bp-0x10],0x2
    185a:	7f 17                	jg     0x1873
    185c:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    185f:	31 d2                	xor    dx,dx
    1861:	b9 64 00             	mov    cx,0x64
    1864:	f7 f1                	div    cx
    1866:	92                   	xchg   dx,ax
    1867:	50                   	push   ax
    1868:	6a 02                	push   0x2
    186a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    186d:	57                   	push   di
    186e:	e8 05 fe             	call   0x1676
    1871:	eb 0c                	jmp    0x187f
    1873:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1876:	6a 04                	push   0x4
    1878:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    187b:	57                   	push   di
    187c:	e8 f7 fd             	call   0x1676
    187f:	e9 bb 03             	jmp    0x1c3d
    1882:	3c 4d                	cmp    al,0x4d
    1884:	75 54                	jne    0x18da
    1886:	55                   	push   bp
    1887:	e8 3c fe             	call   0x16c6
    188a:	55                   	push   bp
    188b:	e8 85 fe             	call   0x1713
    188e:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1891:	3d 01 00             	cmp    ax,0x1
    1894:	74 05                	je     0x189b
    1896:	3d 02 00             	cmp    ax,0x2
    1899:	75 0f                	jne    0x18aa
    189b:	ff 76 ec             	push   WORD PTR [bp-0x14]
    189e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    18a1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    18a4:	57                   	push   di
    18a5:	e8 ce fd             	call   0x1676
    18a8:	eb 2d                	jmp    0x18d7
    18aa:	3d 03 00             	cmp    ax,0x3
    18ad:	75 15                	jne    0x18c4
    18af:	8b 7e ec             	mov    di,WORD PTR [bp-0x14]
    18b2:	c1 e7 03             	shl    di,0x3
    18b5:	81 c7 d0 2c          	add    di,0x2cd0
    18b9:	1e                   	push   ds
    18ba:	57                   	push   di
    18bb:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    18be:	57                   	push   di
    18bf:	e8 6a fd             	call   0x162c
    18c2:	eb 13                	jmp    0x18d7
    18c4:	8b 7e ec             	mov    di,WORD PTR [bp-0x14]
    18c7:	c1 e7 04             	shl    di,0x4
    18ca:	81 c7 28 2d          	add    di,0x2d28
    18ce:	1e                   	push   ds
    18cf:	57                   	push   di
    18d0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    18d3:	57                   	push   di
    18d4:	e8 55 fd             	call   0x162c
    18d7:	e9 63 03             	jmp    0x1c3d
    18da:	3c 44                	cmp    al,0x44
    18dc:	74 03                	je     0x18e1
    18de:	e9 a3 00             	jmp    0x1984
    18e1:	55                   	push   bp
    18e2:	e8 e1 fd             	call   0x16c6
    18e5:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    18e8:	2d 01 00             	sub    ax,0x1
    18eb:	3d 04 00             	cmp    ax,0x4
    18ee:	76 03                	jbe    0x18f3
    18f0:	e9 82 00             	jmp    0x1975
    18f3:	89 c3                	mov    bx,ax
    18f5:	d1 e3                	shl    bx,1
    18f7:	2e ff a7 bc 17       	jmp    WORD PTR cs:[bx+0x17bc]
    18fc:	55                   	push   bp
    18fd:	e8 13 fe             	call   0x1713
    1900:	ff 76 ea             	push   WORD PTR [bp-0x16]
    1903:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1906:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1909:	57                   	push   di
    190a:	e8 69 fd             	call   0x1676
    190d:	eb 72                	jmp    0x1981
    190f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1912:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    1916:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    191a:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    191e:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    1922:	9a 58 15 51 19       	call   0x1951:0x1558
    1927:	8b f8                	mov    di,ax
    1929:	c1 e7 03             	shl    di,0x3
    192c:	81 c7 f0 2d          	add    di,0x2df0
    1930:	1e                   	push   ds
    1931:	57                   	push   di
    1932:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1935:	57                   	push   di
    1936:	e8 f3 fc             	call   0x162c
    1939:	eb 46                	jmp    0x1981
    193b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    193e:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    1942:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    1946:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    194a:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    194e:	9a 58 15 d5 1a       	call   0x1ad5:0x1558
    1953:	8b f8                	mov    di,ax
    1955:	c1 e7 04             	shl    di,0x4
    1958:	81 c7 20 2e          	add    di,0x2e20
    195c:	1e                   	push   ds
    195d:	57                   	push   di
    195e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1961:	57                   	push   di
    1962:	e8 c7 fc             	call   0x162c
    1965:	eb 1a                	jmp    0x1981
    1967:	bf 66 2c             	mov    di,0x2c66
    196a:	1e                   	push   ds
    196b:	57                   	push   di
    196c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    196f:	57                   	push   di
    1970:	e8 62 fe             	call   0x17d5
    1973:	eb 0c                	jmp    0x1981
    1975:	bf 76 2c             	mov    di,0x2c76
    1978:	1e                   	push   ds
    1979:	57                   	push   di
    197a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    197d:	57                   	push   di
    197e:	e8 54 fe             	call   0x17d5
    1981:	e9 b9 02             	jmp    0x1c3d
    1984:	3c 48                	cmp    al,0x48
    1986:	74 03                	je     0x198b
    1988:	e9 a2 00             	jmp    0x1a2d
    198b:	55                   	push   bp
    198c:	e8 37 fd             	call   0x16c6
    198f:	55                   	push   bp
    1990:	e8 d0 fd             	call   0x1763
    1993:	c6 46 fa 00          	mov    BYTE PTR [bp-0x6],0x0
    1997:	c6 46 f9 00          	mov    BYTE PTR [bp-0x7],0x0
    199b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    199e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    19a1:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    19a4:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    19a7:	7f 46                	jg     0x19ef
    19a9:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    19ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19af:	03 f8                	add    di,ax
    19b1:	26 8a 05             	mov    al,BYTE PTR es:[di]
    19b4:	3c 41                	cmp    al,0x41
    19b6:	74 04                	je     0x19bc
    19b8:	3c 61                	cmp    al,0x61
    19ba:	75 0e                	jne    0x19ca
    19bc:	80 7e f9 00          	cmp    BYTE PTR [bp-0x7],0x0
    19c0:	75 06                	jne    0x19c8
    19c2:	c6 46 fa 01          	mov    BYTE PTR [bp-0x6],0x1
    19c6:	eb 27                	jmp    0x19ef
    19c8:	eb 20                	jmp    0x19ea
    19ca:	3c 48                	cmp    al,0x48
    19cc:	74 04                	je     0x19d2
    19ce:	3c 68                	cmp    al,0x68
    19d0:	75 04                	jne    0x19d6
    19d2:	eb 1b                	jmp    0x19ef
    19d4:	eb 14                	jmp    0x19ea
    19d6:	3c 27                	cmp    al,0x27
    19d8:	74 04                	je     0x19de
    19da:	3c 22                	cmp    al,0x22
    19dc:	75 0c                	jne    0x19ea
    19de:	80 7e f9 00          	cmp    BYTE PTR [bp-0x7],0x0
    19e2:	b0 00                	mov    al,0x0
    19e4:	75 01                	jne    0x19e7
    19e6:	40                   	inc    ax
    19e7:	88 46 f9             	mov    BYTE PTR [bp-0x7],al
    19ea:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    19ed:	eb b2                	jmp    0x19a1
    19ef:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    19f2:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    19f5:	80 7e fa 00          	cmp    BYTE PTR [bp-0x6],0x0
    19f9:	74 17                	je     0x1a12
    19fb:	83 7e e0 00          	cmp    WORD PTR [bp-0x20],0x0
    19ff:	75 07                	jne    0x1a08
    1a01:	c7 46 e0 0c 00       	mov    WORD PTR [bp-0x20],0xc
    1a06:	eb 0a                	jmp    0x1a12
    1a08:	83 7e e0 0c          	cmp    WORD PTR [bp-0x20],0xc
    1a0c:	76 04                	jbe    0x1a12
    1a0e:	83 6e e0 0c          	sub    WORD PTR [bp-0x20],0xc
    1a12:	83 7e f0 02          	cmp    WORD PTR [bp-0x10],0x2
    1a16:	7e 05                	jle    0x1a1d
    1a18:	c7 46 f0 02 00       	mov    WORD PTR [bp-0x10],0x2
    1a1d:	ff 76 e0             	push   WORD PTR [bp-0x20]
    1a20:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1a23:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1a26:	57                   	push   di
    1a27:	e8 4c fc             	call   0x1676
    1a2a:	e9 10 02             	jmp    0x1c3d
    1a2d:	3c 4e                	cmp    al,0x4e
    1a2f:	75 23                	jne    0x1a54
    1a31:	55                   	push   bp
    1a32:	e8 91 fc             	call   0x16c6
    1a35:	55                   	push   bp
    1a36:	e8 2a fd             	call   0x1763
    1a39:	83 7e f0 02          	cmp    WORD PTR [bp-0x10],0x2
    1a3d:	7e 05                	jle    0x1a44
    1a3f:	c7 46 f0 02 00       	mov    WORD PTR [bp-0x10],0x2
    1a44:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    1a47:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1a4a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1a4d:	57                   	push   di
    1a4e:	e8 25 fc             	call   0x1676
    1a51:	e9 e9 01             	jmp    0x1c3d
    1a54:	3c 53                	cmp    al,0x53
    1a56:	75 23                	jne    0x1a7b
    1a58:	55                   	push   bp
    1a59:	e8 6a fc             	call   0x16c6
    1a5c:	55                   	push   bp
    1a5d:	e8 03 fd             	call   0x1763
    1a60:	83 7e f0 02          	cmp    WORD PTR [bp-0x10],0x2
    1a64:	7e 05                	jle    0x1a6b
    1a66:	c7 46 f0 02 00       	mov    WORD PTR [bp-0x10],0x2
    1a6b:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    1a6e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1a71:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1a74:	57                   	push   di
    1a75:	e8 fe fb             	call   0x1676
    1a78:	e9 c2 01             	jmp    0x1c3d
    1a7b:	3c 54                	cmp    al,0x54
    1a7d:	75 27                	jne    0x1aa6
    1a7f:	55                   	push   bp
    1a80:	e8 43 fc             	call   0x16c6
    1a83:	83 7e f0 01          	cmp    WORD PTR [bp-0x10],0x1
    1a87:	75 0e                	jne    0x1a97
    1a89:	bf a8 2c             	mov    di,0x2ca8
    1a8c:	1e                   	push   ds
    1a8d:	57                   	push   di
    1a8e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1a91:	57                   	push   di
    1a92:	e8 40 fd             	call   0x17d5
    1a95:	eb 0c                	jmp    0x1aa3
    1a97:	bf b8 2c             	mov    di,0x2cb8
    1a9a:	1e                   	push   ds
    1a9b:	57                   	push   di
    1a9c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1a9f:	57                   	push   di
    1aa0:	e8 32 fd             	call   0x17d5
    1aa3:	e9 97 01             	jmp    0x1c3d
    1aa6:	3c 41                	cmp    al,0x41
    1aa8:	74 03                	je     0x1aad
    1aaa:	e9 f8 00             	jmp    0x1ba5
    1aad:	55                   	push   bp
    1aae:	e8 b2 fc             	call   0x1763
    1ab1:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1ab4:	48                   	dec    ax
    1ab5:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1ab8:	8d be e0 fe          	lea    di,[bp-0x120]
    1abc:	16                   	push   ss
    1abd:	57                   	push   di
    1abe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac1:	06                   	push   es
    1ac2:	57                   	push   di
    1ac3:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1ac6:	6a 05                	push   0x5
    1ac8:	9a 0b 18 f8 1a       	call   0x1af8:0x180b
    1acd:	bf c6 17             	mov    di,0x17c6
    1ad0:	0e                   	push   cs
    1ad1:	57                   	push   di
    1ad2:	9a 30 07 25 1b       	call   0x1b25:0x730
    1ad7:	09 c0                	or     ax,ax
    1ad9:	75 2d                	jne    0x1b08
    1adb:	83 7e e8 0c          	cmp    WORD PTR [bp-0x18],0xc
    1adf:	72 04                	jb     0x1ae5
    1ae1:	83 46 f6 03          	add    WORD PTR [bp-0xa],0x3
    1ae5:	8d be e0 fd          	lea    di,[bp-0x220]
    1ae9:	16                   	push   ss
    1aea:	57                   	push   di
    1aeb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aee:	06                   	push   es
    1aef:	57                   	push   di
    1af0:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1af3:	6a 02                	push   0x2
    1af5:	9a 0b 18 1b 1b       	call   0x1b1b:0x180b
    1afa:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1afd:	57                   	push   di
    1afe:	e8 2b fb             	call   0x162c
    1b01:	83 46 f4 04          	add    WORD PTR [bp-0xc],0x4
    1b05:	e9 9a 00             	jmp    0x1ba2
    1b08:	8d be e0 fd          	lea    di,[bp-0x220]
    1b0c:	16                   	push   ss
    1b0d:	57                   	push   di
    1b0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b11:	06                   	push   es
    1b12:	57                   	push   di
    1b13:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1b16:	6a 03                	push   0x3
    1b18:	9a 0b 18 61 1b       	call   0x1b61:0x180b
    1b1d:	bf cc 17             	mov    di,0x17cc
    1b20:	0e                   	push   cs
    1b21:	57                   	push   di
    1b22:	9a 30 07 6b 1b       	call   0x1b6b:0x730
    1b27:	09 c0                	or     ax,ax
    1b29:	75 23                	jne    0x1b4e
    1b2b:	83 7e e8 0c          	cmp    WORD PTR [bp-0x18],0xc
    1b2f:	72 04                	jb     0x1b35
    1b31:	83 46 f6 02          	add    WORD PTR [bp-0xa],0x2
    1b35:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b3b:	03 f8                	add    di,ax
    1b3d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1b40:	50                   	push   ax
    1b41:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b44:	57                   	push   di
    1b45:	e8 05 fb             	call   0x164d
    1b48:	83 46 f4 02          	add    WORD PTR [bp-0xc],0x2
    1b4c:	eb 54                	jmp    0x1ba2
    1b4e:	8d be e0 fc          	lea    di,[bp-0x320]
    1b52:	16                   	push   ss
    1b53:	57                   	push   di
    1b54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b57:	06                   	push   es
    1b58:	57                   	push   di
    1b59:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1b5c:	6a 04                	push   0x4
    1b5e:	9a 0b 18 1c 1c       	call   0x1c1c:0x180b
    1b63:	bf d0 17             	mov    di,0x17d0
    1b66:	0e                   	push   cs
    1b67:	57                   	push   di
    1b68:	9a 30 07 de 1c       	call   0x1cde:0x730
    1b6d:	09 c0                	or     ax,ax
    1b6f:	75 26                	jne    0x1b97
    1b71:	83 7e e8 0c          	cmp    WORD PTR [bp-0x18],0xc
    1b75:	73 0e                	jae    0x1b85
    1b77:	bf 98 2c             	mov    di,0x2c98
    1b7a:	1e                   	push   ds
    1b7b:	57                   	push   di
    1b7c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b7f:	57                   	push   di
    1b80:	e8 a9 fa             	call   0x162c
    1b83:	eb 0c                	jmp    0x1b91
    1b85:	bf a0 2c             	mov    di,0x2ca0
    1b88:	1e                   	push   ds
    1b89:	57                   	push   di
    1b8a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b8d:	57                   	push   di
    1b8e:	e8 9b fa             	call   0x162c
    1b91:	83 46 f4 03          	add    WORD PTR [bp-0xc],0x3
    1b95:	eb 0b                	jmp    0x1ba2
    1b97:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1b9a:	50                   	push   ax
    1b9b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b9e:	57                   	push   di
    1b9f:	e8 ab fa             	call   0x164d
    1ba2:	e9 98 00             	jmp    0x1c3d
    1ba5:	3c 43                	cmp    al,0x43
    1ba7:	75 0e                	jne    0x1bb7
    1ba9:	55                   	push   bp
    1baa:	e8 19 fb             	call   0x16c6
    1bad:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1bb0:	57                   	push   di
    1bb1:	e8 9e 00             	call   0x1c52
    1bb4:	e9 86 00             	jmp    0x1c3d
    1bb7:	3c 2f                	cmp    al,0x2f
    1bb9:	75 0d                	jne    0x1bc8
    1bbb:	a0 65 2c             	mov    al,ds:0x2c65
    1bbe:	50                   	push   ax
    1bbf:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1bc2:	57                   	push   di
    1bc3:	e8 87 fa             	call   0x164d
    1bc6:	eb 75                	jmp    0x1c3d
    1bc8:	3c 3a                	cmp    al,0x3a
    1bca:	75 0d                	jne    0x1bd9
    1bcc:	a0 96 2c             	mov    al,ds:0x2c96
    1bcf:	50                   	push   ax
    1bd0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1bd3:	57                   	push   di
    1bd4:	e8 76 fa             	call   0x164d
    1bd7:	eb 64                	jmp    0x1c3d
    1bd9:	3c 27                	cmp    al,0x27
    1bdb:	74 04                	je     0x1be1
    1bdd:	3c 22                	cmp    al,0x22
    1bdf:	75 51                	jne    0x1c32
    1be1:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1be4:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1be7:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1bea:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1bed:	7f 15                	jg     0x1c04
    1bef:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1bf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf5:	03 f8                	add    di,ax
    1bf7:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1bfa:	3a 46 ff             	cmp    al,BYTE PTR [bp-0x1]
    1bfd:	74 05                	je     0x1c04
    1bff:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    1c02:	eb e3                	jmp    0x1be7
    1c04:	8d be e0 fe          	lea    di,[bp-0x120]
    1c08:	16                   	push   ss
    1c09:	57                   	push   di
    1c0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c0d:	06                   	push   es
    1c0e:	57                   	push   di
    1c0f:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1c12:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1c15:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    1c18:	50                   	push   ax
    1c19:	9a 0b 18 72 1c       	call   0x1c72:0x180b
    1c1e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c21:	57                   	push   di
    1c22:	e8 07 fa             	call   0x162c
    1c25:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1c28:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1c2b:	7f 03                	jg     0x1c30
    1c2d:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    1c30:	eb 0b                	jmp    0x1c3d
    1c32:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1c35:	50                   	push   ax
    1c36:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c39:	57                   	push   di
    1c3a:	e8 10 fa             	call   0x164d
    1c3d:	e9 b5 fb             	jmp    0x17f5
    1c40:	c9                   	leave
    1c41:	c2 06 00             	ret    0x6
    1c44:	0f b9 67 fa          	ud1    sp,WORD PTR [bx-0x6]
    1c48:	eb 50                	jmp    0x1c9a
    1c4a:	d7                   	xlat   BYTE PTR ds:[bx]
    1c4b:	c6                   	(bad)
    1c4c:	e3 3f                	jcxz   0x1c8d
    1c4e:	00 c0                	add    al,al
    1c50:	a8 47                	test   al,0x47
    1c52:	55                   	push   bp
    1c53:	89 e5                	mov    bp,sp
    1c55:	bf 66 2c             	mov    di,0x2c66
    1c58:	1e                   	push   ds
    1c59:	57                   	push   di
    1c5a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c5d:	57                   	push   di
    1c5e:	e8 74 fb             	call   0x17d5
    1c61:	9b 2e db 2e 44 1c    	fld    TBYTE PTR cs:0x1c44
    1c67:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c6a:	9b 36 dc 45 06       	fadd   QWORD PTR ss:[di+0x6]
    1c6f:	9a 57 10 7d 1c       	call   0x1c7d:0x1057
    1c74:	9b 2e d8 0e 4e 1c    	fmul   DWORD PTR cs:0x1c4e
    1c7a:	9a 0e 10 32 1e       	call   0x1e32:0x100e
    1c7f:	09 d0                	or     ax,dx
    1c81:	74 15                	je     0x1c98
    1c83:	6a 20                	push   0x20
    1c85:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c88:	57                   	push   di
    1c89:	e8 c1 f9             	call   0x164d
    1c8c:	bf b8 2c             	mov    di,0x2cb8
    1c8f:	1e                   	push   ds
    1c90:	57                   	push   di
    1c91:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c94:	57                   	push   di
    1c95:	e8 3d fb             	call   0x17d5
    1c98:	c9                   	leave
    1c99:	c2 02 00             	ret    0x2
    1c9c:	55                   	push   bp
    1c9d:	89 e5                	mov    bp,sp
    1c9f:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1ca2:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1ca6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1ca9:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1cad:	74 08                	je     0x1cb7
    1caf:	06                   	push   es
    1cb0:	57                   	push   di
    1cb1:	55                   	push   bp
    1cb2:	e8 20 fb             	call   0x17d5
    1cb5:	eb 04                	jmp    0x1cbb
    1cb7:	55                   	push   bp
    1cb8:	e8 97 ff             	call   0x1c52
    1cbb:	c9                   	leave
    1cbc:	ca 12 00             	retf   0x12
    1cbf:	55                   	push   bp
    1cc0:	89 e5                	mov    bp,sp
    1cc2:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1cc5:	06                   	push   es
    1cc6:	57                   	push   di
    1cc7:	68 ff 00             	push   0xff
    1cca:	bf 66 2c             	mov    di,0x2c66
    1ccd:	1e                   	push   ds
    1cce:	57                   	push   di
    1ccf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cd2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1cd5:	ff 76 08             	push   WORD PTR [bp+0x8]
    1cd8:	ff 76 06             	push   WORD PTR [bp+0x6]
    1cdb:	9a 9c 1c 03 1d       	call   0x1d03:0x1c9c
    1ce0:	c9                   	leave
    1ce1:	ca 08 00             	retf   0x8
    1ce4:	55                   	push   bp
    1ce5:	89 e5                	mov    bp,sp
    1ce7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1cea:	06                   	push   es
    1ceb:	57                   	push   di
    1cec:	68 ff 00             	push   0xff
    1cef:	bf b8 2c             	mov    di,0x2cb8
    1cf2:	1e                   	push   ds
    1cf3:	57                   	push   di
    1cf4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cf7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1cfa:	ff 76 08             	push   WORD PTR [bp+0x8]
    1cfd:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d00:	9a 9c 1c 29 1d       	call   0x1d29:0x1c9c
    1d05:	c9                   	leave
    1d06:	ca 08 00             	retf   0x8
    1d09:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1d0c:	e5 c4                	in     ax,0xc4
    1d0e:	7e 0e                	jle    0x1d1e
    1d10:	06                   	push   es
    1d11:	57                   	push   di
    1d12:	68 ff 00             	push   0xff
    1d15:	bf 09 1d             	mov    di,0x1d09
    1d18:	0e                   	push   cs
    1d19:	57                   	push   di
    1d1a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d1d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d20:	ff 76 08             	push   WORD PTR [bp+0x8]
    1d23:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d26:	9a 9c 1c 37 1e       	call   0x1e37:0x1c9c
    1d2b:	c9                   	leave
    1d2c:	ca 08 00             	retf   0x8
    1d2f:	c8 02 00 00          	enter  0x2,0x0
    1d33:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1d36:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1d39:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d3c:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1d3f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1d42:	30 e4                	xor    ah,ah
    1d44:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1d47:	7c 10                	jl     0x1d59
    1d49:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d4c:	03 f8                	add    di,ax
    1d4e:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    1d52:	75 05                	jne    0x1d59
    1d54:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d57:	eb e3                	jmp    0x1d3c
    1d59:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d5c:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1d5f:	26 89 05             	mov    WORD PTR es:[di],ax
    1d62:	c9                   	leave
    1d63:	c2 08 00             	ret    0x8
    1d66:	c8 06 00 00          	enter  0x6,0x0
    1d6a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1d6e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1d71:	06                   	push   es
    1d72:	57                   	push   di
    1d73:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1d76:	06                   	push   es
    1d77:	57                   	push   di
    1d78:	e8 b4 ff             	call   0x1d2f
    1d7b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1d7e:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1d81:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d84:	31 c0                	xor    ax,ax
    1d86:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1d89:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1d8c:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1d8f:	30 e4                	xor    ah,ah
    1d91:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1d94:	7c 37                	jl     0x1dcd
    1d96:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1d99:	03 f8                	add    di,ax
    1d9b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1d9e:	3c 30                	cmp    al,0x30
    1da0:	72 2b                	jb     0x1dcd
    1da2:	3c 39                	cmp    al,0x39
    1da4:	77 27                	ja     0x1dcd
    1da6:	81 7e fa e8 03       	cmp    WORD PTR [bp-0x6],0x3e8
    1dab:	73 20                	jae    0x1dcd
    1dad:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1db0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1db3:	03 f8                	add    di,ax
    1db5:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1db8:	30 e4                	xor    ah,ah
    1dba:	2d 30 00             	sub    ax,0x30
    1dbd:	8b d0                	mov    dx,ax
    1dbf:	6b 46 fa 0a          	imul   ax,WORD PTR [bp-0x6],0xa
    1dc3:	03 c2                	add    ax,dx
    1dc5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1dc8:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1dcb:	eb bc                	jmp    0x1d89
    1dcd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1dd0:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1dd3:	26 3b 05             	cmp    ax,WORD PTR es:[di]
    1dd6:	7e 13                	jle    0x1deb
    1dd8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ddb:	26 89 05             	mov    WORD PTR es:[di],ax
    1dde:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1de1:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1de4:	26 89 05             	mov    WORD PTR es:[di],ax
    1de7:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1deb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1dee:	c9                   	leave
    1def:	c2 0c 00             	ret    0xc
    1df2:	c8 02 01 00          	enter  0x102,0x0
    1df6:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1dfa:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1dfd:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1e01:	74 4c                	je     0x1e4f
    1e03:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1e06:	06                   	push   es
    1e07:	57                   	push   di
    1e08:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1e0b:	06                   	push   es
    1e0c:	57                   	push   di
    1e0d:	e8 1f ff             	call   0x1d2f
    1e10:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1e13:	06                   	push   es
    1e14:	57                   	push   di
    1e15:	8d be fe fe          	lea    di,[bp-0x102]
    1e19:	16                   	push   ss
    1e1a:	57                   	push   di
    1e1b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1e1e:	06                   	push   es
    1e1f:	57                   	push   di
    1e20:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1e23:	26 ff 35             	push   WORD PTR es:[di]
    1e26:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1e29:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1e2c:	30 e4                	xor    ah,ah
    1e2e:	50                   	push   ax
    1e2f:	9a 0b 18 55 23       	call   0x2355:0x180b
    1e34:	9a ed 07 a3 21       	call   0x21a3:0x7ed
    1e39:	09 c0                	or     ax,ax
    1e3b:	75 12                	jne    0x1e4f
    1e3d:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1e40:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1e43:	30 e4                	xor    ah,ah
    1e45:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1e48:	26 01 05             	add    WORD PTR es:[di],ax
    1e4b:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1e4f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e52:	c9                   	leave
    1e53:	c2 0c 00             	ret    0xc
    1e56:	c8 02 00 00          	enter  0x2,0x0
    1e5a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1e5e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e61:	06                   	push   es
    1e62:	57                   	push   di
    1e63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e66:	06                   	push   es
    1e67:	57                   	push   di
    1e68:	e8 c4 fe             	call   0x1d2f
    1e6b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e6e:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1e71:	30 e4                	xor    ah,ah
    1e73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e76:	26 3b 05             	cmp    ax,WORD PTR es:[di]
    1e79:	7c 1a                	jl     0x1e95
    1e7b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1e7e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e81:	03 f8                	add    di,ax
    1e83:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1e86:	3a 46 04             	cmp    al,BYTE PTR [bp+0x4]
    1e89:	75 0a                	jne    0x1e95
    1e8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e8e:	26 ff 05             	inc    WORD PTR es:[di]
    1e91:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1e95:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e98:	c9                   	leave
    1e99:	c2 0a 00             	ret    0xa
    1e9c:	c8 04 00 00          	enter  0x4,0x0
    1ea0:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    1ea5:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1ea8:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1eab:	30 e4                	xor    ah,ah
    1ead:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1eb0:	7c 31                	jl     0x1ee3
    1eb2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1eb5:	03 f8                	add    di,ax
    1eb7:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1eba:	24 df                	and    al,0xdf
    1ebc:	3c 59                	cmp    al,0x59
    1ebe:	75 06                	jne    0x1ec6
    1ec0:	c6 46 ff 02          	mov    BYTE PTR [bp-0x1],0x2
    1ec4:	eb 19                	jmp    0x1edf
    1ec6:	3c 4d                	cmp    al,0x4d
    1ec8:	75 06                	jne    0x1ed0
    1eca:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1ece:	eb 0f                	jmp    0x1edf
    1ed0:	3c 44                	cmp    al,0x44
    1ed2:	75 06                	jne    0x1eda
    1ed4:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1ed8:	eb 05                	jmp    0x1edf
    1eda:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1edd:	eb c6                	jmp    0x1ea5
    1edf:	eb 06                	jmp    0x1ee7
    1ee1:	eb c2                	jmp    0x1ea5
    1ee3:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1ee7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1eea:	c9                   	leave
    1eeb:	c2 04 00             	ret    0x4
    1eee:	c8 10 00 00          	enter  0x10,0x0
    1ef2:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1ef6:	bf 66 2c             	mov    di,0x2c66
    1ef9:	1e                   	push   ds
    1efa:	57                   	push   di
    1efb:	e8 9e ff             	call   0x1e9c
    1efe:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    1f01:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1f04:	06                   	push   es
    1f05:	57                   	push   di
    1f06:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1f09:	06                   	push   es
    1f0a:	57                   	push   di
    1f0b:	8d 7e fa             	lea    di,[bp-0x6]
    1f0e:	16                   	push   ss
    1f0f:	57                   	push   di
    1f10:	e8 53 fe             	call   0x1d66
    1f13:	08 c0                	or     al,al
    1f15:	74 2b                	je     0x1f42
    1f17:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1f1a:	06                   	push   es
    1f1b:	57                   	push   di
    1f1c:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1f1f:	06                   	push   es
    1f20:	57                   	push   di
    1f21:	a0 65 2c             	mov    al,ds:0x2c65
    1f24:	50                   	push   ax
    1f25:	e8 2e ff             	call   0x1e56
    1f28:	08 c0                	or     al,al
    1f2a:	74 16                	je     0x1f42
    1f2c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1f2f:	06                   	push   es
    1f30:	57                   	push   di
    1f31:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1f34:	06                   	push   es
    1f35:	57                   	push   di
    1f36:	8d 7e f8             	lea    di,[bp-0x8]
    1f39:	16                   	push   ss
    1f3a:	57                   	push   di
    1f3b:	e8 28 fe             	call   0x1d66
    1f3e:	08 c0                	or     al,al
    1f40:	75 03                	jne    0x1f45
    1f42:	e9 cb 00             	jmp    0x2010
    1f45:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1f48:	06                   	push   es
    1f49:	57                   	push   di
    1f4a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1f4d:	06                   	push   es
    1f4e:	57                   	push   di
    1f4f:	a0 65 2c             	mov    al,ds:0x2c65
    1f52:	50                   	push   ax
    1f53:	e8 00 ff             	call   0x1e56
    1f56:	08 c0                	or     al,al
    1f58:	74 6f                	je     0x1fc9
    1f5a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1f5d:	06                   	push   es
    1f5e:	57                   	push   di
    1f5f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1f62:	06                   	push   es
    1f63:	57                   	push   di
    1f64:	8d 7e f6             	lea    di,[bp-0xa]
    1f67:	16                   	push   ss
    1f68:	57                   	push   di
    1f69:	e8 fa fd             	call   0x1d66
    1f6c:	08 c0                	or     al,al
    1f6e:	75 03                	jne    0x1f73
    1f70:	e9 9d 00             	jmp    0x2010
    1f73:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    1f76:	3c 00                	cmp    al,0x0
    1f78:	75 14                	jne    0x1f8e
    1f7a:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1f7d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1f80:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1f83:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1f86:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1f89:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1f8c:	eb 2e                	jmp    0x1fbc
    1f8e:	3c 01                	cmp    al,0x1
    1f90:	75 14                	jne    0x1fa6
    1f92:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1f95:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1f98:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1f9b:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1f9e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1fa1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1fa4:	eb 16                	jmp    0x1fbc
    1fa6:	3c 02                	cmp    al,0x2
    1fa8:	75 12                	jne    0x1fbc
    1faa:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1fad:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1fb0:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1fb3:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1fb6:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1fb9:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1fbc:	83 7e f4 63          	cmp    WORD PTR [bp-0xc],0x63
    1fc0:	77 05                	ja     0x1fc7
    1fc2:	81 46 f4 6c 07       	add    WORD PTR [bp-0xc],0x76c
    1fc7:	eb 26                	jmp    0x1fef
    1fc9:	e8 59 f6             	call   0x1625
    1fcc:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1fcf:	80 7e fe 01          	cmp    BYTE PTR [bp-0x2],0x1
    1fd3:	75 0e                	jne    0x1fe3
    1fd5:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1fd8:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1fdb:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1fde:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1fe1:	eb 0c                	jmp    0x1fef
    1fe3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1fe6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1fe9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1fec:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1fef:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1ff2:	06                   	push   es
    1ff3:	57                   	push   di
    1ff4:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1ff7:	06                   	push   es
    1ff8:	57                   	push   di
    1ff9:	e8 33 fd             	call   0x1d2f
    1ffc:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1fff:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2002:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2005:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2008:	06                   	push   es
    2009:	57                   	push   di
    200a:	e8 e4 f2             	call   0x12f1
    200d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2010:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2013:	c9                   	leave
    2014:	c2 0c 00             	ret    0xc
    2017:	02 41 4d             	add    al,BYTE PTR [bx+di+0x4d]
    201a:	02 50 4d             	add    dl,BYTE PTR [bx+si+0x4d]
    201d:	c8 0a 00 00          	enter  0xa,0x0
    2021:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2025:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2028:	06                   	push   es
    2029:	57                   	push   di
    202a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    202d:	06                   	push   es
    202e:	57                   	push   di
    202f:	8d 7e fa             	lea    di,[bp-0x6]
    2032:	16                   	push   ss
    2033:	57                   	push   di
    2034:	e8 2f fd             	call   0x1d66
    2037:	08 c0                	or     al,al
    2039:	74 2b                	je     0x2066
    203b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    203e:	06                   	push   es
    203f:	57                   	push   di
    2040:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2043:	06                   	push   es
    2044:	57                   	push   di
    2045:	a0 96 2c             	mov    al,ds:0x2c96
    2048:	50                   	push   ax
    2049:	e8 0a fe             	call   0x1e56
    204c:	08 c0                	or     al,al
    204e:	74 16                	je     0x2066
    2050:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2053:	06                   	push   es
    2054:	57                   	push   di
    2055:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2058:	06                   	push   es
    2059:	57                   	push   di
    205a:	8d 7e f8             	lea    di,[bp-0x8]
    205d:	16                   	push   ss
    205e:	57                   	push   di
    205f:	e8 04 fd             	call   0x1d66
    2062:	08 c0                	or     al,al
    2064:	75 03                	jne    0x2069
    2066:	e9 e4 00             	jmp    0x214d
    2069:	31 c0                	xor    ax,ax
    206b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    206e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2071:	06                   	push   es
    2072:	57                   	push   di
    2073:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2076:	06                   	push   es
    2077:	57                   	push   di
    2078:	a0 96 2c             	mov    al,ds:0x2c96
    207b:	50                   	push   ax
    207c:	e8 d7 fd             	call   0x1e56
    207f:	08 c0                	or     al,al
    2081:	74 19                	je     0x209c
    2083:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2086:	06                   	push   es
    2087:	57                   	push   di
    2088:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    208b:	06                   	push   es
    208c:	57                   	push   di
    208d:	8d 7e f6             	lea    di,[bp-0xa]
    2090:	16                   	push   ss
    2091:	57                   	push   di
    2092:	e8 d1 fc             	call   0x1d66
    2095:	08 c0                	or     al,al
    2097:	75 03                	jne    0x209c
    2099:	e9 b1 00             	jmp    0x214d
    209c:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
    20a1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    20a4:	06                   	push   es
    20a5:	57                   	push   di
    20a6:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    20a9:	06                   	push   es
    20aa:	57                   	push   di
    20ab:	bf 98 2c             	mov    di,0x2c98
    20ae:	1e                   	push   ds
    20af:	57                   	push   di
    20b0:	e8 3f fd             	call   0x1df2
    20b3:	08 c0                	or     al,al
    20b5:	75 16                	jne    0x20cd
    20b7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    20ba:	06                   	push   es
    20bb:	57                   	push   di
    20bc:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    20bf:	06                   	push   es
    20c0:	57                   	push   di
    20c1:	bf 17 20             	mov    di,0x2017
    20c4:	0e                   	push   cs
    20c5:	57                   	push   di
    20c6:	e8 29 fd             	call   0x1df2
    20c9:	08 c0                	or     al,al
    20cb:	74 07                	je     0x20d4
    20cd:	31 c0                	xor    ax,ax
    20cf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    20d2:	eb 31                	jmp    0x2105
    20d4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    20d7:	06                   	push   es
    20d8:	57                   	push   di
    20d9:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    20dc:	06                   	push   es
    20dd:	57                   	push   di
    20de:	bf a0 2c             	mov    di,0x2ca0
    20e1:	1e                   	push   ds
    20e2:	57                   	push   di
    20e3:	e8 0c fd             	call   0x1df2
    20e6:	08 c0                	or     al,al
    20e8:	75 16                	jne    0x2100
    20ea:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    20ed:	06                   	push   es
    20ee:	57                   	push   di
    20ef:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    20f2:	06                   	push   es
    20f3:	57                   	push   di
    20f4:	bf 1a 20             	mov    di,0x201a
    20f7:	0e                   	push   cs
    20f8:	57                   	push   di
    20f9:	e8 f6 fc             	call   0x1df2
    20fc:	08 c0                	or     al,al
    20fe:	74 05                	je     0x2105
    2100:	c7 46 fc 0c 00       	mov    WORD PTR [bp-0x4],0xc
    2105:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2109:	7c 1f                	jl     0x212a
    210b:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    210f:	74 06                	je     0x2117
    2111:	83 7e fa 0c          	cmp    WORD PTR [bp-0x6],0xc
    2115:	76 02                	jbe    0x2119
    2117:	eb 34                	jmp    0x214d
    2119:	83 7e fa 0c          	cmp    WORD PTR [bp-0x6],0xc
    211d:	75 05                	jne    0x2124
    211f:	31 c0                	xor    ax,ax
    2121:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2124:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2127:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    212a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    212d:	06                   	push   es
    212e:	57                   	push   di
    212f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2132:	06                   	push   es
    2133:	57                   	push   di
    2134:	e8 f8 fb             	call   0x1d2f
    2137:	ff 76 fa             	push   WORD PTR [bp-0x6]
    213a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    213d:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2140:	6a 00                	push   0x0
    2142:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2145:	06                   	push   es
    2146:	57                   	push   di
    2147:	e8 25 f0             	call   0x116f
    214a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    214d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2150:	c9                   	leave
    2151:	c2 0c 00             	ret    0xc
    2154:	c8 12 01 00          	enter  0x112,0x0
    2158:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    215d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2160:	06                   	push   es
    2161:	57                   	push   di
    2162:	8d 7e f6             	lea    di,[bp-0xa]
    2165:	16                   	push   ss
    2166:	57                   	push   di
    2167:	8d 7e f8             	lea    di,[bp-0x8]
    216a:	16                   	push   ss
    216b:	57                   	push   di
    216c:	e8 7f fd             	call   0x1eee
    216f:	08 c0                	or     al,al
    2171:	74 0d                	je     0x2180
    2173:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2176:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2179:	30 e4                	xor    ah,ah
    217b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    217e:	7c 28                	jl     0x21a8
    2180:	8d be ee fe          	lea    di,[bp-0x112]
    2184:	16                   	push   ss
    2185:	57                   	push   di
    2186:	6a 82                	push   0xff82
    2188:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    218b:	89 f8                	mov    ax,di
    218d:	8c c2                	mov    dx,es
    218f:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2192:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    2195:	c6 46 f2 04          	mov    BYTE PTR [bp-0xe],0x4
    2199:	8d 7e ee             	lea    di,[bp-0x12]
    219c:	16                   	push   ss
    219d:	57                   	push   di
    219e:	6a 00                	push   0x0
    21a0:	9a 50 09 01 22       	call   0x2201:0x950
    21a5:	e8 ab e2             	call   0x453
    21a8:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    21ac:	90                   	nop
    21ad:	9b                   	fwait
    21ae:	c9                   	leave
    21af:	ca 04 00             	retf   0x4
    21b2:	c8 12 01 00          	enter  0x112,0x0
    21b6:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    21bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21be:	06                   	push   es
    21bf:	57                   	push   di
    21c0:	8d 7e f6             	lea    di,[bp-0xa]
    21c3:	16                   	push   ss
    21c4:	57                   	push   di
    21c5:	8d 7e f8             	lea    di,[bp-0x8]
    21c8:	16                   	push   ss
    21c9:	57                   	push   di
    21ca:	e8 50 fe             	call   0x201d
    21cd:	08 c0                	or     al,al
    21cf:	74 0d                	je     0x21de
    21d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d4:	26 8a 05             	mov    al,BYTE PTR es:[di]
    21d7:	30 e4                	xor    ah,ah
    21d9:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    21dc:	7c 28                	jl     0x2206
    21de:	8d be ee fe          	lea    di,[bp-0x112]
    21e2:	16                   	push   ss
    21e3:	57                   	push   di
    21e4:	6a 83                	push   0xff83
    21e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e9:	89 f8                	mov    ax,di
    21eb:	8c c2                	mov    dx,es
    21ed:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    21f0:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    21f3:	c6 46 f2 04          	mov    BYTE PTR [bp-0xe],0x4
    21f7:	8d 7e ee             	lea    di,[bp-0x12]
    21fa:	16                   	push   ss
    21fb:	57                   	push   di
    21fc:	6a 00                	push   0x0
    21fe:	9a 50 09 82 22       	call   0x2282:0x950
    2203:	e8 4d e2             	call   0x453
    2206:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    220a:	90                   	nop
    220b:	9b                   	fwait
    220c:	c9                   	leave
    220d:	ca 04 00             	retf   0x4
    2210:	00 00                	add    BYTE PTR [bx+si],al
    2212:	00 00                	add    BYTE PTR [bx+si],al
    2214:	c8 22 01 00          	enter  0x122,0x0
    2218:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    221d:	9b 2e d9 06 10 22    	fld    DWORD PTR cs:0x2210
    2223:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    2227:	90                   	nop
    2228:	9b                   	fwait
    2229:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    222c:	06                   	push   es
    222d:	57                   	push   di
    222e:	8d 7e f6             	lea    di,[bp-0xa]
    2231:	16                   	push   ss
    2232:	57                   	push   di
    2233:	8d 7e ee             	lea    di,[bp-0x12]
    2236:	16                   	push   ss
    2237:	57                   	push   di
    2238:	e8 b3 fc             	call   0x1eee
    223b:	08 c0                	or     al,al
    223d:	74 20                	je     0x225f
    223f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2242:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2245:	30 e4                	xor    ah,ah
    2247:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    224a:	7c 3b                	jl     0x2287
    224c:	06                   	push   es
    224d:	57                   	push   di
    224e:	8d 7e f6             	lea    di,[bp-0xa]
    2251:	16                   	push   ss
    2252:	57                   	push   di
    2253:	8d 7e e6             	lea    di,[bp-0x1a]
    2256:	16                   	push   ss
    2257:	57                   	push   di
    2258:	e8 c2 fd             	call   0x201d
    225b:	08 c0                	or     al,al
    225d:	75 28                	jne    0x2287
    225f:	8d be de fe          	lea    di,[bp-0x122]
    2263:	16                   	push   ss
    2264:	57                   	push   di
    2265:	6a 84                	push   0xff84
    2267:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    226a:	89 f8                	mov    ax,di
    226c:	8c c2                	mov    dx,es
    226e:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2271:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2274:	c6 46 e2 04          	mov    BYTE PTR [bp-0x1e],0x4
    2278:	8d 7e de             	lea    di,[bp-0x22]
    227b:	16                   	push   ss
    227c:	57                   	push   di
    227d:	6a 00                	push   0x0
    227f:	9a 50 09 bd 22       	call   0x22bd:0x950
    2284:	e8 cc e1             	call   0x453
    2287:	9b dd 46 ee          	fld    QWORD PTR [bp-0x12]
    228b:	9b dc 46 e6          	fadd   QWORD PTR [bp-0x1a]
    228f:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2293:	90                   	nop
    2294:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    2299:	90                   	nop
    229a:	9b                   	fwait
    229b:	c9                   	leave
    229c:	ca 04 00             	retf   0x4
    229f:	c8 00 01 00          	enter  0x100,0x0
    22a3:	ff 76 10             	push   WORD PTR [bp+0x10]
    22a6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    22a9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22ac:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22af:	8d be 00 ff          	lea    di,[bp-0x100]
    22b3:	16                   	push   ss
    22b4:	57                   	push   di
    22b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b8:	06                   	push   es
    22b9:	57                   	push   di
    22ba:	9a 4c 0d 42 23       	call   0x2342:0xd4c
    22bf:	52                   	push   dx
    22c0:	50                   	push   ax
    22c1:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    22c4:	81 c7 01 00          	add    di,0x1
    22c8:	06                   	push   es
    22c9:	57                   	push   di
    22ca:	68 ff 00             	push   0xff
    22cd:	9a 03 23 00 00       	call   0x0:0x2303
    22d2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    22d5:	26 88 05             	mov    BYTE PTR es:[di],al
    22d8:	c9                   	leave
    22d9:	ca 0c 00             	retf   0xc
    22dc:	c8 06 00 00          	enter  0x6,0x0
    22e0:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    22e3:	88 46 fc             	mov    BYTE PTR [bp-0x4],al
    22e6:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
    22ea:	ff 76 0e             	push   WORD PTR [bp+0xe]
    22ed:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22f0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22f3:	ff 76 08             	push   WORD PTR [bp+0x8]
    22f6:	8d 7e fc             	lea    di,[bp-0x4]
    22f9:	16                   	push   ss
    22fa:	57                   	push   di
    22fb:	8d 7e fa             	lea    di,[bp-0x6]
    22fe:	16                   	push   ss
    22ff:	57                   	push   di
    2300:	6a 02                	push   0x2
    2302:	9a ff ff 00 00       	call   0x0:0xffff
    2307:	09 c0                	or     ax,ax
    2309:	74 08                	je     0x2313
    230b:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
    230e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2311:	eb 06                	jmp    0x2319
    2313:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    2316:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2319:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    231c:	c9                   	leave
    231d:	ca 0a 00             	retf   0xa
    2320:	c8 02 01 00          	enter  0x102,0x0
    2324:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    2329:	eb 03                	jmp    0x232e
    232b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    232e:	8d be fe fe          	lea    di,[bp-0x102]
    2332:	16                   	push   ss
    2333:	57                   	push   di
    2334:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2337:	99                   	cwd
    2338:	05 bf ff             	add    ax,0xffbf
    233b:	83 d2 00             	adc    dx,0x0
    233e:	50                   	push   ax
    233f:	9a 2b 09 6b 23       	call   0x236b:0x92b
    2344:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    2347:	c1 e7 03             	shl    di,0x3
    234a:	81 c7 d0 2c          	add    di,0x2cd0
    234e:	1e                   	push   ds
    234f:	57                   	push   di
    2350:	6a 07                	push   0x7
    2352:	9a e7 17 7e 23       	call   0x237e:0x17e7
    2357:	8d be fe fe          	lea    di,[bp-0x102]
    235b:	16                   	push   ss
    235c:	57                   	push   di
    235d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2360:	99                   	cwd
    2361:	05 cf ff             	add    ax,0xffcf
    2364:	83 d2 00             	adc    dx,0x0
    2367:	50                   	push   ax
    2368:	9a 2b 09 a4 23       	call   0x23a4:0x92b
    236d:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    2370:	c1 e7 04             	shl    di,0x4
    2373:	81 c7 28 2d          	add    di,0x2d28
    2377:	1e                   	push   ds
    2378:	57                   	push   di
    2379:	6a 0f                	push   0xf
    237b:	9a e7 17 b7 23       	call   0x23b7:0x17e7
    2380:	83 7e fe 0c          	cmp    WORD PTR [bp-0x2],0xc
    2384:	75 a5                	jne    0x232b
    2386:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    238b:	eb 03                	jmp    0x2390
    238d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2390:	8d be fe fe          	lea    di,[bp-0x102]
    2394:	16                   	push   ss
    2395:	57                   	push   di
    2396:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2399:	99                   	cwd
    239a:	05 df ff             	add    ax,0xffdf
    239d:	83 d2 00             	adc    dx,0x0
    23a0:	50                   	push   ax
    23a1:	9a 2b 09 cd 23       	call   0x23cd:0x92b
    23a6:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    23a9:	c1 e7 03             	shl    di,0x3
    23ac:	81 c7 f0 2d          	add    di,0x2df0
    23b0:	1e                   	push   ds
    23b1:	57                   	push   di
    23b2:	6a 07                	push   0x7
    23b4:	9a e7 17 e0 23       	call   0x23e0:0x17e7
    23b9:	8d be fe fe          	lea    di,[bp-0x102]
    23bd:	16                   	push   ss
    23be:	57                   	push   di
    23bf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    23c2:	99                   	cwd
    23c3:	05 e6 ff             	add    ax,0xffe6
    23c6:	83 d2 00             	adc    dx,0x0
    23c9:	50                   	push   ax
    23ca:	9a 2b 09 37 24       	call   0x2437:0x92b
    23cf:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    23d2:	c1 e7 04             	shl    di,0x4
    23d5:	81 c7 20 2e          	add    di,0x2e20
    23d9:	1e                   	push   ds
    23da:	57                   	push   di
    23db:	6a 0f                	push   0xf
    23dd:	9a e7 17 43 24       	call   0x2443:0x17e7
    23e2:	83 7e fe 07          	cmp    WORD PTR [bp-0x2],0x7
    23e6:	75 a5                	jne    0x238d
    23e8:	c9                   	leave
    23e9:	c3                   	ret
    23ea:	00 06 6d 2f          	add    BYTE PTR ds:0x2f6d,al
    23ee:	64 2f                	fs das
    23f0:	79 79                	jns    0x246b
    23f2:	0c 6d                	or     al,0x6d
    23f4:	6d                   	ins    WORD PTR es:[di],dx
    23f5:	6d                   	ins    WORD PTR es:[di],dx
    23f6:	6d                   	ins    WORD PTR es:[di],dx
    23f7:	20 64 2c             	and    BYTE PTR [si+0x2c],ah
    23fa:	20 79 79             	and    BYTE PTR [bx+di+0x79],bh
    23fd:	79 79                	jns    0x2478
    23ff:	02 61 6d             	add    ah,BYTE PTR [bx+di+0x6d]
    2402:	02 70 6d             	add    dh,BYTE PTR [bx+si+0x6d]
    2405:	01 68 02             	add    WORD PTR [bx+si+0x2],bp
    2408:	68 68 05             	push   0x568
    240b:	20 41 4d             	and    BYTE PTR [bx+di+0x4d],al
    240e:	50                   	push   ax
    240f:	4d                   	dec    bp
    2410:	03 3a                	add    di,WORD PTR [bp+si]
    2412:	6d                   	ins    WORD PTR es:[di],dx
    2413:	6d                   	ins    WORD PTR es:[di],dx
    2414:	06                   	push   es
    2415:	3a 6d 6d             	cmp    ch,BYTE PTR [di+0x6d]
    2418:	3a 73 73             	cmp    dh,BYTE PTR [bp+di+0x73]
    241b:	c8 10 01 00          	enter  0x110,0x0
    241f:	8d be f0 fe          	lea    di,[bp-0x110]
    2423:	16                   	push   ss
    2424:	57                   	push   di
    2425:	bf 56 17             	mov    di,0x1756
    2428:	1e                   	push   ds
    2429:	57                   	push   di
    242a:	bf 5b 17             	mov    di,0x175b
    242d:	1e                   	push   ds
    242e:	57                   	push   di
    242f:	bf ea 23             	mov    di,0x23ea
    2432:	0e                   	push   cs
    2433:	57                   	push   di
    2434:	9a 9f 22 7c 24       	call   0x247c:0x229f
    2439:	bf 58 2c             	mov    di,0x2c58
    243c:	1e                   	push   ds
    243d:	57                   	push   di
    243e:	6a 07                	push   0x7
    2440:	9a e7 17 e1 24       	call   0x24e1:0x17e7
    2445:	bf 56 17             	mov    di,0x1756
    2448:	1e                   	push   ds
    2449:	57                   	push   di
    244a:	bf 65 17             	mov    di,0x1765
    244d:	1e                   	push   ds
    244e:	57                   	push   di
    244f:	6a 00                	push   0x0
    2451:	9a 66 24 00 00       	call   0x0:0x2466
    2456:	a2 60 2c             	mov    ds:0x2c60,al
    2459:	bf 56 17             	mov    di,0x1756
    245c:	1e                   	push   ds
    245d:	57                   	push   di
    245e:	bf 6f 17             	mov    di,0x176f
    2461:	1e                   	push   ds
    2462:	57                   	push   di
    2463:	6a 00                	push   0x0
    2465:	9a a2 24 00 00       	call   0x0:0x24a2
    246a:	a2 61 2c             	mov    ds:0x2c61,al
    246d:	bf 56 17             	mov    di,0x1756
    2470:	1e                   	push   ds
    2471:	57                   	push   di
    2472:	bf 78 17             	mov    di,0x1778
    2475:	1e                   	push   ds
    2476:	57                   	push   di
    2477:	6a 2c                	push   0x2c
    2479:	9a dc 22 90 24       	call   0x2490:0x22dc
    247e:	a2 62 2c             	mov    ds:0x2c62,al
    2481:	bf 56 17             	mov    di,0x1756
    2484:	1e                   	push   ds
    2485:	57                   	push   di
    2486:	bf 82 17             	mov    di,0x1782
    2489:	1e                   	push   ds
    248a:	57                   	push   di
    248b:	6a 2e                	push   0x2e
    248d:	9a dc 22 b8 24       	call   0x24b8:0x22dc
    2492:	a2 63 2c             	mov    ds:0x2c63,al
    2495:	bf 56 17             	mov    di,0x1756
    2498:	1e                   	push   ds
    2499:	57                   	push   di
    249a:	bf 8b 17             	mov    di,0x178b
    249d:	1e                   	push   ds
    249e:	57                   	push   di
    249f:	6a 02                	push   0x2
    24a1:	9a 76 25 00 00       	call   0x0:0x2576
    24a6:	a2 64 2c             	mov    ds:0x2c64,al
    24a9:	bf 56 17             	mov    di,0x1756
    24ac:	1e                   	push   ds
    24ad:	57                   	push   di
    24ae:	bf 97 17             	mov    di,0x1797
    24b1:	1e                   	push   ds
    24b2:	57                   	push   di
    24b3:	6a 2f                	push   0x2f
    24b5:	9a dc 22 d5 24       	call   0x24d5:0x22dc
    24ba:	a2 65 2c             	mov    ds:0x2c65,al
    24bd:	8d be f0 fe          	lea    di,[bp-0x110]
    24c1:	16                   	push   ss
    24c2:	57                   	push   di
    24c3:	bf 56 17             	mov    di,0x1756
    24c6:	1e                   	push   ds
    24c7:	57                   	push   di
    24c8:	bf 9d 17             	mov    di,0x179d
    24cb:	1e                   	push   ds
    24cc:	57                   	push   di
    24cd:	bf eb 23             	mov    di,0x23eb
    24d0:	0e                   	push   cs
    24d1:	57                   	push   di
    24d2:	9a 9f 22 fb 24       	call   0x24fb:0x229f
    24d7:	bf 66 2c             	mov    di,0x2c66
    24da:	1e                   	push   ds
    24db:	57                   	push   di
    24dc:	6a 0f                	push   0xf
    24de:	9a e7 17 07 25       	call   0x2507:0x17e7
    24e3:	8d be f0 fe          	lea    di,[bp-0x110]
    24e7:	16                   	push   ss
    24e8:	57                   	push   di
    24e9:	bf 56 17             	mov    di,0x1756
    24ec:	1e                   	push   ds
    24ed:	57                   	push   di
    24ee:	bf a8 17             	mov    di,0x17a8
    24f1:	1e                   	push   ds
    24f2:	57                   	push   di
    24f3:	bf f2 23             	mov    di,0x23f2
    24f6:	0e                   	push   cs
    24f7:	57                   	push   di
    24f8:	9a 9f 22 18 25       	call   0x2518:0x229f
    24fd:	bf 76 2c             	mov    di,0x2c76
    2500:	1e                   	push   ds
    2501:	57                   	push   di
    2502:	6a 1f                	push   0x1f
    2504:	9a e7 17 41 25       	call   0x2541:0x17e7
    2509:	bf 56 17             	mov    di,0x1756
    250c:	1e                   	push   ds
    250d:	57                   	push   di
    250e:	bf b2 17             	mov    di,0x17b2
    2511:	1e                   	push   ds
    2512:	57                   	push   di
    2513:	6a 3a                	push   0x3a
    2515:	9a dc 22 35 25       	call   0x2535:0x22dc
    251a:	a2 96 2c             	mov    ds:0x2c96,al
    251d:	8d be f0 fe          	lea    di,[bp-0x110]
    2521:	16                   	push   ss
    2522:	57                   	push   di
    2523:	bf 56 17             	mov    di,0x1756
    2526:	1e                   	push   ds
    2527:	57                   	push   di
    2528:	bf b8 17             	mov    di,0x17b8
    252b:	1e                   	push   ds
    252c:	57                   	push   di
    252d:	bf ff 23             	mov    di,0x23ff
    2530:	0e                   	push   cs
    2531:	57                   	push   di
    2532:	9a 9f 22 5b 25       	call   0x255b:0x229f
    2537:	bf 98 2c             	mov    di,0x2c98
    253a:	1e                   	push   ds
    253b:	57                   	push   di
    253c:	6a 07                	push   0x7
    253e:	9a e7 17 67 25       	call   0x2567:0x17e7
    2543:	8d be f0 fe          	lea    di,[bp-0x110]
    2547:	16                   	push   ss
    2548:	57                   	push   di
    2549:	bf 56 17             	mov    di,0x1756
    254c:	1e                   	push   ds
    254d:	57                   	push   di
    254e:	bf be 17             	mov    di,0x17be
    2551:	1e                   	push   ds
    2552:	57                   	push   di
    2553:	bf 02 24             	mov    di,0x2402
    2556:	0e                   	push   cs
    2557:	57                   	push   di
    2558:	9a 9f 22 d0 26       	call   0x26d0:0x229f
    255d:	bf a0 2c             	mov    di,0x2ca0
    2560:	1e                   	push   ds
    2561:	57                   	push   di
    2562:	6a 07                	push   0x7
    2564:	9a e7 17 8d 25       	call   0x258d:0x17e7
    2569:	bf 56 17             	mov    di,0x1756
    256c:	1e                   	push   ds
    256d:	57                   	push   di
    256e:	bf c4 17             	mov    di,0x17c4
    2571:	1e                   	push   ds
    2572:	57                   	push   di
    2573:	6a 00                	push   0x0
    2575:	9a af 25 00 00       	call   0x0:0x25af
    257a:	09 c0                	or     ax,ax
    257c:	75 13                	jne    0x2591
    257e:	bf 05 24             	mov    di,0x2405
    2581:	0e                   	push   cs
    2582:	57                   	push   di
    2583:	8d 7e f8             	lea    di,[bp-0x8]
    2586:	16                   	push   ss
    2587:	57                   	push   di
    2588:	6a 07                	push   0x7
    258a:	9a e7 17 a0 25       	call   0x25a0:0x17e7
    258f:	eb 11                	jmp    0x25a2
    2591:	bf 07 24             	mov    di,0x2407
    2594:	0e                   	push   cs
    2595:	57                   	push   di
    2596:	8d 7e f8             	lea    di,[bp-0x8]
    2599:	16                   	push   ss
    259a:	57                   	push   di
    259b:	6a 07                	push   0x7
    259d:	9a e7 17 c6 25       	call   0x25c6:0x17e7
    25a2:	bf 56 17             	mov    di,0x1756
    25a5:	1e                   	push   ds
    25a6:	57                   	push   di
    25a7:	bf cc 17             	mov    di,0x17cc
    25aa:	1e                   	push   ds
    25ab:	57                   	push   di
    25ac:	6a 00                	push   0x0
    25ae:	9a ff ff 00 00       	call   0x0:0xffff
    25b3:	09 c0                	or     ax,ax
    25b5:	75 13                	jne    0x25ca
    25b7:	bf 0a 24             	mov    di,0x240a
    25ba:	0e                   	push   cs
    25bb:	57                   	push   di
    25bc:	8d 7e f0             	lea    di,[bp-0x10]
    25bf:	16                   	push   ss
    25c0:	57                   	push   di
    25c1:	6a 07                	push   0x7
    25c3:	9a e7 17 dc 25       	call   0x25dc:0x17e7
    25c8:	eb 04                	jmp    0x25ce
    25ca:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    25ce:	8d be f0 fe          	lea    di,[bp-0x110]
    25d2:	16                   	push   ss
    25d3:	57                   	push   di
    25d4:	8d 7e f8             	lea    di,[bp-0x8]
    25d7:	16                   	push   ss
    25d8:	57                   	push   di
    25d9:	9a cd 17 e6 25       	call   0x25e6:0x17cd
    25de:	bf 10 24             	mov    di,0x2410
    25e1:	0e                   	push   cs
    25e2:	57                   	push   di
    25e3:	9a 4c 18 f0 25       	call   0x25f0:0x184c
    25e8:	8d 7e f0             	lea    di,[bp-0x10]
    25eb:	16                   	push   ss
    25ec:	57                   	push   di
    25ed:	9a 4c 18 fc 25       	call   0x25fc:0x184c
    25f2:	bf a8 2c             	mov    di,0x2ca8
    25f5:	1e                   	push   ds
    25f6:	57                   	push   di
    25f7:	6a 0f                	push   0xf
    25f9:	9a e7 17 0c 26       	call   0x260c:0x17e7
    25fe:	8d be f0 fe          	lea    di,[bp-0x110]
    2602:	16                   	push   ss
    2603:	57                   	push   di
    2604:	8d 7e f8             	lea    di,[bp-0x8]
    2607:	16                   	push   ss
    2608:	57                   	push   di
    2609:	9a cd 17 16 26       	call   0x2616:0x17cd
    260e:	bf 14 24             	mov    di,0x2414
    2611:	0e                   	push   cs
    2612:	57                   	push   di
    2613:	9a 4c 18 20 26       	call   0x2620:0x184c
    2618:	8d 7e f0             	lea    di,[bp-0x10]
    261b:	16                   	push   ss
    261c:	57                   	push   di
    261d:	9a 4c 18 2c 26       	call   0x262c:0x184c
    2622:	bf b8 2c             	mov    di,0x2cb8
    2625:	1e                   	push   ds
    2626:	57                   	push   di
    2627:	6a 1f                	push   0x1f
    2629:	9a e7 17 e6 26       	call   0x26e6:0x17e7
    262e:	c9                   	leave
    262f:	cb                   	retf
    2630:	31 c0                	xor    ax,ax
    2632:	99                   	cwd
    2633:	8b 1e 5a 18          	mov    bx,WORD PTR ds:0x185a
    2637:	09 db                	or     bx,bx
    2639:	74 08                	je     0x2643
    263b:	36 8b 47 06          	mov    ax,WORD PTR ss:[bx+0x6]
    263f:	36 8b 57 08          	mov    dx,WORD PTR ss:[bx+0x8]
    2643:	cb                   	retf
    2644:	31 c0                	xor    ax,ax
    2646:	99                   	cwd
    2647:	8b 1e 5a 18          	mov    bx,WORD PTR ds:0x185a
    264b:	09 db                	or     bx,bx
    264d:	74 08                	je     0x2657
    264f:	36 8b 47 02          	mov    ax,WORD PTR ss:[bx+0x2]
    2653:	36 8b 57 04          	mov    dx,WORD PTR ss:[bx+0x4]
    2657:	cb                   	retf
    2658:	55                   	push   bp
    2659:	89 e5                	mov    bp,sp
    265b:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    265e:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    2661:	89 d1                	mov    cx,dx
    2663:	09 c1                	or     cx,ax
    2665:	74 0d                	je     0x2674
    2667:	81 fa ff ff          	cmp    dx,0xffff
    266b:	74 07                	je     0x2674
    266d:	8e c2                	mov    es,dx
    266f:	26 8b 16 00 00       	mov    dx,WORD PTR es:0x0
    2674:	c9                   	leave
    2675:	c2 04 00             	ret    0x4
    2678:	c8 38 02 00          	enter  0x238,0x0
    267c:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    267f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2683:	c7 46 dc 24 00       	mov    WORD PTR [bp-0x24],0x24
    2688:	c7 46 de 00 00       	mov    WORD PTR [bp-0x22],0x0
    268d:	8d 7e dc             	lea    di,[bp-0x24]
    2690:	16                   	push   ss
    2691:	57                   	push   di
    2692:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2695:	26 ff 35             	push   WORD PTR es:[di]
    2698:	9a 40 27 00 00       	call   0x0:0x2740
    269d:	09 c0                	or     ax,ax
    269f:	74 5b                	je     0x26fc
    26a1:	c7 86 c8 fe 14 01    	mov    WORD PTR [bp-0x138],0x114
    26a7:	c7 86 ca fe 00 00    	mov    WORD PTR [bp-0x136],0x0
    26ad:	8d be c8 fe          	lea    di,[bp-0x138]
    26b1:	16                   	push   ss
    26b2:	57                   	push   di
    26b3:	ff 76 f2             	push   WORD PTR [bp-0xe]
    26b6:	9a ff ff 00 00       	call   0x0:0xffff
    26bb:	09 c0                	or     ax,ax
    26bd:	74 3d                	je     0x26fc
    26bf:	8d be c8 fd          	lea    di,[bp-0x238]
    26c3:	16                   	push   ss
    26c4:	57                   	push   di
    26c5:	8d be da fe          	lea    di,[bp-0x126]
    26c9:	16                   	push   ss
    26ca:	57                   	push   di
    26cb:	6a 5c                	push   0x5c
    26cd:	9a 47 0e da 26       	call   0x26da:0xe47
    26d2:	05 01 00             	add    ax,0x1
    26d5:	52                   	push   dx
    26d6:	50                   	push   ax
    26d7:	9a 6e 0e 96 27       	call   0x2796:0xe6e
    26dc:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    26df:	06                   	push   es
    26e0:	57                   	push   di
    26e1:	6a 4f                	push   0x4f
    26e3:	9a e7 17 15 27       	call   0x2715:0x17e7
    26e8:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    26eb:	3c 01                	cmp    al,0x1
    26ed:	72 0d                	jb     0x26fc
    26ef:	3c 03                	cmp    al,0x3
    26f1:	77 09                	ja     0x26fc
    26f3:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    26f6:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    26f9:	26 89 05             	mov    WORD PTR es:[di],ax
    26fc:	c9                   	leave
    26fd:	c2 08 00             	ret    0x8
    2700:	c8 9e 02 00          	enter  0x29e,0x0
    2704:	8d be 62 fd          	lea    di,[bp-0x29e]
    2708:	16                   	push   ss
    2709:	57                   	push   di
    270a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    270d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2710:	06                   	push   es
    2711:	57                   	push   di
    2712:	9a ed 20 21 27       	call   0x2721:0x20ed
    2717:	8d 7e c8             	lea    di,[bp-0x38]
    271a:	16                   	push   ss
    271b:	57                   	push   di
    271c:	6a 1f                	push   0x1f
    271e:	9a e7 17 cb 27       	call   0x27cb:0x17e7
    2723:	a1 8c 18             	mov    ax,ds:0x188c
    2726:	89 86 62 fe          	mov    WORD PTR [bp-0x19e],ax
    272a:	c7 86 64 fe 24 00    	mov    WORD PTR [bp-0x19c],0x24
    2730:	c7 86 66 fe 00 00    	mov    WORD PTR [bp-0x19a],0x0
    2736:	8d be 64 fe          	lea    di,[bp-0x19c]
    273a:	16                   	push   ss
    273b:	57                   	push   di
    273c:	ff 76 08             	push   WORD PTR [bp+0x8]
    273f:	9a ff ff 00 00       	call   0x0:0xffff
    2744:	09 c0                	or     ax,ax
    2746:	74 1d                	je     0x2765
    2748:	8b 86 7a fe          	mov    ax,WORD PTR [bp-0x186]
    274c:	89 86 62 fe          	mov    WORD PTR [bp-0x19e],ax
    2750:	8a 86 7c fe          	mov    al,BYTE PTR [bp-0x184]
    2754:	3c 01                	cmp    al,0x1
    2756:	72 0b                	jb     0x2763
    2758:	3c 03                	cmp    al,0x3
    275a:	77 07                	ja     0x2763
    275c:	8b 86 7e fe          	mov    ax,WORD PTR [bp-0x182]
    2760:	89 46 08             	mov    WORD PTR [bp+0x8],ax
    2763:	eb 0f                	jmp    0x2774
    2765:	ff 76 08             	push   WORD PTR [bp+0x8]
    2768:	ff 76 06             	push   WORD PTR [bp+0x6]
    276b:	e8 ea fe             	call   0x2658
    276e:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    2771:	89 56 08             	mov    WORD PTR [bp+0x8],dx
    2774:	ff b6 62 fe          	push   WORD PTR [bp-0x19e]
    2778:	8d be 88 fe          	lea    di,[bp-0x178]
    277c:	16                   	push   ss
    277d:	57                   	push   di
    277e:	68 00 01             	push   0x100
    2781:	9a ff ff 00 00       	call   0x0:0xffff
    2786:	8d 7e e8             	lea    di,[bp-0x18]
    2789:	16                   	push   ss
    278a:	57                   	push   di
    278b:	8d be 88 fe          	lea    di,[bp-0x178]
    278f:	16                   	push   ss
    2790:	57                   	push   di
    2791:	6a 5c                	push   0x5c
    2793:	9a 47 0e a0 27       	call   0x27a0:0xe47
    2798:	05 01 00             	add    ax,0x1
    279b:	52                   	push   dx
    279c:	50                   	push   ax
    279d:	9a df 0c c4 27       	call   0x27c4:0xcdf
    27a2:	a1 16 17             	mov    ax,ds:0x1716
    27a5:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    27a9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    27ac:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    27af:	b8 d2 17             	mov    ax,0x17d2
    27b2:	8c da                	mov    dx,ds
    27b4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    27b7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    27ba:	ff 76 0c             	push   WORD PTR [bp+0xc]
    27bd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    27c0:	bf 2e 00             	mov    di,0x2e
    27c3:	b8 8f 28             	mov    ax,0x288f
    27c6:	50                   	push   ax
    27c7:	57                   	push   di
    27c8:	9a 55 22 e2 28       	call   0x28e2:0x2255
    27cd:	08 c0                	or     al,al
    27cf:	74 38                	je     0x2809
    27d1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    27d4:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    27d8:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    27dc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    27df:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    27e2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27e5:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    27e9:	74 1e                	je     0x2809
    27eb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27ee:	26 8a 05             	mov    al,BYTE PTR es:[di]
    27f1:	30 e4                	xor    ah,ah
    27f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27f6:	03 f8                	add    di,ax
    27f8:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
    27fc:	74 0b                	je     0x2809
    27fe:	b8 d3 17             	mov    ax,0x17d3
    2801:	8c da                	mov    dx,ds
    2803:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2806:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2809:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    280d:	6a a3                	push   0xffa3
    280f:	8d 7e 88             	lea    di,[bp-0x78]
    2812:	16                   	push   ss
    2813:	57                   	push   di
    2814:	6a 40                	push   0x40
    2816:	9a 9f 28 00 00       	call   0x0:0x289f
    281b:	8d be 88 fe          	lea    di,[bp-0x178]
    281f:	16                   	push   ss
    2820:	57                   	push   di
    2821:	8d 7e 88             	lea    di,[bp-0x78]
    2824:	16                   	push   ss
    2825:	57                   	push   di
    2826:	8d 46 c8             	lea    ax,[bp-0x38]
    2829:	8c d2                	mov    dx,ss
    282b:	89 86 3a fe          	mov    WORD PTR [bp-0x1c6],ax
    282f:	89 96 3c fe          	mov    WORD PTR [bp-0x1c4],dx
    2833:	c6 86 3e fe 04       	mov    BYTE PTR [bp-0x1c2],0x4
    2838:	8d 46 e8             	lea    ax,[bp-0x18]
    283b:	8c d2                	mov    dx,ss
    283d:	89 86 42 fe          	mov    WORD PTR [bp-0x1be],ax
    2841:	89 96 44 fe          	mov    WORD PTR [bp-0x1bc],dx
    2845:	c6 86 46 fe 06       	mov    BYTE PTR [bp-0x1ba],0x6
    284a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    284d:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2850:	89 86 4a fe          	mov    WORD PTR [bp-0x1b6],ax
    2854:	89 96 4c fe          	mov    WORD PTR [bp-0x1b4],dx
    2858:	c6 86 4e fe 05       	mov    BYTE PTR [bp-0x1b2],0x5
    285d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2860:	89 f8                	mov    ax,di
    2862:	8c c2                	mov    dx,es
    2864:	89 86 52 fe          	mov    WORD PTR [bp-0x1ae],ax
    2868:	89 96 54 fe          	mov    WORD PTR [bp-0x1ac],dx
    286c:	c6 86 56 fe 04       	mov    BYTE PTR [bp-0x1aa],0x4
    2871:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2874:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2877:	89 86 5a fe          	mov    WORD PTR [bp-0x1a6],ax
    287b:	89 96 5c fe          	mov    WORD PTR [bp-0x1a4],dx
    287f:	c6 86 5e fe 06       	mov    BYTE PTR [bp-0x1a2],0x6
    2884:	8d be 3a fe          	lea    di,[bp-0x1c6]
    2888:	16                   	push   ss
    2889:	57                   	push   di
    288a:	6a 04                	push   0x4
    288c:	9a a3 0f cf 28       	call   0x28cf:0xfa3
    2891:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2895:	6a a4                	push   0xffa4
    2897:	8d 7e 88             	lea    di,[bp-0x78]
    289a:	16                   	push   ss
    289b:	57                   	push   di
    289c:	6a 40                	push   0x40
    289e:	9a ff ff 00 00       	call   0x0:0xffff
    28a3:	6a 00                	push   0x0
    28a5:	8d be 88 fe          	lea    di,[bp-0x178]
    28a9:	16                   	push   ss
    28aa:	57                   	push   di
    28ab:	8d 7e 88             	lea    di,[bp-0x78]
    28ae:	16                   	push   ss
    28af:	57                   	push   di
    28b0:	68 10 10             	push   0x1010
    28b3:	9a ff ff 00 00       	call   0x0:0xffff
    28b8:	c9                   	leave
    28b9:	ca 08 00             	retf   0x8
    28bc:	8b 46 02             	mov    ax,WORD PTR [bp+0x2]
    28bf:	8b 56 04             	mov    dx,WORD PTR [bp+0x4]
    28c2:	c3                   	ret
    28c3:	55                   	push   bp
    28c4:	89 e5                	mov    bp,sp
    28c6:	6a a0                	push   0xffa0
    28c8:	b0 01                	mov    al,0x1
    28ca:	50                   	push   ax
    28cb:	b8 58 00             	mov    ax,0x58
    28ce:	ba d6 28             	mov    dx,0x28d6
    28d1:	52                   	push   dx
    28d2:	50                   	push   ax
    28d3:	9a 23 29 ff 28       	call   0x28ff:0x2923
    28d8:	52                   	push   dx
    28d9:	50                   	push   ax
    28da:	e8 df ff             	call   0x28bc
    28dd:	52                   	push   dx
    28de:	50                   	push   ax
    28df:	ea 99 13 f5 28       	jmp    0x28f5:0x1399
    28e4:	c9                   	leave
    28e5:	cb                   	retf
    28e6:	55                   	push   bp
    28e7:	89 e5                	mov    bp,sp
    28e9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    28ed:	74 08                	je     0x28f7
    28ef:	83 ec 08             	sub    sp,0x8
    28f2:	9a e2 1f 33 29       	call   0x2933:0x1fe2
    28f7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28fa:	06                   	push   es
    28fb:	57                   	push   di
    28fc:	9a d7 05 41 29       	call   0x2941:0x5d7
    2901:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2904:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2908:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    290c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2910:	74 07                	je     0x2919
    2912:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2916:	83 c4 06             	add    sp,0x6
    2919:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    291c:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    291f:	c9                   	leave
    2920:	ca 0a 00             	retf   0xa
    2923:	c8 00 01 00          	enter  0x100,0x0
    2927:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    292b:	74 08                	je     0x2935
    292d:	83 ec 08             	sub    sp,0x8
    2930:	9a e2 1f 7a 29       	call   0x297a:0x1fe2
    2935:	8d be 00 ff          	lea    di,[bp-0x100]
    2939:	16                   	push   ss
    293a:	57                   	push   di
    293b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    293e:	9a 2b 09 46 29       	call   0x2946:0x92b
    2943:	9a d7 05 8e 29       	call   0x298e:0x5d7
    2948:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    294f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    2953:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2957:	74 07                	je     0x2960
    2959:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    295d:	83 c4 06             	add    sp,0x6
    2960:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2963:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2966:	c9                   	leave
    2967:	ca 08 00             	retf   0x8
    296a:	c8 00 02 00          	enter  0x200,0x0
    296e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2972:	74 08                	je     0x297c
    2974:	83 ec 08             	sub    sp,0x8
    2977:	9a e2 1f e0 29       	call   0x29e0:0x1fe2
    297c:	8d be 00 fe          	lea    di,[bp-0x200]
    2980:	16                   	push   ss
    2981:	57                   	push   di
    2982:	8d be 00 ff          	lea    di,[bp-0x100]
    2986:	16                   	push   ss
    2987:	57                   	push   di
    2988:	ff 76 12             	push   WORD PTR [bp+0x12]
    298b:	9a 2b 09 9b 29       	call   0x299b:0x92b
    2990:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2993:	06                   	push   es
    2994:	57                   	push   di
    2995:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2998:	9a 34 10 a0 29       	call   0x29a0:0x1034
    299d:	9a d7 05 d5 29       	call   0x29d5:0x5d7
    29a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a5:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    29a9:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    29ad:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    29b1:	74 07                	je     0x29ba
    29b3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    29b7:	83 c4 06             	add    sp,0x6
    29ba:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    29bd:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    29c0:	c9                   	leave
    29c1:	ca 0e 00             	retf   0xe
    29c4:	55                   	push   bp
    29c5:	89 e5                	mov    bp,sp
    29c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ca:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    29ce:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    29d2:	9a 24 06 17 2a       	call   0x2a17:0x624
    29d7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    29db:	74 05                	je     0x29e2
    29dd:	9a 0f 20 fd 29       	call   0x29fd:0x200f
    29e2:	c9                   	leave
    29e3:	ca 06 00             	retf   0x6
    29e6:	55                   	push   bp
    29e7:	89 e5                	mov    bp,sp
    29e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ec:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    29f0:	06                   	push   es
    29f1:	57                   	push   di
    29f2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29f5:	06                   	push   es
    29f6:	57                   	push   di
    29f7:	68 ff 00             	push   0xff
    29fa:	9a e7 17 29 2a       	call   0x2a29:0x17e7
    29ff:	c9                   	leave
    2a00:	ca 04 00             	retf   0x4
    2a03:	55                   	push   bp
    2a04:	89 e5                	mov    bp,sp
    2a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a09:	81 c7 04 00          	add    di,0x4
    2a0d:	06                   	push   es
    2a0e:	57                   	push   di
    2a0f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a12:	06                   	push   es
    2a13:	57                   	push   di
    2a14:	9a 51 06 71 2a       	call   0x2a71:0x651
    2a19:	c9                   	leave
    2a1a:	ca 08 00             	retf   0x8
    2a1d:	55                   	push   bp
    2a1e:	89 e5                	mov    bp,sp
    2a20:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2a24:	74 05                	je     0x2a2b
    2a26:	9a 0f 20 4b 2c       	call   0x2c4b:0x200f
    2a2b:	c9                   	leave
    2a2c:	ca 06 00             	retf   0x6
    2a2f:	55                   	push   bp
    2a30:	89 e5                	mov    bp,sp
    2a32:	c9                   	leave
    2a33:	ca 04 00             	retf   0x4
    2a36:	c8 0e 00 00          	enter  0xe,0x0
    2a3a:	31 c0                	xor    ax,ax
    2a3c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2a3f:	83 7e fa 07          	cmp    WORD PTR [bp-0x6],0x7
    2a43:	7f 15                	jg     0x2a5a
    2a45:	8b 7e fa             	mov    di,WORD PTR [bp-0x6]
    2a48:	c1 e7 02             	shl    di,0x2
    2a4b:	8b 85 d6 17          	mov    ax,WORD PTR [di+0x17d6]
    2a4f:	3b 06 78 18          	cmp    ax,WORD PTR ds:0x1878
    2a53:	74 05                	je     0x2a5a
    2a55:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2a58:	eb e5                	jmp    0x2a3f
    2a5a:	83 7e fa 07          	cmp    WORD PTR [bp-0x6],0x7
    2a5e:	7f 22                	jg     0x2a82
    2a60:	8b 7e fa             	mov    di,WORD PTR [bp-0x6]
    2a63:	c1 e7 02             	shl    di,0x2
    2a66:	ff b5 d8 17          	push   WORD PTR [di+0x17d8]
    2a6a:	b0 01                	mov    al,0x1
    2a6c:	50                   	push   ax
    2a6d:	b8 ac 00             	mov    ax,0xac
    2a70:	ba 78 2a             	mov    dx,0x2a78
    2a73:	52                   	push   dx
    2a74:	50                   	push   ax
    2a75:	9a 23 29 a0 2a       	call   0x2aa0:0x2923
    2a7a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a7d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2a80:	eb 2d                	jmp    0x2aaf
    2a82:	6a 88                	push   0xff88
    2a84:	a1 78 18             	mov    ax,ds:0x1878
    2a87:	99                   	cwd
    2a88:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2a8b:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2a8e:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
    2a92:	8d 7e f2             	lea    di,[bp-0xe]
    2a95:	16                   	push   ss
    2a96:	57                   	push   di
    2a97:	6a 00                	push   0x0
    2a99:	b0 01                	mov    al,0x1
    2a9b:	50                   	push   ax
    2a9c:	b8 ac 00             	mov    ax,0xac
    2a9f:	ba a7 2a             	mov    dx,0x2aa7
    2aa2:	52                   	push   dx
    2aa3:	50                   	push   ax
    2aa4:	9a 6a 29 11 2b       	call   0x2b11:0x296a
    2aa9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2aac:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2aaf:	a1 78 18             	mov    ax,ds:0x1878
    2ab2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ab5:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2ab9:	31 c0                	xor    ax,ax
    2abb:	a3 78 18             	mov    ds:0x1878,ax
    2abe:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2ac1:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2ac4:	c9                   	leave
    2ac5:	c3                   	ret
    2ac6:	c8 74 01 00          	enter  0x174,0x0
    2aca:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2acd:	3d 01 00             	cmp    ax,0x1
    2ad0:	75 10                	jne    0x2ae2
    2ad2:	a1 a0 2e             	mov    ax,ds:0x2ea0
    2ad5:	8b 16 a2 2e          	mov    dx,WORD PTR ds:0x2ea2
    2ad9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2adc:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2adf:	e9 5a 01             	jmp    0x2c3c
    2ae2:	3d 02 00             	cmp    ax,0x2
    2ae5:	74 0a                	je     0x2af1
    2ae7:	3d 04 00             	cmp    ax,0x4
    2aea:	7c 30                	jl     0x2b1c
    2aec:	3d 0a 00             	cmp    ax,0xa
    2aef:	7f 2b                	jg     0x2b1c
    2af1:	8b 7e 0a             	mov    di,WORD PTR [bp+0xa]
    2af4:	d1 e7                	shl    di,1
    2af6:	8b f7                	mov    si,di
    2af8:	d1 e7                	shl    di,1
    2afa:	01 f7                	add    di,si
    2afc:	81 c7 f2 17          	add    di,0x17f2
    2b00:	1e                   	push   ds
    2b01:	07                   	pop    es
    2b02:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2b06:	b0 01                	mov    al,0x1
    2b08:	50                   	push   ax
    2b09:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b0c:	06                   	push   es
    2b0d:	57                   	push   di
    2b0e:	9a 23 29 79 2b       	call   0x2b79:0x2923
    2b13:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b16:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2b19:	e9 20 01             	jmp    0x2c3c
    2b1c:	3d 03 00             	cmp    ax,0x3
    2b1f:	74 10                	je     0x2b31
    2b21:	3d 0b 00             	cmp    ax,0xb
    2b24:	7d 03                	jge    0x2b29
    2b26:	e9 0a 01             	jmp    0x2c33
    2b29:	3d 10 00             	cmp    ax,0x10
    2b2c:	7e 03                	jle    0x2b31
    2b2e:	e9 02 01             	jmp    0x2c33
    2b31:	8b 7e 0a             	mov    di,WORD PTR [bp+0xa]
    2b34:	d1 e7                	shl    di,1
    2b36:	8b f7                	mov    si,di
    2b38:	d1 e7                	shl    di,1
    2b3a:	01 f7                	add    di,si
    2b3c:	81 c7 f2 17          	add    di,0x17f2
    2b40:	1e                   	push   ds
    2b41:	07                   	pop    es
    2b42:	89 7e a4             	mov    WORD PTR [bp-0x5c],di
    2b45:	8c 46 a6             	mov    WORD PTR [bp-0x5a],es
    2b48:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2b4b:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2b4e:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    2b51:	89 56 aa             	mov    WORD PTR [bp-0x56],dx
    2b54:	8d 7e ac             	lea    di,[bp-0x54]
    2b57:	16                   	push   ss
    2b58:	57                   	push   di
    2b59:	8d 7e aa             	lea    di,[bp-0x56]
    2b5c:	16                   	push   ss
    2b5d:	57                   	push   di
    2b5e:	e8 17 fb             	call   0x2678
    2b61:	80 7e ac 00          	cmp    BYTE PTR [bp-0x54],0x0
    2b65:	74 6f                	je     0x2bd6
    2b67:	6a a1                	push   0xffa1
    2b69:	8d be a4 fe          	lea    di,[bp-0x15c]
    2b6d:	16                   	push   ss
    2b6e:	57                   	push   di
    2b6f:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    2b72:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2b76:	9a 2b 09 cc 2b       	call   0x2bcc:0x92b
    2b7b:	83 c4 04             	add    sp,0x4
    2b7e:	8d 86 a4 fe          	lea    ax,[bp-0x15c]
    2b82:	8c d2                	mov    dx,ss
    2b84:	89 86 8c fe          	mov    WORD PTR [bp-0x174],ax
    2b88:	89 96 8e fe          	mov    WORD PTR [bp-0x172],dx
    2b8c:	c6 86 90 fe 04       	mov    BYTE PTR [bp-0x170],0x4
    2b91:	8d 46 ac             	lea    ax,[bp-0x54]
    2b94:	8c d2                	mov    dx,ss
    2b96:	89 86 94 fe          	mov    WORD PTR [bp-0x16c],ax
    2b9a:	89 96 96 fe          	mov    WORD PTR [bp-0x16a],dx
    2b9e:	c6 86 98 fe 04       	mov    BYTE PTR [bp-0x168],0x4
    2ba3:	8b 46 a8             	mov    ax,WORD PTR [bp-0x58]
    2ba6:	8b 56 aa             	mov    dx,WORD PTR [bp-0x56]
    2ba9:	89 86 9c fe          	mov    WORD PTR [bp-0x164],ax
    2bad:	89 96 9e fe          	mov    WORD PTR [bp-0x162],dx
    2bb1:	c6 86 a0 fe 05       	mov    BYTE PTR [bp-0x160],0x5
    2bb6:	8d be 8c fe          	lea    di,[bp-0x174]
    2bba:	16                   	push   ss
    2bbb:	57                   	push   di
    2bbc:	6a 02                	push   0x2
    2bbe:	b0 01                	mov    al,0x1
    2bc0:	50                   	push   ax
    2bc1:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    2bc4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bc7:	06                   	push   es
    2bc8:	57                   	push   di
    2bc9:	9a 6a 29 e8 2b       	call   0x2be8:0x296a
    2bce:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2bd1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2bd4:	eb 5b                	jmp    0x2c31
    2bd6:	6a a2                	push   0xffa2
    2bd8:	8d be a4 fe          	lea    di,[bp-0x15c]
    2bdc:	16                   	push   ss
    2bdd:	57                   	push   di
    2bde:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    2be1:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2be5:	9a 2b 09 29 2c       	call   0x2c29:0x92b
    2bea:	83 c4 04             	add    sp,0x4
    2bed:	8d 86 a4 fe          	lea    ax,[bp-0x15c]
    2bf1:	8c d2                	mov    dx,ss
    2bf3:	89 86 94 fe          	mov    WORD PTR [bp-0x16c],ax
    2bf7:	89 96 96 fe          	mov    WORD PTR [bp-0x16a],dx
    2bfb:	c6 86 98 fe 04       	mov    BYTE PTR [bp-0x168],0x4
    2c00:	8b 46 a8             	mov    ax,WORD PTR [bp-0x58]
    2c03:	8b 56 aa             	mov    dx,WORD PTR [bp-0x56]
    2c06:	89 86 9c fe          	mov    WORD PTR [bp-0x164],ax
    2c0a:	89 96 9e fe          	mov    WORD PTR [bp-0x162],dx
    2c0e:	c6 86 a0 fe 05       	mov    BYTE PTR [bp-0x160],0x5
    2c13:	8d be 94 fe          	lea    di,[bp-0x16c]
    2c17:	16                   	push   ss
    2c18:	57                   	push   di
    2c19:	6a 01                	push   0x1
    2c1b:	b0 01                	mov    al,0x1
    2c1d:	50                   	push   ax
    2c1e:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    2c21:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c24:	06                   	push   es
    2c25:	57                   	push   di
    2c26:	9a 6a 29 63 2c       	call   0x2c63:0x296a
    2c2b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c2e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2c31:	eb 09                	jmp    0x2c3c
    2c33:	e8 00 fe             	call   0x2a36
    2c36:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c39:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2c3c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c3f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c42:	ff 76 08             	push   WORD PTR [bp+0x8]
    2c45:	ff 76 06             	push   WORD PTR [bp+0x6]
    2c48:	ea 99 13 6b 2c       	jmp    0x2c6b:0x1399
    2c4d:	c9                   	leave
    2c4e:	ca 06 00             	retf   0x6
    2c51:	55                   	push   bp
    2c52:	89 e5                	mov    bp,sp
    2c54:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2c57:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c5a:	ff 76 08             	push   WORD PTR [bp+0x8]
    2c5d:	ff 76 06             	push   WORD PTR [bp+0x6]
    2c60:	9a 00 27 01 2d       	call   0x2d01:0x2700
    2c65:	b8 01 00             	mov    ax,0x1
    2c68:	9a 93 00 f4 38       	call   0x38f4:0x93
    2c6d:	c9                   	leave
    2c6e:	ca 08 00             	retf   0x8
    2c71:	03 0b                	add    cx,WORD PTR [bp+di]
    2c73:	00 0c                	add    BYTE PTR [si],cl
    2c75:	00 00                	add    BYTE PTR [bx+si],al
    2c77:	0d 00 00             	or     ax,0x0
    2c7a:	00 00                	add    BYTE PTR [bx+si],al
    2c7c:	00 0e 0f 10          	add    BYTE PTR ds:0x100f,cl
    2c80:	c3                   	ret
    2c81:	55                   	push   bp
    2c82:	89 e5                	mov    bp,sp
    2c84:	60                   	pusha
    2c85:	06                   	push   es
    2c86:	1e                   	push   ds
    2c87:	8e d8                	mov    ds,ax
    2c89:	f7 46 08 00 80       	test   WORD PTR [bp+0x8],0x8000
    2c8e:	75 77                	jne    0x2d07
    2c90:	9a d5 2d 00 00       	call   0x0:0x2dd5
    2c95:	09 c0                	or     ax,ax
    2c97:	74 6a                	je     0x2d03
    2c99:	3b 06 f6 17          	cmp    ax,WORD PTR ds:0x17f6
    2c9d:	75 64                	jne    0x2d03
    2c9f:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2ca2:	3d 0f 00             	cmp    ax,0xf
    2ca5:	73 60                	jae    0x2d07
    2ca7:	80 3e 12 17 00       	cmp    BYTE PTR ds:0x1712,0x0
    2cac:	75 0a                	jne    0x2cb8
    2cae:	3d 01 00             	cmp    ax,0x1
    2cb1:	74 54                	je     0x2d07
    2cb3:	3d 03 00             	cmp    ax,0x3
    2cb6:	74 4f                	je     0x2d07
    2cb8:	bb 71 2c             	mov    bx,0x2c71
    2cbb:	2e d7                	xlat   BYTE PTR cs:[bx]
    2cbd:	09 c0                	or     ax,ax
    2cbf:	74 42                	je     0x2d03
    2cc1:	50                   	push   ax
    2cc2:	a1 0e 17             	mov    ax,ds:0x170e
    2cc5:	0b 06 10 17          	or     ax,WORD PTR ds:0x1710
    2cc9:	58                   	pop    ax
    2cca:	74 17                	je     0x2ce3
    2ccc:	ff 76 08             	push   WORD PTR [bp+0x8]
    2ccf:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2cd2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2cd5:	ff 1e 0e 17          	call   DWORD PTR ds:0x170e
    2cd9:	08 c0                	or     al,al
    2cdb:	74 31                	je     0x2d0e
    2cdd:	fe c8                	dec    al
    2cdf:	74 38                	je     0x2d19
    2ce1:	eb 24                	jmp    0x2d07
    2ce3:	83 3e fc 17 00       	cmp    WORD PTR ds:0x17fc,0x0
    2ce8:	75 24                	jne    0x2d0e
    2cea:	ff 06 fc 17          	inc    WORD PTR ds:0x17fc
    2cee:	87 46 10             	xchg   WORD PTR [bp+0x10],ax
    2cf1:	ff 46 0c             	inc    WORD PTR [bp+0xc]
    2cf4:	89 ec                	mov    sp,bp
    2cf6:	5d                   	pop    bp
    2cf7:	83 c4 06             	add    sp,0x6
    2cfa:	ff 0e fc 17          	dec    WORD PTR ds:0x17fc
    2cfe:	ea c6 2a 59 2d       	jmp    0x2d59:0x2ac6
    2d03:	ff 0e fc 17          	dec    WORD PTR ds:0x17fc
    2d07:	1f                   	pop    ds
    2d08:	07                   	pop    es
    2d09:	61                   	popa
    2d0a:	89 ec                	mov    sp,bp
    2d0c:	5d                   	pop    bp
    2d0d:	cb                   	retf
    2d0e:	ff 36 f6 17          	push   WORD PTR ds:0x17f6
    2d12:	6a 01                	push   0x1
    2d14:	9a ff ff 00 00       	call   0x0:0xffff
    2d19:	1f                   	pop    ds
    2d1a:	07                   	pop    es
    2d1b:	61                   	popa
    2d1c:	89 ec                	mov    sp,bp
    2d1e:	5d                   	pop    bp
    2d1f:	83 c4 0a             	add    sp,0xa
    2d22:	cf                   	iret
    2d23:	cb                   	retf
    2d24:	55                   	push   bp
    2d25:	89 e5                	mov    bp,sp
    2d27:	c4 3e 24 00          	les    di,DWORD PTR ds:0x24
    2d2b:	8c c0                	mov    ax,es
    2d2d:	09 f8                	or     ax,di
    2d2f:	74 07                	je     0x2d38
    2d31:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    2d34:	26 88 45 2e          	mov    BYTE PTR es:[di+0x2e],al
    2d38:	c9                   	leave
    2d39:	c2 02 00             	ret    0x2
    2d3c:	55                   	push   bp
    2d3d:	89 e5                	mov    bp,sp
    2d3f:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
    2d44:	74 6d                	je     0x2db3
    2d46:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    2d4a:	74 37                	je     0x2d83
    2d4c:	a1 f8 17             	mov    ax,ds:0x17f8
    2d4f:	0b 06 fa 17          	or     ax,WORD PTR ds:0x17fa
    2d53:	75 2e                	jne    0x2d83
    2d55:	bf 81 2c             	mov    di,0x2c81
    2d58:	b8 bf 2d             	mov    ax,0x2dbf
    2d5b:	50                   	push   ax
    2d5c:	57                   	push   di
    2d5d:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2d61:	9a ff ff 00 00       	call   0x0:0xffff
    2d66:	a3 f8 17             	mov    ds:0x17f8,ax
    2d69:	89 16 fa 17          	mov    WORD PTR ds:0x17fa,dx
    2d6d:	6a 00                	push   0x0
    2d6f:	ff 36 fa 17          	push   WORD PTR ds:0x17fa
    2d73:	ff 36 f8 17          	push   WORD PTR ds:0x17f8
    2d77:	9a ff ff 00 00       	call   0x0:0xffff
    2d7c:	6a 01                	push   0x1
    2d7e:	e8 a3 ff             	call   0x2d24
    2d81:	eb 30                	jmp    0x2db3
    2d83:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    2d87:	75 2a                	jne    0x2db3
    2d89:	a1 f8 17             	mov    ax,ds:0x17f8
    2d8c:	0b 06 fa 17          	or     ax,WORD PTR ds:0x17fa
    2d90:	74 21                	je     0x2db3
    2d92:	6a 00                	push   0x0
    2d94:	e8 8d ff             	call   0x2d24
    2d97:	6a 00                	push   0x0
    2d99:	9a ff ff 00 00       	call   0x0:0xffff
    2d9e:	ff 36 fa 17          	push   WORD PTR ds:0x17fa
    2da2:	ff 36 f8 17          	push   WORD PTR ds:0x17f8
    2da6:	9a ff ff 00 00       	call   0x0:0xffff
    2dab:	31 c0                	xor    ax,ax
    2dad:	a3 f8 17             	mov    ds:0x17f8,ax
    2db0:	a3 fa 17             	mov    ds:0x17fa,ax
    2db3:	c9                   	leave
    2db4:	ca 02 00             	retf   0x2
    2db7:	55                   	push   bp
    2db8:	89 e5                	mov    bp,sp
    2dba:	6a 00                	push   0x0
    2dbc:	9a 3c 2d e5 2d       	call   0x2de5:0x2d3c
    2dc1:	a1 a4 2e             	mov    ax,ds:0x2ea4
    2dc4:	8b 16 a6 2e          	mov    dx,WORD PTR ds:0x2ea6
    2dc8:	a3 6c 18             	mov    ds:0x186c,ax
    2dcb:	89 16 6e 18          	mov    WORD PTR ds:0x186e,dx
    2dcf:	c9                   	leave
    2dd0:	cb                   	retf
    2dd1:	55                   	push   bp
    2dd2:	89 e5                	mov    bp,sp
    2dd4:	9a ff ff 00 00       	call   0x0:0xffff
    2dd9:	a3 f6 17             	mov    ds:0x17f6,ax
    2ddc:	6a 87                	push   0xff87
    2dde:	b0 01                	mov    al,0x1
    2de0:	50                   	push   ax
    2de1:	b8 7f 00             	mov    ax,0x7f
    2de4:	ba ec 2d             	mov    dx,0x2dec
    2de7:	52                   	push   dx
    2de8:	50                   	push   ax
    2de9:	9a 23 29 f9 2d       	call   0x2df9:0x2923
    2dee:	a3 a0 2e             	mov    ds:0x2ea0,ax
    2df1:	89 16 a2 2e          	mov    WORD PTR ds:0x2ea2,dx
    2df5:	b8 c6 2a             	mov    ax,0x2ac6
    2df8:	ba 06 2e             	mov    dx,0x2e06
    2dfb:	a3 60 18             	mov    ds:0x1860,ax
    2dfe:	89 16 62 18          	mov    WORD PTR ds:0x1862,dx
    2e02:	b8 51 2c             	mov    ax,0x2c51
    2e05:	ba 13 2e             	mov    dx,0x2e13
    2e08:	a3 5c 18             	mov    ds:0x185c,ax
    2e0b:	89 16 5e 18          	mov    WORD PTR ds:0x185e,dx
    2e0f:	b8 2e 00             	mov    ax,0x2e
    2e12:	ba 2e 2e             	mov    dx,0x2e2e
    2e15:	a3 64 18             	mov    ds:0x1864,ax
    2e18:	89 16 66 18          	mov    WORD PTR ds:0x1866,dx
    2e1c:	a1 6c 18             	mov    ax,ds:0x186c
    2e1f:	8b 16 6e 18          	mov    dx,WORD PTR ds:0x186e
    2e23:	a3 a4 2e             	mov    ds:0x2ea4,ax
    2e26:	89 16 a6 2e          	mov    WORD PTR ds:0x2ea6,dx
    2e2a:	b8 b7 2d             	mov    ax,0x2db7
    2e2d:	ba 3c 2e             	mov    dx,0x2e3c
    2e30:	a3 6c 18             	mov    ds:0x186c,ax
    2e33:	89 16 6e 18          	mov    WORD PTR ds:0x186e,dx
    2e37:	6a 01                	push   0x1
    2e39:	9a 3c 2d 4c 2e       	call   0x2e4c:0x2d3c
    2e3e:	c9                   	leave
    2e3f:	c3                   	ret
    2e40:	55                   	push   bp
    2e41:	89 e5                	mov    bp,sp
    2e43:	e8 8b ff             	call   0x2dd1
    2e46:	e8 d7 f4             	call   0x2320
    2e49:	9a 1b 24 f2 30       	call   0x30f2:0x241b
    2e4e:	c9                   	leave
    2e4f:	cb                   	retf
    2e50:	55                   	push   bp
    2e51:	8b ec                	mov    bp,sp
    2e53:	83 ec 34             	sub    sp,0x34
    2e56:	8c 5e fe             	mov    WORD PTR [bp-0x2],ds
    2e59:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2e5c:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    2e5f:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    2e62:	8b 4e 0c             	mov    cx,WORD PTR [bp+0xc]
    2e65:	c7 46 fc 00 00       	mov    WORD PTR [bp-0x4],0x0
    2e6a:	fc                   	cld
    2e6b:	0b d2                	or     dx,dx
    2e6d:	74 0c                	je     0x2e7b
    2e6f:	e3 0a                	jcxz   0x2e7b
    2e71:	ac                   	lods   al,BYTE PTR ds:[si]
    2e72:	49                   	dec    cx
    2e73:	3c 25                	cmp    al,0x25
    2e75:	74 12                	je     0x2e89
    2e77:	aa                   	stos   BYTE PTR es:[di],al
    2e78:	4a                   	dec    dx
    2e79:	75 f4                	jne    0x2e6f
    2e7b:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    2e7e:	8b c7                	mov    ax,di
    2e80:	2b 46 14             	sub    ax,WORD PTR [bp+0x14]
    2e83:	8b e5                	mov    sp,bp
    2e85:	5d                   	pop    bp
    2e86:	ca 12 00             	retf   0x12
    2e89:	e3 f0                	jcxz   0x2e7b
    2e8b:	ac                   	lods   al,BYTE PTR ds:[si]
    2e8c:	49                   	dec    cx
    2e8d:	3c 25                	cmp    al,0x25
    2e8f:	74 e6                	je     0x2e77
    2e91:	8d 5c fe             	lea    bx,[si-0x2]
    2e94:	89 5e f4             	mov    WORD PTR [bp-0xc],bx
    2e97:	88 46 f6             	mov    BYTE PTR [bp-0xa],al
    2e9a:	3c 2d                	cmp    al,0x2d
    2e9c:	75 04                	jne    0x2ea2
    2e9e:	e3 db                	jcxz   0x2e7b
    2ea0:	ac                   	lods   al,BYTE PTR ds:[si]
    2ea1:	49                   	dec    cx
    2ea2:	e8 60 00             	call   0x2f05
    2ea5:	3c 3a                	cmp    al,0x3a
    2ea7:	75 05                	jne    0x2eae
    2ea9:	89 5e fc             	mov    WORD PTR [bp-0x4],bx
    2eac:	eb db                	jmp    0x2e89
    2eae:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    2eb1:	bb ff ff             	mov    bx,0xffff
    2eb4:	3c 2e                	cmp    al,0x2e
    2eb6:	75 07                	jne    0x2ebf
    2eb8:	e3 c1                	jcxz   0x2e7b
    2eba:	ac                   	lods   al,BYTE PTR ds:[si]
    2ebb:	49                   	dec    cx
    2ebc:	e8 46 00             	call   0x2f05
    2ebf:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
    2ec2:	89 76 0e             	mov    WORD PTR [bp+0xe],si
    2ec5:	51                   	push   cx
    2ec6:	52                   	push   dx
    2ec7:	e8 8c 00             	call   0x2f56
    2eca:	5a                   	pop    dx
    2ecb:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    2ece:	2b d9                	sub    bx,cx
    2ed0:	73 02                	jae    0x2ed4
    2ed2:	33 db                	xor    bx,bx
    2ed4:	80 7e f6 2d          	cmp    BYTE PTR [bp-0xa],0x2d
    2ed8:	75 0a                	jne    0x2ee4
    2eda:	2b d1                	sub    dx,cx
    2edc:	73 04                	jae    0x2ee2
    2ede:	03 ca                	add    cx,dx
    2ee0:	33 d2                	xor    dx,dx
    2ee2:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2ee4:	87 d9                	xchg   cx,bx
    2ee6:	2b d1                	sub    dx,cx
    2ee8:	73 04                	jae    0x2eee
    2eea:	03 ca                	add    cx,dx
    2eec:	33 d2                	xor    dx,dx
    2eee:	b0 20                	mov    al,0x20
    2ef0:	f3 aa                	rep stos BYTE PTR es:[di],al
    2ef2:	87 d9                	xchg   cx,bx
    2ef4:	2b d1                	sub    dx,cx
    2ef6:	73 04                	jae    0x2efc
    2ef8:	03 ca                	add    cx,dx
    2efa:	33 d2                	xor    dx,dx
    2efc:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2efe:	59                   	pop    cx
    2eff:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    2f02:	e9 66 ff             	jmp    0x2e6b
    2f05:	33 db                	xor    bx,bx
    2f07:	3c 2a                	cmp    al,0x2a
    2f09:	74 20                	je     0x2f2b
    2f0b:	3c 30                	cmp    al,0x30
    2f0d:	72 42                	jb     0x2f51
    2f0f:	3c 39                	cmp    al,0x39
    2f11:	77 3e                	ja     0x2f51
    2f13:	2c 30                	sub    al,0x30
    2f15:	32 e4                	xor    ah,ah
    2f17:	50                   	push   ax
    2f18:	d1 e3                	shl    bx,1
    2f1a:	8b c3                	mov    ax,bx
    2f1c:	d1 e3                	shl    bx,1
    2f1e:	d1 e3                	shl    bx,1
    2f20:	03 d8                	add    bx,ax
    2f22:	58                   	pop    ax
    2f23:	03 d8                	add    bx,ax
    2f25:	e3 2b                	jcxz   0x2f52
    2f27:	ac                   	lods   al,BYTE PTR ds:[si]
    2f28:	49                   	dec    cx
    2f29:	eb e0                	jmp    0x2f0b
    2f2b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f2e:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    2f31:	77 1a                	ja     0x2f4d
    2f33:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2f36:	d1 e0                	shl    ax,1
    2f38:	d1 e0                	shl    ax,1
    2f3a:	d1 e0                	shl    ax,1
    2f3c:	1e                   	push   ds
    2f3d:	56                   	push   si
    2f3e:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
    2f41:	03 f0                	add    si,ax
    2f43:	80 7c 04 00          	cmp    BYTE PTR [si+0x4],0x0
    2f47:	75 02                	jne    0x2f4b
    2f49:	8b 1c                	mov    bx,WORD PTR [si]
    2f4b:	5e                   	pop    si
    2f4c:	1f                   	pop    ds
    2f4d:	e3 03                	jcxz   0x2f52
    2f4f:	ac                   	lods   al,BYTE PTR ds:[si]
    2f50:	49                   	dec    cx
    2f51:	c3                   	ret
    2f52:	58                   	pop    ax
    2f53:	e9 25 ff             	jmp    0x2e7b
    2f56:	24 df                	and    al,0xdf
    2f58:	8a c8                	mov    cl,al
    2f5a:	b8 01 00             	mov    ax,0x1
    2f5d:	8b 5e fc             	mov    bx,WORD PTR [bp-0x4]
    2f60:	3b 5e 06             	cmp    bx,WORD PTR [bp+0x6]
    2f63:	77 33                	ja     0x2f98
    2f65:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2f68:	d1 e3                	shl    bx,1
    2f6a:	d1 e3                	shl    bx,1
    2f6c:	d1 e3                	shl    bx,1
    2f6e:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
    2f71:	03 f3                	add    si,bx
    2f73:	8b 04                	mov    ax,WORD PTR [si]
    2f75:	8b 54 02             	mov    dx,WORD PTR [si+0x2]
    2f78:	8a 5c 04             	mov    bl,BYTE PTR [si+0x4]
    2f7b:	32 ff                	xor    bh,bh
    2f7d:	d1 e3                	shl    bx,1
    2f7f:	2e ff a7 84 2f       	jmp    WORD PTR cs:[bx+0x2f84]
    2f84:	ac                   	lods   al,BYTE PTR ds:[si]
    2f85:	2f                   	das
    2f86:	96                   	xchg   si,ax
    2f87:	2f                   	das
    2f88:	1a 30                	sbb    dh,BYTE PTR [bx+si]
    2f8a:	82 30 23             	xor    BYTE PTR [bx+si],0x23
    2f8d:	30 60 30             	xor    BYTE PTR [bx+si+0x30],ah
    2f90:	3e 30 96 2f 96       	xor    BYTE PTR ds:[bp-0x69d1],dl
    2f95:	2f                   	das
    2f96:	33 c0                	xor    ax,ax
    2f98:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    2f9b:	50                   	push   ax
    2f9c:	ff 76 10             	push   WORD PTR [bp+0x10]
    2f9f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2fa2:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    2fa5:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    2fa8:	50                   	push   ax
    2fa9:	e8 9b df             	call   0xf47
    2fac:	80 f9 44             	cmp    cl,0x44
    2faf:	74 0f                	je     0x2fc0
    2fb1:	80 f9 55             	cmp    cl,0x55
    2fb4:	74 1f                	je     0x2fd5
    2fb6:	80 f9 58             	cmp    cl,0x58
    2fb9:	75 db                	jne    0x2f96
    2fbb:	b9 10 00             	mov    cx,0x10
    2fbe:	eb 18                	jmp    0x2fd8
    2fc0:	0b d2                	or     dx,dx
    2fc2:	79 11                	jns    0x2fd5
    2fc4:	f7 da                	neg    dx
    2fc6:	f7 d8                	neg    ax
    2fc8:	83 da 00             	sbb    dx,0x0
    2fcb:	e8 07 00             	call   0x2fd5
    2fce:	b0 2d                	mov    al,0x2d
    2fd0:	41                   	inc    cx
    2fd1:	4e                   	dec    si
    2fd2:	88 04                	mov    BYTE PTR [si],al
    2fd4:	c3                   	ret
    2fd5:	b9 0a 00             	mov    cx,0xa
    2fd8:	8d 76 dc             	lea    si,[bp-0x24]
    2fdb:	8c d3                	mov    bx,ss
    2fdd:	8e db                	mov    ds,bx
    2fdf:	8b da                	mov    bx,dx
    2fe1:	33 d2                	xor    dx,dx
    2fe3:	93                   	xchg   bx,ax
    2fe4:	f7 f1                	div    cx
    2fe6:	93                   	xchg   bx,ax
    2fe7:	f7 f1                	div    cx
    2fe9:	80 c2 30             	add    dl,0x30
    2fec:	80 fa 3a             	cmp    dl,0x3a
    2fef:	72 03                	jb     0x2ff4
    2ff1:	80 c2 07             	add    dl,0x7
    2ff4:	4e                   	dec    si
    2ff5:	88 14                	mov    BYTE PTR [si],dl
    2ff7:	8b d0                	mov    dx,ax
    2ff9:	0b d3                	or     dx,bx
    2ffb:	75 e4                	jne    0x2fe1
    2ffd:	8d 4e dc             	lea    cx,[bp-0x24]
    3000:	2b ce                	sub    cx,si
    3002:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    3005:	83 fa 10             	cmp    dx,0x10
    3008:	72 01                	jb     0x300b
    300a:	c3                   	ret
    300b:	2b d1                	sub    dx,cx
    300d:	76 0a                	jbe    0x3019
    300f:	03 ca                	add    cx,dx
    3011:	b0 30                	mov    al,0x30
    3013:	4e                   	dec    si
    3014:	88 04                	mov    BYTE PTR [si],al
    3016:	4a                   	dec    dx
    3017:	75 fa                	jne    0x3013
    3019:	c3                   	ret
    301a:	80 f9 53             	cmp    cl,0x53
    301d:	75 1c                	jne    0x303b
    301f:	b9 01 00             	mov    cx,0x1
    3022:	c3                   	ret
    3023:	80 f9 53             	cmp    cl,0x53
    3026:	75 13                	jne    0x303b
    3028:	8b f0                	mov    si,ax
    302a:	8e da                	mov    ds,dx
    302c:	ac                   	lods   al,BYTE PTR ds:[si]
    302d:	8a c8                	mov    cl,al
    302f:	32 ed                	xor    ch,ch
    3031:	3b 4e f8             	cmp    cx,WORD PTR [bp-0x8]
    3034:	77 01                	ja     0x3037
    3036:	c3                   	ret
    3037:	8b 4e f8             	mov    cx,WORD PTR [bp-0x8]
    303a:	c3                   	ret
    303b:	e9 58 ff             	jmp    0x2f96
    303e:	80 f9 53             	cmp    cl,0x53
    3041:	75 f8                	jne    0x303b
    3043:	8b f0                	mov    si,ax
    3045:	8e da                	mov    ds,dx
    3047:	06                   	push   es
    3048:	57                   	push   di
    3049:	8b f8                	mov    di,ax
    304b:	8e c2                	mov    es,dx
    304d:	32 c0                	xor    al,al
    304f:	8b 4e f8             	mov    cx,WORD PTR [bp-0x8]
    3052:	e3 05                	jcxz   0x3059
    3054:	f2 ae                	repnz scas al,BYTE PTR es:[di]
    3056:	75 01                	jne    0x3059
    3058:	4f                   	dec    di
    3059:	8b cf                	mov    cx,di
    305b:	2b ce                	sub    cx,si
    305d:	5f                   	pop    di
    305e:	07                   	pop    es
    305f:	c3                   	ret
    3060:	80 f9 50             	cmp    cl,0x50
    3063:	75 d6                	jne    0x303b
    3065:	c7 46 f8 08 00       	mov    WORD PTR [bp-0x8],0x8
    306a:	b9 10 00             	mov    cx,0x10
    306d:	e8 68 ff             	call   0x2fd8
    3070:	41                   	inc    cx
    3071:	4e                   	dec    si
    3072:	8b 44 01             	mov    ax,WORD PTR [si+0x1]
    3075:	89 04                	mov    WORD PTR [si],ax
    3077:	8b 44 03             	mov    ax,WORD PTR [si+0x3]
    307a:	89 44 02             	mov    WORD PTR [si+0x2],ax
    307d:	c6 44 04 3a          	mov    BYTE PTR [si+0x4],0x3a
    3081:	c3                   	ret
    3082:	8b f0                	mov    si,ax
    3084:	8e da                	mov    ds,dx
    3086:	b3 00                	mov    bl,0x0
    3088:	80 f9 47             	cmp    cl,0x47
    308b:	74 39                	je     0x30c6
    308d:	b3 01                	mov    bl,0x1
    308f:	80 f9 45             	cmp    cl,0x45
    3092:	74 32                	je     0x30c6
    3094:	b3 02                	mov    bl,0x2
    3096:	80 f9 46             	cmp    cl,0x46
    3099:	74 0e                	je     0x30a9
    309b:	b3 03                	mov    bl,0x3
    309d:	80 f9 4e             	cmp    cl,0x4e
    30a0:	74 07                	je     0x30a9
    30a2:	80 f9 4d             	cmp    cl,0x4d
    30a5:	75 94                	jne    0x303b
    30a7:	b3 04                	mov    bl,0x4
    30a9:	b8 12 00             	mov    ax,0x12
    30ac:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    30af:	3b d0                	cmp    dx,ax
    30b1:	76 21                	jbe    0x30d4
    30b3:	ba 02 00             	mov    dx,0x2
    30b6:	80 f9 4d             	cmp    cl,0x4d
    30b9:	75 19                	jne    0x30d4
    30bb:	1e                   	push   ds
    30bc:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    30bf:	8a 16 64 2c          	mov    dl,BYTE PTR ds:0x2c64
    30c3:	1f                   	pop    ds
    30c4:	eb 0e                	jmp    0x30d4
    30c6:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    30c9:	ba 03 00             	mov    dx,0x3
    30cc:	3d 12 00             	cmp    ax,0x12
    30cf:	76 03                	jbe    0x30d4
    30d1:	b8 0f 00             	mov    ax,0xf
    30d4:	06                   	push   es
    30d5:	57                   	push   di
    30d6:	8d 7e cc             	lea    di,[bp-0x34]
    30d9:	16                   	push   ss
    30da:	57                   	push   di
    30db:	ff 74 08             	push   WORD PTR [si+0x8]
    30de:	ff 74 06             	push   WORD PTR [si+0x6]
    30e1:	ff 74 04             	push   WORD PTR [si+0x4]
    30e4:	ff 74 02             	push   WORD PTR [si+0x2]
    30e7:	ff 34                	push   WORD PTR [si]
    30e9:	53                   	push   bx
    30ea:	50                   	push   ax
    30eb:	52                   	push   dx
    30ec:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    30ef:	9a a0 31 ff ff       	call   0xffff:0x31a0
    30f4:	8b c8                	mov    cx,ax
    30f6:	8d 76 cc             	lea    si,[bp-0x34]
    30f9:	16                   	push   ss
    30fa:	1f                   	pop    ds
    30fb:	5f                   	pop    di
    30fc:	07                   	pop    es
    30fd:	c3                   	ret
    30fe:	0a 00                	or     al,BYTE PTR [bx+si]
    3100:	01 00                	add    WORD PTR [bx+si],ax
    3102:	00 00                	add    BYTE PTR [bx+si],al
    3104:	0a 00                	or     al,BYTE PTR [bx+si]
    3106:	00 00                	add    BYTE PTR [bx+si],al
    3108:	64 00 00             	add    BYTE PTR fs:[bx+si],al
    310b:	00 e8                	add    al,ch
    310d:	03 00                	add    ax,WORD PTR [bx+si]
    310f:	00 10                	add    BYTE PTR [bx+si],dl
    3111:	27                   	daa
    3112:	00 00                	add    BYTE PTR [bx+si],al
    3114:	a0 86 01             	mov    al,ds:0x186
    3117:	00 40 42             	add    BYTE PTR [bx+si+0x42],al
    311a:	0f 00 80 96 98       	sldt   WORD PTR [bx+si-0x676a]
    311f:	00 00                	add    BYTE PTR [bx+si],al
    3121:	00 00                	add    BYTE PTR [bx+si],al
    3123:	00 00                	add    BYTE PTR [bx+si],al
    3125:	20 bc be 19          	and    BYTE PTR [si+0x19be],bh
    3129:	40                   	inc    ax
    312a:	00 00                	add    BYTE PTR [bx+si],al
    312c:	00 04                	add    BYTE PTR [si],al
    312e:	bf c9 1b             	mov    di,0x1bc9
    3131:	8e 34                	mov    ?,WORD PTR [si]
    3133:	40                   	inc    ax
    3134:	9e                   	sahf
    3135:	b5 70                	mov    ch,0x70
    3137:	2b a8 ad c5          	sub    bp,WORD PTR [bx+si-0x3a53]
    313b:	9d                   	popf
    313c:	69 40 d5 a6 cf       	imul   ax,WORD PTR [bx+si-0x2b],0xcfa6
    3141:	ff 49 1f             	dec    WORD PTR [bx+di+0x1f]
    3144:	78 c2                	js     0x3108
    3146:	d3 40 e0             	rol    WORD PTR [bx+si-0x20],cl
    3149:	8c e9                	mov    cx,gs
    314b:	80 c9 47             	or     cl,0x47
    314e:	ba 93 a8             	mov    dx,0xa893
    3151:	41                   	inc    cx
    3152:	8e de                	mov    ds,si
    3154:	f9                   	stc
    3155:	9d                   	popf
    3156:	fb                   	sti
    3157:	eb 7e                	jmp    0x31d7
    3159:	aa                   	stos   BYTE PTR es:[di],al
    315a:	51                   	push   cx
    315b:	43                   	inc    bx
    315c:	c7                   	(bad)
    315d:	91                   	xchg   cx,ax
    315e:	0e                   	push   cs
    315f:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    3160:	ae                   	scas   al,BYTE PTR es:[di]
    3161:	a0 19 e3             	mov    al,ds:0xe319
    3164:	a3 46 17             	mov    ds:0x1746,ax
    3167:	0c 75                	or     al,0x75
    3169:	81 86 75 76 c9 48    	add    WORD PTR [bp+0x7675],0x48c9
    316f:	4d                   	dec    bp
    3170:	e5 5d                	in     ax,0x5d
    3172:	3d c5 5d             	cmp    ax,0x5dc5
    3175:	3b 8b 9e 92          	cmp    cx,WORD PTR [bp+di-0x6d62]
    3179:	5a                   	pop    dx
    317a:	9b                   	fwait
    317b:	97                   	xchg   di,ax
    317c:	20 8a 02 52          	and    BYTE PTR [bp+si+0x5202],cl
    3180:	60                   	pusha
    3181:	c4 25                	les    sp,DWORD PTR [di]
    3183:	75 00                	jne    0x3185
    3185:	00 40 76             	add    BYTE PTR [bx+si+0x76],al
    3188:	3a 6b 0b             	cmp    ch,BYTE PTR [bp+di+0xb]
    318b:	de 3a                	fidivr WORD PTR [bp+si]
    318d:	40                   	inc    ax
    318e:	00 00                	add    BYTE PTR [bx+si],al
    3190:	00 00                	add    BYTE PTR [bx+si],al
    3192:	00 00                	add    BYTE PTR [bx+si],al
    3194:	00 80 ff 7f          	add    BYTE PTR [bx+si+0x7fff],al
    3198:	3f                   	aas
    3199:	13 4e 41             	adc    cx,WORD PTR [bp+0x41]
    319c:	4e                   	dec    si
    319d:	49                   	dec    cx
    319e:	4e                   	dec    si
    319f:	46                   	inc    si
    31a0:	55                   	push   bp
    31a1:	8b ec                	mov    bp,sp
    31a3:	83 ec 1c             	sub    sp,0x1c
    31a6:	8c 5e fe             	mov    WORD PTR [bp-0x2],ds
    31a9:	a1 60 2c             	mov    ax,ds:0x2c60
    31ac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    31af:	a1 62 2c             	mov    ax,ds:0x2c62
    31b2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    31b5:	83 7e 08 02          	cmp    WORD PTR [bp+0x8],0x2
    31b9:	7d 05                	jge    0x31c0
    31bb:	c7 46 08 02 00       	mov    WORD PTR [bp+0x8],0x2
    31c0:	83 7e 08 12          	cmp    WORD PTR [bp+0x8],0x12
    31c4:	7e 05                	jle    0x31cb
    31c6:	c7 46 08 12 00       	mov    WORD PTR [bp+0x8],0x12
    31cb:	8d 46 e4             	lea    ax,[bp-0x1c]
    31ce:	16                   	push   ss
    31cf:	50                   	push   ax
    31d0:	ff 76 14             	push   WORD PTR [bp+0x14]
    31d3:	ff 76 12             	push   WORD PTR [bp+0x12]
    31d6:	ff 76 10             	push   WORD PTR [bp+0x10]
    31d9:	ff 76 0e             	push   WORD PTR [bp+0xe]
    31dc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    31df:	ff 76 08             	push   WORD PTR [bp+0x8]
    31e2:	b8 0f 27             	mov    ax,0x270f
    31e5:	80 7e 0a 02          	cmp    BYTE PTR [bp+0xa],0x2
    31e9:	72 03                	jb     0x31ee
    31eb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    31ee:	50                   	push   ax
    31ef:	0e                   	push   cs
    31f0:	e8 d7 04             	call   0x36ca
    31f3:	1e                   	push   ds
    31f4:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    31f7:	fc                   	cld
    31f8:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    31fb:	2d ff 7f             	sub    ax,0x7fff
    31fe:	3d 02 00             	cmp    ax,0x2
    3201:	73 12                	jae    0x3215
    3203:	be 9a 31             	mov    si,0x319a
    3206:	0e                   	push   cs
    3207:	1f                   	pop    ds
    3208:	03 f0                	add    si,ax
    320a:	03 f0                	add    si,ax
    320c:	03 f0                	add    si,ax
    320e:	b9 03 00             	mov    cx,0x3
    3211:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    3213:	eb 25                	jmp    0x323a
    3215:	8d 76 e7             	lea    si,[bp-0x19]
    3218:	16                   	push   ss
    3219:	1f                   	pop    ds
    321a:	8a 5e 0a             	mov    bl,BYTE PTR [bp+0xa]
    321d:	80 fb 01             	cmp    bl,0x1
    3220:	74 0f                	je     0x3231
    3222:	80 fb 04             	cmp    bl,0x4
    3225:	77 08                	ja     0x322f
    3227:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    322a:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    322d:	7e 02                	jle    0x3231
    322f:	b3 00                	mov    bl,0x0
    3231:	32 ff                	xor    bh,bh
    3233:	03 db                	add    bx,bx
    3235:	2e ff 97 48 32       	call   WORD PTR cs:[bx+0x3248]
    323a:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    323d:	8b c7                	mov    ax,di
    323f:	2b 46 16             	sub    ax,WORD PTR [bp+0x16]
    3242:	8b e5                	mov    sp,bp
    3244:	5d                   	pop    bp
    3245:	ca 14 00             	retf   0x14
    3248:	65 32 be 32 2b       	xor    bh,BYTE PTR gs:[bp+0x2b32]
    324d:	33 2b                	xor    bp,WORD PTR [bp+di]
    324f:	33 84 33 ac          	xor    ax,WORD PTR [si-0x53cd]
    3253:	0a c0                	or     al,al
    3255:	75 03                	jne    0x325a
    3257:	b0 30                	mov    al,0x30
    3259:	4e                   	dec    si
    325a:	c3                   	ret
    325b:	80 7e e6 00          	cmp    BYTE PTR [bp-0x1a],0x0
    325f:	74 03                	je     0x3264
    3261:	b0 2d                	mov    al,0x2d
    3263:	aa                   	stos   BYTE PTR es:[di],al
    3264:	c3                   	ret
    3265:	e8 f3 ff             	call   0x325b
    3268:	8b 4e e4             	mov    cx,WORD PTR [bp-0x1c]
    326b:	33 d2                	xor    dx,dx
    326d:	3b 4e 08             	cmp    cx,WORD PTR [bp+0x8]
    3270:	7f 1d                	jg     0x328f
    3272:	83 f9 fd             	cmp    cx,0xfffd
    3275:	7c 18                	jl     0x328f
    3277:	0b c9                	or     cx,cx
    3279:	7f 18                	jg     0x3293
    327b:	b0 30                	mov    al,0x30
    327d:	aa                   	stos   BYTE PTR es:[di],al
    327e:	80 3c 00             	cmp    BYTE PTR [si],0x0
    3281:	74 3a                	je     0x32bd
    3283:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3286:	aa                   	stos   BYTE PTR es:[di],al
    3287:	f7 d9                	neg    cx
    3289:	b0 30                	mov    al,0x30
    328b:	f3 aa                	rep stos BYTE PTR es:[di],al
    328d:	eb 17                	jmp    0x32a6
    328f:	b9 01 00             	mov    cx,0x1
    3292:	42                   	inc    dx
    3293:	ac                   	lods   al,BYTE PTR ds:[si]
    3294:	0a c0                	or     al,al
    3296:	74 16                	je     0x32ae
    3298:	aa                   	stos   BYTE PTR es:[di],al
    3299:	e2 f8                	loop   0x3293
    329b:	ac                   	lods   al,BYTE PTR ds:[si]
    329c:	0a c0                	or     al,al
    329e:	74 12                	je     0x32b2
    32a0:	8a e0                	mov    ah,al
    32a2:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    32a5:	ab                   	stos   WORD PTR es:[di],ax
    32a6:	ac                   	lods   al,BYTE PTR ds:[si]
    32a7:	0a c0                	or     al,al
    32a9:	74 07                	je     0x32b2
    32ab:	aa                   	stos   BYTE PTR es:[di],al
    32ac:	eb f8                	jmp    0x32a6
    32ae:	b0 30                	mov    al,0x30
    32b0:	f3 aa                	rep stos BYTE PTR es:[di],al
    32b2:	0b d2                	or     dx,dx
    32b4:	74 07                	je     0x32bd
    32b6:	32 e4                	xor    ah,ah
    32b8:	33 c9                	xor    cx,cx
    32ba:	eb 22                	jmp    0x32de
    32bc:	90                   	nop
    32bd:	c3                   	ret
    32be:	e8 9a ff             	call   0x325b
    32c1:	e8 8e ff             	call   0x3252
    32c4:	8a 66 fb             	mov    ah,BYTE PTR [bp-0x5]
    32c7:	ab                   	stos   WORD PTR es:[di],ax
    32c8:	8b 4e 08             	mov    cx,WORD PTR [bp+0x8]
    32cb:	49                   	dec    cx
    32cc:	e8 83 ff             	call   0x3252
    32cf:	aa                   	stos   BYTE PTR es:[di],al
    32d0:	e2 fa                	loop   0x32cc
    32d2:	b4 2b                	mov    ah,0x2b
    32d4:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    32d7:	83 f9 04             	cmp    cx,0x4
    32da:	72 02                	jb     0x32de
    32dc:	33 c9                	xor    cx,cx
    32de:	b0 45                	mov    al,0x45
    32e0:	8a 5e e7             	mov    bl,BYTE PTR [bp-0x19]
    32e3:	8b 56 e4             	mov    dx,WORD PTR [bp-0x1c]
    32e6:	4a                   	dec    dx
    32e7:	aa                   	stos   BYTE PTR es:[di],al
    32e8:	0a db                	or     bl,bl
    32ea:	75 04                	jne    0x32f0
    32ec:	33 d2                	xor    dx,dx
    32ee:	eb 0a                	jmp    0x32fa
    32f0:	0b d2                	or     dx,dx
    32f2:	7d 06                	jge    0x32fa
    32f4:	b0 2d                	mov    al,0x2d
    32f6:	f7 da                	neg    dx
    32f8:	eb 06                	jmp    0x3300
    32fa:	0a e4                	or     ah,ah
    32fc:	74 03                	je     0x3301
    32fe:	8a c4                	mov    al,ah
    3300:	aa                   	stos   BYTE PTR es:[di],al
    3301:	92                   	xchg   dx,ax
    3302:	83 ec 04             	sub    sp,0x4
    3305:	8b dc                	mov    bx,sp
    3307:	33 d2                	xor    dx,dx
    3309:	2e f7 36 fe 30       	div    WORD PTR cs:0x30fe
    330e:	80 c2 30             	add    dl,0x30
    3311:	36 88 17             	mov    BYTE PTR ss:[bx],dl
    3314:	43                   	inc    bx
    3315:	49                   	dec    cx
    3316:	0b c0                	or     ax,ax
    3318:	75 ed                	jne    0x3307
    331a:	0b c9                	or     cx,cx
    331c:	7f e9                	jg     0x3307
    331e:	4b                   	dec    bx
    331f:	36 8a 07             	mov    al,BYTE PTR ss:[bx]
    3322:	aa                   	stos   BYTE PTR es:[di],al
    3323:	3b dc                	cmp    bx,sp
    3325:	75 f7                	jne    0x331e
    3327:	83 c4 04             	add    sp,0x4
    332a:	c3                   	ret
    332b:	e8 2d ff             	call   0x325b
    332e:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    3331:	83 fa 12             	cmp    dx,0x12
    3334:	72 03                	jb     0x3339
    3336:	ba 12 00             	mov    dx,0x12
    3339:	8b 4e e4             	mov    cx,WORD PTR [bp-0x1c]
    333c:	0b c9                	or     cx,cx
    333e:	7f 05                	jg     0x3345
    3340:	b0 30                	mov    al,0x30
    3342:	aa                   	stos   BYTE PTR es:[di],al
    3343:	eb 24                	jmp    0x3369
    3345:	33 db                	xor    bx,bx
    3347:	80 7e 0a 02          	cmp    BYTE PTR [bp+0xa],0x2
    334b:	74 0a                	je     0x3357
    334d:	8b c1                	mov    ax,cx
    334f:	48                   	dec    ax
    3350:	b3 03                	mov    bl,0x3
    3352:	f6 f3                	div    bl
    3354:	8a dc                	mov    bl,ah
    3356:	43                   	inc    bx
    3357:	e8 f8 fe             	call   0x3252
    335a:	aa                   	stos   BYTE PTR es:[di],al
    335b:	49                   	dec    cx
    335c:	74 0b                	je     0x3369
    335e:	4b                   	dec    bx
    335f:	75 f6                	jne    0x3357
    3361:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
    3364:	aa                   	stos   BYTE PTR es:[di],al
    3365:	b3 03                	mov    bl,0x3
    3367:	eb ee                	jmp    0x3357
    3369:	0b d2                	or     dx,dx
    336b:	74 16                	je     0x3383
    336d:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3370:	aa                   	stos   BYTE PTR es:[di],al
    3371:	e3 09                	jcxz   0x337c
    3373:	b0 30                	mov    al,0x30
    3375:	aa                   	stos   BYTE PTR es:[di],al
    3376:	4a                   	dec    dx
    3377:	74 0a                	je     0x3383
    3379:	41                   	inc    cx
    337a:	75 f9                	jne    0x3375
    337c:	e8 d3 fe             	call   0x3252
    337f:	aa                   	stos   BYTE PTR es:[di],al
    3380:	4a                   	dec    dx
    3381:	75 f9                	jne    0x337c
    3383:	c3                   	ret
    3384:	8a 5e fc             	mov    bl,BYTE PTR [bp-0x4]
    3387:	b9 03 00             	mov    cx,0x3
    338a:	80 7e e6 00          	cmp    BYTE PTR [bp-0x1a],0x0
    338e:	74 06                	je     0x3396
    3390:	8a 5e fd             	mov    bl,BYTE PTR [bp-0x3]
    3393:	b9 0a 04             	mov    cx,0x40a
    3396:	3a d9                	cmp    bl,cl
    3398:	76 02                	jbe    0x339c
    339a:	8a d9                	mov    bl,cl
    339c:	02 dd                	add    bl,ch
    339e:	32 ff                	xor    bh,bh
    33a0:	d1 e3                	shl    bx,1
    33a2:	d1 e3                	shl    bx,1
    33a4:	b9 04 00             	mov    cx,0x4
    33a7:	2e 8a 87 dd 33       	mov    al,BYTE PTR cs:[bx+0x33dd]
    33ac:	3c 40                	cmp    al,0x40
    33ae:	74 1a                	je     0x33ca
    33b0:	51                   	push   cx
    33b1:	53                   	push   bx
    33b2:	3c 24                	cmp    al,0x24
    33b4:	74 07                	je     0x33bd
    33b6:	3c 2a                	cmp    al,0x2a
    33b8:	74 08                	je     0x33c2
    33ba:	aa                   	stos   BYTE PTR es:[di],al
    33bb:	eb 08                	jmp    0x33c5
    33bd:	e8 0b 00             	call   0x33cb
    33c0:	eb 03                	jmp    0x33c5
    33c2:	e8 69 ff             	call   0x332e
    33c5:	5b                   	pop    bx
    33c6:	59                   	pop    cx
    33c7:	43                   	inc    bx
    33c8:	e2 dd                	loop   0x33a7
    33ca:	c3                   	ret
    33cb:	1e                   	push   ds
    33cc:	56                   	push   si
    33cd:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    33d0:	be 58 2c             	mov    si,0x2c58
    33d3:	ac                   	lods   al,BYTE PTR ds:[si]
    33d4:	8a c8                	mov    cl,al
    33d6:	32 ed                	xor    ch,ch
    33d8:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    33da:	5e                   	pop    si
    33db:	1f                   	pop    ds
    33dc:	c3                   	ret
    33dd:	24 2a                	and    al,0x2a
    33df:	40                   	inc    ax
    33e0:	40                   	inc    ax
    33e1:	2a 24                	sub    ah,BYTE PTR [si]
    33e3:	40                   	inc    ax
    33e4:	40                   	inc    ax
    33e5:	24 20                	and    al,0x20
    33e7:	2a 40 2a             	sub    al,BYTE PTR [bx+si+0x2a]
    33ea:	20 24                	and    BYTE PTR [si],ah
    33ec:	40                   	inc    ax
    33ed:	28 24                	sub    BYTE PTR [si],ah
    33ef:	2a 29                	sub    ch,BYTE PTR [bx+di]
    33f1:	2d 24 2a             	sub    ax,0x2a24
    33f4:	40                   	inc    ax
    33f5:	24 2d                	and    al,0x2d
    33f7:	2a 40 24             	sub    al,BYTE PTR [bx+si+0x24]
    33fa:	2a 2d                	sub    ch,BYTE PTR [di]
    33fc:	40                   	inc    ax
    33fd:	28 2a                	sub    BYTE PTR [bp+si],ch
    33ff:	24 29                	and    al,0x29
    3401:	2d 2a 24             	sub    ax,0x242a
    3404:	40                   	inc    ax
    3405:	2a 2d                	sub    ch,BYTE PTR [di]
    3407:	24 40                	and    al,0x40
    3409:	2a 24                	sub    ah,BYTE PTR [si]
    340b:	2d 40 2d             	sub    ax,0x2d40
    340e:	2a 20                	sub    ah,BYTE PTR [bx+si]
    3410:	24 2d                	and    al,0x2d
    3412:	24 20                	and    al,0x20
    3414:	2a 24                	sub    ah,BYTE PTR [si]
    3416:	20 2a                	and    BYTE PTR [bp+si],ch
    3418:	2d 55 8b             	sub    ax,0x8b55
    341b:	ec                   	in     al,dx
    341c:	83 ec 28             	sub    sp,0x28
    341f:	fc                   	cld
    3420:	a1 62 2c             	mov    ax,ds:0x2c62
    3423:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3426:	b9 02 00             	mov    cx,0x2
    3429:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    342c:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    342f:	0b 46 0e             	or     ax,WORD PTR [bp+0xe]
    3432:	0b 46 10             	or     ax,WORD PTR [bp+0x10]
    3435:	0b 46 12             	or     ax,WORD PTR [bp+0x12]
    3438:	74 06                	je     0x3440
    343a:	8b 4e 12             	mov    cx,WORD PTR [bp+0x12]
    343d:	c1 e9 0f             	shr    cx,0xf
    3440:	e8 8e 00             	call   0x34d1
    3443:	74 4c                	je     0x3491
    3445:	89 76 fa             	mov    WORD PTR [bp-0x6],si
    3448:	e8 c3 00             	call   0x350e
    344b:	8d 46 d8             	lea    ax,[bp-0x28]
    344e:	16                   	push   ss
    344f:	50                   	push   ax
    3450:	ff 76 12             	push   WORD PTR [bp+0x12]
    3453:	ff 76 10             	push   WORD PTR [bp+0x10]
    3456:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3459:	ff 76 0c             	push   WORD PTR [bp+0xc]
    345c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    345f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3462:	ba 0f 27             	mov    dx,0x270f
    3465:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    3469:	75 08                	jne    0x3473
    346b:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    346e:	8b d0                	mov    dx,ax
    3470:	b8 12 00             	mov    ax,0x12
    3473:	50                   	push   ax
    3474:	52                   	push   dx
    3475:	0e                   	push   cs
    3476:	e8 51 02             	call   0x36ca
    3479:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    347c:	3d 00 80             	cmp    ax,0x8000
    347f:	74 10                	je     0x3491
    3481:	3d ff 7f             	cmp    ax,0x7fff
    3484:	74 0b                	je     0x3491
    3486:	3d 12 00             	cmp    ax,0x12
    3489:	7e 27                	jle    0x34b2
    348b:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    348f:	75 21                	jne    0x34b2
    3491:	ff 76 16             	push   WORD PTR [bp+0x16]
    3494:	ff 76 14             	push   WORD PTR [bp+0x14]
    3497:	ff 76 12             	push   WORD PTR [bp+0x12]
    349a:	ff 76 10             	push   WORD PTR [bp+0x10]
    349d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    34a0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    34a3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    34a6:	6a 00                	push   0x0
    34a8:	6a 0f                	push   0xf
    34aa:	6a 00                	push   0x0
    34ac:	0e                   	push   cs
    34ad:	e8 f0 fc             	call   0x31a0
    34b0:	eb 19                	jmp    0x34cb
    34b2:	80 7e db 00          	cmp    BYTE PTR [bp-0x25],0x0
    34b6:	75 10                	jne    0x34c8
    34b8:	b9 02 00             	mov    cx,0x2
    34bb:	e8 13 00             	call   0x34d1
    34be:	74 d1                	je     0x3491
    34c0:	3b 76 fa             	cmp    si,WORD PTR [bp-0x6]
    34c3:	74 03                	je     0x34c8
    34c5:	e8 46 00             	call   0x350e
    34c8:	e8 ea 00             	call   0x35b5
    34cb:	8b e5                	mov    sp,bp
    34cd:	5d                   	pop    bp
    34ce:	ca 12 00             	retf   0x12
    34d1:	1e                   	push   ds
    34d2:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    34d5:	e3 1d                	jcxz   0x34f4
    34d7:	ac                   	lods   al,BYTE PTR ds:[si]
    34d8:	3c 27                	cmp    al,0x27
    34da:	74 25                	je     0x3501
    34dc:	3c 22                	cmp    al,0x22
    34de:	74 21                	je     0x3501
    34e0:	0a c0                	or     al,al
    34e2:	74 10                	je     0x34f4
    34e4:	3c 3b                	cmp    al,0x3b
    34e6:	75 ef                	jne    0x34d7
    34e8:	e2 ed                	loop   0x34d7
    34ea:	8a 04                	mov    al,BYTE PTR [si]
    34ec:	0a c0                	or     al,al
    34ee:	74 04                	je     0x34f4
    34f0:	3c 3b                	cmp    al,0x3b
    34f2:	75 0b                	jne    0x34ff
    34f4:	8b 76 06             	mov    si,WORD PTR [bp+0x6]
    34f7:	8a 04                	mov    al,BYTE PTR [si]
    34f9:	0a c0                	or     al,al
    34fb:	74 02                	je     0x34ff
    34fd:	3c 3b                	cmp    al,0x3b
    34ff:	1f                   	pop    ds
    3500:	c3                   	ret
    3501:	8a e0                	mov    ah,al
    3503:	ac                   	lods   al,BYTE PTR ds:[si]
    3504:	3a c4                	cmp    al,ah
    3506:	74 cf                	je     0x34d7
    3508:	0a c0                	or     al,al
    350a:	75 f7                	jne    0x3503
    350c:	eb e6                	jmp    0x34f4
    350e:	1e                   	push   ds
    350f:	8e 5e 08             	mov    ds,WORD PTR [bp+0x8]
    3512:	89 76 fa             	mov    WORD PTR [bp-0x6],si
    3515:	bb ff 7f             	mov    bx,0x7fff
    3518:	33 c9                	xor    cx,cx
    351a:	33 d2                	xor    dx,dx
    351c:	c7 46 f6 ff ff       	mov    WORD PTR [bp-0xa],0xffff
    3521:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3524:	ac                   	lods   al,BYTE PTR ds:[si]
    3525:	3c 23                	cmp    al,0x23
    3527:	74 26                	je     0x354f
    3529:	3c 30                	cmp    al,0x30
    352b:	74 25                	je     0x3552
    352d:	3c 2e                	cmp    al,0x2e
    352f:	74 2c                	je     0x355d
    3531:	3c 2c                	cmp    al,0x2c
    3533:	74 33                	je     0x3568
    3535:	3c 27                	cmp    al,0x27
    3537:	74 35                	je     0x356e
    3539:	3c 22                	cmp    al,0x22
    353b:	74 31                	je     0x356e
    353d:	3c 45                	cmp    al,0x45
    353f:	74 3a                	je     0x357b
    3541:	3c 65                	cmp    al,0x65
    3543:	74 36                	je     0x357b
    3545:	3c 3b                	cmp    al,0x3b
    3547:	74 46                	je     0x358f
    3549:	0a c0                	or     al,al
    354b:	75 d7                	jne    0x3524
    354d:	eb 40                	jmp    0x358f
    354f:	42                   	inc    dx
    3550:	eb d2                	jmp    0x3524
    3552:	3b d3                	cmp    dx,bx
    3554:	7d 02                	jge    0x3558
    3556:	8b da                	mov    bx,dx
    3558:	42                   	inc    dx
    3559:	8b ca                	mov    cx,dx
    355b:	eb c7                	jmp    0x3524
    355d:	83 7e f6 ff          	cmp    WORD PTR [bp-0xa],0xffff
    3561:	75 c1                	jne    0x3524
    3563:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3566:	eb bc                	jmp    0x3524
    3568:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    356c:	eb b6                	jmp    0x3524
    356e:	8a e0                	mov    ah,al
    3570:	ac                   	lods   al,BYTE PTR ds:[si]
    3571:	3a c4                	cmp    al,ah
    3573:	74 af                	je     0x3524
    3575:	0a c0                	or     al,al
    3577:	75 f7                	jne    0x3570
    3579:	eb 14                	jmp    0x358f
    357b:	ac                   	lods   al,BYTE PTR ds:[si]
    357c:	3c 2d                	cmp    al,0x2d
    357e:	74 04                	je     0x3584
    3580:	3c 2b                	cmp    al,0x2b
    3582:	75 a1                	jne    0x3525
    3584:	c6 46 fe 01          	mov    BYTE PTR [bp-0x2],0x1
    3588:	ac                   	lods   al,BYTE PTR ds:[si]
    3589:	3c 30                	cmp    al,0x30
    358b:	74 fb                	je     0x3588
    358d:	eb 96                	jmp    0x3525
    358f:	1f                   	pop    ds
    3590:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3593:	83 7e f6 ff          	cmp    WORD PTR [bp-0xa],0xffff
    3597:	75 03                	jne    0x359c
    3599:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    359c:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    359f:	2b c1                	sub    ax,cx
    35a1:	7e 02                	jle    0x35a5
    35a3:	33 c0                	xor    ax,ax
    35a5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    35a8:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    35ab:	2b c3                	sub    ax,bx
    35ad:	7d 02                	jge    0x35b1
    35af:	33 c0                	xor    ax,ax
    35b1:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    35b4:	c3                   	ret
    35b5:	1e                   	push   ds
    35b6:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    35ba:	74 07                	je     0x35c3
    35bc:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    35bf:	33 d2                	xor    dx,dx
    35c1:	eb 11                	jmp    0x35d4
    35c3:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    35c6:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    35c9:	7f 03                	jg     0x35ce
    35cb:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    35ce:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    35d1:	2b 56 f6             	sub    dx,WORD PTR [bp-0xa]
    35d4:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    35d7:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    35da:	8e 5e 08             	mov    ds,WORD PTR [bp+0x8]
    35dd:	8b 76 fa             	mov    si,WORD PTR [bp-0x6]
    35e0:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    35e3:	8d 5e db             	lea    bx,[bp-0x25]
    35e6:	80 7e da 00          	cmp    BYTE PTR [bp-0x26],0x0
    35ea:	74 08                	je     0x35f4
    35ec:	3b 76 06             	cmp    si,WORD PTR [bp+0x6]
    35ef:	75 03                	jne    0x35f4
    35f1:	b0 2d                	mov    al,0x2d
    35f3:	aa                   	stos   BYTE PTR es:[di],al
    35f4:	ac                   	lods   al,BYTE PTR ds:[si]
    35f5:	3c 23                	cmp    al,0x23
    35f7:	74 27                	je     0x3620
    35f9:	3c 30                	cmp    al,0x30
    35fb:	74 23                	je     0x3620
    35fd:	3c 2e                	cmp    al,0x2e
    35ff:	74 f3                	je     0x35f4
    3601:	3c 2c                	cmp    al,0x2c
    3603:	74 ef                	je     0x35f4
    3605:	3c 27                	cmp    al,0x27
    3607:	74 1c                	je     0x3625
    3609:	3c 22                	cmp    al,0x22
    360b:	74 18                	je     0x3625
    360d:	3c 45                	cmp    al,0x45
    360f:	74 22                	je     0x3633
    3611:	3c 65                	cmp    al,0x65
    3613:	74 1e                	je     0x3633
    3615:	3c 3b                	cmp    al,0x3b
    3617:	74 4a                	je     0x3663
    3619:	0a c0                	or     al,al
    361b:	74 46                	je     0x3663
    361d:	aa                   	stos   BYTE PTR es:[di],al
    361e:	eb d4                	jmp    0x35f4
    3620:	e8 47 00             	call   0x366a
    3623:	eb cf                	jmp    0x35f4
    3625:	8a e0                	mov    ah,al
    3627:	ac                   	lods   al,BYTE PTR ds:[si]
    3628:	3a c4                	cmp    al,ah
    362a:	74 c8                	je     0x35f4
    362c:	0a c0                	or     al,al
    362e:	74 33                	je     0x3663
    3630:	aa                   	stos   BYTE PTR es:[di],al
    3631:	eb f4                	jmp    0x3627
    3633:	8a 24                	mov    ah,BYTE PTR [si]
    3635:	80 fc 2b             	cmp    ah,0x2b
    3638:	74 07                	je     0x3641
    363a:	80 fc 2d             	cmp    ah,0x2d
    363d:	75 de                	jne    0x361d
    363f:	32 e4                	xor    ah,ah
    3641:	b9 ff ff             	mov    cx,0xffff
    3644:	41                   	inc    cx
    3645:	46                   	inc    si
    3646:	80 3c 30             	cmp    BYTE PTR [si],0x30
    3649:	74 f9                	je     0x3644
    364b:	83 f9 04             	cmp    cx,0x4
    364e:	72 03                	jb     0x3653
    3650:	b9 04 00             	mov    cx,0x4
    3653:	53                   	push   bx
    3654:	8a 5e db             	mov    bl,BYTE PTR [bp-0x25]
    3657:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    365a:	2b 56 f6             	sub    dx,WORD PTR [bp-0xa]
    365d:	e8 87 fc             	call   0x32e7
    3660:	5b                   	pop    bx
    3661:	eb 91                	jmp    0x35f4
    3663:	1f                   	pop    ds
    3664:	8b c7                	mov    ax,di
    3666:	2b 46 14             	sub    ax,WORD PTR [bp+0x14]
    3669:	c3                   	ret
    366a:	83 7e ee 00          	cmp    WORD PTR [bp-0x12],0x0
    366e:	74 19                	je     0x3689
    3670:	7c 0a                	jl     0x367c
    3672:	e8 14 00             	call   0x3689
    3675:	ff 4e ee             	dec    WORD PTR [bp-0x12]
    3678:	75 f8                	jne    0x3672
    367a:	eb 0d                	jmp    0x3689
    367c:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    367f:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    3682:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    3685:	7e 13                	jle    0x369a
    3687:	eb 3d                	jmp    0x36c6
    3689:	36 8a 07             	mov    al,BYTE PTR ss:[bx]
    368c:	43                   	inc    bx
    368d:	0a c0                	or     al,al
    368f:	75 0b                	jne    0x369c
    3691:	4b                   	dec    bx
    3692:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    3695:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    3698:	7e 2c                	jle    0x36c6
    369a:	b0 30                	mov    al,0x30
    369c:	83 7e f0 00          	cmp    WORD PTR [bp-0x10],0x0
    36a0:	75 08                	jne    0x36aa
    36a2:	8a e0                	mov    ah,al
    36a4:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    36a7:	ab                   	stos   WORD PTR es:[di],ax
    36a8:	eb 1c                	jmp    0x36c6
    36aa:	aa                   	stos   BYTE PTR es:[di],al
    36ab:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    36af:	74 15                	je     0x36c6
    36b1:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    36b4:	3d 01 00             	cmp    ax,0x1
    36b7:	7e 0d                	jle    0x36c6
    36b9:	b2 03                	mov    dl,0x3
    36bb:	f6 f2                	div    dl
    36bd:	80 fc 01             	cmp    ah,0x1
    36c0:	75 04                	jne    0x36c6
    36c2:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    36c5:	aa                   	stos   BYTE PTR es:[di],al
    36c6:	ff 4e f0             	dec    WORD PTR [bp-0x10]
    36c9:	c3                   	ret
    36ca:	55                   	push   bp
    36cb:	8b ec                	mov    bp,sp
    36cd:	83 ec 12             	sub    sp,0x12
    36d0:	9b d9 7e fe          	fstcw  WORD PTR [bp-0x2]
    36d4:	9b 2e d9 2e 98 31    	fldcw  WORD PTR cs:0x3198
    36da:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    36dd:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    36e0:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    36e3:	8b d0                	mov    dx,ax
    36e5:	25 ff 7f             	and    ax,0x7fff
    36e8:	74 0d                	je     0x36f7
    36ea:	3d ff 7f             	cmp    ax,0x7fff
    36ed:	75 12                	jne    0x3701
    36ef:	81 7e 10 00 80       	cmp    WORD PTR [bp+0x10],0x8000
    36f4:	74 03                	je     0x36f9
    36f6:	40                   	inc    ax
    36f7:	33 d2                	xor    dx,dx
    36f9:	26 c6 45 03 00       	mov    BYTE PTR es:[di+0x3],0x0
    36fe:	e9 cc 00             	jmp    0x37cd
    3701:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    3704:	9b db 6e 0a          	fld    TBYTE PTR [bp+0xa]
    3708:	2d ff 3f             	sub    ax,0x3fff
    370b:	ba 10 4d             	mov    dx,0x4d10
    370e:	f7 ea                	imul   dx
    3710:	42                   	inc    dx
    3711:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3714:	b8 12 00             	mov    ax,0x12
    3717:	2b c2                	sub    ax,dx
    3719:	e8 b9 01             	call   0x38d5
    371c:	9b d9 fc             	frndint
    371f:	9b 2e db 2e 84 31    	fld    TBYTE PTR cs:0x3184
    3725:	9b d8 d9             	fcomp  st(1)
    3728:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    372c:	90                   	nop
    372d:	9b                   	fwait
    372e:	f7 46 fc 00 41       	test   WORD PTR [bp-0x4],0x4100
    3733:	74 09                	je     0x373e
    3735:	9b 2e da 36 04 31    	fidiv  DWORD PTR cs:0x3104
    373b:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    373e:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    3741:	83 c7 03             	add    di,0x3
    3744:	2e 80 3e 51 37 cd    	cmp    BYTE PTR cs:0x3751,0xcd
    374a:	75 05                	jne    0x3751
    374c:	e8 ee 01             	call   0x393d
    374f:	eb 1f                	jmp    0x3770
    3751:	9b df 76 ee          	fbstp  TBYTE PTR [bp-0x12]
    3755:	b1 04                	mov    cl,0x4
    3757:	be 09 00             	mov    si,0x9
    375a:	90                   	nop
    375b:	9b                   	fwait
    375c:	8a 42 ed             	mov    al,BYTE PTR [bp+si-0x13]
    375f:	8a e0                	mov    ah,al
    3761:	d2 e8                	shr    al,cl
    3763:	80 e4 0f             	and    ah,0xf
    3766:	05 30 30             	add    ax,0x3030
    3769:	ab                   	stos   WORD PTR es:[di],ax
    376a:	4e                   	dec    si
    376b:	75 ef                	jne    0x375c
    376d:	32 c0                	xor    al,al
    376f:	aa                   	stos   BYTE PTR es:[di],al
    3770:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    3773:	8b 5e 06             	mov    bx,WORD PTR [bp+0x6]
    3776:	03 5e fa             	add    bx,WORD PTR [bp-0x6]
    3779:	79 05                	jns    0x3780
    377b:	33 c0                	xor    ax,ax
    377d:	e9 77 ff             	jmp    0x36f7
    3780:	3b 5e 08             	cmp    bx,WORD PTR [bp+0x8]
    3783:	72 03                	jb     0x3788
    3785:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    3788:	83 fb 12             	cmp    bx,0x12
    378b:	73 28                	jae    0x37b5
    378d:	26 80 79 03 35       	cmp    BYTE PTR es:[bx+di+0x3],0x35
    3792:	72 24                	jb     0x37b8
    3794:	26 c6 41 03 00       	mov    BYTE PTR es:[bx+di+0x3],0x0
    3799:	4b                   	dec    bx
    379a:	78 0d                	js     0x37a9
    379c:	26 fe 41 03          	inc    BYTE PTR es:[bx+di+0x3]
    37a0:	26 80 79 03 39       	cmp    BYTE PTR es:[bx+di+0x3],0x39
    37a5:	77 ed                	ja     0x3794
    37a7:	eb 1e                	jmp    0x37c7
    37a9:	26 c7 45 03 31 00    	mov    WORD PTR es:[di+0x3],0x31
    37af:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    37b2:	eb 13                	jmp    0x37c7
    37b4:	90                   	nop
    37b5:	bb 12 00             	mov    bx,0x12
    37b8:	26 c6 41 03 00       	mov    BYTE PTR es:[bx+di+0x3],0x0
    37bd:	4b                   	dec    bx
    37be:	78 bb                	js     0x377b
    37c0:	26 80 79 03 30       	cmp    BYTE PTR es:[bx+di+0x3],0x30
    37c5:	74 f1                	je     0x37b8
    37c7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    37ca:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    37cd:	26 89 05             	mov    WORD PTR es:[di],ax
    37d0:	33 c0                	xor    ax,ax
    37d2:	03 d2                	add    dx,dx
    37d4:	13 c0                	adc    ax,ax
    37d6:	26 88 45 02          	mov    BYTE PTR es:[di+0x2],al
    37da:	9b db e2             	fclex
    37dd:	9b d9 6e fe          	fldcw  WORD PTR [bp-0x2]
    37e1:	90                   	nop
    37e2:	9b                   	fwait
    37e3:	8b e5                	mov    sp,bp
    37e5:	5d                   	pop    bp
    37e6:	ca 12 00             	retf   0x12
    37e9:	55                   	push   bp
    37ea:	8b ec                	mov    bp,sp
    37ec:	83 ec 10             	sub    sp,0x10
    37ef:	9b d9 7e fe          	fstcw  WORD PTR [bp-0x2]
    37f3:	9b db e2             	fclex
    37f6:	9b 2e d9 2e 98 31    	fldcw  WORD PTR cs:0x3198
    37fc:	9b d9 ee             	fldz
    37ff:	1e                   	push   ds
    3800:	8a 0e 63 2c          	mov    cl,BYTE PTR ds:0x2c63
    3804:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    3807:	fc                   	cld
    3808:	e8 77 00             	call   0x3882
    380b:	8a 04                	mov    al,BYTE PTR [si]
    380d:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
    3810:	3c 2b                	cmp    al,0x2b
    3812:	74 04                	je     0x3818
    3814:	3c 2d                	cmp    al,0x2d
    3816:	75 01                	jne    0x3819
    3818:	46                   	inc    si
    3819:	8b d6                	mov    dx,si
    381b:	e8 6b 00             	call   0x3889
    381e:	33 db                	xor    bx,bx
    3820:	3a 0c                	cmp    cl,BYTE PTR [si]
    3822:	75 06                	jne    0x382a
    3824:	46                   	inc    si
    3825:	e8 61 00             	call   0x3889
    3828:	f7 db                	neg    bx
    382a:	3b f2                	cmp    si,dx
    382c:	74 33                	je     0x3861
    382e:	8a 04                	mov    al,BYTE PTR [si]
    3830:	24 df                	and    al,0xdf
    3832:	3c 45                	cmp    al,0x45
    3834:	75 08                	jne    0x383e
    3836:	46                   	inc    si
    3837:	53                   	push   bx
    3838:	e8 6a 00             	call   0x38a5
    383b:	5b                   	pop    bx
    383c:	03 d8                	add    bx,ax
    383e:	e8 41 00             	call   0x3882
    3841:	80 3c 00             	cmp    BYTE PTR [si],0x0
    3844:	75 1b                	jne    0x3861
    3846:	8b c3                	mov    ax,bx
    3848:	e8 8a 00             	call   0x38d5
    384b:	80 7e fa 2d          	cmp    BYTE PTR [bp-0x6],0x2d
    384f:	75 03                	jne    0x3854
    3851:	9b d9 e0             	fchs
    3854:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    3858:	90                   	nop
    3859:	9b                   	fwait
    385a:	f7 46 fc 09 00       	test   WORD PTR [bp-0x4],0x9
    385f:	74 08                	je     0x3869
    3861:	9b db 7e f0          	fstp   TBYTE PTR [bp-0x10]
    3865:	33 c0                	xor    ax,ax
    3867:	eb 09                	jmp    0x3872
    3869:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    386c:	9b 26 db 3d          	fstp   TBYTE PTR es:[di]
    3870:	b0 01                	mov    al,0x1
    3872:	1f                   	pop    ds
    3873:	9b db e2             	fclex
    3876:	9b d9 6e fe          	fldcw  WORD PTR [bp-0x2]
    387a:	90                   	nop
    387b:	9b                   	fwait
    387c:	8b e5                	mov    sp,bp
    387e:	5d                   	pop    bp
    387f:	ca 08 00             	retf   0x8
    3882:	ac                   	lods   al,BYTE PTR ds:[si]
    3883:	3c 20                	cmp    al,0x20
    3885:	74 fb                	je     0x3882
    3887:	4e                   	dec    si
    3888:	c3                   	ret
    3889:	33 db                	xor    bx,bx
    388b:	ac                   	lods   al,BYTE PTR ds:[si]
    388c:	2c 3a                	sub    al,0x3a
    388e:	04 0a                	add    al,0xa
    3890:	73 11                	jae    0x38a3
    3892:	9b 2e da 0e 04 31    	fimul  DWORD PTR cs:0x3104
    3898:	98                   	cbw
    3899:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    389c:	9b de 46 fc          	fiadd  WORD PTR [bp-0x4]
    38a0:	43                   	inc    bx
    38a1:	eb e8                	jmp    0x388b
    38a3:	4e                   	dec    si
    38a4:	c3                   	ret
    38a5:	33 c0                	xor    ax,ax
    38a7:	8a 1c                	mov    bl,BYTE PTR [si]
    38a9:	80 fb 2b             	cmp    bl,0x2b
    38ac:	74 05                	je     0x38b3
    38ae:	80 fb 2d             	cmp    bl,0x2d
    38b1:	75 01                	jne    0x38b4
    38b3:	46                   	inc    si
    38b4:	8a 0c                	mov    cl,BYTE PTR [si]
    38b6:	80 e9 3a             	sub    cl,0x3a
    38b9:	80 c1 0a             	add    cl,0xa
    38bc:	73 0f                	jae    0x38cd
    38be:	ba 0a 00             	mov    dx,0xa
    38c1:	f7 e2                	mul    dx
    38c3:	32 ed                	xor    ch,ch
    38c5:	03 c1                	add    ax,cx
    38c7:	46                   	inc    si
    38c8:	3d f4 01             	cmp    ax,0x1f4
    38cb:	72 e7                	jb     0x38b4
    38cd:	80 fb 2d             	cmp    bl,0x2d
    38d0:	75 02                	jne    0x38d4
    38d2:	f7 d8                	neg    ax
    38d4:	c3                   	ret
    38d5:	3d 00 10             	cmp    ax,0x1000
    38d8:	7e 0c                	jle    0x38e6
    38da:	9b 2e db 2e 7a 31    	fld    TBYTE PTR cs:0x317a
    38e0:	9b de c9             	fmulp  st(1),st
    38e3:	2d 00 10             	sub    ax,0x1000
    38e6:	3d 00 f0             	cmp    ax,0xf000
    38e9:	7d 0e                	jge    0x38f9
    38eb:	9b 2e db 2e 7a 31    	fld    TBYTE PTR cs:0x317a
    38f1:	9a b2 04 3a 39       	call   0x393a:0x4b2
    38f6:	05 00 10             	add    ax,0x1000
    38f9:	8b d8                	mov    bx,ax
    38fb:	0b c0                	or     ax,ax
    38fd:	74 3d                	je     0x393c
    38ff:	79 02                	jns    0x3903
    3901:	f7 d8                	neg    ax
    3903:	8b f0                	mov    si,ax
    3905:	83 e6 07             	and    si,0x7
    3908:	d1 e6                	shl    si,1
    390a:	d1 e6                	shl    si,1
    390c:	9b 2e db 84 00 31    	fild   DWORD PTR cs:[si+0x3100]
    3912:	d1 e8                	shr    ax,1
    3914:	d1 e8                	shr    ax,1
    3916:	d1 e8                	shr    ax,1
    3918:	be 20 31             	mov    si,0x3120
    391b:	eb 0e                	jmp    0x392b
    391d:	d1 e8                	shr    ax,1
    391f:	73 07                	jae    0x3928
    3921:	9b 2e db 2c          	fld    TBYTE PTR cs:[si]
    3925:	9b de c9             	fmulp  st(1),st
    3928:	83 c6 0a             	add    si,0xa
    392b:	0b c0                	or     ax,ax
    392d:	75 ee                	jne    0x391d
    392f:	0b db                	or     bx,bx
    3931:	78 04                	js     0x3937
    3933:	9b de c9             	fmulp  st(1),st
    3936:	c3                   	ret
    3937:	9a b2 04 ff ff       	call   0xffff:0x4b2
    393c:	c3                   	ret
    393d:	26 c6 45 12 00       	mov    BYTE PTR es:[di+0x12],0x0
    3942:	83 c7 10             	add    di,0x10
    3945:	fd                   	std
    3946:	83 ec 08             	sub    sp,0x8
    3949:	8b f4                	mov    si,sp
    394b:	9b 36 df 3c          	fistp  QWORD PTR ss:[si]
    394f:	90                   	nop
    3950:	9b                   	fwait
    3951:	5b                   	pop    bx
    3952:	59                   	pop    cx
    3953:	58                   	pop    ax
    3954:	5a                   	pop    dx
    3955:	be 10 27             	mov    si,0x2710
    3958:	f7 f6                	div    si
    395a:	91                   	xchg   cx,ax
    395b:	f7 f6                	div    si
    395d:	93                   	xchg   bx,ax
    395e:	f7 f6                	div    si
    3960:	e8 2a 00             	call   0x398d
    3963:	33 d2                	xor    dx,dx
    3965:	91                   	xchg   cx,ax
    3966:	f7 f6                	div    si
    3968:	93                   	xchg   bx,ax
    3969:	f7 f6                	div    si
    396b:	91                   	xchg   cx,ax
    396c:	f7 f6                	div    si
    396e:	e8 1c 00             	call   0x398d
    3971:	8b d3                	mov    dx,bx
    3973:	91                   	xchg   cx,ax
    3974:	f7 f6                	div    si
    3976:	91                   	xchg   cx,ax
    3977:	f7 f6                	div    si
    3979:	e8 11 00             	call   0x398d
    397c:	8b d1                	mov    dx,cx
    397e:	f7 f6                	div    si
    3980:	e8 0a 00             	call   0x398d
    3983:	d4 0a                	aam    0xa
    3985:	86 c4                	xchg   ah,al
    3987:	05 30 30             	add    ax,0x3030
    398a:	ab                   	stos   WORD PTR es:[di],ax
    398b:	fc                   	cld
    398c:	c3                   	ret
    398d:	50                   	push   ax
    398e:	b0 64                	mov    al,0x64
    3990:	92                   	xchg   dx,ax
    3991:	f6 f2                	div    dl
    3993:	8a d4                	mov    dl,ah
    3995:	d4 0a                	aam    0xa
    3997:	05 30 30             	add    ax,0x3030
    399a:	86 c4                	xchg   ah,al
    399c:	92                   	xchg   dx,ax
    399d:	d4 0a                	aam    0xa
    399f:	05 30 30             	add    ax,0x3030
    39a2:	86 c4                	xchg   ah,al
    39a4:	ab                   	stos   WORD PTR es:[di],ax
    39a5:	92                   	xchg   dx,ax
    39a6:	ab                   	stos   WORD PTR es:[di],ax
    39a7:	58                   	pop    ax
    39a8:	c3                   	ret
