; ================================================================
; seg07_CODE  (25163 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	07                   	pop    es
       1:	00 10                	add    BYTE PTR [bx+si],dl
       3:	07                   	pop    es
       4:	42                   	inc    dx
       5:	02 af 00 00          	add    ch,BYTE PTR [bx+0x0]
       9:	00 9e 00 95          	add    BYTE PTR [bp-0x6b00],bl
       d:	0b fb                	or     di,bx
       f:	04 28                	add    al,0x28
      11:	07                   	pop    es
      12:	39 3f                	cmp    WORD PTR [bx],di
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 3b 07 cb       	call   0xcb07:0x3b1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 db                	adc    bl,bl
      2d:	1f                   	pop    ds
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c e3                	sbb    al,0xe3
      61:	07                   	pop    es
      62:	e2 2f                	loop   0x93
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	10 54 46             	adc    BYTE PTR [si+0x46],dl
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	45                   	inc    bp
      a8:	5f                   	pop    di
      a9:	45                   	inc    bp
      aa:	74 75                	je     0x121
      ac:	64 65 73 15          	fs gs jae 0xc5
      b0:	00 99 24 c2          	add    BYTE PTR [bx+di-0x3ddc],bl
      b4:	00 0a                	add    BYTE PTR [bp+si],cl
      b6:	46                   	inc    si
      b7:	6f                   	outs   dx,WORD PTR ds:[si]
      b8:	72 6d                	jb     0x127
      ba:	43                   	inc    bx
      bb:	72 65                	jb     0x122
      bd:	61                   	popa
      be:	74 65                	je     0x125
      c0:	78 29                	js     0xeb
      c2:	dc 00                	fadd   QWORD PTR [bx+si]
      c4:	15 53 74             	adc    ax,0x7453
      c7:	72 69                	jb     0x132
      c9:	6e                   	outs   dx,BYTE PTR ds:[si]
      ca:	67 47                	addr32 inc di
      cc:	72 69                	jb     0x137
      ce:	64 31 53 65          	xor    WORD PTR fs:[bp+di+0x65],dx
      d2:	6c                   	ins    BYTE PTR es:[di],dx
      d3:	65 63 74 43          	arpl   WORD PTR gs:[si+0x43],si
      d7:	65 6c                	gs ins BYTE PTR es:[di],dx
      d9:	6c                   	ins    BYTE PTR es:[di],dx
      da:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
      db:	29 f4                	sub    sp,si
      dd:	00 13                	add    BYTE PTR [bp+di],dl
      df:	53                   	push   bx
      e0:	74 72                	je     0x154
      e2:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
      e7:	69 64 31 44 72       	imul   sp,WORD PTR [si+0x31],0x7244
      ec:	61                   	popa
      ed:	77 43                	ja     0x132
      ef:	65 6c                	gs ins BYTE PTR es:[di],dx
      f1:	6c                   	ins    BYTE PTR es:[di],dx
      f2:	66 34 03             	data32 xor al,0x3
      f5:	01 0a                	add    WORD PTR [bp+si],cx
      f7:	46                   	inc    si
      f8:	6f                   	outs   dx,WORD PTR ds:[si]
      f9:	72 6d                	jb     0x168
      fb:	52                   	push   dx
      fc:	65 73 69             	gs jae 0x168
      ff:	7a 65                	jp     0x166
     101:	b4 3b                	mov    ah,0x3b
     103:	18 01                	sbb    BYTE PTR [bx+di],al
     105:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
     108:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     10e:	61                   	popa
     10f:	6e                   	outs   dx,BYTE PTR ds:[si]
     110:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     113:	69 63 6b c1 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3ac1
     118:	2b 01                	sub    ax,WORD PTR [bx+di]
     11a:	0e                   	push   cs
     11b:	49                   	dec    cx
     11c:	6d                   	ins    WORD PTR es:[di],dx
     11d:	70 72                	jo     0x191
     11f:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     124:	43                   	inc    bx
     125:	6c                   	ins    BYTE PTR es:[di],dx
     126:	69 63 6b 9c 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3b9c
     12b:	3d 01 0d             	cmp    ax,0xd01
     12e:	51                   	push   cx
     12f:	75 69                	jne    0x19a
     131:	74 74                	je     0x1a7
     133:	65 72 31             	gs jb  0x167
     136:	43                   	inc    bx
     137:	6c                   	ins    BYTE PTR es:[di],dx
     138:	69 63 6b e4 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3be4
     13d:	4f                   	dec    di
     13e:	01 0d                	add    WORD PTR [di],cx
     140:	50                   	push   ax
     141:	65 72 69             	gs jb  0x1ad
     144:	6f                   	outs   dx,WORD PTR ds:[si]
     145:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     14a:	69 63 6b 23 52       	imul   sp,WORD PTR [bp+di+0x6b],0x5223
     14f:	5f                   	pop    di
     150:	01 0b                	add    WORD PTR [bp+di],cx
     152:	49                   	dec    cx
     153:	6e                   	outs   dx,BYTE PTR ds:[si]
     154:	64 65 78 31          	fs gs js 0x189
     158:	43                   	inc    bx
     159:	6c                   	ins    BYTE PTR es:[di],dx
     15a:	69 63 6b 42 52       	imul   sp,WORD PTR [bp+di+0x6b],0x5242
     15f:	74 01                	je     0x162
     161:	10 52 65             	adc    BYTE PTR [bp+si+0x65],dl
     164:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     167:	72 63                	jb     0x1cc
     169:	68 65 72             	push   0x7265
     16c:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     16f:	69 63 6b 63 52       	imul   sp,WORD PTR [bp+di+0x6b],0x5263
     174:	8c 01                	mov    WORD PTR [bx+di],es
     176:	13 55 74             	adc    dx,WORD PTR [di+0x74]
     179:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     17e:	72 6c                	jb     0x1ec
     180:	61                   	popa
     181:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     186:	6c                   	ins    BYTE PTR es:[di],dx
     187:	69 63 6b 82 52       	imul   sp,WORD PTR [bp+di+0x6b],0x5282
     18c:	9e                   	sahf
     18d:	01 0d                	add    WORD PTR [di],cx
     18f:	41                   	inc    cx
     190:	70 72                	jo     0x204
     192:	6f                   	outs   dx,WORD PTR ds:[si]
     193:	70 6f                	jo     0x204
     195:	73 31                	jae    0x1c8
     197:	43                   	inc    bx
     198:	6c                   	ins    BYTE PTR es:[di],dx
     199:	69 63 6b 29 3d       	imul   sp,WORD PTR [bp+di+0x6b],0x3d29
     19e:	ab                   	stos   WORD PTR es:[di],ax
     19f:	01 08                	add    WORD PTR [bx+si],cx
     1a1:	4e                   	dec    si
     1a2:	31 31                	xor    WORD PTR [bx+di],si
     1a4:	43                   	inc    bx
     1a5:	6c                   	ins    BYTE PTR es:[di],dx
     1a6:	69 63 6b 69 28       	imul   sp,WORD PTR [bp+di+0x6b],0x2869
     1ab:	b8 01 08             	mov    ax,0x801
     1ae:	46                   	inc    si
     1af:	6f                   	outs   dx,WORD PTR ds:[si]
     1b0:	72 6d                	jb     0x21f
     1b2:	53                   	push   bx
     1b3:	68 6f 77             	push   0x776f
     1b6:	2c 50                	sub    al,0x50
     1b8:	c8 01 0b 46          	enter  0xb01,0x46
     1bc:	6f                   	outs   dx,WORD PTR ds:[si]
     1bd:	72 6d                	jb     0x22c
     1bf:	4b                   	dec    bx
     1c0:	65 79 44             	gs jns 0x207
     1c3:	6f                   	outs   dx,WORD PTR ds:[si]
     1c4:	77 6e                	ja     0x234
     1c6:	1a 53 e1             	sbb    dl,BYTE PTR [bp+di-0x1f]
     1c9:	01 14                	add    WORD PTR [si],dx
     1cb:	53                   	push   bx
     1cc:	74 72                	je     0x240
     1ce:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     1d3:	69 64 31 4d 6f       	imul   sp,WORD PTR [si+0x31],0x6f4d
     1d8:	75 73                	jne    0x24d
     1da:	65 44                	gs inc sp
     1dc:	6f                   	outs   dx,WORD PTR ds:[si]
     1dd:	77 6e                	ja     0x24d
     1df:	f8                   	clc
     1e0:	51                   	push   cx
     1e1:	f1                   	int1
     1e2:	01 0b                	add    WORD PTR [bp+di],cx
     1e4:	46                   	inc    si
     1e5:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     1ea:	43                   	inc    bx
     1eb:	6c                   	ins    BYTE PTR es:[di],dx
     1ec:	69 63 6b 29 59       	imul   sp,WORD PTR [bp+di+0x6b],0x5929
     1f1:	02 02                	add    al,BYTE PTR [bp+si]
     1f3:	0c 43                	or     al,0x43
     1f5:	6f                   	outs   dx,WORD PTR ds:[si]
     1f6:	70 69                	jo     0x261
     1f8:	65 72 31             	gs jb  0x22c
     1fb:	43                   	inc    bx
     1fc:	6c                   	ins    BYTE PTR es:[di],dx
     1fd:	69 63 6b d1 53       	imul   sp,WORD PTR [bp+di+0x6b],0x53d1
     202:	1d 02 16             	sbb    ax,0x1602
     205:	49                   	dec    cx
     206:	6d                   	ins    WORD PTR es:[di],dx
     207:	70 72                	jo     0x27b
     209:	65 73 73             	gs jae 0x27f
     20c:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     211:	70 69                	jo     0x27c
     213:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     218:	69 63 6b 28 62       	imul   sp,WORD PTR [bp+di+0x6b],0x6228
     21d:	37                   	aaa
     21e:	02 15                	add    dl,BYTE PTR [di]
     220:	52                   	push   dx
     221:	61                   	popa
     222:	70 70                	jo     0x294
     224:	65 6c                	gs ins BYTE PTR es:[di],dx
     226:	64 65 63 69 73       	fs arpl WORD PTR gs:[bx+di+0x73],bp
     22b:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     230:	43                   	inc    bx
     231:	6c                   	ins    BYTE PTR es:[di],dx
     232:	69 63 6b 2b 3c       	imul   sp,WORD PTR [bp+di+0x6b],0x3c2b
     237:	24 07                	and    al,0x7
     239:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     23c:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     23f:	69 63 6b 67 00       	imul   sp,WORD PTR [bp+di+0x6b],0x67
     244:	ea 06 7c 01 00       	jmp    0x1:0x7c06
     249:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     24d:	6e                   	outs   dx,BYTE PTR ds:[si]
     24e:	65 6c                	gs ins BYTE PTR es:[di],dx
     250:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     254:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     258:	6e                   	outs   dx,BYTE PTR ds:[si]
     259:	65 6c                	gs ins BYTE PTR es:[di],dx
     25b:	31 84 01 04          	xor    WORD PTR [si+0x401],ax
     25f:	00 0b                	add    BYTE PTR [bp+di],cl
     261:	53                   	push   bx
     262:	74 72                	je     0x2d6
     264:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     269:	69 64 31 88 01       	imul   sp,WORD PTR [si+0x31],0x188
     26e:	08 00                	or     BYTE PTR [bx+si],al
     270:	0b 4c 69             	or     cx,WORD PTR [si+0x69]
     273:	73 74                	jae    0x2e9
     275:	42                   	inc    dx
     276:	6f                   	outs   dx,WORD PTR ds:[si]
     277:	78 31                	js     0x2aa
     279:	65 74 32             	gs je  0x2ae
     27c:	8c 01                	mov    WORD PTR [bx+di],es
     27e:	00 00                	add    BYTE PTR [bx+si],al
     280:	06                   	push   es
     281:	50                   	push   ax
     282:	61                   	popa
     283:	6e                   	outs   dx,BYTE PTR ds:[si]
     284:	65 6c                	gs ins BYTE PTR es:[di],dx
     286:	32 90 01 04          	xor    dl,BYTE PTR [bx+si+0x401]
     28a:	00 0b                	add    BYTE PTR [bp+di],cl
     28c:	53                   	push   bx
     28d:	74 72                	je     0x301
     28f:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     294:	69 64 32 94 01       	imul   sp,WORD PTR [si+0x32],0x194
     299:	00 00                	add    BYTE PTR [bx+si],al
     29b:	06                   	push   es
     29c:	50                   	push   ax
     29d:	61                   	popa
     29e:	6e                   	outs   dx,BYTE PTR ds:[si]
     29f:	65 6c                	gs ins BYTE PTR es:[di],dx
     2a1:	33 98 01 08          	xor    bx,WORD PTR [bx+si+0x801]
     2a5:	00 08                	add    BYTE PTR [bx+si],cl
     2a7:	4c                   	dec    sp
     2a8:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     2ad:	78 33                	js     0x2e2
     2af:	9c                   	pushf
     2b0:	01 04                	add    WORD PTR [si],ax
     2b2:	00 0b                	add    BYTE PTR [bp+di],cl
     2b4:	53                   	push   bx
     2b5:	74 72                	je     0x329
     2b7:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     2bc:	69 64 33 a0 01       	imul   sp,WORD PTR [si+0x33],0x1a0
     2c1:	00 00                	add    BYTE PTR [bx+si],al
     2c3:	06                   	push   es
     2c4:	50                   	push   ax
     2c5:	61                   	popa
     2c6:	6e                   	outs   dx,BYTE PTR ds:[si]
     2c7:	65 6c                	gs ins BYTE PTR es:[di],dx
     2c9:	34 a4                	xor    al,0xa4
     2cb:	01 08                	add    WORD PTR [bx+si],cx
     2cd:	00 08                	add    BYTE PTR [bx+si],cl
     2cf:	4c                   	dec    sp
     2d0:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     2d5:	78 34                	js     0x30b
     2d7:	a8 01                	test   al,0x1
     2d9:	04 00                	add    al,0x0
     2db:	0b 53 74             	or     dx,WORD PTR [bp+di+0x74]
     2de:	72 69                	jb     0x349
     2e0:	6e                   	outs   dx,BYTE PTR ds:[si]
     2e1:	67 47                	addr32 inc di
     2e3:	72 69                	jb     0x34e
     2e5:	64 34 ac             	fs xor al,0xac
     2e8:	01 00                	add    WORD PTR [bx+si],ax
     2ea:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     2ee:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ef:	65 6c                	gs ins BYTE PTR es:[di],dx
     2f1:	35 b0 01             	xor    ax,0x1b0
     2f4:	08 00                	or     BYTE PTR [bx+si],al
     2f6:	08 4c 69             	or     BYTE PTR [si+0x69],cl
     2f9:	73 74                	jae    0x36f
     2fb:	42                   	inc    dx
     2fc:	6f                   	outs   dx,WORD PTR ds:[si]
     2fd:	78 35                	js     0x334
     2ff:	b4 01                	mov    ah,0x1
     301:	04 00                	add    al,0x0
     303:	0b 53 74             	or     dx,WORD PTR [bp+di+0x74]
     306:	72 69                	jb     0x371
     308:	6e                   	outs   dx,BYTE PTR ds:[si]
     309:	67 47                	addr32 inc di
     30b:	72 69                	jb     0x376
     30d:	64 35 b8 01          	fs xor ax,0x1b8
     311:	00 00                	add    BYTE PTR [bx+si],al
     313:	06                   	push   es
     314:	50                   	push   ax
     315:	61                   	popa
     316:	6e                   	outs   dx,BYTE PTR ds:[si]
     317:	65 6c                	gs ins BYTE PTR es:[di],dx
     319:	36 bc 01 08          	ss mov sp,0x801
     31d:	00 08                	add    BYTE PTR [bx+si],cl
     31f:	4c                   	dec    sp
     320:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     325:	78 36                	js     0x35d
     327:	c0 01 04             	rol    BYTE PTR [bx+di],0x4
     32a:	00 0b                	add    BYTE PTR [bp+di],cl
     32c:	53                   	push   bx
     32d:	74 72                	je     0x3a1
     32f:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     334:	69 64 36 c4 01       	imul   sp,WORD PTR [si+0x36],0x1c4
     339:	00 00                	add    BYTE PTR [bx+si],al
     33b:	06                   	push   es
     33c:	50                   	push   ax
     33d:	61                   	popa
     33e:	6e                   	outs   dx,BYTE PTR ds:[si]
     33f:	65 6c                	gs ins BYTE PTR es:[di],dx
     341:	37                   	aaa
     342:	c8 01 04 00          	enter  0x401,0x0
     346:	0b 53 74             	or     dx,WORD PTR [bp+di+0x74]
     349:	72 69                	jb     0x3b4
     34b:	6e                   	outs   dx,BYTE PTR ds:[si]
     34c:	67 47                	addr32 inc di
     34e:	72 69                	jb     0x3b9
     350:	64 37                	fs aaa
     352:	cc                   	int3
     353:	01 08                	add    WORD PTR [bx+si],cx
     355:	00 08                	add    BYTE PTR [bx+si],cl
     357:	4c                   	dec    sp
     358:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     35d:	78 37                	js     0x396
     35f:	d0 01                	rol    BYTE PTR [bx+di],1
     361:	0c 00                	or     al,0x0
     363:	09 4d 61             	or     WORD PTR [di+0x61],cx
     366:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     36b:	75 31                	jne    0x39e
     36d:	d4 01                	aam    0x1
     36f:	10 00                	adc    BYTE PTR [bx+si],al
     371:	08 46 69             	or     BYTE PTR [bp+0x69],al
     374:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     377:	65 72 31             	gs jb  0x3ab
     37a:	d8 01                	fadd   DWORD PTR [bx+di]
     37c:	10 00                	adc    BYTE PTR [bx+si],al
     37e:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     381:	70 72                	jo     0x3f5
     383:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     388:	dc 01                	fadd   QWORD PTR [bx+di]
     38a:	10 00                	adc    BYTE PTR [bx+si],al
     38c:	02 4e 31             	add    cl,BYTE PTR [bp+0x31]
     38f:	e0 01                	loopne 0x392
     391:	10 00                	adc    BYTE PTR [bx+si],al
     393:	08 51 75             	or     BYTE PTR [bx+di+0x75],dl
     396:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
     39b:	31 e4                	xor    sp,sp
     39d:	01 10                	add    WORD PTR [bx+si],dx
     39f:	00 0a                	add    BYTE PTR [bp+si],cl
     3a1:	41                   	inc    cx
     3a2:	66 66 69 63 68 61 67 	data32 imul esp,DWORD PTR [bp+di+0x68],0x31656761
     3a9:	65 31 
     3ab:	e8 01 10             	call   0x13af
     3ae:	00 0d                	add    BYTE PTR [di],cl
     3b0:	42                   	inc    dx
     3b1:	61                   	popa
     3b2:	72 72                	jb     0x426
     3b4:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     3b7:	75 74                	jne    0x42d
     3b9:	69 6c 73 31 ec       	imul   bp,WORD PTR [si+0x73],0xec31
     3be:	01 10                	add    WORD PTR [bx+si],dx
     3c0:	00 0b                	add    BYTE PTR [bp+di],cl
     3c2:	50                   	push   ax
     3c3:	6c                   	ins    BYTE PTR es:[di],dx
     3c4:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     3ca:	61                   	popa
     3cb:	6e                   	outs   dx,BYTE PTR ds:[si]
     3cc:	31 f0                	xor    ax,si
     3ce:	01 10                	add    WORD PTR [bx+si],dx
     3d0:	00 02                	add    BYTE PTR [bp+si],al
     3d2:	4e                   	dec    si
     3d3:	32 f4                	xor    dh,ah
     3d5:	01 10                	add    WORD PTR [bx+si],dx
     3d7:	00 05                	add    BYTE PTR [di],al
     3d9:	5a                   	pop    dx
     3da:	6f                   	outs   dx,WORD PTR ds:[si]
     3db:	6f                   	outs   dx,WORD PTR ds:[si]
     3dc:	6d                   	ins    WORD PTR es:[di],dx
     3dd:	31 f8                	xor    ax,di
     3df:	01 10                	add    WORD PTR [bx+si],dx
     3e1:	00 08                	add    BYTE PTR [bx+si],cl
     3e3:	50                   	push   ax
     3e4:	65 72 69             	gs jb  0x450
     3e7:	6f                   	outs   dx,WORD PTR ds:[si]
     3e8:	64 65 31 fc          	fs gs xor sp,di
     3ec:	01 10                	add    WORD PTR [bx+si],dx
     3ee:	00 0b                	add    BYTE PTR [bp+di],cl
     3f0:	45                   	inc    bp
     3f1:	6e                   	outs   dx,BYTE PTR ds:[si]
     3f2:	74 72                	je     0x466
     3f4:	65 70 72             	gs jo  0x469
     3f7:	69 73 65 31 00       	imul   si,WORD PTR [bp+di+0x65],0x31
     3fc:	02 10                	add    dl,BYTE PTR [bx+si]
     3fe:	00 03                	add    BYTE PTR [bp+di],al
     400:	4e                   	dec    si
     401:	31 31                	xor    WORD PTR [bx+di],si
     403:	04 02                	add    al,0x2
     405:	10 00                	adc    BYTE PTR [bx+si],al
     407:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     40a:	31 08                	xor    WORD PTR [bx+si],cx
     40c:	02 10                	add    dl,BYTE PTR [bx+si]
     40e:	00 03                	add    BYTE PTR [bp+di],al
     410:	4e                   	dec    si
     411:	33 31                	xor    si,WORD PTR [bx+di]
     413:	0c 02                	or     al,0x2
     415:	10 00                	adc    BYTE PTR [bx+si],al
     417:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     41a:	31 10                	xor    WORD PTR [bx+si],dx
     41c:	02 10                	add    dl,BYTE PTR [bx+si]
     41e:	00 03                	add    BYTE PTR [bp+di],al
     420:	4e                   	dec    si
     421:	35 31 14             	xor    ax,0x1431
     424:	02 10                	add    dl,BYTE PTR [bx+si]
     426:	00 03                	add    BYTE PTR [bp+di],al
     428:	4e                   	dec    si
     429:	36 31 18             	xor    WORD PTR ss:[bx+si],bx
     42c:	02 10                	add    dl,BYTE PTR [bx+si]
     42e:	00 03                	add    BYTE PTR [bp+di],al
     430:	4e                   	dec    si
     431:	37                   	aaa
     432:	31 1c                	xor    WORD PTR [si],bx
     434:	02 10                	add    dl,BYTE PTR [bx+si]
     436:	00 03                	add    BYTE PTR [bp+di],al
     438:	4e                   	dec    si
     439:	38 31                	cmp    BYTE PTR [bx+di],dh
     43b:	20 02                	and    BYTE PTR [bp+si],al
     43d:	10 00                	adc    BYTE PTR [bx+si],al
     43f:	05 41 69             	add    ax,0x6941
     442:	64 65 31 24          	fs xor WORD PTR gs:[si],sp
     446:	02 10                	add    dl,BYTE PTR [bx+si]
     448:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     44c:	64 65 78 31          	fs gs js 0x481
     450:	28 02                	sub    BYTE PTR [bp+si],al
     452:	10 00                	adc    BYTE PTR [bx+si],al
     454:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     457:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     45a:	72 63                	jb     0x4bf
     45c:	68 65 72             	push   0x7265
     45f:	31 2c                	xor    WORD PTR [si],bp
     461:	02 10                	add    dl,BYTE PTR [bx+si]
     463:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     467:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     46c:	72 6c                	jb     0x4da
     46e:	61                   	popa
     46f:	69 64 65 31 30       	imul   sp,WORD PTR [si+0x65],0x3031
     474:	02 10                	add    dl,BYTE PTR [bx+si]
     476:	00 08                	add    BYTE PTR [bx+si],cl
     478:	41                   	inc    cx
     479:	70 72                	jo     0x4ed
     47b:	6f                   	outs   dx,WORD PTR ds:[si]
     47c:	70 6f                	jo     0x4ed
     47e:	73 31                	jae    0x4b1
     480:	34 02                	xor    al,0x2
     482:	14 00                	adc    al,0x0
     484:	0c 50                	or     al,0x50
     486:	72 69                	jb     0x4f1
     488:	6e                   	outs   dx,BYTE PTR ds:[si]
     489:	74 44                	je     0x4cf
     48b:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     490:	31 38                	xor    WORD PTR [bx+si],di
     492:	02 18                	add    bl,BYTE PTR [bx+si]
     494:	00 08                	add    BYTE PTR [bx+si],cl
     496:	54                   	push   sp
     497:	61                   	popa
     498:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     49b:	45                   	inc    bp
     49c:	44                   	inc    sp
     49d:	50                   	push   ax
     49e:	3c 02                	cmp    al,0x2
     4a0:	18 00                	sbb    BYTE PTR [bx+si],al
     4a2:	08 54 61             	or     BYTE PTR [si+0x61],dl
     4a5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4a8:	45                   	inc    bp
     4a9:	52                   	push   dx
     4aa:	47                   	inc    di
     4ab:	40                   	inc    ax
     4ac:	02 18                	add    bl,BYTE PTR [bx+si]
     4ae:	00 08                	add    BYTE PTR [bx+si],cl
     4b0:	54                   	push   sp
     4b1:	61                   	popa
     4b2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4b5:	45                   	inc    bp
     4b6:	52                   	push   dx
     4b7:	50                   	push   ax
     4b8:	44                   	inc    sp
     4b9:	02 18                	add    bl,BYTE PTR [bx+si]
     4bb:	00 08                	add    BYTE PTR [bx+si],cl
     4bd:	54                   	push   sp
     4be:	61                   	popa
     4bf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4c2:	45                   	inc    bp
     4c3:	44                   	inc    sp
     4c4:	4d                   	dec    bp
     4c5:	48                   	dec    ax
     4c6:	02 00                	add    al,BYTE PTR [bx+si]
     4c8:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     4cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     4cd:	65 6c                	gs ins BYTE PTR es:[di],dx
     4cf:	38 4c 02             	cmp    BYTE PTR [si+0x2],cl
     4d2:	00 00                	add    BYTE PTR [bx+si],al
     4d4:	06                   	push   es
     4d5:	50                   	push   ax
     4d6:	61                   	popa
     4d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     4d8:	65 6c                	gs ins BYTE PTR es:[di],dx
     4da:	39 50 02             	cmp    WORD PTR [bx+si+0x2],dx
     4dd:	00 00                	add    BYTE PTR [bx+si],al
     4df:	07                   	pop    es
     4e0:	50                   	push   ax
     4e1:	61                   	popa
     4e2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e3:	65 6c                	gs ins BYTE PTR es:[di],dx
     4e5:	31 30                	xor    WORD PTR [bx+si],si
     4e7:	54                   	push   sp
     4e8:	02 00                	add    al,BYTE PTR [bx+si]
     4ea:	00 07                	add    BYTE PTR [bx],al
     4ec:	50                   	push   ax
     4ed:	61                   	popa
     4ee:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ef:	65 6c                	gs ins BYTE PTR es:[di],dx
     4f1:	31 31                	xor    WORD PTR [bx+di],si
     4f3:	58                   	pop    ax
     4f4:	02 00                	add    al,BYTE PTR [bx+si]
     4f6:	00 07                	add    BYTE PTR [bx],al
     4f8:	50                   	push   ax
     4f9:	61                   	popa
     4fa:	6e                   	outs   dx,BYTE PTR ds:[si]
     4fb:	65 6c                	gs ins BYTE PTR es:[di],dx
     4fd:	31 32                	xor    WORD PTR [bp+si],si
     4ff:	5c                   	pop    sp
     500:	02 00                	add    al,BYTE PTR [bx+si]
     502:	00 07                	add    BYTE PTR [bx],al
     504:	50                   	push   ax
     505:	61                   	popa
     506:	6e                   	outs   dx,BYTE PTR ds:[si]
     507:	65 6c                	gs ins BYTE PTR es:[di],dx
     509:	31 33                	xor    WORD PTR [bp+di],si
     50b:	60                   	pusha
     50c:	02 00                	add    al,BYTE PTR [bx+si]
     50e:	00 07                	add    BYTE PTR [bx],al
     510:	50                   	push   ax
     511:	61                   	popa
     512:	6e                   	outs   dx,BYTE PTR ds:[si]
     513:	65 6c                	gs ins BYTE PTR es:[di],dx
     515:	33 37                	xor    si,WORD PTR [bx]
     517:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     51a:	00 07                	add    BYTE PTR [bx],al
     51c:	50                   	push   ax
     51d:	61                   	popa
     51e:	6e                   	outs   dx,BYTE PTR ds:[si]
     51f:	65 6c                	gs ins BYTE PTR es:[di],dx
     521:	33 38                	xor    di,WORD PTR [bx+si]
     523:	68 02 18             	push   0x1802
     526:	00 08                	add    BYTE PTR [bx+si],cl
     528:	54                   	push   sp
     529:	61                   	popa
     52a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     52d:	4d                   	dec    bp
     52e:	52                   	push   dx
     52f:	50                   	push   ax
     530:	6c                   	ins    BYTE PTR es:[di],dx
     531:	02 10                	add    dl,BYTE PTR [bx+si]
     533:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
     537:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     53a:	31 70 02             	xor    WORD PTR [bx+si+0x2],si
     53d:	10 00                	adc    BYTE PTR [bx+si],al
     53f:	02 4e 33             	add    cl,BYTE PTR [bp+0x33]
     542:	74 02                	je     0x546
     544:	1c 00                	sbb    al,0x0
     546:	06                   	push   es
     547:	4c                   	dec    sp
     548:	61                   	popa
     549:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     54c:	31 78 02             	xor    WORD PTR [bx+si+0x2],di
     54f:	1c 00                	sbb    al,0x0
     551:	06                   	push   es
     552:	4c                   	dec    sp
     553:	61                   	popa
     554:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     557:	32 7c 02             	xor    bh,BYTE PTR [si+0x2]
     55a:	1c 00                	sbb    al,0x0
     55c:	06                   	push   es
     55d:	4c                   	dec    sp
     55e:	61                   	popa
     55f:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     562:	37                   	aaa
     563:	80 02 1c             	add    BYTE PTR [bp+si],0x1c
     566:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     56a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     56d:	36 84 02             	test   BYTE PTR ss:[bp+si],al
     570:	1c 00                	sbb    al,0x0
     572:	06                   	push   es
     573:	4c                   	dec    sp
     574:	61                   	popa
     575:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     578:	35 88 02             	xor    ax,0x288
     57b:	1c 00                	sbb    al,0x0
     57d:	06                   	push   es
     57e:	4c                   	dec    sp
     57f:	61                   	popa
     580:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     583:	34 8c                	xor    al,0x8c
     585:	02 1c                	add    bl,BYTE PTR [si]
     587:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     58b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     58e:	33 90 02 00          	xor    dx,WORD PTR [bx+si+0x2]
     592:	00 07                	add    BYTE PTR [bx],al
     594:	50                   	push   ax
     595:	61                   	popa
     596:	6e                   	outs   dx,BYTE PTR ds:[si]
     597:	65 6c                	gs ins BYTE PTR es:[di],dx
     599:	34 34                	xor    al,0x34
     59b:	94                   	xchg   sp,ax
     59c:	02 1c                	add    bl,BYTE PTR [si]
     59e:	00 07                	add    BYTE PTR [bx],al
     5a0:	4c                   	dec    sp
     5a1:	61                   	popa
     5a2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5a5:	55                   	push   bp
     5a6:	30 98 02 1c          	xor    BYTE PTR [bx+si+0x1c02],bl
     5aa:	00 07                	add    BYTE PTR [bx],al
     5ac:	4c                   	dec    sp
     5ad:	61                   	popa
     5ae:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5b1:	55                   	push   bp
     5b2:	31 9c 02 1c          	xor    WORD PTR [si+0x1c02],bx
     5b6:	00 07                	add    BYTE PTR [bx],al
     5b8:	4c                   	dec    sp
     5b9:	61                   	popa
     5ba:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5bd:	55                   	push   bp
     5be:	32 a0 02 1c          	xor    ah,BYTE PTR [bx+si+0x1c02]
     5c2:	00 07                	add    BYTE PTR [bx],al
     5c4:	4c                   	dec    sp
     5c5:	61                   	popa
     5c6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5c9:	55                   	push   bp
     5ca:	33 a4 02 20          	xor    sp,WORD PTR [si+0x2002]
     5ce:	00 05                	add    BYTE PTR [di],al
     5d0:	4d                   	dec    bp
     5d1:	65 6d                	gs ins WORD PTR es:[di],dx
     5d3:	6f                   	outs   dx,WORD PTR ds:[si]
     5d4:	31 a8 02 10          	xor    WORD PTR [bx+si+0x1002],bp
     5d8:	00 08                	add    BYTE PTR [bx+si],cl
     5da:	45                   	inc    bp
     5db:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     5e1:	31 ac 02 10          	xor    WORD PTR [si+0x1002],bp
     5e5:	00 07                	add    BYTE PTR [bx],al
     5e7:	43                   	inc    bx
     5e8:	6f                   	outs   dx,WORD PTR ds:[si]
     5e9:	70 69                	jo     0x654
     5eb:	65 72 31             	gs jb  0x61f
     5ee:	b0 02                	mov    al,0x2
     5f0:	10 00                	adc    BYTE PTR [bx+si],al
     5f2:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
     5f5:	b4 02                	mov    ah,0x2
     5f7:	10 00                	adc    BYTE PTR [bx+si],al
     5f9:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     5fc:	70 72                	jo     0x670
     5fe:	65 73 73             	gs jae 0x674
     601:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     606:	70 69                	jo     0x671
     608:	64 65 31 b8 02 10    	fs xor WORD PTR gs:[bx+si+0x1002],di
     60e:	00 02                	add    BYTE PTR [bp+si],al
     610:	4e                   	dec    si
     611:	35 bc 02             	xor    ax,0x2bc
     614:	10 00                	adc    BYTE PTR [bx+si],al
     616:	10 52 61             	adc    BYTE PTR [bp+si+0x61],dl
     619:	70 70                	jo     0x68b
     61b:	65 6c                	gs ins BYTE PTR es:[di],dx
     61d:	64 65 63 69 73       	fs arpl WORD PTR gs:[bx+di+0x73],bp
     622:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     627:	c0 02 10             	rol    BYTE PTR [bp+si],0x10
     62a:	00 08                	add    BYTE PTR [bx+si],cl
     62c:	50                   	push   ax
     62d:	65 72 69             	gs jb  0x699
     630:	6f                   	outs   dx,WORD PTR ds:[si]
     631:	64 65 32 c4          	fs gs xor al,ah
     635:	02 10                	add    dl,BYTE PTR [bx+si]
     637:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
     63b:	74 72                	je     0x6af
     63d:	65 31 c8             	gs xor ax,cx
     640:	02 10                	add    dl,BYTE PTR [bx+si]
     642:	00 04                	add    BYTE PTR [si],al
     644:	4e                   	dec    si
     645:	32 30                	xor    dh,BYTE PTR [bx+si]
     647:	31 cc                	xor    sp,cx
     649:	02 10                	add    dl,BYTE PTR [bx+si]
     64b:	00 04                	add    BYTE PTR [si],al
     64d:	4e                   	dec    si
     64e:	31 39                	xor    WORD PTR [bx+di],di
     650:	31 d0                	xor    ax,dx
     652:	02 10                	add    dl,BYTE PTR [bx+si]
     654:	00 04                	add    BYTE PTR [si],al
     656:	4e                   	dec    si
     657:	31 38                	xor    WORD PTR [bx+si],di
     659:	31 d4                	xor    sp,dx
     65b:	02 10                	add    dl,BYTE PTR [bx+si]
     65d:	00 04                	add    BYTE PTR [si],al
     65f:	4e                   	dec    si
     660:	31 37                	xor    WORD PTR [bx],si
     662:	31 d8                	xor    ax,bx
     664:	02 10                	add    dl,BYTE PTR [bx+si]
     666:	00 04                	add    BYTE PTR [si],al
     668:	4e                   	dec    si
     669:	31 36 31 dc          	xor    WORD PTR ds:0xdc31,si
     66d:	02 10                	add    dl,BYTE PTR [bx+si]
     66f:	00 04                	add    BYTE PTR [si],al
     671:	4e                   	dec    si
     672:	31 35                	xor    WORD PTR [di],si
     674:	31 e0                	xor    ax,sp
     676:	02 10                	add    dl,BYTE PTR [bx+si]
     678:	00 04                	add    BYTE PTR [si],al
     67a:	4e                   	dec    si
     67b:	31 34                	xor    WORD PTR [si],si
     67d:	31 e4                	xor    sp,sp
     67f:	02 10                	add    dl,BYTE PTR [bx+si]
     681:	00 04                	add    BYTE PTR [si],al
     683:	4e                   	dec    si
     684:	31 33                	xor    WORD PTR [bp+di],si
     686:	31 e8                	xor    ax,bp
     688:	02 10                	add    dl,BYTE PTR [bx+si]
     68a:	00 04                	add    BYTE PTR [si],al
     68c:	4e                   	dec    si
     68d:	31 32                	xor    WORD PTR [bp+si],si
     68f:	31 ec                	xor    sp,bp
     691:	02 10                	add    dl,BYTE PTR [bx+si]
     693:	00 04                	add    BYTE PTR [si],al
     695:	4e                   	dec    si
     696:	31 31                	xor    WORD PTR [bx+di],si
     698:	31 f0                	xor    ax,si
     69a:	02 10                	add    dl,BYTE PTR [bx+si]
     69c:	00 04                	add    BYTE PTR [si],al
     69e:	4e                   	dec    si
     69f:	31 30                	xor    WORD PTR [bx+si],si
     6a1:	31 f4                	xor    sp,si
     6a3:	02 10                	add    dl,BYTE PTR [bx+si]
     6a5:	00 03                	add    BYTE PTR [bp+di],al
     6a7:	4e                   	dec    si
     6a8:	39 31                	cmp    WORD PTR [bx+di],si
     6aa:	f8                   	clc
     6ab:	02 10                	add    dl,BYTE PTR [bx+si]
     6ad:	00 03                	add    BYTE PTR [bp+di],al
     6af:	4e                   	dec    si
     6b0:	38 32                	cmp    BYTE PTR [bp+si],dh
     6b2:	fc                   	cld
     6b3:	02 10                	add    dl,BYTE PTR [bx+si]
     6b5:	00 03                	add    BYTE PTR [bp+di],al
     6b7:	4e                   	dec    si
     6b8:	37                   	aaa
     6b9:	32 00                	xor    al,BYTE PTR [bx+si]
     6bb:	03 10                	add    dx,WORD PTR [bx+si]
     6bd:	00 03                	add    BYTE PTR [bp+di],al
     6bf:	4e                   	dec    si
     6c0:	36 32 04             	xor    al,BYTE PTR ss:[si]
     6c3:	03 10                	add    dx,WORD PTR [bx+si]
     6c5:	00 03                	add    BYTE PTR [bp+di],al
     6c7:	4e                   	dec    si
     6c8:	35 32 08             	xor    ax,0x832
     6cb:	03 10                	add    dx,WORD PTR [bx+si]
     6cd:	00 03                	add    BYTE PTR [bp+di],al
     6cf:	4e                   	dec    si
     6d0:	34 32                	xor    al,0x32
     6d2:	0c 03                	or     al,0x3
     6d4:	10 00                	adc    BYTE PTR [bx+si],al
     6d6:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     6d9:	32 10                	xor    dl,BYTE PTR [bx+si]
     6db:	03 10                	add    dx,WORD PTR [bx+si]
     6dd:	00 03                	add    BYTE PTR [bp+di],al
     6df:	4e                   	dec    si
     6e0:	32 32                	xor    dh,BYTE PTR [bp+si]
     6e2:	14 03                	adc    al,0x3
     6e4:	10 00                	adc    BYTE PTR [bx+si],al
     6e6:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     6e9:	32 09                	xor    cl,BYTE PTR [bx+di]
     6eb:	00 ad 0d 30          	add    BYTE PTR [di+0x300d],ch
     6ef:	5a                   	pop    dx
     6f0:	4d                   	dec    bp
     6f1:	0e                   	push   cs
     6f2:	05 0c 7d             	add    ax,0x7d0c
     6f5:	32 0a                	xor    cl,BYTE PTR [bp+si]
     6f7:	07                   	pop    es
     6f8:	ef                   	out    dx,ax
     6f9:	02 fe                	add    bh,dh
     6fb:	06                   	push   es
     6fc:	94                   	xchg   sp,ax
     6fd:	00 45 0a             	add    BYTE PTR [di+0xa],al
     700:	7e 08                	jle    0x70a
     702:	dc 3a                	fdivr  QWORD PTR [bp+si]
     704:	38 01                	cmp    BYTE PTR [bx+di],al
     706:	a8 27                	test   al,0x27
     708:	17                   	pop    ss
     709:	06                   	push   es
     70a:	0e                   	push   cs
     70b:	07                   	pop    es
     70c:	91                   	xchg   cx,ax
     70d:	12 22                	adc    ah,BYTE PTR [bp+si]
     70f:	59                   	pop    cx
     710:	07                   	pop    es
     711:	10 54 46             	adc    BYTE PTR [si+0x46],dl
     714:	6f                   	outs   dx,WORD PTR ds:[si]
     715:	72 6d                	jb     0x784
     717:	53                   	push   bx
     718:	45                   	inc    bp
     719:	52                   	push   dx
     71a:	45                   	inc    bp
     71b:	5f                   	pop    di
     71c:	45                   	inc    bp
     71d:	74 75                	je     0x794
     71f:	64 65 73 22          	fs gs jae 0x745
     723:	00 62 07             	add    BYTE PTR [bp+si+0x7],ah
     726:	7b 06                	jnp    0x72e
     728:	53                   	push   bx
     729:	07                   	pop    es
     72a:	38 00                	cmp    BYTE PTR [bx+si],al
     72c:	04 53                	add    al,0x53
     72e:	65 72 65             	gs jb  0x796
     731:	00 00                	add    BYTE PTR [bx+si],al
     733:	55                   	push   bp
     734:	89 e5                	mov    bp,sp
     736:	31 c0                	xor    ax,ax
     738:	9a 44 04 6d 07       	call   0x76d:0x444
     73d:	6a 00                	push   0x0
     73f:	9a c2 38 53 09       	call   0x953:0x38c2
     744:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     747:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     74e:	06                   	push   es
     74f:	57                   	push   di
     750:	9a 56 55 7b 07       	call   0x77b:0x5556
     755:	9a c3 28 ec 09       	call   0x9ec:0x28c3
     75a:	c9                   	leave
     75b:	ca 04 00             	retf   0x4
     75e:	00 00                	add    BYTE PTR [bx+si],al
     760:	07                   	pop    es
     761:	08 95 07 55          	or     BYTE PTR [di+0x5507],dl
     765:	89 e5                	mov    bp,sp
     767:	b8 08 00             	mov    ax,0x8
     76a:	9a 44 04 25 08       	call   0x825:0x444
     76f:	83 ec 08             	sub    sp,0x8
     772:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     776:	06                   	push   es
     777:	57                   	push   di
     778:	9a 03 73 9c 07       	call   0x79c:0x7303
     77d:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
     781:	7f 03                	jg     0x786
     783:	e9 8c 00             	jmp    0x812
     786:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     78a:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     78e:	b0 01                	mov    al,0x1
     790:	50                   	push   ax
     791:	b8 22 00             	mov    ax,0x22
     794:	ba d5 07             	mov    dx,0x7d5
     797:	52                   	push   dx
     798:	50                   	push   ax
     799:	9a 53 25 ef 07       	call   0x7ef:0x2553
     79e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     7a1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     7a4:	b8 5e 07             	mov    ax,0x75e
     7a7:	0e                   	push   cs
     7a8:	50                   	push   ax
     7a9:	55                   	push   bp
     7aa:	ff 36 58 18          	push   WORD PTR ds:0x1858
     7ae:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     7b2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     7b5:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     7b8:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     7bb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     7be:	26 89 85 1a 03       	mov    WORD PTR es:[di+0x31a],ax
     7c3:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     7c6:	26 89 85 18 03       	mov    WORD PTR es:[di+0x318],ax
     7cb:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
     7d0:	06                   	push   es
     7d1:	57                   	push   di
     7d2:	9a be 09 1a 08       	call   0x81a:0x9be
     7d7:	6a ff                	push   0xffff
     7d9:	6a f0                	push   0xfff0
     7db:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7de:	06                   	push   es
     7df:	57                   	push   di
     7e0:	9a d5 1e d0 08       	call   0x8d0:0x1ed5
     7e5:	6a 02                	push   0x2
     7e7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7ea:	06                   	push   es
     7eb:	57                   	push   di
     7ec:	9a 14 3a f9 07       	call   0x7f9:0x3a14
     7f1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7f4:	06                   	push   es
     7f5:	57                   	push   di
     7f6:	9a 45 5d 0f 08       	call   0x80f:0x5d45
     7fb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     7ff:	83 c4 06             	add    sp,0x6
     802:	b8 12 08             	mov    ax,0x812
     805:	0e                   	push   cs
     806:	50                   	push   ax
     807:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     80a:	06                   	push   es
     80b:	57                   	push   di
     80c:	9a 1d 5f 33 08       	call   0x833:0x5f1d
     811:	cb                   	retf
     812:	c9                   	leave
     813:	ca 04 00             	retf   0x4
     816:	00 00                	add    BYTE PTR [bx+si],al
     818:	6c                   	ins    BYTE PTR es:[di],dx
     819:	09 75 08             	or     WORD PTR [di+0x8],si
     81c:	55                   	push   bp
     81d:	89 e5                	mov    bp,sp
     81f:	b8 0a 00             	mov    ax,0xa
     822:	9a 44 04 83 09       	call   0x983:0x444
     827:	83 ec 0a             	sub    sp,0xa
     82a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     82e:	06                   	push   es
     82f:	57                   	push   di
     830:	9a 03 73 7c 08       	call   0x87c:0x7303
     835:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
     839:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
     83d:	7e 1e                	jle    0x85d
     83f:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     843:	75 14                	jne    0x859
     845:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     849:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
     84f:	b0 00                	mov    al,0x0
     851:	75 01                	jne    0x854
     853:	40                   	inc    ax
     854:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     857:	eb 04                	jmp    0x85d
     859:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
     85d:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
     861:	75 03                	jne    0x866
     863:	e9 11 01             	jmp    0x977
     866:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     86a:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     86e:	b0 01                	mov    al,0x1
     870:	50                   	push   ax
     871:	b8 22 00             	mov    ax,0x22
     874:	ba b5 08             	mov    dx,0x8b5
     877:	52                   	push   dx
     878:	50                   	push   ax
     879:	9a 53 25 ee 08       	call   0x8ee:0x2553
     87e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     881:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     884:	b8 16 08             	mov    ax,0x816
     887:	0e                   	push   cs
     888:	50                   	push   ax
     889:	55                   	push   bp
     88a:	ff 36 58 18          	push   WORD PTR ds:0x1858
     88e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     892:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     895:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     898:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     89b:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     89e:	26 89 85 1a 03       	mov    WORD PTR es:[di+0x31a],ax
     8a3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     8a6:	26 89 85 18 03       	mov    WORD PTR es:[di+0x318],ax
     8ab:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
     8b0:	06                   	push   es
     8b1:	57                   	push   di
     8b2:	9a be 09 c1 08       	call   0x8c1:0x9be
     8b7:	6a 01                	push   0x1
     8b9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     8bc:	06                   	push   es
     8bd:	57                   	push   di
     8be:	9a 7b 09 e0 08       	call   0x8e0:0x97b
     8c3:	68 ff 00             	push   0xff
     8c6:	6a ff                	push   0xffff
     8c8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     8cb:	06                   	push   es
     8cc:	57                   	push   di
     8cd:	9a d5 1e 10 09       	call   0x910:0x1ed5
     8d2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     8d5:	ff 76 fc             	push   WORD PTR [bp-0x4]
     8d8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     8db:	06                   	push   es
     8dc:	57                   	push   di
     8dd:	9a 66 34 28 09       	call   0x928:0x3466
     8e2:	6a 00                	push   0x0
     8e4:	6a 00                	push   0x0
     8e6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     8e9:	06                   	push   es
     8ea:	57                   	push   di
     8eb:	9a b2 36 fa 08       	call   0x8fa:0x36b2
     8f0:	6a 02                	push   0x2
     8f2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     8f5:	06                   	push   es
     8f6:	57                   	push   di
     8f7:	9a 14 3a 06 09       	call   0x906:0x3a14
     8fc:	6a 01                	push   0x1
     8fe:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     901:	06                   	push   es
     902:	57                   	push   di
     903:	9a e5 34 35 09       	call   0x935:0x34e5
     908:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     90b:	06                   	push   es
     90c:	57                   	push   di
     90d:	9a b9 62 fb 09       	call   0x9fb:0x62b9
     912:	50                   	push   ax
     913:	6a 04                	push   0x4
     915:	9a ff ff 00 00       	call   0x0:0xffff
     91a:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     91e:	74 0c                	je     0x92c
     920:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     923:	06                   	push   es
     924:	57                   	push   di
     925:	9a 67 54 05 0a       	call   0xa05:0x5467
     92a:	eb 34                	jmp    0x960
     92c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     930:	06                   	push   es
     931:	57                   	push   di
     932:	9a 03 73 5e 09       	call   0x95e:0x7303
     937:	ff 76 fe             	push   WORD PTR [bp-0x2]
     93a:	ff 76 fc             	push   WORD PTR [bp-0x4]
     93d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     940:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
     945:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
     94a:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     94e:	06                   	push   es
     94f:	57                   	push   di
     950:	9a 1a 31 16 3b       	call   0x3b16:0x311a
     955:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     959:	06                   	push   es
     95a:	57                   	push   di
     95b:	9a 03 73 74 09       	call   0x974:0x7303
     960:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     964:	83 c4 06             	add    sp,0x6
     967:	b8 77 09             	mov    ax,0x977
     96a:	0e                   	push   cs
     96b:	50                   	push   ax
     96c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     96f:	06                   	push   es
     970:	57                   	push   di
     971:	9a 1d 5f 9c 09       	call   0x99c:0x5f1d
     976:	cb                   	retf
     977:	c9                   	leave
     978:	ca 06 00             	retf   0x6
     97b:	55                   	push   bp
     97c:	89 e5                	mov    bp,sp
     97e:	31 c0                	xor    ax,ax
     980:	9a 44 04 c7 09       	call   0x9c7:0x444
     985:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
     988:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     98b:	26 88 85 1c 03       	mov    BYTE PTR es:[di+0x31c],al
     990:	6a 00                	push   0x0
     992:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     997:	06                   	push   es
     998:	57                   	push   di
     999:	9a d0 1c ad 09       	call   0x9ad:0x1cd0
     99e:	6a 00                	push   0x0
     9a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9a3:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     9a8:	06                   	push   es
     9a9:	57                   	push   di
     9aa:	9a d0 1c c9 25       	call   0x25c9:0x1cd0
     9af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9b2:	26 80 bd 1c 03 00    	cmp    BYTE PTR es:[di+0x31c],0x0
     9b8:	74 00                	je     0x9ba
     9ba:	c9                   	leave
     9bb:	ca 06 00             	retf   0x6
     9be:	55                   	push   bp
     9bf:	89 e5                	mov    bp,sp
     9c1:	b8 02 01             	mov    ax,0x102
     9c4:	9a 44 04 2a 0a       	call   0xa2a:0x444
     9c9:	81 ec 02 01          	sub    sp,0x102
     9cd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     9d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9d3:	26 89 85 18 03       	mov    WORD PTR es:[di+0x318],ax
     9d8:	8d be fe fe          	lea    di,[bp-0x102]
     9dc:	16                   	push   ss
     9dd:	57                   	push   di
     9de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9e1:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
     9e6:	99                   	cwd
     9e7:	52                   	push   dx
     9e8:	50                   	push   ax
     9e9:	9a a9 08 b6 0a       	call   0xab6:0x8a9
     9ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9f1:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
     9f6:	06                   	push   es
     9f7:	57                   	push   di
     9f8:	9a 8c 1d c5 0a       	call   0xac5:0x1d8c
     9fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a00:	06                   	push   es
     a01:	57                   	push   di
     a02:	9a c2 3f 65 0a       	call   0xa65:0x3fc2
     a07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a0a:	26 c4 bd c0 02       	les    di,DWORD PTR es:[di+0x2c0]
     a0f:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     a12:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     a15:	31 c0                	xor    ax,ax
     a17:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     a1a:	eb 03                	jmp    0xa1f
     a1c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     a1f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     a22:	05 01 00             	add    ax,0x1
     a25:	71 05                	jno    0xa2c
     a27:	9a 3e 04 91 0a       	call   0xa91:0x43e
     a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a2f:	26 3b 85 18 03       	cmp    ax,WORD PTR es:[di+0x318]
     a34:	b0 00                	mov    al,0x0
     a36:	75 01                	jne    0xa39
     a38:	40                   	inc    ax
     a39:	50                   	push   ax
     a3a:	ff 76 fe             	push   WORD PTR [bp-0x2]
     a3d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     a40:	06                   	push   es
     a41:	57                   	push   di
     a42:	9a 53 13 50 0a       	call   0xa50:0x1353
     a47:	89 c7                	mov    di,ax
     a49:	8e c2                	mov    es,dx
     a4b:	06                   	push   es
     a4c:	57                   	push   di
     a4d:	9a 75 12 e4 0a       	call   0xae4:0x1275
     a52:	83 7e fe 13          	cmp    WORD PTR [bp-0x2],0x13
     a56:	75 c4                	jne    0xa1c
     a58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a5b:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
     a60:	06                   	push   es
     a61:	57                   	push   di
     a62:	9a 88 0a cf 0a       	call   0xacf:0xa88
     a67:	c9                   	leave
     a68:	ca 06 00             	retf   0x6
     a6b:	01 00                	add    WORD PTR [bx+si],ax
     a6d:	00 00                	add    BYTE PTR [bx+si],al
     a6f:	08 00                	or     BYTE PTR [bx+si],al
     a71:	00 00                	add    BYTE PTR [bx+si],al
     a73:	05 25 38             	add    ax,0x3825
     a76:	2e 32 66 03          	xor    ah,BYTE PTR cs:[bp+0x3]
     a7a:	23 41 64             	and    ax,WORD PTR [bx+di+0x64]
     a7d:	02 25                	add    ah,BYTE PTR [di]
     a7f:	64 01 00             	add    WORD PTR fs:[bx+si],ax
     a82:	00 00                	add    BYTE PTR [bx+si],al
     a84:	02 00                	add    al,BYTE PTR [bx+si]
     a86:	00 00                	add    BYTE PTR [bx+si],al
     a88:	55                   	push   bp
     a89:	89 e5                	mov    bp,sp
     a8b:	b8 28 02             	mov    ax,0x228
     a8e:	9a 44 04 ee 0a       	call   0xaee:0x444
     a93:	81 ec 28 02          	sub    sp,0x228
     a97:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     a9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a9d:	26 89 85 1a 03       	mov    WORD PTR es:[di+0x31a],ax
     aa2:	8d be fa fe          	lea    di,[bp-0x106]
     aa6:	16                   	push   ss
     aa7:	57                   	push   di
     aa8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aab:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
     ab0:	99                   	cwd
     ab1:	52                   	push   dx
     ab2:	50                   	push   ax
     ab3:	9a a9 08 14 20       	call   0x2014:0x8a9
     ab8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     abb:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
     ac0:	06                   	push   es
     ac1:	57                   	push   di
     ac2:	9a 8c 1d c7 0d       	call   0xdc7:0x1d8c
     ac7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aca:	06                   	push   es
     acb:	57                   	push   di
     acc:	9a 96 28 b0 21       	call   0x21b0:0x2896
     ad1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ad4:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
     ad9:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     adc:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     adf:	06                   	push   es
     ae0:	57                   	push   di
     ae1:	9a 26 13 28 0b       	call   0xb28:0x1326
     ae6:	2d 01 00             	sub    ax,0x1
     ae9:	71 05                	jno    0xaf0
     aeb:	9a 3e 04 0d 0b       	call   0xb0d:0x43e
     af0:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     af3:	31 c0                	xor    ax,ax
     af5:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     af8:	7f 43                	jg     0xb3d
     afa:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     afd:	eb 03                	jmp    0xb02
     aff:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     b02:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     b05:	05 01 00             	add    ax,0x1
     b08:	71 05                	jno    0xb0f
     b0a:	9a 3e 04 67 0b       	call   0xb67:0x43e
     b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b12:	26 3b 85 1a 03       	cmp    ax,WORD PTR es:[di+0x31a]
     b17:	b0 00                	mov    al,0x0
     b19:	75 01                	jne    0xb1c
     b1b:	40                   	inc    ax
     b1c:	50                   	push   ax
     b1d:	ff 76 fa             	push   WORD PTR [bp-0x6]
     b20:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     b23:	06                   	push   es
     b24:	57                   	push   di
     b25:	9a 53 13 33 0b       	call   0xb33:0x1353
     b2a:	89 c7                	mov    di,ax
     b2c:	8e c2                	mov    es,dx
     b2e:	06                   	push   es
     b2f:	57                   	push   di
     b30:	9a 75 12 19 25       	call   0x2519:0x1275
     b35:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     b38:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     b3b:	75 c2                	jne    0xaff
     b3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b40:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
     b45:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     b48:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     b4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b4e:	81 c7 1d 04          	add    di,0x41d
     b52:	89 7e f2             	mov    WORD PTR [bp-0xe],di
     b55:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
     b58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b5b:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
     b60:	99                   	cwd
     b61:	bf 6b 0a             	mov    di,0xa6b
     b64:	9a 16 04 9e 0b       	call   0xb9e:0x416
     b69:	6b c0 07             	imul   ax,ax,0x7
     b6c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     b6f:	03 f8                	add    di,ax
     b71:	26 80 7d f9 00       	cmp    BYTE PTR es:[di-0x7],0x0
     b76:	75 03                	jne    0xb7b
     b78:	e9 e5 01             	jmp    0xd60
     b7b:	a1 4e 01             	mov    ax,ds:0x14e
     b7e:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     b81:	b8 01 00             	mov    ax,0x1
     b84:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     b87:	7e 03                	jle    0xb8c
     b89:	e9 d2 01             	jmp    0xd5e
     b8c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     b8f:	eb 03                	jmp    0xb94
     b91:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     b94:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b97:	99                   	cwd
     b98:	bf 6b 0a             	mov    di,0xa6b
     b9b:	9a 16 04 c5 0b       	call   0xbc5:0x416
     ba0:	c1 e0 06             	shl    ax,0x6
     ba3:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     ba6:	03 f8                	add    di,ax
     ba8:	81 c7 f8 ff          	add    di,0xfff8
     bac:	89 7e ec             	mov    WORD PTR [bp-0x14],di
     baf:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
     bb2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     bb5:	6a 01                	push   0x1
     bb7:	8d be da fd          	lea    di,[bp-0x226]
     bbb:	16                   	push   ss
     bbc:	57                   	push   di
     bbd:	bf 79 0a             	mov    di,0xa79
     bc0:	0e                   	push   cs
     bc1:	57                   	push   di
     bc2:	9a cd 17 fb 0b       	call   0xbfb:0x17cd
     bc7:	8d be da fe          	lea    di,[bp-0x126]
     bcb:	16                   	push   ss
     bcc:	57                   	push   di
     bcd:	bf 73 0a             	mov    di,0xa73
     bd0:	0e                   	push   cs
     bd1:	57                   	push   di
     bd2:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     bd5:	9b 26 dd 05          	fld    QWORD PTR es:[di]
     bd9:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     bdd:	8d 46 e2             	lea    ax,[bp-0x1e]
     be0:	8c d2                	mov    dx,ss
     be2:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     be5:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     be8:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
     bec:	8d 7e da             	lea    di,[bp-0x26]
     bef:	16                   	push   ss
     bf0:	57                   	push   di
     bf1:	6a 00                	push   0x0
     bf3:	9a fb 32 4c 0c       	call   0xc4c:0x32fb
     bf8:	9a 4c 18 1a 0c       	call   0xc1a:0x184c
     bfd:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     c00:	06                   	push   es
     c01:	57                   	push   di
     c02:	9a 08 9b 5b 0c       	call   0xc5b:0x9b08
     c07:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c0a:	6a 02                	push   0x2
     c0c:	8d be da fd          	lea    di,[bp-0x226]
     c10:	16                   	push   ss
     c11:	57                   	push   di
     c12:	bf 79 0a             	mov    di,0xa79
     c15:	0e                   	push   cs
     c16:	57                   	push   di
     c17:	9a cd 17 51 0c       	call   0xc51:0x17cd
     c1c:	8d be da fe          	lea    di,[bp-0x126]
     c20:	16                   	push   ss
     c21:	57                   	push   di
     c22:	bf 73 0a             	mov    di,0xa73
     c25:	0e                   	push   cs
     c26:	57                   	push   di
     c27:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     c2a:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
     c2f:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     c33:	8d 46 e2             	lea    ax,[bp-0x1e]
     c36:	8c d2                	mov    dx,ss
     c38:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     c3b:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     c3e:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
     c42:	8d 7e da             	lea    di,[bp-0x26]
     c45:	16                   	push   ss
     c46:	57                   	push   di
     c47:	6a 00                	push   0x0
     c49:	9a fb 32 a2 0c       	call   0xca2:0x32fb
     c4e:	9a 4c 18 70 0c       	call   0xc70:0x184c
     c53:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     c56:	06                   	push   es
     c57:	57                   	push   di
     c58:	9a 08 9b b1 0c       	call   0xcb1:0x9b08
     c5d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c60:	6a 03                	push   0x3
     c62:	8d be da fd          	lea    di,[bp-0x226]
     c66:	16                   	push   ss
     c67:	57                   	push   di
     c68:	bf 79 0a             	mov    di,0xa79
     c6b:	0e                   	push   cs
     c6c:	57                   	push   di
     c6d:	9a cd 17 a7 0c       	call   0xca7:0x17cd
     c72:	8d be da fe          	lea    di,[bp-0x126]
     c76:	16                   	push   ss
     c77:	57                   	push   di
     c78:	bf 73 0a             	mov    di,0xa73
     c7b:	0e                   	push   cs
     c7c:	57                   	push   di
     c7d:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     c80:	9b 26 dd 45 10       	fld    QWORD PTR es:[di+0x10]
     c85:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     c89:	8d 46 e2             	lea    ax,[bp-0x1e]
     c8c:	8c d2                	mov    dx,ss
     c8e:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     c91:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     c94:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
     c98:	8d 7e da             	lea    di,[bp-0x26]
     c9b:	16                   	push   ss
     c9c:	57                   	push   di
     c9d:	6a 00                	push   0x0
     c9f:	9a fb 32 f2 0c       	call   0xcf2:0x32fb
     ca4:	9a 4c 18 c6 0c       	call   0xcc6:0x184c
     ca9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     cac:	06                   	push   es
     cad:	57                   	push   di
     cae:	9a 08 9b 01 0d       	call   0xd01:0x9b08
     cb3:	ff 76 fe             	push   WORD PTR [bp-0x2]
     cb6:	6a 04                	push   0x4
     cb8:	8d be e4 fd          	lea    di,[bp-0x21c]
     cbc:	16                   	push   ss
     cbd:	57                   	push   di
     cbe:	bf 79 0a             	mov    di,0xa79
     cc1:	0e                   	push   cs
     cc2:	57                   	push   di
     cc3:	9a cd 17 f7 0c       	call   0xcf7:0x17cd
     cc8:	8d be e4 fe          	lea    di,[bp-0x11c]
     ccc:	16                   	push   ss
     ccd:	57                   	push   di
     cce:	bf 7d 0a             	mov    di,0xa7d
     cd1:	0e                   	push   cs
     cd2:	57                   	push   di
     cd3:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     cd6:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
     cda:	26 8b 55 1a          	mov    dx,WORD PTR es:[di+0x1a]
     cde:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
     ce1:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
     ce4:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
     ce8:	8d 7e e4             	lea    di,[bp-0x1c]
     ceb:	16                   	push   ss
     cec:	57                   	push   di
     ced:	6a 00                	push   0x0
     cef:	9a fb 32 42 0d       	call   0xd42:0x32fb
     cf4:	9a 4c 18 16 0d       	call   0xd16:0x184c
     cf9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     cfc:	06                   	push   es
     cfd:	57                   	push   di
     cfe:	9a 08 9b 51 0d       	call   0xd51:0x9b08
     d03:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d06:	6a 05                	push   0x5
     d08:	8d be e4 fd          	lea    di,[bp-0x21c]
     d0c:	16                   	push   ss
     d0d:	57                   	push   di
     d0e:	bf 79 0a             	mov    di,0xa79
     d11:	0e                   	push   cs
     d12:	57                   	push   di
     d13:	9a cd 17 47 0d       	call   0xd47:0x17cd
     d18:	8d be e4 fe          	lea    di,[bp-0x11c]
     d1c:	16                   	push   ss
     d1d:	57                   	push   di
     d1e:	bf 7d 0a             	mov    di,0xa7d
     d21:	0e                   	push   cs
     d22:	57                   	push   di
     d23:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     d26:	26 8b 45 1c          	mov    ax,WORD PTR es:[di+0x1c]
     d2a:	26 8b 55 1e          	mov    dx,WORD PTR es:[di+0x1e]
     d2e:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
     d31:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
     d34:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
     d38:	8d 7e e4             	lea    di,[bp-0x1c]
     d3b:	16                   	push   ss
     d3c:	57                   	push   di
     d3d:	6a 00                	push   0x0
     d3f:	9a fb 32 9a 0e       	call   0xe9a:0x32fb
     d44:	9a 4c 18 ae 0d       	call   0xdae:0x184c
     d49:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     d4c:	06                   	push   es
     d4d:	57                   	push   di
     d4e:	9a 08 9b 93 0d       	call   0xd93:0x9b08
     d53:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d56:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     d59:	74 03                	je     0xd5e
     d5b:	e9 33 fe             	jmp    0xb91
     d5e:	eb 43                	jmp    0xda3
     d60:	a1 4e 01             	mov    ax,ds:0x14e
     d63:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     d66:	b8 01 00             	mov    ax,0x1
     d69:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     d6c:	7f 35                	jg     0xda3
     d6e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     d71:	eb 03                	jmp    0xd76
     d73:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     d76:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
     d7b:	eb 03                	jmp    0xd80
     d7d:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     d80:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d83:	ff 76 fa             	push   WORD PTR [bp-0x6]
     d86:	bf 6c 0a             	mov    di,0xa6c
     d89:	0e                   	push   cs
     d8a:	57                   	push   di
     d8b:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     d8e:	06                   	push   es
     d8f:	57                   	push   di
     d90:	9a 08 9b bb 0d       	call   0xdbb:0x9b08
     d95:	83 7e fa 05          	cmp    WORD PTR [bp-0x6],0x5
     d99:	75 e2                	jne    0xd7d
     d9b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d9e:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     da1:	75 d0                	jne    0xd73
     da3:	a1 4e 01             	mov    ax,ds:0x14e
     da6:	05 01 00             	add    ax,0x1
     da9:	71 05                	jno    0xdb0
     dab:	9a 3e 04 0a 0e       	call   0xe0a:0x43e
     db0:	99                   	cwd
     db1:	52                   	push   dx
     db2:	50                   	push   ax
     db3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     db6:	06                   	push   es
     db7:	57                   	push   di
     db8:	9a 1b 70 a9 0e       	call   0xea9:0x701b
     dbd:	6a 01                	push   0x1
     dbf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     dc2:	06                   	push   es
     dc3:	57                   	push   di
     dc4:	9a 77 1c de 0d       	call   0xdde:0x1c77
     dc9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     dcc:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
     dd0:	50                   	push   ax
     dd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dd4:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
     dd9:	06                   	push   es
     dda:	57                   	push   di
     ddb:	9a 77 1c 74 10       	call   0x1074:0x1c77
     de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     de8:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     deb:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     dee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     df1:	81 c7 1d 04          	add    di,0x41d
     df5:	89 7e f2             	mov    WORD PTR [bp-0xe],di
     df8:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
     dfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dfe:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
     e03:	99                   	cwd
     e04:	bf 6b 0a             	mov    di,0xa6b
     e07:	9a 16 04 42 0e       	call   0xe42:0x416
     e0c:	6b c0 07             	imul   ax,ax,0x7
     e0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e12:	03 f8                	add    di,ax
     e14:	26 80 bd 17 04 00    	cmp    BYTE PTR es:[di+0x417],0x0
     e1a:	75 03                	jne    0xe1f
     e1c:	e9 e5 01             	jmp    0x1004
     e1f:	a1 4e 01             	mov    ax,ds:0x14e
     e22:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     e25:	b8 01 00             	mov    ax,0x1
     e28:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     e2b:	7e 03                	jle    0xe30
     e2d:	e9 d2 01             	jmp    0x1002
     e30:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     e33:	eb 03                	jmp    0xe38
     e35:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     e38:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e3b:	99                   	cwd
     e3c:	bf 6b 0a             	mov    di,0xa6b
     e3f:	9a 16 04 69 0e       	call   0xe69:0x416
     e44:	c1 e0 06             	shl    ax,0x6
     e47:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     e4a:	03 f8                	add    di,ax
     e4c:	81 c7 18 00          	add    di,0x18
     e50:	89 7e ec             	mov    WORD PTR [bp-0x14],di
     e53:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
     e56:	ff 76 fe             	push   WORD PTR [bp-0x2]
     e59:	6a 01                	push   0x1
     e5b:	8d be da fd          	lea    di,[bp-0x226]
     e5f:	16                   	push   ss
     e60:	57                   	push   di
     e61:	bf 79 0a             	mov    di,0xa79
     e64:	0e                   	push   cs
     e65:	57                   	push   di
     e66:	9a cd 17 9f 0e       	call   0xe9f:0x17cd
     e6b:	8d be da fe          	lea    di,[bp-0x126]
     e6f:	16                   	push   ss
     e70:	57                   	push   di
     e71:	bf 73 0a             	mov    di,0xa73
     e74:	0e                   	push   cs
     e75:	57                   	push   di
     e76:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     e79:	9b 26 dd 05          	fld    QWORD PTR es:[di]
     e7d:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     e81:	8d 46 e2             	lea    ax,[bp-0x1e]
     e84:	8c d2                	mov    dx,ss
     e86:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e89:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     e8c:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
     e90:	8d 7e da             	lea    di,[bp-0x26]
     e93:	16                   	push   ss
     e94:	57                   	push   di
     e95:	6a 00                	push   0x0
     e97:	9a fb 32 f0 0e       	call   0xef0:0x32fb
     e9c:	9a 4c 18 be 0e       	call   0xebe:0x184c
     ea1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     ea4:	06                   	push   es
     ea5:	57                   	push   di
     ea6:	9a 08 9b ff 0e       	call   0xeff:0x9b08
     eab:	ff 76 fe             	push   WORD PTR [bp-0x2]
     eae:	6a 02                	push   0x2
     eb0:	8d be da fd          	lea    di,[bp-0x226]
     eb4:	16                   	push   ss
     eb5:	57                   	push   di
     eb6:	bf 79 0a             	mov    di,0xa79
     eb9:	0e                   	push   cs
     eba:	57                   	push   di
     ebb:	9a cd 17 f5 0e       	call   0xef5:0x17cd
     ec0:	8d be da fe          	lea    di,[bp-0x126]
     ec4:	16                   	push   ss
     ec5:	57                   	push   di
     ec6:	bf 73 0a             	mov    di,0xa73
     ec9:	0e                   	push   cs
     eca:	57                   	push   di
     ecb:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     ece:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
     ed3:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     ed7:	8d 46 e2             	lea    ax,[bp-0x1e]
     eda:	8c d2                	mov    dx,ss
     edc:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     edf:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     ee2:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
     ee6:	8d 7e da             	lea    di,[bp-0x26]
     ee9:	16                   	push   ss
     eea:	57                   	push   di
     eeb:	6a 00                	push   0x0
     eed:	9a fb 32 46 0f       	call   0xf46:0x32fb
     ef2:	9a 4c 18 14 0f       	call   0xf14:0x184c
     ef7:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     efa:	06                   	push   es
     efb:	57                   	push   di
     efc:	9a 08 9b 55 0f       	call   0xf55:0x9b08
     f01:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f04:	6a 03                	push   0x3
     f06:	8d be da fd          	lea    di,[bp-0x226]
     f0a:	16                   	push   ss
     f0b:	57                   	push   di
     f0c:	bf 79 0a             	mov    di,0xa79
     f0f:	0e                   	push   cs
     f10:	57                   	push   di
     f11:	9a cd 17 4b 0f       	call   0xf4b:0x17cd
     f16:	8d be da fe          	lea    di,[bp-0x126]
     f1a:	16                   	push   ss
     f1b:	57                   	push   di
     f1c:	bf 73 0a             	mov    di,0xa73
     f1f:	0e                   	push   cs
     f20:	57                   	push   di
     f21:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     f24:	9b 26 dd 45 10       	fld    QWORD PTR es:[di+0x10]
     f29:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     f2d:	8d 46 e2             	lea    ax,[bp-0x1e]
     f30:	8c d2                	mov    dx,ss
     f32:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     f35:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     f38:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
     f3c:	8d 7e da             	lea    di,[bp-0x26]
     f3f:	16                   	push   ss
     f40:	57                   	push   di
     f41:	6a 00                	push   0x0
     f43:	9a fb 32 96 0f       	call   0xf96:0x32fb
     f48:	9a 4c 18 6a 0f       	call   0xf6a:0x184c
     f4d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f50:	06                   	push   es
     f51:	57                   	push   di
     f52:	9a 08 9b a5 0f       	call   0xfa5:0x9b08
     f57:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f5a:	6a 04                	push   0x4
     f5c:	8d be e4 fd          	lea    di,[bp-0x21c]
     f60:	16                   	push   ss
     f61:	57                   	push   di
     f62:	bf 79 0a             	mov    di,0xa79
     f65:	0e                   	push   cs
     f66:	57                   	push   di
     f67:	9a cd 17 9b 0f       	call   0xf9b:0x17cd
     f6c:	8d be e4 fe          	lea    di,[bp-0x11c]
     f70:	16                   	push   ss
     f71:	57                   	push   di
     f72:	bf 7d 0a             	mov    di,0xa7d
     f75:	0e                   	push   cs
     f76:	57                   	push   di
     f77:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     f7a:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
     f7e:	26 8b 55 1a          	mov    dx,WORD PTR es:[di+0x1a]
     f82:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
     f85:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
     f88:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
     f8c:	8d 7e e4             	lea    di,[bp-0x1c]
     f8f:	16                   	push   ss
     f90:	57                   	push   di
     f91:	6a 00                	push   0x0
     f93:	9a fb 32 e6 0f       	call   0xfe6:0x32fb
     f98:	9a 4c 18 ba 0f       	call   0xfba:0x184c
     f9d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     fa0:	06                   	push   es
     fa1:	57                   	push   di
     fa2:	9a 08 9b f5 0f       	call   0xff5:0x9b08
     fa7:	ff 76 fe             	push   WORD PTR [bp-0x2]
     faa:	6a 05                	push   0x5
     fac:	8d be e4 fd          	lea    di,[bp-0x21c]
     fb0:	16                   	push   ss
     fb1:	57                   	push   di
     fb2:	bf 79 0a             	mov    di,0xa79
     fb5:	0e                   	push   cs
     fb6:	57                   	push   di
     fb7:	9a cd 17 eb 0f       	call   0xfeb:0x17cd
     fbc:	8d be e4 fe          	lea    di,[bp-0x11c]
     fc0:	16                   	push   ss
     fc1:	57                   	push   di
     fc2:	bf 7d 0a             	mov    di,0xa7d
     fc5:	0e                   	push   cs
     fc6:	57                   	push   di
     fc7:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
     fca:	26 8b 45 1c          	mov    ax,WORD PTR es:[di+0x1c]
     fce:	26 8b 55 1e          	mov    dx,WORD PTR es:[di+0x1e]
     fd2:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
     fd5:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
     fd8:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
     fdc:	8d 7e e4             	lea    di,[bp-0x1c]
     fdf:	16                   	push   ss
     fe0:	57                   	push   di
     fe1:	6a 00                	push   0x0
     fe3:	9a fb 32 69 11       	call   0x1169:0x32fb
     fe8:	9a 4c 18 52 10       	call   0x1052:0x184c
     fed:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     ff0:	06                   	push   es
     ff1:	57                   	push   di
     ff2:	9a 08 9b 37 10       	call   0x1037:0x9b08
     ff7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ffa:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
     ffd:	74 03                	je     0x1002
     fff:	e9 33 fe             	jmp    0xe35
    1002:	eb 43                	jmp    0x1047
    1004:	a1 4e 01             	mov    ax,ds:0x14e
    1007:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    100a:	b8 01 00             	mov    ax,0x1
    100d:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1010:	7f 35                	jg     0x1047
    1012:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1015:	eb 03                	jmp    0x101a
    1017:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    101a:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    101f:	eb 03                	jmp    0x1024
    1021:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1024:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1027:	ff 76 fa             	push   WORD PTR [bp-0x6]
    102a:	bf 6c 0a             	mov    di,0xa6c
    102d:	0e                   	push   cs
    102e:	57                   	push   di
    102f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1032:	06                   	push   es
    1033:	57                   	push   di
    1034:	9a 08 9b 5f 10       	call   0x105f:0x9b08
    1039:	83 7e fa 05          	cmp    WORD PTR [bp-0x6],0x5
    103d:	75 e2                	jne    0x1021
    103f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1042:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1045:	75 d0                	jne    0x1017
    1047:	a1 4e 01             	mov    ax,ds:0x14e
    104a:	05 01 00             	add    ax,0x1
    104d:	71 05                	jno    0x1054
    104f:	9a 3e 04 ba 10       	call   0x10ba:0x43e
    1054:	99                   	cwd
    1055:	52                   	push   dx
    1056:	50                   	push   ax
    1057:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    105a:	06                   	push   es
    105b:	57                   	push   di
    105c:	9a 1b 70 78 11       	call   0x1178:0x701b
    1061:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    1066:	b0 00                	mov    al,0x0
    1068:	7c 01                	jl     0x106b
    106a:	40                   	inc    ax
    106b:	50                   	push   ax
    106c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    106f:	06                   	push   es
    1070:	57                   	push   di
    1071:	9a 77 1c 8e 10       	call   0x108e:0x1c77
    1076:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    107b:	b0 00                	mov    al,0x0
    107d:	7c 01                	jl     0x1080
    107f:	40                   	inc    ax
    1080:	50                   	push   ax
    1081:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1084:	26 c4 bd 78 02       	les    di,DWORD PTR es:[di+0x278]
    1089:	06                   	push   es
    108a:	57                   	push   di
    108b:	9a 77 1c f7 11       	call   0x11f7:0x1c77
    1090:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1093:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    1098:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    109b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    109e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a1:	81 c7 1d 04          	add    di,0x41d
    10a5:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    10a8:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    10ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ae:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    10b3:	99                   	cwd
    10b4:	bf 6b 0a             	mov    di,0xa6b
    10b7:	9a 16 04 fc 10       	call   0x10fc:0x416
    10bc:	6b c0 07             	imul   ax,ax,0x7
    10bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10c2:	03 f8                	add    di,ax
    10c4:	26 80 bd 18 04 00    	cmp    BYTE PTR es:[di+0x418],0x0
    10ca:	75 03                	jne    0x10cf
    10cc:	e9 c1 00             	jmp    0x1190
    10cf:	a1 4e 01             	mov    ax,ds:0x14e
    10d2:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    10d5:	b8 01 00             	mov    ax,0x1
    10d8:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    10db:	7e 03                	jle    0x10e0
    10dd:	e9 ae 00             	jmp    0x118e
    10e0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    10e3:	eb 03                	jmp    0x10e8
    10e5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    10e8:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    10ed:	eb 03                	jmp    0x10f2
    10ef:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    10f2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    10f5:	99                   	cwd
    10f6:	bf 80 0a             	mov    di,0xa80
    10f9:	9a 16 04 0d 11       	call   0x110d:0x416
    10fe:	6b c0 30             	imul   ax,ax,0x30
    1101:	8b c8                	mov    cx,ax
    1103:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1106:	99                   	cwd
    1107:	bf 6b 0a             	mov    di,0xa6b
    110a:	9a 16 04 37 11       	call   0x1137:0x416
    110f:	6b c0 60             	imul   ax,ax,0x60
    1112:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1115:	03 f8                	add    di,ax
    1117:	03 f9                	add    di,cx
    1119:	81 c7 a8 01          	add    di,0x1a8
    111d:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    1120:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    1123:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1126:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1129:	8d be da fd          	lea    di,[bp-0x226]
    112d:	16                   	push   ss
    112e:	57                   	push   di
    112f:	bf 79 0a             	mov    di,0xa79
    1132:	0e                   	push   cs
    1133:	57                   	push   di
    1134:	9a cd 17 6e 11       	call   0x116e:0x17cd
    1139:	8d be da fe          	lea    di,[bp-0x126]
    113d:	16                   	push   ss
    113e:	57                   	push   di
    113f:	bf 73 0a             	mov    di,0xa73
    1142:	0e                   	push   cs
    1143:	57                   	push   di
    1144:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    1147:	9b 26 dd 45 1c       	fld    QWORD PTR es:[di+0x1c]
    114c:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    1150:	8d 46 e2             	lea    ax,[bp-0x1e]
    1153:	8c d2                	mov    dx,ss
    1155:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1158:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    115b:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    115f:	8d 7e da             	lea    di,[bp-0x26]
    1162:	16                   	push   ss
    1163:	57                   	push   di
    1164:	6a 00                	push   0x0
    1166:	9a fb 32 fe 12       	call   0x12fe:0x32fb
    116b:	9a 4c 18 de 11       	call   0x11de:0x184c
    1170:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1173:	06                   	push   es
    1174:	57                   	push   di
    1175:	9a 08 9b c3 11       	call   0x11c3:0x9b08
    117a:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    117e:	74 03                	je     0x1183
    1180:	e9 6c ff             	jmp    0x10ef
    1183:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1186:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1189:	74 03                	je     0x118e
    118b:	e9 57 ff             	jmp    0x10e5
    118e:	eb 43                	jmp    0x11d3
    1190:	a1 4e 01             	mov    ax,ds:0x14e
    1193:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1196:	b8 01 00             	mov    ax,0x1
    1199:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    119c:	7f 35                	jg     0x11d3
    119e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    11a1:	eb 03                	jmp    0x11a6
    11a3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    11a6:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    11ab:	eb 03                	jmp    0x11b0
    11ad:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    11b0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    11b3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    11b6:	bf 6c 0a             	mov    di,0xa6c
    11b9:	0e                   	push   cs
    11ba:	57                   	push   di
    11bb:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11be:	06                   	push   es
    11bf:	57                   	push   di
    11c0:	9a 08 9b eb 11       	call   0x11eb:0x9b08
    11c5:	83 7e fa 02          	cmp    WORD PTR [bp-0x6],0x2
    11c9:	75 e2                	jne    0x11ad
    11cb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    11ce:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    11d1:	75 d0                	jne    0x11a3
    11d3:	a1 4e 01             	mov    ax,ds:0x14e
    11d6:	05 01 00             	add    ax,0x1
    11d9:	71 05                	jno    0x11e0
    11db:	9a 3e 04 4f 12       	call   0x124f:0x43e
    11e0:	99                   	cwd
    11e1:	52                   	push   dx
    11e2:	50                   	push   ax
    11e3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11e6:	06                   	push   es
    11e7:	57                   	push   di
    11e8:	9a 1b 70 0c 12       	call   0x120c:0x701b
    11ed:	6a 01                	push   0x1
    11ef:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11f2:	06                   	push   es
    11f3:	57                   	push   di
    11f4:	9a 77 1c 23 12       	call   0x1223:0x1c77
    11f9:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    11fe:	7d 0e                	jge    0x120e
    1200:	6a 00                	push   0x0
    1202:	6a 02                	push   0x2
    1204:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1207:	06                   	push   es
    1208:	57                   	push   di
    1209:	9a 26 74 0d 13       	call   0x130d:0x7426
    120e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1211:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    1215:	50                   	push   ax
    1216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1219:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    121e:	06                   	push   es
    121f:	57                   	push   di
    1220:	9a 77 1c 55 14       	call   0x1455:0x1c77
    1225:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1228:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    122d:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1230:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1233:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1236:	81 c7 1d 04          	add    di,0x41d
    123a:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    123d:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    1240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1243:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    1248:	99                   	cwd
    1249:	bf 6b 0a             	mov    di,0xa6b
    124c:	9a 16 04 91 12       	call   0x1291:0x416
    1251:	6b c0 07             	imul   ax,ax,0x7
    1254:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1257:	03 f8                	add    di,ax
    1259:	26 80 bd 19 04 00    	cmp    BYTE PTR es:[di+0x419],0x0
    125f:	75 03                	jne    0x1264
    1261:	e9 8a 01             	jmp    0x13ee
    1264:	a1 4e 01             	mov    ax,ds:0x14e
    1267:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    126a:	b8 01 00             	mov    ax,0x1
    126d:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1270:	7e 03                	jle    0x1275
    1272:	e9 77 01             	jmp    0x13ec
    1275:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1278:	eb 03                	jmp    0x127d
    127a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    127d:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    1282:	eb 03                	jmp    0x1287
    1284:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1287:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    128a:	99                   	cwd
    128b:	bf 80 0a             	mov    di,0xa80
    128e:	9a 16 04 a2 12       	call   0x12a2:0x416
    1293:	6b c0 30             	imul   ax,ax,0x30
    1296:	8b c8                	mov    cx,ax
    1298:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    129b:	99                   	cwd
    129c:	bf 6b 0a             	mov    di,0xa6b
    129f:	9a 16 04 cc 12       	call   0x12cc:0x416
    12a4:	6b c0 60             	imul   ax,ax,0x60
    12a7:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    12aa:	03 f8                	add    di,ax
    12ac:	03 f9                	add    di,cx
    12ae:	81 c7 a8 01          	add    di,0x1a8
    12b2:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    12b5:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    12b8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    12bb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    12be:	8d be da fd          	lea    di,[bp-0x226]
    12c2:	16                   	push   ss
    12c3:	57                   	push   di
    12c4:	bf 79 0a             	mov    di,0xa79
    12c7:	0e                   	push   cs
    12c8:	57                   	push   di
    12c9:	9a cd 17 03 13       	call   0x1303:0x17cd
    12ce:	8d be da fe          	lea    di,[bp-0x126]
    12d2:	16                   	push   ss
    12d3:	57                   	push   di
    12d4:	bf 73 0a             	mov    di,0xa73
    12d7:	0e                   	push   cs
    12d8:	57                   	push   di
    12d9:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    12dc:	9b 26 dd 45 0c       	fld    QWORD PTR es:[di+0xc]
    12e1:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    12e5:	8d 46 e2             	lea    ax,[bp-0x1e]
    12e8:	8c d2                	mov    dx,ss
    12ea:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    12ed:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    12f0:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    12f4:	8d 7e da             	lea    di,[bp-0x26]
    12f7:	16                   	push   ss
    12f8:	57                   	push   di
    12f9:	6a 00                	push   0x0
    12fb:	9a fb 32 7a 13       	call   0x137a:0x32fb
    1300:	9a 4c 18 22 13       	call   0x1322:0x184c
    1305:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1308:	06                   	push   es
    1309:	57                   	push   di
    130a:	9a 08 9b 89 13       	call   0x1389:0x9b08
    130f:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    1313:	74 03                	je     0x1318
    1315:	e9 6c ff             	jmp    0x1284
    1318:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    131b:	99                   	cwd
    131c:	bf 6b 0a             	mov    di,0xa6b
    131f:	9a 16 04 49 13       	call   0x1349:0x416
    1324:	6b c0 38             	imul   ax,ax,0x38
    1327:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    132a:	03 f8                	add    di,ax
    132c:	81 c7 00 05          	add    di,0x500
    1330:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    1333:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    1336:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1339:	6a 03                	push   0x3
    133b:	8d be da fd          	lea    di,[bp-0x226]
    133f:	16                   	push   ss
    1340:	57                   	push   di
    1341:	bf 79 0a             	mov    di,0xa79
    1344:	0e                   	push   cs
    1345:	57                   	push   di
    1346:	9a cd 17 7f 13       	call   0x137f:0x17cd
    134b:	8d be da fe          	lea    di,[bp-0x126]
    134f:	16                   	push   ss
    1350:	57                   	push   di
    1351:	bf 73 0a             	mov    di,0xa73
    1354:	0e                   	push   cs
    1355:	57                   	push   di
    1356:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    1359:	9b 26 dd 05          	fld    QWORD PTR es:[di]
    135d:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    1361:	8d 46 e2             	lea    ax,[bp-0x1e]
    1364:	8c d2                	mov    dx,ss
    1366:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1369:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    136c:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    1370:	8d 7e da             	lea    di,[bp-0x26]
    1373:	16                   	push   ss
    1374:	57                   	push   di
    1375:	6a 00                	push   0x0
    1377:	9a fb 32 d0 13       	call   0x13d0:0x32fb
    137c:	9a 4c 18 9e 13       	call   0x139e:0x184c
    1381:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1384:	06                   	push   es
    1385:	57                   	push   di
    1386:	9a 08 9b df 13       	call   0x13df:0x9b08
    138b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    138e:	6a 04                	push   0x4
    1390:	8d be da fd          	lea    di,[bp-0x226]
    1394:	16                   	push   ss
    1395:	57                   	push   di
    1396:	bf 79 0a             	mov    di,0xa79
    1399:	0e                   	push   cs
    139a:	57                   	push   di
    139b:	9a cd 17 d5 13       	call   0x13d5:0x17cd
    13a0:	8d be da fe          	lea    di,[bp-0x126]
    13a4:	16                   	push   ss
    13a5:	57                   	push   di
    13a6:	bf 73 0a             	mov    di,0xa73
    13a9:	0e                   	push   cs
    13aa:	57                   	push   di
    13ab:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    13ae:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
    13b3:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    13b7:	8d 46 e2             	lea    ax,[bp-0x1e]
    13ba:	8c d2                	mov    dx,ss
    13bc:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    13bf:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    13c2:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    13c6:	8d 7e da             	lea    di,[bp-0x26]
    13c9:	16                   	push   ss
    13ca:	57                   	push   di
    13cb:	6a 00                	push   0x0
    13cd:	9a fb 32 40 15       	call   0x1540:0x32fb
    13d2:	9a 4c 18 3c 14       	call   0x143c:0x184c
    13d7:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    13da:	06                   	push   es
    13db:	57                   	push   di
    13dc:	9a 08 9b 21 14       	call   0x1421:0x9b08
    13e1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    13e4:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    13e7:	74 03                	je     0x13ec
    13e9:	e9 8e fe             	jmp    0x127a
    13ec:	eb 43                	jmp    0x1431
    13ee:	a1 4e 01             	mov    ax,ds:0x14e
    13f1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    13f4:	b8 01 00             	mov    ax,0x1
    13f7:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    13fa:	7f 35                	jg     0x1431
    13fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    13ff:	eb 03                	jmp    0x1404
    1401:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1404:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    1409:	eb 03                	jmp    0x140e
    140b:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    140e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1411:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1414:	bf 6c 0a             	mov    di,0xa6c
    1417:	0e                   	push   cs
    1418:	57                   	push   di
    1419:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    141c:	06                   	push   es
    141d:	57                   	push   di
    141e:	9a 08 9b 49 14       	call   0x1449:0x9b08
    1423:	83 7e fa 04          	cmp    WORD PTR [bp-0x6],0x4
    1427:	75 e2                	jne    0x140b
    1429:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    142c:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    142f:	75 d0                	jne    0x1401
    1431:	a1 4e 01             	mov    ax,ds:0x14e
    1434:	05 01 00             	add    ax,0x1
    1437:	71 05                	jno    0x143e
    1439:	9a 3e 04 af 14       	call   0x14af:0x43e
    143e:	99                   	cwd
    143f:	52                   	push   dx
    1440:	50                   	push   ax
    1441:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1444:	06                   	push   es
    1445:	57                   	push   di
    1446:	9a 1b 70 6c 14       	call   0x146c:0x701b
    144b:	6a 01                	push   0x1
    144d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1450:	06                   	push   es
    1451:	57                   	push   di
    1452:	9a 77 1c 83 14       	call   0x1483:0x1c77
    1457:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    145c:	7d 10                	jge    0x146e
    145e:	6a 00                	push   0x0
    1460:	6a 02                	push   0x2
    1462:	6a 00                	push   0x0
    1464:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1467:	06                   	push   es
    1468:	57                   	push   di
    1469:	9a a3 74 4f 15       	call   0x154f:0x74a3
    146e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1471:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    1475:	50                   	push   ax
    1476:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1479:	26 c4 bd 88 02       	les    di,DWORD PTR es:[di+0x288]
    147e:	06                   	push   es
    147f:	57                   	push   di
    1480:	9a 77 1c cc 17       	call   0x17cc:0x1c77
    1485:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1488:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    148d:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1490:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1496:	81 c7 1d 04          	add    di,0x41d
    149a:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    149d:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    14a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14a3:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    14a8:	99                   	cwd
    14a9:	bf 6b 0a             	mov    di,0xa6b
    14ac:	9a 16 04 e7 14       	call   0x14e7:0x416
    14b1:	6b c0 07             	imul   ax,ax,0x7
    14b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14b7:	03 f8                	add    di,ax
    14b9:	26 80 bd 1a 04 00    	cmp    BYTE PTR es:[di+0x41a],0x0
    14bf:	75 03                	jne    0x14c4
    14c1:	e9 98 02             	jmp    0x175c
    14c4:	a1 4e 01             	mov    ax,ds:0x14e
    14c7:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    14ca:	b8 01 00             	mov    ax,0x1
    14cd:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    14d0:	7e 03                	jle    0x14d5
    14d2:	e9 85 02             	jmp    0x175a
    14d5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    14d8:	eb 03                	jmp    0x14dd
    14da:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    14dd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    14e0:	99                   	cwd
    14e1:	bf 6b 0a             	mov    di,0xa6b
    14e4:	9a 16 04 0e 15       	call   0x150e:0x416
    14e9:	6b c0 38             	imul   ax,ax,0x38
    14ec:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    14ef:	03 f8                	add    di,ax
    14f1:	81 c7 00 05          	add    di,0x500
    14f5:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    14f8:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    14fb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14fe:	6a 01                	push   0x1
    1500:	8d be da fd          	lea    di,[bp-0x226]
    1504:	16                   	push   ss
    1505:	57                   	push   di
    1506:	bf 79 0a             	mov    di,0xa79
    1509:	0e                   	push   cs
    150a:	57                   	push   di
    150b:	9a cd 17 45 15       	call   0x1545:0x17cd
    1510:	8d be da fe          	lea    di,[bp-0x126]
    1514:	16                   	push   ss
    1515:	57                   	push   di
    1516:	bf 73 0a             	mov    di,0xa73
    1519:	0e                   	push   cs
    151a:	57                   	push   di
    151b:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    151e:	9b 26 dd 45 10       	fld    QWORD PTR es:[di+0x10]
    1523:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    1527:	8d 46 e2             	lea    ax,[bp-0x1e]
    152a:	8c d2                	mov    dx,ss
    152c:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    152f:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    1532:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    1536:	8d 7e da             	lea    di,[bp-0x26]
    1539:	16                   	push   ss
    153a:	57                   	push   di
    153b:	6a 00                	push   0x0
    153d:	9a fb 32 96 15       	call   0x1596:0x32fb
    1542:	9a 4c 18 64 15       	call   0x1564:0x184c
    1547:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    154a:	06                   	push   es
    154b:	57                   	push   di
    154c:	9a 08 9b a5 15       	call   0x15a5:0x9b08
    1551:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1554:	6a 02                	push   0x2
    1556:	8d be da fd          	lea    di,[bp-0x226]
    155a:	16                   	push   ss
    155b:	57                   	push   di
    155c:	bf 79 0a             	mov    di,0xa79
    155f:	0e                   	push   cs
    1560:	57                   	push   di
    1561:	9a cd 17 9b 15       	call   0x159b:0x17cd
    1566:	8d be da fe          	lea    di,[bp-0x126]
    156a:	16                   	push   ss
    156b:	57                   	push   di
    156c:	bf 73 0a             	mov    di,0xa73
    156f:	0e                   	push   cs
    1570:	57                   	push   di
    1571:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    1574:	9b 26 dd 45 18       	fld    QWORD PTR es:[di+0x18]
    1579:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    157d:	8d 46 e2             	lea    ax,[bp-0x1e]
    1580:	8c d2                	mov    dx,ss
    1582:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1585:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    1588:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    158c:	8d 7e da             	lea    di,[bp-0x26]
    158f:	16                   	push   ss
    1590:	57                   	push   di
    1591:	6a 00                	push   0x0
    1593:	9a fb 32 ec 15       	call   0x15ec:0x32fb
    1598:	9a 4c 18 ba 15       	call   0x15ba:0x184c
    159d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15a0:	06                   	push   es
    15a1:	57                   	push   di
    15a2:	9a 08 9b fb 15       	call   0x15fb:0x9b08
    15a7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    15aa:	6a 03                	push   0x3
    15ac:	8d be da fd          	lea    di,[bp-0x226]
    15b0:	16                   	push   ss
    15b1:	57                   	push   di
    15b2:	bf 79 0a             	mov    di,0xa79
    15b5:	0e                   	push   cs
    15b6:	57                   	push   di
    15b7:	9a cd 17 f1 15       	call   0x15f1:0x17cd
    15bc:	8d be da fe          	lea    di,[bp-0x126]
    15c0:	16                   	push   ss
    15c1:	57                   	push   di
    15c2:	bf 73 0a             	mov    di,0xa73
    15c5:	0e                   	push   cs
    15c6:	57                   	push   di
    15c7:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    15ca:	9b 26 dd 45 30       	fld    QWORD PTR es:[di+0x30]
    15cf:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    15d3:	8d 46 e2             	lea    ax,[bp-0x1e]
    15d6:	8c d2                	mov    dx,ss
    15d8:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    15db:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    15de:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    15e2:	8d 7e da             	lea    di,[bp-0x26]
    15e5:	16                   	push   ss
    15e6:	57                   	push   di
    15e7:	6a 00                	push   0x0
    15e9:	9a fb 32 42 16       	call   0x1642:0x32fb
    15ee:	9a 4c 18 10 16       	call   0x1610:0x184c
    15f3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15f6:	06                   	push   es
    15f7:	57                   	push   di
    15f8:	9a 08 9b 51 16       	call   0x1651:0x9b08
    15fd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1600:	6a 04                	push   0x4
    1602:	8d be da fd          	lea    di,[bp-0x226]
    1606:	16                   	push   ss
    1607:	57                   	push   di
    1608:	bf 79 0a             	mov    di,0xa79
    160b:	0e                   	push   cs
    160c:	57                   	push   di
    160d:	9a cd 17 47 16       	call   0x1647:0x17cd
    1612:	8d be da fe          	lea    di,[bp-0x126]
    1616:	16                   	push   ss
    1617:	57                   	push   di
    1618:	bf 73 0a             	mov    di,0xa73
    161b:	0e                   	push   cs
    161c:	57                   	push   di
    161d:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    1620:	9b 26 dd 45 28       	fld    QWORD PTR es:[di+0x28]
    1625:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    1629:	8d 46 e2             	lea    ax,[bp-0x1e]
    162c:	8c d2                	mov    dx,ss
    162e:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1631:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    1634:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    1638:	8d 7e da             	lea    di,[bp-0x26]
    163b:	16                   	push   ss
    163c:	57                   	push   di
    163d:	6a 00                	push   0x0
    163f:	9a fb 32 98 16       	call   0x1698:0x32fb
    1644:	9a 4c 18 66 16       	call   0x1666:0x184c
    1649:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    164c:	06                   	push   es
    164d:	57                   	push   di
    164e:	9a 08 9b a7 16       	call   0x16a7:0x9b08
    1653:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1656:	6a 05                	push   0x5
    1658:	8d be da fd          	lea    di,[bp-0x226]
    165c:	16                   	push   ss
    165d:	57                   	push   di
    165e:	bf 79 0a             	mov    di,0xa79
    1661:	0e                   	push   cs
    1662:	57                   	push   di
    1663:	9a cd 17 9d 16       	call   0x169d:0x17cd
    1668:	8d be da fe          	lea    di,[bp-0x126]
    166c:	16                   	push   ss
    166d:	57                   	push   di
    166e:	bf 73 0a             	mov    di,0xa73
    1671:	0e                   	push   cs
    1672:	57                   	push   di
    1673:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    1676:	9b 26 dd 45 20       	fld    QWORD PTR es:[di+0x20]
    167b:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    167f:	8d 46 e2             	lea    ax,[bp-0x1e]
    1682:	8c d2                	mov    dx,ss
    1684:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1687:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    168a:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    168e:	8d 7e da             	lea    di,[bp-0x26]
    1691:	16                   	push   ss
    1692:	57                   	push   di
    1693:	6a 00                	push   0x0
    1695:	9a fb 32 35 17       	call   0x1735:0x32fb
    169a:	9a 4c 18 bd 16       	call   0x16bd:0x184c
    169f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    16a2:	06                   	push   es
    16a3:	57                   	push   di
    16a4:	9a 08 9b 44 17       	call   0x1744:0x9b08
    16a9:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    16ae:	eb 03                	jmp    0x16b3
    16b0:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    16b3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16b6:	99                   	cwd
    16b7:	bf 80 0a             	mov    di,0xa80
    16ba:	9a 16 04 ce 16       	call   0x16ce:0x416
    16bf:	6b c0 30             	imul   ax,ax,0x30
    16c2:	8b c8                	mov    cx,ax
    16c4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    16c7:	99                   	cwd
    16c8:	bf 6b 0a             	mov    di,0xa6b
    16cb:	9a 16 04 f2 16       	call   0x16f2:0x416
    16d0:	6b c0 60             	imul   ax,ax,0x60
    16d3:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    16d6:	03 f8                	add    di,ax
    16d8:	03 f9                	add    di,cx
    16da:	81 c7 a8 01          	add    di,0x1a8
    16de:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    16e1:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    16e4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    16e7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16ea:	05 05 00             	add    ax,0x5
    16ed:	71 05                	jno    0x16f4
    16ef:	9a 3e 04 03 17       	call   0x1703:0x43e
    16f4:	50                   	push   ax
    16f5:	8d be da fd          	lea    di,[bp-0x226]
    16f9:	16                   	push   ss
    16fa:	57                   	push   di
    16fb:	bf 79 0a             	mov    di,0xa79
    16fe:	0e                   	push   cs
    16ff:	57                   	push   di
    1700:	9a cd 17 3a 17       	call   0x173a:0x17cd
    1705:	8d be da fe          	lea    di,[bp-0x126]
    1709:	16                   	push   ss
    170a:	57                   	push   di
    170b:	bf 73 0a             	mov    di,0xa73
    170e:	0e                   	push   cs
    170f:	57                   	push   di
    1710:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    1713:	9b 26 dd 45 24       	fld    QWORD PTR es:[di+0x24]
    1718:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    171c:	8d 46 e2             	lea    ax,[bp-0x1e]
    171f:	8c d2                	mov    dx,ss
    1721:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1724:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    1727:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    172b:	8d 7e da             	lea    di,[bp-0x26]
    172e:	16                   	push   ss
    172f:	57                   	push   di
    1730:	6a 00                	push   0x0
    1732:	9a fb 32 9f 18       	call   0x189f:0x32fb
    1737:	9a 4c 18 aa 17       	call   0x17aa:0x184c
    173c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    173f:	06                   	push   es
    1740:	57                   	push   di
    1741:	9a 08 9b 8f 17       	call   0x178f:0x9b08
    1746:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    174a:	74 03                	je     0x174f
    174c:	e9 61 ff             	jmp    0x16b0
    174f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1752:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1755:	74 03                	je     0x175a
    1757:	e9 80 fd             	jmp    0x14da
    175a:	eb 43                	jmp    0x179f
    175c:	a1 4e 01             	mov    ax,ds:0x14e
    175f:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1762:	b8 01 00             	mov    ax,0x1
    1765:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1768:	7f 35                	jg     0x179f
    176a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    176d:	eb 03                	jmp    0x1772
    176f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1772:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    1777:	eb 03                	jmp    0x177c
    1779:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    177c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    177f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1782:	bf 6c 0a             	mov    di,0xa6c
    1785:	0e                   	push   cs
    1786:	57                   	push   di
    1787:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    178a:	06                   	push   es
    178b:	57                   	push   di
    178c:	9a 08 9b b7 17       	call   0x17b7:0x9b08
    1791:	83 7e fa 05          	cmp    WORD PTR [bp-0x6],0x5
    1795:	75 e2                	jne    0x1779
    1797:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    179a:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    179d:	75 d0                	jne    0x176f
    179f:	a1 4e 01             	mov    ax,ds:0x14e
    17a2:	05 01 00             	add    ax,0x1
    17a5:	71 05                	jno    0x17ac
    17a7:	9a 3e 04 24 18       	call   0x1824:0x43e
    17ac:	99                   	cwd
    17ad:	52                   	push   dx
    17ae:	50                   	push   ax
    17af:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    17b2:	06                   	push   es
    17b3:	57                   	push   di
    17b4:	9a 1b 70 e1 17       	call   0x17e1:0x701b
    17b9:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    17be:	b0 00                	mov    al,0x0
    17c0:	7c 01                	jl     0x17c3
    17c2:	40                   	inc    ax
    17c3:	50                   	push   ax
    17c4:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    17c7:	06                   	push   es
    17c8:	57                   	push   di
    17c9:	9a 77 1c f8 17       	call   0x17f8:0x1c77
    17ce:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    17d3:	7d 0e                	jge    0x17e3
    17d5:	6a 00                	push   0x0
    17d7:	6a 06                	push   0x6
    17d9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    17dc:	06                   	push   es
    17dd:	57                   	push   di
    17de:	9a 26 74 ae 18       	call   0x18ae:0x7426
    17e3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    17e6:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    17ea:	50                   	push   ax
    17eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17ee:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    17f3:	06                   	push   es
    17f4:	57                   	push   di
    17f5:	9a 77 1c f0 19       	call   0x19f0:0x1c77
    17fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17fd:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1802:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1805:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    180b:	81 c7 1d 04          	add    di,0x41d
    180f:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1812:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    1815:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1818:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    181d:	99                   	cwd
    181e:	bf 6b 0a             	mov    di,0xa6b
    1821:	9a 16 04 4d 18       	call   0x184d:0x416
    1826:	6b c0 07             	imul   ax,ax,0x7
    1829:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    182c:	03 f8                	add    di,ax
    182e:	26 80 bd 1b 04 00    	cmp    BYTE PTR es:[di+0x41b],0x0
    1834:	75 03                	jne    0x1839
    1836:	e9 78 01             	jmp    0x19b1
    1839:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    183e:	eb 03                	jmp    0x1843
    1840:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1843:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1846:	99                   	cwd
    1847:	bf 80 0a             	mov    di,0xa80
    184a:	9a 16 04 74 18       	call   0x1874:0x416
    184f:	6b c0 18             	imul   ax,ax,0x18
    1852:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1855:	03 f8                	add    di,ax
    1857:	81 c7 e0 06          	add    di,0x6e0
    185b:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    185e:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    1861:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1864:	6a 01                	push   0x1
    1866:	8d be e6 fd          	lea    di,[bp-0x21a]
    186a:	16                   	push   ss
    186b:	57                   	push   di
    186c:	bf 79 0a             	mov    di,0xa79
    186f:	0e                   	push   cs
    1870:	57                   	push   di
    1871:	9a cd 17 a4 18       	call   0x18a4:0x17cd
    1876:	8d be e6 fe          	lea    di,[bp-0x11a]
    187a:	16                   	push   ss
    187b:	57                   	push   di
    187c:	bf 7d 0a             	mov    di,0xa7d
    187f:	0e                   	push   cs
    1880:	57                   	push   di
    1881:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1884:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1887:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    188b:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    188e:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    1891:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    1895:	8d 7e e6             	lea    di,[bp-0x1a]
    1898:	16                   	push   ss
    1899:	57                   	push   di
    189a:	6a 00                	push   0x0
    189c:	9a fb 32 ef 18       	call   0x18ef:0x32fb
    18a1:	9a 4c 18 c3 18       	call   0x18c3:0x184c
    18a6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    18a9:	06                   	push   es
    18aa:	57                   	push   di
    18ab:	9a 08 9b fe 18       	call   0x18fe:0x9b08
    18b0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    18b3:	6a 02                	push   0x2
    18b5:	8d be e6 fd          	lea    di,[bp-0x21a]
    18b9:	16                   	push   ss
    18ba:	57                   	push   di
    18bb:	bf 79 0a             	mov    di,0xa79
    18be:	0e                   	push   cs
    18bf:	57                   	push   di
    18c0:	9a cd 17 f4 18       	call   0x18f4:0x17cd
    18c5:	8d be e6 fe          	lea    di,[bp-0x11a]
    18c9:	16                   	push   ss
    18ca:	57                   	push   di
    18cb:	bf 7d 0a             	mov    di,0xa7d
    18ce:	0e                   	push   cs
    18cf:	57                   	push   di
    18d0:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    18d3:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    18d7:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    18db:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    18de:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    18e1:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    18e5:	8d 7e e6             	lea    di,[bp-0x1a]
    18e8:	16                   	push   ss
    18e9:	57                   	push   di
    18ea:	6a 00                	push   0x0
    18ec:	9a fb 32 3f 19       	call   0x193f:0x32fb
    18f1:	9a 4c 18 13 19       	call   0x1913:0x184c
    18f6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    18f9:	06                   	push   es
    18fa:	57                   	push   di
    18fb:	9a 08 9b 4e 19       	call   0x194e:0x9b08
    1900:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1903:	6a 03                	push   0x3
    1905:	8d be e6 fd          	lea    di,[bp-0x21a]
    1909:	16                   	push   ss
    190a:	57                   	push   di
    190b:	bf 79 0a             	mov    di,0xa79
    190e:	0e                   	push   cs
    190f:	57                   	push   di
    1910:	9a cd 17 44 19       	call   0x1944:0x17cd
    1915:	8d be e6 fe          	lea    di,[bp-0x11a]
    1919:	16                   	push   ss
    191a:	57                   	push   di
    191b:	bf 7d 0a             	mov    di,0xa7d
    191e:	0e                   	push   cs
    191f:	57                   	push   di
    1920:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1923:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1927:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    192b:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    192e:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    1931:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    1935:	8d 7e e6             	lea    di,[bp-0x1a]
    1938:	16                   	push   ss
    1939:	57                   	push   di
    193a:	6a 00                	push   0x0
    193c:	9a fb 32 95 19       	call   0x1995:0x32fb
    1941:	9a 4c 18 63 19       	call   0x1963:0x184c
    1946:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1949:	06                   	push   es
    194a:	57                   	push   di
    194b:	9a 08 9b a4 19       	call   0x19a4:0x9b08
    1950:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1953:	6a 04                	push   0x4
    1955:	8d be dc fd          	lea    di,[bp-0x224]
    1959:	16                   	push   ss
    195a:	57                   	push   di
    195b:	bf 79 0a             	mov    di,0xa79
    195e:	0e                   	push   cs
    195f:	57                   	push   di
    1960:	9a cd 17 9a 19       	call   0x199a:0x17cd
    1965:	8d be dc fe          	lea    di,[bp-0x124]
    1969:	16                   	push   ss
    196a:	57                   	push   di
    196b:	bf 73 0a             	mov    di,0xa73
    196e:	0e                   	push   cs
    196f:	57                   	push   di
    1970:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1973:	9b 26 dd 45 10       	fld    QWORD PTR es:[di+0x10]
    1978:	9b db 7e e4          	fstp   TBYTE PTR [bp-0x1c]
    197c:	8d 46 e4             	lea    ax,[bp-0x1c]
    197f:	8c d2                	mov    dx,ss
    1981:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    1984:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    1987:	c6 46 e0 03          	mov    BYTE PTR [bp-0x20],0x3
    198b:	8d 7e dc             	lea    di,[bp-0x24]
    198e:	16                   	push   ss
    198f:	57                   	push   di
    1990:	6a 00                	push   0x0
    1992:	9a fb 32 02 1b       	call   0x1b02:0x32fb
    1997:	9a 4c 18 48 1a       	call   0x1a48:0x184c
    199c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    199f:	06                   	push   es
    19a0:	57                   	push   di
    19a1:	9a 08 9b d8 19       	call   0x19d8:0x9b08
    19a6:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    19aa:	74 03                	je     0x19af
    19ac:	e9 91 fe             	jmp    0x1840
    19af:	eb 35                	jmp    0x19e6
    19b1:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    19b6:	eb 03                	jmp    0x19bb
    19b8:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    19bb:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    19c0:	eb 03                	jmp    0x19c5
    19c2:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    19c5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19c8:	ff 76 fa             	push   WORD PTR [bp-0x6]
    19cb:	bf 6c 0a             	mov    di,0xa6c
    19ce:	0e                   	push   cs
    19cf:	57                   	push   di
    19d0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    19d3:	06                   	push   es
    19d4:	57                   	push   di
    19d5:	9a 08 9b 05 1a       	call   0x1a05:0x9b08
    19da:	83 7e fa 04          	cmp    WORD PTR [bp-0x6],0x4
    19de:	75 e2                	jne    0x19c2
    19e0:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    19e4:	75 d2                	jne    0x19b8
    19e6:	6a 01                	push   0x1
    19e8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    19eb:	06                   	push   es
    19ec:	57                   	push   di
    19ed:	9a 77 1c 1c 1a       	call   0x1a1c:0x1c77
    19f2:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    19f7:	7d 0e                	jge    0x1a07
    19f9:	6a 00                	push   0x0
    19fb:	6a 02                	push   0x2
    19fd:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1a00:	06                   	push   es
    1a01:	57                   	push   di
    1a02:	9a 1b 70 30 1b       	call   0x1b30:0x701b
    1a07:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1a0a:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    1a0e:	50                   	push   ax
    1a0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a12:	26 c4 bd 80 02       	les    di,DWORD PTR es:[di+0x280]
    1a17:	06                   	push   es
    1a18:	57                   	push   di
    1a19:	9a 77 1c 6e 1d       	call   0x1d6e:0x1c77
    1a1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a21:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    1a26:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1a29:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a2f:	81 c7 1d 04          	add    di,0x41d
    1a33:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1a36:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    1a39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a3c:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    1a41:	99                   	cwd
    1a42:	bf 6b 0a             	mov    di,0xa6b
    1a45:	9a 16 04 71 1a       	call   0x1a71:0x416
    1a4a:	6b c0 07             	imul   ax,ax,0x7
    1a4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a50:	03 f8                	add    di,ax
    1a52:	26 80 bd 1c 04 00    	cmp    BYTE PTR es:[di+0x41c],0x0
    1a58:	75 03                	jne    0x1a5d
    1a5a:	e9 c4 02             	jmp    0x1d21
    1a5d:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    1a62:	eb 03                	jmp    0x1a67
    1a64:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1a67:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a6a:	99                   	cwd
    1a6b:	bf 80 0a             	mov    di,0xa80
    1a6e:	9a 16 04 8f 1a       	call   0x1a8f:0x416
    1a73:	6b c0 28             	imul   ax,ax,0x28
    1a76:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1a79:	03 f8                	add    di,ax
    1a7b:	81 c7 00 07          	add    di,0x700
    1a7f:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    1a82:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    1a85:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a88:	99                   	cwd
    1a89:	bf 80 0a             	mov    di,0xa80
    1a8c:	9a 16 04 a5 1a       	call   0x1aa5:0x416
    1a91:	c1 e0 05             	shl    ax,0x5
    1a94:	8b c8                	mov    cx,ax
    1a96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a99:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    1a9e:	99                   	cwd
    1a9f:	bf 6b 0a             	mov    di,0xa6b
    1aa2:	9a 16 04 ce 1a       	call   0x1ace:0x416
    1aa7:	c1 e0 06             	shl    ax,0x6
    1aaa:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1aad:	03 f8                	add    di,ax
    1aaf:	03 f9                	add    di,cx
    1ab1:	81 c7 d8 ff          	add    di,0xffd8
    1ab5:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    1ab8:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    1abb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1abe:	6a 01                	push   0x1
    1ac0:	8d be d8 fd          	lea    di,[bp-0x228]
    1ac4:	16                   	push   ss
    1ac5:	57                   	push   di
    1ac6:	bf 79 0a             	mov    di,0xa79
    1ac9:	0e                   	push   cs
    1aca:	57                   	push   di
    1acb:	9a cd 17 26 1b       	call   0x1b26:0x17cd
    1ad0:	8d be d8 fe          	lea    di,[bp-0x128]
    1ad4:	16                   	push   ss
    1ad5:	57                   	push   di
    1ad6:	bf 73 0a             	mov    di,0xa73
    1ad9:	0e                   	push   cs
    1ada:	57                   	push   di
    1adb:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    1ade:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1ae2:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1ae6:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1aea:	26 ff 35             	push   WORD PTR es:[di]
    1aed:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1af0:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1af4:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1af8:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1afc:	26 ff 35             	push   WORD PTR es:[di]
    1aff:	9a a7 2e 21 1b       	call   0x1b21:0x2ea7
    1b04:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
    1b08:	8d 46 e0             	lea    ax,[bp-0x20]
    1b0b:	8c d2                	mov    dx,ss
    1b0d:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    1b10:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    1b13:	c6 46 dc 03          	mov    BYTE PTR [bp-0x24],0x3
    1b17:	8d 7e d8             	lea    di,[bp-0x28]
    1b1a:	16                   	push   ss
    1b1b:	57                   	push   di
    1b1c:	6a 00                	push   0x0
    1b1e:	9a fb 32 7b 1b       	call   0x1b7b:0x32fb
    1b23:	9a 4c 18 45 1b       	call   0x1b45:0x184c
    1b28:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1b2b:	06                   	push   es
    1b2c:	57                   	push   di
    1b2d:	9a 08 9b a9 1b       	call   0x1ba9:0x9b08
    1b32:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b35:	6a 02                	push   0x2
    1b37:	8d be d8 fd          	lea    di,[bp-0x228]
    1b3b:	16                   	push   ss
    1b3c:	57                   	push   di
    1b3d:	bf 79 0a             	mov    di,0xa79
    1b40:	0e                   	push   cs
    1b41:	57                   	push   di
    1b42:	9a cd 17 9f 1b       	call   0x1b9f:0x17cd
    1b47:	8d be d8 fe          	lea    di,[bp-0x128]
    1b4b:	16                   	push   ss
    1b4c:	57                   	push   di
    1b4d:	bf 73 0a             	mov    di,0xa73
    1b50:	0e                   	push   cs
    1b51:	57                   	push   di
    1b52:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    1b55:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1b59:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1b5d:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1b61:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    1b65:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1b68:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1b6c:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1b70:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    1b74:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    1b78:	9a a7 2e 9a 1b       	call   0x1b9a:0x2ea7
    1b7d:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
    1b81:	8d 46 e0             	lea    ax,[bp-0x20]
    1b84:	8c d2                	mov    dx,ss
    1b86:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    1b89:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    1b8c:	c6 46 dc 03          	mov    BYTE PTR [bp-0x24],0x3
    1b90:	8d 7e d8             	lea    di,[bp-0x28]
    1b93:	16                   	push   ss
    1b94:	57                   	push   di
    1b95:	6a 00                	push   0x0
    1b97:	9a fb 32 f4 1b       	call   0x1bf4:0x32fb
    1b9c:	9a 4c 18 be 1b       	call   0x1bbe:0x184c
    1ba1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1ba4:	06                   	push   es
    1ba5:	57                   	push   di
    1ba6:	9a 08 9b 22 1c       	call   0x1c22:0x9b08
    1bab:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bae:	6a 03                	push   0x3
    1bb0:	8d be d8 fd          	lea    di,[bp-0x228]
    1bb4:	16                   	push   ss
    1bb5:	57                   	push   di
    1bb6:	bf 79 0a             	mov    di,0xa79
    1bb9:	0e                   	push   cs
    1bba:	57                   	push   di
    1bbb:	9a cd 17 18 1c       	call   0x1c18:0x17cd
    1bc0:	8d be d8 fe          	lea    di,[bp-0x128]
    1bc4:	16                   	push   ss
    1bc5:	57                   	push   di
    1bc6:	bf 73 0a             	mov    di,0xa73
    1bc9:	0e                   	push   cs
    1bca:	57                   	push   di
    1bcb:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    1bce:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    1bd2:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    1bd6:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    1bda:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1bde:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1be1:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    1be5:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    1be9:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    1bed:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1bf1:	9a a7 2e 13 1c       	call   0x1c13:0x2ea7
    1bf6:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
    1bfa:	8d 46 e0             	lea    ax,[bp-0x20]
    1bfd:	8c d2                	mov    dx,ss
    1bff:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    1c02:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    1c05:	c6 46 dc 03          	mov    BYTE PTR [bp-0x24],0x3
    1c09:	8d 7e d8             	lea    di,[bp-0x28]
    1c0c:	16                   	push   ss
    1c0d:	57                   	push   di
    1c0e:	6a 00                	push   0x0
    1c10:	9a fb 32 6d 1c       	call   0x1c6d:0x32fb
    1c15:	9a 4c 18 37 1c       	call   0x1c37:0x184c
    1c1a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1c1d:	06                   	push   es
    1c1e:	57                   	push   di
    1c1f:	9a 08 9b 9b 1c       	call   0x1c9b:0x9b08
    1c24:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c27:	6a 04                	push   0x4
    1c29:	8d be d8 fd          	lea    di,[bp-0x228]
    1c2d:	16                   	push   ss
    1c2e:	57                   	push   di
    1c2f:	bf 79 0a             	mov    di,0xa79
    1c32:	0e                   	push   cs
    1c33:	57                   	push   di
    1c34:	9a cd 17 91 1c       	call   0x1c91:0x17cd
    1c39:	8d be d8 fe          	lea    di,[bp-0x128]
    1c3d:	16                   	push   ss
    1c3e:	57                   	push   di
    1c3f:	bf 73 0a             	mov    di,0xa73
    1c42:	0e                   	push   cs
    1c43:	57                   	push   di
    1c44:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    1c47:	9b 26 db 45 18       	fild   DWORD PTR es:[di+0x18]
    1c4c:	83 ec 08             	sub    sp,0x8
    1c4f:	89 e3                	mov    bx,sp
    1c51:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1c55:	90                   	nop
    1c56:	9b                   	fwait
    1c57:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1c5a:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1c5e:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1c62:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1c66:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    1c6a:	9a a7 2e 8c 1c       	call   0x1c8c:0x2ea7
    1c6f:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
    1c73:	8d 46 e0             	lea    ax,[bp-0x20]
    1c76:	8c d2                	mov    dx,ss
    1c78:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    1c7b:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    1c7e:	c6 46 dc 03          	mov    BYTE PTR [bp-0x24],0x3
    1c82:	8d 7e d8             	lea    di,[bp-0x28]
    1c85:	16                   	push   ss
    1c86:	57                   	push   di
    1c87:	6a 00                	push   0x0
    1c89:	9a fb 32 e6 1c       	call   0x1ce6:0x32fb
    1c8e:	9a 4c 18 b0 1c       	call   0x1cb0:0x184c
    1c93:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1c96:	06                   	push   es
    1c97:	57                   	push   di
    1c98:	9a 08 9b 14 1d       	call   0x1d14:0x9b08
    1c9d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ca0:	6a 05                	push   0x5
    1ca2:	8d be d8 fd          	lea    di,[bp-0x228]
    1ca6:	16                   	push   ss
    1ca7:	57                   	push   di
    1ca8:	bf 79 0a             	mov    di,0xa79
    1cab:	0e                   	push   cs
    1cac:	57                   	push   di
    1cad:	9a cd 17 0a 1d       	call   0x1d0a:0x17cd
    1cb2:	8d be d8 fe          	lea    di,[bp-0x128]
    1cb6:	16                   	push   ss
    1cb7:	57                   	push   di
    1cb8:	bf 73 0a             	mov    di,0xa73
    1cbb:	0e                   	push   cs
    1cbc:	57                   	push   di
    1cbd:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    1cc0:	9b 26 db 45 1c       	fild   DWORD PTR es:[di+0x1c]
    1cc5:	83 ec 08             	sub    sp,0x8
    1cc8:	89 e3                	mov    bx,sp
    1cca:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1cce:	90                   	nop
    1ccf:	9b                   	fwait
    1cd0:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    1cd3:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    1cd7:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1cdb:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1cdf:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1ce3:	9a a7 2e 05 1d       	call   0x1d05:0x2ea7
    1ce8:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
    1cec:	8d 46 e0             	lea    ax,[bp-0x20]
    1cef:	8c d2                	mov    dx,ss
    1cf1:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    1cf4:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    1cf7:	c6 46 dc 03          	mov    BYTE PTR [bp-0x24],0x3
    1cfb:	8d 7e d8             	lea    di,[bp-0x28]
    1cfe:	16                   	push   ss
    1cff:	57                   	push   di
    1d00:	6a 00                	push   0x0
    1d02:	9a fb 32 1d 46       	call   0x461d:0x32fb
    1d07:	9a 4c 18 b1 1d       	call   0x1db1:0x184c
    1d0c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d0f:	06                   	push   es
    1d10:	57                   	push   di
    1d11:	9a 08 9b 54 1d       	call   0x1d54:0x9b08
    1d16:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    1d1a:	74 03                	je     0x1d1f
    1d1c:	e9 45 fd             	jmp    0x1a64
    1d1f:	eb 43                	jmp    0x1d64
    1d21:	a1 4e 01             	mov    ax,ds:0x14e
    1d24:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1d27:	b8 01 00             	mov    ax,0x1
    1d2a:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1d2d:	7f 35                	jg     0x1d64
    1d2f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d32:	eb 03                	jmp    0x1d37
    1d34:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1d37:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    1d3c:	eb 03                	jmp    0x1d41
    1d3e:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1d41:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1d44:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d47:	bf 6c 0a             	mov    di,0xa6c
    1d4a:	0e                   	push   cs
    1d4b:	57                   	push   di
    1d4c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d4f:	06                   	push   es
    1d50:	57                   	push   di
    1d51:	9a 08 9b 83 1d       	call   0x1d83:0x9b08
    1d56:	83 7e fa 05          	cmp    WORD PTR [bp-0x6],0x5
    1d5a:	75 e2                	jne    0x1d3e
    1d5c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1d5f:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1d62:	75 d0                	jne    0x1d34
    1d64:	6a 01                	push   0x1
    1d66:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d69:	06                   	push   es
    1d6a:	57                   	push   di
    1d6b:	9a 77 1c 9a 1d       	call   0x1d9a:0x1c77
    1d70:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    1d75:	7d 0e                	jge    0x1d85
    1d77:	6a 00                	push   0x0
    1d79:	6a 02                	push   0x2
    1d7b:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d7e:	06                   	push   es
    1d7f:	57                   	push   di
    1d80:	9a 1b 70 06 1e       	call   0x1e06:0x701b
    1d85:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d88:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    1d8c:	50                   	push   ax
    1d8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d90:	26 c4 bd 7c 02       	les    di,DWORD PTR es:[di+0x27c]
    1d95:	06                   	push   es
    1d96:	57                   	push   di
    1d97:	9a 77 1c 59 23       	call   0x2359:0x1c77
    1d9c:	c9                   	leave
    1d9d:	ca 06 00             	retf   0x6
    1da0:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1da4:	ff                   	(bad)
    1da5:	7f 00                	jg     0x1da7
    1da7:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1daa:	e5 b8                	in     ax,0xb8
    1dac:	0c 00                	or     al,0x0
    1dae:	9a 44 04 dc 1d       	call   0x1ddc:0x444
    1db3:	83 ec 0c             	sub    sp,0xc
    1db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db9:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1dbc:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1dbf:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    1dc4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1dc7:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1dcc:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1dd1:	2d 01 00             	sub    ax,0x1
    1dd4:	83 da 00             	sbb    dx,0x0
    1dd7:	71 05                	jno    0x1dde
    1dd9:	9a 3e 04 e4 1d       	call   0x1de4:0x43e
    1dde:	bf a0 1d             	mov    di,0x1da0
    1de1:	9a 16 04 10 1e       	call   0x1e10:0x416
    1de6:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1de9:	31 c0                	xor    ax,ax
    1deb:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1dee:	7f 3c                	jg     0x1e2c
    1df0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1df3:	eb 03                	jmp    0x1df8
    1df5:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1df8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1dfb:	99                   	cwd
    1dfc:	52                   	push   dx
    1dfd:	50                   	push   ax
    1dfe:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e01:	06                   	push   es
    1e02:	57                   	push   di
    1e03:	9a 30 6e 9f 1e       	call   0x1e9f:0x6e30
    1e08:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1e0b:	71 05                	jno    0x1e12
    1e0d:	9a 3e 04 1f 1e       	call   0x1e1f:0x43e
    1e12:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e15:	26 03 85 06 01       	add    ax,WORD PTR es:[di+0x106]
    1e1a:	71 05                	jno    0x1e21
    1e1c:	9a 3e 04 4a 1e       	call   0x1e4a:0x43e
    1e21:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e24:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e27:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1e2a:	75 c9                	jne    0x1df5
    1e2c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1e2f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e32:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e35:	c9                   	leave
    1e36:	ca 04 00             	retf   0x4
    1e39:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1e3d:	ff                   	(bad)
    1e3e:	7f 00                	jg     0x1e40
    1e40:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1e43:	e5 b8                	in     ax,0xb8
    1e45:	0c 00                	or     al,0x0
    1e47:	9a 44 04 75 1e       	call   0x1e75:0x444
    1e4c:	83 ec 0c             	sub    sp,0xc
    1e4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e52:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1e55:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1e58:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    1e5d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e60:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    1e65:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    1e6a:	2d 01 00             	sub    ax,0x1
    1e6d:	83 da 00             	sbb    dx,0x0
    1e70:	71 05                	jno    0x1e77
    1e72:	9a 3e 04 7d 1e       	call   0x1e7d:0x43e
    1e77:	bf 39 1e             	mov    di,0x1e39
    1e7a:	9a 16 04 a9 1e       	call   0x1ea9:0x416
    1e7f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1e82:	31 c0                	xor    ax,ax
    1e84:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1e87:	7f 3c                	jg     0x1ec5
    1e89:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e8c:	eb 03                	jmp    0x1e91
    1e8e:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1e91:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e94:	99                   	cwd
    1e95:	52                   	push   dx
    1e96:	50                   	push   ax
    1e97:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e9a:	06                   	push   es
    1e9b:	57                   	push   di
    1e9c:	9a 8b 6e 39 1f       	call   0x1f39:0x6e8b
    1ea1:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1ea4:	71 05                	jno    0x1eab
    1ea6:	9a 3e 04 b8 1e       	call   0x1eb8:0x43e
    1eab:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1eae:	26 03 85 06 01       	add    ax,WORD PTR es:[di+0x106]
    1eb3:	71 05                	jno    0x1eba
    1eb5:	9a 3e 04 e3 1e       	call   0x1ee3:0x43e
    1eba:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1ebd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ec0:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1ec3:	75 c9                	jne    0x1e8e
    1ec5:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1ec8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ecb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ece:	c9                   	leave
    1ecf:	ca 04 00             	retf   0x4
    1ed2:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1ed6:	ff                   	(bad)
    1ed7:	7f 00                	jg     0x1ed9
    1ed9:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1edc:	e5 b8                	in     ax,0xb8
    1ede:	08 00                	or     BYTE PTR [bx+si],al
    1ee0:	9a 44 04 06 1f       	call   0x1f06:0x444
    1ee5:	83 ec 08             	sub    sp,0x8
    1ee8:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1eeb:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    1eee:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    1ef1:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1ef6:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1efb:	2d 01 00             	sub    ax,0x1
    1efe:	83 da 00             	sbb    dx,0x0
    1f01:	71 05                	jno    0x1f08
    1f03:	9a 3e 04 0e 1f       	call   0x1f0e:0x43e
    1f08:	bf d2 1e             	mov    di,0x1ed2
    1f0b:	9a 16 04 65 1f       	call   0x1f65:0x416
    1f10:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1f13:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1f16:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    1f1b:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1f1e:	7f 23                	jg     0x1f43
    1f20:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f23:	eb 03                	jmp    0x1f28
    1f25:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1f28:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f2b:	99                   	cwd
    1f2c:	52                   	push   dx
    1f2d:	50                   	push   ax
    1f2e:	ff 76 06             	push   WORD PTR [bp+0x6]
    1f31:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1f34:	06                   	push   es
    1f35:	57                   	push   di
    1f36:	9a c9 70 23 20       	call   0x2023:0x70c9
    1f3b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f3e:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1f41:	75 e2                	jne    0x1f25
    1f43:	c9                   	leave
    1f44:	ca 06 00             	retf   0x6
    1f47:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1f4b:	ff                   	(bad)
    1f4c:	7f 00                	jg     0x1f4e
    1f4e:	00 03                	add    BYTE PTR [bp+di],al
    1f50:	43                   	inc    bx
    1f51:	2c 30                	sub    al,0x30
    1f53:	03 23                	add    sp,WORD PTR [bp+di]
    1f55:	41                   	inc    cx
    1f56:	63 01                	arpl   WORD PTR [bx+di],ax
    1f58:	20 02                	and    BYTE PTR [bp+si],al
    1f5a:	30 2c                	xor    BYTE PTR [si],ch
    1f5c:	55                   	push   bp
    1f5d:	89 e5                	mov    bp,sp
    1f5f:	b8 0a 03             	mov    ax,0x30a
    1f62:	9a 44 04 89 1f       	call   0x1f89:0x444
    1f67:	81 ec 0a 03          	sub    sp,0x30a
    1f6b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f6e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1f71:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1f74:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1f79:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1f7e:	2d 01 00             	sub    ax,0x1
    1f81:	83 da 00             	sbb    dx,0x0
    1f84:	71 05                	jno    0x1f8b
    1f86:	9a 3e 04 91 1f       	call   0x1f91:0x43e
    1f8b:	bf 47 1f             	mov    di,0x1f47
    1f8e:	9a 16 04 c1 1f       	call   0x1fc1:0x416
    1f93:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1f96:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f99:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    1f9e:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1fa1:	7e 03                	jle    0x1fa6
    1fa3:	e9 8a 00             	jmp    0x2030
    1fa6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fa9:	eb 03                	jmp    0x1fae
    1fab:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1fae:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fb1:	6a 00                	push   0x0
    1fb3:	8d be f6 fd          	lea    di,[bp-0x20a]
    1fb7:	16                   	push   ss
    1fb8:	57                   	push   di
    1fb9:	bf 53 1f             	mov    di,0x1f53
    1fbc:	0e                   	push   cs
    1fbd:	57                   	push   di
    1fbe:	9a cd 17 e0 1f       	call   0x1fe0:0x17cd
    1fc3:	8d be f6 fe          	lea    di,[bp-0x10a]
    1fc7:	16                   	push   ss
    1fc8:	57                   	push   di
    1fc9:	bf 4f 1f             	mov    di,0x1f4f
    1fcc:	0e                   	push   cs
    1fcd:	57                   	push   di
    1fce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd1:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1fd6:	06                   	push   es
    1fd7:	57                   	push   di
    1fd8:	9a 19 15 c7 20       	call   0x20c7:0x1519
    1fdd:	9a 4c 18 ea 1f       	call   0x1fea:0x184c
    1fe2:	bf 57 1f             	mov    di,0x1f57
    1fe5:	0e                   	push   cs
    1fe6:	57                   	push   di
    1fe7:	9a 4c 18 02 20       	call   0x2002:0x184c
    1fec:	8d be f6 fc          	lea    di,[bp-0x30a]
    1ff0:	16                   	push   ss
    1ff1:	57                   	push   di
    1ff2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ff5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ff8:	26 2b 85 fe 00       	sub    ax,WORD PTR es:[di+0xfe]
    1ffd:	71 05                	jno    0x2004
    1fff:	9a 3e 04 0c 20       	call   0x200c:0x43e
    2004:	05 01 00             	add    ax,0x1
    2007:	71 05                	jno    0x200e
    2009:	9a 3e 04 19 20       	call   0x2019:0x43e
    200e:	99                   	cwd
    200f:	52                   	push   dx
    2010:	50                   	push   ax
    2011:	9a a9 08 b3 20       	call   0x20b3:0x8a9
    2016:	9a 4c 18 4e 20       	call   0x204e:0x184c
    201b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    201e:	06                   	push   es
    201f:	57                   	push   di
    2020:	9a 08 9b d1 20       	call   0x20d1:0x9b08
    2025:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2028:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    202b:	74 03                	je     0x2030
    202d:	e9 7b ff             	jmp    0x1fab
    2030:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2033:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2036:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2039:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    203e:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    2043:	2d 01 00             	sub    ax,0x1
    2046:	83 da 00             	sbb    dx,0x0
    2049:	71 05                	jno    0x2050
    204b:	9a 3e 04 56 20       	call   0x2056:0x43e
    2050:	bf 47 1f             	mov    di,0x1f47
    2053:	9a 16 04 89 20       	call   0x2089:0x416
    2058:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    205b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    205e:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    2063:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2066:	7f 73                	jg     0x20db
    2068:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    206b:	eb 03                	jmp    0x2070
    206d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2070:	6a 00                	push   0x0
    2072:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2075:	8d be f6 fc          	lea    di,[bp-0x30a]
    2079:	16                   	push   ss
    207a:	57                   	push   di
    207b:	8d be f6 fd          	lea    di,[bp-0x20a]
    207f:	16                   	push   ss
    2080:	57                   	push   di
    2081:	bf 59 1f             	mov    di,0x1f59
    2084:	0e                   	push   cs
    2085:	57                   	push   di
    2086:	9a cd 17 a1 20       	call   0x20a1:0x17cd
    208b:	8d be f6 fe          	lea    di,[bp-0x10a]
    208f:	16                   	push   ss
    2090:	57                   	push   di
    2091:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2094:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2097:	26 2b 85 00 01       	sub    ax,WORD PTR es:[di+0x100]
    209c:	71 05                	jno    0x20a3
    209e:	9a 3e 04 ab 20       	call   0x20ab:0x43e
    20a3:	05 01 00             	add    ax,0x1
    20a6:	71 05                	jno    0x20ad
    20a8:	9a 3e 04 b8 20       	call   0x20b8:0x43e
    20ad:	99                   	cwd
    20ae:	52                   	push   dx
    20af:	50                   	push   ax
    20b0:	9a a9 08 3c 27       	call   0x273c:0x8a9
    20b5:	9a 4c 18 f0 20       	call   0x20f0:0x184c
    20ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20bd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    20c2:	06                   	push   es
    20c3:	57                   	push   di
    20c4:	9a 19 15 e4 25       	call   0x25e4:0x1519
    20c9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20cc:	06                   	push   es
    20cd:	57                   	push   di
    20ce:	9a 08 9b 7f 21       	call   0x217f:0x9b08
    20d3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    20d6:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    20d9:	75 92                	jne    0x206d
    20db:	c9                   	leave
    20dc:	ca 08 00             	retf   0x8
    20df:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    20e3:	ff                   	(bad)
    20e4:	7f 00                	jg     0x20e6
    20e6:	00 55 89             	add    BYTE PTR [di-0x77],dl
    20e9:	e5 b8                	in     ax,0xb8
    20eb:	0c 00                	or     al,0x0
    20ed:	9a 44 04 1c 21       	call   0x211c:0x444
    20f2:	83 ec 0c             	sub    sp,0xc
    20f5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    20f8:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    20fc:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    2101:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2104:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2107:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    210c:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    2111:	2d 01 00             	sub    ax,0x1
    2114:	83 da 00             	sbb    dx,0x0
    2117:	71 05                	jno    0x211e
    2119:	9a 3e 04 24 21       	call   0x2124:0x43e
    211e:	bf df 20             	mov    di,0x20df
    2121:	9a 16 04 50 21       	call   0x2150:0x416
    2126:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2129:	31 c0                	xor    ax,ax
    212b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    212e:	7f 61                	jg     0x2191
    2130:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2133:	eb 03                	jmp    0x2138
    2135:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2138:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    213b:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2140:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2145:	2d 01 00             	sub    ax,0x1
    2148:	83 da 00             	sbb    dx,0x0
    214b:	71 05                	jno    0x2152
    214d:	9a 3e 04 58 21       	call   0x2158:0x43e
    2152:	bf df 20             	mov    di,0x20df
    2155:	9a 16 04 9d 21       	call   0x219d:0x416
    215a:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    215d:	31 c0                	xor    ax,ax
    215f:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2162:	7f 25                	jg     0x2189
    2164:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2167:	eb 03                	jmp    0x216c
    2169:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    216c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    216f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2172:	bf df 20             	mov    di,0x20df
    2175:	0e                   	push   cs
    2176:	57                   	push   di
    2177:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    217a:	06                   	push   es
    217b:	57                   	push   di
    217c:	9a 08 9b 38 22       	call   0x2238:0x9b08
    2181:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2184:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2187:	75 e0                	jne    0x2169
    2189:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    218c:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    218f:	75 a4                	jne    0x2135
    2191:	c9                   	leave
    2192:	ca 06 00             	retf   0x6
    2195:	55                   	push   bp
    2196:	89 e5                	mov    bp,sp
    2198:	31 c0                	xor    ax,ax
    219a:	9a 44 04 a2 24       	call   0x24a2:0x444
    219f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a2:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    21a7:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    21ac:	55                   	push   bp
    21ad:	9a e7 20 c3 21       	call   0x21c3:0x20e7
    21b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b5:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    21ba:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    21bf:	55                   	push   bp
    21c0:	9a e7 20 d6 21       	call   0x21d6:0x20e7
    21c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c8:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    21cd:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    21d2:	55                   	push   bp
    21d3:	9a e7 20 e9 21       	call   0x21e9:0x20e7
    21d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21db:	26 ff b5 aa 01       	push   WORD PTR es:[di+0x1aa]
    21e0:	26 ff b5 a8 01       	push   WORD PTR es:[di+0x1a8]
    21e5:	55                   	push   bp
    21e6:	9a e7 20 fc 21       	call   0x21fc:0x20e7
    21eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ee:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    21f3:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    21f8:	55                   	push   bp
    21f9:	9a e7 20 0f 22       	call   0x220f:0x20e7
    21fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2201:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    2206:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    220b:	55                   	push   bp
    220c:	9a e7 20 22 22       	call   0x2222:0x20e7
    2211:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2214:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    2219:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    221e:	55                   	push   bp
    221f:	9a e7 20 d0 22       	call   0x22d0:0x20e7
    2224:	6a 00                	push   0x0
    2226:	6a 00                	push   0x0
    2228:	68 80 00             	push   0x80
    222b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    222e:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    2233:	06                   	push   es
    2234:	57                   	push   di
    2235:	9a c9 70 4e 22       	call   0x224e:0x70c9
    223a:	6a 00                	push   0x0
    223c:	6a 00                	push   0x0
    223e:	68 80 00             	push   0x80
    2241:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2244:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2249:	06                   	push   es
    224a:	57                   	push   di
    224b:	9a c9 70 64 22       	call   0x2264:0x70c9
    2250:	6a 00                	push   0x0
    2252:	6a 00                	push   0x0
    2254:	68 80 00             	push   0x80
    2257:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    225a:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    225f:	06                   	push   es
    2260:	57                   	push   di
    2261:	9a c9 70 7a 22       	call   0x227a:0x70c9
    2266:	6a 00                	push   0x0
    2268:	6a 00                	push   0x0
    226a:	68 80 00             	push   0x80
    226d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2270:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2275:	06                   	push   es
    2276:	57                   	push   di
    2277:	9a c9 70 90 22       	call   0x2290:0x70c9
    227c:	6a 00                	push   0x0
    227e:	6a 00                	push   0x0
    2280:	68 80 00             	push   0x80
    2283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2286:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    228b:	06                   	push   es
    228c:	57                   	push   di
    228d:	9a c9 70 a6 22       	call   0x22a6:0x70c9
    2292:	6a 00                	push   0x0
    2294:	6a 00                	push   0x0
    2296:	68 c0 00             	push   0xc0
    2299:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    229c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    22a1:	06                   	push   es
    22a2:	57                   	push   di
    22a3:	9a c9 70 bc 22       	call   0x22bc:0x70c9
    22a8:	6a 00                	push   0x0
    22aa:	6a 00                	push   0x0
    22ac:	68 c0 00             	push   0xc0
    22af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b2:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    22b7:	06                   	push   es
    22b8:	57                   	push   di
    22b9:	9a c9 70 ef 29       	call   0x29ef:0x70c9
    22be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c1:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    22c6:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    22cb:	6a 60                	push   0x60
    22cd:	9a da 1e e4 22       	call   0x22e4:0x1eda
    22d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22d5:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    22da:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    22df:	6a 60                	push   0x60
    22e1:	9a da 1e f8 22       	call   0x22f8:0x1eda
    22e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e9:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    22ee:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    22f3:	6a 60                	push   0x60
    22f5:	9a da 1e 0c 23       	call   0x230c:0x1eda
    22fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fd:	26 ff b5 aa 01       	push   WORD PTR es:[di+0x1aa]
    2302:	26 ff b5 a8 01       	push   WORD PTR es:[di+0x1a8]
    2307:	6a 60                	push   0x60
    2309:	9a da 1e 20 23       	call   0x2320:0x1eda
    230e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2311:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    2316:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    231b:	6a 60                	push   0x60
    231d:	9a da 1e 34 23       	call   0x2334:0x1eda
    2322:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2325:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    232a:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    232f:	6a 60                	push   0x60
    2331:	9a da 1e 48 23       	call   0x2348:0x1eda
    2336:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2339:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    233e:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    2343:	6a 60                	push   0x60
    2345:	9a da 1e db 23       	call   0x23db:0x1eda
    234a:	6a 05                	push   0x5
    234c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234f:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    2354:	06                   	push   es
    2355:	57                   	push   di
    2356:	9a 72 16 6a 23       	call   0x236a:0x1672
    235b:	6a 05                	push   0x5
    235d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2360:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2365:	06                   	push   es
    2366:	57                   	push   di
    2367:	9a 72 16 7b 23       	call   0x237b:0x1672
    236c:	6a 05                	push   0x5
    236e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2371:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    2376:	06                   	push   es
    2377:	57                   	push   di
    2378:	9a 72 16 8c 23       	call   0x238c:0x1672
    237d:	6a 05                	push   0x5
    237f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2382:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2387:	06                   	push   es
    2388:	57                   	push   di
    2389:	9a 72 16 9d 23       	call   0x239d:0x1672
    238e:	6a 05                	push   0x5
    2390:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2393:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2398:	06                   	push   es
    2399:	57                   	push   di
    239a:	9a 72 16 ae 23       	call   0x23ae:0x1672
    239f:	6a 05                	push   0x5
    23a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23a4:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    23a9:	06                   	push   es
    23aa:	57                   	push   di
    23ab:	9a 72 16 bf 23       	call   0x23bf:0x1672
    23b0:	6a 05                	push   0x5
    23b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b5:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    23ba:	06                   	push   es
    23bb:	57                   	push   di
    23bc:	9a 72 16 da 24       	call   0x24da:0x1672
    23c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c4:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    23c9:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    23ce:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    23d3:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    23d8:	9a 5c 1f f7 23       	call   0x23f7:0x1f5c
    23dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e0:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    23e5:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    23ea:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    23ef:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    23f4:	9a 5c 1f 13 24       	call   0x2413:0x1f5c
    23f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fc:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    2401:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    2406:	26 ff b5 9a 01       	push   WORD PTR es:[di+0x19a]
    240b:	26 ff b5 98 01       	push   WORD PTR es:[di+0x198]
    2410:	9a 5c 1f 2f 24       	call   0x242f:0x1f5c
    2415:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2418:	26 ff b5 aa 01       	push   WORD PTR es:[di+0x1aa]
    241d:	26 ff b5 a8 01       	push   WORD PTR es:[di+0x1a8]
    2422:	26 ff b5 a6 01       	push   WORD PTR es:[di+0x1a6]
    2427:	26 ff b5 a4 01       	push   WORD PTR es:[di+0x1a4]
    242c:	9a 5c 1f 4b 24       	call   0x244b:0x1f5c
    2431:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2434:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    2439:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    243e:	26 ff b5 b2 01       	push   WORD PTR es:[di+0x1b2]
    2443:	26 ff b5 b0 01       	push   WORD PTR es:[di+0x1b0]
    2448:	9a 5c 1f 67 24       	call   0x2467:0x1f5c
    244d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2450:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    2455:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    245a:	26 ff b5 be 01       	push   WORD PTR es:[di+0x1be]
    245f:	26 ff b5 bc 01       	push   WORD PTR es:[di+0x1bc]
    2464:	9a 5c 1f 83 24       	call   0x2483:0x1f5c
    2469:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246c:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    2471:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    2476:	26 ff b5 ce 01       	push   WORD PTR es:[di+0x1ce]
    247b:	26 ff b5 cc 01       	push   WORD PTR es:[di+0x1cc]
    2480:	9a 5c 1f 1e 28       	call   0x281e:0x1f5c
    2485:	c9                   	leave
    2486:	ca 04 00             	retf   0x4
    2489:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    248c:	6d                   	ins    WORD PTR es:[di],dx
    248d:	73 74                	jae    0x2503
    248f:	72 61                	jb     0x24f2
    2491:	74 20                	je     0x24b3
    2493:	2d 20 03             	sub    ax,0x320
    2496:	20 2d                	and    BYTE PTR [di],ch
    2498:	20 55 89             	and    BYTE PTR [di-0x77],dl
    249b:	e5 b8                	in     ax,0xb8
    249d:	02 03                	add    al,BYTE PTR [bp+di]
    249f:	9a 44 04 b6 24       	call   0x24b6:0x444
    24a4:	81 ec 02 03          	sub    sp,0x302
    24a8:	8d be fe fe          	lea    di,[bp-0x102]
    24ac:	16                   	push   ss
    24ad:	57                   	push   di
    24ae:	bf 89 24             	mov    di,0x2489
    24b1:	0e                   	push   cs
    24b2:	57                   	push   di
    24b3:	9a cd 17 c0 24       	call   0x24c0:0x17cd
    24b8:	bf fa 1d             	mov    di,0x1dfa
    24bb:	1e                   	push   ds
    24bc:	57                   	push   di
    24bd:	9a 4c 18 ca 24       	call   0x24ca:0x184c
    24c2:	bf 95 24             	mov    di,0x2495
    24c5:	0e                   	push   cs
    24c6:	57                   	push   di
    24c7:	9a 4c 18 df 24       	call   0x24df:0x184c
    24cc:	8d be fe fd          	lea    di,[bp-0x202]
    24d0:	16                   	push   ss
    24d1:	57                   	push   di
    24d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d5:	06                   	push   es
    24d6:	57                   	push   di
    24d7:	9a 53 1d 04 25       	call   0x2504:0x1d53
    24dc:	9a 4c 18 f0 24       	call   0x24f0:0x184c
    24e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e4:	81 c7 1d 03          	add    di,0x31d
    24e8:	06                   	push   es
    24e9:	57                   	push   di
    24ea:	68 ff 00             	push   0xff
    24ed:	9a e7 17 23 25       	call   0x2523:0x17e7
    24f2:	bf fa 1d             	mov    di,0x1dfa
    24f5:	1e                   	push   ds
    24f6:	57                   	push   di
    24f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24fa:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    24ff:	06                   	push   es
    2500:	57                   	push   di
    2501:	9a 8c 1d 18 26       	call   0x2618:0x1d8c
    2506:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2509:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    250e:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2511:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2514:	06                   	push   es
    2515:	57                   	push   di
    2516:	9a 26 13 4d 25       	call   0x254d:0x1326
    251b:	2d 01 00             	sub    ax,0x1
    251e:	71 05                	jno    0x2525
    2520:	9a 3e 04 85 25       	call   0x2585:0x43e
    2525:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2528:	31 c0                	xor    ax,ax
    252a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    252d:	7f 33                	jg     0x2562
    252f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2532:	eb 03                	jmp    0x2537
    2534:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2537:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    253a:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    253e:	7c 1a                	jl     0x255a
    2540:	6a 00                	push   0x0
    2542:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2545:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2548:	06                   	push   es
    2549:	57                   	push   di
    254a:	9a 53 13 58 25       	call   0x2558:0x1353
    254f:	89 c7                	mov    di,ax
    2551:	8e c2                	mov    es,dx
    2553:	06                   	push   es
    2554:	57                   	push   di
    2555:	9a a5 13 a7 25       	call   0x25a7:0x13a5
    255a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    255d:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2560:	75 d2                	jne    0x2534
    2562:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2565:	26 c4 bd c0 02       	les    di,DWORD PTR es:[di+0x2c0]
    256a:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    256d:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2570:	31 c0                	xor    ax,ax
    2572:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2575:	eb 03                	jmp    0x257a
    2577:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    257a:	a1 4c 01             	mov    ax,ds:0x14c
    257d:	2d 01 00             	sub    ax,0x1
    2580:	71 05                	jno    0x2587
    2582:	9a 3e 04 94 25       	call   0x2594:0x43e
    2587:	8b d0                	mov    dx,ax
    2589:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    258c:	05 01 00             	add    ax,0x1
    258f:	71 05                	jno    0x2596
    2591:	9a 3e 04 ee 25       	call   0x25ee:0x43e
    2596:	3b c2                	cmp    ax,dx
    2598:	7e 1a                	jle    0x25b4
    259a:	6a 00                	push   0x0
    259c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    259f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    25a2:	06                   	push   es
    25a3:	57                   	push   di
    25a4:	9a 53 13 b2 25       	call   0x25b2:0x1353
    25a9:	89 c7                	mov    di,ax
    25ab:	8e c2                	mov    es,dx
    25ad:	06                   	push   es
    25ae:	57                   	push   di
    25af:	9a a5 13 93 3a       	call   0x3a93:0x13a5
    25b4:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    25b8:	75 bd                	jne    0x2577
    25ba:	6a 00                	push   0x0
    25bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25bf:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    25c4:	06                   	push   es
    25c5:	57                   	push   di
    25c6:	9a d0 1c da 25       	call   0x25da:0x1cd0
    25cb:	6a 00                	push   0x0
    25cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d0:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    25d5:	06                   	push   es
    25d6:	57                   	push   di
    25d7:	9a d0 1c 8e 28       	call   0x288e:0x1cd0
    25dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25df:	06                   	push   es
    25e0:	57                   	push   di
    25e1:	9a 7d 52 10 26       	call   0x2610:0x527d
    25e6:	2d 01 00             	sub    ax,0x1
    25e9:	71 05                	jno    0x25f0
    25eb:	9a 3e 04 1f 26       	call   0x261f:0x43e
    25f0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    25f3:	31 c0                	xor    ax,ax
    25f5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    25f8:	7e 03                	jle    0x25fd
    25fa:	e9 a7 00             	jmp    0x26a4
    25fd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2600:	eb 03                	jmp    0x2605
    2602:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2605:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2608:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    260b:	06                   	push   es
    260c:	57                   	push   di
    260d:	9a 46 52 30 26       	call   0x2630:0x5246
    2612:	52                   	push   dx
    2613:	50                   	push   ax
    2614:	bf 99 03             	mov    di,0x399
    2617:	b8 38 26             	mov    ax,0x2638
    261a:	50                   	push   ax
    261b:	57                   	push   di
    261c:	9a 55 22 3f 26       	call   0x263f:0x2255
    2621:	08 c0                	or     al,al
    2623:	74 74                	je     0x2699
    2625:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    262b:	06                   	push   es
    262c:	57                   	push   di
    262d:	9a 46 52 80 3d       	call   0x3d80:0x5246
    2632:	52                   	push   dx
    2633:	50                   	push   ax
    2634:	bf 99 03             	mov    di,0x399
    2637:	b8 97 26             	mov    ax,0x2697
    263a:	50                   	push   ax
    263b:	57                   	push   di
    263c:	9a 73 22 7c 26       	call   0x267c:0x2273
    2641:	89 c7                	mov    di,ax
    2643:	8e c2                	mov    es,dx
    2645:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2648:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    264b:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2650:	74 47                	je     0x2699
    2652:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2656:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    265a:	74 3d                	je     0x2699
    265c:	a1 06 1e             	mov    ax,ds:0x1e06
    265f:	99                   	cwd
    2660:	8b c8                	mov    cx,ax
    2662:	8b da                	mov    bx,dx
    2664:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2668:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    266c:	09 d2                	or     dx,dx
    266e:	79 07                	jns    0x2677
    2670:	f7 d2                	not    dx
    2672:	f7 d8                	neg    ax
    2674:	83 da ff             	sbb    dx,0xffff
    2677:	71 05                	jno    0x267e
    2679:	9a 3e 04 31 27       	call   0x2731:0x43e
    267e:	3b d3                	cmp    dx,bx
    2680:	7c 0a                	jl     0x268c
    2682:	7f 04                	jg     0x2688
    2684:	3b c1                	cmp    ax,cx
    2686:	76 04                	jbe    0x268c
    2688:	b0 00                	mov    al,0x0
    268a:	eb 02                	jmp    0x268e
    268c:	b0 01                	mov    al,0x1
    268e:	50                   	push   ax
    268f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2692:	06                   	push   es
    2693:	57                   	push   di
    2694:	9a 77 1c b8 26       	call   0x26b8:0x1c77
    2699:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    269c:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    269f:	74 03                	je     0x26a4
    26a1:	e9 5e ff             	jmp    0x2602
    26a4:	8d be fe fe          	lea    di,[bp-0x102]
    26a8:	16                   	push   ss
    26a9:	57                   	push   di
    26aa:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    26ae:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    26b3:	06                   	push   es
    26b4:	57                   	push   di
    26b5:	9a 53 1d c7 26       	call   0x26c7:0x1d53
    26ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26bd:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    26c2:	06                   	push   es
    26c3:	57                   	push   di
    26c4:	9a 8c 1d dd 26       	call   0x26dd:0x1d8c
    26c9:	8d be fe fe          	lea    di,[bp-0x102]
    26cd:	16                   	push   ss
    26ce:	57                   	push   di
    26cf:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    26d3:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    26d8:	06                   	push   es
    26d9:	57                   	push   di
    26da:	9a 53 1d ec 26       	call   0x26ec:0x1d53
    26df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e2:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    26e7:	06                   	push   es
    26e8:	57                   	push   di
    26e9:	9a 8c 1d 02 27       	call   0x2702:0x1d8c
    26ee:	8d be fe fe          	lea    di,[bp-0x102]
    26f2:	16                   	push   ss
    26f3:	57                   	push   di
    26f4:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    26f8:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    26fd:	06                   	push   es
    26fe:	57                   	push   di
    26ff:	9a 53 1d 11 27       	call   0x2711:0x1d53
    2704:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2707:	26 c4 bd 9c 02       	les    di,DWORD PTR es:[di+0x29c]
    270c:	06                   	push   es
    270d:	57                   	push   di
    270e:	9a 8c 1d 27 27       	call   0x2727:0x1d8c
    2713:	8d be fe fe          	lea    di,[bp-0x102]
    2717:	16                   	push   ss
    2718:	57                   	push   di
    2719:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    271d:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    2722:	06                   	push   es
    2723:	57                   	push   di
    2724:	9a 53 1d 94 27       	call   0x2794:0x1d53
    2729:	bf 95 24             	mov    di,0x2495
    272c:	0e                   	push   cs
    272d:	57                   	push   di
    272e:	9a 4c 18 51 27       	call   0x2751:0x184c
    2733:	8d be fe fd          	lea    di,[bp-0x202]
    2737:	16                   	push   ss
    2738:	57                   	push   di
    2739:	9a fe 15 4c 27       	call   0x274c:0x15fe
    273e:	83 ec 08             	sub    sp,0x8
    2741:	89 e3                	mov    bx,sp
    2743:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2747:	90                   	nop
    2748:	9b                   	fwait
    2749:	9a bf 1c 66 27       	call   0x2766:0x1cbf
    274e:	9a 4c 18 5b 27       	call   0x275b:0x184c
    2753:	bf 95 24             	mov    di,0x2495
    2756:	0e                   	push   cs
    2757:	57                   	push   di
    2758:	9a 4c 18 7b 27       	call   0x277b:0x184c
    275d:	8d be fe fc          	lea    di,[bp-0x302]
    2761:	16                   	push   ss
    2762:	57                   	push   di
    2763:	9a fe 15 76 27       	call   0x2776:0x15fe
    2768:	83 ec 08             	sub    sp,0x8
    276b:	89 e3                	mov    bx,sp
    276d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2771:	90                   	nop
    2772:	9b                   	fwait
    2773:	9a e4 1c fc 28       	call   0x28fc:0x1ce4
    2778:	9a 4c 18 85 27       	call   0x2785:0x184c
    277d:	bf 95 24             	mov    di,0x2495
    2780:	0e                   	push   cs
    2781:	57                   	push   di
    2782:	9a 4c 18 0f 28       	call   0x280f:0x184c
    2787:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    278a:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    278f:	06                   	push   es
    2790:	57                   	push   di
    2791:	9a 8c 1d 53 28       	call   0x2853:0x1d8c
    2796:	bf 6a 1e             	mov    di,0x1e6a
    2799:	1e                   	push   ds
    279a:	57                   	push   di
    279b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279e:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    27a3:	06                   	push   es
    27a4:	57                   	push   di
    27a5:	9a 17 30 bc 27       	call   0x27bc:0x3017
    27aa:	bf 78 1e             	mov    di,0x1e78
    27ad:	1e                   	push   ds
    27ae:	57                   	push   di
    27af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b2:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    27b7:	06                   	push   es
    27b8:	57                   	push   di
    27b9:	9a 17 30 d0 27       	call   0x27d0:0x3017
    27be:	bf 86 1e             	mov    di,0x1e86
    27c1:	1e                   	push   ds
    27c2:	57                   	push   di
    27c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c6:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    27cb:	06                   	push   es
    27cc:	57                   	push   di
    27cd:	9a 17 30 e4 27       	call   0x27e4:0x3017
    27d2:	bf 5c 1e             	mov    di,0x1e5c
    27d5:	1e                   	push   ds
    27d6:	57                   	push   di
    27d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27da:	26 c4 bd 38 02       	les    di,DWORD PTR es:[di+0x238]
    27df:	06                   	push   es
    27e0:	57                   	push   di
    27e1:	9a 17 30 f8 27       	call   0x27f8:0x3017
    27e6:	bf 94 1e             	mov    di,0x1e94
    27e9:	1e                   	push   ds
    27ea:	57                   	push   di
    27eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27ee:	26 c4 bd 68 02       	les    di,DWORD PTR es:[di+0x268]
    27f3:	06                   	push   es
    27f4:	57                   	push   di
    27f5:	9a 17 30 ef 3f       	call   0x3fef:0x3017
    27fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fd:	26 c7 85 1a 03 01 00 	mov    WORD PTR es:[di+0x31a],0x1
    2804:	a1 4c 01             	mov    ax,ds:0x14c
    2807:	2d 01 00             	sub    ax,0x1
    280a:	71 05                	jno    0x2811
    280c:	9a 3e 04 43 28       	call   0x2843:0x43e
    2811:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2814:	26 89 85 18 03       	mov    WORD PTR es:[di+0x318],ax
    2819:	06                   	push   es
    281a:	57                   	push   di
    281b:	9a 95 21 30 28       	call   0x2830:0x2195
    2820:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2823:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    2828:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    282d:	9a a8 1d 63 28       	call   0x2863:0x1da8
    2832:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2835:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    283a:	26 03 45 1e          	add    ax,WORD PTR es:[di+0x1e]
    283e:	71 05                	jno    0x2845
    2840:	9a 3e 04 71 28       	call   0x2871:0x43e
    2845:	50                   	push   ax
    2846:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2849:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    284e:	06                   	push   es
    284f:	57                   	push   di
    2850:	9a bf 17 72 29       	call   0x2972:0x17bf
    2855:	ff 76 08             	push   WORD PTR [bp+0x8]
    2858:	ff 76 06             	push   WORD PTR [bp+0x6]
    285b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    285e:	06                   	push   es
    285f:	57                   	push   di
    2860:	9a 66 34 81 28       	call   0x2881:0x3466
    2865:	c9                   	leave
    2866:	ca 08 00             	retf   0x8
    2869:	55                   	push   bp
    286a:	89 e5                	mov    bp,sp
    286c:	31 c0                	xor    ax,ax
    286e:	9a 44 04 9f 28       	call   0x289f:0x444
    2873:	ff 76 08             	push   WORD PTR [bp+0x8]
    2876:	ff 76 06             	push   WORD PTR [bp+0x6]
    2879:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287c:	06                   	push   es
    287d:	57                   	push   di
    287e:	9a 66 34 44 2b       	call   0x2b44:0x3466
    2883:	6a fe                	push   0xfffe
    2885:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2889:	06                   	push   es
    288a:	57                   	push   di
    288b:	9a a9 63 07 3b       	call   0x3b07:0x63a9
    2890:	c9                   	leave
    2891:	ca 08 00             	retf   0x8
    2894:	01 23                	add    WORD PTR [bp+di],sp
    2896:	55                   	push   bp
    2897:	89 e5                	mov    bp,sp
    2899:	b8 02 02             	mov    ax,0x202
    289c:	9a 44 04 ba 28       	call   0x28ba:0x444
    28a1:	81 ec 02 02          	sub    sp,0x202
    28a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28a8:	81 c7 1d 03          	add    di,0x31d
    28ac:	06                   	push   es
    28ad:	57                   	push   di
    28ae:	8d be 00 ff          	lea    di,[bp-0x100]
    28b2:	16                   	push   ss
    28b3:	57                   	push   di
    28b4:	68 ff 00             	push   0xff
    28b7:	9a e7 17 ca 28       	call   0x28ca:0x17e7
    28bc:	bf 94 28             	mov    di,0x2894
    28bf:	0e                   	push   cs
    28c0:	57                   	push   di
    28c1:	8d be 00 ff          	lea    di,[bp-0x100]
    28c5:	16                   	push   ss
    28c6:	57                   	push   di
    28c7:	9a 78 18 e6 28       	call   0x28e6:0x1878
    28cc:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    28d0:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    28d5:	7e 39                	jle    0x2910
    28d7:	8d be 00 ff          	lea    di,[bp-0x100]
    28db:	16                   	push   ss
    28dc:	57                   	push   di
    28dd:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    28e1:	6a 01                	push   0x1
    28e3:	9a 75 19 0e 29       	call   0x290e:0x1975
    28e8:	8d be fe fd          	lea    di,[bp-0x202]
    28ec:	16                   	push   ss
    28ed:	57                   	push   di
    28ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f1:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    28f6:	99                   	cwd
    28f7:	52                   	push   dx
    28f8:	50                   	push   ax
    28f9:	9a a9 08 50 29       	call   0x2950:0x8a9
    28fe:	8d be 00 ff          	lea    di,[bp-0x100]
    2902:	16                   	push   ss
    2903:	57                   	push   di
    2904:	68 ff 00             	push   0xff
    2907:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    290b:	9a 16 19 1e 29       	call   0x291e:0x1916
    2910:	bf 94 28             	mov    di,0x2894
    2913:	0e                   	push   cs
    2914:	57                   	push   di
    2915:	8d be 00 ff          	lea    di,[bp-0x100]
    2919:	16                   	push   ss
    291a:	57                   	push   di
    291b:	9a 78 18 3a 29       	call   0x293a:0x1878
    2920:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    2924:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    2929:	7e 39                	jle    0x2964
    292b:	8d be 00 ff          	lea    di,[bp-0x100]
    292f:	16                   	push   ss
    2930:	57                   	push   di
    2931:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    2935:	6a 01                	push   0x1
    2937:	9a 75 19 62 29       	call   0x2962:0x1975
    293c:	8d be fe fd          	lea    di,[bp-0x202]
    2940:	16                   	push   ss
    2941:	57                   	push   di
    2942:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2945:	26 8b 85 1a 03       	mov    ax,WORD PTR es:[di+0x31a]
    294a:	99                   	cwd
    294b:	52                   	push   dx
    294c:	50                   	push   ax
    294d:	9a a9 08 92 3d       	call   0x3d92:0x8a9
    2952:	8d be 00 ff          	lea    di,[bp-0x100]
    2956:	16                   	push   ss
    2957:	57                   	push   di
    2958:	68 ff 00             	push   0xff
    295b:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    295f:	9a 16 19 80 29       	call   0x2980:0x1916
    2964:	8d be 00 ff          	lea    di,[bp-0x100]
    2968:	16                   	push   ss
    2969:	57                   	push   di
    296a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    296d:	06                   	push   es
    296e:	57                   	push   di
    296f:	9a 8c 1d 4a 34       	call   0x344a:0x1d8c
    2974:	c9                   	leave
    2975:	ca 04 00             	retf   0x4
    2978:	55                   	push   bp
    2979:	89 e5                	mov    bp,sp
    297b:	31 c0                	xor    ax,ax
    297d:	9a 44 04 af 29       	call   0x29af:0x444
    2982:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2985:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    2989:	c9                   	leave
    298a:	ca 14 00             	retf   0x14
    298d:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2991:	ff                   	(bad)
    2992:	7f 00                	jg     0x2994
    2994:	00 eb                	add    bl,ch
    2996:	ff                   	(bad)
    2997:	ff                   	(bad)
    2998:	ff                   	(bad)
    2999:	ff                   	(bad)
    299a:	ff                   	(bad)
    299b:	ff 02                	inc    WORD PTR [bp+si]
    299d:	02 23                	add    ah,BYTE PTR [bp+di]
    299f:	43                   	inc    bx
    29a0:	02 23                	add    ah,BYTE PTR [bp+di]
    29a2:	26 02 23             	add    ah,BYTE PTR es:[bp+di]
    29a5:	41                   	inc    cx
    29a6:	55                   	push   bp
    29a7:	89 e5                	mov    bp,sp
    29a9:	b8 5a 03             	mov    ax,0x35a
    29ac:	9a 44 04 f6 29       	call   0x29f6:0x444
    29b1:	81 ec 5a 03          	sub    sp,0x35a
    29b5:	8c d3                	mov    bx,ss
    29b7:	8e c3                	mov    es,bx
    29b9:	8c db                	mov    bx,ds
    29bb:	fc                   	cld
    29bc:	8d 7e f8             	lea    di,[bp-0x8]
    29bf:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    29c2:	b9 08 00             	mov    cx,0x8
    29c5:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    29c7:	8e db                	mov    ds,bx
    29c9:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    29cc:	8b 56 16             	mov    dx,WORD PTR [bp+0x16]
    29cf:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    29d3:	89 96 f2 fd          	mov    WORD PTR [bp-0x20e],dx
    29d7:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    29da:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    29dd:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    29e1:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    29e5:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    29e8:	ff 76 18             	push   WORD PTR [bp+0x18]
    29eb:	bf 4d 0e             	mov    di,0xe4d
    29ee:	b8 91 2a             	mov    ax,0x2a91
    29f1:	50                   	push   ax
    29f2:	57                   	push   di
    29f3:	9a 73 22 19 2a       	call   0x2a19:0x2273
    29f8:	89 c7                	mov    di,ax
    29fa:	8e c2                	mov    es,dx
    29fc:	89 be a8 fd          	mov    WORD PTR [bp-0x258],di
    2a00:	8c 86 aa fd          	mov    WORD PTR [bp-0x256],es
    2a04:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2a09:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2a0e:	2d 01 00             	sub    ax,0x1
    2a11:	83 da 00             	sbb    dx,0x0
    2a14:	71 05                	jno    0x2a1b
    2a16:	9a 3e 04 84 2a       	call   0x2a84:0x43e
    2a1b:	8b c8                	mov    cx,ax
    2a1d:	8b da                	mov    bx,dx
    2a1f:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2a23:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    2a28:	99                   	cwd
    2a29:	3b d3                	cmp    dx,bx
    2a2b:	7c 0a                	jl     0x2a37
    2a2d:	7f 04                	jg     0x2a33
    2a2f:	3b c1                	cmp    ax,cx
    2a31:	72 04                	jb     0x2a37
    2a33:	b0 00                	mov    al,0x0
    2a35:	eb 02                	jmp    0x2a39
    2a37:	b0 01                	mov    al,0x1
    2a39:	8a d8                	mov    bl,al
    2a3b:	8b 86 ec fd          	mov    ax,WORD PTR [bp-0x214]
    2a3f:	0b 86 ee fd          	or     ax,WORD PTR [bp-0x212]
    2a43:	b0 00                	mov    al,0x0
    2a45:	75 01                	jne    0x2a48
    2a47:	40                   	inc    ax
    2a48:	8a c8                	mov    cl,al
    2a4a:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2a4e:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    2a53:	99                   	cwd
    2a54:	3b 96 f2 fd          	cmp    dx,WORD PTR [bp-0x20e]
    2a58:	75 06                	jne    0x2a60
    2a5a:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    2a5e:	74 04                	je     0x2a64
    2a60:	b0 00                	mov    al,0x0
    2a62:	eb 02                	jmp    0x2a66
    2a64:	b0 01                	mov    al,0x1
    2a66:	22 c1                	and    al,cl
    2a68:	22 c3                	and    al,bl
    2a6a:	08 c0                	or     al,al
    2a6c:	75 03                	jne    0x2a71
    2a6e:	e9 d5 00             	jmp    0x2b46
    2a71:	8b 86 f0 fd          	mov    ax,WORD PTR [bp-0x210]
    2a75:	8b 96 f2 fd          	mov    dx,WORD PTR [bp-0x20e]
    2a79:	05 01 00             	add    ax,0x1
    2a7c:	83 d2 00             	adc    dx,0x0
    2a7f:	71 05                	jno    0x2a86
    2a81:	9a 3e 04 c8 2a       	call   0x2ac8:0x43e
    2a86:	52                   	push   dx
    2a87:	50                   	push   ax
    2a88:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2a8c:	06                   	push   es
    2a8d:	57                   	push   di
    2a8e:	9a 30 6e a5 2a       	call   0x2aa5:0x6e30
    2a93:	50                   	push   ax
    2a94:	ff b6 f2 fd          	push   WORD PTR [bp-0x20e]
    2a98:	ff b6 f0 fd          	push   WORD PTR [bp-0x210]
    2a9c:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2aa0:	06                   	push   es
    2aa1:	57                   	push   di
    2aa2:	9a 30 6e 11 2b       	call   0x2b11:0x6e30
    2aa7:	5a                   	pop    dx
    2aa8:	3b c2                	cmp    ax,dx
    2aaa:	75 03                	jne    0x2aaf
    2aac:	e9 97 00             	jmp    0x2b46
    2aaf:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2ab3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2ab8:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2abd:	2d 01 00             	sub    ax,0x1
    2ac0:	83 da 00             	sbb    dx,0x0
    2ac3:	71 05                	jno    0x2aca
    2ac5:	9a 3e 04 d0 2a       	call   0x2ad0:0x43e
    2aca:	bf 8d 29             	mov    di,0x298d
    2acd:	9a 16 04 e7 2a       	call   0x2ae7:0x416
    2ad2:	89 86 a6 fd          	mov    WORD PTR [bp-0x25a],ax
    2ad6:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2ada:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    2adf:	05 01 00             	add    ax,0x1
    2ae2:	71 05                	jno    0x2ae9
    2ae4:	9a 3e 04 56 2b       	call   0x2b56:0x43e
    2ae9:	3b 86 a6 fd          	cmp    ax,WORD PTR [bp-0x25a]
    2aed:	7f 3a                	jg     0x2b29
    2aef:	89 86 b2 fd          	mov    WORD PTR [bp-0x24e],ax
    2af3:	eb 04                	jmp    0x2af9
    2af5:	ff 86 b2 fd          	inc    WORD PTR [bp-0x24e]
    2af9:	8b 86 b2 fd          	mov    ax,WORD PTR [bp-0x24e]
    2afd:	99                   	cwd
    2afe:	52                   	push   dx
    2aff:	50                   	push   ax
    2b00:	ff b6 f2 fd          	push   WORD PTR [bp-0x20e]
    2b04:	ff b6 f0 fd          	push   WORD PTR [bp-0x210]
    2b08:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2b0c:	06                   	push   es
    2b0d:	57                   	push   di
    2b0e:	9a 30 6e 1d 2b       	call   0x2b1d:0x6e30
    2b13:	50                   	push   ax
    2b14:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2b18:	06                   	push   es
    2b19:	57                   	push   di
    2b1a:	9a c9 70 7c 2b       	call   0x2b7c:0x70c9
    2b1f:	8b 86 b2 fd          	mov    ax,WORD PTR [bp-0x24e]
    2b23:	3b 86 a6 fd          	cmp    ax,WORD PTR [bp-0x25a]
    2b27:	75 cc                	jne    0x2af5
    2b29:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2b2d:	06                   	push   es
    2b2e:	57                   	push   di
    2b2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b32:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    2b36:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    2b39:	ff 76 18             	push   WORD PTR [bp+0x18]
    2b3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b3f:	06                   	push   es
    2b40:	57                   	push   di
    2b41:	9a 66 34 58 33       	call   0x3358:0x3466
    2b46:	8d 7e f8             	lea    di,[bp-0x8]
    2b49:	16                   	push   ss
    2b4a:	57                   	push   di
    2b4b:	8d be c6 fd          	lea    di,[bp-0x23a]
    2b4f:	16                   	push   ss
    2b50:	57                   	push   di
    2b51:	6a 08                	push   0x8
    2b53:	9a 1b 16 68 2b       	call   0x2b68:0x161b
    2b58:	8d 7e f8             	lea    di,[bp-0x8]
    2b5b:	16                   	push   ss
    2b5c:	57                   	push   di
    2b5d:	8d be be fd          	lea    di,[bp-0x242]
    2b61:	16                   	push   ss
    2b62:	57                   	push   di
    2b63:	6a 08                	push   0x8
    2b65:	9a 1b 16 83 2b       	call   0x2b83:0x161b
    2b6a:	ff 86 be fd          	inc    WORD PTR [bp-0x242]
    2b6e:	ff 86 c0 fd          	inc    WORD PTR [bp-0x240]
    2b72:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    2b75:	ff 76 18             	push   WORD PTR [bp+0x18]
    2b78:	bf 4d 0e             	mov    di,0xe4d
    2b7b:	b8 5d 2d             	mov    ax,0x2d5d
    2b7e:	50                   	push   ax
    2b7f:	57                   	push   di
    2b80:	9a 73 22 a8 2b       	call   0x2ba8:0x2273
    2b85:	89 c7                	mov    di,ax
    2b87:	8e c2                	mov    es,dx
    2b89:	89 be a8 fd          	mov    WORD PTR [bp-0x258],di
    2b8d:	8c 86 aa fd          	mov    WORD PTR [bp-0x256],es
    2b91:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2b96:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2b9a:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2b9e:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    2ba2:	bf 95 29             	mov    di,0x2995
    2ba5:	9a 16 04 dc 2b       	call   0x2bdc:0x416
    2baa:	89 86 ac fd          	mov    WORD PTR [bp-0x254],ax
    2bae:	89 96 ae fd          	mov    WORD PTR [bp-0x252],dx
    2bb2:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2bb6:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2bba:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2bbe:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2bc3:	06                   	push   es
    2bc4:	57                   	push   di
    2bc5:	9a 99 20 27 2c       	call   0x2c27:0x2099
    2bca:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2bce:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    2bd2:	26 8b 55 3a          	mov    dx,WORD PTR es:[di+0x3a]
    2bd6:	bf 95 29             	mov    di,0x2995
    2bd9:	9a 16 04 37 2c       	call   0x2c37:0x416
    2bde:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    2be2:	89 96 f6 fd          	mov    WORD PTR [bp-0x20a],dx
    2be6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be9:	26 80 bd 1c 03 00    	cmp    BYTE PTR es:[di+0x31c],0x0
    2bef:	b0 00                	mov    al,0x0
    2bf1:	75 01                	jne    0x2bf4
    2bf3:	40                   	inc    ax
    2bf4:	8a d0                	mov    dl,al
    2bf6:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    2bfa:	b0 00                	mov    al,0x0
    2bfc:	74 01                	je     0x2bff
    2bfe:	40                   	inc    ax
    2bff:	22 c2                	and    al,dl
    2c01:	08 c0                	or     al,al
    2c03:	74 24                	je     0x2c29
    2c05:	c7 86 f4 fd f2 ff    	mov    WORD PTR [bp-0x20c],0xfff2
    2c0b:	c7 86 f6 fd ff ff    	mov    WORD PTR [bp-0x20a],0xffff
    2c11:	6a ff                	push   0xffff
    2c13:	6a f1                	push   0xfff1
    2c15:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2c19:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2c1e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2c22:	06                   	push   es
    2c23:	57                   	push   di
    2c24:	9a df 0f 4d 2c       	call   0x2c4d:0xfdf
    2c29:	8b 86 f4 fd          	mov    ax,WORD PTR [bp-0x20c]
    2c2d:	8b 96 f6 fd          	mov    dx,WORD PTR [bp-0x20a]
    2c31:	bf 95 29             	mov    di,0x2995
    2c34:	9a 16 04 7e 2c       	call   0x2c7e:0x416
    2c39:	52                   	push   dx
    2c3a:	50                   	push   ax
    2c3b:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2c3f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2c44:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2c48:	06                   	push   es
    2c49:	57                   	push   di
    2c4a:	9a 84 16 62 2c       	call   0x2c62:0x1684
    2c4f:	8d 7e f8             	lea    di,[bp-0x8]
    2c52:	16                   	push   ss
    2c53:	57                   	push   di
    2c54:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2c58:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2c5d:	06                   	push   es
    2c5e:	57                   	push   di
    2c5f:	9a e5 1c a4 2c       	call   0x2ca4:0x1ce5
    2c64:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    2c68:	74 20                	je     0x2c8a
    2c6a:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2c6e:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    2c73:	26 8b 95 04 01       	mov    dx,WORD PTR es:[di+0x104]
    2c78:	bf 95 29             	mov    di,0x2995
    2c7b:	9a 16 04 b0 2c       	call   0x2cb0:0x416
    2c80:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    2c84:	89 96 f6 fd          	mov    WORD PTR [bp-0x20a],dx
    2c88:	eb 60                	jmp    0x2cea
    2c8a:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2c8e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2c93:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2c97:	89 be a4 fd          	mov    WORD PTR [bp-0x25c],di
    2c9b:	8c 86 a6 fd          	mov    WORD PTR [bp-0x25a],es
    2c9f:	06                   	push   es
    2ca0:	57                   	push   di
    2ca1:	9a cc 11 c2 2c       	call   0x2cc2:0x11cc
    2ca6:	b9 0a 00             	mov    cx,0xa
    2ca9:	f7 e9                	imul   cx
    2cab:	71 05                	jno    0x2cb2
    2cad:	9a 3e 04 fe 2c       	call   0x2cfe:0x43e
    2cb2:	99                   	cwd
    2cb3:	b9 0c 00             	mov    cx,0xc
    2cb6:	f7 f9                	idiv   cx
    2cb8:	50                   	push   ax
    2cb9:	c4 be a4 fd          	les    di,DWORD PTR [bp-0x25c]
    2cbd:	06                   	push   es
    2cbe:	57                   	push   di
    2cbf:	9a f5 11 cd 2c       	call   0x2ccd:0x11f5
    2cc4:	c4 be a4 fd          	les    di,DWORD PTR [bp-0x25c]
    2cc8:	06                   	push   es
    2cc9:	57                   	push   di
    2cca:	9a 1a 12 db 2c       	call   0x2cdb:0x121a
    2ccf:	24 fe                	and    al,0xfe
    2cd1:	50                   	push   ax
    2cd2:	c4 be a4 fd          	les    di,DWORD PTR [bp-0x25c]
    2cd6:	06                   	push   es
    2cd7:	57                   	push   di
    2cd8:	9a 33 12 e8 2c       	call   0x2ce8:0x1233
    2cdd:	6a 02                	push   0x2
    2cdf:	c4 be a4 fd          	les    di,DWORD PTR [bp-0x25c]
    2ce3:	06                   	push   es
    2ce4:	57                   	push   di
    2ce5:	9a 78 12 14 2d       	call   0x2d14:0x1278
    2cea:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    2cee:	74 3c                	je     0x2d2c
    2cf0:	8b 86 f4 fd          	mov    ax,WORD PTR [bp-0x20c]
    2cf4:	8b 96 f6 fd          	mov    dx,WORD PTR [bp-0x20a]
    2cf8:	bf 95 29             	mov    di,0x2995
    2cfb:	9a 16 04 40 2d       	call   0x2d40:0x416
    2d00:	52                   	push   dx
    2d01:	50                   	push   ax
    2d02:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2d06:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2d0b:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2d0f:	06                   	push   es
    2d10:	57                   	push   di
    2d11:	9a 84 16 2a 2d       	call   0x2d2a:0x1684
    2d16:	8d be be fd          	lea    di,[bp-0x242]
    2d1a:	16                   	push   ss
    2d1b:	57                   	push   di
    2d1c:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2d20:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2d25:	06                   	push   es
    2d26:	57                   	push   di
    2d27:	9a e5 1c 21 2f       	call   0x2f21:0x1ce5
    2d2c:	8d be a8 fc          	lea    di,[bp-0x358]
    2d30:	16                   	push   ss
    2d31:	57                   	push   di
    2d32:	8b 86 f0 fd          	mov    ax,WORD PTR [bp-0x210]
    2d36:	8b 96 f2 fd          	mov    dx,WORD PTR [bp-0x20e]
    2d3a:	bf 8d 29             	mov    di,0x298d
    2d3d:	9a 16 04 51 2d       	call   0x2d51:0x416
    2d42:	50                   	push   ax
    2d43:	8b 86 ec fd          	mov    ax,WORD PTR [bp-0x214]
    2d47:	8b 96 ee fd          	mov    dx,WORD PTR [bp-0x212]
    2d4b:	bf 8d 29             	mov    di,0x298d
    2d4e:	9a 16 04 6b 2d       	call   0x2d6b:0x416
    2d53:	50                   	push   ax
    2d54:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2d58:	06                   	push   es
    2d59:	57                   	push   di
    2d5a:	9a 68 9a 6b 33       	call   0x336b:0x9a68
    2d5f:	8d be f8 fe          	lea    di,[bp-0x108]
    2d63:	16                   	push   ss
    2d64:	57                   	push   di
    2d65:	68 ff 00             	push   0xff
    2d68:	9a e7 17 88 2d       	call   0x2d88:0x17e7
    2d6d:	c7 86 ce fd 01 00    	mov    WORD PTR [bp-0x232],0x1
    2d73:	80 be f8 fe 02       	cmp    BYTE PTR [bp-0x108],0x2
    2d78:	76 38                	jbe    0x2db2
    2d7a:	bf 9d 29             	mov    di,0x299d
    2d7d:	0e                   	push   cs
    2d7e:	57                   	push   di
    2d7f:	8d be f8 fe          	lea    di,[bp-0x108]
    2d83:	16                   	push   ss
    2d84:	57                   	push   di
    2d85:	9a 78 18 9d 2d       	call   0x2d9d:0x1878
    2d8a:	3d 01 00             	cmp    ax,0x1
    2d8d:	75 23                	jne    0x2db2
    2d8f:	8a 86 fb fe          	mov    al,BYTE PTR [bp-0x105]
    2d93:	30 e4                	xor    ah,ah
    2d95:	2d 30 00             	sub    ax,0x30
    2d98:	71 05                	jno    0x2d9f
    2d9a:	9a 3e 04 b0 2d       	call   0x2db0:0x43e
    2d9f:	89 86 ce fd          	mov    WORD PTR [bp-0x232],ax
    2da3:	8d be f8 fe          	lea    di,[bp-0x108]
    2da7:	16                   	push   ss
    2da8:	57                   	push   di
    2da9:	6a 01                	push   0x1
    2dab:	6a 03                	push   0x3
    2dad:	9a 75 19 bf 2d       	call   0x2dbf:0x1975
    2db2:	8b 86 ca fd          	mov    ax,WORD PTR [bp-0x236]
    2db6:	2b 86 c6 fd          	sub    ax,WORD PTR [bp-0x23a]
    2dba:	71 05                	jno    0x2dc1
    2dbc:	9a 3e 04 db 2d       	call   0x2ddb:0x43e
    2dc1:	99                   	cwd
    2dc2:	f7 be ce fd          	idiv   WORD PTR [bp-0x232]
    2dc6:	99                   	cwd
    2dc7:	89 86 d0 fd          	mov    WORD PTR [bp-0x230],ax
    2dcb:	89 96 d2 fd          	mov    WORD PTR [bp-0x22e],dx
    2dcf:	8b 86 ce fd          	mov    ax,WORD PTR [bp-0x232]
    2dd3:	2d 01 00             	sub    ax,0x1
    2dd6:	71 05                	jno    0x2ddd
    2dd8:	9a 3e 04 e7 2d       	call   0x2de7:0x43e
    2ddd:	b9 01 00             	mov    cx,0x1
    2de0:	f7 e9                	imul   cx
    2de2:	71 05                	jno    0x2de9
    2de4:	9a 3e 04 ff 2d       	call   0x2dff:0x43e
    2de9:	99                   	cwd
    2dea:	8b c8                	mov    cx,ax
    2dec:	8b da                	mov    bx,dx
    2dee:	8b 86 d0 fd          	mov    ax,WORD PTR [bp-0x230]
    2df2:	8b 96 d2 fd          	mov    dx,WORD PTR [bp-0x22e]
    2df6:	2b c1                	sub    ax,cx
    2df8:	1b d3                	sbb    dx,bx
    2dfa:	71 05                	jno    0x2e01
    2dfc:	9a 3e 04 1b 2e       	call   0x2e1b:0x43e
    2e01:	89 86 d0 fd          	mov    WORD PTR [bp-0x230],ax
    2e05:	89 96 d2 fd          	mov    WORD PTR [bp-0x22e],dx
    2e09:	8b 86 c6 fd          	mov    ax,WORD PTR [bp-0x23a]
    2e0d:	99                   	cwd
    2e0e:	03 86 d0 fd          	add    ax,WORD PTR [bp-0x230]
    2e12:	13 96 d2 fd          	adc    dx,WORD PTR [bp-0x22e]
    2e16:	71 05                	jno    0x2e1d
    2e18:	9a 3e 04 23 2e       	call   0x2e23:0x43e
    2e1d:	bf 8d 29             	mov    di,0x298d
    2e20:	9a 16 04 66 2e       	call   0x2e66:0x416
    2e25:	89 86 ca fd          	mov    WORD PTR [bp-0x236],ax
    2e29:	8b 86 ce fd          	mov    ax,WORD PTR [bp-0x232]
    2e2d:	89 86 a6 fd          	mov    WORD PTR [bp-0x25a],ax
    2e31:	b8 01 00             	mov    ax,0x1
    2e34:	3b 86 a6 fd          	cmp    ax,WORD PTR [bp-0x25a]
    2e38:	7e 03                	jle    0x2e3d
    2e3a:	e9 60 04             	jmp    0x329d
    2e3d:	89 86 b2 fd          	mov    WORD PTR [bp-0x24e],ax
    2e41:	eb 04                	jmp    0x2e47
    2e43:	ff 86 b2 fd          	inc    WORD PTR [bp-0x24e]
    2e47:	8b 86 b2 fd          	mov    ax,WORD PTR [bp-0x24e]
    2e4b:	3b 86 ce fd          	cmp    ax,WORD PTR [bp-0x232]
    2e4f:	75 07                	jne    0x2e58
    2e51:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e54:	89 86 ca fd          	mov    WORD PTR [bp-0x236],ax
    2e58:	bf a0 29             	mov    di,0x29a0
    2e5b:	0e                   	push   cs
    2e5c:	57                   	push   di
    2e5d:	8d be f8 fe          	lea    di,[bp-0x108]
    2e61:	16                   	push   ss
    2e62:	57                   	push   di
    2e63:	9a 78 18 8d 2e       	call   0x2e8d:0x1878
    2e68:	89 86 b0 fd          	mov    WORD PTR [bp-0x250],ax
    2e6c:	83 be b0 fd 00       	cmp    WORD PTR [bp-0x250],0x0
    2e71:	7e 4e                	jle    0x2ec1
    2e73:	8d be a6 fc          	lea    di,[bp-0x35a]
    2e77:	16                   	push   ss
    2e78:	57                   	push   di
    2e79:	8d be f8 fe          	lea    di,[bp-0x108]
    2e7d:	16                   	push   ss
    2e7e:	57                   	push   di
    2e7f:	6a 01                	push   0x1
    2e81:	8b 86 b0 fd          	mov    ax,WORD PTR [bp-0x250]
    2e85:	2d 01 00             	sub    ax,0x1
    2e88:	71 05                	jno    0x2e8f
    2e8a:	9a 3e 04 93 2e       	call   0x2e93:0x43e
    2e8f:	50                   	push   ax
    2e90:	9a 0b 18 a1 2e       	call   0x2ea1:0x180b
    2e95:	8d be f8 fd          	lea    di,[bp-0x208]
    2e99:	16                   	push   ss
    2e9a:	57                   	push   di
    2e9b:	68 ff 00             	push   0xff
    2e9e:	9a e7 17 b7 2e       	call   0x2eb7:0x17e7
    2ea3:	8d be f8 fe          	lea    di,[bp-0x108]
    2ea7:	16                   	push   ss
    2ea8:	57                   	push   di
    2ea9:	6a 01                	push   0x1
    2eab:	8b 86 b0 fd          	mov    ax,WORD PTR [bp-0x250]
    2eaf:	05 01 00             	add    ax,0x1
    2eb2:	71 05                	jno    0x2eb9
    2eb4:	9a 3e 04 bd 2e       	call   0x2ebd:0x43e
    2eb9:	50                   	push   ax
    2eba:	9a 75 19 d3 2e       	call   0x2ed3:0x1975
    2ebf:	eb 14                	jmp    0x2ed5
    2ec1:	8d be f8 fe          	lea    di,[bp-0x108]
    2ec5:	16                   	push   ss
    2ec6:	57                   	push   di
    2ec7:	8d be f8 fd          	lea    di,[bp-0x208]
    2ecb:	16                   	push   ss
    2ecc:	57                   	push   di
    2ecd:	68 ff 00             	push   0xff
    2ed0:	9a e7 17 ef 2e       	call   0x2eef:0x17e7
    2ed5:	c6 86 b5 fd 67       	mov    BYTE PTR [bp-0x24b],0x67
    2eda:	80 be f8 fd 02       	cmp    BYTE PTR [bp-0x208],0x2
    2edf:	76 2c                	jbe    0x2f0d
    2ee1:	bf a3 29             	mov    di,0x29a3
    2ee4:	0e                   	push   cs
    2ee5:	57                   	push   di
    2ee6:	8d be f8 fd          	lea    di,[bp-0x208]
    2eea:	16                   	push   ss
    2eeb:	57                   	push   di
    2eec:	9a 78 18 0b 2f       	call   0x2f0b:0x1878
    2ef1:	3d 01 00             	cmp    ax,0x1
    2ef4:	75 17                	jne    0x2f0d
    2ef6:	8a 86 fb fd          	mov    al,BYTE PTR [bp-0x205]
    2efa:	88 86 b5 fd          	mov    BYTE PTR [bp-0x24b],al
    2efe:	8d be f8 fd          	lea    di,[bp-0x208]
    2f02:	16                   	push   ss
    2f03:	57                   	push   di
    2f04:	6a 01                	push   0x1
    2f06:	6a 03                	push   0x3
    2f08:	9a 75 19 72 2f       	call   0x2f72:0x1975
    2f0d:	8d be f8 fd          	lea    di,[bp-0x208]
    2f11:	16                   	push   ss
    2f12:	57                   	push   di
    2f13:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2f17:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f1c:	06                   	push   es
    2f1d:	57                   	push   di
    2f1e:	9a 03 20 40 2f       	call   0x2f40:0x2003
    2f23:	99                   	cwd
    2f24:	89 86 e0 fd          	mov    WORD PTR [bp-0x220],ax
    2f28:	89 96 e2 fd          	mov    WORD PTR [bp-0x21e],dx
    2f2c:	8d be f8 fd          	lea    di,[bp-0x208]
    2f30:	16                   	push   ss
    2f31:	57                   	push   di
    2f32:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    2f36:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f3b:	06                   	push   es
    2f3c:	57                   	push   di
    2f3d:	9a 4e 20 10 31       	call   0x3110:0x204e
    2f42:	99                   	cwd
    2f43:	89 86 dc fd          	mov    WORD PTR [bp-0x224],ax
    2f47:	89 96 de fd          	mov    WORD PTR [bp-0x222],dx
    2f4b:	8b 86 c6 fd          	mov    ax,WORD PTR [bp-0x23a]
    2f4f:	99                   	cwd
    2f50:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    2f54:	89 96 ea fd          	mov    WORD PTR [bp-0x216],dx
    2f58:	8b 86 c8 fd          	mov    ax,WORD PTR [bp-0x238]
    2f5c:	99                   	cwd
    2f5d:	89 86 e4 fd          	mov    WORD PTR [bp-0x21c],ax
    2f61:	89 96 e6 fd          	mov    WORD PTR [bp-0x21a],dx
    2f65:	8b 86 ca fd          	mov    ax,WORD PTR [bp-0x236]
    2f69:	2b 86 c6 fd          	sub    ax,WORD PTR [bp-0x23a]
    2f6d:	71 05                	jno    0x2f74
    2f6f:	9a 3e 04 8a 2f       	call   0x2f8a:0x43e
    2f74:	99                   	cwd
    2f75:	89 86 d8 fd          	mov    WORD PTR [bp-0x228],ax
    2f79:	89 96 da fd          	mov    WORD PTR [bp-0x226],dx
    2f7d:	8b 86 cc fd          	mov    ax,WORD PTR [bp-0x234]
    2f81:	2b 86 c8 fd          	sub    ax,WORD PTR [bp-0x238]
    2f85:	71 05                	jno    0x2f8c
    2f87:	9a 3e 04 c8 2f       	call   0x2fc8:0x43e
    2f8c:	99                   	cwd
    2f8d:	89 86 d4 fd          	mov    WORD PTR [bp-0x22c],ax
    2f91:	89 96 d6 fd          	mov    WORD PTR [bp-0x22a],dx
    2f95:	8a 86 b5 fd          	mov    al,BYTE PTR [bp-0x24b]
    2f99:	3c 63                	cmp    al,0x63
    2f9b:	75 50                	jne    0x2fed
    2f9d:	8b 86 e0 fd          	mov    ax,WORD PTR [bp-0x220]
    2fa1:	8b 96 e2 fd          	mov    dx,WORD PTR [bp-0x21e]
    2fa5:	3b 96 da fd          	cmp    dx,WORD PTR [bp-0x226]
    2fa9:	7c 08                	jl     0x2fb3
    2fab:	7f 3e                	jg     0x2feb
    2fad:	3b 86 d8 fd          	cmp    ax,WORD PTR [bp-0x228]
    2fb1:	73 38                	jae    0x2feb
    2fb3:	8b 86 d8 fd          	mov    ax,WORD PTR [bp-0x228]
    2fb7:	8b 96 da fd          	mov    dx,WORD PTR [bp-0x226]
    2fbb:	2b 86 e0 fd          	sub    ax,WORD PTR [bp-0x220]
    2fbf:	1b 96 e2 fd          	sbb    dx,WORD PTR [bp-0x21e]
    2fc3:	71 05                	jno    0x2fca
    2fc5:	9a 3e 04 d2 2f       	call   0x2fd2:0x43e
    2fca:	b9 02 00             	mov    cx,0x2
    2fcd:	31 db                	xor    bx,bx
    2fcf:	9a 70 16 e1 2f       	call   0x2fe1:0x1670
    2fd4:	03 86 e8 fd          	add    ax,WORD PTR [bp-0x218]
    2fd8:	13 96 ea fd          	adc    dx,WORD PTR [bp-0x216]
    2fdc:	71 05                	jno    0x2fe3
    2fde:	9a 3e 04 19 30       	call   0x3019:0x43e
    2fe3:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    2fe7:	89 96 ea fd          	mov    WORD PTR [bp-0x216],dx
    2feb:	eb 62                	jmp    0x304f
    2fed:	3c 64                	cmp    al,0x64
    2fef:	75 41                	jne    0x3032
    2ff1:	8b 86 e0 fd          	mov    ax,WORD PTR [bp-0x220]
    2ff5:	8b 96 e2 fd          	mov    dx,WORD PTR [bp-0x21e]
    2ff9:	3b 96 da fd          	cmp    dx,WORD PTR [bp-0x226]
    2ffd:	7c 08                	jl     0x3007
    2fff:	7f 2f                	jg     0x3030
    3001:	3b 86 d8 fd          	cmp    ax,WORD PTR [bp-0x228]
    3005:	73 29                	jae    0x3030
    3007:	8b 86 ca fd          	mov    ax,WORD PTR [bp-0x236]
    300b:	99                   	cwd
    300c:	2b 86 e0 fd          	sub    ax,WORD PTR [bp-0x220]
    3010:	1b 96 e2 fd          	sbb    dx,WORD PTR [bp-0x21e]
    3014:	71 05                	jno    0x301b
    3016:	9a 3e 04 26 30       	call   0x3026:0x43e
    301b:	2d 02 00             	sub    ax,0x2
    301e:	83 da 00             	sbb    dx,0x0
    3021:	71 05                	jno    0x3028
    3023:	9a 3e 04 45 30       	call   0x3045:0x43e
    3028:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    302c:	89 96 ea fd          	mov    WORD PTR [bp-0x216],dx
    3030:	eb 1d                	jmp    0x304f
    3032:	8b 86 e8 fd          	mov    ax,WORD PTR [bp-0x218]
    3036:	8b 96 ea fd          	mov    dx,WORD PTR [bp-0x216]
    303a:	05 02 00             	add    ax,0x2
    303d:	83 d2 00             	adc    dx,0x0
    3040:	71 05                	jno    0x3047
    3042:	9a 3e 04 7a 30       	call   0x307a:0x43e
    3047:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    304b:	89 96 ea fd          	mov    WORD PTR [bp-0x216],dx
    304f:	8b 86 dc fd          	mov    ax,WORD PTR [bp-0x224]
    3053:	8b 96 de fd          	mov    dx,WORD PTR [bp-0x222]
    3057:	3b 96 d6 fd          	cmp    dx,WORD PTR [bp-0x22a]
    305b:	7c 08                	jl     0x3065
    305d:	7f 3e                	jg     0x309d
    305f:	3b 86 d4 fd          	cmp    ax,WORD PTR [bp-0x22c]
    3063:	73 38                	jae    0x309d
    3065:	8b 86 d4 fd          	mov    ax,WORD PTR [bp-0x22c]
    3069:	8b 96 d6 fd          	mov    dx,WORD PTR [bp-0x22a]
    306d:	2b 86 dc fd          	sub    ax,WORD PTR [bp-0x224]
    3071:	1b 96 de fd          	sbb    dx,WORD PTR [bp-0x222]
    3075:	71 05                	jno    0x307c
    3077:	9a 3e 04 84 30       	call   0x3084:0x43e
    307c:	b9 02 00             	mov    cx,0x2
    307f:	31 db                	xor    bx,bx
    3081:	9a 70 16 93 30       	call   0x3093:0x1670
    3086:	03 86 e4 fd          	add    ax,WORD PTR [bp-0x21c]
    308a:	13 96 e6 fd          	adc    dx,WORD PTR [bp-0x21a]
    308e:	71 05                	jno    0x3095
    3090:	9a 3e 04 ae 30       	call   0x30ae:0x43e
    3095:	89 86 e4 fd          	mov    WORD PTR [bp-0x21c],ax
    3099:	89 96 e6 fd          	mov    WORD PTR [bp-0x21a],dx
    309d:	8d be c6 fd          	lea    di,[bp-0x23a]
    30a1:	16                   	push   ss
    30a2:	57                   	push   di
    30a3:	8d be b6 fd          	lea    di,[bp-0x24a]
    30a7:	16                   	push   ss
    30a8:	57                   	push   di
    30a9:	6a 08                	push   0x8
    30ab:	9a 1b 16 bc 30       	call   0x30bc:0x161b
    30b0:	8b 86 b6 fd          	mov    ax,WORD PTR [bp-0x24a]
    30b4:	05 01 00             	add    ax,0x1
    30b7:	71 05                	jno    0x30be
    30b9:	9a 3e 04 ce 30       	call   0x30ce:0x43e
    30be:	89 86 b6 fd          	mov    WORD PTR [bp-0x24a],ax
    30c2:	8b 86 b8 fd          	mov    ax,WORD PTR [bp-0x248]
    30c6:	05 01 00             	add    ax,0x1
    30c9:	71 05                	jno    0x30d0
    30cb:	9a 3e 04 e8 30       	call   0x30e8:0x43e
    30d0:	89 86 b8 fd          	mov    WORD PTR [bp-0x248],ax
    30d4:	8d be b6 fd          	lea    di,[bp-0x24a]
    30d8:	16                   	push   ss
    30d9:	57                   	push   di
    30da:	8b 86 e8 fd          	mov    ax,WORD PTR [bp-0x218]
    30de:	8b 96 ea fd          	mov    dx,WORD PTR [bp-0x216]
    30e2:	bf 8d 29             	mov    di,0x298d
    30e5:	9a 16 04 f9 30       	call   0x30f9:0x416
    30ea:	50                   	push   ax
    30eb:	8b 86 e4 fd          	mov    ax,WORD PTR [bp-0x21c]
    30ef:	8b 96 e6 fd          	mov    dx,WORD PTR [bp-0x21a]
    30f3:	bf 8d 29             	mov    di,0x298d
    30f6:	9a 16 04 43 31       	call   0x3143:0x416
    30fb:	50                   	push   ax
    30fc:	8d be f8 fd          	lea    di,[bp-0x208]
    3100:	16                   	push   ss
    3101:	57                   	push   di
    3102:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    3106:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    310b:	06                   	push   es
    310c:	57                   	push   di
    310d:	9a 78 1f 30 31       	call   0x3130:0x1f78
    3112:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    3116:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    311b:	89 be a2 fd          	mov    WORD PTR [bp-0x25e],di
    311f:	8c 86 a4 fd          	mov    WORD PTR [bp-0x25c],es
    3123:	6a 00                	push   0x0
    3125:	6a 00                	push   0x0
    3127:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    312b:	06                   	push   es
    312c:	57                   	push   di
    312d:	9a da 13 61 31       	call   0x3161:0x13da
    3132:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    3136:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    313b:	2d 01 00             	sub    ax,0x1
    313e:	71 05                	jno    0x3145
    3140:	9a 3e 04 eb 31       	call   0x31eb:0x43e
    3145:	99                   	cwd
    3146:	3b 96 ee fd          	cmp    dx,WORD PTR [bp-0x212]
    314a:	75 4e                	jne    0x319a
    314c:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    3150:	75 48                	jne    0x319a
    3152:	6a 01                	push   0x1
    3154:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3158:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    315c:	06                   	push   es
    315d:	57                   	push   di
    315e:	9a f5 14 72 31       	call   0x3172:0x14f5
    3163:	6a 00                	push   0x0
    3165:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3169:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    316d:	06                   	push   es
    316e:	57                   	push   di
    316f:	9a b0 14 85 31       	call   0x3185:0x14b0
    3174:	ff b6 c6 fd          	push   WORD PTR [bp-0x23a]
    3178:	ff b6 cc fd          	push   WORD PTR [bp-0x234]
    317c:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3180:	06                   	push   es
    3181:	57                   	push   di
    3182:	9a b8 1d 98 31       	call   0x3198:0x1db8
    3187:	ff b6 ca fd          	push   WORD PTR [bp-0x236]
    318b:	ff b6 cc fd          	push   WORD PTR [bp-0x234]
    318f:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3193:	06                   	push   es
    3194:	57                   	push   di
    3195:	9a 7b 1d c8 31       	call   0x31c8:0x1d7b
    319a:	8b 86 b2 fd          	mov    ax,WORD PTR [bp-0x24e]
    319e:	3b 86 ce fd          	cmp    ax,WORD PTR [bp-0x232]
    31a2:	b0 00                	mov    al,0x0
    31a4:	7f 01                	jg     0x31a7
    31a6:	40                   	inc    ax
    31a7:	8a d0                	mov    dl,al
    31a9:	83 be b2 fd 01       	cmp    WORD PTR [bp-0x24e],0x1
    31ae:	b0 00                	mov    al,0x0
    31b0:	7e 01                	jle    0x31b3
    31b2:	40                   	inc    ax
    31b3:	22 c2                	and    al,dl
    31b5:	08 c0                	or     al,al
    31b7:	74 53                	je     0x320c
    31b9:	6a 00                	push   0x0
    31bb:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    31bf:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    31c3:	06                   	push   es
    31c4:	57                   	push   di
    31c5:	9a b0 14 d9 31       	call   0x31d9:0x14b0
    31ca:	6a 01                	push   0x1
    31cc:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    31d0:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    31d4:	06                   	push   es
    31d5:	57                   	push   di
    31d6:	9a f5 14 f7 31       	call   0x31f7:0x14f5
    31db:	ff b6 c6 fd          	push   WORD PTR [bp-0x23a]
    31df:	8b 86 c8 fd          	mov    ax,WORD PTR [bp-0x238]
    31e3:	2d 01 00             	sub    ax,0x1
    31e6:	71 05                	jno    0x31ed
    31e8:	9a 3e 04 6a 32       	call   0x326a:0x43e
    31ed:	50                   	push   ax
    31ee:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    31f2:	06                   	push   es
    31f3:	57                   	push   di
    31f4:	9a b8 1d 0a 32       	call   0x320a:0x1db8
    31f9:	ff b6 c6 fd          	push   WORD PTR [bp-0x23a]
    31fd:	ff b6 cc fd          	push   WORD PTR [bp-0x234]
    3201:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3205:	06                   	push   es
    3206:	57                   	push   di
    3207:	9a 7b 1d 25 32       	call   0x3225:0x1d7b
    320c:	8b 86 b2 fd          	mov    ax,WORD PTR [bp-0x24e]
    3210:	3b 86 ce fd          	cmp    ax,WORD PTR [bp-0x232]
    3214:	75 48                	jne    0x325e
    3216:	6a 01                	push   0x1
    3218:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    321c:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3220:	06                   	push   es
    3221:	57                   	push   di
    3222:	9a f5 14 36 32       	call   0x3236:0x14f5
    3227:	6a 00                	push   0x0
    3229:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    322d:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3231:	06                   	push   es
    3232:	57                   	push   di
    3233:	9a b0 14 49 32       	call   0x3249:0x14b0
    3238:	ff b6 ca fd          	push   WORD PTR [bp-0x236]
    323c:	ff b6 c8 fd          	push   WORD PTR [bp-0x238]
    3240:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3244:	06                   	push   es
    3245:	57                   	push   di
    3246:	9a b8 1d 5c 32       	call   0x325c:0x1db8
    324b:	ff b6 ca fd          	push   WORD PTR [bp-0x236]
    324f:	ff b6 cc fd          	push   WORD PTR [bp-0x234]
    3253:	c4 be a2 fd          	les    di,DWORD PTR [bp-0x25e]
    3257:	06                   	push   es
    3258:	57                   	push   di
    3259:	9a 7b 1d ea 32       	call   0x32ea:0x1d7b
    325e:	8b 86 ca fd          	mov    ax,WORD PTR [bp-0x236]
    3262:	05 02 00             	add    ax,0x2
    3265:	71 05                	jno    0x326c
    3267:	9a 3e 04 82 32       	call   0x3282:0x43e
    326c:	89 86 c6 fd          	mov    WORD PTR [bp-0x23a],ax
    3270:	8b 86 c6 fd          	mov    ax,WORD PTR [bp-0x23a]
    3274:	99                   	cwd
    3275:	03 86 d0 fd          	add    ax,WORD PTR [bp-0x230]
    3279:	13 96 d2 fd          	adc    dx,WORD PTR [bp-0x22e]
    327d:	71 05                	jno    0x3284
    327f:	9a 3e 04 8a 32       	call   0x328a:0x43e
    3284:	bf 8d 29             	mov    di,0x298d
    3287:	9a 16 04 25 33       	call   0x3325:0x416
    328c:	89 86 ca fd          	mov    WORD PTR [bp-0x236],ax
    3290:	8b 86 b2 fd          	mov    ax,WORD PTR [bp-0x24e]
    3294:	3b 86 a6 fd          	cmp    ax,WORD PTR [bp-0x25a]
    3298:	74 03                	je     0x329d
    329a:	e9 a6 fb             	jmp    0x2e43
    329d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32a0:	26 80 bd 1c 03 00    	cmp    BYTE PTR es:[di+0x31c],0x0
    32a6:	74 6f                	je     0x3317
    32a8:	83 be ee fd 00       	cmp    WORD PTR [bp-0x212],0x0
    32ad:	7f 09                	jg     0x32b8
    32af:	7c 0a                	jl     0x32bb
    32b1:	83 be ec fd 00       	cmp    WORD PTR [bp-0x214],0x0
    32b6:	76 03                	jbe    0x32bb
    32b8:	ff 4e fa             	dec    WORD PTR [bp-0x6]
    32bb:	83 be f2 fd 00       	cmp    WORD PTR [bp-0x20e],0x0
    32c0:	7f 09                	jg     0x32cb
    32c2:	7c 0a                	jl     0x32ce
    32c4:	83 be f0 fd 00       	cmp    WORD PTR [bp-0x210],0x0
    32c9:	76 03                	jbe    0x32ce
    32cb:	ff 4e f8             	dec    WORD PTR [bp-0x8]
    32ce:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    32d1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    32d4:	6a 00                	push   0x0
    32d6:	6a 00                	push   0x0
    32d8:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    32dc:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    32e1:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    32e5:	06                   	push   es
    32e6:	57                   	push   di
    32e7:	9a 84 16 00 33       	call   0x3300:0x1684
    32ec:	6a 03                	push   0x3
    32ee:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    32f2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    32f7:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    32fb:	06                   	push   es
    32fc:	57                   	push   di
    32fd:	9a 7c 17 15 33       	call   0x3315:0x177c
    3302:	8d 7e f8             	lea    di,[bp-0x8]
    3305:	16                   	push   ss
    3306:	57                   	push   di
    3307:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    330b:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3310:	06                   	push   es
    3311:	57                   	push   di
    3312:	9a 30 1d 3b 33       	call   0x333b:0x1d30
    3317:	8b 86 ac fd          	mov    ax,WORD PTR [bp-0x254]
    331b:	8b 96 ae fd          	mov    dx,WORD PTR [bp-0x252]
    331f:	bf 95 29             	mov    di,0x2995
    3322:	9a 16 04 4a 33       	call   0x334a:0x416
    3327:	52                   	push   dx
    3328:	50                   	push   ax
    3329:	c4 be a8 fd          	les    di,DWORD PTR [bp-0x258]
    332d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3332:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3336:	06                   	push   es
    3337:	57                   	push   di
    3338:	9a df 0f 26 54       	call   0x5426:0xfdf
    333d:	c9                   	leave
    333e:	ca 16 00             	retf   0x16
    3341:	55                   	push   bp
    3342:	89 e5                	mov    bp,sp
    3344:	b8 0e 00             	mov    ax,0xe
    3347:	9a 44 04 7a 33       	call   0x337a:0x444
    334c:	83 ec 0e             	sub    sp,0xe
    334f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3352:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3355:	9a 41 1e 27 35       	call   0x3527:0x1e41
    335a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    335d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3360:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3363:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3366:	06                   	push   es
    3367:	57                   	push   di
    3368:	9a 52 6f b7 33       	call   0x33b7:0x6f52
    336d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3370:	26 03 85 fe 00       	add    ax,WORD PTR es:[di+0xfe]
    3375:	71 05                	jno    0x337c
    3377:	9a 3e 04 95 33       	call   0x3395:0x43e
    337c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    337f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3382:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    3387:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    338a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    338d:	2d 01 00             	sub    ax,0x1
    3390:	71 05                	jno    0x3397
    3392:	9a 3e 04 c1 33       	call   0x33c1:0x43e
    3397:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    339a:	31 c0                	xor    ax,ax
    339c:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    339f:	7f 3c                	jg     0x33dd
    33a1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    33a4:	eb 03                	jmp    0x33a9
    33a6:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    33a9:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    33ac:	99                   	cwd
    33ad:	52                   	push   dx
    33ae:	50                   	push   ax
    33af:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    33b2:	06                   	push   es
    33b3:	57                   	push   di
    33b4:	9a 30 6e 28 5c       	call   0x5c28:0x6e30
    33b9:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    33bc:	71 05                	jno    0x33c3
    33be:	9a 3e 04 d0 33       	call   0x33d0:0x43e
    33c3:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    33c6:	26 03 85 06 01       	add    ax,WORD PTR es:[di+0x106]
    33cb:	71 05                	jno    0x33d2
    33cd:	9a 3e 04 03 34       	call   0x3403:0x43e
    33d2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    33d5:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    33d8:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    33db:	75 c9                	jne    0x33a6
    33dd:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    33e0:	99                   	cwd
    33e1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    33e4:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    33e9:	7c 09                	jl     0x33f4
    33eb:	7f 1b                	jg     0x3408
    33ed:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    33f2:	73 14                	jae    0x3408
    33f4:	6a 03                	push   0x3
    33f6:	9a c6 37 00 00       	call   0x0:0x37c6
    33fb:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    33fe:	71 05                	jno    0x3405
    3400:	9a 3e 04 17 34       	call   0x3417:0x43e
    3405:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3408:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    340b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    340e:	26 03 45 20          	add    ax,WORD PTR es:[di+0x20]
    3412:	71 05                	jno    0x3419
    3414:	9a 3e 04 2b 34       	call   0x342b:0x43e
    3419:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    341c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    341f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3422:	26 03 45 1e          	add    ax,WORD PTR es:[di+0x1e]
    3426:	71 05                	jno    0x342d
    3428:	9a 3e 04 6f 34       	call   0x346f:0x43e
    342d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3430:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3433:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3436:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3439:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    343d:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3440:	74 0a                	je     0x344c
    3442:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3445:	06                   	push   es
    3446:	57                   	push   di
    3447:	9a e1 17 60 34       	call   0x3460:0x17e1
    344c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    344f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3453:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    3456:	74 0a                	je     0x3462
    3458:	ff 76 fe             	push   WORD PTR [bp-0x2]
    345b:	06                   	push   es
    345c:	57                   	push   di
    345d:	9a bf 17 a8 34       	call   0x34a8:0x17bf
    3462:	c9                   	leave
    3463:	ca 08 00             	retf   0x8
    3466:	55                   	push   bp
    3467:	89 e5                	mov    bp,sp
    3469:	b8 08 00             	mov    ax,0x8
    346c:	9a 44 04 99 34       	call   0x3499:0x444
    3471:	83 ec 08             	sub    sp,0x8
    3474:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3477:	26 80 bd 1c 03 00    	cmp    BYTE PTR es:[di+0x31c],0x0
    347d:	74 21                	je     0x34a0
    347f:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3484:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3488:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    348b:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3490:	26 2b 45 1e          	sub    ax,WORD PTR es:[di+0x1e]
    3494:	71 05                	jno    0x349b
    3496:	9a 3e 04 bb 34       	call   0x34bb:0x43e
    349b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    349e:	eb 20                	jmp    0x34c0
    34a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34a3:	06                   	push   es
    34a4:	57                   	push   di
    34a5:	9a a9 18 0b 35       	call   0x350b:0x18a9
    34aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ad:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    34b2:	26 2b 45 1e          	sub    ax,WORD PTR es:[di+0x1e]
    34b6:	71 05                	jno    0x34bd
    34b8:	9a 3e 04 e2 37       	call   0x37e2:0x43e
    34bd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    34c0:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    34c3:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    34c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c9:	26 3b 95 86 01       	cmp    dx,WORD PTR es:[di+0x186]
    34ce:	75 07                	jne    0x34d7
    34d0:	26 3b 85 84 01       	cmp    ax,WORD PTR es:[di+0x184]
    34d5:	74 04                	je     0x34db
    34d7:	b0 00                	mov    al,0x0
    34d9:	eb 02                	jmp    0x34dd
    34db:	b0 01                	mov    al,0x1
    34dd:	8a c8                	mov    cl,al
    34df:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    34e2:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    34e5:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    34e8:	75 05                	jne    0x34ef
    34ea:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    34ed:	74 04                	je     0x34f3
    34ef:	b0 00                	mov    al,0x0
    34f1:	eb 02                	jmp    0x34f5
    34f3:	b0 01                	mov    al,0x1
    34f5:	0a c1                	or     al,cl
    34f7:	08 c0                	or     al,al
    34f9:	74 2e                	je     0x3529
    34fb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    34fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3501:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3506:	06                   	push   es
    3507:	57                   	push   di
    3508:	9a bf 17 74 35       	call   0x3574:0x17bf
    350d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3510:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    3515:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    351a:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    351f:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    3524:	9a 41 33 90 35       	call   0x3590:0x3341
    3529:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    352c:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    352f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3532:	26 3b 95 92 01       	cmp    dx,WORD PTR es:[di+0x192]
    3537:	75 07                	jne    0x3540
    3539:	26 3b 85 90 01       	cmp    ax,WORD PTR es:[di+0x190]
    353e:	74 04                	je     0x3544
    3540:	b0 00                	mov    al,0x0
    3542:	eb 02                	jmp    0x3546
    3544:	b0 01                	mov    al,0x1
    3546:	8a c8                	mov    cl,al
    3548:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    354b:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    354e:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    3551:	75 05                	jne    0x3558
    3553:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    3556:	74 04                	je     0x355c
    3558:	b0 00                	mov    al,0x0
    355a:	eb 02                	jmp    0x355e
    355c:	b0 01                	mov    al,0x1
    355e:	0a c1                	or     al,cl
    3560:	08 c0                	or     al,al
    3562:	74 2e                	je     0x3592
    3564:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3567:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    356a:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    356f:	06                   	push   es
    3570:	57                   	push   di
    3571:	9a bf 17 dd 35       	call   0x35dd:0x17bf
    3576:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3579:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    357e:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    3583:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    3588:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    358d:	9a 41 33 f9 35       	call   0x35f9:0x3341
    3592:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3595:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3598:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    359b:	26 3b 95 9e 01       	cmp    dx,WORD PTR es:[di+0x19e]
    35a0:	75 07                	jne    0x35a9
    35a2:	26 3b 85 9c 01       	cmp    ax,WORD PTR es:[di+0x19c]
    35a7:	74 04                	je     0x35ad
    35a9:	b0 00                	mov    al,0x0
    35ab:	eb 02                	jmp    0x35af
    35ad:	b0 01                	mov    al,0x1
    35af:	8a c8                	mov    cl,al
    35b1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    35b4:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    35b7:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    35ba:	75 05                	jne    0x35c1
    35bc:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    35bf:	74 04                	je     0x35c5
    35c1:	b0 00                	mov    al,0x0
    35c3:	eb 02                	jmp    0x35c7
    35c5:	b0 01                	mov    al,0x1
    35c7:	0a c1                	or     al,cl
    35c9:	08 c0                	or     al,al
    35cb:	74 2e                	je     0x35fb
    35cd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    35d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35d3:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    35d8:	06                   	push   es
    35d9:	57                   	push   di
    35da:	9a bf 17 46 36       	call   0x3646:0x17bf
    35df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35e2:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    35e7:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    35ec:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    35f1:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    35f6:	9a 41 33 62 36       	call   0x3662:0x3341
    35fb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    35fe:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3601:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3604:	26 3b 95 aa 01       	cmp    dx,WORD PTR es:[di+0x1aa]
    3609:	75 07                	jne    0x3612
    360b:	26 3b 85 a8 01       	cmp    ax,WORD PTR es:[di+0x1a8]
    3610:	74 04                	je     0x3616
    3612:	b0 00                	mov    al,0x0
    3614:	eb 02                	jmp    0x3618
    3616:	b0 01                	mov    al,0x1
    3618:	8a c8                	mov    cl,al
    361a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    361d:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3620:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    3623:	75 05                	jne    0x362a
    3625:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    3628:	74 04                	je     0x362e
    362a:	b0 00                	mov    al,0x0
    362c:	eb 02                	jmp    0x3630
    362e:	b0 01                	mov    al,0x1
    3630:	0a c1                	or     al,cl
    3632:	08 c0                	or     al,al
    3634:	74 2e                	je     0x3664
    3636:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3639:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    363c:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    3641:	06                   	push   es
    3642:	57                   	push   di
    3643:	9a bf 17 af 36       	call   0x36af:0x17bf
    3648:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    364b:	26 ff b5 aa 01       	push   WORD PTR es:[di+0x1aa]
    3650:	26 ff b5 a8 01       	push   WORD PTR es:[di+0x1a8]
    3655:	26 ff b5 a2 01       	push   WORD PTR es:[di+0x1a2]
    365a:	26 ff b5 a0 01       	push   WORD PTR es:[di+0x1a0]
    365f:	9a 41 33 cb 36       	call   0x36cb:0x3341
    3664:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3667:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    366a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    366d:	26 3b 95 b6 01       	cmp    dx,WORD PTR es:[di+0x1b6]
    3672:	75 07                	jne    0x367b
    3674:	26 3b 85 b4 01       	cmp    ax,WORD PTR es:[di+0x1b4]
    3679:	74 04                	je     0x367f
    367b:	b0 00                	mov    al,0x0
    367d:	eb 02                	jmp    0x3681
    367f:	b0 01                	mov    al,0x1
    3681:	8a c8                	mov    cl,al
    3683:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3686:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3689:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    368c:	75 05                	jne    0x3693
    368e:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    3691:	74 04                	je     0x3697
    3693:	b0 00                	mov    al,0x0
    3695:	eb 02                	jmp    0x3699
    3697:	b0 01                	mov    al,0x1
    3699:	0a c1                	or     al,cl
    369b:	08 c0                	or     al,al
    369d:	74 2e                	je     0x36cd
    369f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    36a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36a5:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    36aa:	06                   	push   es
    36ab:	57                   	push   di
    36ac:	9a bf 17 18 37       	call   0x3718:0x17bf
    36b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b4:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    36b9:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    36be:	26 ff b5 ae 01       	push   WORD PTR es:[di+0x1ae]
    36c3:	26 ff b5 ac 01       	push   WORD PTR es:[di+0x1ac]
    36c8:	9a 41 33 34 37       	call   0x3734:0x3341
    36cd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    36d0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    36d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36d6:	26 3b 95 c2 01       	cmp    dx,WORD PTR es:[di+0x1c2]
    36db:	75 07                	jne    0x36e4
    36dd:	26 3b 85 c0 01       	cmp    ax,WORD PTR es:[di+0x1c0]
    36e2:	74 04                	je     0x36e8
    36e4:	b0 00                	mov    al,0x0
    36e6:	eb 02                	jmp    0x36ea
    36e8:	b0 01                	mov    al,0x1
    36ea:	8a c8                	mov    cl,al
    36ec:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    36ef:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    36f2:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    36f5:	75 05                	jne    0x36fc
    36f7:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    36fa:	74 04                	je     0x3700
    36fc:	b0 00                	mov    al,0x0
    36fe:	eb 02                	jmp    0x3702
    3700:	b0 01                	mov    al,0x1
    3702:	0a c1                	or     al,cl
    3704:	08 c0                	or     al,al
    3706:	74 2e                	je     0x3736
    3708:	ff 76 fe             	push   WORD PTR [bp-0x2]
    370b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    370e:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3713:	06                   	push   es
    3714:	57                   	push   di
    3715:	9a bf 17 81 37       	call   0x3781:0x17bf
    371a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    371d:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    3722:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    3727:	26 ff b5 ba 01       	push   WORD PTR es:[di+0x1ba]
    372c:	26 ff b5 b8 01       	push   WORD PTR es:[di+0x1b8]
    3731:	9a 41 33 9d 37       	call   0x379d:0x3341
    3736:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3739:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    373c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    373f:	26 3b 95 ca 01       	cmp    dx,WORD PTR es:[di+0x1ca]
    3744:	75 07                	jne    0x374d
    3746:	26 3b 85 c8 01       	cmp    ax,WORD PTR es:[di+0x1c8]
    374b:	74 04                	je     0x3751
    374d:	b0 00                	mov    al,0x0
    374f:	eb 02                	jmp    0x3753
    3751:	b0 01                	mov    al,0x1
    3753:	8a c8                	mov    cl,al
    3755:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3758:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    375b:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    375e:	75 05                	jne    0x3765
    3760:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    3763:	74 04                	je     0x3769
    3765:	b0 00                	mov    al,0x0
    3767:	eb 02                	jmp    0x376b
    3769:	b0 01                	mov    al,0x1
    376b:	0a c1                	or     al,cl
    376d:	08 c0                	or     al,al
    376f:	74 2e                	je     0x379f
    3771:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3774:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3777:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    377c:	06                   	push   es
    377d:	57                   	push   di
    377e:	9a bf 17 0d 38       	call   0x380d:0x17bf
    3783:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3786:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    378b:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    3790:	26 ff b5 c6 01       	push   WORD PTR es:[di+0x1c6]
    3795:	26 ff b5 c4 01       	push   WORD PTR es:[di+0x1c4]
    379a:	9a 41 33 b5 3a       	call   0x3ab5:0x3341
    379f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    37a2:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    37a5:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    37a8:	74 03                	je     0x37ad
    37aa:	e9 cd 02             	jmp    0x3a7a
    37ad:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    37b0:	74 03                	je     0x37b5
    37b2:	e9 c5 02             	jmp    0x3a7a
    37b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b8:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    37bd:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    37c0:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    37c3:	6a 03                	push   0x3
    37c5:	9a 12 38 00 00       	call   0x0:0x3812
    37ca:	99                   	cwd
    37cb:	b9 02 00             	mov    cx,0x2
    37ce:	f7 f9                	idiv   cx
    37d0:	8b d0                	mov    dx,ax
    37d2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    37d5:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    37d9:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    37dd:	71 05                	jno    0x37e4
    37df:	9a 3e 04 eb 37       	call   0x37eb:0x43e
    37e4:	03 c2                	add    ax,dx
    37e6:	71 05                	jno    0x37ed
    37e8:	9a 3e 04 2d 38       	call   0x382d:0x43e
    37ed:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    37f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f3:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    37f8:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    37fb:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    37fe:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3803:	74 36                	je     0x383b
    3805:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3808:	06                   	push   es
    3809:	57                   	push   di
    380a:	9a 9d 17 58 38       	call   0x3858:0x179d
    380f:	6a 03                	push   0x3
    3811:	9a 5d 38 00 00       	call   0x0:0x385d
    3816:	99                   	cwd
    3817:	b9 02 00             	mov    cx,0x2
    381a:	f7 f9                	idiv   cx
    381c:	8b d0                	mov    dx,ax
    381e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3821:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3824:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3828:	71 05                	jno    0x382f
    382a:	9a 3e 04 36 38       	call   0x3836:0x43e
    382f:	03 c2                	add    ax,dx
    3831:	71 05                	jno    0x3838
    3833:	9a 3e 04 78 38       	call   0x3878:0x43e
    3838:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    383b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    383e:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    3843:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3846:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3849:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    384e:	74 36                	je     0x3886
    3850:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3853:	06                   	push   es
    3854:	57                   	push   di
    3855:	9a 9d 17 a3 38       	call   0x38a3:0x179d
    385a:	6a 03                	push   0x3
    385c:	9a a8 38 00 00       	call   0x0:0x38a8
    3861:	99                   	cwd
    3862:	b9 02 00             	mov    cx,0x2
    3865:	f7 f9                	idiv   cx
    3867:	8b d0                	mov    dx,ax
    3869:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    386c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    386f:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3873:	71 05                	jno    0x387a
    3875:	9a 3e 04 81 38       	call   0x3881:0x43e
    387a:	03 c2                	add    ax,dx
    387c:	71 05                	jno    0x3883
    387e:	9a 3e 04 c3 38       	call   0x38c3:0x43e
    3883:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3886:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3889:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    388e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3891:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3894:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3899:	74 36                	je     0x38d1
    389b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    389e:	06                   	push   es
    389f:	57                   	push   di
    38a0:	9a 9d 17 ee 38       	call   0x38ee:0x179d
    38a5:	6a 03                	push   0x3
    38a7:	9a f3 38 00 00       	call   0x0:0x38f3
    38ac:	99                   	cwd
    38ad:	b9 02 00             	mov    cx,0x2
    38b0:	f7 f9                	idiv   cx
    38b2:	8b d0                	mov    dx,ax
    38b4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    38b7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    38ba:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    38be:	71 05                	jno    0x38c5
    38c0:	9a 3e 04 cc 38       	call   0x38cc:0x43e
    38c5:	03 c2                	add    ax,dx
    38c7:	71 05                	jno    0x38ce
    38c9:	9a 3e 04 0e 39       	call   0x390e:0x43e
    38ce:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    38d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38d4:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    38d9:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    38dc:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    38df:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    38e4:	74 36                	je     0x391c
    38e6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    38e9:	06                   	push   es
    38ea:	57                   	push   di
    38eb:	9a 9d 17 39 39       	call   0x3939:0x179d
    38f0:	6a 03                	push   0x3
    38f2:	9a 3e 39 00 00       	call   0x0:0x393e
    38f7:	99                   	cwd
    38f8:	b9 02 00             	mov    cx,0x2
    38fb:	f7 f9                	idiv   cx
    38fd:	8b d0                	mov    dx,ax
    38ff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3902:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3905:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3909:	71 05                	jno    0x3910
    390b:	9a 3e 04 17 39       	call   0x3917:0x43e
    3910:	03 c2                	add    ax,dx
    3912:	71 05                	jno    0x3919
    3914:	9a 3e 04 59 39       	call   0x3959:0x43e
    3919:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    391c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    391f:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3924:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3927:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    392a:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    392f:	74 36                	je     0x3967
    3931:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3934:	06                   	push   es
    3935:	57                   	push   di
    3936:	9a 9d 17 98 39       	call   0x3998:0x179d
    393b:	6a 03                	push   0x3
    393d:	9a 9d 39 00 00       	call   0x0:0x399d
    3942:	99                   	cwd
    3943:	b9 02 00             	mov    cx,0x2
    3946:	f7 f9                	idiv   cx
    3948:	8b d0                	mov    dx,ax
    394a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    394d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3950:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3954:	71 05                	jno    0x395b
    3956:	9a 3e 04 62 39       	call   0x3962:0x43e
    395b:	03 c2                	add    ax,dx
    395d:	71 05                	jno    0x3964
    395f:	9a 3e 04 c0 39       	call   0x39c0:0x43e
    3964:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3967:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    396a:	26 80 bd 1c 03 00    	cmp    BYTE PTR es:[di+0x31c],0x0
    3970:	74 66                	je     0x39d8
    3972:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3977:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    397a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    397d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3982:	74 52                	je     0x39d6
    3984:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3987:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    398c:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    3990:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3993:	06                   	push   es
    3994:	57                   	push   di
    3995:	9a 9d 17 d4 39       	call   0x39d4:0x179d
    399a:	6a 02                	push   0x2
    399c:	9a fa 39 00 00       	call   0x0:0x39fa
    39a1:	8b d0                	mov    dx,ax
    39a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a6:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    39ab:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    39af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39b2:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    39b7:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    39bb:	71 05                	jno    0x39c2
    39bd:	9a 3e 04 c9 39       	call   0x39c9:0x43e
    39c2:	03 c2                	add    ax,dx
    39c4:	71 05                	jno    0x39cb
    39c6:	9a 3e 04 15 3a       	call   0x3a15:0x43e
    39cb:	50                   	push   ax
    39cc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    39cf:	06                   	push   es
    39d0:	57                   	push   di
    39d1:	9a 7b 17 f5 39       	call   0x39f5:0x177b
    39d6:	eb 4b                	jmp    0x3a23
    39d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39db:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    39e0:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    39e3:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    39e6:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    39eb:	74 36                	je     0x3a23
    39ed:	ff 76 fc             	push   WORD PTR [bp-0x4]
    39f0:	06                   	push   es
    39f1:	57                   	push   di
    39f2:	9a 9d 17 78 3a       	call   0x3a78:0x179d
    39f7:	6a 03                	push   0x3
    39f9:	9a ff ff 00 00       	call   0x0:0xffff
    39fe:	99                   	cwd
    39ff:	b9 02 00             	mov    cx,0x2
    3a02:	f7 f9                	idiv   cx
    3a04:	8b d0                	mov    dx,ax
    3a06:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a09:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3a0c:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3a10:	71 05                	jno    0x3a17
    3a12:	9a 3e 04 1e 3a       	call   0x3a1e:0x43e
    3a17:	03 c2                	add    ax,dx
    3a19:	71 05                	jno    0x3a20
    3a1b:	9a 3e 04 37 3a       	call   0x3a37:0x43e
    3a20:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a23:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a29:	26 c4 bd 90 02       	les    di,DWORD PTR es:[di+0x290]
    3a2e:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    3a32:	71 05                	jno    0x3a39
    3a34:	9a 3e 04 59 3a       	call   0x3a59:0x43e
    3a39:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a3f:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3a44:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3a47:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3a4a:	26 8b 85 e0 00       	mov    ax,WORD PTR es:[di+0xe0]
    3a4f:	b9 02 00             	mov    cx,0x2
    3a52:	f7 e9                	imul   cx
    3a54:	71 05                	jno    0x3a5b
    3a56:	9a 3e 04 63 3a       	call   0x3a63:0x43e
    3a5b:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3a5e:	71 05                	jno    0x3a65
    3a60:	9a 3e 04 6d 3a       	call   0x3a6d:0x43e
    3a65:	05 06 00             	add    ax,0x6
    3a68:	71 05                	jno    0x3a6f
    3a6a:	9a 3e 04 a1 3a       	call   0x3aa1:0x43e
    3a6f:	50                   	push   ax
    3a70:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3a73:	06                   	push   es
    3a74:	57                   	push   di
    3a75:	9a e1 17 dc 50       	call   0x50dc:0x17e1
    3a7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a7d:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3a83:	b0 00                	mov    al,0x0
    3a85:	75 01                	jne    0x3a88
    3a87:	40                   	inc    ax
    3a88:	50                   	push   ax
    3a89:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3a8e:	06                   	push   es
    3a8f:	57                   	push   di
    3a90:	9a 75 12 43 3c       	call   0x3c43:0x1275
    3a95:	c9                   	leave
    3a96:	ca 08 00             	retf   0x8
    3a99:	55                   	push   bp
    3a9a:	89 e5                	mov    bp,sp
    3a9c:	31 c0                	xor    ax,ax
    3a9e:	9a 44 04 ca 3a       	call   0x3aca:0x444
    3aa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aa6:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    3aab:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
    3ab0:	6a 00                	push   0x0
    3ab2:	9a 1c 08 bf 3a       	call   0x3abf:0x81c
    3ab7:	c9                   	leave
    3ab8:	ca 08 00             	retf   0x8
    3abb:	00 00                	add    BYTE PTR [bx+si],al
    3abd:	7c 3b                	jl     0x3afa
    3abf:	50                   	push   ax
    3ac0:	3b 55 89             	cmp    dx,WORD PTR [di-0x77]
    3ac3:	e5 b8                	in     ax,0xb8
    3ac5:	08 00                	or     BYTE PTR [bx+si],al
    3ac7:	9a 44 04 a4 3b       	call   0x3ba4:0x444
    3acc:	83 ec 08             	sub    sp,0x8
    3acf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad2:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    3ad7:	06                   	push   es
    3ad8:	57                   	push   di
    3ad9:	9a 17 2f e8 53       	call   0x53e8:0x2f17
    3ade:	08 c0                	or     al,al
    3ae0:	75 03                	jne    0x3ae5
    3ae2:	e9 b3 00             	jmp    0x3b98
    3ae5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ae8:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    3aed:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    3af2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3af5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3af8:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    3afd:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    3b02:	06                   	push   es
    3b03:	57                   	push   di
    3b04:	9a d0 3f 1d 3b       	call   0x3b1d:0x3fd0
    3b09:	ff 76 08             	push   WORD PTR [bp+0x8]
    3b0c:	ff 76 06             	push   WORD PTR [bp+0x6]
    3b0f:	b0 01                	mov    al,0x1
    3b11:	50                   	push   ax
    3b12:	b8 b4 25             	mov    ax,0x25b4
    3b15:	ba 45 3b             	mov    dx,0x3b45
    3b18:	52                   	push   dx
    3b19:	50                   	push   ax
    3b1a:	9a 53 25 6e 3b       	call   0x3b6e:0x2553
    3b1f:	a3 04 20             	mov    ds:0x2004,ax
    3b22:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    3b26:	b8 bb 3a             	mov    ax,0x3abb
    3b29:	0e                   	push   cs
    3b2a:	50                   	push   ax
    3b2b:	55                   	push   bp
    3b2c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3b30:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3b34:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    3b38:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3b3b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3b3e:	6a 01                	push   0x1
    3b40:	06                   	push   es
    3b41:	57                   	push   di
    3b42:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    3b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b4a:	06                   	push   es
    3b4b:	57                   	push   di
    3b4c:	b8 99 3a             	mov    ax,0x3a99
    3b4f:	ba 25 3c             	mov    dx,0x3c25
    3b52:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3b55:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    3b5a:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    3b5f:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    3b64:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    3b69:	06                   	push   es
    3b6a:	57                   	push   di
    3b6b:	9a 45 5d 85 3b       	call   0x3b85:0x5d45
    3b70:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3b74:	83 c4 06             	add    sp,0x6
    3b77:	b8 88 3b             	mov    ax,0x3b88
    3b7a:	0e                   	push   cs
    3b7b:	50                   	push   ax
    3b7c:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    3b80:	06                   	push   es
    3b81:	57                   	push   di
    3b82:	9a 1d 5f 96 3b       	call   0x3b96:0x5f1d
    3b87:	cb                   	retf
    3b88:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3b8b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3b8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b91:	06                   	push   es
    3b92:	57                   	push   di
    3b93:	9a d0 3f ae 3b       	call   0x3bae:0x3fd0
    3b98:	c9                   	leave
    3b99:	ca 08 00             	retf   0x8
    3b9c:	55                   	push   bp
    3b9d:	89 e5                	mov    bp,sp
    3b9f:	31 c0                	xor    ax,ax
    3ba1:	9a 44 04 bc 3b       	call   0x3bbc:0x444
    3ba6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ba9:	06                   	push   es
    3baa:	57                   	push   di
    3bab:	9a 56 55 d0 3b       	call   0x3bd0:0x5556
    3bb0:	c9                   	leave
    3bb1:	ca 08 00             	retf   0x8
    3bb4:	55                   	push   bp
    3bb5:	89 e5                	mov    bp,sp
    3bb7:	31 c0                	xor    ax,ax
    3bb9:	9a 44 04 ed 3b       	call   0x3bed:0x444
    3bbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bc1:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3bc7:	75 0b                	jne    0x3bd4
    3bc9:	6a 00                	push   0x0
    3bcb:	06                   	push   es
    3bcc:	57                   	push   di
    3bcd:	9a 14 3a de 3b       	call   0x3bde:0x3a14
    3bd2:	eb 0c                	jmp    0x3be0
    3bd4:	6a 02                	push   0x2
    3bd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bd9:	06                   	push   es
    3bda:	57                   	push   di
    3bdb:	9a 14 3a 80 50       	call   0x5080:0x3a14
    3be0:	c9                   	leave
    3be1:	ca 08 00             	retf   0x8
    3be4:	55                   	push   bp
    3be5:	89 e5                	mov    bp,sp
    3be7:	b8 02 00             	mov    ax,0x2
    3bea:	9a 44 04 fd 3b       	call   0x3bfd:0x444
    3bef:	83 ec 02             	sub    sp,0x2
    3bf2:	a1 4c 01             	mov    ax,ds:0x14c
    3bf5:	2d 01 00             	sub    ax,0x1
    3bf8:	71 05                	jno    0x3bff
    3bfa:	9a 3e 04 34 3c       	call   0x3c34:0x43e
    3bff:	50                   	push   ax
    3c00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c03:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    3c08:	9a 32 3e 01 3d       	call   0x3d01:0x3e32
    3c0d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c10:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3c13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c16:	26 3b 85 18 03       	cmp    ax,WORD PTR es:[di+0x318]
    3c1b:	74 0a                	je     0x3c27
    3c1d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3c20:	06                   	push   es
    3c21:	57                   	push   di
    3c22:	9a be 09 1b 3d       	call   0x3d1b:0x9be
    3c27:	c9                   	leave
    3c28:	ca 08 00             	retf   0x8
    3c2b:	55                   	push   bp
    3c2c:	89 e5                	mov    bp,sp
    3c2e:	b8 08 00             	mov    ax,0x8
    3c31:	9a 44 04 4a 3c       	call   0x3c4a:0x444
    3c36:	83 ec 08             	sub    sp,0x8
    3c39:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c3c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c3f:	bf 94 00             	mov    di,0x94
    3c42:	b8 5d 3c             	mov    ax,0x3c5d
    3c45:	50                   	push   ax
    3c46:	57                   	push   di
    3c47:	9a 55 22 64 3c       	call   0x3c64:0x2255
    3c4c:	08 c0                	or     al,al
    3c4e:	75 03                	jne    0x3c53
    3c50:	e9 ca 00             	jmp    0x3d1d
    3c53:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c56:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c59:	bf 94 00             	mov    di,0x94
    3c5c:	b8 7f 3c             	mov    ax,0x3c7f
    3c5f:	50                   	push   ax
    3c60:	57                   	push   di
    3c61:	9a 73 22 86 3c       	call   0x3c86:0x2273
    3c66:	89 c7                	mov    di,ax
    3c68:	8e c2                	mov    es,dx
    3c6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c6d:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    3c72:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c75:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c78:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c7b:	bf 94 00             	mov    di,0x94
    3c7e:	b8 97 3c             	mov    ax,0x3c97
    3c81:	50                   	push   ax
    3c82:	57                   	push   di
    3c83:	9a 73 22 a7 3c       	call   0x3ca7:0x2273
    3c88:	52                   	push   dx
    3c89:	50                   	push   ax
    3c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c8d:	26 c4 bd c0 02       	les    di,DWORD PTR es:[di+0x2c0]
    3c92:	06                   	push   es
    3c93:	57                   	push   di
    3c94:	9a 2b 16 42 3d       	call   0x3d42:0x162b
    3c99:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c9c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c9f:	05 01 00             	add    ax,0x1
    3ca2:	71 05                	jno    0x3ca9
    3ca4:	9a 3e 04 db 3c       	call   0x3cdb:0x43e
    3ca9:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    3cad:	b0 00                	mov    al,0x0
    3caf:	7d 01                	jge    0x3cb2
    3cb1:	40                   	inc    ax
    3cb2:	8a c8                	mov    cl,al
    3cb4:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3cb8:	b0 00                	mov    al,0x0
    3cba:	7d 01                	jge    0x3cbd
    3cbc:	40                   	inc    ax
    3cbd:	8a d0                	mov    dl,al
    3cbf:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3cc3:	b0 00                	mov    al,0x0
    3cc5:	7c 01                	jl     0x3cc8
    3cc7:	40                   	inc    ax
    3cc8:	22 c2                	and    al,dl
    3cca:	22 c1                	and    al,cl
    3ccc:	08 c0                	or     al,al
    3cce:	74 12                	je     0x3ce2
    3cd0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3cd3:	05 01 00             	add    ax,0x1
    3cd6:	71 05                	jno    0x3cdd
    3cd8:	9a 3e 04 f3 3c       	call   0x3cf3:0x43e
    3cdd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3ce0:	eb 24                	jmp    0x3d06
    3ce2:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3ce6:	75 1e                	jne    0x3d06
    3ce8:	a1 4c 01             	mov    ax,ds:0x14c
    3ceb:	2d 01 00             	sub    ax,0x1
    3cee:	71 05                	jno    0x3cf5
    3cf0:	9a 3e 04 32 3d       	call   0x3d32:0x43e
    3cf5:	50                   	push   ax
    3cf6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf9:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    3cfe:	9a 32 3e ff ff       	call   0xffff:0x3e32
    3d03:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3d06:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3d09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d0c:	26 3b 85 18 03       	cmp    ax,WORD PTR es:[di+0x318]
    3d11:	74 0a                	je     0x3d1d
    3d13:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3d16:	06                   	push   es
    3d17:	57                   	push   di
    3d18:	9a be 09 c7 3d       	call   0x3dc7:0x9be
    3d1d:	c9                   	leave
    3d1e:	ca 08 00             	retf   0x8
    3d21:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    3d25:	ff                   	(bad)
    3d26:	7f 00                	jg     0x3d28
    3d28:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3d2b:	e5 b8                	in     ax,0xb8
    3d2d:	06                   	push   es
    3d2e:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    3d32:	49                   	dec    cx
    3d33:	3d 81 ec             	cmp    ax,0xec81
    3d36:	06                   	push   es
    3d37:	02 ff                	add    bh,bh
    3d39:	76 0c                	jbe    0x3d47
    3d3b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d3e:	bf 94 00             	mov    di,0x94
    3d41:	b8 59 3d             	mov    ax,0x3d59
    3d44:	50                   	push   ax
    3d45:	57                   	push   di
    3d46:	9a 55 22 60 3d       	call   0x3d60:0x2255
    3d4b:	08 c0                	or     al,al
    3d4d:	74 7a                	je     0x3dc9
    3d4f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d52:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d55:	bf 94 00             	mov    di,0x94
    3d58:	b8 ff ff             	mov    ax,0xffff
    3d5b:	50                   	push   ax
    3d5c:	57                   	push   di
    3d5d:	9a 73 22 8d 3d       	call   0x3d8d:0x2273
    3d62:	89 c7                	mov    di,ax
    3d64:	8e c2                	mov    es,dx
    3d66:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3d69:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3d6c:	8d be fa fd          	lea    di,[bp-0x206]
    3d70:	16                   	push   ss
    3d71:	57                   	push   di
    3d72:	8d be fa fe          	lea    di,[bp-0x106]
    3d76:	16                   	push   ss
    3d77:	57                   	push   di
    3d78:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d7b:	06                   	push   es
    3d7c:	57                   	push   di
    3d7d:	9a 2a 51 ff ff       	call   0xffff:0x512a
    3d82:	83 c4 04             	add    sp,0x4
    3d85:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    3d89:	50                   	push   ax
    3d8a:	9a e9 18 9a 3d       	call   0x3d9a:0x18e9
    3d8f:	9a da 08 ff ff       	call   0xffff:0x8da
    3d94:	bf 21 3d             	mov    di,0x3d21
    3d97:	9a 16 04 cb 3f       	call   0x3fcb:0x416
    3d9c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3d9f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3da2:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    3da6:	b0 00                	mov    al,0x0
    3da8:	7f 01                	jg     0x3dab
    3daa:	40                   	inc    ax
    3dab:	8a d0                	mov    dl,al
    3dad:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3db1:	b0 00                	mov    al,0x0
    3db3:	7e 01                	jle    0x3db6
    3db5:	40                   	inc    ax
    3db6:	22 c2                	and    al,dl
    3db8:	08 c0                	or     al,al
    3dba:	74 0d                	je     0x3dc9
    3dbc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3dbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dc2:	06                   	push   es
    3dc3:	57                   	push   di
    3dc4:	9a 88 0a 55 41       	call   0x4155:0xa88
    3dc9:	c9                   	leave
    3dca:	ca 08 00             	retf   0x8
    3dcd:	01 00                	add    WORD PTR [bx+si],ax
    3dcf:	00 00                	add    BYTE PTR [bx+si],al
    3dd1:	08 00                	or     BYTE PTR [bx+si],al
    3dd3:	00 00                	add    BYTE PTR [bx+si],al
    3dd5:	13 43 6f             	adc    ax,WORD PTR [bp+di+0x6f]
    3dd8:	6e                   	outs   dx,BYTE PTR ds:[si]
    3dd9:	63 75 72             	arpl   WORD PTR [di+0x72],si
    3ddc:	72 65                	jb     0x3e43
    3dde:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ddf:	74 73                	je     0x3e54
    3de1:	50                   	push   ax
    3de2:	72 6f                	jb     0x3e53
    3de4:	64 75 69             	fs jne 0x3e50
    3de7:	74 31                	je     0x3e1a
    3de9:	13 43 6f             	adc    ax,WORD PTR [bp+di+0x6f]
    3dec:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ded:	63 75 72             	arpl   WORD PTR [di+0x72],si
    3df0:	72 65                	jb     0x3e57
    3df2:	6e                   	outs   dx,BYTE PTR ds:[si]
    3df3:	74 73                	je     0x3e68
    3df5:	50                   	push   ax
    3df6:	72 6f                	jb     0x3e67
    3df8:	64 75 69             	fs jne 0x3e64
    3dfb:	74 32                	je     0x3e2f
    3dfd:	15 43 6f             	adc    ax,0x6f43
    3e00:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e01:	63 75 72             	arpl   WORD PTR [di+0x72],si
    3e04:	72 65                	jb     0x3e6b
    3e06:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e07:	74 73                	je     0x3e7c
    3e09:	50                   	push   ax
    3e0a:	61                   	popa
    3e0b:	72 74                	jb     0x3e81
    3e0d:	4d                   	dec    bp
    3e0e:	61                   	popa
    3e0f:	72 63                	jb     0x3e74
    3e11:	68 65 13             	push   0x1365
    3e14:	43                   	inc    bx
    3e15:	6f                   	outs   dx,WORD PTR ds:[si]
    3e16:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e17:	63 75 72             	arpl   WORD PTR [di+0x72],si
    3e1a:	72 65                	jb     0x3e81
    3e1c:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e1d:	74 73                	je     0x3e92
    3e1f:	52                   	push   dx
    3e20:	65 73 75             	gs jae 0x3e98
    3e23:	6c                   	ins    BYTE PTR es:[di],dx
    3e24:	74 61                	je     0x3e87
    3e26:	74 14                	je     0x3e3c
    3e28:	43                   	inc    bx
    3e29:	6f                   	outs   dx,WORD PTR ds:[si]
    3e2a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e2b:	63 75 72             	arpl   WORD PTR [di+0x72],si
    3e2e:	72 65                	jb     0x3e95
    3e30:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e31:	74 73                	je     0x3ea6
    3e33:	53                   	push   bx
    3e34:	74 72                	je     0x3ea8
    3e36:	75 63                	jne    0x3e9b
    3e38:	74 75                	je     0x3eaf
    3e3a:	72 65                	jb     0x3ea1
    3e3c:	0f 53 69 74          	rcpps  xmm5,XMMWORD PTR [bx+di+0x74]
    3e40:	75 61                	jne    0x3ea3
    3e42:	74 69                	je     0x3ead
    3e44:	6f                   	outs   dx,WORD PTR ds:[si]
    3e45:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e46:	4d                   	dec    bp
    3e47:	61                   	popa
    3e48:	72 63                	jb     0x3ead
    3e4a:	68 65 0f             	push   0xf65
    3e4d:	41                   	inc    cx
    3e4e:	75 74                	jne    0x3ec4
    3e50:	6f                   	outs   dx,WORD PTR ds:[si]
    3e51:	50                   	push   ax
    3e52:	65 72 66             	gs jb  0x3ebb
    3e55:	6f                   	outs   dx,WORD PTR ds:[si]
    3e56:	72 6d                	jb     0x3ec5
    3e58:	61                   	popa
    3e59:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e5a:	63 65 01             	arpl   WORD PTR [di+0x1],sp
    3e5d:	00 00                	add    BYTE PTR [bx+si],al
    3e5f:	00 02                	add    BYTE PTR [bp+si],al
    3e61:	00 00                	add    BYTE PTR [bx+si],al
    3e63:	00 04                	add    BYTE PTR [si],al
    3e65:	50                   	push   ax
    3e66:	72 69                	jb     0x3ed1
    3e68:	78 09                	js     0x3e73
    3e6a:	50                   	push   ax
    3e6b:	75 62                	jne    0x3ecf
    3e6d:	6c                   	ins    BYTE PTR es:[di],dx
    3e6e:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    3e73:	11 41 63             	adc    WORD PTR [bx+di+0x63],ax
    3e76:	74 69                	je     0x3ee1
    3e78:	6f                   	outs   dx,WORD PTR ds:[si]
    3e79:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e7a:	43                   	inc    bx
    3e7b:	6f                   	outs   dx,WORD PTR ds:[si]
    3e7c:	6d                   	ins    WORD PTR es:[di],dx
    3e7d:	6d                   	ins    WORD PTR es:[di],dx
    3e7e:	65 72 63             	gs jb  0x3ee4
    3e81:	69 61 6c 65 10       	imul   sp,WORD PTR [bx+di+0x6c],0x1065
    3e86:	56                   	push   si
    3e87:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e89:	64 65 75 72          	fs gs jne 0x3eff
    3e8d:	73 41                	jae    0x3ed0
    3e8f:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    3e95:	73 11                	jae    0x3ea8
    3e97:	44                   	inc    sp
    3e98:	75 72                	jne    0x3f0c
    3e9a:	65 65 43             	gs gs inc bx
    3e9d:	72 65                	jb     0x3f04
    3e9f:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    3ea5:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3ea7:	74 06                	je     0x3eaf
    3ea9:	56                   	push   si
    3eaa:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3eac:	74 65                	je     0x3f13
    3eae:	73 10                	jae    0x3ec0
    3eb0:	56                   	push   si
    3eb1:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3eb3:	74 65                	je     0x3f1a
    3eb5:	73 53                	jae    0x3f0a
    3eb7:	6f                   	outs   dx,WORD PTR ds:[si]
    3eb8:	6c                   	ins    BYTE PTR es:[di],dx
    3eb9:	64 65 65 73 51       	fs gs gs jae 0x3f0f
    3ebe:	74 65                	je     0x3f25
    3ec0:	0c 56                	or     al,0x56
    3ec2:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3ec4:	74 65                	je     0x3f2b
    3ec6:	73 53                	jae    0x3f1b
    3ec8:	70 65                	jo     0x3f2f
    3eca:	51                   	push   cx
    3ecb:	74 65                	je     0x3f32
    3ecd:	0b 56 61             	or     dx,WORD PTR [bp+0x61]
    3ed0:	6c                   	ins    BYTE PTR es:[di],dx
    3ed1:	65 75 72             	gs jne 0x3f46
    3ed4:	53                   	push   bx
    3ed5:	74 6f                	je     0x3f46
    3ed7:	63 6b 07             	arpl   WORD PTR [bp+di+0x7],bp
    3eda:	44                   	inc    sp
    3edb:	65 6d                	gs ins WORD PTR es:[di],dx
    3edd:	61                   	popa
    3ede:	6e                   	outs   dx,BYTE PTR ds:[si]
    3edf:	64 65 14 44          	fs gs adc al,0x44
    3ee3:	65 6d                	gs ins WORD PTR es:[di],dx
    3ee5:	61                   	popa
    3ee6:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ee7:	64 65 4e             	fs gs dec si
    3eea:	6f                   	outs   dx,WORD PTR ds:[si]
    3eeb:	6e                   	outs   dx,BYTE PTR ds:[si]
    3eec:	53                   	push   bx
    3eed:	61                   	popa
    3eee:	74 69                	je     0x3f59
    3ef0:	73 66                	jae    0x3f58
    3ef2:	61                   	popa
    3ef3:	69 74 65 0a 50       	imul   si,WORD PTR [si+0x65],0x500a
    3ef8:	61                   	popa
    3ef9:	72 74                	jb     0x3f6f
    3efb:	4d                   	dec    bp
    3efc:	61                   	popa
    3efd:	72 63                	jb     0x3f62
    3eff:	68 65 11             	push   0x1165
    3f02:	56                   	push   si
    3f03:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3f05:	74 65                	je     0x3f6c
    3f07:	73 53                	jae    0x3f5c
    3f09:	6f                   	outs   dx,WORD PTR ds:[si]
    3f0a:	6c                   	ins    BYTE PTR es:[di],dx
    3f0b:	64 65 65 73 50       	fs gs gs jae 0x3f60
    3f10:	72 69                	jb     0x3f7b
    3f12:	78 0d                	js     0x3f21
    3f14:	56                   	push   si
    3f15:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3f17:	74 65                	je     0x3f7e
    3f19:	73 53                	jae    0x3f6e
    3f1b:	70 65                	jo     0x3f82
    3f1d:	50                   	push   ax
    3f1e:	72 69                	jb     0x3f89
    3f20:	78 0b                	js     0x3f2d
    3f22:	48                   	dec    ax
    3f23:	65 75 72             	gs jne 0x3f98
    3f26:	65 73 53             	gs jae 0x3f7c
    3f29:	75 70                	jne    0x3f9b
    3f2b:	50                   	push   ax
    3f2c:	63 0b                	arpl   WORD PTR [bp+di],cx
    3f2e:	52                   	push   dx
    3f2f:	65 73 75             	gs jae 0x3fa7
    3f32:	6c                   	ins    BYTE PTR es:[di],dx
    3f33:	74 61                	je     0x3f96
    3f35:	74 4e                	je     0x3f85
    3f37:	65 74 05             	gs je  0x3f3f
    3f3a:	49                   	dec    cx
    3f3b:	6d                   	ins    WORD PTR es:[di],dx
    3f3c:	70 6f                	jo     0x3fad
    3f3e:	74 0d                	je     0x3f4d
    3f40:	43                   	inc    bx
    3f41:	61                   	popa
    3f42:	70 69                	jo     0x3fad
    3f44:	74 61                	je     0x3fa7
    3f46:	6c                   	ins    BYTE PTR es:[di],dx
    3f47:	53                   	push   bx
    3f48:	6f                   	outs   dx,WORD PTR ds:[si]
    3f49:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    3f4c:	6c                   	ins    BYTE PTR es:[di],dx
    3f4d:	15 49 6d             	adc    ax,0x6d49
    3f50:	6d                   	ins    WORD PTR es:[di],dx
    3f51:	6f                   	outs   dx,WORD PTR ds:[si]
    3f52:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    3f55:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    3f5a:	6f                   	outs   dx,WORD PTR ds:[si]
    3f5b:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f5c:	73 42                	jae    0x3fa0
    3f5e:	72 75                	jb     0x3fd5
    3f60:	74 65                	je     0x3fc7
    3f62:	73 07                	jae    0x3f6b
    3f64:	45                   	inc    bp
    3f65:	6d                   	ins    WORD PTR es:[di],dx
    3f66:	70 72                	jo     0x3fda
    3f68:	75 6e                	jne    0x3fd8
    3f6a:	74 0c                	je     0x3f78
    3f6c:	46                   	inc    si
    3f6d:	6f                   	outs   dx,WORD PTR ds:[si]
    3f6e:	75 72                	jne    0x3fe2
    3f70:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f71:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    3f76:	72 73                	jb     0x3feb
    3f78:	0d 44 65             	or     ax,0x6544
    3f7b:	63 6f 75             	arpl   WORD PTR [bx+0x75],bp
    3f7e:	76 65                	jbe    0x3fe5
    3f80:	72 74                	jb     0x3ff6
    3f82:	41                   	inc    cx
    3f83:	75 74                	jne    0x3ff9
    3f85:	6f                   	outs   dx,WORD PTR ds:[si]
    3f86:	0e                   	push   cs
    3f87:	44                   	inc    sp
    3f88:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3f8c:	76 65                	jbe    0x3ff3
    3f8e:	72 74                	jb     0x4004
    3f90:	4e                   	dec    si
    3f91:	61                   	popa
    3f92:	75 74                	jne    0x4008
    3f94:	6f                   	outs   dx,WORD PTR ds:[si]
    3f95:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    3f98:	73 65                	jae    0x3fff
    3f9a:	72 76                	jb     0x4012
    3f9c:	65 73 00             	gs jae 0x3f9f
    3f9f:	00 c8                	add    al,cl
    3fa1:	42                   	inc    dx
    3fa2:	0e                   	push   cs
    3fa3:	44                   	inc    sp
    3fa4:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3fa8:	76 65                	jbe    0x400f
    3faa:	72 74                	jb     0x4020
    3fac:	4e                   	dec    si
    3fad:	41                   	inc    cx
    3fae:	75 74                	jne    0x4024
    3fb0:	6f                   	outs   dx,WORD PTR ds:[si]
    3fb1:	0c 56                	or     al,0x56
    3fb3:	6f                   	outs   dx,WORD PTR ds:[si]
    3fb4:	6c                   	ins    BYTE PTR es:[di],dx
    3fb5:	75 6d                	jne    0x4024
    3fb7:	65 4d                	gs dec bp
    3fb9:	61                   	popa
    3fba:	72 63                	jb     0x401f
    3fbc:	68 65 00             	push   0x65
    3fbf:	00 00                	add    BYTE PTR [bx+si],al
    3fc1:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3fc4:	e5 b8                	in     ax,0xb8
    3fc6:	58                   	pop    ax
    3fc7:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    3fcb:	61                   	popa
    3fcc:	41                   	inc    cx
    3fcd:	83 ec 58             	sub    sp,0x58
    3fd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fd3:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    3fd8:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    3fdb:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    3fde:	06                   	push   es
    3fdf:	57                   	push   di
    3fe0:	9a d2 31 05 40       	call   0x4005:0x31d2
    3fe5:	6a 01                	push   0x1
    3fe7:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    3fea:	06                   	push   es
    3feb:	57                   	push   di
    3fec:	9a fb 2f fb 3f       	call   0x3ffb:0x2ffb
    3ff1:	6a 00                	push   0x0
    3ff3:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    3ff6:	06                   	push   es
    3ff7:	57                   	push   di
    3ff8:	9a d2 2e 26 40       	call   0x4026:0x2ed2
    3ffd:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4000:	06                   	push   es
    4001:	57                   	push   di
    4002:	9a bf 31 1a 40       	call   0x401a:0x31bf
    4007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    400a:	26 c4 bd 38 02       	les    di,DWORD PTR es:[di+0x238]
    400f:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    4012:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    4015:	06                   	push   es
    4016:	57                   	push   di
    4017:	9a d2 31 3c 40       	call   0x403c:0x31d2
    401c:	6a 01                	push   0x1
    401e:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4021:	06                   	push   es
    4022:	57                   	push   di
    4023:	9a fb 2f 32 40       	call   0x4032:0x2ffb
    4028:	6a 00                	push   0x0
    402a:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    402d:	06                   	push   es
    402e:	57                   	push   di
    402f:	9a d2 2e 5d 40       	call   0x405d:0x2ed2
    4034:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4037:	06                   	push   es
    4038:	57                   	push   di
    4039:	9a bf 31 51 40       	call   0x4051:0x31bf
    403e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4041:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    4046:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    4049:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    404c:	06                   	push   es
    404d:	57                   	push   di
    404e:	9a d2 31 73 40       	call   0x4073:0x31d2
    4053:	6a 01                	push   0x1
    4055:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4058:	06                   	push   es
    4059:	57                   	push   di
    405a:	9a fb 2f 69 40       	call   0x4069:0x2ffb
    405f:	6a 00                	push   0x0
    4061:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4064:	06                   	push   es
    4065:	57                   	push   di
    4066:	9a d2 2e 94 40       	call   0x4094:0x2ed2
    406b:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    406e:	06                   	push   es
    406f:	57                   	push   di
    4070:	9a bf 31 88 40       	call   0x4088:0x31bf
    4075:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4078:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    407d:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    4080:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    4083:	06                   	push   es
    4084:	57                   	push   di
    4085:	9a d2 31 aa 40       	call   0x40aa:0x31d2
    408a:	6a 01                	push   0x1
    408c:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    408f:	06                   	push   es
    4090:	57                   	push   di
    4091:	9a fb 2f a0 40       	call   0x40a0:0x2ffb
    4096:	6a 00                	push   0x0
    4098:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    409b:	06                   	push   es
    409c:	57                   	push   di
    409d:	9a d2 2e cb 40       	call   0x40cb:0x2ed2
    40a2:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    40a5:	06                   	push   es
    40a6:	57                   	push   di
    40a7:	9a bf 31 bf 40       	call   0x40bf:0x31bf
    40ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40af:	26 c4 bd 68 02       	les    di,DWORD PTR es:[di+0x268]
    40b4:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    40b7:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    40ba:	06                   	push   es
    40bb:	57                   	push   di
    40bc:	9a d2 31 e1 40       	call   0x40e1:0x31d2
    40c1:	6a 01                	push   0x1
    40c3:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    40c6:	06                   	push   es
    40c7:	57                   	push   di
    40c8:	9a fb 2f d7 40       	call   0x40d7:0x2ffb
    40cd:	6a 00                	push   0x0
    40cf:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    40d2:	06                   	push   es
    40d3:	57                   	push   di
    40d4:	9a d2 2e 47 41       	call   0x4147:0x2ed2
    40d9:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    40dc:	06                   	push   es
    40dd:	57                   	push   di
    40de:	9a bf 31 82 41       	call   0x4182:0x31bf
    40e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e6:	81 c7 1d 04          	add    di,0x41d
    40ea:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    40ed:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    40f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40f3:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    40f8:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    40fb:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    40fe:	a1 4e 01             	mov    ax,ds:0x14e
    4101:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4104:	b8 01 00             	mov    ax,0x1
    4107:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    410a:	7e 03                	jle    0x410f
    410c:	e9 65 01             	jmp    0x4274
    410f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4112:	eb 03                	jmp    0x4117
    4114:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4117:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    411a:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    411f:	99                   	cwd
    4120:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    4123:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    4126:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    412a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    412d:	99                   	cwd
    412e:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4131:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    4134:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    4138:	8d 7e d0             	lea    di,[bp-0x30]
    413b:	16                   	push   ss
    413c:	57                   	push   di
    413d:	6a 01                	push   0x1
    413f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4142:	06                   	push   es
    4143:	57                   	push   di
    4144:	9a 95 28 e3 42       	call   0x42e3:0x2895
    4149:	08 c0                	or     al,al
    414b:	75 0a                	jne    0x4157
    414d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4150:	06                   	push   es
    4151:	57                   	push   di
    4152:	9a 33 07 f1 42       	call   0x42f1:0x733
    4157:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    415a:	99                   	cwd
    415b:	bf cd 3d             	mov    di,0x3dcd
    415e:	9a 16 04 fd 42       	call   0x42fd:0x416
    4163:	6b c0 07             	imul   ax,ax,0x7
    4166:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4169:	03 f8                	add    di,ax
    416b:	81 c7 f9 ff          	add    di,0xfff9
    416f:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    4172:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    4175:	bf d5 3d             	mov    di,0x3dd5
    4178:	0e                   	push   cs
    4179:	57                   	push   di
    417a:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    417d:	06                   	push   es
    417e:	57                   	push   di
    417f:	9a 9b 3b a4 41       	call   0x41a4:0x3b9b
    4184:	89 c7                	mov    di,ax
    4186:	8e c2                	mov    es,dx
    4188:	06                   	push   es
    4189:	57                   	push   di
    418a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    418d:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4191:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4194:	26 88 05             	mov    BYTE PTR es:[di],al
    4197:	bf e9 3d             	mov    di,0x3de9
    419a:	0e                   	push   cs
    419b:	57                   	push   di
    419c:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    419f:	06                   	push   es
    41a0:	57                   	push   di
    41a1:	9a 9b 3b c7 41       	call   0x41c7:0x3b9b
    41a6:	89 c7                	mov    di,ax
    41a8:	8e c2                	mov    es,dx
    41aa:	06                   	push   es
    41ab:	57                   	push   di
    41ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41af:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    41b3:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    41b6:	26 88 45 01          	mov    BYTE PTR es:[di+0x1],al
    41ba:	bf fd 3d             	mov    di,0x3dfd
    41bd:	0e                   	push   cs
    41be:	57                   	push   di
    41bf:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    41c2:	06                   	push   es
    41c3:	57                   	push   di
    41c4:	9a 9b 3b ea 41       	call   0x41ea:0x3b9b
    41c9:	89 c7                	mov    di,ax
    41cb:	8e c2                	mov    es,dx
    41cd:	06                   	push   es
    41ce:	57                   	push   di
    41cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41d2:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    41d6:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    41d9:	26 88 45 02          	mov    BYTE PTR es:[di+0x2],al
    41dd:	bf 13 3e             	mov    di,0x3e13
    41e0:	0e                   	push   cs
    41e1:	57                   	push   di
    41e2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    41e5:	06                   	push   es
    41e6:	57                   	push   di
    41e7:	9a 9b 3b 0d 42       	call   0x420d:0x3b9b
    41ec:	89 c7                	mov    di,ax
    41ee:	8e c2                	mov    es,dx
    41f0:	06                   	push   es
    41f1:	57                   	push   di
    41f2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41f5:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    41f9:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    41fc:	26 88 45 03          	mov    BYTE PTR es:[di+0x3],al
    4200:	bf 27 3e             	mov    di,0x3e27
    4203:	0e                   	push   cs
    4204:	57                   	push   di
    4205:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4208:	06                   	push   es
    4209:	57                   	push   di
    420a:	9a 9b 3b 30 42       	call   0x4230:0x3b9b
    420f:	89 c7                	mov    di,ax
    4211:	8e c2                	mov    es,dx
    4213:	06                   	push   es
    4214:	57                   	push   di
    4215:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4218:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    421c:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    421f:	26 88 45 04          	mov    BYTE PTR es:[di+0x4],al
    4223:	bf 3c 3e             	mov    di,0x3e3c
    4226:	0e                   	push   cs
    4227:	57                   	push   di
    4228:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    422b:	06                   	push   es
    422c:	57                   	push   di
    422d:	9a 9b 3b 53 42       	call   0x4253:0x3b9b
    4232:	89 c7                	mov    di,ax
    4234:	8e c2                	mov    es,dx
    4236:	06                   	push   es
    4237:	57                   	push   di
    4238:	26 c4 3d             	les    di,DWORD PTR es:[di]
    423b:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    423f:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4242:	26 88 45 05          	mov    BYTE PTR es:[di+0x5],al
    4246:	bf 4c 3e             	mov    di,0x3e4c
    4249:	0e                   	push   cs
    424a:	57                   	push   di
    424b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    424e:	06                   	push   es
    424f:	57                   	push   di
    4250:	9a 9b 3b 31 43       	call   0x4331:0x3b9b
    4255:	89 c7                	mov    di,ax
    4257:	8e c2                	mov    es,dx
    4259:	06                   	push   es
    425a:	57                   	push   di
    425b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    425e:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4262:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4265:	26 88 45 06          	mov    BYTE PTR es:[di+0x6],al
    4269:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    426c:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    426f:	74 03                	je     0x4274
    4271:	e9 a0 fe             	jmp    0x4114
    4274:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4277:	26 c4 bd 38 02       	les    di,DWORD PTR es:[di+0x238]
    427c:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    427f:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4282:	a1 4e 01             	mov    ax,ds:0x14e
    4285:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4288:	b8 01 00             	mov    ax,0x1
    428b:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    428e:	7e 03                	jle    0x4293
    4290:	e9 64 01             	jmp    0x43f7
    4293:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4296:	eb 03                	jmp    0x429b
    4298:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    429b:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    42a0:	eb 03                	jmp    0x42a5
    42a2:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    42a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42a8:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    42ad:	99                   	cwd
    42ae:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    42b1:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
    42b4:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
    42b8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    42bb:	99                   	cwd
    42bc:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    42bf:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    42c2:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    42c6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    42c9:	99                   	cwd
    42ca:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    42cd:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    42d0:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    42d4:	8d 7e c8             	lea    di,[bp-0x38]
    42d7:	16                   	push   ss
    42d8:	57                   	push   di
    42d9:	6a 02                	push   0x2
    42db:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    42de:	06                   	push   es
    42df:	57                   	push   di
    42e0:	9a 95 28 66 44       	call   0x4466:0x2895
    42e5:	08 c0                	or     al,al
    42e7:	75 0a                	jne    0x42f3
    42e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42ec:	06                   	push   es
    42ed:	57                   	push   di
    42ee:	9a 33 07 74 44       	call   0x4474:0x733
    42f3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    42f6:	99                   	cwd
    42f7:	bf 5c 3e             	mov    di,0x3e5c
    42fa:	9a 16 04 0e 43       	call   0x430e:0x416
    42ff:	c1 e0 05             	shl    ax,0x5
    4302:	8b c8                	mov    cx,ax
    4304:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4307:	99                   	cwd
    4308:	bf cd 3d             	mov    di,0x3dcd
    430b:	9a 16 04 80 44       	call   0x4480:0x416
    4310:	c1 e0 06             	shl    ax,0x6
    4313:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4316:	03 f8                	add    di,ax
    4318:	03 f9                	add    di,cx
    431a:	81 c7 d8 ff          	add    di,0xffd8
    431e:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    4321:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    4324:	bf 64 3e             	mov    di,0x3e64
    4327:	0e                   	push   cs
    4328:	57                   	push   di
    4329:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    432c:	06                   	push   es
    432d:	57                   	push   di
    432e:	9a 9b 3b 56 43       	call   0x4356:0x3b9b
    4333:	89 c7                	mov    di,ax
    4335:	8e c2                	mov    es,dx
    4337:	06                   	push   es
    4338:	57                   	push   di
    4339:	26 c4 3d             	les    di,DWORD PTR es:[di]
    433c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4340:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4343:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    4347:	90                   	nop
    4348:	9b                   	fwait
    4349:	bf 69 3e             	mov    di,0x3e69
    434c:	0e                   	push   cs
    434d:	57                   	push   di
    434e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4351:	06                   	push   es
    4352:	57                   	push   di
    4353:	9a 9b 3b 7c 43       	call   0x437c:0x3b9b
    4358:	89 c7                	mov    di,ax
    435a:	8e c2                	mov    es,dx
    435c:	06                   	push   es
    435d:	57                   	push   di
    435e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4361:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4365:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4368:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    436d:	90                   	nop
    436e:	9b                   	fwait
    436f:	bf 73 3e             	mov    di,0x3e73
    4372:	0e                   	push   cs
    4373:	57                   	push   di
    4374:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4377:	06                   	push   es
    4378:	57                   	push   di
    4379:	9a 9b 3b a2 43       	call   0x43a2:0x3b9b
    437e:	89 c7                	mov    di,ax
    4380:	8e c2                	mov    es,dx
    4382:	06                   	push   es
    4383:	57                   	push   di
    4384:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4387:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    438b:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    438e:	9b 26 dd 5d 10       	fstp   QWORD PTR es:[di+0x10]
    4393:	90                   	nop
    4394:	9b                   	fwait
    4395:	bf 85 3e             	mov    di,0x3e85
    4398:	0e                   	push   cs
    4399:	57                   	push   di
    439a:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    439d:	06                   	push   es
    439e:	57                   	push   di
    439f:	9a 9b 3b c9 43       	call   0x43c9:0x3b9b
    43a4:	89 c7                	mov    di,ax
    43a6:	8e c2                	mov    es,dx
    43a8:	06                   	push   es
    43a9:	57                   	push   di
    43aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43ad:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    43b1:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    43b4:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    43b8:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    43bc:	bf 96 3e             	mov    di,0x3e96
    43bf:	0e                   	push   cs
    43c0:	57                   	push   di
    43c1:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    43c4:	06                   	push   es
    43c5:	57                   	push   di
    43c6:	9a 9b 3b b4 44       	call   0x44b4:0x3b9b
    43cb:	89 c7                	mov    di,ax
    43cd:	8e c2                	mov    es,dx
    43cf:	06                   	push   es
    43d0:	57                   	push   di
    43d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43d4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    43d8:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    43db:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    43df:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    43e3:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    43e7:	74 03                	je     0x43ec
    43e9:	e9 b6 fe             	jmp    0x42a2
    43ec:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    43ef:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    43f2:	74 03                	je     0x43f7
    43f4:	e9 a1 fe             	jmp    0x4298
    43f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43fa:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    43ff:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4402:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4405:	a1 4e 01             	mov    ax,ds:0x14e
    4408:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    440b:	b8 01 00             	mov    ax,0x1
    440e:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4411:	7e 03                	jle    0x4416
    4413:	e9 cd 03             	jmp    0x47e3
    4416:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4419:	eb 03                	jmp    0x441e
    441b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    441e:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4423:	eb 03                	jmp    0x4428
    4425:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4428:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    442b:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    4430:	99                   	cwd
    4431:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    4434:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
    4437:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
    443b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    443e:	99                   	cwd
    443f:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    4442:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    4445:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    4449:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    444c:	99                   	cwd
    444d:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4450:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    4453:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    4457:	8d 7e c8             	lea    di,[bp-0x38]
    445a:	16                   	push   ss
    445b:	57                   	push   di
    445c:	6a 02                	push   0x2
    445e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4461:	06                   	push   es
    4462:	57                   	push   di
    4463:	9a 95 28 67 47       	call   0x4767:0x2895
    4468:	08 c0                	or     al,al
    446a:	75 0a                	jne    0x4476
    446c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    446f:	06                   	push   es
    4470:	57                   	push   di
    4471:	9a 33 07 75 47       	call   0x4775:0x733
    4476:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4479:	99                   	cwd
    447a:	bf 5c 3e             	mov    di,0x3e5c
    447d:	9a 16 04 91 44       	call   0x4491:0x416
    4482:	6b c0 30             	imul   ax,ax,0x30
    4485:	8b c8                	mov    cx,ax
    4487:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    448a:	99                   	cwd
    448b:	bf cd 3d             	mov    di,0x3dcd
    448e:	9a 16 04 0a 45       	call   0x450a:0x416
    4493:	6b c0 60             	imul   ax,ax,0x60
    4496:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4499:	03 f8                	add    di,ax
    449b:	03 f9                	add    di,cx
    449d:	81 c7 a8 01          	add    di,0x1a8
    44a1:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    44a4:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    44a7:	bf c0 3e             	mov    di,0x3ec0
    44aa:	0e                   	push   cs
    44ab:	57                   	push   di
    44ac:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    44af:	06                   	push   es
    44b0:	57                   	push   di
    44b1:	9a 9b 3b d2 44       	call   0x44d2:0x3b9b
    44b6:	89 c7                	mov    di,ax
    44b8:	8e c2                	mov    es,dx
    44ba:	06                   	push   es
    44bb:	57                   	push   di
    44bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44bf:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    44c3:	52                   	push   dx
    44c4:	50                   	push   ax
    44c5:	bf af 3e             	mov    di,0x3eaf
    44c8:	0e                   	push   cs
    44c9:	57                   	push   di
    44ca:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    44cd:	06                   	push   es
    44ce:	57                   	push   di
    44cf:	9a 9b 3b f0 44       	call   0x44f0:0x3b9b
    44d4:	89 c7                	mov    di,ax
    44d6:	8e c2                	mov    es,dx
    44d8:	06                   	push   es
    44d9:	57                   	push   di
    44da:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44dd:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    44e1:	52                   	push   dx
    44e2:	50                   	push   ax
    44e3:	bf a8 3e             	mov    di,0x3ea8
    44e6:	0e                   	push   cs
    44e7:	57                   	push   di
    44e8:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    44eb:	06                   	push   es
    44ec:	57                   	push   di
    44ed:	9a 9b 3b 30 45       	call   0x4530:0x3b9b
    44f2:	89 c7                	mov    di,ax
    44f4:	8e c2                	mov    es,dx
    44f6:	06                   	push   es
    44f7:	57                   	push   di
    44f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44fb:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    44ff:	59                   	pop    cx
    4500:	5b                   	pop    bx
    4501:	03 c1                	add    ax,cx
    4503:	13 d3                	adc    dx,bx
    4505:	71 05                	jno    0x450c
    4507:	9a 3e 04 17 45       	call   0x4517:0x43e
    450c:	59                   	pop    cx
    450d:	5b                   	pop    bx
    450e:	03 c1                	add    ax,cx
    4510:	13 d3                	adc    dx,bx
    4512:	71 05                	jno    0x4519
    4514:	9a 3e 04 ed 45       	call   0x45ed:0x43e
    4519:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    451c:	26 89 05             	mov    WORD PTR es:[di],ax
    451f:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    4523:	bf cd 3e             	mov    di,0x3ecd
    4526:	0e                   	push   cs
    4527:	57                   	push   di
    4528:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    452b:	06                   	push   es
    452c:	57                   	push   di
    452d:	9a 9b 3b 56 45       	call   0x4556:0x3b9b
    4532:	89 c7                	mov    di,ax
    4534:	8e c2                	mov    es,dx
    4536:	06                   	push   es
    4537:	57                   	push   di
    4538:	26 c4 3d             	les    di,DWORD PTR es:[di]
    453b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    453f:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4542:	9b 26 dd 5d 14       	fstp   QWORD PTR es:[di+0x14]
    4547:	90                   	nop
    4548:	9b                   	fwait
    4549:	bf d9 3e             	mov    di,0x3ed9
    454c:	0e                   	push   cs
    454d:	57                   	push   di
    454e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4551:	06                   	push   es
    4552:	57                   	push   di
    4553:	9a 9b 3b 7d 45       	call   0x457d:0x3b9b
    4558:	89 c7                	mov    di,ax
    455a:	8e c2                	mov    es,dx
    455c:	06                   	push   es
    455d:	57                   	push   di
    455e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4561:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4565:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4568:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    456c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4570:	bf e1 3e             	mov    di,0x3ee1
    4573:	0e                   	push   cs
    4574:	57                   	push   di
    4575:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4578:	06                   	push   es
    4579:	57                   	push   di
    457a:	9a 9b 3b a4 45       	call   0x45a4:0x3b9b
    457f:	89 c7                	mov    di,ax
    4581:	8e c2                	mov    es,dx
    4583:	06                   	push   es
    4584:	57                   	push   di
    4585:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4588:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    458c:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    458f:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4593:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    4597:	bf f6 3e             	mov    di,0x3ef6
    459a:	0e                   	push   cs
    459b:	57                   	push   di
    459c:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    459f:	06                   	push   es
    45a0:	57                   	push   di
    45a1:	9a 9b 3b ca 45       	call   0x45ca:0x3b9b
    45a6:	89 c7                	mov    di,ax
    45a8:	8e c2                	mov    es,dx
    45aa:	06                   	push   es
    45ab:	57                   	push   di
    45ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45af:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45b3:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    45b6:	9b 26 dd 5d 1c       	fstp   QWORD PTR es:[di+0x1c]
    45bb:	90                   	nop
    45bc:	9b                   	fwait
    45bd:	bf a8 3e             	mov    di,0x3ea8
    45c0:	0e                   	push   cs
    45c1:	57                   	push   di
    45c2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    45c5:	06                   	push   es
    45c6:	57                   	push   di
    45c7:	9a 9b 3b 30 46       	call   0x4630:0x3b9b
    45cc:	89 c7                	mov    di,ax
    45ce:	8e c2                	mov    es,dx
    45d0:	06                   	push   es
    45d1:	57                   	push   di
    45d2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45d5:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    45d9:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    45dc:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    45df:	9b db 46 d8          	fild   DWORD PTR [bp-0x28]
    45e3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    45e6:	99                   	cwd
    45e7:	bf 5c 3e             	mov    di,0x3e5c
    45ea:	9a 16 04 fe 45       	call   0x45fe:0x416
    45ef:	c1 e0 05             	shl    ax,0x5
    45f2:	8b c8                	mov    cx,ax
    45f4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    45f7:	99                   	cwd
    45f8:	bf cd 3d             	mov    di,0x3dcd
    45fb:	9a 16 04 2f 47       	call   0x472f:0x416
    4600:	c1 e0 06             	shl    ax,0x6
    4603:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4606:	03 f8                	add    di,ax
    4608:	03 f9                	add    di,cx
    460a:	9b 26 dc 4d d8       	fmul   QWORD PTR es:[di-0x28]
    460f:	83 ec 08             	sub    sp,0x8
    4612:	89 e3                	mov    bx,sp
    4614:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4618:	90                   	nop
    4619:	9b                   	fwait
    461a:	9a a6 2f 7e 46       	call   0x467e:0x2fa6
    461f:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    4623:	bf af 3e             	mov    di,0x3eaf
    4626:	0e                   	push   cs
    4627:	57                   	push   di
    4628:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    462b:	06                   	push   es
    462c:	57                   	push   di
    462d:	9a 9b 3b 5a 46       	call   0x465a:0x3b9b
    4632:	89 c7                	mov    di,ax
    4634:	8e c2                	mov    es,dx
    4636:	06                   	push   es
    4637:	57                   	push   di
    4638:	26 c4 3d             	les    di,DWORD PTR es:[di]
    463b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    463f:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    4642:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    4645:	9b db 46 d4          	fild   DWORD PTR [bp-0x2c]
    4649:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    464d:	bf 01 3f             	mov    di,0x3f01
    4650:	0e                   	push   cs
    4651:	57                   	push   di
    4652:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4655:	06                   	push   es
    4656:	57                   	push   di
    4657:	9a 9b 3b 98 46       	call   0x4698:0x3b9b
    465c:	89 c7                	mov    di,ax
    465e:	8e c2                	mov    es,dx
    4660:	06                   	push   es
    4661:	57                   	push   di
    4662:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4665:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4669:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    466d:	9b de c9             	fmulp  st(1),st
    4670:	83 ec 08             	sub    sp,0x8
    4673:	89 e3                	mov    bx,sp
    4675:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4679:	90                   	nop
    467a:	9b                   	fwait
    467b:	9a a6 2f e6 46       	call   0x46e6:0x2fa6
    4680:	9b db 6e c0          	fld    TBYTE PTR [bp-0x40]
    4684:	9b de c1             	faddp  st(1),st
    4687:	9b db 7e a8          	fstp   TBYTE PTR [bp-0x58]
    468b:	bf c0 3e             	mov    di,0x3ec0
    468e:	0e                   	push   cs
    468f:	57                   	push   di
    4690:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4693:	06                   	push   es
    4694:	57                   	push   di
    4695:	9a 9b 3b c2 46       	call   0x46c2:0x3b9b
    469a:	89 c7                	mov    di,ax
    469c:	8e c2                	mov    es,dx
    469e:	06                   	push   es
    469f:	57                   	push   di
    46a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46a3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    46a7:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    46aa:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    46ad:	9b db 46 bc          	fild   DWORD PTR [bp-0x44]
    46b1:	9b db 7e b2          	fstp   TBYTE PTR [bp-0x4e]
    46b5:	bf 13 3f             	mov    di,0x3f13
    46b8:	0e                   	push   cs
    46b9:	57                   	push   di
    46ba:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    46bd:	06                   	push   es
    46be:	57                   	push   di
    46bf:	9a 9b 3b 06 47       	call   0x4706:0x3b9b
    46c4:	89 c7                	mov    di,ax
    46c6:	8e c2                	mov    es,dx
    46c8:	06                   	push   es
    46c9:	57                   	push   di
    46ca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46cd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46d1:	9b db 6e b2          	fld    TBYTE PTR [bp-0x4e]
    46d5:	9b de c9             	fmulp  st(1),st
    46d8:	83 ec 08             	sub    sp,0x8
    46db:	89 e3                	mov    bx,sp
    46dd:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    46e1:	90                   	nop
    46e2:	9b                   	fwait
    46e3:	9a a6 2f 51 4a       	call   0x4a51:0x2fa6
    46e8:	9b db 6e a8          	fld    TBYTE PTR [bp-0x58]
    46ec:	9b de c1             	faddp  st(1),st
    46ef:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    46f2:	9b 26 dd 5d 0c       	fstp   QWORD PTR es:[di+0xc]
    46f7:	90                   	nop
    46f8:	9b                   	fwait
    46f9:	bf 21 3f             	mov    di,0x3f21
    46fc:	0e                   	push   cs
    46fd:	57                   	push   di
    46fe:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4701:	06                   	push   es
    4702:	57                   	push   di
    4703:	9a 9b 3b b5 47       	call   0x47b5:0x3b9b
    4708:	89 c7                	mov    di,ax
    470a:	8e c2                	mov    es,dx
    470c:	06                   	push   es
    470d:	57                   	push   di
    470e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4711:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4715:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4718:	9b 26 dd 5d 24       	fstp   QWORD PTR es:[di+0x24]
    471d:	90                   	nop
    471e:	9b                   	fwait
    471f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4722:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    4727:	2d 01 00             	sub    ax,0x1
    472a:	71 05                	jno    0x4731
    472c:	9a 3e 04 81 47       	call   0x4781:0x43e
    4731:	99                   	cwd
    4732:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    4735:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
    4738:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
    473c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    473f:	99                   	cwd
    4740:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    4743:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    4746:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    474a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    474d:	99                   	cwd
    474e:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4751:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    4754:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    4758:	8d 7e c8             	lea    di,[bp-0x38]
    475b:	16                   	push   ss
    475c:	57                   	push   di
    475d:	6a 02                	push   0x2
    475f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4762:	06                   	push   es
    4763:	57                   	push   di
    4764:	9a 95 28 3a 48       	call   0x483a:0x2895
    4769:	08 c0                	or     al,al
    476b:	75 0a                	jne    0x4777
    476d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4770:	06                   	push   es
    4771:	57                   	push   di
    4772:	9a 33 07 48 48       	call   0x4848:0x733
    4777:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    477a:	99                   	cwd
    477b:	bf 5c 3e             	mov    di,0x3e5c
    477e:	9a 16 04 92 47       	call   0x4792:0x416
    4783:	6b c0 30             	imul   ax,ax,0x30
    4786:	8b c8                	mov    cx,ax
    4788:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    478b:	99                   	cwd
    478c:	bf cd 3d             	mov    di,0x3dcd
    478f:	9a 16 04 54 48       	call   0x4854:0x416
    4794:	6b c0 60             	imul   ax,ax,0x60
    4797:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    479a:	03 f8                	add    di,ax
    479c:	03 f9                	add    di,cx
    479e:	81 c7 a8 01          	add    di,0x1a8
    47a2:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    47a5:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    47a8:	bf d9 3e             	mov    di,0x3ed9
    47ab:	0e                   	push   cs
    47ac:	57                   	push   di
    47ad:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    47b0:	06                   	push   es
    47b1:	57                   	push   di
    47b2:	9a 9b 3b 75 48       	call   0x4875:0x3b9b
    47b7:	89 c7                	mov    di,ax
    47b9:	8e c2                	mov    es,dx
    47bb:	06                   	push   es
    47bc:	57                   	push   di
    47bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47c0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    47c4:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    47c7:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    47cb:	26 89 55 2e          	mov    WORD PTR es:[di+0x2e],dx
    47cf:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    47d3:	74 03                	je     0x47d8
    47d5:	e9 4d fc             	jmp    0x4425
    47d8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    47db:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    47de:	74 03                	je     0x47e3
    47e0:	e9 38 fc             	jmp    0x441b
    47e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47e6:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    47eb:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    47ee:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    47f1:	a1 4e 01             	mov    ax,ds:0x14e
    47f4:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    47f7:	b8 01 00             	mov    ax,0x1
    47fa:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    47fd:	7e 03                	jle    0x4802
    47ff:	e9 b9 02             	jmp    0x4abb
    4802:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4805:	eb 03                	jmp    0x480a
    4807:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    480a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    480d:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    4812:	99                   	cwd
    4813:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    4816:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    4819:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    481d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4820:	99                   	cwd
    4821:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4824:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    4827:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    482b:	8d 7e d0             	lea    di,[bp-0x30]
    482e:	16                   	push   ss
    482f:	57                   	push   di
    4830:	6a 01                	push   0x1
    4832:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4835:	06                   	push   es
    4836:	57                   	push   di
    4837:	9a 95 28 03 4b       	call   0x4b03:0x2895
    483c:	08 c0                	or     al,al
    483e:	75 0a                	jne    0x484a
    4840:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4843:	06                   	push   es
    4844:	57                   	push   di
    4845:	9a 33 07 11 4b       	call   0x4b11:0x733
    484a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    484d:	99                   	cwd
    484e:	bf cd 3d             	mov    di,0x3dcd
    4851:	9a 16 04 1d 4b       	call   0x4b1d:0x416
    4856:	6b c0 38             	imul   ax,ax,0x38
    4859:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    485c:	03 f8                	add    di,ax
    485e:	81 c7 00 05          	add    di,0x500
    4862:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    4865:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    4868:	bf 2d 3f             	mov    di,0x3f2d
    486b:	0e                   	push   cs
    486c:	57                   	push   di
    486d:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4870:	06                   	push   es
    4871:	57                   	push   di
    4872:	9a 9b 3b 9b 48       	call   0x489b:0x3b9b
    4877:	89 c7                	mov    di,ax
    4879:	8e c2                	mov    es,dx
    487b:	06                   	push   es
    487c:	57                   	push   di
    487d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4880:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4884:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4887:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    488c:	90                   	nop
    488d:	9b                   	fwait
    488e:	bf 39 3f             	mov    di,0x3f39
    4891:	0e                   	push   cs
    4892:	57                   	push   di
    4893:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4896:	06                   	push   es
    4897:	57                   	push   di
    4898:	9a 9b 3b c5 48       	call   0x48c5:0x3b9b
    489d:	89 c7                	mov    di,ax
    489f:	8e c2                	mov    es,dx
    48a1:	06                   	push   es
    48a2:	57                   	push   di
    48a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48a6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48aa:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    48ad:	9b 26 dc 45 08       	fadd   QWORD PTR es:[di+0x8]
    48b2:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    48b6:	90                   	nop
    48b7:	9b                   	fwait
    48b8:	bf 3f 3f             	mov    di,0x3f3f
    48bb:	0e                   	push   cs
    48bc:	57                   	push   di
    48bd:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    48c0:	06                   	push   es
    48c1:	57                   	push   di
    48c2:	9a 9b 3b eb 48       	call   0x48eb:0x3b9b
    48c7:	89 c7                	mov    di,ax
    48c9:	8e c2                	mov    es,dx
    48cb:	06                   	push   es
    48cc:	57                   	push   di
    48cd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48d0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48d4:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    48d7:	9b 26 dd 5d 10       	fstp   QWORD PTR es:[di+0x10]
    48dc:	90                   	nop
    48dd:	9b                   	fwait
    48de:	bf 4d 3f             	mov    di,0x3f4d
    48e1:	0e                   	push   cs
    48e2:	57                   	push   di
    48e3:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    48e6:	06                   	push   es
    48e7:	57                   	push   di
    48e8:	9a 9b 3b 11 49       	call   0x4911:0x3b9b
    48ed:	89 c7                	mov    di,ax
    48ef:	8e c2                	mov    es,dx
    48f1:	06                   	push   es
    48f2:	57                   	push   di
    48f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48f6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48fa:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    48fd:	9b 26 dd 5d 18       	fstp   QWORD PTR es:[di+0x18]
    4902:	90                   	nop
    4903:	9b                   	fwait
    4904:	bf 63 3f             	mov    di,0x3f63
    4907:	0e                   	push   cs
    4908:	57                   	push   di
    4909:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    490c:	06                   	push   es
    490d:	57                   	push   di
    490e:	9a 9b 3b 31 49       	call   0x4931:0x3b9b
    4913:	89 c7                	mov    di,ax
    4915:	8e c2                	mov    es,dx
    4917:	06                   	push   es
    4918:	57                   	push   di
    4919:	26 c4 3d             	les    di,DWORD PTR es:[di]
    491c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4920:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
    4924:	bf 6b 3f             	mov    di,0x3f6b
    4927:	0e                   	push   cs
    4928:	57                   	push   di
    4929:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    492c:	06                   	push   es
    492d:	57                   	push   di
    492e:	9a 9b 3b 58 49       	call   0x4958:0x3b9b
    4933:	89 c7                	mov    di,ax
    4935:	8e c2                	mov    es,dx
    4937:	06                   	push   es
    4938:	57                   	push   di
    4939:	26 c4 3d             	les    di,DWORD PTR es:[di]
    493c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4940:	9b db 6e d2          	fld    TBYTE PTR [bp-0x2e]
    4944:	9b de c1             	faddp  st(1),st
    4947:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
    494b:	bf 39 3f             	mov    di,0x3f39
    494e:	0e                   	push   cs
    494f:	57                   	push   di
    4950:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4953:	06                   	push   es
    4954:	57                   	push   di
    4955:	9a 9b 3b 7f 49       	call   0x497f:0x3b9b
    495a:	89 c7                	mov    di,ax
    495c:	8e c2                	mov    es,dx
    495e:	06                   	push   es
    495f:	57                   	push   di
    4960:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4963:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4967:	9b db 6e c8          	fld    TBYTE PTR [bp-0x38]
    496b:	9b de c1             	faddp  st(1),st
    496e:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
    4972:	bf 78 3f             	mov    di,0x3f78
    4975:	0e                   	push   cs
    4976:	57                   	push   di
    4977:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    497a:	06                   	push   es
    497b:	57                   	push   di
    497c:	9a 9b 3b a6 49       	call   0x49a6:0x3b9b
    4981:	89 c7                	mov    di,ax
    4983:	8e c2                	mov    es,dx
    4985:	06                   	push   es
    4986:	57                   	push   di
    4987:	26 c4 3d             	les    di,DWORD PTR es:[di]
    498a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    498e:	9b db 6e be          	fld    TBYTE PTR [bp-0x42]
    4992:	9b de c1             	faddp  st(1),st
    4995:	9b db 7e b4          	fstp   TBYTE PTR [bp-0x4c]
    4999:	bf 86 3f             	mov    di,0x3f86
    499c:	0e                   	push   cs
    499d:	57                   	push   di
    499e:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    49a1:	06                   	push   es
    49a2:	57                   	push   di
    49a3:	9a 9b 3b cf 49       	call   0x49cf:0x3b9b
    49a8:	89 c7                	mov    di,ax
    49aa:	8e c2                	mov    es,dx
    49ac:	06                   	push   es
    49ad:	57                   	push   di
    49ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49b1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49b5:	9b db 6e b4          	fld    TBYTE PTR [bp-0x4c]
    49b9:	9b de c1             	faddp  st(1),st
    49bc:	9b dd 5e f2          	fstp   QWORD PTR [bp-0xe]
    49c0:	90                   	nop
    49c1:	9b                   	fwait
    49c2:	bf 3f 3f             	mov    di,0x3f3f
    49c5:	0e                   	push   cs
    49c6:	57                   	push   di
    49c7:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    49ca:	06                   	push   es
    49cb:	57                   	push   di
    49cc:	9a 9b 3b f3 49       	call   0x49f3:0x3b9b
    49d1:	89 c7                	mov    di,ax
    49d3:	8e c2                	mov    es,dx
    49d5:	06                   	push   es
    49d6:	57                   	push   di
    49d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49da:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49de:	9b dc 46 f2          	fadd   QWORD PTR [bp-0xe]
    49e2:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
    49e6:	bf 95 3f             	mov    di,0x3f95
    49e9:	0e                   	push   cs
    49ea:	57                   	push   di
    49eb:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    49ee:	06                   	push   es
    49ef:	57                   	push   di
    49f0:	9a 9b 3b 1a 4a       	call   0x4a1a:0x3b9b
    49f5:	89 c7                	mov    di,ax
    49f7:	8e c2                	mov    es,dx
    49f9:	06                   	push   es
    49fa:	57                   	push   di
    49fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49fe:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a02:	9b db 6e d2          	fld    TBYTE PTR [bp-0x2e]
    4a06:	9b de c1             	faddp  st(1),st
    4a09:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
    4a0d:	bf 2d 3f             	mov    di,0x3f2d
    4a10:	0e                   	push   cs
    4a11:	57                   	push   di
    4a12:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4a15:	06                   	push   es
    4a16:	57                   	push   di
    4a17:	9a 9b 3b 70 4a       	call   0x4a70:0x3b9b
    4a1c:	89 c7                	mov    di,ax
    4a1e:	8e c2                	mov    es,dx
    4a20:	06                   	push   es
    4a21:	57                   	push   di
    4a22:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a25:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a29:	9b db 6e c8          	fld    TBYTE PTR [bp-0x38]
    4a2d:	9b de c1             	faddp  st(1),st
    4a30:	9b dd 5e ea          	fstp   QWORD PTR [bp-0x16]
    4a34:	90                   	nop
    4a35:	9b                   	fwait
    4a36:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4a39:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4a3c:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4a3f:	ff 76 f2             	push   WORD PTR [bp-0xe]
    4a42:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4a45:	ff 76 ee             	push   WORD PTR [bp-0x12]
    4a48:	ff 76 ec             	push   WORD PTR [bp-0x14]
    4a4b:	ff 76 ea             	push   WORD PTR [bp-0x16]
    4a4e:	9a a7 2e 6c 4d       	call   0x4d6c:0x2ea7
    4a53:	9b 2e d8 0e 9e 3f    	fmul   DWORD PTR cs:0x3f9e
    4a59:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4a5c:	9b 26 dd 5d 28       	fstp   QWORD PTR es:[di+0x28]
    4a61:	90                   	nop
    4a62:	9b                   	fwait
    4a63:	bf 78 3f             	mov    di,0x3f78
    4a66:	0e                   	push   cs
    4a67:	57                   	push   di
    4a68:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4a6b:	06                   	push   es
    4a6c:	57                   	push   di
    4a6d:	9a 9b 3b 90 4a       	call   0x4a90:0x3b9b
    4a72:	89 c7                	mov    di,ax
    4a74:	8e c2                	mov    es,dx
    4a76:	06                   	push   es
    4a77:	57                   	push   di
    4a78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a7b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a7f:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
    4a83:	bf a2 3f             	mov    di,0x3fa2
    4a86:	0e                   	push   cs
    4a87:	57                   	push   di
    4a88:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4a8b:	06                   	push   es
    4a8c:	57                   	push   di
    4a8d:	9a 9b 3b 3e 4b       	call   0x4b3e:0x3b9b
    4a92:	89 c7                	mov    di,ax
    4a94:	8e c2                	mov    es,dx
    4a96:	06                   	push   es
    4a97:	57                   	push   di
    4a98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a9b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a9f:	9b db 6e d2          	fld    TBYTE PTR [bp-0x2e]
    4aa3:	9b de c1             	faddp  st(1),st
    4aa6:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4aa9:	9b 26 dd 5d 20       	fstp   QWORD PTR es:[di+0x20]
    4aae:	90                   	nop
    4aaf:	9b                   	fwait
    4ab0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ab3:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4ab6:	74 03                	je     0x4abb
    4ab8:	e9 4c fd             	jmp    0x4807
    4abb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4abe:	26 c4 bd 68 02       	les    di,DWORD PTR es:[di+0x268]
    4ac3:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4ac6:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4ac9:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4ace:	eb 03                	jmp    0x4ad3
    4ad0:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4ad3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ad6:	26 8b 85 18 03       	mov    ax,WORD PTR es:[di+0x318]
    4adb:	99                   	cwd
    4adc:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    4adf:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    4ae2:	c6 46 d6 00          	mov    BYTE PTR [bp-0x2a],0x0
    4ae6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4ae9:	99                   	cwd
    4aea:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    4aed:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    4af0:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    4af4:	8d 7e d2             	lea    di,[bp-0x2e]
    4af7:	16                   	push   ss
    4af8:	57                   	push   di
    4af9:	6a 01                	push   0x1
    4afb:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4afe:	06                   	push   es
    4aff:	57                   	push   di
    4b00:	9a 95 28 ff ff       	call   0xffff:0x2895
    4b05:	08 c0                	or     al,al
    4b07:	75 0a                	jne    0x4b13
    4b09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b0c:	06                   	push   es
    4b0d:	57                   	push   di
    4b0e:	9a 33 07 b8 53       	call   0x53b8:0x733
    4b13:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4b16:	99                   	cwd
    4b17:	bf 5c 3e             	mov    di,0x3e5c
    4b1a:	9a 16 04 50 4b       	call   0x4b50:0x416
    4b1f:	6b c0 18             	imul   ax,ax,0x18
    4b22:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4b25:	03 f8                	add    di,ax
    4b27:	81 c7 e0 06          	add    di,0x6e0
    4b2b:	89 7e de             	mov    WORD PTR [bp-0x22],di
    4b2e:	8c 46 e0             	mov    WORD PTR [bp-0x20],es
    4b31:	bf b1 3f             	mov    di,0x3fb1
    4b34:	0e                   	push   cs
    4b35:	57                   	push   di
    4b36:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4b39:	06                   	push   es
    4b3a:	57                   	push   di
    4b3b:	9a 9b 3b d2 4f       	call   0x4fd2:0x3b9b
    4b40:	89 c7                	mov    di,ax
    4b42:	8e c2                	mov    es,dx
    4b44:	06                   	push   es
    4b45:	57                   	push   di
    4b46:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b49:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b4d:	9a 2f 10 85 4b       	call   0x4b85:0x102f
    4b52:	c4 7e de             	les    di,DWORD PTR [bp-0x22]
    4b55:	26 89 05             	mov    WORD PTR es:[di],ax
    4b58:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    4b5c:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    4b60:	74 03                	je     0x4b65
    4b62:	e9 6b ff             	jmp    0x4ad0
    4b65:	a1 4e 01             	mov    ax,ds:0x14e
    4b68:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    4b6b:	b8 01 00             	mov    ax,0x1
    4b6e:	3b 46 e4             	cmp    ax,WORD PTR [bp-0x1c]
    4b71:	7f 60                	jg     0x4bd3
    4b73:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4b76:	eb 03                	jmp    0x4b7b
    4b78:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4b7b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b7e:	99                   	cwd
    4b7f:	bf cd 3d             	mov    di,0x3dcd
    4b82:	9a 16 04 9f 4b       	call   0x4b9f:0x416
    4b87:	6b c0 60             	imul   ax,ax,0x60
    4b8a:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4b8d:	03 f8                	add    di,ax
    4b8f:	9b 26 dd 85 ec 01    	fld    QWORD PTR es:[di+0x1ec]
    4b95:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b98:	99                   	cwd
    4b99:	bf cd 3d             	mov    di,0x3dcd
    4b9c:	9a 16 04 b9 4b       	call   0x4bb9:0x416
    4ba1:	6b c0 60             	imul   ax,ax,0x60
    4ba4:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4ba7:	03 f8                	add    di,ax
    4ba9:	9b 26 dc 85 1c 02    	fadd   QWORD PTR es:[di+0x21c]
    4baf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4bb2:	99                   	cwd
    4bb3:	bf cd 3d             	mov    di,0x3dcd
    4bb6:	9a 16 04 e7 4b       	call   0x4be7:0x416
    4bbb:	6b c0 38             	imul   ax,ax,0x38
    4bbe:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4bc1:	03 f8                	add    di,ax
    4bc3:	9b 26 dd 9d 30 05    	fstp   QWORD PTR es:[di+0x530]
    4bc9:	90                   	nop
    4bca:	9b                   	fwait
    4bcb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4bce:	3b 46 e4             	cmp    ax,WORD PTR [bp-0x1c]
    4bd1:	75 a5                	jne    0x4b78
    4bd3:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4bd8:	eb 03                	jmp    0x4bdd
    4bda:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4bdd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4be0:	99                   	cwd
    4be1:	bf 5c 3e             	mov    di,0x3e5c
    4be4:	9a 16 04 3c 4c       	call   0x4c3c:0x416
    4be9:	6b c0 18             	imul   ax,ax,0x18
    4bec:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4bef:	03 f8                	add    di,ax
    4bf1:	81 c7 e0 06          	add    di,0x6e0
    4bf5:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4bf8:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4bfb:	31 c0                	xor    ax,ax
    4bfd:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4c01:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    4c05:	31 c0                	xor    ax,ax
    4c07:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4c0b:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    4c0f:	31 c0                	xor    ax,ax
    4c11:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    4c15:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    4c19:	a1 4e 01             	mov    ax,ds:0x14e
    4c1c:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4c1f:	b8 01 00             	mov    ax,0x1
    4c22:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4c25:	7e 03                	jle    0x4c2a
    4c27:	e9 fd 00             	jmp    0x4d27
    4c2a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c2d:	eb 03                	jmp    0x4c32
    4c2f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4c32:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4c35:	99                   	cwd
    4c36:	bf 5c 3e             	mov    di,0x3e5c
    4c39:	9a 16 04 4d 4c       	call   0x4c4d:0x416
    4c3e:	6b c0 30             	imul   ax,ax,0x30
    4c41:	8b c8                	mov    cx,ax
    4c43:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4c46:	99                   	cwd
    4c47:	bf cd 3d             	mov    di,0x3dcd
    4c4a:	9a 16 04 73 4c       	call   0x4c73:0x416
    4c4f:	6b c0 60             	imul   ax,ax,0x60
    4c52:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4c55:	03 f8                	add    di,ax
    4c57:	03 f9                	add    di,cx
    4c59:	26 8b 85 d4 01       	mov    ax,WORD PTR es:[di+0x1d4]
    4c5e:	26 8b 95 d6 01       	mov    dx,WORD PTR es:[di+0x1d6]
    4c63:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4c66:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    4c6a:	26 13 55 0a          	adc    dx,WORD PTR es:[di+0xa]
    4c6e:	71 05                	jno    0x4c75
    4c70:	9a 3e 04 8a 4c       	call   0x4c8a:0x43e
    4c75:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4c78:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4c7c:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    4c80:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4c83:	99                   	cwd
    4c84:	bf 5c 3e             	mov    di,0x3e5c
    4c87:	9a 16 04 9b 4c       	call   0x4c9b:0x416
    4c8c:	6b c0 30             	imul   ax,ax,0x30
    4c8f:	8b c8                	mov    cx,ax
    4c91:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4c94:	99                   	cwd
    4c95:	bf cd 3d             	mov    di,0x3dcd
    4c98:	9a 16 04 c1 4c       	call   0x4cc1:0x416
    4c9d:	6b c0 60             	imul   ax,ax,0x60
    4ca0:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4ca3:	03 f8                	add    di,ax
    4ca5:	03 f9                	add    di,cx
    4ca7:	26 8b 85 ac 01       	mov    ax,WORD PTR es:[di+0x1ac]
    4cac:	26 8b 95 ae 01       	mov    dx,WORD PTR es:[di+0x1ae]
    4cb1:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4cb4:	26 03 45 04          	add    ax,WORD PTR es:[di+0x4]
    4cb8:	26 13 55 06          	adc    dx,WORD PTR es:[di+0x6]
    4cbc:	71 05                	jno    0x4cc3
    4cbe:	9a 3e 04 d8 4c       	call   0x4cd8:0x43e
    4cc3:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4cc6:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4cca:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4cce:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4cd1:	99                   	cwd
    4cd2:	bf 5c 3e             	mov    di,0x3e5c
    4cd5:	9a 16 04 e9 4c       	call   0x4ce9:0x416
    4cda:	6b c0 30             	imul   ax,ax,0x30
    4cdd:	8b c8                	mov    cx,ax
    4cdf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ce2:	99                   	cwd
    4ce3:	bf cd 3d             	mov    di,0x3dcd
    4ce6:	9a 16 04 0f 4d       	call   0x4d0f:0x416
    4ceb:	6b c0 60             	imul   ax,ax,0x60
    4cee:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4cf1:	03 f8                	add    di,ax
    4cf3:	03 f9                	add    di,cx
    4cf5:	26 8b 85 b0 01       	mov    ax,WORD PTR es:[di+0x1b0]
    4cfa:	26 8b 95 b2 01       	mov    dx,WORD PTR es:[di+0x1b2]
    4cff:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4d02:	26 03 45 0c          	add    ax,WORD PTR es:[di+0xc]
    4d06:	26 13 55 0e          	adc    dx,WORD PTR es:[di+0xe]
    4d0a:	71 05                	jno    0x4d11
    4d0c:	9a 3e 04 3f 4d       	call   0x4d3f:0x43e
    4d11:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4d14:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    4d18:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    4d1c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4d1f:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4d22:	74 03                	je     0x4d27
    4d24:	e9 08 ff             	jmp    0x4c2f
    4d27:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4d2a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4d2e:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    4d32:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    4d36:	26 1b 55 0a          	sbb    dx,WORD PTR es:[di+0xa]
    4d3a:	71 05                	jno    0x4d41
    4d3c:	9a 3e 04 9b 4d       	call   0x4d9b:0x43e
    4d41:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    4d44:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    4d47:	9b db 46 de          	fild   DWORD PTR [bp-0x22]
    4d4b:	83 ec 08             	sub    sp,0x8
    4d4e:	89 e3                	mov    bx,sp
    4d50:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d54:	90                   	nop
    4d55:	9b                   	fwait
    4d56:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4d59:	9b 26 db 45 08       	fild   DWORD PTR es:[di+0x8]
    4d5e:	83 ec 08             	sub    sp,0x8
    4d61:	89 e3                	mov    bx,sp
    4d63:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d67:	90                   	nop
    4d68:	9b                   	fwait
    4d69:	9a a7 2e f9 4e       	call   0x4ef9:0x2ea7
    4d6e:	9b 2e d8 0e 9e 3f    	fmul   DWORD PTR cs:0x3f9e
    4d74:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4d77:	9b 26 dd 5d 10       	fstp   QWORD PTR es:[di+0x10]
    4d7c:	90                   	nop
    4d7d:	9b                   	fwait
    4d7e:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    4d82:	74 03                	je     0x4d87
    4d84:	e9 53 fe             	jmp    0x4bda
    4d87:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4d8c:	eb 03                	jmp    0x4d91
    4d8e:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4d91:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4d94:	99                   	cwd
    4d95:	bf 5c 3e             	mov    di,0x3e5c
    4d98:	9a 16 04 17 4e       	call   0x4e17:0x416
    4d9d:	6b c0 28             	imul   ax,ax,0x28
    4da0:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4da3:	03 f8                	add    di,ax
    4da5:	81 c7 00 07          	add    di,0x700
    4da9:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4dac:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    4daf:	9b 2e d9 06 be 3f    	fld    DWORD PTR cs:0x3fbe
    4db5:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    4db9:	90                   	nop
    4dba:	9b                   	fwait
    4dbb:	9b 2e d9 06 be 3f    	fld    DWORD PTR cs:0x3fbe
    4dc1:	9b 26 dd 5d 18       	fstp   QWORD PTR es:[di+0x18]
    4dc6:	90                   	nop
    4dc7:	9b                   	fwait
    4dc8:	9b 2e d9 06 be 3f    	fld    DWORD PTR cs:0x3fbe
    4dce:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    4dd3:	90                   	nop
    4dd4:	9b                   	fwait
    4dd5:	9b 2e d9 06 be 3f    	fld    DWORD PTR cs:0x3fbe
    4ddb:	9b 26 dd 5d 10       	fstp   QWORD PTR es:[di+0x10]
    4de0:	90                   	nop
    4de1:	9b                   	fwait
    4de2:	9b 2e d9 06 be 3f    	fld    DWORD PTR cs:0x3fbe
    4de8:	9b 26 dd 5d 20       	fstp   QWORD PTR es:[di+0x20]
    4ded:	90                   	nop
    4dee:	9b                   	fwait
    4def:	31 c0                	xor    ax,ax
    4df1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4df4:	a1 4e 01             	mov    ax,ds:0x14e
    4df7:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4dfa:	b8 01 00             	mov    ax,0x1
    4dfd:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4e00:	7e 03                	jle    0x4e05
    4e02:	e9 d0 00             	jmp    0x4ed5
    4e05:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e08:	eb 03                	jmp    0x4e0d
    4e0a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4e0d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4e10:	99                   	cwd
    4e11:	bf 5c 3e             	mov    di,0x3e5c
    4e14:	9a 16 04 28 4e       	call   0x4e28:0x416
    4e19:	c1 e0 05             	shl    ax,0x5
    4e1c:	8b c8                	mov    cx,ax
    4e1e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e21:	99                   	cwd
    4e22:	bf cd 3d             	mov    di,0x3dcd
    4e25:	9a 16 04 35 50       	call   0x5035:0x416
    4e2a:	c1 e0 06             	shl    ax,0x6
    4e2d:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    4e30:	03 f8                	add    di,ax
    4e32:	03 f9                	add    di,cx
    4e34:	81 c7 d8 ff          	add    di,0xffd8
    4e38:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    4e3b:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    4e3e:	9b 26 dd 05          	fld    QWORD PTR es:[di]
    4e42:	9b 2e d8 1e be 3f    	fcomp  DWORD PTR cs:0x3fbe
    4e48:	9b dd 7e da          	fstsw  WORD PTR [bp-0x26]
    4e4c:	90                   	nop
    4e4d:	9b                   	fwait
    4e4e:	8a 66 db             	mov    ah,BYTE PTR [bp-0x25]
    4e51:	9e                   	sahf
    4e52:	76 76                	jbe    0x4eca
    4e54:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4e57:	9b 26 dd 05          	fld    QWORD PTR es:[di]
    4e5b:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4e5e:	9b 26 dc 05          	fadd   QWORD PTR es:[di]
    4e62:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4e65:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    4e69:	90                   	nop
    4e6a:	9b                   	fwait
    4e6b:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
    4e70:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4e73:	9b 26 dc 45 08       	fadd   QWORD PTR es:[di+0x8]
    4e78:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4e7b:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    4e80:	90                   	nop
    4e81:	9b                   	fwait
    4e82:	9b 26 dd 45 10       	fld    QWORD PTR es:[di+0x10]
    4e87:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4e8a:	9b 26 dc 45 10       	fadd   QWORD PTR es:[di+0x10]
    4e8f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4e92:	9b 26 dd 5d 10       	fstp   QWORD PTR es:[di+0x10]
    4e97:	90                   	nop
    4e98:	9b                   	fwait
    4e99:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4e9c:	9b 26 db 45 18       	fild   DWORD PTR es:[di+0x18]
    4ea1:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4ea4:	9b 26 dc 45 18       	fadd   QWORD PTR es:[di+0x18]
    4ea9:	9b 26 dd 5d 18       	fstp   QWORD PTR es:[di+0x18]
    4eae:	90                   	nop
    4eaf:	9b                   	fwait
    4eb0:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    4eb3:	9b 26 db 45 1c       	fild   DWORD PTR es:[di+0x1c]
    4eb8:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4ebb:	9b 26 dc 45 20       	fadd   QWORD PTR es:[di+0x20]
    4ec0:	9b 26 dd 5d 20       	fstp   QWORD PTR es:[di+0x20]
    4ec5:	90                   	nop
    4ec6:	9b                   	fwait
    4ec7:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    4eca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4ecd:	3b 46 e0             	cmp    ax,WORD PTR [bp-0x20]
    4ed0:	74 03                	je     0x4ed5
    4ed2:	e9 35 ff             	jmp    0x4e0a
    4ed5:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4ed8:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4edc:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    4ee0:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4ee4:	26 ff 35             	push   WORD PTR es:[di]
    4ee7:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    4eeb:	83 ec 08             	sub    sp,0x8
    4eee:	89 e3                	mov    bx,sp
    4ef0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4ef4:	90                   	nop
    4ef5:	9b                   	fwait
    4ef6:	9a a7 2e 26 4f       	call   0x4f26:0x2ea7
    4efb:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4efe:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    4f02:	90                   	nop
    4f03:	9b                   	fwait
    4f04:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    4f08:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4f0c:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4f10:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4f14:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    4f18:	83 ec 08             	sub    sp,0x8
    4f1b:	89 e3                	mov    bx,sp
    4f1d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4f21:	90                   	nop
    4f22:	9b                   	fwait
    4f23:	9a a7 2e 54 4f       	call   0x4f54:0x2ea7
    4f28:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4f2b:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    4f30:	90                   	nop
    4f31:	9b                   	fwait
    4f32:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    4f36:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    4f3a:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    4f3e:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    4f42:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    4f46:	83 ec 08             	sub    sp,0x8
    4f49:	89 e3                	mov    bx,sp
    4f4b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4f4f:	90                   	nop
    4f50:	9b                   	fwait
    4f51:	9a a7 2e 82 4f       	call   0x4f82:0x2ea7
    4f56:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4f59:	9b 26 dd 5d 10       	fstp   QWORD PTR es:[di+0x10]
    4f5e:	90                   	nop
    4f5f:	9b                   	fwait
    4f60:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    4f64:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    4f68:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    4f6c:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    4f70:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    4f74:	83 ec 08             	sub    sp,0x8
    4f77:	89 e3                	mov    bx,sp
    4f79:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4f7d:	90                   	nop
    4f7e:	9b                   	fwait
    4f7f:	9a a7 2e b0 4f       	call   0x4fb0:0x2ea7
    4f84:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4f87:	9b 26 dd 5d 18       	fstp   QWORD PTR es:[di+0x18]
    4f8c:	90                   	nop
    4f8d:	9b                   	fwait
    4f8e:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    4f92:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    4f96:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    4f9a:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    4f9e:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    4fa2:	83 ec 08             	sub    sp,0x8
    4fa5:	89 e3                	mov    bx,sp
    4fa7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4fab:	90                   	nop
    4fac:	9b                   	fwait
    4fad:	9a a7 2e ff ff       	call   0xffff:0x2ea7
    4fb2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4fb5:	9b 26 dd 5d 20       	fstp   QWORD PTR es:[di+0x20]
    4fba:	90                   	nop
    4fbb:	9b                   	fwait
    4fbc:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    4fc0:	74 03                	je     0x4fc5
    4fc2:	e9 c9 fd             	jmp    0x4d8e
    4fc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fc8:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    4fcd:	06                   	push   es
    4fce:	57                   	push   di
    4fcf:	9a d2 31 e1 4f       	call   0x4fe1:0x31d2
    4fd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fd7:	26 c4 bd 38 02       	les    di,DWORD PTR es:[di+0x238]
    4fdc:	06                   	push   es
    4fdd:	57                   	push   di
    4fde:	9a d2 31 f0 4f       	call   0x4ff0:0x31d2
    4fe3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fe6:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    4feb:	06                   	push   es
    4fec:	57                   	push   di
    4fed:	9a d2 31 ff 4f       	call   0x4fff:0x31d2
    4ff2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ff5:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    4ffa:	06                   	push   es
    4ffb:	57                   	push   di
    4ffc:	9a d2 31 0e 50       	call   0x500e:0x31d2
    5001:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5004:	26 c4 bd 68 02       	les    di,DWORD PTR es:[di+0x268]
    5009:	06                   	push   es
    500a:	57                   	push   di
    500b:	9a d2 31 ff ff       	call   0xffff:0x31d2
    5010:	c9                   	leave
    5011:	ca 04 00             	retf   0x4
    5014:	f9                   	stc
    5015:	50                   	push   ax
    5016:	d4 50                	aam    0x50
    5018:	85 50 76             	test   WORD PTR [bx+si+0x76],dx
    501b:	50                   	push   ax
    501c:	22 51 b5             	and    dl,BYTE PTR [bx+di-0x4b]
    501f:	50                   	push   ax
    5020:	22 51 96             	and    dl,BYTE PTR [bx+di-0x6a]
    5023:	50                   	push   ax
    5024:	00 00                	add    BYTE PTR [bx+si],al
    5026:	00 00                	add    BYTE PTR [bx+si],al
    5028:	ff 00                	inc    WORD PTR [bx+si]
    502a:	00 00                	add    BYTE PTR [bx+si],al
    502c:	55                   	push   bp
    502d:	89 e5                	mov    bp,sp
    502f:	b8 04 00             	mov    ax,0x4
    5032:	9a 44 04 a6 50       	call   0x50a6:0x444
    5037:	83 ec 04             	sub    sp,0x4
    503a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    503d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    5042:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5045:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5048:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    504c:	b0 00                	mov    al,0x0
    504e:	74 01                	je     0x5051
    5050:	40                   	inc    ax
    5051:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    5055:	08 c0                	or     al,al
    5057:	75 03                	jne    0x505c
    5059:	e9 ee 00             	jmp    0x514a
    505c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    505f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5062:	2d 21 00             	sub    ax,0x21
    5065:	3d 07 00             	cmp    ax,0x7
    5068:	76 03                	jbe    0x506d
    506a:	e9 b5 00             	jmp    0x5122
    506d:	89 c3                	mov    bx,ax
    506f:	d1 e3                	shl    bx,1
    5071:	2e ff a7 14 50       	jmp    WORD PTR cs:[bx+0x5014]
    5076:	6a 00                	push   0x0
    5078:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    507b:	06                   	push   es
    507c:	57                   	push   di
    507d:	9a d0 1c 91 50       	call   0x5091:0x1cd0
    5082:	e9 9d 00             	jmp    0x5122
    5085:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5088:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    508c:	06                   	push   es
    508d:	57                   	push   di
    508e:	9a d0 1c b1 50       	call   0x50b1:0x1cd0
    5093:	e9 8c 00             	jmp    0x5122
    5096:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5099:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    509d:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    50a1:	71 05                	jno    0x50a8
    50a3:	9a 3e 04 c5 50       	call   0x50c5:0x43e
    50a8:	50                   	push   ax
    50a9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50ac:	06                   	push   es
    50ad:	57                   	push   di
    50ae:	9a d0 1c d0 50       	call   0x50d0:0x1cd0
    50b3:	eb 6d                	jmp    0x5122
    50b5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50b8:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    50bc:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    50c0:	71 05                	jno    0x50c7
    50c2:	9a 3e 04 ea 50       	call   0x50ea:0x43e
    50c7:	50                   	push   ax
    50c8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50cb:	06                   	push   es
    50cc:	57                   	push   di
    50cd:	9a d0 1c f5 50       	call   0x50f5:0x1cd0
    50d2:	eb 4e                	jmp    0x5122
    50d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50d7:	06                   	push   es
    50d8:	57                   	push   di
    50d9:	9a f4 18 01 51       	call   0x5101:0x18f4
    50de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50e1:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    50e5:	71 05                	jno    0x50ec
    50e7:	9a 3e 04 13 51       	call   0x5113:0x43e
    50ec:	50                   	push   ax
    50ed:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50f0:	06                   	push   es
    50f1:	57                   	push   di
    50f2:	9a d0 1c 1e 51       	call   0x511e:0x1cd0
    50f7:	eb 29                	jmp    0x5122
    50f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50fc:	06                   	push   es
    50fd:	57                   	push   di
    50fe:	9a f4 18 3b 53       	call   0x533b:0x18f4
    5103:	8b d0                	mov    dx,ax
    5105:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5108:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    510c:	2b c2                	sub    ax,dx
    510e:	71 05                	jno    0x5115
    5110:	9a 3e 04 30 51       	call   0x5130:0x43e
    5115:	50                   	push   ax
    5116:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5119:	06                   	push   es
    511a:	57                   	push   di
    511b:	9a d0 1c 8f 51       	call   0x518f:0x1cd0
    5120:	eb 00                	jmp    0x5122
    5122:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5125:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5128:	31 d2                	xor    dx,dx
    512a:	bf 24 50             	mov    di,0x5024
    512d:	9a 16 04 84 51       	call   0x5184:0x416
    5132:	3c 21                	cmp    al,0x21
    5134:	72 14                	jb     0x514a
    5136:	3c 24                	cmp    al,0x24
    5138:	76 08                	jbe    0x5142
    513a:	3c 26                	cmp    al,0x26
    513c:	74 04                	je     0x5142
    513e:	3c 28                	cmp    al,0x28
    5140:	75 08                	jne    0x514a
    5142:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5145:	31 c0                	xor    ax,ax
    5147:	26 89 05             	mov    WORD PTR es:[di],ax
    514a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    514d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    5152:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5155:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5158:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    515c:	b0 00                	mov    al,0x0
    515e:	74 01                	je     0x5161
    5160:	40                   	inc    ax
    5161:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    5165:	08 c0                	or     al,al
    5167:	74 6e                	je     0x51d7
    5169:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    516c:	26 8b 05             	mov    ax,WORD PTR es:[di]
    516f:	3d 27 00             	cmp    ax,0x27
    5172:	75 1f                	jne    0x5193
    5174:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5177:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    517b:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    517f:	71 05                	jno    0x5186
    5181:	9a 3e 04 a8 51       	call   0x51a8:0x43e
    5186:	50                   	push   ax
    5187:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    518a:	06                   	push   es
    518b:	57                   	push   di
    518c:	9a d0 1c b3 51       	call   0x51b3:0x1cd0
    5191:	eb 24                	jmp    0x51b7
    5193:	3d 25 00             	cmp    ax,0x25
    5196:	75 1f                	jne    0x51b7
    5198:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    519b:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    519f:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    51a3:	71 05                	jno    0x51aa
    51a5:	9a 3e 04 c5 51       	call   0x51c5:0x43e
    51aa:	50                   	push   ax
    51ab:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    51ae:	06                   	push   es
    51af:	57                   	push   di
    51b0:	9a d0 1c f2 51       	call   0x51f2:0x1cd0
    51b5:	eb 00                	jmp    0x51b7
    51b7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    51ba:	26 8b 05             	mov    ax,WORD PTR es:[di]
    51bd:	31 d2                	xor    dx,dx
    51bf:	bf 24 50             	mov    di,0x5024
    51c2:	9a 16 04 00 52       	call   0x5200:0x416
    51c7:	3c 25                	cmp    al,0x25
    51c9:	74 04                	je     0x51cf
    51cb:	3c 27                	cmp    al,0x27
    51cd:	75 08                	jne    0x51d7
    51cf:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    51d2:	31 c0                	xor    ax,ax
    51d4:	26 89 05             	mov    WORD PTR es:[di],ax
    51d7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    51da:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    51de:	74 14                	je     0x51f4
    51e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51e3:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    51e8:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    51ed:	06                   	push   es
    51ee:	57                   	push   di
    51ef:	9a 30 22 1d 52       	call   0x521d:0x2230
    51f4:	c9                   	leave
    51f5:	ca 0e 00             	retf   0xe
    51f8:	55                   	push   bp
    51f9:	89 e5                	mov    bp,sp
    51fb:	31 c0                	xor    ax,ax
    51fd:	9a 44 04 2b 52       	call   0x522b:0x444
    5202:	6a 01                	push   0x1
    5204:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5207:	26 c4 bd 6c 02       	les    di,DWORD PTR es:[di+0x26c]
    520c:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    5210:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    5214:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5218:	06                   	push   es
    5219:	57                   	push   di
    521a:	9a b2 77 3c 52       	call   0x523c:0x77b2
    521f:	c9                   	leave
    5220:	ca 08 00             	retf   0x8
    5223:	55                   	push   bp
    5224:	89 e5                	mov    bp,sp
    5226:	31 c0                	xor    ax,ax
    5228:	9a 44 04 4a 52       	call   0x524a:0x444
    522d:	6a 03                	push   0x3
    522f:	6a 00                	push   0x0
    5231:	6a 00                	push   0x0
    5233:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5237:	06                   	push   es
    5238:	57                   	push   di
    5239:	9a b2 77 5d 52       	call   0x525d:0x77b2
    523e:	c9                   	leave
    523f:	ca 08 00             	retf   0x8
    5242:	55                   	push   bp
    5243:	89 e5                	mov    bp,sp
    5245:	31 c0                	xor    ax,ax
    5247:	9a 44 04 6b 52       	call   0x526b:0x444
    524c:	68 05 01             	push   0x105
    524f:	bf d2 01             	mov    di,0x1d2
    5252:	1e                   	push   ds
    5253:	57                   	push   di
    5254:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5258:	06                   	push   es
    5259:	57                   	push   di
    525a:	9a b2 77 7c 52       	call   0x527c:0x77b2
    525f:	c9                   	leave
    5260:	ca 08 00             	retf   0x8
    5263:	55                   	push   bp
    5264:	89 e5                	mov    bp,sp
    5266:	31 c0                	xor    ax,ax
    5268:	9a 44 04 8b 52       	call   0x528b:0x444
    526d:	6a 04                	push   0x4
    526f:	6a 00                	push   0x0
    5271:	6a 00                	push   0x0
    5273:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5277:	06                   	push   es
    5278:	57                   	push   di
    5279:	9a b2 77 99 52       	call   0x5299:0x77b2
    527e:	c9                   	leave
    527f:	ca 08 00             	retf   0x8
    5282:	55                   	push   bp
    5283:	89 e5                	mov    bp,sp
    5285:	b8 04 00             	mov    ax,0x4
    5288:	9a 44 04 a8 52       	call   0x52a8:0x444
    528d:	83 ec 04             	sub    sp,0x4
    5290:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    5294:	06                   	push   es
    5295:	57                   	push   di
    5296:	9a 45 5d 14 53       	call   0x5314:0x5d45
    529b:	c9                   	leave
    529c:	ca 08 00             	retf   0x8
    529f:	55                   	push   bp
    52a0:	89 e5                	mov    bp,sp
    52a2:	b8 04 00             	mov    ax,0x4
    52a5:	9a 44 04 23 53       	call   0x5323:0x444
    52aa:	83 ec 04             	sub    sp,0x4
    52ad:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    52b0:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    52b5:	b0 00                	mov    al,0x0
    52b7:	75 01                	jne    0x52ba
    52b9:	40                   	inc    ax
    52ba:	8a c8                	mov    cl,al
    52bc:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    52c2:	b0 00                	mov    al,0x0
    52c4:	77 01                	ja     0x52c7
    52c6:	40                   	inc    ax
    52c7:	8a d0                	mov    dl,al
    52c9:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    52cf:	b0 00                	mov    al,0x0
    52d1:	76 01                	jbe    0x52d4
    52d3:	40                   	inc    ax
    52d4:	22 c2                	and    al,dl
    52d6:	0a c1                	or     al,cl
    52d8:	08 c0                	or     al,al
    52da:	74 3a                	je     0x5316
    52dc:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    52e0:	31 c0                	xor    ax,ax
    52e2:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    52e6:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    52ea:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    52ee:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    52f2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    52f5:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    52f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52fc:	06                   	push   es
    52fd:	57                   	push   di
    52fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5301:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    5305:	6a 02                	push   0x2
    5307:	6a 00                	push   0x0
    5309:	6a 00                	push   0x0
    530b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    530f:	06                   	push   es
    5310:	57                   	push   di
    5311:	9a b2 77 a3 53       	call   0x53a3:0x77b2
    5316:	c9                   	leave
    5317:	ca 0c 00             	retf   0xc
    531a:	55                   	push   bp
    531b:	89 e5                	mov    bp,sp
    531d:	b8 04 00             	mov    ax,0x4
    5320:	9a 44 04 42 53       	call   0x5342:0x444
    5325:	83 ec 04             	sub    sp,0x4
    5328:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    532c:	74 03                	je     0x5331
    532e:	e9 9c 00             	jmp    0x53cd
    5331:	ff 76 14             	push   WORD PTR [bp+0x14]
    5334:	ff 76 12             	push   WORD PTR [bp+0x12]
    5337:	bf c1 05             	mov    di,0x5c1
    533a:	b8 55 53             	mov    ax,0x5355
    533d:	50                   	push   ax
    533e:	57                   	push   di
    533f:	9a 55 22 5c 53       	call   0x535c:0x2255
    5344:	08 c0                	or     al,al
    5346:	75 03                	jne    0x534b
    5348:	e9 82 00             	jmp    0x53cd
    534b:	ff 76 14             	push   WORD PTR [bp+0x14]
    534e:	ff 76 12             	push   WORD PTR [bp+0x12]
    5351:	bf c1 05             	mov    di,0x5c1
    5354:	b8 84 53             	mov    ax,0x5384
    5357:	50                   	push   ax
    5358:	57                   	push   di
    5359:	9a 73 22 8b 53       	call   0x538b:0x2273
    535e:	89 c7                	mov    di,ax
    5360:	8e c2                	mov    es,dx
    5362:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    5367:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    536c:	74 5f                	je     0x53cd
    536e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5372:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5375:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5378:	6a 08                	push   0x8
    537a:	ff 76 14             	push   WORD PTR [bp+0x14]
    537d:	ff 76 12             	push   WORD PTR [bp+0x12]
    5380:	bf c1 05             	mov    di,0x5c1
    5383:	b8 f5 56             	mov    ax,0x56f5
    5386:	50                   	push   ax
    5387:	57                   	push   di
    5388:	9a 73 22 d9 53       	call   0x53d9:0x2273
    538d:	89 c7                	mov    di,ax
    538f:	8e c2                	mov    es,dx
    5391:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    5396:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    539b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    539e:	06                   	push   es
    539f:	57                   	push   di
    53a0:	9a b2 77 ad 53       	call   0x53ad:0x77b2
    53a5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    53a8:	06                   	push   es
    53a9:	57                   	push   di
    53aa:	9a 03 73 ff ff       	call   0xffff:0x7303
    53af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53b2:	06                   	push   es
    53b3:	57                   	push   di
    53b4:	b8 9f 52             	mov    ax,0x529f
    53b7:	ba f6 53             	mov    dx,0x53f6
    53ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    53bd:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    53c1:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    53c5:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    53c9:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    53cd:	c9                   	leave
    53ce:	ca 10 00             	retf   0x10
    53d1:	55                   	push   bp
    53d2:	89 e5                	mov    bp,sp
    53d4:	31 c0                	xor    ax,ax
    53d6:	9a 44 04 0d 54       	call   0x540d:0x444
    53db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53de:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    53e3:	06                   	push   es
    53e4:	57                   	push   di
    53e5:	9a 17 2f ff ff       	call   0xffff:0x2f17
    53ea:	08 c0                	or     al,al
    53ec:	74 0a                	je     0x53f8
    53ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53f1:	06                   	push   es
    53f2:	57                   	push   di
    53f3:	9a 67 54 65 54       	call   0x5465:0x5467
    53f8:	c9                   	leave
    53f9:	ca 08 00             	retf   0x8
    53fc:	00 00                	add    BYTE PTR [bx+si],al
    53fe:	00 00                	add    BYTE PTR [bx+si],al
    5400:	ff                   	(bad)
    5401:	ff 00                	inc    WORD PTR [bx+si]
    5403:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5406:	e5 b8                	in     ax,0xb8
    5408:	26 00 9a 44 04       	add    BYTE PTR es:[bp+si+0x444],bl
    540d:	44                   	inc    sp
    540e:	54                   	push   sp
    540f:	83 ec 26             	sub    sp,0x26
    5412:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5416:	06                   	push   es
    5417:	57                   	push   di
    5418:	9a 04 2a 7f 54       	call   0x547f:0x2a04
    541d:	89 c7                	mov    di,ax
    541f:	8e c2                	mov    es,dx
    5421:	06                   	push   es
    5422:	57                   	push   di
    5423:	9a d2 21 d0 54       	call   0x54d0:0x21d2
    5428:	50                   	push   ax
    5429:	bf d4 01             	mov    di,0x1d4
    542c:	1e                   	push   ds
    542d:	57                   	push   di
    542e:	6a 01                	push   0x1
    5430:	8d 7e da             	lea    di,[bp-0x26]
    5433:	16                   	push   ss
    5434:	57                   	push   di
    5435:	9a ff ff 00 00       	call   0x0:0xffff
    543a:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    543d:	99                   	cwd
    543e:	bf fc 53             	mov    di,0x53fc
    5441:	9a 16 04 70 54       	call   0x5470:0x416
    5446:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5449:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    544c:	c9                   	leave
    544d:	ca 02 00             	retf   0x2
    5450:	00 01                	add    BYTE PTR [bx+di],al
    5452:	09 01                	or     WORD PTR [bx+di],ax
    5454:	20 03                	and    BYTE PTR [bp+di],al
    5456:	20 20                	and    BYTE PTR [bx+si],ah
    5458:	20 00                	and    BYTE PTR [bx+si],al
    545a:	80 ff ff             	cmp    bh,0xff
    545d:	ff                   	(bad)
    545e:	7f 00                	jg     0x5460
    5460:	00 00                	add    BYTE PTR [bx+si],al
    5462:	00 05                	add    BYTE PTR [di],al
    5464:	59                   	pop    cx
    5465:	04 55                	add    al,0x55
    5467:	55                   	push   bp
    5468:	89 e5                	mov    bp,sp
    546a:	b8 14 04             	mov    ax,0x414
    546d:	9a 44 04 8a 54       	call   0x548a:0x444
    5472:	81 ec 14 04          	sub    sp,0x414
    5476:	8d be fe fe          	lea    di,[bp-0x102]
    547a:	16                   	push   ss
    547b:	57                   	push   di
    547c:	9a 4e 20 a8 54       	call   0x54a8:0x204e
    5481:	8d be fe fe          	lea    di,[bp-0x102]
    5485:	16                   	push   ss
    5486:	57                   	push   di
    5487:	9a f5 09 8f 54       	call   0x548f:0x9f5
    548c:	9a 08 04 5e 55       	call   0x555e:0x408
    5491:	b8 61 54             	mov    ax,0x5461
    5494:	0e                   	push   cs
    5495:	50                   	push   ax
    5496:	55                   	push   bp
    5497:	ff 36 58 18          	push   WORD PTR ds:0x1858
    549b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    549f:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    54a3:	06                   	push   es
    54a4:	57                   	push   di
    54a5:	9a 04 2a 11 55       	call   0x5511:0x2a04
    54aa:	89 c7                	mov    di,ax
    54ac:	8e c2                	mov    es,dx
    54ae:	89 be ee fd          	mov    WORD PTR [bp-0x212],di
    54b2:	8c 86 f0 fd          	mov    WORD PTR [bp-0x210],es
    54b6:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    54ba:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    54bf:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    54c3:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    54c7:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    54cb:	06                   	push   es
    54cc:	57                   	push   di
    54cd:	9a 99 20 20 55       	call   0x5520:0x2099
    54d2:	c7 86 f6 fd 01 00    	mov    WORD PTR [bp-0x20a],0x1
    54d8:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    54dc:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    54e0:	b8 01 00             	mov    ax,0x1
    54e3:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    54e7:	7e 03                	jle    0x54ec
    54e9:	e9 0d 04             	jmp    0x58f9
    54ec:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    54f0:	eb 04                	jmp    0x54f6
    54f2:	ff 86 f4 fd          	inc    WORD PTR [bp-0x20c]
    54f6:	6a 01                	push   0x1
    54f8:	ff b6 f4 fd          	push   WORD PTR [bp-0x20c]
    54fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54ff:	06                   	push   es
    5500:	57                   	push   di
    5501:	9a 52 5f b8 56       	call   0x56b8:0x5f52
    5506:	6a 08                	push   0x8
    5508:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    550c:	06                   	push   es
    550d:	57                   	push   di
    550e:	9a 04 2a 2d 55       	call   0x552d:0x2a04
    5513:	89 c7                	mov    di,ax
    5515:	8e c2                	mov    es,dx
    5517:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    551b:	06                   	push   es
    551c:	57                   	push   di
    551d:	9a f5 11 3c 55       	call   0x553c:0x11f5
    5522:	6a 02                	push   0x2
    5524:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5528:	06                   	push   es
    5529:	57                   	push   di
    552a:	9a 04 2a 87 56       	call   0x5687:0x2a04
    552f:	89 c7                	mov    di,ax
    5531:	8e c2                	mov    es,dx
    5533:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5537:	06                   	push   es
    5538:	57                   	push   di
    5539:	9a 78 12 96 56       	call   0x5696:0x1278
    553e:	c7 86 f8 fd 01 00    	mov    WORD PTR [bp-0x208],0x1
    5544:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    5549:	eb 03                	jmp    0x554e
    554b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    554e:	8d be fe fe          	lea    di,[bp-0x102]
    5552:	16                   	push   ss
    5553:	57                   	push   di
    5554:	bf 50 54             	mov    di,0x5450
    5557:	0e                   	push   cs
    5558:	57                   	push   di
    5559:	6a 00                	push   0x0
    555b:	9a b5 0d 63 55       	call   0x5563:0xdb5
    5560:	9a 78 0c 68 55       	call   0x5568:0xc78
    5565:	9a 08 04 96 55       	call   0x5596:0x408
    556a:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
    556e:	75 db                	jne    0x554b
    5570:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5573:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    5578:	89 be ec fd          	mov    WORD PTR [bp-0x214],di
    557c:	8c 86 ee fd          	mov    WORD PTR [bp-0x212],es
    5580:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5585:	06                   	push   es
    5586:	57                   	push   di
    5587:	26 c4 3d             	les    di,DWORD PTR es:[di]
    558a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    558e:	2d 01 00             	sub    ax,0x1
    5591:	71 05                	jno    0x5598
    5593:	9a 3e 04 d6 55       	call   0x55d6:0x43e
    5598:	89 86 ea fd          	mov    WORD PTR [bp-0x216],ax
    559c:	31 c0                	xor    ax,ax
    559e:	3b 86 ea fd          	cmp    ax,WORD PTR [bp-0x216]
    55a2:	7e 03                	jle    0x55a7
    55a4:	e9 cd 00             	jmp    0x5674
    55a7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    55aa:	eb 03                	jmp    0x55af
    55ac:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    55af:	8d be ea fc          	lea    di,[bp-0x316]
    55b3:	16                   	push   ss
    55b4:	57                   	push   di
    55b5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    55b8:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    55bc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    55c1:	06                   	push   es
    55c2:	57                   	push   di
    55c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55c6:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    55ca:	8d be fe fd          	lea    di,[bp-0x202]
    55ce:	16                   	push   ss
    55cf:	57                   	push   di
    55d0:	68 ff 00             	push   0xff
    55d3:	9a e7 17 e6 55       	call   0x55e6:0x17e7
    55d8:	bf 51 54             	mov    di,0x5451
    55db:	0e                   	push   cs
    55dc:	57                   	push   di
    55dd:	8d be fe fd          	lea    di,[bp-0x202]
    55e1:	16                   	push   ss
    55e2:	57                   	push   di
    55e3:	9a 78 18 02 56       	call   0x5602:0x1878
    55e8:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    55ec:	83 be f2 fd 00       	cmp    WORD PTR [bp-0x20e],0x0
    55f1:	7e 28                	jle    0x561b
    55f3:	8d be fe fd          	lea    di,[bp-0x202]
    55f7:	16                   	push   ss
    55f8:	57                   	push   di
    55f9:	ff b6 f2 fd          	push   WORD PTR [bp-0x20e]
    55fd:	6a 01                	push   0x1
    55ff:	9a 75 19 19 56       	call   0x5619:0x1975
    5604:	bf 53 54             	mov    di,0x5453
    5607:	0e                   	push   cs
    5608:	57                   	push   di
    5609:	8d be fe fd          	lea    di,[bp-0x202]
    560d:	16                   	push   ss
    560e:	57                   	push   di
    560f:	68 ff 00             	push   0xff
    5612:	ff b6 f2 fd          	push   WORD PTR [bp-0x20e]
    5616:	9a 16 19 30 56       	call   0x5630:0x1916
    561b:	83 be f2 fd 00       	cmp    WORD PTR [bp-0x20e],0x0
    5620:	75 b6                	jne    0x55d8
    5622:	8d be ea fc          	lea    di,[bp-0x316]
    5626:	16                   	push   ss
    5627:	57                   	push   di
    5628:	bf 55 54             	mov    di,0x5455
    562b:	0e                   	push   cs
    562c:	57                   	push   di
    562d:	9a cd 17 3b 56       	call   0x563b:0x17cd
    5632:	8d be fe fd          	lea    di,[bp-0x202]
    5636:	16                   	push   ss
    5637:	57                   	push   di
    5638:	9a 4c 18 49 56       	call   0x5649:0x184c
    563d:	8d be fe fd          	lea    di,[bp-0x202]
    5641:	16                   	push   ss
    5642:	57                   	push   di
    5643:	68 ff 00             	push   0xff
    5646:	9a e7 17 5c 56       	call   0x565c:0x17e7
    564b:	8d be fe fe          	lea    di,[bp-0x102]
    564f:	16                   	push   ss
    5650:	57                   	push   di
    5651:	8d be fe fd          	lea    di,[bp-0x202]
    5655:	16                   	push   ss
    5656:	57                   	push   di
    5657:	6a 00                	push   0x0
    5659:	9a b5 0d 61 56       	call   0x5661:0xdb5
    565e:	9a 78 0c 66 56       	call   0x5666:0xc78
    5663:	9a 08 04 c2 56       	call   0x56c2:0x408
    5668:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    566b:	3b 86 ea fd          	cmp    ax,WORD PTR [bp-0x216]
    566f:	74 03                	je     0x5674
    5671:	e9 38 ff             	jmp    0x55ac
    5674:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5678:	89 be ec fd          	mov    WORD PTR [bp-0x214],di
    567c:	8c 86 ee fd          	mov    WORD PTR [bp-0x212],es
    5680:	6a 06                	push   0x6
    5682:	06                   	push   es
    5683:	57                   	push   di
    5684:	9a 04 2a a3 56       	call   0x56a3:0x2a04
    5689:	89 c7                	mov    di,ax
    568b:	8e c2                	mov    es,dx
    568d:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5691:	06                   	push   es
    5692:	57                   	push   di
    5693:	9a f5 11 b2 56       	call   0x56b2:0x11f5
    5698:	6a 00                	push   0x0
    569a:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    569e:	06                   	push   es
    569f:	57                   	push   di
    56a0:	9a 04 2a 26 57       	call   0x5726:0x2a04
    56a5:	89 c7                	mov    di,ax
    56a7:	8e c2                	mov    es,dx
    56a9:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    56ad:	06                   	push   es
    56ae:	57                   	push   di
    56af:	9a 78 12 4d 57       	call   0x574d:0x1278
    56b4:	55                   	push   bp
    56b5:	9a 04 54 43 59       	call   0x5943:0x5404
    56ba:	05 02 00             	add    ax,0x2
    56bd:	73 05                	jae    0x56c4
    56bf:	9a 3e 04 cc 56       	call   0x56cc:0x43e
    56c4:	31 d2                	xor    dx,dx
    56c6:	bf 59 54             	mov    di,0x5459
    56c9:	9a 16 04 e0 56       	call   0x56e0:0x416
    56ce:	89 86 fc fd          	mov    WORD PTR [bp-0x204],ax
    56d2:	8d be ec fb          	lea    di,[bp-0x414]
    56d6:	16                   	push   ss
    56d7:	57                   	push   di
    56d8:	bf 55 54             	mov    di,0x5455
    56db:	0e                   	push   cs
    56dc:	57                   	push   di
    56dd:	9a cd 17 fa 56       	call   0x56fa:0x17cd
    56e2:	8d be ec fc          	lea    di,[bp-0x314]
    56e6:	16                   	push   ss
    56e7:	57                   	push   di
    56e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56eb:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    56f0:	06                   	push   es
    56f1:	57                   	push   di
    56f2:	9a 53 1d 72 57       	call   0x5772:0x1d53
    56f7:	9a 4c 18 08 57       	call   0x5708:0x184c
    56fc:	8d be fe fd          	lea    di,[bp-0x202]
    5700:	16                   	push   ss
    5701:	57                   	push   di
    5702:	68 ff 00             	push   0xff
    5705:	9a e7 17 1a 57       	call   0x571a:0x17e7
    570a:	6a 00                	push   0x0
    570c:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    5710:	b9 05 00             	mov    cx,0x5
    5713:	f7 e9                	imul   cx
    5715:	71 05                	jno    0x571c
    5717:	9a 3e 04 30 57       	call   0x5730:0x43e
    571c:	50                   	push   ax
    571d:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    5721:	06                   	push   es
    5722:	57                   	push   di
    5723:	9a 72 2a 42 57       	call   0x5742:0x2a72
    5728:	5a                   	pop    dx
    5729:	2b c2                	sub    ax,dx
    572b:	71 05                	jno    0x5732
    572d:	9a 3e 04 5d 57       	call   0x575d:0x43e
    5732:	50                   	push   ax
    5733:	8d be fe fd          	lea    di,[bp-0x202]
    5737:	16                   	push   ss
    5738:	57                   	push   di
    5739:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    573d:	06                   	push   es
    573e:	57                   	push   di
    573f:	9a 04 2a a3 57       	call   0x57a3:0x2a04
    5744:	89 c7                	mov    di,ax
    5746:	8e c2                	mov    es,dx
    5748:	06                   	push   es
    5749:	57                   	push   di
    574a:	9a 09 1f ca 57       	call   0x57ca:0x1f09
    574f:	8d be ec fb          	lea    di,[bp-0x414]
    5753:	16                   	push   ss
    5754:	57                   	push   di
    5755:	bf 55 54             	mov    di,0x5455
    5758:	0e                   	push   cs
    5759:	57                   	push   di
    575a:	9a cd 17 77 57       	call   0x5777:0x17cd
    575f:	8d be ec fc          	lea    di,[bp-0x314]
    5763:	16                   	push   ss
    5764:	57                   	push   di
    5765:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5768:	26 c4 bd 98 02       	les    di,DWORD PTR es:[di+0x298]
    576d:	06                   	push   es
    576e:	57                   	push   di
    576f:	9a 53 1d ef 57       	call   0x57ef:0x1d53
    5774:	9a 4c 18 85 57       	call   0x5785:0x184c
    5779:	8d be fe fd          	lea    di,[bp-0x202]
    577d:	16                   	push   ss
    577e:	57                   	push   di
    577f:	68 ff 00             	push   0xff
    5782:	9a e7 17 97 57       	call   0x5797:0x17e7
    5787:	6a 00                	push   0x0
    5789:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    578d:	b9 04 00             	mov    cx,0x4
    5790:	f7 e9                	imul   cx
    5792:	71 05                	jno    0x5799
    5794:	9a 3e 04 ad 57       	call   0x57ad:0x43e
    5799:	50                   	push   ax
    579a:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    579e:	06                   	push   es
    579f:	57                   	push   di
    57a0:	9a 72 2a bf 57       	call   0x57bf:0x2a72
    57a5:	5a                   	pop    dx
    57a6:	2b c2                	sub    ax,dx
    57a8:	71 05                	jno    0x57af
    57aa:	9a 3e 04 da 57       	call   0x57da:0x43e
    57af:	50                   	push   ax
    57b0:	8d be fe fd          	lea    di,[bp-0x202]
    57b4:	16                   	push   ss
    57b5:	57                   	push   di
    57b6:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    57ba:	06                   	push   es
    57bb:	57                   	push   di
    57bc:	9a 04 2a 20 58       	call   0x5820:0x2a04
    57c1:	89 c7                	mov    di,ax
    57c3:	8e c2                	mov    es,dx
    57c5:	06                   	push   es
    57c6:	57                   	push   di
    57c7:	9a 09 1f 47 58       	call   0x5847:0x1f09
    57cc:	8d be ec fb          	lea    di,[bp-0x414]
    57d0:	16                   	push   ss
    57d1:	57                   	push   di
    57d2:	bf 55 54             	mov    di,0x5455
    57d5:	0e                   	push   cs
    57d6:	57                   	push   di
    57d7:	9a cd 17 f4 57       	call   0x57f4:0x17cd
    57dc:	8d be ec fc          	lea    di,[bp-0x314]
    57e0:	16                   	push   ss
    57e1:	57                   	push   di
    57e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57e5:	26 c4 bd 9c 02       	les    di,DWORD PTR es:[di+0x29c]
    57ea:	06                   	push   es
    57eb:	57                   	push   di
    57ec:	9a 53 1d 6c 58       	call   0x586c:0x1d53
    57f1:	9a 4c 18 02 58       	call   0x5802:0x184c
    57f6:	8d be fe fd          	lea    di,[bp-0x202]
    57fa:	16                   	push   ss
    57fb:	57                   	push   di
    57fc:	68 ff 00             	push   0xff
    57ff:	9a e7 17 14 58       	call   0x5814:0x17e7
    5804:	6a 00                	push   0x0
    5806:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    580a:	b9 03 00             	mov    cx,0x3
    580d:	f7 e9                	imul   cx
    580f:	71 05                	jno    0x5816
    5811:	9a 3e 04 2a 58       	call   0x582a:0x43e
    5816:	50                   	push   ax
    5817:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    581b:	06                   	push   es
    581c:	57                   	push   di
    581d:	9a 72 2a 3c 58       	call   0x583c:0x2a72
    5822:	5a                   	pop    dx
    5823:	2b c2                	sub    ax,dx
    5825:	71 05                	jno    0x582c
    5827:	9a 3e 04 57 58       	call   0x5857:0x43e
    582c:	50                   	push   ax
    582d:	8d be fe fd          	lea    di,[bp-0x202]
    5831:	16                   	push   ss
    5832:	57                   	push   di
    5833:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    5837:	06                   	push   es
    5838:	57                   	push   di
    5839:	9a 04 2a 9d 58       	call   0x589d:0x2a04
    583e:	89 c7                	mov    di,ax
    5840:	8e c2                	mov    es,dx
    5842:	06                   	push   es
    5843:	57                   	push   di
    5844:	9a 09 1f c4 58       	call   0x58c4:0x1f09
    5849:	8d be ec fb          	lea    di,[bp-0x414]
    584d:	16                   	push   ss
    584e:	57                   	push   di
    584f:	bf 55 54             	mov    di,0x5455
    5852:	0e                   	push   cs
    5853:	57                   	push   di
    5854:	9a cd 17 71 58       	call   0x5871:0x17cd
    5859:	8d be ec fc          	lea    di,[bp-0x314]
    585d:	16                   	push   ss
    585e:	57                   	push   di
    585f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5862:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    5867:	06                   	push   es
    5868:	57                   	push   di
    5869:	9a 53 1d 12 5a       	call   0x5a12:0x1d53
    586e:	9a 4c 18 7f 58       	call   0x587f:0x184c
    5873:	8d be fe fd          	lea    di,[bp-0x202]
    5877:	16                   	push   ss
    5878:	57                   	push   di
    5879:	68 ff 00             	push   0xff
    587c:	9a e7 17 91 58       	call   0x5891:0x17e7
    5881:	6a 00                	push   0x0
    5883:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    5887:	b9 02 00             	mov    cx,0x2
    588a:	f7 e9                	imul   cx
    588c:	71 05                	jno    0x5893
    588e:	9a 3e 04 a7 58       	call   0x58a7:0x43e
    5893:	50                   	push   ax
    5894:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    5898:	06                   	push   es
    5899:	57                   	push   di
    589a:	9a 72 2a b9 58       	call   0x58b9:0x2a72
    589f:	5a                   	pop    dx
    58a0:	2b c2                	sub    ax,dx
    58a2:	71 05                	jno    0x58a9
    58a4:	9a 3e 04 e0 58       	call   0x58e0:0x43e
    58a9:	50                   	push   ax
    58aa:	8d be fe fd          	lea    di,[bp-0x202]
    58ae:	16                   	push   ss
    58af:	57                   	push   di
    58b0:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    58b4:	06                   	push   es
    58b5:	57                   	push   di
    58b6:	9a 04 2a ff ff       	call   0xffff:0x2a04
    58bb:	89 c7                	mov    di,ax
    58bd:	8e c2                	mov    es,dx
    58bf:	06                   	push   es
    58c0:	57                   	push   di
    58c1:	9a 09 1f ff ff       	call   0xffff:0x1f09
    58c6:	8b 86 f4 fd          	mov    ax,WORD PTR [bp-0x20c]
    58ca:	3b 86 f6 fd          	cmp    ax,WORD PTR [bp-0x20a]
    58ce:	7d 1c                	jge    0x58ec
    58d0:	8d be fe fe          	lea    di,[bp-0x102]
    58d4:	16                   	push   ss
    58d5:	57                   	push   di
    58d6:	bf 50 54             	mov    di,0x5450
    58d9:	0e                   	push   cs
    58da:	57                   	push   di
    58db:	6a 00                	push   0x0
    58dd:	9a b5 0d e5 58       	call   0x58e5:0xdb5
    58e2:	9a 78 0c ea 58       	call   0x58ea:0xc78
    58e7:	9a 08 04 0e 59       	call   0x590e:0x408
    58ec:	8b 86 f4 fd          	mov    ax,WORD PTR [bp-0x20c]
    58f0:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    58f4:	74 03                	je     0x58f9
    58f6:	e9 f9 fb             	jmp    0x54f2
    58f9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    58fd:	83 c4 06             	add    sp,0x6
    5900:	b8 25 59             	mov    ax,0x5925
    5903:	0e                   	push   cs
    5904:	50                   	push   ax
    5905:	8d be fe fe          	lea    di,[bp-0x102]
    5909:	16                   	push   ss
    590a:	57                   	push   di
    590b:	9a 4f 0a 13 59       	call   0x5913:0xa4f
    5910:	9a 08 04 32 59       	call   0x5932:0x408
    5915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5918:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    591d:	06                   	push   es
    591e:	57                   	push   di
    591f:	9a e3 49 58 59       	call   0x5958:0x49e3
    5924:	cb                   	retf
    5925:	c9                   	leave
    5926:	ca 04 00             	retf   0x4
    5929:	55                   	push   bp
    592a:	89 e5                	mov    bp,sp
    592c:	b8 04 00             	mov    ax,0x4
    592f:	9a 44 04 7d 59       	call   0x597d:0x444
    5934:	83 ec 04             	sub    sp,0x4
    5937:	6a 00                	push   0x0
    5939:	6a 00                	push   0x0
    593b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    593e:	06                   	push   es
    593f:	57                   	push   di
    5940:	9a 52 5f 97 5f       	call   0x5f97:0x5f52
    5945:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5948:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    594d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5950:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5953:	06                   	push   es
    5954:	57                   	push   di
    5955:	9a 3f 4a 62 59       	call   0x5962:0x4a3f
    595a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    595d:	06                   	push   es
    595e:	57                   	push   di
    595f:	9a ff 49 6c 59       	call   0x596c:0x49ff
    5964:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5967:	06                   	push   es
    5968:	57                   	push   di
    5969:	9a e3 49 ca 59       	call   0x59ca:0x49e3
    596e:	c9                   	leave
    596f:	ca 08 00             	retf   0x8
    5972:	01 09                	add    WORD PTR [bx+di],cx
    5974:	55                   	push   bp
    5975:	89 e5                	mov    bp,sp
    5977:	b8 04 02             	mov    ax,0x204
    597a:	9a 44 04 9a 59       	call   0x599a:0x444
    597f:	81 ec 04 02          	sub    sp,0x204
    5983:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5986:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    598a:	76 27                	jbe    0x59b3
    598c:	8d be 00 ff          	lea    di,[bp-0x100]
    5990:	16                   	push   ss
    5991:	57                   	push   di
    5992:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5995:	06                   	push   es
    5996:	57                   	push   di
    5997:	9a cd 17 a4 59       	call   0x59a4:0x17cd
    599c:	bf 72 59             	mov    di,0x5972
    599f:	0e                   	push   cs
    59a0:	57                   	push   di
    59a1:	9a 4c 18 b1 59       	call   0x59b1:0x184c
    59a6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    59a9:	06                   	push   es
    59aa:	57                   	push   di
    59ab:	ff 76 0c             	push   WORD PTR [bp+0xc]
    59ae:	9a e7 17 d1 59       	call   0x59d1:0x17e7
    59b3:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    59b6:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    59bb:	75 03                	jne    0x59c0
    59bd:	e9 cc 00             	jmp    0x5a8c
    59c0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    59c3:	ff 76 08             	push   WORD PTR [bp+0x8]
    59c6:	bf 0c 01             	mov    di,0x10c
    59c9:	b8 e1 59             	mov    ax,0x59e1
    59cc:	50                   	push   ax
    59cd:	57                   	push   di
    59ce:	9a 55 22 e8 59       	call   0x59e8:0x2255
    59d3:	08 c0                	or     al,al
    59d5:	74 4f                	je     0x5a26
    59d7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    59da:	ff 76 08             	push   WORD PTR [bp+0x8]
    59dd:	bf 0c 01             	mov    di,0x10c
    59e0:	b8 76 5f             	mov    ax,0x5f76
    59e3:	50                   	push   ax
    59e4:	57                   	push   di
    59e5:	9a 73 22 02 5a       	call   0x5a02:0x2273
    59ea:	89 c7                	mov    di,ax
    59ec:	8e c2                	mov    es,dx
    59ee:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    59f1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    59f4:	8d be fc fd          	lea    di,[bp-0x204]
    59f8:	16                   	push   ss
    59f9:	57                   	push   di
    59fa:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    59fd:	06                   	push   es
    59fe:	57                   	push   di
    59ff:	9a cd 17 17 5a       	call   0x5a17:0x17cd
    5a04:	8d be fc fe          	lea    di,[bp-0x104]
    5a08:	16                   	push   ss
    5a09:	57                   	push   di
    5a0a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5a0d:	06                   	push   es
    5a0e:	57                   	push   di
    5a0f:	9a 53 1d 78 5a       	call   0x5a78:0x1d53
    5a14:	9a 4c 18 24 5a       	call   0x5a24:0x184c
    5a19:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5a1c:	06                   	push   es
    5a1d:	57                   	push   di
    5a1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5a21:	9a e7 17 37 5a       	call   0x5a37:0x17e7
    5a26:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5a29:	ff 76 08             	push   WORD PTR [bp+0x8]
    5a2c:	bf ad 0d             	mov    di,0xdad
    5a2f:	b8 47 5a             	mov    ax,0x5a47
    5a32:	50                   	push   ax
    5a33:	57                   	push   di
    5a34:	9a 55 22 4e 5a       	call   0x5a4e:0x2255
    5a39:	08 c0                	or     al,al
    5a3b:	74 4f                	je     0x5a8c
    5a3d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5a40:	ff 76 08             	push   WORD PTR [bp+0x8]
    5a43:	bf ad 0d             	mov    di,0xdad
    5a46:	b8 ff ff             	mov    ax,0xffff
    5a49:	50                   	push   ax
    5a4a:	57                   	push   di
    5a4b:	9a 73 22 68 5a       	call   0x5a68:0x2273
    5a50:	89 c7                	mov    di,ax
    5a52:	8e c2                	mov    es,dx
    5a54:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5a57:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5a5a:	8d be fc fd          	lea    di,[bp-0x204]
    5a5e:	16                   	push   ss
    5a5f:	57                   	push   di
    5a60:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5a63:	06                   	push   es
    5a64:	57                   	push   di
    5a65:	9a cd 17 7d 5a       	call   0x5a7d:0x17cd
    5a6a:	8d be fc fe          	lea    di,[bp-0x104]
    5a6e:	16                   	push   ss
    5a6f:	57                   	push   di
    5a70:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5a73:	06                   	push   es
    5a74:	57                   	push   di
    5a75:	9a 53 1d e2 5a       	call   0x5ae2:0x1d53
    5a7a:	9a 4c 18 8a 5a       	call   0x5a8a:0x184c
    5a7f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5a82:	06                   	push   es
    5a83:	57                   	push   di
    5a84:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5a87:	9a e7 17 bb 5a       	call   0x5abb:0x17e7
    5a8c:	c9                   	leave
    5a8d:	ca 0c 00             	retf   0xc
    5a90:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    5a94:	ff                   	(bad)
    5a95:	7f 00                	jg     0x5a97
    5a97:	00 04                	add    BYTE PTR [si],al
    5a99:	20 20                	and    BYTE PTR [bx+si],ah
    5a9b:	20 20                	and    BYTE PTR [bx+si],ah
    5a9d:	02 23                	add    ah,BYTE PTR [bp+di]
    5a9f:	43                   	inc    bx
    5aa0:	02 23                	add    ah,BYTE PTR [bp+di]
    5aa2:	26 01 09             	add    WORD PTR es:[bx+di],cx
    5aa5:	02 23                	add    ah,BYTE PTR [bp+di]
    5aa7:	41                   	inc    cx
    5aa8:	00 00                	add    BYTE PTR [bx+si],al
    5aaa:	00 00                	add    BYTE PTR [bx+si],al
    5aac:	ff 00                	inc    WORD PTR [bx+si]
    5aae:	00 00                	add    BYTE PTR [bx+si],al
    5ab0:	01 20                	add    WORD PTR [bx+si],sp
    5ab2:	55                   	push   bp
    5ab3:	89 e5                	mov    bp,sp
    5ab5:	b8 18 03             	mov    ax,0x318
    5ab8:	9a 44 04 93 5b       	call   0x5b93:0x444
    5abd:	81 ec 18 03          	sub    sp,0x318
    5ac1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5ac4:	89 be ee fd          	mov    WORD PTR [bp-0x212],di
    5ac8:	8c 86 f0 fd          	mov    WORD PTR [bp-0x210],es
    5acc:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5ad1:	74 2b                	je     0x5afe
    5ad3:	8d be ee fc          	lea    di,[bp-0x312]
    5ad7:	16                   	push   ss
    5ad8:	57                   	push   di
    5ad9:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    5add:	06                   	push   es
    5ade:	57                   	push   di
    5adf:	9a 53 1d 2e 60       	call   0x602e:0x1d53
    5ae4:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    5ae7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5aeb:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    5af0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5af5:	06                   	push   es
    5af6:	57                   	push   di
    5af7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5afa:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5afe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5b01:	89 be ee fd          	mov    WORD PTR [bp-0x212],di
    5b05:	8c 86 f0 fd          	mov    WORD PTR [bp-0x210],es
    5b09:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5b0e:	75 03                	jne    0x5b13
    5b10:	e9 2d 04             	jmp    0x5f40
    5b13:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    5b16:	3d 01 00             	cmp    ax,0x1
    5b19:	75 08                	jne    0x5b23
    5b1b:	c7 86 f8 fd 01 00    	mov    WORD PTR [bp-0x208],0x1
    5b21:	eb 1f                	jmp    0x5b42
    5b23:	3d 02 00             	cmp    ax,0x2
    5b26:	75 17                	jne    0x5b3f
    5b28:	83 3e 4e 01 04       	cmp    WORD PTR ds:0x14e,0x4
    5b2d:	7e 08                	jle    0x5b37
    5b2f:	c7 86 f8 fd 02 00    	mov    WORD PTR [bp-0x208],0x2
    5b35:	eb 06                	jmp    0x5b3d
    5b37:	c7 86 f8 fd 01 00    	mov    WORD PTR [bp-0x208],0x1
    5b3d:	eb 03                	jmp    0x5b42
    5b3f:	e9 fe 03             	jmp    0x5f40
    5b42:	c7 86 f4 fd 01 00    	mov    WORD PTR [bp-0x20c],0x1
    5b48:	c7 86 f2 fd 03 00    	mov    WORD PTR [bp-0x20e],0x3
    5b4e:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    5b52:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    5b56:	b8 01 00             	mov    ax,0x1
    5b59:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    5b5d:	7e 03                	jle    0x5b62
    5b5f:	e9 de 03             	jmp    0x5f40
    5b62:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    5b66:	eb 04                	jmp    0x5b6c
    5b68:	ff 86 f6 fd          	inc    WORD PTR [bp-0x20a]
    5b6c:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    5b6f:	3d 01 00             	cmp    ax,0x1
    5b72:	75 2f                	jne    0x5ba3
    5b74:	c7 86 f4 fd 01 00    	mov    WORD PTR [bp-0x20c],0x1
    5b7a:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    5b7e:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5b83:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    5b88:	2d 01 00             	sub    ax,0x1
    5b8b:	83 da 00             	sbb    dx,0x0
    5b8e:	71 05                	jno    0x5b95
    5b90:	9a 3e 04 9b 5b       	call   0x5b9b:0x43e
    5b95:	bf 90 5a             	mov    di,0x5a90
    5b98:	9a 16 04 f5 5b       	call   0x5bf5:0x416
    5b9d:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    5ba1:	eb 39                	jmp    0x5bdc
    5ba3:	3d 02 00             	cmp    ax,0x2
    5ba6:	75 34                	jne    0x5bdc
    5ba8:	83 be f6 fd 01       	cmp    WORD PTR [bp-0x20a],0x1
    5bad:	75 1e                	jne    0x5bcd
    5baf:	c7 86 f4 fd 01 00    	mov    WORD PTR [bp-0x20c],0x1
    5bb5:	83 be f8 fd 02       	cmp    WORD PTR [bp-0x208],0x2
    5bba:	75 08                	jne    0x5bc4
    5bbc:	c7 86 f2 fd 04 00    	mov    WORD PTR [bp-0x20e],0x4
    5bc2:	eb 07                	jmp    0x5bcb
    5bc4:	a1 4e 01             	mov    ax,ds:0x14e
    5bc7:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    5bcb:	eb 0d                	jmp    0x5bda
    5bcd:	c7 86 f4 fd 05 00    	mov    WORD PTR [bp-0x20c],0x5
    5bd3:	a1 4e 01             	mov    ax,ds:0x14e
    5bd6:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    5bda:	eb 00                	jmp    0x5bdc
    5bdc:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    5be0:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    5be5:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    5bea:	2d 01 00             	sub    ax,0x1
    5bed:	83 da 00             	sbb    dx,0x0
    5bf0:	71 05                	jno    0x5bf7
    5bf2:	9a 3e 04 fd 5b       	call   0x5bfd:0x43e
    5bf7:	bf 90 5a             	mov    di,0x5a90
    5bfa:	9a 16 04 42 5c       	call   0x5c42:0x416
    5bff:	89 86 ea fd          	mov    WORD PTR [bp-0x216],ax
    5c03:	31 c0                	xor    ax,ax
    5c05:	3b 86 ea fd          	cmp    ax,WORD PTR [bp-0x216]
    5c09:	7e 03                	jle    0x5c0e
    5c0b:	e9 25 03             	jmp    0x5f33
    5c0e:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    5c12:	eb 04                	jmp    0x5c18
    5c14:	ff 86 fe fd          	inc    WORD PTR [bp-0x202]
    5c18:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    5c1c:	99                   	cwd
    5c1d:	52                   	push   dx
    5c1e:	50                   	push   ax
    5c1f:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    5c23:	06                   	push   es
    5c24:	57                   	push   di
    5c25:	9a 8b 6e ca 5c       	call   0x5cca:0x6e8b
    5c2a:	09 c0                	or     ax,ax
    5c2c:	7f 03                	jg     0x5c31
    5c2e:	e9 f5 02             	jmp    0x5f26
    5c31:	bf 98 5a             	mov    di,0x5a98
    5c34:	0e                   	push   cs
    5c35:	57                   	push   di
    5c36:	8d be 00 ff          	lea    di,[bp-0x100]
    5c3a:	16                   	push   ss
    5c3b:	57                   	push   di
    5c3c:	68 ff 00             	push   0xff
    5c3f:	9a e7 17 5d 5c       	call   0x5c5d:0x17e7
    5c44:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    5c48:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5c4d:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    5c52:	2d 01 00             	sub    ax,0x1
    5c55:	83 da 00             	sbb    dx,0x0
    5c58:	71 05                	jno    0x5c5f
    5c5a:	9a 3e 04 65 5c       	call   0x5c65:0x43e
    5c5f:	bf 90 5a             	mov    di,0x5a90
    5c62:	9a 16 04 d8 5c       	call   0x5cd8:0x416
    5c67:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    5c6b:	31 c0                	xor    ax,ax
    5c6d:	3b 86 e8 fd          	cmp    ax,WORD PTR [bp-0x218]
    5c71:	7e 03                	jle    0x5c76
    5c73:	e9 90 02             	jmp    0x5f06
    5c76:	89 86 fc fd          	mov    WORD PTR [bp-0x204],ax
    5c7a:	eb 04                	jmp    0x5c80
    5c7c:	ff 86 fc fd          	inc    WORD PTR [bp-0x204]
    5c80:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    5c84:	3b 86 f2 fd          	cmp    ax,WORD PTR [bp-0x20e]
    5c88:	b0 00                	mov    al,0x0
    5c8a:	7f 01                	jg     0x5c8d
    5c8c:	40                   	inc    ax
    5c8d:	8a d0                	mov    dl,al
    5c8f:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    5c93:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    5c97:	b0 00                	mov    al,0x0
    5c99:	7c 01                	jl     0x5c9c
    5c9b:	40                   	inc    ax
    5c9c:	22 c2                	and    al,dl
    5c9e:	8a d0                	mov    dl,al
    5ca0:	83 be fc fd 01       	cmp    WORD PTR [bp-0x204],0x1
    5ca5:	b0 00                	mov    al,0x0
    5ca7:	7d 01                	jge    0x5caa
    5ca9:	40                   	inc    ax
    5caa:	0a c2                	or     al,dl
    5cac:	08 c0                	or     al,al
    5cae:	75 03                	jne    0x5cb3
    5cb0:	e9 46 02             	jmp    0x5ef9
    5cb3:	8d be e8 fc          	lea    di,[bp-0x318]
    5cb7:	16                   	push   ss
    5cb8:	57                   	push   di
    5cb9:	ff b6 fc fd          	push   WORD PTR [bp-0x204]
    5cbd:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    5cc1:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    5cc5:	06                   	push   es
    5cc6:	57                   	push   di
    5cc7:	9a 68 9a ff ff       	call   0xffff:0x9a68
    5ccc:	8d be 00 fe          	lea    di,[bp-0x200]
    5cd0:	16                   	push   ss
    5cd1:	57                   	push   di
    5cd2:	68 ff 00             	push   0xff
    5cd5:	9a e7 17 e8 5c       	call   0x5ce8:0x17e7
    5cda:	bf 9d 5a             	mov    di,0x5a9d
    5cdd:	0e                   	push   cs
    5cde:	57                   	push   di
    5cdf:	8d be 00 fe          	lea    di,[bp-0x200]
    5ce3:	16                   	push   ss
    5ce4:	57                   	push   di
    5ce5:	9a 78 18 04 5d       	call   0x5d04:0x1878
    5cea:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5cee:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    5cf3:	7e 11                	jle    0x5d06
    5cf5:	8d be 00 fe          	lea    di,[bp-0x200]
    5cf9:	16                   	push   ss
    5cfa:	57                   	push   di
    5cfb:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    5cff:	6a 03                	push   0x3
    5d01:	9a 75 19 1b 5d       	call   0x5d1b:0x1975
    5d06:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    5d0b:	75 cd                	jne    0x5cda
    5d0d:	bf a0 5a             	mov    di,0x5aa0
    5d10:	0e                   	push   cs
    5d11:	57                   	push   di
    5d12:	8d be 00 fe          	lea    di,[bp-0x200]
    5d16:	16                   	push   ss
    5d17:	57                   	push   di
    5d18:	9a 78 18 37 5d       	call   0x5d37:0x1878
    5d1d:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5d21:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    5d26:	7e 28                	jle    0x5d50
    5d28:	8d be 00 fe          	lea    di,[bp-0x200]
    5d2c:	16                   	push   ss
    5d2d:	57                   	push   di
    5d2e:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    5d32:	6a 02                	push   0x2
    5d34:	9a 75 19 4e 5d       	call   0x5d4e:0x1975
    5d39:	bf a3 5a             	mov    di,0x5aa3
    5d3c:	0e                   	push   cs
    5d3d:	57                   	push   di
    5d3e:	8d be 00 fe          	lea    di,[bp-0x200]
    5d42:	16                   	push   ss
    5d43:	57                   	push   di
    5d44:	68 ff 00             	push   0xff
    5d47:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    5d4b:	9a 16 19 65 5d       	call   0x5d65:0x1916
    5d50:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    5d55:	75 b6                	jne    0x5d0d
    5d57:	bf a5 5a             	mov    di,0x5aa5
    5d5a:	0e                   	push   cs
    5d5b:	57                   	push   di
    5d5c:	8d be 00 fe          	lea    di,[bp-0x200]
    5d60:	16                   	push   ss
    5d61:	57                   	push   di
    5d62:	9a 78 18 81 5d       	call   0x5d81:0x1878
    5d67:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5d6b:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    5d70:	7e 11                	jle    0x5d83
    5d72:	8d be 00 fe          	lea    di,[bp-0x200]
    5d76:	16                   	push   ss
    5d77:	57                   	push   di
    5d78:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    5d7c:	6a 03                	push   0x3
    5d7e:	9a 75 19 ca 5d       	call   0x5dca:0x1975
    5d83:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    5d88:	75 cd                	jne    0x5d57
    5d8a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    5d8d:	36 83 7d 0c 01       	cmp    WORD PTR ss:[di+0xc],0x1
    5d92:	74 03                	je     0x5d97
    5d94:	e9 05 01             	jmp    0x5e9c
    5d97:	83 be fc fd 00       	cmp    WORD PTR [bp-0x204],0x0
    5d9c:	74 03                	je     0x5da1
    5d9e:	e9 bb 00             	jmp    0x5e5c
    5da1:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    5da6:	b0 00                	mov    al,0x0
    5da8:	76 01                	jbe    0x5dab
    5daa:	40                   	inc    ax
    5dab:	8a d0                	mov    dl,al
    5dad:	80 be 01 fe 20       	cmp    BYTE PTR [bp-0x1ff],0x20
    5db2:	b0 00                	mov    al,0x0
    5db4:	75 01                	jne    0x5db7
    5db6:	40                   	inc    ax
    5db7:	22 c2                	and    al,dl
    5db9:	08 c0                	or     al,al
    5dbb:	74 11                	je     0x5dce
    5dbd:	8d be 00 fe          	lea    di,[bp-0x200]
    5dc1:	16                   	push   ss
    5dc2:	57                   	push   di
    5dc3:	6a 01                	push   0x1
    5dc5:	6a 01                	push   0x1
    5dc7:	9a 75 19 e3 5d       	call   0x5de3:0x1975
    5dcc:	eb d3                	jmp    0x5da1
    5dce:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    5dd2:	30 e4                	xor    ah,ah
    5dd4:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5dd8:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5ddc:	99                   	cwd
    5ddd:	bf a8 5a             	mov    di,0x5aa8
    5de0:	9a 16 04 12 5e       	call   0x5e12:0x416
    5de5:	8b f8                	mov    di,ax
    5de7:	80 bb 00 fe 20       	cmp    BYTE PTR [bp+di-0x200],0x20
    5dec:	b0 00                	mov    al,0x0
    5dee:	75 01                	jne    0x5df1
    5df0:	40                   	inc    ax
    5df1:	8a d0                	mov    dl,al
    5df3:	83 be fa fd 12       	cmp    WORD PTR [bp-0x206],0x12
    5df8:	b0 00                	mov    al,0x0
    5dfa:	7e 01                	jle    0x5dfd
    5dfc:	40                   	inc    ax
    5dfd:	22 c2                	and    al,dl
    5dff:	08 c0                	or     al,al
    5e01:	74 17                	je     0x5e1a
    5e03:	8d be 00 fe          	lea    di,[bp-0x200]
    5e07:	16                   	push   ss
    5e08:	57                   	push   di
    5e09:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    5e0d:	6a 01                	push   0x1
    5e0f:	9a 75 19 3e 5e       	call   0x5e3e:0x1975
    5e14:	ff 8e fa fd          	dec    WORD PTR [bp-0x206]
    5e18:	eb be                	jmp    0x5dd8
    5e1a:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    5e1e:	30 e4                	xor    ah,ah
    5e20:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5e24:	83 be fa fd 12       	cmp    WORD PTR [bp-0x206],0x12
    5e29:	7d 2f                	jge    0x5e5a
    5e2b:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    5e2f:	8d be e8 fc          	lea    di,[bp-0x318]
    5e33:	16                   	push   ss
    5e34:	57                   	push   di
    5e35:	8d be 00 fe          	lea    di,[bp-0x200]
    5e39:	16                   	push   ss
    5e3a:	57                   	push   di
    5e3b:	9a cd 17 48 5e       	call   0x5e48:0x17cd
    5e40:	bf b0 5a             	mov    di,0x5ab0
    5e43:	0e                   	push   cs
    5e44:	57                   	push   di
    5e45:	9a 4c 18 56 5e       	call   0x5e56:0x184c
    5e4a:	8d be 00 fe          	lea    di,[bp-0x200]
    5e4e:	16                   	push   ss
    5e4f:	57                   	push   di
    5e50:	68 ff 00             	push   0xff
    5e53:	9a e7 17 7f 5e       	call   0x5e7f:0x17e7
    5e58:	eb ca                	jmp    0x5e24
    5e5a:	eb 40                	jmp    0x5e9c
    5e5c:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    5e60:	30 e4                	xor    ah,ah
    5e62:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5e66:	83 be fa fd 12       	cmp    WORD PTR [bp-0x206],0x12
    5e6b:	7d 2f                	jge    0x5e9c
    5e6d:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    5e71:	8d be e8 fc          	lea    di,[bp-0x318]
    5e75:	16                   	push   ss
    5e76:	57                   	push   di
    5e77:	bf b0 5a             	mov    di,0x5ab0
    5e7a:	0e                   	push   cs
    5e7b:	57                   	push   di
    5e7c:	9a cd 17 8a 5e       	call   0x5e8a:0x17cd
    5e81:	8d be 00 fe          	lea    di,[bp-0x200]
    5e85:	16                   	push   ss
    5e86:	57                   	push   di
    5e87:	9a 4c 18 98 5e       	call   0x5e98:0x184c
    5e8c:	8d be 00 fe          	lea    di,[bp-0x200]
    5e90:	16                   	push   ss
    5e91:	57                   	push   di
    5e92:	68 ff 00             	push   0xff
    5e95:	9a e7 17 b5 5e       	call   0x5eb5:0x17e7
    5e9a:	eb ca                	jmp    0x5e66
    5e9c:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    5ea0:	3b 86 f2 fd          	cmp    ax,WORD PTR [bp-0x20e]
    5ea4:	7d 29                	jge    0x5ecf
    5ea6:	8d be e8 fc          	lea    di,[bp-0x318]
    5eaa:	16                   	push   ss
    5eab:	57                   	push   di
    5eac:	8d be 00 fe          	lea    di,[bp-0x200]
    5eb0:	16                   	push   ss
    5eb1:	57                   	push   di
    5eb2:	9a cd 17 bf 5e       	call   0x5ebf:0x17cd
    5eb7:	bf a3 5a             	mov    di,0x5aa3
    5eba:	0e                   	push   cs
    5ebb:	57                   	push   di
    5ebc:	9a 4c 18 cd 5e       	call   0x5ecd:0x184c
    5ec1:	8d be 00 fe          	lea    di,[bp-0x200]
    5ec5:	16                   	push   ss
    5ec6:	57                   	push   di
    5ec7:	68 ff 00             	push   0xff
    5eca:	9a e7 17 de 5e       	call   0x5ede:0x17e7
    5ecf:	8d be e8 fc          	lea    di,[bp-0x318]
    5ed3:	16                   	push   ss
    5ed4:	57                   	push   di
    5ed5:	8d be 00 ff          	lea    di,[bp-0x100]
    5ed9:	16                   	push   ss
    5eda:	57                   	push   di
    5edb:	9a cd 17 e9 5e       	call   0x5ee9:0x17cd
    5ee0:	8d be 00 fe          	lea    di,[bp-0x200]
    5ee4:	16                   	push   ss
    5ee5:	57                   	push   di
    5ee6:	9a 4c 18 f7 5e       	call   0x5ef7:0x184c
    5eeb:	8d be 00 ff          	lea    di,[bp-0x100]
    5eef:	16                   	push   ss
    5ef0:	57                   	push   di
    5ef1:	68 ff 00             	push   0xff
    5ef4:	9a e7 17 5b 5f       	call   0x5f5b:0x17e7
    5ef9:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    5efd:	3b 86 e8 fd          	cmp    ax,WORD PTR [bp-0x218]
    5f01:	74 03                	je     0x5f06
    5f03:	e9 76 fd             	jmp    0x5c7c
    5f06:	8d be 00 ff          	lea    di,[bp-0x100]
    5f0a:	16                   	push   ss
    5f0b:	57                   	push   di
    5f0c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    5f0f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    5f13:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    5f18:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5f1d:	06                   	push   es
    5f1e:	57                   	push   di
    5f1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f22:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f26:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    5f2a:	3b 86 ea fd          	cmp    ax,WORD PTR [bp-0x216]
    5f2e:	74 03                	je     0x5f33
    5f30:	e9 e1 fc             	jmp    0x5c14
    5f33:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    5f37:	3b 86 ec fd          	cmp    ax,WORD PTR [bp-0x214]
    5f3b:	74 03                	je     0x5f40
    5f3d:	e9 28 fc             	jmp    0x5b68
    5f40:	c9                   	leave
    5f41:	ca 0c 00             	retf   0xc
    5f44:	0a 20                	or     ah,BYTE PTR [bx+si]
    5f46:	20 20                	and    BYTE PTR [bx+si],ah
    5f48:	20 20                	and    BYTE PTR [bx+si],ah
    5f4a:	20 20                	and    BYTE PTR [bx+si],ah
    5f4c:	20 20                	and    BYTE PTR [bx+si],ah
    5f4e:	20 01                	and    BYTE PTR [bx+di],al
    5f50:	20 00                	and    BYTE PTR [bx+si],al
    5f52:	55                   	push   bp
    5f53:	89 e5                	mov    bp,sp
    5f55:	b8 04 03             	mov    ax,0x304
    5f58:	9a 44 04 ca 5f       	call   0x5fca:0x444
    5f5d:	81 ec 04 03          	sub    sp,0x304
    5f61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f64:	26 c4 bd a4 02       	les    di,DWORD PTR es:[di+0x2a4]
    5f69:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    5f6d:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    5f71:	06                   	push   es
    5f72:	57                   	push   di
    5f73:	9a e3 49 ff ff       	call   0xffff:0x49e3
    5f78:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5f7d:	8d be 00 ff          	lea    di,[bp-0x100]
    5f81:	16                   	push   ss
    5f82:	57                   	push   di
    5f83:	68 ff 00             	push   0xff
    5f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f89:	26 ff b5 4e 02       	push   WORD PTR es:[di+0x24e]
    5f8e:	26 ff b5 4c 02       	push   WORD PTR es:[di+0x24c]
    5f93:	55                   	push   bp
    5f94:	9a 74 59 b3 5f       	call   0x5fb3:0x5974
    5f99:	8d be 00 ff          	lea    di,[bp-0x100]
    5f9d:	16                   	push   ss
    5f9e:	57                   	push   di
    5f9f:	68 ff 00             	push   0xff
    5fa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fa5:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    5faa:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    5faf:	55                   	push   bp
    5fb0:	9a 74 59 fe 5f       	call   0x5ffe:0x5974
    5fb5:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    5fb9:	75 29                	jne    0x5fe4
    5fbb:	8d be fc fd          	lea    di,[bp-0x204]
    5fbf:	16                   	push   ss
    5fc0:	57                   	push   di
    5fc1:	8d be 00 ff          	lea    di,[bp-0x100]
    5fc5:	16                   	push   ss
    5fc6:	57                   	push   di
    5fc7:	9a cd 17 d4 5f       	call   0x5fd4:0x17cd
    5fcc:	bf 44 5f             	mov    di,0x5f44
    5fcf:	0e                   	push   cs
    5fd0:	57                   	push   di
    5fd1:	9a 4c 18 e2 5f       	call   0x5fe2:0x184c
    5fd6:	8d be 00 ff          	lea    di,[bp-0x100]
    5fda:	16                   	push   ss
    5fdb:	57                   	push   di
    5fdc:	68 ff 00             	push   0xff
    5fdf:	9a e7 17 0f 60       	call   0x600f:0x17e7
    5fe4:	8d be 00 ff          	lea    di,[bp-0x100]
    5fe8:	16                   	push   ss
    5fe9:	57                   	push   di
    5fea:	68 ff 00             	push   0xff
    5fed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ff0:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    5ff5:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    5ffa:	55                   	push   bp
    5ffb:	9a 74 59 8c 60       	call   0x608c:0x5974
    6000:	8d be fc fd          	lea    di,[bp-0x204]
    6004:	16                   	push   ss
    6005:	57                   	push   di
    6006:	8d be 00 ff          	lea    di,[bp-0x100]
    600a:	16                   	push   ss
    600b:	57                   	push   di
    600c:	9a cd 17 19 60       	call   0x6019:0x17cd
    6011:	bf 4f 5f             	mov    di,0x5f4f
    6014:	0e                   	push   cs
    6015:	57                   	push   di
    6016:	9a 4c 18 33 60       	call   0x6033:0x184c
    601b:	8d be fc fc          	lea    di,[bp-0x304]
    601f:	16                   	push   ss
    6020:	57                   	push   di
    6021:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6024:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    6029:	06                   	push   es
    602a:	57                   	push   di
    602b:	9a 53 1d 07 61       	call   0x6107:0x1d53
    6030:	9a 4c 18 41 60       	call   0x6041:0x184c
    6035:	8d be 00 ff          	lea    di,[bp-0x100]
    6039:	16                   	push   ss
    603a:	57                   	push   di
    603b:	68 ff 00             	push   0xff
    603e:	9a e7 17 58 60       	call   0x6058:0x17e7
    6043:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    6047:	75 29                	jne    0x6072
    6049:	8d be fc fd          	lea    di,[bp-0x204]
    604d:	16                   	push   ss
    604e:	57                   	push   di
    604f:	8d be 00 ff          	lea    di,[bp-0x100]
    6053:	16                   	push   ss
    6054:	57                   	push   di
    6055:	9a cd 17 62 60       	call   0x6062:0x17cd
    605a:	bf 44 5f             	mov    di,0x5f44
    605d:	0e                   	push   cs
    605e:	57                   	push   di
    605f:	9a 4c 18 70 60       	call   0x6070:0x184c
    6064:	8d be 00 ff          	lea    di,[bp-0x100]
    6068:	16                   	push   ss
    6069:	57                   	push   di
    606a:	68 ff 00             	push   0xff
    606d:	9a e7 17 a3 60       	call   0x60a3:0x17e7
    6072:	8d be 00 ff          	lea    di,[bp-0x100]
    6076:	16                   	push   ss
    6077:	57                   	push   di
    6078:	68 ff 00             	push   0xff
    607b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    607e:	26 ff b5 66 02       	push   WORD PTR es:[di+0x266]
    6083:	26 ff b5 64 02       	push   WORD PTR es:[di+0x264]
    6088:	55                   	push   bp
    6089:	9a 74 59 d7 60       	call   0x60d7:0x5974
    608e:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    6092:	75 29                	jne    0x60bd
    6094:	8d be fc fd          	lea    di,[bp-0x204]
    6098:	16                   	push   ss
    6099:	57                   	push   di
    609a:	8d be 00 ff          	lea    di,[bp-0x100]
    609e:	16                   	push   ss
    609f:	57                   	push   di
    60a0:	9a cd 17 ad 60       	call   0x60ad:0x17cd
    60a5:	bf 44 5f             	mov    di,0x5f44
    60a8:	0e                   	push   cs
    60a9:	57                   	push   di
    60aa:	9a 4c 18 bb 60       	call   0x60bb:0x184c
    60af:	8d be 00 ff          	lea    di,[bp-0x100]
    60b3:	16                   	push   ss
    60b4:	57                   	push   di
    60b5:	68 ff 00             	push   0xff
    60b8:	9a e7 17 e8 60       	call   0x60e8:0x17e7
    60bd:	8d be 00 ff          	lea    di,[bp-0x100]
    60c1:	16                   	push   ss
    60c2:	57                   	push   di
    60c3:	68 ff 00             	push   0xff
    60c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60c9:	26 ff b5 5e 02       	push   WORD PTR es:[di+0x25e]
    60ce:	26 ff b5 5c 02       	push   WORD PTR es:[di+0x25c]
    60d3:	55                   	push   bp
    60d4:	9a 74 59 68 61       	call   0x6168:0x5974
    60d9:	8d be fc fd          	lea    di,[bp-0x204]
    60dd:	16                   	push   ss
    60de:	57                   	push   di
    60df:	8d be 00 ff          	lea    di,[bp-0x100]
    60e3:	16                   	push   ss
    60e4:	57                   	push   di
    60e5:	9a cd 17 f2 60       	call   0x60f2:0x17cd
    60ea:	bf 4f 5f             	mov    di,0x5f4f
    60ed:	0e                   	push   cs
    60ee:	57                   	push   di
    60ef:	9a 4c 18 0c 61       	call   0x610c:0x184c
    60f4:	8d be fc fc          	lea    di,[bp-0x304]
    60f8:	16                   	push   ss
    60f9:	57                   	push   di
    60fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60fd:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    6102:	06                   	push   es
    6103:	57                   	push   di
    6104:	9a 53 1d ff ff       	call   0xffff:0x1d53
    6109:	9a 4c 18 1a 61       	call   0x611a:0x184c
    610e:	8d be 00 ff          	lea    di,[bp-0x100]
    6112:	16                   	push   ss
    6113:	57                   	push   di
    6114:	68 ff 00             	push   0xff
    6117:	9a e7 17 30 62       	call   0x6230:0x17e7
    611c:	8d be 00 ff          	lea    di,[bp-0x100]
    6120:	16                   	push   ss
    6121:	57                   	push   di
    6122:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6126:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    612b:	06                   	push   es
    612c:	57                   	push   di
    612d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6130:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6134:	bf 51 5f             	mov    di,0x5f51
    6137:	0e                   	push   cs
    6138:	57                   	push   di
    6139:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    613d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6142:	06                   	push   es
    6143:	57                   	push   di
    6144:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6147:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    614b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    614e:	26 ff b5 76 02       	push   WORD PTR es:[di+0x276]
    6153:	26 ff b5 74 02       	push   WORD PTR es:[di+0x274]
    6158:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    615d:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    6162:	6a 02                	push   0x2
    6164:	55                   	push   bp
    6165:	9a b2 5a 87 61       	call   0x6187:0x5ab2
    616a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616d:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    6172:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    6177:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    617c:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    6181:	6a 02                	push   0x2
    6183:	55                   	push   bp
    6184:	9a b2 5a a6 61       	call   0x61a6:0x5ab2
    6189:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    618c:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    6191:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    6196:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    619b:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    61a0:	6a 02                	push   0x2
    61a2:	55                   	push   bp
    61a3:	9a b2 5a c5 61       	call   0x61c5:0x5ab2
    61a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61ab:	26 ff b5 8a 02       	push   WORD PTR es:[di+0x28a]
    61b0:	26 ff b5 88 02       	push   WORD PTR es:[di+0x288]
    61b5:	26 ff b5 aa 01       	push   WORD PTR es:[di+0x1aa]
    61ba:	26 ff b5 a8 01       	push   WORD PTR es:[di+0x1a8]
    61bf:	6a 02                	push   0x2
    61c1:	55                   	push   bp
    61c2:	9a b2 5a e4 61       	call   0x61e4:0x5ab2
    61c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61ca:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    61cf:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    61d4:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    61d9:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    61de:	6a 02                	push   0x2
    61e0:	55                   	push   bp
    61e1:	9a b2 5a 03 62       	call   0x6203:0x5ab2
    61e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61e9:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    61ee:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    61f3:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    61f8:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    61fd:	6a 01                	push   0x1
    61ff:	55                   	push   bp
    6200:	9a b2 5a 22 62       	call   0x6222:0x5ab2
    6205:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6208:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    620d:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    6212:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    6217:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    621c:	6a 01                	push   0x1
    621e:	55                   	push   bp
    621f:	9a b2 5a ff ff       	call   0xffff:0x5ab2
    6224:	c9                   	leave
    6225:	ca 08 00             	retf   0x8
    6228:	55                   	push   bp
    6229:	89 e5                	mov    bp,sp
    622b:	31 c0                	xor    ax,ax
    622d:	9a 44 04 ff ff       	call   0xffff:0x444
    6232:	ff 36 50 01          	push   WORD PTR ds:0x150
    6236:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6239:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    623e:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
    6243:	9a a1 0c ff ff       	call   0xffff:0xca1
    6248:	c9                   	leave
    6249:	ca                   	.byte 0xca
    624a:	08                   	.byte 0x8
