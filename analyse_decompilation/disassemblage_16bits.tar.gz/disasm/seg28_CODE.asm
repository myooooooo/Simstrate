; ================================================================
; seg28_CODE  (31657 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	1c 00                	sbb    al,0x0
       2:	05 0a 54             	add    ax,0x540a
       5:	53                   	push   bx
       6:	79 6d                	jns    0x75
       8:	62 6f 6c             	bound  bp,DWORD PTR [bx+0x6c]
       b:	53                   	push   bx
       c:	74 72                	je     0x80
       e:	1f                   	pop    ds
	...
      17:	2f                   	das
      18:	00 0c                	add    BYTE PTR [si],cl
      1a:	00 2e 00 71          	add    BYTE PTR ds:0x7100,ch
      1e:	02 64 20             	add    ah,BYTE PTR [si+0x20]
      21:	58                   	pop    ax
      22:	00 9a 1f 21          	add    BYTE PTR [bp+si+0x211f],bl
      26:	00 cb                	add    bl,cl
      28:	1f                   	pop    ds
      29:	25 00 c4             	and    ax,0xc400
      2c:	29 1d                	sub    WORD PTR [di],bx
      2e:	00 0e 45 44          	add    BYTE PTR ds:0x4445,cl
      32:	61                   	popa
      33:	74 61                	je     0x96
      35:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
      38:	65 45                	gs inc bp
      3a:	72 72                	jb     0xae
      3c:	6f                   	outs   dx,WORD PTR ds:[si]
      3d:	72 00                	jb     0x3f
      3f:	00 00                	add    BYTE PTR [bx+si],al
      41:	00 00                	add    BYTE PTR [bx+si],al
      43:	00 00                	add    BYTE PTR [bx+si],al
      45:	00 5e 00             	add    BYTE PTR [bp+0x0],bl
      48:	10 00                	adc    BYTE PTR [bx+si],al
      4a:	2f                   	das
      4b:	00 b4 00 64          	add    BYTE PTR [si+0x6400],dh
      4f:	20 8b 00 9a          	and    BYTE PTR [bp+di-0x6600],cl
      53:	1f                   	pop    ds
      54:	50                   	push   ax
      55:	00 cb                	add    bl,cl
      57:	1f                   	pop    ds
      58:	54                   	push   sp
      59:	00 2b                	add    BYTE PTR [bp+di],ch
      5b:	15 4c 00             	adc    ax,0x4c
      5e:	0e                   	push   cs
      5f:	45                   	inc    bp
      60:	44                   	inc    sp
      61:	42                   	inc    dx
      62:	45                   	inc    bp
      63:	6e                   	outs   dx,BYTE PTR ds:[si]
      64:	67 69 6e 65 45 72    	imul   bp,WORD PTR [esi+0x65],0x7245
      6a:	72 6f                	jb     0xdb
      6c:	72 00                	jb     0x6e
      6e:	00 00                	add    BYTE PTR [bx+si],al
      70:	00 00                	add    BYTE PTR [bx+si],al
      72:	00 00                	add    BYTE PTR [bx+si],al
      74:	00 8d 00 8a          	add    BYTE PTR [di-0x7600],cl
      78:	00 2c                	add    BYTE PTR [si],ch
      7a:	1f                   	pop    ds
      7b:	b0 00                	mov    al,0x0
      7d:	64 20 7b 00          	and    BYTE PTR fs:[bp+di+0x0],bh
      81:	9a 1f 7f 00 cb       	call   0xcb00:0x7f1f
      86:	1f                   	pop    ds
      87:	83 00 66             	add    WORD PTR [bx+si],0x66
      8a:	1f                   	pop    ds
      8b:	87 00                	xchg   WORD PTR [bx+si],ax
      8d:	08 54 44             	or     BYTE PTR [si+0x44],dl
      90:	42                   	inc    dx
      91:	45                   	inc    bp
      92:	72 72                	jb     0x106
      94:	6f                   	outs   dx,WORD PTR ds:[si]
      95:	72 ef                	jb     0x86
      97:	00 00                	add    BYTE PTR [bx+si],al
      99:	00 00                	add    BYTE PTR [bx+si],al
      9b:	00 00                	add    BYTE PTR [bx+si],al
      9d:	00 e6                	add    dh,ah
      9f:	00 3a                	add    BYTE PTR [bp+si],bh
      a1:	00 da                	add    dl,bl
      a3:	05 ff 00             	add    ax,0xff
      a6:	64 20 22             	and    BYTE PTR fs:[bp+si],ah
      a9:	01 9a 1f a8          	add    WORD PTR [bp+si-0x57e1],bx
      ad:	00 cb                	add    bl,cl
      af:	1f                   	pop    ds
      b0:	ac                   	lods   al,BYTE PTR ds:[si]
      b1:	00 e8                	add    al,ch
      b3:	16                   	push   ss
      b4:	fb                   	sti
      b5:	00 cd                	add    ch,cl
      b7:	11 c0                	adc    ax,ax
      b9:	00 6e 4f             	add    BYTE PTR [bp+0x4f],ch
      bc:	c4 00                	les    ax,DWORD PTR [bx+si]
      be:	fa                   	cli
      bf:	10 a4 00 e5          	adc    BYTE PTR [si-0x1b00],ah
      c3:	4f                   	dec    di
      c4:	c8 00 f4 4f          	enter  0xf400,0x4f
      c8:	cc                   	int3
      c9:	00 05                	add    BYTE PTR [di],al
      cb:	4f                   	dec    di
      cc:	d0 00                	rol    BYTE PTR [bx+si],1
      ce:	03 50 d4             	add    dx,WORD PTR [bx+si-0x2c]
      d1:	00 46 51             	add    BYTE PTR [bp+0x51],al
      d4:	d8 00                	fadd   DWORD PTR [bx+si]
      d6:	38 50 dc             	cmp    BYTE PTR [bx+si-0x24],dl
      d9:	00 1a                	add    BYTE PTR [bp+si],bl
      db:	50                   	push   ax
      dc:	e0 00                	loopne 0xde
      de:	21 50 e4             	and    WORD PTR [bx+si-0x1c],dx
      e1:	00 d9                	add    cl,bl
      e3:	4b                   	dec    bx
      e4:	b8 00 08             	mov    ax,0x800
      e7:	54                   	push   sp
      e8:	53                   	push   bx
      e9:	65 73 73             	gs jae 0x15f
      ec:	69 6f 6e 07 08       	imul   bp,WORD PTR [bx+0x6e],0x807
      f1:	54                   	push   sp
      f2:	53                   	push   bx
      f3:	65 73 73             	gs jae 0x169
      f6:	69 6f 6e b6 00       	imul   bp,WORD PTR [bx+0x6e],0xb6
      fb:	26 01 15             	add    WORD PTR es:[di],dx
      fe:	06                   	push   es
      ff:	dd 01                	fld    QWORD PTR [bx+di]
     101:	02 00                	add    al,BYTE PTR [bx+si]
     103:	02 44 42             	add    al,BYTE PTR [si+0x42]
	...
     10e:	00 00                	add    BYTE PTR [bx+si],al
     110:	28 01                	sub    BYTE PTR [bx+di],al
     112:	10 00                	adc    BYTE PTR [bx+si],al
     114:	2c 1f                	sub    al,0x1f
     116:	d1 01                	rol    WORD PTR [bx+di],1
     118:	64 20 16 01 9a       	and    BYTE PTR fs:0x9a01,dl
     11d:	1f                   	pop    ds
     11e:	1a 01                	sbb    al,BYTE PTR [bx+di]
     120:	cb                   	retf
     121:	1f                   	pop    ds
     122:	1e                   	push   ds
     123:	01 a8 1e 4f          	add    WORD PTR [bx+si+0x4f1e],bp
     127:	01 0a                	add    WORD PTR [bp+si],cx
     129:	54                   	push   sp
     12a:	50                   	push   ax
     12b:	61                   	popa
     12c:	72 61                	jb     0x18f
     12e:	6d                   	ins    WORD PTR es:[di],dx
     12f:	4c                   	dec    sp
     130:	69 73 74 03 0f       	imul   si,WORD PTR [bp+di+0x74],0xf03
     135:	54                   	push   sp
     136:	54                   	push   sp
     137:	72 61                	jb     0x19a
     139:	6e                   	outs   dx,BYTE PTR ds:[si]
     13a:	73 49                	jae    0x185
     13c:	73 6f                	jae    0x1ad
     13e:	6c                   	ins    BYTE PTR es:[di],dx
     13f:	61                   	popa
     140:	74 69                	je     0x1ab
     142:	6f                   	outs   dx,WORD PTR ds:[si]
     143:	6e                   	outs   dx,BYTE PTR ds:[si]
     144:	00 00                	add    BYTE PTR [bx+si],al
     146:	00 00                	add    BYTE PTR [bx+si],al
     148:	00 02                	add    BYTE PTR [bp+si],al
     14a:	00 00                	add    BYTE PTR [bx+si],al
     14c:	00 33                	add    BYTE PTR [bp+di],dh
     14e:	01 e9                	add    cx,bp
     150:	01 0b                	add    WORD PTR [bp+di],cx
     152:	74 69                	je     0x1bd
     154:	44                   	inc    sp
     155:	69 72 74 79 52       	imul   si,WORD PTR [bp+si+0x74],0x5279
     15a:	65 61                	gs popa
     15c:	64 0f 74 69 52       	pcmpeqb mm5,QWORD PTR fs:[bx+di+0x52]
     161:	65 61                	gs popa
     163:	64 43                	fs inc bx
     165:	6f                   	outs   dx,WORD PTR ds:[si]
     166:	6d                   	ins    WORD PTR es:[di],dx
     167:	6d                   	ins    WORD PTR es:[di],dx
     168:	69 74 74 65 64       	imul   si,WORD PTR [si+0x74],0x6465
     16d:	10 74 69             	adc    BYTE PTR [si+0x69],dh
     170:	52                   	push   dx
     171:	65 70 65             	gs jo  0x1d9
     174:	61                   	popa
     175:	74 61                	je     0x1d8
     177:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     17a:	52                   	push   dx
     17b:	65 61                	gs popa
     17d:	64 08 0b             	or     BYTE PTR fs:[bp+di],cl
     180:	54                   	push   sp
     181:	4c                   	dec    sp
     182:	6f                   	outs   dx,WORD PTR ds:[si]
     183:	67 69 6e 45 76 65    	imul   bp,WORD PTR [esi+0x45],0x6576
     189:	6e                   	outs   dx,BYTE PTR ds:[si]
     18a:	74 00                	je     0x18c
     18c:	02 00                	add    al,BYTE PTR [bx+si]
     18e:	08 44 61             	or     BYTE PTR [si+0x61],al
     191:	74 61                	je     0x1f4
     193:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     196:	65 09 54 44          	or     WORD PTR gs:[si+0x44],dx
     19a:	61                   	popa
     19b:	74 61                	je     0x1fe
     19d:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     1a0:	65 00 0b             	add    BYTE PTR gs:[bp+di],cl
     1a3:	4c                   	dec    sp
     1a4:	6f                   	outs   dx,WORD PTR ds:[si]
     1a5:	67 69 6e 50 61 72    	imul   bp,WORD PTR [esi+0x50],0x7261
     1ab:	61                   	popa
     1ac:	6d                   	ins    WORD PTR es:[di],dx
     1ad:	73 08                	jae    0x1b7
     1af:	54                   	push   sp
     1b0:	53                   	push   bx
     1b1:	74 72                	je     0x225
     1b3:	69 6e 67 73 11       	imul   bp,WORD PTR [bp+0x67],0x1173
     1b8:	02 00                	add    al,BYTE PTR [bx+si]
     1ba:	00 00                	add    BYTE PTR [bx+si],al
     1bc:	00 00                	add    BYTE PTR [bx+si],al
     1be:	00 07                	add    BYTE PTR [bx],al
     1c0:	02 b0 00 da          	add    dh,BYTE PTR [bx+si-0x2600]
     1c4:	05 22 02             	add    ax,0x222
     1c7:	64 20 4f 02          	and    BYTE PTR fs:[bx+0x2],cl
     1cb:	9a 1f c9 01 cb       	call   0xcb01:0xc91f
     1d0:	1f                   	pop    ds
     1d1:	cd 01                	int    0x1
     1d3:	ad                   	lods   ax,WORD PTR ds:[si]
     1d4:	1f                   	pop    ds
     1d5:	1e                   	push   ds
     1d6:	02 cd                	add    cl,ch
     1d8:	11 e1                	adc    cx,sp
     1da:	01 6e 4f             	add    WORD PTR [bp+0x4f],bp
     1dd:	e5 01                	in     ax,0x1
     1df:	fa                   	cli
     1e0:	10 c5                	adc    ch,al
     1e2:	01 e5                	add    bp,sp
     1e4:	4f                   	dec    di
     1e5:	ed                   	in     ax,dx
     1e6:	01 dc                	add    sp,bx
     1e8:	21 05                	and    WORD PTR [di],ax
     1ea:	02 05                	add    al,BYTE PTR [di]
     1ec:	4f                   	dec    di
     1ed:	f1                   	int1
     1ee:	01 03                	add    WORD PTR [bp+di],ax
     1f0:	50                   	push   ax
     1f1:	f5                   	cmc
     1f2:	01 46 51             	add    WORD PTR [bp+0x51],ax
     1f5:	f9                   	stc
     1f6:	01 38                	add    WORD PTR [bx+si],di
     1f8:	50                   	push   ax
     1f9:	fd                   	std
     1fa:	01 1a                	add    WORD PTR [bp+si],bx
     1fc:	50                   	push   ax
     1fd:	01 02                	add    WORD PTR [bp+si],ax
     1ff:	21 50 d9             	and    WORD PTR [bx+si-0x27],dx
     202:	01 e2                	add    dx,sp
     204:	1e                   	push   ds
     205:	d5 01                	aad    0x1
     207:	09 54 44             	or     WORD PTR [si+0x44],dx
     20a:	61                   	popa
     20b:	74 61                	je     0x26e
     20d:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     210:	65 07                	gs pop es
     212:	09 54 44             	or     WORD PTR [si+0x44],dx
     215:	61                   	popa
     216:	74 61                	je     0x279
     218:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     21b:	65 d7                	xlat   BYTE PTR gs:[bx]
     21d:	01 2d                	add    WORD PTR [di],bp
     21f:	02 15                	add    dl,BYTE PTR [di]
     221:	06                   	push   es
     222:	04 03                	add    al,0x3
     224:	0b 00                	or     ax,WORD PTR [bx+si]
     226:	02 44 42             	add    al,BYTE PTR [si+0x42]
     229:	09 00                	or     WORD PTR [bx+si],ax
     22b:	02 00                	add    al,BYTE PTR [bx+si]
     22d:	31 02                	xor    WORD PTR [bp+si],ax
     22f:	c3                   	ret
     230:	20 35                	and    BYTE PTR [di],dh
     232:	02 5a 26             	add    bl,BYTE PTR [bp+si+0x26]
     235:	53                   	push   bx
     236:	02 01                	add    al,BYTE PTR [bx+di]
     238:	00 00                	add    BYTE PTR [bx+si],al
     23a:	00 00                	add    BYTE PTR [bx+si],al
     23c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     23f:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     243:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     246:	69 61 73 4e 61       	imul   sp,WORD PTR [bx+di+0x73],0x614e
     24b:	6d                   	ins    WORD PTR es:[di],dx
     24c:	65 07                	gs pop es
     24e:	23 b9 02 ef          	and    di,WORD PTR [bx+di-0x10fe]
     252:	20 57 02             	and    BYTE PTR [bx+0x2],dl
     255:	72 26                	jb     0x27d
     257:	79 02                	jns    0x25b
     259:	01 00                	add    WORD PTR [bx+si],ax
     25b:	00 00                	add    BYTE PTR [bx+si],al
     25d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     261:	00 00                	add    BYTE PTR [bx+si],al
     263:	03 00                	add    ax,WORD PTR [bx+si]
     265:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     268:	6e                   	outs   dx,BYTE PTR ds:[si]
     269:	6e                   	outs   dx,BYTE PTR ds:[si]
     26a:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     26e:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     271:	53                   	push   bx
     272:	08 38                	or     BYTE PTR [bx+si],bh
     274:	00 ff                	add    bh,bh
     276:	ff a8 26 96          	jmp    DWORD PTR [bx+si-0x69da]
     27a:	02 01                	add    al,BYTE PTR [bx+di]
     27c:	00 00                	add    BYTE PTR [bx+si],al
     27e:	00 00                	add    BYTE PTR [bx+si],al
     280:	80 00 00             	add    BYTE PTR [bx+si],0x0
     283:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     287:	0c 44                	or     al,0x44
     289:	61                   	popa
     28a:	74 61                	je     0x2ed
     28c:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     28f:	65 4e                	gs dec si
     291:	61                   	popa
     292:	6d                   	ins    WORD PTR es:[di],dx
     293:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
     296:	9a 02 4b 21 9e       	call   0x9e21:0x4b02
     29b:	02 22                	add    ah,BYTE PTR [bp+si]
     29d:	27                   	daa
     29e:	c1 02 01             	rol    WORD PTR [bp+si],0x1
     2a1:	00 00                	add    BYTE PTR [bx+si],al
     2a3:	00 00                	add    BYTE PTR [bx+si],al
     2a5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2a8:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     2ac:	0a 44 72             	or     al,BYTE PTR [si+0x72]
     2af:	69 76 65 72 4e       	imul   si,WORD PTR [bp+0x65],0x4e72
     2b4:	61                   	popa
     2b5:	6d                   	ins    WORD PTR es:[di],dx
     2b6:	65 07                	gs pop es
     2b8:	23 e0                	and    sp,ax
     2ba:	02 20                	add    ah,BYTE PTR [bx+si]
     2bc:	00 ff                	add    bh,bh
     2be:	ff                   	(bad)
     2bf:	3a 27                	cmp    ah,BYTE PTR [bx]
     2c1:	0c 03                	or     al,0x3
     2c3:	01 00                	add    WORD PTR [bx+si],ax
     2c5:	00 00                	add    BYTE PTR [bx+si],al
     2c7:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     2cb:	00 00                	add    BYTE PTR [bx+si],al
     2cd:	06                   	push   es
     2ce:	00 0e 4b 65          	add    BYTE PTR ds:0x654b,cl
     2d2:	65 70 43             	gs jo  0x318
     2d5:	6f                   	outs   dx,WORD PTR ds:[si]
     2d6:	6e                   	outs   dx,BYTE PTR ds:[si]
     2d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     2d8:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
     2dc:	6f                   	outs   dx,WORD PTR ds:[si]
     2dd:	6e                   	outs   dx,BYTE PTR ds:[si]
     2de:	07                   	pop    es
     2df:	23 82 03 1f          	and    ax,WORD PTR [bp+si+0x1f03]
     2e3:	00 ff                	add    bh,bh
     2e5:	ff 1f                	call   DWORD PTR [bx]
     2e7:	00 ff                	add    bh,bh
     2e9:	ff 01                	inc    WORD PTR [bx+di]
     2eb:	00 00                	add    BYTE PTR [bx+si],al
     2ed:	00 00                	add    BYTE PTR [bx+si],al
     2ef:	80 01 00             	add    BYTE PTR [bx+di],0x0
     2f2:	00 00                	add    BYTE PTR [bx+si],al
     2f4:	07                   	pop    es
     2f5:	00 0b                	add    BYTE PTR [bp+di],cl
     2f7:	4c                   	dec    sp
     2f8:	6f                   	outs   dx,WORD PTR ds:[si]
     2f9:	67 69 6e 50 72 6f    	imul   bp,WORD PTR [esi+0x50],0x6f72
     2ff:	6d                   	ins    WORD PTR es:[di],dx
     300:	70 74                	jo     0x376
     302:	8b 03                	mov    ax,WORD PTR [bp+di]
     304:	0c 04                	or     al,0x4
     306:	34 00                	xor    al,0x0
     308:	ff                   	(bad)
     309:	ff 68 27             	jmp    DWORD PTR [bx+si+0x27]
     30c:	23 03                	and    ax,WORD PTR [bp+di]
     30e:	01 00                	add    WORD PTR [bx+si],ax
     310:	00 00                	add    BYTE PTR [bx+si],al
     312:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     316:	00 80 08 00          	add    BYTE PTR [bx+si+0x8],al
     31a:	06                   	push   es
     31b:	50                   	push   ax
     31c:	61                   	popa
     31d:	72 61                	jb     0x380
     31f:	6d                   	ins    WORD PTR es:[di],dx
     320:	73 33                	jae    0x355
     322:	01 4a 03             	add    WORD PTR [bp+si+0x3],cx
     325:	1e                   	push   ds
     326:	00 ff                	add    bh,bh
     328:	ff 1e 00 ff          	call   DWORD PTR ds:0xff00
     32c:	ff 01                	inc    WORD PTR [bx+di]
     32e:	00 00                	add    BYTE PTR [bx+si],al
     330:	00 00                	add    BYTE PTR [bx+si],al
     332:	80 01 00             	add    BYTE PTR [bx+di],0x0
     335:	00 00                	add    BYTE PTR [bx+si],al
     337:	09 00                	or     WORD PTR [bx+si],ax
     339:	0e                   	push   cs
     33a:	54                   	push   sp
     33b:	72 61                	jb     0x39e
     33d:	6e                   	outs   dx,BYTE PTR ds:[si]
     33e:	73 49                	jae    0x389
     340:	73 6f                	jae    0x3b1
     342:	6c                   	ins    BYTE PTR es:[di],dx
     343:	61                   	popa
     344:	74 69                	je     0x3af
     346:	6f                   	outs   dx,WORD PTR ds:[si]
     347:	6e                   	outs   dx,BYTE PTR ds:[si]
     348:	7e 01                	jle    0x34b
     34a:	86 03                	xchg   BYTE PTR [bp+di],al
     34c:	a8 00                	test   al,0x0
     34e:	ff                   	(bad)
     34f:	ff a8 00 ff          	jmp    DWORD PTR [bx+si-0x100]
     353:	ff 01                	inc    WORD PTR [bx+di]
     355:	00 00                	add    BYTE PTR [bx+si],al
     357:	00 00                	add    BYTE PTR [bx+si],al
     359:	80 00 00             	add    BYTE PTR [bx+si],0x0
     35c:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     360:	07                   	pop    es
     361:	4f                   	dec    di
     362:	6e                   	outs   dx,BYTE PTR ds:[si]
     363:	4c                   	dec    sp
     364:	6f                   	outs   dx,WORD PTR ds:[si]
     365:	67 69 6e 00 00 00    	imul   bp,WORD PTR [esi+0x0],0x0
     36b:	00 00                	add    BYTE PTR [bx+si],al
     36d:	00 00                	add    BYTE PTR [bx+si],al
     36f:	00 88 03 12          	add    BYTE PTR [bx+si+0x1203],cl
     373:	00 2c                	add    BYTE PTR [si],ch
     375:	1f                   	pop    ds
     376:	ac                   	lods   al,BYTE PTR ds:[si]
     377:	03 64 20             	add    sp,WORD PTR [si+0x20]
     37a:	76 03                	jbe    0x37f
     37c:	9a 1f 7a 03 cb       	call   0xcb03:0x7a1f
     381:	1f                   	pop    ds
     382:	7e 03                	jle    0x387
     384:	97                   	xchg   di,ax
     385:	28 b0 03 09          	sub    BYTE PTR [bx+si+0x903],dh
     389:	54                   	push   sp
     38a:	46                   	inc    si
     38b:	69 65 6c 64 44       	imul   sp,WORD PTR [di+0x6c],0x4464
     390:	65 66 00 00          	data32 add BYTE PTR gs:[bx+si],al
     394:	00 00                	add    BYTE PTR [bx+si],al
     396:	00 00                	add    BYTE PTR [bx+si],al
     398:	00 00                	add    BYTE PTR [bx+si],al
     39a:	b2 03                	mov    dl,0x3
     39c:	0e                   	push   cs
     39d:	00 2c                	add    BYTE PTR [si],ch
     39f:	1f                   	pop    ds
     3a0:	00 04                	add    BYTE PTR [si],al
     3a2:	64 20 a0 03 9a       	and    BYTE PTR fs:[bx+si-0x65fd],ah
     3a7:	1f                   	pop    ds
     3a8:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     3a9:	03 cb                	add    cx,bx
     3ab:	1f                   	pop    ds
     3ac:	a8 03                	test   al,0x3
     3ae:	6d                   	ins    WORD PTR es:[di],dx
     3af:	2a 38                	sub    bh,BYTE PTR [bx+si]
     3b1:	04 0a                	add    al,0xa
     3b3:	54                   	push   sp
     3b4:	46                   	inc    si
     3b5:	69 65 6c 64 44       	imul   sp,WORD PTR [di+0x6c],0x4464
     3ba:	65 66 73 08          	gs data32 jae 0x3c6
     3be:	13 54 44             	adc    dx,WORD PTR [si+0x44]
     3c1:	61                   	popa
     3c2:	74 61                	je     0x425
     3c4:	53                   	push   bx
     3c5:	65 74 4e             	gs je  0x416
     3c8:	6f                   	outs   dx,WORD PTR ds:[si]
     3c9:	74 69                	je     0x434
     3cb:	66 79 45             	data32 jns 0x413
     3ce:	76 65                	jbe    0x435
     3d0:	6e                   	outs   dx,BYTE PTR ds:[si]
     3d1:	74 00                	je     0x3d3
     3d3:	01 00                	add    WORD PTR [bx+si],ax
     3d5:	07                   	pop    es
     3d6:	44                   	inc    sp
     3d7:	61                   	popa
     3d8:	74 61                	je     0x43b
     3da:	53                   	push   bx
     3db:	65 74 08             	gs je  0x3e6
     3de:	54                   	push   sp
     3df:	44                   	inc    sp
     3e0:	61                   	popa
     3e1:	74 61                	je     0x444
     3e3:	73 65                	jae    0x44a
     3e5:	74 9b                	je     0x382
     3e7:	04 00                	add    al,0x0
     3e9:	00 00                	add    BYTE PTR [bx+si],al
     3eb:	00 00                	add    BYTE PTR [bx+si],al
     3ed:	00 92 04 20          	add    BYTE PTR [bp+si+0x2004],dl
     3f1:	01 da                	add    dx,bx
     3f3:	05 ab 04             	add    ax,0x4ab
     3f6:	64 20 b6 04 9a       	and    BYTE PTR fs:[bp-0x65fc],dh
     3fb:	1f                   	pop    ds
     3fc:	f8                   	clc
     3fd:	03 cb                	add    cx,bx
     3ff:	1f                   	pop    ds
     400:	fc                   	cld
     401:	03 9a 2e a7          	add    bx,WORD PTR [bp+si-0x58d2]
     405:	04 cd                	add    al,0xcd
     407:	11 10                	adc    WORD PTR [bx+si],dx
     409:	04 6e                	add    al,0x6e
     40b:	4f                   	dec    di
     40c:	14 04                	adc    al,0x4
     40e:	fa                   	cli
     40f:	10 f4                	adc    ah,dh
     411:	03 e5                	add    sp,bp
     413:	4f                   	dec    di
     414:	1c 04                	sbb    al,0x4
     416:	2f                   	das
     417:	31 8c 04 05          	xor    WORD PTR [si+0x504],cx
     41b:	4f                   	dec    di
     41c:	20 04                	and    BYTE PTR [si],al
     41e:	03 50 28             	add    dx,WORD PTR [bx+si+0x28]
     421:	04 43                	add    al,0x43
     423:	2f                   	das
     424:	2c 04                	sub    al,0x4
     426:	38 50 30             	cmp    BYTE PTR [bx+si+0x30],dl
     429:	04 b6                	add    al,0xb6
     42b:	30 34                	xor    BYTE PTR [si],dh
     42d:	04 21                	add    al,0x21
     42f:	50                   	push   ax
     430:	08 04                	or     BYTE PTR [si],al
     432:	e5 2d                	in     ax,0x2d
     434:	04 04                	add    al,0x4
     436:	70 33                	jo     0x46b
     438:	3c 04                	cmp    al,0x4
     43a:	ba 33 40             	mov    dx,0x4033
     43d:	04 19                	add    al,0x19
     43f:	43                   	inc    bx
     440:	44                   	inc    sp
     441:	04 f4                	add    al,0xf4
     443:	5a                   	pop    dx
     444:	48                   	dec    ax
     445:	04 1c                	add    al,0x1c
     447:	5b                   	pop    bx
     448:	4c                   	dec    sp
     449:	04 44                	add    al,0x44
     44b:	5b                   	pop    bx
     44c:	50                   	push   ax
     44d:	04 6c                	add    al,0x6c
     44f:	5b                   	pop    bx
     450:	54                   	push   sp
     451:	04 94                	add    al,0x94
     453:	5b                   	pop    bx
     454:	58                   	pop    ax
     455:	04 bc                	add    al,0xbc
     457:	5b                   	pop    bx
     458:	5c                   	pop    sp
     459:	04 e4                	add    al,0xe4
     45b:	5b                   	pop    bx
     45c:	60                   	pusha
     45d:	04 0c                	add    al,0xc
     45f:	5c                   	pop    sp
     460:	64 04 34             	fs add al,0x34
     463:	5c                   	pop    sp
     464:	68 04 5c             	push   0x5c04
     467:	5c                   	pop    sp
     468:	6c                   	ins    BYTE PTR es:[di],dx
     469:	04 84                	add    al,0x84
     46b:	5c                   	pop    sp
     46c:	70 04                	jo     0x472
     46e:	ac                   	lods   al,BYTE PTR ds:[si]
     46f:	5c                   	pop    sp
     470:	74 04                	je     0x476
     472:	d4 5c                	aam    0x5c
     474:	78 04                	js     0x47a
     476:	fc                   	cld
     477:	5c                   	pop    sp
     478:	7c 04                	jl     0x47e
     47a:	24 5d                	and    al,0x5d
     47c:	80 04 4c             	add    BYTE PTR [si],0x4c
     47f:	5d                   	pop    bp
     480:	84 04                	test   BYTE PTR [si],al
     482:	c4 3d                	les    di,DWORD PTR [di]
     484:	88 04                	mov    BYTE PTR [si],al
     486:	88 3a                	mov    BYTE PTR [bp+si],bh
     488:	18 04                	sbb    BYTE PTR [si],al
     48a:	0b 33                	or     si,WORD PTR [bp+di]
     48c:	90                   	nop
     48d:	04 0a                	add    al,0xa
     48f:	37                   	aaa
     490:	24 04                	and    al,0x4
     492:	08 54 44             	or     BYTE PTR [si+0x44],dl
     495:	61                   	popa
     496:	74 61                	je     0x4f9
     498:	73 65                	jae    0x4ff
     49a:	74 07                	je     0x4a3
     49c:	08 54 44             	or     BYTE PTR [si+0x44],dl
     49f:	61                   	popa
     4a0:	74 61                	je     0x503
     4a2:	73 65                	jae    0x509
     4a4:	74 06                	je     0x4ac
     4a6:	04 ba                	add    al,0xba
     4a8:	04 15                	add    al,0x15
     4aa:	06                   	push   es
     4ab:	9d                   	popf
     4ac:	07                   	pop    es
     4ad:	14 00                	adc    al,0x0
     4af:	02 44 42             	add    al,BYTE PTR [si+0x42]
     4b2:	12 00                	adc    al,BYTE PTR [bx+si]
     4b4:	07                   	pop    es
     4b5:	23 d5                	and    dx,bp
     4b7:	04 02                	add    al,0x2
     4b9:	32 be 04 27          	xor    bh,BYTE PTR [bp+0x2704]
     4bd:	32 fc                	xor    bh,ah
     4bf:	04 01                	add    al,0x1
     4c1:	00 00                	add    BYTE PTR [bx+si],al
     4c3:	00 00                	add    BYTE PTR [bx+si],al
     4c5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4c8:	00 00                	add    BYTE PTR [bx+si],al
     4ca:	02 00                	add    al,BYTE PTR [bx+si]
     4cc:	06                   	push   es
     4cd:	41                   	inc    cx
     4ce:	63 74 69             	arpl   WORD PTR [si+0x69],si
     4d1:	76 65                	jbe    0x538
     4d3:	07                   	pop    es
     4d4:	23 91 07 3b          	and    dx,WORD PTR [bx+di+0x3b07]
     4d8:	00 ff                	add    bh,bh
     4da:	ff                   	(bad)
     4db:	3b 00                	cmp    ax,WORD PTR [bx+si]
     4dd:	ff                   	(bad)
     4de:	ff 01                	inc    WORD PTR [bx+di]
     4e0:	00 00                	add    BYTE PTR [bx+si],al
     4e2:	00 00                	add    BYTE PTR [bx+si],al
     4e4:	80 01 00             	add    BYTE PTR [bx+di],0x0
     4e7:	00 00                	add    BYTE PTR [bx+si],al
     4e9:	03 00                	add    ax,WORD PTR [bx+si]
     4eb:	0e                   	push   cs
     4ec:	41                   	inc    cx
     4ed:	75 74                	jne    0x563
     4ef:	6f                   	outs   dx,WORD PTR ds:[si]
     4f0:	43                   	inc    bx
     4f1:	61                   	popa
     4f2:	6c                   	ins    BYTE PTR es:[di],dx
     4f3:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     4f6:	65 6c                	gs ins BYTE PTR es:[di],dx
     4f8:	64 73 bd             	fs jae 0x4b8
     4fb:	03 1f                	add    bx,WORD PTR [bx]
     4fd:	05 a0 00             	add    ax,0xa0
     500:	ff                   	(bad)
     501:	ff a0 00 ff          	jmp    WORD PTR [bx+si-0x100]
     505:	ff 01                	inc    WORD PTR [bx+di]
     507:	00 00                	add    BYTE PTR [bx+si],al
     509:	00 00                	add    BYTE PTR [bx+si],al
     50b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     50e:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     512:	0a 42 65             	or     al,BYTE PTR [bp+si+0x65]
     515:	66 6f                	outs   dx,DWORD PTR ds:[si]
     517:	72 65                	jb     0x57e
     519:	4f                   	dec    di
     51a:	70 65                	jo     0x581
     51c:	6e                   	outs   dx,BYTE PTR ds:[si]
     51d:	bd 03 41             	mov    bp,0x4103
     520:	05 a8 00             	add    ax,0xa8
     523:	ff                   	(bad)
     524:	ff a8 00 ff          	jmp    DWORD PTR [bx+si-0x100]
     528:	ff 01                	inc    WORD PTR [bx+di]
     52a:	00 00                	add    BYTE PTR [bx+si],al
     52c:	00 00                	add    BYTE PTR [bx+si],al
     52e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     531:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     535:	09 41 66             	or     WORD PTR [bx+di+0x66],ax
     538:	74 65                	je     0x59f
     53a:	72 4f                	jb     0x58b
     53c:	70 65                	jo     0x5a3
     53e:	6e                   	outs   dx,BYTE PTR ds:[si]
     53f:	bd 03 65             	mov    bp,0x6503
     542:	05 b0 00             	add    ax,0xb0
     545:	ff                   	(bad)
     546:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     54a:	ff 01                	inc    WORD PTR [bx+di]
     54c:	00 00                	add    BYTE PTR [bx+si],al
     54e:	00 00                	add    BYTE PTR [bx+si],al
     550:	80 00 00             	add    BYTE PTR [bx+si],0x0
     553:	00 80 06 00          	add    BYTE PTR [bx+si+0x6],al
     557:	0b 42 65             	or     ax,WORD PTR [bp+si+0x65]
     55a:	66 6f                	outs   dx,DWORD PTR ds:[si]
     55c:	72 65                	jb     0x5c3
     55e:	43                   	inc    bx
     55f:	6c                   	ins    BYTE PTR es:[di],dx
     560:	6f                   	outs   dx,WORD PTR ds:[si]
     561:	73 65                	jae    0x5c8
     563:	bd 03 88             	mov    bp,0x8803
     566:	05 b8 00             	add    ax,0xb8
     569:	ff                   	(bad)
     56a:	ff                   	(bad)
     56b:	b8 00 ff             	mov    ax,0xff00
     56e:	ff 01                	inc    WORD PTR [bx+di]
     570:	00 00                	add    BYTE PTR [bx+si],al
     572:	00 00                	add    BYTE PTR [bx+si],al
     574:	80 00 00             	add    BYTE PTR [bx+si],0x0
     577:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     57b:	0a 41 66             	or     al,BYTE PTR [bx+di+0x66]
     57e:	74 65                	je     0x5e5
     580:	72 43                	jb     0x5c5
     582:	6c                   	ins    BYTE PTR es:[di],dx
     583:	6f                   	outs   dx,WORD PTR ds:[si]
     584:	73 65                	jae    0x5eb
     586:	bd 03 ad             	mov    bp,0xad03
     589:	05 c0 00             	add    ax,0xc0
     58c:	ff                   	(bad)
     58d:	ff c0                	inc    ax
     58f:	00 ff                	add    bh,bh
     591:	ff 01                	inc    WORD PTR [bx+di]
     593:	00 00                	add    BYTE PTR [bx+si],al
     595:	00 00                	add    BYTE PTR [bx+si],al
     597:	80 00 00             	add    BYTE PTR [bx+si],0x0
     59a:	00 80 08 00          	add    BYTE PTR [bx+si+0x8],al
     59e:	0c 42                	or     al,0x42
     5a0:	65 66 6f             	outs   dx,DWORD PTR gs:[si]
     5a3:	72 65                	jb     0x60a
     5a5:	49                   	dec    cx
     5a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     5a7:	73 65                	jae    0x60e
     5a9:	72 74                	jb     0x61f
     5ab:	bd 03 d1             	mov    bp,0xd103
     5ae:	05 c8 00             	add    ax,0xc8
     5b1:	ff                   	(bad)
     5b2:	ff c8                	dec    ax
     5b4:	00 ff                	add    bh,bh
     5b6:	ff 01                	inc    WORD PTR [bx+di]
     5b8:	00 00                	add    BYTE PTR [bx+si],al
     5ba:	00 00                	add    BYTE PTR [bx+si],al
     5bc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5bf:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     5c3:	0b 41 66             	or     ax,WORD PTR [bx+di+0x66]
     5c6:	74 65                	je     0x62d
     5c8:	72 49                	jb     0x613
     5ca:	6e                   	outs   dx,BYTE PTR ds:[si]
     5cb:	73 65                	jae    0x632
     5cd:	72 74                	jb     0x643
     5cf:	bd 03 f4             	mov    bp,0xf403
     5d2:	05 d0 00             	add    ax,0xd0
     5d5:	ff                   	(bad)
     5d6:	ff d0                	call   ax
     5d8:	00 ff                	add    bh,bh
     5da:	ff 01                	inc    WORD PTR [bx+di]
     5dc:	00 00                	add    BYTE PTR [bx+si],al
     5de:	00 00                	add    BYTE PTR [bx+si],al
     5e0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5e3:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     5e7:	0a 42 65             	or     al,BYTE PTR [bp+si+0x65]
     5ea:	66 6f                	outs   dx,DWORD PTR ds:[si]
     5ec:	72 65                	jb     0x653
     5ee:	45                   	inc    bp
     5ef:	64 69 74 bd 03 16    	imul   si,WORD PTR fs:[si-0x43],0x1603
     5f5:	06                   	push   es
     5f6:	d8 00                	fadd   DWORD PTR [bx+si]
     5f8:	ff                   	(bad)
     5f9:	ff                   	call   (bad)
     5fa:	d8 00                	fadd   DWORD PTR [bx+si]
     5fc:	ff                   	(bad)
     5fd:	ff 01                	inc    WORD PTR [bx+di]
     5ff:	00 00                	add    BYTE PTR [bx+si],al
     601:	00 00                	add    BYTE PTR [bx+si],al
     603:	80 00 00             	add    BYTE PTR [bx+si],0x0
     606:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     60a:	09 41 66             	or     WORD PTR [bx+di+0x66],ax
     60d:	74 65                	je     0x674
     60f:	72 45                	jb     0x656
     611:	64 69 74 bd 03 39    	imul   si,WORD PTR fs:[si-0x43],0x3903
     617:	06                   	push   es
     618:	e0 00                	loopne 0x61a
     61a:	ff                   	(bad)
     61b:	ff e0                	jmp    ax
     61d:	00 ff                	add    bh,bh
     61f:	ff 01                	inc    WORD PTR [bx+di]
     621:	00 00                	add    BYTE PTR [bx+si],al
     623:	00 00                	add    BYTE PTR [bx+si],al
     625:	80 00 00             	add    BYTE PTR [bx+si],0x0
     628:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     62c:	0a 42 65             	or     al,BYTE PTR [bp+si+0x65]
     62f:	66 6f                	outs   dx,DWORD PTR ds:[si]
     631:	72 65                	jb     0x698
     633:	50                   	push   ax
     634:	6f                   	outs   dx,WORD PTR ds:[si]
     635:	73 74                	jae    0x6ab
     637:	bd 03 5b             	mov    bp,0x5b03
     63a:	06                   	push   es
     63b:	e8 00 ff             	call   0x53e
     63e:	ff                   	jmp    (bad)
     63f:	e8 00 ff             	call   0x542
     642:	ff 01                	inc    WORD PTR [bx+di]
     644:	00 00                	add    BYTE PTR [bx+si],al
     646:	00 00                	add    BYTE PTR [bx+si],al
     648:	80 00 00             	add    BYTE PTR [bx+si],0x0
     64b:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     64f:	09 41 66             	or     WORD PTR [bx+di+0x66],ax
     652:	74 65                	je     0x6b9
     654:	72 50                	jb     0x6a6
     656:	6f                   	outs   dx,WORD PTR ds:[si]
     657:	73 74                	jae    0x6cd
     659:	bd 03 80             	mov    bp,0x8003
     65c:	06                   	push   es
     65d:	f0 00 ff             	lock add bh,bh
     660:	ff f0                	push   ax
     662:	00 ff                	add    bh,bh
     664:	ff 01                	inc    WORD PTR [bx+di]
     666:	00 00                	add    BYTE PTR [bx+si],al
     668:	00 00                	add    BYTE PTR [bx+si],al
     66a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     66d:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     671:	0c 42                	or     al,0x42
     673:	65 66 6f             	outs   dx,DWORD PTR gs:[si]
     676:	72 65                	jb     0x6dd
     678:	43                   	inc    bx
     679:	61                   	popa
     67a:	6e                   	outs   dx,BYTE PTR ds:[si]
     67b:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     67e:	bd 03 a4             	mov    bp,0xa403
     681:	06                   	push   es
     682:	f8                   	clc
     683:	00 ff                	add    bh,bh
     685:	ff                   	(bad)
     686:	f8                   	clc
     687:	00 ff                	add    bh,bh
     689:	ff 01                	inc    WORD PTR [bx+di]
     68b:	00 00                	add    BYTE PTR [bx+si],al
     68d:	00 00                	add    BYTE PTR [bx+si],al
     68f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     692:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     696:	0b 41 66             	or     ax,WORD PTR [bx+di+0x66]
     699:	74 65                	je     0x700
     69b:	72 43                	jb     0x6e0
     69d:	61                   	popa
     69e:	6e                   	outs   dx,BYTE PTR ds:[si]
     69f:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     6a2:	bd 03 c9             	mov    bp,0xc903
     6a5:	06                   	push   es
     6a6:	00 01                	add    BYTE PTR [bx+di],al
     6a8:	ff                   	(bad)
     6a9:	ff 00                	inc    WORD PTR [bx+si]
     6ab:	01 ff                	add    di,di
     6ad:	ff 01                	inc    WORD PTR [bx+di]
     6af:	00 00                	add    BYTE PTR [bx+si],al
     6b1:	00 00                	add    BYTE PTR [bx+si],al
     6b3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6b6:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     6ba:	0c 42                	or     al,0x42
     6bc:	65 66 6f             	outs   dx,DWORD PTR gs:[si]
     6bf:	72 65                	jb     0x726
     6c1:	44                   	inc    sp
     6c2:	65 6c                	gs ins BYTE PTR es:[di],dx
     6c4:	65 74 65             	gs je  0x72c
     6c7:	bd 03 ed             	mov    bp,0xed03
     6ca:	06                   	push   es
     6cb:	08 01                	or     BYTE PTR [bx+di],al
     6cd:	ff                   	(bad)
     6ce:	ff 08                	dec    WORD PTR [bx+si]
     6d0:	01 ff                	add    di,di
     6d2:	ff 01                	inc    WORD PTR [bx+di]
     6d4:	00 00                	add    BYTE PTR [bx+si],al
     6d6:	00 00                	add    BYTE PTR [bx+si],al
     6d8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6db:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     6df:	0b 41 66             	or     ax,WORD PTR [bx+di+0x66]
     6e2:	74 65                	je     0x749
     6e4:	72 44                	jb     0x72a
     6e6:	65 6c                	gs ins BYTE PTR es:[di],dx
     6e8:	65 74 65             	gs je  0x750
     6eb:	bd 03 11             	mov    bp,0x1103
     6ee:	07                   	pop    es
     6ef:	10 01                	adc    BYTE PTR [bx+di],al
     6f1:	ff                   	(bad)
     6f2:	ff 10                	call   WORD PTR [bx+si]
     6f4:	01 ff                	add    di,di
     6f6:	ff 01                	inc    WORD PTR [bx+di]
     6f8:	00 00                	add    BYTE PTR [bx+si],al
     6fa:	00 00                	add    BYTE PTR [bx+si],al
     6fc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6ff:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     703:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     706:	4e                   	dec    si
     707:	65 77 52             	gs ja  0x75c
     70a:	65 63 6f 72          	arpl   WORD PTR gs:[bx+0x72],bp
     70e:	64 bd 03 4c          	fs mov bp,0x4c03
     712:	07                   	pop    es
     713:	18 01                	sbb    BYTE PTR [bx+di],al
     715:	ff                   	(bad)
     716:	ff 18                	call   DWORD PTR [bx+si]
     718:	01 ff                	add    di,di
     71a:	ff 01                	inc    WORD PTR [bx+di]
     71c:	00 00                	add    BYTE PTR [bx+si],al
     71e:	00 00                	add    BYTE PTR [bx+si],al
     720:	80 00 00             	add    BYTE PTR [bx+si],0x0
     723:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     727:	0c 4f                	or     al,0x4f
     729:	6e                   	outs   dx,BYTE PTR ds:[si]
     72a:	43                   	inc    bx
     72b:	61                   	popa
     72c:	6c                   	ins    BYTE PTR es:[di],dx
     72d:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     730:	65 6c                	gs ins BYTE PTR es:[di],dx
     732:	64 73 03             	fs jae 0x738
     735:	0b 54 55             	or     dx,WORD PTR [si+0x55]
     738:	70 64                	jo     0x79e
     73a:	61                   	popa
     73b:	74 65                	je     0x7a2
     73d:	4d                   	dec    bp
     73e:	6f                   	outs   dx,WORD PTR ds:[si]
     73f:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
     743:	00 00                	add    BYTE PTR [bx+si],al
     745:	00 02                	add    BYTE PTR [bp+si],al
     747:	00 00                	add    BYTE PTR [bx+si],al
     749:	00 34                	add    BYTE PTR [si],dh
     74b:	07                   	pop    es
     74c:	c9                   	leave
     74d:	07                   	pop    es
     74e:	0a 75 70             	or     dh,BYTE PTR [di+0x70]
     751:	57                   	push   di
     752:	68 65 72             	push   0x7265
     755:	65 41                	gs inc cx
     757:	6c                   	ins    BYTE PTR es:[di],dx
     758:	6c                   	ins    BYTE PTR es:[di],dx
     759:	0e                   	push   cs
     75a:	75 70                	jne    0x7cc
     75c:	57                   	push   di
     75d:	68 65 72             	push   0x7265
     760:	65 43                	gs inc bx
     762:	68 61 6e             	push   0x6e61
     765:	67 65 64 0e          	addr32 gs fs push cs
     769:	75 70                	jne    0x7db
     76b:	57                   	push   di
     76c:	68 65 72             	push   0x7265
     76f:	65 4b                	gs dec bx
     771:	65 79 4f             	gs jns 0x7c3
     774:	6e                   	outs   dx,BYTE PTR ds:[si]
     775:	6c                   	ins    BYTE PTR es:[di],dx
     776:	79 36                	jns    0x7ae
     778:	08 00                	or     BYTE PTR [bx+si],al
     77a:	00 00                	add    BYTE PTR [bx+si],al
     77c:	00 00                	add    BYTE PTR [bx+si],al
     77e:	00 2b                	add    BYTE PTR [bp+di],ch
     780:	08 78 01             	or     BYTE PTR [bx+si+0x1],bh
     783:	06                   	push   es
     784:	04 44                	add    al,0x44
     786:	08 64 20             	or     BYTE PTR [si+0x20],ah
     789:	c2 08 9a             	ret    0x9a08
     78c:	1f                   	pop    ds
     78d:	89 07                	mov    WORD PTR [bx],ax
     78f:	cb                   	retf
     790:	1f                   	pop    ds
     791:	8d 07                	lea    ax,[bx]
     793:	9a 2e 85 07 cd       	call   0xcd07:0x852e
     798:	11 a1 07 6e          	adc    WORD PTR [bx+di+0x6e07],sp
     79c:	4f                   	dec    di
     79d:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     79e:	07                   	pop    es
     79f:	fa                   	cli
     7a0:	10 ce                	adc    dh,cl
     7a2:	08 e5                	or     ch,ah
     7a4:	4f                   	dec    di
     7a5:	ad                   	lods   ax,WORD PTR ds:[si]
     7a6:	07                   	pop    es
     7a7:	2f                   	das
     7a8:	31 21                	xor    WORD PTR [bx+di],sp
     7aa:	08 05                	or     BYTE PTR [di],al
     7ac:	4f                   	dec    di
     7ad:	b1 07                	mov    cl,0x7
     7af:	03 50 b9             	add    dx,WORD PTR [bx+si-0x47]
     7b2:	07                   	pop    es
     7b3:	43                   	inc    bx
     7b4:	2f                   	das
     7b5:	bd 07 38             	mov    bp,0x3807
     7b8:	50                   	push   ax
     7b9:	c1 07 b6             	rol    WORD PTR [bx],0xb6
     7bc:	30 c5                	xor    ch,al
     7be:	07                   	pop    es
     7bf:	21 50 99             	and    WORD PTR [bx+si-0x67],dx
     7c2:	07                   	pop    es
     7c3:	e5 2d                	in     ax,0x2d
     7c5:	95                   	xchg   bp,ax
     7c6:	07                   	pop    es
     7c7:	d4 5d                	aam    0x5d
     7c9:	25 08 ba             	and    ax,0xba08
     7cc:	33 d1                	xor    dx,cx
     7ce:	07                   	pop    es
     7cf:	19 43 d5             	sbb    WORD PTR [bp+di-0x2b],ax
     7d2:	07                   	pop    es
     7d3:	f4                   	hlt
     7d4:	5a                   	pop    dx
     7d5:	d9 07                	fld    DWORD PTR [bx]
     7d7:	1c 5b                	sbb    al,0x5b
     7d9:	dd 07                	fld    QWORD PTR [bx]
     7db:	44                   	inc    sp
     7dc:	5b                   	pop    bx
     7dd:	e1 07                	loope  0x7e6
     7df:	6c                   	ins    BYTE PTR es:[di],dx
     7e0:	5b                   	pop    bx
     7e1:	e5 07                	in     ax,0x7
     7e3:	94                   	xchg   sp,ax
     7e4:	5b                   	pop    bx
     7e5:	e9 07 bc             	jmp    0xc3ef
     7e8:	5b                   	pop    bx
     7e9:	ed                   	in     ax,dx
     7ea:	07                   	pop    es
     7eb:	e4 5b                	in     al,0x5b
     7ed:	f1                   	int1
     7ee:	07                   	pop    es
     7ef:	0c 5c                	or     al,0x5c
     7f1:	f5                   	cmc
     7f2:	07                   	pop    es
     7f3:	34 5c                	xor    al,0x5c
     7f5:	f9                   	stc
     7f6:	07                   	pop    es
     7f7:	5c                   	pop    sp
     7f8:	5c                   	pop    sp
     7f9:	fd                   	std
     7fa:	07                   	pop    es
     7fb:	84 5c 01             	test   BYTE PTR [si+0x1],bl
     7fe:	08 ac 5c 05          	or     BYTE PTR [si+0x55c],ch
     802:	08 d4                	or     ah,dl
     804:	5c                   	pop    sp
     805:	09 08                	or     WORD PTR [bx+si],cx
     807:	fc                   	cld
     808:	5c                   	pop    sp
     809:	0d 08 24             	or     ax,0x2408
     80c:	5d                   	pop    bp
     80d:	11 08                	adc    WORD PTR [bx+si],cx
     80f:	4c                   	dec    sp
     810:	5d                   	pop    bp
     811:	15 08 c4             	adc    ax,0xc408
     814:	3d 19 08             	cmp    ax,0x819
     817:	88 3a                	mov    BYTE PTR [bp+si],bh
     819:	a9 07 74             	test   ax,0x7407
     81c:	5d                   	pop    bp
     81d:	29 08                	sub    WORD PTR [bx+si],cx
     81f:	0a 37                	or     dh,BYTE PTR [bx]
     821:	b5 07                	mov    ch,0x7
     823:	f6 5d 1d             	neg    BYTE PTR [di+0x1d]
     826:	08 07                	or     BYTE PTR [bx],al
     828:	5e                   	pop    si
     829:	cd 07                	int    0x7
     82b:	0a 54 44             	or     dl,BYTE PTR [si+0x44]
     82e:	42                   	inc    dx
     82f:	44                   	inc    sp
     830:	61                   	popa
     831:	74 61                	je     0x894
     833:	73 65                	jae    0x89a
     835:	74 07                	je     0x83e
     837:	0a 54 44             	or     dl,BYTE PTR [si+0x44]
     83a:	42                   	inc    dx
     83b:	44                   	inc    sp
     83c:	61                   	popa
     83d:	74 61                	je     0x8a0
     83f:	73 65                	jae    0x8a6
     841:	74 97                	je     0x7da
     843:	07                   	pop    es
     844:	48                   	dec    ax
     845:	08 9b 04 5b          	or     BYTE PTR [bp+di+0x5b04],bl
     849:	08 15                	or     BYTE PTR [di],dl
     84b:	00 02                	add    BYTE PTR [bp+si],al
     84d:	44                   	inc    sp
     84e:	42                   	inc    dx
     84f:	01 00                	add    WORD PTR [bx+si],ax
     851:	02 00                	add    al,BYTE PTR [bx+si]
     853:	20 0f                	and    BYTE PTR [bx],cl
     855:	28 01                	sub    BYTE PTR [bx+di],al
     857:	ff                   	(bad)
     858:	ff a9 5f f6          	jmp    DWORD PTR [bx+di-0x9a1]
     85c:	08 01                	or     BYTE PTR [bx+di],al
     85e:	00 00                	add    BYTE PTR [bx+si],al
     860:	00 00                	add    BYTE PTR [bx+si],al
     862:	80 00 00             	add    BYTE PTR [bx+si],0x0
     865:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     869:	0c 44                	or     al,0x44
     86b:	61                   	popa
     86c:	74 61                	je     0x8cf
     86e:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     871:	65 4e                	gs dec si
     873:	61                   	popa
     874:	6d                   	ins    WORD PTR es:[di],dx
     875:	65 08 10             	or     BYTE PTR gs:[bx+si],dl
     878:	54                   	push   sp
     879:	44                   	inc    sp
     87a:	61                   	popa
     87b:	74 61                	je     0x8de
     87d:	43                   	inc    bx
     87e:	68 61 6e             	push   0x6e61
     881:	67 65 45             	addr32 gs inc bp
     884:	76 65                	jbe    0x8eb
     886:	6e                   	outs   dx,BYTE PTR ds:[si]
     887:	74 00                	je     0x889
     889:	02 00                	add    al,BYTE PTR [bx+si]
     88b:	06                   	push   es
     88c:	53                   	push   bx
     88d:	65 6e                	outs   dx,BYTE PTR gs:[si]
     88f:	64 65 72 07          	fs gs jb 0x89a
     893:	54                   	push   sp
     894:	4f                   	dec    di
     895:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     898:	63 74 00             	arpl   WORD PTR [si+0x0],si
     89b:	05 46 69             	add    ax,0x6946
     89e:	65 6c                	gs ins BYTE PTR es:[di],dx
     8a0:	64 06                	fs push es
     8a2:	54                   	push   sp
     8a3:	46                   	inc    si
     8a4:	69 65 6c 64 04       	imul   sp,WORD PTR [di+0x6c],0x464
     8a9:	09 00                	or     WORD PTR [bx+si],ax
     8ab:	00 00                	add    BYTE PTR [bx+si],al
     8ad:	00 00                	add    BYTE PTR [bx+si],al
     8af:	00 f8                	add    al,bh
     8b1:	08 3e 00 da          	or     BYTE PTR ds:0xda00,bh
     8b5:	05 17 09             	add    ax,0x917
     8b8:	64 20 22             	and    BYTE PTR fs:[bp+si],ah
     8bb:	09 9a 1f ba          	or     WORD PTR [bp+si-0x45e1],bx
     8bf:	08 cb                	or     bl,cl
     8c1:	1f                   	pop    ds
     8c2:	be 08 19             	mov    si,0x1908
     8c5:	72 13                	jb     0x8da
     8c7:	09 cd                	or     bp,cx
     8c9:	11 d2                	adc    dx,dx
     8cb:	08 6e 4f             	or     BYTE PTR [bp+0x4f],ch
     8ce:	d6                   	(bad)
     8cf:	08 fa                	or     dl,bh
     8d1:	10 b6 08 e5          	adc    BYTE PTR [bp-0x1af8],dh
     8d5:	4f                   	dec    di
     8d6:	da 08                	fimul  DWORD PTR [bx+si]
     8d8:	f4                   	hlt
     8d9:	4f                   	dec    di
     8da:	de 08                	fimul  WORD PTR [bx+si]
     8dc:	05 4f e2             	add    ax,0xe24f
     8df:	08 03                	or     BYTE PTR [bp+di],al
     8e1:	50                   	push   ax
     8e2:	e6 08                	out    0x8,al
     8e4:	46                   	inc    si
     8e5:	51                   	push   cx
     8e6:	ea 08 38 50 ee       	jmp    0xee50:0x3808
     8eb:	08 1a                	or     BYTE PTR [bp+si],bl
     8ed:	50                   	push   ax
     8ee:	f2 08 21             	repnz or BYTE PTR [bx+di],ah
     8f1:	50                   	push   ax
     8f2:	ca 08 b9             	retf   0xb908
     8f5:	71 c6                	jno    0x8bd
     8f7:	08 0b                	or     BYTE PTR [bp+di],cl
     8f9:	54                   	push   sp
     8fa:	44                   	inc    sp
     8fb:	61                   	popa
     8fc:	74 61                	je     0x95f
     8fe:	53                   	push   bx
     8ff:	6f                   	outs   dx,WORD PTR ds:[si]
     900:	75 72                	jne    0x974
     902:	63 65 07             	arpl   WORD PTR [di+0x7],sp
     905:	0b 54 44             	or     dx,WORD PTR [si+0x44]
     908:	61                   	popa
     909:	74 61                	je     0x96c
     90b:	53                   	push   bx
     90c:	6f                   	outs   dx,WORD PTR ds:[si]
     90d:	75 72                	jne    0x981
     90f:	63 65 c8             	arpl   WORD PTR [di-0x38],sp
     912:	08 43 09             	or     BYTE PTR [bp+di+0x9],al
     915:	15 06 83             	adc    ax,0x8306
     918:	09 08                	or     WORD PTR [bx+si],cx
     91a:	00 02                	add    BYTE PTR [bp+si],al
     91c:	44                   	inc    sp
     91d:	42                   	inc    dx
     91e:	06                   	push   es
     91f:	00 07                	add    BYTE PTR [bx],al
     921:	23 63 09             	and    sp,WORD PTR [bp+di+0x9]
     924:	23 00                	and    ax,WORD PTR [bx+si]
     926:	ff                   	(bad)
     927:	ff 23                	jmp    WORD PTR [bp+di]
     929:	00 ff                	add    bh,bh
     92b:	ff 01                	inc    WORD PTR [bx+di]
     92d:	00 00                	add    BYTE PTR [bx+si],al
     92f:	00 00                	add    BYTE PTR [bx+si],al
     931:	80 01 00             	add    BYTE PTR [bx+di],0x0
     934:	00 00                	add    BYTE PTR [bx+si],al
     936:	02 00                	add    al,BYTE PTR [bx+si]
     938:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     93b:	74 6f                	je     0x9ac
     93d:	45                   	inc    bp
     93e:	64 69 74 9b 04 4b    	imul   si,WORD PTR fs:[si-0x65],0x4b04
     944:	09 1a                	or     WORD PTR [bp+si],bx
     946:	00 ff                	add    bh,bh
     948:	ff c5                	inc    bp
     94a:	73 6b                	jae    0x9b7
     94c:	09 01                	or     WORD PTR [bx+di],ax
     94e:	00 00                	add    BYTE PTR [bx+si],al
     950:	00 00                	add    BYTE PTR [bx+si],al
     952:	80 00 00             	add    BYTE PTR [bx+si],0x0
     955:	00 80 03 00          	add    BYTE PTR [bx+si+0x3],al
     959:	07                   	pop    es
     95a:	44                   	inc    sp
     95b:	61                   	popa
     95c:	74 61                	je     0x9bf
     95e:	53                   	push   bx
     95f:	65 74 07             	gs je  0x969
     962:	23 ac 0a 22          	and    bp,WORD PTR [si+0x220a]
     966:	00 ff                	add    bh,bh
     968:	ff 1e 74 a9          	call   DWORD PTR ds:0xa974
     96c:	09 01                	or     WORD PTR [bx+di],ax
     96e:	00 00                	add    BYTE PTR [bx+si],al
     970:	00 00                	add    BYTE PTR [bx+si],al
     972:	80 01 00             	add    BYTE PTR [bx+di],0x0
     975:	00 00                	add    BYTE PTR [bx+si],al
     977:	04 00                	add    al,0x0
     979:	07                   	pop    es
     97a:	45                   	inc    bp
     97b:	6e                   	outs   dx,BYTE PTR ds:[si]
     97c:	61                   	popa
     97d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     980:	64 71 00             	fs jno 0x983
     983:	ce                   	into
     984:	09 26 00 ff          	or     WORD PTR ds:0xff00,sp
     988:	ff 26 00 ff          	jmp    WORD PTR ds:0xff00
     98c:	ff 01                	inc    WORD PTR [bx+di]
     98e:	00 00                	add    BYTE PTR [bx+si],al
     990:	00 00                	add    BYTE PTR [bx+si],al
     992:	80 00 00             	add    BYTE PTR [bx+si],0x0
     995:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     999:	0d 4f 6e             	or     ax,0x6e4f
     99c:	53                   	push   bx
     99d:	74 61                	je     0xa00
     99f:	74 65                	je     0xa06
     9a1:	43                   	inc    bx
     9a2:	68 61 6e             	push   0x6e61
     9a5:	67 65 76 08          	addr32 gs jbe 0x9b1
     9a9:	e4 0a                	in     al,0xa
     9ab:	2e 00 ff             	cs add bh,bh
     9ae:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     9b2:	ff 01                	inc    WORD PTR [bx+di]
     9b4:	00 00                	add    BYTE PTR [bx+si],al
     9b6:	00 00                	add    BYTE PTR [bx+si],al
     9b8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9bb:	00 80 06 00          	add    BYTE PTR [bx+si+0x6],al
     9bf:	0c 4f                	or     al,0x4f
     9c1:	6e                   	outs   dx,BYTE PTR ds:[si]
     9c2:	44                   	inc    sp
     9c3:	61                   	popa
     9c4:	74 61                	je     0xa27
     9c6:	43                   	inc    bx
     9c7:	68 61 6e             	push   0x6e61
     9ca:	67 65 71 00          	addr32 gs jno 0x9ce
     9ce:	b8 0a 36             	mov    ax,0x360a
     9d1:	00 ff                	add    bh,bh
     9d3:	ff 36 00 ff          	push   WORD PTR ds:0xff00
     9d7:	ff 01                	inc    WORD PTR [bx+di]
     9d9:	00 00                	add    BYTE PTR [bx+si],al
     9db:	00 00                	add    BYTE PTR [bx+si],al
     9dd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9e0:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     9e4:	0c 4f                	or     al,0x4f
     9e6:	6e                   	outs   dx,BYTE PTR ds:[si]
     9e7:	55                   	push   bp
     9e8:	70 64                	jo     0xa4e
     9ea:	61                   	popa
     9eb:	74 65                	je     0xa52
     9ed:	44                   	inc    sp
     9ee:	61                   	popa
     9ef:	74 61                	je     0xa52
     9f1:	08 11                	or     BYTE PTR [bx+di],dl
     9f3:	54                   	push   sp
     9f4:	46                   	inc    si
     9f5:	69 65 6c 64 4e       	imul   sp,WORD PTR [di+0x6c],0x4e64
     9fa:	6f                   	outs   dx,WORD PTR ds:[si]
     9fb:	74 69                	je     0xa66
     9fd:	66 79 45             	data32 jns 0xa45
     a00:	76 65                	jbe    0xa67
     a02:	6e                   	outs   dx,BYTE PTR ds:[si]
     a03:	74 00                	je     0xa05
     a05:	01 00                	add    WORD PTR [bx+si],ax
     a07:	06                   	push   es
     a08:	53                   	push   bx
     a09:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a0b:	64 65 72 06          	fs gs jb 0xa15
     a0f:	54                   	push   sp
     a10:	46                   	inc    si
     a11:	69 65 6c 64 08       	imul   sp,WORD PTR [di+0x6c],0x864
     a16:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
     a19:	69 65 6c 64 47       	imul   sp,WORD PTR [di+0x6c],0x4764
     a1e:	65 74 54             	gs je  0xa75
     a21:	65 78 74             	gs js  0xa98
     a24:	45                   	inc    bp
     a25:	76 65                	jbe    0xa8c
     a27:	6e                   	outs   dx,BYTE PTR ds:[si]
     a28:	74 00                	je     0xa2a
     a2a:	03 00                	add    ax,WORD PTR [bx+si]
     a2c:	06                   	push   es
     a2d:	53                   	push   bx
     a2e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a30:	64 65 72 06          	fs gs jb 0xa3a
     a34:	54                   	push   sp
     a35:	46                   	inc    si
     a36:	69 65 6c 64 01       	imul   sp,WORD PTR [di+0x6c],0x164
     a3b:	04 54                	add    al,0x54
     a3d:	65 78 74             	gs js  0xab4
     a40:	0a 4f 70             	or     cl,BYTE PTR [bx+0x70]
     a43:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a45:	53                   	push   bx
     a46:	74 72                	je     0xaba
     a48:	69 6e 67 00 0b       	imul   bp,WORD PTR [bp+0x67],0xb00
     a4d:	44                   	inc    sp
     a4e:	69 73 70 6c 61       	imul   si,WORD PTR [bp+di+0x70],0x616c
     a53:	79 54                	jns    0xaa9
     a55:	65 78 74             	gs js  0xacc
     a58:	07                   	pop    es
     a59:	42                   	inc    dx
     a5a:	6f                   	outs   dx,WORD PTR ds:[si]
     a5b:	6f                   	outs   dx,WORD PTR ds:[si]
     a5c:	6c                   	ins    BYTE PTR es:[di],dx
     a5d:	65 61                	gs popa
     a5f:	6e                   	outs   dx,BYTE PTR ds:[si]
     a60:	08 12                	or     BYTE PTR [bp+si],dl
     a62:	54                   	push   sp
     a63:	46                   	inc    si
     a64:	69 65 6c 64 53       	imul   sp,WORD PTR [di+0x6c],0x5364
     a69:	65 74 54             	gs je  0xac0
     a6c:	65 78 74             	gs js  0xae3
     a6f:	45                   	inc    bp
     a70:	76 65                	jbe    0xad7
     a72:	6e                   	outs   dx,BYTE PTR ds:[si]
     a73:	74 00                	je     0xa75
     a75:	02 00                	add    al,BYTE PTR [bx+si]
     a77:	06                   	push   es
     a78:	53                   	push   bx
     a79:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a7b:	64 65 72 06          	fs gs jb 0xa85
     a7f:	54                   	push   sp
     a80:	46                   	inc    si
     a81:	69 65 6c 64 02       	imul   sp,WORD PTR [di+0x6c],0x264
     a86:	04 54                	add    al,0x54
     a88:	65 78 74             	gs js  0xaff
     a8b:	06                   	push   es
     a8c:	53                   	push   bx
     a8d:	74 72                	je     0xb01
     a8f:	69 6e 67 2d 0b       	imul   bp,WORD PTR [bp+0x67],0xb2d
     a94:	00 00                	add    BYTE PTR [bx+si],al
     a96:	00 00                	add    BYTE PTR [bx+si],al
     a98:	00 00                	add    BYTE PTR [bx+si],al
     a9a:	26 0b 60 00          	or     sp,WORD PTR es:[bx+si+0x0]
     a9e:	da 05                	fiadd  DWORD PTR [di]
     aa0:	3b 0b                	cmp    cx,WORD PTR [bp+di]
     aa2:	64 20 68 0b          	and    BYTE PTR fs:[bx+si+0xb],ch
     aa6:	9a 1f a4 0a cb       	call   0xcb0a:0xa41f
     aab:	1f                   	pop    ds
     aac:	a8 0a                	test   al,0xa
     aae:	5e                   	pop    si
     aaf:	60                   	pusha
     ab0:	bc 0a cd             	mov    sp,0xcd0a
     ab3:	11 a0 0a 6e          	adc    WORD PTR [bx+si+0x6e0a],sp
     ab7:	4f                   	dec    di
     ab8:	c4 0a                	les    cx,DWORD PTR [bp+si]
     aba:	1d 61 20             	sbb    ax,0x2061
     abd:	0b 25                	or     sp,WORD PTR [di]
     abf:	6a cc                	push   0xffcc
     ac1:	0a f4                	or     dh,ah
     ac3:	4f                   	dec    di
     ac4:	c8 0a 05 4f          	enter  0x50a,0x4f
     ac8:	d0 0a                	ror    BYTE PTR [bp+si],1
     aca:	be 6a 08             	mov    si,0x86a
     acd:	0b 46 51             	or     ax,WORD PTR [bp+0x51]
     ad0:	d4 0a                	aam    0xa
     ad2:	38 50 d8             	cmp    BYTE PTR [bx+si-0x28],dl
     ad5:	0a 1a                	or     bl,BYTE PTR [bp+si]
     ad7:	50                   	push   ax
     ad8:	dc 0a                	fmul   QWORD PTR [bp+si]
     ada:	21 50 b4             	and    WORD PTR [bx+si-0x4c],dx
     add:	0a ee                	or     ch,dh
     adf:	5f                   	pop    di
     ae0:	b0 0a                	mov    al,0xa
     ae2:	a3 63 e8             	mov    ds:0xe863,ax
     ae5:	0a 6d 64             	or     ch,BYTE PTR [di+0x64]
     ae8:	ec                   	in     al,dx
     ae9:	0a 7c 64             	or     bh,BYTE PTR [si+0x64]
     aec:	f0 0a 9f 64 f4       	lock or bl,BYTE PTR [bx-0xb9c]
     af1:	0a c2                	or     al,dl
     af3:	64 f8                	fs clc
     af5:	0a e7                	or     ah,bh
     af7:	64 fc                	fs cld
     af9:	0a 0f                	or     cl,BYTE PTR [bx]
     afb:	65 00 0b             	add    BYTE PTR gs:[bp+di],cl
     afe:	c2 67 04             	ret    0x467
     b01:	0b fe                	or     di,si
     b03:	69 c0 0a 0e          	imul   ax,ax,0xe0a
     b07:	6b 0c 0b             	imul   cx,WORD PTR [si],0xb
     b0a:	2d 6b 10             	sub    ax,0x106b
     b0d:	0b 49 6b             	or     cx,WORD PTR [bx+di+0x6b]
     b10:	14 0b                	adc    al,0xb
     b12:	67 6b 18 0b          	imul   bx,WORD PTR [eax],0xb
     b16:	84 6b 1c             	test   BYTE PTR [bp+di+0x1c],ch
     b19:	0b f6                	or     si,si
     b1b:	70 e0                	jo     0xafd
     b1d:	0a f2                	or     dh,dl
     b1f:	63 24                	arpl   WORD PTR [si],sp
     b21:	0b 34                	or     si,WORD PTR [si]
     b23:	6a 37                	push   0x37
     b25:	0b 06 54 46          	or     ax,WORD PTR ds:0x4654
     b29:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     b2e:	06                   	push   es
     b2f:	54                   	push   sp
     b30:	46                   	inc    si
     b31:	69 65 6c 64 b2       	imul   sp,WORD PTR [di+0x6c],0xb264
     b36:	0a 4e 0b             	or     cl,BYTE PTR [bp+0xb]
     b39:	15 06 46             	adc    ax,0x4606
     b3c:	0b 0f                	or     cx,WORD PTR [bx]
     b3e:	00 02                	add    BYTE PTR [bp+si],al
     b40:	44                   	inc    sp
     b41:	42                   	inc    dx
     b42:	0d 00 02             	or     ax,0x200
     b45:	00 1f                	add    BYTE PTR [bx],bl
     b47:	0d 25 00             	or     ax,0x25
     b4a:	ff                   	(bad)
     b4b:	ff 9a 6b 70          	call   DWORD PTR [bp+si+0x706b]
     b4f:	0b 01                	or     ax,WORD PTR [bx+di]
     b51:	00 00                	add    BYTE PTR [bx+si],al
     b53:	00 00                	add    BYTE PTR [bx+si],al
     b55:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b58:	00 00                	add    BYTE PTR [bx+si],al
     b5a:	02 00                	add    al,BYTE PTR [bx+si]
     b5c:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     b5f:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     b64:	6e                   	outs   dx,BYTE PTR ds:[si]
     b65:	74 07                	je     0xb6e
     b67:	23 8b 0b 24          	and    cx,WORD PTR [bp+di+0x240b]
     b6b:	00 ff                	add    bh,bh
     b6d:	ff                   	(bad)
     b6e:	bd 6b 8f             	mov    bp,0x8f6b
     b71:	0b 01                	or     ax,WORD PTR [bx+di]
     b73:	00 00                	add    BYTE PTR [bx+si],al
     b75:	00 00                	add    BYTE PTR [bx+si],al
     b77:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b7a:	00 00                	add    BYTE PTR [bx+si],al
     b7c:	03 00                	add    ax,WORD PTR [bx+si]
     b7e:	0a 43 61             	or     al,BYTE PTR [bp+di+0x61]
     b81:	6c                   	ins    BYTE PTR es:[di],dx
     b82:	63 75 6c             	arpl   WORD PTR [di+0x6c],si
     b85:	61                   	popa
     b86:	74 65                	je     0xbed
     b88:	64 62 23             	bound  sp,DWORD PTR fs:[bp+di]
     b8b:	b0 0b                	mov    al,0xb
     b8d:	d2 67 93             	shl    BYTE PTR [bx-0x6d],cl
     b90:	0b 9d 6e 97          	or     bx,WORD PTR [di-0x6892]
     b94:	0b 43 6a             	or     ax,WORD PTR [bp+di+0x6a]
     b97:	b4 0b                	mov    ah,0xb
     b99:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     b9d:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     ba1:	0c 44                	or     al,0x44
     ba3:	69 73 70 6c 61       	imul   si,WORD PTR [bp+di+0x70],0x616c
     ba8:	79 4c                	jns    0xbf6
     baa:	61                   	popa
     bab:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     bae:	d4 22                	aam    0x22
     bb0:	d5 0b                	aad    0xb
     bb2:	85 68 b8             	test   WORD PTR [bx+si-0x48],bp
     bb5:	0b 0d                	or     cx,WORD PTR [di]
     bb7:	6f                   	outs   dx,WORD PTR ds:[si]
     bb8:	bc 0b 61             	mov    sp,0x610b
     bbb:	6a d9                	push   0xffd9
     bbd:	0b 00                	or     ax,WORD PTR [bx+si]
     bbf:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bc2:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     bc6:	0c 44                	or     al,0x44
     bc8:	69 73 70 6c 61       	imul   si,WORD PTR [bp+di+0x70],0x616c
     bcd:	79 57                	jns    0xc26
     bcf:	69 64 74 68 62       	imul   sp,WORD PTR [si+0x74],0x6268
     bd4:	23 f7                	and    si,di
     bd6:	0b 1f                	or     bx,WORD PTR [bx]
     bd8:	69 dd 0b 96          	imul   bx,bp,0x960b
     bdc:	6f                   	outs   dx,WORD PTR ds:[si]
     bdd:	fb                   	sti
     bde:	0b 01                	or     ax,WORD PTR [bx+di]
     be0:	00 00                	add    BYTE PTR [bx+si],al
     be2:	00 00                	add    BYTE PTR [bx+si],al
     be4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     be7:	00 80 06 00          	add    BYTE PTR [bx+si+0x6],al
     beb:	09 46 69             	or     WORD PTR [bp+0x69],ax
     bee:	65 6c                	gs ins BYTE PTR es:[di],dx
     bf0:	64 4e                	fs dec si
     bf2:	61                   	popa
     bf3:	6d                   	ins    WORD PTR es:[di],dx
     bf4:	65 d4 22             	gs aam 0x22
     bf7:	15 0c 3c             	adc    ax,0x3c0c
     bfa:	69 ff 0b 22          	imul   di,di,0x220b
     bfe:	70 5f                	jo     0xc5f
     c00:	0c 00                	or     al,0x0
     c02:	00 00                	add    BYTE PTR [bx+si],al
     c04:	00 00                	add    BYTE PTR [bx+si],al
     c06:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c09:	00 80 07 00          	add    BYTE PTR [bx+si+0x7],al
     c0d:	05 49 6e             	add    ax,0x6e49
     c10:	64 65 78 07          	fs gs js 0xc1b
     c14:	23 36 0c 23          	and    si,WORD PTR ds:0x230c
     c18:	00 ff                	add    bh,bh
     c1a:	ff 23                	jmp    WORD PTR [bp+di]
     c1c:	00 ff                	add    bh,bh
     c1e:	ff 01                	inc    WORD PTR [bx+di]
     c20:	00 00                	add    BYTE PTR [bx+si],al
     c22:	00 00                	add    BYTE PTR [bx+si],al
     c24:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c27:	00 00                	add    BYTE PTR [bx+si],al
     c29:	08 00                	or     BYTE PTR [bx+si],al
     c2b:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     c2e:	61                   	popa
     c2f:	64 4f                	fs dec di
     c31:	6e                   	outs   dx,BYTE PTR ds:[si]
     c32:	6c                   	ins    BYTE PTR es:[di],dx
     c33:	79 07                	jns    0xc3c
     c35:	23 57 0c             	and    dx,WORD PTR [bx+0xc]
     c38:	27                   	daa
     c39:	00 ff                	add    bh,bh
     c3b:	ff 27                	jmp    WORD PTR [bx]
     c3d:	00 ff                	add    bh,bh
     c3f:	ff 01                	inc    WORD PTR [bx+di]
     c41:	00 00                	add    BYTE PTR [bx+si],al
     c43:	00 00                	add    BYTE PTR [bx+si],al
     c45:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c48:	00 00                	add    BYTE PTR [bx+si],al
     c4a:	09 00                	or     WORD PTR [bx+si],ax
     c4c:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     c4f:	71 75                	jno    0xcc6
     c51:	69 72 65 64 07       	imul   si,WORD PTR [bp+si+0x65],0x764
     c56:	23 17                	and    dx,WORD PTR [bx]
     c58:	0d 26 00             	or     ax,0x26
     c5b:	ff                   	(bad)
     c5c:	ff 0e 71 77          	dec    WORD PTR ds:0x7771
     c60:	0c 01                	or     al,0x1
     c62:	00 00                	add    BYTE PTR [bx+si],al
     c64:	00 00                	add    BYTE PTR [bx+si],al
     c66:	80 01 00             	add    BYTE PTR [bx+di],0x0
     c69:	00 00                	add    BYTE PTR [bx+si],al
     c6b:	0a 00                	or     al,BYTE PTR [bx+si]
     c6d:	07                   	pop    es
     c6e:	56                   	push   si
     c6f:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     c74:	65 f1                	gs int1
     c76:	09 98 0c 40          	or     WORD PTR [bx+si+0x400c],bx
     c7a:	00 ff                	add    bh,bh
     c7c:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     c7f:	ff                   	(bad)
     c80:	ff 01                	inc    WORD PTR [bx+di]
     c82:	00 00                	add    BYTE PTR [bx+si],al
     c84:	00 00                	add    BYTE PTR [bx+si],al
     c86:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c89:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     c8d:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     c90:	43                   	inc    bx
     c91:	68 61 6e             	push   0x6e61
     c94:	67 65 15 0a ba       	addr32 gs adc ax,0xba0a
     c99:	0c 50                	or     al,0x50
     c9b:	00 ff                	add    bh,bh
     c9d:	ff 50 00             	call   WORD PTR [bx+si+0x0]
     ca0:	ff                   	(bad)
     ca1:	ff 01                	inc    WORD PTR [bx+di]
     ca3:	00 00                	add    BYTE PTR [bx+si],al
     ca5:	00 00                	add    BYTE PTR [bx+si],al
     ca7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     caa:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     cae:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     cb1:	47                   	inc    di
     cb2:	65 74 54             	gs je  0xd09
     cb5:	65 78 74             	gs js  0xd2c
     cb8:	60                   	pusha
     cb9:	0a dc                	or     bl,ah
     cbb:	0c 58                	or     al,0x58
     cbd:	00 ff                	add    bh,bh
     cbf:	ff 58 00             	call   DWORD PTR [bx+si+0x0]
     cc2:	ff                   	(bad)
     cc3:	ff 01                	inc    WORD PTR [bx+di]
     cc5:	00 00                	add    BYTE PTR [bx+si],al
     cc7:	00 00                	add    BYTE PTR [bx+si],al
     cc9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ccc:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     cd0:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     cd3:	53                   	push   bx
     cd4:	65 74 54             	gs je  0xd2b
     cd7:	65 78 74             	gs js  0xd4e
     cda:	f1                   	int1
     cdb:	09 2b                	or     WORD PTR [bp+di],bp
     cdd:	0d 48 00             	or     ax,0x48
     ce0:	ff                   	(bad)
     ce1:	ff 48 00             	dec    WORD PTR [bx+si+0x0]
     ce4:	ff                   	(bad)
     ce5:	ff 01                	inc    WORD PTR [bx+di]
     ce7:	00 00                	add    BYTE PTR [bx+si],al
     ce9:	00 00                	add    BYTE PTR [bx+si],al
     ceb:	80 00 00             	add    BYTE PTR [bx+si],0x0
     cee:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     cf2:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     cf5:	56                   	push   si
     cf6:	61                   	popa
     cf7:	6c                   	ins    BYTE PTR es:[di],dx
     cf8:	69 64 61 74 65       	imul   sp,WORD PTR [si+0x61],0x6574
     cfd:	57                   	push   di
     cfe:	0d 00 00             	or     ax,0x0
     d01:	00 00                	add    BYTE PTR [bx+si],al
     d03:	00 00                	add    BYTE PTR [bx+si],al
     d05:	4d                   	dec    bp
     d06:	0d 14 00             	or     ax,0x14
     d09:	d1 02                	rol    WORD PTR [bp+si],1
     d0b:	68 0d 64             	push   0x640d
     d0e:	20 8b 0e 9a          	and    BYTE PTR [bp+di-0x65f2],cl
     d12:	1f                   	pop    ds
     d13:	0f                   	prefetchw (bad)
     d14:	0d cb 1f             	or     ax,0x1fcb
     d17:	13 0d                	adc    cx,WORD PTR [di]
     d19:	1a 76 64             	sbb    dh,BYTE PTR [bp+0x64]
     d1c:	0d cd 11             	or     ax,0x11cd
     d1f:	23 0d                	and    cx,WORD PTR [di]
     d21:	e4 11                	in     al,0x11
     d23:	27                   	daa
     d24:	0d fa 10             	or     ax,0x10fa
     d27:	0b 0d                	or     cx,WORD PTR [di]
     d29:	05 7b 2f             	add    ax,0x2f7b
     d2c:	0d 0c 7b             	or     ax,0x7b0c
     d2f:	33 0d                	xor    cx,WORD PTR [di]
     d31:	13 7b 37             	adc    di,WORD PTR [bp+di+0x37]
     d34:	0d 2a 7b             	or     ax,0x7b2a
     d37:	3b 0d                	cmp    cx,WORD PTR [di]
     d39:	44                   	inc    sp
     d3a:	7b 3f                	jnp    0xd7b
     d3c:	0d 3d 7b             	or     ax,0x7b3d
     d3f:	43                   	inc    bx
     d40:	0d 4b 7b             	or     ax,0x7b4b
     d43:	47                   	inc    di
     d44:	0d 5e 7b             	or     ax,0x7b5e
     d47:	4b                   	dec    bx
     d48:	0d 65 7b             	or     ax,0x7b65
     d4b:	1b 0d                	sbb    cx,WORD PTR [di]
     d4d:	09 54 44             	or     WORD PTR [si+0x44],dx
     d50:	61                   	popa
     d51:	74 61                	je     0xdb4
     d53:	4c                   	dec    sp
     d54:	69 6e 6b 07 09       	imul   bp,WORD PTR [bp+0x6b],0x907
     d59:	54                   	push   sp
     d5a:	44                   	inc    sp
     d5b:	61                   	popa
     d5c:	74 61                	je     0xdbf
     d5e:	4c                   	dec    sp
     d5f:	69 6e 6b 1d 0d       	imul   bp,WORD PTR [bp+0x6b],0xd1d
     d64:	e9 0d e9             	jmp    0xf674
     d67:	02 55 11             	add    dl,BYTE PTR [di+0x11]
     d6a:	00 00                	add    BYTE PTR [bx+si],al
     d6c:	02 44 42             	add    al,BYTE PTR [si+0x42]
     d6f:	00 00                	add    BYTE PTR [bx+si],al
     d71:	8c d0                	mov    ax,ss
     d73:	90                   	nop
     d74:	45                   	inc    bp
     d75:	55                   	push   bp
     d76:	89 e5                	mov    bp,sp
     d78:	1e                   	push   ds
     d79:	8e d8                	mov    ds,ax
     d7b:	56                   	push   si
     d7c:	57                   	push   di
     d7d:	6a 00                	push   0x0
     d7f:	ff 76 0a             	push   WORD PTR [bp+0xa]
     d82:	9a 60 17 00 00       	call   0x0:0x1760
     d87:	31 c0                	xor    ax,ax
     d89:	a3 ac 0a             	mov    ds:0xaac,ax
     d8c:	6a 00                	push   0x0
     d8e:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     d92:	06                   	push   es
     d93:	57                   	push   di
     d94:	9a a9 63 2e 0e       	call   0xe2e:0x63a9
     d99:	31 c0                	xor    ax,ax
     d9b:	a3 a8 0a             	mov    ds:0xaa8,ax
     d9e:	a3 aa 0a             	mov    ds:0xaaa,ax
     da1:	5f                   	pop    di
     da2:	5e                   	pop    si
     da3:	1f                   	pop    ds
     da4:	5d                   	pop    bp
     da5:	4d                   	dec    bp
     da6:	ca 0a 00             	retf   0xa
     da9:	8c d0                	mov    ax,ss
     dab:	90                   	nop
     dac:	45                   	inc    bp
     dad:	55                   	push   bp
     dae:	89 e5                	mov    bp,sp
     db0:	1e                   	push   ds
     db1:	8e d8                	mov    ds,ax
     db3:	83 ec 08             	sub    sp,0x8
     db6:	56                   	push   si
     db7:	57                   	push   di
     db8:	31 c0                	xor    ax,ax
     dba:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     dbd:	83 7e 0e 15          	cmp    WORD PTR [bp+0xe],0x15
     dc1:	74 03                	je     0xdc6
     dc3:	e9 9b 00             	jmp    0xe61
     dc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dc9:	26 8b 05             	mov    ax,WORD PTR es:[di]
     dcc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     dcf:	83 7e fa 01          	cmp    WORD PTR [bp-0x6],0x1
     dd3:	75 5b                	jne    0xe30
     dd5:	a1 a8 0a             	mov    ax,ds:0xaa8
     dd8:	0b 06 aa 0a          	or     ax,WORD PTR ds:0xaaa
     ddc:	75 25                	jne    0xe03
     dde:	6a 00                	push   0x0
     de0:	6a 00                	push   0x0
     de2:	68 e8 03             	push   0x3e8
     de5:	bf 71 0d             	mov    di,0xd71
     de8:	b8 ef 0e             	mov    ax,0xeef
     deb:	50                   	push   ax
     dec:	57                   	push   di
     ded:	9a ff ff 00 00       	call   0x0:0xffff
     df2:	a3 ac 0a             	mov    ds:0xaac,ax
     df5:	9a 0b 0e 00 00       	call   0x0:0xe0b
     dfa:	a3 a8 0a             	mov    ds:0xaa8,ax
     dfd:	89 16 aa 0a          	mov    WORD PTR ds:0xaaa,dx
     e01:	eb 2d                	jmp    0xe30
     e03:	83 3e ac 0a 00       	cmp    WORD PTR ds:0xaac,0x0
     e08:	74 26                	je     0xe30
     e0a:	9a ff ff 00 00       	call   0x0:0xffff
     e0f:	2b 06 a8 0a          	sub    ax,WORD PTR ds:0xaa8
     e13:	1b 16 aa 0a          	sbb    dx,WORD PTR ds:0xaaa
     e17:	83 fa 00             	cmp    dx,0x0
     e1a:	7f 07                	jg     0xe23
     e1c:	7c 12                	jl     0xe30
     e1e:	3d f4 01             	cmp    ax,0x1f4
     e21:	76 0d                	jbe    0xe30
     e23:	6a ef                	push   0xffef
     e25:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     e29:	06                   	push   es
     e2a:	57                   	push   di
     e2b:	9a a9 63 2a 22       	call   0x222a:0x63a9
     e30:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
     e34:	81 c7 28 00          	add    di,0x28
     e38:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     e3b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     e3e:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
     e42:	26 0b 45 0c          	or     ax,WORD PTR es:[di+0xc]
     e46:	74 19                	je     0xe61
     e48:	6a 15                	push   0x15
     e4a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
     e4e:	26 ff 35             	push   WORD PTR es:[di]
     e51:	81 c7 06 00          	add    di,0x6
     e55:	06                   	push   es
     e56:	57                   	push   di
     e57:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     e5a:	26 ff 5d 0a          	call   DWORD PTR es:[di+0xa]
     e5e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e61:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     e64:	5f                   	pop    di
     e65:	5e                   	pop    si
     e66:	8d 66 fe             	lea    sp,[bp-0x2]
     e69:	1f                   	pop    ds
     e6a:	5d                   	pop    bp
     e6b:	4d                   	dec    bp
     e6c:	ca 0a 00             	retf   0xa
     e6f:	55                   	push   bp
     e70:	89 e5                	mov    bp,sp
     e72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e75:	26 8b 05             	mov    ax,WORD PTR es:[di]
     e78:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
     e7c:	74 1b                	je     0xe99
     e7e:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
     e82:	26 ff 35             	push   WORD PTR es:[di]
     e85:	ff 76 04             	push   WORD PTR [bp+0x4]
     e88:	9a 9c 01 38 10       	call   0x1038:0x19c
     e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e90:	31 c0                	xor    ax,ax
     e92:	26 89 05             	mov    WORD PTR es:[di],ax
     e95:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
     e99:	c9                   	leave
     e9a:	c2 06 00             	ret    0x6
     e9d:	55                   	push   bp
     e9e:	89 e5                	mov    bp,sp
     ea0:	1e                   	push   ds
     ea1:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
     ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ea7:	8b 4e 04             	mov    cx,WORD PTR [bp+0x4]
     eaa:	31 c0                	xor    ax,ax
     eac:	fc                   	cld
     ead:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
     eaf:	75 01                	jne    0xeb2
     eb1:	40                   	inc    ax
     eb2:	1f                   	pop    ds
     eb3:	c9                   	leave
     eb4:	c2 0a 00             	ret    0xa
     eb7:	c8 06 00 00          	enter  0x6,0x0
     ebb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     ebe:	26 8a 05             	mov    al,BYTE PTR es:[di]
     ec1:	30 e4                	xor    ah,ah
     ec3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     ec6:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     ec9:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     ecc:	76 06                	jbe    0xed4
     ece:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ed1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     ed4:	ff 76 12             	push   WORD PTR [bp+0x12]
     ed7:	ff 76 10             	push   WORD PTR [bp+0x10]
     eda:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     edd:	81 c7 01 00          	add    di,0x1
     ee1:	06                   	push   es
     ee2:	57                   	push   di
     ee3:	ff 76 0a             	push   WORD PTR [bp+0xa]
     ee6:	ff 76 08             	push   WORD PTR [bp+0x8]
     ee9:	ff 76 fa             	push   WORD PTR [bp-0x6]
     eec:	9a 5d 0f 4e 0f       	call   0xf4e:0xf5d
     ef1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     ef4:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     ef7:	03 f8                	add    di,ax
     ef9:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     efd:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     f00:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
     f03:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f06:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f09:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f0c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     f0f:	c9                   	leave
     f10:	ca 0e 00             	retf   0xe
     f13:	c8 02 00 00          	enter  0x2,0x0
     f17:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f1a:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f1d:	9a 8c 0c e2 11       	call   0x11e2:0xc8c
     f22:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     f25:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f28:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     f2b:	76 06                	jbe    0xf33
     f2d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     f30:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     f33:	ff 76 12             	push   WORD PTR [bp+0x12]
     f36:	ff 76 10             	push   WORD PTR [bp+0x10]
     f39:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f3c:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f3f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     f42:	81 c7 01 00          	add    di,0x1
     f46:	06                   	push   es
     f47:	57                   	push   di
     f48:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f4b:	9a a8 0f c6 11       	call   0x11c6:0xfa8
     f50:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
     f53:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     f56:	26 88 05             	mov    BYTE PTR es:[di],al
     f59:	c9                   	leave
     f5a:	ca 0e 00             	retf   0xe
     f5d:	c8 02 00 00          	enter  0x2,0x0
     f61:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     f65:	74 3d                	je     0xfa4
     f67:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
     f6a:	0b 46 12             	or     ax,WORD PTR [bp+0x12]
     f6d:	74 21                	je     0xf90
     f6f:	ff 76 12             	push   WORD PTR [bp+0x12]
     f72:	ff 76 10             	push   WORD PTR [bp+0x10]
     f75:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f78:	ff 76 08             	push   WORD PTR [bp+0x8]
     f7b:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f7e:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f81:	ff 76 06             	push   WORD PTR [bp+0x6]
     f84:	8d 7e fe             	lea    di,[bp-0x2]
     f87:	16                   	push   ss
     f88:	57                   	push   di
     f89:	9a 9d 21 d7 0f       	call   0xfd7:0x219d
     f8e:	eb 14                	jmp    0xfa4
     f90:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f93:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f96:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f99:	ff 76 08             	push   WORD PTR [bp+0x8]
     f9c:	ff 76 06             	push   WORD PTR [bp+0x6]
     f9f:	9a ff ff 00 00       	call   0x0:0xffff
     fa4:	c9                   	leave
     fa5:	ca 0e 00             	retf   0xe
     fa8:	c8 02 00 00          	enter  0x2,0x0
     fac:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     fb0:	74 3d                	je     0xfef
     fb2:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
     fb5:	0b 46 12             	or     ax,WORD PTR [bp+0x12]
     fb8:	74 21                	je     0xfdb
     fba:	ff 76 12             	push   WORD PTR [bp+0x12]
     fbd:	ff 76 10             	push   WORD PTR [bp+0x10]
     fc0:	ff 76 0a             	push   WORD PTR [bp+0xa]
     fc3:	ff 76 08             	push   WORD PTR [bp+0x8]
     fc6:	ff 76 0e             	push   WORD PTR [bp+0xe]
     fc9:	ff 76 0c             	push   WORD PTR [bp+0xc]
     fcc:	ff 76 06             	push   WORD PTR [bp+0x6]
     fcf:	8d 7e fe             	lea    di,[bp-0x2]
     fd2:	16                   	push   ss
     fd3:	57                   	push   di
     fd4:	9a 8d 21 be 13       	call   0x13be:0x218d
     fd9:	eb 14                	jmp    0xfef
     fdb:	ff 76 0e             	push   WORD PTR [bp+0xe]
     fde:	ff 76 0c             	push   WORD PTR [bp+0xc]
     fe1:	ff 76 0a             	push   WORD PTR [bp+0xa]
     fe4:	ff 76 08             	push   WORD PTR [bp+0x8]
     fe7:	ff 76 06             	push   WORD PTR [bp+0x6]
     fea:	9a ff ff 00 00       	call   0x0:0xffff
     fef:	c9                   	leave
     ff0:	ca 0e 00             	retf   0xe
     ff3:	c8 02 01 00          	enter  0x102,0x0
     ff7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ffa:	26 8b 05             	mov    ax,WORD PTR es:[di]
     ffd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1000:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1003:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1006:	30 e4                	xor    ah,ah
    1008:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    100b:	7c 10                	jl     0x101d
    100d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1010:	03 f8                	add    di,ax
    1012:	26 80 3d 3b          	cmp    BYTE PTR es:[di],0x3b
    1016:	74 05                	je     0x101d
    1018:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    101b:	eb e3                	jmp    0x1000
    101d:	8d be fe fe          	lea    di,[bp-0x102]
    1021:	16                   	push   ss
    1022:	57                   	push   di
    1023:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1026:	06                   	push   es
    1027:	57                   	push   di
    1028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    102b:	26 ff 35             	push   WORD PTR es:[di]
    102e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1031:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1034:	50                   	push   ax
    1035:	9a 0b 18 45 10       	call   0x1045:0x180b
    103a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    103d:	06                   	push   es
    103e:	57                   	push   di
    103f:	68 ff 00             	push   0xff
    1042:	9a e7 17 8d 10       	call   0x108d:0x17e7
    1047:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    104a:	26 8a 05             	mov    al,BYTE PTR es:[di]
    104d:	30 e4                	xor    ah,ah
    104f:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1052:	7c 0e                	jl     0x1062
    1054:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1057:	03 f8                	add    di,ax
    1059:	26 80 3d 3b          	cmp    BYTE PTR es:[di],0x3b
    105d:	75 03                	jne    0x1062
    105f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1062:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1065:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1068:	26 89 05             	mov    WORD PTR es:[di],ax
    106b:	c9                   	leave
    106c:	ca 08 00             	retf   0x8
    106f:	01 3a                	add    WORD PTR [bp+si],di
    1071:	01 5c c8             	add    WORD PTR [si-0x38],bx
    1074:	02 00                	add    al,BYTE PTR [bx+si]
    1076:	00 c4                	add    ah,al
    1078:	7e 04                	jle    0x107e
    107a:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    107e:	74 2a                	je     0x10aa
    1080:	bf 6f 10             	mov    di,0x106f
    1083:	0e                   	push   cs
    1084:	57                   	push   di
    1085:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1088:	06                   	push   es
    1089:	57                   	push   di
    108a:	9a 78 18 a0 10       	call   0x10a0:0x1878
    108f:	09 c0                	or     ax,ax
    1091:	75 17                	jne    0x10aa
    1093:	bf 71 10             	mov    di,0x1071
    1096:	0e                   	push   cs
    1097:	57                   	push   di
    1098:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    109b:	06                   	push   es
    109c:	57                   	push   di
    109d:	9a 78 18 01 11       	call   0x1101:0x1878
    10a2:	09 c0                	or     ax,ax
    10a4:	75 04                	jne    0x10aa
    10a6:	b0 00                	mov    al,0x0
    10a8:	eb 02                	jmp    0x10ac
    10aa:	b0 01                	mov    al,0x1
    10ac:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    10af:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    10b2:	c9                   	leave
    10b3:	c2 04 00             	ret    0x4
    10b6:	01 3d                	add    WORD PTR [di],di
    10b8:	c8 06 03 00          	enter  0x306,0x0
    10bc:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    10bf:	06                   	push   es
    10c0:	57                   	push   di
    10c1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10c4:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    10c8:	48                   	dec    ax
    10c9:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    10cd:	31 c0                	xor    ax,ax
    10cf:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
    10d3:	7e 03                	jle    0x10d8
    10d5:	e9 8b 00             	jmp    0x1163
    10d8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    10db:	eb 03                	jmp    0x10e0
    10dd:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    10e0:	8d be fa fd          	lea    di,[bp-0x206]
    10e4:	16                   	push   ss
    10e5:	57                   	push   di
    10e6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10e9:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    10ec:	06                   	push   es
    10ed:	57                   	push   di
    10ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10f1:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    10f5:	8d be fc fe          	lea    di,[bp-0x104]
    10f9:	16                   	push   ss
    10fa:	57                   	push   di
    10fb:	68 ff 00             	push   0xff
    10fe:	9a e7 17 11 11       	call   0x1111:0x17e7
    1103:	bf b6 10             	mov    di,0x10b6
    1106:	0e                   	push   cs
    1107:	57                   	push   di
    1108:	8d be fc fe          	lea    di,[bp-0x104]
    110c:	16                   	push   ss
    110d:	57                   	push   di
    110e:	9a 78 18 32 11       	call   0x1132:0x1878
    1113:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1116:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    111a:	7e 3b                	jle    0x1157
    111c:	8d be fa fd          	lea    di,[bp-0x206]
    1120:	16                   	push   ss
    1121:	57                   	push   di
    1122:	8d be fc fe          	lea    di,[bp-0x104]
    1126:	16                   	push   ss
    1127:	57                   	push   di
    1128:	6a 01                	push   0x1
    112a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    112d:	48                   	dec    ax
    112e:	50                   	push   ax
    112f:	9a 0b 18 4b 11       	call   0x114b:0x180b
    1134:	8d be fa fc          	lea    di,[bp-0x306]
    1138:	16                   	push   ss
    1139:	57                   	push   di
    113a:	8d be fc fe          	lea    di,[bp-0x104]
    113e:	16                   	push   ss
    113f:	57                   	push   di
    1140:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1143:	40                   	inc    ax
    1144:	50                   	push   ax
    1145:	68 ff 00             	push   0xff
    1148:	9a 0b 18 e9 11       	call   0x11e9:0x180b
    114d:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1150:	06                   	push   es
    1151:	57                   	push   di
    1152:	9a 1b 1b 87 12       	call   0x1287:0x1b1b
    1157:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    115a:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
    115e:	74 03                	je     0x1163
    1160:	e9 7a ff             	jmp    0x10dd
    1163:	c9                   	leave
    1164:	c2 08 00             	ret    0x8
    1167:	55                   	push   bp
    1168:	89 e5                	mov    bp,sp
    116a:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    116d:	3c 01                	cmp    al,0x1
    116f:	75 11                	jne    0x1182
    1171:	83 7e 04 01          	cmp    WORD PTR [bp+0x4],0x1
    1175:	72 09                	jb     0x1180
    1177:	81 7e 04 ff 00       	cmp    WORD PTR [bp+0x4],0xff
    117c:	77 02                	ja     0x1180
    117e:	eb 48                	jmp    0x11c8
    1180:	eb 3e                	jmp    0x11c0
    1182:	3c 08                	cmp    al,0x8
    1184:	75 0a                	jne    0x1190
    1186:	83 7e 04 20          	cmp    WORD PTR [bp+0x4],0x20
    118a:	77 02                	ja     0x118e
    118c:	eb 3a                	jmp    0x11c8
    118e:	eb 30                	jmp    0x11c0
    1190:	3c 0c                	cmp    al,0xc
    1192:	74 04                	je     0x1198
    1194:	3c 0d                	cmp    al,0xd
    1196:	75 0a                	jne    0x11a2
    1198:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    119c:	76 02                	jbe    0x11a0
    119e:	eb 28                	jmp    0x11c8
    11a0:	eb 1e                	jmp    0x11c0
    11a2:	3c 0e                	cmp    al,0xe
    11a4:	74 08                	je     0x11ae
    11a6:	3c 0f                	cmp    al,0xf
    11a8:	74 04                	je     0x11ae
    11aa:	3c 10                	cmp    al,0x10
    11ac:	75 0a                	jne    0x11b8
    11ae:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    11b2:	72 02                	jb     0x11b6
    11b4:	eb 12                	jmp    0x11c8
    11b6:	eb 08                	jmp    0x11c0
    11b8:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    11bc:	75 02                	jne    0x11c0
    11be:	eb 08                	jmp    0x11c8
    11c0:	68 1e f2             	push   0xf21e
    11c3:	9a ef 11 db 11       	call   0x11db:0x11ef
    11c8:	c9                   	leave
    11c9:	c2 04 00             	ret    0x4
    11cc:	55                   	push   bp
    11cd:	89 e5                	mov    bp,sp
    11cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11d2:	06                   	push   es
    11d3:	57                   	push   di
    11d4:	b0 01                	mov    al,0x1
    11d6:	50                   	push   ax
    11d7:	b8 2f 00             	mov    ax,0x2f
    11da:	ba 04 12             	mov    dx,0x1204
    11dd:	52                   	push   dx
    11de:	50                   	push   ax
    11df:	9a e6 28 ff 11       	call   0x11ff:0x28e6
    11e4:	52                   	push   dx
    11e5:	50                   	push   ax
    11e6:	9a 99 13 48 12       	call   0x1248:0x1399
    11eb:	c9                   	leave
    11ec:	ca 04 00             	retf   0x4
    11ef:	c8 00 01 00          	enter  0x100,0x0
    11f3:	8d be 00 ff          	lea    di,[bp-0x100]
    11f7:	16                   	push   ss
    11f8:	57                   	push   di
    11f9:	ff 76 06             	push   WORD PTR [bp+0x6]
    11fc:	9a 2b 09 22 12       	call   0x1222:0x92b
    1201:	9a cc 11 27 12       	call   0x1227:0x11cc
    1206:	c9                   	leave
    1207:	ca 02 00             	retf   0x2
    120a:	c8 00 01 00          	enter  0x100,0x0
    120e:	8d be 00 ff          	lea    di,[bp-0x100]
    1212:	16                   	push   ss
    1213:	57                   	push   di
    1214:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1217:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    121a:	06                   	push   es
    121b:	57                   	push   di
    121c:	ff 76 06             	push   WORD PTR [bp+0x6]
    121f:	9a 50 09 b0 12       	call   0x12b0:0x950
    1224:	9a cc 11 3a 12       	call   0x123a:0x11cc
    1229:	c9                   	leave
    122a:	ca 08 00             	retf   0x8
    122d:	55                   	push   bp
    122e:	89 e5                	mov    bp,sp
    1230:	ff 76 06             	push   WORD PTR [bp+0x6]
    1233:	b0 01                	mov    al,0x1
    1235:	50                   	push   ax
    1236:	b8 5e 00             	mov    ax,0x5e
    1239:	ba 41 12             	mov    dx,0x1241
    123c:	52                   	push   dx
    123d:	50                   	push   ax
    123e:	9a 73 13 5d 12       	call   0x125d:0x1373
    1243:	52                   	push   dx
    1244:	50                   	push   ax
    1245:	9a 99 13 73 12       	call   0x1273:0x1399
    124a:	c9                   	leave
    124b:	ca 02 00             	retf   0x2
    124e:	55                   	push   bp
    124f:	89 e5                	mov    bp,sp
    1251:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    1255:	74 08                	je     0x125f
    1257:	ff 76 06             	push   WORD PTR [bp+0x6]
    125a:	9a 2d 12 da 13       	call   0x13da:0x122d
    125f:	c9                   	leave
    1260:	ca 02 00             	retf   0x2
    1263:	c8 00 01 00          	enter  0x100,0x0
    1267:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    126b:	74 08                	je     0x1275
    126d:	83 ec 08             	sub    sp,0x8
    1270:	9a e2 1f c0 12       	call   0x12c0:0x1fe2
    1275:	ff 76 08             	push   WORD PTR [bp+0x8]
    1278:	ff 76 06             	push   WORD PTR [bp+0x6]
    127b:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    127e:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1282:	06                   	push   es
    1283:	57                   	push   di
    1284:	9a 2b 0c 9e 13       	call   0x139e:0xc2b
    1289:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    128c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    128f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1293:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    1296:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    1299:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    129d:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    12a1:	8d be 00 ff          	lea    di,[bp-0x100]
    12a5:	16                   	push   ss
    12a6:	57                   	push   di
    12a7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    12aa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    12ad:	9a 6e 0e 95 13       	call   0x1395:0xe6e
    12b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b5:	81 c7 0a 00          	add    di,0xa
    12b9:	06                   	push   es
    12ba:	57                   	push   di
    12bb:	6a 7f                	push   0x7f
    12bd:	9a e7 17 83 13       	call   0x1383:0x17e7
    12c2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    12c6:	74 07                	je     0x12cf
    12c8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    12cc:	83 c4 06             	add    sp,0x6
    12cf:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    12d2:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    12d5:	c9                   	leave
    12d6:	ca 14 00             	retf   0x14
    12d9:	c8 0e 00 00          	enter  0xe,0x0
    12dd:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    12e0:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    12e3:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    12e6:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    12e9:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    12ec:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    12ef:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    12f2:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    12f5:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    12f9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    12fc:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1300:	74 37                	je     0x1339
    1302:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1305:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    1309:	77 06                	ja     0x1311
    130b:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    130f:	eb 23                	jmp    0x1334
    1311:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1315:	74 0e                	je     0x1325
    1317:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    131a:	26 c6 05 20          	mov    BYTE PTR es:[di],0x20
    131e:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    1321:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    1325:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1328:	26 8a 05             	mov    al,BYTE PTR es:[di]
    132b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    132e:	26 88 05             	mov    BYTE PTR es:[di],al
    1331:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    1334:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    1337:	eb c0                	jmp    0x12f9
    1339:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    133c:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
    133f:	76 0d                	jbe    0x134e
    1341:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1344:	26 80 7d ff 2e       	cmp    BYTE PTR es:[di-0x1],0x2e
    1349:	75 03                	jne    0x134e
    134b:	ff 4e f2             	dec    WORD PTR [bp-0xe]
    134e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1351:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1355:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    1358:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    135b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    135e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1361:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1364:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1367:	c9                   	leave
    1368:	c2 04 00             	ret    0x4
    136b:	00 06 25 73          	add    BYTE PTR ds:0x7325,al
    136f:	2e 20 25             	and    BYTE PTR cs:[di],ah
    1372:	73 c8                	jae    0x133c
    1374:	16                   	push   ss
    1375:	02 00                	add    al,BYTE PTR [bx+si]
    1377:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    137b:	74 08                	je     0x1385
    137d:	83 ec 08             	sub    sp,0x8
    1380:	9a e2 1f a5 13       	call   0x13a5:0x1fe2
    1385:	bf 6b 13             	mov    di,0x136b
    1388:	0e                   	push   cs
    1389:	57                   	push   di
    138a:	31 c0                	xor    ax,ax
    138c:	50                   	push   ax
    138d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1390:	06                   	push   es
    1391:	57                   	push   di
    1392:	9a e6 28 19 14       	call   0x1419:0x28e6
    1397:	b0 01                	mov    al,0x1
    1399:	50                   	push   ax
    139a:	b8 a3 02             	mov    ax,0x2a3
    139d:	ba 60 15             	mov    dx,0x1560
    13a0:	52                   	push   dx
    13a1:	50                   	push   ax
    13a2:	9a 50 1f 6b 15       	call   0x156b:0x1f50
    13a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13aa:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    13ae:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    13b2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    13b5:	8d be 7a ff          	lea    di,[bp-0x86]
    13b9:	16                   	push   ss
    13ba:	57                   	push   di
    13bb:	9a fd 09 69 14       	call   0x1469:0x9fd
    13c0:	ff 76 08             	push   WORD PTR [bp+0x8]
    13c3:	ff 76 06             	push   WORD PTR [bp+0x6]
    13c6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    13c9:	6a 00                	push   0x0
    13cb:	6a 00                	push   0x0
    13cd:	8d be 7a ff          	lea    di,[bp-0x86]
    13d1:	16                   	push   ss
    13d2:	57                   	push   di
    13d3:	b0 01                	mov    al,0x1
    13d5:	50                   	push   ax
    13d6:	b8 8d 00             	mov    ax,0x8d
    13d9:	ba e1 13             	mov    dx,0x13e1
    13dc:	52                   	push   dx
    13dd:	50                   	push   ax
    13de:	9a 63 12 93 14       	call   0x1493:0x1263
    13e3:	8d be 7a ff          	lea    di,[bp-0x86]
    13e7:	16                   	push   ss
    13e8:	57                   	push   di
    13e9:	e8 ed fe             	call   0x12d9
    13ec:	80 be 7a ff 00       	cmp    BYTE PTR [bp-0x86],0x0
    13f1:	75 34                	jne    0x1427
    13f3:	8d be f2 fd          	lea    di,[bp-0x20e]
    13f7:	16                   	push   ss
    13f8:	57                   	push   di
    13f9:	68 5a f2             	push   0xf25a
    13fc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    13ff:	31 d2                	xor    dx,dx
    1401:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1405:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    1409:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    140e:	8d be f2 fe          	lea    di,[bp-0x10e]
    1412:	16                   	push   ss
    1413:	57                   	push   di
    1414:	6a 00                	push   0x0
    1416:	9a 50 09 23 14       	call   0x1423:0x950
    141b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141e:	06                   	push   es
    141f:	57                   	push   di
    1420:	9a 03 2a 36 14       	call   0x1436:0x2a03
    1425:	eb 1b                	jmp    0x1442
    1427:	8d be fa fd          	lea    di,[bp-0x206]
    142b:	16                   	push   ss
    142c:	57                   	push   di
    142d:	8d be 7a ff          	lea    di,[bp-0x86]
    1431:	16                   	push   ss
    1432:	57                   	push   di
    1433:	9a 6e 0e 40 14       	call   0x1440:0xe6e
    1438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    143b:	06                   	push   es
    143c:	57                   	push   di
    143d:	9a 03 2a 56 14       	call   0x1456:0x2a03
    1442:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    1447:	8d be fa fe          	lea    di,[bp-0x106]
    144b:	16                   	push   ss
    144c:	57                   	push   di
    144d:	8d be 7a ff          	lea    di,[bp-0x86]
    1451:	16                   	push   ss
    1452:	57                   	push   di
    1453:	9a df 0c bb 14       	call   0x14bb:0xcdf
    1458:	ff 76 fe             	push   WORD PTR [bp-0x2]
    145b:	8d 7e fa             	lea    di,[bp-0x6]
    145e:	16                   	push   ss
    145f:	57                   	push   di
    1460:	8d be 7a ff          	lea    di,[bp-0x86]
    1464:	16                   	push   ss
    1465:	57                   	push   di
    1466:	9a 1d 0a 15 16       	call   0x1615:0xa1d
    146b:	89 46 0c             	mov    WORD PTR [bp+0xc],ax
    146e:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    1472:	75 03                	jne    0x1477
    1474:	e9 9d 00             	jmp    0x1514
    1477:	ff 76 08             	push   WORD PTR [bp+0x8]
    147a:	ff 76 06             	push   WORD PTR [bp+0x6]
    147d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1480:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1483:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1486:	8d be 7a ff          	lea    di,[bp-0x86]
    148a:	16                   	push   ss
    148b:	57                   	push   di
    148c:	b0 01                	mov    al,0x1
    148e:	50                   	push   ax
    148f:	b8 8d 00             	mov    ax,0x8d
    1492:	ba 9a 14             	mov    dx,0x149a
    1495:	52                   	push   dx
    1496:	50                   	push   ax
    1497:	9a 63 12 85 16       	call   0x1685:0x1263
    149c:	8d be 7a ff          	lea    di,[bp-0x86]
    14a0:	16                   	push   ss
    14a1:	57                   	push   di
    14a2:	e8 34 fe             	call   0x12d9
    14a5:	80 be 7a ff 00       	cmp    BYTE PTR [bp-0x86],0x0
    14aa:	74 62                	je     0x150e
    14ac:	8d be 7a ff          	lea    di,[bp-0x86]
    14b0:	16                   	push   ss
    14b1:	57                   	push   di
    14b2:	8d be fa fe          	lea    di,[bp-0x106]
    14b6:	16                   	push   ss
    14b7:	57                   	push   di
    14b8:	9a b2 0d 02 15       	call   0x1502:0xdb2
    14bd:	09 c0                	or     ax,ax
    14bf:	74 4d                	je     0x150e
    14c1:	8d be ea fd          	lea    di,[bp-0x216]
    14c5:	16                   	push   ss
    14c6:	57                   	push   di
    14c7:	bf 6c 13             	mov    di,0x136c
    14ca:	0e                   	push   cs
    14cb:	57                   	push   di
    14cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14cf:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    14d3:	89 f8                	mov    ax,di
    14d5:	8c c2                	mov    dx,es
    14d7:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    14db:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    14df:	c6 86 ee fe 04       	mov    BYTE PTR [bp-0x112],0x4
    14e4:	8d 86 7a ff          	lea    ax,[bp-0x86]
    14e8:	8c d2                	mov    dx,ss
    14ea:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    14ee:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    14f2:	c6 86 f6 fe 06       	mov    BYTE PTR [bp-0x10a],0x6
    14f7:	8d be ea fe          	lea    di,[bp-0x116]
    14fb:	16                   	push   ss
    14fc:	57                   	push   di
    14fd:	6a 01                	push   0x1
    14ff:	9a 34 10 0c 15       	call   0x150c:0x1034
    1504:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1507:	06                   	push   es
    1508:	57                   	push   di
    1509:	9a 03 2a 8c 15       	call   0x158c:0x2a03
    150e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1511:	e9 33 ff             	jmp    0x1447
    1514:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1518:	74 07                	je     0x1521
    151a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    151e:	83 c4 06             	add    sp,0x6
    1521:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1524:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1527:	c9                   	leave
    1528:	ca 08 00             	retf   0x8
    152b:	c8 02 00 00          	enter  0x2,0x0
    152f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1532:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1536:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    153a:	74 45                	je     0x1581
    153c:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1540:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1544:	48                   	dec    ax
    1545:	09 c0                	or     ax,ax
    1547:	7c 2a                	jl     0x1573
    1549:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    154c:	eb 03                	jmp    0x1551
    154e:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    1551:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1554:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1557:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    155b:	06                   	push   es
    155c:	57                   	push   di
    155d:	9a d0 0d c0 15       	call   0x15c0:0xdd0
    1562:	89 c7                	mov    di,ax
    1564:	8e c2                	mov    es,dx
    1566:	06                   	push   es
    1567:	57                   	push   di
    1568:	9a 7f 1f 7f 15       	call   0x157f:0x1f7f
    156d:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1571:	75 db                	jne    0x154e
    1573:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1576:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    157a:	06                   	push   es
    157b:	57                   	push   di
    157c:	9a 7f 1f 97 15       	call   0x1597:0x1f7f
    1581:	31 c0                	xor    ax,ax
    1583:	50                   	push   ax
    1584:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1587:	06                   	push   es
    1588:	57                   	push   di
    1589:	9a c4 29 03 16       	call   0x1603:0x29c4
    158e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1592:	74 05                	je     0x1599
    1594:	9a 0f 20 ad 15       	call   0x15ad:0x200f
    1599:	c9                   	leave
    159a:	ca 06 00             	retf   0x6
    159d:	c8 e8 01 00          	enter  0x1e8,0x0
    15a1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    15a5:	74 08                	je     0x15af
    15a7:	83 ec 08             	sub    sp,0x8
    15aa:	9a e2 1f d0 15       	call   0x15d0:0x1fe2
    15af:	ff 76 0e             	push   WORD PTR [bp+0xe]
    15b2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15b5:	31 c0                	xor    ax,ax
    15b7:	50                   	push   ax
    15b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15bb:	06                   	push   es
    15bc:	57                   	push   di
    15bd:	9a d9 4b c9 15       	call   0x15c9:0x4bd9
    15c2:	b0 01                	mov    al,0x1
    15c4:	50                   	push   ax
    15c5:	b8 a3 02             	mov    ax,0x2a3
    15c8:	ba 13 17             	mov    dx,0x1713
    15cb:	52                   	push   dx
    15cc:	50                   	push   ax
    15cd:	9a 50 1f f0 15       	call   0x15f0:0x1f50
    15d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15d5:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    15d9:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    15dd:	26 c6 45 22 01       	mov    BYTE PTR es:[di+0x22],0x1
    15e2:	8d be 18 ff          	lea    di,[bp-0xe8]
    15e6:	16                   	push   ss
    15e7:	57                   	push   di
    15e8:	68 e6 00             	push   0xe6
    15eb:	6a 00                	push   0x0
    15ed:	9a e5 1e 1e 17       	call   0x171e:0x1ee5
    15f2:	8d 7e be             	lea    di,[bp-0x42]
    15f5:	16                   	push   ss
    15f6:	57                   	push   di
    15f7:	8d be 18 fe          	lea    di,[bp-0x1e8]
    15fb:	16                   	push   ss
    15fc:	57                   	push   di
    15fd:	68 58 f2             	push   0xf258
    1600:	9a 2b 09 0a 16       	call   0x160a:0x92b
    1605:	6a 1f                	push   0x1f
    1607:	9a 6a 0d 25 16       	call   0x1625:0xd6a
    160c:	8d be 18 ff          	lea    di,[bp-0xe8]
    1610:	16                   	push   ss
    1611:	57                   	push   di
    1612:	9a 02 00 68 16       	call   0x1668:0x2
    1617:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    161a:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    161e:	75 70                	jne    0x1690
    1620:	6a 02                	push   0x2
    1622:	9a 76 04 7d 18       	call   0x187d:0x476
    1627:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    162a:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    162e:	26 89 55 26          	mov    WORD PTR es:[di+0x26],dx
    1632:	26 c6 45 23 01       	mov    BYTE PTR es:[di+0x23],0x1
    1637:	81 c7 28 00          	add    di,0x28
    163b:	89 be 14 ff          	mov    WORD PTR [bp-0xec],di
    163f:	8c 86 16 ff          	mov    WORD PTR [bp-0xea],es
    1643:	6a 00                	push   0x0
    1645:	6a 00                	push   0x0
    1647:	6a 15                	push   0x15
    1649:	06                   	push   es
    164a:	57                   	push   di
    164b:	81 c7 04 00          	add    di,0x4
    164f:	06                   	push   es
    1650:	57                   	push   di
    1651:	c4 be 14 ff          	les    di,DWORD PTR [bp-0xec]
    1655:	81 c7 06 00          	add    di,0x6
    1659:	06                   	push   es
    165a:	57                   	push   di
    165b:	c4 be 14 ff          	les    di,DWORD PTR [bp-0xec]
    165f:	81 c7 0a 00          	add    di,0xa
    1663:	06                   	push   es
    1664:	57                   	push   di
    1665:	9a 7d 0a 8c 16       	call   0x168c:0xa7d
    166a:	6a 00                	push   0x0
    166c:	6a 00                	push   0x0
    166e:	6a 15                	push   0x15
    1670:	6a 00                	push   0x0
    1672:	6a 00                	push   0x0
    1674:	6a 02                	push   0x2
    1676:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1679:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    167d:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1681:	bf a9 0d             	mov    di,0xda9
    1684:	b8 b7 16             	mov    ax,0x16b7
    1687:	50                   	push   ax
    1688:	57                   	push   di
    1689:	9a dd 06 c9 16       	call   0x16c9:0x6dd
    168e:	eb 29                	jmp    0x16b9
    1690:	81 7e fe 07 2a       	cmp    WORD PTR [bp-0x2],0x2a07
    1695:	74 22                	je     0x16b9
    1697:	68 32 f2             	push   0xf232
    169a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    169d:	31 d2                	xor    dx,dx
    169f:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
    16a3:	89 96 12 ff          	mov    WORD PTR [bp-0xee],dx
    16a7:	c6 86 14 ff 00       	mov    BYTE PTR [bp-0xec],0x0
    16ac:	8d be 10 ff          	lea    di,[bp-0xf0]
    16b0:	16                   	push   ss
    16b1:	57                   	push   di
    16b2:	6a 00                	push   0x0
    16b4:	9a 0a 12 cf 16       	call   0x16cf:0x120a
    16b9:	6a 00                	push   0x0
    16bb:	6a 00                	push   0x0
    16bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c0:	81 c7 1e 00          	add    di,0x1e
    16c4:	06                   	push   es
    16c5:	57                   	push   di
    16c6:	9a ad 09 4b 17       	call   0x174b:0x9ad
    16cb:	50                   	push   ax
    16cc:	9a 4e 12 c0 17       	call   0x17c0:0x124e
    16d1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    16d5:	74 07                	je     0x16de
    16d7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    16db:	83 c4 06             	add    sp,0x6
    16de:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    16e1:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    16e4:	c9                   	leave
    16e5:	ca 0a 00             	retf   0xa
    16e8:	c8 06 00 00          	enter  0x6,0x0
    16ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ef:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    16f3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    16f7:	48                   	dec    ax
    16f8:	09 c0                	or     ax,ax
    16fa:	7c 2a                	jl     0x1726
    16fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    16ff:	eb 03                	jmp    0x1704
    1701:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    1704:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1707:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    170a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    170e:	06                   	push   es
    170f:	57                   	push   di
    1710:	9a d0 0d 86 17       	call   0x1786:0xdd0
    1715:	89 c7                	mov    di,ax
    1717:	8e c2                	mov    es,dx
    1719:	06                   	push   es
    171a:	57                   	push   di
    171b:	9a 7f 1f 79 17       	call   0x1779:0x1f7f
    1720:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1724:	75 db                	jne    0x1701
    1726:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1729:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    172e:	74 4b                	je     0x177b
    1730:	6a 00                	push   0x0
    1732:	6a 00                	push   0x0
    1734:	6a 15                	push   0x15
    1736:	6a 00                	push   0x0
    1738:	6a 00                	push   0x0
    173a:	6a 02                	push   0x2
    173c:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    1740:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1744:	6a 00                	push   0x0
    1746:	6a 00                	push   0x0
    1748:	9a dd 06 50 17       	call   0x1750:0x6dd
    174d:	9a a3 31 c7 17       	call   0x17c7:0x31a3
    1752:	83 3e ac 0a 00       	cmp    WORD PTR ds:0xaac,0x0
    1757:	74 10                	je     0x1769
    1759:	6a 00                	push   0x0
    175b:	ff 36 ac 0a          	push   WORD PTR ds:0xaac
    175f:	9a ff ff 00 00       	call   0x0:0xffff
    1764:	31 c0                	xor    ax,ax
    1766:	a3 ac 0a             	mov    ds:0xaac,ax
    1769:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    176c:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    1770:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1774:	6a 02                	push   0x2
    1776:	9a 9c 01 91 17       	call   0x1791:0x19c
    177b:	31 c0                	xor    ax,ax
    177d:	50                   	push   ax
    177e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1781:	06                   	push   es
    1782:	57                   	push   di
    1783:	9a 2b 4c 50 18       	call   0x1850:0x4c2b
    1788:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    178c:	74 05                	je     0x1793
    178e:	9a 0f 20 0d 18       	call   0x180d:0x200f
    1793:	c9                   	leave
    1794:	ca 06 00             	retf   0x6
    1797:	c8 00 01 00          	enter  0x100,0x0
    179b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    179e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    17a2:	74 2b                	je     0x17cf
    17a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17a7:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    17ab:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    17af:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    17b2:	06                   	push   es
    17b3:	57                   	push   di
    17b4:	8d be 00 ff          	lea    di,[bp-0x100]
    17b8:	16                   	push   ss
    17b9:	57                   	push   di
    17ba:	68 ff 00             	push   0xff
    17bd:	9a b7 0e cd 17       	call   0x17cd:0xeb7
    17c2:	52                   	push   dx
    17c3:	50                   	push   ax
    17c4:	9a 2d 04 03 19       	call   0x1903:0x42d
    17c9:	50                   	push   ax
    17ca:	9a 4e 12 19 18       	call   0x1819:0x124e
    17cf:	c9                   	leave
    17d0:	ca 08 00             	retf   0x8
    17d3:	55                   	push   bp
    17d4:	89 e5                	mov    bp,sp
    17d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    17d9:	26 83 7d 26 00       	cmp    WORD PTR es:[di+0x26],0x0
    17de:	74 07                	je     0x17e7
    17e0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    17e3:	26 ff 4d 26          	dec    WORD PTR es:[di+0x26]
    17e7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    17ea:	26 83 7d 26 00       	cmp    WORD PTR es:[di+0x26],0x0
    17ef:	75 2a                	jne    0x181b
    17f1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    17f4:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    17f9:	75 20                	jne    0x181b
    17fb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    17fe:	26 80 7d 21 00       	cmp    BYTE PTR es:[di+0x21],0x0
    1803:	74 0c                	je     0x1811
    1805:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1808:	06                   	push   es
    1809:	57                   	push   di
    180a:	9a 7f 1f 40 1c       	call   0x1c40:0x1f7f
    180f:	eb 0a                	jmp    0x181b
    1811:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1814:	06                   	push   es
    1815:	57                   	push   di
    1816:	9a 23 20 ab 18       	call   0x18ab:0x2023
    181b:	c9                   	leave
    181c:	ca 08 00             	retf   0x8
    181f:	c8 08 00 00          	enter  0x8,0x0
    1823:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1826:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    182a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    182e:	48                   	dec    ax
    182f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1832:	31 c0                	xor    ax,ax
    1834:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1837:	7f 54                	jg     0x188d
    1839:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    183c:	eb 03                	jmp    0x1841
    183e:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1841:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1844:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1847:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    184b:	06                   	push   es
    184c:	57                   	push   di
    184d:	9a d0 0d b9 18       	call   0x18b9:0xdd0
    1852:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1855:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1858:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    185b:	26 80 7d 38 00       	cmp    BYTE PTR es:[di+0x38],0x0
    1860:	75 0a                	jne    0x186c
    1862:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1865:	26 80 7d 21 00       	cmp    BYTE PTR es:[di+0x21],0x0
    186a:	74 19                	je     0x1885
    186c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    186f:	81 c7 38 00          	add    di,0x38
    1873:	06                   	push   es
    1874:	57                   	push   di
    1875:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1878:	06                   	push   es
    1879:	57                   	push   di
    187a:	9a ed 07 e4 18       	call   0x18e4:0x7ed
    187f:	09 c0                	or     ax,ax
    1881:	75 02                	jne    0x1885
    1883:	eb 10                	jmp    0x1895
    1885:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1888:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    188b:	75 b1                	jne    0x183e
    188d:	31 c0                	xor    ax,ax
    188f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1892:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1895:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1898:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    189b:	c9                   	leave
    189c:	ca 08 00             	retf   0x8
    189f:	07                   	pop    es
    18a0:	50                   	push   ax
    18a1:	41                   	inc    cx
    18a2:	54                   	push   sp
    18a3:	48                   	dec    ax
    18a4:	3d 25 73             	cmp    ax,0x7325
    18a7:	00 00                	add    BYTE PTR [bx+si],al
    18a9:	8e 19                	mov    ds,WORD PTR [bx+di]
    18ab:	09 19                	or     WORD PTR [bx+di],bx
    18ad:	c8 da 01 00          	enter  0x1da,0x0
    18b1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18b4:	06                   	push   es
    18b5:	57                   	push   di
    18b6:	9a c5 13 96 19       	call   0x1996:0x13c5
    18bb:	b8 a7 18             	mov    ax,0x18a7
    18be:	0e                   	push   cs
    18bf:	50                   	push   ax
    18c0:	55                   	push   bp
    18c1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    18c5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    18c9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18cc:	06                   	push   es
    18cd:	57                   	push   di
    18ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18d1:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    18d5:	8d 7e e0             	lea    di,[bp-0x20]
    18d8:	16                   	push   ss
    18d9:	57                   	push   di
    18da:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    18dd:	06                   	push   es
    18de:	57                   	push   di
    18df:	6a 1f                	push   0x1f
    18e1:	9a 6a 0d 18 19       	call   0x1918:0xd6a
    18e6:	8d 7e e0             	lea    di,[bp-0x20]
    18e9:	16                   	push   ss
    18ea:	57                   	push   di
    18eb:	8d 7e e0             	lea    di,[bp-0x20]
    18ee:	16                   	push   ss
    18ef:	57                   	push   di
    18f0:	9a 76 1e 00 00       	call   0x0:0x1e76
    18f5:	8d 7e e0             	lea    di,[bp-0x20]
    18f8:	16                   	push   ss
    18f9:	57                   	push   di
    18fa:	8d be 2e ff          	lea    di,[bp-0xd2]
    18fe:	16                   	push   ss
    18ff:	57                   	push   di
    1900:	9a bd 04 f6 19       	call   0x19f6:0x4bd
    1905:	50                   	push   ax
    1906:	9a 4e 12 80 19       	call   0x1980:0x124e
    190b:	8d 7e c0             	lea    di,[bp-0x40]
    190e:	16                   	push   ss
    190f:	57                   	push   di
    1910:	bf ae 0a             	mov    di,0xaae
    1913:	1e                   	push   ds
    1914:	57                   	push   di
    1915:	9a db 0d 58 19       	call   0x1958:0xddb
    191a:	09 c0                	or     ax,ax
    191c:	75 4a                	jne    0x1968
    191e:	8d be 6e ff          	lea    di,[bp-0x92]
    1922:	16                   	push   ss
    1923:	57                   	push   di
    1924:	8d be 6e ff          	lea    di,[bp-0x92]
    1928:	16                   	push   ss
    1929:	57                   	push   di
    192a:	9a 34 1a 00 00       	call   0x0:0x1a34
    192f:	8d be 26 fe          	lea    di,[bp-0x1da]
    1933:	16                   	push   ss
    1934:	57                   	push   di
    1935:	bf 9f 18             	mov    di,0x189f
    1938:	0e                   	push   cs
    1939:	57                   	push   di
    193a:	8d 86 6e ff          	lea    ax,[bp-0x92]
    193e:	8c d2                	mov    dx,ss
    1940:	89 86 26 ff          	mov    WORD PTR [bp-0xda],ax
    1944:	89 96 28 ff          	mov    WORD PTR [bp-0xd8],dx
    1948:	c6 86 2a ff 06       	mov    BYTE PTR [bp-0xd6],0x6
    194d:	8d be 26 ff          	lea    di,[bp-0xda]
    1951:	16                   	push   ss
    1952:	57                   	push   di
    1953:	6a 00                	push   0x0
    1955:	9a 34 10 ea 19       	call   0x19ea:0x1034
    195a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    195d:	06                   	push   es
    195e:	57                   	push   di
    195f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1962:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1966:	eb 1a                	jmp    0x1982
    1968:	bf b7 0a             	mov    di,0xab7
    196b:	1e                   	push   ds
    196c:	57                   	push   di
    196d:	8d 7e e0             	lea    di,[bp-0x20]
    1970:	16                   	push   ss
    1971:	57                   	push   di
    1972:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1975:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1978:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    197b:	06                   	push   es
    197c:	57                   	push   di
    197d:	9a b3 19 b1 19       	call   0x19b1:0x19b3
    1982:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1986:	83 c4 06             	add    sp,0x6
    1989:	b8 99 19             	mov    ax,0x1999
    198c:	0e                   	push   cs
    198d:	50                   	push   ax
    198e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1991:	06                   	push   es
    1992:	57                   	push   di
    1993:	9a 35 14 d1 1a       	call   0x1ad1:0x1435
    1998:	cb                   	retf
    1999:	c9                   	leave
    199a:	ca 0c 00             	retf   0xc
    199d:	05 25 73             	add    ax,0x7325
    19a0:	3d 25 73             	cmp    ax,0x7325
    19a3:	09 50 41             	or     WORD PTR [bx+si+0x41],dx
    19a6:	53                   	push   bx
    19a7:	53                   	push   bx
    19a8:	57                   	push   di
    19a9:	4f                   	dec    di
    19aa:	52                   	push   dx
    19ab:	44                   	inc    sp
    19ac:	3d 00 00             	cmp    ax,0x0
    19af:	a1 1a fc             	mov    ax,ds:0xfc1a
    19b2:	19 c8                	sbb    ax,cx
    19b4:	78 02                	js     0x19b8
    19b6:	00 6a 00             	add    BYTE PTR [bp+si+0x0],ch
    19b9:	6a 00                	push   0x0
    19bb:	6a 01                	push   0x1
    19bd:	6a 00                	push   0x0
    19bf:	8d 7e bc             	lea    di,[bp-0x44]
    19c2:	16                   	push   ss
    19c3:	57                   	push   di
    19c4:	6a 3f                	push   0x3f
    19c6:	ff 76 14             	push   WORD PTR [bp+0x14]
    19c9:	ff 76 12             	push   WORD PTR [bp+0x12]
    19cc:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    19cf:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    19d2:	89 86 90 fe          	mov    WORD PTR [bp-0x170],ax
    19d6:	89 96 92 fe          	mov    WORD PTR [bp-0x16e],dx
    19da:	c6 86 94 fe 06       	mov    BYTE PTR [bp-0x16c],0x6
    19df:	8d be 90 fe          	lea    di,[bp-0x170]
    19e3:	16                   	push   ss
    19e4:	57                   	push   di
    19e5:	6a 00                	push   0x0
    19e7:	9a eb 0f 74 1a       	call   0x1a74:0xfeb
    19ec:	52                   	push   dx
    19ed:	50                   	push   ax
    19ee:	8d 7e fc             	lea    di,[bp-0x4]
    19f1:	16                   	push   ss
    19f2:	57                   	push   di
    19f3:	9a 2d 21 21 1a       	call   0x1a21:0x212d
    19f8:	50                   	push   ax
    19f9:	9a 4e 12 c3 1a       	call   0x1ac3:0x124e
    19fe:	b8 ad 19             	mov    ax,0x19ad
    1a01:	0e                   	push   cs
    1a02:	50                   	push   ax
    1a03:	55                   	push   bp
    1a04:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1a08:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1a0c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a0f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a12:	6a 00                	push   0x0
    1a14:	8d be 98 fe          	lea    di,[bp-0x168]
    1a18:	16                   	push   ss
    1a19:	57                   	push   di
    1a1a:	6a 00                	push   0x0
    1a1c:	6a 00                	push   0x0
    1a1e:	9a ed 00 a9 1a       	call   0x1aa9:0xed
    1a23:	09 c0                	or     ax,ax
    1a25:	75 5d                	jne    0x1a84
    1a27:	8d be 3a ff          	lea    di,[bp-0xc6]
    1a2b:	16                   	push   ss
    1a2c:	57                   	push   di
    1a2d:	8d be 3a ff          	lea    di,[bp-0xc6]
    1a31:	16                   	push   ss
    1a32:	57                   	push   di
    1a33:	9a ff ff 00 00       	call   0x0:0xffff
    1a38:	8d be 88 fd          	lea    di,[bp-0x278]
    1a3c:	16                   	push   ss
    1a3d:	57                   	push   di
    1a3e:	bf 9d 19             	mov    di,0x199d
    1a41:	0e                   	push   cs
    1a42:	57                   	push   di
    1a43:	8d 86 98 fe          	lea    ax,[bp-0x168]
    1a47:	8c d2                	mov    dx,ss
    1a49:	89 86 88 fe          	mov    WORD PTR [bp-0x178],ax
    1a4d:	89 96 8a fe          	mov    WORD PTR [bp-0x176],dx
    1a51:	c6 86 8c fe 06       	mov    BYTE PTR [bp-0x174],0x6
    1a56:	8d 86 3a ff          	lea    ax,[bp-0xc6]
    1a5a:	8c d2                	mov    dx,ss
    1a5c:	89 86 90 fe          	mov    WORD PTR [bp-0x170],ax
    1a60:	89 96 92 fe          	mov    WORD PTR [bp-0x16e],dx
    1a64:	c6 86 94 fe 06       	mov    BYTE PTR [bp-0x16c],0x6
    1a69:	8d be 88 fe          	lea    di,[bp-0x178]
    1a6d:	16                   	push   ss
    1a6e:	57                   	push   di
    1a6f:	6a 01                	push   0x1
    1a71:	9a 34 10 fa 1a       	call   0x1afa:0x1034
    1a76:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a79:	06                   	push   es
    1a7a:	57                   	push   di
    1a7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a7e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1a82:	eb 88                	jmp    0x1a0c
    1a84:	bf a3 19             	mov    di,0x19a3
    1a87:	0e                   	push   cs
    1a88:	57                   	push   di
    1a89:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a8c:	06                   	push   es
    1a8d:	57                   	push   di
    1a8e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a91:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1a95:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1a99:	83 c4 06             	add    sp,0x6
    1a9c:	b8 ac 1a             	mov    ax,0x1aac
    1a9f:	0e                   	push   cs
    1aa0:	50                   	push   ax
    1aa1:	8d 7e fc             	lea    di,[bp-0x4]
    1aa4:	16                   	push   ss
    1aa5:	57                   	push   di
    1aa6:	9a ad 00 60 1c       	call   0x1c60:0xad
    1aab:	cb                   	retf
    1aac:	c9                   	leave
    1aad:	ca 10 00             	retf   0x10
    1ab0:	08 53 54             	or     BYTE PTR [bp+di+0x54],dl
    1ab3:	41                   	inc    cx
    1ab4:	4e                   	dec    si
    1ab5:	44                   	inc    sp
    1ab6:	41                   	inc    cx
    1ab7:	52                   	push   dx
    1ab8:	44                   	inc    sp
    1ab9:	05 50 41             	add    ax,0x4150
    1abc:	54                   	push   sp
    1abd:	48                   	dec    ax
    1abe:	3d 00 00             	cmp    ax,0x0
    1ac1:	47                   	inc    di
    1ac2:	1b 39                	sbb    di,WORD PTR [bx+di]
    1ac4:	1b c8                	sbb    cx,ax
    1ac6:	20 00                	and    BYTE PTR [bx+si],al
    1ac8:	00 c4                	add    ah,al
    1aca:	7e 0a                	jle    0x1ad6
    1acc:	06                   	push   es
    1acd:	57                   	push   di
    1ace:	9a c5 13 4f 1b       	call   0x1b4f:0x13c5
    1ad3:	b8 bf 1a             	mov    ax,0x1abf
    1ad6:	0e                   	push   cs
    1ad7:	50                   	push   ax
    1ad8:	55                   	push   bp
    1ad9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1add:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1ae1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ae4:	06                   	push   es
    1ae5:	57                   	push   di
    1ae6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ae9:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1aed:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1af0:	06                   	push   es
    1af1:	57                   	push   di
    1af2:	bf b0 1a             	mov    di,0x1ab0
    1af5:	0e                   	push   cs
    1af6:	57                   	push   di
    1af7:	9a 30 07 27 1b       	call   0x1b27:0x730
    1afc:	09 c0                	or     ax,ax
    1afe:	75 13                	jne    0x1b13
    1b00:	bf b9 1a             	mov    di,0x1ab9
    1b03:	0e                   	push   cs
    1b04:	57                   	push   di
    1b05:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b08:	06                   	push   es
    1b09:	57                   	push   di
    1b0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b0d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1b11:	eb 28                	jmp    0x1b3b
    1b13:	bf ce 0a             	mov    di,0xace
    1b16:	1e                   	push   ds
    1b17:	57                   	push   di
    1b18:	8d 7e e0             	lea    di,[bp-0x20]
    1b1b:	16                   	push   ss
    1b1c:	57                   	push   di
    1b1d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1b20:	06                   	push   es
    1b21:	57                   	push   di
    1b22:	6a 1f                	push   0x1f
    1b24:	9a 6a 0d 41 1d       	call   0x1d41:0xd6a
    1b29:	52                   	push   dx
    1b2a:	50                   	push   ax
    1b2b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b2e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1b31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b34:	06                   	push   es
    1b35:	57                   	push   di
    1b36:	9a b3 19 94 1b       	call   0x1b94:0x19b3
    1b3b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1b3f:	83 c4 06             	add    sp,0x6
    1b42:	b8 52 1b             	mov    ax,0x1b52
    1b45:	0e                   	push   cs
    1b46:	50                   	push   ax
    1b47:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b4a:	06                   	push   es
    1b4b:	57                   	push   di
    1b4c:	9a 35 14 04 1f       	call   0x1f04:0x1435
    1b51:	cb                   	retf
    1b52:	c9                   	leave
    1b53:	ca 0c 00             	retf   0xc
    1b56:	c8 02 00 00          	enter  0x2,0x0
    1b5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b5d:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    1b61:	09 c0                	or     ax,ax
    1b63:	74 18                	je     0x1b7d
    1b65:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1b69:	ff 76 08             	push   WORD PTR [bp+0x8]
    1b6c:	ff 76 06             	push   WORD PTR [bp+0x6]
    1b6f:	8d 7e ff             	lea    di,[bp-0x1]
    1b72:	16                   	push   ss
    1b73:	57                   	push   di
    1b74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b77:	26 ff 5d 36          	call   DWORD PTR es:[di+0x36]
    1b7b:	eb 08                	jmp    0x1b85
    1b7d:	9a 03 3d b8 22       	call   0x22b8:0x3d03
    1b82:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1b85:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1b88:	c9                   	leave
    1b89:	ca 04 00             	retf   0x4
    1b8c:	01 00                	add    WORD PTR [bx+si],ax
    1b8e:	00 00                	add    BYTE PTR [bx+si],al
    1b90:	00 00                	add    BYTE PTR [bx+si],al
    1b92:	38 1c                	cmp    BYTE PTR [si],bl
    1b94:	bd 1b c8             	mov    bp,0xc81b
    1b97:	08 00                	or     BYTE PTR [bx+si],al
    1b99:	00 31                	add    BYTE PTR [bx+di],dh
    1b9b:	c0 89 46 f8 89       	ror    BYTE PTR [bx+di-0x7ba],0x89
    1ba0:	46                   	inc    si
    1ba1:	fa                   	cli
    1ba2:	b8 8c 1b             	mov    ax,0x1b8c
    1ba5:	0e                   	push   cs
    1ba6:	50                   	push   ax
    1ba7:	55                   	push   bp
    1ba8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1bac:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1bb0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1bb3:	06                   	push   es
    1bb4:	57                   	push   di
    1bb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb8:	06                   	push   es
    1bb9:	57                   	push   di
    1bba:	9a 1f 18 da 1b       	call   0x1bda:0x181f
    1bbf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1bc2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1bc5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1bc8:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    1bcb:	75 51                	jne    0x1c1e
    1bcd:	ff 76 08             	push   WORD PTR [bp+0x8]
    1bd0:	ff 76 06             	push   WORD PTR [bp+0x6]
    1bd3:	b0 01                	mov    al,0x1
    1bd5:	50                   	push   ax
    1bd6:	b8 d7 01             	mov    ax,0x1d7
    1bd9:	ba e1 1b             	mov    dx,0x1be1
    1bdc:	52                   	push   dx
    1bdd:	50                   	push   ax
    1bde:	9a e2 1e f6 1b       	call   0x1bf6:0x1ee2
    1be3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1be6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1be9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1bec:	06                   	push   es
    1bed:	57                   	push   di
    1bee:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1bf1:	06                   	push   es
    1bf2:	57                   	push   di
    1bf3:	9a a8 26 08 1c       	call   0x1c08:0x26a8
    1bf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bfb:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    1bff:	50                   	push   ax
    1c00:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c03:	06                   	push   es
    1c04:	57                   	push   di
    1c05:	9a 3a 27 26 1c       	call   0x1c26:0x273a
    1c0a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c0d:	26 c6 45 21 01       	mov    BYTE PTR es:[di+0x21],0x1
    1c12:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1c15:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1c18:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c1b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c1e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c21:	06                   	push   es
    1c22:	57                   	push   di
    1c23:	9a 23 23 8f 1c       	call   0x1c8f:0x2323
    1c28:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c2b:	26 ff 45 26          	inc    WORD PTR es:[di+0x26]
    1c2f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1c33:	83 c4 06             	add    sp,0x6
    1c36:	eb 14                	jmp    0x1c4c
    1c38:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c3b:	06                   	push   es
    1c3c:	57                   	push   di
    1c3d:	9a 7f 1f 45 1c       	call   0x1c45:0x1f7f
    1c42:	ea 85 13 4a 1c       	jmp    0x1c4a:0x1385
    1c47:	9a 34 14 ae 1c       	call   0x1cae:0x1434
    1c4c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1c4f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1c52:	c9                   	leave
    1c53:	ca 08 00             	retf   0x8
    1c56:	55                   	push   bp
    1c57:	89 e5                	mov    bp,sp
    1c59:	6a 00                	push   0x0
    1c5b:	6a 00                	push   0x0
    1c5d:	9a 3d 04 96 1c       	call   0x1c96:0x43d
    1c62:	c9                   	leave
    1c63:	ca 04 00             	retf   0x4
    1c66:	c8 00 01 00          	enter  0x100,0x0
    1c6a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c6d:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1c71:	74 25                	je     0x1c98
    1c73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c76:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1c7a:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1c7e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c81:	06                   	push   es
    1c82:	57                   	push   di
    1c83:	8d be 00 ff          	lea    di,[bp-0x100]
    1c87:	16                   	push   ss
    1c88:	57                   	push   di
    1c89:	68 ff 00             	push   0xff
    1c8c:	9a b7 0e 57 1f       	call   0x1f57:0xeb7
    1c91:	52                   	push   dx
    1c92:	50                   	push   ax
    1c93:	9a 3d 04 4d 20       	call   0x204d:0x43d
    1c98:	c9                   	leave
    1c99:	ca 08 00             	retf   0x8
    1c9c:	01 3d                	add    WORD PTR [di],di
    1c9e:	c8 10 02 00          	enter  0x210,0x0
    1ca2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ca6:	74 08                	je     0x1cb0
    1ca8:	83 ec 08             	sub    sp,0x8
    1cab:	9a e2 1f f2 1c       	call   0x1cf2:0x1fe2
    1cb0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1cb3:	06                   	push   es
    1cb4:	57                   	push   di
    1cb5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1cb8:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1cbc:	48                   	dec    ax
    1cbd:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    1cc1:	31 c0                	xor    ax,ax
    1cc3:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    1cc7:	7f 62                	jg     0x1d2b
    1cc9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ccc:	eb 03                	jmp    0x1cd1
    1cce:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1cd1:	8d be f4 fd          	lea    di,[bp-0x20c]
    1cd5:	16                   	push   ss
    1cd6:	57                   	push   di
    1cd7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1cda:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1cdd:	06                   	push   es
    1cde:	57                   	push   di
    1cdf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ce2:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1ce6:	8d be f6 fe          	lea    di,[bp-0x10a]
    1cea:	16                   	push   ss
    1ceb:	57                   	push   di
    1cec:	68 ff 00             	push   0xff
    1cef:	9a e7 17 02 1d       	call   0x1d02:0x17e7
    1cf4:	bf 9c 1c             	mov    di,0x1c9c
    1cf7:	0e                   	push   cs
    1cf8:	57                   	push   di
    1cf9:	8d be f6 fe          	lea    di,[bp-0x10a]
    1cfd:	16                   	push   ss
    1cfe:	57                   	push   di
    1cff:	9a 78 18 ba 1d       	call   0x1dba:0x1878
    1d04:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d07:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1d0b:	74 15                	je     0x1d22
    1d0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d10:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
    1d14:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    1d18:	30 e4                	xor    ah,ah
    1d1a:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1d1d:	40                   	inc    ax
    1d1e:	26 01 45 06          	add    WORD PTR es:[di+0x6],ax
    1d22:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d25:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    1d29:	75 a3                	jne    0x1cce
    1d2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d2e:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    1d33:	7f 03                	jg     0x1d38
    1d35:	e9 59 01             	jmp    0x1e91
    1d38:	26 6b 45 04 34       	imul   ax,WORD PTR es:[di+0x4],0x34
    1d3d:	50                   	push   ax
    1d3e:	9a 76 04 55 1d       	call   0x1d55:0x476
    1d43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d46:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1d4a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    1d4e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1d52:	9a 76 04 19 1e       	call   0x1e19:0x476
    1d57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d5a:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1d5e:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1d62:	31 c0                	xor    ax,ax
    1d64:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1d67:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1d6b:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    1d6f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1d72:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    1d75:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1d78:	06                   	push   es
    1d79:	57                   	push   di
    1d7a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d7d:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1d81:	48                   	dec    ax
    1d82:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    1d86:	31 c0                	xor    ax,ax
    1d88:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    1d8c:	7e 03                	jle    0x1d91
    1d8e:	e9 00 01             	jmp    0x1e91
    1d91:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d94:	eb 03                	jmp    0x1d99
    1d96:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d99:	8d be f4 fd          	lea    di,[bp-0x20c]
    1d9d:	16                   	push   ss
    1d9e:	57                   	push   di
    1d9f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1da2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1da5:	06                   	push   es
    1da6:	57                   	push   di
    1da7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1daa:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1dae:	8d be f6 fe          	lea    di,[bp-0x10a]
    1db2:	16                   	push   ss
    1db3:	57                   	push   di
    1db4:	68 ff 00             	push   0xff
    1db7:	9a e7 17 ca 1d       	call   0x1dca:0x17e7
    1dbc:	bf 9c 1c             	mov    di,0x1c9c
    1dbf:	0e                   	push   cs
    1dc0:	57                   	push   di
    1dc1:	8d be f6 fe          	lea    di,[bp-0x10a]
    1dc5:	16                   	push   ss
    1dc6:	57                   	push   di
    1dc7:	9a 78 18 12 1e       	call   0x1e12:0x1878
    1dcc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1dcf:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1dd3:	75 03                	jne    0x1dd8
    1dd5:	e9 ad 00             	jmp    0x1e85
    1dd8:	6b 46 fa 34          	imul   ax,WORD PTR [bp-0x6],0x34
    1ddc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ddf:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1de3:	03 f8                	add    di,ax
    1de5:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    1de9:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    1ded:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1df0:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1df3:	26 89 05             	mov    WORD PTR es:[di],ax
    1df6:	81 c7 02 00          	add    di,0x2
    1dfa:	06                   	push   es
    1dfb:	57                   	push   di
    1dfc:	8d be f0 fd          	lea    di,[bp-0x210]
    1e00:	16                   	push   ss
    1e01:	57                   	push   di
    1e02:	8d be f6 fe          	lea    di,[bp-0x10a]
    1e06:	16                   	push   ss
    1e07:	57                   	push   di
    1e08:	6a 01                	push   0x1
    1e0a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e0d:	48                   	dec    ax
    1e0e:	50                   	push   ax
    1e0f:	9a 0b 18 62 1e       	call   0x1e62:0x180b
    1e14:	6a 1f                	push   0x1f
    1e16:	9a 6a 0d 67 1e       	call   0x1e67:0xd6a
    1e1b:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1e1f:	26 c7 45 22 01 00    	mov    WORD PTR es:[di+0x22],0x1
    1e25:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1e28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2b:	26 2b 45 0c          	sub    ax,WORD PTR es:[di+0xc]
    1e2f:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1e33:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    1e37:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    1e3b:	30 e4                	xor    ah,ah
    1e3d:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1e40:	40                   	inc    ax
    1e41:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    1e45:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1e48:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1e4b:	8d be f0 fd          	lea    di,[bp-0x210]
    1e4f:	16                   	push   ss
    1e50:	57                   	push   di
    1e51:	8d be f6 fe          	lea    di,[bp-0x10a]
    1e55:	16                   	push   ss
    1e56:	57                   	push   di
    1e57:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e5a:	40                   	inc    ax
    1e5b:	50                   	push   ax
    1e5c:	68 ff 00             	push   0xff
    1e5f:	9a 0b 18 dc 1e       	call   0x1edc:0x180b
    1e64:	9a 4c 0d bf 21       	call   0x21bf:0xd4c
    1e69:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1e6c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1e6f:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1e72:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1e75:	9a 2e 24 00 00       	call   0x0:0x242e
    1e7a:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1e7e:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    1e82:	01 46 f6             	add    WORD PTR [bp-0xa],ax
    1e85:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e88:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    1e8c:	74 03                	je     0x1e91
    1e8e:	e9 05 ff             	jmp    0x1d96
    1e91:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1e95:	74 07                	je     0x1e9e
    1e97:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1e9b:	83 c4 06             	add    sp,0x6
    1e9e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1ea1:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1ea4:	c9                   	leave
    1ea5:	ca 0a 00             	retf   0xa
    1ea8:	55                   	push   bp
    1ea9:	89 e5                	mov    bp,sp
    1eab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eae:	81 c7 0c 00          	add    di,0xc
    1eb2:	06                   	push   es
    1eb3:	57                   	push   di
    1eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb7:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1ebb:	e8 b1 ef             	call   0xe6f
    1ebe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec1:	81 c7 08 00          	add    di,0x8
    1ec5:	06                   	push   es
    1ec6:	57                   	push   di
    1ec7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eca:	26 6b 45 04 34       	imul   ax,WORD PTR es:[di+0x4],0x34
    1ecf:	50                   	push   ax
    1ed0:	e8 9c ef             	call   0xe6f
    1ed3:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ed7:	74 05                	je     0x1ede
    1ed9:	9a 0f 20 f1 1e       	call   0x1ef1:0x200f
    1ede:	c9                   	leave
    1edf:	ca 06 00             	retf   0x6
    1ee2:	55                   	push   bp
    1ee3:	89 e5                	mov    bp,sp
    1ee5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ee9:	74 08                	je     0x1ef3
    1eeb:	83 ec 08             	sub    sp,0x8
    1eee:	9a e2 1f 29 1f       	call   0x1f29:0x1fe2
    1ef3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1ef6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ef9:	31 c0                	xor    ax,ax
    1efb:	50                   	push   ax
    1efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eff:	06                   	push   es
    1f00:	57                   	push   di
    1f01:	9a d9 4b 19 1f       	call   0x1f19:0x4bd9
    1f06:	ff 76 08             	push   WORD PTR [bp+0x8]
    1f09:	ff 76 06             	push   WORD PTR [bp+0x6]
    1f0c:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    1f10:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1f14:	06                   	push   es
    1f15:	57                   	push   di
    1f16:	9a 2b 0c 22 1f       	call   0x1f22:0xc2b
    1f1b:	b0 01                	mov    al,0x1
    1f1d:	50                   	push   ax
    1f1e:	b8 a3 02             	mov    ax,0x2a3
    1f21:	ba 3d 1f             	mov    dx,0x1f3d
    1f24:	52                   	push   dx
    1f25:	50                   	push   ax
    1f26:	9a 50 1f c6 1f       	call   0x1fc6:0x1f50
    1f2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2e:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    1f32:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    1f36:	b0 01                	mov    al,0x1
    1f38:	50                   	push   ax
    1f39:	b8 c9 03             	mov    ax,0x3c9
    1f3c:	ba 44 1f             	mov    dx,0x1f44
    1f3f:	52                   	push   dx
    1f40:	50                   	push   ax
    1f41:	9a 08 1d e9 1f       	call   0x1fe9:0x1d08
    1f46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f49:	26 89 45 34          	mov    WORD PTR es:[di+0x34],ax
    1f4d:	26 89 55 36          	mov    WORD PTR es:[di+0x36],dx
    1f51:	06                   	push   es
    1f52:	57                   	push   di
    1f53:	b8 49 26             	mov    ax,0x2649
    1f56:	ba b8 1f             	mov    dx,0x1fb8
    1f59:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1f5d:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    1f61:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    1f65:	26 8f 45 18          	pop    WORD PTR es:[di+0x18]
    1f69:	26 8f 45 1a          	pop    WORD PTR es:[di+0x1a]
    1f6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f70:	26 c6 45 1f 01       	mov    BYTE PTR es:[di+0x1f],0x1
    1f75:	26 c6 45 20 01       	mov    BYTE PTR es:[di+0x20],0x1
    1f7a:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    1f7e:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    1f82:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    1f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f89:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    1f8d:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    1f91:	26 c6 45 1e 01       	mov    BYTE PTR es:[di+0x1e],0x1
    1f96:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1f9a:	74 07                	je     0x1fa3
    1f9c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1fa0:	83 c4 06             	add    sp,0x6
    1fa3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1fa6:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1fa9:	c9                   	leave
    1faa:	ca 0a 00             	retf   0xa
    1fad:	55                   	push   bp
    1fae:	89 e5                	mov    bp,sp
    1fb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb3:	06                   	push   es
    1fb4:	57                   	push   di
    1fb5:	9a 23 20 1d 20       	call   0x201d:0x2023
    1fba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fbd:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1fc1:	06                   	push   es
    1fc2:	57                   	push   di
    1fc3:	9a 7f 1f d4 1f       	call   0x1fd4:0x1f7f
    1fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fcb:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1fcf:	06                   	push   es
    1fd0:	57                   	push   di
    1fd1:	9a 7f 1f 01 20       	call   0x2001:0x1f7f
    1fd6:	ff 76 08             	push   WORD PTR [bp+0x8]
    1fd9:	ff 76 06             	push   WORD PTR [bp+0x6]
    1fdc:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    1fe0:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1fe4:	06                   	push   es
    1fe5:	57                   	push   di
    1fe6:	9a a7 0f f6 1f       	call   0x1ff6:0xfa7
    1feb:	31 c0                	xor    ax,ax
    1fed:	50                   	push   ax
    1fee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ff1:	06                   	push   es
    1ff2:	57                   	push   di
    1ff3:	9a 2b 4c ad 20       	call   0x20ad:0x4c2b
    1ff8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ffc:	74 05                	je     0x2003
    1ffe:	9a 0f 20 e0 20       	call   0x20e0:0x200f
    2003:	c9                   	leave
    2004:	ca 06 00             	retf   0x6
    2007:	55                   	push   bp
    2008:	89 e5                	mov    bp,sp
    200a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200d:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    2011:	26 0b 45 2a          	or     ax,WORD PTR es:[di+0x2a]
    2015:	74 08                	je     0x201f
    2017:	68 02 f2             	push   0xf202
    201a:	9a ef 11 38 20       	call   0x2038:0x11ef
    201f:	c9                   	leave
    2020:	ca 04 00             	retf   0x4
    2023:	55                   	push   bp
    2024:	89 e5                	mov    bp,sp
    2026:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2029:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    202d:	26 0b 45 2a          	or     ax,WORD PTR es:[di+0x2a]
    2031:	74 59                	je     0x208c
    2033:	06                   	push   es
    2034:	57                   	push   di
    2035:	9a 90 20 b0 21       	call   0x21b0:0x2090
    203a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    203d:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    2042:	74 0b                	je     0x204f
    2044:	81 c7 30 00          	add    di,0x30
    2048:	06                   	push   es
    2049:	57                   	push   di
    204a:	9a dd 14 77 20       	call   0x2077:0x14dd
    204f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2052:	26 c6 45 23 00       	mov    BYTE PTR es:[di+0x23],0x0
    2057:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    205b:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    205f:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    2063:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2066:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    206a:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    206e:	81 c7 28 00          	add    di,0x28
    2072:	06                   	push   es
    2073:	57                   	push   di
    2074:	9a 5d 00 aa 21       	call   0x21aa:0x5d
    2079:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    207c:	31 c0                	xor    ax,ax
    207e:	26 89 45 28          	mov    WORD PTR es:[di+0x28],ax
    2082:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    2086:	31 c0                	xor    ax,ax
    2088:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    208c:	c9                   	leave
    208d:	ca 04 00             	retf   0x4
    2090:	55                   	push   bp
    2091:	89 e5                	mov    bp,sp
    2093:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2096:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    209a:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    209f:	74 1e                	je     0x20bf
    20a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a4:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    20a8:	06                   	push   es
    20a9:	57                   	push   di
    20aa:	9a 43 0f 20 21       	call   0x2120:0xf43
    20af:	89 c7                	mov    di,ax
    20b1:	8e c2                	mov    es,dx
    20b3:	06                   	push   es
    20b4:	57                   	push   di
    20b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20b8:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    20bd:	eb d4                	jmp    0x2093
    20bf:	c9                   	leave
    20c0:	ca 04 00             	retf   0x4
    20c3:	55                   	push   bp
    20c4:	89 e5                	mov    bp,sp
    20c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20c9:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    20ce:	74 14                	je     0x20e4
    20d0:	81 c7 88 00          	add    di,0x88
    20d4:	06                   	push   es
    20d5:	57                   	push   di
    20d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    20d9:	06                   	push   es
    20da:	57                   	push   di
    20db:	6a 1f                	push   0x1f
    20dd:	9a e7 17 74 21       	call   0x2174:0x17e7
    20e2:	eb 07                	jmp    0x20eb
    20e4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    20e7:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    20eb:	c9                   	leave
    20ec:	ca 04 00             	retf   0x4
    20ef:	c8 02 00 00          	enter  0x2,0x0
    20f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f6:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    20fa:	26 0b 45 2a          	or     ax,WORD PTR es:[di+0x2a]
    20fe:	b0 00                	mov    al,0x0
    2100:	74 01                	je     0x2103
    2102:	40                   	inc    ax
    2103:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2106:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2109:	c9                   	leave
    210a:	ca 04 00             	retf   0x4
    210d:	c8 04 00 00          	enter  0x4,0x0
    2111:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2114:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2117:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    211b:	06                   	push   es
    211c:	57                   	push   di
    211d:	9a d0 0d e7 21       	call   0x21e7:0xdd0
    2122:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2125:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2128:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    212b:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    212e:	c9                   	leave
    212f:	ca 06 00             	retf   0x6
    2132:	c8 02 00 00          	enter  0x2,0x0
    2136:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2139:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    213d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2141:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2144:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2147:	c9                   	leave
    2148:	ca 04 00             	retf   0x4
    214b:	55                   	push   bp
    214c:	89 e5                	mov    bp,sp
    214e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2151:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    2156:	74 09                	je     0x2161
    2158:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    215b:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    215f:	eb 15                	jmp    0x2176
    2161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2164:	81 c7 88 00          	add    di,0x88
    2168:	06                   	push   es
    2169:	57                   	push   di
    216a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    216d:	06                   	push   es
    216e:	57                   	push   di
    216f:	6a 1f                	push   0x1f
    2171:	9a e7 17 31 22       	call   0x2231:0x17e7
    2176:	c9                   	leave
    2177:	ca 04 00             	retf   0x4
    217a:	c8 44 00 00          	enter  0x44,0x0
    217e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2182:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2185:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    2189:	26 0b 45 2a          	or     ax,WORD PTR es:[di+0x2a]
    218d:	74 3c                	je     0x21cb
    218f:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    2193:	26 ff 75 28          	push   WORD PTR es:[di+0x28]
    2197:	6a 04                	push   0x4
    2199:	6a 02                	push   0x2
    219b:	8d 7e bc             	lea    di,[bp-0x44]
    219e:	16                   	push   ss
    219f:	57                   	push   di
    21a0:	6a 40                	push   0x40
    21a2:	8d 7e fc             	lea    di,[bp-0x4]
    21a5:	16                   	push   ss
    21a6:	57                   	push   di
    21a7:	9a ad 21 52 24       	call   0x2452:0x21ad
    21ac:	50                   	push   ax
    21ad:	9a 4e 12 da 21       	call   0x21da:0x124e
    21b2:	8d 7e bc             	lea    di,[bp-0x44]
    21b5:	16                   	push   ss
    21b6:	57                   	push   di
    21b7:	bf e2 0a             	mov    di,0xae2
    21ba:	1e                   	push   ds
    21bb:	57                   	push   di
    21bc:	9a db 0d cd 23       	call   0x23cd:0xddb
    21c1:	09 c0                	or     ax,ax
    21c3:	b0 00                	mov    al,0x0
    21c5:	74 01                	je     0x21c8
    21c7:	40                   	inc    ax
    21c8:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    21cb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    21ce:	c9                   	leave
    21cf:	ca 04 00             	retf   0x4
    21d2:	01 00                	add    WORD PTR [bx+si],ax
    21d4:	00 00                	add    BYTE PTR [bx+si],al
    21d6:	00 00                	add    BYTE PTR [bx+si],al
    21d8:	11 22                	adc    WORD PTR [bp+si],sp
    21da:	06                   	push   es
    21db:	22 55 89             	and    dl,BYTE PTR [di-0x77]
    21de:	e5 c4                	in     ax,0xc4
    21e0:	7e 06                	jle    0x21e8
    21e2:	06                   	push   es
    21e3:	57                   	push   di
    21e4:	9a f4 4f 90 22       	call   0x2290:0x4ff4
    21e9:	b8 d2 21             	mov    ax,0x21d2
    21ec:	0e                   	push   cs
    21ed:	50                   	push   ax
    21ee:	55                   	push   bp
    21ef:	ff 36 58 18          	push   WORD PTR ds:0x1858
    21f3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    21f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21fa:	26 80 7d 22 00       	cmp    BYTE PTR es:[di+0x22],0x0
    21ff:	74 07                	je     0x2208
    2201:	06                   	push   es
    2202:	57                   	push   di
    2203:	9a 23 23 de 22       	call   0x22de:0x2323
    2208:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    220c:	83 c4 06             	add    sp,0x6
    220f:	eb 27                	jmp    0x2238
    2211:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2214:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2219:	74 13                	je     0x222e
    221b:	ff 76 08             	push   WORD PTR [bp+0x8]
    221e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2221:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2225:	06                   	push   es
    2226:	57                   	push   di
    2227:	9a 51 75 7f 31       	call   0x317f:0x7551
    222c:	eb 05                	jmp    0x2233
    222e:	ea 85 13 36 22       	jmp    0x2236:0x1385
    2233:	9a 34 14 9c 22       	call   0x229c:0x1434
    2238:	c9                   	leave
    2239:	ca 04 00             	retf   0x4
    223c:	09 55 53             	or     WORD PTR [di+0x53],dx
    223f:	45                   	inc    bp
    2240:	52                   	push   dx
    2241:	20 4e 41             	and    BYTE PTR [bp+0x41],cl
    2244:	4d                   	dec    bp
    2245:	45                   	inc    bp
    2246:	08 50 41             	or     BYTE PTR [bx+si+0x41],dl
    2249:	53                   	push   bx
    224a:	53                   	push   bx
    224b:	57                   	push   di
    224c:	4f                   	dec    di
    224d:	52                   	push   dx
    224e:	44                   	inc    sp
    224f:	c8 40 01 00          	enter  0x140,0x0
    2253:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2256:	26 8b 85 aa 00       	mov    ax,WORD PTR es:[di+0xaa]
    225b:	09 c0                	or     ax,ax
    225d:	74 1e                	je     0x227d
    225f:	ff 76 08             	push   WORD PTR [bp+0x8]
    2262:	ff 76 06             	push   WORD PTR [bp+0x6]
    2265:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2268:	ff 76 0a             	push   WORD PTR [bp+0xa]
    226b:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    2270:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    2275:	26 ff 9d a8 00       	call   DWORD PTR es:[di+0xa8]
    227a:	e9 8b 00             	jmp    0x2308
    227d:	8d be c0 fe          	lea    di,[bp-0x140]
    2281:	16                   	push   ss
    2282:	57                   	push   di
    2283:	bf 3c 22             	mov    di,0x223c
    2286:	0e                   	push   cs
    2287:	57                   	push   di
    2288:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    228b:	06                   	push   es
    228c:	57                   	push   di
    228d:	9a 19 15 f2 22       	call   0x22f2:0x1519
    2292:	8d 7e e0             	lea    di,[bp-0x20]
    2295:	16                   	push   ss
    2296:	57                   	push   di
    2297:	6a 1f                	push   0x1f
    2299:	9a e7 17 f2 25       	call   0x25f2:0x17e7
    229e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a1:	81 c7 38 00          	add    di,0x38
    22a5:	06                   	push   es
    22a6:	57                   	push   di
    22a7:	8d 7e e0             	lea    di,[bp-0x20]
    22aa:	16                   	push   ss
    22ab:	57                   	push   di
    22ac:	6a 1f                	push   0x1f
    22ae:	8d 7e c0             	lea    di,[bp-0x40]
    22b1:	16                   	push   ss
    22b2:	57                   	push   di
    22b3:	6a 1f                	push   0x1f
    22b5:	9a 57 3a ff ff       	call   0xffff:0x3a57
    22ba:	08 c0                	or     al,al
    22bc:	75 22                	jne    0x22e0
    22be:	68 2e f2             	push   0xf22e
    22c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c4:	26 8d 45 38          	lea    ax,es:[di+0x38]
    22c8:	8c c2                	mov    dx,es
    22ca:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    22cd:	89 56 ba             	mov    WORD PTR [bp-0x46],dx
    22d0:	c6 46 bc 04          	mov    BYTE PTR [bp-0x44],0x4
    22d4:	8d 7e b8             	lea    di,[bp-0x48]
    22d7:	16                   	push   ss
    22d8:	57                   	push   di
    22d9:	6a 00                	push   0x0
    22db:	9a 0a 12 21 23       	call   0x2321:0x120a
    22e0:	bf 3c 22             	mov    di,0x223c
    22e3:	0e                   	push   cs
    22e4:	57                   	push   di
    22e5:	8d 7e e0             	lea    di,[bp-0x20]
    22e8:	16                   	push   ss
    22e9:	57                   	push   di
    22ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    22ed:	06                   	push   es
    22ee:	57                   	push   di
    22ef:	9a 1b 1b 06 23       	call   0x2306:0x1b1b
    22f4:	bf 46 22             	mov    di,0x2246
    22f7:	0e                   	push   cs
    22f8:	57                   	push   di
    22f9:	8d 7e c0             	lea    di,[bp-0x40]
    22fc:	16                   	push   ss
    22fd:	57                   	push   di
    22fe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2301:	06                   	push   es
    2302:	57                   	push   di
    2303:	9a 1b 1b 6c 23       	call   0x236c:0x1b1b
    2308:	c9                   	leave
    2309:	ca 08 00             	retf   0x8
    230c:	07                   	pop    es
    230d:	50                   	push   ax
    230e:	41                   	inc    cx
    230f:	54                   	push   sp
    2310:	48                   	dec    ax
    2311:	3d 25 73             	cmp    ax,0x7325
    2314:	08 50 41             	or     BYTE PTR [bx+si+0x41],dl
    2317:	53                   	push   bx
    2318:	53                   	push   bx
    2319:	57                   	push   di
    231a:	4f                   	dec    di
    231b:	52                   	push   dx
    231c:	44                   	inc    sp
    231d:	00 00                	add    BYTE PTR [bx+si],al
    231f:	ea 25 4b 23 c8       	jmp    0xc823:0x4b25
    2324:	14 02                	adc    al,0x2
    2326:	00 c4                	add    ah,al
    2328:	7e 06                	jle    0x2330
    232a:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    232e:	26 0b 45 2a          	or     ax,WORD PTR es:[di+0x2a]
    2332:	74 03                	je     0x2337
    2334:	e9 0e 03             	jmp    0x2645
    2337:	26 80 7d 38 00       	cmp    BYTE PTR es:[di+0x38],0x0
    233c:	75 0f                	jne    0x234d
    233e:	26 80 7d 21 00       	cmp    BYTE PTR es:[di+0x21],0x0
    2343:	75 08                	jne    0x234d
    2345:	68 01 f2             	push   0xf201
    2348:	9a ef 11 c5 24       	call   0x24c5:0x11ef
    234d:	31 c0                	xor    ax,ax
    234f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2352:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2355:	31 c0                	xor    ax,ax
    2357:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    235a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    235d:	31 c0                	xor    ax,ax
    235f:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2362:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2365:	b0 01                	mov    al,0x1
    2367:	50                   	push   ax
    2368:	b8 c9 03             	mov    ax,0x3c9
    236b:	ba 73 23             	mov    dx,0x2373
    236e:	52                   	push   dx
    236f:	50                   	push   ax
    2370:	9a 08 1d 34 25       	call   0x2534:0x1d08
    2375:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2378:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    237b:	b8 1d 23             	mov    ax,0x231d
    237e:	0e                   	push   cs
    237f:	50                   	push   ax
    2380:	55                   	push   bp
    2381:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2385:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2389:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    238c:	26 80 bd 88 00 00    	cmp    BYTE PTR es:[di+0x88],0x0
    2392:	75 4a                	jne    0x23de
    2394:	81 c7 38 00          	add    di,0x38
    2398:	06                   	push   es
    2399:	57                   	push   di
    239a:	e8 d6 ec             	call   0x1073
    239d:	08 c0                	or     al,al
    239f:	74 3d                	je     0x23de
    23a1:	8d be ec fd          	lea    di,[bp-0x214]
    23a5:	16                   	push   ss
    23a6:	57                   	push   di
    23a7:	bf 0c 23             	mov    di,0x230c
    23aa:	0e                   	push   cs
    23ab:	57                   	push   di
    23ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23af:	26 8d 45 38          	lea    ax,es:[di+0x38]
    23b3:	8c c2                	mov    dx,es
    23b5:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    23b9:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    23bd:	c6 86 f0 fe 04       	mov    BYTE PTR [bp-0x110],0x4
    23c2:	8d be ec fe          	lea    di,[bp-0x114]
    23c6:	16                   	push   ss
    23c7:	57                   	push   di
    23c8:	6a 00                	push   0x0
    23ca:	9a 34 10 21 24       	call   0x2421:0x1034
    23cf:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    23d2:	06                   	push   es
    23d3:	57                   	push   di
    23d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23d7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    23db:	e9 3e 01             	jmp    0x251c
    23de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e1:	26 80 bd 88 00 00    	cmp    BYTE PTR es:[di+0x88],0x0
    23e7:	74 16                	je     0x23ff
    23e9:	26 8d 85 88 00       	lea    ax,es:[di+0x88]
    23ee:	8c c2                	mov    dx,es
    23f0:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    23f3:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    23f6:	26 8a 45 24          	mov    al,BYTE PTR es:[di+0x24]
    23fa:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    23fd:	eb 13                	jmp    0x2412
    23ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2402:	26 8d 45 38          	lea    ax,es:[di+0x38]
    2406:	8c c2                	mov    dx,es
    2408:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    240b:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    240e:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2412:	8d 7e a6             	lea    di,[bp-0x5a]
    2415:	16                   	push   ss
    2416:	57                   	push   di
    2417:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    241a:	06                   	push   es
    241b:	57                   	push   di
    241c:	6a 1f                	push   0x1f
    241e:	9a 6a 0d 65 24       	call   0x2465:0xd6a
    2423:	8d 7e a6             	lea    di,[bp-0x5a]
    2426:	16                   	push   ss
    2427:	57                   	push   di
    2428:	8d 7e a6             	lea    di,[bp-0x5a]
    242b:	16                   	push   ss
    242c:	57                   	push   di
    242d:	9a 48 25 00 00       	call   0x0:0x2548
    2432:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2436:	74 3e                	je     0x2476
    2438:	8d 46 a6             	lea    ax,[bp-0x5a]
    243b:	8c d2                	mov    dx,ss
    243d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2440:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2443:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2446:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2449:	8d be f4 fe          	lea    di,[bp-0x10c]
    244d:	16                   	push   ss
    244e:	57                   	push   di
    244f:	9a bd 04 a6 25       	call   0x25a6:0x4bd
    2454:	09 c0                	or     ax,ax
    2456:	75 13                	jne    0x246b
    2458:	8d 7e 86             	lea    di,[bp-0x7a]
    245b:	16                   	push   ss
    245c:	57                   	push   di
    245d:	bf ec 0a             	mov    di,0xaec
    2460:	1e                   	push   ds
    2461:	57                   	push   di
    2462:	9a db 0d 8f 24       	call   0x248f:0xddb
    2467:	09 c0                	or     ax,ax
    2469:	75 04                	jne    0x246f
    246b:	b0 00                	mov    al,0x0
    246d:	eb 02                	jmp    0x2471
    246f:	b0 01                	mov    al,0x1
    2471:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    2474:	eb 25                	jmp    0x249b
    2476:	8d 46 a6             	lea    ax,[bp-0x5a]
    2479:	8c d2                	mov    dx,ss
    247b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    247e:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2481:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2484:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2487:	bf ec 0a             	mov    di,0xaec
    248a:	1e                   	push   ds
    248b:	57                   	push   di
    248c:	9a db 0d 3b 25       	call   0x253b:0xddb
    2491:	09 c0                	or     ax,ax
    2493:	b0 00                	mov    al,0x0
    2495:	74 01                	je     0x2498
    2497:	40                   	inc    ax
    2498:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    249b:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    249f:	74 64                	je     0x2505
    24a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a4:	26 80 7d 1f 00       	cmp    BYTE PTR es:[di+0x1f],0x0
    24a9:	74 5a                	je     0x2505
    24ab:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    24af:	74 18                	je     0x24c9
    24b1:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    24b4:	06                   	push   es
    24b5:	57                   	push   di
    24b6:	ff 76 f4             	push   WORD PTR [bp-0xc]
    24b9:	ff 76 f2             	push   WORD PTR [bp-0xe]
    24bc:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    24c0:	06                   	push   es
    24c1:	57                   	push   di
    24c2:	9a ad 18 dd 24       	call   0x24dd:0x18ad
    24c7:	eb 16                	jmp    0x24df
    24c9:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    24cc:	06                   	push   es
    24cd:	57                   	push   di
    24ce:	ff 76 f4             	push   WORD PTR [bp-0xc]
    24d1:	ff 76 f2             	push   WORD PTR [bp-0xe]
    24d4:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    24d8:	06                   	push   es
    24d9:	57                   	push   di
    24da:	9a c5 1a 01 25       	call   0x2501:0x1ac5
    24df:	ff 76 f4             	push   WORD PTR [bp-0xc]
    24e2:	ff 76 f2             	push   WORD PTR [bp-0xe]
    24e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e8:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    24ec:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    24f0:	e8 c5 eb             	call   0x10b8
    24f3:	ff 76 f4             	push   WORD PTR [bp-0xc]
    24f6:	ff 76 f2             	push   WORD PTR [bp-0xe]
    24f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24fc:	06                   	push   es
    24fd:	57                   	push   di
    24fe:	9a 4f 22 59 25       	call   0x2559:0x224f
    2503:	eb 17                	jmp    0x251c
    2505:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2508:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    250c:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2510:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2513:	06                   	push   es
    2514:	57                   	push   di
    2515:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2518:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    251c:	8d 7e c6             	lea    di,[bp-0x3a]
    251f:	16                   	push   ss
    2520:	57                   	push   di
    2521:	8d be f4 fd          	lea    di,[bp-0x20c]
    2525:	16                   	push   ss
    2526:	57                   	push   di
    2527:	bf 14 23             	mov    di,0x2314
    252a:	0e                   	push   cs
    252b:	57                   	push   di
    252c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    252f:	06                   	push   es
    2530:	57                   	push   di
    2531:	9a 19 15 34 28       	call   0x2834:0x1519
    2536:	6a 1f                	push   0x1f
    2538:	9a 6a 0d 57 28       	call   0x2857:0xd6a
    253d:	8d 7e c6             	lea    di,[bp-0x3a]
    2540:	16                   	push   ss
    2541:	57                   	push   di
    2542:	8d 7e c6             	lea    di,[bp-0x3a]
    2545:	16                   	push   ss
    2546:	57                   	push   di
    2547:	9a ff ff 00 00       	call   0x0:0xffff
    254c:	ff 76 f4             	push   WORD PTR [bp-0xc]
    254f:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2552:	b0 01                	mov    al,0x1
    2554:	50                   	push   ax
    2555:	b8 28 01             	mov    ax,0x128
    2558:	ba 60 25             	mov    dx,0x2560
    255b:	52                   	push   dx
    255c:	50                   	push   ax
    255d:	9a 9e 1c ac 25       	call   0x25ac:0x1c9e
    2562:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2565:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    2568:	ff 76 fc             	push   WORD PTR [bp-0x4]
    256b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    256e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2571:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2574:	6a 00                	push   0x0
    2576:	6a 00                	push   0x0
    2578:	8d 7e c6             	lea    di,[bp-0x3a]
    257b:	16                   	push   ss
    257c:	57                   	push   di
    257d:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2580:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2584:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2587:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    258b:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    258f:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2592:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    2596:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    259a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259d:	81 c7 28 00          	add    di,0x28
    25a1:	06                   	push   es
    25a2:	57                   	push   di
    25a3:	9a 4d 00 c4 25       	call   0x25c4:0x4d
    25a8:	50                   	push   ax
    25a9:	9a 4e 12 54 26       	call   0x2654:0x124e
    25ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b1:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    25b5:	26 ff 75 28          	push   WORD PTR es:[di+0x28]
    25b9:	6a 04                	push   0x4
    25bb:	6a 05                	push   0x5
    25bd:	6a 00                	push   0x0
    25bf:	6a 01                	push   0x1
    25c1:	9a bd 21 dc 25       	call   0x25dc:0x21bd
    25c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c9:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    25cd:	26 ff 75 28          	push   WORD PTR es:[di+0x28]
    25d1:	6a 04                	push   0x4
    25d3:	6a 04                	push   0x4
    25d5:	6a 00                	push   0x0
    25d7:	6a 01                	push   0x1
    25d9:	9a bd 21 16 26       	call   0x2616:0x21bd
    25de:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    25e2:	83 c4 06             	add    sp,0x6
    25e5:	b8 ff 25             	mov    ax,0x25ff
    25e8:	0e                   	push   cs
    25e9:	50                   	push   ax
    25ea:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    25ed:	06                   	push   es
    25ee:	57                   	push   di
    25ef:	9a 7f 1f fc 25       	call   0x25fc:0x1f7f
    25f4:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    25f7:	06                   	push   es
    25f8:	57                   	push   di
    25f9:	9a 7f 1f c6 26       	call   0x26c6:0x1f7f
    25fe:	cb                   	retf
    25ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2602:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    2606:	26 ff 75 28          	push   WORD PTR es:[di+0x28]
    260a:	6a 00                	push   0x0
    260c:	6a 00                	push   0x0
    260e:	8d 7e a6             	lea    di,[bp-0x5a]
    2611:	16                   	push   ss
    2612:	57                   	push   di
    2613:	9a 0d 17 29 26       	call   0x2629:0x170d
    2618:	09 c0                	or     ax,ax
    261a:	75 29                	jne    0x2645
    261c:	8d 7e a6             	lea    di,[bp-0x5a]
    261f:	16                   	push   ss
    2620:	57                   	push   di
    2621:	8d 7e ea             	lea    di,[bp-0x16]
    2624:	16                   	push   ss
    2625:	57                   	push   di
    2626:	9a ad 13 4b 33       	call   0x334b:0x13ad
    262b:	09 c0                	or     ax,ax
    262d:	75 16                	jne    0x2645
    262f:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    2632:	8b 56 ec             	mov    dx,WORD PTR [bp-0x14]
    2635:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2638:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    263c:	26 89 55 32          	mov    WORD PTR es:[di+0x32],dx
    2640:	26 c6 45 23 01       	mov    BYTE PTR es:[di+0x23],0x1
    2645:	c9                   	leave
    2646:	ca 04 00             	retf   0x4
    2649:	55                   	push   bp
    264a:	89 e5                	mov    bp,sp
    264c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    264f:	06                   	push   es
    2650:	57                   	push   di
    2651:	9a 07 20 6c 26       	call   0x266c:0x2007
    2656:	c9                   	leave
    2657:	ca 08 00             	retf   0x8
    265a:	55                   	push   bp
    265b:	89 e5                	mov    bp,sp
    265d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2660:	06                   	push   es
    2661:	57                   	push   di
    2662:	6a 01                	push   0x1
    2664:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2667:	06                   	push   es
    2668:	57                   	push   di
    2669:	9a f2 26 96 26       	call   0x2696:0x26f2
    266e:	c9                   	leave
    266f:	ca 08 00             	retf   0x8
    2672:	55                   	push   bp
    2673:	89 e5                	mov    bp,sp
    2675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2678:	26 f6 45 18 02       	test   BYTE PTR es:[di+0x18],0x2
    267d:	74 09                	je     0x2688
    267f:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2682:	26 88 45 22          	mov    BYTE PTR es:[di+0x22],al
    2686:	eb 1c                	jmp    0x26a4
    2688:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    268c:	74 0c                	je     0x269a
    268e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2691:	06                   	push   es
    2692:	57                   	push   di
    2693:	9a 23 23 a2 26       	call   0x26a2:0x2323
    2698:	eb 0a                	jmp    0x26a4
    269a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    269d:	06                   	push   es
    269e:	57                   	push   di
    269f:	9a 23 20 b3 26       	call   0x26b3:0x2023
    26a4:	c9                   	leave
    26a5:	ca 06 00             	retf   0x6
    26a8:	55                   	push   bp
    26a9:	89 e5                	mov    bp,sp
    26ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ae:	06                   	push   es
    26af:	57                   	push   di
    26b0:	9a 07 20 d7 26       	call   0x26d7:0x2007
    26b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b8:	81 c7 38 00          	add    di,0x38
    26bc:	06                   	push   es
    26bd:	57                   	push   di
    26be:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    26c1:	06                   	push   es
    26c2:	57                   	push   di
    26c3:	9a be 18 ec 26       	call   0x26ec:0x18be
    26c8:	74 24                	je     0x26ee
    26ca:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    26cd:	06                   	push   es
    26ce:	57                   	push   di
    26cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d2:	06                   	push   es
    26d3:	57                   	push   di
    26d4:	9a 85 27 fd 26       	call   0x26fd:0x2785
    26d9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    26dc:	06                   	push   es
    26dd:	57                   	push   di
    26de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e1:	81 c7 38 00          	add    di,0x38
    26e5:	06                   	push   es
    26e6:	57                   	push   di
    26e7:	6a 4f                	push   0x4f
    26e9:	9a e7 17 12 27       	call   0x2712:0x17e7
    26ee:	c9                   	leave
    26ef:	ca 08 00             	retf   0x8
    26f2:	55                   	push   bp
    26f3:	89 e5                	mov    bp,sp
    26f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f8:	06                   	push   es
    26f9:	57                   	push   di
    26fa:	9a 07 20 34 27       	call   0x2734:0x2007
    26ff:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2702:	06                   	push   es
    2703:	57                   	push   di
    2704:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2707:	81 c7 88 00          	add    di,0x88
    270b:	06                   	push   es
    270c:	57                   	push   di
    270d:	6a 1f                	push   0x1f
    270f:	9a e7 17 f9 27       	call   0x27f9:0x17e7
    2714:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2717:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    271a:	26 88 45 24          	mov    BYTE PTR es:[di+0x24],al
    271e:	c9                   	leave
    271f:	ca 0a 00             	retf   0xa
    2722:	55                   	push   bp
    2723:	89 e5                	mov    bp,sp
    2725:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2728:	06                   	push   es
    2729:	57                   	push   di
    272a:	6a 00                	push   0x0
    272c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    272f:	06                   	push   es
    2730:	57                   	push   di
    2731:	9a f2 26 62 27       	call   0x2762:0x26f2
    2736:	c9                   	leave
    2737:	ca 08 00             	retf   0x8
    273a:	55                   	push   bp
    273b:	89 e5                	mov    bp,sp
    273d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2740:	26 8a 45 20          	mov    al,BYTE PTR es:[di+0x20]
    2744:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2747:	74 1b                	je     0x2764
    2749:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    274c:	26 88 45 20          	mov    BYTE PTR es:[di+0x20],al
    2750:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2754:	75 0e                	jne    0x2764
    2756:	26 83 7d 26 00       	cmp    WORD PTR es:[di+0x26],0x0
    275b:	75 07                	jne    0x2764
    275d:	06                   	push   es
    275e:	57                   	push   di
    275f:	9a 23 20 9d 27       	call   0x279d:0x2023
    2764:	c9                   	leave
    2765:	ca 06 00             	retf   0x6
    2768:	55                   	push   bp
    2769:	89 e5                	mov    bp,sp
    276b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    276e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2771:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2774:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    2778:	06                   	push   es
    2779:	57                   	push   di
    277a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    277d:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2781:	c9                   	leave
    2782:	ca 08 00             	retf   0x8
    2785:	c8 0c 00 00          	enter  0xc,0x0
    2789:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    278c:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2790:	74 69                	je     0x27fb
    2792:	06                   	push   es
    2793:	57                   	push   di
    2794:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    2798:	06                   	push   es
    2799:	57                   	push   di
    279a:	9a 1f 18 ef 27       	call   0x27ef:0x181f
    279f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    27a2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    27a5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    27a8:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    27ab:	74 4e                	je     0x27fb
    27ad:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    27b0:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    27b3:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    27b6:	75 05                	jne    0x27bd
    27b8:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    27bb:	74 3e                	je     0x27fb
    27bd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27c0:	26 80 7d 21 00       	cmp    BYTE PTR es:[di+0x21],0x0
    27c5:	74 0a                	je     0x27d1
    27c7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27ca:	26 83 7d 26 00       	cmp    WORD PTR es:[di+0x26],0x0
    27cf:	74 20                	je     0x27f1
    27d1:	68 00 f2             	push   0xf200
    27d4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    27d7:	89 f8                	mov    ax,di
    27d9:	8c c2                	mov    dx,es
    27db:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    27de:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    27e1:	c6 46 f8 04          	mov    BYTE PTR [bp-0x8],0x4
    27e5:	8d 7e f4             	lea    di,[bp-0xc]
    27e8:	16                   	push   ss
    27e9:	57                   	push   di
    27ea:	6a 00                	push   0x0
    27ec:	9a 0a 12 ef 28       	call   0x28ef:0x120a
    27f1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    27f4:	06                   	push   es
    27f5:	57                   	push   di
    27f6:	9a 7f 1f 0e 28       	call   0x280e:0x1f7f
    27fb:	c9                   	leave
    27fc:	ca 08 00             	retf   0x8
    27ff:	55                   	push   bp
    2800:	89 e5                	mov    bp,sp
    2802:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2806:	74 08                	je     0x2810
    2808:	83 ec 08             	sub    sp,0x8
    280b:	9a e2 1f e1 28       	call   0x28e1:0x1fe2
    2810:	8a 46 12             	mov    al,BYTE PTR [bp+0x12]
    2813:	50                   	push   ax
    2814:	ff 76 10             	push   WORD PTR [bp+0x10]
    2817:	e8 4d e9             	call   0x1167
    281a:	8b 46 18             	mov    ax,WORD PTR [bp+0x18]
    281d:	0b 46 1a             	or     ax,WORD PTR [bp+0x1a]
    2820:	74 2d                	je     0x284f
    2822:	ff 76 08             	push   WORD PTR [bp+0x8]
    2825:	ff 76 06             	push   WORD PTR [bp+0x6]
    2828:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
    282b:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    282f:	06                   	push   es
    2830:	57                   	push   di
    2831:	9a 2b 0c ca 28       	call   0x28ca:0xc2b
    2836:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
    2839:	26 c6 45 0c 00       	mov    BYTE PTR es:[di+0xc],0x0
    283e:	8b 46 18             	mov    ax,WORD PTR [bp+0x18]
    2841:	8b 56 1a             	mov    dx,WORD PTR [bp+0x1a]
    2844:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2847:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    284b:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    284f:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2852:	06                   	push   es
    2853:	57                   	push   di
    2854:	9a d7 05 a8 28       	call   0x28a8:0x5d7
    2859:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    285c:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2860:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    2864:	8a 46 12             	mov    al,BYTE PTR [bp+0x12]
    2867:	26 88 45 0c          	mov    BYTE PTR es:[di+0xc],al
    286b:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    286e:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    2872:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    2875:	26 88 45 0d          	mov    BYTE PTR es:[di+0xd],al
    2879:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    287c:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2880:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2884:	74 07                	je     0x288d
    2886:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    288a:	83 c4 06             	add    sp,0x6
    288d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2890:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2893:	c9                   	leave
    2894:	ca 16 00             	retf   0x16
    2897:	55                   	push   bp
    2898:	89 e5                	mov    bp,sp
    289a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289d:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    28a1:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    28a5:	9a 24 06 e1 2b       	call   0x2be1:0x624
    28aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ad:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    28b1:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    28b5:	74 21                	je     0x28d8
    28b7:	ff 76 08             	push   WORD PTR [bp+0x8]
    28ba:	ff 76 06             	push   WORD PTR [bp+0x6]
    28bd:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    28c1:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    28c5:	06                   	push   es
    28c6:	57                   	push   di
    28c7:	9a a7 0f 42 2a       	call   0x2a42:0xfa7
    28cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28cf:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    28d3:	26 c6 45 0c 00       	mov    BYTE PTR es:[di+0xc],0x0
    28d8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    28dc:	74 05                	je     0x28e3
    28de:	9a 0f 20 bd 29       	call   0x29bd:0x200f
    28e3:	c9                   	leave
    28e4:	ca 06 00             	retf   0x6
    28e7:	01 00                	add    WORD PTR [bx+si],ax
    28e9:	00 00                	add    BYTE PTR [bx+si],al
    28eb:	00 00                	add    BYTE PTR [bx+si],al
    28ed:	b5 29                	mov    ch,0x29
    28ef:	fd                   	std
    28f0:	28 c8                	sub    al,cl
    28f2:	10 00                	adc    BYTE PTR [bx+si],al
    28f4:	00 c4                	add    ah,al
    28f6:	7e 06                	jle    0x28fe
    28f8:	06                   	push   es
    28f9:	57                   	push   di
    28fa:	9a d3 29 2f 29       	call   0x292f:0x29d3
    28ff:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2902:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2905:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2908:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    290b:	75 24                	jne    0x2931
    290d:	68 07 f2             	push   0xf207
    2910:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2913:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2917:	89 f8                	mov    ax,di
    2919:	8c c2                	mov    dx,es
    291b:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    291e:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    2921:	c6 46 f4 04          	mov    BYTE PTR [bp-0xc],0x4
    2925:	8d 7e f0             	lea    di,[bp-0x10]
    2928:	16                   	push   ss
    2929:	57                   	push   di
    292a:	6a 00                	push   0x0
    292c:	9a 0a 12 68 29       	call   0x2968:0x120a
    2931:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2934:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2937:	b0 01                	mov    al,0x1
    2939:	50                   	push   ax
    293a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    293d:	06                   	push   es
    293e:	57                   	push   di
    293f:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    2943:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2946:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2949:	b8 e7 28             	mov    ax,0x28e7
    294c:	0e                   	push   cs
    294d:	50                   	push   ax
    294e:	55                   	push   bp
    294f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2953:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2957:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    295a:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    295e:	06                   	push   es
    295f:	57                   	push   di
    2960:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2963:	06                   	push   es
    2964:	57                   	push   di
    2965:	9a 96 6f 79 29       	call   0x2979:0x6f96
    296a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    296d:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    2971:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2974:	06                   	push   es
    2975:	57                   	push   di
    2976:	9a c6 70 aa 29       	call   0x29aa:0x70c6
    297b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    297e:	26 8a 45 0d          	mov    al,BYTE PTR es:[di+0xd]
    2982:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2985:	26 88 45 27          	mov    BYTE PTR es:[di+0x27],al
    2989:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    298c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2990:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    2994:	74 16                	je     0x29ac
    2996:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    299a:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    299e:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    29a2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    29a5:	06                   	push   es
    29a6:	57                   	push   di
    29a7:	9a 0b 6e 82 2a       	call   0x2a82:0x6e0b
    29ac:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    29b0:	83 c4 06             	add    sp,0x6
    29b3:	eb 14                	jmp    0x29c9
    29b5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    29b8:	06                   	push   es
    29b9:	57                   	push   di
    29ba:	9a 7f 1f c2 29       	call   0x29c2:0x1f7f
    29bf:	ea 85 13 c7 29       	jmp    0x29c7:0x1385
    29c4:	9a 34 14 13 2a       	call   0x2a13:0x1434
    29c9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    29cc:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    29cf:	c9                   	leave
    29d0:	ca 08 00             	retf   0x8
    29d3:	c8 04 00 00          	enter  0x4,0x0
    29d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29da:	26 8a 45 0c          	mov    al,BYTE PTR es:[di+0xc]
    29de:	98                   	cbw
    29df:	8b f8                	mov    di,ax
    29e1:	c1 e7 02             	shl    di,0x2
    29e4:	8b 85 f6 0a          	mov    ax,WORD PTR [di+0xaf6]
    29e8:	8b 95 f8 0a          	mov    dx,WORD PTR [di+0xaf8]
    29ec:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    29ef:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    29f2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    29f5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    29f8:	c9                   	leave
    29f9:	ca 04 00             	retf   0x4
    29fc:	55                   	push   bp
    29fd:	89 e5                	mov    bp,sp
    29ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a02:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2a06:	06                   	push   es
    2a07:	57                   	push   di
    2a08:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a0b:	06                   	push   es
    2a0c:	57                   	push   di
    2a0d:	68 ff 00             	push   0xff
    2a10:	9a e7 17 28 2a       	call   0x2a28:0x17e7
    2a15:	c9                   	leave
    2a16:	ca 04 00             	retf   0x4
    2a19:	55                   	push   bp
    2a1a:	89 e5                	mov    bp,sp
    2a1c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2a20:	74 08                	je     0x2a2a
    2a22:	83 ec 08             	sub    sp,0x8
    2a25:	9a e2 1f 49 2a       	call   0x2a49:0x1fe2
    2a2a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2a2d:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    2a30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a33:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2a37:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    2a3b:	b0 01                	mov    al,0x1
    2a3d:	50                   	push   ax
    2a3e:	b8 a3 02             	mov    ax,0x2a3
    2a41:	ba c1 2c             	mov    dx,0x2cc1
    2a44:	52                   	push   dx
    2a45:	50                   	push   ax
    2a46:	9a 50 1f 90 2a       	call   0x2a90:0x1f50
    2a4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4e:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2a52:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    2a56:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2a5a:	74 07                	je     0x2a63
    2a5c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2a60:	83 c4 06             	add    sp,0x6
    2a63:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2a66:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2a69:	c9                   	leave
    2a6a:	ca 0a 00             	retf   0xa
    2a6d:	55                   	push   bp
    2a6e:	89 e5                	mov    bp,sp
    2a70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a73:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2a77:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    2a7b:	74 07                	je     0x2a84
    2a7d:	06                   	push   es
    2a7e:	57                   	push   di
    2a7f:	9a a4 2c b4 2a       	call   0x2ab4:0x2ca4
    2a84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a87:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2a8b:	06                   	push   es
    2a8c:	57                   	push   di
    2a8d:	9a 7f 1f 9b 2a       	call   0x2a9b:0x1f7f
    2a92:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2a96:	74 05                	je     0x2a9d
    2a98:	9a 0f 20 90 2b       	call   0x2b90:0x200f
    2a9d:	c9                   	leave
    2a9e:	ca 06 00             	retf   0x6
    2aa1:	c8 08 00 00          	enter  0x8,0x0
    2aa5:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2aa8:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2aac:	75 08                	jne    0x2ab6
    2aae:	68 24 f2             	push   0xf224
    2ab1:	9a ef 11 c3 2a       	call   0x2ac3:0x11ef
    2ab6:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2ab9:	06                   	push   es
    2aba:	57                   	push   di
    2abb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2abe:	06                   	push   es
    2abf:	57                   	push   di
    2ac0:	9a 6f 2d e7 2a       	call   0x2ae7:0x2d6f
    2ac5:	09 c0                	or     ax,ax
    2ac7:	7c 20                	jl     0x2ae9
    2ac9:	68 22 f2             	push   0xf222
    2acc:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2acf:	89 f8                	mov    ax,di
    2ad1:	8c c2                	mov    dx,es
    2ad3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2ad6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2ad9:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    2add:	8d 7e f8             	lea    di,[bp-0x8]
    2ae0:	16                   	push   ss
    2ae1:	57                   	push   di
    2ae2:	6a 00                	push   0x0
    2ae4:	9a 0a 12 13 2b       	call   0x2b13:0x120a
    2ae9:	ff 76 08             	push   WORD PTR [bp+0x8]
    2aec:	ff 76 06             	push   WORD PTR [bp+0x6]
    2aef:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2af2:	06                   	push   es
    2af3:	57                   	push   di
    2af4:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    2af7:	50                   	push   ax
    2af8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2afb:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2afe:	50                   	push   ax
    2aff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b02:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2b06:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2b0a:	40                   	inc    ax
    2b0b:	50                   	push   ax
    2b0c:	b0 01                	mov    al,0x1
    2b0e:	50                   	push   ax
    2b0f:	b8 88 03             	mov    ax,0x388
    2b12:	ba 1a 2b             	mov    dx,0x2b1a
    2b15:	52                   	push   dx
    2b16:	50                   	push   ax
    2b17:	9a ff 27 7a 2b       	call   0x2b7a:0x27ff
    2b1c:	c9                   	leave
    2b1d:	ca 0e 00             	retf   0xe
    2b20:	05 25 73             	add    ax,0x7325
    2b23:	5f                   	pop    di
    2b24:	25 64 20             	and    ax,0x2064
    2b27:	2c 71                	sub    al,0x71
    2b29:	2c 54                	sub    al,0x54
    2b2b:	2c 71                	sub    al,0x71
    2b2d:	2c 28                	sub    al,0x28
    2b2f:	2c 71                	sub    al,0x71
    2b31:	2c 34                	sub    al,0x34
    2b33:	2c 40                	sub    al,0x40
    2b35:	2c 20                	sub    al,0x20
    2b37:	2c 71                	sub    al,0x71
    2b39:	2c 71                	sub    al,0x71
    2b3b:	2c 28                	sub    al,0x28
    2b3d:	2c 71                	sub    al,0x71
    2b3f:	2c 71                	sub    al,0x71
    2b41:	2c 20                	sub    al,0x20
    2b43:	2c c8                	sub    al,0xc8
    2b45:	8e 01                	mov    es,WORD PTR [bx+di]
    2b47:	00 8c d3 8e          	add    BYTE PTR [si-0x712d],cl
    2b4b:	c3                   	ret
    2b4c:	8c db                	mov    bx,ds
    2b4e:	fc                   	cld
    2b4f:	8d 7e cc             	lea    di,[bp-0x34]
    2b52:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    2b55:	b9 34 00             	mov    cx,0x34
    2b58:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2b5a:	8e db                	mov    ds,bx
    2b5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b5f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2b63:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    2b67:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    2b6b:	8d 7e ce             	lea    di,[bp-0x32]
    2b6e:	16                   	push   ss
    2b6f:	57                   	push   di
    2b70:	8d 7e a6             	lea    di,[bp-0x5a]
    2b73:	16                   	push   ss
    2b74:	57                   	push   di
    2b75:	6a 1f                	push   0x1f
    2b77:	9a 13 0f 9f 2b       	call   0x2b9f:0xf13
    2b7c:	31 c0                	xor    ax,ax
    2b7e:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    2b81:	8d 7e a6             	lea    di,[bp-0x5a]
    2b84:	16                   	push   ss
    2b85:	57                   	push   di
    2b86:	8d 7e 82             	lea    di,[bp-0x7e]
    2b89:	16                   	push   ss
    2b8a:	57                   	push   di
    2b8b:	6a 23                	push   0x23
    2b8d:	9a e7 17 ed 2b       	call   0x2bed:0x17e7
    2b92:	8d 7e 82             	lea    di,[bp-0x7e]
    2b95:	16                   	push   ss
    2b96:	57                   	push   di
    2b97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b9a:	06                   	push   es
    2b9b:	57                   	push   di
    2b9c:	9a 6f 2d 97 2c       	call   0x2c97:0x2d6f
    2ba1:	09 c0                	or     ax,ax
    2ba3:	7c 4c                	jl     0x2bf1
    2ba5:	ff 46 c6             	inc    WORD PTR [bp-0x3a]
    2ba8:	8d be 72 fe          	lea    di,[bp-0x18e]
    2bac:	16                   	push   ss
    2bad:	57                   	push   di
    2bae:	bf 20 2b             	mov    di,0x2b20
    2bb1:	0e                   	push   cs
    2bb2:	57                   	push   di
    2bb3:	8d 46 a6             	lea    ax,[bp-0x5a]
    2bb6:	8c d2                	mov    dx,ss
    2bb8:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    2bbc:	89 96 74 ff          	mov    WORD PTR [bp-0x8c],dx
    2bc0:	c6 86 76 ff 04       	mov    BYTE PTR [bp-0x8a],0x4
    2bc5:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    2bc8:	99                   	cwd
    2bc9:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    2bcd:	89 96 7c ff          	mov    WORD PTR [bp-0x84],dx
    2bd1:	c6 86 7e ff 00       	mov    BYTE PTR [bp-0x82],0x0
    2bd6:	8d be 72 ff          	lea    di,[bp-0x8e]
    2bda:	16                   	push   ss
    2bdb:	57                   	push   di
    2bdc:	6a 01                	push   0x1
    2bde:	9a 34 10 b4 2d       	call   0x2db4:0x1034
    2be3:	8d 7e 82             	lea    di,[bp-0x7e]
    2be6:	16                   	push   ss
    2be7:	57                   	push   di
    2be8:	6a 23                	push   0x23
    2bea:	9a e7 17 cc 2c       	call   0x2ccc:0x17e7
    2bef:	eb a1                	jmp    0x2b92
    2bf1:	83 7e ee 11          	cmp    WORD PTR [bp-0x12],0x11
    2bf5:	73 0c                	jae    0x2c03
    2bf7:	8b 7e ee             	mov    di,WORD PTR [bp-0x12]
    2bfa:	8a 85 3a 0b          	mov    al,BYTE PTR [di+0xb3a]
    2bfe:	88 46 cb             	mov    BYTE PTR [bp-0x35],al
    2c01:	eb 04                	jmp    0x2c07
    2c03:	c6 46 cb 00          	mov    BYTE PTR [bp-0x35],0x0
    2c07:	31 c0                	xor    ax,ax
    2c09:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2c0c:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2c0f:	2d 01 00             	sub    ax,0x1
    2c12:	3d 0e 00             	cmp    ax,0xe
    2c15:	77 5a                	ja     0x2c71
    2c17:	89 c3                	mov    bx,ax
    2c19:	d1 e3                	shl    bx,1
    2c1b:	2e ff a7 26 2b       	jmp    WORD PTR cs:[bx+0x2b26]
    2c20:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2c23:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2c26:	eb 49                	jmp    0x2c71
    2c28:	83 7e f8 02          	cmp    WORD PTR [bp-0x8],0x2
    2c2c:	74 04                	je     0x2c32
    2c2e:	c6 46 cb 00          	mov    BYTE PTR [bp-0x35],0x0
    2c32:	eb 3d                	jmp    0x2c71
    2c34:	83 7e f0 15          	cmp    WORD PTR [bp-0x10],0x15
    2c38:	75 04                	jne    0x2c3e
    2c3a:	c6 46 cb 07          	mov    BYTE PTR [bp-0x35],0x7
    2c3e:	eb 31                	jmp    0x2c71
    2c40:	83 7e f2 20          	cmp    WORD PTR [bp-0xe],0x20
    2c44:	75 08                	jne    0x2c4e
    2c46:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2c49:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2c4c:	eb 04                	jmp    0x2c52
    2c4e:	c6 46 cb 00          	mov    BYTE PTR [bp-0x35],0x0
    2c52:	eb 1d                	jmp    0x2c71
    2c54:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2c57:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2c5a:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2c5d:	3d 16 00             	cmp    ax,0x16
    2c60:	75 06                	jne    0x2c68
    2c62:	c6 46 cb 0f          	mov    BYTE PTR [bp-0x35],0xf
    2c66:	eb 09                	jmp    0x2c71
    2c68:	3d 1a 00             	cmp    ax,0x1a
    2c6b:	75 04                	jne    0x2c71
    2c6d:	c6 46 cb 10          	mov    BYTE PTR [bp-0x35],0x10
    2c71:	80 7e cb 00          	cmp    BYTE PTR [bp-0x35],0x0
    2c75:	74 29                	je     0x2ca0
    2c77:	ff 76 08             	push   WORD PTR [bp+0x8]
    2c7a:	ff 76 06             	push   WORD PTR [bp+0x6]
    2c7d:	8d 7e 82             	lea    di,[bp-0x7e]
    2c80:	16                   	push   ss
    2c81:	57                   	push   di
    2c82:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    2c85:	50                   	push   ax
    2c86:	ff 76 c8             	push   WORD PTR [bp-0x38]
    2c89:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    2c8c:	50                   	push   ax
    2c8d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c90:	b0 01                	mov    al,0x1
    2c92:	50                   	push   ax
    2c93:	b8 88 03             	mov    ax,0x388
    2c96:	ba 9e 2c             	mov    dx,0x2c9e
    2c99:	52                   	push   dx
    2c9a:	50                   	push   ax
    2c9b:	9a ff 27 e5 2c       	call   0x2ce5:0x27ff
    2ca0:	c9                   	leave
    2ca1:	ca 0c 00             	retf   0xc
    2ca4:	55                   	push   bp
    2ca5:	89 e5                	mov    bp,sp
    2ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2caa:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2cae:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    2cb3:	7e 1b                	jle    0x2cd0
    2cb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb8:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2cbc:	06                   	push   es
    2cbd:	57                   	push   di
    2cbe:	9a 43 0f 1f 2d       	call   0x2d1f:0xf43
    2cc3:	89 c7                	mov    di,ax
    2cc5:	8e c2                	mov    es,dx
    2cc7:	06                   	push   es
    2cc8:	57                   	push   di
    2cc9:	9a 7f 1f f4 2d       	call   0x2df4:0x1f7f
    2cce:	eb d7                	jmp    0x2ca7
    2cd0:	c9                   	leave
    2cd1:	ca 04 00             	retf   0x4
    2cd4:	c8 0e 00 00          	enter  0xe,0x0
    2cd8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2cdb:	06                   	push   es
    2cdc:	57                   	push   di
    2cdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ce0:	06                   	push   es
    2ce1:	57                   	push   di
    2ce2:	9a 6f 2d 0e 2d       	call   0x2d0e:0x2d6f
    2ce7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2cea:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    2cee:	7d 20                	jge    0x2d10
    2cf0:	68 08 f2             	push   0xf208
    2cf3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2cf6:	89 f8                	mov    ax,di
    2cf8:	8c c2                	mov    dx,es
    2cfa:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2cfd:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2d00:	c6 46 f6 04          	mov    BYTE PTR [bp-0xa],0x4
    2d04:	8d 7e f2             	lea    di,[bp-0xe]
    2d07:	16                   	push   ss
    2d08:	57                   	push   di
    2d09:	6a 00                	push   0x0
    2d0b:	9a 0a 12 df 2d       	call   0x2ddf:0x120a
    2d10:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d16:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2d1a:	06                   	push   es
    2d1b:	57                   	push   di
    2d1c:	9a d0 0d 5d 2d       	call   0x2d5d:0xdd0
    2d21:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d24:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2d27:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d2a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2d2d:	c9                   	leave
    2d2e:	ca 08 00             	retf   0x8
    2d31:	c8 02 00 00          	enter  0x2,0x0
    2d35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d38:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2d3c:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2d40:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d43:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d46:	c9                   	leave
    2d47:	ca 04 00             	retf   0x4
    2d4a:	c8 04 00 00          	enter  0x4,0x0
    2d4e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2d51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d54:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2d58:	06                   	push   es
    2d59:	57                   	push   di
    2d5a:	9a d0 0d a0 2d       	call   0x2da0:0xdd0
    2d5f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d62:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2d65:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d68:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2d6b:	c9                   	leave
    2d6c:	ca 06 00             	retf   0x6
    2d6f:	c8 04 00 00          	enter  0x4,0x0
    2d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d76:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2d7a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2d7e:	48                   	dec    ax
    2d7f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d82:	31 c0                	xor    ax,ax
    2d84:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2d87:	7f 3b                	jg     0x2dc4
    2d89:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d8c:	eb 03                	jmp    0x2d91
    2d8e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2d91:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d97:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2d9b:	06                   	push   es
    2d9c:	57                   	push   di
    2d9d:	9a d0 0d 07 2e       	call   0x2e07:0xdd0
    2da2:	89 c7                	mov    di,ax
    2da4:	8e c2                	mov    es,dx
    2da6:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2daa:	06                   	push   es
    2dab:	57                   	push   di
    2dac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2daf:	06                   	push   es
    2db0:	57                   	push   di
    2db1:	9a ed 07 4a 30       	call   0x304a:0x7ed
    2db6:	09 c0                	or     ax,ax
    2db8:	75 02                	jne    0x2dbc
    2dba:	eb 0d                	jmp    0x2dc9
    2dbc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dbf:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2dc2:	75 ca                	jne    0x2d8e
    2dc4:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    2dc9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dcc:	c9                   	leave
    2dcd:	ca 08 00             	retf   0x8
    2dd0:	55                   	push   bp
    2dd1:	89 e5                	mov    bp,sp
    2dd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd6:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2dda:	06                   	push   es
    2ddb:	57                   	push   di
    2ddc:	9a 54 3a 16 2e       	call   0x2e16:0x3a54
    2de1:	c9                   	leave
    2de2:	ca 04 00             	retf   0x4
    2de5:	55                   	push   bp
    2de6:	89 e5                	mov    bp,sp
    2de8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2dec:	74 08                	je     0x2df6
    2dee:	83 ec 08             	sub    sp,0x8
    2df1:	9a e2 1f 38 2e       	call   0x2e38:0x1fe2
    2df6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2df9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2dfc:	31 c0                	xor    ax,ax
    2dfe:	50                   	push   ax
    2dff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e02:	06                   	push   es
    2e03:	57                   	push   di
    2e04:	9a d9 4b 31 2e       	call   0x2e31:0x4bd9
    2e09:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e0c:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e0f:	b0 01                	mov    al,0x1
    2e11:	50                   	push   ax
    2e12:	b8 b2 03             	mov    ax,0x3b2
    2e15:	ba 1d 2e             	mov    dx,0x2e1d
    2e18:	52                   	push   dx
    2e19:	50                   	push   ax
    2e1a:	9a 19 2a 6a 2e       	call   0x2e6a:0x2a19
    2e1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e22:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    2e26:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    2e2a:	b0 01                	mov    al,0x1
    2e2c:	50                   	push   ax
    2e2d:	b8 a3 02             	mov    ax,0x2a3
    2e30:	ba 4c 2e             	mov    dx,0x2e4c
    2e33:	52                   	push   dx
    2e34:	50                   	push   ax
    2e35:	9a 50 1f 53 2e       	call   0x2e53:0x1f50
    2e3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e3d:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    2e41:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    2e45:	b0 01                	mov    al,0x1
    2e47:	50                   	push   ax
    2e48:	b8 a3 02             	mov    ax,0x2a3
    2e4b:	ba a5 2e             	mov    dx,0x2ea5
    2e4e:	52                   	push   dx
    2e4f:	50                   	push   ax
    2e50:	9a 50 1f bd 2e       	call   0x2ebd:0x1f50
    2e55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e58:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    2e5c:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
    2e60:	26 c6 45 3b 01       	mov    BYTE PTR es:[di+0x3b],0x1
    2e65:	06                   	push   es
    2e66:	57                   	push   di
    2e67:	9a d2 45 af 2e       	call   0x2eaf:0x45d2
    2e6c:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    2e70:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2e74:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    2e78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e7b:	26 89 45 56          	mov    WORD PTR es:[di+0x56],ax
    2e7f:	26 89 55 58          	mov    WORD PTR es:[di+0x58],dx
    2e83:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2e87:	74 07                	je     0x2e90
    2e89:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e8d:	83 c4 06             	add    sp,0x6
    2e90:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2e93:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2e96:	c9                   	leave
    2e97:	ca 0a 00             	retf   0xa
    2e9a:	55                   	push   bp
    2e9b:	89 e5                	mov    bp,sp
    2e9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea0:	06                   	push   es
    2ea1:	57                   	push   di
    2ea2:	9a a5 4e d9 2e       	call   0x2ed9:0x4ea5
    2ea7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eaa:	06                   	push   es
    2eab:	57                   	push   di
    2eac:	9a d2 31 e5 2e       	call   0x2ee5:0x31d2
    2eb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb4:	26 c4 7d 5a          	les    di,DWORD PTR es:[di+0x5a]
    2eb8:	06                   	push   es
    2eb9:	57                   	push   di
    2eba:	9a 7f 1f f5 2e       	call   0x2ef5:0x1f7f
    2ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec2:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    2ec6:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    2ecb:	7e 1c                	jle    0x2ee9
    2ecd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed0:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    2ed4:	06                   	push   es
    2ed5:	57                   	push   di
    2ed6:	9a 43 0f 28 2f       	call   0x2f28:0xf43
    2edb:	52                   	push   dx
    2edc:	50                   	push   ax
    2edd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee0:	06                   	push   es
    2ee1:	57                   	push   di
    2ee2:	9a 76 3e ff 2e       	call   0x2eff:0x3e76
    2ee7:	eb d6                	jmp    0x2ebf
    2ee9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eec:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    2ef0:	06                   	push   es
    2ef1:	57                   	push   di
    2ef2:	9a 7f 1f 0d 2f       	call   0x2f0d:0x1f7f
    2ef7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2efa:	06                   	push   es
    2efb:	57                   	push   di
    2efc:	9a 6b 37 41 2f       	call   0x2f41:0x376b
    2f01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f04:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2f08:	06                   	push   es
    2f09:	57                   	push   di
    2f0a:	9a 7f 1f 1b 2f       	call   0x2f1b:0x1f7f
    2f0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f12:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2f16:	06                   	push   es
    2f17:	57                   	push   di
    2f18:	9a 7f 1f 33 2f       	call   0x2f33:0x1f7f
    2f1d:	31 c0                	xor    ax,ax
    2f1f:	50                   	push   ax
    2f20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f23:	06                   	push   es
    2f24:	57                   	push   di
    2f25:	9a 2b 4c 3d 2f       	call   0x2f3d:0x4c2b
    2f2a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2f2e:	74 05                	je     0x2f35
    2f30:	9a 0f 20 61 2f       	call   0x2f61:0x200f
    2f35:	c9                   	leave
    2f36:	ca 06 00             	retf   0x6
    2f39:	01 00                	add    WORD PTR [bx+si],ax
    2f3b:	73 02                	jae    0x2f3f
    2f3d:	55                   	push   bp
    2f3e:	2f                   	das
    2f3f:	a1 30 2d             	mov    ax,ds:0x2d30
    2f42:	31 c8                	xor    ax,cx
    2f44:	c8 02 00 8d          	enter  0x2,0x8d
    2f48:	be 3a fe             	mov    si,0xfe3a
    2f4b:	16                   	push   ss
    2f4c:	57                   	push   di
    2f4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f50:	06                   	push   es
    2f51:	57                   	push   di
    2f52:	9a 2a 51 70 2f       	call   0x2f70:0x512a
    2f57:	8d 7e be             	lea    di,[bp-0x42]
    2f5a:	16                   	push   ss
    2f5b:	57                   	push   di
    2f5c:	6a 3f                	push   0x3f
    2f5e:	9a e7 17 97 2f       	call   0x2f97:0x17e7
    2f63:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f66:	06                   	push   es
    2f67:	57                   	push   di
    2f68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6b:	06                   	push   es
    2f6c:	57                   	push   di
    2f6d:	9a 46 51 8d 2f       	call   0x2f8d:0x5146
    2f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f75:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2f7a:	75 03                	jne    0x2f7f
    2f7c:	e9 33 01             	jmp    0x30b2
    2f7f:	8d be 3a fe          	lea    di,[bp-0x1c6]
    2f83:	16                   	push   ss
    2f84:	57                   	push   di
    2f85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f88:	06                   	push   es
    2f89:	57                   	push   di
    2f8a:	9a 2a 51 d0 2f       	call   0x2fd0:0x512a
    2f8f:	8d 7e be             	lea    di,[bp-0x42]
    2f92:	16                   	push   ss
    2f93:	57                   	push   di
    2f94:	9a be 18 17 30       	call   0x3017:0x18be
    2f99:	75 03                	jne    0x2f9e
    2f9b:	e9 14 01             	jmp    0x30b2
    2f9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa1:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2fa5:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2fa9:	48                   	dec    ax
    2faa:	89 86 38 fe          	mov    WORD PTR [bp-0x1c8],ax
    2fae:	31 c0                	xor    ax,ax
    2fb0:	3b 86 38 fe          	cmp    ax,WORD PTR [bp-0x1c8]
    2fb4:	7e 03                	jle    0x2fb9
    2fb6:	e9 f9 00             	jmp    0x30b2
    2fb9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2fbc:	eb 03                	jmp    0x2fc1
    2fbe:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2fc1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2fc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2fcb:	06                   	push   es
    2fcc:	57                   	push   di
    2fcd:	9a d0 0d 0a 30       	call   0x300a:0xdd0
    2fd2:	89 86 3a ff          	mov    WORD PTR [bp-0xc6],ax
    2fd6:	89 96 3c ff          	mov    WORD PTR [bp-0xc4],dx
    2fda:	c4 be 3a ff          	les    di,DWORD PTR [bp-0xc6]
    2fde:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2fe2:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    2fe6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fe9:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
    2fed:	74 03                	je     0x2ff2
    2fef:	e9 b4 00             	jmp    0x30a6
    2ff2:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    2ff6:	74 03                	je     0x2ffb
    2ff8:	e9 ab 00             	jmp    0x30a6
    2ffb:	8d be 38 fd          	lea    di,[bp-0x2c8]
    2fff:	16                   	push   ss
    3000:	57                   	push   di
    3001:	c4 be 3a ff          	les    di,DWORD PTR [bp-0xc6]
    3005:	06                   	push   es
    3006:	57                   	push   di
    3007:	9a 2a 51 e7 30       	call   0x30e7:0x512a
    300c:	8d be 7e ff          	lea    di,[bp-0x82]
    3010:	16                   	push   ss
    3011:	57                   	push   di
    3012:	6a 3f                	push   0x3f
    3014:	9a e7 17 2a 30       	call   0x302a:0x17e7
    3019:	8d be 7e ff          	lea    di,[bp-0x82]
    301d:	16                   	push   ss
    301e:	57                   	push   di
    301f:	8d be 3e ff          	lea    di,[bp-0xc2]
    3023:	16                   	push   ss
    3024:	57                   	push   di
    3025:	6a 3f                	push   0x3f
    3027:	9a e7 17 61 30       	call   0x3061:0x17e7
    302c:	8a 86 3e ff          	mov    al,BYTE PTR [bp-0xc2]
    3030:	3a 46 be             	cmp    al,BYTE PTR [bp-0x42]
    3033:	76 71                	jbe    0x30a6
    3035:	8a 46 be             	mov    al,BYTE PTR [bp-0x42]
    3038:	88 86 3e ff          	mov    BYTE PTR [bp-0xc2],al
    303c:	8d 7e be             	lea    di,[bp-0x42]
    303f:	16                   	push   ss
    3040:	57                   	push   di
    3041:	8d be 3e ff          	lea    di,[bp-0xc2]
    3045:	16                   	push   ss
    3046:	57                   	push   di
    3047:	9a 30 07 9c 34       	call   0x349c:0x730
    304c:	09 c0                	or     ax,ax
    304e:	75 56                	jne    0x30a6
    3050:	8d be 7e ff          	lea    di,[bp-0x82]
    3054:	16                   	push   ss
    3055:	57                   	push   di
    3056:	6a 01                	push   0x1
    3058:	8a 46 be             	mov    al,BYTE PTR [bp-0x42]
    305b:	30 e4                	xor    ah,ah
    305d:	50                   	push   ax
    305e:	9a 75 19 75 30       	call   0x3075:0x1975
    3063:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3066:	06                   	push   es
    3067:	57                   	push   di
    3068:	8d be 7e ff          	lea    di,[bp-0x82]
    306c:	16                   	push   ss
    306d:	57                   	push   di
    306e:	6a 3f                	push   0x3f
    3070:	6a 01                	push   0x1
    3072:	9a 16 19 a4 30       	call   0x30a4:0x1916
    3077:	b8 39 2f             	mov    ax,0x2f39
    307a:	0e                   	push   cs
    307b:	50                   	push   ax
    307c:	55                   	push   bp
    307d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3081:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3085:	8d be 7e ff          	lea    di,[bp-0x82]
    3089:	16                   	push   ss
    308a:	57                   	push   di
    308b:	c4 be 3a ff          	les    di,DWORD PTR [bp-0xc6]
    308f:	06                   	push   es
    3090:	57                   	push   di
    3091:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3094:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3098:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    309c:	83 c4 06             	add    sp,0x6
    309f:	eb 05                	jmp    0x30a6
    30a1:	9a 34 14 86 31       	call   0x3186:0x1434
    30a6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    30a9:	3b 86 38 fe          	cmp    ax,WORD PTR [bp-0x1c8]
    30ad:	74 03                	je     0x30b2
    30af:	e9 0c ff             	jmp    0x2fbe
    30b2:	c9                   	leave
    30b3:	ca 08 00             	retf   0x8
    30b6:	c8 08 00 00          	enter  0x8,0x0
    30ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30bd:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    30c1:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    30c5:	48                   	dec    ax
    30c6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    30c9:	31 c0                	xor    ax,ax
    30cb:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    30ce:	7f 51                	jg     0x3121
    30d0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    30d3:	eb 03                	jmp    0x30d8
    30d5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    30d8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    30db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30de:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    30e2:	06                   	push   es
    30e3:	57                   	push   di
    30e4:	9a d0 0d 17 31       	call   0x3117:0xdd0
    30e9:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    30ec:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    30ef:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    30f2:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    30f6:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    30fa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    30fd:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    3101:	75 16                	jne    0x3119
    3103:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    3107:	75 10                	jne    0x3119
    3109:	ff 76 fc             	push   WORD PTR [bp-0x4]
    310c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    310f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3112:	06                   	push   es
    3113:	57                   	push   di
    3114:	9a 2a 43 3a 31       	call   0x313a:0x432a
    3119:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    311c:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    311f:	75 b4                	jne    0x30d5
    3121:	c9                   	leave
    3122:	ca 08 00             	retf   0x8
    3125:	01 00                	add    WORD PTR [bx+si],ax
    3127:	00 00                	add    BYTE PTR [bx+si],al
    3129:	00 00                	add    BYTE PTR [bx+si],al
    312b:	66 31 5b 31          	xor    DWORD PTR [bp+di+0x31],ebx
    312f:	55                   	push   bp
    3130:	89 e5                	mov    bp,sp
    3132:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3135:	06                   	push   es
    3136:	57                   	push   di
    3137:	9a f4 4f 89 37       	call   0x3789:0x4ff4
    313c:	b8 25 31             	mov    ax,0x3125
    313f:	0e                   	push   cs
    3140:	50                   	push   ax
    3141:	55                   	push   bp
    3142:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3146:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    314a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    314d:	26 80 7d 3f 00       	cmp    BYTE PTR es:[di+0x3f],0x0
    3152:	74 09                	je     0x315d
    3154:	6a 01                	push   0x1
    3156:	06                   	push   es
    3157:	57                   	push   di
    3158:	9a 27 32 cc 31       	call   0x31cc:0x3227
    315d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3161:	83 c4 06             	add    sp,0x6
    3164:	eb 27                	jmp    0x318d
    3166:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3169:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    316e:	74 13                	je     0x3183
    3170:	ff 76 08             	push   WORD PTR [bp+0x8]
    3173:	ff 76 06             	push   WORD PTR [bp+0x6]
    3176:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    317a:	06                   	push   es
    317b:	57                   	push   di
    317c:	9a 51 75 ff ff       	call   0xffff:0x7551
    3181:	eb 05                	jmp    0x3188
    3183:	ea 85 13 8b 31       	jmp    0x318b:0x1385
    3188:	9a 34 14 b4 32       	call   0x32b4:0x1434
    318d:	c9                   	leave
    318e:	ca 04 00             	retf   0x4
    3191:	55                   	push   bp
    3192:	89 e5                	mov    bp,sp
    3194:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3197:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    319b:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    319e:	74 1b                	je     0x31bb
    31a0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    31a3:	26 88 45 3a          	mov    BYTE PTR es:[di+0x3a],al
    31a7:	26 c6 45 3e 00       	mov    BYTE PTR es:[di+0x3e],0x0
    31ac:	6a 06                	push   0x6
    31ae:	6a 00                	push   0x0
    31b0:	6a 00                	push   0x0
    31b2:	06                   	push   es
    31b3:	57                   	push   di
    31b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31b7:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    31bb:	c9                   	leave
    31bc:	ca 06 00             	retf   0x6
    31bf:	55                   	push   bp
    31c0:	89 e5                	mov    bp,sp
    31c2:	6a 01                	push   0x1
    31c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31c7:	06                   	push   es
    31c8:	57                   	push   di
    31c9:	9a 27 32 df 31       	call   0x31df:0x3227
    31ce:	c9                   	leave
    31cf:	ca 04 00             	retf   0x4
    31d2:	55                   	push   bp
    31d3:	89 e5                	mov    bp,sp
    31d5:	6a 00                	push   0x0
    31d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31da:	06                   	push   es
    31db:	57                   	push   di
    31dc:	9a 27 32 f0 31       	call   0x31f0:0x3227
    31e1:	c9                   	leave
    31e2:	ca 04 00             	retf   0x4
    31e5:	55                   	push   bp
    31e6:	89 e5                	mov    bp,sp
    31e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31eb:	06                   	push   es
    31ec:	57                   	push   di
    31ed:	9a 02 32 fc 31       	call   0x31fc:0x3202
    31f2:	08 c0                	or     al,al
    31f4:	74 08                	je     0x31fe
    31f6:	68 04 f2             	push   0xf204
    31f9:	9a ef 11 25 32       	call   0x3225:0x11ef
    31fe:	c9                   	leave
    31ff:	ca 04 00             	retf   0x4
    3202:	c8 02 00 00          	enter  0x2,0x0
    3206:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3209:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    320e:	b0 00                	mov    al,0x0
    3210:	74 01                	je     0x3213
    3212:	40                   	inc    ax
    3213:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3216:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3219:	c9                   	leave
    321a:	ca 04 00             	retf   0x4
    321d:	01 00                	add    WORD PTR [bx+si],ax
    321f:	00 00                	add    BYTE PTR [bx+si],al
    3221:	00 00                	add    BYTE PTR [bx+si],al
    3223:	99                   	cwd
    3224:	32 4d 32             	xor    cl,BYTE PTR [di+0x32]
    3227:	c8 02 00 00          	enter  0x2,0x0
    322b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322e:	26 f6 45 18 02       	test   BYTE PTR es:[di+0x18],0x2
    3233:	74 10                	je     0x3245
    3235:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3239:	74 07                	je     0x3242
    323b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    323e:	26 88 45 3f          	mov    BYTE PTR es:[di+0x3f],al
    3242:	e9 c2 00             	jmp    0x3307
    3245:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3248:	06                   	push   es
    3249:	57                   	push   di
    324a:	9a 02 32 8e 32       	call   0x328e:0x3202
    324f:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    3252:	75 03                	jne    0x3257
    3254:	e9 b0 00             	jmp    0x3307
    3257:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    325b:	74 6c                	je     0x32c9
    325d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3260:	06                   	push   es
    3261:	57                   	push   di
    3262:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3265:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    3269:	b8 1d 32             	mov    ax,0x321d
    326c:	0e                   	push   cs
    326d:	50                   	push   ax
    326e:	55                   	push   bp
    326f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3273:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3277:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    327a:	06                   	push   es
    327b:	57                   	push   di
    327c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    327f:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    3284:	6a 01                	push   0x1
    3286:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3289:	06                   	push   es
    328a:	57                   	push   di
    328b:	9a 91 31 a3 32       	call   0x32a3:0x3191
    3290:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3294:	83 c4 06             	add    sp,0x6
    3297:	eb 22                	jmp    0x32bb
    3299:	6a 00                	push   0x0
    329b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329e:	06                   	push   es
    329f:	57                   	push   di
    32a0:	9a 91 31 e6 32       	call   0x32e6:0x3191
    32a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32a8:	06                   	push   es
    32a9:	57                   	push   di
    32aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32ad:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    32b1:	ea 85 13 b9 32       	jmp    0x32b9:0x1385
    32b6:	9a 34 14 28 34       	call   0x3428:0x1434
    32bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32be:	06                   	push   es
    32bf:	57                   	push   di
    32c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32c3:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    32c7:	eb 3e                	jmp    0x3307
    32c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32cc:	26 f6 45 18 08       	test   BYTE PTR es:[di+0x18],0x8
    32d1:	75 09                	jne    0x32dc
    32d3:	06                   	push   es
    32d4:	57                   	push   di
    32d5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32d8:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    32dc:	6a 00                	push   0x0
    32de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e1:	06                   	push   es
    32e2:	57                   	push   di
    32e3:	9a 91 31 36 33       	call   0x3336:0x3191
    32e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32eb:	06                   	push   es
    32ec:	57                   	push   di
    32ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32f0:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    32f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f7:	26 f6 45 18 08       	test   BYTE PTR es:[di+0x18],0x8
    32fc:	75 09                	jne    0x3307
    32fe:	06                   	push   es
    32ff:	57                   	push   di
    3300:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3303:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3307:	c9                   	leave
    3308:	ca 06 00             	retf   0x6
    330b:	c8 04 00 00          	enter  0x4,0x0
    330f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3312:	06                   	push   es
    3313:	57                   	push   di
    3314:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3317:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    331b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    331e:	26 89 45 34          	mov    WORD PTR es:[di+0x34],ax
    3322:	26 89 55 36          	mov    WORD PTR es:[di+0x36],dx
    3326:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    332a:	26 0b 45 36          	or     ax,WORD PTR es:[di+0x36]
    332e:	75 08                	jne    0x3338
    3330:	68 06 f2             	push   0xf206
    3333:	9a ef 11 6a 33       	call   0x336a:0x11ef
    3338:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    333b:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    333f:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3343:	8d 7e fc             	lea    di,[bp-0x4]
    3346:	16                   	push   ss
    3347:	57                   	push   di
    3348:	9a ad 09 a7 33       	call   0x33a7:0x9ad
    334d:	09 c0                	or     ax,ax
    334f:	75 11                	jne    0x3362
    3351:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3354:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    335a:	26 89 45 56          	mov    WORD PTR es:[di+0x56],ax
    335e:	26 89 55 58          	mov    WORD PTR es:[di+0x58],dx
    3362:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3365:	06                   	push   es
    3366:	57                   	push   di
    3367:	9a d6 33 7b 33       	call   0x337b:0x33d6
    336c:	c9                   	leave
    336d:	ca 04 00             	retf   0x4
    3370:	55                   	push   bp
    3371:	89 e5                	mov    bp,sp
    3373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3376:	06                   	push   es
    3377:	57                   	push   di
    3378:	9a 24 36 d4 33       	call   0x33d4:0x3624
    337d:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    3381:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3385:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    3389:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    338c:	26 89 45 56          	mov    WORD PTR es:[di+0x56],ax
    3390:	26 89 55 58          	mov    WORD PTR es:[di+0x58],dx
    3394:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    3398:	26 0b 45 36          	or     ax,WORD PTR es:[di+0x36]
    339c:	74 18                	je     0x33b6
    339e:	81 c7 34 00          	add    di,0x34
    33a2:	06                   	push   es
    33a3:	57                   	push   di
    33a4:	9a ad 00 ee 33       	call   0x33ee:0xad
    33a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33ac:	31 c0                	xor    ax,ax
    33ae:	26 89 45 34          	mov    WORD PTR es:[di+0x34],ax
    33b2:	26 89 45 36          	mov    WORD PTR es:[di+0x36],ax
    33b6:	c9                   	leave
    33b7:	ca 04 00             	retf   0x4
    33ba:	c8 04 00 00          	enter  0x4,0x0
    33be:	31 c0                	xor    ax,ax
    33c0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    33c3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    33c6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33c9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    33cc:	c9                   	leave
    33cd:	ca 04 00             	retf   0x4
    33d0:	00 00                	add    BYTE PTR [bx+si],al
    33d2:	3a 35                	cmp    dh,BYTE PTR [di]
    33d4:	d4 34                	aam    0x34
    33d6:	c8 74 05 00          	enter  0x574,0x0
    33da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33dd:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    33e1:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    33e5:	8d be ba fe          	lea    di,[bp-0x146]
    33e9:	16                   	push   ss
    33ea:	57                   	push   di
    33eb:	9a 7d 00 66 34       	call   0x3466:0x7d
    33f0:	8b 86 60 ff          	mov    ax,WORD PTR [bp-0xa0]
    33f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33f7:	26 89 45 46          	mov    WORD PTR es:[di+0x46],ax
    33fb:	8b 86 6a ff          	mov    ax,WORD PTR [bp-0x96]
    33ff:	26 89 45 48          	mov    WORD PTR es:[di+0x48],ax
    3403:	83 be 6e ff 00       	cmp    WORD PTR [bp-0x92],0x0
    3408:	75 06                	jne    0x3410
    340a:	83 7e b6 00          	cmp    WORD PTR [bp-0x4a],0x0
    340e:	74 04                	je     0x3414
    3410:	b0 00                	mov    al,0x0
    3412:	eb 02                	jmp    0x3416
    3414:	b0 01                	mov    al,0x1
    3416:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3419:	26 88 45 3d          	mov    BYTE PTR es:[di+0x3d],al
    341d:	8d be 8c fa          	lea    di,[bp-0x574]
    3421:	16                   	push   ss
    3422:	57                   	push   di
    3423:	6a 00                	push   0x0
    3425:	9a 0e 1a 34 34       	call   0x3434:0x1a0e
    342a:	8d 7e d8             	lea    di,[bp-0x28]
    342d:	16                   	push   ss
    342e:	57                   	push   di
    342f:	6a 20                	push   0x20
    3431:	9a 79 1a 83 34       	call   0x3483:0x1a79
    3436:	8b 86 66 ff          	mov    ax,WORD PTR [bp-0x9a]
    343a:	89 86 aa fa          	mov    WORD PTR [bp-0x556],ax
    343e:	b8 01 00             	mov    ax,0x1
    3441:	3b 86 aa fa          	cmp    ax,WORD PTR [bp-0x556]
    3445:	7f 4c                	jg     0x3493
    3447:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    344a:	eb 03                	jmp    0x344f
    344c:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    344f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3452:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3456:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    345a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    345d:	8d be ac fa          	lea    di,[bp-0x554]
    3461:	16                   	push   ss
    3462:	57                   	push   di
    3463:	9a 4d 23 c6 34       	call   0x34c6:0x234d
    3468:	83 be ae fa 00       	cmp    WORD PTR [bp-0x552],0x0
    346d:	74 1b                	je     0x348a
    346f:	83 be b4 fa 00       	cmp    WORD PTR [bp-0x54c],0x0
    3474:	75 14                	jne    0x348a
    3476:	8b 86 ac fa          	mov    ax,WORD PTR [bp-0x554]
    347a:	48                   	dec    ax
    347b:	b4 01                	mov    ah,0x1
    347d:	ba 20 00             	mov    dx,0x20
    3480:	9a 99 1a 05 35       	call   0x3505:0x1a99
    3485:	8b fa                	mov    di,dx
    3487:	08 43 d8             	or     BYTE PTR [bp+di-0x28],al
    348a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    348d:	3b 86 aa fa          	cmp    ax,WORD PTR [bp-0x556]
    3491:	75 b9                	jne    0x344c
    3493:	6b 86 5c ff 34       	imul   ax,WORD PTR [bp-0xa4],0x34
    3498:	50                   	push   ax
    3499:	9a 76 04 c5 35       	call   0x35c5:0x476
    349e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    34a1:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    34a4:	b8 d0 33             	mov    ax,0x33d0
    34a7:	0e                   	push   cs
    34a8:	50                   	push   ax
    34a9:	55                   	push   bp
    34aa:	ff 36 58 18          	push   WORD PTR ds:0x1858
    34ae:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    34b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    34b9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    34bd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    34c0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    34c3:	9a 9d 00 ff 35       	call   0x35ff:0x9d
    34c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34cb:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    34cf:	06                   	push   es
    34d0:	57                   	push   di
    34d1:	9a a4 2c 23 35       	call   0x3523:0x2ca4
    34d6:	8b 86 5c ff          	mov    ax,WORD PTR [bp-0xa4]
    34da:	48                   	dec    ax
    34db:	89 86 aa fa          	mov    WORD PTR [bp-0x556],ax
    34df:	31 c0                	xor    ax,ax
    34e1:	3b 86 aa fa          	cmp    ax,WORD PTR [bp-0x556]
    34e5:	7f 47                	jg     0x352e
    34e7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34ea:	eb 03                	jmp    0x34ef
    34ec:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    34ef:	6b 46 fc 34          	imul   ax,WORD PTR [bp-0x4],0x34
    34f3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34f6:	03 f8                	add    di,ax
    34f8:	06                   	push   es
    34f9:	57                   	push   di
    34fa:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    34fd:	b4 01                	mov    ah,0x1
    34ff:	ba 20 00             	mov    dx,0x20
    3502:	9a 99 1a 49 35       	call   0x3549:0x1a99
    3507:	8b fa                	mov    di,dx
    3509:	84 43 d8             	test   BYTE PTR [bp+di-0x28],al
    350c:	b0 00                	mov    al,0x0
    350e:	74 01                	je     0x3511
    3510:	40                   	inc    ax
    3511:	50                   	push   ax
    3512:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3515:	40                   	inc    ax
    3516:	50                   	push   ax
    3517:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    351a:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    351e:	06                   	push   es
    351f:	57                   	push   di
    3520:	9a 44 2b 5e 35       	call   0x355e:0x2b44
    3525:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3528:	3b 86 aa fa          	cmp    ax,WORD PTR [bp-0x556]
    352c:	75 be                	jne    0x34ec
    352e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3532:	83 c4 06             	add    sp,0x6
    3535:	b8 4c 35             	mov    ax,0x354c
    3538:	0e                   	push   cs
    3539:	50                   	push   ax
    353a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    353d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3540:	6b 86 5c ff 34       	imul   ax,WORD PTR [bp-0xa4],0x34
    3545:	50                   	push   ax
    3546:	9a 9c 01 04 37       	call   0x3704:0x19c
    354b:	cb                   	retf
    354c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    354f:	26 80 7d 40 00       	cmp    BYTE PTR es:[di+0x40],0x0
    3554:	74 03                	je     0x3559
    3556:	e9 c7 00             	jmp    0x3620
    3559:	06                   	push   es
    355a:	57                   	push   di
    355b:	9a be 36 84 35       	call   0x3584:0x36be
    3560:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3563:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3567:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    356c:	b0 00                	mov    al,0x0
    356e:	75 01                	jne    0x3571
    3570:	40                   	inc    ax
    3571:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3574:	26 88 45 3c          	mov    BYTE PTR es:[di+0x3c],al
    3578:	26 80 7d 3c 00       	cmp    BYTE PTR es:[di+0x3c],0x0
    357d:	74 07                	je     0x3586
    357f:	06                   	push   es
    3580:	57                   	push   di
    3581:	9a 11 37 90 35       	call   0x3590:0x3711
    3586:	6a 01                	push   0x1
    3588:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    358b:	06                   	push   es
    358c:	57                   	push   di
    358d:	9a b1 37 d1 35       	call   0x35d1:0x37b1
    3592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3595:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    3599:	26 03 45 4c          	add    ax,WORD PTR es:[di+0x4c]
    359d:	26 89 45 4a          	mov    WORD PTR es:[di+0x4a],ax
    35a1:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    35a5:	40                   	inc    ax
    35a6:	26 03 45 48          	add    ax,WORD PTR es:[di+0x48]
    35aa:	26 89 45 4e          	mov    WORD PTR es:[di+0x4e],ax
    35ae:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    35b2:	eb 03                	jmp    0x35b7
    35b4:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    35b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ba:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    35be:	05 04 00             	add    ax,0x4
    35c1:	50                   	push   ax
    35c2:	9a 76 04 8d 3c       	call   0x3c8d:0x476
    35c7:	52                   	push   dx
    35c8:	50                   	push   ax
    35c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35cc:	06                   	push   es
    35cd:	57                   	push   di
    35ce:	9a cd 42 16 36       	call   0x3616:0x42cd
    35d3:	8b c8                	mov    cx,ax
    35d5:	8b da                	mov    bx,dx
    35d7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    35da:	98                   	cbw
    35db:	c1 e0 02             	shl    ax,0x2
    35de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35e1:	03 f8                	add    di,ax
    35e3:	26 89 4d 5e          	mov    WORD PTR es:[di+0x5e],cx
    35e7:	26 89 5d 60          	mov    WORD PTR es:[di+0x60],bx
    35eb:	80 7e ff 05          	cmp    BYTE PTR [bp-0x1],0x5
    35ef:	75 c3                	jne    0x35b4
    35f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35f4:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    35f8:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    35fc:	9a bd 00 d8 36       	call   0x36d8:0xbd
    3601:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3604:	06                   	push   es
    3605:	57                   	push   di
    3606:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3609:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    360e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3611:	06                   	push   es
    3612:	57                   	push   di
    3613:	9a b5 41 3a 36       	call   0x363a:0x41b5
    3618:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    361b:	26 c6 45 38 01       	mov    BYTE PTR es:[di+0x38],0x1
    3620:	c9                   	leave
    3621:	ca 04 00             	retf   0x4
    3624:	c8 02 00 00          	enter  0x2,0x0
    3628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    362b:	26 80 7d 40 00       	cmp    BYTE PTR es:[di+0x40],0x0
    3630:	74 03                	je     0x3635
    3632:	e9 7d 00             	jmp    0x36b2
    3635:	06                   	push   es
    3636:	57                   	push   di
    3637:	9a 08 3a 46 36       	call   0x3646:0x3a08
    363c:	6a 00                	push   0x0
    363e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3641:	06                   	push   es
    3642:	57                   	push   di
    3643:	9a bc 3e 56 36       	call   0x3656:0x3ebc
    3648:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    364b:	31 c0                	xor    ax,ax
    364d:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    3651:	06                   	push   es
    3652:	57                   	push   di
    3653:	9a d2 45 91 36       	call   0x3691:0x45d2
    3658:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    365c:	eb 03                	jmp    0x3661
    365e:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    3661:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3664:	98                   	cbw
    3665:	c1 e0 02             	shl    ax,0x2
    3668:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    366b:	03 f8                	add    di,ax
    366d:	81 c7 5e 00          	add    di,0x5e
    3671:	06                   	push   es
    3672:	57                   	push   di
    3673:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3676:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    367a:	05 04 00             	add    ax,0x4
    367d:	50                   	push   ax
    367e:	e8 ee d7             	call   0xe6f
    3681:	80 7e ff 05          	cmp    BYTE PTR [bp-0x1],0x5
    3685:	75 d7                	jne    0x365e
    3687:	6a 00                	push   0x0
    3689:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    368c:	06                   	push   es
    368d:	57                   	push   di
    368e:	9a b1 37 a2 36       	call   0x36a2:0x37b1
    3693:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3696:	26 80 7d 3c 00       	cmp    BYTE PTR es:[di+0x3c],0x0
    369b:	74 07                	je     0x36a4
    369d:	06                   	push   es
    369e:	57                   	push   di
    369f:	9a 6b 37 21 37       	call   0x3721:0x376b
    36a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36a7:	26 c6 45 3c 00       	mov    BYTE PTR es:[di+0x3c],0x0
    36ac:	31 c0                	xor    ax,ax
    36ae:	26 89 45 7e          	mov    WORD PTR es:[di+0x7e],ax
    36b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b5:	26 c6 45 3d 00       	mov    BYTE PTR es:[di+0x3d],0x0
    36ba:	c9                   	leave
    36bb:	ca 04 00             	retf   0x4
    36be:	c8 d8 02 00          	enter  0x2d8,0x0
    36c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36c5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    36c9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    36cd:	6a 00                	push   0x0
    36cf:	8d be 28 fd          	lea    di,[bp-0x2d8]
    36d3:	16                   	push   ss
    36d4:	57                   	push   di
    36d5:	9a 6d 07 40 39       	call   0x3940:0x76d
    36da:	09 c0                	or     ax,ax
    36dc:	75 28                	jne    0x3706
    36de:	83 be f4 fd 00       	cmp    WORD PTR [bp-0x20c],0x0
    36e3:	75 21                	jne    0x3706
    36e5:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    36e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ec:	26 89 45 7e          	mov    WORD PTR es:[di+0x7e],ax
    36f0:	8d be 00 fe          	lea    di,[bp-0x200]
    36f4:	16                   	push   ss
    36f5:	57                   	push   di
    36f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36f9:	81 c7 80 00          	add    di,0x80
    36fd:	06                   	push   es
    36fe:	57                   	push   di
    36ff:	6a 20                	push   0x20
    3701:	9a 1b 16 a9 37       	call   0x37a9:0x161b
    3706:	c9                   	leave
    3707:	ca 04 00             	retf   0x4
    370a:	55                   	push   bp
    370b:	89 e5                	mov    bp,sp
    370d:	c9                   	leave
    370e:	ca 04 00             	retf   0x4
    3711:	c8 08 00 00          	enter  0x8,0x0
    3715:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3718:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    371c:	06                   	push   es
    371d:	57                   	push   di
    371e:	9a 31 2d 45 37       	call   0x3745:0x2d31
    3723:	48                   	dec    ax
    3724:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3727:	31 c0                	xor    ax,ax
    3729:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    372c:	7f 39                	jg     0x3767
    372e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3731:	eb 03                	jmp    0x3736
    3733:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3736:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3739:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    373c:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3740:	06                   	push   es
    3741:	57                   	push   di
    3742:	9a 4a 2d 5d 37       	call   0x375d:0x2d4a
    3747:	89 c7                	mov    di,ax
    3749:	8e c2                	mov    es,dx
    374b:	26 80 7d 0c 00       	cmp    BYTE PTR es:[di+0xc],0x0
    3750:	74 0d                	je     0x375f
    3752:	ff 76 08             	push   WORD PTR [bp+0x8]
    3755:	ff 76 06             	push   WORD PTR [bp+0x6]
    3758:	06                   	push   es
    3759:	57                   	push   di
    375a:	9a f1 28 9f 37       	call   0x379f:0x28f1
    375f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3762:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3765:	75 cc                	jne    0x3733
    3767:	c9                   	leave
    3768:	ca 04 00             	retf   0x4
    376b:	c8 04 00 00          	enter  0x4,0x0
    376f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3772:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3776:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    377b:	7e 30                	jle    0x37ad
    377d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3780:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3784:	06                   	push   es
    3785:	57                   	push   di
    3786:	9a 43 0f eb 37       	call   0x37eb:0xf43
    378b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    378e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3791:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3794:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3797:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    379a:	06                   	push   es
    379b:	57                   	push   di
    379c:	9a 0a 3b 26 38       	call   0x3826:0x3b0a
    37a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    37a4:	06                   	push   es
    37a5:	57                   	push   di
    37a6:	9a 7f 1f f3 39       	call   0x39f3:0x1f7f
    37ab:	eb c2                	jmp    0x376f
    37ad:	c9                   	leave
    37ae:	ca 04 00             	retf   0x4
    37b1:	c8 14 00 00          	enter  0x14,0x0
    37b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b8:	31 c0                	xor    ax,ax
    37ba:	26 89 45 4c          	mov    WORD PTR es:[di+0x4c],ax
    37be:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    37c2:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    37c6:	48                   	dec    ax
    37c7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    37ca:	31 c0                	xor    ax,ax
    37cc:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    37cf:	7e 03                	jle    0x37d4
    37d1:	e9 34 01             	jmp    0x3908
    37d4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    37d7:	eb 03                	jmp    0x37dc
    37d9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    37dc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    37df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37e2:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    37e6:	06                   	push   es
    37e7:	57                   	push   di
    37e8:	9a d0 0d 39 3a       	call   0x3a39:0xdd0
    37ed:	89 c7                	mov    di,ax
    37ef:	8e c2                	mov    es,dx
    37f1:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    37f4:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    37f7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    37fb:	75 03                	jne    0x3800
    37fd:	e9 f4 00             	jmp    0x38f4
    3800:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    3805:	74 65                	je     0x386c
    3807:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    380b:	3c 01                	cmp    al,0x1
    380d:	72 0c                	jb     0x381b
    380f:	3c 07                	cmp    al,0x7
    3811:	76 33                	jbe    0x3846
    3813:	3c 09                	cmp    al,0x9
    3815:	72 04                	jb     0x381b
    3817:	3c 0b                	cmp    al,0xb
    3819:	76 2b                	jbe    0x3846
    381b:	68 1d f2             	push   0xf21d
    381e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3821:	06                   	push   es
    3822:	57                   	push   di
    3823:	9a f6 67 44 38       	call   0x3844:0x67f6
    3828:	89 c7                	mov    di,ax
    382a:	8e c2                	mov    es,dx
    382c:	89 f8                	mov    ax,di
    382e:	8c c2                	mov    dx,es
    3830:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3833:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3836:	c6 46 f0 04          	mov    BYTE PTR [bp-0x10],0x4
    383a:	8d 7e ec             	lea    di,[bp-0x14]
    383d:	16                   	push   ss
    383e:	57                   	push   di
    383f:	6a 00                	push   0x0
    3841:	9a 0a 12 81 38       	call   0x3881:0x120a
    3846:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3849:	26 c7 45 2e ff ff    	mov    WORD PTR es:[di+0x2e],0xffff
    384f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3852:	26 8b 45 4c          	mov    ax,WORD PTR es:[di+0x4c]
    3856:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3859:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    385d:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    3861:	40                   	inc    ax
    3862:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3865:	26 01 45 4c          	add    WORD PTR es:[di+0x4c],ax
    3869:	e9 86 00             	jmp    0x38f2
    386c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    386f:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    3873:	06                   	push   es
    3874:	57                   	push   di
    3875:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3878:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    387c:	06                   	push   es
    387d:	57                   	push   di
    387e:	9a d4 2c c4 38       	call   0x38c4:0x2cd4
    3883:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3886:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3889:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    388c:	26 8a 45 0c          	mov    al,BYTE PTR es:[di+0xc]
    3890:	98                   	cbw
    3891:	8b f8                	mov    di,ax
    3893:	8a 95 4c 0b          	mov    dl,BYTE PTR [di+0xb4c]
    3897:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    389a:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    389e:	98                   	cbw
    389f:	8b f8                	mov    di,ax
    38a1:	8a 85 4c 0b          	mov    al,BYTE PTR [di+0xb4c]
    38a5:	3a c2                	cmp    al,dl
    38a7:	75 10                	jne    0x38b9
    38a9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    38ac:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    38b0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    38b3:	26 3b 45 0e          	cmp    ax,WORD PTR es:[di+0xe]
    38b7:	74 2b                	je     0x38e4
    38b9:	68 0b f2             	push   0xf20b
    38bc:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    38bf:	06                   	push   es
    38c0:	57                   	push   di
    38c1:	9a f6 67 e2 38       	call   0x38e2:0x67f6
    38c6:	89 c7                	mov    di,ax
    38c8:	8e c2                	mov    es,dx
    38ca:	89 f8                	mov    ax,di
    38cc:	8c c2                	mov    dx,es
    38ce:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    38d1:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    38d4:	c6 46 f0 04          	mov    BYTE PTR [bp-0x10],0x4
    38d8:	8d 7e ec             	lea    di,[bp-0x14]
    38db:	16                   	push   ss
    38dc:	57                   	push   di
    38dd:	6a 00                	push   0x0
    38df:	9a 0a 12 14 39       	call   0x3914:0x120a
    38e4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    38e7:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    38eb:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    38ee:	26 89 45 2e          	mov    WORD PTR es:[di+0x2e],ax
    38f2:	eb 09                	jmp    0x38fd
    38f4:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    38f7:	31 c0                	xor    ax,ax
    38f9:	26 89 45 2e          	mov    WORD PTR es:[di+0x2e],ax
    38fd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3900:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3903:	74 03                	je     0x3908
    3905:	e9 d1 fe             	jmp    0x37d9
    3908:	c9                   	leave
    3909:	ca 06 00             	retf   0x6
    390c:	01 00                	add    WORD PTR [bx+si],ax
    390e:	00 00                	add    BYTE PTR [bx+si],al
    3910:	00 00                	add    BYTE PTR [bx+si],al
    3912:	d8 39                	fdivr  DWORD PTR [bx+di]
    3914:	22 39                	and    bh,BYTE PTR [bx+di]
    3916:	c8 20 01 00          	enter  0x120,0x0
    391a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    391d:	06                   	push   es
    391e:	57                   	push   di
    391f:	9a 3b 48 73 39       	call   0x3973:0x483b
    3924:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3927:	81 c7 34 00          	add    di,0x34
    392b:	06                   	push   es
    392c:	57                   	push   di
    392d:	ff 76 10             	push   WORD PTR [bp+0x10]
    3930:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3933:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3936:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3939:	6a 00                	push   0x0
    393b:	6a 01                	push   0x1
    393d:	9a 5d 07 68 39       	call   0x3968:0x75d
    3942:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3945:	81 7e fe 05 22       	cmp    WORD PTR [bp-0x2],0x2205
    394a:	75 21                	jne    0x396d
    394c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    394f:	81 c7 34 00          	add    di,0x34
    3953:	06                   	push   es
    3954:	57                   	push   di
    3955:	ff 76 10             	push   WORD PTR [bp+0x10]
    3958:	ff 76 0e             	push   WORD PTR [bp+0xe]
    395b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    395e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3961:	6a 00                	push   0x0
    3963:	6a 00                	push   0x0
    3965:	9a 5d 07 9b 39       	call   0x399b:0x75d
    396a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    396d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3970:	9a 4e 12 7f 39       	call   0x397f:0x124e
    3975:	6a 00                	push   0x0
    3977:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    397a:	06                   	push   es
    397b:	57                   	push   di
    397c:	9a bc 3e cd 39       	call   0x39cd:0x3ebc
    3981:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3984:	31 c0                	xor    ax,ax
    3986:	26 89 45 7e          	mov    WORD PTR es:[di+0x7e],ax
    398a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    398e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3992:	8d be e0 fe          	lea    di,[bp-0x120]
    3996:	16                   	push   ss
    3997:	57                   	push   di
    3998:	9a 7d 00 ab 42       	call   0x42ab:0x7d
    399d:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    39a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a3:	26 89 45 48          	mov    WORD PTR es:[di+0x48],ax
    39a7:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    39ab:	40                   	inc    ax
    39ac:	26 03 45 48          	add    ax,WORD PTR es:[di+0x48]
    39b0:	26 89 45 4e          	mov    WORD PTR es:[di+0x4e],ax
    39b4:	b8 0c 39             	mov    ax,0x390c
    39b7:	0e                   	push   cs
    39b8:	50                   	push   ax
    39b9:	55                   	push   bp
    39ba:	ff 36 58 18          	push   WORD PTR ds:0x1858
    39be:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    39c2:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    39c6:	40                   	inc    ax
    39c7:	50                   	push   ax
    39c8:	06                   	push   es
    39c9:	57                   	push   di
    39ca:	9a bc 3e e2 39       	call   0x39e2:0x3ebc
    39cf:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    39d3:	83 c4 06             	add    sp,0x6
    39d6:	eb 22                	jmp    0x39fa
    39d8:	6a 00                	push   0x0
    39da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39dd:	06                   	push   es
    39de:	57                   	push   di
    39df:	9a 91 31 02 3a       	call   0x3a02:0x3191
    39e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39e7:	06                   	push   es
    39e8:	57                   	push   di
    39e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39ec:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    39f0:	ea 85 13 f8 39       	jmp    0x39f8:0x1385
    39f5:	9a 34 14 d9 3e       	call   0x3ed9:0x1434
    39fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39fd:	06                   	push   es
    39fe:	57                   	push   di
    39ff:	9a be 36 86 3a       	call   0x3a86:0x36be
    3a04:	c9                   	leave
    3a05:	ca 0c 00             	retf   0xc
    3a08:	c8 04 00 00          	enter  0x4,0x0
    3a0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a0f:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3a13:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3a17:	48                   	dec    ax
    3a18:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a1b:	31 c0                	xor    ax,ax
    3a1d:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3a20:	7f 2e                	jg     0x3a50
    3a22:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3a25:	eb 03                	jmp    0x3a2a
    3a27:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3a2a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3a2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a30:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3a34:	06                   	push   es
    3a35:	57                   	push   di
    3a36:	9a d0 0d f3 3a       	call   0x3af3:0xdd0
    3a3b:	89 c7                	mov    di,ax
    3a3d:	8e c2                	mov    es,dx
    3a3f:	06                   	push   es
    3a40:	57                   	push   di
    3a41:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a44:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    3a48:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a4b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3a4e:	75 d7                	jne    0x3a27
    3a50:	c9                   	leave
    3a51:	ca 04 00             	retf   0x4
    3a54:	55                   	push   bp
    3a55:	89 e5                	mov    bp,sp
    3a57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a5a:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3a5e:	26 80 7d 0c 00       	cmp    BYTE PTR es:[di+0xc],0x0
    3a63:	75 19                	jne    0x3a7e
    3a65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a68:	06                   	push   es
    3a69:	57                   	push   di
    3a6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a6d:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    3a72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a75:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3a79:	26 c6 45 0c 01       	mov    BYTE PTR es:[di+0xc],0x1
    3a7e:	c9                   	leave
    3a7f:	ca 04 00             	retf   0x4
    3a82:	00 00                	add    BYTE PTR [bx+si],al
    3a84:	c5 3a                	lds    di,DWORD PTR [bp+si]
    3a86:	93                   	xchg   bx,ax
    3a87:	3a 55 89             	cmp    dl,BYTE PTR [di-0x77]
    3a8a:	e5 c4                	in     ax,0xc4
    3a8c:	7e 06                	jle    0x3a94
    3a8e:	06                   	push   es
    3a8f:	57                   	push   di
    3a90:	9a 02 32 ac 3b       	call   0x3bac:0x3202
    3a95:	08 c0                	or     al,al
    3a97:	75 41                	jne    0x3ada
    3a99:	b8 82 3a             	mov    ax,0x3a82
    3a9c:	0e                   	push   cs
    3a9d:	50                   	push   ax
    3a9e:	55                   	push   bp
    3a9f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3aa3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3aa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aaa:	26 c6 45 40 01       	mov    BYTE PTR es:[di+0x40],0x1
    3aaf:	06                   	push   es
    3ab0:	57                   	push   di
    3ab1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ab4:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    3ab9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3abd:	83 c4 06             	add    sp,0x6
    3ac0:	b8 da 3a             	mov    ax,0x3ada
    3ac3:	0e                   	push   cs
    3ac4:	50                   	push   ax
    3ac5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ac8:	06                   	push   es
    3ac9:	57                   	push   di
    3aca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3acd:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    3ad1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad4:	26 c6 45 40 00       	mov    BYTE PTR es:[di+0x40],0x0
    3ad9:	cb                   	retf
    3ada:	c9                   	leave
    3adb:	ca 04 00             	retf   0x4
    3ade:	55                   	push   bp
    3adf:	89 e5                	mov    bp,sp
    3ae1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3ae4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3ae7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aea:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3aee:	06                   	push   es
    3aef:	57                   	push   di
    3af0:	9a 2b 0c 2c 3b       	call   0x3b2c:0xc2b
    3af5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3af8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3afb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3afe:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3b02:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    3b06:	c9                   	leave
    3b07:	ca 08 00             	retf   0x8
    3b0a:	55                   	push   bp
    3b0b:	89 e5                	mov    bp,sp
    3b0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3b10:	31 c0                	xor    ax,ax
    3b12:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3b16:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    3b1a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b1d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b23:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3b27:	06                   	push   es
    3b28:	57                   	push   di
    3b29:	9a a7 0f 5e 3b       	call   0x3b5e:0xfa7
    3b2e:	c9                   	leave
    3b2f:	ca 08 00             	retf   0x8
    3b32:	c8 02 00 00          	enter  0x2,0x0
    3b36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b39:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3b3d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3b41:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3b44:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b47:	c9                   	leave
    3b48:	ca 04 00             	retf   0x4
    3b4b:	c8 04 00 00          	enter  0x4,0x0
    3b4f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b55:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3b59:	06                   	push   es
    3b5a:	57                   	push   di
    3b5b:	9a d0 0d 88 3b       	call   0x3b88:0xdd0
    3b60:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3b63:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3b66:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3b69:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3b6c:	c9                   	leave
    3b6d:	ca 06 00             	retf   0x6
    3b70:	55                   	push   bp
    3b71:	89 e5                	mov    bp,sp
    3b73:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b76:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b79:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3b7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b7f:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3b83:	06                   	push   es
    3b84:	57                   	push   di
    3b85:	9a d0 0d 74 3c       	call   0x3c74:0xdd0
    3b8a:	89 c7                	mov    di,ax
    3b8c:	8e c2                	mov    es,dx
    3b8e:	06                   	push   es
    3b8f:	57                   	push   di
    3b90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b93:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3b97:	c9                   	leave
    3b98:	ca 0a 00             	retf   0xa
    3b9b:	c8 0c 00 00          	enter  0xc,0x0
    3b9f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ba2:	06                   	push   es
    3ba3:	57                   	push   di
    3ba4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ba7:	06                   	push   es
    3ba8:	57                   	push   di
    3ba9:	9a 43 3c da 3b       	call   0x3bda:0x3c43
    3bae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3bb1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3bb4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3bb7:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    3bba:	75 20                	jne    0x3bdc
    3bbc:	68 08 f2             	push   0xf208
    3bbf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3bc2:	89 f8                	mov    ax,di
    3bc4:	8c c2                	mov    dx,es
    3bc6:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3bc9:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3bcc:	c6 46 f8 04          	mov    BYTE PTR [bp-0x8],0x4
    3bd0:	8d 7e f4             	lea    di,[bp-0xc]
    3bd3:	16                   	push   ss
    3bd4:	57                   	push   di
    3bd5:	6a 00                	push   0x0
    3bd7:	9a 0a 12 13 3c       	call   0x3c13:0x120a
    3bdc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3bdf:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3be2:	c9                   	leave
    3be3:	ca 08 00             	retf   0x8
    3be6:	c8 08 00 00          	enter  0x8,0x0
    3bea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bed:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3bf1:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3bf5:	48                   	dec    ax
    3bf6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3bf9:	31 c0                	xor    ax,ax
    3bfb:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3bfe:	7f 31                	jg     0x3c31
    3c00:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3c03:	eb 03                	jmp    0x3c08
    3c05:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3c08:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c0e:	06                   	push   es
    3c0f:	57                   	push   di
    3c10:	9a 4b 3b c2 3c       	call   0x3cc2:0x3b4b
    3c15:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c18:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3c1b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c1e:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    3c22:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3c25:	75 02                	jne    0x3c29
    3c27:	eb 10                	jmp    0x3c39
    3c29:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3c2c:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3c2f:	75 d4                	jne    0x3c05
    3c31:	31 c0                	xor    ax,ax
    3c33:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c36:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c39:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c3c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3c3f:	c9                   	leave
    3c40:	ca 06 00             	retf   0x6
    3c43:	c8 08 00 00          	enter  0x8,0x0
    3c47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c4a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3c4e:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3c52:	48                   	dec    ax
    3c53:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3c56:	31 c0                	xor    ax,ax
    3c58:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3c5b:	7f 40                	jg     0x3c9d
    3c5d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3c60:	eb 03                	jmp    0x3c65
    3c62:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3c65:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3c68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c6b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3c6f:	06                   	push   es
    3c70:	57                   	push   di
    3c71:	9a d0 0d 4b 3e       	call   0x3e4b:0xdd0
    3c76:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c79:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3c7c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3c7f:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    3c83:	06                   	push   es
    3c84:	57                   	push   di
    3c85:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c88:	06                   	push   es
    3c89:	57                   	push   di
    3c8a:	9a ed 07 9b 60       	call   0x609b:0x7ed
    3c8f:	09 c0                	or     ax,ax
    3c91:	75 02                	jne    0x3c95
    3c93:	eb 10                	jmp    0x3ca5
    3c95:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3c98:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3c9b:	75 c5                	jne    0x3c62
    3c9d:	31 c0                	xor    ax,ax
    3c9f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ca2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3ca5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3ca8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3cab:	c9                   	leave
    3cac:	ca 08 00             	retf   0x8
    3caf:	c8 08 00 00          	enter  0x8,0x0
    3cb3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3cb6:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    3cba:	75 08                	jne    0x3cc4
    3cbc:	68 24 f2             	push   0xf224
    3cbf:	9a ef 11 d1 3c       	call   0x3cd1:0x11ef
    3cc4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3cc7:	06                   	push   es
    3cc8:	57                   	push   di
    3cc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ccc:	06                   	push   es
    3ccd:	57                   	push   di
    3cce:	9a 43 3c f5 3c       	call   0x3cf5:0x3c43
    3cd3:	09 d0                	or     ax,dx
    3cd5:	74 20                	je     0x3cf7
    3cd7:	68 22 f2             	push   0xf222
    3cda:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3cdd:	89 f8                	mov    ax,di
    3cdf:	8c c2                	mov    dx,es
    3ce1:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3ce4:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3ce7:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    3ceb:	8d 7e f8             	lea    di,[bp-0x8]
    3cee:	16                   	push   ss
    3cef:	57                   	push   di
    3cf0:	6a 00                	push   0x0
    3cf2:	9a 0a 12 17 3d       	call   0x3d17:0x120a
    3cf7:	c9                   	leave
    3cf8:	ca 08 00             	retf   0x8
    3cfb:	c8 0e 00 00          	enter  0xe,0x0
    3cff:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    3d03:	7c 0c                	jl     0x3d11
    3d05:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3d08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d0b:	26 3b 45 7e          	cmp    ax,WORD PTR es:[di+0x7e]
    3d0f:	7c 08                	jl     0x3d19
    3d11:	68 20 f2             	push   0xf220
    3d14:	9a ef 11 36 3d       	call   0x3d36:0x11ef
    3d19:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3d1c:	d1 e0                	shl    ax,1
    3d1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d21:	03 f8                	add    di,ax
    3d23:	26 8b 85 80 00       	mov    ax,WORD PTR es:[di+0x80]
    3d28:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3d2b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3d2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d31:	06                   	push   es
    3d32:	57                   	push   di
    3d33:	9a e6 3b 5a 3d       	call   0x3d5a:0x3be6
    3d38:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3d3b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3d3e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d41:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    3d44:	75 38                	jne    0x3d7e
    3d46:	68 21 f2             	push   0xf221
    3d49:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3d4c:	48                   	dec    ax
    3d4d:	50                   	push   ax
    3d4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d51:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3d55:	06                   	push   es
    3d56:	57                   	push   di
    3d57:	9a 4a 2d 7c 3d       	call   0x3d7c:0x2d4a
    3d5c:	89 c7                	mov    di,ax
    3d5e:	8e c2                	mov    es,dx
    3d60:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    3d64:	89 f8                	mov    ax,di
    3d66:	8c c2                	mov    dx,es
    3d68:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3d6b:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3d6e:	c6 46 f6 04          	mov    BYTE PTR [bp-0xa],0x4
    3d72:	8d 7e f2             	lea    di,[bp-0xe]
    3d75:	16                   	push   ss
    3d76:	57                   	push   di
    3d77:	6a 00                	push   0x0
    3d79:	9a 0a 12 9c 3d       	call   0x3d9c:0x120a
    3d7e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d81:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3d84:	c9                   	leave
    3d85:	ca 06 00             	retf   0x6
    3d88:	55                   	push   bp
    3d89:	89 e5                	mov    bp,sp
    3d8b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d8e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d91:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d97:	06                   	push   es
    3d98:	57                   	push   di
    3d99:	9a fb 3c 66 3e       	call   0x3e66:0x3cfb
    3d9e:	89 c7                	mov    di,ax
    3da0:	8e c2                	mov    es,dx
    3da2:	06                   	push   es
    3da3:	57                   	push   di
    3da4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3da7:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3dab:	c9                   	leave
    3dac:	ca 0a 00             	retf   0xa
    3daf:	c8 02 00 00          	enter  0x2,0x0
    3db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db6:	26 8b 45 7e          	mov    ax,WORD PTR es:[di+0x7e]
    3dba:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3dbd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3dc0:	c9                   	leave
    3dc1:	ca 04 00             	retf   0x4
    3dc4:	c8 04 00 00          	enter  0x4,0x0
    3dc8:	31 c0                	xor    ax,ax
    3dca:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3dcd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3dd0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3dd3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3dd6:	c9                   	leave
    3dd7:	ca 04 00             	retf   0x4
    3dda:	c8 06 00 00          	enter  0x6,0x0
    3dde:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    3de2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3de5:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3de8:	74 41                	je     0x3e2b
    3dea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ded:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    3df1:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    3df5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3df8:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3dfb:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3dfe:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    3e01:	75 02                	jne    0x3e05
    3e03:	eb 26                	jmp    0x3e2b
    3e05:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3e08:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    3e0b:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    3e0e:	75 07                	jne    0x3e17
    3e10:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    3e13:	75 02                	jne    0x3e17
    3e15:	eb 18                	jmp    0x3e2f
    3e17:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e1a:	06                   	push   es
    3e1b:	57                   	push   di
    3e1c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e1f:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    3e23:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    3e26:	89 56 0c             	mov    WORD PTR [bp+0xc],dx
    3e29:	eb b7                	jmp    0x3de2
    3e2b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3e2f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3e32:	c9                   	leave
    3e33:	ca 08 00             	retf   0x8
    3e36:	55                   	push   bp
    3e37:	89 e5                	mov    bp,sp
    3e39:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3e3c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3e3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e42:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    3e46:	06                   	push   es
    3e47:	57                   	push   di
    3e48:	9a 2b 0c 98 3e       	call   0x3e98:0xc2b
    3e4d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3e50:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3e53:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e56:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3e5a:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    3e5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e61:	06                   	push   es
    3e62:	57                   	push   di
    3e63:	9a b5 41 70 3e       	call   0x3e70:0x41b5
    3e68:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e6b:	06                   	push   es
    3e6c:	57                   	push   di
    3e6d:	9a 2d 73 a2 3e       	call   0x3ea2:0x732d
    3e72:	c9                   	leave
    3e73:	ca 08 00             	retf   0x8
    3e76:	55                   	push   bp
    3e77:	89 e5                	mov    bp,sp
    3e79:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e7c:	31 c0                	xor    ax,ax
    3e7e:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3e82:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    3e86:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3e89:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3e8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e8f:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    3e93:	06                   	push   es
    3e94:	57                   	push   di
    3e95:	9a a7 0f ff 41       	call   0x41ff:0xfa7
    3e9a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e9d:	06                   	push   es
    3e9e:	57                   	push   di
    3e9f:	9a 2d 73 ac 3e       	call   0x3eac:0x732d
    3ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ea7:	06                   	push   es
    3ea8:	57                   	push   di
    3ea9:	9a b5 41 ba 3e       	call   0x3eba:0x41b5
    3eae:	c9                   	leave
    3eaf:	ca 08 00             	retf   0x8
    3eb2:	01 00                	add    WORD PTR [bx+si],ax
    3eb4:	00 00                	add    BYTE PTR [bx+si],al
    3eb6:	00 00                	add    BYTE PTR [bx+si],al
    3eb8:	d3 3f                	sar    WORD PTR [bx],cl
    3eba:	43                   	inc    bx
    3ebb:	41                   	inc    cx
    3ebc:	c8 08 00 00          	enter  0x8,0x0
    3ec0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ec3:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    3ec7:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3eca:	75 03                	jne    0x3ecf
    3ecc:	e9 91 01             	jmp    0x4060
    3ecf:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3ed2:	c1 e0 02             	shl    ax,0x2
    3ed5:	50                   	push   ax
    3ed6:	9a 82 01 08 3f       	call   0x3f08:0x182
    3edb:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3ede:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3ee1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ee4:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    3ee8:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    3eeb:	7e 65                	jle    0x3f52
    3eed:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    3ef1:	74 17                	je     0x3f0a
    3ef3:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    3ef7:	06                   	push   es
    3ef8:	57                   	push   di
    3ef9:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3efc:	06                   	push   es
    3efd:	57                   	push   di
    3efe:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3f01:	c1 e0 02             	shl    ax,0x2
    3f04:	50                   	push   ax
    3f05:	9a c1 1e 45 3f       	call   0x3f45:0x1ec1
    3f0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f0d:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    3f11:	48                   	dec    ax
    3f12:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3f15:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3f18:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3f1b:	7f 32                	jg     0x3f4f
    3f1d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f20:	eb 03                	jmp    0x3f25
    3f22:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3f25:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f28:	c1 e0 02             	shl    ax,0x2
    3f2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f2e:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    3f32:	03 f8                	add    di,ax
    3f34:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3f38:	26 ff 35             	push   WORD PTR es:[di]
    3f3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f3e:	26 ff 75 4e          	push   WORD PTR es:[di+0x4e]
    3f42:	9a 9c 01 75 3f       	call   0x3f75:0x19c
    3f47:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f4a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3f4d:	75 d3                	jne    0x3f22
    3f4f:	e9 de 00             	jmp    0x4030
    3f52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f55:	26 83 7d 2a 00       	cmp    WORD PTR es:[di+0x2a],0x0
    3f5a:	74 1b                	je     0x3f77
    3f5c:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    3f60:	06                   	push   es
    3f61:	57                   	push   di
    3f62:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3f65:	06                   	push   es
    3f66:	57                   	push   di
    3f67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f6a:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    3f6e:	c1 e0 02             	shl    ax,0x2
    3f71:	50                   	push   ax
    3f72:	9a c1 1e aa 3f       	call   0x3faa:0x1ec1
    3f77:	b8 b2 3e             	mov    ax,0x3eb2
    3f7a:	0e                   	push   cs
    3f7b:	50                   	push   ax
    3f7c:	55                   	push   bp
    3f7d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3f81:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3f85:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3f88:	48                   	dec    ax
    3f89:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3f8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f8f:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    3f93:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3f96:	7f 32                	jg     0x3fca
    3f98:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f9b:	eb 03                	jmp    0x3fa0
    3f9d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3fa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fa3:	26 ff 75 4e          	push   WORD PTR es:[di+0x4e]
    3fa7:	9a 82 01 0a 40       	call   0x400a:0x182
    3fac:	8b c8                	mov    cx,ax
    3fae:	8b da                	mov    bx,dx
    3fb0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fb3:	c1 e0 02             	shl    ax,0x2
    3fb6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3fb9:	03 f8                	add    di,ax
    3fbb:	26 89 0d             	mov    WORD PTR es:[di],cx
    3fbe:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
    3fc2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fc5:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3fc8:	75 d3                	jne    0x3f9d
    3fca:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3fce:	83 c4 06             	add    sp,0x6
    3fd1:	eb 5d                	jmp    0x4030
    3fd3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fd6:	48                   	dec    ax
    3fd7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3fda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fdd:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    3fe1:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3fe4:	7f 2e                	jg     0x4014
    3fe6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3fe9:	eb 03                	jmp    0x3fee
    3feb:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3fee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ff1:	c1 e0 02             	shl    ax,0x2
    3ff4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ff7:	03 f8                	add    di,ax
    3ff9:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3ffd:	26 ff 35             	push   WORD PTR es:[di]
    4000:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4003:	26 ff 75 4e          	push   WORD PTR es:[di+0x4e]
    4007:	9a 9c 01 24 40       	call   0x4024:0x19c
    400c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    400f:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4012:	75 d7                	jne    0x3feb
    4014:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4017:	ff 76 fa             	push   WORD PTR [bp-0x6]
    401a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    401d:	c1 e0 02             	shl    ax,0x2
    4020:	50                   	push   ax
    4021:	9a 9c 01 29 40       	call   0x4029:0x19c
    4026:	ea 85 13 2e 40       	jmp    0x402e:0x1385
    402b:	9a 34 14 46 40       	call   0x4046:0x1434
    4030:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4033:	26 ff 75 28          	push   WORD PTR es:[di+0x28]
    4037:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    403b:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    403f:	c1 e0 02             	shl    ax,0x2
    4042:	50                   	push   ax
    4043:	9a 9c 01 c7 42       	call   0x42c7:0x19c
    4048:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    404b:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    404e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4051:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    4055:	26 89 55 28          	mov    WORD PTR es:[di+0x28],dx
    4059:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    405c:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    4060:	c9                   	leave
    4061:	ca 06 00             	retf   0x6
    4064:	c8 04 00 00          	enter  0x4,0x0
    4068:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    406c:	74 3a                	je     0x40a8
    406e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4071:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4075:	26 8b 45 52          	mov    ax,WORD PTR es:[di+0x52]
    4079:	26 8b 55 54          	mov    dx,WORD PTR es:[di+0x54]
    407d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4080:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4083:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4086:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    4089:	74 1d                	je     0x40a8
    408b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    408e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4091:	26 01 45 0e          	add    WORD PTR es:[di+0xe],ax
    4095:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4098:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    409c:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    40a0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    40a3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    40a6:	eb db                	jmp    0x4083
    40a8:	c9                   	leave
    40a9:	c2 04 00             	ret    0x4
    40ac:	c8 0a 00 00          	enter  0xa,0x0
    40b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b3:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    40b7:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    40ba:	75 03                	jne    0x40bf
    40bc:	e9 f2 00             	jmp    0x41b1
    40bf:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    40c3:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    40c6:	7f 03                	jg     0x40cb
    40c8:	e9 b7 00             	jmp    0x4182
    40cb:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    40d0:	7f 03                	jg     0x40d5
    40d2:	e9 ad 00             	jmp    0x4182
    40d5:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    40d9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    40dc:	26 8b 45 52          	mov    ax,WORD PTR es:[di+0x52]
    40e0:	26 8b 55 54          	mov    dx,WORD PTR es:[di+0x54]
    40e4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    40e7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    40ea:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    40ed:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    40f0:	74 29                	je     0x411b
    40f2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    40f5:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    40f9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    40fc:	7d 0a                	jge    0x4108
    40fe:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4101:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4105:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4108:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    410b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    410f:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    4113:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4116:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    4119:	eb cf                	jmp    0x40ea
    411b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    411e:	48                   	dec    ax
    411f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4122:	31 c0                	xor    ax,ax
    4124:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    4127:	7f 24                	jg     0x414d
    4129:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    412c:	eb 03                	jmp    0x4131
    412e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4131:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4134:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    4137:	50                   	push   ax
    4138:	ff 76 fe             	push   WORD PTR [bp-0x2]
    413b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    413e:	06                   	push   es
    413f:	57                   	push   di
    4140:	9a ee 44 8f 41       	call   0x418f:0x44ee
    4145:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4148:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    414b:	75 e1                	jne    0x412e
    414d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4150:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4153:	26 29 45 30          	sub    WORD PTR es:[di+0x30],ax
    4157:	26 83 7d 32 ff       	cmp    WORD PTR es:[di+0x32],0xffff
    415c:	74 07                	je     0x4165
    415e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4161:	26 29 45 32          	sub    WORD PTR es:[di+0x32],ax
    4165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4168:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    416c:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    416f:	7e 07                	jle    0x4178
    4171:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4174:	26 89 45 2e          	mov    WORD PTR es:[di+0x2e],ax
    4178:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    417b:	f7 d8                	neg    ax
    417d:	50                   	push   ax
    417e:	55                   	push   bp
    417f:	e8 e2 fe             	call   0x4064
    4182:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4185:	40                   	inc    ax
    4186:	50                   	push   ax
    4187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    418a:	06                   	push   es
    418b:	57                   	push   di
    418c:	9a bc 3e a0 41       	call   0x41a0:0x3ebc
    4191:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4194:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4197:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    419b:	06                   	push   es
    419c:	57                   	push   di
    419d:	9a 78 4a aa 41       	call   0x41aa:0x4a78
    41a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41a5:	06                   	push   es
    41a6:	57                   	push   di
    41a7:	9a cb 4a 8e 42       	call   0x428e:0x4acb
    41ac:	50                   	push   ax
    41ad:	55                   	push   bp
    41ae:	e8 b3 fe             	call   0x4064
    41b1:	c9                   	leave
    41b2:	ca 06 00             	retf   0x6
    41b5:	c8 0e 00 00          	enter  0xe,0x0
    41b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41bc:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    41c0:	26 0b 45 36          	or     ax,WORD PTR es:[di+0x36]
    41c4:	75 03                	jne    0x41c9
    41c6:	e9 c7 00             	jmp    0x4290
    41c9:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    41ce:	31 c0                	xor    ax,ax
    41d0:	26 89 45 52          	mov    WORD PTR es:[di+0x52],ax
    41d4:	26 89 45 54          	mov    WORD PTR es:[di+0x54],ax
    41d8:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    41dc:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    41e0:	48                   	dec    ax
    41e1:	09 c0                	or     ax,ax
    41e3:	7d 03                	jge    0x41e8
    41e5:	e9 9b 00             	jmp    0x4283
    41e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    41eb:	eb 03                	jmp    0x41f0
    41ed:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    41f0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    41f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41f6:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    41fa:	06                   	push   es
    41fb:	57                   	push   di
    41fc:	9a d0 0d 2f 42       	call   0x422f:0xdd0
    4201:	89 c7                	mov    di,ax
    4203:	8e c2                	mov    es,dx
    4205:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    4208:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    420b:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    420f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4213:	48                   	dec    ax
    4214:	09 c0                	or     ax,ax
    4216:	7c 62                	jl     0x427a
    4218:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    421b:	eb 03                	jmp    0x4220
    421d:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    4220:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4223:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4226:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    422a:	06                   	push   es
    422b:	57                   	push   di
    422c:	9a d0 0d e5 43       	call   0x43e5:0xdd0
    4231:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4234:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4237:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    423a:	26 8b 45 52          	mov    ax,WORD PTR es:[di+0x52]
    423e:	26 8b 55 54          	mov    dx,WORD PTR es:[di+0x54]
    4242:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4245:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4249:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    424d:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    4250:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    4253:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4256:	26 89 45 52          	mov    WORD PTR es:[di+0x52],ax
    425a:	26 89 55 54          	mov    WORD PTR es:[di+0x54],dx
    425e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4261:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4265:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    4268:	7e 0a                	jle    0x4274
    426a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    426d:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4271:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4274:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    4278:	75 a3                	jne    0x421d
    427a:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    427e:	74 03                	je     0x4283
    4280:	e9 6a ff             	jmp    0x41ed
    4283:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4286:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4289:	06                   	push   es
    428a:	57                   	push   di
    428b:	9a ac 40 64 43       	call   0x4364:0x40ac
    4290:	c9                   	leave
    4291:	ca 04 00             	retf   0x4
    4294:	55                   	push   bp
    4295:	89 e5                	mov    bp,sp
    4297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    429a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    429e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    42a2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    42a5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    42a8:	9a cd 07 01 43       	call   0x4301:0x7cd
    42ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b0:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    42b4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    42b7:	03 f8                	add    di,ax
    42b9:	06                   	push   es
    42ba:	57                   	push   di
    42bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42be:	26 ff 75 4c          	push   WORD PTR es:[di+0x4c]
    42c2:	6a 00                	push   0x0
    42c4:	9a e5 1e e6 42       	call   0x42e6:0x1ee5
    42c9:	c9                   	leave
    42ca:	ca 08 00             	retf   0x8
    42cd:	c8 04 00 00          	enter  0x4,0x0
    42d1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    42d4:	06                   	push   es
    42d5:	57                   	push   di
    42d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42d9:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    42dd:	05 04 00             	add    ax,0x4
    42e0:	50                   	push   ax
    42e1:	6a 00                	push   0x0
    42e3:	9a e5 1e 7b 43       	call   0x437b:0x1ee5
    42e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42eb:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    42ef:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    42f3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    42f6:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    42f9:	05 04 00             	add    ax,0x4
    42fc:	52                   	push   dx
    42fd:	50                   	push   ax
    42fe:	9a cd 07 ec 46       	call   0x46ec:0x7cd
    4303:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4306:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4309:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    430c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    430f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4312:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4315:	c9                   	leave
    4316:	ca 08 00             	retf   0x8
    4319:	c8 04 00 00          	enter  0x4,0x0
    431d:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    4320:	3c 00                	cmp    al,0x0
    4322:	75 73                	jne    0x4397
    4324:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4327:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    432c:	75 08                	jne    0x4336
    432e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4331:	26 c6 45 3e 01       	mov    BYTE PTR es:[di+0x3e],0x1
    4336:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4339:	26 80 7d 3a 04       	cmp    BYTE PTR es:[di+0x3a],0x4
    433e:	74 55                	je     0x4395
    4340:	26 83 7d 4c 00       	cmp    WORD PTR es:[di+0x4c],0x0
    4345:	74 42                	je     0x4389
    4347:	26 80 7d 3b 00       	cmp    BYTE PTR es:[di+0x3b],0x0
    434c:	74 3b                	je     0x4389
    434e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4351:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    4356:	75 31                	jne    0x4389
    4358:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    435b:	26 ff 75 46          	push   WORD PTR es:[di+0x46]
    435f:	06                   	push   es
    4360:	57                   	push   di
    4361:	9a a7 45 f0 43       	call   0x43f0:0x45a7
    4366:	89 c7                	mov    di,ax
    4368:	8e c2                	mov    es,dx
    436a:	58                   	pop    ax
    436b:	03 f8                	add    di,ax
    436d:	06                   	push   es
    436e:	57                   	push   di
    436f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4372:	26 ff 75 4c          	push   WORD PTR es:[di+0x4c]
    4376:	6a 00                	push   0x0
    4378:	9a e5 1e 51 45       	call   0x4551:0x1ee5
    437d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4380:	06                   	push   es
    4381:	57                   	push   di
    4382:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4385:	26 ff 5d 74          	call   DWORD PTR es:[di+0x74]
    4389:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    438c:	06                   	push   es
    438d:	57                   	push   di
    438e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4391:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    4395:	eb 10                	jmp    0x43a7
    4397:	3c 08                	cmp    al,0x8
    4399:	75 0c                	jne    0x43a7
    439b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    439e:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    43a2:	26 c6 45 0c 00       	mov    BYTE PTR es:[di+0xc],0x0
    43a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43aa:	26 83 7d 50 00       	cmp    WORD PTR es:[di+0x50],0x0
    43af:	75 6e                	jne    0x441f
    43b1:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    43b5:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    43b9:	48                   	dec    ax
    43ba:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    43bd:	31 c0                	xor    ax,ax
    43bf:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    43c2:	7f 36                	jg     0x43fa
    43c4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    43c7:	eb 03                	jmp    0x43cc
    43c9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    43cc:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    43cf:	50                   	push   ax
    43d0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    43d3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    43d6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    43d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43dc:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    43e0:	06                   	push   es
    43e1:	57                   	push   di
    43e2:	9a d0 0d 24 54       	call   0x5424:0xdd0
    43e7:	89 c7                	mov    di,ax
    43e9:	8e c2                	mov    es,dx
    43eb:	06                   	push   es
    43ec:	57                   	push   di
    43ed:	9a 2e 75 d6 44       	call   0x44d6:0x752e
    43f2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    43f5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    43f8:	75 cf                	jne    0x43c9
    43fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43fd:	26 8b 45 5a          	mov    ax,WORD PTR es:[di+0x5a]
    4401:	26 0b 45 5c          	or     ax,WORD PTR es:[di+0x5c]
    4405:	74 16                	je     0x441d
    4407:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    440a:	50                   	push   ax
    440b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    440e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4411:	26 c4 7d 5a          	les    di,DWORD PTR es:[di+0x5a]
    4415:	06                   	push   es
    4416:	57                   	push   di
    4417:	26 c4 3d             	les    di,DWORD PTR es:[di]
    441a:	26 ff 1d             	call   DWORD PTR es:[di]
    441d:	eb 1e                	jmp    0x443d
    441f:	80 7e 0e 06          	cmp    BYTE PTR [bp+0xe],0x6
    4423:	75 0a                	jne    0x442f
    4425:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4428:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    442d:	74 06                	je     0x4435
    442f:	80 7e 0e 04          	cmp    BYTE PTR [bp+0xe],0x4
    4433:	75 08                	jne    0x443d
    4435:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4438:	26 c6 45 42 04       	mov    BYTE PTR es:[di+0x42],0x4
    443d:	c9                   	leave
    443e:	ca 0a 00             	retf   0xa
    4441:	55                   	push   bp
    4442:	89 e5                	mov    bp,sp
    4444:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4447:	26 83 7d 50 00       	cmp    WORD PTR es:[di+0x50],0x0
    444c:	75 0d                	jne    0x445b
    444e:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    4452:	26 88 45 41          	mov    BYTE PTR es:[di+0x41],al
    4456:	26 c6 45 42 02       	mov    BYTE PTR es:[di+0x42],0x2
    445b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    445e:	26 ff 45 50          	inc    WORD PTR es:[di+0x50]
    4462:	c9                   	leave
    4463:	ca 04 00             	retf   0x4
    4466:	55                   	push   bp
    4467:	89 e5                	mov    bp,sp
    4469:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    446c:	26 83 7d 50 00       	cmp    WORD PTR es:[di+0x50],0x0
    4471:	74 47                	je     0x44ba
    4473:	26 ff 4d 50          	dec    WORD PTR es:[di+0x50]
    4477:	26 83 7d 50 00       	cmp    WORD PTR es:[di+0x50],0x0
    447c:	75 3c                	jne    0x44ba
    447e:	26 8a 45 41          	mov    al,BYTE PTR es:[di+0x41]
    4482:	26 3a 45 3a          	cmp    al,BYTE PTR es:[di+0x3a]
    4486:	74 0f                	je     0x4497
    4488:	6a 06                	push   0x6
    448a:	6a 00                	push   0x0
    448c:	6a 00                	push   0x0
    448e:	06                   	push   es
    448f:	57                   	push   di
    4490:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4493:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4497:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    449a:	26 80 7d 41 00       	cmp    BYTE PTR es:[di+0x41],0x0
    449f:	74 19                	je     0x44ba
    44a1:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    44a6:	74 12                	je     0x44ba
    44a8:	26 8a 45 42          	mov    al,BYTE PTR es:[di+0x42]
    44ac:	50                   	push   ax
    44ad:	6a 00                	push   0x0
    44af:	6a 00                	push   0x0
    44b1:	06                   	push   es
    44b2:	57                   	push   di
    44b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44b6:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    44ba:	c9                   	leave
    44bb:	ca 04 00             	retf   0x4
    44be:	55                   	push   bp
    44bf:	89 e5                	mov    bp,sp
    44c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c4:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    44c8:	3c 02                	cmp    al,0x2
    44ca:	72 04                	jb     0x44d0
    44cc:	3c 04                	cmp    al,0x4
    44ce:	76 08                	jbe    0x44d8
    44d0:	68 12 f2             	push   0xf212
    44d3:	9a ef 11 22 46       	call   0x4622:0x11ef
    44d8:	6a 05                	push   0x5
    44da:	6a 00                	push   0x0
    44dc:	6a 00                	push   0x0
    44de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44e1:	06                   	push   es
    44e2:	57                   	push   di
    44e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44e6:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    44ea:	c9                   	leave
    44eb:	ca 04 00             	retf   0x4
    44ee:	c8 04 00 00          	enter  0x4,0x0
    44f2:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    44f5:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    44f8:	75 03                	jne    0x44fd
    44fa:	e9 a6 00             	jmp    0x45a3
    44fd:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    4500:	c1 e0 02             	shl    ax,0x2
    4503:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4506:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    450a:	03 f8                	add    di,ax
    450c:	26 8b 05             	mov    ax,WORD PTR es:[di]
    450f:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    4513:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4516:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4519:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    451c:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    451f:	7d 34                	jge    0x4555
    4521:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    4524:	40                   	inc    ax
    4525:	c1 e0 02             	shl    ax,0x2
    4528:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    452b:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    452f:	03 f8                	add    di,ax
    4531:	06                   	push   es
    4532:	57                   	push   di
    4533:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    4536:	c1 e0 02             	shl    ax,0x2
    4539:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    453c:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    4540:	03 f8                	add    di,ax
    4542:	06                   	push   es
    4543:	57                   	push   di
    4544:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4547:	2b 46 0c             	sub    ax,WORD PTR [bp+0xc]
    454a:	c1 e0 02             	shl    ax,0x2
    454d:	50                   	push   ax
    454e:	9a c1 1e 85 45       	call   0x4585:0x1ec1
    4553:	eb 32                	jmp    0x4587
    4555:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4558:	c1 e0 02             	shl    ax,0x2
    455b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    455e:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    4562:	03 f8                	add    di,ax
    4564:	06                   	push   es
    4565:	57                   	push   di
    4566:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4569:	40                   	inc    ax
    456a:	c1 e0 02             	shl    ax,0x2
    456d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4570:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    4574:	03 f8                	add    di,ax
    4576:	06                   	push   es
    4577:	57                   	push   di
    4578:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    457b:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    457e:	c1 e0 02             	shl    ax,0x2
    4581:	50                   	push   ax
    4582:	9a c1 1e 82 46       	call   0x4682:0x1ec1
    4587:	8b 4e fc             	mov    cx,WORD PTR [bp-0x4]
    458a:	8b 5e fe             	mov    bx,WORD PTR [bp-0x2]
    458d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4590:	c1 e0 02             	shl    ax,0x2
    4593:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4596:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    459a:	03 f8                	add    di,ax
    459c:	26 89 0d             	mov    WORD PTR es:[di],cx
    459f:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
    45a3:	c9                   	leave
    45a4:	ca 08 00             	retf   0x8
    45a7:	c8 04 00 00          	enter  0x4,0x0
    45ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45ae:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    45b2:	c1 e0 02             	shl    ax,0x2
    45b5:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    45b9:	03 f8                	add    di,ax
    45bb:	26 8b 05             	mov    ax,WORD PTR es:[di]
    45be:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    45c2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    45c5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    45c8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    45cb:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    45ce:	c9                   	leave
    45cf:	ca 04 00             	retf   0x4
    45d2:	55                   	push   bp
    45d3:	89 e5                	mov    bp,sp
    45d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45d8:	31 c0                	xor    ax,ax
    45da:	26 89 45 2e          	mov    WORD PTR es:[di+0x2e],ax
    45de:	31 c0                	xor    ax,ax
    45e0:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    45e4:	26 c7 45 32 ff ff    	mov    WORD PTR es:[di+0x32],0xffff
    45ea:	26 c6 45 38 01       	mov    BYTE PTR es:[di+0x38],0x1
    45ef:	26 c6 45 39 01       	mov    BYTE PTR es:[di+0x39],0x1
    45f4:	c9                   	leave
    45f5:	ca 04 00             	retf   0x4
    45f8:	55                   	push   bp
    45f9:	89 e5                	mov    bp,sp
    45fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45fe:	26 c7 45 2e 01 00    	mov    WORD PTR es:[di+0x2e],0x1
    4604:	31 c0                	xor    ax,ax
    4606:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    460a:	31 c0                	xor    ax,ax
    460c:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    4610:	26 c6 45 38 00       	mov    BYTE PTR es:[di+0x38],0x0
    4615:	26 c6 45 39 00       	mov    BYTE PTR es:[di+0x39],0x0
    461a:	c9                   	leave
    461b:	ca 04 00             	retf   0x4
    461e:	00 00                	add    BYTE PTR [bx+si],al
    4620:	9c                   	pushf
    4621:	46                   	inc    si
    4622:	53                   	push   bx
    4623:	47                   	inc    di
    4624:	c8 02 00 00          	enter  0x2,0x0
    4628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    462b:	26 83 7d 4c 00       	cmp    WORD PTR es:[di+0x4c],0x0
    4630:	74 75                	je     0x46a7
    4632:	b8 1e 46             	mov    ax,0x461e
    4635:	0e                   	push   cs
    4636:	50                   	push   ax
    4637:	55                   	push   bp
    4638:	ff 36 58 18          	push   WORD PTR ds:0x1858
    463c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4640:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    4644:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4647:	26 c6 45 3a 05       	mov    BYTE PTR es:[di+0x3a],0x5
    464c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    464f:	c1 e0 02             	shl    ax,0x2
    4652:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    4656:	03 f8                	add    di,ax
    4658:	26 8b 05             	mov    ax,WORD PTR es:[di]
    465b:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    465f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4662:	26 89 45 7a          	mov    WORD PTR es:[di+0x7a],ax
    4666:	26 89 55 7c          	mov    WORD PTR es:[di+0x7c],dx
    466a:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    466e:	26 c4 7d 7a          	les    di,DWORD PTR es:[di+0x7a]
    4672:	03 f8                	add    di,ax
    4674:	06                   	push   es
    4675:	57                   	push   di
    4676:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4679:	26 ff 75 4c          	push   WORD PTR es:[di+0x4c]
    467d:	6a 00                	push   0x0
    467f:	9a e5 1e b8 4a       	call   0x4ab8:0x1ee5
    4684:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4687:	06                   	push   es
    4688:	57                   	push   di
    4689:	26 c4 3d             	les    di,DWORD PTR es:[di]
    468c:	26 ff 5d 74          	call   DWORD PTR es:[di+0x74]
    4690:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4694:	83 c4 06             	add    sp,0x6
    4697:	b8 a7 46             	mov    ax,0x46a7
    469a:	0e                   	push   cs
    469b:	50                   	push   ax
    469c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    469f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46a2:	26 88 45 3a          	mov    BYTE PTR es:[di+0x3a],al
    46a6:	cb                   	retf
    46a7:	c9                   	leave
    46a8:	ca 06 00             	retf   0x6
    46ab:	c8 06 00 00          	enter  0x6,0x0
    46af:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    46b2:	c1 e0 02             	shl    ax,0x2
    46b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46b8:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    46bc:	03 f8                	add    di,ax
    46be:	26 8b 05             	mov    ax,WORD PTR es:[di]
    46c1:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    46c5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    46c8:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    46cb:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    46ce:	3c 00                	cmp    al,0x0
    46d0:	75 21                	jne    0x46f3
    46d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46d5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    46d9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    46dd:	6a 00                	push   0x0
    46df:	ff 76 fc             	push   WORD PTR [bp-0x4]
    46e2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    46e5:	6a 00                	push   0x0
    46e7:	6a 00                	push   0x0
    46e9:	9a 0d 01 11 47       	call   0x4711:0x10d
    46ee:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    46f1:	eb 4f                	jmp    0x4742
    46f3:	3c 01                	cmp    al,0x1
    46f5:	75 21                	jne    0x4718
    46f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46fa:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    46fe:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4702:	6a 00                	push   0x0
    4704:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4707:	ff 76 fa             	push   WORD PTR [bp-0x6]
    470a:	6a 00                	push   0x0
    470c:	6a 00                	push   0x0
    470e:	9a ed 00 36 47       	call   0x4736:0xed
    4713:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4716:	eb 2a                	jmp    0x4742
    4718:	3c 02                	cmp    al,0x2
    471a:	75 21                	jne    0x473d
    471c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    471f:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4723:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4727:	6a 00                	push   0x0
    4729:	ff 76 fc             	push   WORD PTR [bp-0x4]
    472c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    472f:	6a 00                	push   0x0
    4731:	6a 00                	push   0x0
    4733:	9a fd 00 82 47       	call   0x4782:0xfd
    4738:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    473b:	eb 05                	jmp    0x4742
    473d:	31 c0                	xor    ax,ax
    473f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4742:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4746:	75 42                	jne    0x478a
    4748:	ff 76 0c             	push   WORD PTR [bp+0xc]
    474b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    474e:	06                   	push   es
    474f:	57                   	push   di
    4750:	9a 24 46 88 47       	call   0x4788:0x4624
    4755:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4758:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    475c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    475f:	03 f8                	add    di,ax
    4761:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    4765:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4768:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    476c:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4770:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4773:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    4776:	26 03 45 4a          	add    ax,WORD PTR es:[di+0x4a]
    477a:	05 01 00             	add    ax,0x1
    477d:	52                   	push   dx
    477e:	50                   	push   ax
    477f:	9a 8d 07 ed 47       	call   0x47ed:0x78d
    4784:	50                   	push   ax
    4785:	9a 4e 12 f3 47       	call   0x47f3:0x124e
    478a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    478d:	c9                   	leave
    478e:	ca 08 00             	retf   0x8
    4791:	c8 04 00 00          	enter  0x4,0x0
    4795:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4798:	26 8b 45 32          	mov    ax,WORD PTR es:[di+0x32]
    479c:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    479f:	75 03                	jne    0x47a4
    47a1:	e9 93 00             	jmp    0x4837
    47a4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    47a7:	c1 e0 02             	shl    ax,0x2
    47aa:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    47ae:	03 f8                	add    di,ax
    47b0:	26 8b 05             	mov    ax,WORD PTR es:[di]
    47b3:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    47b7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    47ba:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    47bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47c0:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    47c4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    47c7:	03 f8                	add    di,ax
    47c9:	26 8a 05             	mov    al,BYTE PTR es:[di]
    47cc:	3c 00                	cmp    al,0x0
    47ce:	75 27                	jne    0x47f7
    47d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47d3:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    47d7:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    47db:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    47de:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    47e1:	26 03 45 4a          	add    ax,WORD PTR es:[di+0x4a]
    47e5:	05 01 00             	add    ax,0x1
    47e8:	52                   	push   dx
    47e9:	50                   	push   ax
    47ea:	9a 9d 07 09 48       	call   0x4809:0x79d
    47ef:	50                   	push   ax
    47f0:	9a 4e 12 0f 48       	call   0x480f:0x124e
    47f5:	eb 36                	jmp    0x482d
    47f7:	3c 01                	cmp    al,0x1
    47f9:	75 18                	jne    0x4813
    47fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47fe:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4802:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4806:	9a bd 00 25 48       	call   0x4825:0xbd
    480b:	50                   	push   ax
    480c:	9a 4e 12 2b 48       	call   0x482b:0x124e
    4811:	eb 1a                	jmp    0x482d
    4813:	3c 02                	cmp    al,0x2
    4815:	75 16                	jne    0x482d
    4817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    481a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    481e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4822:	9a cd 00 bd 48       	call   0x48bd:0xcd
    4827:	50                   	push   ax
    4828:	9a 4e 12 51 48       	call   0x4851:0x124e
    482d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4830:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4833:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    4837:	c9                   	leave
    4838:	ca 06 00             	retf   0x6
    483b:	55                   	push   bp
    483c:	89 e5                	mov    bp,sp
    483e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4841:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    4846:	7e 0b                	jle    0x4853
    4848:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    484c:	06                   	push   es
    484d:	57                   	push   di
    484e:	9a 91 47 18 49       	call   0x4918:0x4791
    4853:	c9                   	leave
    4854:	ca 04 00             	retf   0x4
    4857:	55                   	push   bp
    4858:	89 e5                	mov    bp,sp
    485a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    485d:	26 c7 45 32 ff ff    	mov    WORD PTR es:[di+0x32],0xffff
    4863:	c9                   	leave
    4864:	ca 04 00             	retf   0x4
    4867:	c8 02 00 00          	enter  0x2,0x0
    486b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    486f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4872:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    4876:	3c 01                	cmp    al,0x1
    4878:	72 7a                	jb     0x48f4
    487a:	3c 02                	cmp    al,0x2
    487c:	77 76                	ja     0x48f4
    487e:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    4882:	26 3b 45 2e          	cmp    ax,WORD PTR es:[di+0x2e]
    4886:	7d 6c                	jge    0x48f4
    4888:	26 8b 45 32          	mov    ax,WORD PTR es:[di+0x32]
    488c:	26 3b 45 30          	cmp    ax,WORD PTR es:[di+0x30]
    4890:	74 3e                	je     0x48d0
    4892:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4896:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    489a:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    489e:	c1 e0 02             	shl    ax,0x2
    48a1:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    48a5:	03 f8                	add    di,ax
    48a7:	26 8b 05             	mov    ax,WORD PTR es:[di]
    48aa:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    48ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48b1:	26 03 45 4a          	add    ax,WORD PTR es:[di+0x4a]
    48b5:	05 01 00             	add    ax,0x1
    48b8:	52                   	push   dx
    48b9:	50                   	push   ax
    48ba:	9a 9d 07 ea 48       	call   0x48ea:0x79d
    48bf:	09 c0                	or     ax,ax
    48c1:	74 02                	je     0x48c5
    48c3:	eb 2f                	jmp    0x48f4
    48c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48c8:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    48cc:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    48d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48d3:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    48d7:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    48db:	6a 00                	push   0x0
    48dd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    48e0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    48e3:	6a 00                	push   0x0
    48e5:	6a 00                	push   0x0
    48e7:	9a 0d 01 00 4d       	call   0x4d00:0x10d
    48ec:	09 c0                	or     ax,ax
    48ee:	75 04                	jne    0x48f4
    48f0:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    48f4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    48f7:	c9                   	leave
    48f8:	ca 08 00             	retf   0x8
    48fb:	c8 04 00 00          	enter  0x4,0x0
    48ff:	c6 46 fe 01          	mov    BYTE PTR [bp-0x2],0x1
    4903:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4906:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    490b:	7e 3d                	jle    0x494a
    490d:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4911:	48                   	dec    ax
    4912:	50                   	push   ax
    4913:	06                   	push   es
    4914:	57                   	push   di
    4915:	9a 91 47 37 49       	call   0x4937:0x4791
    491a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    491d:	26 80 7d 3a 03       	cmp    BYTE PTR es:[di+0x3a],0x3
    4922:	75 26                	jne    0x494a
    4924:	26 8b 45 32          	mov    ax,WORD PTR es:[di+0x32]
    4928:	26 3b 45 30          	cmp    ax,WORD PTR es:[di+0x30]
    492c:	75 1c                	jne    0x494a
    492e:	26 ff 75 4a          	push   WORD PTR es:[di+0x4a]
    4932:	06                   	push   es
    4933:	57                   	push   di
    4934:	9a a7 45 5a 49       	call   0x495a:0x45a7
    4939:	89 c7                	mov    di,ax
    493b:	8e c2                	mov    es,dx
    493d:	58                   	pop    ax
    493e:	03 f8                	add    di,ax
    4940:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    4944:	75 04                	jne    0x494a
    4946:	c6 46 fe 00          	mov    BYTE PTR [bp-0x2],0x0
    494a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    494d:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4951:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    4954:	50                   	push   ax
    4955:	06                   	push   es
    4956:	57                   	push   di
    4957:	9a ab 46 76 49       	call   0x4976:0x46ab
    495c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    495f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4962:	3d 00 00             	cmp    ax,0x0
    4965:	75 48                	jne    0x49af
    4967:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    496a:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    496f:	75 09                	jne    0x497a
    4971:	06                   	push   es
    4972:	57                   	push   di
    4973:	9a f8 45 9b 49       	call   0x499b:0x45f8
    4978:	eb 23                	jmp    0x499d
    497a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    497d:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4981:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    4985:	7d 06                	jge    0x498d
    4987:	26 ff 45 2e          	inc    WORD PTR es:[di+0x2e]
    498b:	eb 10                	jmp    0x499d
    498d:	6a 00                	push   0x0
    498f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4992:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4996:	06                   	push   es
    4997:	57                   	push   di
    4998:	9a ee 44 c9 49       	call   0x49c9:0x44ee
    499d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49a0:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    49a4:	48                   	dec    ax
    49a5:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    49a9:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    49ad:	eb 1c                	jmp    0x49cb
    49af:	3d 02 22             	cmp    ax,0x2202
    49b2:	75 0f                	jne    0x49c3
    49b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49b7:	26 c7 45 32 ff ff    	mov    WORD PTR es:[di+0x32],0xffff
    49bd:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    49c1:	eb 08                	jmp    0x49cb
    49c3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    49c6:	9a 2d 12 e7 49       	call   0x49e7:0x122d
    49cb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    49ce:	c9                   	leave
    49cf:	ca 04 00             	retf   0x4
    49d2:	c8 08 00 00          	enter  0x8,0x0
    49d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49d9:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    49de:	7e 09                	jle    0x49e9
    49e0:	6a 00                	push   0x0
    49e2:	06                   	push   es
    49e3:	57                   	push   di
    49e4:	9a 91 47 f7 49       	call   0x49f7:0x4791
    49e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49ec:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    49f0:	6a 02                	push   0x2
    49f2:	06                   	push   es
    49f3:	57                   	push   di
    49f4:	9a ab 46 13 4a       	call   0x4a13:0x46ab
    49f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    49fc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    49ff:	3d 00 00             	cmp    ax,0x0
    4a02:	75 47                	jne    0x4a4b
    4a04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a07:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    4a0c:	75 09                	jne    0x4a17
    4a0e:	06                   	push   es
    4a0f:	57                   	push   di
    4a10:	9a f8 45 25 4a       	call   0x4a25:0x45f8
    4a15:	eb 25                	jmp    0x4a3c
    4a17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a1a:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4a1e:	6a 00                	push   0x0
    4a20:	06                   	push   es
    4a21:	57                   	push   di
    4a22:	9a ee 44 65 4a       	call   0x4a65:0x44ee
    4a27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a2a:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4a2e:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    4a32:	7d 08                	jge    0x4a3c
    4a34:	26 ff 45 2e          	inc    WORD PTR es:[di+0x2e]
    4a38:	26 ff 45 30          	inc    WORD PTR es:[di+0x30]
    4a3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a3f:	31 c0                	xor    ax,ax
    4a41:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    4a45:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    4a49:	eb 1c                	jmp    0x4a67
    4a4b:	3d 01 22             	cmp    ax,0x2201
    4a4e:	75 0f                	jne    0x4a5f
    4a50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a53:	26 c7 45 32 ff ff    	mov    WORD PTR es:[di+0x32],0xffff
    4a59:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    4a5d:	eb 08                	jmp    0x4a67
    4a5f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4a62:	9a 2d 12 76 4a       	call   0x4a76:0x122d
    4a67:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4a6a:	c9                   	leave
    4a6b:	ca 04 00             	retf   0x4
    4a6e:	01 00                	add    WORD PTR [bx+si],ax
    4a70:	00 00                	add    BYTE PTR [bx+si],al
    4a72:	00 00                	add    BYTE PTR [bx+si],al
    4a74:	b5 4a                	mov    ch,0x4a
    4a76:	a1 4a c8             	mov    ax,ds:0xc84a
    4a79:	02 00                	add    al,BYTE PTR [bx+si]
    4a7b:	00 31                	add    BYTE PTR [bx+di],dh
    4a7d:	c0 89 46 fe b8       	ror    BYTE PTR [bx+di-0x1ba],0xb8
    4a82:	6e                   	outs   dx,BYTE PTR ds:[si]
    4a83:	4a                   	dec    dx
    4a84:	0e                   	push   cs
    4a85:	50                   	push   ax
    4a86:	55                   	push   bp
    4a87:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4a8b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4a8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a92:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4a96:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    4a9a:	7d 10                	jge    0x4aac
    4a9c:	06                   	push   es
    4a9d:	57                   	push   di
    4a9e:	9a fb 48 c9 4a       	call   0x4ac9:0x48fb
    4aa3:	08 c0                	or     al,al
    4aa5:	74 05                	je     0x4aac
    4aa7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4aaa:	eb e3                	jmp    0x4a8f
    4aac:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4ab0:	83 c4 06             	add    sp,0x6
    4ab3:	eb 05                	jmp    0x4aba
    4ab5:	9a 34 14 0b 4b       	call   0x4b0b:0x1434
    4aba:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4abd:	c9                   	leave
    4abe:	ca 04 00             	retf   0x4
    4ac1:	01 00                	add    WORD PTR [bx+si],ax
    4ac3:	00 00                	add    BYTE PTR [bx+si],al
    4ac5:	00 00                	add    BYTE PTR [bx+si],al
    4ac7:	08 4b f4             	or     BYTE PTR [bp+di-0xc],cl
    4aca:	4a                   	dec    dx
    4acb:	c8 02 00 00          	enter  0x2,0x0
    4acf:	31 c0                	xor    ax,ax
    4ad1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ad4:	b8 c1 4a             	mov    ax,0x4ac1
    4ad7:	0e                   	push   cs
    4ad8:	50                   	push   ax
    4ad9:	55                   	push   bp
    4ada:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4ade:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4ae2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ae5:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4ae9:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    4aed:	7d 10                	jge    0x4aff
    4aef:	06                   	push   es
    4af0:	57                   	push   di
    4af1:	9a d2 49 1c 4b       	call   0x4b1c:0x49d2
    4af6:	08 c0                	or     al,al
    4af8:	74 05                	je     0x4aff
    4afa:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4afd:	eb e3                	jmp    0x4ae2
    4aff:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4b03:	83 c4 06             	add    sp,0x6
    4b06:	eb 05                	jmp    0x4b0d
    4b08:	9a 34 14 25 4c       	call   0x4c25:0x1434
    4b0d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b10:	c9                   	leave
    4b11:	ca 04 00             	retf   0x4
    4b14:	01 00                	add    WORD PTR [bx+si],ax
    4b16:	00 00                	add    BYTE PTR [bx+si],al
    4b18:	00 00                	add    BYTE PTR [bx+si],al
    4b1a:	22 4c 3c             	and    cl,BYTE PTR [si+0x3c]
    4b1d:	4b                   	dec    bx
    4b1e:	c8 02 00 00          	enter  0x2,0x0
    4b22:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    4b26:	74 1e                	je     0x4b46
    4b28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b2b:	26 c7 45 32 ff ff    	mov    WORD PTR es:[di+0x32],0xffff
    4b31:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4b35:	6a 00                	push   0x0
    4b37:	06                   	push   es
    4b38:	57                   	push   di
    4b39:	9a ab 46 42 4b       	call   0x4b42:0x46ab
    4b3e:	50                   	push   ax
    4b3f:	9a 4e 12 54 4b       	call   0x4b54:0x124e
    4b44:	eb 5b                	jmp    0x4ba1
    4b46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b49:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4b4d:	6a 00                	push   0x0
    4b4f:	06                   	push   es
    4b50:	57                   	push   di
    4b51:	9a ab 46 68 4b       	call   0x4b68:0x46ab
    4b56:	09 c0                	or     ax,ax
    4b58:	74 47                	je     0x4ba1
    4b5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b5d:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4b61:	6a 01                	push   0x1
    4b63:	06                   	push   es
    4b64:	57                   	push   di
    4b65:	9a ab 46 7c 4b       	call   0x4b7c:0x46ab
    4b6a:	09 c0                	or     ax,ax
    4b6c:	74 33                	je     0x4ba1
    4b6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b71:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4b75:	6a 02                	push   0x2
    4b77:	06                   	push   es
    4b78:	57                   	push   di
    4b79:	9a ab 46 8a 4b       	call   0x4b8a:0x46ab
    4b7e:	09 c0                	or     ax,ax
    4b80:	74 1f                	je     0x4ba1
    4b82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b85:	06                   	push   es
    4b86:	57                   	push   di
    4b87:	9a d2 45 d2 4b       	call   0x4bd2:0x45d2
    4b8c:	6a 02                	push   0x2
    4b8e:	6a 00                	push   0x0
    4b90:	6a 00                	push   0x0
    4b92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b95:	06                   	push   es
    4b96:	57                   	push   di
    4b97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b9a:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4b9e:	e9 98 00             	jmp    0x4c39
    4ba1:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    4ba5:	74 13                	je     0x4bba
    4ba7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4baa:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    4bae:	48                   	dec    ax
    4baf:	99                   	cwd
    4bb0:	b9 02 00             	mov    cx,0x2
    4bb3:	f7 f9                	idiv   cx
    4bb5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4bb8:	eb 0a                	jmp    0x4bc4
    4bba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bbd:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    4bc1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4bc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bc7:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4bcb:	6a 00                	push   0x0
    4bcd:	06                   	push   es
    4bce:	57                   	push   di
    4bcf:	9a ee 44 dc 4b       	call   0x4bdc:0x44ee
    4bd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bd7:	06                   	push   es
    4bd8:	57                   	push   di
    4bd9:	9a f8 45 fa 4b       	call   0x4bfa:0x45f8
    4bde:	b8 14 4b             	mov    ax,0x4b14
    4be1:	0e                   	push   cs
    4be2:	50                   	push   ax
    4be3:	55                   	push   bp
    4be4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4be8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4bec:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4bf0:	7e 13                	jle    0x4c05
    4bf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bf5:	06                   	push   es
    4bf6:	57                   	push   di
    4bf7:	9a d2 49 0d 4c       	call   0x4c0d:0x49d2
    4bfc:	08 c0                	or     al,al
    4bfe:	74 05                	je     0x4c05
    4c00:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    4c03:	eb e7                	jmp    0x4bec
    4c05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c08:	06                   	push   es
    4c09:	57                   	push   di
    4c0a:	9a 78 4a 17 4c       	call   0x4c17:0x4a78
    4c0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c12:	06                   	push   es
    4c13:	57                   	push   di
    4c14:	9a cb 4a 50 4c       	call   0x4c50:0x4acb
    4c19:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4c1d:	83 c4 06             	add    sp,0x6
    4c20:	eb 05                	jmp    0x4c27
    4c22:	9a 34 14 28 50       	call   0x5028:0x1434
    4c27:	6a 02                	push   0x2
    4c29:	6a 00                	push   0x0
    4c2b:	6a 00                	push   0x0
    4c2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c30:	06                   	push   es
    4c31:	57                   	push   di
    4c32:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c35:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4c39:	c9                   	leave
    4c3a:	ca 06 00             	retf   0x6
    4c3d:	55                   	push   bp
    4c3e:	89 e5                	mov    bp,sp
    4c40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c43:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    4c48:	75 08                	jne    0x4c52
    4c4a:	68 05 f2             	push   0xf205
    4c4d:	9a ef 11 7b 4c       	call   0x4c7b:0x11ef
    4c52:	6a 07                	push   0x7
    4c54:	6a 00                	push   0x0
    4c56:	6a 00                	push   0x0
    4c58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c5b:	06                   	push   es
    4c5c:	57                   	push   di
    4c5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c60:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4c64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c67:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    4c6b:	3c 02                	cmp    al,0x2
    4c6d:	74 04                	je     0x4c73
    4c6f:	3c 03                	cmp    al,0x3
    4c71:	75 29                	jne    0x4c9c
    4c73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c76:	06                   	push   es
    4c77:	57                   	push   di
    4c78:	9a be 44 8c 4c       	call   0x4c8c:0x44be
    4c7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c80:	26 80 7d 3e 00       	cmp    BYTE PTR es:[di+0x3e],0x0
    4c85:	74 09                	je     0x4c90
    4c87:	06                   	push   es
    4c88:	57                   	push   di
    4c89:	9a a0 54 98 4c       	call   0x4c98:0x54a0
    4c8e:	eb 0a                	jmp    0x4c9a
    4c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c93:	06                   	push   es
    4c94:	57                   	push   di
    4c95:	9a 8b 55 a8 4c       	call   0x4ca8:0x558b
    4c9a:	eb 0e                	jmp    0x4caa
    4c9c:	3c 04                	cmp    al,0x4
    4c9e:	75 0a                	jne    0x4caa
    4ca0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ca3:	06                   	push   es
    4ca4:	57                   	push   di
    4ca5:	9a a0 54 c1 4c       	call   0x4cc1:0x54a0
    4caa:	c9                   	leave
    4cab:	ca 04 00             	retf   0x4
    4cae:	55                   	push   bp
    4caf:	89 e5                	mov    bp,sp
    4cb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cb4:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    4cb9:	75 08                	jne    0x4cc3
    4cbb:	68 14 f2             	push   0xf214
    4cbe:	9a ef 11 cb 4c       	call   0x4ccb:0x11ef
    4cc3:	c9                   	leave
    4cc4:	ca 04 00             	retf   0x4
    4cc7:	00 00                	add    BYTE PTR [bx+si],al
    4cc9:	28 4d d8             	sub    BYTE PTR [di-0x28],cl
    4ccc:	4c                   	dec    sp
    4ccd:	55                   	push   bp
    4cce:	89 e5                	mov    bp,sp
    4cd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cd3:	06                   	push   es
    4cd4:	57                   	push   di
    4cd5:	9a 3d 4c e2 4c       	call   0x4ce2:0x4c3d
    4cda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cdd:	06                   	push   es
    4cde:	57                   	push   di
    4cdf:	9a d2 45 06 4d       	call   0x4d06:0x45d2
    4ce4:	b8 c7 4c             	mov    ax,0x4cc7
    4ce7:	0e                   	push   cs
    4ce8:	50                   	push   ax
    4ce9:	55                   	push   bp
    4cea:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4cee:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4cf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cf5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4cf9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4cfd:	9a bd 00 7d 4d       	call   0x4d7d:0xbd
    4d02:	50                   	push   ax
    4d03:	9a 4e 12 10 4d       	call   0x4d10:0x124e
    4d08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d0b:	06                   	push   es
    4d0c:	57                   	push   di
    4d0d:	9a fb 48 1a 4d       	call   0x4d1a:0x48fb
    4d12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d15:	06                   	push   es
    4d16:	57                   	push   di
    4d17:	9a 78 4a 48 4d       	call   0x4d48:0x4a78
    4d1c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4d20:	83 c4 06             	add    sp,0x6
    4d23:	b8 40 4d             	mov    ax,0x4d40
    4d26:	0e                   	push   cs
    4d27:	50                   	push   ax
    4d28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d2b:	26 c6 45 38 01       	mov    BYTE PTR es:[di+0x38],0x1
    4d30:	6a 02                	push   0x2
    4d32:	6a 00                	push   0x0
    4d34:	6a 00                	push   0x0
    4d36:	06                   	push   es
    4d37:	57                   	push   di
    4d38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d3b:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4d3f:	cb                   	retf
    4d40:	c9                   	leave
    4d41:	ca 04 00             	retf   0x4
    4d44:	00 00                	add    BYTE PTR [bx+si],al
    4d46:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    4d47:	4d                   	dec    bp
    4d48:	55                   	push   bp
    4d49:	4d                   	dec    bp
    4d4a:	55                   	push   bp
    4d4b:	89 e5                	mov    bp,sp
    4d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d50:	06                   	push   es
    4d51:	57                   	push   di
    4d52:	9a 3d 4c 5f 4d       	call   0x4d5f:0x4c3d
    4d57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d5a:	06                   	push   es
    4d5b:	57                   	push   di
    4d5c:	9a d2 45 83 4d       	call   0x4d83:0x45d2
    4d61:	b8 44 4d             	mov    ax,0x4d44
    4d64:	0e                   	push   cs
    4d65:	50                   	push   ax
    4d66:	55                   	push   bp
    4d67:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4d6b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4d6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d72:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4d76:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4d7a:	9a cd 00 37 4f       	call   0x4f37:0xcd
    4d7f:	50                   	push   ax
    4d80:	9a 4e 12 8d 4d       	call   0x4d8d:0x124e
    4d85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d88:	06                   	push   es
    4d89:	57                   	push   di
    4d8a:	9a d2 49 97 4d       	call   0x4d97:0x49d2
    4d8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d92:	06                   	push   es
    4d93:	57                   	push   di
    4d94:	9a cb 4a c5 4d       	call   0x4dc5:0x4acb
    4d99:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4d9d:	83 c4 06             	add    sp,0x6
    4da0:	b8 bd 4d             	mov    ax,0x4dbd
    4da3:	0e                   	push   cs
    4da4:	50                   	push   ax
    4da5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4da8:	26 c6 45 39 01       	mov    BYTE PTR es:[di+0x39],0x1
    4dad:	6a 02                	push   0x2
    4daf:	6a 00                	push   0x0
    4db1:	6a 00                	push   0x0
    4db3:	06                   	push   es
    4db4:	57                   	push   di
    4db5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4db8:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4dbc:	cb                   	retf
    4dbd:	c9                   	leave
    4dbe:	ca 04 00             	retf   0x4
    4dc1:	00 00                	add    BYTE PTR [bx+si],al
    4dc3:	d3 4e d3             	ror    WORD PTR [bp-0x2d],cl
    4dc6:	4d                   	dec    bp
    4dc7:	c8 04 00 00          	enter  0x4,0x0
    4dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dce:	06                   	push   es
    4dcf:	57                   	push   di
    4dd0:	9a 3d 4c 56 4e       	call   0x4e56:0x4c3d
    4dd5:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    4dd9:	7e 0a                	jle    0x4de5
    4ddb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dde:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    4de3:	74 16                	je     0x4dfb
    4de5:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    4de9:	7c 03                	jl     0x4dee
    4deb:	e9 fa 00             	jmp    0x4ee8
    4dee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4df1:	26 80 7d 38 00       	cmp    BYTE PTR es:[di+0x38],0x0
    4df6:	74 03                	je     0x4dfb
    4df8:	e9 ed 00             	jmp    0x4ee8
    4dfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dfe:	26 c6 45 38 00       	mov    BYTE PTR es:[di+0x38],0x0
    4e03:	26 c6 45 39 00       	mov    BYTE PTR es:[di+0x39],0x0
    4e08:	31 c0                	xor    ax,ax
    4e0a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4e0d:	b8 c1 4d             	mov    ax,0x4dc1
    4e10:	0e                   	push   cs
    4e11:	50                   	push   ax
    4e12:	55                   	push   bp
    4e13:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4e17:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4e1b:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    4e1f:	7e 52                	jle    0x4e73
    4e21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e24:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4e28:	48                   	dec    ax
    4e29:	26 3b 45 30          	cmp    ax,WORD PTR es:[di+0x30]
    4e2d:	7e 06                	jle    0x4e35
    4e2f:	26 ff 45 30          	inc    WORD PTR es:[di+0x30]
    4e33:	eb 39                	jmp    0x4e6e
    4e35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e38:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4e3c:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    4e40:	7d 07                	jge    0x4e49
    4e42:	31 c0                	xor    ax,ax
    4e44:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e47:	eb 05                	jmp    0x4e4e
    4e49:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    4e4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e51:	06                   	push   es
    4e52:	57                   	push   di
    4e53:	9a fb 48 aa 4e       	call   0x4eaa:0x48fb
    4e58:	08 c0                	or     al,al
    4e5a:	74 08                	je     0x4e64
    4e5c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e5f:	29 46 fc             	sub    WORD PTR [bp-0x4],ax
    4e62:	eb 0a                	jmp    0x4e6e
    4e64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e67:	26 c6 45 39 01       	mov    BYTE PTR es:[di+0x39],0x1
    4e6c:	eb 05                	jmp    0x4e73
    4e6e:	ff 4e 0a             	dec    WORD PTR [bp+0xa]
    4e71:	eb a8                	jmp    0x4e1b
    4e73:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    4e77:	7d 4e                	jge    0x4ec7
    4e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e7c:	26 83 7d 30 00       	cmp    WORD PTR es:[di+0x30],0x0
    4e81:	7e 06                	jle    0x4e89
    4e83:	26 ff 4d 30          	dec    WORD PTR es:[di+0x30]
    4e87:	eb 39                	jmp    0x4ec2
    4e89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e8c:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    4e90:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    4e94:	7d 07                	jge    0x4e9d
    4e96:	31 c0                	xor    ax,ax
    4e98:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e9b:	eb 05                	jmp    0x4ea2
    4e9d:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    4ea2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ea5:	06                   	push   es
    4ea6:	57                   	push   di
    4ea7:	9a d2 49 f9 4e       	call   0x4ef9:0x49d2
    4eac:	08 c0                	or     al,al
    4eae:	74 08                	je     0x4eb8
    4eb0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4eb3:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    4eb6:	eb 0a                	jmp    0x4ec2
    4eb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ebb:	26 c6 45 38 01       	mov    BYTE PTR es:[di+0x38],0x1
    4ec0:	eb 05                	jmp    0x4ec7
    4ec2:	ff 46 0a             	inc    WORD PTR [bp+0xa]
    4ec5:	eb ac                	jmp    0x4e73
    4ec7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4ecb:	83 c4 06             	add    sp,0x6
    4ece:	b8 e8 4e             	mov    ax,0x4ee8
    4ed1:	0e                   	push   cs
    4ed2:	50                   	push   ax
    4ed3:	6a 03                	push   0x3
    4ed5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4ed8:	99                   	cwd
    4ed9:	52                   	push   dx
    4eda:	50                   	push   ax
    4edb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ede:	06                   	push   es
    4edf:	57                   	push   di
    4ee0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ee3:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4ee7:	cb                   	retf
    4ee8:	c9                   	leave
    4ee9:	ca 06 00             	retf   0x6
    4eec:	55                   	push   bp
    4eed:	89 e5                	mov    bp,sp
    4eef:	6a 01                	push   0x1
    4ef1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ef4:	06                   	push   es
    4ef5:	57                   	push   di
    4ef6:	9a c7 4d 0c 4f       	call   0x4f0c:0x4dc7
    4efb:	c9                   	leave
    4efc:	ca 04 00             	retf   0x4
    4eff:	55                   	push   bp
    4f00:	89 e5                	mov    bp,sp
    4f02:	6a ff                	push   0xffff
    4f04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f07:	06                   	push   es
    4f08:	57                   	push   di
    4f09:	9a c7 4d 1d 4f       	call   0x4f1d:0x4dc7
    4f0e:	c9                   	leave
    4f0f:	ca 04 00             	retf   0x4
    4f12:	55                   	push   bp
    4f13:	89 e5                	mov    bp,sp
    4f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f18:	06                   	push   es
    4f19:	57                   	push   di
    4f1a:	9a 3d 4c 27 4f       	call   0x4f27:0x4c3d
    4f1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f22:	06                   	push   es
    4f23:	57                   	push   di
    4f24:	9a 3b 48 3d 4f       	call   0x4f3d:0x483b
    4f29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f2c:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4f30:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4f34:	9a bd 03 67 52       	call   0x5267:0x3bd
    4f39:	50                   	push   ax
    4f3a:	9a 4e 12 49 4f       	call   0x4f49:0x124e
    4f3f:	6a 00                	push   0x0
    4f41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f44:	06                   	push   es
    4f45:	57                   	push   di
    4f46:	9a 1e 4b 80 4f       	call   0x4f80:0x4b1e
    4f4b:	c9                   	leave
    4f4c:	ca 04 00             	retf   0x4
    4f4f:	c8 04 00 00          	enter  0x4,0x0
    4f53:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4f56:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4f59:	31 c0                	xor    ax,ax
    4f5b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4f5e:	7f 35                	jg     0x4f95
    4f60:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4f63:	eb 03                	jmp    0x4f68
    4f65:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4f68:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f6b:	c1 e0 03             	shl    ax,0x3
    4f6e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4f71:	03 f8                	add    di,ax
    4f73:	06                   	push   es
    4f74:	57                   	push   di
    4f75:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4f78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f7b:	06                   	push   es
    4f7c:	57                   	push   di
    4f7d:	9a 4b 3b 8b 4f       	call   0x4f8b:0x3b4b
    4f82:	89 c7                	mov    di,ax
    4f84:	8e c2                	mov    es,dx
    4f86:	06                   	push   es
    4f87:	57                   	push   di
    4f88:	9a 77 62 a5 4f       	call   0x4fa5:0x6277
    4f8d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f90:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4f93:	75 d0                	jne    0x4f65
    4f95:	c9                   	leave
    4f96:	ca 0a 00             	retf   0xa
    4f99:	c8 04 00 00          	enter  0x4,0x0
    4f9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fa0:	06                   	push   es
    4fa1:	57                   	push   di
    4fa2:	9a b8 50 b7 4f       	call   0x4fb7:0x50b8
    4fa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4faa:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    4fae:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    4fb2:	06                   	push   es
    4fb3:	57                   	push   di
    4fb4:	9a ee 44 c1 4f       	call   0x4fc1:0x44ee
    4fb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fbc:	06                   	push   es
    4fbd:	57                   	push   di
    4fbe:	9a a7 45 d7 4f       	call   0x4fd7:0x45a7
    4fc3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4fc6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4fc9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4fcc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fd2:	06                   	push   es
    4fd3:	57                   	push   di
    4fd4:	9a 94 42 43 50       	call   0x5043:0x4294
    4fd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fdc:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    4fe1:	75 0f                	jne    0x4ff2
    4fe3:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    4fe7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4fea:	03 f8                	add    di,ax
    4fec:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    4ff0:	eb 38                	jmp    0x502a
    4ff2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ff5:	26 8b 55 4a          	mov    dx,WORD PTR es:[di+0x4a]
    4ff9:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    4ffd:	40                   	inc    ax
    4ffe:	c1 e0 02             	shl    ax,0x2
    5001:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    5005:	03 f8                	add    di,ax
    5007:	26 c4 3d             	les    di,DWORD PTR es:[di]
    500a:	03 fa                	add    di,dx
    500c:	06                   	push   es
    500d:	57                   	push   di
    500e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5011:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    5015:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5018:	03 f8                	add    di,ax
    501a:	06                   	push   es
    501b:	57                   	push   di
    501c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    501f:	26 8b 45 48          	mov    ax,WORD PTR es:[di+0x48]
    5023:	40                   	inc    ax
    5024:	50                   	push   ax
    5025:	9a c1 1e 4a 51       	call   0x514a:0x1ec1
    502a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    502d:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    5031:	26 3b 45 2c          	cmp    ax,WORD PTR es:[di+0x2c]
    5035:	7d 04                	jge    0x503b
    5037:	26 ff 45 2e          	inc    WORD PTR es:[di+0x2e]
    503b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    503e:	06                   	push   es
    503f:	57                   	push   di
    5040:	9a e9 50 55 50       	call   0x5055:0x50e9
    5045:	c9                   	leave
    5046:	ca 04 00             	retf   0x4
    5049:	c8 04 00 00          	enter  0x4,0x0
    504d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5050:	06                   	push   es
    5051:	57                   	push   di
    5052:	9a b8 50 5f 50       	call   0x505f:0x50b8
    5057:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    505a:	06                   	push   es
    505b:	57                   	push   di
    505c:	9a d2 45 83 50       	call   0x5083:0x45d2
    5061:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5064:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    5068:	26 8b 05             	mov    ax,WORD PTR es:[di]
    506b:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    506f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5072:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5075:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5078:	ff 76 fc             	push   WORD PTR [bp-0x4]
    507b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    507e:	06                   	push   es
    507f:	57                   	push   di
    5080:	9a 94 42 a8 50       	call   0x50a8:0x4294
    5085:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5088:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    508c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    508f:	03 f8                	add    di,ax
    5091:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    5095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5098:	26 c7 45 2e 01 00    	mov    WORD PTR es:[di+0x2e],0x1
    509e:	26 c6 45 38 00       	mov    BYTE PTR es:[di+0x38],0x0
    50a3:	06                   	push   es
    50a4:	57                   	push   di
    50a5:	9a cb 4a b2 50       	call   0x50b2:0x4acb
    50aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50ad:	06                   	push   es
    50ae:	57                   	push   di
    50af:	9a e9 50 c3 50       	call   0x50c3:0x50e9
    50b4:	c9                   	leave
    50b5:	ca 04 00             	retf   0x4
    50b8:	55                   	push   bp
    50b9:	89 e5                	mov    bp,sp
    50bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50be:	06                   	push   es
    50bf:	57                   	push   di
    50c0:	9a 3d 4c cd 50       	call   0x50cd:0x4c3d
    50c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50c8:	06                   	push   es
    50c9:	57                   	push   di
    50ca:	9a ae 4c e7 50       	call   0x50e7:0x4cae
    50cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50d2:	06                   	push   es
    50d3:	57                   	push   di
    50d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50d7:	26 ff 5d 68          	call   DWORD PTR es:[di+0x68]
    50db:	c9                   	leave
    50dc:	ca 04 00             	retf   0x4
    50df:	01 00                	add    WORD PTR [bx+si],ax
    50e1:	00 00                	add    BYTE PTR [bx+si],al
    50e3:	00 00                	add    BYTE PTR [bx+si],al
    50e5:	1b 51 f6             	sbb    dx,WORD PTR [bx+di-0xa]
    50e8:	50                   	push   ax
    50e9:	55                   	push   bp
    50ea:	89 e5                	mov    bp,sp
    50ec:	6a 03                	push   0x3
    50ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50f1:	06                   	push   es
    50f2:	57                   	push   di
    50f3:	9a 91 31 23 51       	call   0x5123:0x3191
    50f8:	b8 df 50             	mov    ax,0x50df
    50fb:	0e                   	push   cs
    50fc:	50                   	push   ax
    50fd:	55                   	push   bp
    50fe:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5102:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5109:	06                   	push   es
    510a:	57                   	push   di
    510b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    510e:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    5112:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5116:	83 c4 06             	add    sp,0x6
    5119:	eb 36                	jmp    0x5151
    511b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    511e:	06                   	push   es
    511f:	57                   	push   di
    5120:	9a 3b 48 2d 51       	call   0x512d:0x483b
    5125:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5128:	06                   	push   es
    5129:	57                   	push   di
    512a:	9a 08 3a 39 51       	call   0x5139:0x3a08
    512f:	6a 01                	push   0x1
    5131:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5134:	06                   	push   es
    5135:	57                   	push   di
    5136:	9a 91 31 45 51       	call   0x5145:0x3191
    513b:	6a 00                	push   0x0
    513d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5140:	06                   	push   es
    5141:	57                   	push   di
    5142:	9a 1e 4b 7c 51       	call   0x517c:0x4b1e
    5147:	ea 85 13 4f 51       	jmp    0x514f:0x1385
    514c:	9a 34 14 cc 52       	call   0x52cc:0x1434
    5151:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5154:	26 c6 45 3e 00       	mov    BYTE PTR es:[di+0x3e],0x0
    5159:	6a 02                	push   0x2
    515b:	6a 00                	push   0x0
    515d:	6a 00                	push   0x0
    515f:	06                   	push   es
    5160:	57                   	push   di
    5161:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5164:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    5168:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    516b:	06                   	push   es
    516c:	57                   	push   di
    516d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5170:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    5174:	c9                   	leave
    5175:	ca 04 00             	retf   0x4
    5178:	00 00                	add    BYTE PTR [bx+si],al
    517a:	9b                   	fwait
    517b:	52                   	push   dx
    517c:	86 51 01             	xchg   BYTE PTR [bx+di+0x1],dl
    517f:	00 00                	add    BYTE PTR [bx+si],al
    5181:	00 00                	add    BYTE PTR [bx+si],al
    5183:	00 b7 52 8c          	add    BYTE PTR [bx-0x73ae],dh
    5187:	51                   	push   cx
    5188:	00 00                	add    BYTE PTR [bx+si],al
    518a:	f7 52 9a             	not    WORD PTR [bp+si-0x66]
    518d:	51                   	push   cx
    518e:	c8 04 00 00          	enter  0x4,0x0
    5192:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5195:	06                   	push   es
    5196:	57                   	push   di
    5197:	9a b8 50 aa 51       	call   0x51aa:0x50b8
    519c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    51a0:	75 0a                	jne    0x51ac
    51a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51a5:	06                   	push   es
    51a6:	57                   	push   di
    51a7:	9a 3b 48 b4 51       	call   0x51b4:0x483b
    51ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51af:	06                   	push   es
    51b0:	57                   	push   di
    51b1:	9a 41 44 d4 51       	call   0x51d4:0x4441
    51b6:	b8 88 51             	mov    ax,0x5188
    51b9:	0e                   	push   cs
    51ba:	50                   	push   ax
    51bb:	55                   	push   bp
    51bc:	ff 36 58 18          	push   WORD PTR ds:0x1858
    51c0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    51c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51c7:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    51cb:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    51cf:	06                   	push   es
    51d0:	57                   	push   di
    51d1:	9a ee 44 ec 51       	call   0x51ec:0x44ee
    51d6:	b8 7e 51             	mov    ax,0x517e
    51d9:	0e                   	push   cs
    51da:	50                   	push   ax
    51db:	55                   	push   bp
    51dc:	ff 36 58 18          	push   WORD PTR ds:0x1858
    51e0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    51e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51e7:	06                   	push   es
    51e8:	57                   	push   di
    51e9:	9a a7 45 02 52       	call   0x5202:0x45a7
    51ee:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    51f1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    51f4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    51f7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    51fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51fd:	06                   	push   es
    51fe:	57                   	push   di
    51ff:	9a 94 42 3f 52       	call   0x523f:0x4294
    5204:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5207:	26 c6 45 3a 03       	mov    BYTE PTR es:[di+0x3a],0x3
    520c:	b8 78 51             	mov    ax,0x5178
    520f:	0e                   	push   cs
    5210:	50                   	push   ax
    5211:	55                   	push   bp
    5212:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5216:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    521a:	06                   	push   es
    521b:	57                   	push   di
    521c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    521f:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    5223:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5226:	06                   	push   es
    5227:	57                   	push   di
    5228:	26 c4 3d             	les    di,DWORD PTR es:[di]
    522b:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    522f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5232:	06                   	push   es
    5233:	57                   	push   di
    5234:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5237:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    523a:	06                   	push   es
    523b:	57                   	push   di
    523c:	9a 4f 4f 6d 52       	call   0x526d:0x4f4f
    5241:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5244:	06                   	push   es
    5245:	57                   	push   di
    5246:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5249:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    524d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5251:	74 1e                	je     0x5271
    5253:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5256:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    525a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    525e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5261:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5264:	9a 3d 09 87 52       	call   0x5287:0x93d
    5269:	50                   	push   ax
    526a:	9a 4e 12 8d 52       	call   0x528d:0x124e
    526f:	eb 1e                	jmp    0x528f
    5271:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5274:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5278:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    527c:	6a 00                	push   0x0
    527e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5281:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5284:	9a 3d 01 ac 53       	call   0x53ac:0x13d
    5289:	50                   	push   ax
    528a:	9a 4e 12 a3 52       	call   0x52a3:0x124e
    528f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5293:	83 c4 06             	add    sp,0x6
    5296:	b8 ae 52             	mov    ax,0x52ae
    5299:	0e                   	push   cs
    529a:	50                   	push   ax
    529b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    529e:	06                   	push   es
    529f:	57                   	push   di
    52a0:	9a 08 3a c7 52       	call   0x52c7:0x3a08
    52a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52a8:	26 c6 45 3a 01       	mov    BYTE PTR es:[di+0x3a],0x1
    52ad:	cb                   	retf
    52ae:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    52b2:	83 c4 06             	add    sp,0x6
    52b5:	eb 1c                	jmp    0x52d3
    52b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52ba:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    52be:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    52c2:	06                   	push   es
    52c3:	57                   	push   di
    52c4:	9a ee 44 dd 52       	call   0x52dd:0x44ee
    52c9:	ea 85 13 d1 52       	jmp    0x52d1:0x1385
    52ce:	9a 34 14 5b 57       	call   0x575b:0x1434
    52d3:	6a 00                	push   0x0
    52d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52d8:	06                   	push   es
    52d9:	57                   	push   di
    52da:	9a 1e 4b ff 52       	call   0x52ff:0x4b1e
    52df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52e2:	06                   	push   es
    52e3:	57                   	push   di
    52e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52e7:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    52eb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    52ef:	83 c4 06             	add    sp,0x6
    52f2:	b8 02 53             	mov    ax,0x5302
    52f5:	0e                   	push   cs
    52f6:	50                   	push   ax
    52f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52fa:	06                   	push   es
    52fb:	57                   	push   di
    52fc:	9a 66 44 1b 53       	call   0x531b:0x4466
    5301:	cb                   	retf
    5302:	c9                   	leave
    5303:	ca 0c 00             	retf   0xc
    5306:	55                   	push   bp
    5307:	89 e5                	mov    bp,sp
    5309:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    530c:	06                   	push   es
    530d:	57                   	push   di
    530e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5311:	6a 00                	push   0x0
    5313:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5316:	06                   	push   es
    5317:	57                   	push   di
    5318:	9a 8e 51 36 53       	call   0x5336:0x518e
    531d:	c9                   	leave
    531e:	ca 0a 00             	retf   0xa
    5321:	55                   	push   bp
    5322:	89 e5                	mov    bp,sp
    5324:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5327:	06                   	push   es
    5328:	57                   	push   di
    5329:	ff 76 0a             	push   WORD PTR [bp+0xa]
    532c:	6a 01                	push   0x1
    532e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5331:	06                   	push   es
    5332:	57                   	push   di
    5333:	9a 8e 51 60 53       	call   0x5360:0x518e
    5338:	c9                   	leave
    5339:	ca 0a 00             	retf   0xa
    533c:	55                   	push   bp
    533d:	89 e5                	mov    bp,sp
    533f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5342:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    5346:	3c 02                	cmp    al,0x2
    5348:	72 07                	jb     0x5351
    534a:	3c 03                	cmp    al,0x3
    534c:	77 03                	ja     0x5351
    534e:	e9 9b 00             	jmp    0x53ec
    5351:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5354:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    5359:	75 0a                	jne    0x5365
    535b:	06                   	push   es
    535c:	57                   	push   di
    535d:	9a 99 4f 6d 53       	call   0x536d:0x4f99
    5362:	e9 87 00             	jmp    0x53ec
    5365:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5368:	06                   	push   es
    5369:	57                   	push   di
    536a:	9a 3d 4c 77 53       	call   0x5377:0x4c3d
    536f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5372:	06                   	push   es
    5373:	57                   	push   di
    5374:	9a ae 4c 8d 53       	call   0x538d:0x4cae
    5379:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    537c:	06                   	push   es
    537d:	57                   	push   di
    537e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5381:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    5385:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5388:	06                   	push   es
    5389:	57                   	push   di
    538a:	9a 3b 48 a1 53       	call   0x53a1:0x483b
    538f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5392:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5396:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    539a:	6a 01                	push   0x1
    539c:	06                   	push   es
    539d:	57                   	push   di
    539e:	9a a7 45 b2 53       	call   0x53b2:0x45a7
    53a3:	52                   	push   dx
    53a4:	50                   	push   ax
    53a5:	6a 00                	push   0x0
    53a7:	6a 00                	push   0x0
    53a9:	9a 0d 01 1f 55       	call   0x551f:0x10d
    53ae:	50                   	push   ax
    53af:	9a 4e 12 c0 53       	call   0x53c0:0x124e
    53b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53b7:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    53bb:	06                   	push   es
    53bc:	57                   	push   di
    53bd:	9a 24 46 cc 53       	call   0x53cc:0x4624
    53c2:	6a 02                	push   0x2
    53c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53c7:	06                   	push   es
    53c8:	57                   	push   di
    53c9:	9a 91 31 56 54       	call   0x5456:0x3191
    53ce:	6a 01                	push   0x1
    53d0:	6a 00                	push   0x0
    53d2:	6a 00                	push   0x0
    53d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53d7:	06                   	push   es
    53d8:	57                   	push   di
    53d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53dc:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    53e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53e3:	06                   	push   es
    53e4:	57                   	push   di
    53e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53e8:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    53ec:	c9                   	leave
    53ed:	ca 04 00             	retf   0x4
    53f0:	c8 10 00 00          	enter  0x10,0x0
    53f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53f7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    53fb:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    53ff:	48                   	dec    ax
    5400:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5403:	31 c0                	xor    ax,ax
    5405:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5408:	7e 03                	jle    0x540d
    540a:	e9 8f 00             	jmp    0x549c
    540d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5410:	eb 03                	jmp    0x5415
    5412:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5415:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5418:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    541b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    541f:	06                   	push   es
    5420:	57                   	push   di
    5421:	9a d0 0d 7b 5a       	call   0x5a7b:0xdd0
    5426:	89 c7                	mov    di,ax
    5428:	8e c2                	mov    es,dx
    542a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    542d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    5430:	26 80 7d 27 00       	cmp    BYTE PTR es:[di+0x27],0x0
    5435:	74 5a                	je     0x5491
    5437:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    543c:	75 53                	jne    0x5491
    543e:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    5443:	75 4c                	jne    0x5491
    5445:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    5449:	3c 01                	cmp    al,0x1
    544b:	72 44                	jb     0x5491
    544d:	3c 0d                	cmp    al,0xd
    544f:	77 40                	ja     0x5491
    5451:	06                   	push   es
    5452:	57                   	push   di
    5453:	9a db 69 64 54       	call   0x5464:0x69db
    5458:	08 c0                	or     al,al
    545a:	74 35                	je     0x5491
    545c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    545f:	06                   	push   es
    5460:	57                   	push   di
    5461:	9a 26 64 71 54       	call   0x5471:0x6426
    5466:	68 17 f2             	push   0xf217
    5469:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    546c:	06                   	push   es
    546d:	57                   	push   di
    546e:	9a f6 67 8f 54       	call   0x548f:0x67f6
    5473:	89 c7                	mov    di,ax
    5475:	8e c2                	mov    es,dx
    5477:	89 f8                	mov    ax,di
    5479:	8c c2                	mov    dx,es
    547b:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    547e:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    5481:	c6 46 f4 04          	mov    BYTE PTR [bp-0xc],0x4
    5485:	8d 7e f0             	lea    di,[bp-0x10]
    5488:	16                   	push   ss
    5489:	57                   	push   di
    548a:	6a 00                	push   0x0
    548c:	9a 0a 12 ac 54       	call   0x54ac:0x120a
    5491:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5494:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5497:	74 03                	je     0x549c
    5499:	e9 76 ff             	jmp    0x5412
    549c:	c9                   	leave
    549d:	ca 04 00             	retf   0x4
    54a0:	c8 04 00 00          	enter  0x4,0x0
    54a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54a7:	06                   	push   es
    54a8:	57                   	push   di
    54a9:	9a be 44 da 54       	call   0x54da:0x44be
    54ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54b1:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    54b5:	3c 02                	cmp    al,0x2
    54b7:	74 07                	je     0x54c0
    54b9:	3c 03                	cmp    al,0x3
    54bb:	74 03                	je     0x54c0
    54bd:	e9 b7 00             	jmp    0x5577
    54c0:	6a 07                	push   0x7
    54c2:	6a 00                	push   0x0
    54c4:	6a 00                	push   0x0
    54c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54c9:	06                   	push   es
    54ca:	57                   	push   di
    54cb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54ce:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    54d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54d5:	06                   	push   es
    54d6:	57                   	push   di
    54d7:	9a f0 53 f0 54       	call   0x54f0:0x53f0
    54dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54df:	06                   	push   es
    54e0:	57                   	push   di
    54e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54e4:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    54e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54eb:	06                   	push   es
    54ec:	57                   	push   di
    54ed:	9a a7 45 00 55       	call   0x5500:0x45a7
    54f2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    54f5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    54f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54fb:	06                   	push   es
    54fc:	57                   	push   di
    54fd:	9a 3b 48 25 55       	call   0x5525:0x483b
    5502:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5505:	26 80 7d 3a 02       	cmp    BYTE PTR es:[di+0x3a],0x2
    550a:	75 1d                	jne    0x5529
    550c:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5510:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5514:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5517:	ff 76 fc             	push   WORD PTR [bp-0x4]
    551a:	6a 01                	push   0x1
    551c:	9a 4d 01 3f 55       	call   0x553f:0x14d
    5521:	50                   	push   ax
    5522:	9a 4e 12 45 55       	call   0x5545:0x124e
    5527:	eb 1e                	jmp    0x5547
    5529:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    552c:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5530:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5534:	6a 00                	push   0x0
    5536:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5539:	ff 76 fc             	push   WORD PTR [bp-0x4]
    553c:	9a 3d 01 dc 55       	call   0x55dc:0x13d
    5541:	50                   	push   ax
    5542:	9a 4e 12 4f 55       	call   0x554f:0x124e
    5547:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    554a:	06                   	push   es
    554b:	57                   	push   di
    554c:	9a 08 3a 5b 55       	call   0x555b:0x3a08
    5551:	6a 01                	push   0x1
    5553:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5556:	06                   	push   es
    5557:	57                   	push   di
    5558:	9a 91 31 67 55       	call   0x5567:0x3191
    555d:	6a 00                	push   0x0
    555f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5562:	06                   	push   es
    5563:	57                   	push   di
    5564:	9a 1e 4b 85 55       	call   0x5585:0x4b1e
    5569:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    556c:	06                   	push   es
    556d:	57                   	push   di
    556e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5571:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    5575:	eb 10                	jmp    0x5587
    5577:	3c 04                	cmp    al,0x4
    5579:	75 0c                	jne    0x5587
    557b:	6a 01                	push   0x1
    557d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5580:	06                   	push   es
    5581:	57                   	push   di
    5582:	9a 10 57 c3 55       	call   0x55c3:0x5710
    5587:	c9                   	leave
    5588:	ca 04 00             	retf   0x4
    558b:	55                   	push   bp
    558c:	89 e5                	mov    bp,sp
    558e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5591:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    5595:	3c 02                	cmp    al,0x2
    5597:	74 04                	je     0x559d
    5599:	3c 03                	cmp    al,0x3
    559b:	75 71                	jne    0x560e
    559d:	6a 07                	push   0x7
    559f:	6a 00                	push   0x0
    55a1:	6a 00                	push   0x0
    55a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55a6:	06                   	push   es
    55a7:	57                   	push   di
    55a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55ab:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    55af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55b2:	06                   	push   es
    55b3:	57                   	push   di
    55b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55b7:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    55bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55be:	06                   	push   es
    55bf:	57                   	push   di
    55c0:	9a 3b 48 e6 55       	call   0x55e6:0x483b
    55c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55c8:	26 80 7d 3a 02       	cmp    BYTE PTR es:[di+0x3a],0x2
    55cd:	75 0f                	jne    0x55de
    55cf:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    55d3:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    55d7:	6a 00                	push   0x0
    55d9:	9a 7d 03 9d 56       	call   0x569d:0x37d
    55de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55e1:	06                   	push   es
    55e2:	57                   	push   di
    55e3:	9a 08 3a f2 55       	call   0x55f2:0x3a08
    55e8:	6a 01                	push   0x1
    55ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55ed:	06                   	push   es
    55ee:	57                   	push   di
    55ef:	9a 91 31 fe 55       	call   0x55fe:0x3191
    55f4:	6a 00                	push   0x0
    55f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55f9:	06                   	push   es
    55fa:	57                   	push   di
    55fb:	9a 1e 4b 1c 56       	call   0x561c:0x4b1e
    5600:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5603:	06                   	push   es
    5604:	57                   	push   di
    5605:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5608:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    560c:	eb 10                	jmp    0x561e
    560e:	3c 04                	cmp    al,0x4
    5610:	75 0c                	jne    0x561e
    5612:	6a 00                	push   0x0
    5614:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5617:	06                   	push   es
    5618:	57                   	push   di
    5619:	9a 10 57 36 56       	call   0x5636:0x5710
    561e:	c9                   	leave
    561f:	ca 04 00             	retf   0x4
    5622:	c8 02 00 00          	enter  0x2,0x0
    5626:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5629:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    562e:	75 08                	jne    0x5638
    5630:	68 05 f2             	push   0xf205
    5633:	9a ef 11 4c 56       	call   0x564c:0x11ef
    5638:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    563b:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    563f:	3c 03                	cmp    al,0x3
    5641:	72 0e                	jb     0x5651
    5643:	3c 04                	cmp    al,0x4
    5645:	77 0a                	ja     0x5651
    5647:	06                   	push   es
    5648:	57                   	push   di
    5649:	9a 8b 55 61 56       	call   0x5661:0x558b
    564e:	e9 93 00             	jmp    0x56e4
    5651:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5654:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    5659:	75 08                	jne    0x5663
    565b:	68 0a f2             	push   0xf20a
    565e:	9a ef 11 89 56       	call   0x5689:0x11ef
    5663:	6a 07                	push   0x7
    5665:	6a 00                	push   0x0
    5667:	6a 00                	push   0x0
    5669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    566c:	06                   	push   es
    566d:	57                   	push   di
    566e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5671:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    5675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5678:	06                   	push   es
    5679:	57                   	push   di
    567a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    567d:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    5681:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5684:	06                   	push   es
    5685:	57                   	push   di
    5686:	9a 3b 48 b4 56       	call   0x56b4:0x483b
    568b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    568e:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5692:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5696:	6a 00                	push   0x0
    5698:	6a 00                	push   0x0
    569a:	9a 5d 01 4b 59       	call   0x594b:0x15d
    569f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    56a2:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    56a6:	74 0e                	je     0x56b6
    56a8:	80 7e ff 22          	cmp    BYTE PTR [bp-0x1],0x22
    56ac:	74 08                	je     0x56b6
    56ae:	ff 76 fe             	push   WORD PTR [bp-0x2]
    56b1:	9a 2d 12 be 56       	call   0x56be:0x122d
    56b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56b9:	06                   	push   es
    56ba:	57                   	push   di
    56bb:	9a 08 3a ca 56       	call   0x56ca:0x3a08
    56c0:	6a 01                	push   0x1
    56c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56c5:	06                   	push   es
    56c6:	57                   	push   di
    56c7:	9a 91 31 d6 56       	call   0x56d6:0x3191
    56cc:	6a 00                	push   0x0
    56ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d1:	06                   	push   es
    56d2:	57                   	push   di
    56d3:	9a 1e 4b 67 57       	call   0x5767:0x4b1e
    56d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56db:	06                   	push   es
    56dc:	57                   	push   di
    56dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56e0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    56e4:	c9                   	leave
    56e5:	ca 04 00             	retf   0x4
    56e8:	c8 04 00 00          	enter  0x4,0x0
    56ec:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    56ef:	98                   	cbw
    56f0:	c1 e0 02             	shl    ax,0x2
    56f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56f6:	03 f8                	add    di,ax
    56f8:	26 8b 45 5e          	mov    ax,WORD PTR es:[di+0x5e]
    56fc:	26 8b 55 60          	mov    dx,WORD PTR es:[di+0x60]
    5700:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5703:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5706:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5709:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    570c:	c9                   	leave
    570d:	ca 06 00             	retf   0x6
    5710:	55                   	push   bp
    5711:	89 e5                	mov    bp,sp
    5713:	6a 07                	push   0x7
    5715:	6a 00                	push   0x0
    5717:	6a 00                	push   0x0
    5719:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    571c:	06                   	push   es
    571d:	57                   	push   di
    571e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5721:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    5725:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5729:	74 10                	je     0x573b
    572b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    572e:	26 8a 45 3e          	mov    al,BYTE PTR es:[di+0x3e]
    5732:	26 c4 7d 76          	les    di,DWORD PTR es:[di+0x76]
    5736:	26 88 05             	mov    BYTE PTR es:[di],al
    5739:	eb 22                	jmp    0x575d
    573b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    573e:	26 c4 7d 72          	les    di,DWORD PTR es:[di+0x72]
    5742:	06                   	push   es
    5743:	57                   	push   di
    5744:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5747:	26 c4 7d 76          	les    di,DWORD PTR es:[di+0x76]
    574b:	06                   	push   es
    574c:	57                   	push   di
    574d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5750:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    5754:	05 04 00             	add    ax,0x4
    5757:	50                   	push   ax
    5758:	9a c1 1e 73 59       	call   0x5973:0x1ec1
    575d:	6a 01                	push   0x1
    575f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5762:	06                   	push   es
    5763:	57                   	push   di
    5764:	9a 91 31 83 57       	call   0x5783:0x3191
    5769:	6a 02                	push   0x2
    576b:	6a 00                	push   0x0
    576d:	6a 00                	push   0x0
    576f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5772:	06                   	push   es
    5773:	57                   	push   di
    5774:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5777:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    577b:	c9                   	leave
    577c:	ca 06 00             	retf   0x6
    577f:	00 00                	add    BYTE PTR [bx+si],al
    5781:	39 58 b3             	cmp    WORD PTR [bx+si-0x4d],bx
    5784:	57                   	push   di
    5785:	c8 04 00 00          	enter  0x4,0x0
    5789:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    578c:	26 ff 45 50          	inc    WORD PTR es:[di+0x50]
    5790:	26 c6 45 3a 04       	mov    BYTE PTR es:[di+0x3a],0x4
    5795:	26 c6 45 3e 00       	mov    BYTE PTR es:[di+0x3e],0x0
    579a:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    579d:	98                   	cbw
    579e:	c1 e0 02             	shl    ax,0x2
    57a1:	03 f8                	add    di,ax
    57a3:	26 ff 75 60          	push   WORD PTR es:[di+0x60]
    57a7:	26 ff 75 5e          	push   WORD PTR es:[di+0x5e]
    57ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57ae:	06                   	push   es
    57af:	57                   	push   di
    57b0:	9a cd 42 fb 57       	call   0x57fb:0x42cd
    57b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57b8:	26 89 45 76          	mov    WORD PTR es:[di+0x76],ax
    57bc:	26 89 55 78          	mov    WORD PTR es:[di+0x78],dx
    57c0:	b8 7f 57             	mov    ax,0x577f
    57c3:	0e                   	push   cs
    57c4:	50                   	push   ax
    57c5:	55                   	push   bp
    57c6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    57ca:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    57ce:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    57d1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    57d4:	31 c0                	xor    ax,ax
    57d6:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    57d9:	7f 35                	jg     0x5810
    57db:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    57de:	eb 03                	jmp    0x57e3
    57e0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    57e3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    57e6:	c1 e0 03             	shl    ax,0x3
    57e9:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    57ec:	03 f8                	add    di,ax
    57ee:	06                   	push   es
    57ef:	57                   	push   di
    57f0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    57f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57f6:	06                   	push   es
    57f7:	57                   	push   di
    57f8:	9a fb 3c 06 58       	call   0x5806:0x3cfb
    57fd:	89 c7                	mov    di,ax
    57ff:	8e c2                	mov    es,dx
    5801:	06                   	push   es
    5802:	57                   	push   di
    5803:	9a 77 62 51 59       	call   0x5951:0x6277
    5808:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    580b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    580e:	75 d0                	jne    0x57e0
    5810:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5813:	40                   	inc    ax
    5814:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5817:	26 c4 7d 76          	les    di,DWORD PTR es:[di+0x76]
    581b:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    581f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5822:	26 8a 45 3e          	mov    al,BYTE PTR es:[di+0x3e]
    5826:	26 c4 7d 76          	les    di,DWORD PTR es:[di+0x76]
    582a:	26 88 05             	mov    BYTE PTR es:[di],al
    582d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5831:	83 c4 06             	add    sp,0x6
    5834:	b8 46 58             	mov    ax,0x5846
    5837:	0e                   	push   cs
    5838:	50                   	push   ax
    5839:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    583c:	26 c6 45 3a 01       	mov    BYTE PTR es:[di+0x3a],0x1
    5841:	26 ff 4d 50          	dec    WORD PTR es:[di+0x50]
    5845:	cb                   	retf
    5846:	c9                   	leave
    5847:	ca 0c 00             	retf   0xc
    584a:	c8 12 00 00          	enter  0x12,0x0
    584e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    5852:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5855:	26 ff 75 64          	push   WORD PTR es:[di+0x64]
    5859:	26 ff 75 62          	push   WORD PTR es:[di+0x62]
    585d:	26 ff 75 6c          	push   WORD PTR es:[di+0x6c]
    5861:	26 ff 75 6a          	push   WORD PTR es:[di+0x6a]
    5865:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    5869:	05 04 00             	add    ax,0x4
    586c:	50                   	push   ax
    586d:	e8 2d b6             	call   0xe9d
    5870:	08 c0                	or     al,al
    5872:	74 25                	je     0x5899
    5874:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5877:	26 ff 75 68          	push   WORD PTR es:[di+0x68]
    587b:	26 ff 75 66          	push   WORD PTR es:[di+0x66]
    587f:	26 ff 75 70          	push   WORD PTR es:[di+0x70]
    5883:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
    5887:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    588b:	05 04 00             	add    ax,0x4
    588e:	50                   	push   ax
    588f:	e8 0b b6             	call   0xe9d
    5892:	08 c0                	or     al,al
    5894:	74 03                	je     0x5899
    5896:	e9 02 01             	jmp    0x599b
    5899:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    589c:	26 8b 45 62          	mov    ax,WORD PTR es:[di+0x62]
    58a0:	26 8b 55 64          	mov    dx,WORD PTR es:[di+0x64]
    58a4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    58a7:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    58aa:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    58ad:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    58b1:	74 11                	je     0x58c4
    58b3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    58b6:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    58b9:	05 04 00             	add    ax,0x4
    58bc:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    58bf:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    58c2:	eb 08                	jmp    0x58cc
    58c4:	31 c0                	xor    ax,ax
    58c6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    58c9:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    58cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58cf:	26 8b 45 66          	mov    ax,WORD PTR es:[di+0x66]
    58d3:	26 8b 55 68          	mov    dx,WORD PTR es:[di+0x68]
    58d7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    58da:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    58dd:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    58e0:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    58e4:	74 11                	je     0x58f7
    58e6:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    58e9:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    58ec:	05 04 00             	add    ax,0x4
    58ef:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    58f2:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    58f5:	eb 08                	jmp    0x58ff
    58f7:	31 c0                	xor    ax,ax
    58f9:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    58fc:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    58ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5902:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5906:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    590a:	6a 00                	push   0x0
    590c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    590f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5913:	6a 00                	push   0x0
    5915:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5918:	ff 76 f2             	push   WORD PTR [bp-0xe]
    591b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    591e:	26 80 7d 01 00       	cmp    BYTE PTR es:[di+0x1],0x0
    5923:	b0 00                	mov    al,0x0
    5925:	75 01                	jne    0x5928
    5927:	40                   	inc    ax
    5928:	98                   	cbw
    5929:	50                   	push   ax
    592a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    592d:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5931:	6a 00                	push   0x0
    5933:	ff 76 f0             	push   WORD PTR [bp-0x10]
    5936:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5939:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    593c:	26 80 7d 01 00       	cmp    BYTE PTR es:[di+0x1],0x0
    5941:	b0 00                	mov    al,0x0
    5943:	75 01                	jne    0x5946
    5945:	40                   	inc    ax
    5946:	98                   	cbw
    5947:	50                   	push   ax
    5948:	9a 7d 01 d2 59       	call   0x59d2:0x17d
    594d:	50                   	push   ax
    594e:	9a 4e 12 d8 59       	call   0x59d8:0x124e
    5953:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5956:	26 c4 7d 62          	les    di,DWORD PTR es:[di+0x62]
    595a:	06                   	push   es
    595b:	57                   	push   di
    595c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    595f:	26 c4 7d 6a          	les    di,DWORD PTR es:[di+0x6a]
    5963:	06                   	push   es
    5964:	57                   	push   di
    5965:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5968:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    596c:	05 04 00             	add    ax,0x4
    596f:	50                   	push   ax
    5970:	9a c1 1e 95 59       	call   0x5995:0x1ec1
    5975:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5978:	26 c4 7d 66          	les    di,DWORD PTR es:[di+0x66]
    597c:	06                   	push   es
    597d:	57                   	push   di
    597e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5981:	26 c4 7d 6e          	les    di,DWORD PTR es:[di+0x6e]
    5985:	06                   	push   es
    5986:	57                   	push   di
    5987:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    598a:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    598e:	05 04 00             	add    ax,0x4
    5991:	50                   	push   ax
    5992:	9a c1 1e ee 5a       	call   0x5aee:0x1ec1
    5997:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    599b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    599e:	c9                   	leave
    599f:	ca 04 00             	retf   0x4
    59a2:	c8 02 00 00          	enter  0x2,0x0
    59a6:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    59aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59ad:	26 c4 7d 6a          	les    di,DWORD PTR es:[di+0x6a]
    59b1:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    59b5:	75 0d                	jne    0x59c4
    59b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59ba:	26 c4 7d 6e          	les    di,DWORD PTR es:[di+0x6e]
    59be:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    59c2:	74 3e                	je     0x5a02
    59c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59c7:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    59cb:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    59cf:	9a 8d 01 c8 5d       	call   0x5dc8:0x18d
    59d4:	50                   	push   ax
    59d5:	9a 4e 12 ea 59       	call   0x59ea:0x124e
    59da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59dd:	26 ff 75 6c          	push   WORD PTR es:[di+0x6c]
    59e1:	26 ff 75 6a          	push   WORD PTR es:[di+0x6a]
    59e5:	06                   	push   es
    59e6:	57                   	push   di
    59e7:	9a cd 42 fc 59       	call   0x59fc:0x42cd
    59ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59ef:	26 ff 75 70          	push   WORD PTR es:[di+0x70]
    59f3:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
    59f7:	06                   	push   es
    59f8:	57                   	push   di
    59f9:	9a cd 42 0d 5a       	call   0x5a0d:0x42cd
    59fe:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    5a02:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5a05:	c9                   	leave
    5a06:	ca 04 00             	retf   0x4
    5a09:	00 00                	add    BYTE PTR [bx+si],al
    5a0b:	bf 5a 41             	mov    di,0x415a
    5a0e:	5a                   	pop    dx
    5a0f:	c8 06 00 00          	enter  0x6,0x0
    5a13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a16:	26 ff 45 50          	inc    WORD PTR es:[di+0x50]
    5a1a:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    5a1e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5a21:	26 c6 45 3a 04       	mov    BYTE PTR es:[di+0x3a],0x4
    5a26:	b8 09 5a             	mov    ax,0x5a09
    5a29:	0e                   	push   cs
    5a2a:	50                   	push   ax
    5a2b:	55                   	push   bp
    5a2c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5a30:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5a34:	26 ff 75 64          	push   WORD PTR es:[di+0x64]
    5a38:	26 ff 75 62          	push   WORD PTR es:[di+0x62]
    5a3c:	06                   	push   es
    5a3d:	57                   	push   di
    5a3e:	9a cd 42 8a 5a       	call   0x5a8a:0x42cd
    5a43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a46:	26 89 45 76          	mov    WORD PTR es:[di+0x76],ax
    5a4a:	26 89 55 78          	mov    WORD PTR es:[di+0x78],dx
    5a4e:	26 c4 7d 76          	les    di,DWORD PTR es:[di+0x76]
    5a52:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    5a56:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5a59:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    5a5d:	48                   	dec    ax
    5a5e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5a61:	31 c0                	xor    ax,ax
    5a63:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    5a66:	7f 39                	jg     0x5aa1
    5a68:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5a6b:	eb 03                	jmp    0x5a70
    5a6d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    5a70:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5a73:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5a76:	06                   	push   es
    5a77:	57                   	push   di
    5a78:	9a d0 0d 67 5e       	call   0x5e67:0xdd0
    5a7d:	52                   	push   dx
    5a7e:	50                   	push   ax
    5a7f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a85:	06                   	push   es
    5a86:	57                   	push   di
    5a87:	9a fb 3c 90 5d       	call   0x5d90:0x3cfb
    5a8c:	89 c7                	mov    di,ax
    5a8e:	8e c2                	mov    es,dx
    5a90:	06                   	push   es
    5a91:	57                   	push   di
    5a92:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a95:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    5a99:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5a9c:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    5a9f:	75 cc                	jne    0x5a6d
    5aa1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5aa4:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    5aa8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5aab:	26 c4 7d 76          	les    di,DWORD PTR es:[di+0x76]
    5aaf:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    5ab3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ab7:	83 c4 06             	add    sp,0x6
    5aba:	b8 ce 5a             	mov    ax,0x5ace
    5abd:	0e                   	push   cs
    5abe:	50                   	push   ax
    5abf:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5ac2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ac5:	26 88 45 3a          	mov    BYTE PTR es:[di+0x3a],al
    5ac9:	26 ff 4d 50          	dec    WORD PTR es:[di+0x50]
    5acd:	cb                   	retf
    5ace:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ad1:	26 c4 7d 62          	les    di,DWORD PTR es:[di+0x62]
    5ad5:	06                   	push   es
    5ad6:	57                   	push   di
    5ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ada:	26 c4 7d 66          	les    di,DWORD PTR es:[di+0x66]
    5ade:	06                   	push   es
    5adf:	57                   	push   di
    5ae0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ae3:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    5ae7:	05 04 00             	add    ax,0x4
    5aea:	50                   	push   ax
    5aeb:	9a c1 1e d6 5f       	call   0x5fd6:0x1ec1
    5af0:	c9                   	leave
    5af1:	ca 08 00             	retf   0x8
    5af4:	55                   	push   bp
    5af5:	89 e5                	mov    bp,sp
    5af7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5afa:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    5aff:	09 c0                	or     ax,ax
    5b01:	74 15                	je     0x5b18
    5b03:	ff 76 08             	push   WORD PTR [bp+0x8]
    5b06:	ff 76 06             	push   WORD PTR [bp+0x6]
    5b09:	26 ff b5 fe 00       	push   WORD PTR es:[di+0xfe]
    5b0e:	26 ff b5 fc 00       	push   WORD PTR es:[di+0xfc]
    5b13:	26 ff 9d f8 00       	call   DWORD PTR es:[di+0xf8]
    5b18:	c9                   	leave
    5b19:	ca 04 00             	retf   0x4
    5b1c:	55                   	push   bp
    5b1d:	89 e5                	mov    bp,sp
    5b1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b22:	26 8b 85 ba 00       	mov    ax,WORD PTR es:[di+0xba]
    5b27:	09 c0                	or     ax,ax
    5b29:	74 15                	je     0x5b40
    5b2b:	ff 76 08             	push   WORD PTR [bp+0x8]
    5b2e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5b31:	26 ff b5 be 00       	push   WORD PTR es:[di+0xbe]
    5b36:	26 ff b5 bc 00       	push   WORD PTR es:[di+0xbc]
    5b3b:	26 ff 9d b8 00       	call   DWORD PTR es:[di+0xb8]
    5b40:	c9                   	leave
    5b41:	ca 04 00             	retf   0x4
    5b44:	55                   	push   bp
    5b45:	89 e5                	mov    bp,sp
    5b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b4a:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    5b4f:	09 c0                	or     ax,ax
    5b51:	74 15                	je     0x5b68
    5b53:	ff 76 08             	push   WORD PTR [bp+0x8]
    5b56:	ff 76 06             	push   WORD PTR [bp+0x6]
    5b59:	26 ff b5 0e 01       	push   WORD PTR es:[di+0x10e]
    5b5e:	26 ff b5 0c 01       	push   WORD PTR es:[di+0x10c]
    5b63:	26 ff 9d 08 01       	call   DWORD PTR es:[di+0x108]
    5b68:	c9                   	leave
    5b69:	ca 04 00             	retf   0x4
    5b6c:	55                   	push   bp
    5b6d:	89 e5                	mov    bp,sp
    5b6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b72:	26 8b 85 da 00       	mov    ax,WORD PTR es:[di+0xda]
    5b77:	09 c0                	or     ax,ax
    5b79:	74 15                	je     0x5b90
    5b7b:	ff 76 08             	push   WORD PTR [bp+0x8]
    5b7e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5b81:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    5b86:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
    5b8b:	26 ff 9d d8 00       	call   DWORD PTR es:[di+0xd8]
    5b90:	c9                   	leave
    5b91:	ca 04 00             	retf   0x4
    5b94:	55                   	push   bp
    5b95:	89 e5                	mov    bp,sp
    5b97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b9a:	26 8b 85 ca 00       	mov    ax,WORD PTR es:[di+0xca]
    5b9f:	09 c0                	or     ax,ax
    5ba1:	74 15                	je     0x5bb8
    5ba3:	ff 76 08             	push   WORD PTR [bp+0x8]
    5ba6:	ff 76 06             	push   WORD PTR [bp+0x6]
    5ba9:	26 ff b5 ce 00       	push   WORD PTR es:[di+0xce]
    5bae:	26 ff b5 cc 00       	push   WORD PTR es:[di+0xcc]
    5bb3:	26 ff 9d c8 00       	call   DWORD PTR es:[di+0xc8]
    5bb8:	c9                   	leave
    5bb9:	ca 04 00             	retf   0x4
    5bbc:	55                   	push   bp
    5bbd:	89 e5                	mov    bp,sp
    5bbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bc2:	26 8b 85 aa 00       	mov    ax,WORD PTR es:[di+0xaa]
    5bc7:	09 c0                	or     ax,ax
    5bc9:	74 15                	je     0x5be0
    5bcb:	ff 76 08             	push   WORD PTR [bp+0x8]
    5bce:	ff 76 06             	push   WORD PTR [bp+0x6]
    5bd1:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    5bd6:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    5bdb:	26 ff 9d a8 00       	call   DWORD PTR es:[di+0xa8]
    5be0:	c9                   	leave
    5be1:	ca 04 00             	retf   0x4
    5be4:	55                   	push   bp
    5be5:	89 e5                	mov    bp,sp
    5be7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bea:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
    5bef:	09 c0                	or     ax,ax
    5bf1:	74 15                	je     0x5c08
    5bf3:	ff 76 08             	push   WORD PTR [bp+0x8]
    5bf6:	ff 76 06             	push   WORD PTR [bp+0x6]
    5bf9:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    5bfe:	26 ff b5 ec 00       	push   WORD PTR es:[di+0xec]
    5c03:	26 ff 9d e8 00       	call   DWORD PTR es:[di+0xe8]
    5c08:	c9                   	leave
    5c09:	ca 04 00             	retf   0x4
    5c0c:	55                   	push   bp
    5c0d:	89 e5                	mov    bp,sp
    5c0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c12:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    5c17:	09 c0                	or     ax,ax
    5c19:	74 15                	je     0x5c30
    5c1b:	ff 76 08             	push   WORD PTR [bp+0x8]
    5c1e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5c21:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    5c26:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    5c2b:	26 ff 9d f0 00       	call   DWORD PTR es:[di+0xf0]
    5c30:	c9                   	leave
    5c31:	ca 04 00             	retf   0x4
    5c34:	55                   	push   bp
    5c35:	89 e5                	mov    bp,sp
    5c37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c3a:	26 8b 85 b2 00       	mov    ax,WORD PTR es:[di+0xb2]
    5c3f:	09 c0                	or     ax,ax
    5c41:	74 15                	je     0x5c58
    5c43:	ff 76 08             	push   WORD PTR [bp+0x8]
    5c46:	ff 76 06             	push   WORD PTR [bp+0x6]
    5c49:	26 ff b5 b6 00       	push   WORD PTR es:[di+0xb6]
    5c4e:	26 ff b5 b4 00       	push   WORD PTR es:[di+0xb4]
    5c53:	26 ff 9d b0 00       	call   DWORD PTR es:[di+0xb0]
    5c58:	c9                   	leave
    5c59:	ca 04 00             	retf   0x4
    5c5c:	55                   	push   bp
    5c5d:	89 e5                	mov    bp,sp
    5c5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c62:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    5c67:	09 c0                	or     ax,ax
    5c69:	74 15                	je     0x5c80
    5c6b:	ff 76 08             	push   WORD PTR [bp+0x8]
    5c6e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5c71:	26 ff b5 06 01       	push   WORD PTR es:[di+0x106]
    5c76:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    5c7b:	26 ff 9d 00 01       	call   DWORD PTR es:[di+0x100]
    5c80:	c9                   	leave
    5c81:	ca 04 00             	retf   0x4
    5c84:	55                   	push   bp
    5c85:	89 e5                	mov    bp,sp
    5c87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c8a:	26 8b 85 d2 00       	mov    ax,WORD PTR es:[di+0xd2]
    5c8f:	09 c0                	or     ax,ax
    5c91:	74 15                	je     0x5ca8
    5c93:	ff 76 08             	push   WORD PTR [bp+0x8]
    5c96:	ff 76 06             	push   WORD PTR [bp+0x6]
    5c99:	26 ff b5 d6 00       	push   WORD PTR es:[di+0xd6]
    5c9e:	26 ff b5 d4 00       	push   WORD PTR es:[di+0xd4]
    5ca3:	26 ff 9d d0 00       	call   DWORD PTR es:[di+0xd0]
    5ca8:	c9                   	leave
    5ca9:	ca 04 00             	retf   0x4
    5cac:	55                   	push   bp
    5cad:	89 e5                	mov    bp,sp
    5caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cb2:	26 8b 85 c2 00       	mov    ax,WORD PTR es:[di+0xc2]
    5cb7:	09 c0                	or     ax,ax
    5cb9:	74 15                	je     0x5cd0
    5cbb:	ff 76 08             	push   WORD PTR [bp+0x8]
    5cbe:	ff 76 06             	push   WORD PTR [bp+0x6]
    5cc1:	26 ff b5 c6 00       	push   WORD PTR es:[di+0xc6]
    5cc6:	26 ff b5 c4 00       	push   WORD PTR es:[di+0xc4]
    5ccb:	26 ff 9d c0 00       	call   DWORD PTR es:[di+0xc0]
    5cd0:	c9                   	leave
    5cd1:	ca 04 00             	retf   0x4
    5cd4:	55                   	push   bp
    5cd5:	89 e5                	mov    bp,sp
    5cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cda:	26 8b 85 a2 00       	mov    ax,WORD PTR es:[di+0xa2]
    5cdf:	09 c0                	or     ax,ax
    5ce1:	74 15                	je     0x5cf8
    5ce3:	ff 76 08             	push   WORD PTR [bp+0x8]
    5ce6:	ff 76 06             	push   WORD PTR [bp+0x6]
    5ce9:	26 ff b5 a6 00       	push   WORD PTR es:[di+0xa6]
    5cee:	26 ff b5 a4 00       	push   WORD PTR es:[di+0xa4]
    5cf3:	26 ff 9d a0 00       	call   DWORD PTR es:[di+0xa0]
    5cf8:	c9                   	leave
    5cf9:	ca 04 00             	retf   0x4
    5cfc:	55                   	push   bp
    5cfd:	89 e5                	mov    bp,sp
    5cff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d02:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    5d07:	09 c0                	or     ax,ax
    5d09:	74 15                	je     0x5d20
    5d0b:	ff 76 08             	push   WORD PTR [bp+0x8]
    5d0e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5d11:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    5d16:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    5d1b:	26 ff 9d e0 00       	call   DWORD PTR es:[di+0xe0]
    5d20:	c9                   	leave
    5d21:	ca 04 00             	retf   0x4
    5d24:	55                   	push   bp
    5d25:	89 e5                	mov    bp,sp
    5d27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d2a:	26 8b 85 1a 01       	mov    ax,WORD PTR es:[di+0x11a]
    5d2f:	09 c0                	or     ax,ax
    5d31:	74 15                	je     0x5d48
    5d33:	ff 76 08             	push   WORD PTR [bp+0x8]
    5d36:	ff 76 06             	push   WORD PTR [bp+0x6]
    5d39:	26 ff b5 1e 01       	push   WORD PTR es:[di+0x11e]
    5d3e:	26 ff b5 1c 01       	push   WORD PTR es:[di+0x11c]
    5d43:	26 ff 9d 18 01       	call   DWORD PTR es:[di+0x118]
    5d48:	c9                   	leave
    5d49:	ca 04 00             	retf   0x4
    5d4c:	55                   	push   bp
    5d4d:	89 e5                	mov    bp,sp
    5d4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d52:	26 8b 85 12 01       	mov    ax,WORD PTR es:[di+0x112]
    5d57:	09 c0                	or     ax,ax
    5d59:	74 15                	je     0x5d70
    5d5b:	ff 76 08             	push   WORD PTR [bp+0x8]
    5d5e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5d61:	26 ff b5 16 01       	push   WORD PTR es:[di+0x116]
    5d66:	26 ff b5 14 01       	push   WORD PTR es:[di+0x114]
    5d6b:	26 ff 9d 10 01       	call   DWORD PTR es:[di+0x110]
    5d70:	c9                   	leave
    5d71:	ca 04 00             	retf   0x4
    5d74:	55                   	push   bp
    5d75:	89 e5                	mov    bp,sp
    5d77:	6a 00                	push   0x0
    5d79:	6a 01                	push   0x1
    5d7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d7e:	06                   	push   es
    5d7f:	57                   	push   di
    5d80:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d83:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    5d88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d8b:	06                   	push   es
    5d8c:	57                   	push   di
    5d8d:	9a 0b 33 9f 5d       	call   0x5d9f:0x330b
    5d92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d95:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5d9a:	06                   	push   es
    5d9b:	57                   	push   di
    5d9c:	9a 7a 21 ce 5d       	call   0x5dce:0x217a
    5da1:	08 c0                	or     al,al
    5da3:	74 2b                	je     0x5dd0
    5da5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5da8:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    5dad:	74 21                	je     0x5dd0
    5daf:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5db3:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5db7:	68 05 04             	push   0x405
    5dba:	6a 00                	push   0x0
    5dbc:	26 8a 85 22 01       	mov    al,BYTE PTR es:[di+0x122]
    5dc1:	98                   	cbw
    5dc2:	99                   	cwd
    5dc3:	52                   	push   dx
    5dc4:	50                   	push   ax
    5dc5:	9a bd 21 52 67       	call   0x6752:0x21bd
    5dca:	50                   	push   ax
    5dcb:	9a 4e 12 df 5d       	call   0x5ddf:0x124e
    5dd0:	c9                   	leave
    5dd1:	ca 04 00             	retf   0x4
    5dd4:	55                   	push   bp
    5dd5:	89 e5                	mov    bp,sp
    5dd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dda:	06                   	push   es
    5ddb:	57                   	push   di
    5ddc:	9a 70 33 01 5e       	call   0x5e01:0x3370
    5de1:	6a 00                	push   0x0
    5de3:	6a 00                	push   0x0
    5de5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5de8:	06                   	push   es
    5de9:	57                   	push   di
    5dea:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ded:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    5df2:	c9                   	leave
    5df3:	ca 04 00             	retf   0x4
    5df6:	55                   	push   bp
    5df7:	89 e5                	mov    bp,sp
    5df9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dfc:	06                   	push   es
    5dfd:	57                   	push   di
    5dfe:	9a d2 31 44 5e       	call   0x5e44:0x31d2
    5e03:	c9                   	leave
    5e04:	ca 04 00             	retf   0x4
    5e07:	55                   	push   bp
    5e08:	89 e5                	mov    bp,sp
    5e0a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5e0e:	75 03                	jne    0x5e13
    5e10:	e9 89 00             	jmp    0x5e9c
    5e13:	8a 4e 0c             	mov    cl,BYTE PTR [bp+0xc]
    5e16:	80 f9 10             	cmp    cl,0x10
    5e19:	73 0f                	jae    0x5e2a
    5e1b:	b8 01 00             	mov    ax,0x1
    5e1e:	d3 c0                	rol    ax,cl
    5e20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e23:	26 85 85 20 01       	test   WORD PTR es:[di+0x120],ax
    5e28:	75 6f                	jne    0x5e99
    5e2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e2d:	26 83 bd 20 01 00    	cmp    WORD PTR es:[di+0x120],0x0
    5e33:	75 4f                	jne    0x5e84
    5e35:	81 c7 28 01          	add    di,0x128
    5e39:	06                   	push   es
    5e3a:	57                   	push   di
    5e3b:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    5e3f:	06                   	push   es
    5e40:	57                   	push   di
    5e41:	9a 96 1b 16 5f       	call   0x5f16:0x1b96
    5e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e49:	26 89 85 24 01       	mov    WORD PTR es:[di+0x124],ax
    5e4e:	26 89 95 26 01       	mov    WORD PTR es:[di+0x126],dx
    5e53:	ff 76 08             	push   WORD PTR [bp+0x8]
    5e56:	ff 76 06             	push   WORD PTR [bp+0x6]
    5e59:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5e5e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5e62:	06                   	push   es
    5e63:	57                   	push   di
    5e64:	9a 2b 0c fe 5e       	call   0x5efe:0xc2b
    5e69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e6c:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5e71:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    5e75:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    5e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e7c:	26 89 45 56          	mov    WORD PTR es:[di+0x56],ax
    5e80:	26 89 55 58          	mov    WORD PTR es:[di+0x58],dx
    5e84:	8a 4e 0c             	mov    cl,BYTE PTR [bp+0xc]
    5e87:	80 f9 10             	cmp    cl,0x10
    5e8a:	73 0d                	jae    0x5e99
    5e8c:	b8 01 00             	mov    ax,0x1
    5e8f:	d3 c0                	rol    ax,cl
    5e91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e94:	26 09 85 20 01       	or     WORD PTR es:[di+0x120],ax
    5e99:	e9 8b 00             	jmp    0x5f27
    5e9c:	8a 4e 0c             	mov    cl,BYTE PTR [bp+0xc]
    5e9f:	80 f9 10             	cmp    cl,0x10
    5ea2:	72 03                	jb     0x5ea7
    5ea4:	e9 80 00             	jmp    0x5f27
    5ea7:	b8 01 00             	mov    ax,0x1
    5eaa:	d3 c0                	rol    ax,cl
    5eac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5eaf:	26 85 85 20 01       	test   WORD PTR es:[di+0x120],ax
    5eb4:	74 71                	je     0x5f27
    5eb6:	8a 4e 0c             	mov    cl,BYTE PTR [bp+0xc]
    5eb9:	80 f9 10             	cmp    cl,0x10
    5ebc:	73 0a                	jae    0x5ec8
    5ebe:	b8 fe ff             	mov    ax,0xfffe
    5ec1:	d3 c0                	rol    ax,cl
    5ec3:	26 21 85 20 01       	and    WORD PTR es:[di+0x120],ax
    5ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ecb:	26 83 bd 20 01 00    	cmp    WORD PTR es:[di+0x120],0x0
    5ed1:	75 54                	jne    0x5f27
    5ed3:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    5ed7:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    5edb:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    5edf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ee2:	26 89 45 56          	mov    WORD PTR es:[di+0x56],ax
    5ee6:	26 89 55 58          	mov    WORD PTR es:[di+0x58],dx
    5eea:	ff 76 08             	push   WORD PTR [bp+0x8]
    5eed:	ff 76 06             	push   WORD PTR [bp+0x6]
    5ef0:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5ef5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5ef9:	06                   	push   es
    5efa:	57                   	push   di
    5efb:	9a a7 0f 10 60       	call   0x6010:0xfa7
    5f00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f03:	26 ff b5 26 01       	push   WORD PTR es:[di+0x126]
    5f08:	26 ff b5 24 01       	push   WORD PTR es:[di+0x124]
    5f0d:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    5f11:	06                   	push   es
    5f12:	57                   	push   di
    5f13:	9a d3 17 c1 5f       	call   0x5fc1:0x17d3
    5f18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f1b:	31 c0                	xor    ax,ax
    5f1d:	26 89 85 24 01       	mov    WORD PTR es:[di+0x124],ax
    5f22:	26 89 85 26 01       	mov    WORD PTR es:[di+0x126],ax
    5f27:	c9                   	leave
    5f28:	ca 08 00             	retf   0x8
    5f2b:	c8 04 00 00          	enter  0x4,0x0
    5f2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f32:	26 8b 85 24 01       	mov    ax,WORD PTR es:[di+0x124]
    5f37:	26 0b 85 26 01       	or     ax,WORD PTR es:[di+0x126]
    5f3c:	74 15                	je     0x5f53
    5f3e:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5f43:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    5f47:	26 8b 55 2a          	mov    dx,WORD PTR es:[di+0x2a]
    5f4b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5f4e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5f51:	eb 08                	jmp    0x5f5b
    5f53:	31 c0                	xor    ax,ax
    5f55:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5f58:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5f5b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5f5e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5f61:	c9                   	leave
    5f62:	ca 04 00             	retf   0x4
    5f65:	c8 04 00 00          	enter  0x4,0x0
    5f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f6c:	26 8b 85 24 01       	mov    ax,WORD PTR es:[di+0x124]
    5f71:	26 0b 85 26 01       	or     ax,WORD PTR es:[di+0x126]
    5f76:	74 15                	je     0x5f8d
    5f78:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5f7d:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    5f81:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    5f85:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5f88:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5f8b:	eb 12                	jmp    0x5f9f
    5f8d:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    5f91:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    5f95:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    5f99:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5f9c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5f9f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5fa2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5fa5:	c9                   	leave
    5fa6:	ca 04 00             	retf   0x4
    5fa9:	55                   	push   bp
    5faa:	89 e5                	mov    bp,sp
    5fac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5faf:	26 8b 85 24 01       	mov    ax,WORD PTR es:[di+0x124]
    5fb4:	26 0b 85 26 01       	or     ax,WORD PTR es:[di+0x126]
    5fb9:	74 08                	je     0x5fc3
    5fbb:	68 02 f2             	push   0xf202
    5fbe:	9a ef 11 77 60       	call   0x6077:0x11ef
    5fc3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5fc6:	06                   	push   es
    5fc7:	57                   	push   di
    5fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fcb:	81 c7 28 01          	add    di,0x128
    5fcf:	06                   	push   es
    5fd0:	57                   	push   di
    5fd1:	6a 4f                	push   0x4f
    5fd3:	9a e7 17 fd 5f       	call   0x5ffd:0x17e7
    5fd8:	6a 08                	push   0x8
    5fda:	6a 00                	push   0x0
    5fdc:	6a 00                	push   0x0
    5fde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fe1:	06                   	push   es
    5fe2:	57                   	push   di
    5fe3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5fe6:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    5fea:	c9                   	leave
    5feb:	ca 08 00             	retf   0x8
    5fee:	55                   	push   bp
    5fef:	89 e5                	mov    bp,sp
    5ff1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5ff5:	74 08                	je     0x5fff
    5ff7:	83 ec 08             	sub    sp,0x8
    5ffa:	9a e2 1f d3 60       	call   0x60d3:0x1fe2
    5fff:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6002:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6005:	31 c0                	xor    ax,ax
    6007:	50                   	push   ax
    6008:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    600b:	06                   	push   es
    600c:	57                   	push   di
    600d:	9a d9 4b c8 60       	call   0x60c8:0x4bd9
    6012:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6015:	26 c6 45 26 01       	mov    BYTE PTR es:[di+0x26],0x1
    601a:	a1 16 17             	mov    ax,ds:0x1716
    601d:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    6021:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    6025:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
    6029:	a1 16 17             	mov    ax,ds:0x1716
    602c:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    6030:	26 89 45 34          	mov    WORD PTR es:[di+0x34],ax
    6034:	26 89 55 36          	mov    WORD PTR es:[di+0x36],dx
    6038:	a1 16 17             	mov    ax,ds:0x1716
    603b:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    603f:	26 89 45 38          	mov    WORD PTR es:[di+0x38],ax
    6043:	26 89 55 3a          	mov    WORD PTR es:[di+0x3a],dx
    6047:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    604b:	74 07                	je     0x6054
    604d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6051:	83 c4 06             	add    sp,0x6
    6054:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6057:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    605a:	c9                   	leave
    605b:	ca 0a 00             	retf   0xa
    605e:	55                   	push   bp
    605f:	89 e5                	mov    bp,sp
    6061:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6064:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6068:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    606c:	74 1f                	je     0x608d
    606e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6072:	06                   	push   es
    6073:	57                   	push   di
    6074:	9a d2 31 8b 60       	call   0x608b:0x31d2
    6079:	ff 76 08             	push   WORD PTR [bp+0x8]
    607c:	ff 76 06             	push   WORD PTR [bp+0x6]
    607f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6082:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6086:	06                   	push   es
    6087:	57                   	push   di
    6088:	9a 0a 3b e8 60       	call   0x60e8:0x3b0a
    608d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6090:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    6094:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    6098:	9a 24 06 ab 60       	call   0x60ab:0x624
    609d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60a0:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    60a4:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    60a8:	9a 24 06 bb 60       	call   0x60bb:0x624
    60ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60b0:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    60b4:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    60b8:	9a 24 06 49 63       	call   0x6349:0x624
    60bd:	31 c0                	xor    ax,ax
    60bf:	50                   	push   ax
    60c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60c3:	06                   	push   es
    60c4:	57                   	push   di
    60c5:	9a 2b 4c 2a 62       	call   0x622a:0x4c2b
    60ca:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    60ce:	74 05                	je     0x60d5
    60d0:	9a 0f 20 49 61       	call   0x6149:0x200f
    60d5:	c9                   	leave
    60d6:	ca 06 00             	retf   0x6
    60d9:	c8 10 00 00          	enter  0x10,0x0
    60dd:	68 18 f2             	push   0xf218
    60e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60e3:	06                   	push   es
    60e4:	57                   	push   di
    60e5:	9a f6 67 17 61       	call   0x6117:0x67f6
    60ea:	89 c7                	mov    di,ax
    60ec:	8e c2                	mov    es,dx
    60ee:	89 f8                	mov    ax,di
    60f0:	8c c2                	mov    dx,es
    60f2:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    60f5:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    60f8:	c6 46 f4 04          	mov    BYTE PTR [bp-0xc],0x4
    60fc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    60ff:	89 f8                	mov    ax,di
    6101:	8c c2                	mov    dx,es
    6103:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6106:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6109:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    610d:	8d 7e f0             	lea    di,[bp-0x10]
    6110:	16                   	push   ss
    6111:	57                   	push   di
    6112:	6a 01                	push   0x1
    6114:	9a 0a 12 42 61       	call   0x6142:0x120a
    6119:	c9                   	leave
    611a:	ca 08 00             	retf   0x8
    611d:	c8 10 01 00          	enter  0x110,0x0
    6121:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6124:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    6127:	75 0f                	jne    0x6138
    6129:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    612c:	06                   	push   es
    612d:	57                   	push   di
    612e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6131:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    6135:	e9 f4 00             	jmp    0x622c
    6138:	ff 76 0c             	push   WORD PTR [bp+0xc]
    613b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    613e:	bf b2 0a             	mov    di,0xab2
    6141:	b8 a3 61             	mov    ax,0x61a3
    6144:	50                   	push   ax
    6145:	57                   	push   di
    6146:	9a 55 22 d9 62       	call   0x62d9:0x2255
    614b:	08 c0                	or     al,al
    614d:	75 03                	jne    0x6152
    614f:	e9 ca 00             	jmp    0x621c
    6152:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6155:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    615a:	74 3c                	je     0x6198
    615c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    615f:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    6164:	74 32                	je     0x6198
    6166:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6169:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    616d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6170:	26 3a 45 22          	cmp    al,BYTE PTR es:[di+0x22]
    6174:	75 22                	jne    0x6198
    6176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6179:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    617d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6180:	26 3b 45 2a          	cmp    ax,WORD PTR es:[di+0x2a]
    6184:	75 12                	jne    0x6198
    6186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6189:	26 80 7d 22 0e       	cmp    BYTE PTR es:[di+0x22],0xe
    618e:	74 08                	je     0x6198
    6190:	26 81 7d 2c 00 01    	cmp    WORD PTR es:[di+0x2c],0x100
    6196:	76 4e                	jbe    0x61e6
    6198:	68 19 f2             	push   0xf219
    619b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    619e:	06                   	push   es
    619f:	57                   	push   di
    61a0:	9a f6 67 c2 61       	call   0x61c2:0x67f6
    61a5:	89 c7                	mov    di,ax
    61a7:	8e c2                	mov    es,dx
    61a9:	89 f8                	mov    ax,di
    61ab:	8c c2                	mov    dx,es
    61ad:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    61b1:	89 96 f2 fe          	mov    WORD PTR [bp-0x10e],dx
    61b5:	c6 86 f4 fe 04       	mov    BYTE PTR [bp-0x10c],0x4
    61ba:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    61bd:	06                   	push   es
    61be:	57                   	push   di
    61bf:	9a f6 67 e4 61       	call   0x61e4:0x67f6
    61c4:	89 c7                	mov    di,ax
    61c6:	8e c2                	mov    es,dx
    61c8:	89 f8                	mov    ax,di
    61ca:	8c c2                	mov    dx,es
    61cc:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    61d0:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    61d4:	c6 86 fc fe 04       	mov    BYTE PTR [bp-0x104],0x4
    61d9:	8d be f0 fe          	lea    di,[bp-0x110]
    61dd:	16                   	push   ss
    61de:	57                   	push   di
    61df:	6a 01                	push   0x1
    61e1:	9a 0a 12 f4 61       	call   0x61f4:0x120a
    61e6:	8d be 00 ff          	lea    di,[bp-0x100]
    61ea:	16                   	push   ss
    61eb:	57                   	push   di
    61ec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    61ef:	06                   	push   es
    61f0:	57                   	push   di
    61f1:	9a 35 66 08 62       	call   0x6208:0x6635
    61f6:	08 c0                	or     al,al
    61f8:	74 12                	je     0x620c
    61fa:	8d be 00 ff          	lea    di,[bp-0x100]
    61fe:	16                   	push   ss
    61ff:	57                   	push   di
    6200:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6203:	06                   	push   es
    6204:	57                   	push   di
    6205:	9a de 6b 18 62       	call   0x6218:0x6bde
    620a:	eb 0e                	jmp    0x621a
    620c:	6a 00                	push   0x0
    620e:	6a 00                	push   0x0
    6210:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6213:	06                   	push   es
    6214:	57                   	push   di
    6215:	9a de 6b 43 62       	call   0x6243:0x6bde
    621a:	eb 10                	jmp    0x622c
    621c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    621f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6222:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6225:	06                   	push   es
    6226:	57                   	push   di
    6227:	9a fa 10 70 63       	call   0x6370:0x10fa
    622c:	c9                   	leave
    622d:	ca 08 00             	retf   0x8
    6230:	c8 08 00 00          	enter  0x8,0x0
    6234:	68 1a f2             	push   0xf21a
    6237:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    623a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    623e:	06                   	push   es
    623f:	57                   	push   di
    6240:	9a f6 67 61 62       	call   0x6261:0x67f6
    6245:	89 c7                	mov    di,ax
    6247:	8e c2                	mov    es,dx
    6249:	89 f8                	mov    ax,di
    624b:	8c c2                	mov    dx,es
    624d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6250:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6253:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    6257:	8d 7e f8             	lea    di,[bp-0x8]
    625a:	16                   	push   ss
    625b:	57                   	push   di
    625c:	6a 00                	push   0x0
    625e:	9a 0a 12 e0 63       	call   0x63e0:0x120a
    6263:	c9                   	leave
    6264:	c2 02 00             	ret    0x2
    6267:	9a 62 b3 62 c9       	call   0xc962:0xb362
    626c:	62 ea 62             	(bad)  {k6}
    626f:	0e                   	push   cs
    6270:	63 24                	arpl   WORD PTR [si],sp
    6272:	63 36 63 59          	arpl   WORD PTR ds:0x5963,si
    6276:	63 c8                	arpl   ax,cx
    6278:	04 01                	add    al,0x1
    627a:	00 c4                	add    ah,al
    627c:	7e 0a                	jle    0x6288
    627e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6281:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6284:	26 8a 45 04          	mov    al,BYTE PTR es:[di+0x4]
    6288:	3c 07                	cmp    al,0x7
    628a:	76 03                	jbe    0x628f
    628c:	e9 0c 01             	jmp    0x639b
    628f:	30 e4                	xor    ah,ah
    6291:	89 c3                	mov    bx,ax
    6293:	d1 e3                	shl    bx,1
    6295:	2e ff a7 67 62       	jmp    WORD PTR cs:[bx+0x6267]
    629a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    629d:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    62a1:	26 ff 35             	push   WORD PTR es:[di]
    62a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62a7:	06                   	push   es
    62a8:	57                   	push   di
    62a9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62ac:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    62b0:	e9 ec 00             	jmp    0x639f
    62b3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    62b6:	26 8a 05             	mov    al,BYTE PTR es:[di]
    62b9:	50                   	push   ax
    62ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62bd:	06                   	push   es
    62be:	57                   	push   di
    62bf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62c2:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    62c6:	e9 d6 00             	jmp    0x639f
    62c9:	8d be fc fe          	lea    di,[bp-0x104]
    62cd:	16                   	push   ss
    62ce:	57                   	push   di
    62cf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    62d2:	26 8a 05             	mov    al,BYTE PTR es:[di]
    62d5:	50                   	push   ax
    62d6:	9a e9 18 77 63       	call   0x6377:0x18e9
    62db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62de:	06                   	push   es
    62df:	57                   	push   di
    62e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62e3:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    62e7:	e9 b5 00             	jmp    0x639f
    62ea:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    62ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62f0:	9b 26 db 2d          	fld    TBYTE PTR es:[di]
    62f4:	83 ec 08             	sub    sp,0x8
    62f7:	89 e3                	mov    bx,sp
    62f9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    62fd:	90                   	nop
    62fe:	9b                   	fwait
    62ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6302:	06                   	push   es
    6303:	57                   	push   di
    6304:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6307:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    630b:	e9 91 00             	jmp    0x639f
    630e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6311:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6314:	06                   	push   es
    6315:	57                   	push   di
    6316:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6319:	06                   	push   es
    631a:	57                   	push   di
    631b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    631e:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    6322:	eb 7b                	jmp    0x639f
    6324:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6327:	26 8b 05             	mov    ax,WORD PTR es:[di]
    632a:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    632e:	74 04                	je     0x6334
    6330:	55                   	push   bp
    6331:	e8 fc fe             	call   0x6230
    6334:	eb 69                	jmp    0x639f
    6336:	8d be fc fe          	lea    di,[bp-0x104]
    633a:	16                   	push   ss
    633b:	57                   	push   di
    633c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    633f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6343:	26 ff 35             	push   WORD PTR es:[di]
    6346:	9a 6e 0e 71 65       	call   0x6571:0xe6e
    634b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    634e:	06                   	push   es
    634f:	57                   	push   di
    6350:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6353:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    6357:	eb 46                	jmp    0x639f
    6359:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    635c:	26 8b 05             	mov    ax,WORD PTR es:[di]
    635f:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    6363:	74 18                	je     0x637d
    6365:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6369:	26 ff 35             	push   WORD PTR es:[di]
    636c:	bf d1 02             	mov    di,0x2d1
    636f:	b8 60 69             	mov    ax,0x6960
    6372:	50                   	push   ax
    6373:	57                   	push   di
    6374:	9a 55 22 24 65       	call   0x6524:0x2255
    6379:	08 c0                	or     al,al
    637b:	74 18                	je     0x6395
    637d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6380:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6384:	26 ff 35             	push   WORD PTR es:[di]
    6387:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    638a:	06                   	push   es
    638b:	57                   	push   di
    638c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    638f:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    6393:	eb 04                	jmp    0x6399
    6395:	55                   	push   bp
    6396:	e8 97 fe             	call   0x6230
    6399:	eb 04                	jmp    0x639f
    639b:	55                   	push   bp
    639c:	e8 91 fe             	call   0x6230
    639f:	c9                   	leave
    63a0:	ca 08 00             	retf   0x8
    63a3:	55                   	push   bp
    63a4:	89 e5                	mov    bp,sp
    63a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63a9:	26 8b 45 42          	mov    ax,WORD PTR es:[di+0x42]
    63ad:	09 c0                	or     ax,ax
    63af:	74 12                	je     0x63c3
    63b1:	ff 76 08             	push   WORD PTR [bp+0x8]
    63b4:	ff 76 06             	push   WORD PTR [bp+0x6]
    63b7:	26 ff 75 46          	push   WORD PTR es:[di+0x46]
    63bb:	26 ff 75 44          	push   WORD PTR es:[di+0x44]
    63bf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    63c3:	c9                   	leave
    63c4:	ca 04 00             	retf   0x4
    63c7:	55                   	push   bp
    63c8:	89 e5                	mov    bp,sp
    63ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63cd:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    63d1:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    63d5:	74 17                	je     0x63ee
    63d7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    63db:	06                   	push   es
    63dc:	57                   	push   di
    63dd:	9a 02 32 ec 63       	call   0x63ec:0x3202
    63e2:	08 c0                	or     al,al
    63e4:	74 08                	je     0x63ee
    63e6:	68 04 f2             	push   0xf204
    63e9:	9a ef 11 01 64       	call   0x6401:0x11ef
    63ee:	c9                   	leave
    63ef:	ca 04 00             	retf   0x4
    63f2:	55                   	push   bp
    63f3:	89 e5                	mov    bp,sp
    63f5:	6a 00                	push   0x0
    63f7:	6a 00                	push   0x0
    63f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63fc:	06                   	push   es
    63fd:	57                   	push   di
    63fe:	9a de 6b 40 64       	call   0x6440:0x6bde
    6403:	c9                   	leave
    6404:	ca 04 00             	retf   0x4
    6407:	55                   	push   bp
    6408:	89 e5                	mov    bp,sp
    640a:	6a 00                	push   0x0
    640c:	ff 76 08             	push   WORD PTR [bp+0x8]
    640f:	ff 76 06             	push   WORD PTR [bp+0x6]
    6412:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6415:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6419:	06                   	push   es
    641a:	57                   	push   di
    641b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    641e:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    6422:	c9                   	leave
    6423:	ca 04 00             	retf   0x4
    6426:	c8 04 00 00          	enter  0x4,0x0
    642a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    642d:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6431:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6435:	74 32                	je     0x6469
    6437:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    643b:	06                   	push   es
    643c:	57                   	push   di
    643d:	9a 02 32 8d 64       	call   0x648d:0x3202
    6442:	08 c0                	or     al,al
    6444:	74 23                	je     0x6469
    6446:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6449:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    644c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    644f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6452:	6a 0a                	push   0xa
    6454:	8d 7e fc             	lea    di,[bp-0x4]
    6457:	16                   	push   ss
    6458:	57                   	push   di
    6459:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    645c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6460:	06                   	push   es
    6461:	57                   	push   di
    6462:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6465:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    6469:	c9                   	leave
    646a:	ca 04 00             	retf   0x4
    646d:	55                   	push   bp
    646e:	89 e5                	mov    bp,sp
    6470:	c9                   	leave
    6471:	ca 04 00             	retf   0x4
    6474:	07                   	pop    es
    6475:	42                   	inc    dx
    6476:	6f                   	outs   dx,WORD PTR ds:[si]
    6477:	6f                   	outs   dx,WORD PTR ds:[si]
    6478:	6c                   	ins    BYTE PTR es:[di],dx
    6479:	65 61                	gs popa
    647b:	6e                   	outs   dx,BYTE PTR ds:[si]
    647c:	c8 02 00 00          	enter  0x2,0x0
    6480:	bf 74 64             	mov    di,0x6474
    6483:	0e                   	push   cs
    6484:	57                   	push   di
    6485:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6488:	06                   	push   es
    6489:	57                   	push   di
    648a:	9a d9 60 b0 64       	call   0x64b0:0x60d9
    648f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6492:	c9                   	leave
    6493:	ca 04 00             	retf   0x4
    6496:	08 44 61             	or     BYTE PTR [si+0x61],al
    6499:	74 65                	je     0x6500
    649b:	54                   	push   sp
    649c:	69 6d 65 c8 08       	imul   bp,WORD PTR [di+0x65],0x8c8
    64a1:	00 00                	add    BYTE PTR [bx+si],al
    64a3:	bf 96 64             	mov    di,0x6496
    64a6:	0e                   	push   cs
    64a7:	57                   	push   di
    64a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64ab:	06                   	push   es
    64ac:	57                   	push   di
    64ad:	9a d9 60 d3 64       	call   0x64d3:0x60d9
    64b2:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    64b6:	90                   	nop
    64b7:	9b                   	fwait
    64b8:	c9                   	leave
    64b9:	ca 04 00             	retf   0x4
    64bc:	05 46 6c             	add    ax,0x6c46
    64bf:	6f                   	outs   dx,WORD PTR ds:[si]
    64c0:	61                   	popa
    64c1:	74 c8                	je     0x648b
    64c3:	08 00                	or     BYTE PTR [bx+si],al
    64c5:	00 bf bc 64          	add    BYTE PTR [bx+0x64bc],bh
    64c9:	0e                   	push   cs
    64ca:	57                   	push   di
    64cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64ce:	06                   	push   es
    64cf:	57                   	push   di
    64d0:	9a d9 60 f8 64       	call   0x64f8:0x60d9
    64d5:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    64d9:	90                   	nop
    64da:	9b                   	fwait
    64db:	c9                   	leave
    64dc:	ca 04 00             	retf   0x4
    64df:	07                   	pop    es
    64e0:	49                   	dec    cx
    64e1:	6e                   	outs   dx,BYTE PTR ds:[si]
    64e2:	74 65                	je     0x6549
    64e4:	67 65 72 c8          	addr32 gs jb 0x64b0
    64e8:	04 00                	add    al,0x0
    64ea:	00 bf df 64          	add    BYTE PTR [bx+0x64df],bh
    64ee:	0e                   	push   cs
    64ef:	57                   	push   di
    64f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64f3:	06                   	push   es
    64f4:	57                   	push   di
    64f5:	9a d9 60 19 66       	call   0x6619:0x60d9
    64fa:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    64fd:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6500:	c9                   	leave
    6501:	ca 04 00             	retf   0x4
    6504:	05 46 49             	add    ax,0x4946
    6507:	45                   	inc    bp
    6508:	4c                   	dec    sp
    6509:	44                   	inc    sp
    650a:	04 28                	add    al,0x28
    650c:	25 73 29             	and    ax,0x2973
    650f:	c8 4c 01 00          	enter  0x14c,0x0
    6513:	8d be bc fe          	lea    di,[bp-0x144]
    6517:	16                   	push   ss
    6518:	57                   	push   di
    6519:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    651c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    651f:	06                   	push   es
    6520:	57                   	push   di
    6521:	9a ed 20 30 65       	call   0x6530:0x20ed
    6526:	8d 7e bc             	lea    di,[bp-0x44]
    6529:	16                   	push   ss
    652a:	57                   	push   di
    652b:	6a 3f                	push   0x3f
    652d:	9a e7 17 67 65       	call   0x6567:0x17e7
    6532:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    6537:	8a 46 bc             	mov    al,BYTE PTR [bp-0x44]
    653a:	30 e4                	xor    ah,ah
    653c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    653f:	80 7e bd 54          	cmp    BYTE PTR [bp-0x43],0x54
    6543:	75 05                	jne    0x654a
    6545:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    654a:	83 7e fc 05          	cmp    WORD PTR [bp-0x4],0x5
    654e:	7c 2b                	jl     0x657b
    6550:	8d be bc fe          	lea    di,[bp-0x144]
    6554:	16                   	push   ss
    6555:	57                   	push   di
    6556:	8d 7e bc             	lea    di,[bp-0x44]
    6559:	16                   	push   ss
    655a:	57                   	push   di
    655b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    655e:	2d 04 00             	sub    ax,0x4
    6561:	50                   	push   ax
    6562:	6a 05                	push   0x5
    6564:	9a 0b 18 a1 65       	call   0x65a1:0x180b
    6569:	bf 04 65             	mov    di,0x6504
    656c:	0e                   	push   cs
    656d:	57                   	push   di
    656e:	9a 30 07 c4 65       	call   0x65c4:0x730
    6573:	09 c0                	or     ax,ax
    6575:	75 04                	jne    0x657b
    6577:	83 6e fc 05          	sub    WORD PTR [bp-0x4],0x5
    657b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    657e:	06                   	push   es
    657f:	57                   	push   di
    6580:	68 ff 00             	push   0xff
    6583:	bf 0a 65             	mov    di,0x650a
    6586:	0e                   	push   cs
    6587:	57                   	push   di
    6588:	8d be bc fe          	lea    di,[bp-0x144]
    658c:	16                   	push   ss
    658d:	57                   	push   di
    658e:	8d 7e bc             	lea    di,[bp-0x44]
    6591:	16                   	push   ss
    6592:	57                   	push   di
    6593:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6596:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6599:	40                   	inc    ax
    659a:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    659d:	50                   	push   ax
    659e:	9a 0b 18 28 67       	call   0x6728:0x180b
    65a3:	83 c4 04             	add    sp,0x4
    65a6:	8d 86 bc fe          	lea    ax,[bp-0x144]
    65aa:	8c d2                	mov    dx,ss
    65ac:	89 86 b4 fe          	mov    WORD PTR [bp-0x14c],ax
    65b0:	89 96 b6 fe          	mov    WORD PTR [bp-0x14a],dx
    65b4:	c6 86 b8 fe 04       	mov    BYTE PTR [bp-0x148],0x4
    65b9:	8d be b4 fe          	lea    di,[bp-0x14c]
    65bd:	16                   	push   ss
    65be:	57                   	push   di
    65bf:	6a 00                	push   0x0
    65c1:	9a 6c 10 fb 6e       	call   0x6efb:0x106c
    65c6:	c9                   	leave
    65c7:	ca 04 00             	retf   0x4
    65ca:	c8 02 00 00          	enter  0x2,0x0
    65ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65d1:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    65d6:	7e 52                	jle    0x662a
    65d8:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    65dc:	26 80 7d 3a 04       	cmp    BYTE PTR es:[di+0x3a],0x4
    65e1:	74 20                	je     0x6603
    65e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65e6:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    65eb:	75 0b                	jne    0x65f8
    65ed:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    65f1:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    65f6:	75 04                	jne    0x65fc
    65f8:	b0 00                	mov    al,0x0
    65fa:	eb 02                	jmp    0x65fe
    65fc:	b0 01                	mov    al,0x1
    65fe:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6601:	eb 25                	jmp    0x6628
    6603:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6606:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    660a:	26 83 7d 7e 00       	cmp    WORD PTR es:[di+0x7e],0x0
    660f:	74 12                	je     0x6623
    6611:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6614:	06                   	push   es
    6615:	57                   	push   di
    6616:	9a 73 69 4e 66       	call   0x664e:0x6973
    661b:	08 c0                	or     al,al
    661d:	75 04                	jne    0x6623
    661f:	b0 00                	mov    al,0x0
    6621:	eb 02                	jmp    0x6625
    6623:	b0 01                	mov    al,0x1
    6625:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6628:	eb 04                	jmp    0x662e
    662a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    662e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6631:	c9                   	leave
    6632:	ca 04 00             	retf   0x4
    6635:	c8 10 00 00          	enter  0x10,0x0
    6639:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    663c:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6640:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6644:	75 28                	jne    0x666e
    6646:	68 09 f2             	push   0xf209
    6649:	06                   	push   es
    664a:	57                   	push   di
    664b:	9a f6 67 6c 66       	call   0x666c:0x67f6
    6650:	89 c7                	mov    di,ax
    6652:	8e c2                	mov    es,dx
    6654:	89 f8                	mov    ax,di
    6656:	8c c2                	mov    dx,es
    6658:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    665b:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    665e:	c6 46 f4 04          	mov    BYTE PTR [bp-0xc],0x4
    6662:	8d 7e f0             	lea    di,[bp-0x10]
    6665:	16                   	push   ss
    6666:	57                   	push   di
    6667:	6a 00                	push   0x0
    6669:	9a 0a 12 58 67       	call   0x6758:0x120a
    666e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    6672:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6675:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6679:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    667c:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    667f:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    6683:	3c 04                	cmp    al,0x4
    6685:	75 13                	jne    0x669a
    6687:	26 8b 45 76          	mov    ax,WORD PTR es:[di+0x76]
    668b:	26 8b 55 78          	mov    dx,WORD PTR es:[di+0x78]
    668f:	05 04 00             	add    ax,0x4
    6692:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6695:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6698:	eb 44                	jmp    0x66de
    669a:	3c 05                	cmp    al,0x5
    669c:	75 13                	jne    0x66b1
    669e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    66a1:	26 8b 45 7a          	mov    ax,WORD PTR es:[di+0x7a]
    66a5:	26 8b 55 7c          	mov    dx,WORD PTR es:[di+0x7c]
    66a9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    66ac:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    66af:	eb 2d                	jmp    0x66de
    66b1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    66b4:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    66b8:	26 3b 45 2e          	cmp    ax,WORD PTR es:[di+0x2e]
    66bc:	7c 03                	jl     0x66c1
    66be:	e9 fa 00             	jmp    0x67bb
    66c1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    66c4:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    66c8:	c1 e0 02             	shl    ax,0x2
    66cb:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    66cf:	03 f8                	add    di,ax
    66d1:	26 8b 05             	mov    ax,WORD PTR es:[di]
    66d4:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    66d8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    66db:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    66de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66e1:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    66e6:	7f 03                	jg     0x66eb
    66e8:	e9 7d 00             	jmp    0x6768
    66eb:	26 80 7d 28 00       	cmp    BYTE PTR es:[di+0x28],0x0
    66f0:	74 3a                	je     0x672c
    66f2:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    66f6:	26 8b 55 3e          	mov    dx,WORD PTR es:[di+0x3e]
    66fa:	09 d0                	or     ax,dx
    66fc:	f7 d8                	neg    ax
    66fe:	18 c0                	sbb    al,al
    6700:	f6 d8                	neg    al
    6702:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6705:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    6709:	74 1f                	je     0x672a
    670b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    670e:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    6711:	74 17                	je     0x672a
    6713:	26 c4 7d 3c          	les    di,DWORD PTR es:[di+0x3c]
    6717:	06                   	push   es
    6718:	57                   	push   di
    6719:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    671c:	06                   	push   es
    671d:	57                   	push   di
    671e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6721:	26 ff 75 2c          	push   WORD PTR es:[di+0x2c]
    6725:	9a c1 1e b9 67       	call   0x67b9:0x1ec1
    672a:	eb 3a                	jmp    0x6766
    672c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    672f:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    6733:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    6737:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    673a:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    673e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6741:	ff 76 f8             	push   WORD PTR [bp-0x8]
    6744:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6747:	ff 76 0a             	push   WORD PTR [bp+0xa]
    674a:	8d 7e fc             	lea    di,[bp-0x4]
    674d:	16                   	push   ss
    674e:	57                   	push   di
    674f:	9a ed 06 9a 6d       	call   0x6d9a:0x6ed
    6754:	50                   	push   ax
    6755:	9a 4e 12 dd 67       	call   0x67dd:0x124e
    675a:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    675e:	b0 00                	mov    al,0x0
    6760:	75 01                	jne    0x6763
    6762:	40                   	inc    ax
    6763:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6766:	eb 53                	jmp    0x67bb
    6768:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    676b:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    6770:	7d 49                	jge    0x67bb
    6772:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6775:	26 80 7d 3a 04       	cmp    BYTE PTR es:[di+0x3a],0x4
    677a:	74 3f                	je     0x67bb
    677c:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    6780:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6783:	26 03 45 30          	add    ax,WORD PTR es:[di+0x30]
    6787:	01 46 f8             	add    WORD PTR [bp-0x8],ax
    678a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    678d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    6790:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6793:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    6797:	74 22                	je     0x67bb
    6799:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    679c:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    679f:	74 1a                	je     0x67bb
    67a1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    67a4:	81 c7 01 00          	add    di,0x1
    67a8:	06                   	push   es
    67a9:	57                   	push   di
    67aa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    67ad:	06                   	push   es
    67ae:	57                   	push   di
    67af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67b2:	26 ff 75 2c          	push   WORD PTR es:[di+0x2c]
    67b6:	9a c1 1e f0 67       	call   0x67f0:0x1ec1
    67bb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    67be:	c9                   	leave
    67bf:	ca 08 00             	retf   0x8
    67c2:	c8 02 00 00          	enter  0x2,0x0
    67c6:	c7 46 fe 0a 00       	mov    WORD PTR [bp-0x2],0xa
    67cb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    67ce:	c9                   	leave
    67cf:	ca 04 00             	retf   0x4
    67d2:	55                   	push   bp
    67d3:	89 e5                	mov    bp,sp
    67d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67d8:	06                   	push   es
    67d9:	57                   	push   di
    67da:	9a f6 67 eb 69       	call   0x69eb:0x67f6
    67df:	89 c7                	mov    di,ax
    67e1:	8e c2                	mov    es,dx
    67e3:	06                   	push   es
    67e4:	57                   	push   di
    67e5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    67e8:	06                   	push   es
    67e9:	57                   	push   di
    67ea:	68 ff 00             	push   0xff
    67ed:	9a e7 17 c9 68       	call   0x68c9:0x17e7
    67f2:	c9                   	leave
    67f3:	ca 04 00             	retf   0x4
    67f6:	c8 04 00 00          	enter  0x4,0x0
    67fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67fd:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    6801:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6805:	74 13                	je     0x681a
    6807:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    680a:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    680e:	26 8b 55 36          	mov    dx,WORD PTR es:[di+0x36]
    6812:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6815:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6818:	eb 11                	jmp    0x682b
    681a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    681d:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    6821:	26 8b 55 20          	mov    dx,WORD PTR es:[di+0x20]
    6825:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6828:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    682b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    682e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6831:	c9                   	leave
    6832:	ca 04 00             	retf   0x4
    6835:	55                   	push   bp
    6836:	89 e5                	mov    bp,sp
    6838:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    683b:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    683f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6842:	26 8b 45 52          	mov    ax,WORD PTR es:[di+0x52]
    6846:	09 c0                	or     ax,ax
    6848:	74 21                	je     0x686b
    684a:	ff 76 08             	push   WORD PTR [bp+0x8]
    684d:	ff 76 06             	push   WORD PTR [bp+0x6]
    6850:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6853:	06                   	push   es
    6854:	57                   	push   di
    6855:	68 ff 00             	push   0xff
    6858:	6a 01                	push   0x1
    685a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    685d:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    6861:	26 ff 75 54          	push   WORD PTR es:[di+0x54]
    6865:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    6869:	eb 16                	jmp    0x6881
    686b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    686e:	06                   	push   es
    686f:	57                   	push   di
    6870:	68 ff 00             	push   0xff
    6873:	6a 01                	push   0x1
    6875:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6878:	06                   	push   es
    6879:	57                   	push   di
    687a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    687d:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    6881:	c9                   	leave
    6882:	ca 04 00             	retf   0x4
    6885:	c8 02 00 00          	enter  0x2,0x0
    6889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    688c:	26 83 7d 32 00       	cmp    WORD PTR es:[di+0x32],0x0
    6891:	7e 09                	jle    0x689c
    6893:	26 8b 45 32          	mov    ax,WORD PTR es:[di+0x32]
    6897:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    689a:	eb 0f                	jmp    0x68ab
    689c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    689f:	06                   	push   es
    68a0:	57                   	push   di
    68a1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    68a4:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    68a8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    68ab:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    68ae:	c9                   	leave
    68af:	ca 04 00             	retf   0x4
    68b2:	55                   	push   bp
    68b3:	89 e5                	mov    bp,sp
    68b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68b8:	26 c4 7d 38          	les    di,DWORD PTR es:[di+0x38]
    68bc:	06                   	push   es
    68bd:	57                   	push   di
    68be:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    68c1:	06                   	push   es
    68c2:	57                   	push   di
    68c3:	68 ff 00             	push   0xff
    68c6:	9a e7 17 36 69       	call   0x6936:0x17e7
    68cb:	c9                   	leave
    68cc:	ca 04 00             	retf   0x4
    68cf:	55                   	push   bp
    68d0:	89 e5                	mov    bp,sp
    68d2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    68d5:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    68d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68dc:	26 8b 45 52          	mov    ax,WORD PTR es:[di+0x52]
    68e0:	09 c0                	or     ax,ax
    68e2:	74 21                	je     0x6905
    68e4:	ff 76 08             	push   WORD PTR [bp+0x8]
    68e7:	ff 76 06             	push   WORD PTR [bp+0x6]
    68ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    68ed:	06                   	push   es
    68ee:	57                   	push   di
    68ef:	68 ff 00             	push   0xff
    68f2:	6a 00                	push   0x0
    68f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68f7:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    68fb:	26 ff 75 54          	push   WORD PTR es:[di+0x54]
    68ff:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    6903:	eb 16                	jmp    0x691b
    6905:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6908:	06                   	push   es
    6909:	57                   	push   di
    690a:	68 ff 00             	push   0xff
    690d:	6a 00                	push   0x0
    690f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6912:	06                   	push   es
    6913:	57                   	push   di
    6914:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6917:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    691b:	c9                   	leave
    691c:	ca 04 00             	retf   0x4
    691f:	55                   	push   bp
    6920:	89 e5                	mov    bp,sp
    6922:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6925:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    6929:	06                   	push   es
    692a:	57                   	push   di
    692b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    692e:	06                   	push   es
    692f:	57                   	push   di
    6930:	68 ff 00             	push   0xff
    6933:	9a e7 17 1f 6a       	call   0x6a1f:0x17e7
    6938:	c9                   	leave
    6939:	ca 04 00             	retf   0x4
    693c:	c8 02 00 00          	enter  0x2,0x0
    6940:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6943:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6947:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    694b:	74 1a                	je     0x6967
    694d:	ff 76 08             	push   WORD PTR [bp+0x8]
    6950:	ff 76 06             	push   WORD PTR [bp+0x6]
    6953:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6957:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    695b:	06                   	push   es
    695c:	57                   	push   di
    695d:	9a 58 0e cf 6a       	call   0x6acf:0xe58
    6962:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6965:	eb 05                	jmp    0x696c
    6967:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    696c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    696f:	c9                   	leave
    6970:	ca 04 00             	retf   0x4
    6973:	c8 06 00 00          	enter  0x6,0x0
    6977:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    697b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    697e:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    6983:	7e 4f                	jle    0x69d4
    6985:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6989:	26 8b 45 7e          	mov    ax,WORD PTR es:[di+0x7e]
    698d:	48                   	dec    ax
    698e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6991:	31 c0                	xor    ax,ax
    6993:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    6996:	7f 3c                	jg     0x69d4
    6998:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    699b:	eb 03                	jmp    0x69a0
    699d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    69a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69a3:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    69a7:	99                   	cwd
    69a8:	8b c8                	mov    cx,ax
    69aa:	8b da                	mov    bx,dx
    69ac:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    69af:	d1 e0                	shl    ax,1
    69b1:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    69b5:	03 f8                	add    di,ax
    69b7:	26 8b 85 80 00       	mov    ax,WORD PTR es:[di+0x80]
    69bc:	31 d2                	xor    dx,dx
    69be:	3b d3                	cmp    dx,bx
    69c0:	75 0a                	jne    0x69cc
    69c2:	3b c1                	cmp    ax,cx
    69c4:	75 06                	jne    0x69cc
    69c6:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    69ca:	eb 08                	jmp    0x69d4
    69cc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    69cf:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    69d2:	75 c9                	jne    0x699d
    69d4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    69d7:	c9                   	leave
    69d8:	ca 04 00             	retf   0x4
    69db:	c8 02 00 00          	enter  0x2,0x0
    69df:	6a 00                	push   0x0
    69e1:	6a 00                	push   0x0
    69e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69e6:	06                   	push   es
    69e7:	57                   	push   di
    69e8:	9a 35 66 95 6a       	call   0x6a95:0x6635
    69ed:	08 c0                	or     al,al
    69ef:	b0 00                	mov    al,0x0
    69f1:	75 01                	jne    0x69f4
    69f3:	40                   	inc    ax
    69f4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    69f7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    69fa:	c9                   	leave
    69fb:	ca 04 00             	retf   0x4
    69fe:	c8 00 01 00          	enter  0x100,0x0
    6a02:	8d be 00 ff          	lea    di,[bp-0x100]
    6a06:	16                   	push   ss
    6a07:	57                   	push   di
    6a08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a0b:	06                   	push   es
    6a0c:	57                   	push   di
    6a0d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a10:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    6a14:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6a17:	06                   	push   es
    6a18:	57                   	push   di
    6a19:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6a1c:	9a e7 17 e7 6a       	call   0x6ae7:0x17e7
    6a21:	c9                   	leave
    6a22:	ca 0c 00             	retf   0xc
    6a25:	c8 02 00 00          	enter  0x2,0x0
    6a29:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    6a2d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6a30:	c9                   	leave
    6a31:	ca 04 00             	retf   0x4
    6a34:	c8 02 00 00          	enter  0x2,0x0
    6a38:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    6a3c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6a3f:	c9                   	leave
    6a40:	ca 06 00             	retf   0x6
    6a43:	c8 02 00 00          	enter  0x2,0x0
    6a47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a4a:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    6a4e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6a52:	b0 00                	mov    al,0x0
    6a54:	74 01                	je     0x6a57
    6a56:	40                   	inc    ax
    6a57:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6a5a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6a5d:	c9                   	leave
    6a5e:	ca 04 00             	retf   0x4
    6a61:	c8 02 00 00          	enter  0x2,0x0
    6a65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a68:	26 83 7d 32 00       	cmp    WORD PTR es:[di+0x32],0x0
    6a6d:	b0 00                	mov    al,0x0
    6a6f:	7e 01                	jle    0x6a72
    6a71:	40                   	inc    ax
    6a72:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6a75:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6a78:	c9                   	leave
    6a79:	ca 04 00             	retf   0x4
    6a7c:	55                   	push   bp
    6a7d:	89 e5                	mov    bp,sp
    6a7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a82:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6a86:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6a8a:	74 2e                	je     0x6aba
    6a8c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6a90:	06                   	push   es
    6a91:	57                   	push   di
    6a92:	9a 02 32 e0 6a       	call   0x6ae0:0x3202
    6a97:	08 c0                	or     al,al
    6a99:	74 1f                	je     0x6aba
    6a9b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6a9e:	98                   	cbw
    6a9f:	8b f8                	mov    di,ax
    6aa1:	8a 85 5e 0b          	mov    al,BYTE PTR [di+0xb5e]
    6aa5:	50                   	push   ax
    6aa6:	6a 00                	push   0x0
    6aa8:	6a 00                	push   0x0
    6aaa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aad:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6ab1:	06                   	push   es
    6ab2:	57                   	push   di
    6ab3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6ab6:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    6aba:	c9                   	leave
    6abb:	ca 06 00             	retf   0x6
    6abe:	55                   	push   bp
    6abf:	89 e5                	mov    bp,sp
    6ac1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6ac4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6ac7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aca:	06                   	push   es
    6acb:	57                   	push   di
    6acc:	9a 03 50 83 70       	call   0x7083:0x5003
    6ad1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6ad4:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    6ad8:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6adc:	bf 06 04             	mov    di,0x406
    6adf:	b8 00 6b             	mov    ax,0x6b00
    6ae2:	50                   	push   ax
    6ae3:	57                   	push   di
    6ae4:	9a 55 22 ea 6d       	call   0x6dea:0x2255
    6ae9:	08 c0                	or     al,al
    6aeb:	74 15                	je     0x6b02
    6aed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6af0:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    6af4:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    6af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6afb:	06                   	push   es
    6afc:	57                   	push   di
    6afd:	9a 0b 6e 1e 6b       	call   0x6b1e:0x6e0b
    6b02:	c9                   	leave
    6b03:	ca 08 00             	retf   0x8
    6b06:	07                   	pop    es
    6b07:	42                   	inc    dx
    6b08:	6f                   	outs   dx,WORD PTR ds:[si]
    6b09:	6f                   	outs   dx,WORD PTR ds:[si]
    6b0a:	6c                   	ins    BYTE PTR es:[di],dx
    6b0b:	65 61                	gs popa
    6b0d:	6e                   	outs   dx,BYTE PTR ds:[si]
    6b0e:	55                   	push   bp
    6b0f:	89 e5                	mov    bp,sp
    6b11:	bf 06 6b             	mov    di,0x6b06
    6b14:	0e                   	push   cs
    6b15:	57                   	push   di
    6b16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b19:	06                   	push   es
    6b1a:	57                   	push   di
    6b1b:	9a d9 60 3d 6b       	call   0x6b3d:0x60d9
    6b20:	c9                   	leave
    6b21:	ca 06 00             	retf   0x6
    6b24:	08 44 61             	or     BYTE PTR [si+0x61],al
    6b27:	74 65                	je     0x6b8e
    6b29:	54                   	push   sp
    6b2a:	69 6d 65 55 89       	imul   bp,WORD PTR [di+0x65],0x8955
    6b2f:	e5 bf                	in     ax,0xbf
    6b31:	24 6b                	and    al,0x6b
    6b33:	0e                   	push   cs
    6b34:	57                   	push   di
    6b35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b38:	06                   	push   es
    6b39:	57                   	push   di
    6b3a:	9a d9 60 59 6b       	call   0x6b59:0x60d9
    6b3f:	c9                   	leave
    6b40:	ca 0c 00             	retf   0xc
    6b43:	05 46 6c             	add    ax,0x6c46
    6b46:	6f                   	outs   dx,WORD PTR ds:[si]
    6b47:	61                   	popa
    6b48:	74 55                	je     0x6b9f
    6b4a:	89 e5                	mov    bp,sp
    6b4c:	bf 43 6b             	mov    di,0x6b43
    6b4f:	0e                   	push   cs
    6b50:	57                   	push   di
    6b51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b54:	06                   	push   es
    6b55:	57                   	push   di
    6b56:	9a d9 60 77 6b       	call   0x6b77:0x60d9
    6b5b:	c9                   	leave
    6b5c:	ca 0c 00             	retf   0xc
    6b5f:	07                   	pop    es
    6b60:	49                   	dec    cx
    6b61:	6e                   	outs   dx,BYTE PTR ds:[si]
    6b62:	74 65                	je     0x6bc9
    6b64:	67 65 72 55          	addr32 gs jb 0x6bbd
    6b68:	89 e5                	mov    bp,sp
    6b6a:	bf 5f 6b             	mov    di,0x6b5f
    6b6d:	0e                   	push   cs
    6b6e:	57                   	push   di
    6b6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b72:	06                   	push   es
    6b73:	57                   	push   di
    6b74:	9a d9 60 94 6b       	call   0x6b94:0x60d9
    6b79:	c9                   	leave
    6b7a:	ca 08 00             	retf   0x8
    6b7d:	06                   	push   es
    6b7e:	53                   	push   bx
    6b7f:	74 72                	je     0x6bf3
    6b81:	69 6e 67 55 89       	imul   bp,WORD PTR [bp+0x67],0x8955
    6b86:	e5 bf                	in     ax,0xbf
    6b88:	7d 6b                	jge    0x6bf5
    6b8a:	0e                   	push   cs
    6b8b:	57                   	push   di
    6b8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b8f:	06                   	push   es
    6b90:	57                   	push   di
    6b91:	9a d9 60 b7 6b       	call   0x6bb7:0x60d9
    6b96:	c9                   	leave
    6b97:	ca 08 00             	retf   0x8
    6b9a:	55                   	push   bp
    6b9b:	89 e5                	mov    bp,sp
    6b9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ba0:	26 8a 45 25          	mov    al,BYTE PTR es:[di+0x25]
    6ba4:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6ba7:	74 10                	je     0x6bb9
    6ba9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6bac:	26 88 45 25          	mov    BYTE PTR es:[di+0x25],al
    6bb0:	6a 00                	push   0x0
    6bb2:	06                   	push   es
    6bb3:	57                   	push   di
    6bb4:	9a 7c 6a c8 6b       	call   0x6bc8:0x6a7c
    6bb9:	c9                   	leave
    6bba:	ca 06 00             	retf   0x6
    6bbd:	55                   	push   bp
    6bbe:	89 e5                	mov    bp,sp
    6bc0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bc3:	06                   	push   es
    6bc4:	57                   	push   di
    6bc5:	9a c7 63 dc 6b       	call   0x6bdc:0x63c7
    6bca:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6bcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bd0:	26 88 45 24          	mov    BYTE PTR es:[di+0x24],al
    6bd4:	c9                   	leave
    6bd5:	ca 06 00             	retf   0x6
    6bd8:	00 00                	add    BYTE PTR [bx+si],al
    6bda:	70 6d                	jo     0x6c49
    6bdc:	f7 6b c8             	imul   WORD PTR [bp+di-0x38]
    6bdf:	10 00                	adc    BYTE PTR [bx+si],al
    6be1:	00 c4                	add    ah,al
    6be3:	7e 06                	jle    0x6beb
    6be5:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6be9:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6bed:	75 28                	jne    0x6c17
    6bef:	68 09 f2             	push   0xf209
    6bf2:	06                   	push   es
    6bf3:	57                   	push   di
    6bf4:	9a f6 67 15 6c       	call   0x6c15:0x67f6
    6bf9:	89 c7                	mov    di,ax
    6bfb:	8e c2                	mov    es,dx
    6bfd:	89 f8                	mov    ax,di
    6bff:	8c c2                	mov    dx,es
    6c01:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6c04:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    6c07:	c6 46 f8 04          	mov    BYTE PTR [bp-0x8],0x4
    6c0b:	8d 7e f4             	lea    di,[bp-0xc]
    6c0e:	16                   	push   ss
    6c0f:	57                   	push   di
    6c10:	6a 00                	push   0x0
    6c12:	9a 0a 12 58 6c       	call   0x6c58:0x120a
    6c17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c1a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6c1e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    6c21:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    6c24:	26 80 7d 3a 04       	cmp    BYTE PTR es:[di+0x3a],0x4
    6c29:	75 60                	jne    0x6c8b
    6c2b:	26 8b 45 76          	mov    ax,WORD PTR es:[di+0x76]
    6c2f:	26 8b 55 78          	mov    dx,WORD PTR es:[di+0x78]
    6c33:	05 04 00             	add    ax,0x4
    6c36:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6c39:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6c3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c3f:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    6c44:	7c 18                	jl     0x6c5e
    6c46:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6c49:	26 83 7d 7e 00       	cmp    WORD PTR es:[di+0x7e],0x0
    6c4e:	7e 39                	jle    0x6c89
    6c50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c53:	06                   	push   es
    6c54:	57                   	push   di
    6c55:	9a 73 69 69 6c       	call   0x6c69:0x6973
    6c5a:	08 c0                	or     al,al
    6c5c:	75 2b                	jne    0x6c89
    6c5e:	68 16 f2             	push   0xf216
    6c61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c64:	06                   	push   es
    6c65:	57                   	push   di
    6c66:	9a f6 67 87 6c       	call   0x6c87:0x67f6
    6c6b:	89 c7                	mov    di,ax
    6c6d:	8e c2                	mov    es,dx
    6c6f:	89 f8                	mov    ax,di
    6c71:	8c c2                	mov    dx,es
    6c73:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    6c76:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    6c79:	c6 46 f4 04          	mov    BYTE PTR [bp-0xc],0x4
    6c7d:	8d 7e f0             	lea    di,[bp-0x10]
    6c80:	16                   	push   ss
    6c81:	57                   	push   di
    6c82:	6a 00                	push   0x0
    6c84:	9a 0a 12 d3 6c       	call   0x6cd3:0x120a
    6c89:	eb 7c                	jmp    0x6d07
    6c8b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6c8e:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    6c92:	3c 05                	cmp    al,0x5
    6c94:	75 10                	jne    0x6ca6
    6c96:	26 8b 45 7a          	mov    ax,WORD PTR es:[di+0x7a]
    6c9a:	26 8b 55 7c          	mov    dx,WORD PTR es:[di+0x7c]
    6c9e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6ca1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6ca4:	eb 2f                	jmp    0x6cd5
    6ca6:	3c 02                	cmp    al,0x2
    6ca8:	74 04                	je     0x6cae
    6caa:	3c 03                	cmp    al,0x3
    6cac:	75 1f                	jne    0x6ccd
    6cae:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6cb1:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    6cb5:	c1 e0 02             	shl    ax,0x2
    6cb8:	26 c4 7d 26          	les    di,DWORD PTR es:[di+0x26]
    6cbc:	03 f8                	add    di,ax
    6cbe:	26 8b 05             	mov    ax,WORD PTR es:[di]
    6cc1:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    6cc5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6cc8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6ccb:	eb 08                	jmp    0x6cd5
    6ccd:	68 12 f2             	push   0xf212
    6cd0:	9a ef 11 e7 6c       	call   0x6ce7:0x11ef
    6cd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cd8:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    6cdd:	74 28                	je     0x6d07
    6cdf:	68 15 f2             	push   0xf215
    6ce2:	06                   	push   es
    6ce3:	57                   	push   di
    6ce4:	9a f6 67 05 6d       	call   0x6d05:0x67f6
    6ce9:	89 c7                	mov    di,ax
    6ceb:	8e c2                	mov    es,dx
    6ced:	89 f8                	mov    ax,di
    6cef:	8c c2                	mov    dx,es
    6cf1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    6cf4:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    6cf7:	c6 46 f4 04          	mov    BYTE PTR [bp-0xc],0x4
    6cfb:	8d 7e f0             	lea    di,[bp-0x10]
    6cfe:	16                   	push   ss
    6cff:	57                   	push   di
    6d00:	6a 00                	push   0x0
    6d02:	9a 0a 12 24 6d       	call   0x6d24:0x120a
    6d07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d0a:	26 83 7d 2e 00       	cmp    WORD PTR es:[di+0x2e],0x0
    6d0f:	7f 03                	jg     0x6d14
    6d11:	e9 90 00             	jmp    0x6da4
    6d14:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6d17:	26 80 7d 3a 05       	cmp    BYTE PTR es:[di+0x3a],0x5
    6d1c:	75 08                	jne    0x6d26
    6d1e:	68 12 f2             	push   0xf212
    6d21:	9a ef 11 a0 6d       	call   0x6da0:0x11ef
    6d26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d29:	26 8b 45 4a          	mov    ax,WORD PTR es:[di+0x4a]
    6d2d:	09 c0                	or     ax,ax
    6d2f:	74 48                	je     0x6d79
    6d31:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6d34:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6d37:	26 89 45 3c          	mov    WORD PTR es:[di+0x3c],ax
    6d3b:	26 89 55 3e          	mov    WORD PTR es:[di+0x3e],dx
    6d3f:	26 c6 45 28 01       	mov    BYTE PTR es:[di+0x28],0x1
    6d44:	b8 d8 6b             	mov    ax,0x6bd8
    6d47:	0e                   	push   cs
    6d48:	50                   	push   ax
    6d49:	55                   	push   bp
    6d4a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6d4e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6d52:	ff 76 08             	push   WORD PTR [bp+0x8]
    6d55:	ff 76 06             	push   WORD PTR [bp+0x6]
    6d58:	26 ff 75 4e          	push   WORD PTR es:[di+0x4e]
    6d5c:	26 ff 75 4c          	push   WORD PTR es:[di+0x4c]
    6d60:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    6d64:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6d68:	83 c4 06             	add    sp,0x6
    6d6b:	b8 79 6d             	mov    ax,0x6d79
    6d6e:	0e                   	push   cs
    6d6f:	50                   	push   ax
    6d70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d73:	26 c6 45 28 00       	mov    BYTE PTR es:[di+0x28],0x0
    6d78:	cb                   	retf
    6d79:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6d7c:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    6d80:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    6d84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d87:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    6d8b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6d8e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6d91:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6d94:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6d97:	9a fd 06 ff ff       	call   0xffff:0x6fd
    6d9c:	50                   	push   ax
    6d9d:	9a 4e 12 24 6e       	call   0x6e24:0x124e
    6da2:	eb 48                	jmp    0x6dec
    6da4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6da7:	26 8b 45 46          	mov    ax,WORD PTR es:[di+0x46]
    6dab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dae:	26 03 45 30          	add    ax,WORD PTR es:[di+0x30]
    6db2:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    6db5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6db8:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6dbb:	09 d0                	or     ax,dx
    6dbd:	f7 d8                	neg    ax
    6dbf:	18 c0                	sbb    al,al
    6dc1:	f6 d8                	neg    al
    6dc3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6dc6:	26 88 05             	mov    BYTE PTR es:[di],al
    6dc9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6dcc:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6dd0:	74 1a                	je     0x6dec
    6dd2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6dd5:	06                   	push   es
    6dd6:	57                   	push   di
    6dd7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6dda:	81 c7 01 00          	add    di,0x1
    6dde:	06                   	push   es
    6ddf:	57                   	push   di
    6de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6de3:	26 ff 75 2c          	push   WORD PTR es:[di+0x2c]
    6de7:	9a c1 1e ca 6e       	call   0x6eca:0x1ec1
    6dec:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6def:	26 80 7d 3a 05       	cmp    BYTE PTR es:[di+0x3a],0x5
    6df4:	74 11                	je     0x6e07
    6df6:	6a 00                	push   0x0
    6df8:	ff 76 08             	push   WORD PTR [bp+0x8]
    6dfb:	ff 76 06             	push   WORD PTR [bp+0x6]
    6dfe:	06                   	push   es
    6dff:	57                   	push   di
    6e00:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e03:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    6e07:	c9                   	leave
    6e08:	ca 08 00             	retf   0x8
    6e0b:	55                   	push   bp
    6e0c:	89 e5                	mov    bp,sp
    6e0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e11:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6e15:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6e19:	74 0b                	je     0x6e26
    6e1b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6e1f:	06                   	push   es
    6e20:	57                   	push   di
    6e21:	9a e5 31 36 6e       	call   0x6e36:0x31e5
    6e26:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6e29:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    6e2c:	74 1d                	je     0x6e4b
    6e2e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6e31:	06                   	push   es
    6e32:	57                   	push   di
    6e33:	9a e5 31 49 6e       	call   0x6e49:0x31e5
    6e38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e3b:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    6e3f:	06                   	push   es
    6e40:	57                   	push   di
    6e41:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6e44:	06                   	push   es
    6e45:	57                   	push   di
    6e46:	9a af 3c 67 6e       	call   0x6e67:0x3caf
    6e4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e4e:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6e52:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6e56:	74 11                	je     0x6e69
    6e58:	ff 76 08             	push   WORD PTR [bp+0x8]
    6e5b:	ff 76 06             	push   WORD PTR [bp+0x6]
    6e5e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6e62:	06                   	push   es
    6e63:	57                   	push   di
    6e64:	9a 0a 3b 7f 6e       	call   0x6e7f:0x3b0a
    6e69:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6e6c:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    6e6f:	74 10                	je     0x6e81
    6e71:	ff 76 08             	push   WORD PTR [bp+0x8]
    6e74:	ff 76 06             	push   WORD PTR [bp+0x6]
    6e77:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6e7a:	06                   	push   es
    6e7b:	57                   	push   di
    6e7c:	9a de 3a 97 6e       	call   0x6e97:0x3ade
    6e81:	c9                   	leave
    6e82:	ca 08 00             	retf   0x8
    6e85:	55                   	push   bp
    6e86:	89 e5                	mov    bp,sp
    6e88:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6e8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e8e:	26 88 45 22          	mov    BYTE PTR es:[di+0x22],al
    6e92:	06                   	push   es
    6e93:	57                   	push   di
    6e94:	9a 4b 71 07 6f       	call   0x6f07:0x714b
    6e99:	c9                   	leave
    6e9a:	ca 06 00             	retf   0x6
    6e9d:	c8 00 01 00          	enter  0x100,0x0
    6ea1:	8c d3                	mov    bx,ss
    6ea3:	8e c3                	mov    es,bx
    6ea5:	8c db                	mov    bx,ds
    6ea7:	fc                   	cld
    6ea8:	8d be 00 ff          	lea    di,[bp-0x100]
    6eac:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    6eaf:	ac                   	lods   al,BYTE PTR ds:[si]
    6eb0:	aa                   	stos   BYTE PTR es:[di],al
    6eb1:	91                   	xchg   cx,ax
    6eb2:	30 ed                	xor    ch,ch
    6eb4:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    6eb6:	8e db                	mov    ds,bx
    6eb8:	8d be 00 ff          	lea    di,[bp-0x100]
    6ebc:	16                   	push   ss
    6ebd:	57                   	push   di
    6ebe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ec1:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    6ec5:	06                   	push   es
    6ec6:	57                   	push   di
    6ec7:	9a be 18 e5 6e       	call   0x6ee5:0x18be
    6ecc:	75 05                	jne    0x6ed3
    6ece:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ed3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ed6:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    6eda:	06                   	push   es
    6edb:	57                   	push   di
    6edc:	8d be 00 ff          	lea    di,[bp-0x100]
    6ee0:	16                   	push   ss
    6ee1:	57                   	push   di
    6ee2:	9a be 18 e7 6f       	call   0x6fe7:0x18be
    6ee7:	74 20                	je     0x6f09
    6ee9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6eec:	81 c7 34 00          	add    di,0x34
    6ef0:	06                   	push   es
    6ef1:	57                   	push   di
    6ef2:	8d be 00 ff          	lea    di,[bp-0x100]
    6ef6:	16                   	push   ss
    6ef7:	57                   	push   di
    6ef8:	9a 51 06 44 6f       	call   0x6f44:0x651
    6efd:	6a 01                	push   0x1
    6eff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f02:	06                   	push   es
    6f03:	57                   	push   di
    6f04:	9a 7c 6a 2a 6f       	call   0x6f2a:0x6a7c
    6f09:	c9                   	leave
    6f0a:	ca 08 00             	retf   0x8
    6f0d:	55                   	push   bp
    6f0e:	89 e5                	mov    bp,sp
    6f10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f13:	26 8b 45 32          	mov    ax,WORD PTR es:[di+0x32]
    6f17:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    6f1a:	74 10                	je     0x6f2c
    6f1c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6f1f:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    6f23:	6a 01                	push   0x1
    6f25:	06                   	push   es
    6f26:	57                   	push   di
    6f27:	9a 7c 6a 50 6f       	call   0x6f50:0x6a7c
    6f2c:	c9                   	leave
    6f2d:	ca 06 00             	retf   0x6
    6f30:	55                   	push   bp
    6f31:	89 e5                	mov    bp,sp
    6f33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f36:	81 c7 38 00          	add    di,0x38
    6f3a:	06                   	push   es
    6f3b:	57                   	push   di
    6f3c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f3f:	06                   	push   es
    6f40:	57                   	push   di
    6f41:	9a 51 06 d4 6f       	call   0x6fd4:0x651
    6f46:	6a 00                	push   0x0
    6f48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f4b:	06                   	push   es
    6f4c:	57                   	push   di
    6f4d:	9a 7c 6a a1 6f       	call   0x6fa1:0x6a7c
    6f52:	c9                   	leave
    6f53:	ca 08 00             	retf   0x8
    6f56:	55                   	push   bp
    6f57:	89 e5                	mov    bp,sp
    6f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f5c:	26 8b 45 5a          	mov    ax,WORD PTR es:[di+0x5a]
    6f60:	09 c0                	or     ax,ax
    6f62:	74 1c                	je     0x6f80
    6f64:	ff 76 08             	push   WORD PTR [bp+0x8]
    6f67:	ff 76 06             	push   WORD PTR [bp+0x6]
    6f6a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f6d:	06                   	push   es
    6f6e:	57                   	push   di
    6f6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f72:	26 ff 75 5e          	push   WORD PTR es:[di+0x5e]
    6f76:	26 ff 75 5c          	push   WORD PTR es:[di+0x5c]
    6f7a:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    6f7e:	eb 11                	jmp    0x6f91
    6f80:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f83:	06                   	push   es
    6f84:	57                   	push   di
    6f85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f88:	06                   	push   es
    6f89:	57                   	push   di
    6f8a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f8d:	26 ff 5d 68          	call   DWORD PTR es:[di+0x68]
    6f91:	c9                   	leave
    6f92:	ca 08 00             	retf   0x8
    6f95:	00 55 89             	add    BYTE PTR [di-0x77],dl
    6f98:	e5 c4                	in     ax,0xc4
    6f9a:	7e 06                	jle    0x6fa2
    6f9c:	06                   	push   es
    6f9d:	57                   	push   di
    6f9e:	9a c7 63 c1 6f       	call   0x6fc1:0x63c7
    6fa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fa6:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    6faa:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    6fae:	74 13                	je     0x6fc3
    6fb0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6fb3:	06                   	push   es
    6fb4:	57                   	push   di
    6fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fb8:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    6fbc:	06                   	push   es
    6fbd:	57                   	push   di
    6fbe:	9a af 3c 2e 70       	call   0x702e:0x3caf
    6fc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fc6:	81 c7 1e 00          	add    di,0x1e
    6fca:	06                   	push   es
    6fcb:	57                   	push   di
    6fcc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6fcf:	06                   	push   es
    6fd0:	57                   	push   di
    6fd1:	9a 51 06 fc 6f       	call   0x6ffc:0x651
    6fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fd9:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    6fdd:	06                   	push   es
    6fde:	57                   	push   di
    6fdf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6fe2:	06                   	push   es
    6fe3:	57                   	push   di
    6fe4:	9a be 18 c8 71       	call   0x71c8:0x18be
    6fe9:	75 13                	jne    0x6ffe
    6feb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fee:	81 c7 34 00          	add    di,0x34
    6ff2:	06                   	push   es
    6ff3:	57                   	push   di
    6ff4:	bf 95 6f             	mov    di,0x6f95
    6ff7:	0e                   	push   cs
    6ff8:	57                   	push   di
    6ff9:	9a 51 06 a5 7b       	call   0x7ba5:0x651
    6ffe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7001:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7005:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    7009:	74 13                	je     0x701e
    700b:	6a 09                	push   0x9
    700d:	6a 00                	push   0x0
    700f:	6a 00                	push   0x0
    7011:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7015:	06                   	push   es
    7016:	57                   	push   di
    7017:	26 c4 3d             	les    di,DWORD PTR es:[di]
    701a:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    701e:	c9                   	leave
    701f:	ca 08 00             	retf   0x8
    7022:	c8 04 00 00          	enter  0x4,0x0
    7026:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7029:	06                   	push   es
    702a:	57                   	push   di
    702b:	9a 3c 69 aa 70       	call   0x70aa:0x693c
    7030:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7033:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    7037:	7d 03                	jge    0x703c
    7039:	e9 86 00             	jmp    0x70c2
    703c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    703f:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7043:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7047:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    704b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    704e:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    7052:	7d 05                	jge    0x7059
    7054:	31 c0                	xor    ax,ax
    7056:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    7059:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    705c:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    705f:	7c 07                	jl     0x7068
    7061:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7064:	48                   	dec    ax
    7065:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    7068:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    706b:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    706e:	74 52                	je     0x70c2
    7070:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7076:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    707a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    707e:	06                   	push   es
    707f:	57                   	push   di
    7080:	9a 94 0c 9e 70       	call   0x709e:0xc94
    7085:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7088:	ff 76 08             	push   WORD PTR [bp+0x8]
    708b:	ff 76 06             	push   WORD PTR [bp+0x6]
    708e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7091:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7095:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7099:	06                   	push   es
    709a:	57                   	push   di
    709b:	9a a7 0e db 71       	call   0x71db:0xea7
    70a0:	6a 01                	push   0x1
    70a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70a5:	06                   	push   es
    70a6:	57                   	push   di
    70a7:	9a 7c 6a d1 70       	call   0x70d1:0x6a7c
    70ac:	6a 09                	push   0x9
    70ae:	6a 00                	push   0x0
    70b0:	6a 00                	push   0x0
    70b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70b5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    70b9:	06                   	push   es
    70ba:	57                   	push   di
    70bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    70be:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    70c2:	c9                   	leave
    70c3:	ca 06 00             	retf   0x6
    70c6:	55                   	push   bp
    70c7:	89 e5                	mov    bp,sp
    70c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70cc:	06                   	push   es
    70cd:	57                   	push   di
    70ce:	9a c7 63 f0 70       	call   0x70f0:0x63c7
    70d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70d6:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    70da:	50                   	push   ax
    70db:	ff 76 0a             	push   WORD PTR [bp+0xa]
    70de:	e8 86 a0             	call   0x1167
    70e1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    70e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70e7:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    70eb:	06                   	push   es
    70ec:	57                   	push   di
    70ed:	9a 4b 71 2b 71       	call   0x712b:0x714b
    70f2:	c9                   	leave
    70f3:	ca 06 00             	retf   0x6
    70f6:	55                   	push   bp
    70f7:	89 e5                	mov    bp,sp
    70f9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    70fc:	06                   	push   es
    70fd:	57                   	push   di
    70fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7101:	06                   	push   es
    7102:	57                   	push   di
    7103:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7106:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    710a:	c9                   	leave
    710b:	ca 08 00             	retf   0x8
    710e:	55                   	push   bp
    710f:	89 e5                	mov    bp,sp
    7111:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7114:	26 8a 45 26          	mov    al,BYTE PTR es:[di+0x26]
    7118:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    711b:	74 10                	je     0x712d
    711d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7120:	26 88 45 26          	mov    BYTE PTR es:[di+0x26],al
    7124:	6a 01                	push   0x1
    7126:	06                   	push   es
    7127:	57                   	push   di
    7128:	9a 7c 6a 3a 72       	call   0x723a:0x6a7c
    712d:	c9                   	leave
    712e:	ca 06 00             	retf   0x6
    7131:	9e                   	sahf
    7132:	71 65                	jno    0x7199
    7134:	71 70                	jno    0x71a6
    7136:	71 65                	jno    0x719d
    7138:	71 65                	jno    0x719f
    713a:	71 7b                	jno    0x71b7
    713c:	71 7b                	jno    0x71b9
    713e:	71 86                	jno    0x70c6
    7140:	71 70                	jno    0x71b2
    7142:	71 70                	jno    0x71b4
    7144:	71 7b                	jno    0x71c1
    7146:	71 91                	jno    0x70d9
    7148:	71 91                	jno    0x70db
    714a:	71 55                	jno    0x71a1
    714c:	89 e5                	mov    bp,sp
    714e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7151:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    7155:	2c 01                	sub    al,0x1
    7157:	3c 0c                	cmp    al,0xc
    7159:	77 51                	ja     0x71ac
    715b:	98                   	cbw
    715c:	89 c3                	mov    bx,ax
    715e:	d1 e3                	shl    bx,1
    7160:	2e ff a7 31 71       	jmp    WORD PTR cs:[bx+0x7131]
    7165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7168:	26 c7 45 2c 02 00    	mov    WORD PTR es:[di+0x2c],0x2
    716e:	eb 45                	jmp    0x71b5
    7170:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7173:	26 c7 45 2c 04 00    	mov    WORD PTR es:[di+0x2c],0x4
    7179:	eb 3a                	jmp    0x71b5
    717b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    717e:	26 c7 45 2c 08 00    	mov    WORD PTR es:[di+0x2c],0x8
    7184:	eb 2f                	jmp    0x71b5
    7186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7189:	26 c7 45 2c 12 00    	mov    WORD PTR es:[di+0x2c],0x12
    718f:	eb 24                	jmp    0x71b5
    7191:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7194:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    7198:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    719c:	eb 17                	jmp    0x71b5
    719e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71a1:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    71a5:	40                   	inc    ax
    71a6:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    71aa:	eb 09                	jmp    0x71b5
    71ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71af:	31 c0                	xor    ax,ax
    71b1:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    71b5:	c9                   	leave
    71b6:	ca 04 00             	retf   0x4
    71b9:	55                   	push   bp
    71ba:	89 e5                	mov    bp,sp
    71bc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    71c0:	74 08                	je     0x71ca
    71c2:	83 ec 08             	sub    sp,0x8
    71c5:	9a e2 1f eb 71       	call   0x71eb:0x1fe2
    71ca:	ff 76 0e             	push   WORD PTR [bp+0xe]
    71cd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    71d0:	31 c0                	xor    ax,ax
    71d2:	50                   	push   ax
    71d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71d6:	06                   	push   es
    71d7:	57                   	push   di
    71d8:	9a d9 4b e4 71       	call   0x71e4:0x4bd9
    71dd:	b0 01                	mov    al,0x1
    71df:	50                   	push   ax
    71e0:	b8 a3 02             	mov    ax,0x2a3
    71e3:	ba 56 72             	mov    dx,0x7256
    71e6:	52                   	push   dx
    71e7:	50                   	push   ax
    71e8:	9a 50 1f 72 72       	call   0x7272:0x1f50
    71ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71f0:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    71f4:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
    71f8:	26 c6 45 22 01       	mov    BYTE PTR es:[di+0x22],0x1
    71fd:	26 c6 45 23 01       	mov    BYTE PTR es:[di+0x23],0x1
    7202:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7206:	74 07                	je     0x720f
    7208:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    720c:	83 c4 06             	add    sp,0x6
    720f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7212:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7215:	c9                   	leave
    7216:	ca 0a 00             	retf   0xa
    7219:	55                   	push   bp
    721a:	89 e5                	mov    bp,sp
    721c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    721f:	31 c0                	xor    ax,ax
    7221:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    7225:	26 89 45 28          	mov    WORD PTR es:[di+0x28],ax
    7229:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    722d:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    7231:	6a 00                	push   0x0
    7233:	6a 00                	push   0x0
    7235:	06                   	push   es
    7236:	57                   	push   di
    7237:	9a c5 73 62 72       	call   0x7262:0x73c5
    723c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    723f:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    7243:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    7248:	7e 1c                	jle    0x7266
    724a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    724d:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    7251:	06                   	push   es
    7252:	57                   	push   di
    7253:	9a 43 0f 7f 72       	call   0x727f:0xf43
    7258:	52                   	push   dx
    7259:	50                   	push   ax
    725a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    725d:	06                   	push   es
    725e:	57                   	push   di
    725f:	9a 84 74 ad 72       	call   0x72ad:0x7484
    7264:	eb d6                	jmp    0x723c
    7266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7269:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    726d:	06                   	push   es
    726e:	57                   	push   di
    726f:	9a 7f 1f 8a 72       	call   0x728a:0x1f7f
    7274:	31 c0                	xor    ax,ax
    7276:	50                   	push   ax
    7277:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    727a:	06                   	push   es
    727b:	57                   	push   di
    727c:	9a 2b 4c 4b 74       	call   0x744b:0x4c2b
    7281:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7285:	74 05                	je     0x728c
    7287:	9a 0f 20 eb 75       	call   0x75eb:0x200f
    728c:	c9                   	leave
    728d:	ca 06 00             	retf   0x6
    7290:	55                   	push   bp
    7291:	89 e5                	mov    bp,sp
    7293:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7296:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    729b:	74 12                	je     0x72af
    729d:	26 80 7d 24 01       	cmp    BYTE PTR es:[di+0x24],0x1
    72a2:	75 0b                	jne    0x72af
    72a4:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    72a8:	06                   	push   es
    72a9:	57                   	push   di
    72aa:	9a 3c 53 dc 72       	call   0x72dc:0x533c
    72af:	c9                   	leave
    72b0:	ca 04 00             	retf   0x4
    72b3:	c8 02 00 00          	enter  0x2,0x0
    72b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72ba:	26 8a 45 24          	mov    al,BYTE PTR es:[di+0x24]
    72be:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    72c1:	74 66                	je     0x7329
    72c3:	26 8a 45 24          	mov    al,BYTE PTR es:[di+0x24]
    72c7:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    72ca:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    72cd:	26 88 45 24          	mov    BYTE PTR es:[di+0x24],al
    72d1:	6a 06                	push   0x6
    72d3:	6a 00                	push   0x0
    72d5:	6a 00                	push   0x0
    72d7:	06                   	push   es
    72d8:	57                   	push   di
    72d9:	9a ce 74 55 73       	call   0x7355:0x74ce
    72de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72e1:	26 f6 45 18 08       	test   BYTE PTR es:[di+0x18],0x8
    72e6:	75 41                	jne    0x7329
    72e8:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    72ec:	09 c0                	or     ax,ax
    72ee:	74 12                	je     0x7302
    72f0:	ff 76 08             	push   WORD PTR [bp+0x8]
    72f3:	ff 76 06             	push   WORD PTR [bp+0x6]
    72f6:	26 ff 75 2c          	push   WORD PTR es:[di+0x2c]
    72fa:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    72fe:	26 ff 5d 26          	call   DWORD PTR es:[di+0x26]
    7302:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    7306:	75 21                	jne    0x7329
    7308:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    730b:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    730f:	09 c0                	or     ax,ax
    7311:	74 16                	je     0x7329
    7313:	ff 76 08             	push   WORD PTR [bp+0x8]
    7316:	ff 76 06             	push   WORD PTR [bp+0x6]
    7319:	6a 00                	push   0x0
    731b:	6a 00                	push   0x0
    731d:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7321:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    7325:	26 ff 5d 2e          	call   DWORD PTR es:[di+0x2e]
    7329:	c9                   	leave
    732a:	ca 06 00             	retf   0x6
    732d:	55                   	push   bp
    732e:	89 e5                	mov    bp,sp
    7330:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7333:	26 80 7d 22 00       	cmp    BYTE PTR es:[di+0x22],0x0
    7338:	74 1f                	je     0x7359
    733a:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    733e:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    7342:	74 15                	je     0x7359
    7344:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7348:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    734c:	50                   	push   ax
    734d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7350:	06                   	push   es
    7351:	57                   	push   di
    7352:	9a b3 72 63 73       	call   0x7363:0x72b3
    7357:	eb 0c                	jmp    0x7365
    7359:	6a 00                	push   0x0
    735b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    735e:	06                   	push   es
    735f:	57                   	push   di
    7360:	9a b3 72 d6 73       	call   0x73d6:0x72b3
    7365:	c9                   	leave
    7366:	ca 04 00             	retf   0x4
    7369:	c8 06 00 00          	enter  0x6,0x0
    736d:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    7371:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7374:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    7377:	74 41                	je     0x73ba
    7379:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    737c:	06                   	push   es
    737d:	57                   	push   di
    737e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7381:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    7385:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7388:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    738b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    738e:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    7391:	75 02                	jne    0x7395
    7393:	eb 25                	jmp    0x73ba
    7395:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7398:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    739b:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    739e:	75 07                	jne    0x73a7
    73a0:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    73a3:	75 02                	jne    0x73a7
    73a5:	eb 17                	jmp    0x73be
    73a7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    73aa:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    73ae:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    73b2:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    73b5:	89 56 0c             	mov    WORD PTR [bp+0xc],dx
    73b8:	eb b7                	jmp    0x7371
    73ba:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    73be:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    73c1:	c9                   	leave
    73c2:	ca 08 00             	retf   0x8
    73c5:	55                   	push   bp
    73c6:	89 e5                	mov    bp,sp
    73c8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    73cb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    73ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73d1:	06                   	push   es
    73d2:	57                   	push   di
    73d3:	9a 69 73 e2 73       	call   0x73e2:0x7369
    73d8:	08 c0                	or     al,al
    73da:	74 08                	je     0x73e4
    73dc:	68 1f f2             	push   0xf21f
    73df:	9a ef 11 00 74       	call   0x7400:0x11ef
    73e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73e7:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    73eb:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    73ef:	74 11                	je     0x7402
    73f1:	ff 76 08             	push   WORD PTR [bp+0x8]
    73f4:	ff 76 06             	push   WORD PTR [bp+0x6]
    73f7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    73fb:	06                   	push   es
    73fc:	57                   	push   di
    73fd:	9a 76 3e 18 74       	call   0x7418:0x3e76
    7402:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7405:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    7408:	74 10                	je     0x741a
    740a:	ff 76 08             	push   WORD PTR [bp+0x8]
    740d:	ff 76 06             	push   WORD PTR [bp+0x6]
    7410:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7413:	06                   	push   es
    7414:	57                   	push   di
    7415:	9a 36 3e 30 74       	call   0x7430:0x3e36
    741a:	c9                   	leave
    741b:	ca 08 00             	retf   0x8
    741e:	55                   	push   bp
    741f:	89 e5                	mov    bp,sp
    7421:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7424:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7427:	26 88 45 22          	mov    BYTE PTR es:[di+0x22],al
    742b:	06                   	push   es
    742c:	57                   	push   di
    742d:	9a 2d 73 74 74       	call   0x7474:0x732d
    7432:	c9                   	leave
    7433:	ca 06 00             	retf   0x6
    7436:	55                   	push   bp
    7437:	89 e5                	mov    bp,sp
    7439:	ff 76 0c             	push   WORD PTR [bp+0xc]
    743c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    743f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7442:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    7446:	06                   	push   es
    7447:	57                   	push   di
    7448:	9a 2b 0c a6 74       	call   0x74a6:0xc2b
    744d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7450:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7453:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7456:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    745a:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    745e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7461:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7465:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    7469:	74 0b                	je     0x7476
    746b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    746f:	06                   	push   es
    7470:	57                   	push   di
    7471:	9a b5 41 7e 74       	call   0x747e:0x41b5
    7476:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7479:	06                   	push   es
    747a:	57                   	push   di
    747b:	9a f0 77 b0 74       	call   0x74b0:0x77f0
    7480:	c9                   	leave
    7481:	ca 08 00             	retf   0x8
    7484:	55                   	push   bp
    7485:	89 e5                	mov    bp,sp
    7487:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    748a:	31 c0                	xor    ax,ax
    748c:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    7490:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    7494:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7497:	ff 76 0a             	push   WORD PTR [bp+0xa]
    749a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    749d:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    74a1:	06                   	push   es
    74a2:	57                   	push   di
    74a3:	9a a7 0f 09 75       	call   0x7509:0xfa7
    74a8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    74ab:	06                   	push   es
    74ac:	57                   	push   di
    74ad:	9a f0 77 c8 74       	call   0x74c8:0x77f0
    74b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74b5:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    74b9:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    74bd:	74 0b                	je     0x74ca
    74bf:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    74c3:	06                   	push   es
    74c4:	57                   	push   di
    74c5:	9a b5 41 14 75       	call   0x7514:0x41b5
    74ca:	c9                   	leave
    74cb:	ca 08 00             	retf   0x8
    74ce:	c8 04 00 00          	enter  0x4,0x0
    74d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74d5:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    74d9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    74dd:	48                   	dec    ax
    74de:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    74e1:	31 c0                	xor    ax,ax
    74e3:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    74e6:	7f 36                	jg     0x751e
    74e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    74eb:	eb 03                	jmp    0x74f0
    74ed:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    74f0:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    74f3:	50                   	push   ax
    74f4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    74f7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    74fa:	ff 76 fe             	push   WORD PTR [bp-0x2]
    74fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7500:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    7504:	06                   	push   es
    7505:	57                   	push   di
    7506:	9a d0 0d ff ff       	call   0xffff:0xdd0
    750b:	89 c7                	mov    di,ax
    750d:	8e c2                	mov    es,dx
    750f:	06                   	push   es
    7510:	57                   	push   di
    7511:	9a d3 79 3f 75       	call   0x753f:0x79d3
    7516:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7519:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    751c:	75 cf                	jne    0x74ed
    751e:	c9                   	leave
    751f:	ca 0a 00             	retf   0xa
    7522:	73 75                	jae    0x7599
    7524:	98                   	cbw
    7525:	75 98                	jne    0x74bf
    7527:	75 98                	jne    0x74c1
    7529:	75 98                	jne    0x74c3
    752b:	75 bb                	jne    0x74e8
    752d:	75 55                	jne    0x7584
    752f:	89 e5                	mov    bp,sp
    7531:	80 7e 0e 06          	cmp    BYTE PTR [bp+0xe],0x6
    7535:	75 0d                	jne    0x7544
    7537:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    753a:	06                   	push   es
    753b:	57                   	push   di
    753c:	9a 2d 73 60 75       	call   0x7560:0x732d
    7541:	e9 94 00             	jmp    0x75d8
    7544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7547:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    754c:	75 03                	jne    0x7551
    754e:	e9 87 00             	jmp    0x75d8
    7551:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    7554:	50                   	push   ax
    7555:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7558:	ff 76 0a             	push   WORD PTR [bp+0xa]
    755b:	06                   	push   es
    755c:	57                   	push   di
    755d:	9a ce 74 33 76       	call   0x7633:0x74ce
    7562:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    7565:	3c 05                	cmp    al,0x5
    7567:	77 6f                	ja     0x75d8
    7569:	98                   	cbw
    756a:	89 c3                	mov    bx,ax
    756c:	d1 e3                	shl    bx,1
    756e:	2e ff a7 22 75       	jmp    WORD PTR cs:[bx+0x7522]
    7573:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7576:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    757a:	09 c0                	or     ax,ax
    757c:	74 18                	je     0x7596
    757e:	ff 76 08             	push   WORD PTR [bp+0x8]
    7581:	ff 76 06             	push   WORD PTR [bp+0x6]
    7584:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7587:	ff 76 0a             	push   WORD PTR [bp+0xa]
    758a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    758e:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    7592:	26 ff 5d 2e          	call   DWORD PTR es:[di+0x2e]
    7596:	eb 40                	jmp    0x75d8
    7598:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    759b:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    759f:	09 c0                	or     ax,ax
    75a1:	74 16                	je     0x75b9
    75a3:	ff 76 08             	push   WORD PTR [bp+0x8]
    75a6:	ff 76 06             	push   WORD PTR [bp+0x6]
    75a9:	6a 00                	push   0x0
    75ab:	6a 00                	push   0x0
    75ad:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    75b1:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    75b5:	26 ff 5d 2e          	call   DWORD PTR es:[di+0x2e]
    75b9:	eb 1d                	jmp    0x75d8
    75bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75be:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    75c2:	09 c0                	or     ax,ax
    75c4:	74 12                	je     0x75d8
    75c6:	ff 76 08             	push   WORD PTR [bp+0x8]
    75c9:	ff 76 06             	push   WORD PTR [bp+0x6]
    75cc:	26 ff 75 3c          	push   WORD PTR es:[di+0x3c]
    75d0:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    75d4:	26 ff 5d 36          	call   DWORD PTR es:[di+0x36]
    75d8:	c9                   	leave
    75d9:	ca 0a 00             	retf   0xa
    75dc:	55                   	push   bp
    75dd:	89 e5                	mov    bp,sp
    75df:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    75e3:	74 08                	je     0x75ed
    75e5:	83 ec 08             	sub    sp,0x8
    75e8:	9a e2 1f f8 75       	call   0x75f8:0x1fe2
    75ed:	31 c0                	xor    ax,ax
    75ef:	50                   	push   ax
    75f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75f3:	06                   	push   es
    75f4:	57                   	push   di
    75f5:	9a 50 1f 40 76       	call   0x7640:0x1f50
    75fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75fd:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    7603:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7607:	74 07                	je     0x7610
    7609:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    760d:	83 c4 06             	add    sp,0x6
    7610:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7613:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7616:	c9                   	leave
    7617:	ca 06 00             	retf   0x6
    761a:	55                   	push   bp
    761b:	89 e5                	mov    bp,sp
    761d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7620:	26 c6 45 11 00       	mov    BYTE PTR es:[di+0x11],0x0
    7625:	26 c6 45 12 00       	mov    BYTE PTR es:[di+0x12],0x0
    762a:	6a 00                	push   0x0
    762c:	6a 00                	push   0x0
    762e:	06                   	push   es
    762f:	57                   	push   di
    7630:	9a 31 77 5d 76       	call   0x765d:0x7731
    7635:	31 c0                	xor    ax,ax
    7637:	50                   	push   ax
    7638:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    763b:	06                   	push   es
    763c:	57                   	push   di
    763d:	9a 66 1f 4b 76       	call   0x764b:0x1f66
    7642:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7646:	74 05                	je     0x764d
    7648:	9a 0f 20 78 7b       	call   0x7b78:0x200f
    764d:	c9                   	leave
    764e:	ca 06 00             	retf   0x6
    7651:	c8 04 00 00          	enter  0x4,0x0
    7655:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7658:	06                   	push   es
    7659:	57                   	push   di
    765a:	9a fa 76 85 76       	call   0x7685:0x76fa
    765f:	89 c7                	mov    di,ax
    7661:	8e c2                	mov    es,dx
    7663:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    7667:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    766a:	26 2b 45 0c          	sub    ax,WORD PTR es:[di+0xc]
    766e:	40                   	inc    ax
    766f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7672:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    7676:	7d 05                	jge    0x767d
    7678:	31 c0                	xor    ax,ax
    767a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    767d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7680:	06                   	push   es
    7681:	57                   	push   di
    7682:	9a fa 76 ac 76       	call   0x76ac:0x76fa
    7687:	89 c7                	mov    di,ax
    7689:	8e c2                	mov    es,dx
    768b:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    768f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7692:	26 2b 45 0c          	sub    ax,WORD PTR es:[di+0xc]
    7696:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7699:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    769d:	7d 05                	jge    0x76a4
    769f:	31 c0                	xor    ax,ax
    76a1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    76a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76a7:	06                   	push   es
    76a8:	57                   	push   di
    76a9:	9a fa 76 c3 76       	call   0x76c3:0x76fa
    76ae:	89 c7                	mov    di,ax
    76b0:	8e c2                	mov    es,dx
    76b2:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    76b6:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    76b9:	7d 15                	jge    0x76d0
    76bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76be:	06                   	push   es
    76bf:	57                   	push   di
    76c0:	9a fa 76 50 77       	call   0x7750:0x76fa
    76c5:	89 c7                	mov    di,ax
    76c7:	8e c2                	mov    es,dx
    76c9:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    76cd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    76d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76d3:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    76d7:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    76da:	7d 07                	jge    0x76e3
    76dc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    76df:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    76e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76e6:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    76ea:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    76ed:	7e 07                	jle    0x76f6
    76ef:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    76f2:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    76f6:	c9                   	leave
    76f7:	ca 04 00             	retf   0x4
    76fa:	c8 04 00 00          	enter  0x4,0x0
    76fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7701:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    7705:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    7709:	74 14                	je     0x771f
    770b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    770f:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    7713:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    7717:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    771a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    771d:	eb 08                	jmp    0x7727
    771f:	31 c0                	xor    ax,ax
    7721:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7724:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7727:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    772a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    772d:	c9                   	leave
    772e:	ca 04 00             	retf   0x4
    7731:	55                   	push   bp
    7732:	89 e5                	mov    bp,sp
    7734:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7737:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    773b:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    773f:	74 11                	je     0x7752
    7741:	ff 76 08             	push   WORD PTR [bp+0x8]
    7744:	ff 76 06             	push   WORD PTR [bp+0x6]
    7747:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    774b:	06                   	push   es
    774c:	57                   	push   di
    774d:	9a 84 74 68 77       	call   0x7768:0x7484
    7752:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7755:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    7758:	74 10                	je     0x776a
    775a:	ff 76 08             	push   WORD PTR [bp+0x8]
    775d:	ff 76 06             	push   WORD PTR [bp+0x6]
    7760:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7763:	06                   	push   es
    7764:	57                   	push   di
    7765:	9a 36 74 89 77       	call   0x7789:0x7436
    776a:	c9                   	leave
    776b:	ca 08 00             	retf   0x8
    776e:	55                   	push   bp
    776f:	89 e5                	mov    bp,sp
    7771:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7774:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    7778:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    777b:	74 0e                	je     0x778b
    777d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    7780:	26 88 45 10          	mov    BYTE PTR es:[di+0x10],al
    7784:	06                   	push   es
    7785:	57                   	push   di
    7786:	9a f0 77 b0 77       	call   0x77b0:0x77f0
    778b:	c9                   	leave
    778c:	ca 06 00             	retf   0x6
    778f:	55                   	push   bp
    7790:	89 e5                	mov    bp,sp
    7792:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7795:	26 8a 45 11          	mov    al,BYTE PTR es:[di+0x11]
    7799:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    779c:	74 2b                	je     0x77c9
    779e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    77a1:	26 88 45 11          	mov    BYTE PTR es:[di+0x11],al
    77a5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    77a9:	74 09                	je     0x77b4
    77ab:	06                   	push   es
    77ac:	57                   	push   di
    77ad:	9a 51 76 1a 78       	call   0x781a:0x7651
    77b2:	eb 09                	jmp    0x77bd
    77b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77b7:	31 c0                	xor    ax,ax
    77b9:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    77bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c0:	06                   	push   es
    77c1:	57                   	push   di
    77c2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77c5:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    77c9:	c9                   	leave
    77ca:	ca 06 00             	retf   0x6
    77cd:	55                   	push   bp
    77ce:	89 e5                	mov    bp,sp
    77d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77d3:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    77d7:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    77da:	74 10                	je     0x77ec
    77dc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    77df:	26 88 45 12          	mov    BYTE PTR es:[di+0x12],al
    77e3:	06                   	push   es
    77e4:	57                   	push   di
    77e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77e8:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    77ec:	c9                   	leave
    77ed:	ca 06 00             	retf   0x6
    77f0:	55                   	push   bp
    77f1:	89 e5                	mov    bp,sp
    77f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77f6:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    77fa:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    77fe:	74 0b                	je     0x780b
    7800:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7804:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    7809:	75 04                	jne    0x780f
    780b:	b0 00                	mov    al,0x0
    780d:	eb 02                	jmp    0x7811
    780f:	b0 01                	mov    al,0x1
    7811:	50                   	push   ax
    7812:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7815:	06                   	push   es
    7816:	57                   	push   di
    7817:	9a 8f 77 52 78       	call   0x7852:0x778f
    781c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    781f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    7823:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    7827:	74 1a                	je     0x7843
    7829:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    782d:	26 8a 45 24          	mov    al,BYTE PTR es:[di+0x24]
    7831:	3c 02                	cmp    al,0x2
    7833:	72 0e                	jb     0x7843
    7835:	3c 04                	cmp    al,0x4
    7837:	77 0a                	ja     0x7843
    7839:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    783c:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    7841:	74 04                	je     0x7847
    7843:	b0 00                	mov    al,0x0
    7845:	eb 02                	jmp    0x7849
    7847:	b0 01                	mov    al,0x1
    7849:	50                   	push   ax
    784a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    784d:	06                   	push   es
    784e:	57                   	push   di
    784f:	9a cd 77 5c 78       	call   0x785c:0x77cd
    7854:	c9                   	leave
    7855:	ca 04 00             	retf   0x4
    7858:	00 00                	add    BYTE PTR [bx+si],al
    785a:	8c 78 ba             	mov    WORD PTR [bx+si-0x46],?
    785d:	78 55                	js     0x78b4
    785f:	89 e5                	mov    bp,sp
    7861:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7864:	26 c6 45 13 01       	mov    BYTE PTR es:[di+0x13],0x1
    7869:	b8 58 78             	mov    ax,0x7858
    786c:	0e                   	push   cs
    786d:	50                   	push   ax
    786e:	55                   	push   bp
    786f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7873:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7877:	06                   	push   es
    7878:	57                   	push   di
    7879:	26 c4 3d             	les    di,DWORD PTR es:[di]
    787c:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    7880:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7884:	83 c4 06             	add    sp,0x6
    7887:	b8 95 78             	mov    ax,0x7895
    788a:	0e                   	push   cs
    788b:	50                   	push   ax
    788c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    788f:	26 c6 45 13 00       	mov    BYTE PTR es:[di+0x13],0x0
    7894:	cb                   	retf
    7895:	c9                   	leave
    7896:	ca 04 00             	retf   0x4
    7899:	c8 02 00 00          	enter  0x2,0x0
    789d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78a0:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    78a5:	75 15                	jne    0x78bc
    78a7:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    78ab:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    78af:	74 0b                	je     0x78bc
    78b1:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    78b5:	06                   	push   es
    78b6:	57                   	push   di
    78b7:	9a 90 72 53 79       	call   0x7953:0x7290
    78bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78bf:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    78c3:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    78c6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    78c9:	c9                   	leave
    78ca:	ca 04 00             	retf   0x4
    78cd:	c8 02 00 00          	enter  0x2,0x0
    78d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78d4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    78d8:	26 80 7d 24 04       	cmp    BYTE PTR es:[di+0x24],0x4
    78dd:	75 07                	jne    0x78e6
    78df:	31 c0                	xor    ax,ax
    78e1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    78e4:	eb 19                	jmp    0x78ff
    78e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78e9:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    78ed:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    78f1:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    78f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78f8:	26 2b 45 0e          	sub    ax,WORD PTR es:[di+0xe]
    78fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    78ff:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7902:	c9                   	leave
    7903:	ca 04 00             	retf   0x4
    7906:	55                   	push   bp
    7907:	89 e5                	mov    bp,sp
    7909:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    790c:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7910:	26 80 7d 24 04       	cmp    BYTE PTR es:[di+0x24],0x4
    7915:	74 16                	je     0x792d
    7917:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    791a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    791d:	26 03 45 0e          	add    ax,WORD PTR es:[di+0xe]
    7921:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7925:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7929:	26 89 45 30          	mov    WORD PTR es:[di+0x30],ax
    792d:	c9                   	leave
    792e:	ca 06 00             	retf   0x6
    7931:	55                   	push   bp
    7932:	89 e5                	mov    bp,sp
    7934:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7937:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    793b:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    793e:	74 34                	je     0x7974
    7940:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7943:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    7947:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    794c:	74 26                	je     0x7974
    794e:	06                   	push   es
    794f:	57                   	push   di
    7950:	9a 51 76 5d 79       	call   0x795d:0x7651
    7955:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7958:	06                   	push   es
    7959:	57                   	push   di
    795a:	9a fa 76 68 79       	call   0x7968:0x76fa
    795f:	89 c7                	mov    di,ax
    7961:	8e c2                	mov    es,dx
    7963:	06                   	push   es
    7964:	57                   	push   di
    7965:	9a b5 41 72 79       	call   0x7972:0x41b5
    796a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    796d:	06                   	push   es
    796e:	57                   	push   di
    796f:	9a 51 76 e5 79       	call   0x79e5:0x7651
    7974:	c9                   	leave
    7975:	ca 06 00             	retf   0x6
    7978:	c8 02 00 00          	enter  0x2,0x0
    797c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    797f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7983:	26 80 7d 24 04       	cmp    BYTE PTR es:[di+0x24],0x4
    7988:	75 07                	jne    0x7991
    798a:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    798f:	eb 25                	jmp    0x79b6
    7991:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7994:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7998:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    799c:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    79a0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    79a3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    79a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79a9:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    79ad:	7e 07                	jle    0x79b6
    79af:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    79b3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    79b6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    79b9:	c9                   	leave
    79ba:	ca 04 00             	retf   0x4
    79bd:	0b 7a 0b             	or     di,WORD PTR [bp+si+0xb]
    79c0:	7a 27                	jp     0x79e9
    79c2:	7a 27                	jp     0x79eb
    79c4:	7a 27                	jp     0x79ed
    79c6:	7a d5                	jp     0x799d
    79c8:	7a 01                	jp     0x79cb
    79ca:	7b e1                	jnp    0x79ad
    79cc:	7a 01                	jp     0x79cf
    79ce:	7b 01                	jnp    0x79d1
    79d0:	7b ef                	jnp    0x79c1
    79d2:	7a c8                	jp     0x799c
    79d4:	08 00                	or     BYTE PTR [bx+si],al
    79d6:	00 80 7e 0e          	add    BYTE PTR [bx+si+0xe7e],al
    79da:	06                   	push   es
    79db:	75 0d                	jne    0x79ea
    79dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79e0:	06                   	push   es
    79e1:	57                   	push   di
    79e2:	9a f0 77 dd 7a       	call   0x7add:0x77f0
    79e7:	e9 17 01             	jmp    0x7b01
    79ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79ed:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    79f2:	75 03                	jne    0x79f7
    79f4:	e9 0a 01             	jmp    0x7b01
    79f7:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    79fa:	3c 0a                	cmp    al,0xa
    79fc:	76 03                	jbe    0x7a01
    79fe:	e9 00 01             	jmp    0x7b01
    7a01:	98                   	cbw
    7a02:	89 c3                	mov    bx,ax
    7a04:	d1 e3                	shl    bx,1
    7a06:	2e ff a7 bd 79       	jmp    WORD PTR cs:[bx+0x79bd]
    7a0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a0e:	26 80 7d 13 00       	cmp    BYTE PTR es:[di+0x13],0x0
    7a13:	75 0f                	jne    0x7a24
    7a15:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7a18:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7a1b:	06                   	push   es
    7a1c:	57                   	push   di
    7a1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a20:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    7a24:	e9 da 00             	jmp    0x7b01
    7a27:	31 c0                	xor    ax,ax
    7a29:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a2f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7a33:	26 80 7d 24 04       	cmp    BYTE PTR es:[di+0x24],0x4
    7a38:	74 5f                	je     0x7a99
    7a3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a3d:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7a41:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    7a45:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    7a49:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7a4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a4f:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    7a53:	99                   	cwd
    7a54:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    7a57:	13 56 0c             	adc    dx,WORD PTR [bp+0xc]
    7a5a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7a5d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7a60:	26 03 45 0c          	add    ax,WORD PTR es:[di+0xc]
    7a64:	48                   	dec    ax
    7a65:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7a68:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7a6b:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    7a6e:	7e 0b                	jle    0x7a7b
    7a70:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7a73:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    7a76:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7a79:	eb 11                	jmp    0x7a8c
    7a7b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7a7e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    7a81:	7d 09                	jge    0x7a8c
    7a83:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    7a86:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    7a89:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7a8c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7a8f:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    7a92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a95:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    7a99:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    7a9c:	3c 02                	cmp    al,0x2
    7a9e:	75 0e                	jne    0x7aae
    7aa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7aa3:	06                   	push   es
    7aa4:	57                   	push   di
    7aa5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7aa8:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    7aac:	eb 25                	jmp    0x7ad3
    7aae:	3c 03                	cmp    al,0x3
    7ab0:	75 11                	jne    0x7ac3
    7ab2:	ff 76 f8             	push   WORD PTR [bp-0x8]
    7ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ab8:	06                   	push   es
    7ab9:	57                   	push   di
    7aba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7abd:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    7ac1:	eb 10                	jmp    0x7ad3
    7ac3:	3c 04                	cmp    al,0x4
    7ac5:	75 0c                	jne    0x7ad3
    7ac7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7aca:	06                   	push   es
    7acb:	57                   	push   di
    7acc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7acf:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7ad3:	eb 2c                	jmp    0x7b01
    7ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ad8:	06                   	push   es
    7ad9:	57                   	push   di
    7ada:	9a 5e 78 8a 7b       	call   0x7b8a:0x785e
    7adf:	eb 20                	jmp    0x7b01
    7ae1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ae4:	06                   	push   es
    7ae5:	57                   	push   di
    7ae6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7ae9:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    7aed:	eb 12                	jmp    0x7b01
    7aef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7af2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7af5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7af8:	06                   	push   es
    7af9:	57                   	push   di
    7afa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7afd:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    7b01:	c9                   	leave
    7b02:	ca 0a 00             	retf   0xa
    7b05:	55                   	push   bp
    7b06:	89 e5                	mov    bp,sp
    7b08:	c9                   	leave
    7b09:	ca 04 00             	retf   0x4
    7b0c:	55                   	push   bp
    7b0d:	89 e5                	mov    bp,sp
    7b0f:	c9                   	leave
    7b10:	ca 04 00             	retf   0x4
    7b13:	55                   	push   bp
    7b14:	89 e5                	mov    bp,sp
    7b16:	6a 00                	push   0x0
    7b18:	6a 00                	push   0x0
    7b1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b1d:	06                   	push   es
    7b1e:	57                   	push   di
    7b1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b22:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    7b26:	c9                   	leave
    7b27:	ca 04 00             	retf   0x4
    7b2a:	55                   	push   bp
    7b2b:	89 e5                	mov    bp,sp
    7b2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b30:	06                   	push   es
    7b31:	57                   	push   di
    7b32:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b35:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    7b39:	c9                   	leave
    7b3a:	ca 06 00             	retf   0x6
    7b3d:	55                   	push   bp
    7b3e:	89 e5                	mov    bp,sp
    7b40:	c9                   	leave
    7b41:	ca 04 00             	retf   0x4
    7b44:	55                   	push   bp
    7b45:	89 e5                	mov    bp,sp
    7b47:	c9                   	leave
    7b48:	ca 08 00             	retf   0x8
    7b4b:	55                   	push   bp
    7b4c:	89 e5                	mov    bp,sp
    7b4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b51:	06                   	push   es
    7b52:	57                   	push   di
    7b53:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b56:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    7b5a:	c9                   	leave
    7b5b:	ca 04 00             	retf   0x4
    7b5e:	55                   	push   bp
    7b5f:	89 e5                	mov    bp,sp
    7b61:	c9                   	leave
    7b62:	ca 08 00             	retf   0x8
    7b65:	55                   	push   bp
    7b66:	89 e5                	mov    bp,sp
    7b68:	c9                   	leave
    7b69:	ca 04 00             	retf   0x4
    7b6c:	55                   	push   bp
    7b6d:	89 e5                	mov    bp,sp
    7b6f:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    7b73:	06                   	push   es
    7b74:	57                   	push   di
    7b75:	9a 7f 1f ff ff       	call   0xffff:0x1f7f
    7b7a:	c9                   	leave
    7b7b:	cb                   	retf
    7b7c:	55                   	push   bp
    7b7d:	89 e5                	mov    bp,sp
    7b7f:	6a 00                	push   0x0
    7b81:	6a 00                	push   0x0
    7b83:	b0 01                	mov    al,0x1
    7b85:	50                   	push   ax
    7b86:	b8 b6 00             	mov    ax,0xb6
    7b89:	ba 91 7b             	mov    dx,0x7b91
    7b8c:	52                   	push   dx
    7b8d:	50                   	push   ax
    7b8e:	9a 9d 15 9e 7b       	call   0x7b9e:0x159d
    7b93:	a3 c6 2a             	mov    ds:0x2ac6,ax
    7b96:	89 16 c8 2a          	mov    WORD PTR ds:0x2ac8,dx
    7b9a:	bf 6c 7b             	mov    di,0x7b6c
    7b9d:	b8 ff ff             	mov    ax,0xffff
    7ba0:	50                   	push   ax
    7ba1:	57                   	push   di
    7ba2:	9a 74 05 ff ff       	call   0xffff:0x574
    7ba7:	c9                   	leave
    7ba8:	cb                   	retf
