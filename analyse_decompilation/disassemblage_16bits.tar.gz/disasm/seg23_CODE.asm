; ================================================================
; seg23_CODE  (14611 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	17                   	pop    ss
       1:	00 0d                	add    BYTE PTR [di],cl
       3:	53                   	push   bx
       4:	69 6d 73 74 72       	imul   bp,WORD PTR [di+0x73],0x7274
       9:	61                   	popa
       a:	31 2e 44 4c          	xor    WORD PTR ds:0x4c44,bp
       e:	4c                   	dec    sp
       f:	00 00                	add    BYTE PTR [bx+si],al
      11:	00 b1 00 18          	add    BYTE PTR [bx+di+0x1800],dh
      15:	01 01                	add    WORD PTR [bx+di],ax
      17:	00 00                	add    BYTE PTR [bx+si],al
      19:	00 04                	add    BYTE PTR [si],al
      1b:	00 00                	add    BYTE PTR [bx+si],al
      1d:	00 55 89             	add    BYTE PTR [di-0x77],dl
      20:	e5 b8                	in     ax,0xb8
      22:	0c 01                	or     al,0x1
      24:	9a 44 04 4d 00       	call   0x4d:0x444
      29:	81 ec 0c 01          	sub    sp,0x10c
      2d:	9a 94 35 c5 00       	call   0xc5:0x3594
      32:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
      37:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
      3c:	bf 02 00             	mov    di,0x2
      3f:	0e                   	push   cs
      40:	57                   	push   di
      41:	8d be f4 fe          	lea    di,[bp-0x10c]
      45:	16                   	push   ss
      46:	57                   	push   di
      47:	68 ff 00             	push   0xff
      4a:	9a e7 17 f5 00       	call   0xf5:0x17e7
      4f:	8d be f5 fe          	lea    di,[bp-0x10b]
      53:	16                   	push   ss
      54:	57                   	push   di
      55:	9a ff ff 00 00       	call   0x0:0xffff
      5a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
      5d:	b8 10 00             	mov    ax,0x10
      60:	0e                   	push   cs
      61:	50                   	push   ax
      62:	55                   	push   bp
      63:	ff 36 58 18          	push   WORD PTR ds:0x1858
      67:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
      6b:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
      6f:	74 34                	je     0xa5
      71:	c7 46 fc fe ff       	mov    WORD PTR [bp-0x4],0xfffe
      76:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
      7b:	ff 76 fa             	push   WORD PTR [bp-0x6]
      7e:	6a 00                	push   0x0
      80:	6a 36                	push   0x36
      82:	9a ff ff 00 00       	call   0x0:0xffff
      87:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
      8a:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
      8d:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
      90:	0b 46 f8             	or     ax,WORD PTR [bp-0x8]
      93:	74 10                	je     0xa5
      95:	31 c0                	xor    ax,ax
      97:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
      9a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
      9d:	bf 0c 20             	mov    di,0x200c
      a0:	1e                   	push   ds
      a1:	57                   	push   di
      a2:	ff 5e f6             	call   DWORD PTR [bp-0xa]
      a5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
      a9:	83 c4 06             	add    sp,0x6
      ac:	b8 ba 00             	mov    ax,0xba
      af:	0e                   	push   cs
      b0:	50                   	push   ax
      b1:	ff 76 fa             	push   WORD PTR [bp-0x6]
      b4:	9a ff ff 00 00       	call   0x0:0xffff
      b9:	cb                   	retf
      ba:	bf 0c 20             	mov    di,0x200c
      bd:	1e                   	push   ds
      be:	57                   	push   di
      bf:	68 ff 00             	push   0xff
      c2:	9a c8 34 d2 00       	call   0xd2:0x34c8
      c7:	bf 2f 21             	mov    di,0x212f
      ca:	1e                   	push   ds
      cb:	57                   	push   di
      cc:	68 ff 00             	push   0xff
      cf:	9a c8 34 df 00       	call   0xdf:0x34c8
      d4:	bf 2f 26             	mov    di,0x262f
      d7:	1e                   	push   ds
      d8:	57                   	push   di
      d9:	68 ff 00             	push   0xff
      dc:	9a c8 34 08 01       	call   0x108:0x34c8
      e1:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
      e6:	eb 03                	jmp    0xeb
      e8:	ff 46 f4             	inc    WORD PTR [bp-0xc]
      eb:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
      ee:	99                   	cwd
      ef:	bf 16 00             	mov    di,0x16
      f2:	9a 16 04 5b 01       	call   0x15b:0x416
      f7:	8b f8                	mov    di,ax
      f9:	c1 e7 08             	shl    di,0x8
      fc:	81 c7 2f 21          	add    di,0x212f
     100:	1e                   	push   ds
     101:	57                   	push   di
     102:	68 ff 00             	push   0xff
     105:	9a c8 34 ff ff       	call   0xffff:0x34c8
     10a:	83 7e f4 04          	cmp    WORD PTR [bp-0xc],0x4
     10e:	75 d8                	jne    0xe8
     110:	bf 0c 20             	mov    di,0x200c
     113:	1e                   	push   ds
     114:	57                   	push   di
     115:	9a af 12 29 01       	call   0x129:0x12af
     11a:	a3 58 09             	mov    ds:0x958,ax
     11d:	89 16 5a 09          	mov    WORD PTR ds:0x95a,dx
     121:	bf 0c 20             	mov    di,0x200c
     124:	1e                   	push   ds
     125:	57                   	push   di
     126:	9a c8 01 44 01       	call   0x144:0x1c8
     12b:	a3 60 09             	mov    ds:0x960,ax
     12e:	89 16 62 09          	mov    WORD PTR ds:0x962,dx
     132:	bf 2f 21             	mov    di,0x212f
     135:	1e                   	push   ds
     136:	57                   	push   di
     137:	bf 2f 22             	mov    di,0x222f
     13a:	1e                   	push   ds
     13b:	57                   	push   di
     13c:	bf 2f 23             	mov    di,0x232f
     13f:	1e                   	push   ds
     140:	57                   	push   di
     141:	9a 52 07 a8 0b       	call   0xba8:0x752
     146:	a3 5c 09             	mov    ds:0x95c,ax
     149:	89 16 5e 09          	mov    WORD PTR ds:0x95e,dx
     14d:	a1 94 29             	mov    ax,ds:0x2994
     150:	8b 1e 96 29          	mov    bx,WORD PTR ds:0x2996
     154:	8b 16 98 29          	mov    dx,WORD PTR ds:0x2998
     158:	9a 9d 0f 60 01       	call   0x160:0xf9d
     15d:	9a 2f 10 d1 01       	call   0x1d1:0x102f
     162:	3b 16 5a 09          	cmp    dx,WORD PTR ds:0x95a
     166:	75 0a                	jne    0x172
     168:	3b 06 58 09          	cmp    ax,WORD PTR ds:0x958
     16c:	75 04                	jne    0x172
     16e:	b0 00                	mov    al,0x0
     170:	eb 02                	jmp    0x174
     172:	b0 01                	mov    al,0x1
     174:	8a c8                	mov    cl,al
     176:	a1 5c 09             	mov    ax,ds:0x95c
     179:	8b 16 5e 09          	mov    dx,WORD PTR ds:0x95e
     17d:	3b 16 54 05          	cmp    dx,WORD PTR ds:0x554
     181:	75 06                	jne    0x189
     183:	3b 06 52 05          	cmp    ax,WORD PTR ds:0x552
     187:	74 04                	je     0x18d
     189:	b0 00                	mov    al,0x0
     18b:	eb 02                	jmp    0x18f
     18d:	b0 01                	mov    al,0x1
     18f:	0a c1                	or     al,cl
     191:	a2 56 09             	mov    ds:0x956,al
     194:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     197:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     19a:	c9                   	leave
     19b:	cb                   	retf
     19c:	00 e4                	add    ah,ah
     19e:	2b 46 00             	sub    ax,WORD PTR [bp+0x0]
     1a1:	00 00                	add    BYTE PTR [bx+si],al
     1a3:	00 0c                	add    BYTE PTR [si],cl
     1a5:	00 00                	add    BYTE PTR [bx+si],al
     1a7:	00 01                	add    BYTE PTR [bx+di],al
     1a9:	00 00                	add    BYTE PTR [bx+si],al
     1ab:	00 04                	add    BYTE PTR [si],al
     1ad:	00 00                	add    BYTE PTR [bx+si],al
     1af:	00 00                	add    BYTE PTR [bx+si],al
     1b1:	00 00                	add    BYTE PTR [bx+si],al
     1b3:	00 ff                	add    bh,bh
     1b5:	00 00                	add    BYTE PTR [bx+si],al
     1b7:	00 00                	add    BYTE PTR [bx+si],al
     1b9:	00 00                	add    BYTE PTR [bx+si],al
     1bb:	00 0a                	add    BYTE PTR [bp+si],cl
     1bd:	00 00                	add    BYTE PTR [bx+si],al
     1bf:	00 01                	add    BYTE PTR [bx+di],al
     1c1:	00 00                	add    BYTE PTR [bx+si],al
     1c3:	00 0c                	add    BYTE PTR [si],cl
     1c5:	00 00                	add    BYTE PTR [bx+si],al
     1c7:	00 55 89             	add    BYTE PTR [di-0x77],dl
     1ca:	e5 b8                	in     ax,0xb8
     1cc:	34 01                	xor    al,0x1
     1ce:	9a 44 04 fe 01       	call   0x1fe:0x444
     1d3:	81 ec 34 01          	sub    sp,0x134
     1d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     1da:	89 7e d0             	mov    WORD PTR [bp-0x30],di
     1dd:	8c 46 d2             	mov    WORD PTR [bp-0x2e],es
     1e0:	31 c0                	xor    ax,ax
     1e2:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     1e5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     1e8:	31 c0                	xor    ax,ax
     1ea:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     1ed:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     1f0:	a1 42 05             	mov    ax,ds:0x542
     1f3:	8b 1e 44 05          	mov    bx,WORD PTR ds:0x544
     1f7:	8b 16 46 05          	mov    dx,WORD PTR ds:0x546
     1fb:	9a 9d 0f 35 02       	call   0x235:0xf9d
     200:	9b 2e d8 1e 9c 01    	fcomp  DWORD PTR cs:0x19c
     206:	9b dd 7e ce          	fstsw  WORD PTR [bp-0x32]
     20a:	90                   	nop
     20b:	9b                   	fwait
     20c:	8a 66 cf             	mov    ah,BYTE PTR [bp-0x31]
     20f:	9e                   	sahf
     210:	75 03                	jne    0x215
     212:	e9 eb 00             	jmp    0x300
     215:	c7 46 e0 01 00       	mov    WORD PTR [bp-0x20],0x1
     21a:	c7 46 e2 00 00       	mov    WORD PTR [bp-0x1e],0x0
     21f:	eb 08                	jmp    0x229
     221:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     225:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     229:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     22c:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     22f:	bf a0 01             	mov    di,0x1a0
     232:	9a 16 04 59 02       	call   0x259:0x416
     237:	8b f8                	mov    di,ax
     239:	80 bd 08 05 20       	cmp    BYTE PTR [di+0x508],0x20
     23e:	75 03                	jne    0x243
     240:	e9 ab 00             	jmp    0x2ee
     243:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     247:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     24b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     24e:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     251:	b9 04 00             	mov    cx,0x4
     254:	31 db                	xor    bx,bx
     256:	9a 70 16 6a 02       	call   0x26a:0x1670
     25b:	89 c8                	mov    ax,cx
     25d:	89 da                	mov    dx,bx
     25f:	05 01 00             	add    ax,0x1
     262:	83 d2 00             	adc    dx,0x0
     265:	71 05                	jno    0x26c
     267:	9a 3e 04 7e 02       	call   0x27e:0x43e
     26c:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     26f:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     272:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     275:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     278:	bf a0 01             	mov    di,0x1a0
     27b:	9a 16 04 a3 02       	call   0x2a3:0x416
     280:	8b f8                	mov    di,ax
     282:	8a 85 08 05          	mov    al,BYTE PTR [di+0x508]
     286:	88 46 f3             	mov    BYTE PTR [bp-0xd],al
     289:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     28c:	d0 e8                	shr    al,1
     28e:	73 33                	jae    0x2c3
     290:	8a 46 f3             	mov    al,BYTE PTR [bp-0xd]
     293:	f6 d0                	not    al
     295:	8a c8                	mov    cl,al
     297:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     29a:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     29d:	bf a8 01             	mov    di,0x1a8
     2a0:	9a 16 04 ba 02       	call   0x2ba:0x416
     2a5:	8b f8                	mov    di,ax
     2a7:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     2aa:	32 c1                	xor    al,cl
     2ac:	8a c8                	mov    cl,al
     2ae:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     2b1:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     2b4:	bf a8 01             	mov    di,0x1a8
     2b7:	9a 16 04 cf 02       	call   0x2cf:0x416
     2bc:	8b f8                	mov    di,ax
     2be:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     2c1:	eb 2b                	jmp    0x2ee
     2c3:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     2c6:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     2c9:	bf a8 01             	mov    di,0x1a8
     2cc:	9a 16 04 e7 02       	call   0x2e7:0x416
     2d1:	8b f8                	mov    di,ax
     2d3:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     2d6:	32 46 f3             	xor    al,BYTE PTR [bp-0xd]
     2d9:	8a c8                	mov    cl,al
     2db:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     2de:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     2e1:	bf a8 01             	mov    di,0x1a8
     2e4:	9a 16 04 43 03       	call   0x343:0x416
     2e9:	8b f8                	mov    di,ax
     2eb:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     2ee:	83 7e e2 00          	cmp    WORD PTR [bp-0x1e],0x0
     2f2:	74 03                	je     0x2f7
     2f4:	e9 2a ff             	jmp    0x221
     2f7:	83 7e e0 0c          	cmp    WORD PTR [bp-0x20],0xc
     2fb:	74 03                	je     0x300
     2fd:	e9 21 ff             	jmp    0x221
     300:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     303:	26 8a 05             	mov    al,BYTE PTR es:[di]
     306:	30 e4                	xor    ah,ah
     308:	31 d2                	xor    dx,dx
     30a:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
     30d:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
     310:	b8 01 00             	mov    ax,0x1
     313:	31 d2                	xor    dx,dx
     315:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
     318:	7e 03                	jle    0x31d
     31a:	e9 f9 00             	jmp    0x416
     31d:	7c 08                	jl     0x327
     31f:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
     322:	76 03                	jbe    0x327
     324:	e9 ef 00             	jmp    0x416
     327:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     32a:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     32d:	eb 08                	jmp    0x337
     32f:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     333:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     337:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     33a:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     33d:	bf b0 01             	mov    di,0x1b0
     340:	9a 16 04 69 03       	call   0x369:0x416
     345:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     348:	03 f8                	add    di,ax
     34a:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
     34e:	75 03                	jne    0x353
     350:	e9 ad 00             	jmp    0x400
     353:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     357:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     35b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     35e:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     361:	b9 04 00             	mov    cx,0x4
     364:	31 db                	xor    bx,bx
     366:	9a 70 16 7a 03       	call   0x37a:0x1670
     36b:	89 c8                	mov    ax,cx
     36d:	89 da                	mov    dx,bx
     36f:	05 01 00             	add    ax,0x1
     372:	83 d2 00             	adc    dx,0x0
     375:	71 05                	jno    0x37c
     377:	9a 3e 04 8e 03       	call   0x38e:0x43e
     37c:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     37f:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     382:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     385:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     388:	bf b0 01             	mov    di,0x1b0
     38b:	9a 16 04 ae 03       	call   0x3ae:0x416
     390:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     393:	03 f8                	add    di,ax
     395:	26 8a 05             	mov    al,BYTE PTR es:[di]
     398:	88 46 f3             	mov    BYTE PTR [bp-0xd],al
     39b:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     39e:	d0 e8                	shr    al,1
     3a0:	73 2d                	jae    0x3cf
     3a2:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     3a5:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     3a8:	bf a8 01             	mov    di,0x1a8
     3ab:	9a 16 04 c6 03       	call   0x3c6:0x416
     3b0:	8b f8                	mov    di,ax
     3b2:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     3b5:	32 46 f3             	xor    al,BYTE PTR [bp-0xd]
     3b8:	8a c8                	mov    cl,al
     3ba:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     3bd:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     3c0:	bf a8 01             	mov    di,0x1a8
     3c3:	9a 16 04 e2 03       	call   0x3e2:0x416
     3c8:	8b f8                	mov    di,ax
     3ca:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     3cd:	eb 31                	jmp    0x400
     3cf:	8a 46 f3             	mov    al,BYTE PTR [bp-0xd]
     3d2:	f6 d0                	not    al
     3d4:	8a c8                	mov    cl,al
     3d6:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     3d9:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     3dc:	bf a8 01             	mov    di,0x1a8
     3df:	9a 16 04 f9 03       	call   0x3f9:0x416
     3e4:	8b f8                	mov    di,ax
     3e6:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     3e9:	32 c1                	xor    al,cl
     3eb:	8a c8                	mov    cl,al
     3ed:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     3f0:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     3f3:	bf a8 01             	mov    di,0x1a8
     3f6:	9a 16 04 5b 04       	call   0x45b:0x416
     3fb:	8b f8                	mov    di,ax
     3fd:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     400:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     403:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     406:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
     409:	74 03                	je     0x40e
     40b:	e9 21 ff             	jmp    0x32f
     40e:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
     411:	74 03                	je     0x416
     413:	e9 19 ff             	jmp    0x32f
     416:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     419:	26 8a 85 00 01       	mov    al,BYTE PTR es:[di+0x100]
     41e:	30 e4                	xor    ah,ah
     420:	31 d2                	xor    dx,dx
     422:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
     425:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
     428:	b8 01 00             	mov    ax,0x1
     42b:	31 d2                	xor    dx,dx
     42d:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
     430:	7e 03                	jle    0x435
     432:	e9 c0 00             	jmp    0x4f5
     435:	7c 08                	jl     0x43f
     437:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
     43a:	76 03                	jbe    0x43f
     43c:	e9 b6 00             	jmp    0x4f5
     43f:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     442:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     445:	eb 08                	jmp    0x44f
     447:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     44b:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     44f:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     452:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     455:	bf b8 01             	mov    di,0x1b8
     458:	9a 16 04 80 04       	call   0x480:0x416
     45d:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     460:	03 f8                	add    di,ax
     462:	26 80 bd 00 01 20    	cmp    BYTE PTR es:[di+0x100],0x20
     468:	74 75                	je     0x4df
     46a:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     46e:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     472:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     475:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     478:	b9 04 00             	mov    cx,0x4
     47b:	31 db                	xor    bx,bx
     47d:	9a 70 16 91 04       	call   0x491:0x1670
     482:	89 c8                	mov    ax,cx
     484:	89 da                	mov    dx,bx
     486:	05 01 00             	add    ax,0x1
     489:	83 d2 00             	adc    dx,0x0
     48c:	71 05                	jno    0x493
     48e:	9a 3e 04 a5 04       	call   0x4a5:0x43e
     493:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     496:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     499:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     49c:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     49f:	bf b8 01             	mov    di,0x1b8
     4a2:	9a 16 04 c1 04       	call   0x4c1:0x416
     4a7:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     4aa:	03 f8                	add    di,ax
     4ac:	26 8a 85 00 01       	mov    al,BYTE PTR es:[di+0x100]
     4b1:	f6 d0                	not    al
     4b3:	8a c8                	mov    cl,al
     4b5:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     4b8:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     4bb:	bf a8 01             	mov    di,0x1a8
     4be:	9a 16 04 d8 04       	call   0x4d8:0x416
     4c3:	8b f8                	mov    di,ax
     4c5:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     4c8:	32 c1                	xor    al,cl
     4ca:	8a c8                	mov    cl,al
     4cc:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     4cf:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     4d2:	bf a8 01             	mov    di,0x1a8
     4d5:	9a 16 04 09 05       	call   0x509:0x416
     4da:	8b f8                	mov    di,ax
     4dc:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     4df:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     4e2:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     4e5:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
     4e8:	74 03                	je     0x4ed
     4ea:	e9 5a ff             	jmp    0x447
     4ed:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
     4f0:	74 03                	je     0x4f5
     4f2:	e9 52 ff             	jmp    0x447
     4f5:	8d be d0 fe          	lea    di,[bp-0x130]
     4f9:	16                   	push   ss
     4fa:	57                   	push   di
     4fb:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     4fe:	81 c7 0b 01          	add    di,0x10b
     502:	06                   	push   es
     503:	57                   	push   di
     504:	6a 0c                	push   0xc
     506:	9a fb 18 53 05       	call   0x553:0x18fb
     50b:	83 c4 04             	add    sp,0x4
     50e:	8a 86 d0 fe          	mov    al,BYTE PTR [bp-0x130]
     512:	30 e4                	xor    ah,ah
     514:	31 d2                	xor    dx,dx
     516:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
     51a:	89 96 ce fe          	mov    WORD PTR [bp-0x132],dx
     51e:	b8 01 00             	mov    ax,0x1
     521:	31 d2                	xor    dx,dx
     523:	3b 96 ce fe          	cmp    dx,WORD PTR [bp-0x132]
     527:	7e 03                	jle    0x52c
     529:	e9 c3 00             	jmp    0x5ef
     52c:	7c 09                	jl     0x537
     52e:	3b 86 cc fe          	cmp    ax,WORD PTR [bp-0x134]
     532:	76 03                	jbe    0x537
     534:	e9 b8 00             	jmp    0x5ef
     537:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     53a:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     53d:	eb 08                	jmp    0x547
     53f:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     543:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     547:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     54a:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     54d:	bf c0 01             	mov    di,0x1c0
     550:	9a 16 04 78 05       	call   0x578:0x416
     555:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     558:	03 f8                	add    di,ax
     55a:	26 80 bd 0a 01 20    	cmp    BYTE PTR es:[di+0x10a],0x20
     560:	74 75                	je     0x5d7
     562:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     566:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     56a:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     56d:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     570:	b9 04 00             	mov    cx,0x4
     573:	31 db                	xor    bx,bx
     575:	9a 70 16 89 05       	call   0x589:0x1670
     57a:	89 c8                	mov    ax,cx
     57c:	89 da                	mov    dx,bx
     57e:	05 01 00             	add    ax,0x1
     581:	83 d2 00             	adc    dx,0x0
     584:	71 05                	jno    0x58b
     586:	9a 3e 04 9d 05       	call   0x59d:0x43e
     58b:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     58e:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     591:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     594:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     597:	bf c0 01             	mov    di,0x1c0
     59a:	9a 16 04 b9 05       	call   0x5b9:0x416
     59f:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     5a2:	03 f8                	add    di,ax
     5a4:	26 8a 85 0a 01       	mov    al,BYTE PTR es:[di+0x10a]
     5a9:	f6 d0                	not    al
     5ab:	8a c8                	mov    cl,al
     5ad:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     5b0:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     5b3:	bf a8 01             	mov    di,0x1a8
     5b6:	9a 16 04 d0 05       	call   0x5d0:0x416
     5bb:	8b f8                	mov    di,ax
     5bd:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     5c0:	32 c1                	xor    al,cl
     5c2:	8a c8                	mov    cl,al
     5c4:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     5c7:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     5ca:	bf a8 01             	mov    di,0x1a8
     5cd:	9a 16 04 03 06       	call   0x603:0x416
     5d2:	8b f8                	mov    di,ax
     5d4:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     5d7:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     5da:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     5dd:	3b 96 ce fe          	cmp    dx,WORD PTR [bp-0x132]
     5e1:	74 03                	je     0x5e6
     5e3:	e9 59 ff             	jmp    0x53f
     5e6:	3b 86 cc fe          	cmp    ax,WORD PTR [bp-0x134]
     5ea:	74 03                	je     0x5ef
     5ec:	e9 50 ff             	jmp    0x53f
     5ef:	8d be d0 fe          	lea    di,[bp-0x130]
     5f3:	16                   	push   ss
     5f4:	57                   	push   di
     5f5:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     5f8:	81 c7 17 01          	add    di,0x117
     5fc:	06                   	push   es
     5fd:	57                   	push   di
     5fe:	6a 0c                	push   0xc
     600:	9a fb 18 4d 06       	call   0x64d:0x18fb
     605:	83 c4 04             	add    sp,0x4
     608:	8a 86 d0 fe          	mov    al,BYTE PTR [bp-0x130]
     60c:	30 e4                	xor    ah,ah
     60e:	31 d2                	xor    dx,dx
     610:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
     614:	89 96 ce fe          	mov    WORD PTR [bp-0x132],dx
     618:	b8 01 00             	mov    ax,0x1
     61b:	31 d2                	xor    dx,dx
     61d:	3b 96 ce fe          	cmp    dx,WORD PTR [bp-0x132]
     621:	7e 03                	jle    0x626
     623:	e9 fa 00             	jmp    0x720
     626:	7c 09                	jl     0x631
     628:	3b 86 cc fe          	cmp    ax,WORD PTR [bp-0x134]
     62c:	76 03                	jbe    0x631
     62e:	e9 ef 00             	jmp    0x720
     631:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     634:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     637:	eb 08                	jmp    0x641
     639:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     63d:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     641:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     644:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     647:	bf c0 01             	mov    di,0x1c0
     64a:	9a 16 04 75 06       	call   0x675:0x416
     64f:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     652:	03 f8                	add    di,ax
     654:	26 80 bd 16 01 20    	cmp    BYTE PTR es:[di+0x116],0x20
     65a:	75 03                	jne    0x65f
     65c:	e9 a9 00             	jmp    0x708
     65f:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     663:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     667:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     66a:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     66d:	b9 04 00             	mov    cx,0x4
     670:	31 db                	xor    bx,bx
     672:	9a 70 16 86 06       	call   0x686:0x1670
     677:	89 c8                	mov    ax,cx
     679:	89 da                	mov    dx,bx
     67b:	05 01 00             	add    ax,0x1
     67e:	83 d2 00             	adc    dx,0x0
     681:	71 05                	jno    0x688
     683:	9a 3e 04 9a 06       	call   0x69a:0x43e
     688:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     68b:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     68e:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     691:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     694:	bf c0 01             	mov    di,0x1c0
     697:	9a 16 04 bc 06       	call   0x6bc:0x416
     69c:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     69f:	03 f8                	add    di,ax
     6a1:	26 8a 85 16 01       	mov    al,BYTE PTR es:[di+0x116]
     6a6:	88 46 f3             	mov    BYTE PTR [bp-0xd],al
     6a9:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     6ac:	d0 e8                	shr    al,1
     6ae:	73 2d                	jae    0x6dd
     6b0:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     6b3:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     6b6:	bf a8 01             	mov    di,0x1a8
     6b9:	9a 16 04 d4 06       	call   0x6d4:0x416
     6be:	8b f8                	mov    di,ax
     6c0:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     6c3:	32 46 f3             	xor    al,BYTE PTR [bp-0xd]
     6c6:	8a c8                	mov    cl,al
     6c8:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     6cb:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     6ce:	bf a8 01             	mov    di,0x1a8
     6d1:	9a 16 04 e9 06       	call   0x6e9:0x416
     6d6:	8b f8                	mov    di,ax
     6d8:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     6db:	eb 2b                	jmp    0x708
     6dd:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     6e0:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     6e3:	bf a8 01             	mov    di,0x1a8
     6e6:	9a 16 04 01 07       	call   0x701:0x416
     6eb:	8b f8                	mov    di,ax
     6ed:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     6f0:	32 46 f3             	xor    al,BYTE PTR [bp-0xd]
     6f3:	8a c8                	mov    cl,al
     6f5:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     6f8:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     6fb:	bf a8 01             	mov    di,0x1a8
     6fe:	9a 16 04 5b 07       	call   0x75b:0x416
     703:	8b f8                	mov    di,ax
     705:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     708:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     70b:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     70e:	3b 96 ce fe          	cmp    dx,WORD PTR [bp-0x132]
     712:	74 03                	je     0x717
     714:	e9 22 ff             	jmp    0x639
     717:	3b 86 cc fe          	cmp    ax,WORD PTR [bp-0x134]
     71b:	74 03                	je     0x720
     71d:	e9 19 ff             	jmp    0x639
     720:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     723:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     726:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     729:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     72c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     72f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     732:	c9                   	leave
     733:	ca 04 00             	retf   0x4
     736:	00 e4                	add    ah,ah
     738:	2b 46 00             	sub    ax,WORD PTR [bp+0x0]
     73b:	00 00                	add    BYTE PTR [bx+si],al
     73d:	00 0c                	add    BYTE PTR [si],cl
     73f:	00 00                	add    BYTE PTR [bx+si],al
     741:	00 01                	add    BYTE PTR [bx+di],al
     743:	00 00                	add    BYTE PTR [bx+si],al
     745:	00 04                	add    BYTE PTR [si],al
     747:	00 00                	add    BYTE PTR [bx+si],al
     749:	00 00                	add    BYTE PTR [bx+si],al
     74b:	00 00                	add    BYTE PTR [bx+si],al
     74d:	00 ff                	add    bh,bh
     74f:	00 00                	add    BYTE PTR [bx+si],al
     751:	00 55 89             	add    BYTE PTR [di-0x77],dl
     754:	e5 b8                	in     ax,0xb8
     756:	30 00                	xor    BYTE PTR [bx+si],al
     758:	9a 44 04 7e 07       	call   0x77e:0x444
     75d:	83 ec 30             	sub    sp,0x30
     760:	31 c0                	xor    ax,ax
     762:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     765:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     768:	31 c0                	xor    ax,ax
     76a:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     76d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     770:	a1 42 05             	mov    ax,ds:0x542
     773:	8b 1e 44 05          	mov    bx,WORD PTR ds:0x544
     777:	8b 16 46 05          	mov    dx,WORD PTR ds:0x546
     77b:	9a 9d 0f b5 07       	call   0x7b5:0xf9d
     780:	9b 2e d8 1e 36 07    	fcomp  DWORD PTR cs:0x736
     786:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
     78a:	90                   	nop
     78b:	9b                   	fwait
     78c:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
     78f:	9e                   	sahf
     790:	75 03                	jne    0x795
     792:	e9 eb 00             	jmp    0x880
     795:	c7 46 e0 01 00       	mov    WORD PTR [bp-0x20],0x1
     79a:	c7 46 e2 00 00       	mov    WORD PTR [bp-0x1e],0x0
     79f:	eb 08                	jmp    0x7a9
     7a1:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     7a5:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     7a9:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     7ac:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     7af:	bf 3a 07             	mov    di,0x73a
     7b2:	9a 16 04 d9 07       	call   0x7d9:0x416
     7b7:	8b f8                	mov    di,ax
     7b9:	80 bd 16 05 20       	cmp    BYTE PTR [di+0x516],0x20
     7be:	75 03                	jne    0x7c3
     7c0:	e9 ab 00             	jmp    0x86e
     7c3:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     7c7:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     7cb:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     7ce:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     7d1:	b9 04 00             	mov    cx,0x4
     7d4:	31 db                	xor    bx,bx
     7d6:	9a 70 16 ea 07       	call   0x7ea:0x1670
     7db:	89 c8                	mov    ax,cx
     7dd:	89 da                	mov    dx,bx
     7df:	05 01 00             	add    ax,0x1
     7e2:	83 d2 00             	adc    dx,0x0
     7e5:	71 05                	jno    0x7ec
     7e7:	9a 3e 04 fe 07       	call   0x7fe:0x43e
     7ec:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     7ef:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     7f2:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     7f5:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     7f8:	bf 3a 07             	mov    di,0x73a
     7fb:	9a 16 04 23 08       	call   0x823:0x416
     800:	8b f8                	mov    di,ax
     802:	8a 85 16 05          	mov    al,BYTE PTR [di+0x516]
     806:	88 46 ef             	mov    BYTE PTR [bp-0x11],al
     809:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     80c:	d0 e8                	shr    al,1
     80e:	73 33                	jae    0x843
     810:	8a 46 ef             	mov    al,BYTE PTR [bp-0x11]
     813:	f6 d0                	not    al
     815:	8a c8                	mov    cl,al
     817:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     81a:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     81d:	bf 42 07             	mov    di,0x742
     820:	9a 16 04 3a 08       	call   0x83a:0x416
     825:	8b f8                	mov    di,ax
     827:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     82a:	32 c1                	xor    al,cl
     82c:	8a c8                	mov    cl,al
     82e:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     831:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     834:	bf 42 07             	mov    di,0x742
     837:	9a 16 04 4f 08       	call   0x84f:0x416
     83c:	8b f8                	mov    di,ax
     83e:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     841:	eb 2b                	jmp    0x86e
     843:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     846:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     849:	bf 42 07             	mov    di,0x742
     84c:	9a 16 04 67 08       	call   0x867:0x416
     851:	8b f8                	mov    di,ax
     853:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     856:	32 46 ef             	xor    al,BYTE PTR [bp-0x11]
     859:	8a c8                	mov    cl,al
     85b:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     85e:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     861:	bf 42 07             	mov    di,0x742
     864:	9a 16 04 c3 08       	call   0x8c3:0x416
     869:	8b f8                	mov    di,ax
     86b:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     86e:	83 7e e2 00          	cmp    WORD PTR [bp-0x1e],0x0
     872:	74 03                	je     0x877
     874:	e9 2a ff             	jmp    0x7a1
     877:	83 7e e0 0c          	cmp    WORD PTR [bp-0x20],0xc
     87b:	74 03                	je     0x880
     87d:	e9 21 ff             	jmp    0x7a1
     880:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     883:	26 8a 05             	mov    al,BYTE PTR es:[di]
     886:	30 e4                	xor    ah,ah
     888:	31 d2                	xor    dx,dx
     88a:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
     88d:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
     890:	b8 01 00             	mov    ax,0x1
     893:	31 d2                	xor    dx,dx
     895:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
     898:	7e 03                	jle    0x89d
     89a:	e9 2b 01             	jmp    0x9c8
     89d:	7c 08                	jl     0x8a7
     89f:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     8a2:	76 03                	jbe    0x8a7
     8a4:	e9 21 01             	jmp    0x9c8
     8a7:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     8aa:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     8ad:	eb 08                	jmp    0x8b7
     8af:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     8b3:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     8b7:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     8ba:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     8bd:	bf 4a 07             	mov    di,0x74a
     8c0:	9a 16 04 e9 08       	call   0x8e9:0x416
     8c5:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     8c8:	03 f8                	add    di,ax
     8ca:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
     8ce:	75 03                	jne    0x8d3
     8d0:	e9 df 00             	jmp    0x9b2
     8d3:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     8d7:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     8db:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     8de:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     8e1:	b9 04 00             	mov    cx,0x4
     8e4:	31 db                	xor    bx,bx
     8e6:	9a 70 16 fa 08       	call   0x8fa:0x1670
     8eb:	89 c8                	mov    ax,cx
     8ed:	89 da                	mov    dx,bx
     8ef:	05 01 00             	add    ax,0x1
     8f2:	83 d2 00             	adc    dx,0x0
     8f5:	71 05                	jno    0x8fc
     8f7:	9a 3e 04 0e 09       	call   0x90e:0x43e
     8fc:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     8ff:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     902:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     905:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     908:	bf 4a 07             	mov    di,0x74a
     90b:	9a 16 04 3c 09       	call   0x93c:0x416
     910:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     913:	03 f8                	add    di,ax
     915:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
     919:	b0 00                	mov    al,0x0
     91b:	74 01                	je     0x91e
     91d:	40                   	inc    ax
     91e:	8a d0                	mov    dl,al
     920:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     923:	d0 e8                	shr    al,1
     925:	b0 00                	mov    al,0x0
     927:	73 01                	jae    0x92a
     929:	40                   	inc    ax
     92a:	22 c2                	and    al,dl
     92c:	08 c0                	or     al,al
     92e:	74 42                	je     0x972
     930:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     933:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     936:	bf 4a 07             	mov    di,0x74a
     939:	9a 16 04 52 09       	call   0x952:0x416
     93e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     941:	03 f8                	add    di,ax
     943:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
     946:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     949:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     94c:	bf 42 07             	mov    di,0x742
     94f:	9a 16 04 69 09       	call   0x969:0x416
     954:	8b f8                	mov    di,ax
     956:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     959:	32 c1                	xor    al,cl
     95b:	8a c8                	mov    cl,al
     95d:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     960:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     963:	bf 42 07             	mov    di,0x742
     966:	9a 16 04 7e 09       	call   0x97e:0x416
     96b:	8b f8                	mov    di,ax
     96d:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     970:	eb 40                	jmp    0x9b2
     972:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     975:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     978:	bf 4a 07             	mov    di,0x74a
     97b:	9a 16 04 94 09       	call   0x994:0x416
     980:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     983:	03 f8                	add    di,ax
     985:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
     988:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     98b:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     98e:	bf 42 07             	mov    di,0x742
     991:	9a 16 04 ab 09       	call   0x9ab:0x416
     996:	8b f8                	mov    di,ax
     998:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     99b:	32 c1                	xor    al,cl
     99d:	8a c8                	mov    cl,al
     99f:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     9a2:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     9a5:	bf 42 07             	mov    di,0x742
     9a8:	9a 16 04 0b 0a       	call   0xa0b:0x416
     9ad:	8b f8                	mov    di,ax
     9af:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     9b2:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     9b5:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     9b8:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
     9bb:	74 03                	je     0x9c0
     9bd:	e9 ef fe             	jmp    0x8af
     9c0:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     9c3:	74 03                	je     0x9c8
     9c5:	e9 e7 fe             	jmp    0x8af
     9c8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     9cb:	26 8a 05             	mov    al,BYTE PTR es:[di]
     9ce:	30 e4                	xor    ah,ah
     9d0:	31 d2                	xor    dx,dx
     9d2:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
     9d5:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
     9d8:	b8 01 00             	mov    ax,0x1
     9db:	31 d2                	xor    dx,dx
     9dd:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
     9e0:	7e 03                	jle    0x9e5
     9e2:	e9 bc 00             	jmp    0xaa1
     9e5:	7c 08                	jl     0x9ef
     9e7:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     9ea:	76 03                	jbe    0x9ef
     9ec:	e9 b2 00             	jmp    0xaa1
     9ef:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     9f2:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     9f5:	eb 08                	jmp    0x9ff
     9f7:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     9fb:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     9ff:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     a02:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     a05:	bf 4a 07             	mov    di,0x74a
     a08:	9a 16 04 2e 0a       	call   0xa2e:0x416
     a0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a10:	03 f8                	add    di,ax
     a12:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
     a16:	74 73                	je     0xa8b
     a18:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     a1c:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     a20:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     a23:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     a26:	b9 04 00             	mov    cx,0x4
     a29:	31 db                	xor    bx,bx
     a2b:	9a 70 16 3f 0a       	call   0xa3f:0x1670
     a30:	89 c8                	mov    ax,cx
     a32:	89 da                	mov    dx,bx
     a34:	05 01 00             	add    ax,0x1
     a37:	83 d2 00             	adc    dx,0x0
     a3a:	71 05                	jno    0xa41
     a3c:	9a 3e 04 53 0a       	call   0xa53:0x43e
     a41:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     a44:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     a47:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     a4a:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     a4d:	bf 4a 07             	mov    di,0x74a
     a50:	9a 16 04 6d 0a       	call   0xa6d:0x416
     a55:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a58:	03 f8                	add    di,ax
     a5a:	26 8a 05             	mov    al,BYTE PTR es:[di]
     a5d:	f6 d0                	not    al
     a5f:	8a c8                	mov    cl,al
     a61:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     a64:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     a67:	bf 42 07             	mov    di,0x742
     a6a:	9a 16 04 84 0a       	call   0xa84:0x416
     a6f:	8b f8                	mov    di,ax
     a71:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     a74:	32 c1                	xor    al,cl
     a76:	8a c8                	mov    cl,al
     a78:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     a7b:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     a7e:	bf 42 07             	mov    di,0x742
     a81:	9a 16 04 e4 0a       	call   0xae4:0x416
     a86:	8b f8                	mov    di,ax
     a88:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     a8b:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     a8e:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     a91:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
     a94:	74 03                	je     0xa99
     a96:	e9 5e ff             	jmp    0x9f7
     a99:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     a9c:	74 03                	je     0xaa1
     a9e:	e9 56 ff             	jmp    0x9f7
     aa1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aa4:	26 8a 05             	mov    al,BYTE PTR es:[di]
     aa7:	30 e4                	xor    ah,ah
     aa9:	31 d2                	xor    dx,dx
     aab:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
     aae:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
     ab1:	b8 01 00             	mov    ax,0x1
     ab4:	31 d2                	xor    dx,dx
     ab6:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
     ab9:	7e 03                	jle    0xabe
     abb:	e9 bc 00             	jmp    0xb7a
     abe:	7c 08                	jl     0xac8
     ac0:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     ac3:	76 03                	jbe    0xac8
     ac5:	e9 b2 00             	jmp    0xb7a
     ac8:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     acb:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
     ace:	eb 08                	jmp    0xad8
     ad0:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     ad4:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     ad8:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     adb:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     ade:	bf 4a 07             	mov    di,0x74a
     ae1:	9a 16 04 07 0b       	call   0xb07:0x416
     ae6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ae9:	03 f8                	add    di,ax
     aeb:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
     aef:	74 73                	je     0xb64
     af1:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     af5:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     af9:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     afc:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     aff:	b9 04 00             	mov    cx,0x4
     b02:	31 db                	xor    bx,bx
     b04:	9a 70 16 18 0b       	call   0xb18:0x1670
     b09:	89 c8                	mov    ax,cx
     b0b:	89 da                	mov    dx,bx
     b0d:	05 01 00             	add    ax,0x1
     b10:	83 d2 00             	adc    dx,0x0
     b13:	71 05                	jno    0xb1a
     b15:	9a 3e 04 2c 0b       	call   0xb2c:0x43e
     b1a:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     b1d:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     b20:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     b23:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     b26:	bf 4a 07             	mov    di,0x74a
     b29:	9a 16 04 46 0b       	call   0xb46:0x416
     b2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b31:	03 f8                	add    di,ax
     b33:	26 8a 05             	mov    al,BYTE PTR es:[di]
     b36:	f6 d0                	not    al
     b38:	8a c8                	mov    cl,al
     b3a:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     b3d:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     b40:	bf 42 07             	mov    di,0x742
     b43:	9a 16 04 5d 0b       	call   0xb5d:0x416
     b48:	8b f8                	mov    di,ax
     b4a:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     b4d:	32 c1                	xor    al,cl
     b4f:	8a c8                	mov    cl,al
     b51:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     b54:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     b57:	bf 42 07             	mov    di,0x742
     b5a:	9a 16 04 59 0c       	call   0xc59:0x416
     b5f:	8b f8                	mov    di,ax
     b61:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     b64:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     b67:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     b6a:	3b 56 d2             	cmp    dx,WORD PTR [bp-0x2e]
     b6d:	74 03                	je     0xb72
     b6f:	e9 5e ff             	jmp    0xad0
     b72:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     b75:	74 03                	je     0xb7a
     b77:	e9 56 ff             	jmp    0xad0
     b7a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     b7d:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     b80:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b83:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     b86:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b89:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     b8c:	c9                   	leave
     b8d:	ca 0c 00             	retf   0xc
     b90:	01 00                	add    WORD PTR [bx+si],ax
     b92:	00 00                	add    BYTE PTR [bx+si],al
     b94:	0c 00                	or     al,0x0
     b96:	00 00                	add    BYTE PTR [bx+si],al
     b98:	01 00                	add    WORD PTR [bx+si],ax
     b9a:	00 00                	add    BYTE PTR [bx+si],al
     b9c:	06                   	push   es
     b9d:	00 00                	add    BYTE PTR [bx+si],al
     b9f:	00 08                	add    BYTE PTR [bx+si],cl
     ba1:	00 b1 01 ac          	add    BYTE PTR [bx+di-0x53ff],dh
     ba5:	0b 3a                	or     di,WORD PTR [bp+si]
     ba7:	0d b0 0b             	or     ax,0xbb0
     baa:	dc 01                	fadd   QWORD PTR [bx+di]
     bac:	b4 0b                	mov    ah,0xb
     bae:	44                   	inc    sp
     baf:	0d b8 0b             	or     ax,0xbb8
     bb2:	08 02                	or     BYTE PTR [bp+si],al
     bb4:	bc 0b 4e             	mov    sp,0x4e0b
     bb7:	0d c0 0b             	or     ax,0xbc0
     bba:	32 02                	xor    al,BYTE PTR [bp+si]
     bbc:	c4 0b                	les    cx,DWORD PTR [bp+di]
     bbe:	58                   	pop    ax
     bbf:	0d c8 0b             	or     ax,0xbc8
     bc2:	02 01                	add    al,BYTE PTR [bx+di]
     bc4:	cc                   	int3
     bc5:	0b 62 0d             	or     sp,WORD PTR [bp+si+0xd]
     bc8:	d0 0b                	ror    BYTE PTR [bp+di],1
     bca:	2d 01 d4             	sub    ax,0xd401
     bcd:	0b 6c 0d             	or     bp,WORD PTR [si+0xd]
     bd0:	d8 0b                	fmul   DWORD PTR [bp+di]
     bd2:	59                   	pop    cx
     bd3:	01 f6                	add    si,si
     bd5:	0b 76 0d             	or     si,WORD PTR [bp+0xd]
     bd8:	e0 0b                	loopne 0xbe5
     bda:	00 00                	add    BYTE PTR [bx+si],al
     bdc:	00 00                	add    BYTE PTR [bx+si],al
     bde:	80 0d fa             	or     BYTE PTR [di],0xfa
     be1:	0b 01                	or     ax,WORD PTR [bx+di]
     be3:	00 00                	add    BYTE PTR [bx+si],al
     be5:	00 0c                	add    BYTE PTR [si],cl
     be7:	00 00                	add    BYTE PTR [bx+si],al
     be9:	00 01                	add    BYTE PTR [bx+di],al
     beb:	00 00                	add    BYTE PTR [bx+si],al
     bed:	00 06 00 00          	add    BYTE PTR ds:0x0,al
     bf1:	00 08                	add    BYTE PTR [bx+si],cl
     bf3:	00 b1 01 fe          	add    BYTE PTR [bx+di-0x1ff],dh
     bf7:	0b 60 0e             	or     sp,WORD PTR [bx+si+0xe]
     bfa:	02 0c                	add    cl,BYTE PTR [si]
     bfc:	dc 01                	fadd   QWORD PTR [bx+di]
     bfe:	06                   	push   es
     bff:	0c 6a                	or     al,0x6a
     c01:	0e                   	push   cs
     c02:	0a 0c                	or     cl,BYTE PTR [si]
     c04:	08 02                	or     BYTE PTR [bp+si],al
     c06:	0e                   	push   cs
     c07:	0c 74                	or     al,0x74
     c09:	0e                   	push   cs
     c0a:	12 0c                	adc    cl,BYTE PTR [si]
     c0c:	32 02                	xor    al,BYTE PTR [bp+si]
     c0e:	16                   	push   ss
     c0f:	0c 7e                	or     al,0x7e
     c11:	0e                   	push   cs
     c12:	1a 0c                	sbb    cl,BYTE PTR [si]
     c14:	02 01                	add    al,BYTE PTR [bx+di]
     c16:	1e                   	push   ds
     c17:	0c 88                	or     al,0x88
     c19:	0e                   	push   cs
     c1a:	22 0c                	and    cl,BYTE PTR [si]
     c1c:	2d 01 26             	sub    ax,0x2601
     c1f:	0c 92                	or     al,0x92
     c21:	0e                   	push   cs
     c22:	2a 0c                	sub    cl,BYTE PTR [si]
     c24:	59                   	pop    cx
     c25:	01 a5 21 9c          	add    WORD PTR [di-0x63df],sp
     c29:	0e                   	push   cs
     c2a:	32 0c                	xor    cl,BYTE PTR [si]
     c2c:	00 00                	add    BYTE PTR [bx+si],al
     c2e:	00 00                	add    BYTE PTR [bx+si],al
     c30:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     c31:	0e                   	push   cs
     c32:	c5 12                	lds    dx,DWORD PTR [bp+si]
     c34:	00 e4                	add    ah,ah
     c36:	2b 46 00             	sub    ax,WORD PTR [bp+0x0]
     c39:	00 00                	add    BYTE PTR [bx+si],al
     c3b:	00 0c                	add    BYTE PTR [si],cl
     c3d:	00 00                	add    BYTE PTR [bx+si],al
     c3f:	00 01                	add    BYTE PTR [bx+di],al
     c41:	00 00                	add    BYTE PTR [bx+si],al
     c43:	00 04                	add    BYTE PTR [si],al
     c45:	00 00                	add    BYTE PTR [bx+si],al
     c47:	00 00                	add    BYTE PTR [bx+si],al
     c49:	00 00                	add    BYTE PTR [bx+si],al
     c4b:	00 ff                	add    bh,bh
     c4d:	00 00                	add    BYTE PTR [bx+si],al
     c4f:	00 55 89             	add    BYTE PTR [di-0x77],dl
     c52:	e5 b8                	in     ax,0xb8
     c54:	34 00                	xor    al,0x0
     c56:	9a 44 04 89 0c       	call   0xc89:0x444
     c5b:	83 ec 34             	sub    sp,0x34
     c5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c61:	89 7e d0             	mov    WORD PTR [bp-0x30],di
     c64:	8c 46 d2             	mov    WORD PTR [bp-0x2e],es
     c67:	c7 46 dc 01 00       	mov    WORD PTR [bp-0x24],0x1
     c6c:	c7 46 de 00 00       	mov    WORD PTR [bp-0x22],0x0
     c71:	eb 08                	jmp    0xc7b
     c73:	83 46 dc 01          	add    WORD PTR [bp-0x24],0x1
     c77:	83 56 de 00          	adc    WORD PTR [bp-0x22],0x0
     c7b:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     c7e:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     c81:	b9 02 00             	mov    cx,0x2
     c84:	31 db                	xor    bx,bx
     c86:	9a 5c 17 96 0c       	call   0xc96:0x175c
     c8b:	2d 01 00             	sub    ax,0x1
     c8e:	83 da 00             	sbb    dx,0x0
     c91:	71 05                	jno    0xc98
     c93:	9a 3e 04 9e 0c       	call   0xc9e:0x43e
     c98:	bf 90 0b             	mov    di,0xb90
     c9b:	9a 16 04 b9 0c       	call   0xcb9:0x416
     ca0:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     ca3:	03 f8                	add    di,ax
     ca5:	26 80 bd 0a 01 01    	cmp    BYTE PTR es:[di+0x10a],0x1
     cab:	75 16                	jne    0xcc3
     cad:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     cb0:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     cb3:	bf 98 0b             	mov    di,0xb98
     cb6:	9a 16 04 d1 0c       	call   0xcd1:0x416
     cbb:	8b f8                	mov    di,ax
     cbd:	c6 43 e7 00          	mov    BYTE PTR [bp+di-0x19],0x0
     cc1:	eb 35                	jmp    0xcf8
     cc3:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     cc6:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     cc9:	b9 02 00             	mov    cx,0x2
     ccc:	31 db                	xor    bx,bx
     cce:	9a 5c 17 d9 0c       	call   0xcd9:0x175c
     cd3:	bf 90 0b             	mov    di,0xb90
     cd6:	9a 16 04 f1 0c       	call   0xcf1:0x416
     cdb:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     cde:	03 f8                	add    di,ax
     ce0:	26 8a 8d 0a 01       	mov    cl,BYTE PTR es:[di+0x10a]
     ce5:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     ce8:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     ceb:	bf 98 0b             	mov    di,0xb98
     cee:	9a 16 04 24 0d       	call   0xd24:0x416
     cf3:	8b f8                	mov    di,ax
     cf5:	88 4b e7             	mov    BYTE PTR [bp+di-0x19],cl
     cf8:	83 7e de 00          	cmp    WORD PTR [bp-0x22],0x0
     cfc:	74 03                	je     0xd01
     cfe:	e9 72 ff             	jmp    0xc73
     d01:	83 7e dc 06          	cmp    WORD PTR [bp-0x24],0x6
     d05:	74 03                	je     0xd0a
     d07:	e9 69 ff             	jmp    0xc73
     d0a:	b8 a0 0b             	mov    ax,0xba0
     d0d:	0e                   	push   cs
     d0e:	50                   	push   ax
     d0f:	55                   	push   bp
     d10:	ff 36 58 18          	push   WORD PTR ds:0x1858
     d14:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     d18:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
     d1b:	8b 5e ea             	mov    bx,WORD PTR [bp-0x16]
     d1e:	8b 56 ec             	mov    dx,WORD PTR [bp-0x14]
     d21:	9a 9d 0f 29 0d       	call   0xd29:0xf9d
     d26:	9a 2f 10 8b 0d       	call   0xd8b:0x102f
     d2b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d2e:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     d31:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     d35:	83 c4 06             	add    sp,0x6
     d38:	eb 53                	jmp    0xd8d
     d3a:	31 c0                	xor    ax,ax
     d3c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d3f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d42:	eb 44                	jmp    0xd88
     d44:	31 c0                	xor    ax,ax
     d46:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d49:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d4c:	eb 3a                	jmp    0xd88
     d4e:	31 c0                	xor    ax,ax
     d50:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d53:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d56:	eb 30                	jmp    0xd88
     d58:	31 c0                	xor    ax,ax
     d5a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d5d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d60:	eb 26                	jmp    0xd88
     d62:	31 c0                	xor    ax,ax
     d64:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d67:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d6a:	eb 1c                	jmp    0xd88
     d6c:	31 c0                	xor    ax,ax
     d6e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d71:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d74:	eb 12                	jmp    0xd88
     d76:	31 c0                	xor    ax,ax
     d78:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d7b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d7e:	eb 08                	jmp    0xd88
     d80:	31 c0                	xor    ax,ax
     d82:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d85:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     d88:	9a 34 14 af 0d       	call   0xdaf:0x1434
     d8d:	c7 46 dc 01 00       	mov    WORD PTR [bp-0x24],0x1
     d92:	c7 46 de 00 00       	mov    WORD PTR [bp-0x22],0x0
     d97:	eb 08                	jmp    0xda1
     d99:	83 46 dc 01          	add    WORD PTR [bp-0x24],0x1
     d9d:	83 56 de 00          	adc    WORD PTR [bp-0x22],0x0
     da1:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     da4:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     da7:	b9 02 00             	mov    cx,0x2
     daa:	31 db                	xor    bx,bx
     dac:	9a 5c 17 bc 0d       	call   0xdbc:0x175c
     db1:	2d 01 00             	sub    ax,0x1
     db4:	83 da 00             	sbb    dx,0x0
     db7:	71 05                	jno    0xdbe
     db9:	9a 3e 04 c4 0d       	call   0xdc4:0x43e
     dbe:	bf e2 0b             	mov    di,0xbe2
     dc1:	9a 16 04 df 0d       	call   0xddf:0x416
     dc6:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     dc9:	03 f8                	add    di,ax
     dcb:	26 80 bd 16 01 01    	cmp    BYTE PTR es:[di+0x116],0x1
     dd1:	75 16                	jne    0xde9
     dd3:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     dd6:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     dd9:	bf ea 0b             	mov    di,0xbea
     ddc:	9a 16 04 f7 0d       	call   0xdf7:0x416
     de1:	8b f8                	mov    di,ax
     de3:	c6 43 e7 00          	mov    BYTE PTR [bp+di-0x19],0x0
     de7:	eb 35                	jmp    0xe1e
     de9:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     dec:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     def:	b9 02 00             	mov    cx,0x2
     df2:	31 db                	xor    bx,bx
     df4:	9a 5c 17 ff 0d       	call   0xdff:0x175c
     df9:	bf e2 0b             	mov    di,0xbe2
     dfc:	9a 16 04 17 0e       	call   0xe17:0x416
     e01:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     e04:	03 f8                	add    di,ax
     e06:	26 8a 8d 16 01       	mov    cl,BYTE PTR es:[di+0x116]
     e0b:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
     e0e:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
     e11:	bf ea 0b             	mov    di,0xbea
     e14:	9a 16 04 4a 0e       	call   0xe4a:0x416
     e19:	8b f8                	mov    di,ax
     e1b:	88 4b e7             	mov    BYTE PTR [bp+di-0x19],cl
     e1e:	83 7e de 00          	cmp    WORD PTR [bp-0x22],0x0
     e22:	74 03                	je     0xe27
     e24:	e9 72 ff             	jmp    0xd99
     e27:	83 7e dc 06          	cmp    WORD PTR [bp-0x24],0x6
     e2b:	74 03                	je     0xe30
     e2d:	e9 69 ff             	jmp    0xd99
     e30:	b8 f2 0b             	mov    ax,0xbf2
     e33:	0e                   	push   cs
     e34:	50                   	push   ax
     e35:	55                   	push   bp
     e36:	ff 36 58 18          	push   WORD PTR ds:0x1858
     e3a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     e3e:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
     e41:	8b 5e ea             	mov    bx,WORD PTR [bp-0x16]
     e44:	8b 56 ec             	mov    dx,WORD PTR [bp-0x14]
     e47:	9a 9d 0f 4f 0e       	call   0xe4f:0xf9d
     e4c:	9a 2f 10 b1 0e       	call   0xeb1:0x102f
     e51:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e54:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     e57:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     e5b:	83 c4 06             	add    sp,0x6
     e5e:	eb 53                	jmp    0xeb3
     e60:	31 c0                	xor    ax,ax
     e62:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e65:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e68:	eb 44                	jmp    0xeae
     e6a:	31 c0                	xor    ax,ax
     e6c:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e6f:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e72:	eb 3a                	jmp    0xeae
     e74:	31 c0                	xor    ax,ax
     e76:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e79:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e7c:	eb 30                	jmp    0xeae
     e7e:	31 c0                	xor    ax,ax
     e80:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e83:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e86:	eb 26                	jmp    0xeae
     e88:	31 c0                	xor    ax,ax
     e8a:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e8d:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e90:	eb 1c                	jmp    0xeae
     e92:	31 c0                	xor    ax,ax
     e94:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     e97:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     e9a:	eb 12                	jmp    0xeae
     e9c:	31 c0                	xor    ax,ax
     e9e:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     ea1:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     ea4:	eb 08                	jmp    0xeae
     ea6:	31 c0                	xor    ax,ax
     ea8:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     eab:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     eae:	9a 34 14 df 0e       	call   0xedf:0x1434
     eb3:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     eb6:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     eb9:	f7 d0                	not    ax
     ebb:	f7 d2                	not    dx
     ebd:	33 46 f8             	xor    ax,WORD PTR [bp-0x8]
     ec0:	33 56 fa             	xor    dx,WORD PTR [bp-0x6]
     ec3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     ec6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     ec9:	31 c0                	xor    ax,ax
     ecb:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     ece:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     ed1:	a1 42 05             	mov    ax,ds:0x542
     ed4:	8b 1e 44 05          	mov    bx,WORD PTR ds:0x544
     ed8:	8b 16 46 05          	mov    dx,WORD PTR ds:0x546
     edc:	9a 9d 0f 16 0f       	call   0xf16:0xf9d
     ee1:	9b 2e d8 1e 34 0c    	fcomp  DWORD PTR cs:0xc34
     ee7:	9b dd 7e ce          	fstsw  WORD PTR [bp-0x32]
     eeb:	90                   	nop
     eec:	9b                   	fwait
     eed:	8a 66 cf             	mov    ah,BYTE PTR [bp-0x31]
     ef0:	9e                   	sahf
     ef1:	75 03                	jne    0xef6
     ef3:	e9 eb 00             	jmp    0xfe1
     ef6:	c7 46 e0 01 00       	mov    WORD PTR [bp-0x20],0x1
     efb:	c7 46 e2 00 00       	mov    WORD PTR [bp-0x1e],0x0
     f00:	eb 08                	jmp    0xf0a
     f02:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
     f06:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
     f0a:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     f0d:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     f10:	bf 38 0c             	mov    di,0xc38
     f13:	9a 16 04 3a 0f       	call   0xf3a:0x416
     f18:	8b f8                	mov    di,ax
     f1a:	80 bd 24 05 20       	cmp    BYTE PTR [di+0x524],0x20
     f1f:	75 03                	jne    0xf24
     f21:	e9 ab 00             	jmp    0xfcf
     f24:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
     f28:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
     f2c:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     f2f:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     f32:	b9 04 00             	mov    cx,0x4
     f35:	31 db                	xor    bx,bx
     f37:	9a 70 16 4b 0f       	call   0xf4b:0x1670
     f3c:	89 c8                	mov    ax,cx
     f3e:	89 da                	mov    dx,bx
     f40:	05 01 00             	add    ax,0x1
     f43:	83 d2 00             	adc    dx,0x0
     f46:	71 05                	jno    0xf4d
     f48:	9a 3e 04 5f 0f       	call   0xf5f:0x43e
     f4d:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     f50:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     f53:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
     f56:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
     f59:	bf 38 0c             	mov    di,0xc38
     f5c:	9a 16 04 84 0f       	call   0xf84:0x416
     f61:	8b f8                	mov    di,ax
     f63:	8a 85 24 05          	mov    al,BYTE PTR [di+0x524]
     f67:	88 46 ef             	mov    BYTE PTR [bp-0x11],al
     f6a:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     f6d:	d0 e8                	shr    al,1
     f6f:	73 33                	jae    0xfa4
     f71:	8a 46 ef             	mov    al,BYTE PTR [bp-0x11]
     f74:	f6 d0                	not    al
     f76:	8a c8                	mov    cl,al
     f78:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     f7b:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     f7e:	bf 40 0c             	mov    di,0xc40
     f81:	9a 16 04 9b 0f       	call   0xf9b:0x416
     f86:	8b f8                	mov    di,ax
     f88:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     f8b:	32 c1                	xor    al,cl
     f8d:	8a c8                	mov    cl,al
     f8f:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     f92:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     f95:	bf 40 0c             	mov    di,0xc40
     f98:	9a 16 04 b0 0f       	call   0xfb0:0x416
     f9d:	8b f8                	mov    di,ax
     f9f:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     fa2:	eb 2b                	jmp    0xfcf
     fa4:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     fa7:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     faa:	bf 40 0c             	mov    di,0xc40
     fad:	9a 16 04 c8 0f       	call   0xfc8:0x416
     fb2:	8b f8                	mov    di,ax
     fb4:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
     fb7:	32 46 ef             	xor    al,BYTE PTR [bp-0x11]
     fba:	8a c8                	mov    cl,al
     fbc:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     fbf:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
     fc2:	bf 40 0c             	mov    di,0xc40
     fc5:	9a 16 04 2c 10       	call   0x102c:0x416
     fca:	8b f8                	mov    di,ax
     fcc:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
     fcf:	83 7e e2 00          	cmp    WORD PTR [bp-0x1e],0x0
     fd3:	74 03                	je     0xfd8
     fd5:	e9 2a ff             	jmp    0xf02
     fd8:	83 7e e0 0c          	cmp    WORD PTR [bp-0x20],0xc
     fdc:	74 03                	je     0xfe1
     fde:	e9 21 ff             	jmp    0xf02
     fe1:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
     fe4:	26 8a 05             	mov    al,BYTE PTR es:[di]
     fe7:	30 e4                	xor    ah,ah
     fe9:	31 d2                	xor    dx,dx
     feb:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
     fee:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
     ff1:	b8 01 00             	mov    ax,0x1
     ff4:	31 d2                	xor    dx,dx
     ff6:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
     ff9:	7e 03                	jle    0xffe
     ffb:	e9 a0 00             	jmp    0x109e
     ffe:	7c 08                	jl     0x1008
    1000:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
    1003:	76 03                	jbe    0x1008
    1005:	e9 96 00             	jmp    0x109e
    1008:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    100b:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    100e:	eb 08                	jmp    0x1018
    1010:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
    1014:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
    1018:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    101c:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    1020:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    1023:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    1026:	bf 48 0c             	mov    di,0xc48
    1029:	9a 16 04 5a 10       	call   0x105a:0x416
    102e:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    1031:	03 f8                	add    di,ax
    1033:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    1037:	b0 00                	mov    al,0x0
    1039:	74 01                	je     0x103c
    103b:	40                   	inc    ax
    103c:	8a d0                	mov    dl,al
    103e:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    1041:	d0 e8                	shr    al,1
    1043:	b0 00                	mov    al,0x0
    1045:	73 01                	jae    0x1048
    1047:	40                   	inc    ax
    1048:	22 c2                	and    al,dl
    104a:	08 c0                	or     al,al
    104c:	74 1e                	je     0x106c
    104e:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    1051:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    1054:	bf 48 0c             	mov    di,0xc48
    1057:	9a 16 04 78 10       	call   0x1078:0x416
    105c:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    105f:	03 f8                	add    di,ax
    1061:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1064:	32 46 f8             	xor    al,BYTE PTR [bp-0x8]
    1067:	88 46 f8             	mov    BYTE PTR [bp-0x8],al
    106a:	eb 1c                	jmp    0x1088
    106c:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    106f:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    1072:	bf 48 0c             	mov    di,0xc48
    1075:	9a 16 04 dd 10       	call   0x10dd:0x416
    107a:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    107d:	03 f8                	add    di,ax
    107f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1082:	32 46 f9             	xor    al,BYTE PTR [bp-0x7]
    1085:	88 46 f9             	mov    BYTE PTR [bp-0x7],al
    1088:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    108b:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    108e:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
    1091:	74 03                	je     0x1096
    1093:	e9 7a ff             	jmp    0x1010
    1096:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
    1099:	74 03                	je     0x109e
    109b:	e9 72 ff             	jmp    0x1010
    109e:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    10a1:	26 8a 85 23 06       	mov    al,BYTE PTR es:[di+0x623]
    10a6:	30 e4                	xor    ah,ah
    10a8:	31 d2                	xor    dx,dx
    10aa:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    10ad:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    10b0:	b8 01 00             	mov    ax,0x1
    10b3:	31 d2                	xor    dx,dx
    10b5:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
    10b8:	7f 6a                	jg     0x1124
    10ba:	7c 05                	jl     0x10c1
    10bc:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
    10bf:	77 63                	ja     0x1124
    10c1:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    10c4:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    10c7:	eb 08                	jmp    0x10d1
    10c9:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
    10cd:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
    10d1:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    10d4:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    10d7:	bf 48 0c             	mov    di,0xc48
    10da:	9a 16 04 00 11       	call   0x1100:0x416
    10df:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    10e2:	03 f8                	add    di,ax
    10e4:	26 80 bd 23 06 20    	cmp    BYTE PTR es:[di+0x623],0x20
    10ea:	74 28                	je     0x1114
    10ec:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    10f0:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    10f4:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    10f7:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    10fa:	bf 48 0c             	mov    di,0xc48
    10fd:	9a 16 04 44 11       	call   0x1144:0x416
    1102:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    1105:	03 f8                	add    di,ax
    1107:	26 8a 85 23 06       	mov    al,BYTE PTR es:[di+0x623]
    110c:	f6 d0                	not    al
    110e:	32 46 fa             	xor    al,BYTE PTR [bp-0x6]
    1111:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
    1114:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    1117:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    111a:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
    111d:	75 aa                	jne    0x10c9
    111f:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
    1122:	75 a5                	jne    0x10c9
    1124:	c7 46 dc 01 00       	mov    WORD PTR [bp-0x24],0x1
    1129:	c7 46 de 00 00       	mov    WORD PTR [bp-0x22],0x0
    112e:	eb 08                	jmp    0x1138
    1130:	83 46 dc 01          	add    WORD PTR [bp-0x24],0x1
    1134:	83 56 de 00          	adc    WORD PTR [bp-0x22],0x0
    1138:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    113b:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    113e:	bf 40 0c             	mov    di,0xc40
    1141:	9a 16 04 90 11       	call   0x1190:0x416
    1146:	c1 e0 08             	shl    ax,0x8
    1149:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    114c:	03 f8                	add    di,ax
    114e:	26 8a 85 23 01       	mov    al,BYTE PTR es:[di+0x123]
    1153:	30 e4                	xor    ah,ah
    1155:	31 d2                	xor    dx,dx
    1157:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    115a:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    115d:	b8 01 00             	mov    ax,0x1
    1160:	31 d2                	xor    dx,dx
    1162:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
    1165:	7e 03                	jle    0x116a
    1167:	e9 e9 00             	jmp    0x1253
    116a:	7c 08                	jl     0x1174
    116c:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
    116f:	76 03                	jbe    0x1174
    1171:	e9 df 00             	jmp    0x1253
    1174:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    1177:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    117a:	eb 08                	jmp    0x1184
    117c:	83 46 e0 01          	add    WORD PTR [bp-0x20],0x1
    1180:	83 56 e2 00          	adc    WORD PTR [bp-0x1e],0x0
    1184:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    1187:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    118a:	bf 48 0c             	mov    di,0xc48
    118d:	9a 16 04 a0 11       	call   0x11a0:0x416
    1192:	8b c8                	mov    cx,ax
    1194:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    1197:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    119a:	bf 40 0c             	mov    di,0xc40
    119d:	9a 16 04 cd 11       	call   0x11cd:0x416
    11a2:	c1 e0 08             	shl    ax,0x8
    11a5:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    11a8:	03 f8                	add    di,ax
    11aa:	03 f9                	add    di,cx
    11ac:	26 80 bd 23 01 20    	cmp    BYTE PTR es:[di+0x123],0x20
    11b2:	75 03                	jne    0x11b7
    11b4:	e9 86 00             	jmp    0x123d
    11b7:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    11bb:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    11bf:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    11c2:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    11c5:	b9 04 00             	mov    cx,0x4
    11c8:	31 db                	xor    bx,bx
    11ca:	9a 70 16 de 11       	call   0x11de:0x1670
    11cf:	89 c8                	mov    ax,cx
    11d1:	89 da                	mov    dx,bx
    11d3:	05 01 00             	add    ax,0x1
    11d6:	83 d2 00             	adc    dx,0x0
    11d9:	71 05                	jno    0x11e0
    11db:	9a 3e 04 f2 11       	call   0x11f2:0x43e
    11e0:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    11e3:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    11e6:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    11e9:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    11ec:	bf 48 0c             	mov    di,0xc48
    11ef:	9a 16 04 02 12       	call   0x1202:0x416
    11f4:	8b c8                	mov    cx,ax
    11f6:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    11f9:	8b 56 de             	mov    dx,WORD PTR [bp-0x22]
    11fc:	bf 40 0c             	mov    di,0xc40
    11ff:	9a 16 04 1f 12       	call   0x121f:0x416
    1204:	c1 e0 08             	shl    ax,0x8
    1207:	c4 7e d0             	les    di,DWORD PTR [bp-0x30]
    120a:	03 f8                	add    di,ax
    120c:	03 f9                	add    di,cx
    120e:	26 8a 8d 23 01       	mov    cl,BYTE PTR es:[di+0x123]
    1213:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    1216:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
    1219:	bf 40 0c             	mov    di,0xc40
    121c:	9a 16 04 36 12       	call   0x1236:0x416
    1221:	8b f8                	mov    di,ax
    1223:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
    1226:	32 c1                	xor    al,cl
    1228:	8a c8                	mov    cl,al
    122a:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    122d:	8b 56 da             	mov    dx,WORD PTR [bp-0x26]
    1230:	bf 40 0c             	mov    di,0xc40
    1233:	9a 16 04 b8 12       	call   0x12b8:0x416
    1238:	8b f8                	mov    di,ax
    123a:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
    123d:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    1240:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    1243:	3b 56 ce             	cmp    dx,WORD PTR [bp-0x32]
    1246:	74 03                	je     0x124b
    1248:	e9 31 ff             	jmp    0x117c
    124b:	3b 46 cc             	cmp    ax,WORD PTR [bp-0x34]
    124e:	74 03                	je     0x1253
    1250:	e9 29 ff             	jmp    0x117c
    1253:	83 7e de 00          	cmp    WORD PTR [bp-0x22],0x0
    1257:	74 03                	je     0x125c
    1259:	e9 d4 fe             	jmp    0x1130
    125c:	83 7e dc 04          	cmp    WORD PTR [bp-0x24],0x4
    1260:	74 03                	je     0x1265
    1262:	e9 cb fe             	jmp    0x1130
    1265:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1268:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    126b:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    126e:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    1271:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1274:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    1277:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    127a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    127d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1280:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1283:	c9                   	leave
    1284:	ca 04 00             	retf   0x4
    1287:	00 00                	add    BYTE PTR [bx+si],al
    1289:	00 00                	add    BYTE PTR [bx+si],al
    128b:	31 00                	xor    WORD PTR [bx+si],ax
    128d:	00 00                	add    BYTE PTR [bx+si],al
    128f:	01 00                	add    WORD PTR [bx+si],ax
    1291:	00 00                	add    BYTE PTR [bx+si],al
    1293:	0c 00                	or     al,0x0
    1295:	00 00                	add    BYTE PTR [bx+si],al
    1297:	01 00                	add    WORD PTR [bx+si],ax
    1299:	00 00                	add    BYTE PTR [bx+si],al
    129b:	06                   	push   es
    129c:	00 00                	add    BYTE PTR [bx+si],al
    129e:	00 00                	add    BYTE PTR [bx+si],al
    12a0:	00 00                	add    BYTE PTR [bx+si],al
    12a2:	00 ff                	add    bh,bh
    12a4:	00 00                	add    BYTE PTR [bx+si],al
    12a6:	00 01                	add    BYTE PTR [bx+di],al
    12a8:	00 00                	add    BYTE PTR [bx+si],al
    12aa:	00 04                	add    BYTE PTR [si],al
    12ac:	00 00                	add    BYTE PTR [bx+si],al
    12ae:	00 55 89             	add    BYTE PTR [di-0x77],dl
    12b1:	e5 b8                	in     ax,0xb8
    12b3:	40                   	inc    ax
    12b4:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    12b8:	fc                   	cld
    12b9:	12 83 ec 40          	adc    al,BYTE PTR [bp+di+0x40ec]
    12bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c0:	06                   	push   es
    12c1:	57                   	push   di
    12c2:	9a 50 0c 71 19       	call   0x1971:0xc50
    12c7:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    12ca:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    12cd:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    12d0:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    12d3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    12d6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    12d9:	c7 46 da 01 00       	mov    WORD PTR [bp-0x26],0x1
    12de:	c7 46 dc 00 00       	mov    WORD PTR [bp-0x24],0x0
    12e3:	eb 08                	jmp    0x12ed
    12e5:	83 46 da 01          	add    WORD PTR [bp-0x26],0x1
    12e9:	83 56 dc 00          	adc    WORD PTR [bp-0x24],0x0
    12ed:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    12f0:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    12f3:	8b 4e da             	mov    cx,WORD PTR [bp-0x26]
    12f6:	8b 5e dc             	mov    bx,WORD PTR [bp-0x24]
    12f9:	9a 5c 17 41 13       	call   0x1341:0x175c
    12fe:	33 46 f8             	xor    ax,WORD PTR [bp-0x8]
    1301:	33 56 fa             	xor    dx,WORD PTR [bp-0x6]
    1304:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1307:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    130a:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    130d:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    1310:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1313:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1316:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1319:	89 7e c4             	mov    WORD PTR [bp-0x3c],di
    131c:	8c 46 c6             	mov    WORD PTR [bp-0x3a],es
    131f:	c7 46 d2 01 00       	mov    WORD PTR [bp-0x2e],0x1
    1324:	c7 46 d4 00 00       	mov    WORD PTR [bp-0x2c],0x0
    1329:	eb 08                	jmp    0x1333
    132b:	83 46 d2 01          	add    WORD PTR [bp-0x2e],0x1
    132f:	83 56 d4 00          	adc    WORD PTR [bp-0x2c],0x0
    1333:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1336:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1339:	b9 02 00             	mov    cx,0x2
    133c:	31 db                	xor    bx,bx
    133e:	9a 5c 17 4e 13       	call   0x134e:0x175c
    1343:	2d 01 00             	sub    ax,0x1
    1346:	83 da 00             	sbb    dx,0x0
    1349:	71 05                	jno    0x1350
    134b:	9a 3e 04 56 13       	call   0x1356:0x43e
    1350:	bf 8f 12             	mov    di,0x128f
    1353:	9a 16 04 66 13       	call   0x1366:0x416
    1358:	8b c8                	mov    cx,ax
    135a:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    135d:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    1360:	bf 87 12             	mov    di,0x1287
    1363:	9a 16 04 86 13       	call   0x1386:0x416
    1368:	6b c0 0c             	imul   ax,ax,0xc
    136b:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    136e:	03 f8                	add    di,ax
    1370:	03 f9                	add    di,cx
    1372:	26 80 bd 2d 07 01    	cmp    BYTE PTR es:[di+0x72d],0x1
    1378:	75 16                	jne    0x1390
    137a:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    137d:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1380:	bf 97 12             	mov    di,0x1297
    1383:	9a 16 04 9e 13       	call   0x139e:0x416
    1388:	8b f8                	mov    di,ax
    138a:	c6 43 e7 00          	mov    BYTE PTR [bp+di-0x19],0x0
    138e:	eb 4a                	jmp    0x13da
    1390:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1393:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1396:	b9 02 00             	mov    cx,0x2
    1399:	31 db                	xor    bx,bx
    139b:	9a 5c 17 a6 13       	call   0x13a6:0x175c
    13a0:	bf 8f 12             	mov    di,0x128f
    13a3:	9a 16 04 b6 13       	call   0x13b6:0x416
    13a8:	8b c8                	mov    cx,ax
    13aa:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    13ad:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    13b0:	bf 87 12             	mov    di,0x1287
    13b3:	9a 16 04 d3 13       	call   0x13d3:0x416
    13b8:	6b c0 0c             	imul   ax,ax,0xc
    13bb:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    13be:	03 f8                	add    di,ax
    13c0:	03 f9                	add    di,cx
    13c2:	26 8a 8d 2d 07       	mov    cl,BYTE PTR es:[di+0x72d]
    13c7:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    13ca:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    13cd:	bf 97 12             	mov    di,0x1297
    13d0:	9a 16 04 37 14       	call   0x1437:0x416
    13d5:	8b f8                	mov    di,ax
    13d7:	88 4b e7             	mov    BYTE PTR [bp+di-0x19],cl
    13da:	83 7e d4 00          	cmp    WORD PTR [bp-0x2c],0x0
    13de:	74 03                	je     0x13e3
    13e0:	e9 48 ff             	jmp    0x132b
    13e3:	83 7e d2 06          	cmp    WORD PTR [bp-0x2e],0x6
    13e7:	74 03                	je     0x13ec
    13e9:	e9 3f ff             	jmp    0x132b
    13ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ef:	89 7e c4             	mov    WORD PTR [bp-0x3c],di
    13f2:	8c 46 c6             	mov    WORD PTR [bp-0x3a],es
    13f5:	26 8a 85 23 01       	mov    al,BYTE PTR es:[di+0x123]
    13fa:	30 e4                	xor    ah,ah
    13fc:	31 d2                	xor    dx,dx
    13fe:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    1401:	89 56 c2             	mov    WORD PTR [bp-0x3e],dx
    1404:	b8 01 00             	mov    ax,0x1
    1407:	31 d2                	xor    dx,dx
    1409:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    140c:	7e 03                	jle    0x1411
    140e:	e9 e2 00             	jmp    0x14f3
    1411:	7c 08                	jl     0x141b
    1413:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    1416:	76 03                	jbe    0x141b
    1418:	e9 d8 00             	jmp    0x14f3
    141b:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    141e:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    1421:	eb 08                	jmp    0x142b
    1423:	83 46 d6 01          	add    WORD PTR [bp-0x2a],0x1
    1427:	83 56 d8 00          	adc    WORD PTR [bp-0x28],0x0
    142b:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    142e:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1431:	bf 9f 12             	mov    di,0x129f
    1434:	9a 16 04 5f 14       	call   0x145f:0x416
    1439:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    143c:	03 f8                	add    di,ax
    143e:	26 80 bd 23 01 20    	cmp    BYTE PTR es:[di+0x123],0x20
    1444:	75 03                	jne    0x1449
    1446:	e9 94 00             	jmp    0x14dd
    1449:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    144d:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    1451:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1454:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1457:	b9 04 00             	mov    cx,0x4
    145a:	31 db                	xor    bx,bx
    145c:	9a 70 16 70 14       	call   0x1470:0x1670
    1461:	89 c8                	mov    ax,cx
    1463:	89 da                	mov    dx,bx
    1465:	05 01 00             	add    ax,0x1
    1468:	83 d2 00             	adc    dx,0x0
    146b:	71 05                	jno    0x1472
    146d:	9a 3e 04 84 14       	call   0x1484:0x43e
    1472:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    1475:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    1478:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    147b:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    147e:	bf a7 12             	mov    di,0x12a7
    1481:	9a 16 04 9d 14       	call   0x149d:0x416
    1486:	8b f8                	mov    di,ax
    1488:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
    148b:	32 46 e8             	xor    al,BYTE PTR [bp-0x18]
    148e:	88 46 e8             	mov    BYTE PTR [bp-0x18],al
    1491:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    1494:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1497:	bf 9f 12             	mov    di,0x129f
    149a:	9a 16 04 bf 14       	call   0x14bf:0x416
    149f:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    14a2:	03 f8                	add    di,ax
    14a4:	26 8a 85 23 01       	mov    al,BYTE PTR es:[di+0x123]
    14a9:	88 46 c9             	mov    BYTE PTR [bp-0x37],al
    14ac:	8a 46 c9             	mov    al,BYTE PTR [bp-0x37]
    14af:	f6 d0                	not    al
    14b1:	8a c8                	mov    cl,al
    14b3:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    14b6:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    14b9:	bf a7 12             	mov    di,0x12a7
    14bc:	9a 16 04 d6 14       	call   0x14d6:0x416
    14c1:	8b f8                	mov    di,ax
    14c3:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
    14c6:	32 c1                	xor    al,cl
    14c8:	8a c8                	mov    cl,al
    14ca:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    14cd:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    14d0:	bf a7 12             	mov    di,0x12a7
    14d3:	9a 16 04 38 15       	call   0x1538:0x416
    14d8:	8b f8                	mov    di,ax
    14da:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
    14dd:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    14e0:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    14e3:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    14e6:	74 03                	je     0x14eb
    14e8:	e9 38 ff             	jmp    0x1423
    14eb:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    14ee:	74 03                	je     0x14f3
    14f0:	e9 30 ff             	jmp    0x1423
    14f3:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    14f6:	26 8a 85 23 06       	mov    al,BYTE PTR es:[di+0x623]
    14fb:	30 e4                	xor    ah,ah
    14fd:	31 d2                	xor    dx,dx
    14ff:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    1502:	89 56 c2             	mov    WORD PTR [bp-0x3e],dx
    1505:	b8 01 00             	mov    ax,0x1
    1508:	31 d2                	xor    dx,dx
    150a:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    150d:	7e 03                	jle    0x1512
    150f:	e9 dc 00             	jmp    0x15ee
    1512:	7c 08                	jl     0x151c
    1514:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    1517:	76 03                	jbe    0x151c
    1519:	e9 d2 00             	jmp    0x15ee
    151c:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    151f:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    1522:	eb 08                	jmp    0x152c
    1524:	83 46 d6 01          	add    WORD PTR [bp-0x2a],0x1
    1528:	83 56 d8 00          	adc    WORD PTR [bp-0x28],0x0
    152c:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    152f:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1532:	bf 9f 12             	mov    di,0x129f
    1535:	9a 16 04 60 15       	call   0x1560:0x416
    153a:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    153d:	03 f8                	add    di,ax
    153f:	26 80 bd 23 06 20    	cmp    BYTE PTR es:[di+0x623],0x20
    1545:	75 03                	jne    0x154a
    1547:	e9 8e 00             	jmp    0x15d8
    154a:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    154e:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    1552:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1555:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1558:	b9 04 00             	mov    cx,0x4
    155b:	31 db                	xor    bx,bx
    155d:	9a 70 16 71 15       	call   0x1571:0x1670
    1562:	89 c8                	mov    ax,cx
    1564:	89 da                	mov    dx,bx
    1566:	05 01 00             	add    ax,0x1
    1569:	83 d2 00             	adc    dx,0x0
    156c:	71 05                	jno    0x1573
    156e:	9a 3e 04 85 15       	call   0x1585:0x43e
    1573:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    1576:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    1579:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    157c:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    157f:	bf a7 12             	mov    di,0x12a7
    1582:	9a 16 04 9e 15       	call   0x159e:0x416
    1587:	8b f8                	mov    di,ax
    1589:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
    158c:	32 46 e9             	xor    al,BYTE PTR [bp-0x17]
    158f:	88 46 e9             	mov    BYTE PTR [bp-0x17],al
    1592:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    1595:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1598:	bf 9f 12             	mov    di,0x129f
    159b:	9a 16 04 b9 15       	call   0x15b9:0x416
    15a0:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    15a3:	03 f8                	add    di,ax
    15a5:	26 8a 85 23 06       	mov    al,BYTE PTR es:[di+0x623]
    15aa:	88 46 c9             	mov    BYTE PTR [bp-0x37],al
    15ad:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    15b0:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    15b3:	bf a7 12             	mov    di,0x12a7
    15b6:	9a 16 04 d1 15       	call   0x15d1:0x416
    15bb:	8b f8                	mov    di,ax
    15bd:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
    15c0:	32 46 c9             	xor    al,BYTE PTR [bp-0x37]
    15c3:	8a c8                	mov    cl,al
    15c5:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    15c8:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    15cb:	bf a7 12             	mov    di,0x12a7
    15ce:	9a 16 04 0e 16       	call   0x160e:0x416
    15d3:	8b f8                	mov    di,ax
    15d5:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
    15d8:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    15db:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    15de:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    15e1:	74 03                	je     0x15e6
    15e3:	e9 3e ff             	jmp    0x1524
    15e6:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    15e9:	74 03                	je     0x15ee
    15eb:	e9 36 ff             	jmp    0x1524
    15ee:	c7 46 d2 01 00       	mov    WORD PTR [bp-0x2e],0x1
    15f3:	c7 46 d4 00 00       	mov    WORD PTR [bp-0x2c],0x0
    15f8:	eb 08                	jmp    0x1602
    15fa:	83 46 d2 01          	add    WORD PTR [bp-0x2e],0x1
    15fe:	83 56 d4 00          	adc    WORD PTR [bp-0x2c],0x0
    1602:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1605:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1608:	bf a7 12             	mov    di,0x12a7
    160b:	9a 16 04 5a 16       	call   0x165a:0x416
    1610:	c1 e0 08             	shl    ax,0x8
    1613:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    1616:	03 f8                	add    di,ax
    1618:	26 8a 85 23 01       	mov    al,BYTE PTR es:[di+0x123]
    161d:	30 e4                	xor    ah,ah
    161f:	31 d2                	xor    dx,dx
    1621:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    1624:	89 56 c2             	mov    WORD PTR [bp-0x3e],dx
    1627:	b8 01 00             	mov    ax,0x1
    162a:	31 d2                	xor    dx,dx
    162c:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    162f:	7e 03                	jle    0x1634
    1631:	e9 44 01             	jmp    0x1778
    1634:	7c 08                	jl     0x163e
    1636:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    1639:	76 03                	jbe    0x163e
    163b:	e9 3a 01             	jmp    0x1778
    163e:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    1641:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    1644:	eb 08                	jmp    0x164e
    1646:	83 46 d6 01          	add    WORD PTR [bp-0x2a],0x1
    164a:	83 56 d8 00          	adc    WORD PTR [bp-0x28],0x0
    164e:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    1651:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1654:	bf 9f 12             	mov    di,0x129f
    1657:	9a 16 04 6a 16       	call   0x166a:0x416
    165c:	8b c8                	mov    cx,ax
    165e:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1661:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1664:	bf a7 12             	mov    di,0x12a7
    1667:	9a 16 04 97 16       	call   0x1697:0x416
    166c:	c1 e0 08             	shl    ax,0x8
    166f:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    1672:	03 f8                	add    di,ax
    1674:	03 f9                	add    di,cx
    1676:	26 80 bd 23 01 20    	cmp    BYTE PTR es:[di+0x123],0x20
    167c:	75 03                	jne    0x1681
    167e:	e9 e1 00             	jmp    0x1762
    1681:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    1685:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    1689:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    168c:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    168f:	b9 04 00             	mov    cx,0x4
    1692:	31 db                	xor    bx,bx
    1694:	9a 70 16 a8 16       	call   0x16a8:0x1670
    1699:	89 c8                	mov    ax,cx
    169b:	89 da                	mov    dx,bx
    169d:	05 01 00             	add    ax,0x1
    16a0:	83 d2 00             	adc    dx,0x0
    16a3:	71 05                	jno    0x16aa
    16a5:	9a 3e 04 bc 16       	call   0x16bc:0x43e
    16aa:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    16ad:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    16b0:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    16b3:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    16b6:	bf a7 12             	mov    di,0x12a7
    16b9:	9a 16 04 d4 16       	call   0x16d4:0x416
    16be:	8b f8                	mov    di,ax
    16c0:	8a 4b f7             	mov    cl,BYTE PTR [bp+di-0x9]
    16c3:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    16c6:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    16c9:	05 02 00             	add    ax,0x2
    16cc:	83 d2 00             	adc    dx,0x0
    16cf:	71 05                	jno    0x16d6
    16d1:	9a 3e 04 dc 16       	call   0x16dc:0x43e
    16d6:	bf 97 12             	mov    di,0x1297
    16d9:	9a 16 04 f8 16       	call   0x16f8:0x416
    16de:	8b f8                	mov    di,ax
    16e0:	8a 43 e7             	mov    al,BYTE PTR [bp+di-0x19]
    16e3:	32 c1                	xor    al,cl
    16e5:	8a c8                	mov    cl,al
    16e7:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    16ea:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    16ed:	05 02 00             	add    ax,0x2
    16f0:	83 d2 00             	adc    dx,0x0
    16f3:	71 05                	jno    0x16fa
    16f5:	9a 3e 04 00 17       	call   0x1700:0x43e
    16fa:	bf 97 12             	mov    di,0x1297
    16fd:	9a 16 04 13 17       	call   0x1713:0x416
    1702:	8b f8                	mov    di,ax
    1704:	88 4b e7             	mov    BYTE PTR [bp+di-0x19],cl
    1707:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    170a:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    170d:	bf 9f 12             	mov    di,0x129f
    1710:	9a 16 04 23 17       	call   0x1723:0x416
    1715:	8b c8                	mov    cx,ax
    1717:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    171a:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    171d:	bf a7 12             	mov    di,0x12a7
    1720:	9a 16 04 43 17       	call   0x1743:0x416
    1725:	c1 e0 08             	shl    ax,0x8
    1728:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    172b:	03 f8                	add    di,ax
    172d:	03 f9                	add    di,cx
    172f:	26 8a 85 23 01       	mov    al,BYTE PTR es:[di+0x123]
    1734:	88 46 c9             	mov    BYTE PTR [bp-0x37],al
    1737:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    173a:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    173d:	bf a7 12             	mov    di,0x12a7
    1740:	9a 16 04 5b 17       	call   0x175b:0x416
    1745:	8b f8                	mov    di,ax
    1747:	8a 43 f7             	mov    al,BYTE PTR [bp+di-0x9]
    174a:	32 46 c9             	xor    al,BYTE PTR [bp-0x37]
    174d:	8a c8                	mov    cl,al
    174f:	8b 46 ce             	mov    ax,WORD PTR [bp-0x32]
    1752:	8b 56 d0             	mov    dx,WORD PTR [bp-0x30]
    1755:	bf a7 12             	mov    di,0x12a7
    1758:	9a 16 04 99 17       	call   0x1799:0x416
    175d:	8b f8                	mov    di,ax
    175f:	88 4b f7             	mov    BYTE PTR [bp+di-0x9],cl
    1762:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    1765:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1768:	3b 56 c2             	cmp    dx,WORD PTR [bp-0x3e]
    176b:	74 03                	je     0x1770
    176d:	e9 d6 fe             	jmp    0x1646
    1770:	3b 46 c0             	cmp    ax,WORD PTR [bp-0x40]
    1773:	74 03                	je     0x1778
    1775:	e9 ce fe             	jmp    0x1646
    1778:	83 7e d4 00          	cmp    WORD PTR [bp-0x2c],0x0
    177c:	74 03                	je     0x1781
    177e:	e9 79 fe             	jmp    0x15fa
    1781:	83 7e d2 04          	cmp    WORD PTR [bp-0x2e],0x4
    1785:	74 03                	je     0x178a
    1787:	e9 70 fe             	jmp    0x15fa
    178a:	8d 7e e8             	lea    di,[bp-0x18]
    178d:	16                   	push   ss
    178e:	57                   	push   di
    178f:	8d 7e ee             	lea    di,[bp-0x12]
    1792:	16                   	push   ss
    1793:	57                   	push   di
    1794:	6a 06                	push   0x6
    1796:	9a 1b 16 b3 17       	call   0x17b3:0x161b
    179b:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    179e:	8b 5e f0             	mov    bx,WORD PTR [bp-0x10]
    17a1:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    17a4:	52                   	push   dx
    17a5:	53                   	push   bx
    17a6:	50                   	push   ax
    17a7:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    17aa:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    17ad:	bf 87 12             	mov    di,0x1287
    17b0:	9a 16 04 0b 18       	call   0x180b:0x416
    17b5:	8b f8                	mov    di,ax
    17b7:	d1 e7                	shl    di,1
    17b9:	8b f7                	mov    si,di
    17bb:	d1 e7                	shl    di,1
    17bd:	01 f7                	add    di,si
    17bf:	58                   	pop    ax
    17c0:	5b                   	pop    bx
    17c1:	5a                   	pop    dx
    17c2:	89 85 94 29          	mov    WORD PTR [di+0x2994],ax
    17c6:	89 9d 96 29          	mov    WORD PTR [di+0x2996],bx
    17ca:	89 95 98 29          	mov    WORD PTR [di+0x2998],dx
    17ce:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    17d2:	74 03                	je     0x17d7
    17d4:	e9 0e fb             	jmp    0x12e5
    17d7:	83 7e da 31          	cmp    WORD PTR [bp-0x26],0x31
    17db:	74 03                	je     0x17e0
    17dd:	e9 05 fb             	jmp    0x12e5
    17e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e3:	89 7e c4             	mov    WORD PTR [bp-0x3c],di
    17e6:	8c 46 c6             	mov    WORD PTR [bp-0x3a],es
    17e9:	c7 46 d2 01 00       	mov    WORD PTR [bp-0x2e],0x1
    17ee:	c7 46 d4 00 00       	mov    WORD PTR [bp-0x2c],0x0
    17f3:	eb 08                	jmp    0x17fd
    17f5:	83 46 d2 01          	add    WORD PTR [bp-0x2e],0x1
    17f9:	83 56 d4 00          	adc    WORD PTR [bp-0x2c],0x0
    17fd:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1800:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1803:	b9 02 00             	mov    cx,0x2
    1806:	31 db                	xor    bx,bx
    1808:	9a 5c 17 18 18       	call   0x1818:0x175c
    180d:	2d 01 00             	sub    ax,0x1
    1810:	83 da 00             	sbb    dx,0x0
    1813:	71 05                	jno    0x181a
    1815:	9a 3e 04 20 18       	call   0x1820:0x43e
    181a:	bf 8f 12             	mov    di,0x128f
    181d:	9a 16 04 3b 18       	call   0x183b:0x416
    1822:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    1825:	03 f8                	add    di,ax
    1827:	26 80 bd 2d 07 01    	cmp    BYTE PTR es:[di+0x72d],0x1
    182d:	75 16                	jne    0x1845
    182f:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1832:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    1835:	bf 97 12             	mov    di,0x1297
    1838:	9a 16 04 53 18       	call   0x1853:0x416
    183d:	8b f8                	mov    di,ax
    183f:	c6 43 e7 00          	mov    BYTE PTR [bp+di-0x19],0x0
    1843:	eb 35                	jmp    0x187a
    1845:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    1848:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    184b:	b9 02 00             	mov    cx,0x2
    184e:	31 db                	xor    bx,bx
    1850:	9a 5c 17 5b 18       	call   0x185b:0x175c
    1855:	bf 8f 12             	mov    di,0x128f
    1858:	9a 16 04 73 18       	call   0x1873:0x416
    185d:	c4 7e c4             	les    di,DWORD PTR [bp-0x3c]
    1860:	03 f8                	add    di,ax
    1862:	26 8a 8d 2d 07       	mov    cl,BYTE PTR es:[di+0x72d]
    1867:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    186a:	8b 56 d4             	mov    dx,WORD PTR [bp-0x2c]
    186d:	bf 97 12             	mov    di,0x1297
    1870:	9a 16 04 9b 18       	call   0x189b:0x416
    1875:	8b f8                	mov    di,ax
    1877:	88 4b e7             	mov    BYTE PTR [bp+di-0x19],cl
    187a:	83 7e d4 00          	cmp    WORD PTR [bp-0x2c],0x0
    187e:	74 03                	je     0x1883
    1880:	e9 72 ff             	jmp    0x17f5
    1883:	83 7e d2 06          	cmp    WORD PTR [bp-0x2e],0x6
    1887:	74 03                	je     0x188c
    1889:	e9 69 ff             	jmp    0x17f5
    188c:	8d 7e e8             	lea    di,[bp-0x18]
    188f:	16                   	push   ss
    1890:	57                   	push   di
    1891:	8d 7e ee             	lea    di,[bp-0x12]
    1894:	16                   	push   ss
    1895:	57                   	push   di
    1896:	6a 06                	push   0x6
    1898:	9a 1b 16 e1 18       	call   0x18e1:0x161b
    189d:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    18a0:	8b 5e f0             	mov    bx,WORD PTR [bp-0x10]
    18a3:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    18a6:	a3 94 29             	mov    ds:0x2994,ax
    18a9:	89 1e 96 29          	mov    WORD PTR ds:0x2996,bx
    18ad:	89 16 98 29          	mov    WORD PTR ds:0x2998,dx
    18b1:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    18b4:	8b 56 e6             	mov    dx,WORD PTR [bp-0x1a]
    18b7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    18ba:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    18bd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    18c0:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    18c3:	c9                   	leave
    18c4:	ca 04 00             	retf   0x4
    18c7:	26 1a 03             	sbb    al,BYTE PTR es:[bp+di]
    18ca:	1a a2 19 8e          	sbb    ah,BYTE PTR [bp+si-0x71e7]
    18ce:	19 7b 19             	sbb    WORD PTR [bp+di+0x19],di
    18d1:	9a 01 4d 0e 40       	call   0x400e:0x4d01
    18d6:	1a fa                	sbb    bh,dl
    18d8:	45                   	inc    bp
    18d9:	4d                   	dec    bp
    18da:	19 9a 1f 4f          	sbb    WORD PTR [bp+si+0x4f1f],bx
    18de:	1a cb                	sbb    cl,bl
    18e0:	1f                   	pop    ds
    18e1:	dd 18                	fstp   QWORD PTR [bx+si]
    18e3:	aa                   	stos   BYTE PTR es:[di],al
    18e4:	94                   	xchg   sp,ax
    18e5:	75 19                	jne    0x1900
    18e7:	cd 11                	int    0x11
    18e9:	f1                   	int1
    18ea:	18 8d 27 65          	sbb    BYTE PTR [di+0x6527],cl
    18ee:	19 fa                	sbb    dx,di
    18f0:	10 d3                	adc    bl,dl
    18f2:	1a d6                	sbb    dl,dh
    18f4:	14 fd                	adc    al,0xfd
    18f6:	18 f4                	sbb    ah,dh
    18f8:	4f                   	dec    di
    18f9:	09 19                	or     WORD PTR [bx+di],bx
    18fb:	32 16 25 19          	xor    dl,BYTE PTR ds:0x1925
    18ff:	ec                   	in     al,dx
    1900:	30 5d 19             	xor    BYTE PTR [di+0x19],bl
    1903:	51                   	push   cx
    1904:	1b 37                	sbb    si,WORD PTR [bx]
    1906:	1e                   	push   ds
    1907:	38 50 11             	cmp    BYTE PTR [bx+si+0x11],dl
    190a:	19 63 31             	sbb    WORD PTR [bp+di+0x31],sp
    190d:	2d 19 21             	sub    ax,0x2119
    1910:	50                   	push   ax
    1911:	e9 18 4b             	jmp    0x642c
    1914:	94                   	xchg   sp,ax
    1915:	e5 18                	in     ax,0x18
    1917:	d9 62 1d             	fldenv [bp+si+0x1d]
    191a:	19 06 63 21          	sbb    WORD PTR ds:0x2163,ax
    191e:	19 8f 60 01          	sbb    WORD PTR [bx+0x160],cx
    1922:	19 3a                	sbb    WORD PTR [bp+si],di
    1924:	1c 05                	sbb    al,0x5
    1926:	19 46 44             	sbb    WORD PTR [bp+0x44],ax
    1929:	0d 19 08             	or     ax,0x819
    192c:	61                   	popa
    192d:	31 19                	xor    WORD PTR [bx+di],bx
    192f:	5c                   	pop    sp
    1930:	61                   	popa
    1931:	35 19 62             	xor    ax,0x6219
    1934:	5c                   	pop    sp
    1935:	61                   	popa
    1936:	19 3a                	sbb    WORD PTR [bp+si],di
    1938:	61                   	popa
    1939:	f5                   	cmc
    193a:	18 72 3f             	sbb    BYTE PTR [bp+si+0x3f],dh
    193d:	45                   	inc    bp
    193e:	19 dc                	sbb    sp,bx
    1940:	5c                   	pop    sp
    1941:	6d                   	ins    WORD PTR es:[di],dx
    1942:	19 17                	sbb    WORD PTR [bx],dx
    1944:	3e 49                	ds dec cx
    1946:	19 88 3c d9          	sbb    WORD PTR [bx+si-0x26c4],cx
    194a:	18 ed                	sbb    ch,ch
    194c:	3e 51                	ds push cx
    194e:	19 77 3e             	sbb    WORD PTR [bx+0x3e],si
    1951:	55                   	push   bp
    1952:	19 c2                	sbb    dx,ax
    1954:	35 19 19             	xor    ax,0x1919
    1957:	26 6d                	es ins WORD PTR es:[di],dx
    1959:	3d 19 ae             	cmp    ax,0xae19
    195c:	5f                   	pop    di
    195d:	29 19                	sub    WORD PTR [bx+di],bx
    195f:	35 62 39             	xor    ax,0x3962
    1962:	19 ec                	sbb    sp,bp
    1964:	2e d5 18             	cs aad 0x18
    1967:	b2 5c                	mov    dl,0x5c
    1969:	41                   	inc    cx
    196a:	19 93 24 ed          	sbb    WORD PTR [bp+di-0x12dc],dx
    196e:	18 be 33 79          	sbb    BYTE PTR [bp+0x7933],bh
    1972:	19 a1 80 69          	sbb    WORD PTR [bx+di+0x6980],sp
    1976:	19 5c 38             	sbb    WORD PTR [si+0x38],bx
    1979:	98                   	cbw
    197a:	19 12                	sbb    WORD PTR [bp+si],dx
    197c:	54                   	push   sp
    197d:	53                   	push   bx
    197e:	70 65                	jo     0x19e5
    1980:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1983:	6c                   	ins    BYTE PTR es:[di],dx
    1984:	53                   	push   bx
    1985:	74 72                	je     0x19f9
    1987:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
    198c:	69 64 03 00 f1       	imul   sp,WORD PTR [si+0x3],0xf100
    1991:	ff f0                	push   ax
    1993:	ff                   	call   (bad)
    1994:	df ff                	(bad)
    1996:	d8 34                	fdiv   DWORD PTR [si]
    1998:	9c                   	pushf
    1999:	19 15                	sbb    WORD PTR [di],dx
    199b:	38 a0 19 a4          	cmp    BYTE PTR [bx+si-0x5be7],ah
    199f:	38 a6 19 06          	cmp    BYTE PTR [bp+0x619],ah
    19a3:	00 d8                	add    al,bl
    19a5:	34 b2                	xor    al,0xb2
    19a7:	19 07                	sbb    WORD PTR [bx],ax
    19a9:	4b                   	dec    bx
    19aa:	65 79 44             	gs jns 0x19f1
    19ad:	6f                   	outs   dx,WORD PTR ds:[si]
    19ae:	77 6e                	ja     0x1a1e
    19b0:	15 38 bc             	adc    ax,0xbc38
    19b3:	19 05                	sbb    WORD PTR [di],ax
    19b5:	4b                   	dec    bx
    19b6:	65 79 55             	gs jns 0x1a0e
    19b9:	70 5c                	jo     0x1a17
    19bb:	38 cb                	cmp    bl,cl
    19bd:	19 0a                	sbb    WORD PTR [bp+si],cx
    19bf:	53                   	push   bx
    19c0:	65 6c                	gs ins BYTE PTR es:[di],dx
    19c2:	65 63 74 43          	arpl   WORD PTR gs:[si+0x43],si
    19c6:	65 6c                	gs ins BYTE PTR es:[di],dx
    19c8:	6c                   	ins    BYTE PTR es:[di],dx
    19c9:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    19ca:	38 de                	cmp    dh,bl
    19cc:	19 0e 54 6f          	sbb    WORD PTR ds:0x6f54,cx
    19d0:	70 4c                	jo     0x1a1e
    19d2:	65 66 74 43          	gs data32 je 0x1a19
    19d6:	68 61 6e             	push   0x6e61
    19d9:	67 65 64 fd          	addr32 gs fs std
    19dd:	1a f0                	sbb    dh,al
    19df:	19 0d                	sbb    WORD PTR [di],cx
    19e1:	53                   	push   bx
    19e2:	70 65                	jo     0x1a49
    19e4:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    19e7:	6c                   	ins    BYTE PTR es:[di],dx
    19e8:	52                   	push   dx
    19e9:	65 73 69             	gs jae 0x1a55
    19ec:	7a 65                	jp     0x1a53
    19ee:	2b 1f                	sub    bx,WORD PTR [bx]
    19f0:	3c 1a                	cmp    al,0x1a
    19f2:	10 41 75             	adc    BYTE PTR [bx+di+0x75],al
    19f5:	74 6f                	je     0x1a66
    19f7:	46                   	inc    si
    19f8:	6f                   	outs   dx,WORD PTR ds:[si]
    19f9:	72 6d                	jb     0x1a68
    19fb:	61                   	popa
    19fc:	74 53                	je     0x1a51
    19fe:	74 72                	je     0x1a72
    1a00:	69 6e 67 02 00       	imul   bp,WORD PTR [bp+0x67],0x2
    1a05:	1c 1a                	sbb    al,0x1a
    1a07:	92                   	xchg   dx,ax
    1a08:	01 00                	add    WORD PTR [bx+si],ax
    1a0a:	00 06 46 4c          	add    BYTE PTR ds:0x4c46,al
    1a0e:	6f                   	outs   dx,WORD PTR ds:[si]
    1a0f:	75 70                	jne    0x1a81
    1a11:	65 96                	gs xchg si,ax
    1a13:	01 04                	add    WORD PTR [si],ax
    1a15:	00 05                	add    BYTE PTR [di],al
    1a17:	46                   	inc    si
    1a18:	45                   	inc    bp
    1a19:	64 69 74 02 00 ad    	imul   si,WORD PTR fs:[si+0x2],0xad00
    1a1f:	0d 76 1a             	or     ax,0x1a76
    1a22:	90                   	nop
    1a23:	0b 94 1a 07          	or     dx,WORD PTR [si+0x71a]
    1a27:	12 54 53             	adc    dl,BYTE PTR [si+0x53]
    1a2a:	70 65                	jo     0x1a91
    1a2c:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1a2f:	6c                   	ins    BYTE PTR es:[di],dx
    1a30:	53                   	push   bx
    1a31:	74 72                	je     0x1aa5
    1a33:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
    1a38:	69 64 e7 18 57       	imul   sp,WORD PTR [si-0x19],0x5718
    1a3d:	1a 03                	sbb    al,BYTE PTR [bp+di]
    1a3f:	0f b3 1b             	btr    WORD PTR [bp+di],bx
    1a42:	3f                   	aas
    1a43:	00 06 53 73          	add    BYTE PTR ds:0x7353,al
    1a47:	67 72 69             	addr32 jb 0x1ab3
    1a4a:	64 05 00 07          	fs add ax,0x700
    1a4e:	23 06 1b 91          	and    ax,WORD PTR ds:0x911b
    1a52:	01 ff                	add    di,di
    1a54:	ff a8 1e 29          	jmp    DWORD PTR [bx+si+0x291e]
    1a58:	1f                   	pop    ds
    1a59:	01 00                	add    WORD PTR [bx+si],ax
    1a5b:	00 00                	add    BYTE PTR [bx+si],al
    1a5d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    1a61:	00 80 3c 00          	add    BYTE PTR [bx+si+0x3c],al
    1a65:	0e                   	push   cs
    1a66:	53                   	push   bx
    1a67:	70 65                	jo     0x1ace
    1a69:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1a6c:	6c                   	ins    BYTE PTR es:[di],dx
    1a6d:	44                   	inc    sp
    1a6e:	72 61                	jb     0x1ad1
    1a70:	77 69                	ja     0x1adb
    1a72:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a73:	67 34 0e             	addr32 xor al,0xe
    1a76:	ff                   	(bad)
    1a77:	ff 92 01 ff          	call   WORD PTR [bp+si-0xff]
    1a7b:	ff 92 01 ff          	call   WORD PTR [bp+si-0xff]
    1a7f:	ff 01                	inc    WORD PTR [bx+di]
    1a81:	00 00                	add    BYTE PTR [bx+si],al
    1a83:	00 00                	add    BYTE PTR [bx+si],al
    1a85:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1a88:	00 80 3d 00          	add    BYTE PTR [bx+si+0x3d],al
    1a8c:	05 4c 6f             	add    ax,0x6f4c
    1a8f:	75 70                	jne    0x1b01
    1a91:	65 12 0c             	adc    cl,BYTE PTR gs:[si]
    1a94:	ff                   	(bad)
    1a95:	ff 96 01 ff          	call   WORD PTR [bp-0xff]
    1a99:	ff 96 01 ff          	call   WORD PTR [bp-0xff]
    1a9d:	ff 01                	inc    WORD PTR [bx+di]
    1a9f:	00 00                	add    BYTE PTR [bx+si],al
    1aa1:	00 00                	add    BYTE PTR [bx+si],al
    1aa3:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1aa6:	00 80 3e 00          	add    BYTE PTR [bx+si+0x3e],al
    1aaa:	04 45                	add    al,0x45
    1aac:	64 69 74 0d 04 ff    	imul   si,WORD PTR fs:[si+0xd],0xff04
    1ab2:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    1ab5:	ff                   	(bad)
    1ab6:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    1ab9:	ff                   	(bad)
    1aba:	ff 01                	inc    WORD PTR [bx+di]
    1abc:	00 00                	add    BYTE PTR [bx+si],al
    1abe:	00 00                	add    BYTE PTR [bx+si],al
    1ac0:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1ac3:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    1ac7:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    1aca:	70 55                	jo     0x1b21
    1acc:	70 4d                	jo     0x1b1b
    1ace:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1ad0:	75 5a                	jne    0x1b2c
    1ad2:	00 ff                	add    bh,bh
    1ad4:	ff ac 00 ff          	jmp    DWORD PTR [si-0x100]
    1ad8:	ff ac 00 ff          	jmp    DWORD PTR [si-0x100]
    1adc:	ff 01                	inc    WORD PTR [bx+di]
    1ade:	00 00                	add    BYTE PTR [bx+si],al
    1ae0:	00 00                	add    BYTE PTR [bx+si],al
    1ae2:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1ae5:	00 00                	add    BYTE PTR [bx+si],al
    1ae7:	08 00                	or     BYTE PTR [bx+si],al
    1ae9:	0b 48 65             	or     cx,WORD PTR [bx+si+0x65]
    1aec:	6c                   	ins    BYTE PTR es:[di],dx
    1aed:	70 43                	jo     0x1b32
    1aef:	6f                   	outs   dx,WORD PTR ds:[si]
    1af0:	6e                   	outs   dx,BYTE PTR ds:[si]
    1af1:	74 65                	je     0x1b58
    1af3:	78 74                	js     0x1b69
    1af5:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1af9:	ff                   	(bad)
    1afa:	7f 00                	jg     0x1afc
    1afc:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1aff:	e5 b8                	in     ax,0xb8
    1b01:	28 00                	sub    BYTE PTR [bx+si],al
    1b03:	9a 44 04 5e 1b       	call   0x1b5e:0x444
    1b08:	83 ec 28             	sub    sp,0x28
    1b0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b0e:	26 80 bd e4 00 01    	cmp    BYTE PTR es:[di+0xe4],0x1
    1b14:	75 0c                	jne    0x1b22
    1b16:	c7 46 fc 02 00       	mov    WORD PTR [bp-0x4],0x2
    1b1b:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    1b20:	eb 08                	jmp    0x1b2a
    1b22:	31 c0                	xor    ax,ax
    1b24:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b27:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b2d:	26 80 bd 12 01 02    	cmp    BYTE PTR es:[di+0x112],0x2
    1b33:	b0 00                	mov    al,0x0
    1b35:	75 01                	jne    0x1b38
    1b37:	40                   	inc    ax
    1b38:	8a d0                	mov    dl,al
    1b3a:	26 80 bd 12 01 03    	cmp    BYTE PTR es:[di+0x112],0x3
    1b40:	b0 00                	mov    al,0x0
    1b42:	75 01                	jne    0x1b45
    1b44:	40                   	inc    ax
    1b45:	0a c2                	or     al,dl
    1b47:	08 c0                	or     al,al
    1b49:	74 1b                	je     0x1b66
    1b4b:	6a 02                	push   0x2
    1b4d:	9a 8c 1c 00 00       	call   0x0:0x1c8c
    1b52:	99                   	cwd
    1b53:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    1b56:	13 56 fe             	adc    dx,WORD PTR [bp-0x2]
    1b59:	71 05                	jno    0x1b60
    1b5b:	9a 3e 04 7d 1b       	call   0x1b7d:0x43e
    1b60:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b63:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1b66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b69:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1b6d:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b74:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    1b78:	71 05                	jno    0x1b7f
    1b7a:	9a 3e 04 95 1b       	call   0x1b95:0x43e
    1b7f:	99                   	cwd
    1b80:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1b83:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    1b86:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1b89:	99                   	cwd
    1b8a:	2b 46 e8             	sub    ax,WORD PTR [bp-0x18]
    1b8d:	1b 56 ea             	sbb    dx,WORD PTR [bp-0x16]
    1b90:	71 05                	jno    0x1b97
    1b92:	9a 3e 04 c1 1b       	call   0x1bc1:0x43e
    1b97:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1b9a:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    1b9d:	31 c0                	xor    ax,ax
    1b9f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1ba2:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1ba5:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1ba8:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1bab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bae:	06                   	push   es
    1baf:	57                   	push   di
    1bb0:	9a 30 6e 17 1c       	call   0x1c17:0x6e30
    1bb5:	99                   	cwd
    1bb6:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    1bb9:	13 56 fe             	adc    dx,WORD PTR [bp-0x2]
    1bbc:	71 05                	jno    0x1bc3
    1bbe:	9a 3e 04 ef 1b       	call   0x1bef:0x43e
    1bc3:	3b 56 ee             	cmp    dx,WORD PTR [bp-0x12]
    1bc6:	7c 0b                	jl     0x1bd3
    1bc8:	7f 05                	jg     0x1bcf
    1bca:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    1bcd:	76 04                	jbe    0x1bd3
    1bcf:	b0 00                	mov    al,0x0
    1bd1:	eb 02                	jmp    0x1bd5
    1bd3:	b0 01                	mov    al,0x1
    1bd5:	8a c8                	mov    cl,al
    1bd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bda:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1bdf:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1be4:	2d 01 00             	sub    ax,0x1
    1be7:	83 da 00             	sbb    dx,0x0
    1bea:	71 05                	jno    0x1bf1
    1bec:	9a 3e 04 25 1c       	call   0x1c25:0x43e
    1bf1:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    1bf4:	7f 0b                	jg     0x1c01
    1bf6:	7c 05                	jl     0x1bfd
    1bf8:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1bfb:	73 04                	jae    0x1c01
    1bfd:	b0 00                	mov    al,0x0
    1bff:	eb 02                	jmp    0x1c03
    1c01:	b0 01                	mov    al,0x1
    1c03:	22 c1                	and    al,cl
    1c05:	08 c0                	or     al,al
    1c07:	74 2f                	je     0x1c38
    1c09:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1c0c:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1c0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c12:	06                   	push   es
    1c13:	57                   	push   di
    1c14:	9a 30 6e f1 1c       	call   0x1cf1:0x6e30
    1c19:	99                   	cwd
    1c1a:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    1c1d:	13 56 fe             	adc    dx,WORD PTR [bp-0x2]
    1c20:	71 05                	jno    0x1c27
    1c22:	9a 3e 04 44 1c       	call   0x1c44:0x43e
    1c27:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c2a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c2d:	83 46 f4 01          	add    WORD PTR [bp-0xc],0x1
    1c31:	83 56 f6 00          	adc    WORD PTR [bp-0xa],0x0
    1c35:	e9 6d ff             	jmp    0x1ba5
    1c38:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1c3b:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1c3e:	bf f5 1a             	mov    di,0x1af5
    1c41:	9a 16 04 9c 1c       	call   0x1c9c:0x416
    1c46:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    1c49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c4c:	26 80 bd e4 00 01    	cmp    BYTE PTR es:[di+0xe4],0x1
    1c52:	75 0c                	jne    0x1c60
    1c54:	c7 46 f8 02 00       	mov    WORD PTR [bp-0x8],0x2
    1c59:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    1c5e:	eb 08                	jmp    0x1c68
    1c60:	31 c0                	xor    ax,ax
    1c62:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1c65:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1c68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c6b:	26 80 bd 12 01 01    	cmp    BYTE PTR es:[di+0x112],0x1
    1c71:	b0 00                	mov    al,0x0
    1c73:	75 01                	jne    0x1c76
    1c75:	40                   	inc    ax
    1c76:	8a d0                	mov    dl,al
    1c78:	26 80 bd 12 01 03    	cmp    BYTE PTR es:[di+0x112],0x3
    1c7e:	b0 00                	mov    al,0x0
    1c80:	75 01                	jne    0x1c83
    1c82:	40                   	inc    ax
    1c83:	0a c2                	or     al,dl
    1c85:	08 c0                	or     al,al
    1c87:	74 1b                	je     0x1ca4
    1c89:	6a 03                	push   0x3
    1c8b:	9a a9 1d 00 00       	call   0x0:0x1da9
    1c90:	99                   	cwd
    1c91:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    1c94:	13 56 fa             	adc    dx,WORD PTR [bp-0x6]
    1c97:	71 05                	jno    0x1c9e
    1c99:	9a 3e 04 bb 1c       	call   0x1cbb:0x43e
    1c9e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1ca1:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1ca4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1cab:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb2:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    1cb6:	71 05                	jno    0x1cbd
    1cb8:	9a 3e 04 d3 1c       	call   0x1cd3:0x43e
    1cbd:	99                   	cwd
    1cbe:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    1cc1:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    1cc4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1cc7:	99                   	cwd
    1cc8:	2b 46 e0             	sub    ax,WORD PTR [bp-0x20]
    1ccb:	1b 56 e2             	sbb    dx,WORD PTR [bp-0x1e]
    1cce:	71 05                	jno    0x1cd5
    1cd0:	9a 3e 04 ff 1c       	call   0x1cff:0x43e
    1cd5:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    1cd8:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    1cdb:	31 c0                	xor    ax,ax
    1cdd:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1ce0:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1ce3:	ff 76 f2             	push   WORD PTR [bp-0xe]
    1ce6:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1ce9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cec:	06                   	push   es
    1ced:	57                   	push   di
    1cee:	9a 8b 6e 55 1d       	call   0x1d55:0x6e8b
    1cf3:	99                   	cwd
    1cf4:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    1cf7:	13 56 fa             	adc    dx,WORD PTR [bp-0x6]
    1cfa:	71 05                	jno    0x1d01
    1cfc:	9a 3e 04 2d 1d       	call   0x1d2d:0x43e
    1d01:	3b 56 e6             	cmp    dx,WORD PTR [bp-0x1a]
    1d04:	7c 0b                	jl     0x1d11
    1d06:	7f 05                	jg     0x1d0d
    1d08:	3b 46 e4             	cmp    ax,WORD PTR [bp-0x1c]
    1d0b:	76 04                	jbe    0x1d11
    1d0d:	b0 00                	mov    al,0x0
    1d0f:	eb 02                	jmp    0x1d13
    1d11:	b0 01                	mov    al,0x1
    1d13:	8a c8                	mov    cl,al
    1d15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d18:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    1d1d:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    1d22:	2d 01 00             	sub    ax,0x1
    1d25:	83 da 00             	sbb    dx,0x0
    1d28:	71 05                	jno    0x1d2f
    1d2a:	9a 3e 04 63 1d       	call   0x1d63:0x43e
    1d2f:	3b 56 f2             	cmp    dx,WORD PTR [bp-0xe]
    1d32:	7f 0b                	jg     0x1d3f
    1d34:	7c 05                	jl     0x1d3b
    1d36:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    1d39:	73 04                	jae    0x1d3f
    1d3b:	b0 00                	mov    al,0x0
    1d3d:	eb 02                	jmp    0x1d41
    1d3f:	b0 01                	mov    al,0x1
    1d41:	22 c1                	and    al,cl
    1d43:	08 c0                	or     al,al
    1d45:	74 2f                	je     0x1d76
    1d47:	ff 76 f2             	push   WORD PTR [bp-0xe]
    1d4a:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d50:	06                   	push   es
    1d51:	57                   	push   di
    1d52:	9a 8b 6e fd 1d       	call   0x1dfd:0x6e8b
    1d57:	99                   	cwd
    1d58:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    1d5b:	13 56 fa             	adc    dx,WORD PTR [bp-0x6]
    1d5e:	71 05                	jno    0x1d65
    1d60:	9a 3e 04 82 1d       	call   0x1d82:0x43e
    1d65:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1d68:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1d6b:	83 46 f0 01          	add    WORD PTR [bp-0x10],0x1
    1d6f:	83 56 f2 00          	adc    WORD PTR [bp-0xe],0x0
    1d73:	e9 6d ff             	jmp    0x1ce3
    1d76:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1d79:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1d7c:	bf f5 1a             	mov    di,0x1af5
    1d7f:	9a 16 04 b9 1d       	call   0x1db9:0x416
    1d84:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    1d87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d8a:	26 80 bd 12 01 00    	cmp    BYTE PTR es:[di+0x112],0x0
    1d90:	74 5b                	je     0x1ded
    1d92:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1d95:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    1d98:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    1d9d:	75 1f                	jne    0x1dbe
    1d9f:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    1da4:	75 18                	jne    0x1dbe
    1da6:	6a 02                	push   0x2
    1da8:	9a d8 1d 00 00       	call   0x0:0x1dd8
    1dad:	8b d0                	mov    dx,ax
    1daf:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    1db2:	2b c2                	sub    ax,dx
    1db4:	71 05                	jno    0x1dbb
    1db6:	9a 3e 04 e8 1d       	call   0x1de8:0x43e
    1dbb:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    1dbe:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1dc1:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1dc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dc7:	26 3b 95 e8 00       	cmp    dx,WORD PTR es:[di+0xe8]
    1dcc:	75 1f                	jne    0x1ded
    1dce:	26 3b 85 e6 00       	cmp    ax,WORD PTR es:[di+0xe6]
    1dd3:	75 18                	jne    0x1ded
    1dd5:	6a 03                	push   0x3
    1dd7:	9a ff ff 00 00       	call   0x0:0xffff
    1ddc:	8b d0                	mov    dx,ax
    1dde:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    1de1:	2b c2                	sub    ax,dx
    1de3:	71 05                	jno    0x1dea
    1de5:	9a 3e 04 20 1e       	call   0x1e20:0x43e
    1dea:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    1ded:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df0:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    1df5:	99                   	cwd
    1df6:	52                   	push   dx
    1df7:	50                   	push   ax
    1df8:	06                   	push   es
    1df9:	57                   	push   di
    1dfa:	9a 45 73 0f 1e       	call   0x1e0f:0x7345
    1dff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e02:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    1e07:	99                   	cwd
    1e08:	52                   	push   dx
    1e09:	50                   	push   ax
    1e0a:	06                   	push   es
    1e0b:	57                   	push   di
    1e0c:	9a dd 75 d7 1e       	call   0x1ed7:0x75dd
    1e11:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    1e14:	99                   	cwd
    1e15:	03 46 e8             	add    ax,WORD PTR [bp-0x18]
    1e18:	13 56 ea             	adc    dx,WORD PTR [bp-0x16]
    1e1b:	71 05                	jno    0x1e22
    1e1d:	9a 3e 04 28 1e       	call   0x1e28:0x43e
    1e22:	bf f5 1a             	mov    di,0x1af5
    1e25:	9a 16 04 48 1e       	call   0x1e48:0x416
    1e2a:	50                   	push   ax
    1e2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e32:	06                   	push   es
    1e33:	57                   	push   di
    1e34:	9a bf 17 5f 1e       	call   0x1e5f:0x17bf
    1e39:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    1e3c:	99                   	cwd
    1e3d:	03 46 e0             	add    ax,WORD PTR [bp-0x20]
    1e40:	13 56 e2             	adc    dx,WORD PTR [bp-0x1e]
    1e43:	71 05                	jno    0x1e4a
    1e45:	9a 3e 04 50 1e       	call   0x1e50:0x43e
    1e4a:	bf f5 1a             	mov    di,0x1af5
    1e4d:	9a 16 04 b0 1e       	call   0x1eb0:0x416
    1e52:	50                   	push   ax
    1e53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e56:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e5a:	06                   	push   es
    1e5b:	57                   	push   di
    1e5c:	9a e1 17 88 1e       	call   0x1e88:0x17e1
    1e61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e64:	26 8b 85 98 01       	mov    ax,WORD PTR es:[di+0x198]
    1e69:	09 c0                	or     ax,ax
    1e6b:	74 1d                	je     0x1e8a
    1e6d:	26 c4 bd 96 01       	les    di,DWORD PTR es:[di+0x196]
    1e72:	89 7e d8             	mov    WORD PTR [bp-0x28],di
    1e75:	8c 46 da             	mov    WORD PTR [bp-0x26],es
    1e78:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e7c:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1e80:	c4 7e d8             	les    di,DWORD PTR [bp-0x28]
    1e83:	06                   	push   es
    1e84:	57                   	push   di
    1e85:	9a bf 17 95 1e       	call   0x1e95:0x17bf
    1e8a:	ff 76 dc             	push   WORD PTR [bp-0x24]
    1e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e90:	06                   	push   es
    1e91:	57                   	push   di
    1e92:	9a e1 17 a2 1e       	call   0x1ea2:0x17e1
    1e97:	ff 76 de             	push   WORD PTR [bp-0x22]
    1e9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e9d:	06                   	push   es
    1e9e:	57                   	push   di
    1e9f:	9a bf 17 45 26       	call   0x2645:0x17bf
    1ea4:	c9                   	leave
    1ea5:	ca 08 00             	retf   0x8
    1ea8:	55                   	push   bp
    1ea9:	89 e5                	mov    bp,sp
    1eab:	31 c0                	xor    ax,ax
    1ead:	9a 44 04 34 1f       	call   0x1f34:0x444
    1eb2:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1eb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb8:	26 88 85 91 01       	mov    BYTE PTR es:[di+0x191],al
    1ebd:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ec1:	74 16                	je     0x1ed9
    1ec3:	26 c6 85 3b 01 00    	mov    BYTE PTR es:[di+0x13b],0x0
    1ec9:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    1ece:	25 f0 ff             	and    ax,0xfff0
    1ed1:	50                   	push   ax
    1ed2:	06                   	push   es
    1ed3:	57                   	push   di
    1ed4:	9a 7d 73 40 27       	call   0x2740:0x737d
    1ed9:	c9                   	leave
    1eda:	ca 06 00             	retf   0x6
    1edd:	02 23                	add    ah,BYTE PTR [bp+di]
    1edf:	43                   	inc    bx
    1ee0:	00 00                	add    BYTE PTR [bx+si],al
    1ee2:	00 00                	add    BYTE PTR [bx+si],al
    1ee4:	ff 00                	inc    WORD PTR [bx+si]
    1ee6:	00 00                	add    BYTE PTR [bx+si],al
    1ee8:	02 23                	add    ah,BYTE PTR [bp+di]
    1eea:	41                   	inc    cx
    1eeb:	02 23                	add    ah,BYTE PTR [bp+di]
    1eed:	56                   	push   si
    1eee:	02 23                	add    ah,BYTE PTR [bp+di]
    1ef0:	48                   	dec    ax
    1ef1:	01 20                	add    WORD PTR [bx+si],sp
    1ef3:	01 2c                	add    WORD PTR [si],bp
    1ef5:	0a 23                	or     ah,BYTE PTR [bp+di]
    1ef7:	2c 23                	sub    al,0x23
    1ef9:	23 30                	and    si,WORD PTR [bx+si]
    1efb:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1efe:	23 23                	and    sp,WORD PTR [bp+di]
    1f00:	05 23 2c             	add    ax,0x2c23
    1f03:	23 23                	and    sp,WORD PTR [bp+di]
    1f05:	30 07                	xor    BYTE PTR [bx],al
    1f07:	23 30                	and    si,WORD PTR [bx+si]
    1f09:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1f0c:	23 23                	and    sp,WORD PTR [bp+di]
    1f0e:	02 23                	add    ah,BYTE PTR [bp+di]
    1f10:	30 0c                	xor    BYTE PTR [si],cl
    1f12:	23 23                	and    sp,WORD PTR [bp+di]
    1f14:	23 23                	and    sp,WORD PTR [bp+di]
    1f16:	23 23                	and    sp,WORD PTR [bp+di]
    1f18:	23 23                	and    sp,WORD PTR [bp+di]
    1f1a:	23 23                	and    sp,WORD PTR [bp+di]
    1f1c:	23 23                	and    sp,WORD PTR [bp+di]
    1f1e:	03 23                	add    sp,WORD PTR [bp+di]
    1f20:	2e 30 02             	xor    BYTE PTR cs:[bp+si],al
    1f23:	45                   	inc    bp
    1f24:	2b 00                	sub    ax,WORD PTR [bx+si]
    1f26:	00 cf                	add    bh,cl
    1f28:	23 9a 29 55          	and    bx,WORD PTR [bp+si+0x5529]
    1f2c:	89 e5                	mov    bp,sp
    1f2e:	b8 18 05             	mov    ax,0x518
    1f31:	9a 44 04 4b 1f       	call   0x1f4b:0x444
    1f36:	81 ec 18 05          	sub    sp,0x518
    1f3a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1f3d:	06                   	push   es
    1f3e:	57                   	push   di
    1f3f:	8d be f2 fc          	lea    di,[bp-0x30e]
    1f43:	16                   	push   ss
    1f44:	57                   	push   di
    1f45:	68 ff 00             	push   0xff
    1f48:	9a e7 17 6e 1f       	call   0x1f6e:0x17e7
    1f4d:	c7 86 ee fb 01 00    	mov    WORD PTR [bp-0x412],0x1
    1f53:	c7 86 f0 fb 00 00    	mov    WORD PTR [bp-0x410],0x0
    1f59:	80 be f2 fc 02       	cmp    BYTE PTR [bp-0x30e],0x2
    1f5e:	76 5e                	jbe    0x1fbe
    1f60:	bf dd 1e             	mov    di,0x1edd
    1f63:	0e                   	push   cs
    1f64:	57                   	push   di
    1f65:	8d be f2 fc          	lea    di,[bp-0x30e]
    1f69:	16                   	push   ss
    1f6a:	57                   	push   di
    1f6b:	9a 78 18 87 1f       	call   0x1f87:0x1878
    1f70:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    1f74:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    1f79:	7e 43                	jle    0x1fbe
    1f7b:	8b 86 e8 fb          	mov    ax,WORD PTR [bp-0x418]
    1f7f:	05 02 00             	add    ax,0x2
    1f82:	71 05                	jno    0x1f89
    1f84:	9a 3e 04 90 1f       	call   0x1f90:0x43e
    1f89:	99                   	cwd
    1f8a:	bf e0 1e             	mov    di,0x1ee0
    1f8d:	9a 16 04 a2 1f       	call   0x1fa2:0x416
    1f92:	8b f8                	mov    di,ax
    1f94:	8a 83 f2 fc          	mov    al,BYTE PTR [bp+di-0x30e]
    1f98:	30 e4                	xor    ah,ah
    1f9a:	2d 30 00             	sub    ax,0x30
    1f9d:	71 05                	jno    0x1fa4
    1f9f:	9a 3e 04 bc 1f       	call   0x1fbc:0x43e
    1fa4:	99                   	cwd
    1fa5:	89 86 ee fb          	mov    WORD PTR [bp-0x412],ax
    1fa9:	89 96 f0 fb          	mov    WORD PTR [bp-0x410],dx
    1fad:	8d be f2 fc          	lea    di,[bp-0x30e]
    1fb1:	16                   	push   ss
    1fb2:	57                   	push   di
    1fb3:	ff b6 e8 fb          	push   WORD PTR [bp-0x418]
    1fb7:	6a 03                	push   0x3
    1fb9:	9a 75 19 d8 1f       	call   0x1fd8:0x1975
    1fbe:	c6 86 ed fb 67       	mov    BYTE PTR [bp-0x413],0x67
    1fc3:	80 be f2 fc 02       	cmp    BYTE PTR [bp-0x30e],0x2
    1fc8:	76 4d                	jbe    0x2017
    1fca:	bf e8 1e             	mov    di,0x1ee8
    1fcd:	0e                   	push   cs
    1fce:	57                   	push   di
    1fcf:	8d be f2 fc          	lea    di,[bp-0x30e]
    1fd3:	16                   	push   ss
    1fd4:	57                   	push   di
    1fd5:	9a 78 18 f1 1f       	call   0x1ff1:0x1878
    1fda:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    1fde:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    1fe3:	7e 32                	jle    0x2017
    1fe5:	8b 86 e8 fb          	mov    ax,WORD PTR [bp-0x418]
    1fe9:	05 02 00             	add    ax,0x2
    1fec:	71 05                	jno    0x1ff3
    1fee:	9a 3e 04 fa 1f       	call   0x1ffa:0x43e
    1ff3:	99                   	cwd
    1ff4:	bf e0 1e             	mov    di,0x1ee0
    1ff7:	9a 16 04 15 20       	call   0x2015:0x416
    1ffc:	8b f8                	mov    di,ax
    1ffe:	8a 83 f2 fc          	mov    al,BYTE PTR [bp+di-0x30e]
    2002:	88 86 ed fb          	mov    BYTE PTR [bp-0x413],al
    2006:	8d be f2 fc          	lea    di,[bp-0x30e]
    200a:	16                   	push   ss
    200b:	57                   	push   di
    200c:	ff b6 e8 fb          	push   WORD PTR [bp-0x418]
    2010:	6a 03                	push   0x3
    2012:	9a 75 19 31 20       	call   0x2031:0x1975
    2017:	c6 86 ec fb 00       	mov    BYTE PTR [bp-0x414],0x0
    201c:	80 be f2 fc 01       	cmp    BYTE PTR [bp-0x30e],0x1
    2021:	76 31                	jbe    0x2054
    2023:	bf eb 1e             	mov    di,0x1eeb
    2026:	0e                   	push   cs
    2027:	57                   	push   di
    2028:	8d be f2 fc          	lea    di,[bp-0x30e]
    202c:	16                   	push   ss
    202d:	57                   	push   di
    202e:	9a 78 18 52 20       	call   0x2052:0x1878
    2033:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    2037:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    203c:	7e 16                	jle    0x2054
    203e:	c6 86 ec fb 01       	mov    BYTE PTR [bp-0x414],0x1
    2043:	8d be f2 fc          	lea    di,[bp-0x30e]
    2047:	16                   	push   ss
    2048:	57                   	push   di
    2049:	ff b6 e8 fb          	push   WORD PTR [bp-0x418]
    204d:	6a 02                	push   0x2
    204f:	9a 75 19 6e 20       	call   0x206e:0x1975
    2054:	c6 86 eb fb 00       	mov    BYTE PTR [bp-0x415],0x0
    2059:	80 be f2 fc 01       	cmp    BYTE PTR [bp-0x30e],0x1
    205e:	76 31                	jbe    0x2091
    2060:	bf ee 1e             	mov    di,0x1eee
    2063:	0e                   	push   cs
    2064:	57                   	push   di
    2065:	8d be f2 fc          	lea    di,[bp-0x30e]
    2069:	16                   	push   ss
    206a:	57                   	push   di
    206b:	9a 78 18 8f 20       	call   0x208f:0x1878
    2070:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    2074:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    2079:	7e 16                	jle    0x2091
    207b:	c6 86 eb fb 01       	mov    BYTE PTR [bp-0x415],0x1
    2080:	8d be f2 fc          	lea    di,[bp-0x30e]
    2084:	16                   	push   ss
    2085:	57                   	push   di
    2086:	ff b6 e8 fb          	push   WORD PTR [bp-0x418]
    208a:	6a 02                	push   0x2
    208c:	9a 75 19 a3 20       	call   0x20a3:0x1975
    2091:	8d be f2 fc          	lea    di,[bp-0x30e]
    2095:	16                   	push   ss
    2096:	57                   	push   di
    2097:	8d be f2 fb          	lea    di,[bp-0x40e]
    209b:	16                   	push   ss
    209c:	57                   	push   di
    209d:	68 ff 00             	push   0xff
    20a0:	9a e7 17 b3 20       	call   0x20b3:0x17e7
    20a5:	bf f1 1e             	mov    di,0x1ef1
    20a8:	0e                   	push   cs
    20a9:	57                   	push   di
    20aa:	8d be f2 fc          	lea    di,[bp-0x30e]
    20ae:	16                   	push   ss
    20af:	57                   	push   di
    20b0:	9a 78 18 cf 20       	call   0x20cf:0x1878
    20b5:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    20b9:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    20be:	7e 11                	jle    0x20d1
    20c0:	8d be f2 fc          	lea    di,[bp-0x30e]
    20c4:	16                   	push   ss
    20c5:	57                   	push   di
    20c6:	ff b6 e8 fb          	push   WORD PTR [bp-0x418]
    20ca:	6a 01                	push   0x1
    20cc:	9a 75 19 f2 20       	call   0x20f2:0x1975
    20d1:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    20d6:	75 cd                	jne    0x20a5
    20d8:	c6 86 ea fb 00       	mov    BYTE PTR [bp-0x416],0x0
    20dd:	80 be f2 fc 01       	cmp    BYTE PTR [bp-0x30e],0x1
    20e2:	76 70                	jbe    0x2154
    20e4:	bf f3 1e             	mov    di,0x1ef3
    20e7:	0e                   	push   cs
    20e8:	57                   	push   di
    20e9:	8d be f2 fc          	lea    di,[bp-0x30e]
    20ed:	16                   	push   ss
    20ee:	57                   	push   di
    20ef:	9a 78 18 0e 21       	call   0x210e:0x1878
    20f4:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    20f8:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    20fd:	7e 17                	jle    0x2116
    20ff:	8a 0e 63 2c          	mov    cl,BYTE PTR ds:0x2c63
    2103:	8b 86 e8 fb          	mov    ax,WORD PTR [bp-0x418]
    2107:	99                   	cwd
    2108:	bf e0 1e             	mov    di,0x1ee0
    210b:	9a 16 04 23 21       	call   0x2123:0x416
    2110:	8b f8                	mov    di,ax
    2112:	88 8b f2 fc          	mov    BYTE PTR [bp+di-0x30e],cl
    2116:	8d be e8 fa          	lea    di,[bp-0x518]
    211a:	16                   	push   ss
    211b:	57                   	push   di
    211c:	a0 63 2c             	mov    al,ds:0x2c63
    211f:	50                   	push   ax
    2120:	9a e9 18 2e 21       	call   0x212e:0x18e9
    2125:	8d be f2 fc          	lea    di,[bp-0x30e]
    2129:	16                   	push   ss
    212a:	57                   	push   di
    212b:	9a 78 18 4b 21       	call   0x214b:0x1878
    2130:	89 86 e8 fb          	mov    WORD PTR [bp-0x418],ax
    2134:	83 be e8 fb 00       	cmp    WORD PTR [bp-0x418],0x0
    2139:	7e 19                	jle    0x2154
    213b:	c6 86 ea fb 01       	mov    BYTE PTR [bp-0x416],0x1
    2140:	8b 86 e8 fb          	mov    ax,WORD PTR [bp-0x418]
    2144:	99                   	cwd
    2145:	bf e0 1e             	mov    di,0x1ee0
    2148:	9a 16 04 70 21       	call   0x2170:0x416
    214d:	8b f8                	mov    di,ax
    214f:	c6 83 f2 fc 2e       	mov    BYTE PTR [bp+di-0x30e],0x2e
    2154:	b8 25 1f             	mov    ax,0x1f25
    2157:	0e                   	push   cs
    2158:	50                   	push   ax
    2159:	55                   	push   bp
    215a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    215e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2162:	8d be f2 fc          	lea    di,[bp-0x30e]
    2166:	16                   	push   ss
    2167:	57                   	push   di
    2168:	8d 7e f2             	lea    di,[bp-0xe]
    216b:	16                   	push   ss
    216c:	57                   	push   di
    216d:	9a 86 1e b3 21       	call   0x21b3:0x1e86
    2172:	9b db 7e f6          	fstp   TBYTE PTR [bp-0xa]
    2176:	90                   	nop
    2177:	9b                   	fwait
    2178:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
    217c:	74 03                	je     0x2181
    217e:	e9 2e 02             	jmp    0x23af
    2181:	80 be ea fb 00       	cmp    BYTE PTR [bp-0x416],0x0
    2186:	74 2f                	je     0x21b7
    2188:	8d be e8 fa          	lea    di,[bp-0x518]
    218c:	16                   	push   ss
    218d:	57                   	push   di
    218e:	bf f5 1e             	mov    di,0x1ef5
    2191:	0e                   	push   cs
    2192:	57                   	push   di
    2193:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2196:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2199:	ff 76 fa             	push   WORD PTR [bp-0x6]
    219c:	ff 76 f8             	push   WORD PTR [bp-0x8]
    219f:	ff 76 f6             	push   WORD PTR [bp-0xa]
    21a2:	9a d4 10 d4 21       	call   0x21d4:0x10d4
    21a7:	8d be f2 fc          	lea    di,[bp-0x30e]
    21ab:	16                   	push   ss
    21ac:	57                   	push   di
    21ad:	68 ff 00             	push   0xff
    21b0:	9a e7 17 e2 21       	call   0x21e2:0x17e7
    21b5:	eb 2d                	jmp    0x21e4
    21b7:	8d be e8 fa          	lea    di,[bp-0x518]
    21bb:	16                   	push   ss
    21bc:	57                   	push   di
    21bd:	bf 00 1f             	mov    di,0x1f00
    21c0:	0e                   	push   cs
    21c1:	57                   	push   di
    21c2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    21c5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    21c8:	ff 76 fa             	push   WORD PTR [bp-0x6]
    21cb:	ff 76 f8             	push   WORD PTR [bp-0x8]
    21ce:	ff 76 f6             	push   WORD PTR [bp-0xa]
    21d1:	9a d4 10 4b 22       	call   0x224b:0x10d4
    21d6:	8d be f2 fc          	lea    di,[bp-0x30e]
    21da:	16                   	push   ss
    21db:	57                   	push   di
    21dc:	68 ff 00             	push   0xff
    21df:	9a e7 17 0d 22       	call   0x220d:0x17e7
    21e4:	8d be f2 fc          	lea    di,[bp-0x30e]
    21e8:	16                   	push   ss
    21e9:	57                   	push   di
    21ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ed:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    21f2:	06                   	push   es
    21f3:	57                   	push   di
    21f4:	9a 03 20 9d 22       	call   0x229d:0x2003
    21f9:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    21fc:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    21ff:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2202:	2d 04 00             	sub    ax,0x4
    2205:	83 da 00             	sbb    dx,0x0
    2208:	71 05                	jno    0x220f
    220a:	9a 3e 04 59 22       	call   0x2259:0x43e
    220f:	8b c8                	mov    cx,ax
    2211:	8b da                	mov    bx,dx
    2213:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2216:	99                   	cwd
    2217:	3b d3                	cmp    dx,bx
    2219:	7f 0c                	jg     0x2227
    221b:	7d 03                	jge    0x2220
    221d:	e9 8d 01             	jmp    0x23ad
    2220:	3b c1                	cmp    ax,cx
    2222:	77 03                	ja     0x2227
    2224:	e9 86 01             	jmp    0x23ad
    2227:	80 be ea fb 00       	cmp    BYTE PTR [bp-0x416],0x0
    222c:	74 2f                	je     0x225d
    222e:	8d be e8 fa          	lea    di,[bp-0x518]
    2232:	16                   	push   ss
    2233:	57                   	push   di
    2234:	bf 06 1f             	mov    di,0x1f06
    2237:	0e                   	push   cs
    2238:	57                   	push   di
    2239:	ff 76 fe             	push   WORD PTR [bp-0x2]
    223c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    223f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2242:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2245:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2248:	9a d4 10 7a 22       	call   0x227a:0x10d4
    224d:	8d be f2 fc          	lea    di,[bp-0x30e]
    2251:	16                   	push   ss
    2252:	57                   	push   di
    2253:	68 ff 00             	push   0xff
    2256:	9a e7 17 88 22       	call   0x2288:0x17e7
    225b:	eb 2d                	jmp    0x228a
    225d:	8d be e8 fa          	lea    di,[bp-0x518]
    2261:	16                   	push   ss
    2262:	57                   	push   di
    2263:	bf 0e 1f             	mov    di,0x1f0e
    2266:	0e                   	push   cs
    2267:	57                   	push   di
    2268:	ff 76 fe             	push   WORD PTR [bp-0x2]
    226b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    226e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2271:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2274:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2277:	9a d4 10 31 23       	call   0x2331:0x10d4
    227c:	8d be f2 fc          	lea    di,[bp-0x30e]
    2280:	16                   	push   ss
    2281:	57                   	push   di
    2282:	68 ff 00             	push   0xff
    2285:	9a e7 17 b3 22       	call   0x22b3:0x17e7
    228a:	8d be f2 fc          	lea    di,[bp-0x30e]
    228e:	16                   	push   ss
    228f:	57                   	push   di
    2290:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2293:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2298:	06                   	push   es
    2299:	57                   	push   di
    229a:	9a 03 20 54 23       	call   0x2354:0x2003
    229f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    22a2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    22a5:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    22a8:	2d 04 00             	sub    ax,0x4
    22ab:	83 da 00             	sbb    dx,0x0
    22ae:	71 05                	jno    0x22b5
    22b0:	9a 3e 04 de 22       	call   0x22de:0x43e
    22b5:	8b c8                	mov    cx,ax
    22b7:	8b da                	mov    bx,dx
    22b9:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    22bc:	99                   	cwd
    22bd:	3b d3                	cmp    dx,bx
    22bf:	7f 0c                	jg     0x22cd
    22c1:	7d 03                	jge    0x22c6
    22c3:	e9 e7 00             	jmp    0x23ad
    22c6:	3b c1                	cmp    ax,cx
    22c8:	77 03                	ja     0x22cd
    22ca:	e9 e0 00             	jmp    0x23ad
    22cd:	bf 11 1f             	mov    di,0x1f11
    22d0:	0e                   	push   cs
    22d1:	57                   	push   di
    22d2:	8d be f2 fd          	lea    di,[bp-0x20e]
    22d6:	16                   	push   ss
    22d7:	57                   	push   di
    22d8:	68 ff 00             	push   0xff
    22db:	9a e7 17 ee 22       	call   0x22ee:0x17e7
    22e0:	8d be e8 fa          	lea    di,[bp-0x518]
    22e4:	16                   	push   ss
    22e5:	57                   	push   di
    22e6:	bf 1e 1f             	mov    di,0x1f1e
    22e9:	0e                   	push   cs
    22ea:	57                   	push   di
    22eb:	9a cd 17 f9 22       	call   0x22f9:0x17cd
    22f0:	8d be f2 fd          	lea    di,[bp-0x20e]
    22f4:	16                   	push   ss
    22f5:	57                   	push   di
    22f6:	9a 4c 18 03 23       	call   0x2303:0x184c
    22fb:	bf 22 1f             	mov    di,0x1f22
    22fe:	0e                   	push   cs
    22ff:	57                   	push   di
    2300:	9a 4c 18 11 23       	call   0x2311:0x184c
    2305:	8d be f2 fe          	lea    di,[bp-0x10e]
    2309:	16                   	push   ss
    230a:	57                   	push   di
    230b:	68 ff 00             	push   0xff
    230e:	9a e7 17 3f 23       	call   0x233f:0x17e7
    2313:	8d be e8 fa          	lea    di,[bp-0x518]
    2317:	16                   	push   ss
    2318:	57                   	push   di
    2319:	8d be f2 fe          	lea    di,[bp-0x10e]
    231d:	16                   	push   ss
    231e:	57                   	push   di
    231f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2322:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2325:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2328:	ff 76 f8             	push   WORD PTR [bp-0x8]
    232b:	ff 76 f6             	push   WORD PTR [bp-0xa]
    232e:	9a d4 10 ff ff       	call   0xffff:0x10d4
    2333:	8d be f2 fc          	lea    di,[bp-0x30e]
    2337:	16                   	push   ss
    2338:	57                   	push   di
    2339:	68 ff 00             	push   0xff
    233c:	9a e7 17 6b 23       	call   0x236b:0x17e7
    2341:	8d be f2 fc          	lea    di,[bp-0x30e]
    2345:	16                   	push   ss
    2346:	57                   	push   di
    2347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    234f:	06                   	push   es
    2350:	57                   	push   di
    2351:	9a 03 20 6a 24       	call   0x246a:0x2003
    2356:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2359:	8d be f2 fd          	lea    di,[bp-0x20e]
    235d:	16                   	push   ss
    235e:	57                   	push   di
    235f:	8a 86 f2 fd          	mov    al,BYTE PTR [bp-0x20e]
    2363:	30 e4                	xor    ah,ah
    2365:	50                   	push   ax
    2366:	6a 01                	push   0x1
    2368:	9a 75 19 7e 23       	call   0x237e:0x1975
    236d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2370:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2373:	2d 04 00             	sub    ax,0x4
    2376:	83 da 00             	sbb    dx,0x0
    2379:	71 05                	jno    0x2380
    237b:	9a 3e 04 c1 23       	call   0x23c1:0x43e
    2380:	8b c8                	mov    cx,ax
    2382:	8b da                	mov    bx,dx
    2384:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2387:	99                   	cwd
    2388:	3b d3                	cmp    dx,bx
    238a:	7c 0a                	jl     0x2396
    238c:	7f 04                	jg     0x2392
    238e:	3b c1                	cmp    ax,cx
    2390:	76 04                	jbe    0x2396
    2392:	b0 00                	mov    al,0x0
    2394:	eb 02                	jmp    0x2398
    2396:	b0 01                	mov    al,0x1
    2398:	8a d0                	mov    dl,al
    239a:	80 be f2 fd 00       	cmp    BYTE PTR [bp-0x20e],0x0
    239f:	b0 00                	mov    al,0x0
    23a1:	75 01                	jne    0x23a4
    23a3:	40                   	inc    ax
    23a4:	0a c2                	or     al,dl
    23a6:	08 c0                	or     al,al
    23a8:	75 03                	jne    0x23ad
    23aa:	e9 33 ff             	jmp    0x22e0
    23ad:	eb 14                	jmp    0x23c3
    23af:	8d be f2 fb          	lea    di,[bp-0x40e]
    23b3:	16                   	push   ss
    23b4:	57                   	push   di
    23b5:	8d be f2 fc          	lea    di,[bp-0x30e]
    23b9:	16                   	push   ss
    23ba:	57                   	push   di
    23bb:	68 ff 00             	push   0xff
    23be:	9a e7 17 e0 23       	call   0x23e0:0x17e7
    23c3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    23c7:	83 c4 06             	add    sp,0x6
    23ca:	b8 e3 23             	mov    ax,0x23e3
    23cd:	0e                   	push   cs
    23ce:	50                   	push   ax
    23cf:	8d be f2 fc          	lea    di,[bp-0x30e]
    23d3:	16                   	push   ss
    23d4:	57                   	push   di
    23d5:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    23d8:	06                   	push   es
    23d9:	57                   	push   di
    23da:	68 ff 00             	push   0xff
    23dd:	9a e7 17 26 24       	call   0x2426:0x17e7
    23e2:	cb                   	retf
    23e3:	c9                   	leave
    23e4:	ca 0c 00             	retf   0xc
    23e7:	eb ff                	jmp    0x23e8
    23e9:	ff                   	(bad)
    23ea:	ff                   	(bad)
    23eb:	ff                   	(bad)
    23ec:	ff                   	(bad)
    23ed:	ff 02                	inc    WORD PTR [bp+si]
    23ef:	00 00                	add    BYTE PTR [bx+si],al
    23f1:	00 00                	add    BYTE PTR [bx+si],al
    23f3:	07                   	pop    es
    23f4:	00 00                	add    BYTE PTR [bx+si],al
    23f6:	00 00                	add    BYTE PTR [bx+si],al
    23f8:	00 00                	add    BYTE PTR [bx+si],al
    23fa:	00 02                	add    BYTE PTR [bp+si],al
    23fc:	00 00                	add    BYTE PTR [bx+si],al
    23fe:	00 00                	add    BYTE PTR [bx+si],al
    2400:	80 ff ff             	cmp    bh,0xff
    2403:	ff                   	(bad)
    2404:	7f 00                	jg     0x2406
    2406:	00 02                	add    BYTE PTR [bp+si],al
    2408:	23 43 00             	and    ax,WORD PTR [bp+di+0x0]
    240b:	00 00                	add    BYTE PTR [bx+si],al
    240d:	00 ff                	add    bh,bh
    240f:	00 00                	add    BYTE PTR [bx+si],al
    2411:	00 02                	add    BYTE PTR [bp+si],al
    2413:	23 41 02             	and    ax,WORD PTR [bx+di+0x2]
    2416:	23 56 02             	and    dx,WORD PTR [bp+0x2]
    2419:	23 48 01             	and    cx,WORD PTR [bx+si+0x1]
    241c:	00 55 89             	add    BYTE PTR [di-0x77],dl
    241f:	e5 b8                	in     ax,0xb8
    2421:	3a 03                	cmp    al,BYTE PTR [bp+di]
    2423:	9a 44 04 72 24       	call   0x2472:0x444
    2428:	81 ec 3a 03          	sub    sp,0x33a
    242c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    242f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2433:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2437:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    243b:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2440:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2444:	06                   	push   es
    2445:	57                   	push   di
    2446:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2449:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    244d:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2450:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2454:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2459:	89 be c2 fe          	mov    WORD PTR [bp-0x13e],di
    245d:	8c 86 c4 fe          	mov    WORD PTR [bp-0x13c],es
    2461:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2465:	06                   	push   es
    2466:	57                   	push   di
    2467:	9a 61 16 89 24       	call   0x2489:0x1661
    246c:	bf e7 23             	mov    di,0x23e7
    246f:	9a 16 04 93 24       	call   0x2493:0x416
    2474:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    2478:	89 96 de fe          	mov    WORD PTR [bp-0x122],dx
    247c:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    2480:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2484:	06                   	push   es
    2485:	57                   	push   di
    2486:	9a 63 17 a6 24       	call   0x24a6:0x1763
    248b:	98                   	cbw
    248c:	99                   	cwd
    248d:	bf ef 23             	mov    di,0x23ef
    2490:	9a 16 04 d6 24       	call   0x24d6:0x416
    2495:	88 86 d7 fe          	mov    BYTE PTR [bp-0x129],al
    2499:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    249d:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    24a1:	06                   	push   es
    24a2:	57                   	push   di
    24a3:	9a cc 11 b9 24       	call   0x24b9:0x11cc
    24a8:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    24ac:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    24b0:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    24b4:	06                   	push   es
    24b5:	57                   	push   di
    24b6:	9a 1a 12 cc 24       	call   0x24cc:0x121a
    24bb:	88 86 d3 fe          	mov    BYTE PTR [bp-0x12d],al
    24bf:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    24c3:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    24c7:	06                   	push   es
    24c8:	57                   	push   di
    24c9:	9a 5f 12 13 25       	call   0x2513:0x125f
    24ce:	98                   	cbw
    24cf:	99                   	cwd
    24d0:	bf f7 23             	mov    di,0x23f7
    24d3:	9a 16 04 f2 24       	call   0x24f2:0x416
    24d8:	88 86 d2 fe          	mov    BYTE PTR [bp-0x12e],al
    24dc:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    24e0:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    24e4:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    24e8:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    24ec:	bf e7 23             	mov    di,0x23e7
    24ef:	9a 16 04 2a 25       	call   0x252a:0x416
    24f4:	89 86 ce fe          	mov    WORD PTR [bp-0x132],ax
    24f8:	89 96 d0 fe          	mov    WORD PTR [bp-0x130],dx
    24fc:	6a 00                	push   0x0
    24fe:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2501:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2505:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    250a:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    250e:	06                   	push   es
    250f:	57                   	push   di
    2510:	9a 7c 17 43 25       	call   0x2543:0x177c
    2515:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2518:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    251c:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    2520:	26 8b 55 3a          	mov    dx,WORD PTR es:[di+0x3a]
    2524:	bf e7 23             	mov    di,0x23e7
    2527:	9a 16 04 69 25       	call   0x2569:0x416
    252c:	52                   	push   dx
    252d:	50                   	push   ax
    252e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2531:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2535:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    253a:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    253e:	06                   	push   es
    253f:	57                   	push   di
    2540:	9a 84 16 82 25       	call   0x2582:0x1684
    2545:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2548:	36 f6 45 0a 04       	test   BYTE PTR ss:[di+0xa],0x4
    254d:	75 03                	jne    0x2552
    254f:	e9 b4 00             	jmp    0x2606
    2552:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2555:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2559:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    255e:	26 8b 95 04 01       	mov    dx,WORD PTR es:[di+0x104]
    2563:	bf e7 23             	mov    di,0x23e7
    2566:	9a 16 04 92 25       	call   0x2592:0x416
    256b:	52                   	push   dx
    256c:	50                   	push   ax
    256d:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2570:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2574:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2579:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    257d:	06                   	push   es
    257e:	57                   	push   di
    257f:	9a 84 16 cb 25       	call   0x25cb:0x1684
    2584:	8b 86 d4 fe          	mov    ax,WORD PTR [bp-0x12c]
    2588:	b9 0d 00             	mov    cx,0xd
    258b:	f7 e9                	imul   cx
    258d:	71 05                	jno    0x2594
    258f:	9a 3e 04 ab 25       	call   0x25ab:0x43e
    2594:	99                   	cwd
    2595:	b9 0a 00             	mov    cx,0xa
    2598:	f7 f9                	idiv   cx
    259a:	99                   	cwd
    259b:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    259f:	89 96 c4 fe          	mov    WORD PTR [bp-0x13c],dx
    25a3:	9b db 86 c2 fe       	fild   DWORD PTR [bp-0x13e]
    25a8:	9a 2f 10 b3 25       	call   0x25b3:0x102f
    25ad:	bf ff 23             	mov    di,0x23ff
    25b0:	9a 16 04 00 27       	call   0x2700:0x416
    25b5:	50                   	push   ax
    25b6:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    25b9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    25bd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    25c2:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    25c6:	06                   	push   es
    25c7:	57                   	push   di
    25c8:	9a f5 11 e9 25       	call   0x25e9:0x11f5
    25cd:	8a 86 d3 fe          	mov    al,BYTE PTR [bp-0x12d]
    25d1:	0c 01                	or     al,0x1
    25d3:	50                   	push   ax
    25d4:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    25d7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    25db:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    25e0:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    25e4:	06                   	push   es
    25e5:	57                   	push   di
    25e6:	9a 33 12 02 26       	call   0x2602:0x1233
    25eb:	6a 02                	push   0x2
    25ed:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    25f0:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    25f4:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    25f9:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    25fd:	06                   	push   es
    25fe:	57                   	push   di
    25ff:	9a 78 12 2a 26       	call   0x262a:0x1278
    2604:	eb 33                	jmp    0x2639
    2606:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2609:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    260d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2612:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2616:	89 be c2 fe          	mov    WORD PTR [bp-0x13e],di
    261a:	8c 86 c4 fe          	mov    WORD PTR [bp-0x13c],es
    261e:	8a 86 d3 fe          	mov    al,BYTE PTR [bp-0x12d]
    2622:	24 fe                	and    al,0xfe
    2624:	50                   	push   ax
    2625:	06                   	push   es
    2626:	57                   	push   di
    2627:	9a 33 12 37 26       	call   0x2637:0x1233
    262c:	6a 02                	push   0x2
    262e:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    2632:	06                   	push   es
    2633:	57                   	push   di
    2634:	9a 78 12 75 26       	call   0x2675:0x1278
    2639:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    263c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2640:	06                   	push   es
    2641:	57                   	push   di
    2642:	9a 58 62 9e 26       	call   0x269e:0x6258
    2647:	8a d0                	mov    dl,al
    2649:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    264c:	36 f6 45 0a 01       	test   BYTE PTR ss:[di+0xa],0x1
    2651:	b0 00                	mov    al,0x0
    2653:	74 01                	je     0x2656
    2655:	40                   	inc    ax
    2656:	22 c2                	and    al,dl
    2658:	08 c0                	or     al,al
    265a:	74 36                	je     0x2692
    265c:	6a ff                	push   0xffff
    265e:	6a f2                	push   0xfff2
    2660:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2663:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2667:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    266c:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2670:	06                   	push   es
    2671:	57                   	push   di
    2672:	9a 84 16 90 26       	call   0x2690:0x1684
    2677:	6a ff                	push   0xffff
    2679:	6a f1                	push   0xfff1
    267b:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    267e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2682:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2687:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    268b:	06                   	push   es
    268c:	57                   	push   di
    268d:	9a df 0f e5 26       	call   0x26e5:0xfdf
    2692:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2695:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2699:	06                   	push   es
    269a:	57                   	push   di
    269b:	9a 58 62 a8 34       	call   0x34a8:0x6258
    26a0:	8a c8                	mov    cl,al
    26a2:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    26a5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    26a9:	26 f6 85 08 01 20    	test   BYTE PTR es:[di+0x108],0x20
    26af:	b0 00                	mov    al,0x0
    26b1:	75 01                	jne    0x26b4
    26b3:	40                   	inc    ax
    26b4:	8a d0                	mov    dl,al
    26b6:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    26b9:	36 f6 45 0a 02       	test   BYTE PTR ss:[di+0xa],0x2
    26be:	b0 00                	mov    al,0x0
    26c0:	74 01                	je     0x26c3
    26c2:	40                   	inc    ax
    26c3:	22 c2                	and    al,dl
    26c5:	22 c1                	and    al,cl
    26c7:	08 c0                	or     al,al
    26c9:	74 50                	je     0x271b
    26cb:	6a 00                	push   0x0
    26cd:	68 00 ff             	push   0xff00
    26d0:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    26d3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    26d7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    26dc:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    26e0:	06                   	push   es
    26e1:	57                   	push   di
    26e2:	9a 84 16 19 27       	call   0x2719:0x1684
    26e7:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    26ea:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    26ee:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    26f2:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    26f6:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    26fa:	bf e7 23             	mov    di,0x23e7
    26fd:	9a 16 04 4c 27       	call   0x274c:0x416
    2702:	52                   	push   dx
    2703:	50                   	push   ax
    2704:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2707:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    270b:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2710:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2714:	06                   	push   es
    2715:	57                   	push   di
    2716:	9a df 0f c1 29       	call   0x29c1:0xfdf
    271b:	8d be be fe          	lea    di,[bp-0x142]
    271f:	16                   	push   ss
    2720:	57                   	push   di
    2721:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2724:	36 ff 75 16          	push   WORD PTR ss:[di+0x16]
    2728:	36 ff 75 14          	push   WORD PTR ss:[di+0x14]
    272c:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    2730:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    2734:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2737:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    273b:	06                   	push   es
    273c:	57                   	push   di
    273d:	9a 35 7f a6 27       	call   0x27a6:0x7f35
    2742:	8d 7e f8             	lea    di,[bp-0x8]
    2745:	16                   	push   ss
    2746:	57                   	push   di
    2747:	6a 08                	push   0x8
    2749:	9a 1b 16 6c 27       	call   0x276c:0x161b
    274e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2751:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2754:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2757:	89 86 ca fe          	mov    WORD PTR [bp-0x136],ax
    275b:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    275e:	36 8b 45 14          	mov    ax,WORD PTR ss:[di+0x14]
    2762:	36 8b 55 16          	mov    dx,WORD PTR ss:[di+0x16]
    2766:	bf ff 23             	mov    di,0x23ff
    2769:	9a 16 04 97 27       	call   0x2797:0x416
    276e:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2772:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2775:	36 f6 45 0a 02       	test   BYTE PTR ss:[di+0xa],0x2
    277a:	75 79                	jne    0x27f5
    277c:	8d be c6 fd          	lea    di,[bp-0x23a]
    2780:	16                   	push   ss
    2781:	57                   	push   di
    2782:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    2786:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2789:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    278d:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2791:	bf ff 23             	mov    di,0x23ff
    2794:	9a 16 04 ed 27       	call   0x27ed:0x416
    2799:	50                   	push   ax
    279a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    279d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    27a1:	06                   	push   es
    27a2:	57                   	push   di
    27a3:	9a 68 9a de 27       	call   0x27de:0x9a68
    27a8:	83 c4 04             	add    sp,0x4
    27ab:	80 be c6 fd 00       	cmp    BYTE PTR [bp-0x23a],0x0
    27b0:	b0 00                	mov    al,0x0
    27b2:	75 01                	jne    0x27b5
    27b4:	40                   	inc    ax
    27b5:	8a d0                	mov    dl,al
    27b7:	83 be f2 fe 00       	cmp    WORD PTR [bp-0x10e],0x0
    27bc:	b0 00                	mov    al,0x0
    27be:	7e 01                	jle    0x27c1
    27c0:	40                   	inc    ax
    27c1:	22 c2                	and    al,dl
    27c3:	08 c0                	or     al,al
    27c5:	74 2e                	je     0x27f5
    27c7:	ff 8e f2 fe          	dec    WORD PTR [bp-0x10e]
    27cb:	8b 86 f2 fe          	mov    ax,WORD PTR [bp-0x10e]
    27cf:	99                   	cwd
    27d0:	52                   	push   dx
    27d1:	50                   	push   ax
    27d2:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    27d5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    27d9:	06                   	push   es
    27da:	57                   	push   di
    27db:	9a 30 6e 1f 28       	call   0x281f:0x6e30
    27e0:	8b d0                	mov    dx,ax
    27e2:	8b 86 ca fe          	mov    ax,WORD PTR [bp-0x136]
    27e6:	2b c2                	sub    ax,dx
    27e8:	71 05                	jno    0x27ef
    27ea:	9a 3e 04 10 28       	call   0x2810:0x43e
    27ef:	89 86 ca fe          	mov    WORD PTR [bp-0x136],ax
    27f3:	eb 87                	jmp    0x277c
    27f5:	8d be c6 fd          	lea    di,[bp-0x23a]
    27f9:	16                   	push   ss
    27fa:	57                   	push   di
    27fb:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    27ff:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2802:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2806:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    280a:	bf ff 23             	mov    di,0x23ff
    280d:	9a 16 04 2d 28       	call   0x282d:0x416
    2812:	50                   	push   ax
    2813:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2816:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    281a:	06                   	push   es
    281b:	57                   	push   di
    281c:	9a 68 9a e8 29       	call   0x29e8:0x9a68
    2821:	8d be f4 fe          	lea    di,[bp-0x10c]
    2825:	16                   	push   ss
    2826:	57                   	push   di
    2827:	68 ff 00             	push   0xff
    282a:	9a e7 17 4a 28       	call   0x284a:0x17e7
    282f:	c7 86 e6 fe 01 00    	mov    WORD PTR [bp-0x11a],0x1
    2835:	80 be f4 fe 02       	cmp    BYTE PTR [bp-0x10c],0x2
    283a:	76 59                	jbe    0x2895
    283c:	bf 07 24             	mov    di,0x2407
    283f:	0e                   	push   cs
    2840:	57                   	push   di
    2841:	8d be f4 fe          	lea    di,[bp-0x10c]
    2845:	16                   	push   ss
    2846:	57                   	push   di
    2847:	9a 78 18 63 28       	call   0x2863:0x1878
    284c:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    2850:	83 be c6 fe 00       	cmp    WORD PTR [bp-0x13a],0x0
    2855:	7e 3e                	jle    0x2895
    2857:	8b 86 c6 fe          	mov    ax,WORD PTR [bp-0x13a]
    285b:	05 02 00             	add    ax,0x2
    285e:	71 05                	jno    0x2865
    2860:	9a 3e 04 6c 28       	call   0x286c:0x43e
    2865:	99                   	cwd
    2866:	bf 0a 24             	mov    di,0x240a
    2869:	9a 16 04 7e 28       	call   0x287e:0x416
    286e:	8b f8                	mov    di,ax
    2870:	8a 83 f4 fe          	mov    al,BYTE PTR [bp+di-0x10c]
    2874:	30 e4                	xor    ah,ah
    2876:	2d 30 00             	sub    ax,0x30
    2879:	71 05                	jno    0x2880
    287b:	9a 3e 04 93 28       	call   0x2893:0x43e
    2880:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    2884:	8d be f4 fe          	lea    di,[bp-0x10c]
    2888:	16                   	push   ss
    2889:	57                   	push   di
    288a:	ff b6 c6 fe          	push   WORD PTR [bp-0x13a]
    288e:	6a 03                	push   0x3
    2890:	9a 75 19 af 28       	call   0x28af:0x1975
    2895:	c6 86 eb fe 67       	mov    BYTE PTR [bp-0x115],0x67
    289a:	80 be f4 fe 02       	cmp    BYTE PTR [bp-0x10c],0x2
    289f:	76 4d                	jbe    0x28ee
    28a1:	bf 12 24             	mov    di,0x2412
    28a4:	0e                   	push   cs
    28a5:	57                   	push   di
    28a6:	8d be f4 fe          	lea    di,[bp-0x10c]
    28aa:	16                   	push   ss
    28ab:	57                   	push   di
    28ac:	9a 78 18 c8 28       	call   0x28c8:0x1878
    28b1:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    28b5:	83 be c6 fe 00       	cmp    WORD PTR [bp-0x13a],0x0
    28ba:	7e 32                	jle    0x28ee
    28bc:	8b 86 c6 fe          	mov    ax,WORD PTR [bp-0x13a]
    28c0:	05 02 00             	add    ax,0x2
    28c3:	71 05                	jno    0x28ca
    28c5:	9a 3e 04 d1 28       	call   0x28d1:0x43e
    28ca:	99                   	cwd
    28cb:	bf 0a 24             	mov    di,0x240a
    28ce:	9a 16 04 ec 28       	call   0x28ec:0x416
    28d3:	8b f8                	mov    di,ax
    28d5:	8a 83 f4 fe          	mov    al,BYTE PTR [bp+di-0x10c]
    28d9:	88 86 eb fe          	mov    BYTE PTR [bp-0x115],al
    28dd:	8d be f4 fe          	lea    di,[bp-0x10c]
    28e1:	16                   	push   ss
    28e2:	57                   	push   di
    28e3:	ff b6 c6 fe          	push   WORD PTR [bp-0x13a]
    28e7:	6a 03                	push   0x3
    28e9:	9a 75 19 1d 29       	call   0x291d:0x1975
    28ee:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    28f1:	36 f6 45 0a 02       	test   BYTE PTR ss:[di+0xa],0x2
    28f6:	74 0b                	je     0x2903
    28f8:	c7 86 e6 fe 01 00    	mov    WORD PTR [bp-0x11a],0x1
    28fe:	c6 86 eb fe 67       	mov    BYTE PTR [bp-0x115],0x67
    2903:	c6 86 e1 fe 00       	mov    BYTE PTR [bp-0x11f],0x0
    2908:	80 be f4 fe 01       	cmp    BYTE PTR [bp-0x10c],0x1
    290d:	76 31                	jbe    0x2940
    290f:	bf 15 24             	mov    di,0x2415
    2912:	0e                   	push   cs
    2913:	57                   	push   di
    2914:	8d be f4 fe          	lea    di,[bp-0x10c]
    2918:	16                   	push   ss
    2919:	57                   	push   di
    291a:	9a 78 18 3e 29       	call   0x293e:0x1878
    291f:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    2923:	83 be c6 fe 00       	cmp    WORD PTR [bp-0x13a],0x0
    2928:	7e 16                	jle    0x2940
    292a:	c6 86 e1 fe 01       	mov    BYTE PTR [bp-0x11f],0x1
    292f:	8d be f4 fe          	lea    di,[bp-0x10c]
    2933:	16                   	push   ss
    2934:	57                   	push   di
    2935:	ff b6 c6 fe          	push   WORD PTR [bp-0x13a]
    2939:	6a 02                	push   0x2
    293b:	9a 75 19 5a 29       	call   0x295a:0x1975
    2940:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    2945:	80 be f4 fe 01       	cmp    BYTE PTR [bp-0x10c],0x1
    294a:	76 31                	jbe    0x297d
    294c:	bf 18 24             	mov    di,0x2418
    294f:	0e                   	push   cs
    2950:	57                   	push   di
    2951:	8d be f4 fe          	lea    di,[bp-0x10c]
    2955:	16                   	push   ss
    2956:	57                   	push   di
    2957:	9a 78 18 7b 29       	call   0x297b:0x1878
    295c:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    2960:	83 be c6 fe 00       	cmp    WORD PTR [bp-0x13a],0x0
    2965:	7e 16                	jle    0x297d
    2967:	c6 86 e0 fe 01       	mov    BYTE PTR [bp-0x120],0x1
    296c:	8d be f4 fe          	lea    di,[bp-0x10c]
    2970:	16                   	push   ss
    2971:	57                   	push   di
    2972:	ff b6 c6 fe          	push   WORD PTR [bp-0x13a]
    2976:	6a 02                	push   0x2
    2978:	9a 75 19 a8 29       	call   0x29a8:0x1975
    297d:	8d be c6 fd          	lea    di,[bp-0x23a]
    2981:	16                   	push   ss
    2982:	57                   	push   di
    2983:	8d be f4 fe          	lea    di,[bp-0x10c]
    2987:	16                   	push   ss
    2988:	57                   	push   di
    2989:	6a 00                	push   0x0
    298b:	68 00 7d             	push   0x7d00
    298e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2991:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2995:	06                   	push   es
    2996:	57                   	push   di
    2997:	9a 2b 1f fb 2d       	call   0x2dfb:0x1f2b
    299c:	8d be f4 fe          	lea    di,[bp-0x10c]
    29a0:	16                   	push   ss
    29a1:	57                   	push   di
    29a2:	68 ff 00             	push   0xff
    29a5:	9a e7 17 f3 29       	call   0x29f3:0x17e7
    29aa:	8d be f4 fe          	lea    di,[bp-0x10c]
    29ae:	16                   	push   ss
    29af:	57                   	push   di
    29b0:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    29b3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    29b7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    29bc:	06                   	push   es
    29bd:	57                   	push   di
    29be:	9a 03 20 22 2e       	call   0x2e22:0x2003
    29c3:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    29c7:	31 c0                	xor    ax,ax
    29c9:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    29cd:	8b 86 f2 fe          	mov    ax,WORD PTR [bp-0x10e]
    29d1:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    29d5:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    29d9:	99                   	cwd
    29da:	52                   	push   dx
    29db:	50                   	push   ax
    29dc:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    29df:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    29e3:	06                   	push   es
    29e4:	57                   	push   di
    29e5:	9a 30 6e 58 2a       	call   0x2a58:0x6e30
    29ea:	03 86 ee fe          	add    ax,WORD PTR [bp-0x112]
    29ee:	71 05                	jno    0x29f5
    29f0:	9a 3e 04 19 2a       	call   0x2a19:0x43e
    29f5:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    29f9:	ff 86 f0 fe          	inc    WORD PTR [bp-0x110]
    29fd:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2a00:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2a04:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2a09:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2a0e:	2d 01 00             	sub    ax,0x1
    2a11:	83 da 00             	sbb    dx,0x0
    2a14:	71 05                	jno    0x2a1b
    2a16:	9a 3e 04 49 2a       	call   0x2a49:0x43e
    2a1b:	8b c8                	mov    cx,ax
    2a1d:	8b da                	mov    bx,dx
    2a1f:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2a23:	99                   	cwd
    2a24:	3b d3                	cmp    dx,bx
    2a26:	7c 06                	jl     0x2a2e
    2a28:	7f 3f                	jg     0x2a69
    2a2a:	3b c1                	cmp    ax,cx
    2a2c:	77 3b                	ja     0x2a69
    2a2e:	8d be c6 fd          	lea    di,[bp-0x23a]
    2a32:	16                   	push   ss
    2a33:	57                   	push   di
    2a34:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    2a38:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2a3b:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2a3f:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2a43:	bf ff 23             	mov    di,0x23ff
    2a46:	9a 16 04 8b 2a       	call   0x2a8b:0x416
    2a4b:	50                   	push   ax
    2a4c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2a4f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2a53:	06                   	push   es
    2a54:	57                   	push   di
    2a55:	9a 68 9a 4a 2b       	call   0x2b4a:0x9a68
    2a5a:	83 c4 04             	add    sp,0x4
    2a5d:	8a 86 c6 fd          	mov    al,BYTE PTR [bp-0x23a]
    2a61:	30 e4                	xor    ah,ah
    2a63:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    2a67:	eb 06                	jmp    0x2a6f
    2a69:	31 c0                	xor    ax,ax
    2a6b:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    2a6f:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2a72:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2a76:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2a7b:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2a80:	2d 01 00             	sub    ax,0x1
    2a83:	83 da 00             	sbb    dx,0x0
    2a86:	71 05                	jno    0x2a8d
    2a88:	9a 3e 04 c2 2a       	call   0x2ac2:0x43e
    2a8d:	8b c8                	mov    cx,ax
    2a8f:	8b da                	mov    bx,dx
    2a91:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2a95:	99                   	cwd
    2a96:	3b d3                	cmp    dx,bx
    2a98:	7f 0a                	jg     0x2aa4
    2a9a:	7c 04                	jl     0x2aa0
    2a9c:	3b c1                	cmp    ax,cx
    2a9e:	77 04                	ja     0x2aa4
    2aa0:	b0 00                	mov    al,0x0
    2aa2:	eb 02                	jmp    0x2aa6
    2aa4:	b0 01                	mov    al,0x1
    2aa6:	8a d0                	mov    dl,al
    2aa8:	83 be ec fe 00       	cmp    WORD PTR [bp-0x114],0x0
    2aad:	b0 00                	mov    al,0x0
    2aaf:	7e 01                	jle    0x2ab2
    2ab1:	40                   	inc    ax
    2ab2:	0a c2                	or     al,dl
    2ab4:	8a d0                	mov    dl,al
    2ab6:	8b 86 cc fe          	mov    ax,WORD PTR [bp-0x134]
    2aba:	05 04 00             	add    ax,0x4
    2abd:	71 05                	jno    0x2ac4
    2abf:	9a 3e 04 e3 2a       	call   0x2ae3:0x43e
    2ac4:	3b 86 ee fe          	cmp    ax,WORD PTR [bp-0x112]
    2ac8:	b0 00                	mov    al,0x0
    2aca:	7d 01                	jge    0x2acd
    2acc:	40                   	inc    ax
    2acd:	0a c2                	or     al,dl
    2acf:	08 c0                	or     al,al
    2ad1:	75 03                	jne    0x2ad6
    2ad3:	e9 ff fe             	jmp    0x29d5
    2ad6:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2ada:	2b 86 f2 fe          	sub    ax,WORD PTR [bp-0x10e]
    2ade:	71 05                	jno    0x2ae5
    2ae0:	9a 3e 04 05 2b       	call   0x2b05:0x43e
    2ae5:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    2ae9:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2aec:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2af0:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2af5:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2afa:	2d 01 00             	sub    ax,0x1
    2afd:	83 da 00             	sbb    dx,0x0
    2b00:	71 05                	jno    0x2b07
    2b02:	9a 3e 04 3b 2b       	call   0x2b3b:0x43e
    2b07:	8b c8                	mov    cx,ax
    2b09:	8b da                	mov    bx,dx
    2b0b:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2b0f:	99                   	cwd
    2b10:	3b d3                	cmp    dx,bx
    2b12:	7c 0c                	jl     0x2b20
    2b14:	7e 03                	jle    0x2b19
    2b16:	e9 26 01             	jmp    0x2c3f
    2b19:	3b c1                	cmp    ax,cx
    2b1b:	76 03                	jbe    0x2b20
    2b1d:	e9 1f 01             	jmp    0x2c3f
    2b20:	8d be c6 fd          	lea    di,[bp-0x23a]
    2b24:	16                   	push   ss
    2b25:	57                   	push   di
    2b26:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    2b2a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2b2d:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2b31:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2b35:	bf ff 23             	mov    di,0x23ff
    2b38:	9a 16 04 77 2b       	call   0x2b77:0x416
    2b3d:	50                   	push   ax
    2b3e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2b41:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2b45:	06                   	push   es
    2b46:	57                   	push   di
    2b47:	9a 68 9a 6c 2b       	call   0x2b6c:0x9a68
    2b4c:	83 c4 04             	add    sp,0x4
    2b4f:	80 be c6 fd 00       	cmp    BYTE PTR [bp-0x23a],0x0
    2b54:	74 03                	je     0x2b59
    2b56:	e9 e6 00             	jmp    0x2c3f
    2b59:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2b5d:	99                   	cwd
    2b5e:	52                   	push   dx
    2b5f:	50                   	push   ax
    2b60:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2b63:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2b67:	06                   	push   es
    2b68:	57                   	push   di
    2b69:	9a 30 6e dc 2b       	call   0x2bdc:0x6e30
    2b6e:	03 86 ee fe          	add    ax,WORD PTR [bp-0x112]
    2b72:	71 05                	jno    0x2b79
    2b74:	9a 3e 04 9d 2b       	call   0x2b9d:0x43e
    2b79:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    2b7d:	ff 86 f0 fe          	inc    WORD PTR [bp-0x110]
    2b81:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2b84:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2b88:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2b8d:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2b92:	2d 01 00             	sub    ax,0x1
    2b95:	83 da 00             	sbb    dx,0x0
    2b98:	71 05                	jno    0x2b9f
    2b9a:	9a 3e 04 cd 2b       	call   0x2bcd:0x43e
    2b9f:	8b c8                	mov    cx,ax
    2ba1:	8b da                	mov    bx,dx
    2ba3:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2ba7:	99                   	cwd
    2ba8:	3b d3                	cmp    dx,bx
    2baa:	7c 06                	jl     0x2bb2
    2bac:	7f 3f                	jg     0x2bed
    2bae:	3b c1                	cmp    ax,cx
    2bb0:	77 3b                	ja     0x2bed
    2bb2:	8d be c6 fc          	lea    di,[bp-0x33a]
    2bb6:	16                   	push   ss
    2bb7:	57                   	push   di
    2bb8:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    2bbc:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2bbf:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2bc3:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2bc7:	bf ff 23             	mov    di,0x23ff
    2bca:	9a 16 04 0f 2c       	call   0x2c0f:0x416
    2bcf:	50                   	push   ax
    2bd0:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2bd3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2bd7:	06                   	push   es
    2bd8:	57                   	push   di
    2bd9:	9a 68 9a 87 2d       	call   0x2d87:0x9a68
    2bde:	83 c4 04             	add    sp,0x4
    2be1:	8a 86 c6 fc          	mov    al,BYTE PTR [bp-0x33a]
    2be5:	30 e4                	xor    ah,ah
    2be7:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    2beb:	eb 06                	jmp    0x2bf3
    2bed:	31 c0                	xor    ax,ax
    2bef:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    2bf3:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2bf6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2bfa:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2bff:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2c04:	2d 01 00             	sub    ax,0x1
    2c07:	83 da 00             	sbb    dx,0x0
    2c0a:	71 05                	jno    0x2c11
    2c0c:	9a 3e 04 4c 2c       	call   0x2c4c:0x43e
    2c11:	8b c8                	mov    cx,ax
    2c13:	8b da                	mov    bx,dx
    2c15:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2c19:	99                   	cwd
    2c1a:	3b d3                	cmp    dx,bx
    2c1c:	7f 0a                	jg     0x2c28
    2c1e:	7c 04                	jl     0x2c24
    2c20:	3b c1                	cmp    ax,cx
    2c22:	77 04                	ja     0x2c28
    2c24:	b0 00                	mov    al,0x0
    2c26:	eb 02                	jmp    0x2c2a
    2c28:	b0 01                	mov    al,0x1
    2c2a:	8a d0                	mov    dl,al
    2c2c:	83 be ec fe 00       	cmp    WORD PTR [bp-0x114],0x0
    2c31:	b0 00                	mov    al,0x0
    2c33:	7e 01                	jle    0x2c36
    2c35:	40                   	inc    ax
    2c36:	0a c2                	or     al,dl
    2c38:	08 c0                	or     al,al
    2c3a:	75 03                	jne    0x2c3f
    2c3c:	e9 1a ff             	jmp    0x2b59
    2c3f:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2c43:	2b 86 f2 fe          	sub    ax,WORD PTR [bp-0x10e]
    2c47:	71 05                	jno    0x2c4e
    2c49:	9a 3e 04 97 2c       	call   0x2c97:0x43e
    2c4e:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2c52:	8b 86 e4 fe          	mov    ax,WORD PTR [bp-0x11c]
    2c56:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    2c5a:	83 be e6 fe ff       	cmp    WORD PTR [bp-0x11a],0xffff
    2c5f:	75 08                	jne    0x2c69
    2c61:	8b 86 e2 fe          	mov    ax,WORD PTR [bp-0x11e]
    2c65:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    2c69:	83 be e6 fe 01       	cmp    WORD PTR [bp-0x11a],0x1
    2c6e:	7c 08                	jl     0x2c78
    2c70:	8b 86 e6 fe          	mov    ax,WORD PTR [bp-0x11a]
    2c74:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    2c78:	8b 86 e8 fe          	mov    ax,WORD PTR [bp-0x118]
    2c7c:	3b 86 e2 fe          	cmp    ax,WORD PTR [bp-0x11e]
    2c80:	7e 08                	jle    0x2c8a
    2c82:	8b 86 e2 fe          	mov    ax,WORD PTR [bp-0x11e]
    2c86:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    2c8a:	8b 86 f2 fe          	mov    ax,WORD PTR [bp-0x10e]
    2c8e:	03 86 e8 fe          	add    ax,WORD PTR [bp-0x118]
    2c92:	71 05                	jno    0x2c99
    2c94:	9a 3e 04 a1 2c       	call   0x2ca1:0x43e
    2c99:	2d 01 00             	sub    ax,0x1
    2c9c:	71 05                	jno    0x2ca3
    2c9e:	9a 3e 04 c3 2c       	call   0x2cc3:0x43e
    2ca3:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    2ca7:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2caa:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2cae:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2cb3:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2cb8:	2d 01 00             	sub    ax,0x1
    2cbb:	83 da 00             	sbb    dx,0x0
    2cbe:	71 05                	jno    0x2cc5
    2cc0:	9a 3e 04 f4 2c       	call   0x2cf4:0x43e
    2cc5:	8b c8                	mov    cx,ax
    2cc7:	8b da                	mov    bx,dx
    2cc9:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2ccd:	99                   	cwd
    2cce:	3b d3                	cmp    dx,bx
    2cd0:	7f 06                	jg     0x2cd8
    2cd2:	7c 2e                	jl     0x2d02
    2cd4:	3b c1                	cmp    ax,cx
    2cd6:	76 2a                	jbe    0x2d02
    2cd8:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2cdb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2cdf:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2ce4:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2ce9:	2d 01 00             	sub    ax,0x1
    2cec:	83 da 00             	sbb    dx,0x0
    2cef:	71 05                	jno    0x2cf6
    2cf1:	9a 3e 04 fc 2c       	call   0x2cfc:0x43e
    2cf6:	bf ff 23             	mov    di,0x23ff
    2cf9:	9a 16 04 29 2d       	call   0x2d29:0x416
    2cfe:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    2d02:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2d06:	99                   	cwd
    2d07:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2d0a:	36 3b 55 16          	cmp    dx,WORD PTR ss:[di+0x16]
    2d0e:	7c 08                	jl     0x2d18
    2d10:	7f 40                	jg     0x2d52
    2d12:	36 3b 45 14          	cmp    ax,WORD PTR ss:[di+0x14]
    2d16:	73 3a                	jae    0x2d52
    2d18:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2d1b:	36 8b 45 14          	mov    ax,WORD PTR ss:[di+0x14]
    2d1f:	36 8b 55 16          	mov    dx,WORD PTR ss:[di+0x16]
    2d23:	bf ff 23             	mov    di,0x23ff
    2d26:	9a 16 04 40 2d       	call   0x2d40:0x416
    2d2b:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2d2f:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2d32:	36 8b 45 14          	mov    ax,WORD PTR ss:[di+0x14]
    2d36:	36 8b 55 16          	mov    dx,WORD PTR ss:[di+0x16]
    2d3a:	bf ff 23             	mov    di,0x23ff
    2d3d:	9a 16 04 92 2d       	call   0x2d92:0x416
    2d42:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    2d46:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2d49:	89 86 ca fe          	mov    WORD PTR [bp-0x136],ax
    2d4d:	c6 86 f4 fe 00       	mov    BYTE PTR [bp-0x10c],0x0
    2d52:	31 c0                	xor    ax,ax
    2d54:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    2d58:	8b 86 f0 fe          	mov    ax,WORD PTR [bp-0x110]
    2d5c:	89 86 c4 fe          	mov    WORD PTR [bp-0x13c],ax
    2d60:	8b 86 f2 fe          	mov    ax,WORD PTR [bp-0x10e]
    2d64:	3b 86 c4 fe          	cmp    ax,WORD PTR [bp-0x13c]
    2d68:	7f 38                	jg     0x2da2
    2d6a:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    2d6e:	eb 04                	jmp    0x2d74
    2d70:	ff 86 c6 fe          	inc    WORD PTR [bp-0x13a]
    2d74:	8b 86 c6 fe          	mov    ax,WORD PTR [bp-0x13a]
    2d78:	99                   	cwd
    2d79:	52                   	push   dx
    2d7a:	50                   	push   ax
    2d7b:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2d7e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d82:	06                   	push   es
    2d83:	57                   	push   di
    2d84:	9a 30 6e e6 2d       	call   0x2de6:0x6e30
    2d89:	03 86 ee fe          	add    ax,WORD PTR [bp-0x112]
    2d8d:	71 05                	jno    0x2d94
    2d8f:	9a 3e 04 ae 2d       	call   0x2dae:0x43e
    2d94:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    2d98:	8b 86 c6 fe          	mov    ax,WORD PTR [bp-0x13a]
    2d9c:	3b 86 c4 fe          	cmp    ax,WORD PTR [bp-0x13c]
    2da0:	75 ce                	jne    0x2d70
    2da2:	8b 86 ee fe          	mov    ax,WORD PTR [bp-0x112]
    2da6:	2d 04 00             	sub    ax,0x4
    2da9:	71 05                	jno    0x2db0
    2dab:	9a 3e 04 d7 2d       	call   0x2dd7:0x43e
    2db0:	3b 86 cc fe          	cmp    ax,WORD PTR [bp-0x134]
    2db4:	7d 72                	jge    0x2e28
    2db6:	8d be c6 fc          	lea    di,[bp-0x33a]
    2dba:	16                   	push   ss
    2dbb:	57                   	push   di
    2dbc:	8d be c6 fd          	lea    di,[bp-0x23a]
    2dc0:	16                   	push   ss
    2dc1:	57                   	push   di
    2dc2:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    2dc6:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2dc9:	36 8b 45 10          	mov    ax,WORD PTR ss:[di+0x10]
    2dcd:	36 8b 55 12          	mov    dx,WORD PTR ss:[di+0x12]
    2dd1:	bf ff 23             	mov    di,0x23ff
    2dd4:	9a 16 04 09 2e       	call   0x2e09:0x416
    2dd9:	50                   	push   ax
    2dda:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2ddd:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2de1:	06                   	push   es
    2de2:	57                   	push   di
    2de3:	9a 68 9a 28 30       	call   0x3028:0x9a68
    2de8:	8b 86 ee fe          	mov    ax,WORD PTR [bp-0x112]
    2dec:	99                   	cwd
    2ded:	52                   	push   dx
    2dee:	50                   	push   ax
    2def:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2df2:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2df6:	06                   	push   es
    2df7:	57                   	push   di
    2df8:	9a 2b 1f f0 33       	call   0x33f0:0x1f2b
    2dfd:	8d be f4 fe          	lea    di,[bp-0x10c]
    2e01:	16                   	push   ss
    2e02:	57                   	push   di
    2e03:	68 ff 00             	push   0xff
    2e06:	9a e7 17 3d 2e       	call   0x2e3d:0x17e7
    2e0b:	8d be f4 fe          	lea    di,[bp-0x10c]
    2e0f:	16                   	push   ss
    2e10:	57                   	push   di
    2e11:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2e14:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2e18:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2e1d:	06                   	push   es
    2e1e:	57                   	push   di
    2e1f:	9a 03 20 ad 2e       	call   0x2ead:0x2003
    2e24:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    2e28:	8a 86 eb fe          	mov    al,BYTE PTR [bp-0x115]
    2e2c:	3c 63                	cmp    al,0x63
    2e2e:	75 2f                	jne    0x2e5f
    2e30:	8b 86 ee fe          	mov    ax,WORD PTR [bp-0x112]
    2e34:	2b 86 cc fe          	sub    ax,WORD PTR [bp-0x134]
    2e38:	71 05                	jno    0x2e3f
    2e3a:	9a 3e 04 4e 2e       	call   0x2e4e:0x43e
    2e3f:	99                   	cwd
    2e40:	b9 02 00             	mov    cx,0x2
    2e43:	f7 f9                	idiv   cx
    2e45:	03 86 ca fe          	add    ax,WORD PTR [bp-0x136]
    2e49:	71 05                	jno    0x2e50
    2e4b:	9a 3e 04 58 2e       	call   0x2e58:0x43e
    2e50:	2d 04 00             	sub    ax,0x4
    2e53:	71 05                	jno    0x2e5a
    2e55:	9a 3e 04 70 2e       	call   0x2e70:0x43e
    2e5a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2e5d:	eb 34                	jmp    0x2e93
    2e5f:	3c 64                	cmp    al,0x64
    2e61:	75 29                	jne    0x2e8c
    2e63:	8b 86 ca fe          	mov    ax,WORD PTR [bp-0x136]
    2e67:	03 86 ee fe          	add    ax,WORD PTR [bp-0x112]
    2e6b:	71 05                	jno    0x2e72
    2e6d:	9a 3e 04 7b 2e       	call   0x2e7b:0x43e
    2e72:	2b 86 cc fe          	sub    ax,WORD PTR [bp-0x134]
    2e76:	71 05                	jno    0x2e7d
    2e78:	9a 3e 04 85 2e       	call   0x2e85:0x43e
    2e7d:	2d 04 00             	sub    ax,0x4
    2e80:	71 05                	jno    0x2e87
    2e82:	9a 3e 04 be 2e       	call   0x2ebe:0x43e
    2e87:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2e8a:	eb 07                	jmp    0x2e93
    2e8c:	8b 86 ca fe          	mov    ax,WORD PTR [bp-0x136]
    2e90:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2e93:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2e96:	81 c7 f8 ff          	add    di,0xfff8
    2e9a:	16                   	push   ss
    2e9b:	57                   	push   di
    2e9c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2e9f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2ea3:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2ea8:	06                   	push   es
    2ea9:	57                   	push   di
    2eaa:	9a e5 1c e9 2e       	call   0x2ee9:0x1ce5
    2eaf:	8d be c6 fd          	lea    di,[bp-0x23a]
    2eb3:	16                   	push   ss
    2eb4:	57                   	push   di
    2eb5:	8d be f4 fe          	lea    di,[bp-0x10c]
    2eb9:	16                   	push   ss
    2eba:	57                   	push   di
    2ebb:	9a cd 17 c8 2e       	call   0x2ec8:0x17cd
    2ec0:	bf 1b 24             	mov    di,0x241b
    2ec3:	0e                   	push   cs
    2ec4:	57                   	push   di
    2ec5:	9a 4c 18 d6 2e       	call   0x2ed6:0x184c
    2eca:	8d be f4 fe          	lea    di,[bp-0x10c]
    2ece:	16                   	push   ss
    2ecf:	57                   	push   di
    2ed0:	68 ff 00             	push   0xff
    2ed3:	9a e7 17 f7 2e       	call   0x2ef7:0x17e7
    2ed8:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2edb:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2edf:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2ee4:	06                   	push   es
    2ee5:	57                   	push   di
    2ee6:	9a d2 21 4a 2f       	call   0x2f4a:0x21d2
    2eeb:	50                   	push   ax
    2eec:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2eef:	05 02 00             	add    ax,0x2
    2ef2:	71 05                	jno    0x2ef9
    2ef4:	9a 3e 04 05 2f       	call   0x2f05:0x43e
    2ef9:	50                   	push   ax
    2efa:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2efd:	05 02 00             	add    ax,0x2
    2f00:	71 05                	jno    0x2f07
    2f02:	9a 3e 04 27 2f       	call   0x2f27:0x43e
    2f07:	50                   	push   ax
    2f08:	6a 06                	push   0x6
    2f0a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2f0d:	81 c7 f8 ff          	add    di,0xfff8
    2f11:	16                   	push   ss
    2f12:	57                   	push   di
    2f13:	8d be f5 fe          	lea    di,[bp-0x10b]
    2f17:	16                   	push   ss
    2f18:	57                   	push   di
    2f19:	8a 86 f4 fe          	mov    al,BYTE PTR [bp-0x10c]
    2f1d:	30 e4                	xor    ah,ah
    2f1f:	2d 01 00             	sub    ax,0x1
    2f22:	71 05                	jno    0x2f29
    2f24:	9a 3e 04 72 2f       	call   0x2f72:0x43e
    2f29:	50                   	push   ax
    2f2a:	6a 00                	push   0x0
    2f2c:	6a 00                	push   0x0
    2f2e:	9a ff ff 00 00       	call   0x0:0xffff
    2f33:	6a 01                	push   0x1
    2f35:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2f38:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2f3c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f41:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2f45:	06                   	push   es
    2f46:	57                   	push   di
    2f47:	9a f5 14 63 2f       	call   0x2f63:0x14f5
    2f4c:	6a 04                	push   0x4
    2f4e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2f51:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2f55:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f5a:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2f5e:	06                   	push   es
    2f5f:	57                   	push   di
    2f60:	9a 73 14 d9 2f       	call   0x2fd9:0x1473
    2f65:	8b 86 ca fe          	mov    ax,WORD PTR [bp-0x136]
    2f69:	03 86 ee fe          	add    ax,WORD PTR [bp-0x112]
    2f6d:	71 05                	jno    0x2f74
    2f6f:	9a 3e 04 a3 2f       	call   0x2fa3:0x43e
    2f74:	89 86 c8 fe          	mov    WORD PTR [bp-0x138],ax
    2f78:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2f7b:	36 f6 45 0a 04       	test   BYTE PTR ss:[di+0xa],0x4
    2f80:	b0 00                	mov    al,0x0
    2f82:	74 01                	je     0x2f85
    2f84:	40                   	inc    ax
    2f85:	8a c8                	mov    cl,al
    2f87:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2f8a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2f8e:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2f93:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    2f98:	2d 01 00             	sub    ax,0x1
    2f9b:	83 da 00             	sbb    dx,0x0
    2f9e:	71 05                	jno    0x2fa5
    2fa0:	9a 3e 04 41 30       	call   0x3041:0x43e
    2fa5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2fa8:	36 3b 55 16          	cmp    dx,WORD PTR ss:[di+0x16]
    2fac:	75 06                	jne    0x2fb4
    2fae:	36 3b 45 14          	cmp    ax,WORD PTR ss:[di+0x14]
    2fb2:	74 04                	je     0x2fb8
    2fb4:	b0 00                	mov    al,0x0
    2fb6:	eb 02                	jmp    0x2fba
    2fb8:	b0 01                	mov    al,0x1
    2fba:	0a c1                	or     al,cl
    2fbc:	08 c0                	or     al,al
    2fbe:	74 1d                	je     0x2fdd
    2fc0:	6a 00                	push   0x0
    2fc2:	6a 00                	push   0x0
    2fc4:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2fc7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2fcb:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2fd0:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2fd4:	06                   	push   es
    2fd5:	57                   	push   di
    2fd6:	9a da 13 f8 2f       	call   0x2ff8:0x13da
    2fdb:	eb 1d                	jmp    0x2ffa
    2fdd:	68 c0 00             	push   0xc0
    2fe0:	68 c0 c0             	push   0xc0c0
    2fe3:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2fe6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2fea:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2fef:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2ff3:	06                   	push   es
    2ff4:	57                   	push   di
    2ff5:	9a da 13 1a 30       	call   0x301a:0x13da
    2ffa:	80 be e1 fe 00       	cmp    BYTE PTR [bp-0x11f],0x0
    2fff:	74 1b                	je     0x301c
    3001:	6a 00                	push   0x0
    3003:	6a 00                	push   0x0
    3005:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3008:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    300c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3011:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    3015:	06                   	push   es
    3016:	57                   	push   di
    3017:	9a da 13 77 30       	call   0x3077:0x13da
    301c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    301f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3023:	06                   	push   es
    3024:	57                   	push   di
    3025:	9a 52 6f 9f 30       	call   0x309f:0x6f52
    302a:	99                   	cwd
    302b:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    302e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3032:	26 03 85 13 01       	add    ax,WORD PTR es:[di+0x113]
    3037:	26 13 95 15 01       	adc    dx,WORD PTR es:[di+0x115]
    303c:	71 05                	jno    0x3043
    303e:	9a 3e 04 60 30       	call   0x3060:0x43e
    3043:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3046:	36 3b 55 16          	cmp    dx,WORD PTR ss:[di+0x16]
    304a:	7f 08                	jg     0x3054
    304c:	7c 71                	jl     0x30bf
    304e:	36 3b 45 14          	cmp    ax,WORD PTR ss:[di+0x14]
    3052:	76 6b                	jbe    0x30bf
    3054:	8b 86 c8 fe          	mov    ax,WORD PTR [bp-0x138]
    3058:	2d 01 00             	sub    ax,0x1
    305b:	71 05                	jno    0x3062
    305d:	9a 3e 04 85 30       	call   0x3085:0x43e
    3062:	50                   	push   ax
    3063:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3066:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3069:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    306d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3072:	06                   	push   es
    3073:	57                   	push   di
    3074:	9a b8 1d bd 30       	call   0x30bd:0x1db8
    3079:	8b 86 c8 fe          	mov    ax,WORD PTR [bp-0x138]
    307d:	2d 01 00             	sub    ax,0x1
    3080:	71 05                	jno    0x3087
    3082:	9a 3e 04 a9 30       	call   0x30a9:0x43e
    3087:	50                   	push   ax
    3088:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    308b:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    308f:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    3093:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3096:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    309a:	06                   	push   es
    309b:	57                   	push   di
    309c:	9a 8b 6e 6f 31       	call   0x316f:0x6e8b
    30a1:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    30a4:	71 05                	jno    0x30ab
    30a6:	9a 3e 04 ea 30       	call   0x30ea:0x43e
    30ab:	50                   	push   ax
    30ac:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    30af:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    30b3:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    30b8:	06                   	push   es
    30b9:	57                   	push   di
    30ba:	9a 7b 1d 20 31       	call   0x3120:0x1d7b
    30bf:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    30c2:	36 f6 45 0a 04       	test   BYTE PTR ss:[di+0xa],0x4
    30c7:	b0 00                	mov    al,0x0
    30c9:	74 01                	je     0x30cc
    30cb:	40                   	inc    ax
    30cc:	8a c8                	mov    cl,al
    30ce:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    30d1:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    30d5:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    30da:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    30df:	2d 01 00             	sub    ax,0x1
    30e2:	83 da 00             	sbb    dx,0x0
    30e5:	71 05                	jno    0x30ec
    30e7:	9a 3e 04 88 31       	call   0x3188:0x43e
    30ec:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    30ef:	36 3b 55 12          	cmp    dx,WORD PTR ss:[di+0x12]
    30f3:	75 06                	jne    0x30fb
    30f5:	36 3b 45 10          	cmp    ax,WORD PTR ss:[di+0x10]
    30f9:	74 04                	je     0x30ff
    30fb:	b0 00                	mov    al,0x0
    30fd:	eb 02                	jmp    0x3101
    30ff:	b0 01                	mov    al,0x1
    3101:	0a c1                	or     al,cl
    3103:	08 c0                	or     al,al
    3105:	74 1d                	je     0x3124
    3107:	6a 00                	push   0x0
    3109:	6a 00                	push   0x0
    310b:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    310e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3112:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3117:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    311b:	06                   	push   es
    311c:	57                   	push   di
    311d:	9a da 13 3f 31       	call   0x313f:0x13da
    3122:	eb 1d                	jmp    0x3141
    3124:	68 c0 00             	push   0xc0
    3127:	68 c0 c0             	push   0xc0c0
    312a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    312d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3131:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3136:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    313a:	06                   	push   es
    313b:	57                   	push   di
    313c:	9a da 13 61 31       	call   0x3161:0x13da
    3141:	80 be e0 fe 00       	cmp    BYTE PTR [bp-0x120],0x0
    3146:	74 1b                	je     0x3163
    3148:	6a 00                	push   0x0
    314a:	6a 00                	push   0x0
    314c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    314f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3153:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3158:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    315c:	06                   	push   es
    315d:	57                   	push   di
    315e:	9a da 13 e4 31       	call   0x31e4:0x13da
    3163:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3166:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    316a:	06                   	push   es
    316b:	57                   	push   di
    316c:	9a 88 6f bc 31       	call   0x31bc:0x6f88
    3171:	99                   	cwd
    3172:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3175:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3179:	26 03 85 17 01       	add    ax,WORD PTR es:[di+0x117]
    317e:	26 13 95 19 01       	adc    dx,WORD PTR es:[di+0x119]
    3183:	71 05                	jno    0x318a
    3185:	9a 3e 04 c6 31       	call   0x31c6:0x43e
    318a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    318d:	36 3b 55 12          	cmp    dx,WORD PTR ss:[di+0x12]
    3191:	7f 0e                	jg     0x31a1
    3193:	7d 03                	jge    0x3198
    3195:	e9 93 00             	jmp    0x322b
    3198:	36 3b 45 10          	cmp    ax,WORD PTR ss:[di+0x10]
    319c:	77 03                	ja     0x31a1
    319e:	e9 8a 00             	jmp    0x322b
    31a1:	ff b6 ca fe          	push   WORD PTR [bp-0x136]
    31a5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    31a8:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    31ac:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    31b0:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    31b3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    31b7:	06                   	push   es
    31b8:	57                   	push   di
    31b9:	9a 8b 6e 01 32       	call   0x3201:0x6e8b
    31be:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    31c1:	71 05                	jno    0x31c8
    31c3:	9a 3e 04 d0 31       	call   0x31d0:0x43e
    31c8:	2d 01 00             	sub    ax,0x1
    31cb:	71 05                	jno    0x31d2
    31cd:	9a 3e 04 0b 32       	call   0x320b:0x43e
    31d2:	50                   	push   ax
    31d3:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    31d6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    31da:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    31df:	06                   	push   es
    31e0:	57                   	push   di
    31e1:	9a b8 1d 29 32       	call   0x3229:0x1db8
    31e6:	ff b6 c8 fe          	push   WORD PTR [bp-0x138]
    31ea:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    31ed:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    31f1:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    31f5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    31f8:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    31fc:	06                   	push   es
    31fd:	57                   	push   di
    31fe:	9a 8b 6e e4 32       	call   0x32e4:0x6e8b
    3203:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    3206:	71 05                	jno    0x320d
    3208:	9a 3e 04 15 32       	call   0x3215:0x43e
    320d:	2d 01 00             	sub    ax,0x1
    3210:	71 05                	jno    0x3217
    3212:	9a 3e 04 9c 32       	call   0x329c:0x43e
    3217:	50                   	push   ax
    3218:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    321b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    321f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3224:	06                   	push   es
    3225:	57                   	push   di
    3226:	9a 7b 1d 42 32       	call   0x3242:0x1d7b
    322b:	6a 01                	push   0x1
    322d:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3230:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3234:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3239:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    323d:	06                   	push   es
    323e:	57                   	push   di
    323f:	9a f5 14 74 32       	call   0x3274:0x14f5
    3244:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3247:	36 f6 45 0a 04       	test   BYTE PTR ss:[di+0xa],0x4
    324c:	b0 00                	mov    al,0x0
    324e:	74 01                	je     0x3251
    3250:	40                   	inc    ax
    3251:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3254:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3258:	26 22 85 a5 00       	and    al,BYTE PTR es:[di+0xa5]
    325d:	08 c0                	or     al,al
    325f:	74 54                	je     0x32b5
    3261:	68 ff 00             	push   0xff
    3264:	6a ff                	push   0xffff
    3266:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    326b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    326f:	06                   	push   es
    3270:	57                   	push   di
    3271:	9a da 13 8e 32       	call   0x328e:0x13da
    3276:	ff b6 ca fe          	push   WORD PTR [bp-0x136]
    327a:	ff 76 f4             	push   WORD PTR [bp-0xc]
    327d:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3280:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3284:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3289:	06                   	push   es
    328a:	57                   	push   di
    328b:	9a b8 1d b3 32       	call   0x32b3:0x1db8
    3290:	8b 86 c8 fe          	mov    ax,WORD PTR [bp-0x138]
    3294:	2d 01 00             	sub    ax,0x1
    3297:	71 05                	jno    0x329e
    3299:	9a 3e 04 19 33       	call   0x3319:0x43e
    329e:	50                   	push   ax
    329f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    32a2:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    32a5:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    32a9:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    32ae:	06                   	push   es
    32af:	57                   	push   di
    32b0:	9a 7b 1d f7 32       	call   0x32f7:0x1d7b
    32b5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    32b8:	36 f6 45 0a 02       	test   BYTE PTR ss:[di+0xa],0x2
    32bd:	74 3a                	je     0x32f9
    32bf:	8d be be fe          	lea    di,[bp-0x142]
    32c3:	16                   	push   ss
    32c4:	57                   	push   di
    32c5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    32c8:	36 ff 75 16          	push   WORD PTR ss:[di+0x16]
    32cc:	36 ff 75 14          	push   WORD PTR ss:[di+0x14]
    32d0:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    32d4:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    32d8:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    32db:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    32df:	06                   	push   es
    32e0:	57                   	push   di
    32e1:	9a 35 7f 0f 34       	call   0x340f:0x7f35
    32e6:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    32e9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    32ed:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    32f2:	06                   	push   es
    32f3:	57                   	push   di
    32f4:	9a 66 1c 29 33       	call   0x3329:0x1c66
    32f9:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    32fc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3300:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3305:	89 be c2 fe          	mov    WORD PTR [bp-0x13e],di
    3309:	8c 86 c4 fe          	mov    WORD PTR [bp-0x13c],es
    330d:	8a 86 d7 fe          	mov    al,BYTE PTR [bp-0x129]
    3311:	98                   	cbw
    3312:	99                   	cwd
    3313:	bf ef 23             	mov    di,0x23ef
    3316:	9a 16 04 39 33       	call   0x3339:0x416
    331b:	50                   	push   ax
    331c:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    3320:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    3324:	06                   	push   es
    3325:	57                   	push   di
    3326:	9a 7c 17 4a 33       	call   0x334a:0x177c
    332b:	8b 86 dc fe          	mov    ax,WORD PTR [bp-0x124]
    332f:	8b 96 de fe          	mov    dx,WORD PTR [bp-0x122]
    3333:	bf e7 23             	mov    di,0x23e7
    3336:	9a 16 04 7f 33       	call   0x337f:0x416
    333b:	52                   	push   dx
    333c:	50                   	push   ax
    333d:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    3341:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    3345:	06                   	push   es
    3346:	57                   	push   di
    3347:	9a 84 16 5d 33       	call   0x335d:0x1684
    334c:	ff b6 d4 fe          	push   WORD PTR [bp-0x12c]
    3350:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    3354:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3358:	06                   	push   es
    3359:	57                   	push   di
    335a:	9a f5 11 71 33       	call   0x3371:0x11f5
    335f:	8a 86 d3 fe          	mov    al,BYTE PTR [bp-0x12d]
    3363:	50                   	push   ax
    3364:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    3368:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    336c:	06                   	push   es
    336d:	57                   	push   di
    336e:	9a 33 12 8f 33       	call   0x338f:0x1233
    3373:	8a 86 d2 fe          	mov    al,BYTE PTR [bp-0x12e]
    3377:	98                   	cbw
    3378:	99                   	cwd
    3379:	bf f7 23             	mov    di,0x23f7
    337c:	9a 16 04 9f 33       	call   0x339f:0x416
    3381:	50                   	push   ax
    3382:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    3386:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    338a:	06                   	push   es
    338b:	57                   	push   di
    338c:	9a 78 12 b0 33       	call   0x33b0:0x1278
    3391:	8b 86 ce fe          	mov    ax,WORD PTR [bp-0x132]
    3395:	8b 96 d0 fe          	mov    dx,WORD PTR [bp-0x130]
    3399:	bf e7 23             	mov    di,0x23e7
    339c:	9a 16 04 c7 33       	call   0x33c7:0x416
    33a1:	52                   	push   dx
    33a2:	50                   	push   ax
    33a3:	c4 be c2 fe          	les    di,DWORD PTR [bp-0x13e]
    33a7:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    33ab:	06                   	push   es
    33ac:	57                   	push   di
    33ad:	9a df 0f 88 36       	call   0x3688:0xfdf
    33b2:	c9                   	leave
    33b3:	ca 02 00             	retf   0x2
    33b6:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    33ba:	ff                   	(bad)
    33bb:	7f 00                	jg     0x33bd
    33bd:	00 55 89             	add    BYTE PTR [di-0x77],dl
    33c0:	e5 b8                	in     ax,0xb8
    33c2:	10 02                	adc    BYTE PTR [bp+si],al
    33c4:	9a 44 04 4e 34       	call   0x344e:0x444
    33c9:	81 ec 10 02          	sub    sp,0x210
    33cd:	8c d3                	mov    bx,ss
    33cf:	8e c3                	mov    es,bx
    33d1:	8c db                	mov    bx,ds
    33d3:	fc                   	cld
    33d4:	8d 7e f8             	lea    di,[bp-0x8]
    33d7:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    33da:	b9 08 00             	mov    cx,0x8
    33dd:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    33df:	8e db                	mov    ds,bx
    33e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e4:	26 80 bd 91 01 00    	cmp    BYTE PTR es:[di+0x191],0x0
    33ea:	74 06                	je     0x33f2
    33ec:	55                   	push   bp
    33ed:	9a 1d 24 99 34       	call   0x3499:0x241d
    33f2:	ff 76 16             	push   WORD PTR [bp+0x16]
    33f5:	ff 76 14             	push   WORD PTR [bp+0x14]
    33f8:	ff 76 12             	push   WORD PTR [bp+0x12]
    33fb:	ff 76 10             	push   WORD PTR [bp+0x10]
    33fe:	8d 7e f8             	lea    di,[bp-0x8]
    3401:	16                   	push   ss
    3402:	57                   	push   di
    3403:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3406:	50                   	push   ax
    3407:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    340a:	06                   	push   es
    340b:	57                   	push   di
    340c:	9a 71 97 42 34       	call   0x3442:0x9771
    3411:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3414:	26 8b 85 98 01       	mov    ax,WORD PTR es:[di+0x198]
    3419:	09 c0                	or     ax,ax
    341b:	75 03                	jne    0x3420
    341d:	e9 8a 00             	jmp    0x34aa
    3420:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    3424:	75 03                	jne    0x3429
    3426:	e9 81 00             	jmp    0x34aa
    3429:	8d 7e e8             	lea    di,[bp-0x18]
    342c:	16                   	push   ss
    342d:	57                   	push   di
    342e:	ff 76 16             	push   WORD PTR [bp+0x16]
    3431:	ff 76 14             	push   WORD PTR [bp+0x14]
    3434:	ff 76 12             	push   WORD PTR [bp+0x12]
    3437:	ff 76 10             	push   WORD PTR [bp+0x10]
    343a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    343d:	06                   	push   es
    343e:	57                   	push   di
    343f:	9a 35 7f 8a 34       	call   0x348a:0x7f35
    3444:	8d 7e f0             	lea    di,[bp-0x10]
    3447:	16                   	push   ss
    3448:	57                   	push   di
    3449:	6a 08                	push   0x8
    344b:	9a 1b 16 70 34       	call   0x3470:0x161b
    3450:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    3453:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    3456:	7d 52                	jge    0x34aa
    3458:	8d be f0 fd          	lea    di,[bp-0x210]
    345c:	16                   	push   ss
    345d:	57                   	push   di
    345e:	8d be f0 fe          	lea    di,[bp-0x110]
    3462:	16                   	push   ss
    3463:	57                   	push   di
    3464:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    3467:	8b 56 16             	mov    dx,WORD PTR [bp+0x16]
    346a:	bf b6 33             	mov    di,0x33b6
    346d:	9a 16 04 7f 34       	call   0x347f:0x416
    3472:	50                   	push   ax
    3473:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    3476:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    3479:	bf b6 33             	mov    di,0x33b6
    347c:	9a 16 04 e1 34       	call   0x34e1:0x416
    3481:	50                   	push   ax
    3482:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3485:	06                   	push   es
    3486:	57                   	push   di
    3487:	9a 68 9a f8 34       	call   0x34f8:0x9a68
    348c:	6a 00                	push   0x0
    348e:	68 00 7d             	push   0x7d00
    3491:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3494:	06                   	push   es
    3495:	57                   	push   di
    3496:	9a 2b 1f b4 35       	call   0x35b4:0x1f2b
    349b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    349e:	26 c4 bd 96 01       	les    di,DWORD PTR es:[di+0x196]
    34a3:	06                   	push   es
    34a4:	57                   	push   di
    34a5:	9a 8c 1d c8 34       	call   0x34c8:0x1d8c
    34aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ad:	26 8b 85 94 01       	mov    ax,WORD PTR es:[di+0x194]
    34b2:	09 c0                	or     ax,ax
    34b4:	74 14                	je     0x34ca
    34b6:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    34ba:	74 0e                	je     0x34ca
    34bc:	6a 00                	push   0x0
    34be:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    34c3:	06                   	push   es
    34c4:	57                   	push   di
    34c5:	9a 77 1c ee 35       	call   0x35ee:0x1c77
    34ca:	c9                   	leave
    34cb:	ca 12 00             	retf   0x12
    34ce:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    34d2:	ff                   	(bad)
    34d3:	7f 00                	jg     0x34d5
    34d5:	00 01                	add    BYTE PTR [bx+di],al
    34d7:	20 55 89             	and    BYTE PTR [di-0x77],dl
    34da:	e5 b8                	in     ax,0xb8
    34dc:	10 03                	adc    BYTE PTR [bp+di],al
    34de:	9a 44 04 56 35       	call   0x3556:0x444
    34e3:	81 ec 10 03          	sub    sp,0x310
    34e7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    34ea:	06                   	push   es
    34eb:	57                   	push   di
    34ec:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    34ef:	50                   	push   ax
    34f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34f3:	06                   	push   es
    34f4:	57                   	push   di
    34f5:	9a d1 5e 49 35       	call   0x3549:0x5ed1
    34fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34fd:	26 8b 85 94 01       	mov    ax,WORD PTR es:[di+0x194]
    3502:	09 c0                	or     ax,ax
    3504:	75 03                	jne    0x3509
    3506:	e9 08 03             	jmp    0x3811
    3509:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    350c:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    3510:	74 03                	je     0x3515
    3512:	e9 fc 02             	jmp    0x3811
    3515:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3518:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    351d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3522:	74 03                	je     0x3527
    3524:	e9 ea 02             	jmp    0x3811
    3527:	8d be e8 fe          	lea    di,[bp-0x118]
    352b:	16                   	push   ss
    352c:	57                   	push   di
    352d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3530:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    3535:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    353a:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    353f:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    3544:	06                   	push   es
    3545:	57                   	push   di
    3546:	9a 35 7f a5 35       	call   0x35a5:0x7f35
    354b:	8d be f4 fe          	lea    di,[bp-0x10c]
    354f:	16                   	push   ss
    3550:	57                   	push   di
    3551:	6a 08                	push   0x8
    3553:	9a 1b 16 84 35       	call   0x3584:0x161b
    3558:	8b 86 f4 fe          	mov    ax,WORD PTR [bp-0x10c]
    355c:	3b 86 f8 fe          	cmp    ax,WORD PTR [bp-0x108]
    3560:	75 03                	jne    0x3565
    3562:	e9 ac 02             	jmp    0x3811
    3565:	8d be f0 fc          	lea    di,[bp-0x310]
    3569:	16                   	push   ss
    356a:	57                   	push   di
    356b:	8d be f0 fd          	lea    di,[bp-0x210]
    356f:	16                   	push   ss
    3570:	57                   	push   di
    3571:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3574:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    3579:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    357e:	bf ce 34             	mov    di,0x34ce
    3581:	9a 16 04 9a 35       	call   0x359a:0x416
    3586:	50                   	push   ax
    3587:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    358a:	26 8b 85 f6 00       	mov    ax,WORD PTR es:[di+0xf6]
    358f:	26 8b 95 f8 00       	mov    dx,WORD PTR es:[di+0xf8]
    3594:	bf ce 34             	mov    di,0x34ce
    3597:	9a 16 04 c2 35       	call   0x35c2:0x416
    359c:	50                   	push   ax
    359d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35a0:	06                   	push   es
    35a1:	57                   	push   di
    35a2:	9a 68 9a 7e 38       	call   0x387e:0x9a68
    35a7:	6a 00                	push   0x0
    35a9:	68 00 7d             	push   0x7d00
    35ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35af:	06                   	push   es
    35b0:	57                   	push   di
    35b1:	9a 2b 1f ff ff       	call   0xffff:0x1f2b
    35b6:	8d be 00 ff          	lea    di,[bp-0x100]
    35ba:	16                   	push   ss
    35bb:	57                   	push   di
    35bc:	68 ff 00             	push   0xff
    35bf:	9a e7 17 29 36       	call   0x3629:0x17e7
    35c4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    35c9:	77 03                	ja     0x35ce
    35cb:	e9 43 02             	jmp    0x3811
    35ce:	8b 86 f4 fe          	mov    ax,WORD PTR [bp-0x10c]
    35d2:	8b 96 f6 fe          	mov    dx,WORD PTR [bp-0x10a]
    35d6:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    35da:	89 96 fe fe          	mov    WORD PTR [bp-0x102],dx
    35de:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    35e2:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    35e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35e9:	06                   	push   es
    35ea:	57                   	push   di
    35eb:	9a d4 19 11 36       	call   0x3611:0x19d4
    35f0:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    35f4:	89 96 fe fe          	mov    WORD PTR [bp-0x102],dx
    35f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35fb:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3600:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3604:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    3608:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    360c:	06                   	push   es
    360d:	57                   	push   di
    360e:	9a 06 1a 4d 36       	call   0x364d:0x1a06
    3613:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    3617:	89 96 fe fe          	mov    WORD PTR [bp-0x102],dx
    361b:	8d be f0 fd          	lea    di,[bp-0x210]
    361f:	16                   	push   ss
    3620:	57                   	push   di
    3621:	bf d6 34             	mov    di,0x34d6
    3624:	0e                   	push   cs
    3625:	57                   	push   di
    3626:	9a cd 17 34 36       	call   0x3634:0x17cd
    362b:	8d be 00 ff          	lea    di,[bp-0x100]
    362f:	16                   	push   ss
    3630:	57                   	push   di
    3631:	9a 4c 18 3e 36       	call   0x363e:0x184c
    3636:	bf d6 34             	mov    di,0x34d6
    3639:	0e                   	push   cs
    363a:	57                   	push   di
    363b:	9a 4c 18 e4 36       	call   0x36e4:0x184c
    3640:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3643:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3648:	06                   	push   es
    3649:	57                   	push   di
    364a:	9a 8c 1d 9d 36       	call   0x369d:0x1d8c
    364f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3652:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3657:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    365b:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    365f:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    3663:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    3667:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    366b:	89 96 f2 fe          	mov    WORD PTR [bp-0x10e],dx
    366f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3672:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3677:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    367b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    367f:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3683:	06                   	push   es
    3684:	57                   	push   di
    3685:	9a 99 20 a8 36       	call   0x36a8:0x2099
    368a:	8d be ec fd          	lea    di,[bp-0x214]
    368e:	16                   	push   ss
    368f:	57                   	push   di
    3690:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3693:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3698:	06                   	push   es
    3699:	57                   	push   di
    369a:	9a 53 1d b8 36       	call   0x36b8:0x1d53
    369f:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    36a3:	06                   	push   es
    36a4:	57                   	push   di
    36a5:	9a 03 20 d8 36       	call   0x36d8:0x2003
    36aa:	50                   	push   ax
    36ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ae:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    36b3:	06                   	push   es
    36b4:	57                   	push   di
    36b5:	9a bf 17 cd 36       	call   0x36cd:0x17bf
    36ba:	8d be ec fd          	lea    di,[bp-0x214]
    36be:	16                   	push   ss
    36bf:	57                   	push   di
    36c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36c3:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    36c8:	06                   	push   es
    36c9:	57                   	push   di
    36ca:	9a 53 1d fa 36       	call   0x36fa:0x1d53
    36cf:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    36d3:	06                   	push   es
    36d4:	57                   	push   di
    36d5:	9a 4e 20 0d 37       	call   0x370d:0x204e
    36da:	b9 03 00             	mov    cx,0x3
    36dd:	f7 e9                	imul   cx
    36df:	71 05                	jno    0x36e6
    36e1:	9a 3e 04 3b 37       	call   0x373b:0x43e
    36e6:	99                   	cwd
    36e7:	b9 02 00             	mov    cx,0x2
    36ea:	f7 f9                	idiv   cx
    36ec:	50                   	push   ax
    36ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36f0:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    36f5:	06                   	push   es
    36f6:	57                   	push   di
    36f7:	9a e1 17 28 37       	call   0x3728:0x17e1
    36fc:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    3700:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    3704:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3708:	06                   	push   es
    3709:	57                   	push   di
    370a:	9a 99 20 ff ff       	call   0xffff:0x2099
    370f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3712:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3717:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
    371b:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
    371f:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    3723:	06                   	push   es
    3724:	57                   	push   di
    3725:	9a 7b 17 47 37       	call   0x3747:0x177b
    372a:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    372e:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3732:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    3736:	71 05                	jno    0x373d
    3738:	9a 3e 04 60 37       	call   0x3760:0x43e
    373d:	50                   	push   ax
    373e:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3742:	06                   	push   es
    3743:	57                   	push   di
    3744:	9a 9d 17 6c 37       	call   0x376c:0x179d
    3749:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    374d:	26 83 7d 20 00       	cmp    WORD PTR es:[di+0x20],0x0
    3752:	7d 1c                	jge    0x3770
    3754:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    3758:	05 08 00             	add    ax,0x8
    375b:	71 05                	jno    0x3762
    375d:	9a 3e 04 92 37       	call   0x3792:0x43e
    3762:	50                   	push   ax
    3763:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3767:	06                   	push   es
    3768:	57                   	push   di
    3769:	9a 9d 17 7d 37       	call   0x377d:0x179d
    376e:	eb d9                	jmp    0x3749
    3770:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3774:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3778:	06                   	push   es
    3779:	57                   	push   di
    377a:	9a a9 18 b4 37       	call   0x37b4:0x18a9
    377f:	8b d0                	mov    dx,ax
    3781:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    3785:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3789:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    378d:	71 05                	jno    0x3794
    378f:	9a 3e 04 a8 37       	call   0x37a8:0x43e
    3794:	3b c2                	cmp    ax,dx
    3796:	7e 20                	jle    0x37b8
    3798:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    379c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    37a0:	2d 08 00             	sub    ax,0x8
    37a3:	71 05                	jno    0x37aa
    37a5:	9a 3e 04 da 37       	call   0x37da:0x43e
    37aa:	50                   	push   ax
    37ab:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    37af:	06                   	push   es
    37b0:	57                   	push   di
    37b1:	9a 7b 17 c5 37       	call   0x37c5:0x177b
    37b6:	eb b8                	jmp    0x3770
    37b8:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    37bc:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    37c0:	06                   	push   es
    37c1:	57                   	push   di
    37c2:	9a f4 18 fc 37       	call   0x37fc:0x18f4
    37c7:	8b d0                	mov    dx,ax
    37c9:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    37cd:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    37d1:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    37d5:	71 05                	jno    0x37dc
    37d7:	9a 3e 04 f0 37       	call   0x37f0:0x43e
    37dc:	3b c2                	cmp    ax,dx
    37de:	7e 20                	jle    0x3800
    37e0:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    37e4:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    37e8:	2d 08 00             	sub    ax,0x8
    37eb:	71 05                	jno    0x37f2
    37ed:	9a 3e 04 1d 38       	call   0x381d:0x43e
    37f2:	50                   	push   ax
    37f3:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
    37f7:	06                   	push   es
    37f8:	57                   	push   di
    37f9:	9a 9d 17 0f 38       	call   0x380f:0x179d
    37fe:	eb b8                	jmp    0x37b8
    3800:	6a 01                	push   0x1
    3802:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3805:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    380a:	06                   	push   es
    380b:	57                   	push   di
    380c:	9a 77 1c 30 38       	call   0x3830:0x1c77
    3811:	c9                   	leave
    3812:	ca 0a 00             	retf   0xa
    3815:	55                   	push   bp
    3816:	89 e5                	mov    bp,sp
    3818:	31 c0                	xor    ax,ax
    381a:	9a 44 04 65 38       	call   0x3865:0x444
    381f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3822:	06                   	push   es
    3823:	57                   	push   di
    3824:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3827:	50                   	push   ax
    3828:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    382b:	06                   	push   es
    382c:	57                   	push   di
    382d:	9a fe 50 56 38       	call   0x3856:0x50fe
    3832:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3835:	26 8b 85 94 01       	mov    ax,WORD PTR es:[di+0x194]
    383a:	09 c0                	or     ax,ax
    383c:	74 1a                	je     0x3858
    383e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3841:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    3845:	75 11                	jne    0x3858
    3847:	6a 00                	push   0x0
    3849:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    384c:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3851:	06                   	push   es
    3852:	57                   	push   di
    3853:	9a 77 1c 9b 38       	call   0x389b:0x1c77
    3858:	c9                   	leave
    3859:	ca 0a 00             	retf   0xa
    385c:	55                   	push   bp
    385d:	89 e5                	mov    bp,sp
    385f:	b8 02 00             	mov    ax,0x2
    3862:	9a 44 04 ad 38       	call   0x38ad:0x444
    3867:	83 ec 02             	sub    sp,0x2
    386a:	ff 76 10             	push   WORD PTR [bp+0x10]
    386d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3870:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3873:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3876:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3879:	06                   	push   es
    387a:	57                   	push   di
    387b:	9a a1 80 ba 38       	call   0x38ba:0x80a1
    3880:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3883:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3886:	26 8b 85 94 01       	mov    ax,WORD PTR es:[di+0x194]
    388b:	09 c0                	or     ax,ax
    388d:	74 0e                	je     0x389d
    388f:	6a 00                	push   0x0
    3891:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3896:	06                   	push   es
    3897:	57                   	push   di
    3898:	9a 77 1c 0e 39       	call   0x390e:0x1c77
    389d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    38a0:	c9                   	leave
    38a1:	ca 0c 00             	retf   0xc
    38a4:	55                   	push   bp
    38a5:	89 e5                	mov    bp,sp
    38a7:	b8 10 00             	mov    ax,0x10
    38aa:	9a 44 04 f5 38       	call   0x38f5:0x444
    38af:	83 ec 10             	sub    sp,0x10
    38b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b5:	06                   	push   es
    38b6:	57                   	push   di
    38b7:	9a 76 81 e9 38       	call   0x38e9:0x8176
    38bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38bf:	26 8b 85 94 01       	mov    ax,WORD PTR es:[di+0x194]
    38c4:	09 c0                	or     ax,ax
    38c6:	74 48                	je     0x3910
    38c8:	8d 7e f0             	lea    di,[bp-0x10]
    38cb:	16                   	push   ss
    38cc:	57                   	push   di
    38cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38d0:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    38d5:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    38da:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    38df:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    38e4:	06                   	push   es
    38e5:	57                   	push   di
    38e6:	9a 35 7f ff ff       	call   0xffff:0x7f35
    38eb:	8d 7e f8             	lea    di,[bp-0x8]
    38ee:	16                   	push   ss
    38ef:	57                   	push   di
    38f0:	6a 08                	push   0x8
    38f2:	9a 1b 16 ff ff       	call   0xffff:0x161b
    38f7:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    38fa:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    38fd:	75 11                	jne    0x3910
    38ff:	6a 00                	push   0x0
    3901:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3904:	26 c4 bd 92 01       	les    di,DWORD PTR es:[di+0x192]
    3909:	06                   	push   es
    390a:	57                   	push   di
    390b:	9a 77 1c ff ff       	call   0xffff:0x1c77
    3910:	c9                   	leave
    3911:	ca                   	.byte 0xca
    3912:	04                   	.byte 0x4
