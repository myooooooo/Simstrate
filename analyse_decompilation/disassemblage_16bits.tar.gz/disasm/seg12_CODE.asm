; ================================================================
; seg12_CODE  (31975 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	0c 00                	or     al,0x0
       2:	94                   	xchg   sp,ax
       3:	1c 46                	sbb    al,0x46
       5:	03 af 00 00          	add    bp,WORD PTR [bx+0x0]
       9:	00 9e 00 2e          	add    BYTE PTR [bp+0x2e00],bl
       d:	08 fb                	or     bl,bh
       f:	04 ac                	add    al,0xac
      11:	1c 39                	sbb    al,0x39
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f bf 1c cb       	call   0xcb1c:0xbf1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 75 29             	adc    BYTE PTR [di+0x29],dh
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 71                	sbb    al,0x71
      61:	1d e2 2f             	sbb    ax,0x2fe2
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	10 54 46             	adc    BYTE PTR [si+0x46],dl
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	43                   	inc    bx
      a8:	5f                   	pop    di
      a9:	43                   	inc    bx
      aa:	6f                   	outs   dx,WORD PTR ds:[si]
      ab:	6d                   	ins    WORD PTR es:[di],dx
      ac:	70 74                	jo     0x122
      ae:	65 22 00             	and    al,BYTE PTR gs:[bx+si]
      b1:	2b 1f                	sub    bx,WORD PTR [bx]
      b3:	c6 00 0e             	mov    BYTE PTR [bx+si],0xe
      b6:	49                   	dec    cx
      b7:	6d                   	ins    WORD PTR es:[di],dx
      b8:	70 72                	jo     0x12c
      ba:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      bf:	43                   	inc    bx
      c0:	6c                   	ins    BYTE PTR es:[di],dx
      c1:	69 63 6b 2c 39       	imul   sp,WORD PTR [bp+di+0x6b],0x392c
      c6:	d8 00                	fadd   DWORD PTR [bx+si]
      c8:	0d 51 75             	or     ax,0x7551
      cb:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
      d0:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      d3:	69 63 6b 90 55       	imul   sp,WORD PTR [bp+di+0x6b],0x5590
      d8:	e8 00 0b             	call   0xbdb
      db:	46                   	inc    si
      dc:	6f                   	outs   dx,WORD PTR ds:[si]
      dd:	72 6d                	jb     0x14c
      df:	4b                   	dec    bx
      e0:	65 79 44             	gs jns 0x127
      e3:	6f                   	outs   dx,WORD PTR ds:[si]
      e4:	77 6e                	ja     0x154
      e6:	7b 34                	jnp    0x11c
      e8:	f7 00 0a 46          	test   WORD PTR [bx+si],0x460a
      ec:	6f                   	outs   dx,WORD PTR ds:[si]
      ed:	72 6d                	jb     0x15c
      ef:	43                   	inc    bx
      f0:	72 65                	jb     0x157
      f2:	61                   	popa
      f3:	74 65                	je     0x15a
      f5:	6d                   	ins    WORD PTR es:[di],dx
      f6:	3a 0c                	cmp    cl,BYTE PTR [si]
      f8:	01 10                	add    WORD PTR [bx+si],dx
      fa:	50                   	push   ax
      fb:	6c                   	ins    BYTE PTR es:[di],dx
      fc:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     102:	61                   	popa
     103:	6e                   	outs   dx,BYTE PTR ds:[si]
     104:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     107:	69 63 6b 0d 39       	imul   sp,WORD PTR [bp+di+0x6b],0x390d
     10c:	1a 01                	sbb    al,BYTE PTR [bx+di]
     10e:	09 46 6f             	or     WORD PTR [bp+0x6f],ax
     111:	72 6d                	jb     0x180
     113:	43                   	inc    bx
     114:	6c                   	ins    BYTE PTR es:[di],dx
     115:	6f                   	outs   dx,WORD PTR ds:[si]
     116:	73 65                	jae    0x17d
     118:	9d                   	popf
     119:	3a 29                	cmp    ch,BYTE PTR [bx+di]
     11b:	01 0a                	add    WORD PTR [bp+si],cx
     11d:	46                   	inc    si
     11e:	6f                   	outs   dx,WORD PTR ds:[si]
     11f:	72 6d                	jb     0x18e
     121:	52                   	push   dx
     122:	65 73 69             	gs jae 0x18e
     125:	7a 65                	jp     0x18c
     127:	c7                   	(bad)
     128:	57                   	push   di
     129:	41                   	inc    cx
     12a:	01 13                	add    WORD PTR [bp+di],dx
     12c:	55                   	push   bp
     12d:	74 69                	je     0x198
     12f:	6c                   	ins    BYTE PTR es:[di],dx
     130:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     135:	61                   	popa
     136:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     13b:	6c                   	ins    BYTE PTR es:[di],dx
     13c:	69 63 6b 87 57       	imul   sp,WORD PTR [bp+di+0x6b],0x5787
     141:	51                   	push   cx
     142:	01 0b                	add    WORD PTR [bp+di],cx
     144:	49                   	dec    cx
     145:	6e                   	outs   dx,BYTE PTR ds:[si]
     146:	64 65 78 31          	fs gs js 0x17b
     14a:	43                   	inc    bx
     14b:	6c                   	ins    BYTE PTR es:[di],dx
     14c:	69 63 6b a6 57       	imul   sp,WORD PTR [bp+di+0x6b],0x57a6
     151:	66 01 10             	add    DWORD PTR [bx+si],edx
     154:	52                   	push   dx
     155:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     159:	72 63                	jb     0x1be
     15b:	68 65 72             	push   0x7265
     15e:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     161:	69 63 6b af 3c       	imul   sp,WORD PTR [bp+di+0x6b],0x3caf
     166:	7d 01                	jge    0x169
     168:	12 42 61             	adc    al,BYTE PTR [bp+si+0x61]
     16b:	72 72                	jb     0x1df
     16d:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     170:	75 74                	jne    0x1e6
     172:	69 6c 73 31 43       	imul   bp,WORD PTR [si+0x73],0x4331
     177:	6c                   	ins    BYTE PTR es:[di],dx
     178:	69 63 6b e6 57       	imul   sp,WORD PTR [bp+di+0x6b],0x57e6
     17d:	8f 01                	pop    WORD PTR [bx+di]
     17f:	0d 41 70             	or     ax,0x7041
     182:	72 6f                	jb     0x1f3
     184:	70 6f                	jo     0x1f5
     186:	73 31                	jae    0x1b9
     188:	43                   	inc    bx
     189:	6c                   	ins    BYTE PTR es:[di],dx
     18a:	69 63 6b 45 3e       	imul   sp,WORD PTR [bp+di+0x6b],0x3e45
     18f:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     190:	01 13                	add    WORD PTR [bp+di],dx
     192:	54                   	push   sp
     193:	61                   	popa
     194:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     197:	45                   	inc    bp
     198:	52                   	push   dx
     199:	50                   	push   ax
     19a:	31 43 61             	xor    WORD PTR [bp+di+0x61],ax
     19d:	6c                   	ins    BYTE PTR es:[di],dx
     19e:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     1a1:	65 6c                	gs ins BYTE PTR es:[di],dx
     1a3:	64 73 34             	fs jae 0x1da
     1a6:	47                   	inc    di
     1a7:	be 01 12             	mov    si,0x1201
     1aa:	54                   	push   sp
     1ab:	61                   	popa
     1ac:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1af:	45                   	inc    bp
     1b0:	52                   	push   dx
     1b1:	47                   	inc    di
     1b2:	43                   	inc    bx
     1b3:	61                   	popa
     1b4:	6c                   	ins    BYTE PTR es:[di],dx
     1b5:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     1b8:	65 6c                	gs ins BYTE PTR es:[di],dx
     1ba:	64 73 c6             	fs jae 0x183
     1bd:	3a d0                	cmp    dl,al
     1bf:	01 0d                	add    WORD PTR [di],cx
     1c1:	50                   	push   ax
     1c2:	65 72 69             	gs jb  0x22e
     1c5:	6f                   	outs   dx,WORD PTR ds:[si]
     1c6:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     1cb:	69 63 6b 0b 3c       	imul   sp,WORD PTR [bp+di+0x6b],0x3c0b
     1d0:	dd 01                	fld    QWORD PTR [bx+di]
     1d2:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     1d5:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     1d8:	69 63 6b 9c 24       	imul   sp,WORD PTR [bp+di+0x6b],0x249c
     1dd:	ed                   	in     ax,dx
     1de:	01 0b                	add    WORD PTR [bp+di],cx
     1e0:	44                   	inc    sp
     1e1:	42                   	inc    dx
     1e2:	45                   	inc    bp
     1e3:	64 69 74 31 45 78    	imul   si,WORD PTR fs:[si+0x31],0x7845
     1e9:	69 74 4c 25 00       	imul   si,WORD PTR [si+0x4c],0x25
     1ee:	02 0e 44 42          	add    cl,BYTE PTR ds:0x4244
     1f2:	45                   	inc    bp
     1f3:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1f9:	79 44                	jns    0x23f
     1fb:	6f                   	outs   dx,WORD PTR ds:[si]
     1fc:	77 6e                	ja     0x26c
     1fe:	e9 24 11             	jmp    0x1325
     201:	02 0c                	add    cl,BYTE PTR [si]
     203:	44                   	inc    sp
     204:	42                   	inc    dx
     205:	45                   	inc    bp
     206:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     20c:	79 55                	jns    0x263
     20e:	70 f2                	jo     0x202
     210:	38 1e 02 08          	cmp    BYTE PTR ds:0x802,bl
     214:	46                   	inc    si
     215:	6f                   	outs   dx,WORD PTR ds:[si]
     216:	72 6d                	jb     0x285
     218:	53                   	push   bx
     219:	68 6f 77             	push   0x776f
     21c:	7e 58                	jle    0x276
     21e:	33 02                	xor    ax,WORD PTR [bp+si]
     220:	10 44 42             	adc    BYTE PTR [si+0x42],al
     223:	45                   	inc    bp
     224:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     22a:	75 73                	jne    0x29f
     22c:	65 44                	gs inc sp
     22e:	6f                   	outs   dx,WORD PTR ds:[si]
     22f:	77 6e                	ja     0x29f
     231:	5c                   	pop    sp
     232:	57                   	push   di
     233:	43                   	inc    bx
     234:	02 0b                	add    cl,BYTE PTR [bp+di]
     236:	46                   	inc    si
     237:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     23c:	43                   	inc    bx
     23d:	6c                   	ins    BYTE PTR es:[di],dx
     23e:	69 63 6b 89 5e       	imul   sp,WORD PTR [bp+di+0x6b],0x5e89
     243:	54                   	push   sp
     244:	02 0c                	add    cl,BYTE PTR [si]
     246:	43                   	inc    bx
     247:	6f                   	outs   dx,WORD PTR ds:[si]
     248:	70 69                	jo     0x2b3
     24a:	65 72 31             	gs jb  0x27e
     24d:	43                   	inc    bx
     24e:	6c                   	ins    BYTE PTR es:[di],dx
     24f:	69 63 6b 35 59       	imul   sp,WORD PTR [bp+di+0x6b],0x5935
     254:	69 02 10 50          	imul   ax,WORD PTR [bp+si],0x5010
     258:	61                   	popa
     259:	6e                   	outs   dx,BYTE PTR ds:[si]
     25a:	65 6c                	gs ins BYTE PTR es:[di],dx
     25c:	31 34                	xor    WORD PTR [si],si
     25e:	4d                   	dec    bp
     25f:	6f                   	outs   dx,WORD PTR ds:[si]
     260:	75 73                	jne    0x2d5
     262:	65 44                	gs inc sp
     264:	6f                   	outs   dx,WORD PTR ds:[si]
     265:	77 6e                	ja     0x2d5
     267:	b0 7b                	mov    al,0x7b
     269:	7d 02                	jge    0x26d
     26b:	0f 53 69 74          	rcpps  xmm5,XMMWORD PTR [bx+di+0x74]
     26f:	75 61                	jne    0x2d2
     271:	74 69                	je     0x2dc
     273:	6f                   	outs   dx,WORD PTR ds:[si]
     274:	6e                   	outs   dx,BYTE PTR ds:[si]
     275:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     278:	69 63 6b de 7b       	imul   sp,WORD PTR [bp+di+0x6b],0x7bde
     27d:	99                   	cwd
     27e:	02 17                	add    dl,BYTE PTR [bx]
     280:	43                   	inc    bx
     281:	6f                   	outs   dx,WORD PTR ds:[si]
     282:	6d                   	ins    WORD PTR es:[di],dx
     283:	70 74                	jo     0x2f9
     285:	65 44                	gs inc sp
     287:	65 52                	gs push dx
     289:	65 73 75             	gs jae 0x301
     28c:	6c                   	ins    BYTE PTR es:[di],dx
     28d:	74 61                	je     0x2f0
     28f:	74 73                	je     0x304
     291:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     294:	69 63 6b 0c 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c0c
     299:	a9 02 0b             	test   ax,0xb02
     29c:	42                   	inc    dx
     29d:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
     2a2:	43                   	inc    bx
     2a3:	6c                   	ins    BYTE PTR es:[di],dx
     2a4:	69 63 6b 3a 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c3a
     2a9:	c8 02 1a 54          	enter  0x1a02,0x54
     2ad:	61                   	popa
     2ae:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2b1:	61                   	popa
     2b2:	75 44                	jne    0x2f8
     2b4:	65 46                	gs inc si
     2b6:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     2bb:	65 6d                	gs ins WORD PTR es:[di],dx
     2bd:	65 6e                	outs   dx,BYTE PTR gs:[si]
     2bf:	74 31                	je     0x2f2
     2c1:	43                   	inc    bx
     2c2:	6c                   	ins    BYTE PTR es:[di],dx
     2c3:	69 63 6b 68 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c68
     2c8:	e6 02                	out    0x2,al
     2ca:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     2cd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2d0:	61                   	popa
     2d1:	75 44                	jne    0x317
     2d3:	65 54                	gs push sp
     2d5:	72 65                	jb     0x33c
     2d7:	73 6f                	jae    0x348
     2d9:	72 65                	jb     0x340
     2db:	72 69                	jb     0x346
     2dd:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2e1:	69 63 6b c4 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7cc4
     2e6:	03 03                	add    ax,WORD PTR [bp+di]
     2e8:	18 52 61             	sbb    BYTE PTR [bp+si+0x61],dl
     2eb:	70 70                	jo     0x35d
     2ed:	65 6c                	gs ins BYTE PTR es:[di],dx
     2ef:	44                   	inc    sp
     2f0:	65 73 44             	gs jae 0x337
     2f3:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     2f7:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     2fc:	43                   	inc    bx
     2fd:	6c                   	ins    BYTE PTR es:[di],dx
     2fe:	69 63 6b 50 39       	imul   sp,WORD PTR [bp+di+0x6b],0x3950
     303:	12 03                	adc    al,BYTE PTR [bp+di]
     305:	0a 4e 31             	or     cl,BYTE PTR [bp+0x31]
     308:	30 30                	xor    BYTE PTR [bx+si],dh
     30a:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     30d:	69 63 6b 9e 59       	imul   sp,WORD PTR [bp+di+0x6b],0x599e
     312:	2d 03 16             	sub    ax,0x1603
     315:	49                   	dec    cx
     316:	6d                   	ins    WORD PTR es:[di],dx
     317:	70 72                	jo     0x38b
     319:	65 73 73             	gs jae 0x38f
     31c:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     321:	70 69                	jo     0x38c
     323:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     328:	69 63 6b 0d 3b       	imul   sp,WORD PTR [bp+di+0x6b],0x3b0d
     32d:	3a 03                	cmp    al,BYTE PTR [bp+di]
     32f:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     332:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     335:	69 63 6b 96 7c       	imul   sp,WORD PTR [bp+di+0x6b],0x7c96
     33a:	a8 1c                	test   al,0x1c
     33c:	09 53 49             	or     WORD PTR [bp+di+0x49],dx
     33f:	47                   	inc    di
     340:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     343:	69 63 6b 6b 01       	imul   sp,WORD PTR [bp+di+0x6b],0x16b
     348:	5a                   	pop    dx
     349:	1c 7c                	sbb    al,0x7c
     34b:	01 00                	add    WORD PTR [bx+si],ax
     34d:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     351:	6e                   	outs   dx,BYTE PTR ds:[si]
     352:	65 6c                	gs ins BYTE PTR es:[di],dx
     354:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     358:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     35c:	6e                   	outs   dx,BYTE PTR ds:[si]
     35d:	65 6c                	gs ins BYTE PTR es:[di],dx
     35f:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     363:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     367:	6e                   	outs   dx,BYTE PTR ds:[si]
     368:	65 6c                	gs ins BYTE PTR es:[di],dx
     36a:	35 88 01             	xor    ax,0x188
     36d:	00 00                	add    BYTE PTR [bx+si],al
     36f:	06                   	push   es
     370:	50                   	push   ax
     371:	61                   	popa
     372:	6e                   	outs   dx,BYTE PTR ds:[si]
     373:	65 6c                	gs ins BYTE PTR es:[di],dx
     375:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     379:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     37d:	6e                   	outs   dx,BYTE PTR ds:[si]
     37e:	65 6c                	gs ins BYTE PTR es:[di],dx
     380:	36 90                	ss nop
     382:	01 00                	add    WORD PTR [bx+si],ax
     384:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     388:	6e                   	outs   dx,BYTE PTR ds:[si]
     389:	65 6c                	gs ins BYTE PTR es:[di],dx
     38b:	37                   	aaa
     38c:	94                   	xchg   sp,ax
     38d:	01 00                	add    WORD PTR [bx+si],ax
     38f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     393:	6e                   	outs   dx,BYTE PTR ds:[si]
     394:	65 6c                	gs ins BYTE PTR es:[di],dx
     396:	38 98 01 00          	cmp    BYTE PTR [bx+si+0x1],bl
     39a:	00 07                	add    BYTE PTR [bx],al
     39c:	50                   	push   ax
     39d:	61                   	popa
     39e:	6e                   	outs   dx,BYTE PTR ds:[si]
     39f:	65 6c                	gs ins BYTE PTR es:[di],dx
     3a1:	33 37                	xor    si,WORD PTR [bx]
     3a3:	9c                   	pushf
     3a4:	01 00                	add    WORD PTR [bx+si],ax
     3a6:	00 07                	add    BYTE PTR [bx],al
     3a8:	50                   	push   ax
     3a9:	61                   	popa
     3aa:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ab:	65 6c                	gs ins BYTE PTR es:[di],dx
     3ad:	33 38                	xor    di,WORD PTR [bx+si]
     3af:	a0 01 04             	mov    al,ds:0x401
     3b2:	00 09                	add    BYTE PTR [bx+di],cl
     3b4:	4d                   	dec    bp
     3b5:	61                   	popa
     3b6:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     3bb:	75 31                	jne    0x3ee
     3bd:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     3be:	01 08                	add    WORD PTR [bx+si],cx
     3c0:	00 08                	add    BYTE PTR [bx+si],cl
     3c2:	46                   	inc    si
     3c3:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     3c8:	72 31                	jb     0x3fb
     3ca:	a8 01                	test   al,0x1
     3cc:	08 00                	or     BYTE PTR [bx+si],al
     3ce:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     3d1:	70 72                	jo     0x445
     3d3:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     3d8:	ac                   	lods   al,BYTE PTR ds:[si]
     3d9:	01 08                	add    WORD PTR [bx+si],cx
     3db:	00 02                	add    BYTE PTR [bp+si],al
     3dd:	4e                   	dec    si
     3de:	31 b0 01 08          	xor    WORD PTR [bx+si+0x801],si
     3e2:	00 08                	add    BYTE PTR [bx+si],cl
     3e4:	51                   	push   cx
     3e5:	75 69                	jne    0x450
     3e7:	74 74                	je     0x45d
     3e9:	65 72 31             	gs jb  0x41d
     3ec:	b4 01                	mov    ah,0x1
     3ee:	08 00                	or     BYTE PTR [bx+si],al
     3f0:	0a 41 66             	or     al,BYTE PTR [bx+di+0x66]
     3f3:	66 69 63 68 61 67 65 	imul   esp,DWORD PTR [bp+di+0x68],0x31656761
     3fa:	31 
     3fb:	b8 01 08             	mov    ax,0x801
     3fe:	00 05                	add    BYTE PTR [di],al
     400:	41                   	inc    cx
     401:	69 64 65 31 bc       	imul   sp,WORD PTR [si+0x65],0xbc31
     406:	01 08                	add    WORD PTR [bx+si],cx
     408:	00 08                	add    BYTE PTR [bx+si],cl
     40a:	41                   	inc    cx
     40b:	70 72                	jo     0x47f
     40d:	6f                   	outs   dx,WORD PTR ds:[si]
     40e:	70 6f                	jo     0x47f
     410:	73 31                	jae    0x443
     412:	c0 01 08             	rol    BYTE PTR [bx+di],0x8
     415:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     419:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     41e:	72 6c                	jb     0x48c
     420:	61                   	popa
     421:	69 64 65 31 c4       	imul   sp,WORD PTR [si+0x65],0xc431
     426:	01 08                	add    WORD PTR [bx+si],cx
     428:	00 0b                	add    BYTE PTR [bp+di],cl
     42a:	52                   	push   dx
     42b:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     42f:	72 63                	jb     0x494
     431:	68 65 72             	push   0x7265
     434:	31 c8                	xor    ax,cx
     436:	01 08                	add    WORD PTR [bx+si],cx
     438:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     43c:	64 65 78 31          	fs gs js 0x471
     440:	cc                   	int3
     441:	01 08                	add    WORD PTR [bx+si],cx
     443:	00 0d                	add    BYTE PTR [di],cl
     445:	42                   	inc    dx
     446:	61                   	popa
     447:	72 72                	jb     0x4bb
     449:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     44c:	75 74                	jne    0x4c2
     44e:	69 6c 73 31 d0       	imul   bp,WORD PTR [si+0x73],0xd031
     453:	01 08                	add    WORD PTR [bx+si],cx
     455:	00 0b                	add    BYTE PTR [bp+di],cl
     457:	50                   	push   ax
     458:	6c                   	ins    BYTE PTR es:[di],dx
     459:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     45f:	61                   	popa
     460:	6e                   	outs   dx,BYTE PTR ds:[si]
     461:	31 d4                	xor    sp,dx
     463:	01 08                	add    WORD PTR [bx+si],cx
     465:	00 02                	add    BYTE PTR [bp+si],al
     467:	4e                   	dec    si
     468:	32 d8                	xor    bl,al
     46a:	01 08                	add    WORD PTR [bx+si],cx
     46c:	00 05                	add    BYTE PTR [di],al
     46e:	5a                   	pop    dx
     46f:	6f                   	outs   dx,WORD PTR ds:[si]
     470:	6f                   	outs   dx,WORD PTR ds:[si]
     471:	6d                   	ins    WORD PTR es:[di],dx
     472:	31 dc                	xor    sp,bx
     474:	01 0c                	add    WORD PTR [si],cx
     476:	00 08                	add    BYTE PTR [bx+si],cl
     478:	54                   	push   sp
     479:	61                   	popa
     47a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     47d:	41                   	inc    cx
     47e:	44                   	inc    sp
     47f:	47                   	inc    di
     480:	e0 01                	loopne 0x483
     482:	0c 00                	or     al,0x0
     484:	09 54 61             	or     WORD PTR [si+0x61],dx
     487:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     48a:	41                   	inc    cx
     48b:	44                   	inc    sp
     48c:	50                   	push   ax
     48d:	31 e4                	xor    sp,sp
     48f:	01 0c                	add    WORD PTR [si],cx
     491:	00 09                	add    BYTE PTR [bx+di],cl
     493:	54                   	push   sp
     494:	61                   	popa
     495:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     498:	41                   	inc    cx
     499:	44                   	inc    sp
     49a:	50                   	push   ax
     49b:	32 e8                	xor    ch,al
     49d:	01 0c                	add    WORD PTR [si],cx
     49f:	00 0c                	add    BYTE PTR [si],cl
     4a1:	54                   	push   sp
     4a2:	61                   	popa
     4a3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4a6:	45                   	inc    bp
     4a7:	52                   	push   dx
     4a8:	47                   	inc    di
     4a9:	5f                   	pop    di
     4aa:	6f                   	outs   dx,WORD PTR ds:[si]
     4ab:	6c                   	ins    BYTE PTR es:[di],dx
     4ac:	64 ec                	fs in  al,dx
     4ae:	01 0c                	add    WORD PTR [si],cx
     4b0:	00 0d                	add    BYTE PTR [di],cl
     4b2:	54                   	push   sp
     4b3:	61                   	popa
     4b4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4b7:	45                   	inc    bp
     4b8:	52                   	push   dx
     4b9:	50                   	push   ax
     4ba:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     4bd:	6c                   	ins    BYTE PTR es:[di],dx
     4be:	64 f0 01 0c          	lock add WORD PTR fs:[si],cx
     4c2:	00 0d                	add    BYTE PTR [di],cl
     4c4:	54                   	push   sp
     4c5:	61                   	popa
     4c6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4c9:	45                   	inc    bp
     4ca:	52                   	push   dx
     4cb:	50                   	push   ax
     4cc:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     4cf:	6c                   	ins    BYTE PTR es:[di],dx
     4d0:	64 f4                	fs hlt
     4d2:	01 0c                	add    WORD PTR [si],cx
     4d4:	00 08                	add    BYTE PTR [bx+si],cl
     4d6:	54                   	push   sp
     4d7:	61                   	popa
     4d8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4db:	45                   	inc    bp
     4dc:	44                   	inc    sp
     4dd:	47                   	inc    di
     4de:	f8                   	clc
     4df:	01 0c                	add    WORD PTR [si],cx
     4e1:	00 09                	add    BYTE PTR [bx+di],cl
     4e3:	54                   	push   sp
     4e4:	61                   	popa
     4e5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4e8:	45                   	inc    bp
     4e9:	44                   	inc    sp
     4ea:	50                   	push   ax
     4eb:	31 fc                	xor    sp,di
     4ed:	01 0c                	add    WORD PTR [si],cx
     4ef:	00 09                	add    BYTE PTR [bx+di],cl
     4f1:	54                   	push   sp
     4f2:	61                   	popa
     4f3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4f6:	45                   	inc    bp
     4f7:	44                   	inc    sp
     4f8:	50                   	push   ax
     4f9:	32 00                	xor    al,BYTE PTR [bx+si]
     4fb:	02 0c                	add    cl,BYTE PTR [si]
     4fd:	00 08                	add    BYTE PTR [bx+si],cl
     4ff:	54                   	push   sp
     500:	61                   	popa
     501:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     504:	45                   	inc    bp
     505:	52                   	push   dx
     506:	47                   	inc    di
     507:	04 02                	add    al,0x2
     509:	0c 00                	or     al,0x0
     50b:	09 54 61             	or     WORD PTR [si+0x61],dx
     50e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     511:	45                   	inc    bp
     512:	52                   	push   dx
     513:	50                   	push   ax
     514:	31 08                	xor    WORD PTR [bx+si],cx
     516:	02 0c                	add    cl,BYTE PTR [si]
     518:	00 09                	add    BYTE PTR [bx+di],cl
     51a:	54                   	push   sp
     51b:	61                   	popa
     51c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     51f:	45                   	inc    bp
     520:	52                   	push   dx
     521:	50                   	push   ax
     522:	32 0c                	xor    cl,BYTE PTR [si]
     524:	02 10                	add    dl,BYTE PTR [bx+si]
     526:	00 18                	add    BYTE PTR [bx+si],bl
     528:	54                   	push   sp
     529:	61                   	popa
     52a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     52d:	45                   	inc    bp
     52e:	52                   	push   dx
     52f:	47                   	inc    di
     530:	50                   	push   ax
     531:	72 6f                	jb     0x5a2
     533:	64 75 63             	fs jne 0x599
     536:	74 69                	je     0x5a1
     538:	6f                   	outs   dx,WORD PTR ds:[si]
     539:	6e                   	outs   dx,BYTE PTR ds:[si]
     53a:	56                   	push   si
     53b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     53d:	64 75 65             	fs jne 0x5a5
     540:	10 02                	adc    BYTE PTR [bp+si],al
     542:	10 00                	adc    BYTE PTR [bx+si],al
     544:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     547:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     54a:	45                   	inc    bp
     54b:	52                   	push   dx
     54c:	47                   	inc    di
     54d:	50                   	push   ax
     54e:	72 6f                	jb     0x5bf
     550:	64 75 63             	fs jne 0x5b6
     553:	74 69                	je     0x5be
     555:	6f                   	outs   dx,WORD PTR ds:[si]
     556:	6e                   	outs   dx,BYTE PTR ds:[si]
     557:	53                   	push   bx
     558:	74 6f                	je     0x5c9
     55a:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
     55d:	65 14 02             	gs adc al,0x2
     560:	10 00                	adc    BYTE PTR [bx+si],al
     562:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     565:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     568:	45                   	inc    bp
     569:	52                   	push   dx
     56a:	50                   	push   ax
     56b:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     56e:	6f                   	outs   dx,WORD PTR ds:[si]
     56f:	64 75 63             	fs jne 0x5d5
     572:	74 69                	je     0x5dd
     574:	6f                   	outs   dx,WORD PTR ds:[si]
     575:	6e                   	outs   dx,BYTE PTR ds:[si]
     576:	56                   	push   si
     577:	65 6e                	outs   dx,BYTE PTR gs:[si]
     579:	64 75 65             	fs jne 0x5e1
     57c:	18 02                	sbb    BYTE PTR [bp+si],al
     57e:	10 00                	adc    BYTE PTR [bx+si],al
     580:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     583:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     586:	45                   	inc    bp
     587:	52                   	push   dx
     588:	50                   	push   ax
     589:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     58c:	6f                   	outs   dx,WORD PTR ds:[si]
     58d:	64 75 63             	fs jne 0x5f3
     590:	74 69                	je     0x5fb
     592:	6f                   	outs   dx,WORD PTR ds:[si]
     593:	6e                   	outs   dx,BYTE PTR ds:[si]
     594:	53                   	push   bx
     595:	74 6f                	je     0x606
     597:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
     59a:	65 1c 02             	gs sbb al,0x2
     59d:	10 00                	adc    BYTE PTR [bx+si],al
     59f:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     5a2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5a5:	45                   	inc    bp
     5a6:	52                   	push   dx
     5a7:	50                   	push   ax
     5a8:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     5ab:	6f                   	outs   dx,WORD PTR ds:[si]
     5ac:	64 75 63             	fs jne 0x612
     5af:	74 69                	je     0x61a
     5b1:	6f                   	outs   dx,WORD PTR ds:[si]
     5b2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5b3:	56                   	push   si
     5b4:	65 6e                	outs   dx,BYTE PTR gs:[si]
     5b6:	64 75 65             	fs jne 0x61e
     5b9:	20 02                	and    BYTE PTR [bp+si],al
     5bb:	10 00                	adc    BYTE PTR [bx+si],al
     5bd:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     5c0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5c3:	45                   	inc    bp
     5c4:	52                   	push   dx
     5c5:	50                   	push   ax
     5c6:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     5c9:	6f                   	outs   dx,WORD PTR ds:[si]
     5ca:	64 75 63             	fs jne 0x630
     5cd:	74 69                	je     0x638
     5cf:	6f                   	outs   dx,WORD PTR ds:[si]
     5d0:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d1:	53                   	push   bx
     5d2:	74 6f                	je     0x643
     5d4:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
     5d7:	65 24 02             	gs and al,0x2
     5da:	10 00                	adc    BYTE PTR [bx+si],al
     5dc:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     5df:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5e2:	45                   	inc    bp
     5e3:	52                   	push   dx
     5e4:	47                   	inc    di
     5e5:	50                   	push   ax
     5e6:	72 6f                	jb     0x657
     5e8:	64 75 63             	fs jne 0x64e
     5eb:	74 69                	je     0x656
     5ed:	6f                   	outs   dx,WORD PTR ds:[si]
     5ee:	6e                   	outs   dx,BYTE PTR ds:[si]
     5ef:	56                   	push   si
     5f0:	61                   	popa
     5f1:	6c                   	ins    BYTE PTR es:[di],dx
     5f2:	65 75 72             	gs jne 0x667
     5f5:	28 02                	sub    BYTE PTR [bp+si],al
     5f7:	10 00                	adc    BYTE PTR [bx+si],al
     5f9:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     5fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ff:	45                   	inc    bp
     600:	52                   	push   dx
     601:	50                   	push   ax
     602:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     605:	6f                   	outs   dx,WORD PTR ds:[si]
     606:	64 75 63             	fs jne 0x66c
     609:	74 69                	je     0x674
     60b:	6f                   	outs   dx,WORD PTR ds:[si]
     60c:	6e                   	outs   dx,BYTE PTR ds:[si]
     60d:	56                   	push   si
     60e:	61                   	popa
     60f:	6c                   	ins    BYTE PTR es:[di],dx
     610:	65 75 72             	gs jne 0x685
     613:	2c 02                	sub    al,0x2
     615:	10 00                	adc    BYTE PTR [bx+si],al
     617:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     61a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     61d:	45                   	inc    bp
     61e:	52                   	push   dx
     61f:	50                   	push   ax
     620:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     623:	6f                   	outs   dx,WORD PTR ds:[si]
     624:	64 75 63             	fs jne 0x68a
     627:	74 69                	je     0x692
     629:	6f                   	outs   dx,WORD PTR ds:[si]
     62a:	6e                   	outs   dx,BYTE PTR ds:[si]
     62b:	56                   	push   si
     62c:	61                   	popa
     62d:	6c                   	ins    BYTE PTR es:[di],dx
     62e:	65 75 72             	gs jne 0x6a3
     631:	30 02                	xor    BYTE PTR [bp+si],al
     633:	10 00                	adc    BYTE PTR [bx+si],al
     635:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     638:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     63b:	45                   	inc    bp
     63c:	52                   	push   dx
     63d:	47                   	inc    di
     63e:	50                   	push   ax
     63f:	72 6f                	jb     0x6b0
     641:	64 75 69             	fs jne 0x6ad
     644:	74 45                	je     0x68b
     646:	78 70                	js     0x6b8
     648:	6c                   	ins    BYTE PTR es:[di],dx
     649:	6f                   	outs   dx,WORD PTR ds:[si]
     64a:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     64f:	6f                   	outs   dx,WORD PTR ds:[si]
     650:	6e                   	outs   dx,BYTE PTR ds:[si]
     651:	34 02                	xor    al,0x2
     653:	14 00                	adc    al,0x0
     655:	0d 44 61             	or     ax,0x6144
     658:	74 61                	je     0x6bb
     65a:	53                   	push   bx
     65b:	6f                   	outs   dx,WORD PTR ds:[si]
     65c:	75 72                	jne    0x6d0
     65e:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     661:	52                   	push   dx
     662:	47                   	inc    di
     663:	38 02                	cmp    BYTE PTR [bp+si],al
     665:	14 00                	adc    al,0x0
     667:	0e                   	push   cs
     668:	44                   	inc    sp
     669:	61                   	popa
     66a:	74 61                	je     0x6cd
     66c:	53                   	push   bx
     66d:	6f                   	outs   dx,WORD PTR ds:[si]
     66e:	75 72                	jne    0x6e2
     670:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     673:	52                   	push   dx
     674:	50                   	push   ax
     675:	31 3c                	xor    WORD PTR [si],di
     677:	02 14                	add    dl,BYTE PTR [si]
     679:	00 0e 44 61          	add    BYTE PTR ds:0x6144,cl
     67d:	74 61                	je     0x6e0
     67f:	53                   	push   bx
     680:	6f                   	outs   dx,WORD PTR ds:[si]
     681:	75 72                	jne    0x6f5
     683:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     686:	52                   	push   dx
     687:	50                   	push   ax
     688:	32 40 02             	xor    al,BYTE PTR [bx+si+0x2]
     68b:	14 00                	adc    al,0x0
     68d:	0d 44 61             	or     ax,0x6144
     690:	74 61                	je     0x6f3
     692:	53                   	push   bx
     693:	6f                   	outs   dx,WORD PTR ds:[si]
     694:	75 72                	jne    0x708
     696:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     699:	44                   	inc    sp
     69a:	47                   	inc    di
     69b:	44                   	inc    sp
     69c:	02 10                	add    dl,BYTE PTR [bx+si]
     69e:	00 1b                	add    BYTE PTR [bp+di],bl
     6a0:	54                   	push   sp
     6a1:	61                   	popa
     6a2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a5:	45                   	inc    bp
     6a6:	52                   	push   dx
     6a7:	47                   	inc    di
     6a8:	43                   	inc    bx
     6a9:	6f                   	outs   dx,WORD PTR ds:[si]
     6aa:	6e                   	outs   dx,BYTE PTR ds:[si]
     6ab:	73 6f                	jae    0x71c
     6ad:	6d                   	ins    WORD PTR es:[di],dx
     6ae:	6d                   	ins    WORD PTR es:[di],dx
     6af:	61                   	popa
     6b0:	74 69                	je     0x71b
     6b2:	6f                   	outs   dx,WORD PTR ds:[si]
     6b3:	6e                   	outs   dx,BYTE PTR ds:[si]
     6b4:	4d                   	dec    bp
     6b5:	61                   	popa
     6b6:	74 69                	je     0x721
     6b8:	65 72 65             	gs jb  0x720
     6bb:	48                   	dec    ax
     6bc:	02 14                	add    dl,BYTE PTR [si]
     6be:	00 0e 44 61          	add    BYTE PTR ds:0x6144,cl
     6c2:	74 61                	je     0x725
     6c4:	53                   	push   bx
     6c5:	6f                   	outs   dx,WORD PTR ds:[si]
     6c6:	75 72                	jne    0x73a
     6c8:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     6cb:	44                   	inc    sp
     6cc:	50                   	push   ax
     6cd:	31 4c 02             	xor    WORD PTR [si+0x2],cx
     6d0:	14 00                	adc    al,0x0
     6d2:	0e                   	push   cs
     6d3:	44                   	inc    sp
     6d4:	61                   	popa
     6d5:	74 61                	je     0x738
     6d7:	53                   	push   bx
     6d8:	6f                   	outs   dx,WORD PTR ds:[si]
     6d9:	75 72                	jne    0x74d
     6db:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     6de:	44                   	inc    sp
     6df:	50                   	push   ax
     6e0:	32 50 02             	xor    dl,BYTE PTR [bx+si+0x2]
     6e3:	10 00                	adc    BYTE PTR [bx+si],al
     6e5:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     6e8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6eb:	45                   	inc    bp
     6ec:	52                   	push   dx
     6ed:	47                   	inc    di
     6ee:	4d                   	dec    bp
     6ef:	61                   	popa
     6f0:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
     6f5:	76 72                	jbe    0x769
     6f7:	65 44                	gs inc sp
     6f9:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
     6fe:	65 54                	gs push sp
     700:	02 10                	add    dl,BYTE PTR [bx+si]
     702:	00 11                	add    BYTE PTR [bx+di],dl
     704:	54                   	push   sp
     705:	61                   	popa
     706:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     709:	45                   	inc    bp
     70a:	52                   	push   dx
     70b:	47                   	inc    di
     70c:	43                   	inc    bx
     70d:	6f                   	outs   dx,WORD PTR ds:[si]
     70e:	75 74                	jne    0x784
     710:	53                   	push   bx
     711:	74 6f                	je     0x782
     713:	63 6b 58             	arpl   WORD PTR [bp+di+0x58],bp
     716:	02 10                	add    dl,BYTE PTR [bx+si]
     718:	00 12                	add    BYTE PTR [bp+si],dl
     71a:	54                   	push   sp
     71b:	61                   	popa
     71c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     71f:	45                   	inc    bp
     720:	52                   	push   dx
     721:	50                   	push   ax
     722:	31 43 6f             	xor    WORD PTR [bp+di+0x6f],ax
     725:	75 74                	jne    0x79b
     727:	53                   	push   bx
     728:	74 6f                	je     0x799
     72a:	63 6b 5c             	arpl   WORD PTR [bp+di+0x5c],bp
     72d:	02 10                	add    dl,BYTE PTR [bx+si]
     72f:	00 12                	add    BYTE PTR [bp+si],dl
     731:	54                   	push   sp
     732:	61                   	popa
     733:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     736:	45                   	inc    bp
     737:	52                   	push   dx
     738:	50                   	push   ax
     739:	32 43 6f             	xor    al,BYTE PTR [bp+di+0x6f]
     73c:	75 74                	jne    0x7b2
     73e:	53                   	push   bx
     73f:	74 6f                	je     0x7b0
     741:	63 6b 60             	arpl   WORD PTR [bp+di+0x60],bp
     744:	02 10                	add    dl,BYTE PTR [bx+si]
     746:	00 19                	add    BYTE PTR [bx+di],bl
     748:	54                   	push   sp
     749:	61                   	popa
     74a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     74d:	45                   	inc    bp
     74e:	52                   	push   dx
     74f:	47                   	inc    di
     750:	52                   	push   dx
     751:	65 73 75             	gs jae 0x7c9
     754:	6c                   	ins    BYTE PTR es:[di],dx
     755:	74 61                	je     0x7b8
     757:	74 46                	je     0x79f
     759:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     75e:	69 65 72 64 02       	imul   sp,WORD PTR [di+0x72],0x264
     763:	10 00                	adc    BYTE PTR [bx+si],al
     765:	1c 54                	sbb    al,0x54
     767:	61                   	popa
     768:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     76b:	45                   	inc    bp
     76c:	52                   	push   dx
     76d:	47                   	inc    di
     76e:	52                   	push   dx
     76f:	65 73 75             	gs jae 0x7e7
     772:	6c                   	ins    BYTE PTR es:[di],dx
     773:	74 61                	je     0x7d6
     775:	74 45                	je     0x7bc
     777:	78 70                	js     0x7e9
     779:	6c                   	ins    BYTE PTR es:[di],dx
     77a:	6f                   	outs   dx,WORD PTR ds:[si]
     77b:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     780:	6f                   	outs   dx,WORD PTR ds:[si]
     781:	6e                   	outs   dx,BYTE PTR ds:[si]
     782:	68 02 10             	push   0x1002
     785:	00 1a                	add    BYTE PTR [bp+si],bl
     787:	54                   	push   sp
     788:	61                   	popa
     789:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     78c:	45                   	inc    bp
     78d:	52                   	push   dx
     78e:	47                   	inc    di
     78f:	52                   	push   dx
     790:	65 73 75             	gs jae 0x808
     793:	6c                   	ins    BYTE PTR es:[di],dx
     794:	74 61                	je     0x7f7
     796:	74 41                	je     0x7d9
     798:	76 61                	jbe    0x7fb
     79a:	6e                   	outs   dx,BYTE PTR ds:[si]
     79b:	74 49                	je     0x7e6
     79d:	6d                   	ins    WORD PTR es:[di],dx
     79e:	70 6f                	jo     0x80f
     7a0:	74 6c                	je     0x80e
     7a2:	02 10                	add    dl,BYTE PTR [bx+si]
     7a4:	00 1a                	add    BYTE PTR [bp+si],bl
     7a6:	54                   	push   sp
     7a7:	61                   	popa
     7a8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7ab:	45                   	inc    bp
     7ac:	52                   	push   dx
     7ad:	47                   	inc    di
     7ae:	43                   	inc    bx
     7af:	68 61 72             	push   0x7261
     7b2:	67 65 45             	addr32 gs inc bp
     7b5:	78 70                	js     0x827
     7b7:	6c                   	ins    BYTE PTR es:[di],dx
     7b8:	6f                   	outs   dx,WORD PTR ds:[si]
     7b9:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     7be:	6f                   	outs   dx,WORD PTR ds:[si]
     7bf:	6e                   	outs   dx,BYTE PTR ds:[si]
     7c0:	70 02                	jo     0x7c4
     7c2:	10 00                	adc    BYTE PTR [bx+si],al
     7c4:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     7c7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7ca:	45                   	inc    bp
     7cb:	52                   	push   dx
     7cc:	50                   	push   ax
     7cd:	31 43 68             	xor    WORD PTR [bp+di+0x68],ax
     7d0:	61                   	popa
     7d1:	72 67                	jb     0x83a
     7d3:	65 45                	gs inc bp
     7d5:	78 70                	js     0x847
     7d7:	6c                   	ins    BYTE PTR es:[di],dx
     7d8:	6f                   	outs   dx,WORD PTR ds:[si]
     7d9:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     7de:	6f                   	outs   dx,WORD PTR ds:[si]
     7df:	6e                   	outs   dx,BYTE PTR ds:[si]
     7e0:	74 02                	je     0x7e4
     7e2:	10 00                	adc    BYTE PTR [bx+si],al
     7e4:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     7e7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7ea:	45                   	inc    bp
     7eb:	52                   	push   dx
     7ec:	50                   	push   ax
     7ed:	32 43 68             	xor    al,BYTE PTR [bp+di+0x68]
     7f0:	61                   	popa
     7f1:	72 67                	jb     0x85a
     7f3:	65 45                	gs inc bp
     7f5:	78 70                	js     0x867
     7f7:	6c                   	ins    BYTE PTR es:[di],dx
     7f8:	6f                   	outs   dx,WORD PTR ds:[si]
     7f9:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     7fe:	6f                   	outs   dx,WORD PTR ds:[si]
     7ff:	6e                   	outs   dx,BYTE PTR ds:[si]
     800:	78 02                	js     0x804
     802:	10 00                	adc    BYTE PTR [bx+si],al
     804:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     807:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     80a:	45                   	inc    bp
     80b:	52                   	push   dx
     80c:	47                   	inc    di
     80d:	50                   	push   ax
     80e:	72 6f                	jb     0x87f
     810:	64 75 69             	fs jne 0x87c
     813:	74 46                	je     0x85b
     815:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     81a:	69 65 72 7c 02       	imul   sp,WORD PTR [di+0x72],0x27c
     81f:	10 00                	adc    BYTE PTR [bx+si],al
     821:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     824:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     827:	45                   	inc    bp
     828:	52                   	push   dx
     829:	47                   	inc    di
     82a:	43                   	inc    bx
     82b:	68 61 72             	push   0x7261
     82e:	67 65 46             	addr32 gs inc si
     831:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     836:	69 65 72 65 80       	imul   sp,WORD PTR [di+0x72],0x8065
     83b:	02 08                	add    cl,BYTE PTR [bx+si]
     83d:	00 08                	add    BYTE PTR [bx+si],cl
     83f:	50                   	push   ax
     840:	65 72 69             	gs jb  0x8ac
     843:	6f                   	outs   dx,WORD PTR ds:[si]
     844:	64 65 31 84 02 08    	fs xor WORD PTR gs:[si+0x802],ax
     84a:	00 0b                	add    BYTE PTR [bp+di],cl
     84c:	45                   	inc    bp
     84d:	6e                   	outs   dx,BYTE PTR ds:[si]
     84e:	74 72                	je     0x8c2
     850:	65 70 72             	gs jo  0x8c5
     853:	69 73 65 31 88       	imul   si,WORD PTR [bp+di+0x65],0x8831
     858:	02 18                	add    bl,BYTE PTR [bx+si]
     85a:	00 0c                	add    BYTE PTR [si],cl
     85c:	50                   	push   ax
     85d:	72 69                	jb     0x8c8
     85f:	6e                   	outs   dx,BYTE PTR ds:[si]
     860:	74 44                	je     0x8a6
     862:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     867:	31 8c 02 10          	xor    WORD PTR [si+0x1002],cx
     86b:	00 18                	add    BYTE PTR [bx+si],bl
     86d:	54                   	push   sp
     86e:	61                   	popa
     86f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     872:	45                   	inc    bp
     873:	52                   	push   dx
     874:	47                   	inc    di
     875:	44                   	inc    sp
     876:	6f                   	outs   dx,WORD PTR ds:[si]
     877:	74 41                	je     0x8ba
     879:	6d                   	ins    WORD PTR es:[di],dx
     87a:	6f                   	outs   dx,WORD PTR ds:[si]
     87b:	72 74                	jb     0x8f1
     87d:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     882:	65 6e                	outs   dx,BYTE PTR gs:[si]
     884:	74 90                	je     0x816
     886:	02 08                	add    cl,BYTE PTR [bx+si]
     888:	00 03                	add    BYTE PTR [bp+di],al
     88a:	4e                   	dec    si
     88b:	31 31                	xor    WORD PTR [bx+di],si
     88d:	94                   	xchg   sp,ax
     88e:	02 08                	add    cl,BYTE PTR [bx+si]
     890:	00 03                	add    BYTE PTR [bp+di],al
     892:	4e                   	dec    si
     893:	32 31                	xor    dh,BYTE PTR [bx+di]
     895:	98                   	cbw
     896:	02 08                	add    cl,BYTE PTR [bx+si]
     898:	00 03                	add    BYTE PTR [bp+di],al
     89a:	4e                   	dec    si
     89b:	33 31                	xor    si,WORD PTR [bx+di]
     89d:	9c                   	pushf
     89e:	02 08                	add    cl,BYTE PTR [bx+si]
     8a0:	00 03                	add    BYTE PTR [bp+di],al
     8a2:	4e                   	dec    si
     8a3:	34 31                	xor    al,0x31
     8a5:	a0 02 08             	mov    al,ds:0x802
     8a8:	00 03                	add    BYTE PTR [bp+di],al
     8aa:	4e                   	dec    si
     8ab:	35 31 a4             	xor    ax,0xa431
     8ae:	02 08                	add    cl,BYTE PTR [bx+si]
     8b0:	00 03                	add    BYTE PTR [bp+di],al
     8b2:	4e                   	dec    si
     8b3:	36 31 a8 02 08       	xor    WORD PTR ss:[bx+si+0x802],bp
     8b8:	00 03                	add    BYTE PTR [bp+di],al
     8ba:	4e                   	dec    si
     8bb:	37                   	aaa
     8bc:	31 ac 02 08          	xor    WORD PTR [si+0x802],bp
     8c0:	00 03                	add    BYTE PTR [bp+di],al
     8c2:	4e                   	dec    si
     8c3:	38 31                	cmp    BYTE PTR [bx+di],dh
     8c5:	b0 02                	mov    al,0x2
     8c7:	00 00                	add    BYTE PTR [bx+si],al
     8c9:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     8cc:	6e                   	outs   dx,BYTE PTR ds:[si]
     8cd:	65 6c                	gs ins BYTE PTR es:[di],dx
     8cf:	4c                   	dec    sp
     8d0:	4f                   	dec    di
     8d1:	55                   	push   bp
     8d2:	50                   	push   ax
     8d3:	45                   	inc    bp
     8d4:	b4 02                	mov    ah,0x2
     8d6:	10 00                	adc    BYTE PTR [bx+si],al
     8d8:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     8db:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8de:	45                   	inc    bp
     8df:	52                   	push   dx
     8e0:	47                   	inc    di
     8e1:	52                   	push   dx
     8e2:	65 73 75             	gs jae 0x95a
     8e5:	6c                   	ins    BYTE PTR es:[di],dx
     8e6:	74 61                	je     0x949
     8e8:	74 41                	je     0x92b
     8ea:	70 72                	jo     0x95e
     8ec:	65 73 49             	gs jae 0x938
     8ef:	6d                   	ins    WORD PTR es:[di],dx
     8f0:	70 6f                	jo     0x961
     8f2:	74 b8                	je     0x8ac
     8f4:	02 1c                	add    bl,BYTE PTR [si]
     8f6:	00 11                	add    BYTE PTR [bx+di],dl
     8f8:	54                   	push   sp
     8f9:	61                   	popa
     8fa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8fd:	45                   	inc    bp
     8fe:	52                   	push   dx
     8ff:	47                   	inc    di
     900:	50                   	push   ax
     901:	65 72 69             	gs jb  0x96d
     904:	6f                   	outs   dx,WORD PTR ds:[si]
     905:	64 65 4e             	fs gs dec si
     908:	6f                   	outs   dx,WORD PTR ds:[si]
     909:	bc 02 1c             	mov    sp,0x1c02
     90c:	00 14                	add    BYTE PTR [si],dl
     90e:	54                   	push   sp
     90f:	61                   	popa
     910:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     913:	45                   	inc    bp
     914:	52                   	push   dx
     915:	47                   	inc    di
     916:	45                   	inc    bp
     917:	6e                   	outs   dx,BYTE PTR ds:[si]
     918:	74 72                	je     0x98c
     91a:	65 70 72             	gs jo  0x98f
     91d:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     922:	c0 02 20             	rol    BYTE PTR [bp+si],0x20
     925:	00 15                	add    BYTE PTR [di],dl
     927:	54                   	push   sp
     928:	61                   	popa
     929:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     92c:	45                   	inc    bp
     92d:	52                   	push   dx
     92e:	47                   	inc    di
     92f:	43                   	inc    bx
     930:	61                   	popa
     931:	70 69                	jo     0x99c
     933:	74 61                	je     0x996
     935:	6c                   	ins    BYTE PTR es:[di],dx
     936:	53                   	push   bx
     937:	6f                   	outs   dx,WORD PTR ds:[si]
     938:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     93b:	6c                   	ins    BYTE PTR es:[di],dx
     93c:	c4 02                	les    ax,DWORD PTR [bp+si]
     93e:	20 00                	and    BYTE PTR [bx+si],al
     940:	10 54 61             	adc    BYTE PTR [si+0x61],dl
     943:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     946:	45                   	inc    bp
     947:	52                   	push   dx
     948:	47                   	inc    di
     949:	52                   	push   dx
     94a:	65 73 65             	gs jae 0x9b2
     94d:	72 76                	jb     0x9c5
     94f:	65 73 c8             	gs jae 0x91a
     952:	02 20                	add    ah,BYTE PTR [bx+si]
     954:	00 13                	add    BYTE PTR [bp+di],dl
     956:	54                   	push   sp
     957:	61                   	popa
     958:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     95b:	45                   	inc    bp
     95c:	52                   	push   dx
     95d:	47                   	inc    di
     95e:	52                   	push   dx
     95f:	65 73 75             	gs jae 0x9d7
     962:	6c                   	ins    BYTE PTR es:[di],dx
     963:	74 61                	je     0x9c6
     965:	74 4e                	je     0x9b5
     967:	65 74 cc             	gs je  0x936
     96a:	02 20                	add    ah,BYTE PTR [bx+si]
     96c:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     970:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     973:	45                   	inc    bp
     974:	52                   	push   dx
     975:	47                   	inc    di
     976:	53                   	push   bx
     977:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     97c:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     981:	74 74                	je     0x9f7
     983:	65 d0 02             	rol    BYTE PTR gs:[bp+si],1
     986:	20 00                	and    BYTE PTR [bx+si],al
     988:	0b 54 61             	or     dx,WORD PTR [si+0x61]
     98b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     98e:	45                   	inc    bp
     98f:	52                   	push   dx
     990:	47                   	inc    di
     991:	43                   	inc    bx
     992:	41                   	inc    cx
     993:	46                   	inc    si
     994:	d4 02                	aam    0x2
     996:	20 00                	and    BYTE PTR [bx+si],al
     998:	0d 54 61             	or     ax,0x6154
     99b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     99e:	45                   	inc    bp
     99f:	52                   	push   dx
     9a0:	47                   	inc    di
     9a1:	49                   	dec    cx
     9a2:	6d                   	ins    WORD PTR es:[di],dx
     9a3:	70 6f                	jo     0xa14
     9a5:	74 d8                	je     0x97f
     9a7:	02 20                	add    ah,BYTE PTR [bx+si]
     9a9:	00 0b                	add    BYTE PTR [bp+di],cl
     9ab:	54                   	push   sp
     9ac:	61                   	popa
     9ad:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9b0:	45                   	inc    bp
     9b1:	52                   	push   dx
     9b2:	47                   	inc    di
     9b3:	49                   	dec    cx
     9b4:	46                   	inc    si
     9b5:	41                   	inc    cx
     9b6:	dc 02                	fadd   QWORD PTR [bp+si]
     9b8:	20 00                	and    BYTE PTR [bx+si],al
     9ba:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     9be:	6c                   	ins    BYTE PTR es:[di],dx
     9bf:	65 45                	gs inc bp
     9c1:	52                   	push   dx
     9c2:	47                   	inc    di
     9c3:	43                   	inc    bx
     9c4:	6c                   	ins    BYTE PTR es:[di],dx
     9c5:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     9ca:	e0 02                	loopne 0x9ce
     9cc:	20 00                	and    BYTE PTR [bx+si],al
     9ce:	14 54                	adc    al,0x54
     9d0:	61                   	popa
     9d1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9d4:	45                   	inc    bp
     9d5:	52                   	push   dx
     9d6:	47                   	inc    di
     9d7:	46                   	inc    si
     9d8:	6f                   	outs   dx,WORD PTR ds:[si]
     9d9:	75 72                	jne    0xa4d
     9db:	6e                   	outs   dx,BYTE PTR ds:[si]
     9dc:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     9e1:	72 73                	jb     0xa56
     9e3:	e4 02                	in     al,0x2
     9e5:	20 00                	and    BYTE PTR [bx+si],al
     9e7:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     9ea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9ed:	45                   	inc    bp
     9ee:	52                   	push   dx
     9ef:	47                   	inc    di
     9f0:	54                   	push   sp
     9f1:	72 65                	jb     0xa58
     9f3:	73 6f                	jae    0xa64
     9f5:	72 65                	jb     0xa5c
     9f7:	72 69                	jb     0xa62
     9f9:	65 e8 02 20          	gs call 0x29ff
     9fd:	00 0f                	add    BYTE PTR [bx],cl
     9ff:	54                   	push   sp
     a00:	61                   	popa
     a01:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a04:	45                   	inc    bp
     a05:	52                   	push   dx
     a06:	47                   	inc    di
     a07:	45                   	inc    bp
     a08:	6d                   	ins    WORD PTR es:[di],dx
     a09:	70 72                	jo     0xa7d
     a0b:	75 6e                	jne    0xa7b
     a0d:	74 ec                	je     0x9fb
     a0f:	02 20                	add    ah,BYTE PTR [bx+si]
     a11:	00 15                	add    BYTE PTR [di],dl
     a13:	54                   	push   sp
     a14:	61                   	popa
     a15:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a18:	45                   	inc    bp
     a19:	52                   	push   dx
     a1a:	47                   	inc    di
     a1b:	44                   	inc    sp
     a1c:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     a20:	76 65                	jbe    0xa87
     a22:	72 74                	jb     0xa98
     a24:	41                   	inc    cx
     a25:	75 74                	jne    0xa9b
     a27:	6f                   	outs   dx,WORD PTR ds:[si]
     a28:	f0 02 20             	lock add ah,BYTE PTR [bx+si]
     a2b:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     a2f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a32:	45                   	inc    bp
     a33:	52                   	push   dx
     a34:	47                   	inc    di
     a35:	44                   	inc    sp
     a36:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     a3a:	76 65                	jbe    0xaa1
     a3c:	72 74                	jb     0xab2
     a3e:	4e                   	dec    si
     a3f:	41                   	inc    cx
     a40:	75 74                	jne    0xab6
     a42:	6f                   	outs   dx,WORD PTR ds:[si]
     a43:	f4                   	hlt
     a44:	02 20                	add    ah,BYTE PTR [bx+si]
     a46:	00 15                	add    BYTE PTR [di],dl
     a48:	54                   	push   sp
     a49:	61                   	popa
     a4a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a4d:	45                   	inc    bp
     a4e:	52                   	push   dx
     a4f:	47                   	inc    di
     a50:	41                   	inc    cx
     a51:	6d                   	ins    WORD PTR es:[di],dx
     a52:	6f                   	outs   dx,WORD PTR ds:[si]
     a53:	72 74                	jb     0xac9
     a55:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     a5a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a5c:	74 f8                	je     0xa56
     a5e:	02 20                	add    ah,BYTE PTR [bx+si]
     a60:	00 10                	add    BYTE PTR [bx+si],dl
     a62:	54                   	push   sp
     a63:	61                   	popa
     a64:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a67:	45                   	inc    bp
     a68:	52                   	push   dx
     a69:	47                   	inc    di
     a6a:	43                   	inc    bx
     a6b:	65 73 73             	gs jae 0xae1
     a6e:	69 6f 6e 73 fc       	imul   bp,WORD PTR [bx+0x6e],0xfc73
     a73:	02 1c                	add    bl,BYTE PTR [si]
     a75:	00 10                	add    BYTE PTR [bx+si],dl
     a77:	54                   	push   sp
     a78:	61                   	popa
     a79:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a7c:	45                   	inc    bp
     a7d:	52                   	push   dx
     a7e:	47                   	inc    di
     a7f:	4d                   	dec    bp
     a80:	61                   	popa
     a81:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     a84:	6e                   	outs   dx,BYTE PTR ds:[si]
     a85:	65 73 00             	gs jae 0xa88
     a88:	03 20                	add    sp,WORD PTR [bx+si]
     a8a:	00 1d                	add    BYTE PTR [di],bl
     a8c:	54                   	push   sp
     a8d:	61                   	popa
     a8e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a91:	45                   	inc    bp
     a92:	52                   	push   dx
     a93:	47                   	inc    di
     a94:	49                   	dec    cx
     a95:	6d                   	ins    WORD PTR es:[di],dx
     a96:	6d                   	ins    WORD PTR es:[di],dx
     a97:	6f                   	outs   dx,WORD PTR ds:[si]
     a98:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     a9b:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     aa0:	6f                   	outs   dx,WORD PTR ds:[si]
     aa1:	6e                   	outs   dx,BYTE PTR ds:[si]
     aa2:	73 42                	jae    0xae6
     aa4:	72 75                	jb     0xb1b
     aa6:	74 65                	je     0xb0d
     aa8:	73 04                	jae    0xaae
     aaa:	03 20                	add    sp,WORD PTR [bx+si]
     aac:	00 1c                	add    BYTE PTR [si],bl
     aae:	54                   	push   sp
     aaf:	61                   	popa
     ab0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ab3:	45                   	inc    bp
     ab4:	52                   	push   dx
     ab5:	47                   	inc    di
     ab6:	43                   	inc    bx
     ab7:	6f                   	outs   dx,WORD PTR ds:[si]
     ab8:	75 74                	jne    0xb2e
     aba:	73 46                	jae    0xb02
     abc:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     ac1:	72 6f                	jb     0xb32
     ac3:	64 75 63             	fs jne 0xb29
     ac6:	74 69                	je     0xb31
     ac8:	6f                   	outs   dx,WORD PTR ds:[si]
     ac9:	6e                   	outs   dx,BYTE PTR ds:[si]
     aca:	08 03                	or     BYTE PTR [bp+di],al
     acc:	1c 00                	sbb    al,0x0
     ace:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     ad1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ad4:	45                   	inc    bp
     ad5:	52                   	push   dx
     ad6:	47                   	inc    di
     ad7:	50                   	push   ax
     ad8:	72 6f                	jb     0xb49
     ada:	64 75 63             	fs jne 0xb40
     add:	74 69                	je     0xb48
     adf:	66 73 0c             	data32 jae 0xaee
     ae2:	03 1c                	add    bx,WORD PTR [si]
     ae4:	00 10                	add    BYTE PTR [bx+si],dl
     ae6:	54                   	push   sp
     ae7:	61                   	popa
     ae8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     aeb:	45                   	inc    bp
     aec:	52                   	push   dx
     aed:	47                   	inc    di
     aee:	56                   	push   si
     aef:	65 6e                	outs   dx,BYTE PTR gs:[si]
     af1:	64 65 75 72          	fs gs jne 0xb67
     af5:	73 10                	jae    0xb07
     af7:	03 1c                	add    bx,WORD PTR [si]
     af9:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     afd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b00:	45                   	inc    bp
     b01:	52                   	push   dx
     b02:	47                   	inc    di
     b03:	43                   	inc    bx
     b04:	61                   	popa
     b05:	64 72 65             	fs jb  0xb6d
     b08:	73 14                	jae    0xb1e
     b0a:	03 20                	add    sp,WORD PTR [bx+si]
     b0c:	00 14                	add    BYTE PTR [si],dl
     b0e:	54                   	push   sp
     b0f:	61                   	popa
     b10:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b13:	45                   	inc    bp
     b14:	52                   	push   dx
     b15:	47                   	inc    di
     b16:	43                   	inc    bx
     b17:	6f                   	outs   dx,WORD PTR ds:[si]
     b18:	75 74                	jne    0xb8e
     b1a:	45                   	inc    bp
     b1b:	6d                   	ins    WORD PTR es:[di],dx
     b1c:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     b1f:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     b22:	18 03                	sbb    BYTE PTR [bp+di],al
     b24:	20 00                	and    BYTE PTR [bx+si],al
     b26:	14 54                	adc    al,0x54
     b28:	61                   	popa
     b29:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b2c:	45                   	inc    bp
     b2d:	52                   	push   dx
     b2e:	47                   	inc    di
     b2f:	43                   	inc    bx
     b30:	6f                   	outs   dx,WORD PTR ds:[si]
     b31:	75 74                	jne    0xba7
     b33:	4c                   	dec    sp
     b34:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     b39:	69 65 1c 03 20       	imul   sp,WORD PTR [di+0x1c],0x2003
     b3e:	00 15                	add    BYTE PTR [di],dl
     b40:	54                   	push   sp
     b41:	61                   	popa
     b42:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b45:	45                   	inc    bp
     b46:	52                   	push   dx
     b47:	47                   	inc    di
     b48:	43                   	inc    bx
     b49:	6f                   	outs   dx,WORD PTR ds:[si]
     b4a:	75 74                	jne    0xbc0
     b4c:	46                   	inc    si
     b4d:	6f                   	outs   dx,WORD PTR ds:[si]
     b4e:	72 6d                	jb     0xbbd
     b50:	61                   	popa
     b51:	74 69                	je     0xbbc
     b53:	6f                   	outs   dx,WORD PTR ds:[si]
     b54:	6e                   	outs   dx,BYTE PTR ds:[si]
     b55:	20 03                	and    BYTE PTR [bp+di],al
     b57:	20 00                	and    BYTE PTR [bx+si],al
     b59:	15 54 61             	adc    ax,0x6154
     b5c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b5f:	45                   	inc    bp
     b60:	52                   	push   dx
     b61:	47                   	inc    di
     b62:	44                   	inc    sp
     b63:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     b68:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     b6b:	69 6f 6e 73 24       	imul   bp,WORD PTR [bx+0x6e],0x2473
     b70:	03 1c                	add    bx,WORD PTR [si]
     b72:	00 0f                	add    BYTE PTR [bx],cl
     b74:	54                   	push   sp
     b75:	61                   	popa
     b76:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b79:	45                   	inc    bp
     b7a:	52                   	push   dx
     b7b:	47                   	inc    di
     b7c:	53                   	push   bx
     b7d:	70 65                	jo     0xbe4
     b7f:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     b82:	6c                   	ins    BYTE PTR es:[di],dx
     b83:	28 03                	sub    BYTE PTR [bp+di],al
     b85:	1c 00                	sbb    al,0x0
     b87:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     b8a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b8d:	45                   	inc    bp
     b8e:	52                   	push   dx
     b8f:	50                   	push   ax
     b90:	31 50 65             	xor    WORD PTR [bx+si+0x65],dx
     b93:	72 69                	jb     0xbfe
     b95:	6f                   	outs   dx,WORD PTR ds:[si]
     b96:	64 65 4e             	fs gs dec si
     b99:	6f                   	outs   dx,WORD PTR ds:[si]
     b9a:	2c 03                	sub    al,0x3
     b9c:	1c 00                	sbb    al,0x0
     b9e:	15 54 61             	adc    ax,0x6154
     ba1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ba4:	45                   	inc    bp
     ba5:	52                   	push   dx
     ba6:	50                   	push   ax
     ba7:	31 45 6e             	xor    WORD PTR [di+0x6e],ax
     baa:	74 72                	je     0xc1e
     bac:	65 70 72             	gs jo  0xc21
     baf:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     bb4:	30 03                	xor    BYTE PTR [bp+di],al
     bb6:	1c 00                	sbb    al,0x0
     bb8:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     bbb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bbe:	45                   	inc    bp
     bbf:	52                   	push   dx
     bc0:	50                   	push   ax
     bc1:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     bc4:	6f                   	outs   dx,WORD PTR ds:[si]
     bc5:	64 75 69             	fs jne 0xc31
     bc8:	74 4e                	je     0xc18
     bca:	6f                   	outs   dx,WORD PTR ds:[si]
     bcb:	34 03                	xor    al,0x3
     bcd:	20 00                	and    BYTE PTR [bx+si],al
     bcf:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     bd2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bd5:	45                   	inc    bp
     bd6:	52                   	push   dx
     bd7:	50                   	push   ax
     bd8:	31 45 66             	xor    WORD PTR [di+0x66],ax
     bdb:	66 65 74 50          	data32 gs je 0xc2f
     bdf:	72 69                	jb     0xc4a
     be1:	78 38                	js     0xc1b
     be3:	03 20                	add    sp,WORD PTR [bx+si]
     be5:	00 11                	add    BYTE PTR [bx+di],dl
     be7:	54                   	push   sp
     be8:	61                   	popa
     be9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bec:	45                   	inc    bp
     bed:	52                   	push   dx
     bee:	50                   	push   ax
     bef:	31 45 66             	xor    WORD PTR [di+0x66],ax
     bf2:	66 65 74 50          	data32 gs je 0xc46
     bf6:	75 62                	jne    0xc5a
     bf8:	3c 03                	cmp    al,0x3
     bfa:	20 00                	and    BYTE PTR [bx+si],al
     bfc:	10 54 61             	adc    BYTE PTR [si+0x61],dl
     bff:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c02:	45                   	inc    bp
     c03:	52                   	push   dx
     c04:	50                   	push   ax
     c05:	31 45 66             	xor    WORD PTR [di+0x66],ax
     c08:	66 65 74 46          	data32 gs je 0xc52
     c0c:	56                   	push   si
     c0d:	40                   	inc    ax
     c0e:	03 20                	add    sp,WORD PTR [bx+si]
     c10:	00 14                	add    BYTE PTR [si],dl
     c12:	54                   	push   sp
     c13:	61                   	popa
     c14:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c17:	45                   	inc    bp
     c18:	52                   	push   dx
     c19:	50                   	push   ax
     c1a:	31 45 66             	xor    WORD PTR [di+0x66],ax
     c1d:	66 65 74 43          	data32 gs je 0xc64
     c21:	72 65                	jb     0xc88
     c23:	64 69 74 44 03 20    	imul   si,WORD PTR fs:[si+0x44],0x2003
     c29:	00 14                	add    BYTE PTR [si],dl
     c2b:	54                   	push   sp
     c2c:	61                   	popa
     c2d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c30:	45                   	inc    bp
     c31:	52                   	push   dx
     c32:	50                   	push   ax
     c33:	31 45 66             	xor    WORD PTR [di+0x66],ax
     c36:	66 65 74 47          	data32 gs je 0xc81
     c3a:	6c                   	ins    BYTE PTR es:[di],dx
     c3b:	6f                   	outs   dx,WORD PTR ds:[si]
     c3c:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
     c3f:	48                   	dec    ax
     c40:	03 1c                	add    bx,WORD PTR [si]
     c42:	00 10                	add    BYTE PTR [bx+si],dl
     c44:	54                   	push   sp
     c45:	61                   	popa
     c46:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c49:	45                   	inc    bp
     c4a:	52                   	push   dx
     c4b:	50                   	push   ax
     c4c:	31 44 65             	xor    WORD PTR [si+0x65],ax
     c4f:	6d                   	ins    WORD PTR es:[di],dx
     c50:	61                   	popa
     c51:	6e                   	outs   dx,BYTE PTR ds:[si]
     c52:	64 65 4c             	fs gs dec sp
     c55:	03 1c                	add    bx,WORD PTR [si]
     c57:	00 0f                	add    BYTE PTR [bx],cl
     c59:	54                   	push   sp
     c5a:	61                   	popa
     c5b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c5e:	45                   	inc    bp
     c5f:	52                   	push   dx
     c60:	50                   	push   ax
     c61:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     c64:	6e                   	outs   dx,BYTE PTR ds:[si]
     c65:	74 65                	je     0xccc
     c67:	73 50                	jae    0xcb9
     c69:	03 1c                	add    bx,WORD PTR [si]
     c6b:	00 1d                	add    BYTE PTR [di],bl
     c6d:	54                   	push   sp
     c6e:	61                   	popa
     c6f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c72:	45                   	inc    bp
     c73:	52                   	push   dx
     c74:	50                   	push   ax
     c75:	31 44 65             	xor    WORD PTR [si+0x65],ax
     c78:	6d                   	ins    WORD PTR es:[di],dx
     c79:	61                   	popa
     c7a:	6e                   	outs   dx,BYTE PTR ds:[si]
     c7b:	64 65 4e             	fs gs dec si
     c7e:	6f                   	outs   dx,WORD PTR ds:[si]
     c7f:	6e                   	outs   dx,BYTE PTR ds:[si]
     c80:	53                   	push   bx
     c81:	61                   	popa
     c82:	74 69                	je     0xced
     c84:	73 66                	jae    0xcec
     c86:	61                   	popa
     c87:	69 74 65 54 03       	imul   si,WORD PTR [si+0x65],0x354
     c8c:	1c 00                	sbb    al,0x0
     c8e:	15 54 61             	adc    ax,0x6154
     c91:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c94:	45                   	inc    bp
     c95:	52                   	push   dx
     c96:	50                   	push   ax
     c97:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     c9a:	6e                   	outs   dx,BYTE PTR ds:[si]
     c9b:	74 65                	je     0xd02
     c9d:	73 50                	jae    0xcef
     c9f:	72 69                	jb     0xd0a
     ca1:	73 65                	jae    0xd08
     ca3:	73 58                	jae    0xcfd
     ca5:	03 20                	add    sp,WORD PTR [bx+si]
     ca7:	00 13                	add    BYTE PTR [bp+di],dl
     ca9:	54                   	push   sp
     caa:	61                   	popa
     cab:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cae:	45                   	inc    bp
     caf:	52                   	push   dx
     cb0:	50                   	push   ax
     cb1:	31 50 61             	xor    WORD PTR [bx+si+0x61],dx
     cb4:	72 74                	jb     0xd2a
     cb6:	4d                   	dec    bp
     cb7:	61                   	popa
     cb8:	72 63                	jb     0xd1d
     cba:	68 65 5c             	push   0x5c65
     cbd:	03 1c                	add    bx,WORD PTR [si]
     cbf:	00 11                	add    BYTE PTR [bx+di],dl
     cc1:	54                   	push   sp
     cc2:	61                   	popa
     cc3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cc6:	45                   	inc    bp
     cc7:	52                   	push   dx
     cc8:	50                   	push   ax
     cc9:	31 51 74             	xor    WORD PTR [bx+di+0x74],dx
     ccc:	65 53                	gs push bx
     cce:	74 6f                	je     0xd3f
     cd0:	63 6b 60             	arpl   WORD PTR [bp+di+0x60],bp
     cd3:	03 20                	add    sp,WORD PTR [bx+si]
     cd5:	00 14                	add    BYTE PTR [si],dl
     cd7:	54                   	push   sp
     cd8:	61                   	popa
     cd9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cdc:	45                   	inc    bp
     cdd:	52                   	push   dx
     cde:	50                   	push   ax
     cdf:	31 56 61             	xor    WORD PTR [bp+0x61],dx
     ce2:	6c                   	ins    BYTE PTR es:[di],dx
     ce3:	65 75 72             	gs jne 0xd58
     ce6:	53                   	push   bx
     ce7:	74 6f                	je     0xd58
     ce9:	63 6b 64             	arpl   WORD PTR [bp+di+0x64],bp
     cec:	03 20                	add    sp,WORD PTR [bx+si]
     cee:	00 19                	add    BYTE PTR [bx+di],bl
     cf0:	54                   	push   sp
     cf1:	61                   	popa
     cf2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cf5:	45                   	inc    bp
     cf6:	52                   	push   dx
     cf7:	50                   	push   ax
     cf8:	31 44 6f             	xor    WORD PTR [si+0x6f],ax
     cfb:	74 41                	je     0xd3e
     cfd:	6d                   	ins    WORD PTR es:[di],dx
     cfe:	6f                   	outs   dx,WORD PTR ds:[si]
     cff:	72 74                	jb     0xd75
     d01:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     d06:	65 6e                	outs   dx,BYTE PTR gs:[si]
     d08:	74 68                	je     0xd72
     d0a:	03 1c                	add    bx,WORD PTR [si]
     d0c:	00 19                	add    BYTE PTR [bx+di],bl
     d0e:	54                   	push   sp
     d0f:	61                   	popa
     d10:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d13:	45                   	inc    bp
     d14:	52                   	push   dx
     d15:	50                   	push   ax
     d16:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     d19:	6e                   	outs   dx,BYTE PTR ds:[si]
     d1a:	74 65                	je     0xd81
     d1c:	73 53                	jae    0xd71
     d1e:	6f                   	outs   dx,WORD PTR ds:[si]
     d1f:	6c                   	ins    BYTE PTR es:[di],dx
     d20:	64 65 65 73 51       	fs gs gs jae 0xd76
     d25:	74 65                	je     0xd8c
     d27:	6c                   	ins    BYTE PTR es:[di],dx
     d28:	03 20                	add    sp,WORD PTR [bx+si]
     d2a:	00 1a                	add    BYTE PTR [bp+si],bl
     d2c:	54                   	push   sp
     d2d:	61                   	popa
     d2e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d31:	45                   	inc    bp
     d32:	52                   	push   dx
     d33:	50                   	push   ax
     d34:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     d37:	6e                   	outs   dx,BYTE PTR ds:[si]
     d38:	74 65                	je     0xd9f
     d3a:	73 53                	jae    0xd8f
     d3c:	6f                   	outs   dx,WORD PTR ds:[si]
     d3d:	6c                   	ins    BYTE PTR es:[di],dx
     d3e:	64 65 65 73 50       	fs gs gs jae 0xd93
     d43:	72 69                	jb     0xdae
     d45:	78 70                	js     0xdb7
     d47:	03 1c                	add    bx,WORD PTR [si]
     d49:	00 15                	add    BYTE PTR [di],dl
     d4b:	54                   	push   sp
     d4c:	61                   	popa
     d4d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d50:	45                   	inc    bp
     d51:	52                   	push   dx
     d52:	50                   	push   ax
     d53:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     d56:	6e                   	outs   dx,BYTE PTR ds:[si]
     d57:	74 65                	je     0xdbe
     d59:	73 53                	jae    0xdae
     d5b:	70 65                	jo     0xdc2
     d5d:	51                   	push   cx
     d5e:	74 65                	je     0xdc5
     d60:	74 03                	je     0xd65
     d62:	20 00                	and    BYTE PTR [bx+si],al
     d64:	16                   	push   ss
     d65:	54                   	push   sp
     d66:	61                   	popa
     d67:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d6a:	45                   	inc    bp
     d6b:	52                   	push   dx
     d6c:	50                   	push   ax
     d6d:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     d70:	6e                   	outs   dx,BYTE PTR ds:[si]
     d71:	74 65                	je     0xdd8
     d73:	73 53                	jae    0xdc8
     d75:	70 65                	jo     0xddc
     d77:	50                   	push   ax
     d78:	72 69                	jb     0xde3
     d7a:	78 78                	js     0xdf4
     d7c:	03 10                	add    dx,WORD PTR [bx+si]
     d7e:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
     d82:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d85:	45                   	inc    bp
     d86:	52                   	push   dx
     d87:	50                   	push   ax
     d88:	31 54 65             	xor    WORD PTR [si+0x65],dx
     d8b:	6d                   	ins    WORD PTR es:[di],dx
     d8c:	70 73                	jo     0xe01
     d8e:	46                   	inc    si
     d8f:	61                   	popa
     d90:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
     d93:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
     d96:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
     d9b:	74 75                	je     0xe12
     d9d:	72 7c                	jb     0xe1b
     d9f:	03 1c                	add    bx,WORD PTR [si]
     da1:	00 10                	add    BYTE PTR [bx+si],dl
     da3:	54                   	push   sp
     da4:	61                   	popa
     da5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     da8:	45                   	inc    bp
     da9:	52                   	push   dx
     daa:	50                   	push   ax
     dab:	31 53 70             	xor    WORD PTR [bp+di+0x70],dx
     dae:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     db2:	6c                   	ins    BYTE PTR es:[di],dx
     db3:	80 03 1c             	add    BYTE PTR [bp+di],0x1c
     db6:	00 12                	add    BYTE PTR [bp+si],dl
     db8:	54                   	push   sp
     db9:	61                   	popa
     dba:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dbd:	45                   	inc    bp
     dbe:	52                   	push   dx
     dbf:	50                   	push   ax
     dc0:	32 50 65             	xor    dl,BYTE PTR [bx+si+0x65]
     dc3:	72 69                	jb     0xe2e
     dc5:	6f                   	outs   dx,WORD PTR ds:[si]
     dc6:	64 65 4e             	fs gs dec si
     dc9:	6f                   	outs   dx,WORD PTR ds:[si]
     dca:	84 03                	test   BYTE PTR [bp+di],al
     dcc:	1c 00                	sbb    al,0x0
     dce:	15 54 61             	adc    ax,0x6154
     dd1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dd4:	45                   	inc    bp
     dd5:	52                   	push   dx
     dd6:	50                   	push   ax
     dd7:	32 45 6e             	xor    al,BYTE PTR [di+0x6e]
     dda:	74 72                	je     0xe4e
     ddc:	65 70 72             	gs jo  0xe51
     ddf:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     de4:	88 03                	mov    BYTE PTR [bp+di],al
     de6:	1c 00                	sbb    al,0x0
     de8:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     deb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dee:	45                   	inc    bp
     def:	52                   	push   dx
     df0:	50                   	push   ax
     df1:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     df4:	6f                   	outs   dx,WORD PTR ds:[si]
     df5:	64 75 69             	fs jne 0xe61
     df8:	74 4e                	je     0xe48
     dfa:	6f                   	outs   dx,WORD PTR ds:[si]
     dfb:	8c 03                	mov    WORD PTR [bp+di],es
     dfd:	20 00                	and    BYTE PTR [bx+si],al
     dff:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     e02:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e05:	45                   	inc    bp
     e06:	52                   	push   dx
     e07:	50                   	push   ax
     e08:	32 45 66             	xor    al,BYTE PTR [di+0x66]
     e0b:	66 65 74 50          	data32 gs je 0xe5f
     e0f:	72 69                	jb     0xe7a
     e11:	78 90                	js     0xda3
     e13:	03 20                	add    sp,WORD PTR [bx+si]
     e15:	00 11                	add    BYTE PTR [bx+di],dl
     e17:	54                   	push   sp
     e18:	61                   	popa
     e19:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e1c:	45                   	inc    bp
     e1d:	52                   	push   dx
     e1e:	50                   	push   ax
     e1f:	32 45 66             	xor    al,BYTE PTR [di+0x66]
     e22:	66 65 74 50          	data32 gs je 0xe76
     e26:	75 62                	jne    0xe8a
     e28:	94                   	xchg   sp,ax
     e29:	03 20                	add    sp,WORD PTR [bx+si]
     e2b:	00 10                	add    BYTE PTR [bx+si],dl
     e2d:	54                   	push   sp
     e2e:	61                   	popa
     e2f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e32:	45                   	inc    bp
     e33:	52                   	push   dx
     e34:	50                   	push   ax
     e35:	32 45 66             	xor    al,BYTE PTR [di+0x66]
     e38:	66 65 74 46          	data32 gs je 0xe82
     e3c:	56                   	push   si
     e3d:	98                   	cbw
     e3e:	03 20                	add    sp,WORD PTR [bx+si]
     e40:	00 14                	add    BYTE PTR [si],dl
     e42:	54                   	push   sp
     e43:	61                   	popa
     e44:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e47:	45                   	inc    bp
     e48:	52                   	push   dx
     e49:	50                   	push   ax
     e4a:	32 45 66             	xor    al,BYTE PTR [di+0x66]
     e4d:	66 65 74 43          	data32 gs je 0xe94
     e51:	72 65                	jb     0xeb8
     e53:	64 69 74 9c 03 20    	imul   si,WORD PTR fs:[si-0x64],0x2003
     e59:	00 14                	add    BYTE PTR [si],dl
     e5b:	54                   	push   sp
     e5c:	61                   	popa
     e5d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e60:	45                   	inc    bp
     e61:	52                   	push   dx
     e62:	50                   	push   ax
     e63:	32 45 66             	xor    al,BYTE PTR [di+0x66]
     e66:	66 65 74 47          	data32 gs je 0xeb1
     e6a:	6c                   	ins    BYTE PTR es:[di],dx
     e6b:	6f                   	outs   dx,WORD PTR ds:[si]
     e6c:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
     e6f:	a0 03 1c             	mov    al,ds:0x1c03
     e72:	00 10                	add    BYTE PTR [bx+si],dl
     e74:	54                   	push   sp
     e75:	61                   	popa
     e76:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e79:	45                   	inc    bp
     e7a:	52                   	push   dx
     e7b:	50                   	push   ax
     e7c:	32 44 65             	xor    al,BYTE PTR [si+0x65]
     e7f:	6d                   	ins    WORD PTR es:[di],dx
     e80:	61                   	popa
     e81:	6e                   	outs   dx,BYTE PTR ds:[si]
     e82:	64 65 a4             	fs movs BYTE PTR es:[di],BYTE PTR gs:[si]
     e85:	03 1c                	add    bx,WORD PTR [si]
     e87:	00 0f                	add    BYTE PTR [bx],cl
     e89:	54                   	push   sp
     e8a:	61                   	popa
     e8b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e8e:	45                   	inc    bp
     e8f:	52                   	push   dx
     e90:	50                   	push   ax
     e91:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     e94:	6e                   	outs   dx,BYTE PTR ds:[si]
     e95:	74 65                	je     0xefc
     e97:	73 a8                	jae    0xe41
     e99:	03 1c                	add    bx,WORD PTR [si]
     e9b:	00 1d                	add    BYTE PTR [di],bl
     e9d:	54                   	push   sp
     e9e:	61                   	popa
     e9f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ea2:	45                   	inc    bp
     ea3:	52                   	push   dx
     ea4:	50                   	push   ax
     ea5:	32 44 65             	xor    al,BYTE PTR [si+0x65]
     ea8:	6d                   	ins    WORD PTR es:[di],dx
     ea9:	61                   	popa
     eaa:	6e                   	outs   dx,BYTE PTR ds:[si]
     eab:	64 65 4e             	fs gs dec si
     eae:	6f                   	outs   dx,WORD PTR ds:[si]
     eaf:	6e                   	outs   dx,BYTE PTR ds:[si]
     eb0:	53                   	push   bx
     eb1:	61                   	popa
     eb2:	74 69                	je     0xf1d
     eb4:	73 66                	jae    0xf1c
     eb6:	61                   	popa
     eb7:	69 74 65 ac 03       	imul   si,WORD PTR [si+0x65],0x3ac
     ebc:	1c 00                	sbb    al,0x0
     ebe:	15 54 61             	adc    ax,0x6154
     ec1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ec4:	45                   	inc    bp
     ec5:	52                   	push   dx
     ec6:	50                   	push   ax
     ec7:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     eca:	6e                   	outs   dx,BYTE PTR ds:[si]
     ecb:	74 65                	je     0xf32
     ecd:	73 50                	jae    0xf1f
     ecf:	72 69                	jb     0xf3a
     ed1:	73 65                	jae    0xf38
     ed3:	73 b0                	jae    0xe85
     ed5:	03 20                	add    sp,WORD PTR [bx+si]
     ed7:	00 13                	add    BYTE PTR [bp+di],dl
     ed9:	54                   	push   sp
     eda:	61                   	popa
     edb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ede:	45                   	inc    bp
     edf:	52                   	push   dx
     ee0:	50                   	push   ax
     ee1:	32 50 61             	xor    dl,BYTE PTR [bx+si+0x61]
     ee4:	72 74                	jb     0xf5a
     ee6:	4d                   	dec    bp
     ee7:	61                   	popa
     ee8:	72 63                	jb     0xf4d
     eea:	68 65 b4             	push   0xb465
     eed:	03 1c                	add    bx,WORD PTR [si]
     eef:	00 11                	add    BYTE PTR [bx+di],dl
     ef1:	54                   	push   sp
     ef2:	61                   	popa
     ef3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ef6:	45                   	inc    bp
     ef7:	52                   	push   dx
     ef8:	50                   	push   ax
     ef9:	32 51 74             	xor    dl,BYTE PTR [bx+di+0x74]
     efc:	65 53                	gs push bx
     efe:	74 6f                	je     0xf6f
     f00:	63 6b b8             	arpl   WORD PTR [bp+di-0x48],bp
     f03:	03 20                	add    sp,WORD PTR [bx+si]
     f05:	00 14                	add    BYTE PTR [si],dl
     f07:	54                   	push   sp
     f08:	61                   	popa
     f09:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f0c:	45                   	inc    bp
     f0d:	52                   	push   dx
     f0e:	50                   	push   ax
     f0f:	32 56 61             	xor    dl,BYTE PTR [bp+0x61]
     f12:	6c                   	ins    BYTE PTR es:[di],dx
     f13:	65 75 72             	gs jne 0xf88
     f16:	53                   	push   bx
     f17:	74 6f                	je     0xf88
     f19:	63 6b bc             	arpl   WORD PTR [bp+di-0x44],bp
     f1c:	03 20                	add    sp,WORD PTR [bx+si]
     f1e:	00 19                	add    BYTE PTR [bx+di],bl
     f20:	54                   	push   sp
     f21:	61                   	popa
     f22:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f25:	45                   	inc    bp
     f26:	52                   	push   dx
     f27:	50                   	push   ax
     f28:	32 44 6f             	xor    al,BYTE PTR [si+0x6f]
     f2b:	74 41                	je     0xf6e
     f2d:	6d                   	ins    WORD PTR es:[di],dx
     f2e:	6f                   	outs   dx,WORD PTR ds:[si]
     f2f:	72 74                	jb     0xfa5
     f31:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     f36:	65 6e                	outs   dx,BYTE PTR gs:[si]
     f38:	74 c0                	je     0xefa
     f3a:	03 1c                	add    bx,WORD PTR [si]
     f3c:	00 19                	add    BYTE PTR [bx+di],bl
     f3e:	54                   	push   sp
     f3f:	61                   	popa
     f40:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f43:	45                   	inc    bp
     f44:	52                   	push   dx
     f45:	50                   	push   ax
     f46:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     f49:	6e                   	outs   dx,BYTE PTR ds:[si]
     f4a:	74 65                	je     0xfb1
     f4c:	73 53                	jae    0xfa1
     f4e:	6f                   	outs   dx,WORD PTR ds:[si]
     f4f:	6c                   	ins    BYTE PTR es:[di],dx
     f50:	64 65 65 73 51       	fs gs gs jae 0xfa6
     f55:	74 65                	je     0xfbc
     f57:	c4 03                	les    ax,DWORD PTR [bp+di]
     f59:	20 00                	and    BYTE PTR [bx+si],al
     f5b:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     f5e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f61:	45                   	inc    bp
     f62:	52                   	push   dx
     f63:	50                   	push   ax
     f64:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     f67:	6e                   	outs   dx,BYTE PTR ds:[si]
     f68:	74 65                	je     0xfcf
     f6a:	73 53                	jae    0xfbf
     f6c:	6f                   	outs   dx,WORD PTR ds:[si]
     f6d:	6c                   	ins    BYTE PTR es:[di],dx
     f6e:	64 65 65 73 50       	fs gs gs jae 0xfc3
     f73:	72 69                	jb     0xfde
     f75:	78 c8                	js     0xf3f
     f77:	03 1c                	add    bx,WORD PTR [si]
     f79:	00 15                	add    BYTE PTR [di],dl
     f7b:	54                   	push   sp
     f7c:	61                   	popa
     f7d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f80:	45                   	inc    bp
     f81:	52                   	push   dx
     f82:	50                   	push   ax
     f83:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     f86:	6e                   	outs   dx,BYTE PTR ds:[si]
     f87:	74 65                	je     0xfee
     f89:	73 53                	jae    0xfde
     f8b:	70 65                	jo     0xff2
     f8d:	51                   	push   cx
     f8e:	74 65                	je     0xff5
     f90:	cc                   	int3
     f91:	03 20                	add    sp,WORD PTR [bx+si]
     f93:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     f97:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f9a:	45                   	inc    bp
     f9b:	52                   	push   dx
     f9c:	50                   	push   ax
     f9d:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     fa0:	6e                   	outs   dx,BYTE PTR ds:[si]
     fa1:	74 65                	je     0x1008
     fa3:	73 53                	jae    0xff8
     fa5:	70 65                	jo     0x100c
     fa7:	50                   	push   ax
     fa8:	72 69                	jb     0x1013
     faa:	78 d0                	js     0xf7c
     fac:	03 10                	add    dx,WORD PTR [bx+si]
     fae:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
     fb2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fb5:	45                   	inc    bp
     fb6:	52                   	push   dx
     fb7:	50                   	push   ax
     fb8:	32 54 65             	xor    dl,BYTE PTR [si+0x65]
     fbb:	6d                   	ins    WORD PTR es:[di],dx
     fbc:	70 73                	jo     0x1031
     fbe:	46                   	inc    si
     fbf:	61                   	popa
     fc0:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
     fc3:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
     fc6:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
     fcb:	74 75                	je     0x1042
     fcd:	72 d4                	jb     0xfa3
     fcf:	03 1c                	add    bx,WORD PTR [si]
     fd1:	00 10                	add    BYTE PTR [bx+si],dl
     fd3:	54                   	push   sp
     fd4:	61                   	popa
     fd5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fd8:	45                   	inc    bp
     fd9:	52                   	push   dx
     fda:	50                   	push   ax
     fdb:	32 53 70             	xor    dl,BYTE PTR [bp+di+0x70]
     fde:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     fe2:	6c                   	ins    BYTE PTR es:[di],dx
     fe3:	d8 03                	fadd   DWORD PTR [bp+di]
     fe5:	10 00                	adc    BYTE PTR [bx+si],al
     fe7:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     fea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fed:	45                   	inc    bp
     fee:	52                   	push   dx
     fef:	50                   	push   ax
     ff0:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     ff3:	6f                   	outs   dx,WORD PTR ds:[si]
     ff4:	64 75 63             	fs jne 0x105a
     ff7:	74 69                	je     0x1062
     ff9:	6f                   	outs   dx,WORD PTR ds:[si]
     ffa:	6e                   	outs   dx,BYTE PTR ds:[si]
     ffb:	53                   	push   bx
     ffc:	6f                   	outs   dx,WORD PTR ds:[si]
     ffd:	6c                   	ins    BYTE PTR es:[di],dx
     ffe:	64 65 65 dc 03       	fs gs fadd QWORD PTR gs:[bp+di]
    1003:	10 00                	adc    BYTE PTR [bx+si],al
    1005:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1008:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    100b:	45                   	inc    bp
    100c:	52                   	push   dx
    100d:	50                   	push   ax
    100e:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
    1011:	6f                   	outs   dx,WORD PTR ds:[si]
    1012:	64 75 63             	fs jne 0x1078
    1015:	74 69                	je     0x1080
    1017:	6f                   	outs   dx,WORD PTR ds:[si]
    1018:	6e                   	outs   dx,BYTE PTR ds:[si]
    1019:	53                   	push   bx
    101a:	6f                   	outs   dx,WORD PTR ds:[si]
    101b:	6c                   	ins    BYTE PTR es:[di],dx
    101c:	64 65 65 e0 03       	fs gs gs loopne 0x1024
    1021:	10 00                	adc    BYTE PTR [bx+si],al
    1023:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    1026:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1029:	45                   	inc    bp
    102a:	52                   	push   dx
    102b:	47                   	inc    di
    102c:	50                   	push   ax
    102d:	72 6f                	jb     0x109e
    102f:	64 75 63             	fs jne 0x1095
    1032:	74 69                	je     0x109d
    1034:	6f                   	outs   dx,WORD PTR ds:[si]
    1035:	6e                   	outs   dx,BYTE PTR ds:[si]
    1036:	53                   	push   bx
    1037:	6f                   	outs   dx,WORD PTR ds:[si]
    1038:	6c                   	ins    BYTE PTR es:[di],dx
    1039:	64 65 65 e4 03       	fs gs gs in al,0x3
    103e:	10 00                	adc    BYTE PTR [bx+si],al
    1040:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
    1043:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1046:	45                   	inc    bp
    1047:	52                   	push   dx
    1048:	47                   	inc    di
    1049:	50                   	push   ax
    104a:	72 6f                	jb     0x10bb
    104c:	64 75 63             	fs jne 0x10b2
    104f:	74 69                	je     0x10ba
    1051:	6f                   	outs   dx,WORD PTR ds:[si]
    1052:	6e                   	outs   dx,BYTE PTR ds:[si]
    1053:	53                   	push   bx
    1054:	70 65                	jo     0x10bb
    1056:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1059:	6c                   	ins    BYTE PTR es:[di],dx
    105a:	65 e8 03 10          	gs call 0x2061
    105e:	00 1b                	add    BYTE PTR [bp+di],bl
    1060:	54                   	push   sp
    1061:	61                   	popa
    1062:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1065:	45                   	inc    bp
    1066:	52                   	push   dx
    1067:	50                   	push   ax
    1068:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
    106b:	6f                   	outs   dx,WORD PTR ds:[si]
    106c:	64 75 63             	fs jne 0x10d2
    106f:	74 69                	je     0x10da
    1071:	6f                   	outs   dx,WORD PTR ds:[si]
    1072:	6e                   	outs   dx,BYTE PTR ds:[si]
    1073:	53                   	push   bx
    1074:	70 65                	jo     0x10db
    1076:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1079:	6c                   	ins    BYTE PTR es:[di],dx
    107a:	65 ec                	gs in  al,dx
    107c:	03 10                	add    dx,WORD PTR [bx+si]
    107e:	00 1b                	add    BYTE PTR [bp+di],bl
    1080:	54                   	push   sp
    1081:	61                   	popa
    1082:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1085:	45                   	inc    bp
    1086:	52                   	push   dx
    1087:	50                   	push   ax
    1088:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
    108b:	6f                   	outs   dx,WORD PTR ds:[si]
    108c:	64 75 63             	fs jne 0x10f2
    108f:	74 69                	je     0x10fa
    1091:	6f                   	outs   dx,WORD PTR ds:[si]
    1092:	6e                   	outs   dx,BYTE PTR ds:[si]
    1093:	53                   	push   bx
    1094:	70 65                	jo     0x10fb
    1096:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1099:	6c                   	ins    BYTE PTR es:[di],dx
    109a:	65 f0 03 10          	lock add dx,WORD PTR gs:[bx+si]
    109e:	00 17                	add    BYTE PTR [bx],dl
    10a0:	54                   	push   sp
    10a1:	61                   	popa
    10a2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10a5:	45                   	inc    bp
    10a6:	52                   	push   dx
    10a7:	47                   	inc    di
    10a8:	44                   	inc    sp
    10a9:	65 70 65             	gs jo  0x1111
    10ac:	6e                   	outs   dx,BYTE PTR ds:[si]
    10ad:	73 65                	jae    0x1114
    10af:	73 51                	jae    0x1102
    10b1:	75 61                	jne    0x1114
    10b3:	6c                   	ins    BYTE PTR es:[di],dx
    10b4:	69 74 65 f4 03       	imul   si,WORD PTR [si+0x65],0x3f4
    10b9:	20 00                	and    BYTE PTR [bx+si],al
    10bb:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
    10be:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10c1:	45                   	inc    bp
    10c2:	52                   	push   dx
    10c3:	50                   	push   ax
    10c4:	31 4d 61             	xor    WORD PTR [di+0x61],cx
    10c7:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    10cc:	76 72                	jbe    0x1140
    10ce:	65 44                	gs inc sp
    10d0:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    10d5:	65 f8                	gs clc
    10d7:	03 20                	add    sp,WORD PTR [bx+si]
    10d9:	00 1a                	add    BYTE PTR [bp+si],bl
    10db:	54                   	push   sp
    10dc:	61                   	popa
    10dd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10e0:	45                   	inc    bp
    10e1:	52                   	push   dx
    10e2:	50                   	push   ax
    10e3:	32 4d 61             	xor    cl,BYTE PTR [di+0x61]
    10e6:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    10eb:	76 72                	jbe    0x115f
    10ed:	65 44                	gs inc sp
    10ef:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    10f4:	65 fc                	gs cld
    10f6:	03 20                	add    sp,WORD PTR [bx+si]
    10f8:	00 1c                	add    BYTE PTR [si],bl
    10fa:	54                   	push   sp
    10fb:	61                   	popa
    10fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10ff:	45                   	inc    bp
    1100:	52                   	push   dx
    1101:	50                   	push   ax
    1102:	31 43 6f             	xor    WORD PTR [bp+di+0x6f],ax
    1105:	6e                   	outs   dx,BYTE PTR ds:[si]
    1106:	73 6f                	jae    0x1177
    1108:	6d                   	ins    WORD PTR es:[di],dx
    1109:	6d                   	ins    WORD PTR es:[di],dx
    110a:	61                   	popa
    110b:	74 69                	je     0x1176
    110d:	6f                   	outs   dx,WORD PTR ds:[si]
    110e:	6e                   	outs   dx,BYTE PTR ds:[si]
    110f:	4d                   	dec    bp
    1110:	61                   	popa
    1111:	74 69                	je     0x117c
    1113:	65 72 65             	gs jb  0x117b
    1116:	00 04                	add    BYTE PTR [si],al
    1118:	20 00                	and    BYTE PTR [bx+si],al
    111a:	1c 54                	sbb    al,0x54
    111c:	61                   	popa
    111d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1120:	45                   	inc    bp
    1121:	52                   	push   dx
    1122:	50                   	push   ax
    1123:	32 43 6f             	xor    al,BYTE PTR [bp+di+0x6f]
    1126:	6e                   	outs   dx,BYTE PTR ds:[si]
    1127:	73 6f                	jae    0x1198
    1129:	6d                   	ins    WORD PTR es:[di],dx
    112a:	6d                   	ins    WORD PTR es:[di],dx
    112b:	61                   	popa
    112c:	74 69                	je     0x1197
    112e:	6f                   	outs   dx,WORD PTR ds:[si]
    112f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1130:	4d                   	dec    bp
    1131:	61                   	popa
    1132:	74 69                	je     0x119d
    1134:	65 72 65             	gs jb  0x119c
    1137:	04 04                	add    al,0x4
    1139:	10 00                	adc    BYTE PTR [bx+si],al
    113b:	17                   	pop    ss
    113c:	54                   	push   sp
    113d:	61                   	popa
    113e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1141:	45                   	inc    bp
    1142:	52                   	push   dx
    1143:	50                   	push   ax
    1144:	31 50 75             	xor    WORD PTR [bx+si+0x75],dx
    1147:	62 45 74             	bound  ax,DWORD PTR [di+0x74]
    114a:	41                   	inc    cx
    114b:	63 74 69             	arpl   WORD PTR [si+0x69],si
    114e:	6f                   	outs   dx,WORD PTR ds:[si]
    114f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1150:	43                   	inc    bx
    1151:	6f                   	outs   dx,WORD PTR ds:[si]
    1152:	6d                   	ins    WORD PTR es:[di],dx
    1153:	08 04                	or     BYTE PTR [si],al
    1155:	10 00                	adc    BYTE PTR [bx+si],al
    1157:	17                   	pop    ss
    1158:	54                   	push   sp
    1159:	61                   	popa
    115a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    115d:	45                   	inc    bp
    115e:	52                   	push   dx
    115f:	50                   	push   ax
    1160:	32 50 75             	xor    dl,BYTE PTR [bx+si+0x75]
    1163:	62 45 74             	bound  ax,DWORD PTR [di+0x74]
    1166:	41                   	inc    cx
    1167:	63 74 69             	arpl   WORD PTR [si+0x69],si
    116a:	6f                   	outs   dx,WORD PTR ds:[si]
    116b:	6e                   	outs   dx,BYTE PTR ds:[si]
    116c:	43                   	inc    bx
    116d:	6f                   	outs   dx,WORD PTR ds:[si]
    116e:	6d                   	ins    WORD PTR es:[di],dx
    116f:	0c 04                	or     al,0x4
    1171:	10 00                	adc    BYTE PTR [bx+si],al
    1173:	16                   	push   ss
    1174:	54                   	push   sp
    1175:	61                   	popa
    1176:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1179:	45                   	inc    bp
    117a:	52                   	push   dx
    117b:	47                   	inc    di
    117c:	50                   	push   ax
    117d:	75 62                	jne    0x11e1
    117f:	45                   	inc    bp
    1180:	74 41                	je     0x11c3
    1182:	63 74 69             	arpl   WORD PTR [si+0x69],si
    1185:	6f                   	outs   dx,WORD PTR ds:[si]
    1186:	6e                   	outs   dx,BYTE PTR ds:[si]
    1187:	43                   	inc    bx
    1188:	6f                   	outs   dx,WORD PTR ds:[si]
    1189:	6d                   	ins    WORD PTR es:[di],dx
    118a:	10 04                	adc    BYTE PTR [si],al
    118c:	20 00                	and    BYTE PTR [bx+si],al
    118e:	15 54 61             	adc    ax,0x6154
    1191:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1194:	45                   	inc    bp
    1195:	52                   	push   dx
    1196:	47                   	inc    di
    1197:	54                   	push   sp
    1198:	56                   	push   si
    1199:	41                   	inc    cx
    119a:	44                   	inc    sp
    119b:	65 64 75 63          	gs fs jne 0x1202
    119f:	74 69                	je     0x120a
    11a1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11a4:	14 04                	adc    al,0x4
    11a6:	20 00                	and    BYTE PTR [bx+si],al
    11a8:	17                   	pop    ss
    11a9:	54                   	push   sp
    11aa:	61                   	popa
    11ab:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11ae:	45                   	inc    bp
    11af:	52                   	push   dx
    11b0:	50                   	push   ax
    11b1:	31 52 65             	xor    WORD PTR [bp+si+0x65],dx
    11b4:	6d                   	ins    WORD PTR es:[di],dx
    11b5:	75 6e                	jne    0x1225
    11b7:	65 72 61             	gs jb  0x121b
    11ba:	74 69                	je     0x1225
    11bc:	6f                   	outs   dx,WORD PTR ds:[si]
    11bd:	6e                   	outs   dx,BYTE PTR ds:[si]
    11be:	46                   	inc    si
    11bf:	56                   	push   si
    11c0:	18 04                	sbb    BYTE PTR [si],al
    11c2:	20 00                	and    BYTE PTR [bx+si],al
    11c4:	17                   	pop    ss
    11c5:	54                   	push   sp
    11c6:	61                   	popa
    11c7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11ca:	45                   	inc    bp
    11cb:	52                   	push   dx
    11cc:	50                   	push   ax
    11cd:	32 52 65             	xor    dl,BYTE PTR [bp+si+0x65]
    11d0:	6d                   	ins    WORD PTR es:[di],dx
    11d1:	75 6e                	jne    0x1241
    11d3:	65 72 61             	gs jb  0x1237
    11d6:	74 69                	je     0x1241
    11d8:	6f                   	outs   dx,WORD PTR ds:[si]
    11d9:	6e                   	outs   dx,BYTE PTR ds:[si]
    11da:	46                   	inc    si
    11db:	56                   	push   si
    11dc:	1c 04                	sbb    al,0x4
    11de:	10 00                	adc    BYTE PTR [bx+si],al
    11e0:	16                   	push   ss
    11e1:	54                   	push   sp
    11e2:	61                   	popa
    11e3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11e6:	45                   	inc    bp
    11e7:	52                   	push   dx
    11e8:	47                   	inc    di
    11e9:	52                   	push   dx
    11ea:	65 6d                	gs ins WORD PTR es:[di],dx
    11ec:	75 6e                	jne    0x125c
    11ee:	65 72 61             	gs jb  0x1252
    11f1:	74 69                	je     0x125c
    11f3:	6f                   	outs   dx,WORD PTR ds:[si]
    11f4:	6e                   	outs   dx,BYTE PTR ds:[si]
    11f5:	46                   	inc    si
    11f6:	56                   	push   si
    11f7:	20 04                	and    BYTE PTR [si],al
    11f9:	20 00                	and    BYTE PTR [bx+si],al
    11fb:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
    11fe:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1201:	45                   	inc    bp
    1202:	52                   	push   dx
    1203:	47                   	inc    di
    1204:	52                   	push   dx
    1205:	65 6d                	gs ins WORD PTR es:[di],dx
    1207:	75 6e                	jne    0x1277
    1209:	65 72 61             	gs jb  0x126d
    120c:	74 69                	je     0x1277
    120e:	6f                   	outs   dx,WORD PTR ds:[si]
    120f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1210:	43                   	inc    bx
    1211:	61                   	popa
    1212:	64 72 65             	fs jb  0x127a
    1215:	73 24                	jae    0x123b
    1217:	04 20                	add    al,0x20
    1219:	00 14                	add    BYTE PTR [si],dl
    121b:	54                   	push   sp
    121c:	61                   	popa
    121d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1220:	45                   	inc    bp
    1221:	52                   	push   dx
    1222:	47                   	inc    di
    1223:	54                   	push   sp
    1224:	56                   	push   si
    1225:	41                   	inc    cx
    1226:	43                   	inc    bx
    1227:	6f                   	outs   dx,WORD PTR ds:[si]
    1228:	6c                   	ins    BYTE PTR es:[di],dx
    1229:	6c                   	ins    BYTE PTR es:[di],dx
    122a:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
    122e:	65 28 04             	sub    BYTE PTR gs:[si],al
    1231:	08 00                	or     BYTE PTR [bx+si],al
    1233:	06                   	push   es
    1234:	46                   	inc    si
    1235:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
    123a:	2c 04                	sub    al,0x4
    123c:	08 00                	or     BYTE PTR [bx+si],al
    123e:	02 4e 33             	add    cl,BYTE PTR [bp+0x33]
    1241:	30 04                	xor    BYTE PTR [si],al
    1243:	20 00                	and    BYTE PTR [bx+si],al
    1245:	14 54                	adc    al,0x54
    1247:	61                   	popa
    1248:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    124b:	45                   	inc    bp
    124c:	52                   	push   dx
    124d:	50                   	push   ax
    124e:	31 48 65             	xor    WORD PTR [bx+si+0x65],cx
    1251:	75 72                	jne    0x12c5
    1253:	65 73 53             	gs jae 0x12a9
    1256:	75 70                	jne    0x12c8
    1258:	50                   	push   ax
    1259:	63 34                	arpl   WORD PTR [si],si
    125b:	04 20                	add    al,0x20
    125d:	00 14                	add    BYTE PTR [si],dl
    125f:	54                   	push   sp
    1260:	61                   	popa
    1261:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1264:	45                   	inc    bp
    1265:	52                   	push   dx
    1266:	50                   	push   ax
    1267:	32 48 65             	xor    cl,BYTE PTR [bx+si+0x65]
    126a:	75 72                	jne    0x12de
    126c:	65 73 53             	gs jae 0x12c2
    126f:	75 70                	jne    0x12e1
    1271:	50                   	push   ax
    1272:	63 38                	arpl   WORD PTR [bx+si],di
    1274:	04 00                	add    al,0x0
    1276:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    127a:	6e                   	outs   dx,BYTE PTR ds:[si]
    127b:	65 6c                	gs ins BYTE PTR es:[di],dx
    127d:	34 3c                	xor    al,0x3c
    127f:	04 24                	add    al,0x24
    1281:	00 09                	add    BYTE PTR [bx+di],cl
    1283:	47                   	inc    di
    1284:	72 6f                	jb     0x12f5
    1286:	75 70                	jne    0x12f8
    1288:	42                   	inc    dx
    1289:	6f                   	outs   dx,WORD PTR ds:[si]
    128a:	78 31                	js     0x12bd
    128c:	40                   	inc    ax
    128d:	04 28                	add    al,0x28
    128f:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
    1293:	61                   	popa
    1294:	70 65                	jo     0x12fb
    1296:	36 44                	ss inc sp
    1298:	04 28                	add    al,0x28
    129a:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
    129e:	61                   	popa
    129f:	70 65                	jo     0x1306
    12a1:	34 48                	xor    al,0x48
    12a3:	04 00                	add    al,0x0
    12a5:	00 07                	add    BYTE PTR [bx],al
    12a7:	50                   	push   ax
    12a8:	61                   	popa
    12a9:	6e                   	outs   dx,BYTE PTR ds:[si]
    12aa:	65 6c                	gs ins BYTE PTR es:[di],dx
    12ac:	31 30                	xor    WORD PTR [bx+si],si
    12ae:	4c                   	dec    sp
    12af:	04 2c                	add    al,0x2c
    12b1:	00 07                	add    BYTE PTR [bx],al
    12b3:	44                   	inc    sp
    12b4:	42                   	inc    dx
    12b5:	45                   	inc    bp
    12b6:	64 69 74 31 50 04    	imul   si,WORD PTR fs:[si+0x31],0x450
    12bc:	2c 00                	sub    al,0x0
    12be:	07                   	pop    es
    12bf:	44                   	inc    sp
    12c0:	42                   	inc    dx
    12c1:	45                   	inc    bp
    12c2:	64 69 74 32 54 04    	imul   si,WORD PTR fs:[si+0x32],0x454
    12c8:	00 00                	add    BYTE PTR [bx+si],al
    12ca:	07                   	pop    es
    12cb:	50                   	push   ax
    12cc:	61                   	popa
    12cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    12ce:	65 6c                	gs ins BYTE PTR es:[di],dx
    12d0:	31 32                	xor    WORD PTR [bp+si],si
    12d2:	58                   	pop    ax
    12d3:	04 00                	add    al,0x0
    12d5:	00 07                	add    BYTE PTR [bx],al
    12d7:	50                   	push   ax
    12d8:	61                   	popa
    12d9:	6e                   	outs   dx,BYTE PTR ds:[si]
    12da:	65 6c                	gs ins BYTE PTR es:[di],dx
    12dc:	31 33                	xor    WORD PTR [bp+di],si
    12de:	5c                   	pop    sp
    12df:	04 00                	add    al,0x0
    12e1:	00 07                	add    BYTE PTR [bx],al
    12e3:	50                   	push   ax
    12e4:	61                   	popa
    12e5:	6e                   	outs   dx,BYTE PTR ds:[si]
    12e6:	65 6c                	gs ins BYTE PTR es:[di],dx
    12e8:	31 34                	xor    WORD PTR [si],si
    12ea:	60                   	pusha
    12eb:	04 00                	add    al,0x0
    12ed:	00 07                	add    BYTE PTR [bx],al
    12ef:	50                   	push   ax
    12f0:	61                   	popa
    12f1:	6e                   	outs   dx,BYTE PTR ds:[si]
    12f2:	65 6c                	gs ins BYTE PTR es:[di],dx
    12f4:	31 35                	xor    WORD PTR [di],si
    12f6:	64 04 2c             	fs add al,0x2c
    12f9:	00 07                	add    BYTE PTR [bx],al
    12fb:	44                   	inc    sp
    12fc:	42                   	inc    dx
    12fd:	45                   	inc    bp
    12fe:	64 69 74 35 68 04    	imul   si,WORD PTR fs:[si+0x35],0x468
    1304:	2c 00                	sub    al,0x0
    1306:	08 44 42             	or     BYTE PTR [si+0x42],al
    1309:	45                   	inc    bp
    130a:	64 69 74 32 33 6c    	imul   si,WORD PTR fs:[si+0x32],0x6c33
    1310:	04 2c                	add    al,0x2c
    1312:	00 08                	add    BYTE PTR [bx+si],cl
    1314:	44                   	inc    sp
    1315:	42                   	inc    dx
    1316:	45                   	inc    bp
    1317:	64 69 74 32 34 70    	imul   si,WORD PTR fs:[si+0x32],0x7034
    131d:	04 2c                	add    al,0x2c
    131f:	00 08                	add    BYTE PTR [bx+si],cl
    1321:	44                   	inc    sp
    1322:	42                   	inc    dx
    1323:	45                   	inc    bp
    1324:	64 69 74 32 35 74    	imul   si,WORD PTR fs:[si+0x32],0x7435
    132a:	04 2c                	add    al,0x2c
    132c:	00 08                	add    BYTE PTR [bx+si],cl
    132e:	44                   	inc    sp
    132f:	42                   	inc    dx
    1330:	45                   	inc    bp
    1331:	64 69 74 32 37 78    	imul   si,WORD PTR fs:[si+0x32],0x7837
    1337:	04 2c                	add    al,0x2c
    1339:	00 08                	add    BYTE PTR [bx+si],cl
    133b:	44                   	inc    sp
    133c:	42                   	inc    dx
    133d:	45                   	inc    bp
    133e:	64 69 74 34 33 7c    	imul   si,WORD PTR fs:[si+0x34],0x7c33
    1344:	04 2c                	add    al,0x2c
    1346:	00 08                	add    BYTE PTR [bx+si],cl
    1348:	44                   	inc    sp
    1349:	42                   	inc    dx
    134a:	45                   	inc    bp
    134b:	64 69 74 34 34 80    	imul   si,WORD PTR fs:[si+0x34],0x8034
    1351:	04 2c                	add    al,0x2c
    1353:	00 08                	add    BYTE PTR [bx+si],cl
    1355:	44                   	inc    sp
    1356:	42                   	inc    dx
    1357:	45                   	inc    bp
    1358:	64 69 74 34 37 84    	imul   si,WORD PTR fs:[si+0x34],0x8437
    135e:	04 2c                	add    al,0x2c
    1360:	00 08                	add    BYTE PTR [bx+si],cl
    1362:	44                   	inc    sp
    1363:	42                   	inc    dx
    1364:	45                   	inc    bp
    1365:	64 69 74 34 38 88    	imul   si,WORD PTR fs:[si+0x34],0x8838
    136b:	04 00                	add    al,0x0
    136d:	00 07                	add    BYTE PTR [bx],al
    136f:	50                   	push   ax
    1370:	61                   	popa
    1371:	6e                   	outs   dx,BYTE PTR ds:[si]
    1372:	65 6c                	gs ins BYTE PTR es:[di],dx
    1374:	31 31                	xor    WORD PTR [bx+di],si
    1376:	8c 04                	mov    WORD PTR [si],es
    1378:	28 00                	sub    BYTE PTR [bx+si],al
    137a:	06                   	push   es
    137b:	53                   	push   bx
    137c:	68 61 70             	push   0x7061
    137f:	65 35 90 04          	gs xor ax,0x490
    1383:	00 00                	add    BYTE PTR [bx+si],al
    1385:	07                   	pop    es
    1386:	50                   	push   ax
    1387:	61                   	popa
    1388:	6e                   	outs   dx,BYTE PTR ds:[si]
    1389:	65 6c                	gs ins BYTE PTR es:[di],dx
    138b:	31 36 94 04          	xor    WORD PTR ds:0x494,si
    138f:	2c 00                	sub    al,0x0
    1391:	07                   	pop    es
    1392:	44                   	inc    sp
    1393:	42                   	inc    dx
    1394:	45                   	inc    bp
    1395:	64 69 74 33 98 04    	imul   si,WORD PTR fs:[si+0x33],0x498
    139b:	2c 00                	sub    al,0x0
    139d:	08 44 42             	or     BYTE PTR [si+0x42],al
    13a0:	45                   	inc    bp
    13a1:	64 69 74 34 35 9c    	imul   si,WORD PTR fs:[si+0x34],0x9c35
    13a7:	04 2c                	add    al,0x2c
    13a9:	00 08                	add    BYTE PTR [bx+si],cl
    13ab:	44                   	inc    sp
    13ac:	42                   	inc    dx
    13ad:	45                   	inc    bp
    13ae:	64 69 74 34 36 a0    	imul   si,WORD PTR fs:[si+0x34],0xa036
    13b4:	04 2c                	add    al,0x2c
    13b6:	00 07                	add    BYTE PTR [bx],al
    13b8:	44                   	inc    sp
    13b9:	42                   	inc    dx
    13ba:	45                   	inc    bp
    13bb:	64 69 74 34 a4 04    	imul   si,WORD PTR fs:[si+0x34],0x4a4
    13c1:	2c 00                	sub    al,0x0
    13c3:	08 44 42             	or     BYTE PTR [si+0x42],al
    13c6:	45                   	inc    bp
    13c7:	64 69 74 32 36 a8    	imul   si,WORD PTR fs:[si+0x32],0xa836
    13cd:	04 00                	add    al,0x0
    13cf:	00 07                	add    BYTE PTR [bx],al
    13d1:	50                   	push   ax
    13d2:	61                   	popa
    13d3:	6e                   	outs   dx,BYTE PTR ds:[si]
    13d4:	65 6c                	gs ins BYTE PTR es:[di],dx
    13d6:	31 37                	xor    WORD PTR [bx],si
    13d8:	ac                   	lods   al,BYTE PTR ds:[si]
    13d9:	04 00                	add    al,0x0
    13db:	00 07                	add    BYTE PTR [bx],al
    13dd:	50                   	push   ax
    13de:	61                   	popa
    13df:	6e                   	outs   dx,BYTE PTR ds:[si]
    13e0:	65 6c                	gs ins BYTE PTR es:[di],dx
    13e2:	34 38                	xor    al,0x38
    13e4:	b0 04                	mov    al,0x4
    13e6:	00 00                	add    BYTE PTR [bx+si],al
    13e8:	06                   	push   es
    13e9:	50                   	push   ax
    13ea:	61                   	popa
    13eb:	6e                   	outs   dx,BYTE PTR ds:[si]
    13ec:	65 6c                	gs ins BYTE PTR es:[di],dx
    13ee:	39 b4 04 24          	cmp    WORD PTR [si+0x2404],si
    13f2:	00 09                	add    BYTE PTR [bx+di],cl
    13f4:	47                   	inc    di
    13f5:	72 6f                	jb     0x1466
    13f7:	75 70                	jne    0x1469
    13f9:	42                   	inc    dx
    13fa:	6f                   	outs   dx,WORD PTR ds:[si]
    13fb:	78 32                	js     0x142f
    13fd:	b8 04 28             	mov    ax,0x2804
    1400:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
    1404:	61                   	popa
    1405:	70 65                	jo     0x146c
    1407:	33 bc 04 28          	xor    di,WORD PTR [si+0x2804]
    140b:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
    140f:	61                   	popa
    1410:	70 65                	jo     0x1477
    1412:	31 c0                	xor    ax,ax
    1414:	04 00                	add    al,0x0
    1416:	00 07                	add    BYTE PTR [bx],al
    1418:	50                   	push   ax
    1419:	61                   	popa
    141a:	6e                   	outs   dx,BYTE PTR ds:[si]
    141b:	65 6c                	gs ins BYTE PTR es:[di],dx
    141d:	31 39                	xor    WORD PTR [bx+di],di
    141f:	c4 04                	les    ax,DWORD PTR [si]
    1421:	00 00                	add    BYTE PTR [bx+si],al
    1423:	07                   	pop    es
    1424:	50                   	push   ax
    1425:	61                   	popa
    1426:	6e                   	outs   dx,BYTE PTR ds:[si]
    1427:	65 6c                	gs ins BYTE PTR es:[di],dx
    1429:	32 32                	xor    dh,BYTE PTR [bp+si]
    142b:	c8 04 00 00          	enter  0x4,0x0
    142f:	07                   	pop    es
    1430:	50                   	push   ax
    1431:	61                   	popa
    1432:	6e                   	outs   dx,BYTE PTR ds:[si]
    1433:	65 6c                	gs ins BYTE PTR es:[di],dx
    1435:	32 33                	xor    dh,BYTE PTR [bp+di]
    1437:	cc                   	int3
    1438:	04 00                	add    al,0x0
    143a:	00 07                	add    BYTE PTR [bx],al
    143c:	50                   	push   ax
    143d:	61                   	popa
    143e:	6e                   	outs   dx,BYTE PTR ds:[si]
    143f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1441:	32 34                	xor    dh,BYTE PTR [si]
    1443:	d0 04                	rol    BYTE PTR [si],1
    1445:	00 00                	add    BYTE PTR [bx+si],al
    1447:	07                   	pop    es
    1448:	50                   	push   ax
    1449:	61                   	popa
    144a:	6e                   	outs   dx,BYTE PTR ds:[si]
    144b:	65 6c                	gs ins BYTE PTR es:[di],dx
    144d:	32 38                	xor    bh,BYTE PTR [bx+si]
    144f:	d4 04                	aam    0x4
    1451:	00 00                	add    BYTE PTR [bx+si],al
    1453:	07                   	pop    es
    1454:	50                   	push   ax
    1455:	61                   	popa
    1456:	6e                   	outs   dx,BYTE PTR ds:[si]
    1457:	65 6c                	gs ins BYTE PTR es:[di],dx
    1459:	32 39                	xor    bh,BYTE PTR [bx+di]
    145b:	d8 04                	fadd   DWORD PTR [si]
    145d:	00 00                	add    BYTE PTR [bx+si],al
    145f:	07                   	pop    es
    1460:	50                   	push   ax
    1461:	61                   	popa
    1462:	6e                   	outs   dx,BYTE PTR ds:[si]
    1463:	65 6c                	gs ins BYTE PTR es:[di],dx
    1465:	33 30                	xor    si,WORD PTR [bx+si]
    1467:	dc 04                	fadd   QWORD PTR [si]
    1469:	00 00                	add    BYTE PTR [bx+si],al
    146b:	07                   	pop    es
    146c:	50                   	push   ax
    146d:	61                   	popa
    146e:	6e                   	outs   dx,BYTE PTR ds:[si]
    146f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1471:	33 31                	xor    si,WORD PTR [bx+di]
    1473:	e0 04                	loopne 0x1479
    1475:	00 00                	add    BYTE PTR [bx+si],al
    1477:	07                   	pop    es
    1478:	50                   	push   ax
    1479:	61                   	popa
    147a:	6e                   	outs   dx,BYTE PTR ds:[si]
    147b:	65 6c                	gs ins BYTE PTR es:[di],dx
    147d:	33 32                	xor    si,WORD PTR [bp+si]
    147f:	e4 04                	in     al,0x4
    1481:	00 00                	add    BYTE PTR [bx+si],al
    1483:	07                   	pop    es
    1484:	50                   	push   ax
    1485:	61                   	popa
    1486:	6e                   	outs   dx,BYTE PTR ds:[si]
    1487:	65 6c                	gs ins BYTE PTR es:[di],dx
    1489:	33 33                	xor    si,WORD PTR [bp+di]
    148b:	e8 04 2c             	call   0x4092
    148e:	00 07                	add    BYTE PTR [bx],al
    1490:	44                   	inc    sp
    1491:	42                   	inc    dx
    1492:	45                   	inc    bp
    1493:	64 69 74 36 ec 04    	imul   si,WORD PTR fs:[si+0x36],0x4ec
    1499:	2c 00                	sub    al,0x0
    149b:	07                   	pop    es
    149c:	44                   	inc    sp
    149d:	42                   	inc    dx
    149e:	45                   	inc    bp
    149f:	64 69 74 37 f0 04    	imul   si,WORD PTR fs:[si+0x37],0x4f0
    14a5:	2c 00                	sub    al,0x0
    14a7:	07                   	pop    es
    14a8:	44                   	inc    sp
    14a9:	42                   	inc    dx
    14aa:	45                   	inc    bp
    14ab:	64 69 74 38 f4 04    	imul   si,WORD PTR fs:[si+0x38],0x4f4
    14b1:	2c 00                	sub    al,0x0
    14b3:	07                   	pop    es
    14b4:	44                   	inc    sp
    14b5:	42                   	inc    dx
    14b6:	45                   	inc    bp
    14b7:	64 69 74 39 f8 04    	imul   si,WORD PTR fs:[si+0x39],0x4f8
    14bd:	2c 00                	sub    al,0x0
    14bf:	08 44 42             	or     BYTE PTR [si+0x42],al
    14c2:	45                   	inc    bp
    14c3:	64 69 74 31 30 fc    	imul   si,WORD PTR fs:[si+0x31],0xfc30
    14c9:	04 2c                	add    al,0x2c
    14cb:	00 08                	add    BYTE PTR [bx+si],cl
    14cd:	44                   	inc    sp
    14ce:	42                   	inc    dx
    14cf:	45                   	inc    bp
    14d0:	64 69 74 31 31 00    	imul   si,WORD PTR fs:[si+0x31],0x31
    14d6:	05 00 00             	add    ax,0x0
    14d9:	07                   	pop    es
    14da:	50                   	push   ax
    14db:	61                   	popa
    14dc:	6e                   	outs   dx,BYTE PTR ds:[si]
    14dd:	65 6c                	gs ins BYTE PTR es:[di],dx
    14df:	32 31                	xor    dh,BYTE PTR [bx+di]
    14e1:	04 05                	add    al,0x5
    14e3:	2c 00                	sub    al,0x0
    14e5:	08 44 42             	or     BYTE PTR [si+0x42],al
    14e8:	45                   	inc    bp
    14e9:	64 69 74 31 38 08    	imul   si,WORD PTR fs:[si+0x31],0x838
    14ef:	05 2c 00             	add    ax,0x2c
    14f2:	08 44 42             	or     BYTE PTR [si+0x42],al
    14f5:	45                   	inc    bp
    14f6:	64 69 74 31 39 0c    	imul   si,WORD PTR fs:[si+0x31],0xc39
    14fc:	05 2c 00             	add    ax,0x2c
    14ff:	08 44 42             	or     BYTE PTR [si+0x42],al
    1502:	45                   	inc    bp
    1503:	64 69 74 32 30 10    	imul   si,WORD PTR fs:[si+0x32],0x1030
    1509:	05 2c 00             	add    ax,0x2c
    150c:	08 44 42             	or     BYTE PTR [si+0x42],al
    150f:	45                   	inc    bp
    1510:	64 69 74 32 38 14    	imul   si,WORD PTR fs:[si+0x32],0x1438
    1516:	05 2c 00             	add    ax,0x2c
    1519:	08 44 42             	or     BYTE PTR [si+0x42],al
    151c:	45                   	inc    bp
    151d:	64 69 74 32 39 18    	imul   si,WORD PTR fs:[si+0x32],0x1839
    1523:	05 2c 00             	add    ax,0x2c
    1526:	08 44 42             	or     BYTE PTR [si+0x42],al
    1529:	45                   	inc    bp
    152a:	64 69 74 33 30 1c    	imul   si,WORD PTR fs:[si+0x33],0x1c30
    1530:	05 2c 00             	add    ax,0x2c
    1533:	08 44 42             	or     BYTE PTR [si+0x42],al
    1536:	45                   	inc    bp
    1537:	64 69 74 33 31 20    	imul   si,WORD PTR fs:[si+0x33],0x2031
    153d:	05 2c 00             	add    ax,0x2c
    1540:	08 44 42             	or     BYTE PTR [si+0x42],al
    1543:	45                   	inc    bp
    1544:	64 69 74 33 32 24    	imul   si,WORD PTR fs:[si+0x33],0x2432
    154a:	05 2c 00             	add    ax,0x2c
    154d:	08 44 42             	or     BYTE PTR [si+0x42],al
    1550:	45                   	inc    bp
    1551:	64 69 74 33 33 28    	imul   si,WORD PTR fs:[si+0x33],0x2833
    1557:	05 2c 00             	add    ax,0x2c
    155a:	08 44 42             	or     BYTE PTR [si+0x42],al
    155d:	45                   	inc    bp
    155e:	64 69 74 33 36 2c    	imul   si,WORD PTR fs:[si+0x33],0x2c36
    1564:	05 2c 00             	add    ax,0x2c
    1567:	08 44 42             	or     BYTE PTR [si+0x42],al
    156a:	45                   	inc    bp
    156b:	64 69 74 34 39 30    	imul   si,WORD PTR fs:[si+0x34],0x3039
    1571:	05 2c 00             	add    ax,0x2c
    1574:	08 44 42             	or     BYTE PTR [si+0x42],al
    1577:	45                   	inc    bp
    1578:	64 69 74 35 31 34    	imul   si,WORD PTR fs:[si+0x35],0x3431
    157e:	05 2c 00             	add    ax,0x2c
    1581:	08 44 42             	or     BYTE PTR [si+0x42],al
    1584:	45                   	inc    bp
    1585:	64 69 74 33 34 38    	imul   si,WORD PTR fs:[si+0x33],0x3834
    158b:	05 00 00             	add    ax,0x0
    158e:	07                   	pop    es
    158f:	50                   	push   ax
    1590:	61                   	popa
    1591:	6e                   	outs   dx,BYTE PTR ds:[si]
    1592:	65 6c                	gs ins BYTE PTR es:[di],dx
    1594:	32 35                	xor    dh,BYTE PTR [di]
    1596:	3c 05                	cmp    al,0x5
    1598:	2c 00                	sub    al,0x0
    159a:	08 44 42             	or     BYTE PTR [si+0x42],al
    159d:	45                   	inc    bp
    159e:	64 69 74 35 32 40    	imul   si,WORD PTR fs:[si+0x35],0x4032
    15a4:	05 00 00             	add    ax,0x0
    15a7:	07                   	pop    es
    15a8:	50                   	push   ax
    15a9:	61                   	popa
    15aa:	6e                   	outs   dx,BYTE PTR ds:[si]
    15ab:	65 6c                	gs ins BYTE PTR es:[di],dx
    15ad:	34 34                	xor    al,0x34
    15af:	44                   	inc    sp
    15b0:	05 2c 00             	add    ax,0x2c
    15b3:	08 44 42             	or     BYTE PTR [si+0x42],al
    15b6:	45                   	inc    bp
    15b7:	64 69 74 35 36 48    	imul   si,WORD PTR fs:[si+0x35],0x4836
    15bd:	05 00 00             	add    ax,0x0
    15c0:	07                   	pop    es
    15c1:	50                   	push   ax
    15c2:	61                   	popa
    15c3:	6e                   	outs   dx,BYTE PTR ds:[si]
    15c4:	65 6c                	gs ins BYTE PTR es:[di],dx
    15c6:	31 38                	xor    WORD PTR [bx+si],di
    15c8:	4c                   	dec    sp
    15c9:	05 28 00             	add    ax,0x28
    15cc:	06                   	push   es
    15cd:	53                   	push   bx
    15ce:	68 61 70             	push   0x7061
    15d1:	65 32 50 05          	xor    dl,BYTE PTR gs:[bx+si+0x5]
    15d5:	00 00                	add    BYTE PTR [bx+si],al
    15d7:	07                   	pop    es
    15d8:	50                   	push   ax
    15d9:	61                   	popa
    15da:	6e                   	outs   dx,BYTE PTR ds:[si]
    15db:	65 6c                	gs ins BYTE PTR es:[di],dx
    15dd:	32 30                	xor    dh,BYTE PTR [bx+si]
    15df:	54                   	push   sp
    15e0:	05 2c 00             	add    ax,0x2c
    15e3:	08 44 42             	or     BYTE PTR [si+0x42],al
    15e6:	45                   	inc    bp
    15e7:	64 69 74 31 32 58    	imul   si,WORD PTR fs:[si+0x31],0x5832
    15ed:	05 2c 00             	add    ax,0x2c
    15f0:	08 44 42             	or     BYTE PTR [si+0x42],al
    15f3:	45                   	inc    bp
    15f4:	64 69 74 31 34 5c    	imul   si,WORD PTR fs:[si+0x31],0x5c34
    15fa:	05 2c 00             	add    ax,0x2c
    15fd:	08 44 42             	or     BYTE PTR [si+0x42],al
    1600:	45                   	inc    bp
    1601:	64 69 74 35 30 60    	imul   si,WORD PTR fs:[si+0x35],0x6030
    1607:	05 2c 00             	add    ax,0x2c
    160a:	08 44 42             	or     BYTE PTR [si+0x42],al
    160d:	45                   	inc    bp
    160e:	64 69 74 31 33 64    	imul   si,WORD PTR fs:[si+0x31],0x6433
    1614:	05 2c 00             	add    ax,0x2c
    1617:	08 44 42             	or     BYTE PTR [si+0x42],al
    161a:	45                   	inc    bp
    161b:	64 69 74 31 35 68    	imul   si,WORD PTR fs:[si+0x31],0x6835
    1621:	05 2c 00             	add    ax,0x2c
    1624:	08 44 42             	or     BYTE PTR [si+0x42],al
    1627:	45                   	inc    bp
    1628:	64 69 74 31 36 6c    	imul   si,WORD PTR fs:[si+0x31],0x6c36
    162e:	05 2c 00             	add    ax,0x2c
    1631:	08 44 42             	or     BYTE PTR [si+0x42],al
    1634:	45                   	inc    bp
    1635:	64 69 74 31 37 70    	imul   si,WORD PTR fs:[si+0x31],0x7037
    163b:	05 2c 00             	add    ax,0x2c
    163e:	08 44 42             	or     BYTE PTR [si+0x42],al
    1641:	45                   	inc    bp
    1642:	64 69 74 33 35 74    	imul   si,WORD PTR fs:[si+0x33],0x7435
    1648:	05 00 00             	add    ax,0x0
    164b:	07                   	pop    es
    164c:	50                   	push   ax
    164d:	61                   	popa
    164e:	6e                   	outs   dx,BYTE PTR ds:[si]
    164f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1651:	34 39                	xor    al,0x39
    1653:	78 05                	js     0x165a
    1655:	00 00                	add    BYTE PTR [bx+si],al
    1657:	07                   	pop    es
    1658:	50                   	push   ax
    1659:	61                   	popa
    165a:	6e                   	outs   dx,BYTE PTR ds:[si]
    165b:	65 6c                	gs ins BYTE PTR es:[di],dx
    165d:	33 34                	xor    si,WORD PTR [si]
    165f:	7c 05                	jl     0x1666
    1661:	24 00                	and    al,0x0
    1663:	09 47 72             	or     WORD PTR [bx+0x72],ax
    1666:	6f                   	outs   dx,WORD PTR ds:[si]
    1667:	75 70                	jne    0x16d9
    1669:	42                   	inc    dx
    166a:	6f                   	outs   dx,WORD PTR ds:[si]
    166b:	78 33                	js     0x16a0
    166d:	80 05 00             	add    BYTE PTR [di],0x0
    1670:	00 07                	add    BYTE PTR [bx],al
    1672:	50                   	push   ax
    1673:	61                   	popa
    1674:	6e                   	outs   dx,BYTE PTR ds:[si]
    1675:	65 6c                	gs ins BYTE PTR es:[di],dx
    1677:	33 35                	xor    si,WORD PTR [di]
    1679:	84 05                	test   BYTE PTR [di],al
    167b:	00 00                	add    BYTE PTR [bx+si],al
    167d:	07                   	pop    es
    167e:	50                   	push   ax
    167f:	61                   	popa
    1680:	6e                   	outs   dx,BYTE PTR ds:[si]
    1681:	65 6c                	gs ins BYTE PTR es:[di],dx
    1683:	35 30 88             	xor    ax,0x8830
    1686:	05 2c 00             	add    ax,0x2c
    1689:	08 44 42             	or     BYTE PTR [si+0x42],al
    168c:	45                   	inc    bp
    168d:	64 69 74 32 31 8c    	imul   si,WORD PTR fs:[si+0x32],0x8c31
    1693:	05 2c 00             	add    ax,0x2c
    1696:	08 44 42             	or     BYTE PTR [si+0x42],al
    1699:	45                   	inc    bp
    169a:	64 69 74 32 32 90    	imul   si,WORD PTR fs:[si+0x32],0x9032
    16a0:	05 2c 00             	add    ax,0x2c
    16a3:	08 44 42             	or     BYTE PTR [si+0x42],al
    16a6:	45                   	inc    bp
    16a7:	64 69 74 33 37 94    	imul   si,WORD PTR fs:[si+0x33],0x9437
    16ad:	05 00 00             	add    ax,0x0
    16b0:	07                   	pop    es
    16b1:	50                   	push   ax
    16b2:	61                   	popa
    16b3:	6e                   	outs   dx,BYTE PTR ds:[si]
    16b4:	65 6c                	gs ins BYTE PTR es:[di],dx
    16b6:	33 36 98 05          	xor    si,WORD PTR ds:0x598
    16ba:	24 00                	and    al,0x0
    16bc:	09 47 72             	or     WORD PTR [bx+0x72],ax
    16bf:	6f                   	outs   dx,WORD PTR ds:[si]
    16c0:	75 70                	jne    0x1732
    16c2:	42                   	inc    dx
    16c3:	6f                   	outs   dx,WORD PTR ds:[si]
    16c4:	78 34                	js     0x16fa
    16c6:	9c                   	pushf
    16c7:	05 28 00             	add    ax,0x28
    16ca:	06                   	push   es
    16cb:	53                   	push   bx
    16cc:	68 61 70             	push   0x7061
    16cf:	65 38 a0 05 28       	cmp    BYTE PTR gs:[bx+si+0x2805],ah
    16d4:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
    16d8:	61                   	popa
    16d9:	70 65                	jo     0x1740
    16db:	39 a4 05 00          	cmp    WORD PTR [si+0x5],sp
    16df:	00 07                	add    BYTE PTR [bx],al
    16e1:	50                   	push   ax
    16e2:	61                   	popa
    16e3:	6e                   	outs   dx,BYTE PTR ds:[si]
    16e4:	65 6c                	gs ins BYTE PTR es:[di],dx
    16e6:	33 39                	xor    di,WORD PTR [bx+di]
    16e8:	a8 05                	test   al,0x5
    16ea:	00 00                	add    BYTE PTR [bx+si],al
    16ec:	07                   	pop    es
    16ed:	50                   	push   ax
    16ee:	61                   	popa
    16ef:	6e                   	outs   dx,BYTE PTR ds:[si]
    16f0:	65 6c                	gs ins BYTE PTR es:[di],dx
    16f2:	34 30                	xor    al,0x30
    16f4:	ac                   	lods   al,BYTE PTR ds:[si]
    16f5:	05 00 00             	add    ax,0x0
    16f8:	07                   	pop    es
    16f9:	50                   	push   ax
    16fa:	61                   	popa
    16fb:	6e                   	outs   dx,BYTE PTR ds:[si]
    16fc:	65 6c                	gs ins BYTE PTR es:[di],dx
    16fe:	34 31                	xor    al,0x31
    1700:	b0 05                	mov    al,0x5
    1702:	00 00                	add    BYTE PTR [bx+si],al
    1704:	07                   	pop    es
    1705:	50                   	push   ax
    1706:	61                   	popa
    1707:	6e                   	outs   dx,BYTE PTR ds:[si]
    1708:	65 6c                	gs ins BYTE PTR es:[di],dx
    170a:	34 32                	xor    al,0x32
    170c:	b4 05                	mov    ah,0x5
    170e:	00 00                	add    BYTE PTR [bx+si],al
    1710:	07                   	pop    es
    1711:	50                   	push   ax
    1712:	61                   	popa
    1713:	6e                   	outs   dx,BYTE PTR ds:[si]
    1714:	65 6c                	gs ins BYTE PTR es:[di],dx
    1716:	34 33                	xor    al,0x33
    1718:	b8 05 2c             	mov    ax,0x2c05
    171b:	00 08                	add    BYTE PTR [bx+si],cl
    171d:	44                   	inc    sp
    171e:	42                   	inc    dx
    171f:	45                   	inc    bp
    1720:	64 69 74 33 38 bc    	imul   si,WORD PTR fs:[si+0x33],0xbc38
    1726:	05 2c 00             	add    ax,0x2c
    1729:	08 44 42             	or     BYTE PTR [si+0x42],al
    172c:	45                   	inc    bp
    172d:	64 69 74 33 39 c0    	imul   si,WORD PTR fs:[si+0x33],0xc039
    1733:	05 2c 00             	add    ax,0x2c
    1736:	08 44 42             	or     BYTE PTR [si+0x42],al
    1739:	45                   	inc    bp
    173a:	64 69 74 34 30 c4    	imul   si,WORD PTR fs:[si+0x34],0xc430
    1740:	05 2c 00             	add    ax,0x2c
    1743:	08 44 42             	or     BYTE PTR [si+0x42],al
    1746:	45                   	inc    bp
    1747:	64 69 74 34 31 c8    	imul   si,WORD PTR fs:[si+0x34],0xc831
    174d:	05 2c 00             	add    ax,0x2c
    1750:	08 44 42             	or     BYTE PTR [si+0x42],al
    1753:	45                   	inc    bp
    1754:	64 69 74 34 32 cc    	imul   si,WORD PTR fs:[si+0x34],0xcc32
    175a:	05 00 00             	add    ax,0x0
    175d:	07                   	pop    es
    175e:	50                   	push   ax
    175f:	61                   	popa
    1760:	6e                   	outs   dx,BYTE PTR ds:[si]
    1761:	65 6c                	gs ins BYTE PTR es:[di],dx
    1763:	35 31 d0             	xor    ax,0xd031
    1766:	05 2c 00             	add    ax,0x2c
    1769:	08 44 42             	or     BYTE PTR [si+0x42],al
    176c:	45                   	inc    bp
    176d:	64 69 74 35 35 d4    	imul   si,WORD PTR fs:[si+0x35],0xd435
    1773:	05 00 00             	add    ax,0x0
    1776:	07                   	pop    es
    1777:	50                   	push   ax
    1778:	61                   	popa
    1779:	6e                   	outs   dx,BYTE PTR ds:[si]
    177a:	65 6c                	gs ins BYTE PTR es:[di],dx
    177c:	35 32 d8             	xor    ax,0xd832
    177f:	05 30 00             	add    ax,0x30
    1782:	07                   	pop    es
    1783:	4c                   	dec    sp
    1784:	61                   	popa
    1785:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1788:	55                   	push   bp
    1789:	30 dc                	xor    ah,bl
    178b:	05 30 00             	add    ax,0x30
    178e:	07                   	pop    es
    178f:	4c                   	dec    sp
    1790:	61                   	popa
    1791:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1794:	55                   	push   bp
    1795:	31 e0                	xor    ax,sp
    1797:	05 30 00             	add    ax,0x30
    179a:	07                   	pop    es
    179b:	4c                   	dec    sp
    179c:	61                   	popa
    179d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    17a0:	55                   	push   bp
    17a1:	32 e4                	xor    ah,ah
    17a3:	05 30 00             	add    ax,0x30
    17a6:	07                   	pop    es
    17a7:	4c                   	dec    sp
    17a8:	61                   	popa
    17a9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    17ac:	55                   	push   bp
    17ad:	33 e8                	xor    bp,ax
    17af:	05 08 00             	add    ax,0x8
    17b2:	08 45 64             	or     BYTE PTR [di+0x64],al
    17b5:	69 74 69 6f 6e       	imul   si,WORD PTR [si+0x69],0x6e6f
    17ba:	31 ec                	xor    sp,bp
    17bc:	05 08 00             	add    ax,0x8
    17bf:	07                   	pop    es
    17c0:	43                   	inc    bx
    17c1:	6f                   	outs   dx,WORD PTR ds:[si]
    17c2:	70 69                	jo     0x182d
    17c4:	65 72 31             	gs jb  0x17f8
    17c7:	f0 05 34 00          	lock add ax,0x34
    17cb:	05 4d 65             	add    ax,0x654d
    17ce:	6d                   	ins    WORD PTR es:[di],dx
    17cf:	6f                   	outs   dx,WORD PTR ds:[si]
    17d0:	31 f4                	xor    sp,si
    17d2:	05 00 00             	add    ax,0x0
    17d5:	06                   	push   es
    17d6:	50                   	push   ax
    17d7:	61                   	popa
    17d8:	6e                   	outs   dx,BYTE PTR ds:[si]
    17d9:	65 6c                	gs ins BYTE PTR es:[di],dx
    17db:	31 f8                	xor    ax,di
    17dd:	05 2c 00             	add    ax,0x2c
    17e0:	08 44 42             	or     BYTE PTR [si+0x42],al
    17e3:	45                   	inc    bp
    17e4:	64 69 74 35 37 fc    	imul   si,WORD PTR fs:[si+0x35],0xfc37
    17ea:	05 20 00             	add    ax,0x20
    17ed:	13 54 61             	adc    dx,WORD PTR [si+0x61]
    17f0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    17f3:	45                   	inc    bp
    17f4:	52                   	push   dx
    17f5:	47                   	inc    di
    17f6:	52                   	push   dx
    17f7:	65 70 61             	gs jo  0x185b
    17fa:	72 61                	jb     0x185d
    17fc:	74 69                	je     0x1867
    17fe:	6f                   	outs   dx,WORD PTR ds:[si]
    17ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    1800:	73 00                	jae    0x1802
    1802:	06                   	push   es
    1803:	20 00                	and    BYTE PTR [bx+si],al
    1805:	15 54 61             	adc    ax,0x6154
    1808:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    180b:	45                   	inc    bp
    180c:	52                   	push   dx
    180d:	47                   	inc    di
    180e:	52                   	push   dx
    180f:	65 6d                	gs ins WORD PTR es:[di],dx
    1811:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    1814:	72 73                	jb     0x1889
    1816:	41                   	inc    cx
    1817:	73 73                	jae    0x188c
    1819:	75 72                	jne    0x188d
    181b:	04 06                	add    al,0x6
    181d:	20 00                	and    BYTE PTR [bx+si],al
    181f:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1822:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1825:	45                   	inc    bp
    1826:	52                   	push   dx
    1827:	47                   	inc    di
    1828:	49                   	dec    cx
    1829:	6e                   	outs   dx,BYTE PTR ds:[si]
    182a:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    1830:	74 69                	je     0x189b
    1832:	73 50                	jae    0x1884
    1834:	65 72 73             	gs jb  0x18aa
    1837:	6f                   	outs   dx,WORD PTR ds:[si]
    1838:	6e                   	outs   dx,BYTE PTR ds:[si]
    1839:	08 06 20 00          	or     BYTE PTR ds:0x20,al
    183d:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1840:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1843:	45                   	inc    bp
    1844:	52                   	push   dx
    1845:	47                   	inc    di
    1846:	49                   	dec    cx
    1847:	6e                   	outs   dx,BYTE PTR ds:[si]
    1848:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    184e:	74 69                	je     0x18b9
    1850:	73 41                	jae    0x1893
    1852:	63 74 69             	arpl   WORD PTR [si+0x69],si
    1855:	6f                   	outs   dx,WORD PTR ds:[si]
    1856:	6e                   	outs   dx,BYTE PTR ds:[si]
    1857:	0c 06                	or     al,0x6
    1859:	20 00                	and    BYTE PTR [bx+si],al
    185b:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    185e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1861:	45                   	inc    bp
    1862:	52                   	push   dx
    1863:	47                   	inc    di
    1864:	50                   	push   ax
    1865:	61                   	popa
    1866:	6e                   	outs   dx,BYTE PTR ds:[si]
    1867:	6e                   	outs   dx,BYTE PTR ds:[si]
    1868:	65 73 50             	gs jae 0x18bb
    186b:	63 10                	arpl   WORD PTR [bx+si],dx
    186d:	06                   	push   es
    186e:	20 00                	and    BYTE PTR [bx+si],al
    1870:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    1873:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1876:	45                   	inc    bp
    1877:	52                   	push   dx
    1878:	47                   	inc    di
    1879:	47                   	inc    di
    187a:	72 65                	jb     0x18e1
    187c:	76 65                	jbe    0x18e3
    187e:	73 50                	jae    0x18d0
    1880:	63 14                	arpl   WORD PTR [si],dx
    1882:	06                   	push   es
    1883:	1c 00                	sbb    al,0x0
    1885:	1c 54                	sbb    al,0x54
    1887:	61                   	popa
    1888:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    188b:	45                   	inc    bp
    188c:	52                   	push   dx
    188d:	47                   	inc    di
    188e:	4d                   	dec    bp
    188f:	61                   	popa
    1890:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1893:	6e                   	outs   dx,BYTE PTR ds:[si]
    1894:	65 73 44             	gs jae 0x18db
    1897:	65 74 72             	gs je  0x190c
    189a:	75 69                	jne    0x1905
    189c:	74 65                	je     0x1903
    189e:	73 51                	jae    0x18f1
    18a0:	74 65                	je     0x1907
    18a2:	18 06 1c 00          	sbb    BYTE PTR ds:0x1c,al
    18a6:	17                   	pop    ss
    18a7:	54                   	push   sp
    18a8:	61                   	popa
    18a9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    18ac:	45                   	inc    bp
    18ad:	52                   	push   dx
    18ae:	47                   	inc    di
    18af:	53                   	push   bx
    18b0:	74 6f                	je     0x1921
    18b2:	63 6b 44             	arpl   WORD PTR [bp+di+0x44],bp
    18b5:	65 74 72             	gs je  0x192a
    18b8:	75 69                	jne    0x1923
    18ba:	74 51                	je     0x190d
    18bc:	74 65                	je     0x1923
    18be:	1c 06                	sbb    al,0x6
    18c0:	1c 00                	sbb    al,0x0
    18c2:	1c 54                	sbb    al,0x54
    18c4:	61                   	popa
    18c5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    18c8:	45                   	inc    bp
    18c9:	52                   	push   dx
    18ca:	47                   	inc    di
    18cb:	44                   	inc    sp
    18cc:	65 6d                	gs ins WORD PTR es:[di],dx
    18ce:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    18d3:	6e                   	outs   dx,BYTE PTR ds:[si]
    18d4:	73 50                	jae    0x1926
    18d6:	72 6f                	jb     0x1947
    18d8:	64 75 63             	fs jne 0x193e
    18db:	74 69                	je     0x1946
    18dd:	66 73 20             	data32 jae 0x1900
    18e0:	06                   	push   es
    18e1:	1c 00                	sbb    al,0x0
    18e3:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
    18e6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    18e9:	45                   	inc    bp
    18ea:	52                   	push   dx
    18eb:	47                   	inc    di
    18ec:	44                   	inc    sp
    18ed:	65 6d                	gs ins WORD PTR es:[di],dx
    18ef:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    18f4:	6e                   	outs   dx,BYTE PTR ds:[si]
    18f5:	73 56                	jae    0x194d
    18f7:	65 6e                	outs   dx,BYTE PTR gs:[si]
    18f9:	64 65 75 72          	fs gs jne 0x196f
    18fd:	73 24                	jae    0x1923
    18ff:	06                   	push   es
    1900:	2c 00                	sub    al,0x0
    1902:	08 44 42             	or     BYTE PTR [si+0x42],al
    1905:	45                   	inc    bp
    1906:	64 69 74 35 38 28    	imul   si,WORD PTR fs:[si+0x35],0x2838
    190c:	06                   	push   es
    190d:	2c 00                	sub    al,0x0
    190f:	08 44 42             	or     BYTE PTR [si+0x42],al
    1912:	45                   	inc    bp
    1913:	64 69 74 35 39 2c    	imul   si,WORD PTR fs:[si+0x35],0x2c39
    1919:	06                   	push   es
    191a:	00 00                	add    BYTE PTR [bx+si],al
    191c:	07                   	pop    es
    191d:	50                   	push   ax
    191e:	61                   	popa
    191f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1920:	65 6c                	gs ins BYTE PTR es:[di],dx
    1922:	35 33 30             	xor    ax,0x3033
    1925:	06                   	push   es
    1926:	00 00                	add    BYTE PTR [bx+si],al
    1928:	07                   	pop    es
    1929:	50                   	push   ax
    192a:	61                   	popa
    192b:	6e                   	outs   dx,BYTE PTR ds:[si]
    192c:	65 6c                	gs ins BYTE PTR es:[di],dx
    192e:	35 34 34             	xor    ax,0x3434
    1931:	06                   	push   es
    1932:	00 00                	add    BYTE PTR [bx+si],al
    1934:	07                   	pop    es
    1935:	50                   	push   ax
    1936:	61                   	popa
    1937:	6e                   	outs   dx,BYTE PTR ds:[si]
    1938:	65 6c                	gs ins BYTE PTR es:[di],dx
    193a:	35 35 38             	xor    ax,0x3835
    193d:	06                   	push   es
    193e:	10 00                	adc    BYTE PTR [bx+si],al
    1940:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    1943:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1946:	45                   	inc    bp
    1947:	52                   	push   dx
    1948:	47                   	inc    di
    1949:	50                   	push   ax
    194a:	72 6f                	jb     0x19bb
    194c:	64 75 69             	fs jne 0x19b8
    194f:	74 73                	je     0x19c4
    1951:	45                   	inc    bp
    1952:	78 3c                	js     0x1990
    1954:	06                   	push   es
    1955:	10 00                	adc    BYTE PTR [bx+si],al
    1957:	11 54 61             	adc    WORD PTR [si+0x61],dx
    195a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    195d:	45                   	inc    bp
    195e:	52                   	push   dx
    195f:	47                   	inc    di
    1960:	43                   	inc    bx
    1961:	68 61 72             	push   0x7261
    1964:	67 65 73 45          	addr32 gs jae 0x19ad
    1968:	78 40                	js     0x19aa
    196a:	06                   	push   es
    196b:	00 00                	add    BYTE PTR [bx+si],al
    196d:	07                   	pop    es
    196e:	50                   	push   ax
    196f:	61                   	popa
    1970:	6e                   	outs   dx,BYTE PTR ds:[si]
    1971:	65 6c                	gs ins BYTE PTR es:[di],dx
    1973:	35 36 44             	xor    ax,0x4436
    1976:	06                   	push   es
    1977:	2c 00                	sub    al,0x0
    1979:	08 44 42             	or     BYTE PTR [si+0x42],al
    197c:	45                   	inc    bp
    197d:	64 69 74 36 30 48    	imul   si,WORD PTR fs:[si+0x36],0x4830
    1983:	06                   	push   es
    1984:	20 00                	and    BYTE PTR [bx+si],al
    1986:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    1989:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    198c:	45                   	inc    bp
    198d:	52                   	push   dx
    198e:	47                   	inc    di
    198f:	41                   	inc    cx
    1990:	67 65 4d             	addr32 gs dec bp
    1993:	6f                   	outs   dx,WORD PTR ds:[si]
    1994:	79 65                	jns    0x19fb
    1996:	6e                   	outs   dx,BYTE PTR ds:[si]
    1997:	4d                   	dec    bp
    1998:	61                   	popa
    1999:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    199c:	6e                   	outs   dx,BYTE PTR ds:[si]
    199d:	65 73 4c             	gs jae 0x19ec
    19a0:	06                   	push   es
    19a1:	20 00                	and    BYTE PTR [bx+si],al
    19a3:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    19a6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    19a9:	45                   	inc    bp
    19aa:	52                   	push   dx
    19ab:	47                   	inc    di
    19ac:	45                   	inc    bp
    19ad:	6e                   	outs   dx,BYTE PTR ds:[si]
    19ae:	74 72                	je     0x1a22
    19b0:	65 74 69             	gs je  0x1a1c
    19b3:	65 6e                	outs   dx,BYTE PTR gs:[si]
    19b5:	4d                   	dec    bp
    19b6:	61                   	popa
    19b7:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    19ba:	6e                   	outs   dx,BYTE PTR ds:[si]
    19bb:	65 73 50             	gs jae 0x1a0e
    19be:	06                   	push   es
    19bf:	20 00                	and    BYTE PTR [bx+si],al
    19c1:	17                   	pop    ss
    19c2:	54                   	push   sp
    19c3:	61                   	popa
    19c4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    19c7:	45                   	inc    bp
    19c8:	52                   	push   dx
    19c9:	47                   	inc    di
    19ca:	50                   	push   ax
    19cb:	72 69                	jb     0x1a36
    19cd:	6d                   	ins    WORD PTR es:[di],dx
    19ce:	65 73 41             	gs jae 0x1a12
    19d1:	73 73                	jae    0x1a46
    19d3:	75 72                	jne    0x1a47
    19d5:	61                   	popa
    19d6:	6e                   	outs   dx,BYTE PTR ds:[si]
    19d7:	63 65 54             	arpl   WORD PTR [di+0x54],sp
    19da:	06                   	push   es
    19db:	00 00                	add    BYTE PTR [bx+si],al
    19dd:	07                   	pop    es
    19de:	50                   	push   ax
    19df:	61                   	popa
    19e0:	6e                   	outs   dx,BYTE PTR ds:[si]
    19e1:	65 6c                	gs ins BYTE PTR es:[di],dx
    19e3:	35 37 58             	xor    ax,0x5837
    19e6:	06                   	push   es
    19e7:	2c 00                	sub    al,0x0
    19e9:	08 44 42             	or     BYTE PTR [si+0x42],al
    19ec:	45                   	inc    bp
    19ed:	64 69 74 36 31 5c    	imul   si,WORD PTR fs:[si+0x36],0x5c31
    19f3:	06                   	push   es
    19f4:	08 00                	or     BYTE PTR [bx+si],al
    19f6:	0f 41 75 74          	cmovno si,WORD PTR [di+0x74]
    19fa:	72 65                	jb     0x1a61
    19fc:	73 72                	jae    0x1a70
    19fe:	73 75                	jae    0x1a75
    1a00:	6c                   	ins    BYTE PTR es:[di],dx
    1a01:	74 61                	je     0x1a64
    1a03:	74 73                	je     0x1a78
    1a05:	31 60 06             	xor    WORD PTR [bx+si+0x6],sp
    1a08:	08 00                	or     BYTE PTR [bx+si],al
    1a0a:	13 52 61             	adc    dx,WORD PTR [bp+si+0x61]
    1a0d:	70 70                	jo     0x1a7f
    1a0f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a11:	44                   	inc    sp
    1a12:	65 73 44             	gs jae 0x1a59
    1a15:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
    1a19:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
    1a1e:	64 06                	fs push es
    1a20:	08 00                	or     BYTE PTR [bx+si],al
    1a22:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
    1a25:	68 06 08             	push   0x806
    1a28:	00 14                	add    BYTE PTR [si],dl
    1a2a:	54                   	push   sp
    1a2b:	61                   	popa
    1a2c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1a2f:	61                   	popa
    1a30:	75 44                	jne    0x1a76
    1a32:	65 54                	gs push sp
    1a34:	72 65                	jb     0x1a9b
    1a36:	73 6f                	jae    0x1aa7
    1a38:	72 65                	jb     0x1a9f
    1a3a:	72 69                	jb     0x1aa5
    1a3c:	65 31 6c 06          	xor    WORD PTR gs:[si+0x6],bp
    1a40:	08 00                	or     BYTE PTR [bx+si],al
    1a42:	15 54 61             	adc    ax,0x6154
    1a45:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1a48:	61                   	popa
    1a49:	75 44                	jne    0x1a8f
    1a4b:	65 46                	gs inc si
    1a4d:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    1a52:	65 6d                	gs ins WORD PTR es:[di],dx
    1a54:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1a56:	74 31                	je     0x1a89
    1a58:	70 06                	jo     0x1a60
    1a5a:	08 00                	or     BYTE PTR [bx+si],al
    1a5c:	06                   	push   es
    1a5d:	42                   	inc    dx
    1a5e:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
    1a63:	74 06                	je     0x1a6b
    1a65:	08 00                	or     BYTE PTR [bx+si],al
    1a67:	12 43 6f             	adc    al,BYTE PTR [bp+di+0x6f]
    1a6a:	6d                   	ins    WORD PTR es:[di],dx
    1a6b:	70 74                	jo     0x1ae1
    1a6d:	65 44                	gs inc sp
    1a6f:	65 52                	gs push dx
    1a71:	65 73 75             	gs jae 0x1ae9
    1a74:	6c                   	ins    BYTE PTR es:[di],dx
    1a75:	74 61                	je     0x1ad8
    1a77:	74 73                	je     0x1aec
    1a79:	31 78 06             	xor    WORD PTR [bx+si+0x6],di
    1a7c:	08 00                	or     BYTE PTR [bx+si],al
    1a7e:	0a 53 69             	or     dl,BYTE PTR [bp+di+0x69]
    1a81:	74 75                	je     0x1af8
    1a83:	61                   	popa
    1a84:	74 69                	je     0x1aef
    1a86:	6f                   	outs   dx,WORD PTR ds:[si]
    1a87:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a88:	31 7c 06             	xor    WORD PTR [si+0x6],di
    1a8b:	08 00                	or     BYTE PTR [bx+si],al
    1a8d:	05 4e 31             	add    ax,0x314e
    1a90:	30 30                	xor    BYTE PTR [bx+si],dh
    1a92:	31 80 06 08          	xor    WORD PTR [bx+si+0x806],ax
    1a96:	00 05                	add    BYTE PTR [di],al
    1a98:	4e                   	dec    si
    1a99:	31 35                	xor    WORD PTR [di],si
    1a9b:	30 31                	xor    BYTE PTR [bx+di],dh
    1a9d:	84 06 08 00          	test   BYTE PTR ds:0x8,al
    1aa1:	05 4e 32             	add    ax,0x324e
    1aa4:	30 30                	xor    BYTE PTR [bx+si],dh
    1aa6:	31 88 06 08          	xor    WORD PTR [bx+si+0x806],cx
    1aaa:	00 04                	add    BYTE PTR [si],al
    1aac:	4e                   	dec    si
    1aad:	37                   	aaa
    1aae:	35 31 8c             	xor    ax,0x8c31
    1ab1:	06                   	push   es
    1ab2:	08 00                	or     BYTE PTR [bx+si],al
    1ab4:	04 4e                	add    al,0x4e
    1ab6:	35 30 31             	xor    ax,0x3130
    1ab9:	90                   	nop
    1aba:	06                   	push   es
    1abb:	08 00                	or     BYTE PTR [bx+si],al
    1abd:	02 4e 35             	add    cl,BYTE PTR [bp+0x35]
    1ac0:	94                   	xchg   sp,ax
    1ac1:	06                   	push   es
    1ac2:	08 00                	or     BYTE PTR [bx+si],al
    1ac4:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
    1ac7:	70 72                	jo     0x1b3b
    1ac9:	65 73 73             	gs jae 0x1b3f
    1acc:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
    1ad1:	70 69                	jo     0x1b3c
    1ad3:	64 65 31 98 06 08    	fs xor WORD PTR gs:[bx+si+0x806],bx
    1ad9:	00 02                	add    BYTE PTR [bp+si],al
    1adb:	4e                   	dec    si
    1adc:	36 9c                	ss pushf
    1ade:	06                   	push   es
    1adf:	08 00                	or     BYTE PTR [bx+si],al
    1ae1:	05 4e 31             	add    ax,0x314e
    1ae4:	32 35                	xor    dh,BYTE PTR [di]
    1ae6:	31 a0 06 08          	xor    WORD PTR [bx+si+0x806],sp
    1aea:	00 08                	add    BYTE PTR [bx+si],cl
    1aec:	50                   	push   ax
    1aed:	65 72 69             	gs jb  0x1b59
    1af0:	6f                   	outs   dx,WORD PTR ds:[si]
    1af1:	64 65 32 a4 06 08    	fs xor ah,BYTE PTR gs:[si+0x806]
    1af7:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
    1afb:	74 72                	je     0x1b6f
    1afd:	65 31 a8 06 08       	xor    WORD PTR gs:[bx+si+0x806],bp
    1b02:	00 04                	add    BYTE PTR [si],al
    1b04:	4e                   	dec    si
    1b05:	32 30                	xor    dh,BYTE PTR [bx+si]
    1b07:	31 ac 06 08          	xor    WORD PTR [si+0x806],bp
    1b0b:	00 04                	add    BYTE PTR [si],al
    1b0d:	4e                   	dec    si
    1b0e:	31 39                	xor    WORD PTR [bx+di],di
    1b10:	31 b0 06 08          	xor    WORD PTR [bx+si+0x806],si
    1b14:	00 04                	add    BYTE PTR [si],al
    1b16:	4e                   	dec    si
    1b17:	31 38                	xor    WORD PTR [bx+si],di
    1b19:	31 b4 06 08          	xor    WORD PTR [si+0x806],si
    1b1d:	00 04                	add    BYTE PTR [si],al
    1b1f:	4e                   	dec    si
    1b20:	31 37                	xor    WORD PTR [bx],si
    1b22:	31 b8 06 08          	xor    WORD PTR [bx+si+0x806],di
    1b26:	00 04                	add    BYTE PTR [si],al
    1b28:	4e                   	dec    si
    1b29:	31 36 31 bc          	xor    WORD PTR ds:0xbc31,si
    1b2d:	06                   	push   es
    1b2e:	08 00                	or     BYTE PTR [bx+si],al
    1b30:	04 4e                	add    al,0x4e
    1b32:	31 35                	xor    WORD PTR [di],si
    1b34:	31 c0                	xor    ax,ax
    1b36:	06                   	push   es
    1b37:	08 00                	or     BYTE PTR [bx+si],al
    1b39:	04 4e                	add    al,0x4e
    1b3b:	31 34                	xor    WORD PTR [si],si
    1b3d:	31 c4                	xor    sp,ax
    1b3f:	06                   	push   es
    1b40:	08 00                	or     BYTE PTR [bx+si],al
    1b42:	04 4e                	add    al,0x4e
    1b44:	31 33                	xor    WORD PTR [bp+di],si
    1b46:	31 c8                	xor    ax,cx
    1b48:	06                   	push   es
    1b49:	08 00                	or     BYTE PTR [bx+si],al
    1b4b:	04 4e                	add    al,0x4e
    1b4d:	31 32                	xor    WORD PTR [bp+si],si
    1b4f:	31 cc                	xor    sp,cx
    1b51:	06                   	push   es
    1b52:	08 00                	or     BYTE PTR [bx+si],al
    1b54:	04 4e                	add    al,0x4e
    1b56:	31 31                	xor    WORD PTR [bx+di],si
    1b58:	31 d0                	xor    ax,dx
    1b5a:	06                   	push   es
    1b5b:	08 00                	or     BYTE PTR [bx+si],al
    1b5d:	04 4e                	add    al,0x4e
    1b5f:	31 30                	xor    WORD PTR [bx+si],si
    1b61:	31 d4                	xor    sp,dx
    1b63:	06                   	push   es
    1b64:	08 00                	or     BYTE PTR [bx+si],al
    1b66:	03 4e 39             	add    cx,WORD PTR [bp+0x39]
    1b69:	31 d8                	xor    ax,bx
    1b6b:	06                   	push   es
    1b6c:	08 00                	or     BYTE PTR [bx+si],al
    1b6e:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
    1b71:	32 dc                	xor    bl,ah
    1b73:	06                   	push   es
    1b74:	08 00                	or     BYTE PTR [bx+si],al
    1b76:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
    1b79:	32 e0                	xor    ah,al
    1b7b:	06                   	push   es
    1b7c:	08 00                	or     BYTE PTR [bx+si],al
    1b7e:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
    1b81:	32 e4                	xor    ah,ah
    1b83:	06                   	push   es
    1b84:	08 00                	or     BYTE PTR [bx+si],al
    1b86:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
    1b89:	32 e8                	xor    ch,al
    1b8b:	06                   	push   es
    1b8c:	08 00                	or     BYTE PTR [bx+si],al
    1b8e:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
    1b91:	32 ec                	xor    ch,ah
    1b93:	06                   	push   es
    1b94:	08 00                	or     BYTE PTR [bx+si],al
    1b96:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
    1b99:	32 f0                	xor    dh,al
    1b9b:	06                   	push   es
    1b9c:	08 00                	or     BYTE PTR [bx+si],al
    1b9e:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
    1ba1:	32 f4                	xor    dh,ah
    1ba3:	06                   	push   es
    1ba4:	08 00                	or     BYTE PTR [bx+si],al
    1ba6:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
    1ba9:	32 f8                	xor    bh,al
    1bab:	06                   	push   es
    1bac:	08 00                	or     BYTE PTR [bx+si],al
    1bae:	04 53                	add    al,0x53
    1bb0:	49                   	dec    cx
    1bb1:	47                   	inc    di
    1bb2:	31 fc                	xor    sp,di
    1bb4:	06                   	push   es
    1bb5:	00 00                	add    BYTE PTR [bx+si],al
    1bb7:	07                   	pop    es
    1bb8:	50                   	push   ax
    1bb9:	61                   	popa
    1bba:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bbb:	65 6c                	gs ins BYTE PTR es:[di],dx
    1bbd:	32 36 00 07          	xor    dh,BYTE PTR ds:0x700
    1bc1:	00 00                	add    BYTE PTR [bx+si],al
    1bc3:	07                   	pop    es
    1bc4:	50                   	push   ax
    1bc5:	61                   	popa
    1bc6:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bc7:	65 6c                	gs ins BYTE PTR es:[di],dx
    1bc9:	32 37                	xor    dh,BYTE PTR [bx]
    1bcb:	04 07                	add    al,0x7
    1bcd:	2c 00                	sub    al,0x0
    1bcf:	08 44 42             	or     BYTE PTR [si+0x42],al
    1bd2:	45                   	inc    bp
    1bd3:	64 69 74 35 33 08    	imul   si,WORD PTR fs:[si+0x35],0x833
    1bd9:	07                   	pop    es
    1bda:	2c 00                	sub    al,0x0
    1bdc:	08 44 42             	or     BYTE PTR [si+0x42],al
    1bdf:	45                   	inc    bp
    1be0:	64 69 74 35 34 0c    	imul   si,WORD PTR fs:[si+0x35],0xc34
    1be6:	07                   	pop    es
    1be7:	00 00                	add    BYTE PTR [bx+si],al
    1be9:	07                   	pop    es
    1bea:	50                   	push   ax
    1beb:	61                   	popa
    1bec:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bed:	65 6c                	gs ins BYTE PTR es:[di],dx
    1bef:	34 35                	xor    al,0x35
    1bf1:	10 07                	adc    BYTE PTR [bx],al
    1bf3:	28 00                	sub    BYTE PTR [bx+si],al
    1bf5:	06                   	push   es
    1bf6:	53                   	push   bx
    1bf7:	68 61 70             	push   0x7061
    1bfa:	65 37                	gs aaa
    1bfc:	14 07                	adc    al,0x7
    1bfe:	2c 00                	sub    al,0x0
    1c00:	08 44 42             	or     BYTE PTR [si+0x42],al
    1c03:	45                   	inc    bp
    1c04:	64 69 74 36 32 18    	imul   si,WORD PTR fs:[si+0x36],0x1832
    1c0a:	07                   	pop    es
    1c0b:	28 00                	sub    BYTE PTR [bx+si],al
    1c0d:	07                   	pop    es
    1c0e:	53                   	push   bx
    1c0f:	68 61 70             	push   0x7061
    1c12:	65 31 30             	xor    WORD PTR gs:[bx+si],si
    1c15:	1c 07                	sbb    al,0x7
    1c17:	2c 00                	sub    al,0x0
    1c19:	08 44 42             	or     BYTE PTR [si+0x42],al
    1c1c:	45                   	inc    bp
    1c1d:	64 69 74 36 33 20    	imul   si,WORD PTR fs:[si+0x36],0x2033
    1c23:	07                   	pop    es
    1c24:	10 00                	adc    BYTE PTR [bx+si],al
    1c26:	17                   	pop    ss
    1c27:	54                   	push   sp
    1c28:	61                   	popa
    1c29:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1c2c:	45                   	inc    bp
    1c2d:	52                   	push   dx
    1c2e:	50                   	push   ax
    1c2f:	31 43 6f             	xor    WORD PTR [bp+di+0x6f],ax
    1c32:	75 74                	jne    0x1ca8
    1c34:	50                   	push   ax
    1c35:	72 6f                	jb     0x1ca6
    1c37:	64 75 63             	fs jne 0x1c9d
    1c3a:	74 69                	je     0x1ca5
    1c3c:	6f                   	outs   dx,WORD PTR ds:[si]
    1c3d:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c3e:	24 07                	and    al,0x7
    1c40:	10 00                	adc    BYTE PTR [bx+si],al
    1c42:	17                   	pop    ss
    1c43:	54                   	push   sp
    1c44:	61                   	popa
    1c45:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1c48:	45                   	inc    bp
    1c49:	52                   	push   dx
    1c4a:	50                   	push   ax
    1c4b:	32 43 6f             	xor    al,BYTE PTR [bp+di+0x6f]
    1c4e:	75 74                	jne    0x1cc4
    1c50:	50                   	push   ax
    1c51:	72 6f                	jb     0x1cc2
    1c53:	64 75 63             	fs jne 0x1cb9
    1c56:	74 69                	je     0x1cc1
    1c58:	6f                   	outs   dx,WORD PTR ds:[si]
    1c59:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c5a:	0e                   	push   cs
    1c5b:	00 ad 0d 86          	add    BYTE PTR [di-0x79f3],ch
    1c5f:	1c ef                	sbb    al,0xef
    1c61:	02 66 1c             	add    ah,BYTE PTR [bp+0x1c]
    1c64:	94                   	xchg   sp,ax
    1c65:	00 ea                	add    dl,ch
    1c67:	2d 38 01             	sub    ax,0x138
    1c6a:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c6b:	1c 58                	sbb    al,0x58
    1c6d:	0a 7a 1c             	or     bh,BYTE PTR [bp+si+0x1c]
    1c70:	c8 08 ae 20          	enter  0xae08,0x20
    1c74:	7e 08                	jle    0x1c7e
    1c76:	46                   	inc    si
    1c77:	1f                   	pop    ds
    1c78:	c8 07 7e 1c          	enter  0x7e07,0x1c
    1c7c:	67 0c c0             	addr32 or al,0xc0
    1c7f:	20 0c                	and    BYTE PTR [si],cl
    1c81:	01 8e 1c 7d          	add    WORD PTR [bp+0x7d1c],cx
    1c85:	00 08                	add    BYTE PTR [bx+si],cl
    1c87:	60                   	pusha
    1c88:	22 00                	and    al,BYTE PTR [bx+si]
    1c8a:	94                   	xchg   sp,ax
    1c8b:	20 17                	and    BYTE PTR [bx],dl
    1c8d:	06                   	push   es
    1c8e:	92                   	xchg   dx,ax
    1c8f:	1c 91                	sbb    al,0x91
    1c91:	12 82 5e 07          	adc    al,BYTE PTR [bp+si+0x75e]
    1c95:	10 54 46             	adc    BYTE PTR [si+0x46],dl
    1c98:	6f                   	outs   dx,WORD PTR ds:[si]
    1c99:	72 6d                	jb     0x1d08
    1c9b:	53                   	push   bx
    1c9c:	45                   	inc    bp
    1c9d:	52                   	push   dx
    1c9e:	43                   	inc    bx
    1c9f:	5f                   	pop    di
    1ca0:	43                   	inc    bx
    1ca1:	6f                   	outs   dx,WORD PTR ds:[si]
    1ca2:	6d                   	ins    WORD PTR es:[di],dx
    1ca3:	70 74                	jo     0x1d19
    1ca5:	65 22 00             	and    al,BYTE PTR gs:[bx+si]
    1ca8:	e6 1c                	out    0x1c,al
    1caa:	7b 06                	jnp    0x1cb2
    1cac:	d7                   	xlat   BYTE PTR ds:[bx]
    1cad:	1c 38                	sbb    al,0x38
    1caf:	00 04                	add    BYTE PTR [si],al
    1cb1:	53                   	push   bx
    1cb2:	65 72 63             	gs jb  0x1d18
    1cb5:	00 00                	add    BYTE PTR [bx+si],al
    1cb7:	55                   	push   bp
    1cb8:	89 e5                	mov    bp,sp
    1cba:	31 c0                	xor    ax,ax
    1cbc:	9a 44 04 f1 1c       	call   0x1cf1:0x444
    1cc1:	6a 00                	push   0x0
    1cc3:	9a c2 38 db 1e       	call   0x1edb:0x38c2
    1cc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ccb:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    1cd2:	06                   	push   es
    1cd3:	57                   	push   di
    1cd4:	9a 56 55 ff 1c       	call   0x1cff:0x5556
    1cd9:	9a c3 28 29 21       	call   0x2129:0x28c3
    1cde:	c9                   	leave
    1cdf:	ca 04 00             	retf   0x4
    1ce2:	00 00                	add    BYTE PTR [bx+si],al
    1ce4:	95                   	xchg   bp,ax
    1ce5:	1d 19 1d             	sbb    ax,0x1d19
    1ce8:	55                   	push   bp
    1ce9:	89 e5                	mov    bp,sp
    1ceb:	b8 08 00             	mov    ax,0x8
    1cee:	9a 44 04 b3 1d       	call   0x1db3:0x444
    1cf3:	83 ec 08             	sub    sp,0x8
    1cf6:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1cfa:	06                   	push   es
    1cfb:	57                   	push   di
    1cfc:	9a 03 73 20 1d       	call   0x1d20:0x7303
    1d01:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    1d05:	7f 03                	jg     0x1d0a
    1d07:	e9 96 00             	jmp    0x1da0
    1d0a:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1d0e:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1d12:	b0 01                	mov    al,0x1
    1d14:	50                   	push   ax
    1d15:	b8 22 00             	mov    ax,0x22
    1d18:	ba 54 1d             	mov    dx,0x1d54
    1d1b:	52                   	push   dx
    1d1c:	50                   	push   ax
    1d1d:	9a 53 25 7d 1d       	call   0x1d7d:0x2553
    1d22:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d25:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1d28:	b8 e2 1c             	mov    ax,0x1ce2
    1d2b:	0e                   	push   cs
    1d2c:	50                   	push   ax
    1d2d:	55                   	push   bp
    1d2e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1d32:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1d36:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1d39:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1d3c:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1d3f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1d42:	26 89 85 2c 07       	mov    WORD PTR es:[di+0x72c],ax
    1d47:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1d4a:	26 89 85 2a 07       	mov    WORD PTR es:[di+0x72a],ax
    1d4f:	06                   	push   es
    1d50:	57                   	push   di
    1d51:	9a e7 29 63 1d       	call   0x1d63:0x29e7
    1d56:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d59:	26 ff b5 2a 07       	push   WORD PTR es:[di+0x72a]
    1d5e:	06                   	push   es
    1d5f:	57                   	push   di
    1d60:	9a 2b 34 a8 1d       	call   0x1da8:0x342b
    1d65:	6a ff                	push   0xffff
    1d67:	6a f0                	push   0xfff0
    1d69:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d6c:	06                   	push   es
    1d6d:	57                   	push   di
    1d6e:	9a d5 1e 30 1e       	call   0x1e30:0x1ed5
    1d73:	6a 02                	push   0x2
    1d75:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d78:	06                   	push   es
    1d79:	57                   	push   di
    1d7a:	9a 14 3a 87 1d       	call   0x1d87:0x3a14
    1d7f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d82:	06                   	push   es
    1d83:	57                   	push   di
    1d84:	9a 45 5d 9d 1d       	call   0x1d9d:0x5d45
    1d89:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1d8d:	83 c4 06             	add    sp,0x6
    1d90:	b8 a0 1d             	mov    ax,0x1da0
    1d93:	0e                   	push   cs
    1d94:	50                   	push   ax
    1d95:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1d98:	06                   	push   es
    1d99:	57                   	push   di
    1d9a:	9a 1d 5f c1 1d       	call   0x1dc1:0x5f1d
    1d9f:	cb                   	retf
    1da0:	c9                   	leave
    1da1:	ca 04 00             	retf   0x4
    1da4:	00 00                	add    BYTE PTR [bx+si],al
    1da6:	f4                   	hlt
    1da7:	1e                   	push   ds
    1da8:	03 1e 55 89          	add    bx,WORD PTR ds:0x8955
    1dac:	e5 b8                	in     ax,0xb8
    1dae:	0a 00                	or     al,BYTE PTR [bx+si]
    1db0:	9a 44 04 0b 1f       	call   0x1f0b:0x444
    1db5:	83 ec 0a             	sub    sp,0xa
    1db8:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1dbc:	06                   	push   es
    1dbd:	57                   	push   di
    1dbe:	9a 03 73 0a 1e       	call   0x1e0a:0x7303
    1dc3:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    1dc7:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1dcb:	7e 1e                	jle    0x1deb
    1dcd:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1dd1:	75 14                	jne    0x1de7
    1dd3:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1dd7:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    1ddd:	b0 00                	mov    al,0x0
    1ddf:	75 01                	jne    0x1de2
    1de1:	40                   	inc    ax
    1de2:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    1de5:	eb 04                	jmp    0x1deb
    1de7:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    1deb:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1def:	75 03                	jne    0x1df4
    1df1:	e9 0b 01             	jmp    0x1eff
    1df4:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1df8:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1dfc:	b0 01                	mov    al,0x1
    1dfe:	50                   	push   ax
    1dff:	b8 22 00             	mov    ax,0x22
    1e02:	ba 4a 1e             	mov    dx,0x1e4a
    1e05:	52                   	push   dx
    1e06:	50                   	push   ax
    1e07:	9a 53 25 76 1e       	call   0x1e76:0x2553
    1e0c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e0f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1e12:	b8 a4 1d             	mov    ax,0x1da4
    1e15:	0e                   	push   cs
    1e16:	50                   	push   ax
    1e17:	55                   	push   bp
    1e18:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1e1c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1e20:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1e23:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1e26:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1e29:	6a 00                	push   0x0
    1e2b:	06                   	push   es
    1e2c:	57                   	push   di
    1e2d:	9a 22 63 68 1e       	call   0x1e68:0x6322
    1e32:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1e35:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e38:	26 89 85 2c 07       	mov    WORD PTR es:[di+0x72c],ax
    1e3d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1e40:	26 89 85 2a 07       	mov    WORD PTR es:[di+0x72a],ax
    1e45:	06                   	push   es
    1e46:	57                   	push   di
    1e47:	9a e7 29 59 1e       	call   0x1e59:0x29e7
    1e4c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e4f:	26 ff b5 2a 07       	push   WORD PTR es:[di+0x72a]
    1e54:	06                   	push   es
    1e55:	57                   	push   di
    1e56:	9a 2b 34 b0 1e       	call   0x1eb0:0x342b
    1e5b:	68 ff 00             	push   0xff
    1e5e:	6a ff                	push   0xffff
    1e60:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e63:	06                   	push   es
    1e64:	57                   	push   di
    1e65:	9a d5 1e 98 1e       	call   0x1e98:0x1ed5
    1e6a:	6a 00                	push   0x0
    1e6c:	6a 00                	push   0x0
    1e6e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e71:	06                   	push   es
    1e72:	57                   	push   di
    1e73:	9a b2 36 82 1e       	call   0x1e82:0x36b2
    1e78:	6a 02                	push   0x2
    1e7a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e7d:	06                   	push   es
    1e7e:	57                   	push   di
    1e7f:	9a 14 3a 8e 1e       	call   0x1e8e:0x3a14
    1e84:	6a 01                	push   0x1
    1e86:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e89:	06                   	push   es
    1e8a:	57                   	push   di
    1e8b:	9a e5 34 bd 1e       	call   0x1ebd:0x34e5
    1e90:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1e93:	06                   	push   es
    1e94:	57                   	push   di
    1e95:	9a b9 62 e3 24       	call   0x24e3:0x62b9
    1e9a:	50                   	push   ax
    1e9b:	6a 04                	push   0x4
    1e9d:	9a ff ff 00 00       	call   0x0:0xffff
    1ea2:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1ea6:	74 0c                	je     0x1eb4
    1ea8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1eab:	06                   	push   es
    1eac:	57                   	push   di
    1ead:	9a 2d 5a 1f 1f       	call   0x1f1f:0x5a2d
    1eb2:	eb 34                	jmp    0x1ee8
    1eb4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1eb8:	06                   	push   es
    1eb9:	57                   	push   di
    1eba:	9a 03 73 e6 1e       	call   0x1ee6:0x7303
    1ebf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ec2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ec5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1ec8:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    1ecd:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    1ed2:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1ed6:	06                   	push   es
    1ed7:	57                   	push   di
    1ed8:	9a 1a 31 80 1f       	call   0x1f80:0x311a
    1edd:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1ee1:	06                   	push   es
    1ee2:	57                   	push   di
    1ee3:	9a 03 73 fc 1e       	call   0x1efc:0x7303
    1ee8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1eec:	83 c4 06             	add    sp,0x6
    1eef:	b8 ff 1e             	mov    ax,0x1eff
    1ef2:	0e                   	push   cs
    1ef3:	50                   	push   ax
    1ef4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1ef7:	06                   	push   es
    1ef8:	57                   	push   di
    1ef9:	9a 1d 5f 71 1f       	call   0x1f71:0x5f1d
    1efe:	cb                   	retf
    1eff:	c9                   	leave
    1f00:	ca 06 00             	retf   0x6
    1f03:	55                   	push   bp
    1f04:	89 e5                	mov    bp,sp
    1f06:	31 c0                	xor    ax,ax
    1f08:	9a 44 04 34 1f       	call   0x1f34:0x444
    1f0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f10:	26 ff b5 2a 07       	push   WORD PTR es:[di+0x72a]
    1f15:	26 ff b5 2c 07       	push   WORD PTR es:[di+0x72c]
    1f1a:	6a 00                	push   0x0
    1f1c:	9a aa 1d 29 1f       	call   0x1f29:0x1daa
    1f21:	c9                   	leave
    1f22:	ca 08 00             	retf   0x8
    1f25:	00 00                	add    BYTE PTR [bx+si],al
    1f27:	e6 1f                	out    0x1f,al
    1f29:	ba 1f 55             	mov    dx,0x551f
    1f2c:	89 e5                	mov    bp,sp
    1f2e:	b8 08 00             	mov    ax,0x8
    1f31:	9a 44 04 35 20       	call   0x2035:0x444
    1f36:	83 ec 08             	sub    sp,0x8
    1f39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3c:	26 c4 bd 88 02       	les    di,DWORD PTR es:[di+0x288]
    1f41:	06                   	push   es
    1f42:	57                   	push   di
    1f43:	9a 17 2f b5 59       	call   0x59b5:0x2f17
    1f48:	08 c0                	or     al,al
    1f4a:	75 03                	jne    0x1f4f
    1f4c:	e9 b3 00             	jmp    0x2002
    1f4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f52:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    1f57:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    1f5c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1f5f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1f62:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    1f67:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    1f6c:	06                   	push   es
    1f6d:	57                   	push   di
    1f6e:	9a d0 3f 87 1f       	call   0x1f87:0x3fd0
    1f73:	ff 76 08             	push   WORD PTR [bp+0x8]
    1f76:	ff 76 06             	push   WORD PTR [bp+0x6]
    1f79:	b0 01                	mov    al,0x1
    1f7b:	50                   	push   ax
    1f7c:	b8 b4 25             	mov    ax,0x25b4
    1f7f:	ba af 1f             	mov    dx,0x1faf
    1f82:	52                   	push   dx
    1f83:	50                   	push   ax
    1f84:	9a 53 25 d8 1f       	call   0x1fd8:0x2553
    1f89:	a3 04 20             	mov    ds:0x2004,ax
    1f8c:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    1f90:	b8 25 1f             	mov    ax,0x1f25
    1f93:	0e                   	push   cs
    1f94:	50                   	push   ax
    1f95:	55                   	push   bp
    1f96:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1f9a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1f9e:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1fa2:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1fa5:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1fa8:	6a 01                	push   0x1
    1faa:	06                   	push   es
    1fab:	57                   	push   di
    1fac:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    1fb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb4:	06                   	push   es
    1fb5:	57                   	push   di
    1fb6:	b8 03 1f             	mov    ax,0x1f03
    1fb9:	ba d9 29             	mov    dx,0x29d9
    1fbc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1fbf:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    1fc4:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    1fc9:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    1fce:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    1fd3:	06                   	push   es
    1fd4:	57                   	push   di
    1fd5:	9a 45 5d ef 1f       	call   0x1fef:0x5d45
    1fda:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1fde:	83 c4 06             	add    sp,0x6
    1fe1:	b8 f2 1f             	mov    ax,0x1ff2
    1fe4:	0e                   	push   cs
    1fe5:	50                   	push   ax
    1fe6:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1fea:	06                   	push   es
    1feb:	57                   	push   di
    1fec:	9a 1d 5f 00 20       	call   0x2000:0x5f1d
    1ff1:	cb                   	retf
    1ff2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ff5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ff8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ffb:	06                   	push   es
    1ffc:	57                   	push   di
    1ffd:	9a d0 3f 4e 20       	call   0x204e:0x3fd0
    2002:	c9                   	leave
    2003:	ca 08 00             	retf   0x8
    2006:	0a 23                	or     ah,BYTE PTR [bp+di]
    2008:	2c 23                	sub    al,0x23
    200a:	23 30                	and    si,WORD PTR [bx+si]
    200c:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    200f:	23 23                	and    sp,WORD PTR [bp+di]
    2011:	07                   	pop    es
    2012:	23 30                	and    si,WORD PTR [bx+si]
    2014:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    2017:	23 23                	and    sp,WORD PTR [bp+di]
    2019:	07                   	pop    es
    201a:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    201e:	2b 30                	sub    si,WORD PTR [bx+si]
    2020:	30 01                	xor    BYTE PTR [bx+di],al
    2022:	30 05                	xor    BYTE PTR [di],al
    2024:	23 2c                	and    bp,WORD PTR [si]
    2026:	23 23                	and    sp,WORD PTR [bp+di]
    2028:	30 02                	xor    BYTE PTR [bp+si],al
    202a:	23 30                	and    si,WORD PTR [bx+si]
    202c:	55                   	push   bp
    202d:	89 e5                	mov    bp,sp
    202f:	b8 14 03             	mov    ax,0x314
    2032:	9a 44 04 c7 20       	call   0x20c7:0x444
    2037:	81 ec 14 03          	sub    sp,0x314
    203b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    203e:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    2042:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    2046:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2049:	06                   	push   es
    204a:	57                   	push   di
    204b:	9a d5 33 78 20       	call   0x2078:0x33d5
    2050:	89 c7                	mov    di,ax
    2052:	8e c2                	mov    es,dx
    2054:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    2058:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    205c:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    2060:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    2064:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2068:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    206c:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2070:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2073:	06                   	push   es
    2074:	57                   	push   di
    2075:	9a d5 33 47 21       	call   0x2147:0x33d5
    207a:	89 c7                	mov    di,ax
    207c:	8e c2                	mov    es,dx
    207e:	06                   	push   es
    207f:	57                   	push   di
    2080:	9a 99 20 52 21       	call   0x2152:0x2099
    2085:	8d be f4 fc          	lea    di,[bp-0x30c]
    2089:	16                   	push   ss
    208a:	57                   	push   di
    208b:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    208f:	06                   	push   es
    2090:	57                   	push   di
    2091:	9a 9f 1a 9f 20       	call   0x209f:0x1a9f
    2096:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    209a:	06                   	push   es
    209b:	57                   	push   di
    209c:	9a 5f 1a b0 24       	call   0x24b0:0x1a5f
    20a1:	89 c7                	mov    di,ax
    20a3:	8e c2                	mov    es,dx
    20a5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    20a9:	06                   	push   es
    20aa:	57                   	push   di
    20ab:	9a 9b 3b 36 26       	call   0x2636:0x3b9b
    20b0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    20b3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    20b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20b9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20bc:	bf 58 0a             	mov    di,0xa58
    20bf:	b8 da 20             	mov    ax,0x20da
    20c2:	50                   	push   ax
    20c3:	57                   	push   di
    20c4:	9a 55 22 e1 20       	call   0x20e1:0x2255
    20c9:	08 c0                	or     al,al
    20cb:	75 03                	jne    0x20d0
    20cd:	e9 bb 01             	jmp    0x228b
    20d0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20d3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20d6:	bf 58 0a             	mov    di,0xa58
    20d9:	b8 86 22             	mov    ax,0x2286
    20dc:	50                   	push   ax
    20dd:	57                   	push   di
    20de:	9a 73 22 00 21       	call   0x2100:0x2273
    20e3:	89 c7                	mov    di,ax
    20e5:	8e c2                	mov    es,dx
    20e7:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    20eb:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    20ef:	bf 06 20             	mov    di,0x2006
    20f2:	0e                   	push   cs
    20f3:	57                   	push   di
    20f4:	8d be fc fd          	lea    di,[bp-0x204]
    20f8:	16                   	push   ss
    20f9:	57                   	push   di
    20fa:	68 ff 00             	push   0xff
    20fd:	9a e7 17 37 21       	call   0x2137:0x17e7
    2102:	8d be f0 fc          	lea    di,[bp-0x310]
    2106:	16                   	push   ss
    2107:	57                   	push   di
    2108:	8d be fc fd          	lea    di,[bp-0x204]
    210c:	16                   	push   ss
    210d:	57                   	push   di
    210e:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2112:	06                   	push   es
    2113:	57                   	push   di
    2114:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2117:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    211b:	83 ec 0a             	sub    sp,0xa
    211e:	89 e3                	mov    bx,sp
    2120:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2124:	90                   	nop
    2125:	9b                   	fwait
    2126:	9a d4 10 a9 21       	call   0x21a9:0x10d4
    212b:	8d be fc fe          	lea    di,[bp-0x104]
    212f:	16                   	push   ss
    2130:	57                   	push   di
    2131:	68 ff 00             	push   0xff
    2134:	9a e7 17 66 21       	call   0x2166:0x17e7
    2139:	8d be fc fe          	lea    di,[bp-0x104]
    213d:	16                   	push   ss
    213e:	57                   	push   di
    213f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2142:	06                   	push   es
    2143:	57                   	push   di
    2144:	9a d5 33 c7 21       	call   0x21c7:0x33d5
    2149:	89 c7                	mov    di,ax
    214b:	8e c2                	mov    es,dx
    214d:	06                   	push   es
    214e:	57                   	push   di
    214f:	9a 03 20 d2 21       	call   0x21d2:0x2003
    2154:	8b d0                	mov    dx,ax
    2156:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    215a:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    215e:	2d 05 00             	sub    ax,0x5
    2161:	71 05                	jno    0x2168
    2163:	9a 3e 04 80 21       	call   0x2180:0x43e
    2168:	3b c2                	cmp    ax,dx
    216a:	7e 03                	jle    0x216f
    216c:	e9 08 01             	jmp    0x2277
    216f:	bf 11 20             	mov    di,0x2011
    2172:	0e                   	push   cs
    2173:	57                   	push   di
    2174:	8d be fc fd          	lea    di,[bp-0x204]
    2178:	16                   	push   ss
    2179:	57                   	push   di
    217a:	68 ff 00             	push   0xff
    217d:	9a e7 17 b7 21       	call   0x21b7:0x17e7
    2182:	8d be f0 fc          	lea    di,[bp-0x310]
    2186:	16                   	push   ss
    2187:	57                   	push   di
    2188:	8d be fc fd          	lea    di,[bp-0x204]
    218c:	16                   	push   ss
    218d:	57                   	push   di
    218e:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2192:	06                   	push   es
    2193:	57                   	push   di
    2194:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2197:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    219b:	83 ec 0a             	sub    sp,0xa
    219e:	89 e3                	mov    bx,sp
    21a0:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    21a4:	90                   	nop
    21a5:	9b                   	fwait
    21a6:	9a d4 10 0b 23       	call   0x230b:0x10d4
    21ab:	8d be fc fe          	lea    di,[bp-0x104]
    21af:	16                   	push   ss
    21b0:	57                   	push   di
    21b1:	68 ff 00             	push   0xff
    21b4:	9a e7 17 e6 21       	call   0x21e6:0x17e7
    21b9:	8d be fc fe          	lea    di,[bp-0x104]
    21bd:	16                   	push   ss
    21be:	57                   	push   di
    21bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c2:	06                   	push   es
    21c3:	57                   	push   di
    21c4:	9a d5 33 10 22       	call   0x2210:0x33d5
    21c9:	89 c7                	mov    di,ax
    21cb:	8e c2                	mov    es,dx
    21cd:	06                   	push   es
    21ce:	57                   	push   di
    21cf:	9a 03 20 1b 22       	call   0x221b:0x2003
    21d4:	8b d0                	mov    dx,ax
    21d6:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    21da:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    21de:	2d 05 00             	sub    ax,0x5
    21e1:	71 05                	jno    0x21e8
    21e3:	9a 3e 04 00 22       	call   0x2200:0x43e
    21e8:	3b c2                	cmp    ax,dx
    21ea:	7e 03                	jle    0x21ef
    21ec:	e9 88 00             	jmp    0x2277
    21ef:	bf 19 20             	mov    di,0x2019
    21f2:	0e                   	push   cs
    21f3:	57                   	push   di
    21f4:	8d be fc fd          	lea    di,[bp-0x204]
    21f8:	16                   	push   ss
    21f9:	57                   	push   di
    21fa:	68 ff 00             	push   0xff
    21fd:	9a e7 17 2f 22       	call   0x222f:0x17e7
    2202:	8d be fc fd          	lea    di,[bp-0x204]
    2206:	16                   	push   ss
    2207:	57                   	push   di
    2208:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    220b:	06                   	push   es
    220c:	57                   	push   di
    220d:	9a d5 33 29 23       	call   0x2329:0x33d5
    2212:	89 c7                	mov    di,ax
    2214:	8e c2                	mov    es,dx
    2216:	06                   	push   es
    2217:	57                   	push   di
    2218:	9a 03 20 34 23       	call   0x2334:0x2003
    221d:	8b d0                	mov    dx,ax
    221f:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2223:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2227:	2d 05 00             	sub    ax,0x5
    222a:	71 05                	jno    0x2231
    222c:	9a 3e 04 5d 22       	call   0x225d:0x43e
    2231:	3b c2                	cmp    ax,dx
    2233:	b0 00                	mov    al,0x0
    2235:	7e 01                	jle    0x2238
    2237:	40                   	inc    ax
    2238:	8a d0                	mov    dl,al
    223a:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    223f:	b0 00                	mov    al,0x0
    2241:	73 01                	jae    0x2244
    2243:	40                   	inc    ax
    2244:	22 c2                	and    al,dl
    2246:	08 c0                	or     al,al
    2248:	74 17                	je     0x2261
    224a:	bf 21 20             	mov    di,0x2021
    224d:	0e                   	push   cs
    224e:	57                   	push   di
    224f:	8d be fc fd          	lea    di,[bp-0x204]
    2253:	16                   	push   ss
    2254:	57                   	push   di
    2255:	68 ff 00             	push   0xff
    2258:	6a 03                	push   0x3
    225a:	9a 16 19 75 22       	call   0x2275:0x1916
    225f:	eb a1                	jmp    0x2202
    2261:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    2266:	76 0f                	jbe    0x2277
    2268:	8d be fc fd          	lea    di,[bp-0x204]
    226c:	16                   	push   ss
    226d:	57                   	push   di
    226e:	6a 03                	push   0x3
    2270:	6a 01                	push   0x1
    2272:	9a 75 19 9c 22       	call   0x229c:0x1975
    2277:	8d be fc fd          	lea    di,[bp-0x204]
    227b:	16                   	push   ss
    227c:	57                   	push   di
    227d:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2281:	06                   	push   es
    2282:	57                   	push   di
    2283:	9a f9 60 95 22       	call   0x2295:0x60f9
    2288:	e9 ec 01             	jmp    0x2477
    228b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    228e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2291:	bf c8 07             	mov    di,0x7c8
    2294:	b8 af 22             	mov    ax,0x22af
    2297:	50                   	push   ax
    2298:	57                   	push   di
    2299:	9a 55 22 b6 22       	call   0x22b6:0x2255
    229e:	08 c0                	or     al,al
    22a0:	75 03                	jne    0x22a5
    22a2:	e9 d2 01             	jmp    0x2477
    22a5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22a8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22ab:	bf c8 07             	mov    di,0x7c8
    22ae:	b8 75 24             	mov    ax,0x2475
    22b1:	50                   	push   ax
    22b2:	57                   	push   di
    22b3:	9a 73 22 d5 22       	call   0x22d5:0x2273
    22b8:	89 c7                	mov    di,ax
    22ba:	8e c2                	mov    es,dx
    22bc:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    22c0:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    22c4:	bf 23 20             	mov    di,0x2023
    22c7:	0e                   	push   cs
    22c8:	57                   	push   di
    22c9:	8d be fc fd          	lea    di,[bp-0x204]
    22cd:	16                   	push   ss
    22ce:	57                   	push   di
    22cf:	68 ff 00             	push   0xff
    22d2:	9a e7 17 19 23       	call   0x2319:0x17e7
    22d7:	8d be ec fc          	lea    di,[bp-0x314]
    22db:	16                   	push   ss
    22dc:	57                   	push   di
    22dd:	8d be fc fd          	lea    di,[bp-0x204]
    22e1:	16                   	push   ss
    22e2:	57                   	push   di
    22e3:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    22e7:	06                   	push   es
    22e8:	57                   	push   di
    22e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22ec:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    22f0:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    22f4:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    22f8:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    22fd:	83 ec 0a             	sub    sp,0xa
    2300:	89 e3                	mov    bx,sp
    2302:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2306:	90                   	nop
    2307:	9b                   	fwait
    2308:	9a d4 10 98 23       	call   0x2398:0x10d4
    230d:	8d be fc fe          	lea    di,[bp-0x104]
    2311:	16                   	push   ss
    2312:	57                   	push   di
    2313:	68 ff 00             	push   0xff
    2316:	9a e7 17 48 23       	call   0x2348:0x17e7
    231b:	8d be fc fe          	lea    di,[bp-0x104]
    231f:	16                   	push   ss
    2320:	57                   	push   di
    2321:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2324:	06                   	push   es
    2325:	57                   	push   di
    2326:	9a d5 33 b6 23       	call   0x23b6:0x33d5
    232b:	89 c7                	mov    di,ax
    232d:	8e c2                	mov    es,dx
    232f:	06                   	push   es
    2330:	57                   	push   di
    2331:	9a 03 20 c1 23       	call   0x23c1:0x2003
    2336:	8b d0                	mov    dx,ax
    2338:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    233c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2340:	2d 05 00             	sub    ax,0x5
    2343:	71 05                	jno    0x234a
    2345:	9a 3e 04 62 23       	call   0x2362:0x43e
    234a:	3b c2                	cmp    ax,dx
    234c:	7e 03                	jle    0x2351
    234e:	e9 15 01             	jmp    0x2466
    2351:	bf 29 20             	mov    di,0x2029
    2354:	0e                   	push   cs
    2355:	57                   	push   di
    2356:	8d be fc fd          	lea    di,[bp-0x204]
    235a:	16                   	push   ss
    235b:	57                   	push   di
    235c:	68 ff 00             	push   0xff
    235f:	9a e7 17 a6 23       	call   0x23a6:0x17e7
    2364:	8d be ec fc          	lea    di,[bp-0x314]
    2368:	16                   	push   ss
    2369:	57                   	push   di
    236a:	8d be fc fd          	lea    di,[bp-0x204]
    236e:	16                   	push   ss
    236f:	57                   	push   di
    2370:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2374:	06                   	push   es
    2375:	57                   	push   di
    2376:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2379:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    237d:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    2381:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    2385:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    238a:	83 ec 0a             	sub    sp,0xa
    238d:	89 e3                	mov    bx,sp
    238f:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2393:	90                   	nop
    2394:	9b                   	fwait
    2395:	9a d4 10 9a 26       	call   0x269a:0x10d4
    239a:	8d be fc fe          	lea    di,[bp-0x104]
    239e:	16                   	push   ss
    239f:	57                   	push   di
    23a0:	68 ff 00             	push   0xff
    23a3:	9a e7 17 d5 23       	call   0x23d5:0x17e7
    23a8:	8d be fc fe          	lea    di,[bp-0x104]
    23ac:	16                   	push   ss
    23ad:	57                   	push   di
    23ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b1:	06                   	push   es
    23b2:	57                   	push   di
    23b3:	9a d5 33 ff 23       	call   0x23ff:0x33d5
    23b8:	89 c7                	mov    di,ax
    23ba:	8e c2                	mov    es,dx
    23bc:	06                   	push   es
    23bd:	57                   	push   di
    23be:	9a 03 20 0a 24       	call   0x240a:0x2003
    23c3:	8b d0                	mov    dx,ax
    23c5:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    23c9:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    23cd:	2d 05 00             	sub    ax,0x5
    23d0:	71 05                	jno    0x23d7
    23d2:	9a 3e 04 ef 23       	call   0x23ef:0x43e
    23d7:	3b c2                	cmp    ax,dx
    23d9:	7e 03                	jle    0x23de
    23db:	e9 88 00             	jmp    0x2466
    23de:	bf 19 20             	mov    di,0x2019
    23e1:	0e                   	push   cs
    23e2:	57                   	push   di
    23e3:	8d be fc fd          	lea    di,[bp-0x204]
    23e7:	16                   	push   ss
    23e8:	57                   	push   di
    23e9:	68 ff 00             	push   0xff
    23ec:	9a e7 17 1e 24       	call   0x241e:0x17e7
    23f1:	8d be fc fd          	lea    di,[bp-0x204]
    23f5:	16                   	push   ss
    23f6:	57                   	push   di
    23f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fa:	06                   	push   es
    23fb:	57                   	push   di
    23fc:	9a d5 33 8b 24       	call   0x248b:0x33d5
    2401:	89 c7                	mov    di,ax
    2403:	8e c2                	mov    es,dx
    2405:	06                   	push   es
    2406:	57                   	push   di
    2407:	9a 03 20 96 24       	call   0x2496:0x2003
    240c:	8b d0                	mov    dx,ax
    240e:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2412:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2416:	2d 05 00             	sub    ax,0x5
    2419:	71 05                	jno    0x2420
    241b:	9a 3e 04 4c 24       	call   0x244c:0x43e
    2420:	3b c2                	cmp    ax,dx
    2422:	b0 00                	mov    al,0x0
    2424:	7e 01                	jle    0x2427
    2426:	40                   	inc    ax
    2427:	8a d0                	mov    dl,al
    2429:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    242e:	b0 00                	mov    al,0x0
    2430:	73 01                	jae    0x2433
    2432:	40                   	inc    ax
    2433:	22 c2                	and    al,dl
    2435:	08 c0                	or     al,al
    2437:	74 17                	je     0x2450
    2439:	bf 21 20             	mov    di,0x2021
    243c:	0e                   	push   cs
    243d:	57                   	push   di
    243e:	8d be fc fd          	lea    di,[bp-0x204]
    2442:	16                   	push   ss
    2443:	57                   	push   di
    2444:	68 ff 00             	push   0xff
    2447:	6a 03                	push   0x3
    2449:	9a 16 19 64 24       	call   0x2464:0x1916
    244e:	eb a1                	jmp    0x23f1
    2450:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    2455:	76 0f                	jbe    0x2466
    2457:	8d be fc fd          	lea    di,[bp-0x204]
    245b:	16                   	push   ss
    245c:	57                   	push   di
    245d:	6a 03                	push   0x3
    245f:	6a 01                	push   0x1
    2461:	9a 75 19 a4 24       	call   0x24a4:0x1975
    2466:	8d be fc fd          	lea    di,[bp-0x204]
    246a:	16                   	push   ss
    246b:	57                   	push   di
    246c:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2470:	06                   	push   es
    2471:	57                   	push   di
    2472:	9a f9 60 48 26       	call   0x2648:0x60f9
    2477:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    247b:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    247f:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2483:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2486:	06                   	push   es
    2487:	57                   	push   di
    2488:	9a d5 33 af 25       	call   0x25af:0x33d5
    248d:	89 c7                	mov    di,ax
    248f:	8e c2                	mov    es,dx
    2491:	06                   	push   es
    2492:	57                   	push   di
    2493:	9a 99 20 12 28       	call   0x2812:0x2099
    2498:	c9                   	leave
    2499:	ca 08 00             	retf   0x8
    249c:	55                   	push   bp
    249d:	89 e5                	mov    bp,sp
    249f:	31 c0                	xor    ax,ax
    24a1:	9a 44 04 b7 24       	call   0x24b7:0x444
    24a6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24a9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24ac:	bf a2 0b             	mov    di,0xba2
    24af:	b8 c4 24             	mov    ax,0x24c4
    24b2:	50                   	push   ax
    24b3:	57                   	push   di
    24b4:	9a 55 22 cb 24       	call   0x24cb:0x2255
    24b9:	50                   	push   ax
    24ba:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24bd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24c0:	bf 22 00             	mov    di,0x22
    24c3:	b8 06 25             	mov    ax,0x2506
    24c6:	50                   	push   ax
    24c7:	57                   	push   di
    24c8:	9a 55 22 f1 24       	call   0x24f1:0x2255
    24cd:	5a                   	pop    dx
    24ce:	0a c2                	or     al,dl
    24d0:	08 c0                	or     al,al
    24d2:	74 11                	je     0x24e5
    24d4:	6a 00                	push   0x0
    24d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d9:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    24de:	06                   	push   es
    24df:	57                   	push   di
    24e0:	9a 77 1c 39 25       	call   0x2539:0x1c77
    24e5:	c9                   	leave
    24e6:	ca 08 00             	retf   0x8
    24e9:	55                   	push   bp
    24ea:	89 e5                	mov    bp,sp
    24ec:	31 c0                	xor    ax,ax
    24ee:	9a 44 04 0d 25       	call   0x250d:0x444
    24f3:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    24f6:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    24fa:	75 3f                	jne    0x253b
    24fc:	ff 76 12             	push   WORD PTR [bp+0x12]
    24ff:	ff 76 10             	push   WORD PTR [bp+0x10]
    2502:	bf a2 0b             	mov    di,0xba2
    2505:	b8 1a 25             	mov    ax,0x251a
    2508:	50                   	push   ax
    2509:	57                   	push   di
    250a:	9a 55 22 21 25       	call   0x2521:0x2255
    250f:	50                   	push   ax
    2510:	ff 76 12             	push   WORD PTR [bp+0x12]
    2513:	ff 76 10             	push   WORD PTR [bp+0x10]
    2516:	bf 22 00             	mov    di,0x22
    2519:	b8 de 25             	mov    ax,0x25de
    251c:	50                   	push   ax
    251d:	57                   	push   di
    251e:	9a 55 22 55 25       	call   0x2555:0x2255
    2523:	5a                   	pop    dx
    2524:	0a c2                	or     al,dl
    2526:	08 c0                	or     al,al
    2528:	74 11                	je     0x253b
    252a:	6a 00                	push   0x0
    252c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    252f:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    2534:	06                   	push   es
    2535:	57                   	push   di
    2536:	9a 77 1c 6e 25       	call   0x256e:0x1c77
    253b:	c9                   	leave
    253c:	ca 0e 00             	retf   0xe
    253f:	0a 23                	or     ah,BYTE PTR [bp+di]
    2541:	2c 23                	sub    al,0x23
    2543:	23 30                	and    si,WORD PTR [bx+si]
    2545:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    2548:	23 23                	and    sp,WORD PTR [bp+di]
    254a:	01 20                	add    WORD PTR [bx+si],sp
    254c:	55                   	push   bp
    254d:	89 e5                	mov    bp,sp
    254f:	b8 10 02             	mov    ax,0x210
    2552:	9a 44 04 75 25       	call   0x2575:0x444
    2557:	81 ec 10 02          	sub    sp,0x210
    255b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    255e:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    2562:	75 4d                	jne    0x25b1
    2564:	ff 76 12             	push   WORD PTR [bp+0x12]
    2567:	ff 76 10             	push   WORD PTR [bp+0x10]
    256a:	bf c1 05             	mov    di,0x5c1
    256d:	b8 8f 25             	mov    ax,0x258f
    2570:	50                   	push   ax
    2571:	57                   	push   di
    2572:	9a 55 22 96 25       	call   0x2596:0x2255
    2577:	08 c0                	or     al,al
    2579:	74 36                	je     0x25b1
    257b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    257e:	31 c0                	xor    ax,ax
    2580:	26 89 05             	mov    WORD PTR es:[di],ax
    2583:	6a 08                	push   0x8
    2585:	ff 76 12             	push   WORD PTR [bp+0x12]
    2588:	ff 76 10             	push   WORD PTR [bp+0x10]
    258b:	bf c1 05             	mov    di,0x5c1
    258e:	b8 04 27             	mov    ax,0x2704
    2591:	50                   	push   ax
    2592:	57                   	push   di
    2593:	9a 73 22 e5 25       	call   0x25e5:0x2273
    2598:	89 c7                	mov    di,ax
    259a:	8e c2                	mov    es,dx
    259c:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    25a1:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    25a6:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    25aa:	06                   	push   es
    25ab:	57                   	push   di
    25ac:	9a b2 77 eb 27       	call   0x27eb:0x77b2
    25b1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    25b4:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    25b8:	74 03                	je     0x25bd
    25ba:	e9 9e 03             	jmp    0x295b
    25bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c0:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    25c5:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    25ca:	74 03                	je     0x25cf
    25cc:	e9 8c 03             	jmp    0x295b
    25cf:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    25d4:	ff 76 12             	push   WORD PTR [bp+0x12]
    25d7:	ff 76 10             	push   WORD PTR [bp+0x10]
    25da:	bf 22 00             	mov    di,0x22
    25dd:	b8 f8 25             	mov    ax,0x25f8
    25e0:	50                   	push   ax
    25e1:	57                   	push   di
    25e2:	9a 55 22 ff 25       	call   0x25ff:0x2255
    25e7:	08 c0                	or     al,al
    25e9:	75 03                	jne    0x25ee
    25eb:	e9 1e 01             	jmp    0x270c
    25ee:	ff 76 12             	push   WORD PTR [bp+0x12]
    25f1:	ff 76 10             	push   WORD PTR [bp+0x10]
    25f4:	bf 22 00             	mov    di,0x22
    25f7:	b8 1c 26             	mov    ax,0x261c
    25fa:	50                   	push   ax
    25fb:	57                   	push   di
    25fc:	9a 73 22 4f 26       	call   0x264f:0x2273
    2601:	89 c7                	mov    di,ax
    2603:	8e c2                	mov    es,dx
    2605:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2609:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    260d:	8d be f4 fd          	lea    di,[bp-0x20c]
    2611:	16                   	push   ss
    2612:	57                   	push   di
    2613:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2617:	06                   	push   es
    2618:	57                   	push   di
    2619:	9a 9f 1a 27 26       	call   0x2627:0x1a9f
    261e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2622:	06                   	push   es
    2623:	57                   	push   di
    2624:	9a 5f 1a 16 27       	call   0x2716:0x1a5f
    2629:	89 c7                	mov    di,ax
    262b:	8e c2                	mov    es,dx
    262d:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2631:	06                   	push   es
    2632:	57                   	push   di
    2633:	9a 9b 3b 08 2a       	call   0x2a08:0x3b9b
    2638:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    263b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    263e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2641:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2644:	bf 58 0a             	mov    di,0xa58
    2647:	b8 5f 26             	mov    ax,0x265f
    264a:	50                   	push   ax
    264b:	57                   	push   di
    264c:	9a 55 22 66 26       	call   0x2666:0x2255
    2651:	08 c0                	or     al,al
    2653:	74 57                	je     0x26ac
    2655:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2658:	ff 76 f8             	push   WORD PTR [bp-0x8]
    265b:	bf 58 0a             	mov    di,0xa58
    265e:	b8 14 2a             	mov    ax,0x2a14
    2661:	50                   	push   ax
    2662:	57                   	push   di
    2663:	9a 73 22 a8 26       	call   0x26a8:0x2273
    2668:	89 c7                	mov    di,ax
    266a:	8e c2                	mov    es,dx
    266c:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    2670:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    2674:	8d be f0 fd          	lea    di,[bp-0x210]
    2678:	16                   	push   ss
    2679:	57                   	push   di
    267a:	bf 3f 25             	mov    di,0x253f
    267d:	0e                   	push   cs
    267e:	57                   	push   di
    267f:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    2683:	06                   	push   es
    2684:	57                   	push   di
    2685:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2688:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    268c:	83 ec 0a             	sub    sp,0xa
    268f:	89 e3                	mov    bx,sp
    2691:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2695:	90                   	nop
    2696:	9b                   	fwait
    2697:	9a d4 10 ba 2c       	call   0x2cba:0x10d4
    269c:	8d be f8 fe          	lea    di,[bp-0x108]
    26a0:	16                   	push   ss
    26a1:	57                   	push   di
    26a2:	68 ff 00             	push   0xff
    26a5:	9a e7 17 c9 26       	call   0x26c9:0x17e7
    26aa:	eb 1f                	jmp    0x26cb
    26ac:	8d be f4 fd          	lea    di,[bp-0x20c]
    26b0:	16                   	push   ss
    26b1:	57                   	push   di
    26b2:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26b6:	06                   	push   es
    26b7:	57                   	push   di
    26b8:	9a 24 15 47 61       	call   0x6147:0x1524
    26bd:	8d be f8 fe          	lea    di,[bp-0x108]
    26c1:	16                   	push   ss
    26c2:	57                   	push   di
    26c3:	68 ff 00             	push   0xff
    26c6:	9a e7 17 db 26       	call   0x26db:0x17e7
    26cb:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26cf:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    26d3:	2d 04 00             	sub    ax,0x4
    26d6:	71 05                	jno    0x26dd
    26d8:	9a 3e 04 f0 26       	call   0x26f0:0x43e
    26dd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26e0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26e4:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    26e8:	2d 04 00             	sub    ax,0x4
    26eb:	71 05                	jno    0x26f2
    26ed:	9a 3e 04 1d 27       	call   0x271d:0x43e
    26f2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26f5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    26fb:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26ff:	06                   	push   es
    2700:	57                   	push   di
    2701:	9a d4 19 54 27       	call   0x2754:0x19d4
    2706:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2709:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    270c:	ff 76 12             	push   WORD PTR [bp+0x12]
    270f:	ff 76 10             	push   WORD PTR [bp+0x10]
    2712:	bf a2 0b             	mov    di,0xba2
    2715:	b8 30 27             	mov    ax,0x2730
    2718:	50                   	push   ax
    2719:	57                   	push   di
    271a:	9a 55 22 37 27       	call   0x2737:0x2255
    271f:	08 c0                	or     al,al
    2721:	75 03                	jne    0x2726
    2723:	e9 7f 00             	jmp    0x27a5
    2726:	ff 76 12             	push   WORD PTR [bp+0x12]
    2729:	ff 76 10             	push   WORD PTR [bp+0x10]
    272c:	bf a2 0b             	mov    di,0xba2
    272f:	b8 a6 29             	mov    ax,0x29a6
    2732:	50                   	push   ax
    2733:	57                   	push   di
    2734:	9a 73 22 62 27       	call   0x2762:0x2273
    2739:	89 c7                	mov    di,ax
    273b:	8e c2                	mov    es,dx
    273d:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2741:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2745:	8d be f4 fd          	lea    di,[bp-0x20c]
    2749:	16                   	push   ss
    274a:	57                   	push   di
    274b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    274f:	06                   	push   es
    2750:	57                   	push   di
    2751:	9a 53 1d 9d 27       	call   0x279d:0x1d53
    2756:	8d be f8 fe          	lea    di,[bp-0x108]
    275a:	16                   	push   ss
    275b:	57                   	push   di
    275c:	68 ff 00             	push   0xff
    275f:	9a e7 17 74 27       	call   0x2774:0x17e7
    2764:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2768:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    276c:	2d 04 00             	sub    ax,0x4
    276f:	71 05                	jno    0x2776
    2771:	9a 3e 04 89 27       	call   0x2789:0x43e
    2776:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2779:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    277d:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2781:	2d 04 00             	sub    ax,0x4
    2784:	71 05                	jno    0x278b
    2786:	9a 3e 04 bd 27       	call   0x27bd:0x43e
    278b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    278e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2791:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2794:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2798:	06                   	push   es
    2799:	57                   	push   di
    279a:	9a d4 19 e1 27       	call   0x27e1:0x19d4
    279f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    27a2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    27a5:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    27aa:	77 03                	ja     0x27af
    27ac:	e9 ac 01             	jmp    0x295b
    27af:	8d be f8 fd          	lea    di,[bp-0x208]
    27b3:	16                   	push   ss
    27b4:	57                   	push   di
    27b5:	bf 4a 25             	mov    di,0x254a
    27b8:	0e                   	push   cs
    27b9:	57                   	push   di
    27ba:	9a cd 17 c8 27       	call   0x27c8:0x17cd
    27bf:	8d be f8 fe          	lea    di,[bp-0x108]
    27c3:	16                   	push   ss
    27c4:	57                   	push   di
    27c5:	9a 4c 18 d2 27       	call   0x27d2:0x184c
    27ca:	bf 4a 25             	mov    di,0x254a
    27cd:	0e                   	push   cs
    27ce:	57                   	push   di
    27cf:	9a 4c 18 6e 28       	call   0x286e:0x184c
    27d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d7:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    27dc:	06                   	push   es
    27dd:	57                   	push   di
    27de:	9a 8c 1d 27 28       	call   0x2827:0x1d8c
    27e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e6:	06                   	push   es
    27e7:	57                   	push   di
    27e8:	9a d5 33 12 36       	call   0x3612:0x33d5
    27ed:	89 c7                	mov    di,ax
    27ef:	8e c2                	mov    es,dx
    27f1:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    27f5:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    27f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fc:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    2801:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2805:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2809:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    280d:	06                   	push   es
    280e:	57                   	push   di
    280f:	9a 99 20 32 28       	call   0x2832:0x2099
    2814:	8d be f4 fd          	lea    di,[bp-0x20c]
    2818:	16                   	push   ss
    2819:	57                   	push   di
    281a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    281d:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    2822:	06                   	push   es
    2823:	57                   	push   di
    2824:	9a 53 1d 42 28       	call   0x2842:0x1d53
    2829:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    282d:	06                   	push   es
    282e:	57                   	push   di
    282f:	9a 03 20 62 28       	call   0x2862:0x2003
    2834:	50                   	push   ax
    2835:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2838:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    283d:	06                   	push   es
    283e:	57                   	push   di
    283f:	9a bf 17 57 28       	call   0x2857:0x17bf
    2844:	8d be f4 fd          	lea    di,[bp-0x20c]
    2848:	16                   	push   ss
    2849:	57                   	push   di
    284a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284d:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    2852:	06                   	push   es
    2853:	57                   	push   di
    2854:	9a 53 1d 84 28       	call   0x2884:0x1d53
    2859:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    285d:	06                   	push   es
    285e:	57                   	push   di
    285f:	9a 4e 20 f3 59       	call   0x59f3:0x204e
    2864:	b9 03 00             	mov    cx,0x3
    2867:	f7 e9                	imul   cx
    2869:	71 05                	jno    0x2870
    286b:	9a 3e 04 e1 28       	call   0x28e1:0x43e
    2870:	99                   	cwd
    2871:	b9 02 00             	mov    cx,0x2
    2874:	f7 f9                	idiv   cx
    2876:	50                   	push   ax
    2877:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287a:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    287f:	06                   	push   es
    2880:	57                   	push   di
    2881:	9a e1 17 94 28       	call   0x2894:0x17e1
    2886:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2889:	ff 76 fc             	push   WORD PTR [bp-0x4]
    288c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    288f:	06                   	push   es
    2890:	57                   	push   di
    2891:	9a 06 1a b4 28       	call   0x28b4:0x1a06
    2896:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2899:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    289c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289f:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    28a4:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    28a8:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    28ac:	ff 76 fc             	push   WORD PTR [bp-0x4]
    28af:	06                   	push   es
    28b0:	57                   	push   di
    28b1:	9a 7b 17 c2 28       	call   0x28c2:0x177b
    28b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28b9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28bd:	06                   	push   es
    28be:	57                   	push   di
    28bf:	9a 9d 17 cc 28       	call   0x28cc:0x179d
    28c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c7:	06                   	push   es
    28c8:	57                   	push   di
    28c9:	9a a9 18 03 29       	call   0x2903:0x18a9
    28ce:	8b d0                	mov    dx,ax
    28d0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28d4:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    28d8:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    28dc:	71 05                	jno    0x28e3
    28de:	9a 3e 04 f7 28       	call   0x28f7:0x43e
    28e3:	3b c2                	cmp    ax,dx
    28e5:	7e 20                	jle    0x2907
    28e7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28eb:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    28ef:	2d 08 00             	sub    ax,0x8
    28f2:	71 05                	jno    0x28f9
    28f4:	9a 3e 04 24 29       	call   0x2924:0x43e
    28f9:	50                   	push   ax
    28fa:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28fe:	06                   	push   es
    28ff:	57                   	push   di
    2900:	9a 7b 17 0f 29       	call   0x290f:0x177b
    2905:	eb bd                	jmp    0x28c4
    2907:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290a:	06                   	push   es
    290b:	57                   	push   di
    290c:	9a f4 18 46 29       	call   0x2946:0x18f4
    2911:	8b d0                	mov    dx,ax
    2913:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2917:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    291b:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    291f:	71 05                	jno    0x2926
    2921:	9a 3e 04 3a 29       	call   0x293a:0x43e
    2926:	3b c2                	cmp    ax,dx
    2928:	7e 20                	jle    0x294a
    292a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    292e:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2932:	2d 08 00             	sub    ax,0x8
    2935:	71 05                	jno    0x293c
    2937:	9a 3e 04 68 29       	call   0x2968:0x43e
    293c:	50                   	push   ax
    293d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2941:	06                   	push   es
    2942:	57                   	push   di
    2943:	9a 9d 17 59 29       	call   0x2959:0x179d
    2948:	eb bd                	jmp    0x2907
    294a:	6a 01                	push   0x1
    294c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294f:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
    2954:	06                   	push   es
    2955:	57                   	push   di
    2956:	9a 77 1c c9 2c       	call   0x2cc9:0x1c77
    295b:	c9                   	leave
    295c:	ca 0e 00             	retf   0xe
    295f:	55                   	push   bp
    2960:	89 e5                	mov    bp,sp
    2962:	b8 04 00             	mov    ax,0x4
    2965:	9a 44 04 7f 29       	call   0x297f:0x444
    296a:	83 ec 04             	sub    sp,0x4
    296d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2970:	06                   	push   es
    2971:	57                   	push   di
    2972:	9a 7d 52 9e 29       	call   0x299e:0x527d
    2977:	2d 01 00             	sub    ax,0x1
    297a:	71 05                	jno    0x2981
    297c:	9a 3e 04 ad 29       	call   0x29ad:0x43e
    2981:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2984:	31 c0                	xor    ax,ax
    2986:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2989:	7f 58                	jg     0x29e3
    298b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    298e:	eb 03                	jmp    0x2993
    2990:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2993:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2996:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2999:	06                   	push   es
    299a:	57                   	push   di
    299b:	9a 46 52 be 29       	call   0x29be:0x5246
    29a0:	52                   	push   dx
    29a1:	50                   	push   ax
    29a2:	bf 22 00             	mov    di,0x22
    29a5:	b8 c6 29             	mov    ax,0x29c6
    29a8:	50                   	push   ax
    29a9:	57                   	push   di
    29aa:	9a 55 22 cd 29       	call   0x29cd:0x2255
    29af:	08 c0                	or     al,al
    29b1:	74 28                	je     0x29db
    29b3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b9:	06                   	push   es
    29ba:	57                   	push   di
    29bb:	9a 46 52 2d 36       	call   0x362d:0x5246
    29c0:	52                   	push   dx
    29c1:	50                   	push   ax
    29c2:	bf 22 00             	mov    di,0x22
    29c5:	b8 0c 61             	mov    ax,0x610c
    29c8:	50                   	push   ax
    29c9:	57                   	push   di
    29ca:	9a 73 22 f0 29       	call   0x29f0:0x2273
    29cf:	52                   	push   dx
    29d0:	50                   	push   ax
    29d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29d4:	06                   	push   es
    29d5:	57                   	push   di
    29d6:	9a 2c 20 f2 2e       	call   0x2ef2:0x202c
    29db:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    29de:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    29e1:	75 ad                	jne    0x2990
    29e3:	c9                   	leave
    29e4:	ca 04 00             	retf   0x4
    29e7:	55                   	push   bp
    29e8:	89 e5                	mov    bp,sp
    29ea:	b8 04 00             	mov    ax,0x4
    29ed:	9a 44 04 a0 2c       	call   0x2ca0:0x444
    29f2:	83 ec 04             	sub    sp,0x4
    29f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f8:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    29fd:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2a00:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2a03:	06                   	push   es
    2a04:	57                   	push   di
    2a05:	9a d2 31 2a 2a       	call   0x2a2a:0x31d2
    2a0a:	6a 01                	push   0x1
    2a0c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a0f:	06                   	push   es
    2a10:	57                   	push   di
    2a11:	9a fb 2f 20 2a       	call   0x2a20:0x2ffb
    2a16:	6a 00                	push   0x0
    2a18:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a1b:	06                   	push   es
    2a1c:	57                   	push   di
    2a1d:	9a d2 2e 4b 2a       	call   0x2a4b:0x2ed2
    2a22:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a25:	06                   	push   es
    2a26:	57                   	push   di
    2a27:	9a bf 31 3f 2a       	call   0x2a3f:0x31bf
    2a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2f:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2a34:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2a37:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2a3a:	06                   	push   es
    2a3b:	57                   	push   di
    2a3c:	9a d2 31 61 2a       	call   0x2a61:0x31d2
    2a41:	6a 01                	push   0x1
    2a43:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a46:	06                   	push   es
    2a47:	57                   	push   di
    2a48:	9a fb 2f 57 2a       	call   0x2a57:0x2ffb
    2a4d:	6a 00                	push   0x0
    2a4f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a52:	06                   	push   es
    2a53:	57                   	push   di
    2a54:	9a d2 2e 82 2a       	call   0x2a82:0x2ed2
    2a59:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a5c:	06                   	push   es
    2a5d:	57                   	push   di
    2a5e:	9a bf 31 76 2a       	call   0x2a76:0x31bf
    2a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a66:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    2a6b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2a6e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2a71:	06                   	push   es
    2a72:	57                   	push   di
    2a73:	9a d2 31 98 2a       	call   0x2a98:0x31d2
    2a78:	6a 01                	push   0x1
    2a7a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a7d:	06                   	push   es
    2a7e:	57                   	push   di
    2a7f:	9a fb 2f 8e 2a       	call   0x2a8e:0x2ffb
    2a84:	6a 00                	push   0x0
    2a86:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a89:	06                   	push   es
    2a8a:	57                   	push   di
    2a8b:	9a d2 2e b9 2a       	call   0x2ab9:0x2ed2
    2a90:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a93:	06                   	push   es
    2a94:	57                   	push   di
    2a95:	9a bf 31 ad 2a       	call   0x2aad:0x31bf
    2a9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9d:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    2aa2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2aa5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2aa8:	06                   	push   es
    2aa9:	57                   	push   di
    2aaa:	9a d2 31 cf 2a       	call   0x2acf:0x31d2
    2aaf:	6a 01                	push   0x1
    2ab1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ab4:	06                   	push   es
    2ab5:	57                   	push   di
    2ab6:	9a fb 2f c5 2a       	call   0x2ac5:0x2ffb
    2abb:	6a 00                	push   0x0
    2abd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ac0:	06                   	push   es
    2ac1:	57                   	push   di
    2ac2:	9a d2 2e f0 2a       	call   0x2af0:0x2ed2
    2ac7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2aca:	06                   	push   es
    2acb:	57                   	push   di
    2acc:	9a bf 31 e4 2a       	call   0x2ae4:0x31bf
    2ad1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad4:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2ad9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2adc:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2adf:	06                   	push   es
    2ae0:	57                   	push   di
    2ae1:	9a d2 31 06 2b       	call   0x2b06:0x31d2
    2ae6:	6a 01                	push   0x1
    2ae8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2aeb:	06                   	push   es
    2aec:	57                   	push   di
    2aed:	9a fb 2f fc 2a       	call   0x2afc:0x2ffb
    2af2:	6a 00                	push   0x0
    2af4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2af7:	06                   	push   es
    2af8:	57                   	push   di
    2af9:	9a d2 2e 27 2b       	call   0x2b27:0x2ed2
    2afe:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b01:	06                   	push   es
    2b02:	57                   	push   di
    2b03:	9a bf 31 1b 2b       	call   0x2b1b:0x31bf
    2b08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b0b:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    2b10:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b13:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b16:	06                   	push   es
    2b17:	57                   	push   di
    2b18:	9a d2 31 3d 2b       	call   0x2b3d:0x31d2
    2b1d:	6a 01                	push   0x1
    2b1f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b22:	06                   	push   es
    2b23:	57                   	push   di
    2b24:	9a fb 2f 33 2b       	call   0x2b33:0x2ffb
    2b29:	6a 00                	push   0x0
    2b2b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b2e:	06                   	push   es
    2b2f:	57                   	push   di
    2b30:	9a d2 2e 5e 2b       	call   0x2b5e:0x2ed2
    2b35:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b38:	06                   	push   es
    2b39:	57                   	push   di
    2b3a:	9a bf 31 52 2b       	call   0x2b52:0x31bf
    2b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b42:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    2b47:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b4a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b4d:	06                   	push   es
    2b4e:	57                   	push   di
    2b4f:	9a d2 31 74 2b       	call   0x2b74:0x31d2
    2b54:	6a 01                	push   0x1
    2b56:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b59:	06                   	push   es
    2b5a:	57                   	push   di
    2b5b:	9a fb 2f 6a 2b       	call   0x2b6a:0x2ffb
    2b60:	6a 00                	push   0x0
    2b62:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b65:	06                   	push   es
    2b66:	57                   	push   di
    2b67:	9a d2 2e 95 2b       	call   0x2b95:0x2ed2
    2b6c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b6f:	06                   	push   es
    2b70:	57                   	push   di
    2b71:	9a bf 31 89 2b       	call   0x2b89:0x31bf
    2b76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b79:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2b7e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b81:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b84:	06                   	push   es
    2b85:	57                   	push   di
    2b86:	9a d2 31 ab 2b       	call   0x2bab:0x31d2
    2b8b:	6a 01                	push   0x1
    2b8d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b90:	06                   	push   es
    2b91:	57                   	push   di
    2b92:	9a fb 2f a1 2b       	call   0x2ba1:0x2ffb
    2b97:	6a 00                	push   0x0
    2b99:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b9c:	06                   	push   es
    2b9d:	57                   	push   di
    2b9e:	9a d2 2e cc 2b       	call   0x2bcc:0x2ed2
    2ba3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ba6:	06                   	push   es
    2ba7:	57                   	push   di
    2ba8:	9a bf 31 c0 2b       	call   0x2bc0:0x31bf
    2bad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb0:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    2bb5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2bb8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2bbb:	06                   	push   es
    2bbc:	57                   	push   di
    2bbd:	9a d2 31 e2 2b       	call   0x2be2:0x31d2
    2bc2:	6a 01                	push   0x1
    2bc4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2bc7:	06                   	push   es
    2bc8:	57                   	push   di
    2bc9:	9a fb 2f d8 2b       	call   0x2bd8:0x2ffb
    2bce:	6a 00                	push   0x0
    2bd0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2bd3:	06                   	push   es
    2bd4:	57                   	push   di
    2bd5:	9a d2 2e 03 2c       	call   0x2c03:0x2ed2
    2bda:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2bdd:	06                   	push   es
    2bde:	57                   	push   di
    2bdf:	9a bf 31 f7 2b       	call   0x2bf7:0x31bf
    2be4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be7:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    2bec:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2bef:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2bf2:	06                   	push   es
    2bf3:	57                   	push   di
    2bf4:	9a d2 31 19 2c       	call   0x2c19:0x31d2
    2bf9:	6a 01                	push   0x1
    2bfb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2bfe:	06                   	push   es
    2bff:	57                   	push   di
    2c00:	9a fb 2f 0f 2c       	call   0x2c0f:0x2ffb
    2c05:	6a 00                	push   0x0
    2c07:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c0a:	06                   	push   es
    2c0b:	57                   	push   di
    2c0c:	9a d2 2e 3a 2c       	call   0x2c3a:0x2ed2
    2c11:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c14:	06                   	push   es
    2c15:	57                   	push   di
    2c16:	9a bf 31 2e 2c       	call   0x2c2e:0x31bf
    2c1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c1e:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    2c23:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2c26:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2c29:	06                   	push   es
    2c2a:	57                   	push   di
    2c2b:	9a d2 31 50 2c       	call   0x2c50:0x31d2
    2c30:	6a 01                	push   0x1
    2c32:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c35:	06                   	push   es
    2c36:	57                   	push   di
    2c37:	9a fb 2f 46 2c       	call   0x2c46:0x2ffb
    2c3c:	6a 00                	push   0x0
    2c3e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c41:	06                   	push   es
    2c42:	57                   	push   di
    2c43:	9a d2 2e 71 2c       	call   0x2c71:0x2ed2
    2c48:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c4b:	06                   	push   es
    2c4c:	57                   	push   di
    2c4d:	9a bf 31 65 2c       	call   0x2c65:0x31bf
    2c52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c55:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    2c5a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2c5d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2c60:	06                   	push   es
    2c61:	57                   	push   di
    2c62:	9a d2 31 87 2c       	call   0x2c87:0x31d2
    2c67:	6a 01                	push   0x1
    2c69:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c6c:	06                   	push   es
    2c6d:	57                   	push   di
    2c6e:	9a fb 2f 7d 2c       	call   0x2c7d:0x2ffb
    2c73:	6a 00                	push   0x0
    2c75:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c78:	06                   	push   es
    2c79:	57                   	push   di
    2c7a:	9a d2 2e e4 2e       	call   0x2ee4:0x2ed2
    2c7f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c82:	06                   	push   es
    2c83:	57                   	push   di
    2c84:	9a bf 31 80 33       	call   0x3380:0x31bf
    2c89:	c9                   	leave
    2c8a:	ca 04 00             	retf   0x4
    2c8d:	01 23                	add    WORD PTR [bp+di],sp
    2c8f:	00 00                	add    BYTE PTR [bx+si],al
    2c91:	00 00                	add    BYTE PTR [bx+si],al
    2c93:	ff 00                	inc    WORD PTR [bx+si]
    2c95:	00 00                	add    BYTE PTR [bx+si],al
    2c97:	55                   	push   bp
    2c98:	89 e5                	mov    bp,sp
    2c9a:	b8 02 02             	mov    ax,0x202
    2c9d:	9a 44 04 05 2d       	call   0x2d05:0x444
    2ca2:	81 ec 02 02          	sub    sp,0x202
    2ca6:	8d be fe fd          	lea    di,[bp-0x202]
    2caa:	16                   	push   ss
    2cab:	57                   	push   di
    2cac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2caf:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    2cb4:	99                   	cwd
    2cb5:	52                   	push   dx
    2cb6:	50                   	push   ax
    2cb7:	9a a9 08 df 2c       	call   0x2cdf:0x8a9
    2cbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbf:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2cc4:	06                   	push   es
    2cc5:	57                   	push   di
    2cc6:	9a 8c 1d ee 2c       	call   0x2cee:0x1d8c
    2ccb:	8d be fe fd          	lea    di,[bp-0x202]
    2ccf:	16                   	push   ss
    2cd0:	57                   	push   di
    2cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cd4:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    2cd9:	99                   	cwd
    2cda:	52                   	push   dx
    2cdb:	50                   	push   ax
    2cdc:	9a a9 08 50 2d       	call   0x2d50:0x8a9
    2ce1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ce4:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2ce9:	06                   	push   es
    2cea:	57                   	push   di
    2ceb:	9a 8c 1d d3 2d       	call   0x2dd3:0x1d8c
    2cf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cf3:	81 c7 2e 07          	add    di,0x72e
    2cf7:	06                   	push   es
    2cf8:	57                   	push   di
    2cf9:	8d be fe fe          	lea    di,[bp-0x102]
    2cfd:	16                   	push   ss
    2cfe:	57                   	push   di
    2cff:	68 ff 00             	push   0xff
    2d02:	9a e7 17 15 2d       	call   0x2d15:0x17e7
    2d07:	bf 8d 2c             	mov    di,0x2c8d
    2d0a:	0e                   	push   cs
    2d0b:	57                   	push   di
    2d0c:	8d be fe fe          	lea    di,[bp-0x102]
    2d10:	16                   	push   ss
    2d11:	57                   	push   di
    2d12:	9a 78 18 1e 2d       	call   0x2d1e:0x1878
    2d17:	99                   	cwd
    2d18:	bf 8f 2c             	mov    di,0x2c8f
    2d1b:	9a 16 04 3a 2d       	call   0x2d3a:0x416
    2d20:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2d23:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2d27:	76 3d                	jbe    0x2d66
    2d29:	8d be fe fe          	lea    di,[bp-0x102]
    2d2d:	16                   	push   ss
    2d2e:	57                   	push   di
    2d2f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2d32:	30 e4                	xor    ah,ah
    2d34:	50                   	push   ax
    2d35:	6a 01                	push   0x1
    2d37:	9a 75 19 64 2d       	call   0x2d64:0x1975
    2d3c:	8d be fe fd          	lea    di,[bp-0x202]
    2d40:	16                   	push   ss
    2d41:	57                   	push   di
    2d42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d45:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    2d4a:	99                   	cwd
    2d4b:	52                   	push   dx
    2d4c:	50                   	push   ax
    2d4d:	9a a9 08 af 2d       	call   0x2daf:0x8a9
    2d52:	8d be fe fe          	lea    di,[bp-0x102]
    2d56:	16                   	push   ss
    2d57:	57                   	push   di
    2d58:	68 ff 00             	push   0xff
    2d5b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2d5e:	30 e4                	xor    ah,ah
    2d60:	50                   	push   ax
    2d61:	9a 16 19 74 2d       	call   0x2d74:0x1916
    2d66:	bf 8d 2c             	mov    di,0x2c8d
    2d69:	0e                   	push   cs
    2d6a:	57                   	push   di
    2d6b:	8d be fe fe          	lea    di,[bp-0x102]
    2d6f:	16                   	push   ss
    2d70:	57                   	push   di
    2d71:	9a 78 18 7d 2d       	call   0x2d7d:0x1878
    2d76:	99                   	cwd
    2d77:	bf 8f 2c             	mov    di,0x2c8f
    2d7a:	9a 16 04 99 2d       	call   0x2d99:0x416
    2d7f:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2d82:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2d86:	76 3d                	jbe    0x2dc5
    2d88:	8d be fe fe          	lea    di,[bp-0x102]
    2d8c:	16                   	push   ss
    2d8d:	57                   	push   di
    2d8e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2d91:	30 e4                	xor    ah,ah
    2d93:	50                   	push   ax
    2d94:	6a 01                	push   0x1
    2d96:	9a 75 19 c3 2d       	call   0x2dc3:0x1975
    2d9b:	8d be fe fd          	lea    di,[bp-0x202]
    2d9f:	16                   	push   ss
    2da0:	57                   	push   di
    2da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da4:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    2da9:	99                   	cwd
    2daa:	52                   	push   dx
    2dab:	50                   	push   ax
    2dac:	9a a9 08 85 37       	call   0x3785:0x8a9
    2db1:	8d be fe fe          	lea    di,[bp-0x102]
    2db5:	16                   	push   ss
    2db6:	57                   	push   di
    2db7:	68 ff 00             	push   0xff
    2dba:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2dbd:	30 e4                	xor    ah,ah
    2dbf:	50                   	push   ax
    2dc0:	9a 16 19 f4 2d       	call   0x2df4:0x1916
    2dc5:	8d be fe fe          	lea    di,[bp-0x102]
    2dc9:	16                   	push   ss
    2dca:	57                   	push   di
    2dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dce:	06                   	push   es
    2dcf:	57                   	push   di
    2dd0:	9a 8c 1d bc 34       	call   0x34bc:0x1d8c
    2dd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd8:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    2ddd:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2de1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2de5:	06                   	push   es
    2de6:	57                   	push   di
    2de7:	9a 26 13 3f 2e       	call   0x2e3f:0x1326
    2dec:	2d 01 00             	sub    ax,0x1
    2def:	71 05                	jno    0x2df6
    2df1:	9a 3e 04 fd 2d       	call   0x2dfd:0x43e
    2df6:	99                   	cwd
    2df7:	bf 8f 2c             	mov    di,0x2c8f
    2dfa:	9a 16 04 20 2e       	call   0x2e20:0x416
    2dff:	88 86 f9 fe          	mov    BYTE PTR [bp-0x107],al
    2e03:	b0 00                	mov    al,0x0
    2e05:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    2e09:	77 4a                	ja     0x2e55
    2e0b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2e0e:	eb 03                	jmp    0x2e13
    2e10:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    2e13:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e16:	30 e4                	xor    ah,ah
    2e18:	05 01 00             	add    ax,0x1
    2e1b:	71 05                	jno    0x2e22
    2e1d:	9a 3e 04 7b 2e       	call   0x2e7b:0x43e
    2e22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e25:	26 3b 85 2c 07       	cmp    ax,WORD PTR es:[di+0x72c]
    2e2a:	b0 00                	mov    al,0x0
    2e2c:	75 01                	jne    0x2e2f
    2e2e:	40                   	inc    ax
    2e2f:	50                   	push   ax
    2e30:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e33:	30 e4                	xor    ah,ah
    2e35:	50                   	push   ax
    2e36:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e3a:	06                   	push   es
    2e3b:	57                   	push   di
    2e3c:	9a 53 13 4a 2e       	call   0x2e4a:0x1353
    2e41:	89 c7                	mov    di,ax
    2e43:	8e c2                	mov    es,dx
    2e45:	06                   	push   es
    2e46:	57                   	push   di
    2e47:	9a 75 12 9a 2e       	call   0x2e9a:0x1275
    2e4c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e4f:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    2e53:	75 bb                	jne    0x2e10
    2e55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e58:	26 c4 bd a0 06       	les    di,DWORD PTR es:[di+0x6a0]
    2e5d:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2e61:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2e65:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2e69:	eb 03                	jmp    0x2e6e
    2e6b:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    2e6e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e71:	30 e4                	xor    ah,ah
    2e73:	05 01 00             	add    ax,0x1
    2e76:	71 05                	jno    0x2e7d
    2e78:	9a 3e 04 c4 2f       	call   0x2fc4:0x43e
    2e7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e80:	26 3b 85 2a 07       	cmp    ax,WORD PTR es:[di+0x72a]
    2e85:	b0 00                	mov    al,0x0
    2e87:	75 01                	jne    0x2e8a
    2e89:	40                   	inc    ax
    2e8a:	50                   	push   ax
    2e8b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e8e:	30 e4                	xor    ah,ah
    2e90:	50                   	push   ax
    2e91:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2e95:	06                   	push   es
    2e96:	57                   	push   di
    2e97:	9a 53 13 a5 2e       	call   0x2ea5:0x1353
    2e9c:	89 c7                	mov    di,ax
    2e9e:	8e c2                	mov    es,dx
    2ea0:	06                   	push   es
    2ea1:	57                   	push   di
    2ea2:	9a 75 12 07 35       	call   0x3507:0x1275
    2ea7:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    2eab:	75 be                	jne    0x2e6b
    2ead:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb0:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    2eb5:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2eb9:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2ebd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec0:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    2ec5:	99                   	cwd
    2ec6:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2eca:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2ece:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2ed3:	8d be f2 fe          	lea    di,[bp-0x10e]
    2ed7:	16                   	push   ss
    2ed8:	57                   	push   di
    2ed9:	6a 00                	push   0x0
    2edb:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2edf:	06                   	push   es
    2ee0:	57                   	push   di
    2ee1:	9a 95 28 3c 2f       	call   0x2f3c:0x2895
    2ee6:	08 c0                	or     al,al
    2ee8:	75 0a                	jne    0x2ef4
    2eea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eed:	06                   	push   es
    2eee:	57                   	push   di
    2eef:	9a b7 1c 4a 2f       	call   0x2f4a:0x1cb7
    2ef4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef7:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2efc:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2f00:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2f04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f07:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    2f0c:	99                   	cwd
    2f0d:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2f11:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2f15:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2f1a:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    2f20:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2f26:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2f2b:	8d be ea fe          	lea    di,[bp-0x116]
    2f2f:	16                   	push   ss
    2f30:	57                   	push   di
    2f31:	6a 01                	push   0x1
    2f33:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f37:	06                   	push   es
    2f38:	57                   	push   di
    2f39:	9a 95 28 94 2f       	call   0x2f94:0x2895
    2f3e:	08 c0                	or     al,al
    2f40:	75 0a                	jne    0x2f4c
    2f42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f45:	06                   	push   es
    2f46:	57                   	push   di
    2f47:	9a b7 1c a2 2f       	call   0x2fa2:0x1cb7
    2f4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f4f:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    2f54:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2f58:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2f5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f5f:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    2f64:	99                   	cwd
    2f65:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2f69:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2f6d:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2f72:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2f78:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2f7e:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2f83:	8d be ea fe          	lea    di,[bp-0x116]
    2f87:	16                   	push   ss
    2f88:	57                   	push   di
    2f89:	6a 01                	push   0x1
    2f8b:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f8f:	06                   	push   es
    2f90:	57                   	push   di
    2f91:	9a 95 28 0c 30       	call   0x300c:0x2895
    2f96:	08 c0                	or     al,al
    2f98:	75 0a                	jne    0x2fa4
    2f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f9d:	06                   	push   es
    2f9e:	57                   	push   di
    2f9f:	9a b7 1c 1a 30       	call   0x301a:0x1cb7
    2fa4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa7:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    2fac:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2fb0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2fb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb7:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    2fbc:	2d 01 00             	sub    ax,0x1
    2fbf:	71 05                	jno    0x2fc6
    2fc1:	9a 3e 04 3c 30       	call   0x303c:0x43e
    2fc6:	99                   	cwd
    2fc7:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2fcb:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2fcf:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2fd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd7:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    2fdc:	99                   	cwd
    2fdd:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2fe1:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2fe5:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2fea:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    2ff0:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2ff6:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2ffb:	8d be e2 fe          	lea    di,[bp-0x11e]
    2fff:	16                   	push   ss
    3000:	57                   	push   di
    3001:	6a 02                	push   0x2
    3003:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3007:	06                   	push   es
    3008:	57                   	push   di
    3009:	9a 95 28 84 30       	call   0x3084:0x2895
    300e:	08 c0                	or     al,al
    3010:	75 0a                	jne    0x301c
    3012:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3015:	06                   	push   es
    3016:	57                   	push   di
    3017:	9a b7 1c 92 30       	call   0x3092:0x1cb7
    301c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    301f:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    3024:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3028:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    302c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302f:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    3034:	2d 01 00             	sub    ax,0x1
    3037:	71 05                	jno    0x303e
    3039:	9a 3e 04 b4 30       	call   0x30b4:0x43e
    303e:	99                   	cwd
    303f:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3043:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    3047:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    304c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    304f:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    3054:	99                   	cwd
    3055:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    3059:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    305d:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3062:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    3068:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    306e:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3073:	8d be e2 fe          	lea    di,[bp-0x11e]
    3077:	16                   	push   ss
    3078:	57                   	push   di
    3079:	6a 02                	push   0x2
    307b:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    307f:	06                   	push   es
    3080:	57                   	push   di
    3081:	9a 95 28 eb 30       	call   0x30eb:0x2895
    3086:	08 c0                	or     al,al
    3088:	75 0a                	jne    0x3094
    308a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    308d:	06                   	push   es
    308e:	57                   	push   di
    308f:	9a b7 1c f9 30       	call   0x30f9:0x1cb7
    3094:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3097:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    309c:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    30a0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    30a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30a7:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    30ac:	2d 01 00             	sub    ax,0x1
    30af:	71 05                	jno    0x30b6
    30b1:	9a 3e 04 71 33       	call   0x3371:0x43e
    30b6:	99                   	cwd
    30b7:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    30bb:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    30bf:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    30c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c7:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    30cc:	99                   	cwd
    30cd:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    30d1:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    30d5:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    30da:	8d be ea fe          	lea    di,[bp-0x116]
    30de:	16                   	push   ss
    30df:	57                   	push   di
    30e0:	6a 01                	push   0x1
    30e2:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    30e6:	06                   	push   es
    30e7:	57                   	push   di
    30e8:	9a 95 28 56 31       	call   0x3156:0x2895
    30ed:	08 c0                	or     al,al
    30ef:	75 0a                	jne    0x30fb
    30f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f4:	06                   	push   es
    30f5:	57                   	push   di
    30f6:	9a b7 1c 64 31       	call   0x3164:0x1cb7
    30fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30fe:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    3103:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3107:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    310b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    310e:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    3113:	99                   	cwd
    3114:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3118:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    311c:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    3121:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    3126:	99                   	cwd
    3127:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    312b:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    312f:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3134:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    313a:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    3140:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3145:	8d be e2 fe          	lea    di,[bp-0x11e]
    3149:	16                   	push   ss
    314a:	57                   	push   di
    314b:	6a 02                	push   0x2
    314d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3151:	06                   	push   es
    3152:	57                   	push   di
    3153:	9a 95 28 c1 31       	call   0x31c1:0x2895
    3158:	08 c0                	or     al,al
    315a:	75 0a                	jne    0x3166
    315c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    315f:	06                   	push   es
    3160:	57                   	push   di
    3161:	9a b7 1c cf 31       	call   0x31cf:0x1cb7
    3166:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3169:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    316e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3172:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3179:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    317e:	99                   	cwd
    317f:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3183:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    3187:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    318c:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    3191:	99                   	cwd
    3192:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    3196:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    319a:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    319f:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    31a5:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    31ab:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    31b0:	8d be e2 fe          	lea    di,[bp-0x11e]
    31b4:	16                   	push   ss
    31b5:	57                   	push   di
    31b6:	6a 02                	push   0x2
    31b8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    31bc:	06                   	push   es
    31bd:	57                   	push   di
    31be:	9a 95 28 1b 32       	call   0x321b:0x2895
    31c3:	08 c0                	or     al,al
    31c5:	75 0a                	jne    0x31d1
    31c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ca:	06                   	push   es
    31cb:	57                   	push   di
    31cc:	9a b7 1c 29 32       	call   0x3229:0x1cb7
    31d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31d4:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    31d9:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    31dd:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    31e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e4:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    31e9:	99                   	cwd
    31ea:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    31ee:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    31f2:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    31f7:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    31fc:	99                   	cwd
    31fd:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3201:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    3205:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    320a:	8d be ea fe          	lea    di,[bp-0x116]
    320e:	16                   	push   ss
    320f:	57                   	push   di
    3210:	6a 01                	push   0x1
    3212:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3216:	06                   	push   es
    3217:	57                   	push   di
    3218:	9a 95 28 86 32       	call   0x3286:0x2895
    321d:	08 c0                	or     al,al
    321f:	75 0a                	jne    0x322b
    3221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3224:	06                   	push   es
    3225:	57                   	push   di
    3226:	9a b7 1c 94 32       	call   0x3294:0x1cb7
    322b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322e:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    3233:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3237:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    323b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    323e:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    3243:	99                   	cwd
    3244:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3248:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    324c:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    3251:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    3256:	99                   	cwd
    3257:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    325b:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    325f:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3264:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    326a:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    3270:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3275:	8d be e2 fe          	lea    di,[bp-0x11e]
    3279:	16                   	push   ss
    327a:	57                   	push   di
    327b:	6a 02                	push   0x2
    327d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3281:	06                   	push   es
    3282:	57                   	push   di
    3283:	9a 95 28 f1 32       	call   0x32f1:0x2895
    3288:	08 c0                	or     al,al
    328a:	75 0a                	jne    0x3296
    328c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    328f:	06                   	push   es
    3290:	57                   	push   di
    3291:	9a b7 1c ff 32       	call   0x32ff:0x1cb7
    3296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3299:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    329e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    32a2:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    32a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32a9:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    32ae:	99                   	cwd
    32af:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    32b3:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    32b7:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    32bc:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    32c1:	99                   	cwd
    32c2:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    32c6:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    32ca:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    32cf:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    32d5:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    32db:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    32e0:	8d be e2 fe          	lea    di,[bp-0x11e]
    32e4:	16                   	push   ss
    32e5:	57                   	push   di
    32e6:	6a 02                	push   0x2
    32e8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    32ec:	06                   	push   es
    32ed:	57                   	push   di
    32ee:	9a 95 28 4b 33       	call   0x334b:0x2895
    32f3:	08 c0                	or     al,al
    32f5:	75 0a                	jne    0x3301
    32f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32fa:	06                   	push   es
    32fb:	57                   	push   di
    32fc:	9a b7 1c 59 33       	call   0x3359:0x1cb7
    3301:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3304:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3309:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    330d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3311:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3314:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    3319:	99                   	cwd
    331a:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    331e:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    3322:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3327:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    332c:	99                   	cwd
    332d:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3331:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    3335:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    333a:	8d be ea fe          	lea    di,[bp-0x116]
    333e:	16                   	push   ss
    333f:	57                   	push   di
    3340:	6a 01                	push   0x1
    3342:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3346:	06                   	push   es
    3347:	57                   	push   di
    3348:	9a 95 28 f1 37       	call   0x37f1:0x2895
    334d:	08 c0                	or     al,al
    334f:	75 0a                	jne    0x335b
    3351:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3354:	06                   	push   es
    3355:	57                   	push   di
    3356:	9a b7 1c 63 33       	call   0x3363:0x1cb7
    335b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    335e:	06                   	push   es
    335f:	57                   	push   di
    3360:	9a 5f 29 45 34       	call   0x3445:0x295f
    3365:	c9                   	leave
    3366:	ca 04 00             	retf   0x4
    3369:	55                   	push   bp
    336a:	89 e5                	mov    bp,sp
    336c:	31 c0                	xor    ax,ax
    336e:	9a 44 04 33 34       	call   0x3433:0x444
    3373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3376:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    337b:	06                   	push   es
    337c:	57                   	push   di
    337d:	9a d2 31 8f 33       	call   0x338f:0x31d2
    3382:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3385:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    338a:	06                   	push   es
    338b:	57                   	push   di
    338c:	9a d2 31 9e 33       	call   0x339e:0x31d2
    3391:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3394:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    3399:	06                   	push   es
    339a:	57                   	push   di
    339b:	9a d2 31 ad 33       	call   0x33ad:0x31d2
    33a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a3:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    33a8:	06                   	push   es
    33a9:	57                   	push   di
    33aa:	9a d2 31 bc 33       	call   0x33bc:0x31d2
    33af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33b2:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    33b7:	06                   	push   es
    33b8:	57                   	push   di
    33b9:	9a d2 31 cb 33       	call   0x33cb:0x31d2
    33be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c1:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    33c6:	06                   	push   es
    33c7:	57                   	push   di
    33c8:	9a d2 31 da 33       	call   0x33da:0x31d2
    33cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d0:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    33d5:	06                   	push   es
    33d6:	57                   	push   di
    33d7:	9a d2 31 e9 33       	call   0x33e9:0x31d2
    33dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33df:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    33e4:	06                   	push   es
    33e5:	57                   	push   di
    33e6:	9a d2 31 f8 33       	call   0x33f8:0x31d2
    33eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33ee:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    33f3:	06                   	push   es
    33f4:	57                   	push   di
    33f5:	9a d2 31 07 34       	call   0x3407:0x31d2
    33fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33fd:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3402:	06                   	push   es
    3403:	57                   	push   di
    3404:	9a d2 31 16 34       	call   0x3416:0x31d2
    3409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    340c:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    3411:	06                   	push   es
    3412:	57                   	push   di
    3413:	9a d2 31 25 34       	call   0x3425:0x31d2
    3418:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341b:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    3420:	06                   	push   es
    3421:	57                   	push   di
    3422:	9a d2 31 7d 3e       	call   0x3e7d:0x31d2
    3427:	c9                   	leave
    3428:	ca 04 00             	retf   0x4
    342b:	55                   	push   bp
    342c:	89 e5                	mov    bp,sp
    342e:	31 c0                	xor    ax,ax
    3430:	9a 44 04 53 34       	call   0x3453:0x444
    3435:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    343b:	26 89 85 2a 07       	mov    WORD PTR es:[di+0x72a],ax
    3440:	06                   	push   es
    3441:	57                   	push   di
    3442:	9a 97 2c 65 34       	call   0x3465:0x2c97
    3447:	c9                   	leave
    3448:	ca 06 00             	retf   0x6
    344b:	55                   	push   bp
    344c:	89 e5                	mov    bp,sp
    344e:	31 c0                	xor    ax,ax
    3450:	9a 44 04 84 34       	call   0x3484:0x444
    3455:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3458:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    345b:	26 89 85 2c 07       	mov    WORD PTR es:[di+0x72c],ax
    3460:	06                   	push   es
    3461:	57                   	push   di
    3462:	9a 97 2c 1f 39       	call   0x391f:0x2c97
    3467:	c9                   	leave
    3468:	ca 06 00             	retf   0x6
    346b:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    346e:	6d                   	ins    WORD PTR es:[di],dx
    346f:	73 74                	jae    0x34e5
    3471:	72 61                	jb     0x34d4
    3473:	74 20                	je     0x3495
    3475:	2d 20 03             	sub    ax,0x320
    3478:	20 2d                	and    BYTE PTR [di],ch
    347a:	20 55 89             	and    BYTE PTR [di-0x77],dl
    347d:	e5 b8                	in     ax,0xb8
    347f:	02 03                	add    al,BYTE PTR [bp+di]
    3481:	9a 44 04 98 34       	call   0x3498:0x444
    3486:	81 ec 02 03          	sub    sp,0x302
    348a:	8d be fe fe          	lea    di,[bp-0x102]
    348e:	16                   	push   ss
    348f:	57                   	push   di
    3490:	bf 6b 34             	mov    di,0x346b
    3493:	0e                   	push   cs
    3494:	57                   	push   di
    3495:	9a cd 17 a2 34       	call   0x34a2:0x17cd
    349a:	bf fa 1d             	mov    di,0x1dfa
    349d:	1e                   	push   ds
    349e:	57                   	push   di
    349f:	9a 4c 18 ac 34       	call   0x34ac:0x184c
    34a4:	bf 77 34             	mov    di,0x3477
    34a7:	0e                   	push   cs
    34a8:	57                   	push   di
    34a9:	9a 4c 18 c1 34       	call   0x34c1:0x184c
    34ae:	8d be fe fd          	lea    di,[bp-0x202]
    34b2:	16                   	push   ss
    34b3:	57                   	push   di
    34b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b7:	06                   	push   es
    34b8:	57                   	push   di
    34b9:	9a 53 1d e6 34       	call   0x34e6:0x1d53
    34be:	9a 4c 18 d2 34       	call   0x34d2:0x184c
    34c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c6:	81 c7 2e 07          	add    di,0x72e
    34ca:	06                   	push   es
    34cb:	57                   	push   di
    34cc:	68 ff 00             	push   0xff
    34cf:	9a e7 17 6c 35       	call   0x356c:0x17e7
    34d4:	bf fa 1d             	mov    di,0x1dfa
    34d7:	1e                   	push   ds
    34d8:	57                   	push   di
    34d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34dc:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    34e1:	06                   	push   es
    34e2:	57                   	push   di
    34e3:	9a 8c 1d 61 36       	call   0x3661:0x1d8c
    34e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34eb:	26 c7 85 28 07 64 00 	mov    WORD PTR es:[di+0x728],0x64
    34f2:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    34f7:	b0 00                	mov    al,0x0
    34f9:	7c 01                	jl     0x34fc
    34fb:	40                   	inc    ax
    34fc:	50                   	push   ax
    34fd:	26 c4 bd 6c 06       	les    di,DWORD PTR es:[di+0x66c]
    3502:	06                   	push   es
    3503:	57                   	push   di
    3504:	9a a5 13 21 35       	call   0x3521:0x13a5
    3509:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    350e:	b0 00                	mov    al,0x0
    3510:	7c 01                	jl     0x3513
    3512:	40                   	inc    ax
    3513:	50                   	push   ax
    3514:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3517:	26 c4 bd 68 06       	les    di,DWORD PTR es:[di+0x668]
    351c:	06                   	push   es
    351d:	57                   	push   di
    351e:	9a a5 13 3b 35       	call   0x353b:0x13a5
    3523:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    3528:	b0 00                	mov    al,0x0
    352a:	7c 01                	jl     0x352d
    352c:	40                   	inc    ax
    352d:	50                   	push   ax
    352e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3531:	26 c4 bd f8 06       	les    di,DWORD PTR es:[di+0x6f8]
    3536:	06                   	push   es
    3537:	57                   	push   di
    3538:	9a a5 13 62 35       	call   0x3562:0x13a5
    353d:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    3543:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    3549:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    354f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3552:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    3557:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    355a:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    355d:	06                   	push   es
    355e:	57                   	push   di
    355f:	9a 26 13 96 35       	call   0x3596:0x1326
    3564:	2d 01 00             	sub    ax,0x1
    3567:	71 05                	jno    0x356e
    3569:	9a 3e 04 ce 35       	call   0x35ce:0x43e
    356e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3571:	31 c0                	xor    ax,ax
    3573:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3576:	7f 33                	jg     0x35ab
    3578:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    357b:	eb 03                	jmp    0x3580
    357d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3580:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3583:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    3587:	7c 1a                	jl     0x35a3
    3589:	6a 00                	push   0x0
    358b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    358e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3591:	06                   	push   es
    3592:	57                   	push   di
    3593:	9a 53 13 a1 35       	call   0x35a1:0x1353
    3598:	89 c7                	mov    di,ax
    359a:	8e c2                	mov    es,dx
    359c:	06                   	push   es
    359d:	57                   	push   di
    359e:	9a a5 13 f0 35       	call   0x35f0:0x13a5
    35a3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    35a6:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    35a9:	75 d2                	jne    0x357d
    35ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ae:	26 c4 bd a0 06       	les    di,DWORD PTR es:[di+0x6a0]
    35b3:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    35b6:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    35b9:	31 c0                	xor    ax,ax
    35bb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    35be:	eb 03                	jmp    0x35c3
    35c0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    35c3:	a1 4c 01             	mov    ax,ds:0x14c
    35c6:	2d 01 00             	sub    ax,0x1
    35c9:	71 05                	jno    0x35d0
    35cb:	9a 3e 04 dd 35       	call   0x35dd:0x43e
    35d0:	8b d0                	mov    dx,ax
    35d2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    35d5:	05 01 00             	add    ax,0x1
    35d8:	71 05                	jno    0x35df
    35da:	9a 3e 04 37 36       	call   0x3637:0x43e
    35df:	3b c2                	cmp    ax,dx
    35e1:	7e 1a                	jle    0x35fd
    35e3:	6a 00                	push   0x0
    35e5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    35e8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    35eb:	06                   	push   es
    35ec:	57                   	push   di
    35ed:	9a 53 13 fb 35       	call   0x35fb:0x1353
    35f2:	89 c7                	mov    di,ax
    35f4:	8e c2                	mov    es,dx
    35f6:	06                   	push   es
    35f7:	57                   	push   di
    35f8:	9a a5 13 73 39       	call   0x3973:0x13a5
    35fd:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    3601:	75 bd                	jne    0x35c0
    3603:	6a 00                	push   0x0
    3605:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3608:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    360d:	06                   	push   es
    360e:	57                   	push   di
    360f:	9a d0 1c 23 36       	call   0x3623:0x1cd0
    3614:	6a 00                	push   0x0
    3616:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3619:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    361e:	06                   	push   es
    361f:	57                   	push   di
    3620:	9a d0 1c 07 39       	call   0x3907:0x1cd0
    3625:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3628:	06                   	push   es
    3629:	57                   	push   di
    362a:	9a 7d 52 59 36       	call   0x3659:0x527d
    362f:	2d 01 00             	sub    ax,0x1
    3632:	71 05                	jno    0x3639
    3634:	9a 3e 04 68 36       	call   0x3668:0x43e
    3639:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    363c:	31 c0                	xor    ax,ax
    363e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3641:	7e 03                	jle    0x3646
    3643:	e9 a7 00             	jmp    0x36ed
    3646:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3649:	eb 03                	jmp    0x364e
    364b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    364e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3651:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3654:	06                   	push   es
    3655:	57                   	push   di
    3656:	9a 46 52 79 36       	call   0x3679:0x5246
    365b:	52                   	push   dx
    365c:	50                   	push   ax
    365d:	bf 99 03             	mov    di,0x399
    3660:	b8 81 36             	mov    ax,0x3681
    3663:	50                   	push   ax
    3664:	57                   	push   di
    3665:	9a 55 22 88 36       	call   0x3688:0x2255
    366a:	08 c0                	or     al,al
    366c:	74 74                	je     0x36e2
    366e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3674:	06                   	push   es
    3675:	57                   	push   di
    3676:	9a 46 52 62 3c       	call   0x3c62:0x5246
    367b:	52                   	push   dx
    367c:	50                   	push   ax
    367d:	bf 99 03             	mov    di,0x399
    3680:	b8 e0 36             	mov    ax,0x36e0
    3683:	50                   	push   ax
    3684:	57                   	push   di
    3685:	9a 73 22 c5 36       	call   0x36c5:0x2273
    368a:	89 c7                	mov    di,ax
    368c:	8e c2                	mov    es,dx
    368e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3691:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3694:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3699:	74 47                	je     0x36e2
    369b:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    369f:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    36a3:	74 3d                	je     0x36e2
    36a5:	a1 06 1e             	mov    ax,ds:0x1e06
    36a8:	99                   	cwd
    36a9:	8b c8                	mov    cx,ax
    36ab:	8b da                	mov    bx,dx
    36ad:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    36b1:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    36b5:	09 d2                	or     dx,dx
    36b7:	79 07                	jns    0x36c0
    36b9:	f7 d2                	not    dx
    36bb:	f7 d8                	neg    ax
    36bd:	83 da ff             	sbb    dx,0xffff
    36c0:	71 05                	jno    0x36c7
    36c2:	9a 3e 04 7a 37       	call   0x377a:0x43e
    36c7:	3b d3                	cmp    dx,bx
    36c9:	7c 0a                	jl     0x36d5
    36cb:	7f 04                	jg     0x36d1
    36cd:	3b c1                	cmp    ax,cx
    36cf:	76 04                	jbe    0x36d5
    36d1:	b0 00                	mov    al,0x0
    36d3:	eb 02                	jmp    0x36d7
    36d5:	b0 01                	mov    al,0x1
    36d7:	50                   	push   ax
    36d8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36db:	06                   	push   es
    36dc:	57                   	push   di
    36dd:	9a 77 1c 01 37       	call   0x3701:0x1c77
    36e2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36e5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    36e8:	74 03                	je     0x36ed
    36ea:	e9 5e ff             	jmp    0x364b
    36ed:	8d be fe fe          	lea    di,[bp-0x102]
    36f1:	16                   	push   ss
    36f2:	57                   	push   di
    36f3:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    36f7:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    36fc:	06                   	push   es
    36fd:	57                   	push   di
    36fe:	9a 53 1d 10 37       	call   0x3710:0x1d53
    3703:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3706:	26 c4 bd d8 05       	les    di,DWORD PTR es:[di+0x5d8]
    370b:	06                   	push   es
    370c:	57                   	push   di
    370d:	9a 8c 1d 26 37       	call   0x3726:0x1d8c
    3712:	8d be fe fe          	lea    di,[bp-0x102]
    3716:	16                   	push   ss
    3717:	57                   	push   di
    3718:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    371c:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    3721:	06                   	push   es
    3722:	57                   	push   di
    3723:	9a 53 1d 35 37       	call   0x3735:0x1d53
    3728:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    372b:	26 c4 bd dc 05       	les    di,DWORD PTR es:[di+0x5dc]
    3730:	06                   	push   es
    3731:	57                   	push   di
    3732:	9a 8c 1d 4b 37       	call   0x374b:0x1d8c
    3737:	8d be fe fe          	lea    di,[bp-0x102]
    373b:	16                   	push   ss
    373c:	57                   	push   di
    373d:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3741:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    3746:	06                   	push   es
    3747:	57                   	push   di
    3748:	9a 53 1d 5a 37       	call   0x375a:0x1d53
    374d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3750:	26 c4 bd e0 05       	les    di,DWORD PTR es:[di+0x5e0]
    3755:	06                   	push   es
    3756:	57                   	push   di
    3757:	9a 8c 1d 70 37       	call   0x3770:0x1d8c
    375c:	8d be fe fe          	lea    di,[bp-0x102]
    3760:	16                   	push   ss
    3761:	57                   	push   di
    3762:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3766:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    376b:	06                   	push   es
    376c:	57                   	push   di
    376d:	9a 53 1d dd 37       	call   0x37dd:0x1d53
    3772:	bf 77 34             	mov    di,0x3477
    3775:	0e                   	push   cs
    3776:	57                   	push   di
    3777:	9a 4c 18 9a 37       	call   0x379a:0x184c
    377c:	8d be fe fd          	lea    di,[bp-0x202]
    3780:	16                   	push   ss
    3781:	57                   	push   di
    3782:	9a fe 15 95 37       	call   0x3795:0x15fe
    3787:	83 ec 08             	sub    sp,0x8
    378a:	89 e3                	mov    bx,sp
    378c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3790:	90                   	nop
    3791:	9b                   	fwait
    3792:	9a bf 1c af 37       	call   0x37af:0x1cbf
    3797:	9a 4c 18 a4 37       	call   0x37a4:0x184c
    379c:	bf 77 34             	mov    di,0x3477
    379f:	0e                   	push   cs
    37a0:	57                   	push   di
    37a1:	9a 4c 18 c4 37       	call   0x37c4:0x184c
    37a6:	8d be fe fc          	lea    di,[bp-0x302]
    37aa:	16                   	push   ss
    37ab:	57                   	push   di
    37ac:	9a fe 15 bf 37       	call   0x37bf:0x15fe
    37b1:	83 ec 08             	sub    sp,0x8
    37b4:	89 e3                	mov    bx,sp
    37b6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    37ba:	90                   	nop
    37bb:	9b                   	fwait
    37bc:	9a e4 1c 74 3c       	call   0x3c74:0x1ce4
    37c1:	9a 4c 18 ce 37       	call   0x37ce:0x184c
    37c6:	bf 77 34             	mov    di,0x3477
    37c9:	0e                   	push   cs
    37ca:	57                   	push   di
    37cb:	9a 4c 18 e4 38       	call   0x38e4:0x184c
    37d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d3:	26 c4 bd e4 05       	les    di,DWORD PTR es:[di+0x5e4]
    37d8:	06                   	push   es
    37d9:	57                   	push   di
    37da:	9a 8c 1d 5c 3a       	call   0x3a5c:0x1d8c
    37df:	bf 32 1e             	mov    di,0x1e32
    37e2:	1e                   	push   ds
    37e3:	57                   	push   di
    37e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37e7:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    37ec:	06                   	push   es
    37ed:	57                   	push   di
    37ee:	9a 17 30 05 38       	call   0x3805:0x3017
    37f3:	bf 40 1e             	mov    di,0x1e40
    37f6:	1e                   	push   ds
    37f7:	57                   	push   di
    37f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37fb:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3800:	06                   	push   es
    3801:	57                   	push   di
    3802:	9a 17 30 19 38       	call   0x3819:0x3017
    3807:	bf 40 1e             	mov    di,0x1e40
    380a:	1e                   	push   ds
    380b:	57                   	push   di
    380c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    380f:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    3814:	06                   	push   es
    3815:	57                   	push   di
    3816:	9a 17 30 2d 38       	call   0x382d:0x3017
    381b:	bf 78 1e             	mov    di,0x1e78
    381e:	1e                   	push   ds
    381f:	57                   	push   di
    3820:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3823:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    3828:	06                   	push   es
    3829:	57                   	push   di
    382a:	9a 17 30 41 38       	call   0x3841:0x3017
    382f:	bf 86 1e             	mov    di,0x1e86
    3832:	1e                   	push   ds
    3833:	57                   	push   di
    3834:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3837:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    383c:	06                   	push   es
    383d:	57                   	push   di
    383e:	9a 17 30 55 38       	call   0x3855:0x3017
    3843:	bf 86 1e             	mov    di,0x1e86
    3846:	1e                   	push   ds
    3847:	57                   	push   di
    3848:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    384b:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    3850:	06                   	push   es
    3851:	57                   	push   di
    3852:	9a 17 30 69 38       	call   0x3869:0x3017
    3857:	bf 4e 1e             	mov    di,0x1e4e
    385a:	1e                   	push   ds
    385b:	57                   	push   di
    385c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    385f:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3864:	06                   	push   es
    3865:	57                   	push   di
    3866:	9a 17 30 7d 38       	call   0x387d:0x3017
    386b:	bf 5c 1e             	mov    di,0x1e5c
    386e:	1e                   	push   ds
    386f:	57                   	push   di
    3870:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3873:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    3878:	06                   	push   es
    3879:	57                   	push   di
    387a:	9a 17 30 91 38       	call   0x3891:0x3017
    387f:	bf 5c 1e             	mov    di,0x1e5c
    3882:	1e                   	push   ds
    3883:	57                   	push   di
    3884:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3887:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    388c:	06                   	push   es
    388d:	57                   	push   di
    388e:	9a 17 30 a5 38       	call   0x38a5:0x3017
    3893:	bf 78 1e             	mov    di,0x1e78
    3896:	1e                   	push   ds
    3897:	57                   	push   di
    3898:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    389b:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    38a0:	06                   	push   es
    38a1:	57                   	push   di
    38a2:	9a 17 30 b9 38       	call   0x38b9:0x3017
    38a7:	bf 86 1e             	mov    di,0x1e86
    38aa:	1e                   	push   ds
    38ab:	57                   	push   di
    38ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38af:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    38b4:	06                   	push   es
    38b5:	57                   	push   di
    38b6:	9a 17 30 cd 38       	call   0x38cd:0x3017
    38bb:	bf 86 1e             	mov    di,0x1e86
    38be:	1e                   	push   ds
    38bf:	57                   	push   di
    38c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38c3:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    38c8:	06                   	push   es
    38c9:	57                   	push   di
    38ca:	9a 17 30 5d 3e       	call   0x3e5d:0x3017
    38cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38d2:	26 c7 85 2c 07 01 00 	mov    WORD PTR es:[di+0x72c],0x1
    38d9:	a1 4c 01             	mov    ax,ds:0x14c
    38dc:	2d 01 00             	sub    ax,0x1
    38df:	71 05                	jno    0x38e6
    38e1:	9a 3e 04 fa 38       	call   0x38fa:0x43e
    38e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38e9:	26 89 85 2a 07       	mov    WORD PTR es:[di+0x72a],ax
    38ee:	c9                   	leave
    38ef:	ca 08 00             	retf   0x8
    38f2:	55                   	push   bp
    38f3:	89 e5                	mov    bp,sp
    38f5:	31 c0                	xor    ax,ax
    38f7:	9a 44 04 15 39       	call   0x3915:0x444
    38fc:	6a fe                	push   0xfffe
    38fe:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    3902:	06                   	push   es
    3903:	57                   	push   di
    3904:	9a a9 63 3e 39       	call   0x393e:0x63a9
    3909:	c9                   	leave
    390a:	ca 08 00             	retf   0x8
    390d:	55                   	push   bp
    390e:	89 e5                	mov    bp,sp
    3910:	31 c0                	xor    ax,ax
    3912:	9a 44 04 34 39       	call   0x3934:0x444
    3917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    391a:	06                   	push   es
    391b:	57                   	push   di
    391c:	9a 69 33 07 3b       	call   0x3b07:0x3369
    3921:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3924:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    3928:	c9                   	leave
    3929:	ca 0c 00             	retf   0xc
    392c:	55                   	push   bp
    392d:	89 e5                	mov    bp,sp
    392f:	31 c0                	xor    ax,ax
    3931:	9a 44 04 59 39       	call   0x3959:0x444
    3936:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3939:	06                   	push   es
    393a:	57                   	push   di
    393b:	9a 56 55 89 3a       	call   0x3a89:0x5556
    3940:	c9                   	leave
    3941:	ca 08 00             	retf   0x8
    3944:	bb 39 c2             	mov    bx,0xc239
    3947:	39 c9                	cmp    cx,cx
    3949:	39 d0                	cmp    ax,dx
    394b:	39 d7                	cmp    di,dx
    394d:	39 de                	cmp    si,bx
    394f:	39 55 89             	cmp    WORD PTR [di-0x77],dx
    3952:	e5 b8                	in     ax,0xb8
    3954:	0e                   	push   cs
    3955:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    3959:	7a 39                	jp     0x3994
    395b:	83 ec 0e             	sub    sp,0xe
    395e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3961:	26 8b 85 28 07       	mov    ax,WORD PTR es:[di+0x728]
    3966:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3969:	ff 76 0c             	push   WORD PTR [bp+0xc]
    396c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    396f:	bf 94 00             	mov    di,0x94
    3972:	b8 8d 39             	mov    ax,0x398d
    3975:	50                   	push   ax
    3976:	57                   	push   di
    3977:	9a 55 22 94 39       	call   0x3994:0x2255
    397c:	08 c0                	or     al,al
    397e:	75 03                	jne    0x3983
    3980:	e9 bf 00             	jmp    0x3a42
    3983:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3986:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3989:	bf 94 00             	mov    di,0x94
    398c:	b8 a5 39             	mov    ax,0x39a5
    398f:	50                   	push   ax
    3990:	57                   	push   di
    3991:	9a 73 22 02 3a       	call   0x3a02:0x2273
    3996:	52                   	push   dx
    3997:	50                   	push   ax
    3998:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    399b:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    39a0:	06                   	push   es
    39a1:	57                   	push   di
    39a2:	9a 2b 16 f8 39       	call   0x39f8:0x162b
    39a7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    39aa:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    39ad:	3d 05 00             	cmp    ax,0x5
    39b0:	77 33                	ja     0x39e5
    39b2:	89 c3                	mov    bx,ax
    39b4:	d1 e3                	shl    bx,1
    39b6:	2e ff a7 44 39       	jmp    WORD PTR cs:[bx+0x3944]
    39bb:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    39c0:	eb 23                	jmp    0x39e5
    39c2:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    39c7:	eb 1c                	jmp    0x39e5
    39c9:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    39ce:	eb 15                	jmp    0x39e5
    39d0:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    39d5:	eb 0e                	jmp    0x39e5
    39d7:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    39dc:	eb 07                	jmp    0x39e5
    39de:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    39e3:	eb 00                	jmp    0x39e5
    39e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39e8:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    39ed:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    39f0:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    39f3:	06                   	push   es
    39f4:	57                   	push   di
    39f5:	9a 26 13 2d 3a       	call   0x3a2d:0x1326
    39fa:	2d 01 00             	sub    ax,0x1
    39fd:	71 05                	jno    0x3a04
    39ff:	9a 3e 04 75 3a       	call   0x3a75:0x43e
    3a04:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3a07:	31 c0                	xor    ax,ax
    3a09:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    3a0c:	7f 34                	jg     0x3a42
    3a0e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3a11:	eb 03                	jmp    0x3a16
    3a13:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    3a16:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3a19:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3a1c:	b0 00                	mov    al,0x0
    3a1e:	75 01                	jne    0x3a21
    3a20:	40                   	inc    ax
    3a21:	50                   	push   ax
    3a22:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3a25:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a28:	06                   	push   es
    3a29:	57                   	push   di
    3a2a:	9a 53 13 38 3a       	call   0x3a38:0x1353
    3a2f:	89 c7                	mov    di,ax
    3a31:	8e c2                	mov    es,dx
    3a33:	06                   	push   es
    3a34:	57                   	push   di
    3a35:	9a 75 12 c0 3a       	call   0x3ac0:0x1275
    3a3a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3a3d:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    3a40:	75 d1                	jne    0x3a13
    3a42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a48:	26 3b 85 28 07       	cmp    ax,WORD PTR es:[di+0x728]
    3a4d:	74 1a                	je     0x3a69
    3a4f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3a52:	26 ff b5 28 07       	push   WORD PTR es:[di+0x728]
    3a57:	06                   	push   es
    3a58:	57                   	push   di
    3a59:	9a f4 5d 40 56       	call   0x5640:0x5df4
    3a5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a64:	26 89 85 28 07       	mov    WORD PTR es:[di+0x728],ax
    3a69:	c9                   	leave
    3a6a:	ca 08 00             	retf   0x8
    3a6d:	55                   	push   bp
    3a6e:	89 e5                	mov    bp,sp
    3a70:	31 c0                	xor    ax,ax
    3a72:	9a 44 04 a5 3a       	call   0x3aa5:0x444
    3a77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a7a:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3a80:	75 0b                	jne    0x3a8d
    3a82:	6a 00                	push   0x0
    3a84:	06                   	push   es
    3a85:	57                   	push   di
    3a86:	9a 14 3a 97 3a       	call   0x3a97:0x3a14
    3a8b:	eb 0c                	jmp    0x3a99
    3a8d:	6a 02                	push   0x2
    3a8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a92:	06                   	push   es
    3a93:	57                   	push   di
    3a94:	9a 14 3a e4 55       	call   0x55e4:0x3a14
    3a99:	c9                   	leave
    3a9a:	ca 08 00             	retf   0x8
    3a9d:	55                   	push   bp
    3a9e:	89 e5                	mov    bp,sp
    3aa0:	31 c0                	xor    ax,ax
    3aa2:	9a 44 04 cf 3a       	call   0x3acf:0x444
    3aa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aaa:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3ab0:	b0 00                	mov    al,0x0
    3ab2:	75 01                	jne    0x3ab5
    3ab4:	40                   	inc    ax
    3ab5:	50                   	push   ax
    3ab6:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    3abb:	06                   	push   es
    3abc:	57                   	push   di
    3abd:	9a 75 12 25 3b       	call   0x3b25:0x1275
    3ac2:	c9                   	leave
    3ac3:	ca 08 00             	retf   0x8
    3ac6:	55                   	push   bp
    3ac7:	89 e5                	mov    bp,sp
    3ac9:	b8 02 00             	mov    ax,0x2
    3acc:	9a 44 04 df 3a       	call   0x3adf:0x444
    3ad1:	83 ec 02             	sub    sp,0x2
    3ad4:	a1 4c 01             	mov    ax,ds:0x14c
    3ad7:	2d 01 00             	sub    ax,0x1
    3ada:	71 05                	jno    0x3ae1
    3adc:	9a 3e 04 16 3b       	call   0x3b16:0x43e
    3ae1:	50                   	push   ax
    3ae2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ae5:	26 ff b5 2a 07       	push   WORD PTR es:[di+0x72a]
    3aea:	9a 32 3e e3 3b       	call   0x3be3:0x3e32
    3aef:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3af2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3af5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3af8:	26 3b 85 2a 07       	cmp    ax,WORD PTR es:[di+0x72a]
    3afd:	74 0a                	je     0x3b09
    3aff:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3b02:	06                   	push   es
    3b03:	57                   	push   di
    3b04:	9a 2b 34 fd 3b       	call   0x3bfd:0x342b
    3b09:	c9                   	leave
    3b0a:	ca 08 00             	retf   0x8
    3b0d:	55                   	push   bp
    3b0e:	89 e5                	mov    bp,sp
    3b10:	b8 08 00             	mov    ax,0x8
    3b13:	9a 44 04 2c 3b       	call   0x3b2c:0x444
    3b18:	83 ec 08             	sub    sp,0x8
    3b1b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b1e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b21:	bf 94 00             	mov    di,0x94
    3b24:	b8 3f 3b             	mov    ax,0x3b3f
    3b27:	50                   	push   ax
    3b28:	57                   	push   di
    3b29:	9a 55 22 46 3b       	call   0x3b46:0x2255
    3b2e:	08 c0                	or     al,al
    3b30:	75 03                	jne    0x3b35
    3b32:	e9 ca 00             	jmp    0x3bff
    3b35:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b38:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b3b:	bf 94 00             	mov    di,0x94
    3b3e:	b8 61 3b             	mov    ax,0x3b61
    3b41:	50                   	push   ax
    3b42:	57                   	push   di
    3b43:	9a 73 22 68 3b       	call   0x3b68:0x2273
    3b48:	89 c7                	mov    di,ax
    3b4a:	8e c2                	mov    es,dx
    3b4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b4f:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    3b54:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3b57:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b5a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b5d:	bf 94 00             	mov    di,0x94
    3b60:	b8 79 3b             	mov    ax,0x3b79
    3b63:	50                   	push   ax
    3b64:	57                   	push   di
    3b65:	9a 73 22 89 3b       	call   0x3b89:0x2273
    3b6a:	52                   	push   dx
    3b6b:	50                   	push   ax
    3b6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b6f:	26 c4 bd a0 06       	les    di,DWORD PTR es:[di+0x6a0]
    3b74:	06                   	push   es
    3b75:	57                   	push   di
    3b76:	9a 2b 16 24 3c       	call   0x3c24:0x162b
    3b7b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3b7e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3b81:	05 01 00             	add    ax,0x1
    3b84:	71 05                	jno    0x3b8b
    3b86:	9a 3e 04 bd 3b       	call   0x3bbd:0x43e
    3b8b:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    3b8f:	b0 00                	mov    al,0x0
    3b91:	7d 01                	jge    0x3b94
    3b93:	40                   	inc    ax
    3b94:	8a c8                	mov    cl,al
    3b96:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3b9a:	b0 00                	mov    al,0x0
    3b9c:	7d 01                	jge    0x3b9f
    3b9e:	40                   	inc    ax
    3b9f:	8a d0                	mov    dl,al
    3ba1:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3ba5:	b0 00                	mov    al,0x0
    3ba7:	7c 01                	jl     0x3baa
    3ba9:	40                   	inc    ax
    3baa:	22 c2                	and    al,dl
    3bac:	22 c1                	and    al,cl
    3bae:	08 c0                	or     al,al
    3bb0:	74 12                	je     0x3bc4
    3bb2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3bb5:	05 01 00             	add    ax,0x1
    3bb8:	71 05                	jno    0x3bbf
    3bba:	9a 3e 04 d5 3b       	call   0x3bd5:0x43e
    3bbf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3bc2:	eb 24                	jmp    0x3be8
    3bc4:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3bc8:	75 1e                	jne    0x3be8
    3bca:	a1 4c 01             	mov    ax,ds:0x14c
    3bcd:	2d 01 00             	sub    ax,0x1
    3bd0:	71 05                	jno    0x3bd7
    3bd2:	9a 3e 04 14 3c       	call   0x3c14:0x43e
    3bd7:	50                   	push   ax
    3bd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bdb:	26 ff b5 2a 07       	push   WORD PTR es:[di+0x72a]
    3be0:	9a 32 3e ff ff       	call   0xffff:0x3e32
    3be5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3be8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3beb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bee:	26 3b 85 2a 07       	cmp    ax,WORD PTR es:[di+0x72a]
    3bf3:	74 0a                	je     0x3bff
    3bf5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3bf8:	06                   	push   es
    3bf9:	57                   	push   di
    3bfa:	9a 2b 34 a9 3c       	call   0x3ca9:0x342b
    3bff:	c9                   	leave
    3c00:	ca 08 00             	retf   0x8
    3c03:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    3c07:	ff                   	(bad)
    3c08:	7f 00                	jg     0x3c0a
    3c0a:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3c0d:	e5 b8                	in     ax,0xb8
    3c0f:	06                   	push   es
    3c10:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    3c14:	2b 3c                	sub    di,WORD PTR [si]
    3c16:	81 ec 06 02          	sub    sp,0x206
    3c1a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c1d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c20:	bf 94 00             	mov    di,0x94
    3c23:	b8 3b 3c             	mov    ax,0x3c3b
    3c26:	50                   	push   ax
    3c27:	57                   	push   di
    3c28:	9a 55 22 42 3c       	call   0x3c42:0x2255
    3c2d:	08 c0                	or     al,al
    3c2f:	74 7a                	je     0x3cab
    3c31:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c34:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c37:	bf 94 00             	mov    di,0x94
    3c3a:	b8 ff ff             	mov    ax,0xffff
    3c3d:	50                   	push   ax
    3c3e:	57                   	push   di
    3c3f:	9a 73 22 6f 3c       	call   0x3c6f:0x2273
    3c44:	89 c7                	mov    di,ax
    3c46:	8e c2                	mov    es,dx
    3c48:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3c4b:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3c4e:	8d be fa fd          	lea    di,[bp-0x206]
    3c52:	16                   	push   ss
    3c53:	57                   	push   di
    3c54:	8d be fa fe          	lea    di,[bp-0x106]
    3c58:	16                   	push   ss
    3c59:	57                   	push   di
    3c5a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c5d:	06                   	push   es
    3c5e:	57                   	push   di
    3c5f:	9a 2a 51 ff ff       	call   0xffff:0x512a
    3c64:	83 c4 04             	add    sp,0x4
    3c67:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    3c6b:	50                   	push   ax
    3c6c:	9a e9 18 7c 3c       	call   0x3c7c:0x18e9
    3c71:	9a da 08 ff ff       	call   0xffff:0x8da
    3c76:	bf 03 3c             	mov    di,0x3c03
    3c79:	9a 16 04 b7 3c       	call   0x3cb7:0x416
    3c7e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c81:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3c84:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    3c88:	b0 00                	mov    al,0x0
    3c8a:	7f 01                	jg     0x3c8d
    3c8c:	40                   	inc    ax
    3c8d:	8a d0                	mov    dl,al
    3c8f:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3c93:	b0 00                	mov    al,0x0
    3c95:	7e 01                	jle    0x3c98
    3c97:	40                   	inc    ax
    3c98:	22 c2                	and    al,dl
    3c9a:	08 c0                	or     al,al
    3c9c:	74 0d                	je     0x3cab
    3c9e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3ca1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca4:	06                   	push   es
    3ca5:	57                   	push   di
    3ca6:	9a 4b 34 1c 59       	call   0x591c:0x344b
    3cab:	c9                   	leave
    3cac:	ca 08 00             	retf   0x8
    3caf:	55                   	push   bp
    3cb0:	89 e5                	mov    bp,sp
    3cb2:	31 c0                	xor    ax,ax
    3cb4:	9a 44 04 4e 3e       	call   0x3e4e:0x444
    3cb9:	6a 00                	push   0x0
    3cbb:	9a ff ff 00 00       	call   0x0:0xffff
    3cc0:	c9                   	leave
    3cc1:	ca 08 00             	retf   0x8
    3cc4:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    3cc7:	6f                   	outs   dx,WORD PTR ds:[si]
    3cc8:	64 75 69             	fs jne 0x3d34
    3ccb:	74 4e                	je     0x3d1b
    3ccd:	6f                   	outs   dx,WORD PTR ds:[si]
    3cce:	00 00                	add    BYTE PTR [bx+si],al
    3cd0:	00 00                	add    BYTE PTR [bx+si],al
    3cd2:	06                   	push   es
    3cd3:	56                   	push   si
    3cd4:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3cd6:	74 65                	je     0x3d3d
    3cd8:	73 04                	jae    0x3cde
    3cda:	50                   	push   ax
    3cdb:	72 69                	jb     0x3d46
    3cdd:	78 10                	js     0x3cef
    3cdf:	50                   	push   ax
    3ce0:	72 6f                	jb     0x3d51
    3ce2:	64 75 63             	fs jne 0x3d48
    3ce5:	74 69                	je     0x3d50
    3ce7:	6f                   	outs   dx,WORD PTR ds:[si]
    3ce8:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ce9:	56                   	push   si
    3cea:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3cec:	64 75 65             	fs jne 0x3d54
    3cef:	10 56 65             	adc    BYTE PTR [bp+0x65],dl
    3cf2:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cf3:	74 65                	je     0x3d5a
    3cf5:	73 53                	jae    0x3d4a
    3cf7:	6f                   	outs   dx,WORD PTR ds:[si]
    3cf8:	6c                   	ins    BYTE PTR es:[di],dx
    3cf9:	64 65 65 73 51       	fs gs gs jae 0x3d4f
    3cfe:	74 65                	je     0x3d65
    3d00:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    3d03:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d04:	74 65                	je     0x3d6b
    3d06:	73 53                	jae    0x3d5b
    3d08:	6f                   	outs   dx,WORD PTR ds:[si]
    3d09:	6c                   	ins    BYTE PTR es:[di],dx
    3d0a:	64 65 65 73 50       	fs gs gs jae 0x3d5f
    3d0f:	72 69                	jb     0x3d7a
    3d11:	78 10                	js     0x3d23
    3d13:	50                   	push   ax
    3d14:	72 6f                	jb     0x3d85
    3d16:	64 75 63             	fs jne 0x3d7c
    3d19:	74 69                	je     0x3d84
    3d1b:	6f                   	outs   dx,WORD PTR ds:[si]
    3d1c:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d1d:	53                   	push   bx
    3d1e:	6f                   	outs   dx,WORD PTR ds:[si]
    3d1f:	6c                   	ins    BYTE PTR es:[di],dx
    3d20:	64 65 65 0c 56       	fs gs gs or al,0x56
    3d25:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3d27:	74 65                	je     0x3d8e
    3d29:	73 53                	jae    0x3d7e
    3d2b:	70 65                	jo     0x3d92
    3d2d:	51                   	push   cx
    3d2e:	74 65                	je     0x3d95
    3d30:	0d 56 65             	or     ax,0x6556
    3d33:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d34:	74 65                	je     0x3d9b
    3d36:	73 53                	jae    0x3d8b
    3d38:	70 65                	jo     0x3d9f
    3d3a:	50                   	push   ax
    3d3b:	72 69                	jb     0x3da6
    3d3d:	78 12                	js     0x3d51
    3d3f:	50                   	push   ax
    3d40:	72 6f                	jb     0x3db1
    3d42:	64 75 63             	fs jne 0x3da8
    3d45:	74 69                	je     0x3db0
    3d47:	6f                   	outs   dx,WORD PTR ds:[si]
    3d48:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d49:	53                   	push   bx
    3d4a:	70 65                	jo     0x3db1
    3d4c:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    3d4f:	6c                   	ins    BYTE PTR es:[di],dx
    3d50:	65 0b 56 61          	or     dx,WORD PTR gs:[bp+0x61]
    3d54:	6c                   	ins    BYTE PTR es:[di],dx
    3d55:	65 75 72             	gs jne 0x3dca
    3d58:	53                   	push   bx
    3d59:	74 6f                	je     0x3dca
    3d5b:	63 6b 11             	arpl   WORD PTR [bp+di+0x11],bp
    3d5e:	50                   	push   ax
    3d5f:	72 6f                	jb     0x3dd0
    3d61:	64 75 63             	fs jne 0x3dc7
    3d64:	74 69                	je     0x3dcf
    3d66:	6f                   	outs   dx,WORD PTR ds:[si]
    3d67:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d68:	53                   	push   bx
    3d69:	74 6f                	je     0x3dda
    3d6b:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
    3d6e:	65 10 50 72          	adc    BYTE PTR gs:[bx+si+0x72],dl
    3d72:	6f                   	outs   dx,WORD PTR ds:[si]
    3d73:	64 75 63             	fs jne 0x3dd9
    3d76:	74 69                	je     0x3de1
    3d78:	6f                   	outs   dx,WORD PTR ds:[si]
    3d79:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d7a:	56                   	push   si
    3d7b:	61                   	popa
    3d7c:	6c                   	ins    BYTE PTR es:[di],dx
    3d7d:	65 75 72             	gs jne 0x3df2
    3d80:	0e                   	push   cs
    3d81:	50                   	push   ax
    3d82:	75 62                	jne    0x3de6
    3d84:	45                   	inc    bp
    3d85:	74 41                	je     0x3dc8
    3d87:	63 74 69             	arpl   WORD PTR [si+0x69],si
    3d8a:	6f                   	outs   dx,WORD PTR ds:[si]
    3d8b:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d8c:	43                   	inc    bx
    3d8d:	6f                   	outs   dx,WORD PTR ds:[si]
    3d8e:	6d                   	ins    WORD PTR es:[di],dx
    3d8f:	09 50 75             	or     WORD PTR [bx+si+0x75],dx
    3d92:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    3d95:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    3d98:	65 11 41 63          	adc    WORD PTR gs:[bx+di+0x63],ax
    3d9c:	74 69                	je     0x3e07
    3d9e:	6f                   	outs   dx,WORD PTR ds:[si]
    3d9f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3da0:	43                   	inc    bx
    3da1:	6f                   	outs   dx,WORD PTR ds:[si]
    3da2:	6d                   	ins    WORD PTR es:[di],dx
    3da3:	6d                   	ins    WORD PTR es:[di],dx
    3da4:	65 72 63             	gs jb  0x3e0a
    3da7:	69 61 6c 65 13       	imul   sp,WORD PTR [bx+di+0x6c],0x1365
    3dac:	43                   	inc    bx
    3dad:	6f                   	outs   dx,WORD PTR ds:[si]
    3dae:	6e                   	outs   dx,BYTE PTR ds:[si]
    3daf:	73 6f                	jae    0x3e20
    3db1:	6d                   	ins    WORD PTR es:[di],dx
    3db2:	6d                   	ins    WORD PTR es:[di],dx
    3db3:	61                   	popa
    3db4:	74 69                	je     0x3e1f
    3db6:	6f                   	outs   dx,WORD PTR ds:[si]
    3db7:	6e                   	outs   dx,BYTE PTR ds:[si]
    3db8:	4d                   	dec    bp
    3db9:	61                   	popa
    3dba:	74 69                	je     0x3e25
    3dbc:	65 72 65             	gs jb  0x3e24
    3dbf:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    3dc2:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    3dc7:	76 72                	jbe    0x3e3b
    3dc9:	65 44                	gs inc sp
    3dcb:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    3dd0:	65 0f 44 65 70       	cmove  sp,WORD PTR gs:[di+0x70]
    3dd5:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3dd7:	73 65                	jae    0x3e3e
    3dd9:	73 51                	jae    0x3e2c
    3ddb:	75 61                	jne    0x3e3e
    3ddd:	6c                   	ins    BYTE PTR es:[di],dx
    3dde:	69 74 65 0e 52       	imul   si,WORD PTR [si+0x65],0x520e
    3de3:	65 6d                	gs ins WORD PTR es:[di],dx
    3de5:	75 6e                	jne    0x3e55
    3de7:	65 72 61             	gs jb  0x3e4b
    3dea:	74 69                	je     0x3e55
    3dec:	6f                   	outs   dx,WORD PTR ds:[si]
    3ded:	6e                   	outs   dx,BYTE PTR ds:[si]
    3dee:	46                   	inc    si
    3def:	56                   	push   si
    3df0:	08 51 74             	or     BYTE PTR [bx+di+0x74],dl
    3df3:	65 53                	gs push bx
    3df5:	74 6f                	je     0x3e66
    3df7:	63 6b 0e             	arpl   WORD PTR [bp+di+0xe],bp
    3dfa:	43                   	inc    bx
    3dfb:	6f                   	outs   dx,WORD PTR ds:[si]
    3dfc:	75 74                	jne    0x3e72
    3dfe:	55                   	push   bp
    3dff:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e00:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    3e05:	6f                   	outs   dx,WORD PTR ds:[si]
    3e06:	63 6b 09             	arpl   WORD PTR [bp+di+0x9],bp
    3e09:	43                   	inc    bx
    3e0a:	6f                   	outs   dx,WORD PTR ds:[si]
    3e0b:	75 74                	jne    0x3e81
    3e0d:	53                   	push   bx
    3e0e:	74 6f                	je     0x3e7f
    3e10:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
    3e13:	44                   	inc    sp
    3e14:	6f                   	outs   dx,WORD PTR ds:[si]
    3e15:	74 41                	je     0x3e58
    3e17:	6d                   	ins    WORD PTR es:[di],dx
    3e18:	6f                   	outs   dx,WORD PTR ds:[si]
    3e19:	72 74                	jb     0x3e8f
    3e1b:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    3e20:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e22:	74 12                	je     0x3e36
    3e24:	43                   	inc    bx
    3e25:	68 61 72             	push   0x7261
    3e28:	67 65 45             	addr32 gs inc bp
    3e2b:	78 70                	js     0x3e9d
    3e2d:	6c                   	ins    BYTE PTR es:[di],dx
    3e2e:	6f                   	outs   dx,WORD PTR ds:[si]
    3e2f:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
    3e34:	6f                   	outs   dx,WORD PTR ds:[si]
    3e35:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e36:	0e                   	push   cs
    3e37:	43                   	inc    bx
    3e38:	6f                   	outs   dx,WORD PTR ds:[si]
    3e39:	75 74                	jne    0x3eaf
    3e3b:	50                   	push   ax
    3e3c:	72 6f                	jb     0x3ead
    3e3e:	64 75 63             	fs jne 0x3ea4
    3e41:	74 69                	je     0x3eac
    3e43:	6f                   	outs   dx,WORD PTR ds:[si]
    3e44:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e45:	55                   	push   bp
    3e46:	89 e5                	mov    bp,sp
    3e48:	b8 3a 00             	mov    ax,0x3a
    3e4b:	9a 44 04 64 3e       	call   0x3e64:0x444
    3e50:	83 ec 3a             	sub    sp,0x3a
    3e53:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3e56:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3e59:	bf 38 01             	mov    di,0x138
    3e5c:	b8 4d 47             	mov    ax,0x474d
    3e5f:	50                   	push   ax
    3e60:	57                   	push   di
    3e61:	9a 73 22 3d 47       	call   0x473d:0x2273
    3e66:	89 c7                	mov    di,ax
    3e68:	8e c2                	mov    es,dx
    3e6a:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    3e6d:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    3e70:	bf c4 3c             	mov    di,0x3cc4
    3e73:	0e                   	push   cs
    3e74:	57                   	push   di
    3e75:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3e78:	06                   	push   es
    3e79:	57                   	push   di
    3e7a:	9a 9b 3b f7 3e       	call   0x3ef7:0x3b9b
    3e7f:	89 c7                	mov    di,ax
    3e81:	8e c2                	mov    es,dx
    3e83:	06                   	push   es
    3e84:	57                   	push   di
    3e85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e88:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3e8c:	83 fa 00             	cmp    dx,0x0
    3e8f:	75 2a                	jne    0x3ebb
    3e91:	3d 01 00             	cmp    ax,0x1
    3e94:	75 25                	jne    0x3ebb
    3e96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e99:	26 8b 85 f8 01       	mov    ax,WORD PTR es:[di+0x1f8]
    3e9e:	26 8b 95 fa 01       	mov    dx,WORD PTR es:[di+0x1fa]
    3ea3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ea6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ea9:	26 8b 85 ec 01       	mov    ax,WORD PTR es:[di+0x1ec]
    3eae:	26 8b 95 ee 01       	mov    dx,WORD PTR es:[di+0x1ee]
    3eb3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3eb6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3eb9:	eb 23                	jmp    0x3ede
    3ebb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ebe:	26 8b 85 fc 01       	mov    ax,WORD PTR es:[di+0x1fc]
    3ec3:	26 8b 95 fe 01       	mov    dx,WORD PTR es:[di+0x1fe]
    3ec8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ecb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ece:	26 8b 85 f0 01       	mov    ax,WORD PTR es:[di+0x1f0]
    3ed3:	26 8b 95 f2 01       	mov    dx,WORD PTR es:[di+0x1f2]
    3ed8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3edb:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3ede:	9b 2e d9 06 ce 3c    	fld    DWORD PTR cs:0x3cce
    3ee4:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    3ee8:	90                   	nop
    3ee9:	9b                   	fwait
    3eea:	bf d2 3c             	mov    di,0x3cd2
    3eed:	0e                   	push   cs
    3eee:	57                   	push   di
    3eef:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3ef2:	06                   	push   es
    3ef3:	57                   	push   di
    3ef4:	9a 9b 3b 21 3f       	call   0x3f21:0x3b9b
    3ef9:	89 c7                	mov    di,ax
    3efb:	8e c2                	mov    es,dx
    3efd:	06                   	push   es
    3efe:	57                   	push   di
    3eff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f02:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3f06:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    3f09:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    3f0c:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    3f10:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    3f14:	bf d9 3c             	mov    di,0x3cd9
    3f17:	0e                   	push   cs
    3f18:	57                   	push   di
    3f19:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3f1c:	06                   	push   es
    3f1d:	57                   	push   di
    3f1e:	9a 9b 3b 66 3f       	call   0x3f66:0x3b9b
    3f23:	89 c7                	mov    di,ax
    3f25:	8e c2                	mov    es,dx
    3f27:	06                   	push   es
    3f28:	57                   	push   di
    3f29:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f2c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f30:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    3f34:	9b de c9             	fmulp  st(1),st
    3f37:	83 ec 08             	sub    sp,0x8
    3f3a:	89 e3                	mov    bx,sp
    3f3c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f40:	90                   	nop
    3f41:	9b                   	fwait
    3f42:	9a a6 2f de 3f       	call   0x3fde:0x2fa6
    3f47:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    3f4b:	90                   	nop
    3f4c:	9b                   	fwait
    3f4d:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3f50:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3f53:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    3f56:	ff 76 e0             	push   WORD PTR [bp-0x20]
    3f59:	bf de 3c             	mov    di,0x3cde
    3f5c:	0e                   	push   cs
    3f5d:	57                   	push   di
    3f5e:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3f61:	06                   	push   es
    3f62:	57                   	push   di
    3f63:	9a 9b 3b 90 3f       	call   0x3f90:0x3b9b
    3f68:	89 c7                	mov    di,ax
    3f6a:	8e c2                	mov    es,dx
    3f6c:	06                   	push   es
    3f6d:	57                   	push   di
    3f6e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f71:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3f75:	9b dd 46 d8          	fld    QWORD PTR [bp-0x28]
    3f79:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    3f7d:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    3f81:	90                   	nop
    3f82:	9b                   	fwait
    3f83:	bf ef 3c             	mov    di,0x3cef
    3f86:	0e                   	push   cs
    3f87:	57                   	push   di
    3f88:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3f8b:	06                   	push   es
    3f8c:	57                   	push   di
    3f8d:	9a 9b 3b ba 3f       	call   0x3fba:0x3b9b
    3f92:	89 c7                	mov    di,ax
    3f94:	8e c2                	mov    es,dx
    3f96:	06                   	push   es
    3f97:	57                   	push   di
    3f98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f9b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3f9f:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    3fa2:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    3fa5:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    3fa9:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    3fad:	bf 00 3d             	mov    di,0x3d00
    3fb0:	0e                   	push   cs
    3fb1:	57                   	push   di
    3fb2:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3fb5:	06                   	push   es
    3fb6:	57                   	push   di
    3fb7:	9a 9b 3b ff 3f       	call   0x3fff:0x3b9b
    3fbc:	89 c7                	mov    di,ax
    3fbe:	8e c2                	mov    es,dx
    3fc0:	06                   	push   es
    3fc1:	57                   	push   di
    3fc2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fc5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3fc9:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    3fcd:	9b de c9             	fmulp  st(1),st
    3fd0:	83 ec 08             	sub    sp,0x8
    3fd3:	89 e3                	mov    bx,sp
    3fd5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3fd9:	90                   	nop
    3fda:	9b                   	fwait
    3fdb:	9a a6 2f 77 40       	call   0x4077:0x2fa6
    3fe0:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    3fe4:	90                   	nop
    3fe5:	9b                   	fwait
    3fe6:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3fe9:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3fec:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    3fef:	ff 76 e0             	push   WORD PTR [bp-0x20]
    3ff2:	bf 12 3d             	mov    di,0x3d12
    3ff5:	0e                   	push   cs
    3ff6:	57                   	push   di
    3ff7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    3ffa:	06                   	push   es
    3ffb:	57                   	push   di
    3ffc:	9a 9b 3b 29 40       	call   0x4029:0x3b9b
    4001:	89 c7                	mov    di,ax
    4003:	8e c2                	mov    es,dx
    4005:	06                   	push   es
    4006:	57                   	push   di
    4007:	26 c4 3d             	les    di,DWORD PTR es:[di]
    400a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    400e:	9b dd 46 d8          	fld    QWORD PTR [bp-0x28]
    4012:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    4016:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    401a:	90                   	nop
    401b:	9b                   	fwait
    401c:	bf 23 3d             	mov    di,0x3d23
    401f:	0e                   	push   cs
    4020:	57                   	push   di
    4021:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4024:	06                   	push   es
    4025:	57                   	push   di
    4026:	9a 9b 3b 53 40       	call   0x4053:0x3b9b
    402b:	89 c7                	mov    di,ax
    402d:	8e c2                	mov    es,dx
    402f:	06                   	push   es
    4030:	57                   	push   di
    4031:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4034:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4038:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    403b:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    403e:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    4042:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    4046:	bf 30 3d             	mov    di,0x3d30
    4049:	0e                   	push   cs
    404a:	57                   	push   di
    404b:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    404e:	06                   	push   es
    404f:	57                   	push   di
    4050:	9a 9b 3b 98 40       	call   0x4098:0x3b9b
    4055:	89 c7                	mov    di,ax
    4057:	8e c2                	mov    es,dx
    4059:	06                   	push   es
    405a:	57                   	push   di
    405b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    405e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4062:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    4066:	9b de c9             	fmulp  st(1),st
    4069:	83 ec 08             	sub    sp,0x8
    406c:	89 e3                	mov    bx,sp
    406e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4072:	90                   	nop
    4073:	9b                   	fwait
    4074:	9a a6 2f 94 43       	call   0x4394:0x2fa6
    4079:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    407d:	90                   	nop
    407e:	9b                   	fwait
    407f:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    4082:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    4085:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    4088:	ff 76 e0             	push   WORD PTR [bp-0x20]
    408b:	bf 3e 3d             	mov    di,0x3d3e
    408e:	0e                   	push   cs
    408f:	57                   	push   di
    4090:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4093:	06                   	push   es
    4094:	57                   	push   di
    4095:	9a 9b 3b c2 40       	call   0x40c2:0x3b9b
    409a:	89 c7                	mov    di,ax
    409c:	8e c2                	mov    es,dx
    409e:	06                   	push   es
    409f:	57                   	push   di
    40a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40a3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    40a7:	9b dd 46 d8          	fld    QWORD PTR [bp-0x28]
    40ab:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    40af:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    40b3:	90                   	nop
    40b4:	9b                   	fwait
    40b5:	bf 51 3d             	mov    di,0x3d51
    40b8:	0e                   	push   cs
    40b9:	57                   	push   di
    40ba:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    40bd:	06                   	push   es
    40be:	57                   	push   di
    40bf:	9a 9b 3b e2 40       	call   0x40e2:0x3b9b
    40c4:	89 c7                	mov    di,ax
    40c6:	8e c2                	mov    es,dx
    40c8:	06                   	push   es
    40c9:	57                   	push   di
    40ca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40cd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40d1:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    40d5:	bf 51 3d             	mov    di,0x3d51
    40d8:	0e                   	push   cs
    40d9:	57                   	push   di
    40da:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    40dd:	06                   	push   es
    40de:	57                   	push   di
    40df:	9a 9b 3b 17 41       	call   0x4117:0x3b9b
    40e4:	89 c7                	mov    di,ax
    40e6:	8e c2                	mov    es,dx
    40e8:	06                   	push   es
    40e9:	57                   	push   di
    40ea:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40ed:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40f1:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    40f5:	9b de e1             	fsubrp st(1),st
    40f8:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    40fc:	90                   	nop
    40fd:	9b                   	fwait
    40fe:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    4101:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    4104:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    4107:	ff 76 e0             	push   WORD PTR [bp-0x20]
    410a:	bf 5d 3d             	mov    di,0x3d5d
    410d:	0e                   	push   cs
    410e:	57                   	push   di
    410f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4112:	06                   	push   es
    4113:	57                   	push   di
    4114:	9a 9b 3b 4d 41       	call   0x414d:0x3b9b
    4119:	89 c7                	mov    di,ax
    411b:	8e c2                	mov    es,dx
    411d:	06                   	push   es
    411e:	57                   	push   di
    411f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4122:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4126:	9b dd 46 d8          	fld    QWORD PTR [bp-0x28]
    412a:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    412e:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    4132:	90                   	nop
    4133:	9b                   	fwait
    4134:	ff 76 de             	push   WORD PTR [bp-0x22]
    4137:	ff 76 dc             	push   WORD PTR [bp-0x24]
    413a:	ff 76 da             	push   WORD PTR [bp-0x26]
    413d:	ff 76 d8             	push   WORD PTR [bp-0x28]
    4140:	bf 6f 3d             	mov    di,0x3d6f
    4143:	0e                   	push   cs
    4144:	57                   	push   di
    4145:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4148:	06                   	push   es
    4149:	57                   	push   di
    414a:	9a 9b 3b 69 41       	call   0x4169:0x3b9b
    414f:	89 c7                	mov    di,ax
    4151:	8e c2                	mov    es,dx
    4153:	06                   	push   es
    4154:	57                   	push   di
    4155:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4158:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    415c:	bf 8f 3d             	mov    di,0x3d8f
    415f:	0e                   	push   cs
    4160:	57                   	push   di
    4161:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4164:	06                   	push   es
    4165:	57                   	push   di
    4166:	9a 9b 3b 89 41       	call   0x4189:0x3b9b
    416b:	89 c7                	mov    di,ax
    416d:	8e c2                	mov    es,dx
    416f:	06                   	push   es
    4170:	57                   	push   di
    4171:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4174:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4178:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    417c:	bf 99 3d             	mov    di,0x3d99
    417f:	0e                   	push   cs
    4180:	57                   	push   di
    4181:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4184:	06                   	push   es
    4185:	57                   	push   di
    4186:	9a 9b 3b b7 41       	call   0x41b7:0x3b9b
    418b:	89 c7                	mov    di,ax
    418d:	8e c2                	mov    es,dx
    418f:	06                   	push   es
    4190:	57                   	push   di
    4191:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4194:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4198:	9b db 6e ca          	fld    TBYTE PTR [bp-0x36]
    419c:	9b de c1             	faddp  st(1),st
    419f:	83 ec 08             	sub    sp,0x8
    41a2:	89 e3                	mov    bx,sp
    41a4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    41a8:	90                   	nop
    41a9:	9b                   	fwait
    41aa:	bf 80 3d             	mov    di,0x3d80
    41ad:	0e                   	push   cs
    41ae:	57                   	push   di
    41af:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    41b2:	06                   	push   es
    41b3:	57                   	push   di
    41b4:	9a 9b 3b eb 41       	call   0x41eb:0x3b9b
    41b9:	89 c7                	mov    di,ax
    41bb:	8e c2                	mov    es,dx
    41bd:	06                   	push   es
    41be:	57                   	push   di
    41bf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41c2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    41c6:	9b 2e d9 06 ce 3c    	fld    DWORD PTR cs:0x3cce
    41cc:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    41d0:	90                   	nop
    41d1:	9b                   	fwait
    41d2:	9b 2e d9 06 ce 3c    	fld    DWORD PTR cs:0x3cce
    41d8:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    41dc:	90                   	nop
    41dd:	9b                   	fwait
    41de:	bf ab 3d             	mov    di,0x3dab
    41e1:	0e                   	push   cs
    41e2:	57                   	push   di
    41e3:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    41e6:	06                   	push   es
    41e7:	57                   	push   di
    41e8:	9a 9b 3b 11 42       	call   0x4211:0x3b9b
    41ed:	89 c7                	mov    di,ax
    41ef:	8e c2                	mov    es,dx
    41f1:	06                   	push   es
    41f2:	57                   	push   di
    41f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41f6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41fa:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    41fe:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    4202:	90                   	nop
    4203:	9b                   	fwait
    4204:	bf ab 3d             	mov    di,0x3dab
    4207:	0e                   	push   cs
    4208:	57                   	push   di
    4209:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    420c:	06                   	push   es
    420d:	57                   	push   di
    420e:	9a 9b 3b 37 42       	call   0x4237:0x3b9b
    4213:	89 c7                	mov    di,ax
    4215:	8e c2                	mov    es,dx
    4217:	06                   	push   es
    4218:	57                   	push   di
    4219:	26 c4 3d             	les    di,DWORD PTR es:[di]
    421c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4220:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    4224:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    4228:	90                   	nop
    4229:	9b                   	fwait
    422a:	bf bf 3d             	mov    di,0x3dbf
    422d:	0e                   	push   cs
    422e:	57                   	push   di
    422f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4232:	06                   	push   es
    4233:	57                   	push   di
    4234:	9a 9b 3b 5d 42       	call   0x425d:0x3b9b
    4239:	89 c7                	mov    di,ax
    423b:	8e c2                	mov    es,dx
    423d:	06                   	push   es
    423e:	57                   	push   di
    423f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4242:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4246:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    424a:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    424e:	90                   	nop
    424f:	9b                   	fwait
    4250:	bf bf 3d             	mov    di,0x3dbf
    4253:	0e                   	push   cs
    4254:	57                   	push   di
    4255:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4258:	06                   	push   es
    4259:	57                   	push   di
    425a:	9a 9b 3b 83 42       	call   0x4283:0x3b9b
    425f:	89 c7                	mov    di,ax
    4261:	8e c2                	mov    es,dx
    4263:	06                   	push   es
    4264:	57                   	push   di
    4265:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4268:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    426c:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    4270:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    4274:	90                   	nop
    4275:	9b                   	fwait
    4276:	bf d1 3d             	mov    di,0x3dd1
    4279:	0e                   	push   cs
    427a:	57                   	push   di
    427b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    427e:	06                   	push   es
    427f:	57                   	push   di
    4280:	9a 9b 3b a9 42       	call   0x42a9:0x3b9b
    4285:	89 c7                	mov    di,ax
    4287:	8e c2                	mov    es,dx
    4289:	06                   	push   es
    428a:	57                   	push   di
    428b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    428e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4292:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    4296:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    429a:	90                   	nop
    429b:	9b                   	fwait
    429c:	bf d1 3d             	mov    di,0x3dd1
    429f:	0e                   	push   cs
    42a0:	57                   	push   di
    42a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    42a4:	06                   	push   es
    42a5:	57                   	push   di
    42a6:	9a 9b 3b cf 42       	call   0x42cf:0x3b9b
    42ab:	89 c7                	mov    di,ax
    42ad:	8e c2                	mov    es,dx
    42af:	06                   	push   es
    42b0:	57                   	push   di
    42b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42b4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42b8:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    42bc:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    42c0:	90                   	nop
    42c1:	9b                   	fwait
    42c2:	bf 8f 3d             	mov    di,0x3d8f
    42c5:	0e                   	push   cs
    42c6:	57                   	push   di
    42c7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    42ca:	06                   	push   es
    42cb:	57                   	push   di
    42cc:	9a 9b 3b f5 42       	call   0x42f5:0x3b9b
    42d1:	89 c7                	mov    di,ax
    42d3:	8e c2                	mov    es,dx
    42d5:	06                   	push   es
    42d6:	57                   	push   di
    42d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42da:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42de:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    42e2:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    42e6:	90                   	nop
    42e7:	9b                   	fwait
    42e8:	bf 99 3d             	mov    di,0x3d99
    42eb:	0e                   	push   cs
    42ec:	57                   	push   di
    42ed:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    42f0:	06                   	push   es
    42f1:	57                   	push   di
    42f2:	9a 9b 3b 1b 43       	call   0x431b:0x3b9b
    42f7:	89 c7                	mov    di,ax
    42f9:	8e c2                	mov    es,dx
    42fb:	06                   	push   es
    42fc:	57                   	push   di
    42fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4300:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4304:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    4308:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    430c:	90                   	nop
    430d:	9b                   	fwait
    430e:	bf e1 3d             	mov    di,0x3de1
    4311:	0e                   	push   cs
    4312:	57                   	push   di
    4313:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4316:	06                   	push   es
    4317:	57                   	push   di
    4318:	9a 9b 3b 41 43       	call   0x4341:0x3b9b
    431d:	89 c7                	mov    di,ax
    431f:	8e c2                	mov    es,dx
    4321:	06                   	push   es
    4322:	57                   	push   di
    4323:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4326:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    432a:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    432e:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    4332:	90                   	nop
    4333:	9b                   	fwait
    4334:	bf f0 3d             	mov    di,0x3df0
    4337:	0e                   	push   cs
    4338:	57                   	push   di
    4339:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    433c:	06                   	push   es
    433d:	57                   	push   di
    433e:	9a 9b 3b 70 43       	call   0x4370:0x3b9b
    4343:	89 c7                	mov    di,ax
    4345:	8e c2                	mov    es,dx
    4347:	06                   	push   es
    4348:	57                   	push   di
    4349:	26 c4 3d             	les    di,DWORD PTR es:[di]
    434c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4350:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    4353:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    4356:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    435a:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    435e:	bf f9 3d             	mov    di,0x3df9
    4361:	0e                   	push   cs
    4362:	57                   	push   di
    4363:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4366:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    436b:	06                   	push   es
    436c:	57                   	push   di
    436d:	9a 9b 3b b5 43       	call   0x43b5:0x3b9b
    4372:	89 c7                	mov    di,ax
    4374:	8e c2                	mov    es,dx
    4376:	06                   	push   es
    4377:	57                   	push   di
    4378:	26 c4 3d             	les    di,DWORD PTR es:[di]
    437b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    437f:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    4383:	9b de c9             	fmulp  st(1),st
    4386:	83 ec 08             	sub    sp,0x8
    4389:	89 e3                	mov    bx,sp
    438b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    438f:	90                   	nop
    4390:	9b                   	fwait
    4391:	9a a6 2f 2d 44       	call   0x442d:0x2fa6
    4396:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    439a:	90                   	nop
    439b:	9b                   	fwait
    439c:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    439f:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    43a2:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    43a5:	ff 76 e0             	push   WORD PTR [bp-0x20]
    43a8:	bf 08 3e             	mov    di,0x3e08
    43ab:	0e                   	push   cs
    43ac:	57                   	push   di
    43ad:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    43b0:	06                   	push   es
    43b1:	57                   	push   di
    43b2:	9a 9b 3b df 43       	call   0x43df:0x3b9b
    43b7:	89 c7                	mov    di,ax
    43b9:	8e c2                	mov    es,dx
    43bb:	06                   	push   es
    43bc:	57                   	push   di
    43bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43c0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    43c4:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    43c8:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    43cc:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    43d0:	90                   	nop
    43d1:	9b                   	fwait
    43d2:	bf 12 3e             	mov    di,0x3e12
    43d5:	0e                   	push   cs
    43d6:	57                   	push   di
    43d7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    43da:	06                   	push   es
    43db:	57                   	push   di
    43dc:	9a 9b 3b 05 44       	call   0x4405:0x3b9b
    43e1:	89 c7                	mov    di,ax
    43e3:	8e c2                	mov    es,dx
    43e5:	06                   	push   es
    43e6:	57                   	push   di
    43e7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43ea:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    43ee:	9b dc 46 f0          	fadd   QWORD PTR [bp-0x10]
    43f2:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    43f6:	90                   	nop
    43f7:	9b                   	fwait
    43f8:	bf 12 3e             	mov    di,0x3e12
    43fb:	0e                   	push   cs
    43fc:	57                   	push   di
    43fd:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4400:	06                   	push   es
    4401:	57                   	push   di
    4402:	9a 9b 3b 47 44       	call   0x4447:0x3b9b
    4407:	89 c7                	mov    di,ax
    4409:	8e c2                	mov    es,dx
    440b:	06                   	push   es
    440c:	57                   	push   di
    440d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4410:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4414:	9b dc 46 e8          	fadd   QWORD PTR [bp-0x18]
    4418:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    441c:	90                   	nop
    441d:	9b                   	fwait
    441e:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4421:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4424:	ff 76 f2             	push   WORD PTR [bp-0xe]
    4427:	ff 76 f0             	push   WORD PTR [bp-0x10]
    442a:	9a a6 2f 65 44       	call   0x4465:0x2fa6
    442f:	83 ec 08             	sub    sp,0x8
    4432:	89 e3                	mov    bx,sp
    4434:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4438:	90                   	nop
    4439:	9b                   	fwait
    443a:	bf 23 3e             	mov    di,0x3e23
    443d:	0e                   	push   cs
    443e:	57                   	push   di
    443f:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    4442:	06                   	push   es
    4443:	57                   	push   di
    4444:	9a 9b 3b 7f 44       	call   0x447f:0x3b9b
    4449:	89 c7                	mov    di,ax
    444b:	8e c2                	mov    es,dx
    444d:	06                   	push   es
    444e:	57                   	push   di
    444f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4452:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4456:	ff 76 ee             	push   WORD PTR [bp-0x12]
    4459:	ff 76 ec             	push   WORD PTR [bp-0x14]
    445c:	ff 76 ea             	push   WORD PTR [bp-0x16]
    445f:	ff 76 e8             	push   WORD PTR [bp-0x18]
    4462:	9a a6 2f 53 51       	call   0x5153:0x2fa6
    4467:	83 ec 08             	sub    sp,0x8
    446a:	89 e3                	mov    bx,sp
    446c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4470:	90                   	nop
    4471:	9b                   	fwait
    4472:	bf 36 3e             	mov    di,0x3e36
    4475:	0e                   	push   cs
    4476:	57                   	push   di
    4477:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    447a:	06                   	push   es
    447b:	57                   	push   di
    447c:	9a 9b 3b 88 47       	call   0x4788:0x3b9b
    4481:	89 c7                	mov    di,ax
    4483:	8e c2                	mov    es,dx
    4485:	06                   	push   es
    4486:	57                   	push   di
    4487:	26 c4 3d             	les    di,DWORD PTR es:[di]
    448a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    448e:	c9                   	leave
    448f:	ca 08 00             	retf   0x8
    4492:	10 50 72             	adc    BYTE PTR [bx+si+0x72],dl
    4495:	6f                   	outs   dx,WORD PTR ds:[si]
    4496:	64 75 63             	fs jne 0x44fc
    4499:	74 69                	je     0x4504
    449b:	6f                   	outs   dx,WORD PTR ds:[si]
    449c:	6e                   	outs   dx,BYTE PTR ds:[si]
    449d:	56                   	push   si
    449e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    44a0:	64 75 65             	fs jne 0x4508
    44a3:	10 50 72             	adc    BYTE PTR [bx+si+0x72],dl
    44a6:	6f                   	outs   dx,WORD PTR ds:[si]
    44a7:	64 75 63             	fs jne 0x450d
    44aa:	74 69                	je     0x4515
    44ac:	6f                   	outs   dx,WORD PTR ds:[si]
    44ad:	6e                   	outs   dx,BYTE PTR ds:[si]
    44ae:	53                   	push   bx
    44af:	6f                   	outs   dx,WORD PTR ds:[si]
    44b0:	6c                   	ins    BYTE PTR es:[di],dx
    44b1:	64 65 65 12 50 72    	fs gs adc dl,BYTE PTR gs:[bx+si+0x72]
    44b7:	6f                   	outs   dx,WORD PTR ds:[si]
    44b8:	64 75 63             	fs jne 0x451e
    44bb:	74 69                	je     0x4526
    44bd:	6f                   	outs   dx,WORD PTR ds:[si]
    44be:	6e                   	outs   dx,BYTE PTR ds:[si]
    44bf:	53                   	push   bx
    44c0:	70 65                	jo     0x4527
    44c2:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    44c5:	6c                   	ins    BYTE PTR es:[di],dx
    44c6:	65 11 50 72          	adc    WORD PTR gs:[bx+si+0x72],dx
    44ca:	6f                   	outs   dx,WORD PTR ds:[si]
    44cb:	64 75 63             	fs jne 0x4531
    44ce:	74 69                	je     0x4539
    44d0:	6f                   	outs   dx,WORD PTR ds:[si]
    44d1:	6e                   	outs   dx,BYTE PTR ds:[si]
    44d2:	53                   	push   bx
    44d3:	74 6f                	je     0x4544
    44d5:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
    44d8:	65 10 50 72          	adc    BYTE PTR gs:[bx+si+0x72],dl
    44dc:	6f                   	outs   dx,WORD PTR ds:[si]
    44dd:	64 75 63             	fs jne 0x4543
    44e0:	74 69                	je     0x454b
    44e2:	6f                   	outs   dx,WORD PTR ds:[si]
    44e3:	6e                   	outs   dx,BYTE PTR ds:[si]
    44e4:	56                   	push   si
    44e5:	61                   	popa
    44e6:	6c                   	ins    BYTE PTR es:[di],dx
    44e7:	65 75 72             	gs jne 0x455c
    44ea:	13 50 72             	adc    dx,WORD PTR [bx+si+0x72]
    44ed:	6f                   	outs   dx,WORD PTR ds:[si]
    44ee:	64 75 69             	fs jne 0x455a
    44f1:	74 45                	je     0x4538
    44f3:	78 70                	js     0x4565
    44f5:	6c                   	ins    BYTE PTR es:[di],dx
    44f6:	6f                   	outs   dx,WORD PTR ds:[si]
    44f7:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
    44fc:	6f                   	outs   dx,WORD PTR ds:[si]
    44fd:	6e                   	outs   dx,BYTE PTR ds:[si]
    44fe:	0b 53 75             	or     dx,WORD PTR [bp+di+0x75]
    4501:	62 76 65             	bound  si,DWORD PTR [bp+0x65]
    4504:	6e                   	outs   dx,BYTE PTR ds:[si]
    4505:	74 69                	je     0x4570
    4507:	6f                   	outs   dx,WORD PTR ds:[si]
    4508:	6e                   	outs   dx,BYTE PTR ds:[si]
    4509:	73 13                	jae    0x451e
    450b:	43                   	inc    bx
    450c:	6f                   	outs   dx,WORD PTR ds:[si]
    450d:	6e                   	outs   dx,BYTE PTR ds:[si]
    450e:	73 6f                	jae    0x457f
    4510:	6d                   	ins    WORD PTR es:[di],dx
    4511:	6d                   	ins    WORD PTR es:[di],dx
    4512:	61                   	popa
    4513:	74 69                	je     0x457e
    4515:	6f                   	outs   dx,WORD PTR ds:[si]
    4516:	6e                   	outs   dx,BYTE PTR ds:[si]
    4517:	4d                   	dec    bp
    4518:	61                   	popa
    4519:	74 69                	je     0x4584
    451b:	65 72 65             	gs jb  0x4583
    451e:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    4521:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    4526:	76 72                	jbe    0x459a
    4528:	65 44                	gs inc sp
    452a:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    452f:	65 0f 44 65 70       	cmove  sp,WORD PTR gs:[di+0x70]
    4534:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4536:	73 65                	jae    0x459d
    4538:	73 51                	jae    0x458b
    453a:	75 61                	jne    0x459d
    453c:	6c                   	ins    BYTE PTR es:[di],dx
    453d:	69 74 65 0e 50       	imul   si,WORD PTR [si+0x65],0x500e
    4542:	75 62                	jne    0x45a6
    4544:	45                   	inc    bp
    4545:	74 41                	je     0x4588
    4547:	63 74 69             	arpl   WORD PTR [si+0x69],si
    454a:	6f                   	outs   dx,WORD PTR ds:[si]
    454b:	6e                   	outs   dx,BYTE PTR ds:[si]
    454c:	43                   	inc    bx
    454d:	6f                   	outs   dx,WORD PTR ds:[si]
    454e:	6d                   	ins    WORD PTR es:[di],dx
    454f:	0e                   	push   cs
    4550:	52                   	push   dx
    4551:	65 6d                	gs ins WORD PTR es:[di],dx
    4553:	75 6e                	jne    0x45c3
    4555:	65 72 61             	gs jb  0x45b9
    4558:	74 69                	je     0x45c3
    455a:	6f                   	outs   dx,WORD PTR ds:[si]
    455b:	6e                   	outs   dx,BYTE PTR ds:[si]
    455c:	46                   	inc    si
    455d:	56                   	push   si
    455e:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
    4561:	75 74                	jne    0x45d7
    4563:	53                   	push   bx
    4564:	74 6f                	je     0x45d5
    4566:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
    4569:	44                   	inc    sp
    456a:	6f                   	outs   dx,WORD PTR ds:[si]
    456b:	74 41                	je     0x45ae
    456d:	6d                   	ins    WORD PTR es:[di],dx
    456e:	6f                   	outs   dx,WORD PTR ds:[si]
    456f:	72 74                	jb     0x45e5
    4571:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    4576:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4578:	74 12                	je     0x458c
    457a:	43                   	inc    bx
    457b:	68 61 72             	push   0x7261
    457e:	67 65 45             	addr32 gs inc bp
    4581:	78 70                	js     0x45f3
    4583:	6c                   	ins    BYTE PTR es:[di],dx
    4584:	6f                   	outs   dx,WORD PTR ds:[si]
    4585:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
    458a:	6f                   	outs   dx,WORD PTR ds:[si]
    458b:	6e                   	outs   dx,BYTE PTR ds:[si]
    458c:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
    458f:	6d                   	ins    WORD PTR es:[di],dx
    4590:	75 6e                	jne    0x4600
    4592:	65 72 61             	gs jb  0x45f6
    4595:	74 69                	je     0x4600
    4597:	6f                   	outs   dx,WORD PTR ds:[si]
    4598:	6e                   	outs   dx,BYTE PTR ds:[si]
    4599:	43                   	inc    bx
    459a:	61                   	popa
    459b:	64 72 65             	fs jb  0x4603
    459e:	73 0c                	jae    0x45ac
    45a0:	43                   	inc    bx
    45a1:	6f                   	outs   dx,WORD PTR ds:[si]
    45a2:	75 74                	jne    0x4618
    45a4:	45                   	inc    bp
    45a5:	6d                   	ins    WORD PTR es:[di],dx
    45a6:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    45a9:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    45ac:	0c 43                	or     al,0x43
    45ae:	6f                   	outs   dx,WORD PTR ds:[si]
    45af:	75 74                	jne    0x4625
    45b1:	4c                   	dec    sp
    45b2:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    45b7:	69 65 0d 43 6f       	imul   sp,WORD PTR [di+0xd],0x6f43
    45bc:	75 74                	jne    0x4632
    45be:	46                   	inc    si
    45bf:	6f                   	outs   dx,WORD PTR ds:[si]
    45c0:	72 6d                	jb     0x462f
    45c2:	61                   	popa
    45c3:	74 69                	je     0x462e
    45c5:	6f                   	outs   dx,WORD PTR ds:[si]
    45c6:	6e                   	outs   dx,BYTE PTR ds:[si]
    45c7:	14 43                	adc    al,0x43
    45c9:	6f                   	outs   dx,WORD PTR ds:[si]
    45ca:	75 74                	jne    0x4640
    45cc:	73 46                	jae    0x4614
    45ce:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
    45d3:	72 6f                	jb     0x4644
    45d5:	64 75 63             	fs jne 0x463b
    45d8:	74 69                	je     0x4643
    45da:	6f                   	outs   dx,WORD PTR ds:[si]
    45db:	6e                   	outs   dx,BYTE PTR ds:[si]
    45dc:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    45df:	70 61                	jo     0x4642
    45e1:	72 61                	jb     0x4644
    45e3:	74 69                	je     0x464e
    45e5:	6f                   	outs   dx,WORD PTR ds:[si]
    45e6:	6e                   	outs   dx,BYTE PTR ds:[si]
    45e7:	73 11                	jae    0x45fa
    45e9:	45                   	inc    bp
    45ea:	6e                   	outs   dx,BYTE PTR ds:[si]
    45eb:	74 72                	je     0x465f
    45ed:	65 74 69             	gs je  0x4659
    45f0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    45f2:	4d                   	dec    bp
    45f3:	61                   	popa
    45f4:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    45f7:	6e                   	outs   dx,BYTE PTR ds:[si]
    45f8:	65 73 0f             	gs jae 0x460a
    45fb:	50                   	push   ax
    45fc:	72 69                	jb     0x4667
    45fe:	6d                   	ins    WORD PTR es:[di],dx
    45ff:	65 73 41             	gs jae 0x4643
    4602:	73 73                	jae    0x4677
    4604:	75 72                	jne    0x4678
    4606:	61                   	popa
    4607:	6e                   	outs   dx,BYTE PTR ds:[si]
    4608:	63 65 06             	arpl   WORD PTR [di+0x6],sp
    460b:	45                   	inc    bp
    460c:	74 75                	je     0x4683
    460e:	64 65 73 14          	fs gs jae 0x4626
    4612:	52                   	push   dx
    4613:	65 73 75             	gs jae 0x468b
    4616:	6c                   	ins    BYTE PTR es:[di],dx
    4617:	74 61                	je     0x467a
    4619:	74 45                	je     0x4660
    461b:	78 70                	js     0x468d
    461d:	6c                   	ins    BYTE PTR es:[di],dx
    461e:	6f                   	outs   dx,WORD PTR ds:[si]
    461f:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
    4624:	6f                   	outs   dx,WORD PTR ds:[si]
    4625:	6e                   	outs   dx,BYTE PTR ds:[si]
    4626:	10 50 72             	adc    BYTE PTR [bx+si+0x72],dl
    4629:	6f                   	outs   dx,WORD PTR ds:[si]
    462a:	64 75 69             	fs jne 0x4696
    462d:	74 46                	je     0x4675
    462f:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    4634:	69 65 72 0a 54       	imul   sp,WORD PTR [di+0x72],0x540a
    4639:	72 65                	jb     0x46a0
    463b:	73 6f                	jae    0x46ac
    463d:	72 65                	jb     0x46a4
    463f:	72 69                	jb     0x46aa
    4641:	65 0d 54 61          	gs or  ax,0x6154
    4645:	75 78                	jne    0x46bf
    4647:	50                   	push   ax
    4648:	6c                   	ins    BYTE PTR es:[di],dx
    4649:	61                   	popa
    464a:	63 65 6d             	arpl   WORD PTR [di+0x6d],sp
    464d:	65 6e                	outs   dx,BYTE PTR gs:[si]
    464f:	74 00                	je     0x4651
    4651:	00 c8                	add    al,cl
    4653:	42                   	inc    dx
    4654:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
    4657:	61                   	popa
    4658:	72 67                	jb     0x46c1
    465a:	65 46                	gs inc si
    465c:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    4661:	69 65 72 65 0d       	imul   sp,WORD PTR [di+0x72],0xd65
    4666:	44                   	inc    sp
    4667:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    466b:	76 65                	jbe    0x46d2
    466d:	72 74                	jb     0x46e3
    466f:	41                   	inc    cx
    4670:	75 74                	jne    0x46e6
    4672:	6f                   	outs   dx,WORD PTR ds:[si]
    4673:	11 54 61             	adc    WORD PTR [si+0x61],dx
    4676:	75 78                	jne    0x46f0
    4678:	44                   	inc    sp
    4679:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    467d:	76 65                	jbe    0x46e4
    467f:	72 74                	jb     0x46f5
    4681:	41                   	inc    cx
    4682:	75 74                	jne    0x46f8
    4684:	6f                   	outs   dx,WORD PTR ds:[si]
    4685:	0e                   	push   cs
    4686:	44                   	inc    sp
    4687:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    468b:	76 65                	jbe    0x46f2
    468d:	72 74                	jb     0x4703
    468f:	4e                   	dec    si
    4690:	41                   	inc    cx
    4691:	75 74                	jne    0x4707
    4693:	6f                   	outs   dx,WORD PTR ds:[si]
    4694:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    4697:	75 78                	jne    0x4711
    4699:	44                   	inc    sp
    469a:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    469e:	76 65                	jbe    0x4705
    46a0:	72 74                	jb     0x4716
    46a2:	4e                   	dec    si
    46a3:	41                   	inc    cx
    46a4:	75 74                	jne    0x471a
    46a6:	6f                   	outs   dx,WORD PTR ds:[si]
    46a7:	07                   	pop    es
    46a8:	45                   	inc    bp
    46a9:	6d                   	ins    WORD PTR es:[di],dx
    46aa:	70 72                	jo     0x471e
    46ac:	75 6e                	jne    0x471c
    46ae:	74 0b                	je     0x46bb
    46b0:	54                   	push   sp
    46b1:	61                   	popa
    46b2:	75 78                	jne    0x472c
    46b4:	45                   	inc    bp
    46b5:	6d                   	ins    WORD PTR es:[di],dx
    46b6:	70 72                	jo     0x472a
    46b8:	75 6e                	jne    0x4728
    46ba:	74 11                	je     0x46cd
    46bc:	52                   	push   dx
    46bd:	65 73 75             	gs jae 0x4735
    46c0:	6c                   	ins    BYTE PTR es:[di],dx
    46c1:	74 61                	je     0x4724
    46c3:	74 46                	je     0x470b
    46c5:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    46ca:	69 65 72 13 50       	imul   sp,WORD PTR [di+0x72],0x5013
    46cf:	72 6f                	jb     0x4740
    46d1:	64 75 69             	fs jne 0x473d
    46d4:	74 73                	je     0x4749
    46d6:	4f                   	dec    di
    46d7:	75 43                	jne    0x471c
    46d9:	68 61 72             	push   0x7261
    46dc:	67 65 73 45          	addr32 gs jae 0x4725
    46e0:	78 00                	js     0x46e2
    46e2:	00 00                	add    BYTE PTR [bx+si],al
    46e4:	00 0a                	add    BYTE PTR [bp+si],cl
    46e6:	50                   	push   ax
    46e7:	72 6f                	jb     0x4758
    46e9:	64 75 69             	fs jne 0x4755
    46ec:	74 73                	je     0x4761
    46ee:	45                   	inc    bp
    46ef:	78 09                	js     0x46fa
    46f1:	43                   	inc    bx
    46f2:	68 61 72             	push   0x7261
    46f5:	67 65 73 45          	addr32 gs jae 0x473e
    46f9:	78 12                	js     0x470d
    46fb:	52                   	push   dx
    46fc:	65 73 75             	gs jae 0x4774
    46ff:	6c                   	ins    BYTE PTR es:[di],dx
    4700:	74 61                	je     0x4763
    4702:	74 41                	je     0x4745
    4704:	76 61                	jbe    0x4767
    4706:	6e                   	outs   dx,BYTE PTR ds:[si]
    4707:	74 49                	je     0x4752
    4709:	6d                   	ins    WORD PTR es:[di],dx
    470a:	70 6f                	jo     0x477b
    470c:	74 0d                	je     0x471b
    470e:	52                   	push   dx
    470f:	65 6d                	gs ins WORD PTR es:[di],dx
    4711:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    4714:	72 73                	jb     0x4789
    4716:	41                   	inc    cx
    4717:	73 73                	jae    0x478c
    4719:	75 72                	jne    0x478d
    471b:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
    471e:	73 75                	jae    0x4795
    4720:	6c                   	ins    BYTE PTR es:[di],dx
    4721:	74 61                	je     0x4784
    4723:	74 41                	je     0x4766
    4725:	50                   	push   ax
    4726:	52                   	push   dx
    4727:	45                   	inc    bp
    4728:	53                   	push   bx
    4729:	49                   	dec    cx
    472a:	6d                   	ins    WORD PTR es:[di],dx
    472b:	70 6f                	jo     0x479c
    472d:	74 05                	je     0x4734
    472f:	49                   	dec    cx
    4730:	6d                   	ins    WORD PTR es:[di],dx
    4731:	70 6f                	jo     0x47a2
    4733:	74 55                	je     0x478a
    4735:	89 e5                	mov    bp,sp
    4737:	b8 80 01             	mov    ax,0x180
    473a:	9a 44 04 54 47       	call   0x4754:0x444
    473f:	81 ec 80 01          	sub    sp,0x180
    4743:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4746:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4749:	bf 38 01             	mov    di,0x138
    474c:	b8 ff ff             	mov    ax,0xffff
    474f:	50                   	push   ax
    4750:	57                   	push   di
    4751:	9a 73 22 73 47       	call   0x4773:0x2273
    4756:	89 c7                	mov    di,ax
    4758:	8e c2                	mov    es,dx
    475a:	89 be e4 fe          	mov    WORD PTR [bp-0x11c],di
    475e:	8c 86 e6 fe          	mov    WORD PTR [bp-0x11a],es
    4762:	bf 92 44             	mov    di,0x4492
    4765:	0e                   	push   cs
    4766:	57                   	push   di
    4767:	8d be 00 ff          	lea    di,[bp-0x100]
    476b:	16                   	push   ss
    476c:	57                   	push   di
    476d:	68 ff 00             	push   0xff
    4770:	9a e7 17 00 48       	call   0x4800:0x17e7
    4775:	8d be 00 ff          	lea    di,[bp-0x100]
    4779:	16                   	push   ss
    477a:	57                   	push   di
    477b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    477e:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4783:	06                   	push   es
    4784:	57                   	push   di
    4785:	9a 9b 3b af 47       	call   0x47af:0x3b9b
    478a:	89 c7                	mov    di,ax
    478c:	8e c2                	mov    es,dx
    478e:	06                   	push   es
    478f:	57                   	push   di
    4790:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4793:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4797:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    479c:	8d be 00 ff          	lea    di,[bp-0x100]
    47a0:	16                   	push   ss
    47a1:	57                   	push   di
    47a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47a5:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    47aa:	06                   	push   es
    47ab:	57                   	push   di
    47ac:	9a 9b 3b e0 47       	call   0x47e0:0x3b9b
    47b1:	89 c7                	mov    di,ax
    47b3:	8e c2                	mov    es,dx
    47b5:	06                   	push   es
    47b6:	57                   	push   di
    47b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47ba:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    47be:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    47c3:	9b de c1             	faddp  st(1),st
    47c6:	83 ec 08             	sub    sp,0x8
    47c9:	89 e3                	mov    bx,sp
    47cb:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    47cf:	90                   	nop
    47d0:	9b                   	fwait
    47d1:	8d be 00 ff          	lea    di,[bp-0x100]
    47d5:	16                   	push   ss
    47d6:	57                   	push   di
    47d7:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    47db:	06                   	push   es
    47dc:	57                   	push   di
    47dd:	9a 9b 3b 15 48       	call   0x4815:0x3b9b
    47e2:	89 c7                	mov    di,ax
    47e4:	8e c2                	mov    es,dx
    47e6:	06                   	push   es
    47e7:	57                   	push   di
    47e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47eb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    47ef:	bf a3 44             	mov    di,0x44a3
    47f2:	0e                   	push   cs
    47f3:	57                   	push   di
    47f4:	8d be 00 ff          	lea    di,[bp-0x100]
    47f8:	16                   	push   ss
    47f9:	57                   	push   di
    47fa:	68 ff 00             	push   0xff
    47fd:	9a e7 17 8d 48       	call   0x488d:0x17e7
    4802:	8d be 00 ff          	lea    di,[bp-0x100]
    4806:	16                   	push   ss
    4807:	57                   	push   di
    4808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    480b:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4810:	06                   	push   es
    4811:	57                   	push   di
    4812:	9a 9b 3b 3c 48       	call   0x483c:0x3b9b
    4817:	89 c7                	mov    di,ax
    4819:	8e c2                	mov    es,dx
    481b:	06                   	push   es
    481c:	57                   	push   di
    481d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4820:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4824:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4829:	8d be 00 ff          	lea    di,[bp-0x100]
    482d:	16                   	push   ss
    482e:	57                   	push   di
    482f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4832:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4837:	06                   	push   es
    4838:	57                   	push   di
    4839:	9a 9b 3b 6d 48       	call   0x486d:0x3b9b
    483e:	89 c7                	mov    di,ax
    4840:	8e c2                	mov    es,dx
    4842:	06                   	push   es
    4843:	57                   	push   di
    4844:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4847:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    484b:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4850:	9b de c1             	faddp  st(1),st
    4853:	83 ec 08             	sub    sp,0x8
    4856:	89 e3                	mov    bx,sp
    4858:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    485c:	90                   	nop
    485d:	9b                   	fwait
    485e:	8d be 00 ff          	lea    di,[bp-0x100]
    4862:	16                   	push   ss
    4863:	57                   	push   di
    4864:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4868:	06                   	push   es
    4869:	57                   	push   di
    486a:	9a 9b 3b a2 48       	call   0x48a2:0x3b9b
    486f:	89 c7                	mov    di,ax
    4871:	8e c2                	mov    es,dx
    4873:	06                   	push   es
    4874:	57                   	push   di
    4875:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4878:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    487c:	bf b4 44             	mov    di,0x44b4
    487f:	0e                   	push   cs
    4880:	57                   	push   di
    4881:	8d be 00 ff          	lea    di,[bp-0x100]
    4885:	16                   	push   ss
    4886:	57                   	push   di
    4887:	68 ff 00             	push   0xff
    488a:	9a e7 17 1a 49       	call   0x491a:0x17e7
    488f:	8d be 00 ff          	lea    di,[bp-0x100]
    4893:	16                   	push   ss
    4894:	57                   	push   di
    4895:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4898:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    489d:	06                   	push   es
    489e:	57                   	push   di
    489f:	9a 9b 3b c9 48       	call   0x48c9:0x3b9b
    48a4:	89 c7                	mov    di,ax
    48a6:	8e c2                	mov    es,dx
    48a8:	06                   	push   es
    48a9:	57                   	push   di
    48aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48ad:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48b1:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    48b6:	8d be 00 ff          	lea    di,[bp-0x100]
    48ba:	16                   	push   ss
    48bb:	57                   	push   di
    48bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48bf:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    48c4:	06                   	push   es
    48c5:	57                   	push   di
    48c6:	9a 9b 3b fa 48       	call   0x48fa:0x3b9b
    48cb:	89 c7                	mov    di,ax
    48cd:	8e c2                	mov    es,dx
    48cf:	06                   	push   es
    48d0:	57                   	push   di
    48d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48d4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48d8:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    48dd:	9b de c1             	faddp  st(1),st
    48e0:	83 ec 08             	sub    sp,0x8
    48e3:	89 e3                	mov    bx,sp
    48e5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    48e9:	90                   	nop
    48ea:	9b                   	fwait
    48eb:	8d be 00 ff          	lea    di,[bp-0x100]
    48ef:	16                   	push   ss
    48f0:	57                   	push   di
    48f1:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    48f5:	06                   	push   es
    48f6:	57                   	push   di
    48f7:	9a 9b 3b 2f 49       	call   0x492f:0x3b9b
    48fc:	89 c7                	mov    di,ax
    48fe:	8e c2                	mov    es,dx
    4900:	06                   	push   es
    4901:	57                   	push   di
    4902:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4905:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4909:	bf c7 44             	mov    di,0x44c7
    490c:	0e                   	push   cs
    490d:	57                   	push   di
    490e:	8d be 00 ff          	lea    di,[bp-0x100]
    4912:	16                   	push   ss
    4913:	57                   	push   di
    4914:	68 ff 00             	push   0xff
    4917:	9a e7 17 a7 49       	call   0x49a7:0x17e7
    491c:	8d be 00 ff          	lea    di,[bp-0x100]
    4920:	16                   	push   ss
    4921:	57                   	push   di
    4922:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4925:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    492a:	06                   	push   es
    492b:	57                   	push   di
    492c:	9a 9b 3b 56 49       	call   0x4956:0x3b9b
    4931:	89 c7                	mov    di,ax
    4933:	8e c2                	mov    es,dx
    4935:	06                   	push   es
    4936:	57                   	push   di
    4937:	26 c4 3d             	les    di,DWORD PTR es:[di]
    493a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    493e:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4943:	8d be 00 ff          	lea    di,[bp-0x100]
    4947:	16                   	push   ss
    4948:	57                   	push   di
    4949:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    494c:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4951:	06                   	push   es
    4952:	57                   	push   di
    4953:	9a 9b 3b 87 49       	call   0x4987:0x3b9b
    4958:	89 c7                	mov    di,ax
    495a:	8e c2                	mov    es,dx
    495c:	06                   	push   es
    495d:	57                   	push   di
    495e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4961:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4965:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    496a:	9b de c1             	faddp  st(1),st
    496d:	83 ec 08             	sub    sp,0x8
    4970:	89 e3                	mov    bx,sp
    4972:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4976:	90                   	nop
    4977:	9b                   	fwait
    4978:	8d be 00 ff          	lea    di,[bp-0x100]
    497c:	16                   	push   ss
    497d:	57                   	push   di
    497e:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4982:	06                   	push   es
    4983:	57                   	push   di
    4984:	9a 9b 3b bc 49       	call   0x49bc:0x3b9b
    4989:	89 c7                	mov    di,ax
    498b:	8e c2                	mov    es,dx
    498d:	06                   	push   es
    498e:	57                   	push   di
    498f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4992:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4996:	bf d9 44             	mov    di,0x44d9
    4999:	0e                   	push   cs
    499a:	57                   	push   di
    499b:	8d be 00 ff          	lea    di,[bp-0x100]
    499f:	16                   	push   ss
    49a0:	57                   	push   di
    49a1:	68 ff 00             	push   0xff
    49a4:	9a e7 17 a7 4a       	call   0x4aa7:0x17e7
    49a9:	8d be 00 ff          	lea    di,[bp-0x100]
    49ad:	16                   	push   ss
    49ae:	57                   	push   di
    49af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49b2:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    49b7:	06                   	push   es
    49b8:	57                   	push   di
    49b9:	9a 9b 3b e3 49       	call   0x49e3:0x3b9b
    49be:	89 c7                	mov    di,ax
    49c0:	8e c2                	mov    es,dx
    49c2:	06                   	push   es
    49c3:	57                   	push   di
    49c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49c7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49cb:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    49d0:	8d be 00 ff          	lea    di,[bp-0x100]
    49d4:	16                   	push   ss
    49d5:	57                   	push   di
    49d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49d9:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    49de:	06                   	push   es
    49df:	57                   	push   di
    49e0:	9a 9b 3b 14 4a       	call   0x4a14:0x3b9b
    49e5:	89 c7                	mov    di,ax
    49e7:	8e c2                	mov    es,dx
    49e9:	06                   	push   es
    49ea:	57                   	push   di
    49eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49ee:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49f2:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    49f7:	9b de c1             	faddp  st(1),st
    49fa:	83 ec 08             	sub    sp,0x8
    49fd:	89 e3                	mov    bx,sp
    49ff:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4a03:	90                   	nop
    4a04:	9b                   	fwait
    4a05:	8d be 00 ff          	lea    di,[bp-0x100]
    4a09:	16                   	push   ss
    4a0a:	57                   	push   di
    4a0b:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4a0f:	06                   	push   es
    4a10:	57                   	push   di
    4a11:	9a 9b 3b 35 4a       	call   0x4a35:0x3b9b
    4a16:	89 c7                	mov    di,ax
    4a18:	8e c2                	mov    es,dx
    4a1a:	06                   	push   es
    4a1b:	57                   	push   di
    4a1c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a1f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4a23:	bf fe 44             	mov    di,0x44fe
    4a26:	0e                   	push   cs
    4a27:	57                   	push   di
    4a28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a2b:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    4a30:	06                   	push   es
    4a31:	57                   	push   di
    4a32:	9a 9b 3b 57 4a       	call   0x4a57:0x3b9b
    4a37:	89 c7                	mov    di,ax
    4a39:	8e c2                	mov    es,dx
    4a3b:	06                   	push   es
    4a3c:	57                   	push   di
    4a3d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a40:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a44:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4a49:	bf d9 44             	mov    di,0x44d9
    4a4c:	0e                   	push   cs
    4a4d:	57                   	push   di
    4a4e:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4a52:	06                   	push   es
    4a53:	57                   	push   di
    4a54:	9a 9b 3b 87 4a       	call   0x4a87:0x3b9b
    4a59:	89 c7                	mov    di,ax
    4a5b:	8e c2                	mov    es,dx
    4a5d:	06                   	push   es
    4a5e:	57                   	push   di
    4a5f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a62:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a66:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4a6b:	9b de c1             	faddp  st(1),st
    4a6e:	83 ec 08             	sub    sp,0x8
    4a71:	89 e3                	mov    bx,sp
    4a73:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4a77:	90                   	nop
    4a78:	9b                   	fwait
    4a79:	bf ea 44             	mov    di,0x44ea
    4a7c:	0e                   	push   cs
    4a7d:	57                   	push   di
    4a7e:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4a82:	06                   	push   es
    4a83:	57                   	push   di
    4a84:	9a 9b 3b bc 4a       	call   0x4abc:0x3b9b
    4a89:	89 c7                	mov    di,ax
    4a8b:	8e c2                	mov    es,dx
    4a8d:	06                   	push   es
    4a8e:	57                   	push   di
    4a8f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a92:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4a96:	bf 0a 45             	mov    di,0x450a
    4a99:	0e                   	push   cs
    4a9a:	57                   	push   di
    4a9b:	8d be 00 ff          	lea    di,[bp-0x100]
    4a9f:	16                   	push   ss
    4aa0:	57                   	push   di
    4aa1:	68 ff 00             	push   0xff
    4aa4:	9a e7 17 34 4b       	call   0x4b34:0x17e7
    4aa9:	8d be 00 ff          	lea    di,[bp-0x100]
    4aad:	16                   	push   ss
    4aae:	57                   	push   di
    4aaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ab2:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4ab7:	06                   	push   es
    4ab8:	57                   	push   di
    4ab9:	9a 9b 3b e3 4a       	call   0x4ae3:0x3b9b
    4abe:	89 c7                	mov    di,ax
    4ac0:	8e c2                	mov    es,dx
    4ac2:	06                   	push   es
    4ac3:	57                   	push   di
    4ac4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ac7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4acb:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4ad0:	8d be 00 ff          	lea    di,[bp-0x100]
    4ad4:	16                   	push   ss
    4ad5:	57                   	push   di
    4ad6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ad9:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4ade:	06                   	push   es
    4adf:	57                   	push   di
    4ae0:	9a 9b 3b 14 4b       	call   0x4b14:0x3b9b
    4ae5:	89 c7                	mov    di,ax
    4ae7:	8e c2                	mov    es,dx
    4ae9:	06                   	push   es
    4aea:	57                   	push   di
    4aeb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4aee:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4af2:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4af7:	9b de c1             	faddp  st(1),st
    4afa:	83 ec 08             	sub    sp,0x8
    4afd:	89 e3                	mov    bx,sp
    4aff:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b03:	90                   	nop
    4b04:	9b                   	fwait
    4b05:	8d be 00 ff          	lea    di,[bp-0x100]
    4b09:	16                   	push   ss
    4b0a:	57                   	push   di
    4b0b:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4b0f:	06                   	push   es
    4b10:	57                   	push   di
    4b11:	9a 9b 3b 49 4b       	call   0x4b49:0x3b9b
    4b16:	89 c7                	mov    di,ax
    4b18:	8e c2                	mov    es,dx
    4b1a:	06                   	push   es
    4b1b:	57                   	push   di
    4b1c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b1f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4b23:	bf 1e 45             	mov    di,0x451e
    4b26:	0e                   	push   cs
    4b27:	57                   	push   di
    4b28:	8d be 00 ff          	lea    di,[bp-0x100]
    4b2c:	16                   	push   ss
    4b2d:	57                   	push   di
    4b2e:	68 ff 00             	push   0xff
    4b31:	9a e7 17 c1 4b       	call   0x4bc1:0x17e7
    4b36:	8d be 00 ff          	lea    di,[bp-0x100]
    4b3a:	16                   	push   ss
    4b3b:	57                   	push   di
    4b3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b3f:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4b44:	06                   	push   es
    4b45:	57                   	push   di
    4b46:	9a 9b 3b 70 4b       	call   0x4b70:0x3b9b
    4b4b:	89 c7                	mov    di,ax
    4b4d:	8e c2                	mov    es,dx
    4b4f:	06                   	push   es
    4b50:	57                   	push   di
    4b51:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b54:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b58:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4b5d:	8d be 00 ff          	lea    di,[bp-0x100]
    4b61:	16                   	push   ss
    4b62:	57                   	push   di
    4b63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b66:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4b6b:	06                   	push   es
    4b6c:	57                   	push   di
    4b6d:	9a 9b 3b a1 4b       	call   0x4ba1:0x3b9b
    4b72:	89 c7                	mov    di,ax
    4b74:	8e c2                	mov    es,dx
    4b76:	06                   	push   es
    4b77:	57                   	push   di
    4b78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b7b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b7f:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4b84:	9b de c1             	faddp  st(1),st
    4b87:	83 ec 08             	sub    sp,0x8
    4b8a:	89 e3                	mov    bx,sp
    4b8c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b90:	90                   	nop
    4b91:	9b                   	fwait
    4b92:	8d be 00 ff          	lea    di,[bp-0x100]
    4b96:	16                   	push   ss
    4b97:	57                   	push   di
    4b98:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4b9c:	06                   	push   es
    4b9d:	57                   	push   di
    4b9e:	9a 9b 3b d6 4b       	call   0x4bd6:0x3b9b
    4ba3:	89 c7                	mov    di,ax
    4ba5:	8e c2                	mov    es,dx
    4ba7:	06                   	push   es
    4ba8:	57                   	push   di
    4ba9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bac:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4bb0:	bf 30 45             	mov    di,0x4530
    4bb3:	0e                   	push   cs
    4bb4:	57                   	push   di
    4bb5:	8d be 00 ff          	lea    di,[bp-0x100]
    4bb9:	16                   	push   ss
    4bba:	57                   	push   di
    4bbb:	68 ff 00             	push   0xff
    4bbe:	9a e7 17 4e 4c       	call   0x4c4e:0x17e7
    4bc3:	8d be 00 ff          	lea    di,[bp-0x100]
    4bc7:	16                   	push   ss
    4bc8:	57                   	push   di
    4bc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bcc:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    4bd1:	06                   	push   es
    4bd2:	57                   	push   di
    4bd3:	9a 9b 3b fd 4b       	call   0x4bfd:0x3b9b
    4bd8:	89 c7                	mov    di,ax
    4bda:	8e c2                	mov    es,dx
    4bdc:	06                   	push   es
    4bdd:	57                   	push   di
    4bde:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4be1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4be5:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4bea:	8d be 00 ff          	lea    di,[bp-0x100]
    4bee:	16                   	push   ss
    4bef:	57                   	push   di
    4bf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bf3:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    4bf8:	06                   	push   es
    4bf9:	57                   	push   di
    4bfa:	9a 9b 3b 2e 4c       	call   0x4c2e:0x3b9b
    4bff:	89 c7                	mov    di,ax
    4c01:	8e c2                	mov    es,dx
    4c03:	06                   	push   es
    4c04:	57                   	push   di
    4c05:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c08:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c0c:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4c11:	9b de c1             	faddp  st(1),st
    4c14:	83 ec 08             	sub    sp,0x8
    4c17:	89 e3                	mov    bx,sp
    4c19:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c1d:	90                   	nop
    4c1e:	9b                   	fwait
    4c1f:	8d be 00 ff          	lea    di,[bp-0x100]
    4c23:	16                   	push   ss
    4c24:	57                   	push   di
    4c25:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4c29:	06                   	push   es
    4c2a:	57                   	push   di
    4c2b:	9a 9b 3b 63 4c       	call   0x4c63:0x3b9b
    4c30:	89 c7                	mov    di,ax
    4c32:	8e c2                	mov    es,dx
    4c34:	06                   	push   es
    4c35:	57                   	push   di
    4c36:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c39:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4c3d:	bf 40 45             	mov    di,0x4540
    4c40:	0e                   	push   cs
    4c41:	57                   	push   di
    4c42:	8d be 00 ff          	lea    di,[bp-0x100]
    4c46:	16                   	push   ss
    4c47:	57                   	push   di
    4c48:	68 ff 00             	push   0xff
    4c4b:	9a e7 17 db 4c       	call   0x4cdb:0x17e7
    4c50:	8d be 00 ff          	lea    di,[bp-0x100]
    4c54:	16                   	push   ss
    4c55:	57                   	push   di
    4c56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c59:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4c5e:	06                   	push   es
    4c5f:	57                   	push   di
    4c60:	9a 9b 3b 8a 4c       	call   0x4c8a:0x3b9b
    4c65:	89 c7                	mov    di,ax
    4c67:	8e c2                	mov    es,dx
    4c69:	06                   	push   es
    4c6a:	57                   	push   di
    4c6b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c6e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c72:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4c77:	8d be 00 ff          	lea    di,[bp-0x100]
    4c7b:	16                   	push   ss
    4c7c:	57                   	push   di
    4c7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c80:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4c85:	06                   	push   es
    4c86:	57                   	push   di
    4c87:	9a 9b 3b bb 4c       	call   0x4cbb:0x3b9b
    4c8c:	89 c7                	mov    di,ax
    4c8e:	8e c2                	mov    es,dx
    4c90:	06                   	push   es
    4c91:	57                   	push   di
    4c92:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c95:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c99:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4c9e:	9b de c1             	faddp  st(1),st
    4ca1:	83 ec 08             	sub    sp,0x8
    4ca4:	89 e3                	mov    bx,sp
    4ca6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4caa:	90                   	nop
    4cab:	9b                   	fwait
    4cac:	8d be 00 ff          	lea    di,[bp-0x100]
    4cb0:	16                   	push   ss
    4cb1:	57                   	push   di
    4cb2:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4cb6:	06                   	push   es
    4cb7:	57                   	push   di
    4cb8:	9a 9b 3b f0 4c       	call   0x4cf0:0x3b9b
    4cbd:	89 c7                	mov    di,ax
    4cbf:	8e c2                	mov    es,dx
    4cc1:	06                   	push   es
    4cc2:	57                   	push   di
    4cc3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cc6:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4cca:	bf 4f 45             	mov    di,0x454f
    4ccd:	0e                   	push   cs
    4cce:	57                   	push   di
    4ccf:	8d be 00 ff          	lea    di,[bp-0x100]
    4cd3:	16                   	push   ss
    4cd4:	57                   	push   di
    4cd5:	68 ff 00             	push   0xff
    4cd8:	9a e7 17 68 4d       	call   0x4d68:0x17e7
    4cdd:	8d be 00 ff          	lea    di,[bp-0x100]
    4ce1:	16                   	push   ss
    4ce2:	57                   	push   di
    4ce3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ce6:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4ceb:	06                   	push   es
    4cec:	57                   	push   di
    4ced:	9a 9b 3b 17 4d       	call   0x4d17:0x3b9b
    4cf2:	89 c7                	mov    di,ax
    4cf4:	8e c2                	mov    es,dx
    4cf6:	06                   	push   es
    4cf7:	57                   	push   di
    4cf8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cfb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cff:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4d04:	8d be 00 ff          	lea    di,[bp-0x100]
    4d08:	16                   	push   ss
    4d09:	57                   	push   di
    4d0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d0d:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4d12:	06                   	push   es
    4d13:	57                   	push   di
    4d14:	9a 9b 3b 48 4d       	call   0x4d48:0x3b9b
    4d19:	89 c7                	mov    di,ax
    4d1b:	8e c2                	mov    es,dx
    4d1d:	06                   	push   es
    4d1e:	57                   	push   di
    4d1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d22:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d26:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4d2b:	9b de c1             	faddp  st(1),st
    4d2e:	83 ec 08             	sub    sp,0x8
    4d31:	89 e3                	mov    bx,sp
    4d33:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d37:	90                   	nop
    4d38:	9b                   	fwait
    4d39:	8d be 00 ff          	lea    di,[bp-0x100]
    4d3d:	16                   	push   ss
    4d3e:	57                   	push   di
    4d3f:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4d43:	06                   	push   es
    4d44:	57                   	push   di
    4d45:	9a 9b 3b 7d 4d       	call   0x4d7d:0x3b9b
    4d4a:	89 c7                	mov    di,ax
    4d4c:	8e c2                	mov    es,dx
    4d4e:	06                   	push   es
    4d4f:	57                   	push   di
    4d50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d53:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4d57:	bf 5e 45             	mov    di,0x455e
    4d5a:	0e                   	push   cs
    4d5b:	57                   	push   di
    4d5c:	8d be 00 ff          	lea    di,[bp-0x100]
    4d60:	16                   	push   ss
    4d61:	57                   	push   di
    4d62:	68 ff 00             	push   0xff
    4d65:	9a e7 17 f5 4d       	call   0x4df5:0x17e7
    4d6a:	8d be 00 ff          	lea    di,[bp-0x100]
    4d6e:	16                   	push   ss
    4d6f:	57                   	push   di
    4d70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d73:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4d78:	06                   	push   es
    4d79:	57                   	push   di
    4d7a:	9a 9b 3b a4 4d       	call   0x4da4:0x3b9b
    4d7f:	89 c7                	mov    di,ax
    4d81:	8e c2                	mov    es,dx
    4d83:	06                   	push   es
    4d84:	57                   	push   di
    4d85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d88:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d8c:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4d91:	8d be 00 ff          	lea    di,[bp-0x100]
    4d95:	16                   	push   ss
    4d96:	57                   	push   di
    4d97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d9a:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4d9f:	06                   	push   es
    4da0:	57                   	push   di
    4da1:	9a 9b 3b d5 4d       	call   0x4dd5:0x3b9b
    4da6:	89 c7                	mov    di,ax
    4da8:	8e c2                	mov    es,dx
    4daa:	06                   	push   es
    4dab:	57                   	push   di
    4dac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4daf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4db3:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4db8:	9b de c1             	faddp  st(1),st
    4dbb:	83 ec 08             	sub    sp,0x8
    4dbe:	89 e3                	mov    bx,sp
    4dc0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4dc4:	90                   	nop
    4dc5:	9b                   	fwait
    4dc6:	8d be 00 ff          	lea    di,[bp-0x100]
    4dca:	16                   	push   ss
    4dcb:	57                   	push   di
    4dcc:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4dd0:	06                   	push   es
    4dd1:	57                   	push   di
    4dd2:	9a 9b 3b 0a 4e       	call   0x4e0a:0x3b9b
    4dd7:	89 c7                	mov    di,ax
    4dd9:	8e c2                	mov    es,dx
    4ddb:	06                   	push   es
    4ddc:	57                   	push   di
    4ddd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4de0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4de4:	bf 68 45             	mov    di,0x4568
    4de7:	0e                   	push   cs
    4de8:	57                   	push   di
    4de9:	8d be 00 ff          	lea    di,[bp-0x100]
    4ded:	16                   	push   ss
    4dee:	57                   	push   di
    4def:	68 ff 00             	push   0xff
    4df2:	9a e7 17 82 4e       	call   0x4e82:0x17e7
    4df7:	8d be 00 ff          	lea    di,[bp-0x100]
    4dfb:	16                   	push   ss
    4dfc:	57                   	push   di
    4dfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e00:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4e05:	06                   	push   es
    4e06:	57                   	push   di
    4e07:	9a 9b 3b 31 4e       	call   0x4e31:0x3b9b
    4e0c:	89 c7                	mov    di,ax
    4e0e:	8e c2                	mov    es,dx
    4e10:	06                   	push   es
    4e11:	57                   	push   di
    4e12:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e15:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4e19:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4e1e:	8d be 00 ff          	lea    di,[bp-0x100]
    4e22:	16                   	push   ss
    4e23:	57                   	push   di
    4e24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e27:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4e2c:	06                   	push   es
    4e2d:	57                   	push   di
    4e2e:	9a 9b 3b 62 4e       	call   0x4e62:0x3b9b
    4e33:	89 c7                	mov    di,ax
    4e35:	8e c2                	mov    es,dx
    4e37:	06                   	push   es
    4e38:	57                   	push   di
    4e39:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e3c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4e40:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4e45:	9b de c1             	faddp  st(1),st
    4e48:	83 ec 08             	sub    sp,0x8
    4e4b:	89 e3                	mov    bx,sp
    4e4d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4e51:	90                   	nop
    4e52:	9b                   	fwait
    4e53:	8d be 00 ff          	lea    di,[bp-0x100]
    4e57:	16                   	push   ss
    4e58:	57                   	push   di
    4e59:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4e5d:	06                   	push   es
    4e5e:	57                   	push   di
    4e5f:	9a 9b 3b 97 4e       	call   0x4e97:0x3b9b
    4e64:	89 c7                	mov    di,ax
    4e66:	8e c2                	mov    es,dx
    4e68:	06                   	push   es
    4e69:	57                   	push   di
    4e6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e6d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4e71:	bf 79 45             	mov    di,0x4579
    4e74:	0e                   	push   cs
    4e75:	57                   	push   di
    4e76:	8d be 00 ff          	lea    di,[bp-0x100]
    4e7a:	16                   	push   ss
    4e7b:	57                   	push   di
    4e7c:	68 ff 00             	push   0xff
    4e7f:	9a e7 17 43 51       	call   0x5143:0x17e7
    4e84:	8d be 00 ff          	lea    di,[bp-0x100]
    4e88:	16                   	push   ss
    4e89:	57                   	push   di
    4e8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e8d:	26 c4 bd 04 02       	les    di,DWORD PTR es:[di+0x204]
    4e92:	06                   	push   es
    4e93:	57                   	push   di
    4e94:	9a 9b 3b be 4e       	call   0x4ebe:0x3b9b
    4e99:	89 c7                	mov    di,ax
    4e9b:	8e c2                	mov    es,dx
    4e9d:	06                   	push   es
    4e9e:	57                   	push   di
    4e9f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ea2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ea6:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    4eab:	8d be 00 ff          	lea    di,[bp-0x100]
    4eaf:	16                   	push   ss
    4eb0:	57                   	push   di
    4eb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eb4:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    4eb9:	06                   	push   es
    4eba:	57                   	push   di
    4ebb:	9a 9b 3b e8 4e       	call   0x4ee8:0x3b9b
    4ec0:	89 c7                	mov    di,ax
    4ec2:	8e c2                	mov    es,dx
    4ec4:	06                   	push   es
    4ec5:	57                   	push   di
    4ec6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ec9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ecd:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    4ed2:	9b de c1             	faddp  st(1),st
    4ed5:	9b db be d0 fe       	fstp   TBYTE PTR [bp-0x130]
    4eda:	bf 8c 45             	mov    di,0x458c
    4edd:	0e                   	push   cs
    4ede:	57                   	push   di
    4edf:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4ee3:	06                   	push   es
    4ee4:	57                   	push   di
    4ee5:	9a 9b 3b 12 4f       	call   0x4f12:0x3b9b
    4eea:	89 c7                	mov    di,ax
    4eec:	8e c2                	mov    es,dx
    4eee:	06                   	push   es
    4eef:	57                   	push   di
    4ef0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ef3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ef7:	9b db ae d0 fe       	fld    TBYTE PTR [bp-0x130]
    4efc:	9b de c1             	faddp  st(1),st
    4eff:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    4f04:	bf 9f 45             	mov    di,0x459f
    4f07:	0e                   	push   cs
    4f08:	57                   	push   di
    4f09:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4f0d:	06                   	push   es
    4f0e:	57                   	push   di
    4f0f:	9a 9b 3b 3c 4f       	call   0x4f3c:0x3b9b
    4f14:	89 c7                	mov    di,ax
    4f16:	8e c2                	mov    es,dx
    4f18:	06                   	push   es
    4f19:	57                   	push   di
    4f1a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f1d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4f21:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    4f26:	9b de c1             	faddp  st(1),st
    4f29:	9b db be bc fe       	fstp   TBYTE PTR [bp-0x144]
    4f2e:	bf ac 45             	mov    di,0x45ac
    4f31:	0e                   	push   cs
    4f32:	57                   	push   di
    4f33:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4f37:	06                   	push   es
    4f38:	57                   	push   di
    4f39:	9a 9b 3b 66 4f       	call   0x4f66:0x3b9b
    4f3e:	89 c7                	mov    di,ax
    4f40:	8e c2                	mov    es,dx
    4f42:	06                   	push   es
    4f43:	57                   	push   di
    4f44:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f47:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4f4b:	9b db ae bc fe       	fld    TBYTE PTR [bp-0x144]
    4f50:	9b de c1             	faddp  st(1),st
    4f53:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    4f58:	bf b9 45             	mov    di,0x45b9
    4f5b:	0e                   	push   cs
    4f5c:	57                   	push   di
    4f5d:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4f61:	06                   	push   es
    4f62:	57                   	push   di
    4f63:	9a 9b 3b 90 4f       	call   0x4f90:0x3b9b
    4f68:	89 c7                	mov    di,ax
    4f6a:	8e c2                	mov    es,dx
    4f6c:	06                   	push   es
    4f6d:	57                   	push   di
    4f6e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f71:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4f75:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    4f7a:	9b de c1             	faddp  st(1),st
    4f7d:	9b db be a8 fe       	fstp   TBYTE PTR [bp-0x158]
    4f82:	bf c7 45             	mov    di,0x45c7
    4f85:	0e                   	push   cs
    4f86:	57                   	push   di
    4f87:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4f8b:	06                   	push   es
    4f8c:	57                   	push   di
    4f8d:	9a 9b 3b ba 4f       	call   0x4fba:0x3b9b
    4f92:	89 c7                	mov    di,ax
    4f94:	8e c2                	mov    es,dx
    4f96:	06                   	push   es
    4f97:	57                   	push   di
    4f98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f9b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4f9f:	9b db ae a8 fe       	fld    TBYTE PTR [bp-0x158]
    4fa4:	9b de c1             	faddp  st(1),st
    4fa7:	9b db be 9e fe       	fstp   TBYTE PTR [bp-0x162]
    4fac:	bf dc 45             	mov    di,0x45dc
    4faf:	0e                   	push   cs
    4fb0:	57                   	push   di
    4fb1:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4fb5:	06                   	push   es
    4fb6:	57                   	push   di
    4fb7:	9a 9b 3b e4 4f       	call   0x4fe4:0x3b9b
    4fbc:	89 c7                	mov    di,ax
    4fbe:	8e c2                	mov    es,dx
    4fc0:	06                   	push   es
    4fc1:	57                   	push   di
    4fc2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fc5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4fc9:	9b db ae 9e fe       	fld    TBYTE PTR [bp-0x162]
    4fce:	9b de c1             	faddp  st(1),st
    4fd1:	9b db be 94 fe       	fstp   TBYTE PTR [bp-0x16c]
    4fd6:	bf e8 45             	mov    di,0x45e8
    4fd9:	0e                   	push   cs
    4fda:	57                   	push   di
    4fdb:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    4fdf:	06                   	push   es
    4fe0:	57                   	push   di
    4fe1:	9a 9b 3b 0e 50       	call   0x500e:0x3b9b
    4fe6:	89 c7                	mov    di,ax
    4fe8:	8e c2                	mov    es,dx
    4fea:	06                   	push   es
    4feb:	57                   	push   di
    4fec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fef:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ff3:	9b db ae 94 fe       	fld    TBYTE PTR [bp-0x16c]
    4ff8:	9b de c1             	faddp  st(1),st
    4ffb:	9b db be 8a fe       	fstp   TBYTE PTR [bp-0x176]
    5000:	bf fa 45             	mov    di,0x45fa
    5003:	0e                   	push   cs
    5004:	57                   	push   di
    5005:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5009:	06                   	push   es
    500a:	57                   	push   di
    500b:	9a 9b 3b 3c 50       	call   0x503c:0x3b9b
    5010:	89 c7                	mov    di,ax
    5012:	8e c2                	mov    es,dx
    5014:	06                   	push   es
    5015:	57                   	push   di
    5016:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5019:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    501d:	9b db ae 8a fe       	fld    TBYTE PTR [bp-0x176]
    5022:	9b de c1             	faddp  st(1),st
    5025:	9b db be 80 fe       	fstp   TBYTE PTR [bp-0x180]
    502a:	bf 0a 46             	mov    di,0x460a
    502d:	0e                   	push   cs
    502e:	57                   	push   di
    502f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5032:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    5037:	06                   	push   es
    5038:	57                   	push   di
    5039:	9a 9b 3b 6d 50       	call   0x506d:0x3b9b
    503e:	89 c7                	mov    di,ax
    5040:	8e c2                	mov    es,dx
    5042:	06                   	push   es
    5043:	57                   	push   di
    5044:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5047:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    504b:	9b db ae 80 fe       	fld    TBYTE PTR [bp-0x180]
    5050:	9b de c1             	faddp  st(1),st
    5053:	83 ec 08             	sub    sp,0x8
    5056:	89 e3                	mov    bx,sp
    5058:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    505c:	90                   	nop
    505d:	9b                   	fwait
    505e:	8d be 00 ff          	lea    di,[bp-0x100]
    5062:	16                   	push   ss
    5063:	57                   	push   di
    5064:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5068:	06                   	push   es
    5069:	57                   	push   di
    506a:	9a 9b 3b 8a 50       	call   0x508a:0x3b9b
    506f:	89 c7                	mov    di,ax
    5071:	8e c2                	mov    es,dx
    5073:	06                   	push   es
    5074:	57                   	push   di
    5075:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5078:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    507c:	bf ea 44             	mov    di,0x44ea
    507f:	0e                   	push   cs
    5080:	57                   	push   di
    5081:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5085:	06                   	push   es
    5086:	57                   	push   di
    5087:	9a 9b 3b ac 50       	call   0x50ac:0x3b9b
    508c:	89 c7                	mov    di,ax
    508e:	8e c2                	mov    es,dx
    5090:	06                   	push   es
    5091:	57                   	push   di
    5092:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5095:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5099:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    509e:	bf 79 45             	mov    di,0x4579
    50a1:	0e                   	push   cs
    50a2:	57                   	push   di
    50a3:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    50a7:	06                   	push   es
    50a8:	57                   	push   di
    50a9:	9a 9b 3b dc 50       	call   0x50dc:0x3b9b
    50ae:	89 c7                	mov    di,ax
    50b0:	8e c2                	mov    es,dx
    50b2:	06                   	push   es
    50b3:	57                   	push   di
    50b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50b7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    50bb:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    50c0:	9b de e1             	fsubrp st(1),st
    50c3:	83 ec 08             	sub    sp,0x8
    50c6:	89 e3                	mov    bx,sp
    50c8:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    50cc:	90                   	nop
    50cd:	9b                   	fwait
    50ce:	bf 11 46             	mov    di,0x4611
    50d1:	0e                   	push   cs
    50d2:	57                   	push   di
    50d3:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    50d7:	06                   	push   es
    50d8:	57                   	push   di
    50d9:	9a 9b 3b fd 50       	call   0x50fd:0x3b9b
    50de:	89 c7                	mov    di,ax
    50e0:	8e c2                	mov    es,dx
    50e2:	06                   	push   es
    50e3:	57                   	push   di
    50e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50e7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    50eb:	bf 37 46             	mov    di,0x4637
    50ee:	0e                   	push   cs
    50ef:	57                   	push   di
    50f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50f3:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    50f8:	06                   	push   es
    50f9:	57                   	push   di
    50fa:	9a 9b 3b 23 51       	call   0x5123:0x3b9b
    50ff:	89 c7                	mov    di,ax
    5101:	8e c2                	mov    es,dx
    5103:	06                   	push   es
    5104:	57                   	push   di
    5105:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5108:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    510c:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    5111:	bf 42 46             	mov    di,0x4642
    5114:	0e                   	push   cs
    5115:	57                   	push   di
    5116:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5119:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    511e:	06                   	push   es
    511f:	57                   	push   di
    5120:	9a 9b 3b 6e 51       	call   0x516e:0x3b9b
    5125:	89 c7                	mov    di,ax
    5127:	8e c2                	mov    es,dx
    5129:	06                   	push   es
    512a:	57                   	push   di
    512b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    512e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5132:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    5137:	9b de c9             	fmulp  st(1),st
    513a:	9b 2e d9 06 50 46    	fld    DWORD PTR cs:0x4650
    5140:	9a b2 04 d5 51       	call   0x51d5:0x4b2
    5145:	83 ec 08             	sub    sp,0x8
    5148:	89 e3                	mov    bx,sp
    514a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    514e:	90                   	nop
    514f:	9b                   	fwait
    5150:	9a a6 2f e5 51       	call   0x51e5:0x2fa6
    5155:	83 ec 08             	sub    sp,0x8
    5158:	89 e3                	mov    bx,sp
    515a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    515e:	90                   	nop
    515f:	9b                   	fwait
    5160:	bf 26 46             	mov    di,0x4626
    5163:	0e                   	push   cs
    5164:	57                   	push   di
    5165:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5169:	06                   	push   es
    516a:	57                   	push   di
    516b:	9a 9b 3b 8f 51       	call   0x518f:0x3b9b
    5170:	89 c7                	mov    di,ax
    5172:	8e c2                	mov    es,dx
    5174:	06                   	push   es
    5175:	57                   	push   di
    5176:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5179:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    517d:	bf 65 46             	mov    di,0x4665
    5180:	0e                   	push   cs
    5181:	57                   	push   di
    5182:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5185:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    518a:	06                   	push   es
    518b:	57                   	push   di
    518c:	9a 9b 3b b5 51       	call   0x51b5:0x3b9b
    5191:	89 c7                	mov    di,ax
    5193:	8e c2                	mov    es,dx
    5195:	06                   	push   es
    5196:	57                   	push   di
    5197:	26 c4 3d             	les    di,DWORD PTR es:[di]
    519a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    519e:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    51a3:	bf 73 46             	mov    di,0x4673
    51a6:	0e                   	push   cs
    51a7:	57                   	push   di
    51a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ab:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    51b0:	06                   	push   es
    51b1:	57                   	push   di
    51b2:	9a 9b 3b fe 51       	call   0x51fe:0x3b9b
    51b7:	89 c7                	mov    di,ax
    51b9:	8e c2                	mov    es,dx
    51bb:	06                   	push   es
    51bc:	57                   	push   di
    51bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51c0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    51c4:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    51c9:	9b de c9             	fmulp  st(1),st
    51cc:	9b 2e d9 06 50 46    	fld    DWORD PTR cs:0x4650
    51d2:	9a b2 04 44 52       	call   0x5244:0x4b2
    51d7:	83 ec 08             	sub    sp,0x8
    51da:	89 e3                	mov    bx,sp
    51dc:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    51e0:	90                   	nop
    51e1:	9b                   	fwait
    51e2:	9a a6 2f 54 52       	call   0x5254:0x2fa6
    51e7:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    51ec:	bf 85 46             	mov    di,0x4685
    51ef:	0e                   	push   cs
    51f0:	57                   	push   di
    51f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51f4:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    51f9:	06                   	push   es
    51fa:	57                   	push   di
    51fb:	9a 9b 3b 24 52       	call   0x5224:0x3b9b
    5200:	89 c7                	mov    di,ax
    5202:	8e c2                	mov    es,dx
    5204:	06                   	push   es
    5205:	57                   	push   di
    5206:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5209:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    520d:	9b db be d0 fe       	fstp   TBYTE PTR [bp-0x130]
    5212:	bf 94 46             	mov    di,0x4694
    5215:	0e                   	push   cs
    5216:	57                   	push   di
    5217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    521a:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    521f:	06                   	push   es
    5220:	57                   	push   di
    5221:	9a 9b 3b 75 52       	call   0x5275:0x3b9b
    5226:	89 c7                	mov    di,ax
    5228:	8e c2                	mov    es,dx
    522a:	06                   	push   es
    522b:	57                   	push   di
    522c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    522f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5233:	9b db ae d0 fe       	fld    TBYTE PTR [bp-0x130]
    5238:	9b de c9             	fmulp  st(1),st
    523b:	9b 2e d9 06 50 46    	fld    DWORD PTR cs:0x4650
    5241:	9a b2 04 bb 52       	call   0x52bb:0x4b2
    5246:	83 ec 08             	sub    sp,0x8
    5249:	89 e3                	mov    bx,sp
    524b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    524f:	90                   	nop
    5250:	9b                   	fwait
    5251:	9a a6 2f cb 52       	call   0x52cb:0x2fa6
    5256:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    525b:	9b de c1             	faddp  st(1),st
    525e:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    5263:	bf a7 46             	mov    di,0x46a7
    5266:	0e                   	push   cs
    5267:	57                   	push   di
    5268:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    526b:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    5270:	06                   	push   es
    5271:	57                   	push   di
    5272:	9a 9b 3b 9b 52       	call   0x529b:0x3b9b
    5277:	89 c7                	mov    di,ax
    5279:	8e c2                	mov    es,dx
    527b:	06                   	push   es
    527c:	57                   	push   di
    527d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5280:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5284:	9b db be bc fe       	fstp   TBYTE PTR [bp-0x144]
    5289:	bf af 46             	mov    di,0x46af
    528c:	0e                   	push   cs
    528d:	57                   	push   di
    528e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5291:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    5296:	06                   	push   es
    5297:	57                   	push   di
    5298:	9a 9b 3b ee 52       	call   0x52ee:0x3b9b
    529d:	89 c7                	mov    di,ax
    529f:	8e c2                	mov    es,dx
    52a1:	06                   	push   es
    52a2:	57                   	push   di
    52a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52a6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    52aa:	9b db ae bc fe       	fld    TBYTE PTR [bp-0x144]
    52af:	9b de c9             	fmulp  st(1),st
    52b2:	9b 2e d9 06 50 46    	fld    DWORD PTR cs:0x4650
    52b8:	9a b2 04 99 55       	call   0x5599:0x4b2
    52bd:	83 ec 08             	sub    sp,0x8
    52c0:	89 e3                	mov    bx,sp
    52c2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    52c6:	90                   	nop
    52c7:	9b                   	fwait
    52c8:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    52cd:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    52d2:	9b de c1             	faddp  st(1),st
    52d5:	83 ec 08             	sub    sp,0x8
    52d8:	89 e3                	mov    bx,sp
    52da:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    52de:	90                   	nop
    52df:	9b                   	fwait
    52e0:	bf 54 46             	mov    di,0x4654
    52e3:	0e                   	push   cs
    52e4:	57                   	push   di
    52e5:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    52e9:	06                   	push   es
    52ea:	57                   	push   di
    52eb:	9a 9b 3b 0b 53       	call   0x530b:0x3b9b
    52f0:	89 c7                	mov    di,ax
    52f2:	8e c2                	mov    es,dx
    52f4:	06                   	push   es
    52f5:	57                   	push   di
    52f6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52f9:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    52fd:	bf 26 46             	mov    di,0x4626
    5300:	0e                   	push   cs
    5301:	57                   	push   di
    5302:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5306:	06                   	push   es
    5307:	57                   	push   di
    5308:	9a 9b 3b 2d 53       	call   0x532d:0x3b9b
    530d:	89 c7                	mov    di,ax
    530f:	8e c2                	mov    es,dx
    5311:	06                   	push   es
    5312:	57                   	push   di
    5313:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5316:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    531a:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    531f:	bf 54 46             	mov    di,0x4654
    5322:	0e                   	push   cs
    5323:	57                   	push   di
    5324:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5328:	06                   	push   es
    5329:	57                   	push   di
    532a:	9a 9b 3b 5d 53       	call   0x535d:0x3b9b
    532f:	89 c7                	mov    di,ax
    5331:	8e c2                	mov    es,dx
    5333:	06                   	push   es
    5334:	57                   	push   di
    5335:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5338:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    533c:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    5341:	9b de e1             	fsubrp st(1),st
    5344:	83 ec 08             	sub    sp,0x8
    5347:	89 e3                	mov    bx,sp
    5349:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    534d:	90                   	nop
    534e:	9b                   	fwait
    534f:	bf bb 46             	mov    di,0x46bb
    5352:	0e                   	push   cs
    5353:	57                   	push   di
    5354:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5358:	06                   	push   es
    5359:	57                   	push   di
    535a:	9a 9b 3b 7e 53       	call   0x537e:0x3b9b
    535f:	89 c7                	mov    di,ax
    5361:	8e c2                	mov    es,dx
    5363:	06                   	push   es
    5364:	57                   	push   di
    5365:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5368:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    536c:	bf cd 46             	mov    di,0x46cd
    536f:	0e                   	push   cs
    5370:	57                   	push   di
    5371:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5374:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    5379:	06                   	push   es
    537a:	57                   	push   di
    537b:	9a 9b 3b 02 54       	call   0x5402:0x3b9b
    5380:	89 c7                	mov    di,ax
    5382:	8e c2                	mov    es,dx
    5384:	06                   	push   es
    5385:	57                   	push   di
    5386:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5389:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    538d:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    5392:	90                   	nop
    5393:	9b 9b dd 86 f8 fe    	fld    QWORD PTR [bp-0x108]
    5399:	9b 2e d8 1e e1 46    	fcomp  DWORD PTR cs:0x46e1
    539f:	9b dd be e2 fe       	fstsw  WORD PTR [bp-0x11e]
    53a4:	90                   	nop
    53a5:	9b                   	fwait
    53a6:	8a a6 e3 fe          	mov    ah,BYTE PTR [bp-0x11d]
    53aa:	9e                   	sahf
    53ab:	76 1b                	jbe    0x53c8
    53ad:	9b dd 86 f8 fe       	fld    QWORD PTR [bp-0x108]
    53b2:	9b dd 9e f0 fe       	fstp   QWORD PTR [bp-0x110]
    53b7:	90                   	nop
    53b8:	9b                   	fwait
    53b9:	9b 2e d9 06 e1 46    	fld    DWORD PTR cs:0x46e1
    53bf:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    53c4:	90                   	nop
    53c5:	9b                   	fwait
    53c6:	eb 1c                	jmp    0x53e4
    53c8:	9b dd 86 f8 fe       	fld    QWORD PTR [bp-0x108]
    53cd:	9b d9 e0             	fchs
    53d0:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    53d5:	90                   	nop
    53d6:	9b                   	fwait
    53d7:	9b 2e d9 06 e1 46    	fld    DWORD PTR cs:0x46e1
    53dd:	9b dd 9e f0 fe       	fstp   QWORD PTR [bp-0x110]
    53e2:	90                   	nop
    53e3:	9b                   	fwait
    53e4:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    53e8:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    53ec:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    53f0:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    53f4:	bf e5 46             	mov    di,0x46e5
    53f7:	0e                   	push   cs
    53f8:	57                   	push   di
    53f9:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    53fd:	06                   	push   es
    53fe:	57                   	push   di
    53ff:	9a 9b 3b 2f 54       	call   0x542f:0x3b9b
    5404:	89 c7                	mov    di,ax
    5406:	8e c2                	mov    es,dx
    5408:	06                   	push   es
    5409:	57                   	push   di
    540a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    540d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5411:	ff b6 ee fe          	push   WORD PTR [bp-0x112]
    5415:	ff b6 ec fe          	push   WORD PTR [bp-0x114]
    5419:	ff b6 ea fe          	push   WORD PTR [bp-0x116]
    541d:	ff b6 e8 fe          	push   WORD PTR [bp-0x118]
    5421:	bf f0 46             	mov    di,0x46f0
    5424:	0e                   	push   cs
    5425:	57                   	push   di
    5426:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    542a:	06                   	push   es
    542b:	57                   	push   di
    542c:	9a 9b 3b 4c 54       	call   0x544c:0x3b9b
    5431:	89 c7                	mov    di,ax
    5433:	8e c2                	mov    es,dx
    5435:	06                   	push   es
    5436:	57                   	push   di
    5437:	26 c4 3d             	les    di,DWORD PTR es:[di]
    543a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    543e:	bf 11 46             	mov    di,0x4611
    5441:	0e                   	push   cs
    5442:	57                   	push   di
    5443:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5447:	06                   	push   es
    5448:	57                   	push   di
    5449:	9a 9b 3b 6e 54       	call   0x546e:0x3b9b
    544e:	89 c7                	mov    di,ax
    5450:	8e c2                	mov    es,dx
    5452:	06                   	push   es
    5453:	57                   	push   di
    5454:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5457:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    545b:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    5460:	bf bb 46             	mov    di,0x46bb
    5463:	0e                   	push   cs
    5464:	57                   	push   di
    5465:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5469:	06                   	push   es
    546a:	57                   	push   di
    546b:	9a 9b 3b 9c 54       	call   0x549c:0x3b9b
    5470:	89 c7                	mov    di,ax
    5472:	8e c2                	mov    es,dx
    5474:	06                   	push   es
    5475:	57                   	push   di
    5476:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5479:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    547d:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    5482:	9b de c1             	faddp  st(1),st
    5485:	9b db be d0 fe       	fstp   TBYTE PTR [bp-0x130]
    548a:	bf cd 46             	mov    di,0x46cd
    548d:	0e                   	push   cs
    548e:	57                   	push   di
    548f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5492:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    5497:	06                   	push   es
    5498:	57                   	push   di
    5499:	9a 9b 3b c6 54       	call   0x54c6:0x3b9b
    549e:	89 c7                	mov    di,ax
    54a0:	8e c2                	mov    es,dx
    54a2:	06                   	push   es
    54a3:	57                   	push   di
    54a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54a7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    54ab:	9b db ae d0 fe       	fld    TBYTE PTR [bp-0x130]
    54b0:	9b de c1             	faddp  st(1),st
    54b3:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    54b8:	bf 0d 47             	mov    di,0x470d
    54bb:	0e                   	push   cs
    54bc:	57                   	push   di
    54bd:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    54c1:	06                   	push   es
    54c2:	57                   	push   di
    54c3:	9a 9b 3b f6 54       	call   0x54f6:0x3b9b
    54c8:	89 c7                	mov    di,ax
    54ca:	8e c2                	mov    es,dx
    54cc:	06                   	push   es
    54cd:	57                   	push   di
    54ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54d1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    54d5:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    54da:	9b de c1             	faddp  st(1),st
    54dd:	83 ec 08             	sub    sp,0x8
    54e0:	89 e3                	mov    bx,sp
    54e2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    54e6:	90                   	nop
    54e7:	9b                   	fwait
    54e8:	bf fa 46             	mov    di,0x46fa
    54eb:	0e                   	push   cs
    54ec:	57                   	push   di
    54ed:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    54f1:	06                   	push   es
    54f2:	57                   	push   di
    54f3:	9a 9b 3b 13 55       	call   0x5513:0x3b9b
    54f8:	89 c7                	mov    di,ax
    54fa:	8e c2                	mov    es,dx
    54fc:	06                   	push   es
    54fd:	57                   	push   di
    54fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5501:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5505:	bf fa 46             	mov    di,0x46fa
    5508:	0e                   	push   cs
    5509:	57                   	push   di
    550a:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    550e:	06                   	push   es
    550f:	57                   	push   di
    5510:	9a 9b 3b 35 55       	call   0x5535:0x3b9b
    5515:	89 c7                	mov    di,ax
    5517:	8e c2                	mov    es,dx
    5519:	06                   	push   es
    551a:	57                   	push   di
    551b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    551e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5522:	9b db be da fe       	fstp   TBYTE PTR [bp-0x126]
    5527:	bf 2e 47             	mov    di,0x472e
    552a:	0e                   	push   cs
    552b:	57                   	push   di
    552c:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5530:	06                   	push   es
    5531:	57                   	push   di
    5532:	9a 9b 3b 65 55       	call   0x5565:0x3b9b
    5537:	89 c7                	mov    di,ax
    5539:	8e c2                	mov    es,dx
    553b:	06                   	push   es
    553c:	57                   	push   di
    553d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5540:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5544:	9b db ae da fe       	fld    TBYTE PTR [bp-0x126]
    5549:	9b de e1             	fsubrp st(1),st
    554c:	83 ec 08             	sub    sp,0x8
    554f:	89 e3                	mov    bx,sp
    5551:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5555:	90                   	nop
    5556:	9b                   	fwait
    5557:	bf 1b 47             	mov    di,0x471b
    555a:	0e                   	push   cs
    555b:	57                   	push   di
    555c:	c4 be e4 fe          	les    di,DWORD PTR [bp-0x11c]
    5560:	06                   	push   es
    5561:	57                   	push   di
    5562:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    5567:	89 c7                	mov    di,ax
    5569:	8e c2                	mov    es,dx
    556b:	06                   	push   es
    556c:	57                   	push   di
    556d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5570:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5574:	c9                   	leave
    5575:	ca 08 00             	retf   0x8
    5578:	5d                   	pop    bp
    5579:	56                   	push   si
    557a:	38 56 e9             	cmp    BYTE PTR [bp-0x17],dl
    557d:	55                   	push   bp
    557e:	da 55 86             	ficom  DWORD PTR [di-0x7a]
    5581:	56                   	push   si
    5582:	19 56 86             	sbb    WORD PTR [bp-0x7a],dx
    5585:	56                   	push   si
    5586:	fa                   	cli
    5587:	55                   	push   bp
    5588:	00 00                	add    BYTE PTR [bx+si],al
    558a:	00 00                	add    BYTE PTR [bx+si],al
    558c:	ff 00                	inc    WORD PTR [bx+si]
    558e:	00 00                	add    BYTE PTR [bx+si],al
    5590:	55                   	push   bp
    5591:	89 e5                	mov    bp,sp
    5593:	b8 04 00             	mov    ax,0x4
    5596:	9a 44 04 0a 56       	call   0x560a:0x444
    559b:	83 ec 04             	sub    sp,0x4
    559e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55a1:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    55a6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    55a9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    55ac:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    55b0:	b0 00                	mov    al,0x0
    55b2:	74 01                	je     0x55b5
    55b4:	40                   	inc    ax
    55b5:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    55b9:	08 c0                	or     al,al
    55bb:	75 03                	jne    0x55c0
    55bd:	e9 ee 00             	jmp    0x56ae
    55c0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    55c3:	26 8b 05             	mov    ax,WORD PTR es:[di]
    55c6:	2d 21 00             	sub    ax,0x21
    55c9:	3d 07 00             	cmp    ax,0x7
    55cc:	76 03                	jbe    0x55d1
    55ce:	e9 b5 00             	jmp    0x5686
    55d1:	89 c3                	mov    bx,ax
    55d3:	d1 e3                	shl    bx,1
    55d5:	2e ff a7 78 55       	jmp    WORD PTR cs:[bx+0x5578]
    55da:	6a 00                	push   0x0
    55dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55df:	06                   	push   es
    55e0:	57                   	push   di
    55e1:	9a d0 1c f5 55       	call   0x55f5:0x1cd0
    55e6:	e9 9d 00             	jmp    0x5686
    55e9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55ec:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    55f0:	06                   	push   es
    55f1:	57                   	push   di
    55f2:	9a d0 1c 15 56       	call   0x5615:0x1cd0
    55f7:	e9 8c 00             	jmp    0x5686
    55fa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55fd:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5601:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    5605:	71 05                	jno    0x560c
    5607:	9a 3e 04 29 56       	call   0x5629:0x43e
    560c:	50                   	push   ax
    560d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5610:	06                   	push   es
    5611:	57                   	push   di
    5612:	9a d0 1c 34 56       	call   0x5634:0x1cd0
    5617:	eb 6d                	jmp    0x5686
    5619:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    561c:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5620:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    5624:	71 05                	jno    0x562b
    5626:	9a 3e 04 4e 56       	call   0x564e:0x43e
    562b:	50                   	push   ax
    562c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    562f:	06                   	push   es
    5630:	57                   	push   di
    5631:	9a d0 1c 59 56       	call   0x5659:0x1cd0
    5636:	eb 4e                	jmp    0x5686
    5638:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    563b:	06                   	push   es
    563c:	57                   	push   di
    563d:	9a f4 18 65 56       	call   0x5665:0x18f4
    5642:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5645:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    5649:	71 05                	jno    0x5650
    564b:	9a 3e 04 77 56       	call   0x5677:0x43e
    5650:	50                   	push   ax
    5651:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5654:	06                   	push   es
    5655:	57                   	push   di
    5656:	9a d0 1c 82 56       	call   0x5682:0x1cd0
    565b:	eb 29                	jmp    0x5686
    565d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5660:	06                   	push   es
    5661:	57                   	push   di
    5662:	9a f4 18 9f 58       	call   0x589f:0x18f4
    5667:	8b d0                	mov    dx,ax
    5669:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    566c:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5670:	2b c2                	sub    ax,dx
    5672:	71 05                	jno    0x5679
    5674:	9a 3e 04 94 56       	call   0x5694:0x43e
    5679:	50                   	push   ax
    567a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    567d:	06                   	push   es
    567e:	57                   	push   di
    567f:	9a d0 1c f3 56       	call   0x56f3:0x1cd0
    5684:	eb 00                	jmp    0x5686
    5686:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5689:	26 8b 05             	mov    ax,WORD PTR es:[di]
    568c:	31 d2                	xor    dx,dx
    568e:	bf 88 55             	mov    di,0x5588
    5691:	9a 16 04 e8 56       	call   0x56e8:0x416
    5696:	3c 21                	cmp    al,0x21
    5698:	72 14                	jb     0x56ae
    569a:	3c 24                	cmp    al,0x24
    569c:	76 08                	jbe    0x56a6
    569e:	3c 26                	cmp    al,0x26
    56a0:	74 04                	je     0x56a6
    56a2:	3c 28                	cmp    al,0x28
    56a4:	75 08                	jne    0x56ae
    56a6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    56a9:	31 c0                	xor    ax,ax
    56ab:	26 89 05             	mov    WORD PTR es:[di],ax
    56ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56b1:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    56b6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    56b9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    56bc:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    56c0:	b0 00                	mov    al,0x0
    56c2:	74 01                	je     0x56c5
    56c4:	40                   	inc    ax
    56c5:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    56c9:	08 c0                	or     al,al
    56cb:	74 6e                	je     0x573b
    56cd:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    56d0:	26 8b 05             	mov    ax,WORD PTR es:[di]
    56d3:	3d 27 00             	cmp    ax,0x27
    56d6:	75 1f                	jne    0x56f7
    56d8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    56db:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    56df:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    56e3:	71 05                	jno    0x56ea
    56e5:	9a 3e 04 0c 57       	call   0x570c:0x43e
    56ea:	50                   	push   ax
    56eb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    56ee:	06                   	push   es
    56ef:	57                   	push   di
    56f0:	9a d0 1c 17 57       	call   0x5717:0x1cd0
    56f5:	eb 24                	jmp    0x571b
    56f7:	3d 25 00             	cmp    ax,0x25
    56fa:	75 1f                	jne    0x571b
    56fc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    56ff:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5703:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    5707:	71 05                	jno    0x570e
    5709:	9a 3e 04 29 57       	call   0x5729:0x43e
    570e:	50                   	push   ax
    570f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5712:	06                   	push   es
    5713:	57                   	push   di
    5714:	9a d0 1c 56 57       	call   0x5756:0x1cd0
    5719:	eb 00                	jmp    0x571b
    571b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    571e:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5721:	31 d2                	xor    dx,dx
    5723:	bf 88 55             	mov    di,0x5588
    5726:	9a 16 04 64 57       	call   0x5764:0x416
    572b:	3c 25                	cmp    al,0x25
    572d:	74 04                	je     0x5733
    572f:	3c 27                	cmp    al,0x27
    5731:	75 08                	jne    0x573b
    5733:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5736:	31 c0                	xor    ax,ax
    5738:	26 89 05             	mov    WORD PTR es:[di],ax
    573b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    573e:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    5742:	74 14                	je     0x5758
    5744:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5747:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    574c:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    5751:	06                   	push   es
    5752:	57                   	push   di
    5753:	9a 30 22 81 57       	call   0x5781:0x2230
    5758:	c9                   	leave
    5759:	ca 0e 00             	retf   0xe
    575c:	55                   	push   bp
    575d:	89 e5                	mov    bp,sp
    575f:	31 c0                	xor    ax,ax
    5761:	9a 44 04 8f 57       	call   0x578f:0x444
    5766:	6a 01                	push   0x1
    5768:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    576b:	26 c4 bd 28 04       	les    di,DWORD PTR es:[di+0x428]
    5770:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    5774:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    5778:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    577c:	06                   	push   es
    577d:	57                   	push   di
    577e:	9a b2 77 a0 57       	call   0x57a0:0x77b2
    5783:	c9                   	leave
    5784:	ca 08 00             	retf   0x8
    5787:	55                   	push   bp
    5788:	89 e5                	mov    bp,sp
    578a:	31 c0                	xor    ax,ax
    578c:	9a 44 04 ae 57       	call   0x57ae:0x444
    5791:	6a 03                	push   0x3
    5793:	6a 00                	push   0x0
    5795:	6a 00                	push   0x0
    5797:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    579b:	06                   	push   es
    579c:	57                   	push   di
    579d:	9a b2 77 c1 57       	call   0x57c1:0x77b2
    57a2:	c9                   	leave
    57a3:	ca 08 00             	retf   0x8
    57a6:	55                   	push   bp
    57a7:	89 e5                	mov    bp,sp
    57a9:	31 c0                	xor    ax,ax
    57ab:	9a 44 04 cf 57       	call   0x57cf:0x444
    57b0:	68 05 01             	push   0x105
    57b3:	bf 28 02             	mov    di,0x228
    57b6:	1e                   	push   ds
    57b7:	57                   	push   di
    57b8:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    57bc:	06                   	push   es
    57bd:	57                   	push   di
    57be:	9a b2 77 e0 57       	call   0x57e0:0x77b2
    57c3:	c9                   	leave
    57c4:	ca 08 00             	retf   0x8
    57c7:	55                   	push   bp
    57c8:	89 e5                	mov    bp,sp
    57ca:	31 c0                	xor    ax,ax
    57cc:	9a 44 04 ef 57       	call   0x57ef:0x444
    57d1:	6a 04                	push   0x4
    57d3:	6a 00                	push   0x0
    57d5:	6a 00                	push   0x0
    57d7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    57db:	06                   	push   es
    57dc:	57                   	push   di
    57dd:	9a b2 77 fd 57       	call   0x57fd:0x77b2
    57e2:	c9                   	leave
    57e3:	ca 08 00             	retf   0x8
    57e6:	55                   	push   bp
    57e7:	89 e5                	mov    bp,sp
    57e9:	b8 04 00             	mov    ax,0x4
    57ec:	9a 44 04 0c 58       	call   0x580c:0x444
    57f1:	83 ec 04             	sub    sp,0x4
    57f4:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    57f8:	06                   	push   es
    57f9:	57                   	push   di
    57fa:	9a 45 5d 78 58       	call   0x5878:0x5d45
    57ff:	c9                   	leave
    5800:	ca 08 00             	retf   0x8
    5803:	55                   	push   bp
    5804:	89 e5                	mov    bp,sp
    5806:	b8 04 00             	mov    ax,0x4
    5809:	9a 44 04 87 58       	call   0x5887:0x444
    580e:	83 ec 04             	sub    sp,0x4
    5811:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5814:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    5819:	b0 00                	mov    al,0x0
    581b:	75 01                	jne    0x581e
    581d:	40                   	inc    ax
    581e:	8a c8                	mov    cl,al
    5820:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    5826:	b0 00                	mov    al,0x0
    5828:	77 01                	ja     0x582b
    582a:	40                   	inc    ax
    582b:	8a d0                	mov    dl,al
    582d:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    5833:	b0 00                	mov    al,0x0
    5835:	76 01                	jbe    0x5838
    5837:	40                   	inc    ax
    5838:	22 c2                	and    al,dl
    583a:	0a c1                	or     al,cl
    583c:	08 c0                	or     al,al
    583e:	74 3a                	je     0x587a
    5840:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5844:	31 c0                	xor    ax,ax
    5846:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    584a:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    584e:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    5852:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    5856:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5859:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    585d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5860:	06                   	push   es
    5861:	57                   	push   di
    5862:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5865:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    5869:	6a 02                	push   0x2
    586b:	6a 00                	push   0x0
    586d:	6a 00                	push   0x0
    586f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5873:	06                   	push   es
    5874:	57                   	push   di
    5875:	9a b2 77 07 59       	call   0x5907:0x77b2
    587a:	c9                   	leave
    587b:	ca 0c 00             	retf   0xc
    587e:	55                   	push   bp
    587f:	89 e5                	mov    bp,sp
    5881:	b8 04 00             	mov    ax,0x4
    5884:	9a 44 04 a6 58       	call   0x58a6:0x444
    5889:	83 ec 04             	sub    sp,0x4
    588c:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    5890:	74 03                	je     0x5895
    5892:	e9 9c 00             	jmp    0x5931
    5895:	ff 76 14             	push   WORD PTR [bp+0x14]
    5898:	ff 76 12             	push   WORD PTR [bp+0x12]
    589b:	bf c1 05             	mov    di,0x5c1
    589e:	b8 b9 58             	mov    ax,0x58b9
    58a1:	50                   	push   ax
    58a2:	57                   	push   di
    58a3:	9a 55 22 c0 58       	call   0x58c0:0x2255
    58a8:	08 c0                	or     al,al
    58aa:	75 03                	jne    0x58af
    58ac:	e9 82 00             	jmp    0x5931
    58af:	ff 76 14             	push   WORD PTR [bp+0x14]
    58b2:	ff 76 12             	push   WORD PTR [bp+0x12]
    58b5:	bf c1 05             	mov    di,0x5c1
    58b8:	b8 e8 58             	mov    ax,0x58e8
    58bb:	50                   	push   ax
    58bc:	57                   	push   di
    58bd:	9a 73 22 ef 58       	call   0x58ef:0x2273
    58c2:	89 c7                	mov    di,ax
    58c4:	8e c2                	mov    es,dx
    58c6:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    58cb:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    58d0:	74 5f                	je     0x5931
    58d2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    58d6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    58d9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    58dc:	6a 08                	push   0x8
    58de:	ff 76 14             	push   WORD PTR [bp+0x14]
    58e1:	ff 76 12             	push   WORD PTR [bp+0x12]
    58e4:	bf c1 05             	mov    di,0x5c1
    58e7:	b8 53 59             	mov    ax,0x5953
    58ea:	50                   	push   ax
    58eb:	57                   	push   di
    58ec:	9a 73 22 3e 59       	call   0x593e:0x2273
    58f1:	89 c7                	mov    di,ax
    58f3:	8e c2                	mov    es,dx
    58f5:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    58fa:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    58ff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5902:	06                   	push   es
    5903:	57                   	push   di
    5904:	9a b2 77 11 59       	call   0x5911:0x77b2
    5909:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    590c:	06                   	push   es
    590d:	57                   	push   di
    590e:	9a 03 73 98 59       	call   0x5998:0x7303
    5913:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5916:	06                   	push   es
    5917:	57                   	push   di
    5918:	b8 03 58             	mov    ax,0x5803
    591b:	ba c3 59             	mov    dx,0x59c3
    591e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5921:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    5925:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    5929:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    592d:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    5931:	c9                   	leave
    5932:	ca 10 00             	retf   0x10
    5935:	55                   	push   bp
    5936:	89 e5                	mov    bp,sp
    5938:	b8 04 00             	mov    ax,0x4
    593b:	9a 44 04 5a 59       	call   0x595a:0x444
    5940:	83 ec 04             	sub    sp,0x4
    5943:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    5947:	75 51                	jne    0x599a
    5949:	ff 76 14             	push   WORD PTR [bp+0x14]
    594c:	ff 76 12             	push   WORD PTR [bp+0x12]
    594f:	bf c1 05             	mov    di,0x5c1
    5952:	b8 6a 59             	mov    ax,0x596a
    5955:	50                   	push   ax
    5956:	57                   	push   di
    5957:	9a 55 22 71 59       	call   0x5971:0x2255
    595c:	08 c0                	or     al,al
    595e:	74 3a                	je     0x599a
    5960:	ff 76 14             	push   WORD PTR [bp+0x14]
    5963:	ff 76 12             	push   WORD PTR [bp+0x12]
    5966:	bf c1 05             	mov    di,0x5c1
    5969:	b8 88 5c             	mov    ax,0x5c88
    596c:	50                   	push   ax
    596d:	57                   	push   di
    596e:	9a 73 22 a6 59       	call   0x59a6:0x2273
    5973:	89 c7                	mov    di,ax
    5975:	8e c2                	mov    es,dx
    5977:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    597c:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    5981:	74 17                	je     0x599a
    5983:	6a 08                	push   0x8
    5985:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    598a:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    598f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5993:	06                   	push   es
    5994:	57                   	push   di
    5995:	9a b2 77 d8 7b       	call   0x7bd8:0x77b2
    599a:	c9                   	leave
    599b:	ca 10 00             	retf   0x10
    599e:	55                   	push   bp
    599f:	89 e5                	mov    bp,sp
    59a1:	31 c0                	xor    ax,ax
    59a3:	9a 44 04 da 59       	call   0x59da:0x444
    59a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59ab:	26 c4 bd 88 02       	les    di,DWORD PTR es:[di+0x288]
    59b0:	06                   	push   es
    59b1:	57                   	push   di
    59b2:	9a 17 2f ff ff       	call   0xffff:0x2f17
    59b7:	08 c0                	or     al,al
    59b9:	74 0a                	je     0x59c5
    59bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59be:	06                   	push   es
    59bf:	57                   	push   di
    59c0:	9a 2d 5a 2b 5a       	call   0x5a2b:0x5a2d
    59c5:	c9                   	leave
    59c6:	ca 08 00             	retf   0x8
    59c9:	00 00                	add    BYTE PTR [bx+si],al
    59cb:	00 00                	add    BYTE PTR [bx+si],al
    59cd:	ff                   	(bad)
    59ce:	ff 00                	inc    WORD PTR [bx+si]
    59d0:	00 55 89             	add    BYTE PTR [di-0x77],dl
    59d3:	e5 b8                	in     ax,0xb8
    59d5:	22 00                	and    al,BYTE PTR [bx+si]
    59d7:	9a 44 04 0a 5a       	call   0x5a0a:0x444
    59dc:	83 ec 22             	sub    sp,0x22
    59df:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    59e3:	06                   	push   es
    59e4:	57                   	push   di
    59e5:	9a 04 2a 51 5a       	call   0x5a51:0x2a04
    59ea:	89 c7                	mov    di,ax
    59ec:	8e c2                	mov    es,dx
    59ee:	06                   	push   es
    59ef:	57                   	push   di
    59f0:	9a d2 21 a2 5a       	call   0x5aa2:0x21d2
    59f5:	50                   	push   ax
    59f6:	8d 7e de             	lea    di,[bp-0x22]
    59f9:	16                   	push   ss
    59fa:	57                   	push   di
    59fb:	9a ff ff 00 00       	call   0x0:0xffff
    5a00:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    5a03:	99                   	cwd
    5a04:	bf c9 59             	mov    di,0x59c9
    5a07:	9a 16 04 36 5a       	call   0x5a36:0x416
    5a0c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5a0f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5a12:	c9                   	leave
    5a13:	ca 02 00             	retf   0x2
    5a16:	00 01                	add    BYTE PTR [bx+di],al
    5a18:	09 01                	or     WORD PTR [bx+di],ax
    5a1a:	20 03                	and    BYTE PTR [bp+di],al
    5a1c:	20 20                	and    BYTE PTR [bx+si],ah
    5a1e:	20 00                	and    BYTE PTR [bx+si],al
    5a20:	80 ff ff             	cmp    bh,0xff
    5a23:	ff                   	(bad)
    5a24:	7f 00                	jg     0x5a26
    5a26:	00 00                	add    BYTE PTR [bx+si],al
    5a28:	00 65 5e             	add    BYTE PTR [di+0x5e],ah
    5a2b:	46                   	inc    si
    5a2c:	5a                   	pop    dx
    5a2d:	55                   	push   bp
    5a2e:	89 e5                	mov    bp,sp
    5a30:	b8 0e 04             	mov    ax,0x40e
    5a33:	9a 44 04 5c 5a       	call   0x5a5c:0x444
    5a38:	81 ec 0e 04          	sub    sp,0x40e
    5a3c:	6a 01                	push   0x1
    5a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a41:	06                   	push   es
    5a42:	57                   	push   di
    5a43:	9a 7c 62 4b 5c       	call   0x5c4b:0x627c
    5a48:	8d be fc fe          	lea    di,[bp-0x104]
    5a4c:	16                   	push   ss
    5a4d:	57                   	push   di
    5a4e:	9a 4e 20 7a 5a       	call   0x5a7a:0x204e
    5a53:	8d be fc fe          	lea    di,[bp-0x104]
    5a57:	16                   	push   ss
    5a58:	57                   	push   di
    5a59:	9a f5 09 61 5a       	call   0x5a61:0x9f5
    5a5e:	9a 08 04 f6 5a       	call   0x5af6:0x408
    5a63:	b8 27 5a             	mov    ax,0x5a27
    5a66:	0e                   	push   cs
    5a67:	50                   	push   ax
    5a68:	55                   	push   bp
    5a69:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5a6d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5a71:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5a75:	06                   	push   es
    5a76:	57                   	push   di
    5a77:	9a 04 2a af 5a       	call   0x5aaf:0x2a04
    5a7c:	89 c7                	mov    di,ax
    5a7e:	8e c2                	mov    es,dx
    5a80:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    5a84:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    5a88:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    5a8c:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    5a91:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5a95:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5a99:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5a9d:	06                   	push   es
    5a9e:	57                   	push   di
    5a9f:	9a 99 20 be 5a       	call   0x5abe:0x2099
    5aa4:	6a 0a                	push   0xa
    5aa6:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5aaa:	06                   	push   es
    5aab:	57                   	push   di
    5aac:	9a 04 2a cb 5a       	call   0x5acb:0x2a04
    5ab1:	89 c7                	mov    di,ax
    5ab3:	8e c2                	mov    es,dx
    5ab5:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5ab9:	06                   	push   es
    5aba:	57                   	push   di
    5abb:	9a f5 11 da 5a       	call   0x5ada:0x11f5
    5ac0:	6a 02                	push   0x2
    5ac2:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5ac6:	06                   	push   es
    5ac7:	57                   	push   di
    5ac8:	9a 04 2a 1a 5c       	call   0x5c1a:0x2a04
    5acd:	89 c7                	mov    di,ax
    5acf:	8e c2                	mov    es,dx
    5ad1:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5ad5:	06                   	push   es
    5ad6:	57                   	push   di
    5ad7:	9a 78 12 29 5c       	call   0x5c29:0x1278
    5adc:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    5ae1:	eb 03                	jmp    0x5ae6
    5ae3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5ae6:	8d be fc fe          	lea    di,[bp-0x104]
    5aea:	16                   	push   ss
    5aeb:	57                   	push   di
    5aec:	bf 16 5a             	mov    di,0x5a16
    5aef:	0e                   	push   cs
    5af0:	57                   	push   di
    5af1:	6a 00                	push   0x0
    5af3:	9a b5 0d fb 5a       	call   0x5afb:0xdb5
    5af8:	9a 78 0c 00 5b       	call   0x5b00:0xc78
    5afd:	9a 08 04 2e 5b       	call   0x5b2e:0x408
    5b02:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    5b06:	75 db                	jne    0x5ae3
    5b08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b0b:	26 c4 bd f0 05       	les    di,DWORD PTR es:[di+0x5f0]
    5b10:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    5b14:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    5b18:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b1d:	06                   	push   es
    5b1e:	57                   	push   di
    5b1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b22:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    5b26:	2d 01 00             	sub    ax,0x1
    5b29:	71 05                	jno    0x5b30
    5b2b:	9a 3e 04 6e 5b       	call   0x5b6e:0x43e
    5b30:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    5b34:	31 c0                	xor    ax,ax
    5b36:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    5b3a:	7e 03                	jle    0x5b3f
    5b3c:	e9 c8 00             	jmp    0x5c07
    5b3f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5b42:	eb 03                	jmp    0x5b47
    5b44:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5b47:	8d be f0 fc          	lea    di,[bp-0x310]
    5b4b:	16                   	push   ss
    5b4c:	57                   	push   di
    5b4d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5b50:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5b54:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b59:	06                   	push   es
    5b5a:	57                   	push   di
    5b5b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b5e:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    5b62:	8d be fc fd          	lea    di,[bp-0x204]
    5b66:	16                   	push   ss
    5b67:	57                   	push   di
    5b68:	68 ff 00             	push   0xff
    5b6b:	9a e7 17 7e 5b       	call   0x5b7e:0x17e7
    5b70:	bf 17 5a             	mov    di,0x5a17
    5b73:	0e                   	push   cs
    5b74:	57                   	push   di
    5b75:	8d be fc fd          	lea    di,[bp-0x204]
    5b79:	16                   	push   ss
    5b7a:	57                   	push   di
    5b7b:	9a 78 18 97 5b       	call   0x5b97:0x1878
    5b80:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5b83:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5b87:	7e 26                	jle    0x5baf
    5b89:	8d be fc fd          	lea    di,[bp-0x204]
    5b8d:	16                   	push   ss
    5b8e:	57                   	push   di
    5b8f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5b92:	6a 01                	push   0x1
    5b94:	9a 75 19 ad 5b       	call   0x5bad:0x1975
    5b99:	bf 19 5a             	mov    di,0x5a19
    5b9c:	0e                   	push   cs
    5b9d:	57                   	push   di
    5b9e:	8d be fc fd          	lea    di,[bp-0x204]
    5ba2:	16                   	push   ss
    5ba3:	57                   	push   di
    5ba4:	68 ff 00             	push   0xff
    5ba7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5baa:	9a 16 19 c3 5b       	call   0x5bc3:0x1916
    5baf:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5bb3:	75 bb                	jne    0x5b70
    5bb5:	8d be f0 fc          	lea    di,[bp-0x310]
    5bb9:	16                   	push   ss
    5bba:	57                   	push   di
    5bbb:	bf 1b 5a             	mov    di,0x5a1b
    5bbe:	0e                   	push   cs
    5bbf:	57                   	push   di
    5bc0:	9a cd 17 ce 5b       	call   0x5bce:0x17cd
    5bc5:	8d be fc fd          	lea    di,[bp-0x204]
    5bc9:	16                   	push   ss
    5bca:	57                   	push   di
    5bcb:	9a 4c 18 dc 5b       	call   0x5bdc:0x184c
    5bd0:	8d be fc fd          	lea    di,[bp-0x204]
    5bd4:	16                   	push   ss
    5bd5:	57                   	push   di
    5bd6:	68 ff 00             	push   0xff
    5bd9:	9a e7 17 ef 5b       	call   0x5bef:0x17e7
    5bde:	8d be fc fe          	lea    di,[bp-0x104]
    5be2:	16                   	push   ss
    5be3:	57                   	push   di
    5be4:	8d be fc fd          	lea    di,[bp-0x204]
    5be8:	16                   	push   ss
    5be9:	57                   	push   di
    5bea:	6a 00                	push   0x0
    5bec:	9a b5 0d f4 5b       	call   0x5bf4:0xdb5
    5bf1:	9a 78 0c f9 5b       	call   0x5bf9:0xc78
    5bf6:	9a 08 04 55 5c       	call   0x5c55:0x408
    5bfb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5bfe:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    5c02:	74 03                	je     0x5c07
    5c04:	e9 3d ff             	jmp    0x5b44
    5c07:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5c0b:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    5c0f:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    5c13:	6a 06                	push   0x6
    5c15:	06                   	push   es
    5c16:	57                   	push   di
    5c17:	9a 04 2a 36 5c       	call   0x5c36:0x2a04
    5c1c:	89 c7                	mov    di,ax
    5c1e:	8e c2                	mov    es,dx
    5c20:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5c24:	06                   	push   es
    5c25:	57                   	push   di
    5c26:	9a f5 11 45 5c       	call   0x5c45:0x11f5
    5c2b:	6a 00                	push   0x0
    5c2d:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5c31:	06                   	push   es
    5c32:	57                   	push   di
    5c33:	9a 04 2a b9 5c       	call   0x5cb9:0x2a04
    5c38:	89 c7                	mov    di,ax
    5c3a:	8e c2                	mov    es,dx
    5c3c:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5c40:	06                   	push   es
    5c41:	57                   	push   di
    5c42:	9a 78 12 e0 5c       	call   0x5ce0:0x1278
    5c47:	55                   	push   bp
    5c48:	9a d1 59 a1 5e       	call   0x5ea1:0x59d1
    5c4d:	05 02 00             	add    ax,0x2
    5c50:	73 05                	jae    0x5c57
    5c52:	9a 3e 04 5f 5c       	call   0x5c5f:0x43e
    5c57:	31 d2                	xor    dx,dx
    5c59:	bf 1f 5a             	mov    di,0x5a1f
    5c5c:	9a 16 04 73 5c       	call   0x5c73:0x416
    5c61:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5c65:	8d be f2 fb          	lea    di,[bp-0x40e]
    5c69:	16                   	push   ss
    5c6a:	57                   	push   di
    5c6b:	bf 1b 5a             	mov    di,0x5a1b
    5c6e:	0e                   	push   cs
    5c6f:	57                   	push   di
    5c70:	9a cd 17 8d 5c       	call   0x5c8d:0x17cd
    5c75:	8d be f2 fc          	lea    di,[bp-0x30e]
    5c79:	16                   	push   ss
    5c7a:	57                   	push   di
    5c7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c7e:	26 c4 bd d8 05       	les    di,DWORD PTR es:[di+0x5d8]
    5c83:	06                   	push   es
    5c84:	57                   	push   di
    5c85:	9a 53 1d 05 5d       	call   0x5d05:0x1d53
    5c8a:	9a 4c 18 9b 5c       	call   0x5c9b:0x184c
    5c8f:	8d be fc fd          	lea    di,[bp-0x204]
    5c93:	16                   	push   ss
    5c94:	57                   	push   di
    5c95:	68 ff 00             	push   0xff
    5c98:	9a e7 17 ad 5c       	call   0x5cad:0x17e7
    5c9d:	6a 00                	push   0x0
    5c9f:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5ca3:	b9 05 00             	mov    cx,0x5
    5ca6:	f7 e9                	imul   cx
    5ca8:	71 05                	jno    0x5caf
    5caa:	9a 3e 04 c3 5c       	call   0x5cc3:0x43e
    5caf:	50                   	push   ax
    5cb0:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5cb4:	06                   	push   es
    5cb5:	57                   	push   di
    5cb6:	9a 72 2a d5 5c       	call   0x5cd5:0x2a72
    5cbb:	5a                   	pop    dx
    5cbc:	2b c2                	sub    ax,dx
    5cbe:	71 05                	jno    0x5cc5
    5cc0:	9a 3e 04 f0 5c       	call   0x5cf0:0x43e
    5cc5:	50                   	push   ax
    5cc6:	8d be fc fd          	lea    di,[bp-0x204]
    5cca:	16                   	push   ss
    5ccb:	57                   	push   di
    5ccc:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5cd0:	06                   	push   es
    5cd1:	57                   	push   di
    5cd2:	9a 04 2a 36 5d       	call   0x5d36:0x2a04
    5cd7:	89 c7                	mov    di,ax
    5cd9:	8e c2                	mov    es,dx
    5cdb:	06                   	push   es
    5cdc:	57                   	push   di
    5cdd:	9a 09 1f 5d 5d       	call   0x5d5d:0x1f09
    5ce2:	8d be f2 fb          	lea    di,[bp-0x40e]
    5ce6:	16                   	push   ss
    5ce7:	57                   	push   di
    5ce8:	bf 1b 5a             	mov    di,0x5a1b
    5ceb:	0e                   	push   cs
    5cec:	57                   	push   di
    5ced:	9a cd 17 0a 5d       	call   0x5d0a:0x17cd
    5cf2:	8d be f2 fc          	lea    di,[bp-0x30e]
    5cf6:	16                   	push   ss
    5cf7:	57                   	push   di
    5cf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cfb:	26 c4 bd dc 05       	les    di,DWORD PTR es:[di+0x5dc]
    5d00:	06                   	push   es
    5d01:	57                   	push   di
    5d02:	9a 53 1d 82 5d       	call   0x5d82:0x1d53
    5d07:	9a 4c 18 18 5d       	call   0x5d18:0x184c
    5d0c:	8d be fc fd          	lea    di,[bp-0x204]
    5d10:	16                   	push   ss
    5d11:	57                   	push   di
    5d12:	68 ff 00             	push   0xff
    5d15:	9a e7 17 2a 5d       	call   0x5d2a:0x17e7
    5d1a:	6a 00                	push   0x0
    5d1c:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5d20:	b9 04 00             	mov    cx,0x4
    5d23:	f7 e9                	imul   cx
    5d25:	71 05                	jno    0x5d2c
    5d27:	9a 3e 04 40 5d       	call   0x5d40:0x43e
    5d2c:	50                   	push   ax
    5d2d:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5d31:	06                   	push   es
    5d32:	57                   	push   di
    5d33:	9a 72 2a 52 5d       	call   0x5d52:0x2a72
    5d38:	5a                   	pop    dx
    5d39:	2b c2                	sub    ax,dx
    5d3b:	71 05                	jno    0x5d42
    5d3d:	9a 3e 04 6d 5d       	call   0x5d6d:0x43e
    5d42:	50                   	push   ax
    5d43:	8d be fc fd          	lea    di,[bp-0x204]
    5d47:	16                   	push   ss
    5d48:	57                   	push   di
    5d49:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5d4d:	06                   	push   es
    5d4e:	57                   	push   di
    5d4f:	9a 04 2a b3 5d       	call   0x5db3:0x2a04
    5d54:	89 c7                	mov    di,ax
    5d56:	8e c2                	mov    es,dx
    5d58:	06                   	push   es
    5d59:	57                   	push   di
    5d5a:	9a 09 1f da 5d       	call   0x5dda:0x1f09
    5d5f:	8d be f2 fb          	lea    di,[bp-0x40e]
    5d63:	16                   	push   ss
    5d64:	57                   	push   di
    5d65:	bf 1b 5a             	mov    di,0x5a1b
    5d68:	0e                   	push   cs
    5d69:	57                   	push   di
    5d6a:	9a cd 17 87 5d       	call   0x5d87:0x17cd
    5d6f:	8d be f2 fc          	lea    di,[bp-0x30e]
    5d73:	16                   	push   ss
    5d74:	57                   	push   di
    5d75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d78:	26 c4 bd e0 05       	les    di,DWORD PTR es:[di+0x5e0]
    5d7d:	06                   	push   es
    5d7e:	57                   	push   di
    5d7f:	9a 53 1d ff 5d       	call   0x5dff:0x1d53
    5d84:	9a 4c 18 95 5d       	call   0x5d95:0x184c
    5d89:	8d be fc fd          	lea    di,[bp-0x204]
    5d8d:	16                   	push   ss
    5d8e:	57                   	push   di
    5d8f:	68 ff 00             	push   0xff
    5d92:	9a e7 17 a7 5d       	call   0x5da7:0x17e7
    5d97:	6a 00                	push   0x0
    5d99:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5d9d:	b9 03 00             	mov    cx,0x3
    5da0:	f7 e9                	imul   cx
    5da2:	71 05                	jno    0x5da9
    5da4:	9a 3e 04 bd 5d       	call   0x5dbd:0x43e
    5da9:	50                   	push   ax
    5daa:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5dae:	06                   	push   es
    5daf:	57                   	push   di
    5db0:	9a 72 2a cf 5d       	call   0x5dcf:0x2a72
    5db5:	5a                   	pop    dx
    5db6:	2b c2                	sub    ax,dx
    5db8:	71 05                	jno    0x5dbf
    5dba:	9a 3e 04 ea 5d       	call   0x5dea:0x43e
    5dbf:	50                   	push   ax
    5dc0:	8d be fc fd          	lea    di,[bp-0x204]
    5dc4:	16                   	push   ss
    5dc5:	57                   	push   di
    5dc6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5dca:	06                   	push   es
    5dcb:	57                   	push   di
    5dcc:	9a 04 2a 30 5e       	call   0x5e30:0x2a04
    5dd1:	89 c7                	mov    di,ax
    5dd3:	8e c2                	mov    es,dx
    5dd5:	06                   	push   es
    5dd6:	57                   	push   di
    5dd7:	9a 09 1f 57 5e       	call   0x5e57:0x1f09
    5ddc:	8d be f2 fb          	lea    di,[bp-0x40e]
    5de0:	16                   	push   ss
    5de1:	57                   	push   di
    5de2:	bf 1b 5a             	mov    di,0x5a1b
    5de5:	0e                   	push   cs
    5de6:	57                   	push   di
    5de7:	9a cd 17 04 5e       	call   0x5e04:0x17cd
    5dec:	8d be f2 fc          	lea    di,[bp-0x30e]
    5df0:	16                   	push   ss
    5df1:	57                   	push   di
    5df2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5df5:	26 c4 bd e4 05       	les    di,DWORD PTR es:[di+0x5e4]
    5dfa:	06                   	push   es
    5dfb:	57                   	push   di
    5dfc:	9a 53 1d c1 5f       	call   0x5fc1:0x1d53
    5e01:	9a 4c 18 12 5e       	call   0x5e12:0x184c
    5e06:	8d be fc fd          	lea    di,[bp-0x204]
    5e0a:	16                   	push   ss
    5e0b:	57                   	push   di
    5e0c:	68 ff 00             	push   0xff
    5e0f:	9a e7 17 24 5e       	call   0x5e24:0x17e7
    5e14:	6a 00                	push   0x0
    5e16:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5e1a:	b9 02 00             	mov    cx,0x2
    5e1d:	f7 e9                	imul   cx
    5e1f:	71 05                	jno    0x5e26
    5e21:	9a 3e 04 3a 5e       	call   0x5e3a:0x43e
    5e26:	50                   	push   ax
    5e27:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5e2b:	06                   	push   es
    5e2c:	57                   	push   di
    5e2d:	9a 72 2a 4c 5e       	call   0x5e4c:0x2a72
    5e32:	5a                   	pop    dx
    5e33:	2b c2                	sub    ax,dx
    5e35:	71 05                	jno    0x5e3c
    5e37:	9a 3e 04 6e 5e       	call   0x5e6e:0x43e
    5e3c:	50                   	push   ax
    5e3d:	8d be fc fd          	lea    di,[bp-0x204]
    5e41:	16                   	push   ss
    5e42:	57                   	push   di
    5e43:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5e47:	06                   	push   es
    5e48:	57                   	push   di
    5e49:	9a 04 2a ff ff       	call   0xffff:0x2a04
    5e4e:	89 c7                	mov    di,ax
    5e50:	8e c2                	mov    es,dx
    5e52:	06                   	push   es
    5e53:	57                   	push   di
    5e54:	9a 09 1f ff ff       	call   0xffff:0x1f09
    5e59:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5e5d:	83 c4 06             	add    sp,0x6
    5e60:	b8 85 5e             	mov    ax,0x5e85
    5e63:	0e                   	push   cs
    5e64:	50                   	push   ax
    5e65:	8d be fc fe          	lea    di,[bp-0x104]
    5e69:	16                   	push   ss
    5e6a:	57                   	push   di
    5e6b:	9a 4f 0a 73 5e       	call   0x5e73:0xa4f
    5e70:	9a 08 04 92 5e       	call   0x5e92:0x408
    5e75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e78:	26 c4 bd f0 05       	les    di,DWORD PTR es:[di+0x5f0]
    5e7d:	06                   	push   es
    5e7e:	57                   	push   di
    5e7f:	9a e3 49 b6 5e       	call   0x5eb6:0x49e3
    5e84:	cb                   	retf
    5e85:	c9                   	leave
    5e86:	ca 04 00             	retf   0x4
    5e89:	55                   	push   bp
    5e8a:	89 e5                	mov    bp,sp
    5e8c:	b8 04 00             	mov    ax,0x4
    5e8f:	9a 44 04 dd 5e       	call   0x5edd:0x444
    5e94:	83 ec 04             	sub    sp,0x4
    5e97:	6a 00                	push   0x0
    5e99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e9c:	06                   	push   es
    5e9d:	57                   	push   di
    5e9e:	9a 7c 62 c5 62       	call   0x62c5:0x627c
    5ea3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ea6:	26 c4 bd f0 05       	les    di,DWORD PTR es:[di+0x5f0]
    5eab:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5eae:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5eb1:	06                   	push   es
    5eb2:	57                   	push   di
    5eb3:	9a 3f 4a c0 5e       	call   0x5ec0:0x4a3f
    5eb8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ebb:	06                   	push   es
    5ebc:	57                   	push   di
    5ebd:	9a ff 49 ca 5e       	call   0x5eca:0x49ff
    5ec2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ec5:	06                   	push   es
    5ec6:	57                   	push   di
    5ec7:	9a e3 49 86 5f       	call   0x5f86:0x49e3
    5ecc:	c9                   	leave
    5ecd:	ca 08 00             	retf   0x8
    5ed0:	01 09                	add    WORD PTR [bx+di],cx
    5ed2:	01 20                	add    WORD PTR [bx+si],sp
    5ed4:	55                   	push   bp
    5ed5:	89 e5                	mov    bp,sp
    5ed7:	b8 06 02             	mov    ax,0x206
    5eda:	9a 44 04 18 5f       	call   0x5f18:0x444
    5edf:	81 ec 06 02          	sub    sp,0x206
    5ee3:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5ee6:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5eeb:	75 03                	jne    0x5ef0
    5eed:	e9 83 03             	jmp    0x6273
    5ef0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5ef5:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    5ef8:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    5efc:	3d 00 00             	cmp    ax,0x0
    5eff:	75 32                	jne    0x5f33
    5f01:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    5f04:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    5f08:	76 27                	jbe    0x5f31
    5f0a:	8d be fe fd          	lea    di,[bp-0x202]
    5f0e:	16                   	push   ss
    5f0f:	57                   	push   di
    5f10:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    5f13:	06                   	push   es
    5f14:	57                   	push   di
    5f15:	9a cd 17 22 5f       	call   0x5f22:0x17cd
    5f1a:	bf d0 5e             	mov    di,0x5ed0
    5f1d:	0e                   	push   cs
    5f1e:	57                   	push   di
    5f1f:	9a 4c 18 2f 5f       	call   0x5f2f:0x184c
    5f24:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    5f27:	06                   	push   es
    5f28:	57                   	push   di
    5f29:	ff 76 10             	push   WORD PTR [bp+0x10]
    5f2c:	9a e7 17 5f 5f       	call   0x5f5f:0x17e7
    5f31:	eb 49                	jmp    0x5f7c
    5f33:	3d 01 00             	cmp    ax,0x1
    5f36:	75 44                	jne    0x5f7c
    5f38:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    5f3b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    5f3e:	30 e4                	xor    ah,ah
    5f40:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    5f44:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    5f48:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    5f4b:	7d 2d                	jge    0x5f7a
    5f4d:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    5f51:	8d be fe fd          	lea    di,[bp-0x202]
    5f55:	16                   	push   ss
    5f56:	57                   	push   di
    5f57:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    5f5a:	06                   	push   es
    5f5b:	57                   	push   di
    5f5c:	9a cd 17 69 5f       	call   0x5f69:0x17cd
    5f61:	bf d2 5e             	mov    di,0x5ed2
    5f64:	0e                   	push   cs
    5f65:	57                   	push   di
    5f66:	9a 4c 18 76 5f       	call   0x5f76:0x184c
    5f6b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    5f6e:	06                   	push   es
    5f6f:	57                   	push   di
    5f70:	ff 76 10             	push   WORD PTR [bp+0x10]
    5f73:	9a e7 17 8d 5f       	call   0x5f8d:0x17e7
    5f78:	eb ca                	jmp    0x5f44
    5f7a:	eb 00                	jmp    0x5f7c
    5f7c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5f7f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5f82:	bf 0c 01             	mov    di,0x10c
    5f85:	b8 9d 5f             	mov    ax,0x5f9d
    5f88:	50                   	push   ax
    5f89:	57                   	push   di
    5f8a:	9a 55 22 a4 5f       	call   0x5fa4:0x2255
    5f8f:	08 c0                	or     al,al
    5f91:	74 6b                	je     0x5ffe
    5f93:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5f96:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5f99:	bf 0c 01             	mov    di,0x10c
    5f9c:	b8 8a 60             	mov    ax,0x608a
    5f9f:	50                   	push   ax
    5fa0:	57                   	push   di
    5fa1:	9a 73 22 cf 5f       	call   0x5fcf:0x2273
    5fa6:	89 c7                	mov    di,ax
    5fa8:	8e c2                	mov    es,dx
    5faa:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5fae:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5fb2:	8d be fa fd          	lea    di,[bp-0x206]
    5fb6:	16                   	push   ss
    5fb7:	57                   	push   di
    5fb8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5fbc:	06                   	push   es
    5fbd:	57                   	push   di
    5fbe:	9a 53 1d 43 60       	call   0x6043:0x1d53
    5fc3:	8d be 00 ff          	lea    di,[bp-0x100]
    5fc7:	16                   	push   ss
    5fc8:	57                   	push   di
    5fc9:	68 ff 00             	push   0xff
    5fcc:	9a e7 17 fa 5f       	call   0x5ffa:0x17e7
    5fd1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5fd6:	b0 00                	mov    al,0x0
    5fd8:	76 01                	jbe    0x5fdb
    5fda:	40                   	inc    ax
    5fdb:	8a d0                	mov    dl,al
    5fdd:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    5fe2:	b0 00                	mov    al,0x0
    5fe4:	75 01                	jne    0x5fe7
    5fe6:	40                   	inc    ax
    5fe7:	22 c2                	and    al,dl
    5fe9:	08 c0                	or     al,al
    5feb:	74 11                	je     0x5ffe
    5fed:	8d be 00 ff          	lea    di,[bp-0x100]
    5ff1:	16                   	push   ss
    5ff2:	57                   	push   di
    5ff3:	6a 01                	push   0x1
    5ff5:	6a 01                	push   0x1
    5ff7:	9a 75 19 0f 60       	call   0x600f:0x1975
    5ffc:	eb d3                	jmp    0x5fd1
    5ffe:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6001:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6004:	bf ad 0d             	mov    di,0xdad
    6007:	b8 1f 60             	mov    ax,0x601f
    600a:	50                   	push   ax
    600b:	57                   	push   di
    600c:	9a 55 22 26 60       	call   0x6026:0x2255
    6011:	08 c0                	or     al,al
    6013:	74 6b                	je     0x6080
    6015:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6018:	ff 76 0c             	push   WORD PTR [bp+0xc]
    601b:	bf ad 0d             	mov    di,0xdad
    601e:	b8 ff ff             	mov    ax,0xffff
    6021:	50                   	push   ax
    6022:	57                   	push   di
    6023:	9a 73 22 51 60       	call   0x6051:0x2273
    6028:	89 c7                	mov    di,ax
    602a:	8e c2                	mov    es,dx
    602c:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    6030:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    6034:	8d be fa fd          	lea    di,[bp-0x206]
    6038:	16                   	push   ss
    6039:	57                   	push   di
    603a:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    603e:	06                   	push   es
    603f:	57                   	push   di
    6040:	9a 53 1d c5 60       	call   0x60c5:0x1d53
    6045:	8d be 00 ff          	lea    di,[bp-0x100]
    6049:	16                   	push   ss
    604a:	57                   	push   di
    604b:	68 ff 00             	push   0xff
    604e:	9a e7 17 7c 60       	call   0x607c:0x17e7
    6053:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6058:	b0 00                	mov    al,0x0
    605a:	76 01                	jbe    0x605d
    605c:	40                   	inc    ax
    605d:	8a d0                	mov    dl,al
    605f:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    6064:	b0 00                	mov    al,0x0
    6066:	75 01                	jne    0x6069
    6068:	40                   	inc    ax
    6069:	22 c2                	and    al,dl
    606b:	08 c0                	or     al,al
    606d:	74 11                	je     0x6080
    606f:	8d be 00 ff          	lea    di,[bp-0x100]
    6073:	16                   	push   ss
    6074:	57                   	push   di
    6075:	6a 01                	push   0x1
    6077:	6a 01                	push   0x1
    6079:	9a 75 19 91 60       	call   0x6091:0x1975
    607e:	eb d3                	jmp    0x6053
    6080:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6083:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6086:	bf 17 06             	mov    di,0x617
    6089:	b8 a1 60             	mov    ax,0x60a1
    608c:	50                   	push   ax
    608d:	57                   	push   di
    608e:	9a 55 22 a8 60       	call   0x60a8:0x2255
    6093:	08 c0                	or     al,al
    6095:	74 6b                	je     0x6102
    6097:	ff 76 0e             	push   WORD PTR [bp+0xe]
    609a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    609d:	bf 17 06             	mov    di,0x617
    60a0:	b8 a0 62             	mov    ax,0x62a0
    60a3:	50                   	push   ax
    60a4:	57                   	push   di
    60a5:	9a 73 22 d3 60       	call   0x60d3:0x2273
    60aa:	89 c7                	mov    di,ax
    60ac:	8e c2                	mov    es,dx
    60ae:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    60b2:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    60b6:	8d be fa fd          	lea    di,[bp-0x206]
    60ba:	16                   	push   ss
    60bb:	57                   	push   di
    60bc:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    60c0:	06                   	push   es
    60c1:	57                   	push   di
    60c2:	9a 53 1d f5 62       	call   0x62f5:0x1d53
    60c7:	8d be 00 ff          	lea    di,[bp-0x100]
    60cb:	16                   	push   ss
    60cc:	57                   	push   di
    60cd:	68 ff 00             	push   0xff
    60d0:	9a e7 17 fe 60       	call   0x60fe:0x17e7
    60d5:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    60da:	b0 00                	mov    al,0x0
    60dc:	76 01                	jbe    0x60df
    60de:	40                   	inc    ax
    60df:	8a d0                	mov    dl,al
    60e1:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    60e6:	b0 00                	mov    al,0x0
    60e8:	75 01                	jne    0x60eb
    60ea:	40                   	inc    ax
    60eb:	22 c2                	and    al,dl
    60ed:	08 c0                	or     al,al
    60ef:	74 11                	je     0x6102
    60f1:	8d be 00 ff          	lea    di,[bp-0x100]
    60f5:	16                   	push   ss
    60f6:	57                   	push   di
    60f7:	6a 01                	push   0x1
    60f9:	6a 01                	push   0x1
    60fb:	9a 75 19 13 61       	call   0x6113:0x1975
    6100:	eb d3                	jmp    0x60d5
    6102:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6105:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6108:	bf 22 00             	mov    di,0x22
    610b:	b8 23 61             	mov    ax,0x6123
    610e:	50                   	push   ax
    610f:	57                   	push   di
    6110:	9a 55 22 2a 61       	call   0x612a:0x2255
    6115:	08 c0                	or     al,al
    6117:	74 3e                	je     0x6157
    6119:	ff 76 0e             	push   WORD PTR [bp+0xe]
    611c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    611f:	bf 22 00             	mov    di,0x22
    6122:	b8 ff ff             	mov    ax,0xffff
    6125:	50                   	push   ax
    6126:	57                   	push   di
    6127:	9a 73 22 55 61       	call   0x6155:0x2273
    612c:	89 c7                	mov    di,ax
    612e:	8e c2                	mov    es,dx
    6130:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    6134:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    6138:	8d be fa fd          	lea    di,[bp-0x206]
    613c:	16                   	push   ss
    613d:	57                   	push   di
    613e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    6142:	06                   	push   es
    6143:	57                   	push   di
    6144:	9a 24 15 ff ff       	call   0xffff:0x1524
    6149:	8d be 00 ff          	lea    di,[bp-0x100]
    614d:	16                   	push   ss
    614e:	57                   	push   di
    614f:	68 ff 00             	push   0xff
    6152:	9a e7 17 6b 61       	call   0x616b:0x17e7
    6157:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    615a:	36 83 7d 0a 01       	cmp    WORD PTR ss:[di+0xa],0x1
    615f:	74 03                	je     0x6164
    6161:	e9 e7 00             	jmp    0x624b
    6164:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    6167:	50                   	push   ax
    6168:	9a f9 1e 9a 61       	call   0x619a:0x1ef9
    616d:	3c 47                	cmp    al,0x47
    616f:	75 30                	jne    0x61a1
    6171:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6176:	b0 00                	mov    al,0x0
    6178:	76 01                	jbe    0x617b
    617a:	40                   	inc    ax
    617b:	8a d0                	mov    dl,al
    617d:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    6182:	b0 00                	mov    al,0x0
    6184:	75 01                	jne    0x6187
    6186:	40                   	inc    ax
    6187:	22 c2                	and    al,dl
    6189:	08 c0                	or     al,al
    618b:	74 11                	je     0x619e
    618d:	8d be 00 ff          	lea    di,[bp-0x100]
    6191:	16                   	push   ss
    6192:	57                   	push   di
    6193:	6a 01                	push   0x1
    6195:	6a 01                	push   0x1
    6197:	9a 75 19 b7 61       	call   0x61b7:0x1975
    619c:	eb d3                	jmp    0x6171
    619e:	e9 aa 00             	jmp    0x624b
    61a1:	3c 43                	cmp    al,0x43
    61a3:	75 52                	jne    0x61f7
    61a5:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    61a9:	30 e4                	xor    ah,ah
    61ab:	8b d0                	mov    dx,ax
    61ad:	b8 12 00             	mov    ax,0x12
    61b0:	2b c2                	sub    ax,dx
    61b2:	71 05                	jno    0x61b9
    61b4:	9a 3e 04 d8 61       	call   0x61d8:0x43e
    61b9:	d1 e8                	shr    ax,1
    61bb:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    61bf:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    61c4:	7e 2f                	jle    0x61f5
    61c6:	ff 8e fe fe          	dec    WORD PTR [bp-0x102]
    61ca:	8d be fe fd          	lea    di,[bp-0x202]
    61ce:	16                   	push   ss
    61cf:	57                   	push   di
    61d0:	bf d2 5e             	mov    di,0x5ed2
    61d3:	0e                   	push   cs
    61d4:	57                   	push   di
    61d5:	9a cd 17 e3 61       	call   0x61e3:0x17cd
    61da:	8d be 00 ff          	lea    di,[bp-0x100]
    61de:	16                   	push   ss
    61df:	57                   	push   di
    61e0:	9a 4c 18 f1 61       	call   0x61f1:0x184c
    61e5:	8d be 00 ff          	lea    di,[bp-0x100]
    61e9:	16                   	push   ss
    61ea:	57                   	push   di
    61eb:	68 ff 00             	push   0xff
    61ee:	9a e7 17 0d 62       	call   0x620d:0x17e7
    61f3:	eb ca                	jmp    0x61bf
    61f5:	eb 54                	jmp    0x624b
    61f7:	3c 44                	cmp    al,0x44
    61f9:	75 50                	jne    0x624b
    61fb:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    61ff:	30 e4                	xor    ah,ah
    6201:	8b d0                	mov    dx,ax
    6203:	b8 12 00             	mov    ax,0x12
    6206:	2b c2                	sub    ax,dx
    6208:	71 05                	jno    0x620f
    620a:	9a 3e 04 2c 62       	call   0x622c:0x43e
    620f:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    6213:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    6218:	7e 2f                	jle    0x6249
    621a:	ff 8e fe fe          	dec    WORD PTR [bp-0x102]
    621e:	8d be fe fd          	lea    di,[bp-0x202]
    6222:	16                   	push   ss
    6223:	57                   	push   di
    6224:	bf d2 5e             	mov    di,0x5ed2
    6227:	0e                   	push   cs
    6228:	57                   	push   di
    6229:	9a cd 17 37 62       	call   0x6237:0x17cd
    622e:	8d be 00 ff          	lea    di,[bp-0x100]
    6232:	16                   	push   ss
    6233:	57                   	push   di
    6234:	9a 4c 18 45 62       	call   0x6245:0x184c
    6239:	8d be 00 ff          	lea    di,[bp-0x100]
    623d:	16                   	push   ss
    623e:	57                   	push   di
    623f:	68 ff 00             	push   0xff
    6242:	9a e7 17 59 62       	call   0x6259:0x17e7
    6247:	eb ca                	jmp    0x6213
    6249:	eb 00                	jmp    0x624b
    624b:	8d be fe fd          	lea    di,[bp-0x202]
    624f:	16                   	push   ss
    6250:	57                   	push   di
    6251:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    6254:	06                   	push   es
    6255:	57                   	push   di
    6256:	9a cd 17 64 62       	call   0x6264:0x17cd
    625b:	8d be 00 ff          	lea    di,[bp-0x100]
    625f:	16                   	push   ss
    6260:	57                   	push   di
    6261:	9a 4c 18 71 62       	call   0x6271:0x184c
    6266:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    6269:	06                   	push   es
    626a:	57                   	push   di
    626b:	ff 76 10             	push   WORD PTR [bp+0x10]
    626e:	9a e7 17 85 62       	call   0x6285:0x17e7
    6273:	c9                   	leave
    6274:	ca 10 00             	retf   0x10
    6277:	01 09                	add    WORD PTR [bx+di],cx
    6279:	00 01                	add    BYTE PTR [bx+di],al
    627b:	20 55 89             	and    BYTE PTR [di-0x77],dl
    627e:	e5 b8                	in     ax,0xb8
    6280:	04 03                	add    al,0x3
    6282:	9a 44 04 d6 62       	call   0x62d6:0x444
    6287:	81 ec 04 03          	sub    sp,0x304
    628b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    628e:	26 c4 bd f0 05       	les    di,DWORD PTR es:[di+0x5f0]
    6293:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    6297:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    629b:	06                   	push   es
    629c:	57                   	push   di
    629d:	9a e3 49 ff ff       	call   0xffff:0x49e3
    62a2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    62a7:	8d be 00 ff          	lea    di,[bp-0x100]
    62ab:	16                   	push   ss
    62ac:	57                   	push   di
    62ad:	68 ff 00             	push   0xff
    62b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62b3:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    62b8:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    62bd:	6a 00                	push   0x0
    62bf:	6a 67                	push   0x67
    62c1:	55                   	push   bp
    62c2:	9a d4 5e 62 63       	call   0x6362:0x5ed4
    62c7:	8d be fc fd          	lea    di,[bp-0x204]
    62cb:	16                   	push   ss
    62cc:	57                   	push   di
    62cd:	8d be 00 ff          	lea    di,[bp-0x100]
    62d1:	16                   	push   ss
    62d2:	57                   	push   di
    62d3:	9a cd 17 e0 62       	call   0x62e0:0x17cd
    62d8:	bf 77 62             	mov    di,0x6277
    62db:	0e                   	push   cs
    62dc:	57                   	push   di
    62dd:	9a 4c 18 fa 62       	call   0x62fa:0x184c
    62e2:	8d be fc fc          	lea    di,[bp-0x304]
    62e6:	16                   	push   ss
    62e7:	57                   	push   di
    62e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62eb:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    62f0:	06                   	push   es
    62f1:	57                   	push   di
    62f2:	9a 53 1d 92 63       	call   0x6392:0x1d53
    62f7:	9a 4c 18 08 63       	call   0x6308:0x184c
    62fc:	8d be 00 ff          	lea    di,[bp-0x100]
    6300:	16                   	push   ss
    6301:	57                   	push   di
    6302:	68 ff 00             	push   0xff
    6305:	9a e7 17 73 63       	call   0x6373:0x17e7
    630a:	8d be 00 ff          	lea    di,[bp-0x100]
    630e:	16                   	push   ss
    630f:	57                   	push   di
    6310:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6314:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6319:	06                   	push   es
    631a:	57                   	push   di
    631b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    631e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6322:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6326:	75 17                	jne    0x633f
    6328:	bf 79 62             	mov    di,0x6279
    632b:	0e                   	push   cs
    632c:	57                   	push   di
    632d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6331:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6336:	06                   	push   es
    6337:	57                   	push   di
    6338:	26 c4 3d             	les    di,DWORD PTR es:[di]
    633b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    633f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6344:	8d be 00 ff          	lea    di,[bp-0x100]
    6348:	16                   	push   ss
    6349:	57                   	push   di
    634a:	68 ff 00             	push   0xff
    634d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6350:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    6355:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    635a:	6a 0a                	push   0xa
    635c:	6a 67                	push   0x67
    635e:	55                   	push   bp
    635f:	9a d4 5e c5 63       	call   0x63c5:0x5ed4
    6364:	8d be fc fd          	lea    di,[bp-0x204]
    6368:	16                   	push   ss
    6369:	57                   	push   di
    636a:	8d be 00 ff          	lea    di,[bp-0x100]
    636e:	16                   	push   ss
    636f:	57                   	push   di
    6370:	9a cd 17 7d 63       	call   0x637d:0x17cd
    6375:	bf 7a 62             	mov    di,0x627a
    6378:	0e                   	push   cs
    6379:	57                   	push   di
    637a:	9a 4c 18 97 63       	call   0x6397:0x184c
    637f:	8d be fc fc          	lea    di,[bp-0x304]
    6383:	16                   	push   ss
    6384:	57                   	push   di
    6385:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6388:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    638d:	06                   	push   es
    638e:	57                   	push   di
    638f:	9a 53 1d 15 64       	call   0x6415:0x1d53
    6394:	9a 4c 18 a5 63       	call   0x63a5:0x184c
    6399:	8d be 00 ff          	lea    di,[bp-0x100]
    639d:	16                   	push   ss
    639e:	57                   	push   di
    639f:	68 ff 00             	push   0xff
    63a2:	9a e7 17 f6 63       	call   0x63f6:0x17e7
    63a7:	8d be 00 ff          	lea    di,[bp-0x100]
    63ab:	16                   	push   ss
    63ac:	57                   	push   di
    63ad:	68 ff 00             	push   0xff
    63b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63b3:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    63b8:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    63bd:	6a 25                	push   0x25
    63bf:	6a 67                	push   0x67
    63c1:	55                   	push   bp
    63c2:	9a d4 5e e5 63       	call   0x63e5:0x5ed4
    63c7:	8d be 00 ff          	lea    di,[bp-0x100]
    63cb:	16                   	push   ss
    63cc:	57                   	push   di
    63cd:	68 ff 00             	push   0xff
    63d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63d3:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    63d8:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    63dd:	6a 46                	push   0x46
    63df:	6a 67                	push   0x67
    63e1:	55                   	push   bp
    63e2:	9a d4 5e 84 64       	call   0x6484:0x5ed4
    63e7:	8d be fc fd          	lea    di,[bp-0x204]
    63eb:	16                   	push   ss
    63ec:	57                   	push   di
    63ed:	8d be 00 ff          	lea    di,[bp-0x100]
    63f1:	16                   	push   ss
    63f2:	57                   	push   di
    63f3:	9a cd 17 00 64       	call   0x6400:0x17cd
    63f8:	bf 7a 62             	mov    di,0x627a
    63fb:	0e                   	push   cs
    63fc:	57                   	push   di
    63fd:	9a 4c 18 1a 64       	call   0x641a:0x184c
    6402:	8d be fc fc          	lea    di,[bp-0x304]
    6406:	16                   	push   ss
    6407:	57                   	push   di
    6408:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    640b:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    6410:	06                   	push   es
    6411:	57                   	push   di
    6412:	9a 53 1d ff ff       	call   0xffff:0x1d53
    6417:	9a 4c 18 28 64       	call   0x6428:0x184c
    641c:	8d be 00 ff          	lea    di,[bp-0x100]
    6420:	16                   	push   ss
    6421:	57                   	push   di
    6422:	68 ff 00             	push   0xff
    6425:	9a e7 17 f1 67       	call   0x67f1:0x17e7
    642a:	8d be 00 ff          	lea    di,[bp-0x100]
    642e:	16                   	push   ss
    642f:	57                   	push   di
    6430:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6434:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6439:	06                   	push   es
    643a:	57                   	push   di
    643b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    643e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6442:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6446:	75 17                	jne    0x645f
    6448:	bf 79 62             	mov    di,0x6279
    644b:	0e                   	push   cs
    644c:	57                   	push   di
    644d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6451:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6456:	06                   	push   es
    6457:	57                   	push   di
    6458:	26 c4 3d             	les    di,DWORD PTR es:[di]
    645b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    645f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6464:	8d be 00 ff          	lea    di,[bp-0x100]
    6468:	16                   	push   ss
    6469:	57                   	push   di
    646a:	68 ff 00             	push   0xff
    646d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6470:	26 ff b5 3e 04       	push   WORD PTR es:[di+0x43e]
    6475:	26 ff b5 3c 04       	push   WORD PTR es:[di+0x43c]
    647a:	ff 36 2c 02          	push   WORD PTR ds:0x22c
    647e:	6a 67                	push   0x67
    6480:	55                   	push   bp
    6481:	9a d4 5e a6 64       	call   0x64a6:0x5ed4
    6486:	8d be 00 ff          	lea    di,[bp-0x100]
    648a:	16                   	push   ss
    648b:	57                   	push   di
    648c:	68 ff 00             	push   0xff
    648f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6492:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    6497:	26 ff b5 48 04       	push   WORD PTR es:[di+0x448]
    649c:	ff 36 32 02          	push   WORD PTR ds:0x232
    64a0:	6a 63                	push   0x63
    64a2:	55                   	push   bp
    64a3:	9a d4 5e c8 64       	call   0x64c8:0x5ed4
    64a8:	8d be 00 ff          	lea    di,[bp-0x100]
    64ac:	16                   	push   ss
    64ad:	57                   	push   di
    64ae:	68 ff 00             	push   0xff
    64b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64b4:	26 ff b5 92 04       	push   WORD PTR es:[di+0x492]
    64b9:	26 ff b5 90 04       	push   WORD PTR es:[di+0x490]
    64be:	ff 36 34 02          	push   WORD PTR ds:0x234
    64c2:	6a 63                	push   0x63
    64c4:	55                   	push   bp
    64c5:	9a d4 5e ea 64       	call   0x64ea:0x5ed4
    64ca:	8d be 00 ff          	lea    di,[bp-0x100]
    64ce:	16                   	push   ss
    64cf:	57                   	push   di
    64d0:	68 ff 00             	push   0xff
    64d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64d6:	26 ff b5 56 04       	push   WORD PTR es:[di+0x456]
    64db:	26 ff b5 54 04       	push   WORD PTR es:[di+0x454]
    64e0:	ff 36 36 02          	push   WORD PTR ds:0x236
    64e4:	6a 63                	push   0x63
    64e6:	55                   	push   bp
    64e7:	9a d4 5e 30 65       	call   0x6530:0x5ed4
    64ec:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    64f1:	76 18                	jbe    0x650b
    64f3:	8d be 00 ff          	lea    di,[bp-0x100]
    64f7:	16                   	push   ss
    64f8:	57                   	push   di
    64f9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    64fd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6502:	06                   	push   es
    6503:	57                   	push   di
    6504:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6507:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    650b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6510:	8d be 00 ff          	lea    di,[bp-0x100]
    6514:	16                   	push   ss
    6515:	57                   	push   di
    6516:	68 ff 00             	push   0xff
    6519:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    651c:	26 ff b5 5e 04       	push   WORD PTR es:[di+0x45e]
    6521:	26 ff b5 5c 04       	push   WORD PTR es:[di+0x45c]
    6526:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    652a:	6a 67                	push   0x67
    652c:	55                   	push   bp
    652d:	9a d4 5e 52 65       	call   0x6552:0x5ed4
    6532:	8d be 00 ff          	lea    di,[bp-0x100]
    6536:	16                   	push   ss
    6537:	57                   	push   di
    6538:	68 ff 00             	push   0xff
    653b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    653e:	26 ff b5 4e 04       	push   WORD PTR es:[di+0x44e]
    6543:	26 ff b5 4c 04       	push   WORD PTR es:[di+0x44c]
    6548:	ff 36 32 02          	push   WORD PTR ds:0x232
    654c:	6a 64                	push   0x64
    654e:	55                   	push   bp
    654f:	9a d4 5e 74 65       	call   0x6574:0x5ed4
    6554:	8d be 00 ff          	lea    di,[bp-0x100]
    6558:	16                   	push   ss
    6559:	57                   	push   di
    655a:	68 ff 00             	push   0xff
    655d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6560:	26 ff b5 96 04       	push   WORD PTR es:[di+0x496]
    6565:	26 ff b5 94 04       	push   WORD PTR es:[di+0x494]
    656a:	ff 36 34 02          	push   WORD PTR ds:0x234
    656e:	6a 64                	push   0x64
    6570:	55                   	push   bp
    6571:	9a d4 5e 96 65       	call   0x6596:0x5ed4
    6576:	8d be 00 ff          	lea    di,[bp-0x100]
    657a:	16                   	push   ss
    657b:	57                   	push   di
    657c:	68 ff 00             	push   0xff
    657f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6582:	26 ff b5 6a 04       	push   WORD PTR es:[di+0x46a]
    6587:	26 ff b5 68 04       	push   WORD PTR es:[di+0x468]
    658c:	ff 36 36 02          	push   WORD PTR ds:0x236
    6590:	6a 64                	push   0x64
    6592:	55                   	push   bp
    6593:	9a d4 5e dc 65       	call   0x65dc:0x5ed4
    6598:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    659d:	76 18                	jbe    0x65b7
    659f:	8d be 00 ff          	lea    di,[bp-0x100]
    65a3:	16                   	push   ss
    65a4:	57                   	push   di
    65a5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    65a9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    65ae:	06                   	push   es
    65af:	57                   	push   di
    65b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    65b3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    65b7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    65bc:	8d be 00 ff          	lea    di,[bp-0x100]
    65c0:	16                   	push   ss
    65c1:	57                   	push   di
    65c2:	68 ff 00             	push   0xff
    65c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65c8:	26 ff b5 aa 04       	push   WORD PTR es:[di+0x4aa]
    65cd:	26 ff b5 a8 04       	push   WORD PTR es:[di+0x4a8]
    65d2:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    65d6:	6a 67                	push   0x67
    65d8:	55                   	push   bp
    65d9:	9a d4 5e fe 65       	call   0x65fe:0x5ed4
    65de:	8d be 00 ff          	lea    di,[bp-0x100]
    65e2:	16                   	push   ss
    65e3:	57                   	push   di
    65e4:	68 ff 00             	push   0xff
    65e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65ea:	26 ff b5 7a 04       	push   WORD PTR es:[di+0x47a]
    65ef:	26 ff b5 78 04       	push   WORD PTR es:[di+0x478]
    65f4:	ff 36 32 02          	push   WORD PTR ds:0x232
    65f8:	6a 64                	push   0x64
    65fa:	55                   	push   bp
    65fb:	9a d4 5e 20 66       	call   0x6620:0x5ed4
    6600:	8d be 00 ff          	lea    di,[bp-0x100]
    6604:	16                   	push   ss
    6605:	57                   	push   di
    6606:	68 ff 00             	push   0xff
    6609:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    660c:	26 ff b5 9a 04       	push   WORD PTR es:[di+0x49a]
    6611:	26 ff b5 98 04       	push   WORD PTR es:[di+0x498]
    6616:	ff 36 34 02          	push   WORD PTR ds:0x234
    661a:	6a 64                	push   0x64
    661c:	55                   	push   bp
    661d:	9a d4 5e 42 66       	call   0x6642:0x5ed4
    6622:	8d be 00 ff          	lea    di,[bp-0x100]
    6626:	16                   	push   ss
    6627:	57                   	push   di
    6628:	68 ff 00             	push   0xff
    662b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    662e:	26 ff b5 82 04       	push   WORD PTR es:[di+0x482]
    6633:	26 ff b5 80 04       	push   WORD PTR es:[di+0x480]
    6638:	ff 36 36 02          	push   WORD PTR ds:0x236
    663c:	6a 64                	push   0x64
    663e:	55                   	push   bp
    663f:	9a d4 5e 88 66       	call   0x6688:0x5ed4
    6644:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6649:	76 18                	jbe    0x6663
    664b:	8d be 00 ff          	lea    di,[bp-0x100]
    664f:	16                   	push   ss
    6650:	57                   	push   di
    6651:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6655:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    665a:	06                   	push   es
    665b:	57                   	push   di
    665c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    665f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6663:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6668:	8d be 00 ff          	lea    di,[bp-0x100]
    666c:	16                   	push   ss
    666d:	57                   	push   di
    666e:	68 ff 00             	push   0xff
    6671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6674:	26 ff b5 ae 04       	push   WORD PTR es:[di+0x4ae]
    6679:	26 ff b5 ac 04       	push   WORD PTR es:[di+0x4ac]
    667e:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6682:	6a 67                	push   0x67
    6684:	55                   	push   bp
    6685:	9a d4 5e aa 66       	call   0x66aa:0x5ed4
    668a:	8d be 00 ff          	lea    di,[bp-0x100]
    668e:	16                   	push   ss
    668f:	57                   	push   di
    6690:	68 ff 00             	push   0xff
    6693:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6696:	26 ff b5 7e 04       	push   WORD PTR es:[di+0x47e]
    669b:	26 ff b5 7c 04       	push   WORD PTR es:[di+0x47c]
    66a0:	ff 36 32 02          	push   WORD PTR ds:0x232
    66a4:	6a 64                	push   0x64
    66a6:	55                   	push   bp
    66a7:	9a d4 5e cc 66       	call   0x66cc:0x5ed4
    66ac:	8d be 00 ff          	lea    di,[bp-0x100]
    66b0:	16                   	push   ss
    66b1:	57                   	push   di
    66b2:	68 ff 00             	push   0xff
    66b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66b8:	26 ff b5 9e 04       	push   WORD PTR es:[di+0x49e]
    66bd:	26 ff b5 9c 04       	push   WORD PTR es:[di+0x49c]
    66c2:	ff 36 34 02          	push   WORD PTR ds:0x234
    66c6:	6a 64                	push   0x64
    66c8:	55                   	push   bp
    66c9:	9a d4 5e ee 66       	call   0x66ee:0x5ed4
    66ce:	8d be 00 ff          	lea    di,[bp-0x100]
    66d2:	16                   	push   ss
    66d3:	57                   	push   di
    66d4:	68 ff 00             	push   0xff
    66d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66da:	26 ff b5 86 04       	push   WORD PTR es:[di+0x486]
    66df:	26 ff b5 84 04       	push   WORD PTR es:[di+0x484]
    66e4:	ff 36 36 02          	push   WORD PTR ds:0x236
    66e8:	6a 64                	push   0x64
    66ea:	55                   	push   bp
    66eb:	9a d4 5e 34 67       	call   0x6734:0x5ed4
    66f0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    66f5:	76 18                	jbe    0x670f
    66f7:	8d be 00 ff          	lea    di,[bp-0x100]
    66fb:	16                   	push   ss
    66fc:	57                   	push   di
    66fd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6701:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6706:	06                   	push   es
    6707:	57                   	push   di
    6708:	26 c4 3d             	les    di,DWORD PTR es:[di]
    670b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    670f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6714:	8d be 00 ff          	lea    di,[bp-0x100]
    6718:	16                   	push   ss
    6719:	57                   	push   di
    671a:	68 ff 00             	push   0xff
    671d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6720:	26 ff b5 62 04       	push   WORD PTR es:[di+0x462]
    6725:	26 ff b5 60 04       	push   WORD PTR es:[di+0x460]
    672a:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    672e:	6a 67                	push   0x67
    6730:	55                   	push   bp
    6731:	9a d4 5e 56 67       	call   0x6756:0x5ed4
    6736:	8d be 00 ff          	lea    di,[bp-0x100]
    673a:	16                   	push   ss
    673b:	57                   	push   di
    673c:	68 ff 00             	push   0xff
    673f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6742:	26 ff b5 52 04       	push   WORD PTR es:[di+0x452]
    6747:	26 ff b5 50 04       	push   WORD PTR es:[di+0x450]
    674c:	ff 36 32 02          	push   WORD PTR ds:0x232
    6750:	6a 64                	push   0x64
    6752:	55                   	push   bp
    6753:	9a d4 5e 78 67       	call   0x6778:0x5ed4
    6758:	8d be 00 ff          	lea    di,[bp-0x100]
    675c:	16                   	push   ss
    675d:	57                   	push   di
    675e:	68 ff 00             	push   0xff
    6761:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6764:	26 ff b5 a2 04       	push   WORD PTR es:[di+0x4a2]
    6769:	26 ff b5 a0 04       	push   WORD PTR es:[di+0x4a0]
    676e:	ff 36 34 02          	push   WORD PTR ds:0x234
    6772:	6a 64                	push   0x64
    6774:	55                   	push   bp
    6775:	9a d4 5e 9a 67       	call   0x679a:0x5ed4
    677a:	8d be 00 ff          	lea    di,[bp-0x100]
    677e:	16                   	push   ss
    677f:	57                   	push   di
    6780:	68 ff 00             	push   0xff
    6783:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6786:	26 ff b5 6e 04       	push   WORD PTR es:[di+0x46e]
    678b:	26 ff b5 6c 04       	push   WORD PTR es:[di+0x46c]
    6790:	ff 36 36 02          	push   WORD PTR ds:0x236
    6794:	6a 64                	push   0x64
    6796:	55                   	push   bp
    6797:	9a d4 5e e0 67       	call   0x67e0:0x5ed4
    679c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    67a1:	76 18                	jbe    0x67bb
    67a3:	8d be 00 ff          	lea    di,[bp-0x100]
    67a7:	16                   	push   ss
    67a8:	57                   	push   di
    67a9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    67ad:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    67b2:	06                   	push   es
    67b3:	57                   	push   di
    67b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    67b7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    67bb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    67c0:	8d be 00 ff          	lea    di,[bp-0x100]
    67c4:	16                   	push   ss
    67c5:	57                   	push   di
    67c6:	68 ff 00             	push   0xff
    67c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67cc:	26 ff b5 5a 04       	push   WORD PTR es:[di+0x45a]
    67d1:	26 ff b5 58 04       	push   WORD PTR es:[di+0x458]
    67d6:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    67da:	6a 67                	push   0x67
    67dc:	55                   	push   bp
    67dd:	9a d4 5e 35 68       	call   0x6835:0x5ed4
    67e2:	8d be fc fd          	lea    di,[bp-0x204]
    67e6:	16                   	push   ss
    67e7:	57                   	push   di
    67e8:	8d be 00 ff          	lea    di,[bp-0x100]
    67ec:	16                   	push   ss
    67ed:	57                   	push   di
    67ee:	9a cd 17 fb 67       	call   0x67fb:0x17cd
    67f3:	bf 77 62             	mov    di,0x6277
    67f6:	0e                   	push   cs
    67f7:	57                   	push   di
    67f8:	9a 4c 18 05 68       	call   0x6805:0x184c
    67fd:	bf 77 62             	mov    di,0x6277
    6800:	0e                   	push   cs
    6801:	57                   	push   di
    6802:	9a 4c 18 13 68       	call   0x6813:0x184c
    6807:	8d be 00 ff          	lea    di,[bp-0x100]
    680b:	16                   	push   ss
    680c:	57                   	push   di
    680d:	68 ff 00             	push   0xff
    6810:	9a e7 17 67 68       	call   0x6867:0x17e7
    6815:	8d be 00 ff          	lea    di,[bp-0x100]
    6819:	16                   	push   ss
    681a:	57                   	push   di
    681b:	68 ff 00             	push   0xff
    681e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6821:	26 ff b5 66 04       	push   WORD PTR es:[di+0x466]
    6826:	26 ff b5 64 04       	push   WORD PTR es:[di+0x464]
    682b:	ff 36 36 02          	push   WORD PTR ds:0x236
    682f:	6a 64                	push   0x64
    6831:	55                   	push   bp
    6832:	9a d4 5e 89 68       	call   0x6889:0x5ed4
    6837:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    683c:	76 18                	jbe    0x6856
    683e:	8d be 00 ff          	lea    di,[bp-0x100]
    6842:	16                   	push   ss
    6843:	57                   	push   di
    6844:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6848:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    684d:	06                   	push   es
    684e:	57                   	push   di
    684f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6852:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6856:	bf 7a 62             	mov    di,0x627a
    6859:	0e                   	push   cs
    685a:	57                   	push   di
    685b:	8d be 00 ff          	lea    di,[bp-0x100]
    685f:	16                   	push   ss
    6860:	57                   	push   di
    6861:	68 ff 00             	push   0xff
    6864:	9a e7 17 a1 6e       	call   0x6ea1:0x17e7
    6869:	8d be 00 ff          	lea    di,[bp-0x100]
    686d:	16                   	push   ss
    686e:	57                   	push   di
    686f:	68 ff 00             	push   0xff
    6872:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6875:	26 ff b5 72 04       	push   WORD PTR es:[di+0x472]
    687a:	26 ff b5 70 04       	push   WORD PTR es:[di+0x470]
    687f:	ff 36 32 02          	push   WORD PTR ds:0x232
    6883:	6a 64                	push   0x64
    6885:	55                   	push   bp
    6886:	9a d4 5e ab 68       	call   0x68ab:0x5ed4
    688b:	8d be 00 ff          	lea    di,[bp-0x100]
    688f:	16                   	push   ss
    6890:	57                   	push   di
    6891:	68 ff 00             	push   0xff
    6894:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6897:	26 ff b5 a6 04       	push   WORD PTR es:[di+0x4a6]
    689c:	26 ff b5 a4 04       	push   WORD PTR es:[di+0x4a4]
    68a1:	ff 36 34 02          	push   WORD PTR ds:0x234
    68a5:	6a 64                	push   0x64
    68a7:	55                   	push   bp
    68a8:	9a d4 5e cd 68       	call   0x68cd:0x5ed4
    68ad:	8d be 00 ff          	lea    di,[bp-0x100]
    68b1:	16                   	push   ss
    68b2:	57                   	push   di
    68b3:	68 ff 00             	push   0xff
    68b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68b9:	26 ff b5 76 04       	push   WORD PTR es:[di+0x476]
    68be:	26 ff b5 74 04       	push   WORD PTR es:[di+0x474]
    68c3:	ff 36 36 02          	push   WORD PTR ds:0x236
    68c7:	6a 64                	push   0x64
    68c9:	55                   	push   bp
    68ca:	9a d4 5e 30 69       	call   0x6930:0x5ed4
    68cf:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    68d4:	76 18                	jbe    0x68ee
    68d6:	8d be 00 ff          	lea    di,[bp-0x100]
    68da:	16                   	push   ss
    68db:	57                   	push   di
    68dc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    68e0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    68e5:	06                   	push   es
    68e6:	57                   	push   di
    68e7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    68ea:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    68ee:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    68f2:	75 17                	jne    0x690b
    68f4:	bf 79 62             	mov    di,0x6279
    68f7:	0e                   	push   cs
    68f8:	57                   	push   di
    68f9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    68fd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6902:	06                   	push   es
    6903:	57                   	push   di
    6904:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6907:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    690b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6910:	8d be 00 ff          	lea    di,[bp-0x100]
    6914:	16                   	push   ss
    6915:	57                   	push   di
    6916:	68 ff 00             	push   0xff
    6919:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    691c:	26 ff b5 b6 04       	push   WORD PTR es:[di+0x4b6]
    6921:	26 ff b5 b4 04       	push   WORD PTR es:[di+0x4b4]
    6926:	ff 36 2c 02          	push   WORD PTR ds:0x22c
    692a:	6a 67                	push   0x67
    692c:	55                   	push   bp
    692d:	9a d4 5e 52 69       	call   0x6952:0x5ed4
    6932:	8d be 00 ff          	lea    di,[bp-0x100]
    6936:	16                   	push   ss
    6937:	57                   	push   di
    6938:	68 ff 00             	push   0xff
    693b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    693e:	26 ff b5 c2 04       	push   WORD PTR es:[di+0x4c2]
    6943:	26 ff b5 c0 04       	push   WORD PTR es:[di+0x4c0]
    6948:	ff 36 32 02          	push   WORD PTR ds:0x232
    694c:	6a 63                	push   0x63
    694e:	55                   	push   bp
    694f:	9a d4 5e 74 69       	call   0x6974:0x5ed4
    6954:	8d be 00 ff          	lea    di,[bp-0x100]
    6958:	16                   	push   ss
    6959:	57                   	push   di
    695a:	68 ff 00             	push   0xff
    695d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6960:	26 ff b5 52 05       	push   WORD PTR es:[di+0x552]
    6965:	26 ff b5 50 05       	push   WORD PTR es:[di+0x550]
    696a:	ff 36 34 02          	push   WORD PTR ds:0x234
    696e:	6a 63                	push   0x63
    6970:	55                   	push   bp
    6971:	9a d4 5e 96 69       	call   0x6996:0x5ed4
    6976:	8d be 00 ff          	lea    di,[bp-0x100]
    697a:	16                   	push   ss
    697b:	57                   	push   di
    697c:	68 ff 00             	push   0xff
    697f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6982:	26 ff b5 02 05       	push   WORD PTR es:[di+0x502]
    6987:	26 ff b5 00 05       	push   WORD PTR es:[di+0x500]
    698c:	ff 36 36 02          	push   WORD PTR ds:0x236
    6990:	6a 63                	push   0x63
    6992:	55                   	push   bp
    6993:	9a d4 5e dc 69       	call   0x69dc:0x5ed4
    6998:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    699d:	76 18                	jbe    0x69b7
    699f:	8d be 00 ff          	lea    di,[bp-0x100]
    69a3:	16                   	push   ss
    69a4:	57                   	push   di
    69a5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    69a9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    69ae:	06                   	push   es
    69af:	57                   	push   di
    69b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    69b3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    69b7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    69bc:	8d be 00 ff          	lea    di,[bp-0x100]
    69c0:	16                   	push   ss
    69c1:	57                   	push   di
    69c2:	68 ff 00             	push   0xff
    69c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c8:	26 ff b5 c6 04       	push   WORD PTR es:[di+0x4c6]
    69cd:	26 ff b5 c4 04       	push   WORD PTR es:[di+0x4c4]
    69d2:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    69d6:	6a 67                	push   0x67
    69d8:	55                   	push   bp
    69d9:	9a d4 5e fe 69       	call   0x69fe:0x5ed4
    69de:	8d be 00 ff          	lea    di,[bp-0x100]
    69e2:	16                   	push   ss
    69e3:	57                   	push   di
    69e4:	68 ff 00             	push   0xff
    69e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69ea:	26 ff b5 ea 04       	push   WORD PTR es:[di+0x4ea]
    69ef:	26 ff b5 e8 04       	push   WORD PTR es:[di+0x4e8]
    69f4:	ff 36 32 02          	push   WORD PTR ds:0x232
    69f8:	6a 64                	push   0x64
    69fa:	55                   	push   bp
    69fb:	9a d4 5e 20 6a       	call   0x6a20:0x5ed4
    6a00:	8d be 00 ff          	lea    di,[bp-0x100]
    6a04:	16                   	push   ss
    6a05:	57                   	push   di
    6a06:	68 ff 00             	push   0xff
    6a09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a0c:	26 ff b5 56 05       	push   WORD PTR es:[di+0x556]
    6a11:	26 ff b5 54 05       	push   WORD PTR es:[di+0x554]
    6a16:	ff 36 34 02          	push   WORD PTR ds:0x234
    6a1a:	6a 64                	push   0x64
    6a1c:	55                   	push   bp
    6a1d:	9a d4 5e 42 6a       	call   0x6a42:0x5ed4
    6a22:	8d be 00 ff          	lea    di,[bp-0x100]
    6a26:	16                   	push   ss
    6a27:	57                   	push   di
    6a28:	68 ff 00             	push   0xff
    6a2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a2e:	26 ff b5 12 05       	push   WORD PTR es:[di+0x512]
    6a33:	26 ff b5 10 05       	push   WORD PTR es:[di+0x510]
    6a38:	ff 36 36 02          	push   WORD PTR ds:0x236
    6a3c:	6a 64                	push   0x64
    6a3e:	55                   	push   bp
    6a3f:	9a d4 5e 88 6a       	call   0x6a88:0x5ed4
    6a44:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6a49:	76 18                	jbe    0x6a63
    6a4b:	8d be 00 ff          	lea    di,[bp-0x100]
    6a4f:	16                   	push   ss
    6a50:	57                   	push   di
    6a51:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6a55:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6a5a:	06                   	push   es
    6a5b:	57                   	push   di
    6a5c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a5f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6a63:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6a68:	8d be 00 ff          	lea    di,[bp-0x100]
    6a6c:	16                   	push   ss
    6a6d:	57                   	push   di
    6a6e:	68 ff 00             	push   0xff
    6a71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a74:	26 ff b5 ce 04       	push   WORD PTR es:[di+0x4ce]
    6a79:	26 ff b5 cc 04       	push   WORD PTR es:[di+0x4cc]
    6a7e:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6a82:	6a 67                	push   0x67
    6a84:	55                   	push   bp
    6a85:	9a d4 5e aa 6a       	call   0x6aaa:0x5ed4
    6a8a:	8d be 00 ff          	lea    di,[bp-0x100]
    6a8e:	16                   	push   ss
    6a8f:	57                   	push   di
    6a90:	68 ff 00             	push   0xff
    6a93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a96:	26 ff b5 f2 04       	push   WORD PTR es:[di+0x4f2]
    6a9b:	26 ff b5 f0 04       	push   WORD PTR es:[di+0x4f0]
    6aa0:	ff 36 32 02          	push   WORD PTR ds:0x232
    6aa4:	6a 64                	push   0x64
    6aa6:	55                   	push   bp
    6aa7:	9a d4 5e cc 6a       	call   0x6acc:0x5ed4
    6aac:	8d be 00 ff          	lea    di,[bp-0x100]
    6ab0:	16                   	push   ss
    6ab1:	57                   	push   di
    6ab2:	68 ff 00             	push   0xff
    6ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ab8:	26 ff b5 5a 05       	push   WORD PTR es:[di+0x55a]
    6abd:	26 ff b5 58 05       	push   WORD PTR es:[di+0x558]
    6ac2:	ff 36 34 02          	push   WORD PTR ds:0x234
    6ac6:	6a 64                	push   0x64
    6ac8:	55                   	push   bp
    6ac9:	9a d4 5e ee 6a       	call   0x6aee:0x5ed4
    6ace:	8d be 00 ff          	lea    di,[bp-0x100]
    6ad2:	16                   	push   ss
    6ad3:	57                   	push   di
    6ad4:	68 ff 00             	push   0xff
    6ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ada:	26 ff b5 1a 05       	push   WORD PTR es:[di+0x51a]
    6adf:	26 ff b5 18 05       	push   WORD PTR es:[di+0x518]
    6ae4:	ff 36 36 02          	push   WORD PTR ds:0x236
    6ae8:	6a 64                	push   0x64
    6aea:	55                   	push   bp
    6aeb:	9a d4 5e 34 6b       	call   0x6b34:0x5ed4
    6af0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6af5:	76 18                	jbe    0x6b0f
    6af7:	8d be 00 ff          	lea    di,[bp-0x100]
    6afb:	16                   	push   ss
    6afc:	57                   	push   di
    6afd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b01:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b06:	06                   	push   es
    6b07:	57                   	push   di
    6b08:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b0b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b0f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b14:	8d be 00 ff          	lea    di,[bp-0x100]
    6b18:	16                   	push   ss
    6b19:	57                   	push   di
    6b1a:	68 ff 00             	push   0xff
    6b1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b20:	26 ff b5 76 05       	push   WORD PTR es:[di+0x576]
    6b25:	26 ff b5 74 05       	push   WORD PTR es:[di+0x574]
    6b2a:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6b2e:	6a 67                	push   0x67
    6b30:	55                   	push   bp
    6b31:	9a d4 5e 56 6b       	call   0x6b56:0x5ed4
    6b36:	8d be 00 ff          	lea    di,[bp-0x100]
    6b3a:	16                   	push   ss
    6b3b:	57                   	push   di
    6b3c:	68 ff 00             	push   0xff
    6b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b42:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    6b47:	26 ff b5 2c 05       	push   WORD PTR es:[di+0x52c]
    6b4c:	ff 36 32 02          	push   WORD PTR ds:0x232
    6b50:	6a 64                	push   0x64
    6b52:	55                   	push   bp
    6b53:	9a d4 5e 78 6b       	call   0x6b78:0x5ed4
    6b58:	8d be 00 ff          	lea    di,[bp-0x100]
    6b5c:	16                   	push   ss
    6b5d:	57                   	push   di
    6b5e:	68 ff 00             	push   0xff
    6b61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b64:	26 ff b5 5e 05       	push   WORD PTR es:[di+0x55e]
    6b69:	26 ff b5 5c 05       	push   WORD PTR es:[di+0x55c]
    6b6e:	ff 36 34 02          	push   WORD PTR ds:0x234
    6b72:	6a 64                	push   0x64
    6b74:	55                   	push   bp
    6b75:	9a d4 5e 9a 6b       	call   0x6b9a:0x5ed4
    6b7a:	8d be 00 ff          	lea    di,[bp-0x100]
    6b7e:	16                   	push   ss
    6b7f:	57                   	push   di
    6b80:	68 ff 00             	push   0xff
    6b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b86:	26 ff b5 32 05       	push   WORD PTR es:[di+0x532]
    6b8b:	26 ff b5 30 05       	push   WORD PTR es:[di+0x530]
    6b90:	ff 36 36 02          	push   WORD PTR ds:0x236
    6b94:	6a 64                	push   0x64
    6b96:	55                   	push   bp
    6b97:	9a d4 5e e0 6b       	call   0x6be0:0x5ed4
    6b9c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6ba1:	76 18                	jbe    0x6bbb
    6ba3:	8d be 00 ff          	lea    di,[bp-0x100]
    6ba7:	16                   	push   ss
    6ba8:	57                   	push   di
    6ba9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6bad:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6bb2:	06                   	push   es
    6bb3:	57                   	push   di
    6bb4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6bb7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6bbb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6bc0:	8d be 00 ff          	lea    di,[bp-0x100]
    6bc4:	16                   	push   ss
    6bc5:	57                   	push   di
    6bc6:	68 ff 00             	push   0xff
    6bc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bcc:	26 ff b5 da 04       	push   WORD PTR es:[di+0x4da]
    6bd1:	26 ff b5 d8 04       	push   WORD PTR es:[di+0x4d8]
    6bd6:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6bda:	6a 67                	push   0x67
    6bdc:	55                   	push   bp
    6bdd:	9a d4 5e 02 6c       	call   0x6c02:0x5ed4
    6be2:	8d be 00 ff          	lea    di,[bp-0x100]
    6be6:	16                   	push   ss
    6be7:	57                   	push   di
    6be8:	68 ff 00             	push   0xff
    6beb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bee:	26 ff b5 fe 04       	push   WORD PTR es:[di+0x4fe]
    6bf3:	26 ff b5 fc 04       	push   WORD PTR es:[di+0x4fc]
    6bf8:	ff 36 32 02          	push   WORD PTR ds:0x232
    6bfc:	6a 64                	push   0x64
    6bfe:	55                   	push   bp
    6bff:	9a d4 5e 24 6c       	call   0x6c24:0x5ed4
    6c04:	8d be 00 ff          	lea    di,[bp-0x100]
    6c08:	16                   	push   ss
    6c09:	57                   	push   di
    6c0a:	68 ff 00             	push   0xff
    6c0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c10:	26 ff b5 6e 05       	push   WORD PTR es:[di+0x56e]
    6c15:	26 ff b5 6c 05       	push   WORD PTR es:[di+0x56c]
    6c1a:	ff 36 34 02          	push   WORD PTR ds:0x234
    6c1e:	6a 64                	push   0x64
    6c20:	55                   	push   bp
    6c21:	9a d4 5e 46 6c       	call   0x6c46:0x5ed4
    6c26:	8d be 00 ff          	lea    di,[bp-0x100]
    6c2a:	16                   	push   ss
    6c2b:	57                   	push   di
    6c2c:	68 ff 00             	push   0xff
    6c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c32:	26 ff b5 26 05       	push   WORD PTR es:[di+0x526]
    6c37:	26 ff b5 24 05       	push   WORD PTR es:[di+0x524]
    6c3c:	ff 36 36 02          	push   WORD PTR ds:0x236
    6c40:	6a 64                	push   0x64
    6c42:	55                   	push   bp
    6c43:	9a d4 5e 8c 6c       	call   0x6c8c:0x5ed4
    6c48:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6c4d:	76 18                	jbe    0x6c67
    6c4f:	8d be 00 ff          	lea    di,[bp-0x100]
    6c53:	16                   	push   ss
    6c54:	57                   	push   di
    6c55:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c59:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c5e:	06                   	push   es
    6c5f:	57                   	push   di
    6c60:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c63:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c67:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c6c:	8d be 00 ff          	lea    di,[bp-0x100]
    6c70:	16                   	push   ss
    6c71:	57                   	push   di
    6c72:	68 ff 00             	push   0xff
    6c75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c78:	26 ff b5 ca 04       	push   WORD PTR es:[di+0x4ca]
    6c7d:	26 ff b5 c8 04       	push   WORD PTR es:[di+0x4c8]
    6c82:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6c86:	6a 67                	push   0x67
    6c88:	55                   	push   bp
    6c89:	9a d4 5e ae 6c       	call   0x6cae:0x5ed4
    6c8e:	8d be 00 ff          	lea    di,[bp-0x100]
    6c92:	16                   	push   ss
    6c93:	57                   	push   di
    6c94:	68 ff 00             	push   0xff
    6c97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c9a:	26 ff b5 ee 04       	push   WORD PTR es:[di+0x4ee]
    6c9f:	26 ff b5 ec 04       	push   WORD PTR es:[di+0x4ec]
    6ca4:	ff 36 32 02          	push   WORD PTR ds:0x232
    6ca8:	6a 64                	push   0x64
    6caa:	55                   	push   bp
    6cab:	9a d4 5e d0 6c       	call   0x6cd0:0x5ed4
    6cb0:	8d be 00 ff          	lea    di,[bp-0x100]
    6cb4:	16                   	push   ss
    6cb5:	57                   	push   di
    6cb6:	68 ff 00             	push   0xff
    6cb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cbc:	26 ff b5 62 05       	push   WORD PTR es:[di+0x562]
    6cc1:	26 ff b5 60 05       	push   WORD PTR es:[di+0x560]
    6cc6:	ff 36 34 02          	push   WORD PTR ds:0x234
    6cca:	6a 64                	push   0x64
    6ccc:	55                   	push   bp
    6ccd:	9a d4 5e f2 6c       	call   0x6cf2:0x5ed4
    6cd2:	8d be 00 ff          	lea    di,[bp-0x100]
    6cd6:	16                   	push   ss
    6cd7:	57                   	push   di
    6cd8:	68 ff 00             	push   0xff
    6cdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cde:	26 ff b5 16 05       	push   WORD PTR es:[di+0x516]
    6ce3:	26 ff b5 14 05       	push   WORD PTR es:[di+0x514]
    6ce8:	ff 36 36 02          	push   WORD PTR ds:0x236
    6cec:	6a 64                	push   0x64
    6cee:	55                   	push   bp
    6cef:	9a d4 5e 38 6d       	call   0x6d38:0x5ed4
    6cf4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6cf9:	76 18                	jbe    0x6d13
    6cfb:	8d be 00 ff          	lea    di,[bp-0x100]
    6cff:	16                   	push   ss
    6d00:	57                   	push   di
    6d01:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d05:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d0a:	06                   	push   es
    6d0b:	57                   	push   di
    6d0c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d0f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d13:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d18:	8d be 00 ff          	lea    di,[bp-0x100]
    6d1c:	16                   	push   ss
    6d1d:	57                   	push   di
    6d1e:	68 ff 00             	push   0xff
    6d21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d24:	26 ff b5 d2 04       	push   WORD PTR es:[di+0x4d2]
    6d29:	26 ff b5 d0 04       	push   WORD PTR es:[di+0x4d0]
    6d2e:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6d32:	6a 67                	push   0x67
    6d34:	55                   	push   bp
    6d35:	9a d4 5e 5a 6d       	call   0x6d5a:0x5ed4
    6d3a:	8d be 00 ff          	lea    di,[bp-0x100]
    6d3e:	16                   	push   ss
    6d3f:	57                   	push   di
    6d40:	68 ff 00             	push   0xff
    6d43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d46:	26 ff b5 f6 04       	push   WORD PTR es:[di+0x4f6]
    6d4b:	26 ff b5 f4 04       	push   WORD PTR es:[di+0x4f4]
    6d50:	ff 36 32 02          	push   WORD PTR ds:0x232
    6d54:	6a 64                	push   0x64
    6d56:	55                   	push   bp
    6d57:	9a d4 5e 7c 6d       	call   0x6d7c:0x5ed4
    6d5c:	8d be 00 ff          	lea    di,[bp-0x100]
    6d60:	16                   	push   ss
    6d61:	57                   	push   di
    6d62:	68 ff 00             	push   0xff
    6d65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d68:	26 ff b5 66 05       	push   WORD PTR es:[di+0x566]
    6d6d:	26 ff b5 64 05       	push   WORD PTR es:[di+0x564]
    6d72:	ff 36 34 02          	push   WORD PTR ds:0x234
    6d76:	6a 64                	push   0x64
    6d78:	55                   	push   bp
    6d79:	9a d4 5e 9e 6d       	call   0x6d9e:0x5ed4
    6d7e:	8d be 00 ff          	lea    di,[bp-0x100]
    6d82:	16                   	push   ss
    6d83:	57                   	push   di
    6d84:	68 ff 00             	push   0xff
    6d87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d8a:	26 ff b5 1e 05       	push   WORD PTR es:[di+0x51e]
    6d8f:	26 ff b5 1c 05       	push   WORD PTR es:[di+0x51c]
    6d94:	ff 36 36 02          	push   WORD PTR ds:0x236
    6d98:	6a 64                	push   0x64
    6d9a:	55                   	push   bp
    6d9b:	9a d4 5e e4 6d       	call   0x6de4:0x5ed4
    6da0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6da5:	76 18                	jbe    0x6dbf
    6da7:	8d be 00 ff          	lea    di,[bp-0x100]
    6dab:	16                   	push   ss
    6dac:	57                   	push   di
    6dad:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6db1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6db6:	06                   	push   es
    6db7:	57                   	push   di
    6db8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6dbb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6dbf:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6dc4:	8d be 00 ff          	lea    di,[bp-0x100]
    6dc8:	16                   	push   ss
    6dc9:	57                   	push   di
    6dca:	68 ff 00             	push   0xff
    6dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dd0:	26 ff b5 d6 04       	push   WORD PTR es:[di+0x4d6]
    6dd5:	26 ff b5 d4 04       	push   WORD PTR es:[di+0x4d4]
    6dda:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6dde:	6a 67                	push   0x67
    6de0:	55                   	push   bp
    6de1:	9a d4 5e 06 6e       	call   0x6e06:0x5ed4
    6de6:	8d be 00 ff          	lea    di,[bp-0x100]
    6dea:	16                   	push   ss
    6deb:	57                   	push   di
    6dec:	68 ff 00             	push   0xff
    6def:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6df2:	26 ff b5 fa 04       	push   WORD PTR es:[di+0x4fa]
    6df7:	26 ff b5 f8 04       	push   WORD PTR es:[di+0x4f8]
    6dfc:	ff 36 32 02          	push   WORD PTR ds:0x232
    6e00:	6a 64                	push   0x64
    6e02:	55                   	push   bp
    6e03:	9a d4 5e 28 6e       	call   0x6e28:0x5ed4
    6e08:	8d be 00 ff          	lea    di,[bp-0x100]
    6e0c:	16                   	push   ss
    6e0d:	57                   	push   di
    6e0e:	68 ff 00             	push   0xff
    6e11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e14:	26 ff b5 6a 05       	push   WORD PTR es:[di+0x56a]
    6e19:	26 ff b5 68 05       	push   WORD PTR es:[di+0x568]
    6e1e:	ff 36 34 02          	push   WORD PTR ds:0x234
    6e22:	6a 64                	push   0x64
    6e24:	55                   	push   bp
    6e25:	9a d4 5e 4a 6e       	call   0x6e4a:0x5ed4
    6e2a:	8d be 00 ff          	lea    di,[bp-0x100]
    6e2e:	16                   	push   ss
    6e2f:	57                   	push   di
    6e30:	68 ff 00             	push   0xff
    6e33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e36:	26 ff b5 22 05       	push   WORD PTR es:[di+0x522]
    6e3b:	26 ff b5 20 05       	push   WORD PTR es:[di+0x520]
    6e40:	ff 36 36 02          	push   WORD PTR ds:0x236
    6e44:	6a 64                	push   0x64
    6e46:	55                   	push   bp
    6e47:	9a d4 5e 90 6e       	call   0x6e90:0x5ed4
    6e4c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6e51:	76 18                	jbe    0x6e6b
    6e53:	8d be 00 ff          	lea    di,[bp-0x100]
    6e57:	16                   	push   ss
    6e58:	57                   	push   di
    6e59:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e5d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e62:	06                   	push   es
    6e63:	57                   	push   di
    6e64:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e67:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6e6b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6e70:	8d be 00 ff          	lea    di,[bp-0x100]
    6e74:	16                   	push   ss
    6e75:	57                   	push   di
    6e76:	68 ff 00             	push   0xff
    6e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e7c:	26 ff b5 3a 05       	push   WORD PTR es:[di+0x53a]
    6e81:	26 ff b5 38 05       	push   WORD PTR es:[di+0x538]
    6e86:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6e8a:	6a 67                	push   0x67
    6e8c:	55                   	push   bp
    6e8d:	9a d4 5e e5 6e       	call   0x6ee5:0x5ed4
    6e92:	8d be fc fd          	lea    di,[bp-0x204]
    6e96:	16                   	push   ss
    6e97:	57                   	push   di
    6e98:	8d be 00 ff          	lea    di,[bp-0x100]
    6e9c:	16                   	push   ss
    6e9d:	57                   	push   di
    6e9e:	9a cd 17 ab 6e       	call   0x6eab:0x17cd
    6ea3:	bf 77 62             	mov    di,0x6277
    6ea6:	0e                   	push   cs
    6ea7:	57                   	push   di
    6ea8:	9a 4c 18 b5 6e       	call   0x6eb5:0x184c
    6ead:	bf 77 62             	mov    di,0x6277
    6eb0:	0e                   	push   cs
    6eb1:	57                   	push   di
    6eb2:	9a 4c 18 c3 6e       	call   0x6ec3:0x184c
    6eb7:	8d be 00 ff          	lea    di,[bp-0x100]
    6ebb:	16                   	push   ss
    6ebc:	57                   	push   di
    6ebd:	68 ff 00             	push   0xff
    6ec0:	9a e7 17 3c 6f       	call   0x6f3c:0x17e7
    6ec5:	8d be 00 ff          	lea    di,[bp-0x100]
    6ec9:	16                   	push   ss
    6eca:	57                   	push   di
    6ecb:	68 ff 00             	push   0xff
    6ece:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ed1:	26 ff b5 3e 05       	push   WORD PTR es:[di+0x53e]
    6ed6:	26 ff b5 3c 05       	push   WORD PTR es:[di+0x53c]
    6edb:	ff 36 36 02          	push   WORD PTR ds:0x236
    6edf:	6a 64                	push   0x64
    6ee1:	55                   	push   bp
    6ee2:	9a d4 5e 2b 6f       	call   0x6f2b:0x5ed4
    6ee7:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6eec:	76 18                	jbe    0x6f06
    6eee:	8d be 00 ff          	lea    di,[bp-0x100]
    6ef2:	16                   	push   ss
    6ef3:	57                   	push   di
    6ef4:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ef8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6efd:	06                   	push   es
    6efe:	57                   	push   di
    6eff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f02:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f06:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6f0b:	8d be 00 ff          	lea    di,[bp-0x100]
    6f0f:	16                   	push   ss
    6f10:	57                   	push   di
    6f11:	68 ff 00             	push   0xff
    6f14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f17:	26 ff b5 fe 06       	push   WORD PTR es:[di+0x6fe]
    6f1c:	26 ff b5 fc 06       	push   WORD PTR es:[di+0x6fc]
    6f21:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6f25:	6a 67                	push   0x67
    6f27:	55                   	push   bp
    6f28:	9a d4 5e 80 6f       	call   0x6f80:0x5ed4
    6f2d:	8d be fc fd          	lea    di,[bp-0x204]
    6f31:	16                   	push   ss
    6f32:	57                   	push   di
    6f33:	8d be 00 ff          	lea    di,[bp-0x100]
    6f37:	16                   	push   ss
    6f38:	57                   	push   di
    6f39:	9a cd 17 46 6f       	call   0x6f46:0x17cd
    6f3e:	bf 77 62             	mov    di,0x6277
    6f41:	0e                   	push   cs
    6f42:	57                   	push   di
    6f43:	9a 4c 18 50 6f       	call   0x6f50:0x184c
    6f48:	bf 77 62             	mov    di,0x6277
    6f4b:	0e                   	push   cs
    6f4c:	57                   	push   di
    6f4d:	9a 4c 18 5e 6f       	call   0x6f5e:0x184c
    6f52:	8d be 00 ff          	lea    di,[bp-0x100]
    6f56:	16                   	push   ss
    6f57:	57                   	push   di
    6f58:	68 ff 00             	push   0xff
    6f5b:	9a e7 17 d7 6f       	call   0x6fd7:0x17e7
    6f60:	8d be 00 ff          	lea    di,[bp-0x100]
    6f64:	16                   	push   ss
    6f65:	57                   	push   di
    6f66:	68 ff 00             	push   0xff
    6f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f6c:	26 ff b5 06 07       	push   WORD PTR es:[di+0x706]
    6f71:	26 ff b5 04 07       	push   WORD PTR es:[di+0x704]
    6f76:	ff 36 36 02          	push   WORD PTR ds:0x236
    6f7a:	6a 64                	push   0x64
    6f7c:	55                   	push   bp
    6f7d:	9a d4 5e c6 6f       	call   0x6fc6:0x5ed4
    6f82:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6f87:	76 18                	jbe    0x6fa1
    6f89:	8d be 00 ff          	lea    di,[bp-0x100]
    6f8d:	16                   	push   ss
    6f8e:	57                   	push   di
    6f8f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f93:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f98:	06                   	push   es
    6f99:	57                   	push   di
    6f9a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f9d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6fa1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6fa6:	8d be 00 ff          	lea    di,[bp-0x100]
    6faa:	16                   	push   ss
    6fab:	57                   	push   di
    6fac:	68 ff 00             	push   0xff
    6faf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fb2:	26 ff b5 e2 04       	push   WORD PTR es:[di+0x4e2]
    6fb7:	26 ff b5 e0 04       	push   WORD PTR es:[di+0x4e0]
    6fbc:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    6fc0:	6a 67                	push   0x67
    6fc2:	55                   	push   bp
    6fc3:	9a d4 5e 1b 70       	call   0x701b:0x5ed4
    6fc8:	8d be fc fd          	lea    di,[bp-0x204]
    6fcc:	16                   	push   ss
    6fcd:	57                   	push   di
    6fce:	8d be 00 ff          	lea    di,[bp-0x100]
    6fd2:	16                   	push   ss
    6fd3:	57                   	push   di
    6fd4:	9a cd 17 e1 6f       	call   0x6fe1:0x17cd
    6fd9:	bf 77 62             	mov    di,0x6277
    6fdc:	0e                   	push   cs
    6fdd:	57                   	push   di
    6fde:	9a 4c 18 eb 6f       	call   0x6feb:0x184c
    6fe3:	bf 77 62             	mov    di,0x6277
    6fe6:	0e                   	push   cs
    6fe7:	57                   	push   di
    6fe8:	9a 4c 18 f9 6f       	call   0x6ff9:0x184c
    6fed:	8d be 00 ff          	lea    di,[bp-0x100]
    6ff1:	16                   	push   ss
    6ff2:	57                   	push   di
    6ff3:	68 ff 00             	push   0xff
    6ff6:	9a e7 17 72 70       	call   0x7072:0x17e7
    6ffb:	8d be 00 ff          	lea    di,[bp-0x100]
    6fff:	16                   	push   ss
    7000:	57                   	push   di
    7001:	68 ff 00             	push   0xff
    7004:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7007:	26 ff b5 0a 05       	push   WORD PTR es:[di+0x50a]
    700c:	26 ff b5 08 05       	push   WORD PTR es:[di+0x508]
    7011:	ff 36 36 02          	push   WORD PTR ds:0x236
    7015:	6a 64                	push   0x64
    7017:	55                   	push   bp
    7018:	9a d4 5e 61 70       	call   0x7061:0x5ed4
    701d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7022:	76 18                	jbe    0x703c
    7024:	8d be 00 ff          	lea    di,[bp-0x100]
    7028:	16                   	push   ss
    7029:	57                   	push   di
    702a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    702e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7033:	06                   	push   es
    7034:	57                   	push   di
    7035:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7038:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    703c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7041:	8d be 00 ff          	lea    di,[bp-0x100]
    7045:	16                   	push   ss
    7046:	57                   	push   di
    7047:	68 ff 00             	push   0xff
    704a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    704d:	26 ff b5 02 07       	push   WORD PTR es:[di+0x702]
    7052:	26 ff b5 00 07       	push   WORD PTR es:[di+0x700]
    7057:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    705b:	6a 67                	push   0x67
    705d:	55                   	push   bp
    705e:	9a d4 5e b6 70       	call   0x70b6:0x5ed4
    7063:	8d be fc fd          	lea    di,[bp-0x204]
    7067:	16                   	push   ss
    7068:	57                   	push   di
    7069:	8d be 00 ff          	lea    di,[bp-0x100]
    706d:	16                   	push   ss
    706e:	57                   	push   di
    706f:	9a cd 17 7c 70       	call   0x707c:0x17cd
    7074:	bf 77 62             	mov    di,0x6277
    7077:	0e                   	push   cs
    7078:	57                   	push   di
    7079:	9a 4c 18 86 70       	call   0x7086:0x184c
    707e:	bf 77 62             	mov    di,0x6277
    7081:	0e                   	push   cs
    7082:	57                   	push   di
    7083:	9a 4c 18 94 70       	call   0x7094:0x184c
    7088:	8d be 00 ff          	lea    di,[bp-0x100]
    708c:	16                   	push   ss
    708d:	57                   	push   di
    708e:	68 ff 00             	push   0xff
    7091:	9a e7 17 0d 71       	call   0x710d:0x17e7
    7096:	8d be 00 ff          	lea    di,[bp-0x100]
    709a:	16                   	push   ss
    709b:	57                   	push   di
    709c:	68 ff 00             	push   0xff
    709f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70a2:	26 ff b5 0a 07       	push   WORD PTR es:[di+0x70a]
    70a7:	26 ff b5 08 07       	push   WORD PTR es:[di+0x708]
    70ac:	ff 36 36 02          	push   WORD PTR ds:0x236
    70b0:	6a 64                	push   0x64
    70b2:	55                   	push   bp
    70b3:	9a d4 5e fc 70       	call   0x70fc:0x5ed4
    70b8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    70bd:	76 18                	jbe    0x70d7
    70bf:	8d be 00 ff          	lea    di,[bp-0x100]
    70c3:	16                   	push   ss
    70c4:	57                   	push   di
    70c5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    70c9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    70ce:	06                   	push   es
    70cf:	57                   	push   di
    70d0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    70d3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    70d7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    70dc:	8d be 00 ff          	lea    di,[bp-0x100]
    70e0:	16                   	push   ss
    70e1:	57                   	push   di
    70e2:	68 ff 00             	push   0xff
    70e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70e8:	26 ff b5 e6 04       	push   WORD PTR es:[di+0x4e6]
    70ed:	26 ff b5 e4 04       	push   WORD PTR es:[di+0x4e4]
    70f2:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    70f6:	6a 67                	push   0x67
    70f8:	55                   	push   bp
    70f9:	9a d4 5e 51 71       	call   0x7151:0x5ed4
    70fe:	8d be fc fd          	lea    di,[bp-0x204]
    7102:	16                   	push   ss
    7103:	57                   	push   di
    7104:	8d be 00 ff          	lea    di,[bp-0x100]
    7108:	16                   	push   ss
    7109:	57                   	push   di
    710a:	9a cd 17 17 71       	call   0x7117:0x17cd
    710f:	bf 77 62             	mov    di,0x6277
    7112:	0e                   	push   cs
    7113:	57                   	push   di
    7114:	9a 4c 18 21 71       	call   0x7121:0x184c
    7119:	bf 77 62             	mov    di,0x6277
    711c:	0e                   	push   cs
    711d:	57                   	push   di
    711e:	9a 4c 18 2f 71       	call   0x712f:0x184c
    7123:	8d be 00 ff          	lea    di,[bp-0x100]
    7127:	16                   	push   ss
    7128:	57                   	push   di
    7129:	68 ff 00             	push   0xff
    712c:	9a e7 17 a8 71       	call   0x71a8:0x17e7
    7131:	8d be 00 ff          	lea    di,[bp-0x100]
    7135:	16                   	push   ss
    7136:	57                   	push   di
    7137:	68 ff 00             	push   0xff
    713a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    713d:	26 ff b5 0e 05       	push   WORD PTR es:[di+0x50e]
    7142:	26 ff b5 0c 05       	push   WORD PTR es:[di+0x50c]
    7147:	ff 36 36 02          	push   WORD PTR ds:0x236
    714b:	6a 64                	push   0x64
    714d:	55                   	push   bp
    714e:	9a d4 5e 97 71       	call   0x7197:0x5ed4
    7153:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7158:	76 18                	jbe    0x7172
    715a:	8d be 00 ff          	lea    di,[bp-0x100]
    715e:	16                   	push   ss
    715f:	57                   	push   di
    7160:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7164:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7169:	06                   	push   es
    716a:	57                   	push   di
    716b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    716e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7172:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7177:	8d be 00 ff          	lea    di,[bp-0x100]
    717b:	16                   	push   ss
    717c:	57                   	push   di
    717d:	68 ff 00             	push   0xff
    7180:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7183:	26 ff b5 f6 05       	push   WORD PTR es:[di+0x5f6]
    7188:	26 ff b5 f4 05       	push   WORD PTR es:[di+0x5f4]
    718d:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    7191:	6a 67                	push   0x67
    7193:	55                   	push   bp
    7194:	9a d4 5e ec 71       	call   0x71ec:0x5ed4
    7199:	8d be fc fd          	lea    di,[bp-0x204]
    719d:	16                   	push   ss
    719e:	57                   	push   di
    719f:	8d be 00 ff          	lea    di,[bp-0x100]
    71a3:	16                   	push   ss
    71a4:	57                   	push   di
    71a5:	9a cd 17 b2 71       	call   0x71b2:0x17cd
    71aa:	bf 77 62             	mov    di,0x6277
    71ad:	0e                   	push   cs
    71ae:	57                   	push   di
    71af:	9a 4c 18 bc 71       	call   0x71bc:0x184c
    71b4:	bf 77 62             	mov    di,0x6277
    71b7:	0e                   	push   cs
    71b8:	57                   	push   di
    71b9:	9a 4c 18 ca 71       	call   0x71ca:0x184c
    71be:	8d be 00 ff          	lea    di,[bp-0x100]
    71c2:	16                   	push   ss
    71c3:	57                   	push   di
    71c4:	68 ff 00             	push   0xff
    71c7:	9a e7 17 43 72       	call   0x7243:0x17e7
    71cc:	8d be 00 ff          	lea    di,[bp-0x100]
    71d0:	16                   	push   ss
    71d1:	57                   	push   di
    71d2:	68 ff 00             	push   0xff
    71d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71d8:	26 ff b5 fa 05       	push   WORD PTR es:[di+0x5fa]
    71dd:	26 ff b5 f8 05       	push   WORD PTR es:[di+0x5f8]
    71e2:	ff 36 36 02          	push   WORD PTR ds:0x236
    71e6:	6a 64                	push   0x64
    71e8:	55                   	push   bp
    71e9:	9a d4 5e 32 72       	call   0x7232:0x5ed4
    71ee:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    71f3:	76 18                	jbe    0x720d
    71f5:	8d be 00 ff          	lea    di,[bp-0x100]
    71f9:	16                   	push   ss
    71fa:	57                   	push   di
    71fb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    71ff:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7204:	06                   	push   es
    7205:	57                   	push   di
    7206:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7209:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    720d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7212:	8d be 00 ff          	lea    di,[bp-0x100]
    7216:	16                   	push   ss
    7217:	57                   	push   di
    7218:	68 ff 00             	push   0xff
    721b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    721e:	26 ff b5 42 06       	push   WORD PTR es:[di+0x642]
    7223:	26 ff b5 40 06       	push   WORD PTR es:[di+0x640]
    7228:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    722c:	6a 67                	push   0x67
    722e:	55                   	push   bp
    722f:	9a d4 5e 87 72       	call   0x7287:0x5ed4
    7234:	8d be fc fd          	lea    di,[bp-0x204]
    7238:	16                   	push   ss
    7239:	57                   	push   di
    723a:	8d be 00 ff          	lea    di,[bp-0x100]
    723e:	16                   	push   ss
    723f:	57                   	push   di
    7240:	9a cd 17 4d 72       	call   0x724d:0x17cd
    7245:	bf 77 62             	mov    di,0x6277
    7248:	0e                   	push   cs
    7249:	57                   	push   di
    724a:	9a 4c 18 57 72       	call   0x7257:0x184c
    724f:	bf 77 62             	mov    di,0x6277
    7252:	0e                   	push   cs
    7253:	57                   	push   di
    7254:	9a 4c 18 65 72       	call   0x7265:0x184c
    7259:	8d be 00 ff          	lea    di,[bp-0x100]
    725d:	16                   	push   ss
    725e:	57                   	push   di
    725f:	68 ff 00             	push   0xff
    7262:	9a e7 17 de 72       	call   0x72de:0x17e7
    7267:	8d be 00 ff          	lea    di,[bp-0x100]
    726b:	16                   	push   ss
    726c:	57                   	push   di
    726d:	68 ff 00             	push   0xff
    7270:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7273:	26 ff b5 46 06       	push   WORD PTR es:[di+0x646]
    7278:	26 ff b5 44 06       	push   WORD PTR es:[di+0x644]
    727d:	ff 36 36 02          	push   WORD PTR ds:0x236
    7281:	6a 64                	push   0x64
    7283:	55                   	push   bp
    7284:	9a d4 5e cd 72       	call   0x72cd:0x5ed4
    7289:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    728e:	76 18                	jbe    0x72a8
    7290:	8d be 00 ff          	lea    di,[bp-0x100]
    7294:	16                   	push   ss
    7295:	57                   	push   di
    7296:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    729a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    729f:	06                   	push   es
    72a0:	57                   	push   di
    72a1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    72a4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    72a8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    72ad:	8d be 00 ff          	lea    di,[bp-0x100]
    72b1:	16                   	push   ss
    72b2:	57                   	push   di
    72b3:	68 ff 00             	push   0xff
    72b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72b9:	26 ff b5 42 05       	push   WORD PTR es:[di+0x542]
    72be:	26 ff b5 40 05       	push   WORD PTR es:[di+0x540]
    72c3:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    72c7:	6a 67                	push   0x67
    72c9:	55                   	push   bp
    72ca:	9a d4 5e 22 73       	call   0x7322:0x5ed4
    72cf:	8d be fc fd          	lea    di,[bp-0x204]
    72d3:	16                   	push   ss
    72d4:	57                   	push   di
    72d5:	8d be 00 ff          	lea    di,[bp-0x100]
    72d9:	16                   	push   ss
    72da:	57                   	push   di
    72db:	9a cd 17 e8 72       	call   0x72e8:0x17cd
    72e0:	bf 77 62             	mov    di,0x6277
    72e3:	0e                   	push   cs
    72e4:	57                   	push   di
    72e5:	9a 4c 18 f2 72       	call   0x72f2:0x184c
    72ea:	bf 77 62             	mov    di,0x6277
    72ed:	0e                   	push   cs
    72ee:	57                   	push   di
    72ef:	9a 4c 18 00 73       	call   0x7300:0x184c
    72f4:	8d be 00 ff          	lea    di,[bp-0x100]
    72f8:	16                   	push   ss
    72f9:	57                   	push   di
    72fa:	68 ff 00             	push   0xff
    72fd:	9a e7 17 79 73       	call   0x7379:0x17e7
    7302:	8d be 00 ff          	lea    di,[bp-0x100]
    7306:	16                   	push   ss
    7307:	57                   	push   di
    7308:	68 ff 00             	push   0xff
    730b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    730e:	26 ff b5 46 05       	push   WORD PTR es:[di+0x546]
    7313:	26 ff b5 44 05       	push   WORD PTR es:[di+0x544]
    7318:	ff 36 36 02          	push   WORD PTR ds:0x236
    731c:	6a 64                	push   0x64
    731e:	55                   	push   bp
    731f:	9a d4 5e 68 73       	call   0x7368:0x5ed4
    7324:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7329:	76 18                	jbe    0x7343
    732b:	8d be 00 ff          	lea    di,[bp-0x100]
    732f:	16                   	push   ss
    7330:	57                   	push   di
    7331:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7335:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    733a:	06                   	push   es
    733b:	57                   	push   di
    733c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    733f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7343:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7348:	8d be 00 ff          	lea    di,[bp-0x100]
    734c:	16                   	push   ss
    734d:	57                   	push   di
    734e:	68 ff 00             	push   0xff
    7351:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7354:	26 ff b5 de 04       	push   WORD PTR es:[di+0x4de]
    7359:	26 ff b5 dc 04       	push   WORD PTR es:[di+0x4dc]
    735e:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    7362:	6a 67                	push   0x67
    7364:	55                   	push   bp
    7365:	9a d4 5e bd 73       	call   0x73bd:0x5ed4
    736a:	8d be fc fd          	lea    di,[bp-0x204]
    736e:	16                   	push   ss
    736f:	57                   	push   di
    7370:	8d be 00 ff          	lea    di,[bp-0x100]
    7374:	16                   	push   ss
    7375:	57                   	push   di
    7376:	9a cd 17 83 73       	call   0x7383:0x17cd
    737b:	bf 77 62             	mov    di,0x6277
    737e:	0e                   	push   cs
    737f:	57                   	push   di
    7380:	9a 4c 18 8d 73       	call   0x738d:0x184c
    7385:	bf 77 62             	mov    di,0x6277
    7388:	0e                   	push   cs
    7389:	57                   	push   di
    738a:	9a 4c 18 9b 73       	call   0x739b:0x184c
    738f:	8d be 00 ff          	lea    di,[bp-0x100]
    7393:	16                   	push   ss
    7394:	57                   	push   di
    7395:	68 ff 00             	push   0xff
    7398:	9a e7 17 ef 73       	call   0x73ef:0x17e7
    739d:	8d be 00 ff          	lea    di,[bp-0x100]
    73a1:	16                   	push   ss
    73a2:	57                   	push   di
    73a3:	68 ff 00             	push   0xff
    73a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73a9:	26 ff b5 06 05       	push   WORD PTR es:[di+0x506]
    73ae:	26 ff b5 04 05       	push   WORD PTR es:[di+0x504]
    73b3:	ff 36 36 02          	push   WORD PTR ds:0x236
    73b7:	6a 64                	push   0x64
    73b9:	55                   	push   bp
    73ba:	9a d4 5e 11 74       	call   0x7411:0x5ed4
    73bf:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    73c4:	76 18                	jbe    0x73de
    73c6:	8d be 00 ff          	lea    di,[bp-0x100]
    73ca:	16                   	push   ss
    73cb:	57                   	push   di
    73cc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    73d0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    73d5:	06                   	push   es
    73d6:	57                   	push   di
    73d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    73da:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    73de:	bf 7a 62             	mov    di,0x627a
    73e1:	0e                   	push   cs
    73e2:	57                   	push   di
    73e3:	8d be 00 ff          	lea    di,[bp-0x100]
    73e7:	16                   	push   ss
    73e8:	57                   	push   di
    73e9:	68 ff 00             	push   0xff
    73ec:	9a e7 17 0f 75       	call   0x750f:0x17e7
    73f1:	8d be 00 ff          	lea    di,[bp-0x100]
    73f5:	16                   	push   ss
    73f6:	57                   	push   di
    73f7:	68 ff 00             	push   0xff
    73fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73fd:	26 ff b5 36 05       	push   WORD PTR es:[di+0x536]
    7402:	26 ff b5 34 05       	push   WORD PTR es:[di+0x534]
    7407:	ff 36 32 02          	push   WORD PTR ds:0x232
    740b:	6a 64                	push   0x64
    740d:	55                   	push   bp
    740e:	9a d4 5e 33 74       	call   0x7433:0x5ed4
    7413:	8d be 00 ff          	lea    di,[bp-0x100]
    7417:	16                   	push   ss
    7418:	57                   	push   di
    7419:	68 ff 00             	push   0xff
    741c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    741f:	26 ff b5 72 05       	push   WORD PTR es:[di+0x572]
    7424:	26 ff b5 70 05       	push   WORD PTR es:[di+0x570]
    7429:	ff 36 34 02          	push   WORD PTR ds:0x234
    742d:	6a 64                	push   0x64
    742f:	55                   	push   bp
    7430:	9a d4 5e 55 74       	call   0x7455:0x5ed4
    7435:	8d be 00 ff          	lea    di,[bp-0x100]
    7439:	16                   	push   ss
    743a:	57                   	push   di
    743b:	68 ff 00             	push   0xff
    743e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7441:	26 ff b5 2a 05       	push   WORD PTR es:[di+0x52a]
    7446:	26 ff b5 28 05       	push   WORD PTR es:[di+0x528]
    744b:	ff 36 36 02          	push   WORD PTR ds:0x236
    744f:	6a 64                	push   0x64
    7451:	55                   	push   bp
    7452:	9a d4 5e b8 74       	call   0x74b8:0x5ed4
    7457:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    745c:	76 18                	jbe    0x7476
    745e:	8d be 00 ff          	lea    di,[bp-0x100]
    7462:	16                   	push   ss
    7463:	57                   	push   di
    7464:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7468:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    746d:	06                   	push   es
    746e:	57                   	push   di
    746f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7472:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7476:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    747a:	75 17                	jne    0x7493
    747c:	bf 79 62             	mov    di,0x6279
    747f:	0e                   	push   cs
    7480:	57                   	push   di
    7481:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7485:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    748a:	06                   	push   es
    748b:	57                   	push   di
    748c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    748f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7493:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7498:	8d be 00 ff          	lea    di,[bp-0x100]
    749c:	16                   	push   ss
    749d:	57                   	push   di
    749e:	68 ff 00             	push   0xff
    74a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74a4:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    74a9:	26 ff b5 7c 05       	push   WORD PTR es:[di+0x57c]
    74ae:	ff 36 2c 02          	push   WORD PTR ds:0x22c
    74b2:	6a 67                	push   0x67
    74b4:	55                   	push   bp
    74b5:	9a d4 5e fe 74       	call   0x74fe:0x5ed4
    74ba:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    74bf:	76 18                	jbe    0x74d9
    74c1:	8d be 00 ff          	lea    di,[bp-0x100]
    74c5:	16                   	push   ss
    74c6:	57                   	push   di
    74c7:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    74cb:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    74d0:	06                   	push   es
    74d1:	57                   	push   di
    74d2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    74d5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    74d9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    74de:	8d be 00 ff          	lea    di,[bp-0x100]
    74e2:	16                   	push   ss
    74e3:	57                   	push   di
    74e4:	68 ff 00             	push   0xff
    74e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74ea:	26 ff b5 82 05       	push   WORD PTR es:[di+0x582]
    74ef:	26 ff b5 80 05       	push   WORD PTR es:[di+0x580]
    74f4:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    74f8:	6a 67                	push   0x67
    74fa:	55                   	push   bp
    74fb:	9a d4 5e 49 75       	call   0x7549:0x5ed4
    7500:	8d be fc fd          	lea    di,[bp-0x204]
    7504:	16                   	push   ss
    7505:	57                   	push   di
    7506:	8d be 00 ff          	lea    di,[bp-0x100]
    750a:	16                   	push   ss
    750b:	57                   	push   di
    750c:	9a cd 17 19 75       	call   0x7519:0x17cd
    7511:	bf 77 62             	mov    di,0x6277
    7514:	0e                   	push   cs
    7515:	57                   	push   di
    7516:	9a 4c 18 27 75       	call   0x7527:0x184c
    751b:	8d be 00 ff          	lea    di,[bp-0x100]
    751f:	16                   	push   ss
    7520:	57                   	push   di
    7521:	68 ff 00             	push   0xff
    7524:	9a e7 17 a0 75       	call   0x75a0:0x17e7
    7529:	8d be 00 ff          	lea    di,[bp-0x100]
    752d:	16                   	push   ss
    752e:	57                   	push   di
    752f:	68 ff 00             	push   0xff
    7532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7535:	26 ff b5 8a 05       	push   WORD PTR es:[di+0x58a]
    753a:	26 ff b5 88 05       	push   WORD PTR es:[di+0x588]
    753f:	ff 36 34 02          	push   WORD PTR ds:0x234
    7543:	6a 64                	push   0x64
    7545:	55                   	push   bp
    7546:	9a d4 5e 8f 75       	call   0x758f:0x5ed4
    754b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7550:	76 18                	jbe    0x756a
    7552:	8d be 00 ff          	lea    di,[bp-0x100]
    7556:	16                   	push   ss
    7557:	57                   	push   di
    7558:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    755c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7561:	06                   	push   es
    7562:	57                   	push   di
    7563:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7566:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    756a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    756f:	8d be 00 ff          	lea    di,[bp-0x100]
    7573:	16                   	push   ss
    7574:	57                   	push   di
    7575:	68 ff 00             	push   0xff
    7578:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    757b:	26 ff b5 86 05       	push   WORD PTR es:[di+0x586]
    7580:	26 ff b5 84 05       	push   WORD PTR es:[di+0x584]
    7585:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    7589:	6a 67                	push   0x67
    758b:	55                   	push   bp
    758c:	9a d4 5e da 75       	call   0x75da:0x5ed4
    7591:	8d be fc fd          	lea    di,[bp-0x204]
    7595:	16                   	push   ss
    7596:	57                   	push   di
    7597:	8d be 00 ff          	lea    di,[bp-0x100]
    759b:	16                   	push   ss
    759c:	57                   	push   di
    759d:	9a cd 17 aa 75       	call   0x75aa:0x17cd
    75a2:	bf 77 62             	mov    di,0x6277
    75a5:	0e                   	push   cs
    75a6:	57                   	push   di
    75a7:	9a 4c 18 b8 75       	call   0x75b8:0x184c
    75ac:	8d be 00 ff          	lea    di,[bp-0x100]
    75b0:	16                   	push   ss
    75b1:	57                   	push   di
    75b2:	68 ff 00             	push   0xff
    75b5:	9a e7 17 b6 76       	call   0x76b6:0x17e7
    75ba:	8d be 00 ff          	lea    di,[bp-0x100]
    75be:	16                   	push   ss
    75bf:	57                   	push   di
    75c0:	68 ff 00             	push   0xff
    75c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75c6:	26 ff b5 8e 05       	push   WORD PTR es:[di+0x58e]
    75cb:	26 ff b5 8c 05       	push   WORD PTR es:[di+0x58c]
    75d0:	ff 36 34 02          	push   WORD PTR ds:0x234
    75d4:	6a 64                	push   0x64
    75d6:	55                   	push   bp
    75d7:	9a d4 5e fc 75       	call   0x75fc:0x5ed4
    75dc:	8d be 00 ff          	lea    di,[bp-0x100]
    75e0:	16                   	push   ss
    75e1:	57                   	push   di
    75e2:	68 ff 00             	push   0xff
    75e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75e8:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    75ed:	26 ff b5 90 05       	push   WORD PTR es:[di+0x590]
    75f2:	ff 36 36 02          	push   WORD PTR ds:0x236
    75f6:	6a 64                	push   0x64
    75f8:	55                   	push   bp
    75f9:	9a d4 5e 5f 76       	call   0x765f:0x5ed4
    75fe:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7603:	76 18                	jbe    0x761d
    7605:	8d be 00 ff          	lea    di,[bp-0x100]
    7609:	16                   	push   ss
    760a:	57                   	push   di
    760b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    760f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7614:	06                   	push   es
    7615:	57                   	push   di
    7616:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7619:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    761d:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    7621:	75 17                	jne    0x763a
    7623:	bf 79 62             	mov    di,0x6279
    7626:	0e                   	push   cs
    7627:	57                   	push   di
    7628:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    762c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7631:	06                   	push   es
    7632:	57                   	push   di
    7633:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7636:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    763a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    763f:	8d be 00 ff          	lea    di,[bp-0x100]
    7643:	16                   	push   ss
    7644:	57                   	push   di
    7645:	68 ff 00             	push   0xff
    7648:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    764b:	26 ff b5 9a 05       	push   WORD PTR es:[di+0x59a]
    7650:	26 ff b5 98 05       	push   WORD PTR es:[di+0x598]
    7655:	ff 36 2c 02          	push   WORD PTR ds:0x22c
    7659:	6a 67                	push   0x67
    765b:	55                   	push   bp
    765c:	9a d4 5e a5 76       	call   0x76a5:0x5ed4
    7661:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7666:	76 18                	jbe    0x7680
    7668:	8d be 00 ff          	lea    di,[bp-0x100]
    766c:	16                   	push   ss
    766d:	57                   	push   di
    766e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7672:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7677:	06                   	push   es
    7678:	57                   	push   di
    7679:	26 c4 3d             	les    di,DWORD PTR es:[di]
    767c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7680:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7685:	8d be 00 ff          	lea    di,[bp-0x100]
    7689:	16                   	push   ss
    768a:	57                   	push   di
    768b:	68 ff 00             	push   0xff
    768e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7691:	26 ff b5 a6 05       	push   WORD PTR es:[di+0x5a6]
    7696:	26 ff b5 a4 05       	push   WORD PTR es:[di+0x5a4]
    769b:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    769f:	6a 67                	push   0x67
    76a1:	55                   	push   bp
    76a2:	9a d4 5e fa 76       	call   0x76fa:0x5ed4
    76a7:	8d be fc fd          	lea    di,[bp-0x204]
    76ab:	16                   	push   ss
    76ac:	57                   	push   di
    76ad:	8d be 00 ff          	lea    di,[bp-0x100]
    76b1:	16                   	push   ss
    76b2:	57                   	push   di
    76b3:	9a cd 17 c0 76       	call   0x76c0:0x17cd
    76b8:	bf 77 62             	mov    di,0x6277
    76bb:	0e                   	push   cs
    76bc:	57                   	push   di
    76bd:	9a 4c 18 ca 76       	call   0x76ca:0x184c
    76c2:	bf 77 62             	mov    di,0x6277
    76c5:	0e                   	push   cs
    76c6:	57                   	push   di
    76c7:	9a 4c 18 d8 76       	call   0x76d8:0x184c
    76cc:	8d be 00 ff          	lea    di,[bp-0x100]
    76d0:	16                   	push   ss
    76d1:	57                   	push   di
    76d2:	68 ff 00             	push   0xff
    76d5:	9a e7 17 51 77       	call   0x7751:0x17e7
    76da:	8d be 00 ff          	lea    di,[bp-0x100]
    76de:	16                   	push   ss
    76df:	57                   	push   di
    76e0:	68 ff 00             	push   0xff
    76e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76e6:	26 ff b5 ba 05       	push   WORD PTR es:[di+0x5ba]
    76eb:	26 ff b5 b8 05       	push   WORD PTR es:[di+0x5b8]
    76f0:	ff 36 36 02          	push   WORD PTR ds:0x236
    76f4:	6a 64                	push   0x64
    76f6:	55                   	push   bp
    76f7:	9a d4 5e 40 77       	call   0x7740:0x5ed4
    76fc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7701:	76 18                	jbe    0x771b
    7703:	8d be 00 ff          	lea    di,[bp-0x100]
    7707:	16                   	push   ss
    7708:	57                   	push   di
    7709:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    770d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7712:	06                   	push   es
    7713:	57                   	push   di
    7714:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7717:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    771b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7720:	8d be 00 ff          	lea    di,[bp-0x100]
    7724:	16                   	push   ss
    7725:	57                   	push   di
    7726:	68 ff 00             	push   0xff
    7729:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    772c:	26 ff b5 aa 05       	push   WORD PTR es:[di+0x5aa]
    7731:	26 ff b5 a8 05       	push   WORD PTR es:[di+0x5a8]
    7736:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    773a:	6a 67                	push   0x67
    773c:	55                   	push   bp
    773d:	9a d4 5e 95 77       	call   0x7795:0x5ed4
    7742:	8d be fc fd          	lea    di,[bp-0x204]
    7746:	16                   	push   ss
    7747:	57                   	push   di
    7748:	8d be 00 ff          	lea    di,[bp-0x100]
    774c:	16                   	push   ss
    774d:	57                   	push   di
    774e:	9a cd 17 5b 77       	call   0x775b:0x17cd
    7753:	bf 77 62             	mov    di,0x6277
    7756:	0e                   	push   cs
    7757:	57                   	push   di
    7758:	9a 4c 18 65 77       	call   0x7765:0x184c
    775d:	bf 77 62             	mov    di,0x6277
    7760:	0e                   	push   cs
    7761:	57                   	push   di
    7762:	9a 4c 18 73 77       	call   0x7773:0x184c
    7767:	8d be 00 ff          	lea    di,[bp-0x100]
    776b:	16                   	push   ss
    776c:	57                   	push   di
    776d:	68 ff 00             	push   0xff
    7770:	9a e7 17 32 78       	call   0x7832:0x17e7
    7775:	8d be 00 ff          	lea    di,[bp-0x100]
    7779:	16                   	push   ss
    777a:	57                   	push   di
    777b:	68 ff 00             	push   0xff
    777e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7781:	26 ff b5 be 05       	push   WORD PTR es:[di+0x5be]
    7786:	26 ff b5 bc 05       	push   WORD PTR es:[di+0x5bc]
    778b:	ff 36 36 02          	push   WORD PTR ds:0x236
    778f:	6a 64                	push   0x64
    7791:	55                   	push   bp
    7792:	9a d4 5e db 77       	call   0x77db:0x5ed4
    7797:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    779c:	76 18                	jbe    0x77b6
    779e:	8d be 00 ff          	lea    di,[bp-0x100]
    77a2:	16                   	push   ss
    77a3:	57                   	push   di
    77a4:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    77a8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    77ad:	06                   	push   es
    77ae:	57                   	push   di
    77af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77b2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    77b6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    77bb:	8d be 00 ff          	lea    di,[bp-0x100]
    77bf:	16                   	push   ss
    77c0:	57                   	push   di
    77c1:	68 ff 00             	push   0xff
    77c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77c7:	26 ff b5 ce 05       	push   WORD PTR es:[di+0x5ce]
    77cc:	26 ff b5 cc 05       	push   WORD PTR es:[di+0x5cc]
    77d1:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    77d5:	6a 67                	push   0x67
    77d7:	55                   	push   bp
    77d8:	9a d4 5e 21 78       	call   0x7821:0x5ed4
    77dd:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    77e2:	76 18                	jbe    0x77fc
    77e4:	8d be 00 ff          	lea    di,[bp-0x100]
    77e8:	16                   	push   ss
    77e9:	57                   	push   di
    77ea:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    77ee:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    77f3:	06                   	push   es
    77f4:	57                   	push   di
    77f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77f8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    77fc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7801:	8d be 00 ff          	lea    di,[bp-0x100]
    7805:	16                   	push   ss
    7806:	57                   	push   di
    7807:	68 ff 00             	push   0xff
    780a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    780d:	26 ff b5 32 06       	push   WORD PTR es:[di+0x632]
    7812:	26 ff b5 30 06       	push   WORD PTR es:[di+0x630]
    7817:	ff 36 30 02          	push   WORD PTR ds:0x230
    781b:	6a 67                	push   0x67
    781d:	55                   	push   bp
    781e:	9a d4 5e 6c 78       	call   0x786c:0x5ed4
    7823:	8d be fc fd          	lea    di,[bp-0x204]
    7827:	16                   	push   ss
    7828:	57                   	push   di
    7829:	8d be 00 ff          	lea    di,[bp-0x100]
    782d:	16                   	push   ss
    782e:	57                   	push   di
    782f:	9a cd 17 3c 78       	call   0x783c:0x17cd
    7834:	bf 77 62             	mov    di,0x6277
    7837:	0e                   	push   cs
    7838:	57                   	push   di
    7839:	9a 4c 18 4a 78       	call   0x784a:0x184c
    783e:	8d be 00 ff          	lea    di,[bp-0x100]
    7842:	16                   	push   ss
    7843:	57                   	push   di
    7844:	68 ff 00             	push   0xff
    7847:	9a e7 17 c3 78       	call   0x78c3:0x17e7
    784c:	8d be 00 ff          	lea    di,[bp-0x100]
    7850:	16                   	push   ss
    7851:	57                   	push   di
    7852:	68 ff 00             	push   0xff
    7855:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7858:	26 ff b5 26 06       	push   WORD PTR es:[di+0x626]
    785d:	26 ff b5 24 06       	push   WORD PTR es:[di+0x624]
    7862:	ff 36 34 02          	push   WORD PTR ds:0x234
    7866:	6a 64                	push   0x64
    7868:	55                   	push   bp
    7869:	9a d4 5e b2 78       	call   0x78b2:0x5ed4
    786e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7873:	76 18                	jbe    0x788d
    7875:	8d be 00 ff          	lea    di,[bp-0x100]
    7879:	16                   	push   ss
    787a:	57                   	push   di
    787b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    787f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7884:	06                   	push   es
    7885:	57                   	push   di
    7886:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7889:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    788d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7892:	8d be 00 ff          	lea    di,[bp-0x100]
    7896:	16                   	push   ss
    7897:	57                   	push   di
    7898:	68 ff 00             	push   0xff
    789b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    789e:	26 ff b5 36 06       	push   WORD PTR es:[di+0x636]
    78a3:	26 ff b5 34 06       	push   WORD PTR es:[di+0x634]
    78a8:	ff 36 30 02          	push   WORD PTR ds:0x230
    78ac:	6a 67                	push   0x67
    78ae:	55                   	push   bp
    78af:	9a d4 5e fd 78       	call   0x78fd:0x5ed4
    78b4:	8d be fc fd          	lea    di,[bp-0x204]
    78b8:	16                   	push   ss
    78b9:	57                   	push   di
    78ba:	8d be 00 ff          	lea    di,[bp-0x100]
    78be:	16                   	push   ss
    78bf:	57                   	push   di
    78c0:	9a cd 17 cd 78       	call   0x78cd:0x17cd
    78c5:	bf 77 62             	mov    di,0x6277
    78c8:	0e                   	push   cs
    78c9:	57                   	push   di
    78ca:	9a 4c 18 db 78       	call   0x78db:0x184c
    78cf:	8d be 00 ff          	lea    di,[bp-0x100]
    78d3:	16                   	push   ss
    78d4:	57                   	push   di
    78d5:	68 ff 00             	push   0xff
    78d8:	9a e7 17 76 79       	call   0x7976:0x17e7
    78dd:	8d be 00 ff          	lea    di,[bp-0x100]
    78e1:	16                   	push   ss
    78e2:	57                   	push   di
    78e3:	68 ff 00             	push   0xff
    78e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78e9:	26 ff b5 2a 06       	push   WORD PTR es:[di+0x62a]
    78ee:	26 ff b5 28 06       	push   WORD PTR es:[di+0x628]
    78f3:	ff 36 34 02          	push   WORD PTR ds:0x234
    78f7:	6a 64                	push   0x64
    78f9:	55                   	push   bp
    78fa:	9a d4 5e 1f 79       	call   0x791f:0x5ed4
    78ff:	8d be 00 ff          	lea    di,[bp-0x100]
    7903:	16                   	push   ss
    7904:	57                   	push   di
    7905:	68 ff 00             	push   0xff
    7908:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    790b:	26 ff b5 d2 05       	push   WORD PTR es:[di+0x5d2]
    7910:	26 ff b5 d0 05       	push   WORD PTR es:[di+0x5d0]
    7915:	ff 36 36 02          	push   WORD PTR ds:0x236
    7919:	6a 64                	push   0x64
    791b:	55                   	push   bp
    791c:	9a d4 5e 65 79       	call   0x7965:0x5ed4
    7921:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7926:	76 18                	jbe    0x7940
    7928:	8d be 00 ff          	lea    di,[bp-0x100]
    792c:	16                   	push   ss
    792d:	57                   	push   di
    792e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7932:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7937:	06                   	push   es
    7938:	57                   	push   di
    7939:	26 c4 3d             	les    di,DWORD PTR es:[di]
    793c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7940:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7945:	8d be 00 ff          	lea    di,[bp-0x100]
    7949:	16                   	push   ss
    794a:	57                   	push   di
    794b:	68 ff 00             	push   0xff
    794e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7951:	26 ff b5 56 06       	push   WORD PTR es:[di+0x656]
    7956:	26 ff b5 54 06       	push   WORD PTR es:[di+0x654]
    795b:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    795f:	6a 67                	push   0x67
    7961:	55                   	push   bp
    7962:	9a d4 5e ba 79       	call   0x79ba:0x5ed4
    7967:	8d be fc fd          	lea    di,[bp-0x204]
    796b:	16                   	push   ss
    796c:	57                   	push   di
    796d:	8d be 00 ff          	lea    di,[bp-0x100]
    7971:	16                   	push   ss
    7972:	57                   	push   di
    7973:	9a cd 17 80 79       	call   0x7980:0x17cd
    7978:	bf 77 62             	mov    di,0x6277
    797b:	0e                   	push   cs
    797c:	57                   	push   di
    797d:	9a 4c 18 8a 79       	call   0x798a:0x184c
    7982:	bf 77 62             	mov    di,0x6277
    7985:	0e                   	push   cs
    7986:	57                   	push   di
    7987:	9a 4c 18 98 79       	call   0x7998:0x184c
    798c:	8d be 00 ff          	lea    di,[bp-0x100]
    7990:	16                   	push   ss
    7991:	57                   	push   di
    7992:	68 ff 00             	push   0xff
    7995:	9a e7 17 11 7a       	call   0x7a11:0x17e7
    799a:	8d be 00 ff          	lea    di,[bp-0x100]
    799e:	16                   	push   ss
    799f:	57                   	push   di
    79a0:	68 ff 00             	push   0xff
    79a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79a6:	26 ff b5 5a 06       	push   WORD PTR es:[di+0x65a]
    79ab:	26 ff b5 58 06       	push   WORD PTR es:[di+0x658]
    79b0:	ff 36 36 02          	push   WORD PTR ds:0x236
    79b4:	6a 64                	push   0x64
    79b6:	55                   	push   bp
    79b7:	9a d4 5e 00 7a       	call   0x7a00:0x5ed4
    79bc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    79c1:	76 18                	jbe    0x79db
    79c3:	8d be 00 ff          	lea    di,[bp-0x100]
    79c7:	16                   	push   ss
    79c8:	57                   	push   di
    79c9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    79cd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    79d2:	06                   	push   es
    79d3:	57                   	push   di
    79d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    79d7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    79db:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    79e0:	8d be 00 ff          	lea    di,[bp-0x100]
    79e4:	16                   	push   ss
    79e5:	57                   	push   di
    79e6:	68 ff 00             	push   0xff
    79e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79ec:	26 ff b5 ae 05       	push   WORD PTR es:[di+0x5ae]
    79f1:	26 ff b5 ac 05       	push   WORD PTR es:[di+0x5ac]
    79f6:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    79fa:	6a 67                	push   0x67
    79fc:	55                   	push   bp
    79fd:	9a d4 5e 55 7a       	call   0x7a55:0x5ed4
    7a02:	8d be fc fd          	lea    di,[bp-0x204]
    7a06:	16                   	push   ss
    7a07:	57                   	push   di
    7a08:	8d be 00 ff          	lea    di,[bp-0x100]
    7a0c:	16                   	push   ss
    7a0d:	57                   	push   di
    7a0e:	9a cd 17 1b 7a       	call   0x7a1b:0x17cd
    7a13:	bf 77 62             	mov    di,0x6277
    7a16:	0e                   	push   cs
    7a17:	57                   	push   di
    7a18:	9a 4c 18 25 7a       	call   0x7a25:0x184c
    7a1d:	bf 77 62             	mov    di,0x6277
    7a20:	0e                   	push   cs
    7a21:	57                   	push   di
    7a22:	9a 4c 18 33 7a       	call   0x7a33:0x184c
    7a27:	8d be 00 ff          	lea    di,[bp-0x100]
    7a2b:	16                   	push   ss
    7a2c:	57                   	push   di
    7a2d:	68 ff 00             	push   0xff
    7a30:	9a e7 17 ac 7a       	call   0x7aac:0x17e7
    7a35:	8d be 00 ff          	lea    di,[bp-0x100]
    7a39:	16                   	push   ss
    7a3a:	57                   	push   di
    7a3b:	68 ff 00             	push   0xff
    7a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a41:	26 ff b5 c2 05       	push   WORD PTR es:[di+0x5c2]
    7a46:	26 ff b5 c0 05       	push   WORD PTR es:[di+0x5c0]
    7a4b:	ff 36 36 02          	push   WORD PTR ds:0x236
    7a4f:	6a 64                	push   0x64
    7a51:	55                   	push   bp
    7a52:	9a d4 5e 9b 7a       	call   0x7a9b:0x5ed4
    7a57:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7a5c:	76 18                	jbe    0x7a76
    7a5e:	8d be 00 ff          	lea    di,[bp-0x100]
    7a62:	16                   	push   ss
    7a63:	57                   	push   di
    7a64:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7a68:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7a6d:	06                   	push   es
    7a6e:	57                   	push   di
    7a6f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7a72:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7a76:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7a7b:	8d be 00 ff          	lea    di,[bp-0x100]
    7a7f:	16                   	push   ss
    7a80:	57                   	push   di
    7a81:	68 ff 00             	push   0xff
    7a84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a87:	26 ff b5 b2 05       	push   WORD PTR es:[di+0x5b2]
    7a8c:	26 ff b5 b0 05       	push   WORD PTR es:[di+0x5b0]
    7a91:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    7a95:	6a 67                	push   0x67
    7a97:	55                   	push   bp
    7a98:	9a d4 5e f0 7a       	call   0x7af0:0x5ed4
    7a9d:	8d be fc fd          	lea    di,[bp-0x204]
    7aa1:	16                   	push   ss
    7aa2:	57                   	push   di
    7aa3:	8d be 00 ff          	lea    di,[bp-0x100]
    7aa7:	16                   	push   ss
    7aa8:	57                   	push   di
    7aa9:	9a cd 17 b6 7a       	call   0x7ab6:0x17cd
    7aae:	bf 77 62             	mov    di,0x6277
    7ab1:	0e                   	push   cs
    7ab2:	57                   	push   di
    7ab3:	9a 4c 18 c0 7a       	call   0x7ac0:0x184c
    7ab8:	bf 77 62             	mov    di,0x6277
    7abb:	0e                   	push   cs
    7abc:	57                   	push   di
    7abd:	9a 4c 18 ce 7a       	call   0x7ace:0x184c
    7ac2:	8d be 00 ff          	lea    di,[bp-0x100]
    7ac6:	16                   	push   ss
    7ac7:	57                   	push   di
    7ac8:	68 ff 00             	push   0xff
    7acb:	9a e7 17 47 7b       	call   0x7b47:0x17e7
    7ad0:	8d be 00 ff          	lea    di,[bp-0x100]
    7ad4:	16                   	push   ss
    7ad5:	57                   	push   di
    7ad6:	68 ff 00             	push   0xff
    7ad9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7adc:	26 ff b5 c6 05       	push   WORD PTR es:[di+0x5c6]
    7ae1:	26 ff b5 c4 05       	push   WORD PTR es:[di+0x5c4]
    7ae6:	ff 36 36 02          	push   WORD PTR ds:0x236
    7aea:	6a 64                	push   0x64
    7aec:	55                   	push   bp
    7aed:	9a d4 5e 36 7b       	call   0x7b36:0x5ed4
    7af2:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7af7:	76 18                	jbe    0x7b11
    7af9:	8d be 00 ff          	lea    di,[bp-0x100]
    7afd:	16                   	push   ss
    7afe:	57                   	push   di
    7aff:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b03:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7b08:	06                   	push   es
    7b09:	57                   	push   di
    7b0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7b0d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7b11:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7b16:	8d be 00 ff          	lea    di,[bp-0x100]
    7b1a:	16                   	push   ss
    7b1b:	57                   	push   di
    7b1c:	68 ff 00             	push   0xff
    7b1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b22:	26 ff b5 b6 05       	push   WORD PTR es:[di+0x5b6]
    7b27:	26 ff b5 b4 05       	push   WORD PTR es:[di+0x5b4]
    7b2c:	ff 36 2e 02          	push   WORD PTR ds:0x22e
    7b30:	6a 67                	push   0x67
    7b32:	55                   	push   bp
    7b33:	9a d4 5e 8b 7b       	call   0x7b8b:0x5ed4
    7b38:	8d be fc fd          	lea    di,[bp-0x204]
    7b3c:	16                   	push   ss
    7b3d:	57                   	push   di
    7b3e:	8d be 00 ff          	lea    di,[bp-0x100]
    7b42:	16                   	push   ss
    7b43:	57                   	push   di
    7b44:	9a cd 17 51 7b       	call   0x7b51:0x17cd
    7b49:	bf 77 62             	mov    di,0x6277
    7b4c:	0e                   	push   cs
    7b4d:	57                   	push   di
    7b4e:	9a 4c 18 5b 7b       	call   0x7b5b:0x184c
    7b53:	bf 77 62             	mov    di,0x6277
    7b56:	0e                   	push   cs
    7b57:	57                   	push   di
    7b58:	9a 4c 18 69 7b       	call   0x7b69:0x184c
    7b5d:	8d be 00 ff          	lea    di,[bp-0x100]
    7b61:	16                   	push   ss
    7b62:	57                   	push   di
    7b63:	68 ff 00             	push   0xff
    7b66:	9a e7 17 b8 7b       	call   0x7bb8:0x17e7
    7b6b:	8d be 00 ff          	lea    di,[bp-0x100]
    7b6f:	16                   	push   ss
    7b70:	57                   	push   di
    7b71:	68 ff 00             	push   0xff
    7b74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b77:	26 ff b5 ca 05       	push   WORD PTR es:[di+0x5ca]
    7b7c:	26 ff b5 c8 05       	push   WORD PTR es:[di+0x5c8]
    7b81:	ff 36 36 02          	push   WORD PTR ds:0x236
    7b85:	6a 64                	push   0x64
    7b87:	55                   	push   bp
    7b88:	9a d4 5e ff ff       	call   0xffff:0x5ed4
    7b8d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7b92:	76 18                	jbe    0x7bac
    7b94:	8d be 00 ff          	lea    di,[bp-0x100]
    7b98:	16                   	push   ss
    7b99:	57                   	push   di
    7b9a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7b9e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7ba3:	06                   	push   es
    7ba4:	57                   	push   di
    7ba5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7ba8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7bac:	c9                   	leave
    7bad:	ca 06 00             	retf   0x6
    7bb0:	55                   	push   bp
    7bb1:	89 e5                	mov    bp,sp
    7bb3:	31 c0                	xor    ax,ax
    7bb5:	9a 44 04 e6 7b       	call   0x7be6:0x444
    7bba:	c7 06 44 01 15 00    	mov    WORD PTR ds:0x144,0x15
    7bc0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bc3:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    7bc8:	a3 46 01             	mov    ds:0x146,ax
    7bcb:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    7bd0:	a3 48 01             	mov    ds:0x148,ax
    7bd3:	06                   	push   es
    7bd4:	57                   	push   di
    7bd5:	9a 56 55 06 7c       	call   0x7c06:0x5556
    7bda:	c9                   	leave
    7bdb:	ca 08 00             	retf   0x8
    7bde:	55                   	push   bp
    7bdf:	89 e5                	mov    bp,sp
    7be1:	31 c0                	xor    ax,ax
    7be3:	9a 44 04 14 7c       	call   0x7c14:0x444
    7be8:	c7 06 44 01 16 00    	mov    WORD PTR ds:0x144,0x16
    7bee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bf1:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    7bf6:	a3 46 01             	mov    ds:0x146,ax
    7bf9:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    7bfe:	a3 48 01             	mov    ds:0x148,ax
    7c01:	06                   	push   es
    7c02:	57                   	push   di
    7c03:	9a 56 55 34 7c       	call   0x7c34:0x5556
    7c08:	c9                   	leave
    7c09:	ca 08 00             	retf   0x8
    7c0c:	55                   	push   bp
    7c0d:	89 e5                	mov    bp,sp
    7c0f:	31 c0                	xor    ax,ax
    7c11:	9a 44 04 42 7c       	call   0x7c42:0x444
    7c16:	c7 06 44 01 17 00    	mov    WORD PTR ds:0x144,0x17
    7c1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c1f:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    7c24:	a3 46 01             	mov    ds:0x146,ax
    7c27:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    7c2c:	a3 48 01             	mov    ds:0x148,ax
    7c2f:	06                   	push   es
    7c30:	57                   	push   di
    7c31:	9a 56 55 62 7c       	call   0x7c62:0x5556
    7c36:	c9                   	leave
    7c37:	ca 08 00             	retf   0x8
    7c3a:	55                   	push   bp
    7c3b:	89 e5                	mov    bp,sp
    7c3d:	31 c0                	xor    ax,ax
    7c3f:	9a 44 04 70 7c       	call   0x7c70:0x444
    7c44:	c7 06 44 01 18 00    	mov    WORD PTR ds:0x144,0x18
    7c4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c4d:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    7c52:	a3 46 01             	mov    ds:0x146,ax
    7c55:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    7c5a:	a3 48 01             	mov    ds:0x148,ax
    7c5d:	06                   	push   es
    7c5e:	57                   	push   di
    7c5f:	9a 56 55 90 7c       	call   0x7c90:0x5556
    7c64:	c9                   	leave
    7c65:	ca 08 00             	retf   0x8
    7c68:	55                   	push   bp
    7c69:	89 e5                	mov    bp,sp
    7c6b:	31 c0                	xor    ax,ax
    7c6d:	9a 44 04 9e 7c       	call   0x7c9e:0x444
    7c72:	c7 06 44 01 19 00    	mov    WORD PTR ds:0x144,0x19
    7c78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c7b:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    7c80:	a3 46 01             	mov    ds:0x146,ax
    7c83:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    7c88:	a3 48 01             	mov    ds:0x148,ax
    7c8b:	06                   	push   es
    7c8c:	57                   	push   di
    7c8d:	9a 56 55 be 7c       	call   0x7cbe:0x5556
    7c92:	c9                   	leave
    7c93:	ca 08 00             	retf   0x8
    7c96:	55                   	push   bp
    7c97:	89 e5                	mov    bp,sp
    7c99:	31 c0                	xor    ax,ax
    7c9b:	9a 44 04 cc 7c       	call   0x7ccc:0x444
    7ca0:	c7 06 44 01 1a 00    	mov    WORD PTR ds:0x144,0x1a
    7ca6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ca9:	26 8b 85 2c 07       	mov    ax,WORD PTR es:[di+0x72c]
    7cae:	a3 46 01             	mov    ds:0x146,ax
    7cb1:	26 8b 85 2a 07       	mov    ax,WORD PTR es:[di+0x72a]
    7cb6:	a3 48 01             	mov    ds:0x148,ax
    7cb9:	06                   	push   es
    7cba:	57                   	push   di
    7cbb:	9a 56 55 ff ff       	call   0xffff:0x5556
    7cc0:	c9                   	leave
    7cc1:	ca 08 00             	retf   0x8
    7cc4:	55                   	push   bp
    7cc5:	89 e5                	mov    bp,sp
    7cc7:	31 c0                	xor    ax,ax
    7cc9:	9a 44 04 ff ff       	call   0xffff:0x444
    7cce:	ff 36 50 01          	push   WORD PTR ds:0x150
    7cd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cd5:	26 ff b5 2a 07       	push   WORD PTR es:[di+0x72a]
    7cda:	26 ff b5 2c 07       	push   WORD PTR es:[di+0x72c]
    7cdf:	9a a1 0c ff ff       	call   0xffff:0xca1
    7ce4:	c9                   	leave
    7ce5:	ca                   	.byte 0xca
    7ce6:	08                   	.byte 0x8
