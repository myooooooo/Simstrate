; ================================================================
; seg44_CODE  (9079 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	2c 00                	sub    al,0x0
       2:	45                   	inc    bp
       3:	55                   	push   bp
       4:	8b ec                	mov    bp,sp
       6:	1e                   	push   ds
       7:	0b c0                	or     ax,ax
       9:	74 50                	je     0x5b
       b:	8c 06 76 18          	mov    WORD PTR ds:0x1876,es
       f:	89 36 8a 18          	mov    WORD PTR ds:0x188a,si
      13:	89 3e 8c 18          	mov    WORD PTR ds:0x188c,di
      17:	89 16 8e 18          	mov    WORD PTR ds:0x188e,dx
      1b:	89 1e 90 18          	mov    WORD PTR ds:0x1890,bx
      1f:	8c 06 92 18          	mov    WORD PTR ds:0x1892,es
      23:	33 c0                	xor    ax,ax
      25:	50                   	push   ax
      26:	9a ff ff 00 00       	call   0x0:0xffff
      2b:	ff 36 8c 18          	push   WORD PTR ds:0x188c
      2f:	9a ff ff 00 00       	call   0x0:0xffff
      34:	0b c0                	or     ax,ax
      36:	74 23                	je     0x5b
      38:	9a ff ff 00 00       	call   0x0:0xffff
      3d:	33 d2                	xor    dx,dx
      3f:	a8 c0                	test   al,0xc0
      41:	75 06                	jne    0x49
      43:	42                   	inc    dx
      44:	a8 02                	test   al,0x2
      46:	75 01                	jne    0x49
      48:	42                   	inc    dx
      49:	88 16 88 18          	mov    BYTE PTR ds:0x1888,dl
      4d:	c7 06 7e 18 ff ff    	mov    WORD PTR ds:0x187e,0xffff
      53:	e8 94 15             	call   0x15ea
      56:	8b e5                	mov    sp,bp
      58:	5d                   	pop    bp
      59:	4d                   	dec    bp
      5a:	cb                   	retf
      5b:	b8 ff 4c             	mov    ax,0x4cff
      5e:	cd 21                	int    0x21
      60:	59                   	pop    cx
      61:	5b                   	pop    bx
      62:	8b 16 60 18          	mov    dx,WORD PTR ds:0x1860
      66:	0b 16 62 18          	or     dx,WORD PTR ds:0x1862
      6a:	74 07                	je     0x73
      6c:	50                   	push   ax
      6d:	53                   	push   bx
      6e:	51                   	push   cx
      6f:	ff 1e 60 18          	call   DWORD PTR ds:0x1860
      73:	8b f8                	mov    di,ax
      75:	a1 78 18             	mov    ax,ds:0x1878
      78:	0b ff                	or     di,di
      7a:	74 1b                	je     0x97
      7c:	2e 8a 85 84 00       	mov    al,BYTE PTR cs:[di+0x84]
      81:	32 e4                	xor    ah,ah
      83:	eb 12                	jmp    0x97
      85:	cb                   	retf
      86:	cc                   	int3
      87:	c8 c9 d7 cf          	enter  0xd7c9,0xcf
      8b:	c8 cd ce db          	enter  0xcecd,0xdb
      8f:	59                   	pop    cx
      90:	5b                   	pop    bx
      91:	eb 04                	jmp    0x97
      93:	33 c9                	xor    cx,cx
      95:	33 db                	xor    bx,bx
      97:	a3 70 18             	mov    ds:0x1870,ax
      9a:	8b c1                	mov    ax,cx
      9c:	0b c3                	or     ax,bx
      9e:	74 0c                	je     0xac
      a0:	83 fb ff             	cmp    bx,0xffff
      a3:	74 07                	je     0xac
      a5:	8e c3                	mov    es,bx
      a7:	26 8b 1e 00 00       	mov    bx,WORD PTR es:0x0
      ac:	89 0e 72 18          	mov    WORD PTR ds:0x1872,cx
      b0:	89 1e 74 18          	mov    WORD PTR ds:0x1874,bx
      b4:	83 3e 9e 18 00       	cmp    WORD PTR ds:0x189e,0x0
      b9:	75 07                	jne    0xc2
      bb:	83 3e 76 18 00       	cmp    WORD PTR ds:0x1876,0x0
      c0:	74 03                	je     0xc5
      c2:	e8 4f 00             	call   0x114
      c5:	a1 72 18             	mov    ax,ds:0x1872
      c8:	0b 06 74 18          	or     ax,WORD PTR ds:0x1874
      cc:	74 36                	je     0x104
      ce:	b9 0a 00             	mov    cx,0xa
      d1:	a0 70 18             	mov    al,ds:0x1870
      d4:	32 e4                	xor    ah,ah
      d6:	bb b1 18             	mov    bx,0x18b1
      d9:	e8 56 00             	call   0x132
      dc:	b9 10 00             	mov    cx,0x10
      df:	a1 74 18             	mov    ax,ds:0x1874
      e2:	bb b9 18             	mov    bx,0x18b9
      e5:	e8 4a 00             	call   0x132
      e8:	a1 72 18             	mov    ax,ds:0x1872
      eb:	bb be 18             	mov    bx,0x18be
      ee:	e8 41 00             	call   0x132
      f1:	33 c0                	xor    ax,ax
      f3:	50                   	push   ax
      f4:	bb a0 18             	mov    bx,0x18a0
      f7:	1e                   	push   ds
      f8:	53                   	push   bx
      f9:	50                   	push   ax
      fa:	50                   	push   ax
      fb:	b8 10 10             	mov    ax,0x1010
      fe:	50                   	push   ax
      ff:	9a ff ff 00 00       	call   0x0:0xffff
     104:	a1 9e 18             	mov    ax,ds:0x189e
     107:	0b c0                	or     ax,ax
     109:	74 02                	je     0x10d
     10b:	ff e0                	jmp    ax
     10d:	a0 70 18             	mov    al,ds:0x1870
     110:	b4 4c                	mov    ah,0x4c
     112:	cd 21                	int    0x21
     114:	c4 1e 6c 18          	les    bx,DWORD PTR ds:0x186c
     118:	8c c0                	mov    ax,es
     11a:	0b c3                	or     ax,bx
     11c:	74 13                	je     0x131
     11e:	33 c0                	xor    ax,ax
     120:	a3 6c 18             	mov    ds:0x186c,ax
     123:	a3 6e 18             	mov    ds:0x186e,ax
     126:	a3 78 18             	mov    ds:0x1878,ax
     129:	b8 14 01             	mov    ax,0x114
     12c:	0e                   	push   cs
     12d:	50                   	push   ax
     12e:	06                   	push   es
     12f:	53                   	push   bx
     130:	cb                   	retf
     131:	c3                   	ret
     132:	33 d2                	xor    dx,dx
     134:	f7 f1                	div    cx
     136:	80 c2 30             	add    dl,0x30
     139:	80 fa 3a             	cmp    dl,0x3a
     13c:	72 03                	jb     0x141
     13e:	80 c2 07             	add    dl,0x7
     141:	4b                   	dec    bx
     142:	88 17                	mov    BYTE PTR [bx],dl
     144:	0b c0                	or     ax,ax
     146:	75 ea                	jne    0x132
     148:	c3                   	ret
     149:	42                   	inc    dx
     14a:	6f                   	outs   dx,WORD PTR ds:[si]
     14b:	72 6c                	jb     0x1b9
     14d:	61                   	popa
     14e:	6e                   	outs   dx,BYTE PTR ds:[si]
     14f:	64 20 44 65          	and    BYTE PTR fs:[si+0x65],al
     153:	6c                   	ins    BYTE PTR es:[di],dx
     154:	70 68                	jo     0x1be
     156:	69 0d 0a 50          	imul   cx,WORD PTR [di],0x500a
     15a:	6f                   	outs   dx,WORD PTR ds:[si]
     15b:	72 74                	jb     0x1d1
     15d:	69 6f 6e 73 20       	imul   bp,WORD PTR [bx+0x6e],0x2073
     162:	43                   	inc    bx
     163:	6f                   	outs   dx,WORD PTR ds:[si]
     164:	70 79                	jo     0x1df
     166:	72 69                	jb     0x1d1
     168:	67 68 74 20          	addr32 push 0x2074
     16c:	28 63 29             	sub    BYTE PTR [bp+di+0x29],ah
     16f:	20 31                	and    BYTE PTR [bx+di],dh
     171:	39 38                	cmp    WORD PTR [bx+si],di
     173:	33 2c                	xor    bp,WORD PTR [si]
     175:	39 35                	cmp    WORD PTR [di],si
     177:	20 42 6f             	and    BYTE PTR [bp+si+0x6f],al
     17a:	72 6c                	jb     0x1e8
     17c:	61                   	popa
     17d:	6e                   	outs   dx,BYTE PTR ds:[si]
     17e:	64 0d 0a 00          	fs or  ax,0xa
     182:	45                   	inc    bp
     183:	55                   	push   bp
     184:	8b ec                	mov    bp,sp
     186:	1e                   	push   ds
     187:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     18a:	e8 92 00             	call   0x21f
     18d:	8b e5                	mov    sp,bp
     18f:	5d                   	pop    bp
     190:	4d                   	dec    bp
     191:	72 03                	jb     0x196
     193:	ca 02 00             	retf   0x2
     196:	b8 01 00             	mov    ax,0x1
     199:	e9 c4 fe             	jmp    0x60
     19c:	45                   	inc    bp
     19d:	55                   	push   bp
     19e:	8b ec                	mov    bp,sp
     1a0:	1e                   	push   ds
     1a1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     1a4:	8b 4e 08             	mov    cx,WORD PTR [bp+0x8]
     1a7:	8b 5e 0a             	mov    bx,WORD PTR [bp+0xa]
     1aa:	e8 8f 01             	call   0x33c
     1ad:	8b e5                	mov    sp,bp
     1af:	5d                   	pop    bp
     1b0:	4d                   	dec    bp
     1b1:	72 03                	jb     0x1b6
     1b3:	ca 06 00             	retf   0x6
     1b6:	b8 02 00             	mov    ax,0x2
     1b9:	e9 a4 fe             	jmp    0x60
     1bc:	45                   	inc    bp
     1bd:	55                   	push   bp
     1be:	8b ec                	mov    bp,sp
     1c0:	1e                   	push   ds
     1c1:	b8 00 10             	mov    ax,0x1000
     1c4:	50                   	push   ax
     1c5:	9a ff ff 00 00       	call   0x0:0xffff
     1ca:	8b 0e 94 18          	mov    cx,WORD PTR ds:0x1894
     1ce:	e3 15                	jcxz   0x1e5
     1d0:	8e c1                	mov    es,cx
     1d2:	26 03 06 08 00       	add    ax,WORD PTR es:0x8
     1d7:	83 d2 00             	adc    dx,0x0
     1da:	26 8b 0e 0a 00       	mov    cx,WORD PTR es:0xa
     1df:	3b 0e 94 18          	cmp    cx,WORD PTR ds:0x1894
     1e3:	75 eb                	jne    0x1d0
     1e5:	8b e5                	mov    sp,bp
     1e7:	5d                   	pop    bp
     1e8:	4d                   	dec    bp
     1e9:	cb                   	retf
     1ea:	45                   	inc    bp
     1eb:	55                   	push   bp
     1ec:	8b ec                	mov    bp,sp
     1ee:	1e                   	push   ds
     1ef:	33 c0                	xor    ax,ax
     1f1:	50                   	push   ax
     1f2:	50                   	push   ax
     1f3:	9a ff ff 00 00       	call   0x0:0xffff
     1f8:	0b d2                	or     dx,dx
     1fa:	75 1e                	jne    0x21a
     1fc:	8b 0e 94 18          	mov    cx,WORD PTR ds:0x1894
     200:	e3 18                	jcxz   0x21a
     202:	8e c1                	mov    es,cx
     204:	26 3b 06 08 00       	cmp    ax,WORD PTR es:0x8
     209:	73 04                	jae    0x20f
     20b:	26 a1 08 00          	mov    ax,es:0x8
     20f:	26 8b 0e 0a 00       	mov    cx,WORD PTR es:0xa
     214:	3b 0e 94 18          	cmp    cx,WORD PTR ds:0x1894
     218:	75 e8                	jne    0x202
     21a:	8b e5                	mov    sp,bp
     21c:	5d                   	pop    bp
     21d:	4d                   	dec    bp
     21e:	cb                   	retf
     21f:	0b c0                	or     ax,ax
     221:	74 60                	je     0x283
     223:	a3 a8 2e             	mov    ds:0x2ea8,ax
     226:	8b 1e 80 18          	mov    bx,WORD PTR ds:0x1880
     22a:	0b 1e 82 18          	or     bx,WORD PTR ds:0x1882
     22e:	74 06                	je     0x236
     230:	50                   	push   ax
     231:	ff 1e 80 18          	call   DWORD PTR ds:0x1880
     235:	58                   	pop    ax
     236:	3b 06 96 18          	cmp    ax,WORD PTR ds:0x1896
     23a:	72 1f                	jb     0x25b
     23c:	e8 48 00             	call   0x287
     23f:	73 45                	jae    0x286
     241:	83 3e 96 18 00       	cmp    WORD PTR ds:0x1896,0x0
     246:	74 20                	je     0x268
     248:	a1 a8 2e             	mov    ax,ds:0x2ea8
     24b:	8b 1e 98 18          	mov    bx,WORD PTR ds:0x1898
     24f:	83 eb 0c             	sub    bx,0xc
     252:	3b c3                	cmp    ax,bx
     254:	77 12                	ja     0x268
     256:	e8 48 00             	call   0x2a1
     259:	eb 0b                	jmp    0x266
     25b:	e8 43 00             	call   0x2a1
     25e:	73 26                	jae    0x286
     260:	a1 a8 2e             	mov    ax,ds:0x2ea8
     263:	e8 21 00             	call   0x287
     266:	73 1e                	jae    0x286
     268:	a1 84 18             	mov    ax,ds:0x1884
     26b:	0b 06 86 18          	or     ax,WORD PTR ds:0x1886
     26f:	74 08                	je     0x279
     271:	ff 36 a8 2e          	push   WORD PTR ds:0x2ea8
     275:	ff 1e 84 18          	call   DWORD PTR ds:0x1884
     279:	3d 01 00             	cmp    ax,0x1
     27c:	a1 a8 2e             	mov    ax,ds:0x2ea8
     27f:	77 b5                	ja     0x236
     281:	72 03                	jb     0x286
     283:	33 c0                	xor    ax,ax
     285:	99                   	cwd
     286:	c3                   	ret
     287:	ff 36 9a 18          	push   WORD PTR ds:0x189a
     28b:	33 d2                	xor    dx,dx
     28d:	52                   	push   dx
     28e:	50                   	push   ax
     28f:	9a ff ff 00 00       	call   0x0:0xffff
     294:	3d 01 00             	cmp    ax,0x1
     297:	72 07                	jb     0x2a0
     299:	50                   	push   ax
     29a:	9a ff ff 00 00       	call   0x0:0xffff
     29f:	f8                   	clc
     2a0:	c3                   	ret
     2a1:	05 03 00             	add    ax,0x3
     2a4:	24 fc                	and    al,0xfc
     2a6:	8b 0e 94 18          	mov    cx,WORD PTR ds:0x1894
     2aa:	e3 12                	jcxz   0x2be
     2ac:	8e c1                	mov    es,cx
     2ae:	e8 5a 00             	call   0x30b
     2b1:	73 13                	jae    0x2c6
     2b3:	26 8b 0e 0a 00       	mov    cx,WORD PTR es:0xa
     2b8:	3b 0e 94 18          	cmp    cx,WORD PTR ds:0x1894
     2bc:	75 ee                	jne    0x2ac
     2be:	e8 0e 00             	call   0x2cf
     2c1:	72 0b                	jb     0x2ce
     2c3:	e8 45 00             	call   0x30b
     2c6:	8c 06 94 18          	mov    WORD PTR ds:0x1894,es
     2ca:	8b c3                	mov    ax,bx
     2cc:	8c c2                	mov    dx,es
     2ce:	c3                   	ret
     2cf:	50                   	push   ax
     2d0:	a1 98 18             	mov    ax,ds:0x1898
     2d3:	e8 b1 ff             	call   0x287
     2d6:	72 31                	jb     0x309
     2d8:	8e c2                	mov    es,dx
     2da:	33 ff                	xor    di,di
     2dc:	fc                   	cld
     2dd:	b8 54 50             	mov    ax,0x5054
     2e0:	ab                   	stos   WORD PTR es:[di],ax
     2e1:	33 c0                	xor    ax,ax
     2e3:	ab                   	stos   WORD PTR es:[di],ax
     2e4:	b8 0c 00             	mov    ax,0xc
     2e7:	ab                   	stos   WORD PTR es:[di],ax
     2e8:	33 c0                	xor    ax,ax
     2ea:	ab                   	stos   WORD PTR es:[di],ax
     2eb:	a1 98 18             	mov    ax,ds:0x1898
     2ee:	2d 0c 00             	sub    ax,0xc
     2f1:	ab                   	stos   WORD PTR es:[di],ax
     2f2:	50                   	push   ax
     2f3:	8c c0                	mov    ax,es
     2f5:	8b 0e 94 18          	mov    cx,WORD PTR ds:0x1894
     2f9:	e3 08                	jcxz   0x303
     2fb:	1e                   	push   ds
     2fc:	8e d9                	mov    ds,cx
     2fe:	87 06 0a 00          	xchg   WORD PTR ds:0xa,ax
     302:	1f                   	pop    ds
     303:	ab                   	stos   WORD PTR es:[di],ax
     304:	33 c0                	xor    ax,ax
     306:	ab                   	stos   WORD PTR es:[di],ax
     307:	58                   	pop    ax
     308:	ab                   	stos   WORD PTR es:[di],ax
     309:	58                   	pop    ax
     30a:	c3                   	ret
     30b:	bb 04 00             	mov    bx,0x4
     30e:	8b f3                	mov    si,bx
     310:	26 8b 1f             	mov    bx,WORD PTR es:[bx]
     313:	83 fb 01             	cmp    bx,0x1
     316:	72 23                	jb     0x33b
     318:	26 8b 57 02          	mov    dx,WORD PTR es:[bx+0x2]
     31c:	2b d0                	sub    dx,ax
     31e:	72 ee                	jb     0x30e
     320:	26 8b 0f             	mov    cx,WORD PTR es:[bx]
     323:	74 0d                	je     0x332
     325:	8b fb                	mov    di,bx
     327:	03 f8                	add    di,ax
     329:	26 89 0d             	mov    WORD PTR es:[di],cx
     32c:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     330:	8b cf                	mov    cx,di
     332:	26 89 0c             	mov    WORD PTR es:[si],cx
     335:	26 29 06 08 00       	sub    WORD PTR es:0x8,ax
     33a:	f8                   	clc
     33b:	c3                   	ret
     33c:	0b c0                	or     ax,ax
     33e:	74 79                	je     0x3b9
     340:	e3 7b                	jcxz   0x3bd
     342:	05 03 00             	add    ax,0x3
     345:	24 fc                	and    al,0xfc
     347:	8e c3                	mov    es,bx
     349:	8b d9                	mov    bx,cx
     34b:	26 81 3e 00 00 54 50 	cmp    WORD PTR es:0x0,0x5054
     352:	75 67                	jne    0x3bb
     354:	f6 c3 03             	test   bl,0x3
     357:	75 62                	jne    0x3bb
     359:	8b 0e 80 18          	mov    cx,WORD PTR ds:0x1880
     35d:	0b 0e 82 18          	or     cx,WORD PTR ds:0x1882
     361:	74 0a                	je     0x36d
     363:	50                   	push   ax
     364:	06                   	push   es
     365:	53                   	push   bx
     366:	ff 1e 80 18          	call   DWORD PTR ds:0x1880
     36a:	5b                   	pop    bx
     36b:	07                   	pop    es
     36c:	58                   	pop    ax
     36d:	be 04 00             	mov    si,0x4
     370:	8b fe                	mov    di,si
     372:	26 8b 34             	mov    si,WORD PTR es:[si]
     375:	0b f6                	or     si,si
     377:	74 06                	je     0x37f
     379:	3b de                	cmp    bx,si
     37b:	77 f3                	ja     0x370
     37d:	74 3c                	je     0x3bb
     37f:	26 89 37             	mov    WORD PTR es:[bx],si
     382:	26 89 47 02          	mov    WORD PTR es:[bx+0x2],ax
     386:	26 03 06 08 00       	add    ax,WORD PTR es:0x8
     38b:	26 a3 08 00          	mov    es:0x8,ax
     38f:	05 0c 00             	add    ax,0xc
     392:	3b 06 98 18          	cmp    ax,WORD PTR ds:0x1898
     396:	74 43                	je     0x3db
     398:	e8 05 00             	call   0x3a0
     39b:	26 89 1d             	mov    WORD PTR es:[di],bx
     39e:	8b df                	mov    bx,di
     3a0:	8b f3                	mov    si,bx
     3a2:	26 03 77 02          	add    si,WORD PTR es:[bx+0x2]
     3a6:	26 3b 37             	cmp    si,WORD PTR es:[bx]
     3a9:	75 0e                	jne    0x3b9
     3ab:	26 8b 04             	mov    ax,WORD PTR es:[si]
     3ae:	26 89 07             	mov    WORD PTR es:[bx],ax
     3b1:	26 8b 44 02          	mov    ax,WORD PTR es:[si+0x2]
     3b5:	26 01 47 02          	add    WORD PTR es:[bx+0x2],ax
     3b9:	f8                   	clc
     3ba:	c3                   	ret
     3bb:	f9                   	stc
     3bc:	c3                   	ret
     3bd:	8c d8                	mov    ax,ds
     3bf:	3b c3                	cmp    ax,bx
     3c1:	74 f8                	je     0x3bb
     3c3:	53                   	push   bx
     3c4:	9a ff ff 00 00       	call   0x0:0xffff
     3c9:	0b c0                	or     ax,ax
     3cb:	74 ee                	je     0x3bb
     3cd:	50                   	push   ax
     3ce:	50                   	push   ax
     3cf:	9a ff ff 00 00       	call   0x0:0xffff
     3d4:	9a ff ff 00 00       	call   0x0:0xffff
     3d9:	f8                   	clc
     3da:	c3                   	ret
     3db:	33 c0                	xor    ax,ax
     3dd:	8c c3                	mov    bx,es
     3df:	26 8b 16 0a 00       	mov    dx,WORD PTR es:0xa
     3e4:	3b da                	cmp    bx,dx
     3e6:	74 14                	je     0x3fc
     3e8:	a1 94 18             	mov    ax,ds:0x1894
     3eb:	8e c0                	mov    es,ax
     3ed:	26 a1 0a 00          	mov    ax,es:0xa
     3f1:	3b c3                	cmp    ax,bx
     3f3:	75 f6                	jne    0x3eb
     3f5:	26 89 16 0a 00       	mov    WORD PTR es:0xa,dx
     3fa:	8c c0                	mov    ax,es
     3fc:	a3 94 18             	mov    ds:0x1894,ax
     3ff:	eb bc                	jmp    0x3bd
     401:	33 c0                	xor    ax,ax
     403:	87 06 78 18          	xchg   WORD PTR ds:0x1878,ax
     407:	cb                   	retf
     408:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     40d:	75 01                	jne    0x410
     40f:	cb                   	retf
     410:	b8 00 00             	mov    ax,0x0
     413:	e9 4a fc             	jmp    0x60
     416:	8b f4                	mov    si,sp
     418:	36 8e 44 02          	mov    es,WORD PTR ss:[si+0x2]
     41c:	26 3b 55 02          	cmp    dx,WORD PTR es:[di+0x2]
     420:	7f 07                	jg     0x429
     422:	7c 14                	jl     0x438
     424:	26 3b 05             	cmp    ax,WORD PTR es:[di]
     427:	72 0f                	jb     0x438
     429:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
     42d:	7c 08                	jl     0x437
     42f:	7f 07                	jg     0x438
     431:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
     435:	77 01                	ja     0x438
     437:	cb                   	retf
     438:	b8 04 00             	mov    ax,0x4
     43b:	e9 22 fc             	jmp    0x60
     43e:	b8 05 00             	mov    ax,0x5
     441:	e9 1c fc             	jmp    0x60
     444:	05 00 04             	add    ax,0x400
     447:	72 19                	jb     0x462
     449:	2b c4                	sub    ax,sp
     44b:	73 15                	jae    0x462
     44d:	f7 d8                	neg    ax
     44f:	36 3b 06 0a 00       	cmp    ax,WORD PTR ss:0xa
     454:	72 0c                	jb     0x462
     456:	36 3b 06 0c 00       	cmp    ax,WORD PTR ss:0xc
     45b:	73 04                	jae    0x461
     45d:	36 a3 0c 00          	mov    ss:0xc,ax
     461:	cb                   	retf
     462:	b8 ca 00             	mov    ax,0xca
     465:	e9 27 fc             	jmp    0x8f
     468:	c6 06 9c 18 01       	mov    BYTE PTR ds:0x189c,0x1
     46d:	2e 80 3e af 04 cd    	cmp    BYTE PTR cs:0x4af,0xcd
     473:	74 3d                	je     0x4b2
     475:	55                   	push   bp
     476:	8b ec                	mov    bp,sp
     478:	83 ec 0a             	sub    sp,0xa
     47b:	50                   	push   ax
     47c:	db 7e f6             	fstp   TBYTE PTR [bp-0xa]
     47f:	dd 06 dc 18          	fld    QWORD PTR ds:0x18dc
     483:	9b dc 36 e4 18       	fdiv   QWORD PTR ds:0x18e4
     488:	9b dc 0e e4 18       	fmul   QWORD PTR ds:0x18e4
     48d:	9b dc 2e dc 18       	fsubr  QWORD PTR ds:0x18dc
     492:	9b dc 1e ec 18       	fcomp  QWORD PTR ds:0x18ec
     497:	9b 9b df e0          	fstsw  ax
     49b:	9b                   	fwait
     49c:	25 00 01             	and    ax,0x100
     49f:	c1 e8 07             	shr    ax,0x7
     4a2:	48                   	dec    ax
     4a3:	a2 9c 18             	mov    ds:0x189c,al
     4a6:	db 6e f6             	fld    TBYTE PTR [bp-0xa]
     4a9:	58                   	pop    ax
     4aa:	8b e5                	mov    sp,bp
     4ac:	5d                   	pop    bp
     4ad:	eb 03                	jmp    0x4b2
     4af:	9b d9 c9             	fxch   st(1)
     4b2:	80 3e 9c 18 00       	cmp    BYTE PTR ds:0x189c,0x0
     4b7:	7e 04                	jle    0x4bd
     4b9:	9b de f9             	fdivp  st(1),st
     4bc:	cb                   	retf
     4bd:	74 a9                	je     0x468
     4bf:	55                   	push   bp
     4c0:	8b ec                	mov    bp,sp
     4c2:	83 ec 14             	sub    sp,0x14
     4c5:	50                   	push   ax
     4c6:	db 7e ec             	fstp   TBYTE PTR [bp-0x14]
     4c9:	db 7e f6             	fstp   TBYTE PTR [bp-0xa]
     4cc:	db 6e f6             	fld    TBYTE PTR [bp-0xa]
     4cf:	db 6e ec             	fld    TBYTE PTR [bp-0x14]
     4d2:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
     4d5:	03 c0                	add    ax,ax
     4d7:	73 51                	jae    0x52a
     4d9:	35 00 0e             	xor    ax,0xe00
     4dc:	a9 00 0e             	test   ax,0xe00
     4df:	74 07                	je     0x4e8
     4e1:	de f9                	fdivp  st(1),st
     4e3:	58                   	pop    ax
     4e4:	8b e5                	mov    sp,bp
     4e6:	5d                   	pop    bp
     4e7:	cb                   	retf
     4e8:	c1 e8 0c             	shr    ax,0xc
     4eb:	53                   	push   bx
     4ec:	8b d8                	mov    bx,ax
     4ee:	80 bf c0 18 00       	cmp    BYTE PTR [bx+0x18c0],0x0
     4f3:	5b                   	pop    bx
     4f4:	74 eb                	je     0x4e1
     4f6:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     4f9:	25 ff 7f             	and    ax,0x7fff
     4fc:	74 e3                	je     0x4e1
     4fe:	3d ff 7f             	cmp    ax,0x7fff
     501:	74 de                	je     0x4e1
     503:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     506:	25 ff 7f             	and    ax,0x7fff
     509:	3d 01 00             	cmp    ax,0x1
     50c:	74 0e                	je     0x51c
     50e:	d8 0e d0 18          	fmul   DWORD PTR ds:0x18d0
     512:	d9 c9                	fxch   st(1)
     514:	d8 0e d0 18          	fmul   DWORD PTR ds:0x18d0
     518:	d9 c9                	fxch   st(1)
     51a:	eb c5                	jmp    0x4e1
     51c:	d8 0e d4 18          	fmul   DWORD PTR ds:0x18d4
     520:	d9 c9                	fxch   st(1)
     522:	d8 0e d4 18          	fmul   DWORD PTR ds:0x18d4
     526:	d9 c9                	fxch   st(1)
     528:	eb b7                	jmp    0x4e1
     52a:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
     52d:	0b 46 ee             	or     ax,WORD PTR [bp-0x12]
     530:	0b 46 f0             	or     ax,WORD PTR [bp-0x10]
     533:	0b 46 f2             	or     ax,WORD PTR [bp-0xe]
     536:	74 a9                	je     0x4e1
     538:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     53b:	25 ff 7f             	and    ax,0x7fff
     53e:	75 a1                	jne    0x4e1
     540:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     543:	25 ff 7f             	and    ax,0x7fff
     546:	74 0e                	je     0x556
     548:	3d ff 7f             	cmp    ax,0x7fff
     54b:	74 94                	je     0x4e1
     54d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     550:	03 c0                	add    ax,ax
     552:	73 8d                	jae    0x4e1
     554:	eb 07                	jmp    0x55d
     556:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     559:	03 c0                	add    ax,ax
     55b:	72 84                	jb     0x4e1
     55d:	d9 c9                	fxch   st(1)
     55f:	dd d8                	fstp   st(0)
     561:	d9 c0                	fld    st(0)
     563:	d8 0e d8 18          	fmul   DWORD PTR ds:0x18d8
     567:	db 7e ec             	fstp   TBYTE PTR [bp-0x14]
     56a:	db 6e f6             	fld    TBYTE PTR [bp-0xa]
     56d:	d9 c9                	fxch   st(1)
     56f:	9b                   	fwait
     570:	e9 5f ff             	jmp    0x4d2
     573:	cb                   	retf
     574:	01 00                	add    WORD PTR [bx+si],ax
     576:	00 00                	add    BYTE PTR [bx+si],al
     578:	0a 00                	or     al,BYTE PTR [bx+si]
     57a:	00 00                	add    BYTE PTR [bx+si],al
     57c:	64 00 00             	add    BYTE PTR fs:[bx+si],al
     57f:	00 e8                	add    al,ch
     581:	03 00                	add    ax,WORD PTR [bx+si]
     583:	00 10                	add    BYTE PTR [bx+si],dl
     585:	27                   	daa
     586:	00 00                	add    BYTE PTR [bx+si],al
     588:	a0 86 01             	mov    al,ds:0x186
     58b:	00 40 42             	add    BYTE PTR [bx+si+0x42],al
     58e:	0f 00 80 96 98       	sldt   WORD PTR [bx+si-0x676a]
     593:	00 00                	add    BYTE PTR [bx+si],al
     595:	00 00                	add    BYTE PTR [bx+si],al
     597:	00 00                	add    BYTE PTR [bx+si],al
     599:	20 bc be 19          	and    BYTE PTR [si+0x19be],bh
     59d:	40                   	inc    ax
     59e:	00 00                	add    BYTE PTR [bx+si],al
     5a0:	00 04                	add    BYTE PTR [si],al
     5a2:	bf c9 1b             	mov    di,0x1bc9
     5a5:	8e 34                	mov    ?,WORD PTR [si]
     5a7:	40                   	inc    ax
     5a8:	9e                   	sahf
     5a9:	b5 70                	mov    ch,0x70
     5ab:	2b a8 ad c5          	sub    bp,WORD PTR [bx+si-0x3a53]
     5af:	9d                   	popf
     5b0:	69 40 d5 a6 cf       	imul   ax,WORD PTR [bx+si-0x2b],0xcfa6
     5b5:	ff 49 1f             	dec    WORD PTR [bx+di+0x1f]
     5b8:	78 c2                	js     0x57c
     5ba:	d3 40 e0             	rol    WORD PTR [bx+si-0x20],cl
     5bd:	8c e9                	mov    cx,gs
     5bf:	80 c9 47             	or     cl,0x47
     5c2:	ba 93 a8             	mov    dx,0xa893
     5c5:	41                   	inc    cx
     5c6:	8e de                	mov    ds,si
     5c8:	f9                   	stc
     5c9:	9d                   	popf
     5ca:	fb                   	sti
     5cb:	eb 7e                	jmp    0x64b
     5cd:	aa                   	stos   BYTE PTR es:[di],al
     5ce:	51                   	push   cx
     5cf:	43                   	inc    bx
     5d0:	c7                   	(bad)
     5d1:	91                   	xchg   cx,ax
     5d2:	0e                   	push   cs
     5d3:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     5d4:	ae                   	scas   al,BYTE PTR es:[di]
     5d5:	a0 19 e3             	mov    al,ds:0xe319
     5d8:	a3 46 17             	mov    ds:0x1746,ax
     5db:	0c 75                	or     al,0x75
     5dd:	81 86 75 76 c9 48    	add    WORD PTR [bp+0x7675],0x48c9
     5e3:	4d                   	dec    bp
     5e4:	e5 5d                	in     ax,0x5d
     5e6:	3d c5 5d             	cmp    ax,0x5dc5
     5e9:	3b 8b 9e 92          	cmp    cx,WORD PTR [bp+di-0x6d62]
     5ed:	5a                   	pop    dx
     5ee:	9b                   	fwait
     5ef:	97                   	xchg   di,ax
     5f0:	20 8a 02 52          	and    BYTE PTR [bp+si+0x5202],cl
     5f4:	60                   	pusha
     5f5:	c4 25                	les    sp,DWORD PTR [di]
     5f7:	75 00                	jne    0x5f9
     5f9:	00 40 76             	add    BYTE PTR [bx+si+0x76],al
     5fc:	3a 6b 0b             	cmp    ch,BYTE PTR [bp+di+0xb]
     5ff:	de 3a                	fidivr WORD PTR [bp+si]
     601:	40                   	inc    ax
     602:	00 00                	add    BYTE PTR [bx+si],al
     604:	00 00                	add    BYTE PTR [bx+si],al
     606:	00 00                	add    BYTE PTR [bx+si],al
     608:	00 80 ff 7f          	add    BYTE PTR [bx+si+0x7fff],al
     60c:	3f                   	aas
     60d:	13 55 8b             	adc    dx,WORD PTR [di-0x75]
     610:	ec                   	in     al,dx
     611:	83 ec 28             	sub    sp,0x28
     614:	9b d9 7e fe          	fstcw  WORD PTR [bp-0x2]
     618:	9b 2e d9 2e 0c 06    	fldcw  WORD PTR cs:0x60c
     61e:	9b db 7e ec          	fstp   TBYTE PTR [bp-0x14]
     622:	57                   	push   di
     623:	83 f9 12             	cmp    cx,0x12
     626:	7e 03                	jle    0x62b
     628:	b9 12 00             	mov    cx,0x12
     62b:	83 f9 ee             	cmp    cx,0xffee
     62e:	7d 03                	jge    0x633
     630:	b9 ee ff             	mov    cx,0xffee
     633:	89 4e fa             	mov    WORD PTR [bp-0x6],cx
     636:	fc                   	cld
     637:	90                   	nop
     638:	9b                   	fwait
     639:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     63c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     63f:	25 ff 7f             	and    ax,0x7fff
     642:	74 29                	je     0x66d
     644:	3d ff 7f             	cmp    ax,0x7fff
     647:	75 2d                	jne    0x676
     649:	81 7e f2 00 80       	cmp    WORD PTR [bp-0xe],0x8000
     64e:	74 0a                	je     0x65a
     650:	b8 4e 41             	mov    ax,0x414e
     653:	ab                   	stos   WORD PTR es:[di],ax
     654:	b0 4e                	mov    al,0x4e
     656:	aa                   	stos   BYTE PTR es:[di],al
     657:	e9 66 01             	jmp    0x7c0
     65a:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
     65e:	79 03                	jns    0x663
     660:	b0 2d                	mov    al,0x2d
     662:	aa                   	stos   BYTE PTR es:[di],al
     663:	b8 49 4e             	mov    ax,0x4e49
     666:	ab                   	stos   WORD PTR es:[di],ax
     667:	b0 46                	mov    al,0x46
     669:	aa                   	stos   BYTE PTR es:[di],al
     66a:	e9 53 01             	jmp    0x7c0
     66d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     670:	88 46 d8             	mov    BYTE PTR [bp-0x28],al
     673:	e9 c7 00             	jmp    0x73d
     676:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     679:	9b db 6e ec          	fld    TBYTE PTR [bp-0x14]
     67d:	2d ff 3f             	sub    ax,0x3fff
     680:	ba 10 4d             	mov    dx,0x4d10
     683:	f7 ea                	imul   dx
     685:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
     688:	b8 11 00             	mov    ax,0x11
     68b:	2b c2                	sub    ax,dx
     68d:	e8 08 02             	call   0x898
     690:	9b d9 fc             	frndint
     693:	9b 2e db 2e f8 05    	fld    TBYTE PTR cs:0x5f8
     699:	9b d8 d9             	fcomp  st(1)
     69c:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
     6a0:	90                   	nop
     6a1:	9b                   	fwait
     6a2:	f7 46 fc 00 41       	test   WORD PTR [bp-0x4],0x4100
     6a7:	74 09                	je     0x6b2
     6a9:	9b 2e da 36 78 05    	fidiv  DWORD PTR cs:0x578
     6af:	ff 46 f8             	inc    WORD PTR [bp-0x8]
     6b2:	2e 80 3e c8 06 cd    	cmp    BYTE PTR cs:0x6c8,0xcd
     6b8:	75 0e                	jne    0x6c8
     6ba:	06                   	push   es
     6bb:	57                   	push   di
     6bc:	8d 7e d8             	lea    di,[bp-0x28]
     6bf:	16                   	push   ss
     6c0:	07                   	pop    es
     6c1:	e8 3a 02             	call   0x8fe
     6c4:	5f                   	pop    di
     6c5:	07                   	pop    es
     6c6:	eb 26                	jmp    0x6ee
     6c8:	9b df 76 ec          	fbstp  TBYTE PTR [bp-0x14]
     6cc:	8d 5e d8             	lea    bx,[bp-0x28]
     6cf:	b1 04                	mov    cl,0x4
     6d1:	be 09 00             	mov    si,0x9
     6d4:	90                   	nop
     6d5:	9b                   	fwait
     6d6:	8a 42 eb             	mov    al,BYTE PTR [bp+si-0x15]
     6d9:	8a e0                	mov    ah,al
     6db:	d2 e8                	shr    al,cl
     6dd:	80 e4 0f             	and    ah,0xf
     6e0:	05 30 30             	add    ax,0x3030
     6e3:	36 89 07             	mov    WORD PTR ss:[bx],ax
     6e6:	43                   	inc    bx
     6e7:	43                   	inc    bx
     6e8:	4e                   	dec    si
     6e9:	75 eb                	jne    0x6d6
     6eb:	36 89 37             	mov    WORD PTR ss:[bx],si
     6ee:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     6f2:	7c 0b                	jl     0x6ff
     6f4:	83 7e f8 24          	cmp    WORD PTR [bp-0x8],0x24
     6f8:	7c 05                	jl     0x6ff
     6fa:	c7 46 fa ee ff       	mov    WORD PTR [bp-0x6],0xffee
     6ff:	8b 76 fa             	mov    si,WORD PTR [bp-0x6]
     702:	0b f6                	or     si,si
     704:	78 0c                	js     0x712
     706:	03 76 f8             	add    si,WORD PTR [bp-0x8]
     709:	46                   	inc    si
     70a:	79 08                	jns    0x714
     70c:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
     710:	eb 2b                	jmp    0x73d
     712:	f7 de                	neg    si
     714:	83 fe 12             	cmp    si,0x12
     717:	73 24                	jae    0x73d
     719:	80 7a d8 35          	cmp    BYTE PTR [bp+si-0x28],0x35
     71d:	c6 42 d8 00          	mov    BYTE PTR [bp+si-0x28],0x0
     721:	72 1a                	jb     0x73d
     723:	4e                   	dec    si
     724:	78 0f                	js     0x735
     726:	fe 42 d8             	inc    BYTE PTR [bp+si-0x28]
     729:	80 7a d8 39          	cmp    BYTE PTR [bp+si-0x28],0x39
     72d:	76 0e                	jbe    0x73d
     72f:	c6 42 d8 00          	mov    BYTE PTR [bp+si-0x28],0x0
     733:	eb ee                	jmp    0x723
     735:	c7 46 d8 31 00       	mov    WORD PTR [bp-0x28],0x31
     73a:	ff 46 f8             	inc    WORD PTR [bp-0x8]
     73d:	33 f6                	xor    si,si
     73f:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     742:	0b d2                	or     dx,dx
     744:	78 35                	js     0x77b
     746:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
     74a:	79 03                	jns    0x74f
     74c:	b0 2d                	mov    al,0x2d
     74e:	aa                   	stos   BYTE PTR es:[di],al
     74f:	8b 4e f8             	mov    cx,WORD PTR [bp-0x8]
     752:	0b c9                	or     cx,cx
     754:	79 05                	jns    0x75b
     756:	b0 30                	mov    al,0x30
     758:	aa                   	stos   BYTE PTR es:[di],al
     759:	eb 07                	jmp    0x762
     75b:	e8 74 00             	call   0x7d2
     75e:	aa                   	stos   BYTE PTR es:[di],al
     75f:	49                   	dec    cx
     760:	79 f9                	jns    0x75b
     762:	0b d2                	or     dx,dx
     764:	74 5a                	je     0x7c0
     766:	b0 2e                	mov    al,0x2e
     768:	aa                   	stos   BYTE PTR es:[di],al
     769:	41                   	inc    cx
     76a:	74 06                	je     0x772
     76c:	b0 30                	mov    al,0x30
     76e:	aa                   	stos   BYTE PTR es:[di],al
     76f:	4a                   	dec    dx
     770:	75 f7                	jne    0x769
     772:	4a                   	dec    dx
     773:	78 4b                	js     0x7c0
     775:	e8 5a 00             	call   0x7d2
     778:	aa                   	stos   BYTE PTR es:[di],al
     779:	eb f7                	jmp    0x772
     77b:	b0 20                	mov    al,0x20
     77d:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
     781:	79 02                	jns    0x785
     783:	b0 2d                	mov    al,0x2d
     785:	aa                   	stos   BYTE PTR es:[di],al
     786:	e8 49 00             	call   0x7d2
     789:	aa                   	stos   BYTE PTR es:[di],al
     78a:	42                   	inc    dx
     78b:	74 0a                	je     0x797
     78d:	b0 2e                	mov    al,0x2e
     78f:	aa                   	stos   BYTE PTR es:[di],al
     790:	e8 3f 00             	call   0x7d2
     793:	aa                   	stos   BYTE PTR es:[di],al
     794:	42                   	inc    dx
     795:	75 f9                	jne    0x790
     797:	b0 45                	mov    al,0x45
     799:	aa                   	stos   BYTE PTR es:[di],al
     79a:	b0 2b                	mov    al,0x2b
     79c:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
     79f:	0b d2                	or     dx,dx
     7a1:	79 04                	jns    0x7a7
     7a3:	b0 2d                	mov    al,0x2d
     7a5:	f7 da                	neg    dx
     7a7:	aa                   	stos   BYTE PTR es:[di],al
     7a8:	b8 0a 64             	mov    ax,0x640a
     7ab:	92                   	xchg   dx,ax
     7ac:	f6 f6                	div    dh
     7ae:	8a f4                	mov    dh,ah
     7b0:	98                   	cbw
     7b1:	f6 f2                	div    dl
     7b3:	05 30 30             	add    ax,0x3030
     7b6:	ab                   	stos   WORD PTR es:[di],ax
     7b7:	8a c6                	mov    al,dh
     7b9:	98                   	cbw
     7ba:	f6 f2                	div    dl
     7bc:	05 30 30             	add    ax,0x3030
     7bf:	ab                   	stos   WORD PTR es:[di],ax
     7c0:	8b cf                	mov    cx,di
     7c2:	5f                   	pop    di
     7c3:	2b cf                	sub    cx,di
     7c5:	9b db e2             	fclex
     7c8:	9b d9 6e fe          	fldcw  WORD PTR [bp-0x2]
     7cc:	90                   	nop
     7cd:	9b                   	fwait
     7ce:	8b e5                	mov    sp,bp
     7d0:	5d                   	pop    bp
     7d1:	c3                   	ret
     7d2:	8a 42 d8             	mov    al,BYTE PTR [bp+si-0x28]
     7d5:	46                   	inc    si
     7d6:	0a c0                	or     al,al
     7d8:	75 03                	jne    0x7dd
     7da:	b0 30                	mov    al,0x30
     7dc:	4e                   	dec    si
     7dd:	c3                   	ret
     7de:	55                   	push   bp
     7df:	8b ec                	mov    bp,sp
     7e1:	83 ec 06             	sub    sp,0x6
     7e4:	9b d9 7e fe          	fstcw  WORD PTR [bp-0x2]
     7e8:	9b db e2             	fclex
     7eb:	9b 2e d9 2e 0c 06    	fldcw  WORD PTR cs:0x60c
     7f1:	9b d9 ee             	fldz
     7f4:	e3 73                	jcxz   0x869
     7f6:	26 8a 05             	mov    al,BYTE PTR es:[di]
     7f9:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     7fc:	3c 20                	cmp    al,0x20
     7fe:	74 08                	je     0x808
     800:	3c 2b                	cmp    al,0x2b
     802:	74 04                	je     0x808
     804:	3c 2d                	cmp    al,0x2d
     806:	75 02                	jne    0x80a
     808:	47                   	inc    di
     809:	49                   	dec    cx
     80a:	51                   	push   cx
     80b:	e8 69 00             	call   0x877
     80e:	33 db                	xor    bx,bx
     810:	e3 0e                	jcxz   0x820
     812:	26 8a 05             	mov    al,BYTE PTR es:[di]
     815:	3c 2e                	cmp    al,0x2e
     817:	75 07                	jne    0x820
     819:	47                   	inc    di
     81a:	49                   	dec    cx
     81b:	e8 59 00             	call   0x877
     81e:	f7 db                	neg    bx
     820:	58                   	pop    ax
     821:	3b c1                	cmp    ax,cx
     823:	74 44                	je     0x869
     825:	e3 27                	jcxz   0x84e
     827:	26 8a 05             	mov    al,BYTE PTR es:[di]
     82a:	3c 45                	cmp    al,0x45
     82c:	74 04                	je     0x832
     82e:	3c 65                	cmp    al,0x65
     830:	75 1c                	jne    0x84e
     832:	47                   	inc    di
     833:	49                   	dec    cx
     834:	53                   	push   bx
     835:	e8 d1 14             	call   0x1d09
     838:	5b                   	pop    bx
     839:	72 2e                	jb     0x869
     83b:	8b f2                	mov    si,dx
     83d:	99                   	cwd
     83e:	3b f2                	cmp    si,dx
     840:	75 27                	jne    0x869
     842:	3d 87 13             	cmp    ax,0x1387
     845:	7d 22                	jge    0x869
     847:	3d 79 ec             	cmp    ax,0xec79
     84a:	7e 1d                	jle    0x869
     84c:	03 d8                	add    bx,ax
     84e:	8b c3                	mov    ax,bx
     850:	e8 45 00             	call   0x898
     853:	80 7e fb 2d          	cmp    BYTE PTR [bp-0x5],0x2d
     857:	75 03                	jne    0x85c
     859:	9b d9 e0             	fchs
     85c:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
     860:	90                   	nop
     861:	9b                   	fwait
     862:	f7 46 fc 09 00       	test   WORD PTR [bp-0x4],0x9
     867:	74 01                	je     0x86a
     869:	f9                   	stc
     86a:	9b db e2             	fclex
     86d:	9b d9 6e fe          	fldcw  WORD PTR [bp-0x2]
     871:	90                   	nop
     872:	9b                   	fwait
     873:	8b e5                	mov    sp,bp
     875:	5d                   	pop    bp
     876:	c3                   	ret
     877:	33 db                	xor    bx,bx
     879:	e3 1c                	jcxz   0x897
     87b:	26 8a 05             	mov    al,BYTE PTR es:[di]
     87e:	2c 3a                	sub    al,0x3a
     880:	04 0a                	add    al,0xa
     882:	73 13                	jae    0x897
     884:	9b 2e da 0e 78 05    	fimul  DWORD PTR cs:0x578
     88a:	98                   	cbw
     88b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     88e:	9b de 46 fc          	fiadd  WORD PTR [bp-0x4]
     892:	43                   	inc    bx
     893:	47                   	inc    di
     894:	49                   	dec    cx
     895:	eb e2                	jmp    0x879
     897:	c3                   	ret
     898:	3d 00 10             	cmp    ax,0x1000
     89b:	7e 0c                	jle    0x8a9
     89d:	9b 2e db 2e ee 05    	fld    TBYTE PTR cs:0x5ee
     8a3:	9b de c9             	fmulp  st(1),st
     8a6:	2d 00 10             	sub    ax,0x1000
     8a9:	3d 00 f0             	cmp    ax,0xf000
     8ac:	7d 0d                	jge    0x8bb
     8ae:	9b 2e db 2e ee 05    	fld    TBYTE PTR cs:0x5ee
     8b4:	0e                   	push   cs
     8b5:	e8 fa fb             	call   0x4b2
     8b8:	05 00 10             	add    ax,0x1000
     8bb:	8b d8                	mov    bx,ax
     8bd:	0b c0                	or     ax,ax
     8bf:	74 3c                	je     0x8fd
     8c1:	79 02                	jns    0x8c5
     8c3:	f7 d8                	neg    ax
     8c5:	8b f0                	mov    si,ax
     8c7:	83 e6 07             	and    si,0x7
     8ca:	d1 e6                	shl    si,1
     8cc:	d1 e6                	shl    si,1
     8ce:	9b 2e db 84 74 05    	fild   DWORD PTR cs:[si+0x574]
     8d4:	d1 e8                	shr    ax,1
     8d6:	d1 e8                	shr    ax,1
     8d8:	d1 e8                	shr    ax,1
     8da:	be 94 05             	mov    si,0x594
     8dd:	eb 0e                	jmp    0x8ed
     8df:	d1 e8                	shr    ax,1
     8e1:	73 07                	jae    0x8ea
     8e3:	9b 2e db 2c          	fld    TBYTE PTR cs:[si]
     8e7:	9b de c9             	fmulp  st(1),st
     8ea:	83 c6 0a             	add    si,0xa
     8ed:	0b c0                	or     ax,ax
     8ef:	75 ee                	jne    0x8df
     8f1:	0b db                	or     bx,bx
     8f3:	78 04                	js     0x8f9
     8f5:	9b de c9             	fmulp  st(1),st
     8f8:	c3                   	ret
     8f9:	0e                   	push   cs
     8fa:	e8 b5 fb             	call   0x4b2
     8fd:	c3                   	ret
     8fe:	83 c7 12             	add    di,0x12
     901:	33 c0                	xor    ax,ax
     903:	fd                   	std
     904:	ab                   	stos   WORD PTR es:[di],ax
     905:	83 ec 08             	sub    sp,0x8
     908:	8b f4                	mov    si,sp
     90a:	9b 36 df 3c          	fistp  QWORD PTR ss:[si]
     90e:	90                   	nop
     90f:	9b                   	fwait
     910:	5b                   	pop    bx
     911:	59                   	pop    cx
     912:	58                   	pop    ax
     913:	5a                   	pop    dx
     914:	be 10 27             	mov    si,0x2710
     917:	f7 f6                	div    si
     919:	91                   	xchg   cx,ax
     91a:	f7 f6                	div    si
     91c:	93                   	xchg   bx,ax
     91d:	f7 f6                	div    si
     91f:	e8 2a 00             	call   0x94c
     922:	33 d2                	xor    dx,dx
     924:	91                   	xchg   cx,ax
     925:	f7 f6                	div    si
     927:	93                   	xchg   bx,ax
     928:	f7 f6                	div    si
     92a:	91                   	xchg   cx,ax
     92b:	f7 f6                	div    si
     92d:	e8 1c 00             	call   0x94c
     930:	8b d3                	mov    dx,bx
     932:	91                   	xchg   cx,ax
     933:	f7 f6                	div    si
     935:	91                   	xchg   cx,ax
     936:	f7 f6                	div    si
     938:	e8 11 00             	call   0x94c
     93b:	8b d1                	mov    dx,cx
     93d:	f7 f6                	div    si
     93f:	e8 0a 00             	call   0x94c
     942:	d4 0a                	aam    0xa
     944:	86 c4                	xchg   ah,al
     946:	05 30 30             	add    ax,0x3030
     949:	ab                   	stos   WORD PTR es:[di],ax
     94a:	fc                   	cld
     94b:	c3                   	ret
     94c:	50                   	push   ax
     94d:	b0 64                	mov    al,0x64
     94f:	92                   	xchg   dx,ax
     950:	f6 f2                	div    dl
     952:	8a d4                	mov    dl,ah
     954:	d4 0a                	aam    0xa
     956:	05 30 30             	add    ax,0x3030
     959:	86 c4                	xchg   ah,al
     95b:	92                   	xchg   dx,ax
     95c:	d4 0a                	aam    0xa
     95e:	05 30 30             	add    ax,0x3030
     961:	86 c4                	xchg   ah,al
     963:	ab                   	stos   WORD PTR es:[di],ax
     964:	92                   	xchg   dx,ax
     965:	ab                   	stos   WORD PTR es:[di],ax
     966:	58                   	pop    ax
     967:	c3                   	ret
     968:	ba 33 d2             	mov    dx,0xd233
     96b:	8b dc                	mov    bx,sp
     96d:	1e                   	push   ds
     96e:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
     972:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
     976:	fc                   	cld
     977:	33 c0                	xor    ax,ax
     979:	ab                   	stos   WORD PTR es:[di],ax
     97a:	b8 b0 d7             	mov    ax,0xd7b0
     97d:	ab                   	stos   WORD PTR es:[di],ax
     97e:	b8 80 00             	mov    ax,0x80
     981:	ab                   	stos   WORD PTR es:[di],ax
     982:	33 c0                	xor    ax,ax
     984:	ab                   	stos   WORD PTR es:[di],ax
     985:	ab                   	stos   WORD PTR es:[di],ax
     986:	ab                   	stos   WORD PTR es:[di],ax
     987:	8d 45 74             	lea    ax,[di+0x74]
     98a:	ab                   	stos   WORD PTR es:[di],ax
     98b:	8c c0                	mov    ax,es
     98d:	ab                   	stos   WORD PTR es:[di],ax
     98e:	b8 44 1b             	mov    ax,0x1b44
     991:	ab                   	stos   WORD PTR es:[di],ax
     992:	b8 63 0f             	mov    ax,0xf63
     995:	ab                   	stos   WORD PTR es:[di],ax
     996:	33 c0                	xor    ax,ax
     998:	b9 0e 00             	mov    cx,0xe
     99b:	f3 ab                	rep stos WORD PTR es:[di],ax
     99d:	06                   	push   es
     99e:	57                   	push   di
     99f:	06                   	push   es
     9a0:	57                   	push   di
     9a1:	b9 4f 00             	mov    cx,0x4f
     9a4:	0b d2                	or     dx,dx
     9a6:	75 09                	jne    0x9b1
     9a8:	ac                   	lods   al,BYTE PTR ds:[si]
     9a9:	3a c8                	cmp    cl,al
     9ab:	76 04                	jbe    0x9b1
     9ad:	8a c8                	mov    cl,al
     9af:	e3 08                	jcxz   0x9b9
     9b1:	ac                   	lods   al,BYTE PTR ds:[si]
     9b2:	0a c0                	or     al,al
     9b4:	74 03                	je     0x9b9
     9b6:	aa                   	stos   BYTE PTR es:[di],al
     9b7:	e2 f8                	loop   0x9b1
     9b9:	32 c0                	xor    al,al
     9bb:	aa                   	stos   BYTE PTR es:[di],al
     9bc:	9a 3b 0f 00 00       	call   0x0:0xf3b
     9c1:	1f                   	pop    ds
     9c2:	ca 08 00             	retf   0x8
     9c5:	8b dc                	mov    bx,sp
     9c7:	36 c4 7f 0a          	les    di,DWORD PTR ss:[bx+0xa]
     9cb:	36 8b 47 04          	mov    ax,WORD PTR ss:[bx+0x4]
     9cf:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     9d3:	36 8b 47 06          	mov    ax,WORD PTR ss:[bx+0x6]
     9d7:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     9db:	36 8b 47 08          	mov    ax,WORD PTR ss:[bx+0x8]
     9df:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
     9e3:	33 c0                	xor    ax,ax
     9e5:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     9e9:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
     9ed:	ca 0a 00             	retf   0xa
     9f0:	ba b1 d7             	mov    dx,0xd7b1
     9f3:	eb 08                	jmp    0x9fd
     9f5:	ba b2 d7             	mov    dx,0xd7b2
     9f8:	eb 03                	jmp    0x9fd
     9fa:	ba b3 d7             	mov    dx,0xd7b3
     9fd:	45                   	inc    bp
     9fe:	55                   	push   bp
     9ff:	8b ec                	mov    bp,sp
     a01:	1e                   	push   ds
     a02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a05:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
     a09:	3d b1 d7             	cmp    ax,0xd7b1
     a0c:	74 12                	je     0xa20
     a0e:	3d b2 d7             	cmp    ax,0xd7b2
     a11:	74 0d                	je     0xa20
     a13:	3d b0 d7             	cmp    ax,0xd7b0
     a16:	74 10                	je     0xa28
     a18:	c7 06 78 18 66 00    	mov    WORD PTR ds:0x1878,0x66
     a1e:	eb 24                	jmp    0xa44
     a20:	52                   	push   dx
     a21:	06                   	push   es
     a22:	57                   	push   di
     a23:	0e                   	push   cs
     a24:	e8 28 00             	call   0xa4f
     a27:	5a                   	pop    dx
     a28:	33 c0                	xor    ax,ax
     a2a:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     a2e:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     a32:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
     a36:	bb 10 00             	mov    bx,0x10
     a39:	e8 54 00             	call   0xa90
     a3c:	74 06                	je     0xa44
     a3e:	26 c7 45 02 b0 d7    	mov    WORD PTR es:[di+0x2],0xd7b0
     a44:	8b e5                	mov    sp,bp
     a46:	5d                   	pop    bp
     a47:	4d                   	dec    bp
     a48:	ca 04 00             	retf   0x4
     a4b:	b0 00                	mov    al,0x0
     a4d:	eb 02                	jmp    0xa51
     a4f:	b0 01                	mov    al,0x1
     a51:	45                   	inc    bp
     a52:	55                   	push   bp
     a53:	8b ec                	mov    bp,sp
     a55:	1e                   	push   ds
     a56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a59:	26 81 7d 02 b1 d7    	cmp    WORD PTR es:[di+0x2],0xd7b1
     a5f:	74 18                	je     0xa79
     a61:	26 81 7d 02 b2 d7    	cmp    WORD PTR es:[di+0x2],0xd7b2
     a67:	74 08                	je     0xa71
     a69:	c7 06 78 18 67 00    	mov    WORD PTR ds:0x1878,0x67
     a6f:	eb 18                	jmp    0xa89
     a71:	50                   	push   ax
     a72:	bb 14 00             	mov    bx,0x14
     a75:	e8 18 00             	call   0xa90
     a78:	58                   	pop    ax
     a79:	0a c0                	or     al,al
     a7b:	74 0c                	je     0xa89
     a7d:	bb 1c 00             	mov    bx,0x1c
     a80:	e8 0d 00             	call   0xa90
     a83:	26 c7 45 02 b0 d7    	mov    WORD PTR es:[di+0x2],0xd7b0
     a89:	8b e5                	mov    sp,bp
     a8b:	5d                   	pop    bp
     a8c:	4d                   	dec    bp
     a8d:	ca 04 00             	retf   0x4
     a90:	06                   	push   es
     a91:	57                   	push   di
     a92:	06                   	push   es
     a93:	57                   	push   di
     a94:	26 ff 19             	call   DWORD PTR es:[bx+di]
     a97:	0b c0                	or     ax,ax
     a99:	74 03                	je     0xa9e
     a9b:	a3 78 18             	mov    ds:0x1878,ax
     a9e:	5f                   	pop    di
     a9f:	07                   	pop    es
     aa0:	c3                   	ret
     aa1:	8b dc                	mov    bx,sp
     aa3:	1e                   	push   ds
     aa4:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
     aa8:	26 c5 55 0c          	lds    dx,DWORD PTR es:[di+0xc]
     aac:	26 8b 4d 04          	mov    cx,WORD PTR es:[di+0x4]
     ab0:	26 8b 1d             	mov    bx,WORD PTR es:[di]
     ab3:	b4 3f                	mov    ah,0x3f
     ab5:	cd 21                	int    0x21
     ab7:	72 10                	jb     0xac9
     ab9:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
     abd:	33 c0                	xor    ax,ax
     abf:	26 c7 45 08 00 00    	mov    WORD PTR es:[di+0x8],0x0
     ac5:	1f                   	pop    ds
     ac6:	ca 04 00             	retf   0x4
     ac9:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
     acf:	eb ee                	jmp    0xabf
     ad1:	8b dc                	mov    bx,sp
     ad3:	1e                   	push   ds
     ad4:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
     ad8:	26 c5 55 0c          	lds    dx,DWORD PTR es:[di+0xc]
     adc:	33 c9                	xor    cx,cx
     ade:	26 87 4d 08          	xchg   WORD PTR es:[di+0x8],cx
     ae2:	26 8b 1d             	mov    bx,WORD PTR es:[di]
     ae5:	b4 40                	mov    ah,0x40
     ae7:	cd 21                	int    0x21
     ae9:	72 07                	jb     0xaf2
     aeb:	2b c1                	sub    ax,cx
     aed:	74 03                	je     0xaf2
     aef:	b8 65 00             	mov    ax,0x65
     af2:	1f                   	pop    ds
     af3:	ca 04 00             	retf   0x4
     af6:	8b dc                	mov    bx,sp
     af8:	1e                   	push   ds
     af9:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
     afd:	26 c5 55 0c          	lds    dx,DWORD PTR es:[di+0xc]
     b01:	33 c9                	xor    cx,cx
     b03:	26 87 4d 08          	xchg   WORD PTR es:[di+0x8],cx
     b07:	26 8b 1d             	mov    bx,WORD PTR es:[di]
     b0a:	b4 40                	mov    ah,0x40
     b0c:	cd 21                	int    0x21
     b0e:	72 02                	jb     0xb12
     b10:	33 c0                	xor    ax,ax
     b12:	1f                   	pop    ds
     b13:	ca 04 00             	retf   0x4
     b16:	8b dc                	mov    bx,sp
     b18:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
     b1c:	26 8b 1d             	mov    bx,WORD PTR es:[di]
     b1f:	83 fb 04             	cmp    bx,0x4
     b22:	76 06                	jbe    0xb2a
     b24:	b4 3e                	mov    ah,0x3e
     b26:	cd 21                	int    0x21
     b28:	72 02                	jb     0xb2c
     b2a:	33 c0                	xor    ax,ax
     b2c:	ca 04 00             	retf   0x4
     b2f:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     b34:	75 35                	jne    0xb6b
     b36:	26 81 7f 02 b1 d7    	cmp    WORD PTR es:[bx+0x2],0xd7b1
     b3c:	75 2e                	jne    0xb6c
     b3e:	26 8b 77 08          	mov    si,WORD PTR es:[bx+0x8]
     b42:	26 3b 77 0a          	cmp    si,WORD PTR es:[bx+0xa]
     b46:	74 2b                	je     0xb73
     b48:	1e                   	push   ds
     b49:	06                   	push   es
     b4a:	53                   	push   bx
     b4b:	52                   	push   dx
     b4c:	26 c5 57 0c          	lds    dx,DWORD PTR es:[bx+0xc]
     b50:	26 8b 5f 0a          	mov    bx,WORD PTR es:[bx+0xa]
     b54:	07                   	pop    es
     b55:	03 da                	add    bx,dx
     b57:	03 f2                	add    si,dx
     b59:	fc                   	cld
     b5a:	ff d0                	call   ax
     b5c:	2b f2                	sub    si,dx
     b5e:	8c c2                	mov    dx,es
     b60:	5b                   	pop    bx
     b61:	07                   	pop    es
     b62:	1f                   	pop    ds
     b63:	26 89 77 08          	mov    WORD PTR es:[bx+0x8],si
     b67:	0b c0                	or     ax,ax
     b69:	75 08                	jne    0xb73
     b6b:	c3                   	ret
     b6c:	c7 06 78 18 68 00    	mov    WORD PTR ds:0x1878,0x68
     b72:	c3                   	ret
     b73:	50                   	push   ax
     b74:	51                   	push   cx
     b75:	52                   	push   dx
     b76:	57                   	push   di
     b77:	06                   	push   es
     b78:	53                   	push   bx
     b79:	e8 42 01             	call   0xcbe
     b7c:	5b                   	pop    bx
     b7d:	07                   	pop    es
     b7e:	5f                   	pop    di
     b7f:	5a                   	pop    dx
     b80:	59                   	pop    cx
     b81:	58                   	pop    ax
     b82:	26 8b 77 08          	mov    si,WORD PTR es:[bx+0x8]
     b86:	26 3b 77 0a          	cmp    si,WORD PTR es:[bx+0xa]
     b8a:	75 bc                	jne    0xb48
     b8c:	c3                   	ret
     b8d:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     b92:	75 40                	jne    0xbd4
     b94:	26 81 7f 02 b2 d7    	cmp    WORD PTR es:[bx+0x2],0xd7b2
     b9a:	75 39                	jne    0xbd5
     b9c:	26 8b 4f 04          	mov    cx,WORD PTR es:[bx+0x4]
     ba0:	26 8b 7f 08          	mov    di,WORD PTR es:[bx+0x8]
     ba4:	2b cf                	sub    cx,di
     ba6:	2b d1                	sub    dx,cx
     ba8:	73 04                	jae    0xbae
     baa:	03 ca                	add    cx,dx
     bac:	33 d2                	xor    dx,dx
     bae:	06                   	push   es
     baf:	26 c4 77 0c          	les    si,DWORD PTR es:[bx+0xc]
     bb3:	03 fe                	add    di,si
     bb5:	b0 20                	mov    al,0x20
     bb7:	fc                   	cld
     bb8:	f3 aa                	rep stos BYTE PTR es:[di],al
     bba:	2b fe                	sub    di,si
     bbc:	07                   	pop    es
     bbd:	26 89 7f 08          	mov    WORD PTR es:[bx+0x8],di
     bc1:	26 3b 7f 04          	cmp    di,WORD PTR es:[bx+0x4]
     bc5:	75 09                	jne    0xbd0
     bc7:	52                   	push   dx
     bc8:	06                   	push   es
     bc9:	53                   	push   bx
     bca:	e8 f1 00             	call   0xcbe
     bcd:	5b                   	pop    bx
     bce:	07                   	pop    es
     bcf:	5a                   	pop    dx
     bd0:	0b d2                	or     dx,dx
     bd2:	75 c8                	jne    0xb9c
     bd4:	c3                   	ret
     bd5:	c7 06 78 18 69 00    	mov    WORD PTR ds:0x1878,0x69
     bdb:	c3                   	ret
     bdc:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     be1:	75 48                	jne    0xc2b
     be3:	26 81 7f 02 b2 d7    	cmp    WORD PTR es:[bx+0x2],0xd7b2
     be9:	75 41                	jne    0xc2c
     beb:	26 8b 4f 04          	mov    cx,WORD PTR es:[bx+0x4]
     bef:	26 8b 7f 08          	mov    di,WORD PTR es:[bx+0x8]
     bf3:	2b cf                	sub    cx,di
     bf5:	2b c1                	sub    ax,cx
     bf7:	73 04                	jae    0xbfd
     bf9:	03 c8                	add    cx,ax
     bfb:	33 c0                	xor    ax,ax
     bfd:	1e                   	push   ds
     bfe:	06                   	push   es
     bff:	53                   	push   bx
     c00:	8e da                	mov    ds,dx
     c02:	26 c4 5f 0c          	les    bx,DWORD PTR es:[bx+0xc]
     c06:	03 fb                	add    di,bx
     c08:	fc                   	cld
     c09:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     c0b:	2b fb                	sub    di,bx
     c0d:	5b                   	pop    bx
     c0e:	07                   	pop    es
     c0f:	1f                   	pop    ds
     c10:	26 89 7f 08          	mov    WORD PTR es:[bx+0x8],di
     c14:	26 3b 7f 04          	cmp    di,WORD PTR es:[bx+0x4]
     c18:	75 0d                	jne    0xc27
     c1a:	50                   	push   ax
     c1b:	52                   	push   dx
     c1c:	56                   	push   si
     c1d:	06                   	push   es
     c1e:	53                   	push   bx
     c1f:	e8 9c 00             	call   0xcbe
     c22:	5b                   	pop    bx
     c23:	07                   	pop    es
     c24:	5e                   	pop    si
     c25:	5a                   	pop    dx
     c26:	58                   	pop    ax
     c27:	0b c0                	or     ax,ax
     c29:	75 c0                	jne    0xbeb
     c2b:	c3                   	ret
     c2c:	c7 06 78 18 69 00    	mov    WORD PTR ds:0x1878,0x69
     c32:	c3                   	ret
     c33:	45                   	inc    bp
     c34:	55                   	push   bp
     c35:	8b ec                	mov    bp,sp
     c37:	1e                   	push   ds
     c38:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
     c3b:	b8 56 0c             	mov    ax,0xc56
     c3e:	33 d2                	xor    dx,dx
     c40:	e8 ec fe             	call   0xb2f
     c43:	75 0a                	jne    0xc4f
     c45:	26 83 7f 1a 00       	cmp    WORD PTR es:[bx+0x1a],0x0
     c4a:	74 03                	je     0xc4f
     c4c:	e8 7d 00             	call   0xccc
     c4f:	8b e5                	mov    sp,bp
     c51:	5d                   	pop    bp
     c52:	4d                   	dec    bp
     c53:	ca 04 00             	retf   0x4
     c56:	ac                   	lods   al,BYTE PTR ds:[si]
     c57:	3c 0d                	cmp    al,0xd
     c59:	74 0c                	je     0xc67
     c5b:	3c 1a                	cmp    al,0x1a
     c5d:	74 11                	je     0xc70
     c5f:	3b f3                	cmp    si,bx
     c61:	75 f3                	jne    0xc56
     c63:	b8 56 0c             	mov    ax,0xc56
     c66:	c3                   	ret
     c67:	3b f3                	cmp    si,bx
     c69:	74 09                	je     0xc74
     c6b:	ac                   	lods   al,BYTE PTR ds:[si]
     c6c:	3c 0a                	cmp    al,0xa
     c6e:	74 01                	je     0xc71
     c70:	4e                   	dec    si
     c71:	33 c0                	xor    ax,ax
     c73:	c3                   	ret
     c74:	b8 6b 0c             	mov    ax,0xc6b
     c77:	c3                   	ret
     c78:	45                   	inc    bp
     c79:	55                   	push   bp
     c7a:	8b ec                	mov    bp,sp
     c7c:	1e                   	push   ds
     c7d:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
     c80:	b8 02 00             	mov    ax,0x2
     c83:	be f4 18             	mov    si,0x18f4
     c86:	8c da                	mov    dx,ds
     c88:	e8 51 ff             	call   0xbdc
     c8b:	75 0a                	jne    0xc97
     c8d:	26 83 7f 1a 00       	cmp    WORD PTR es:[bx+0x1a],0x0
     c92:	74 03                	je     0xc97
     c94:	e8 35 00             	call   0xccc
     c97:	8b e5                	mov    sp,bp
     c99:	5d                   	pop    bp
     c9a:	4d                   	dec    bp
     c9b:	ca 04 00             	retf   0x4
     c9e:	45                   	inc    bp
     c9f:	55                   	push   bp
     ca0:	8b ec                	mov    bp,sp
     ca2:	1e                   	push   ds
     ca3:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
     ca6:	26 83 7f 1a 00       	cmp    WORD PTR es:[bx+0x1a],0x0
     cab:	74 0a                	je     0xcb7
     cad:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     cb2:	75 03                	jne    0xcb7
     cb4:	e8 15 00             	call   0xccc
     cb7:	8b e5                	mov    sp,bp
     cb9:	5d                   	pop    bp
     cba:	4d                   	dec    bp
     cbb:	ca 04 00             	retf   0x4
     cbe:	06                   	push   es
     cbf:	53                   	push   bx
     cc0:	26 ff 5f 14          	call   DWORD PTR es:[bx+0x14]
     cc4:	0b c0                	or     ax,ax
     cc6:	74 03                	je     0xccb
     cc8:	a3 78 18             	mov    ds:0x1878,ax
     ccb:	c3                   	ret
     ccc:	06                   	push   es
     ccd:	53                   	push   bx
     cce:	26 ff 5f 18          	call   DWORD PTR es:[bx+0x18]
     cd2:	0b c0                	or     ax,ax
     cd4:	74 03                	je     0xcd9
     cd6:	a3 78 18             	mov    ds:0x1878,ax
     cd9:	c3                   	ret
     cda:	45                   	inc    bp
     cdb:	55                   	push   bp
     cdc:	8b ec                	mov    bp,sp
     cde:	1e                   	push   ds
     cdf:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     ce4:	75 3b                	jne    0xd21
     ce6:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
     ce9:	26 81 7f 02 b1 d7    	cmp    WORD PTR es:[bx+0x2],0xd7b1
     cef:	75 2a                	jne    0xd1b
     cf1:	26 8b 7f 08          	mov    di,WORD PTR es:[bx+0x8]
     cf5:	26 3b 7f 0a          	cmp    di,WORD PTR es:[bx+0xa]
     cf9:	75 10                	jne    0xd0b
     cfb:	e8 c0 ff             	call   0xcbe
     cfe:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
     d01:	26 8b 7f 08          	mov    di,WORD PTR es:[bx+0x8]
     d05:	26 3b 7f 0a          	cmp    di,WORD PTR es:[bx+0xa]
     d09:	74 16                	je     0xd21
     d0b:	26 ff 47 08          	inc    WORD PTR es:[bx+0x8]
     d0f:	26 c4 5f 0c          	les    bx,DWORD PTR es:[bx+0xc]
     d13:	26 8a 01             	mov    al,BYTE PTR es:[bx+di]
     d16:	8b e5                	mov    sp,bp
     d18:	5d                   	pop    bp
     d19:	4d                   	dec    bp
     d1a:	cb                   	retf
     d1b:	c7 06 78 18 68 00    	mov    WORD PTR ds:0x1878,0x68
     d21:	b0 1a                	mov    al,0x1a
     d23:	eb f1                	jmp    0xd16
     d25:	45                   	inc    bp
     d26:	55                   	push   bp
     d27:	8b ec                	mov    bp,sp
     d29:	1e                   	push   ds
     d2a:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
     d2d:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
     d30:	4a                   	dec    dx
     d31:	7e 03                	jle    0xd36
     d33:	e8 57 fe             	call   0xb8d
     d36:	83 3e 78 18 00       	cmp    WORD PTR ds:0x1878,0x0
     d3b:	75 29                	jne    0xd66
     d3d:	26 81 7f 02 b2 d7    	cmp    WORD PTR es:[bx+0x2],0xd7b2
     d43:	75 28                	jne    0xd6d
     d45:	26 ff 47 08          	inc    WORD PTR es:[bx+0x8]
     d49:	26 8b 7f 08          	mov    di,WORD PTR es:[bx+0x8]
     d4d:	26 8b 57 04          	mov    dx,WORD PTR es:[bx+0x4]
     d51:	26 c4 5f 0c          	les    bx,DWORD PTR es:[bx+0xc]
     d55:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
     d58:	26 88 41 ff          	mov    BYTE PTR es:[bx+di-0x1],al
     d5c:	3b fa                	cmp    di,dx
     d5e:	75 06                	jne    0xd66
     d60:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
     d63:	e8 58 ff             	call   0xcbe
     d66:	8b e5                	mov    sp,bp
     d68:	5d                   	pop    bp
     d69:	4d                   	dec    bp
     d6a:	ca 04 00             	retf   0x4
     d6d:	c7 06 78 18 69 00    	mov    WORD PTR ds:0x1878,0x69
     d73:	eb f1                	jmp    0xd66
     d75:	45                   	inc    bp
     d76:	55                   	push   bp
     d77:	8b ec                	mov    bp,sp
     d79:	1e                   	push   ds
     d7a:	c4 5e 0c             	les    bx,DWORD PTR [bp+0xc]
     d7d:	b8 9d 0d             	mov    ax,0xd9d
     d80:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     d83:	8b 7e 08             	mov    di,WORD PTR [bp+0x8]
     d86:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
     d89:	47                   	inc    di
     d8a:	e8 a2 fd             	call   0xb2f
     d8d:	8b c7                	mov    ax,di
     d8f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     d92:	2b c7                	sub    ax,di
     d94:	48                   	dec    ax
     d95:	aa                   	stos   BYTE PTR es:[di],al
     d96:	8b e5                	mov    sp,bp
     d98:	5d                   	pop    bp
     d99:	4d                   	dec    bp
     d9a:	ca 06 00             	retf   0x6
     d9d:	ac                   	lods   al,BYTE PTR ds:[si]
     d9e:	3c 0d                	cmp    al,0xd
     da0:	74 0f                	je     0xdb1
     da2:	3c 1a                	cmp    al,0x1a
     da4:	74 0b                	je     0xdb1
     da6:	aa                   	stos   BYTE PTR es:[di],al
     da7:	3b f3                	cmp    si,bx
     da9:	e0 f2                	loopne 0xd9d
     dab:	e3 05                	jcxz   0xdb2
     dad:	b8 9d 0d             	mov    ax,0xd9d
     db0:	c3                   	ret
     db1:	4e                   	dec    si
     db2:	33 c0                	xor    ax,ax
     db4:	c3                   	ret
     db5:	45                   	inc    bp
     db6:	55                   	push   bp
     db7:	8b ec                	mov    bp,sp
     db9:	1e                   	push   ds
     dba:	c4 5e 08             	les    bx,DWORD PTR [bp+0x8]
     dbd:	26 8a 07             	mov    al,BYTE PTR es:[bx]
     dc0:	32 e4                	xor    ah,ah
     dc2:	c4 5e 0c             	les    bx,DWORD PTR [bp+0xc]
     dc5:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
     dc8:	2b d0                	sub    dx,ax
     dca:	7e 05                	jle    0xdd1
     dcc:	50                   	push   ax
     dcd:	e8 bd fd             	call   0xb8d
     dd0:	58                   	pop    ax
     dd1:	0b c0                	or     ax,ax
     dd3:	74 0a                	je     0xddf
     dd5:	8b 76 08             	mov    si,WORD PTR [bp+0x8]
     dd8:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
     ddb:	46                   	inc    si
     ddc:	e8 fd fd             	call   0xbdc
     ddf:	8b e5                	mov    sp,bp
     de1:	5d                   	pop    bp
     de2:	4d                   	dec    bp
     de3:	ca 06 00             	retf   0x6
     de6:	45                   	inc    bp
     de7:	55                   	push   bp
     de8:	8b ec                	mov    bp,sp
     dea:	1e                   	push   ds
     deb:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     dee:	e3 10                	jcxz   0xe00
     df0:	1e                   	push   ds
     df1:	e8 3e 00             	call   0xe32
     df4:	8b f3                	mov    si,bx
     df6:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     df9:	aa                   	stos   BYTE PTR es:[di],al
     dfa:	91                   	xchg   cx,ax
     dfb:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     dfd:	1f                   	pop    ds
     dfe:	eb 20                	jmp    0xe20
     e00:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     e04:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     e07:	47                   	inc    di
     e08:	06                   	push   es
     e09:	57                   	push   di
     e0a:	b8 ff 00             	mov    ax,0xff
     e0d:	50                   	push   ax
     e0e:	9a ff ff 00 00       	call   0x0:0xffff
     e13:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     e16:	aa                   	stos   BYTE PTR es:[di],al
     e17:	06                   	push   es
     e18:	57                   	push   di
     e19:	06                   	push   es
     e1a:	57                   	push   di
     e1b:	9a 90 0e 00 00       	call   0x0:0xe90
     e20:	8b e5                	mov    sp,bp
     e22:	5d                   	pop    bp
     e23:	4d                   	dec    bp
     e24:	ca 02 00             	retf   0x2
     e27:	1e                   	push   ds
     e28:	33 c9                	xor    cx,cx
     e2a:	e8 05 00             	call   0xe32
     e2d:	91                   	xchg   cx,ax
     e2e:	f7 d8                	neg    ax
     e30:	1f                   	pop    ds
     e31:	cb                   	retf
     e32:	c5 36 90 18          	lds    si,DWORD PTR ds:0x1890
     e36:	8c d8                	mov    ax,ds
     e38:	0b c0                	or     ax,ax
     e3a:	74 1b                	je     0xe57
     e3c:	fc                   	cld
     e3d:	ac                   	lods   al,BYTE PTR ds:[si]
     e3e:	0a c0                	or     al,al
     e40:	74 04                	je     0xe46
     e42:	3c 20                	cmp    al,0x20
     e44:	76 f7                	jbe    0xe3d
     e46:	4e                   	dec    si
     e47:	8b de                	mov    bx,si
     e49:	ac                   	lods   al,BYTE PTR ds:[si]
     e4a:	3c 20                	cmp    al,0x20
     e4c:	77 fb                	ja     0xe49
     e4e:	4e                   	dec    si
     e4f:	8b c6                	mov    ax,si
     e51:	2b c3                	sub    ax,bx
     e53:	74 02                	je     0xe57
     e55:	e2 e6                	loop   0xe3d
     e57:	c3                   	ret
     e58:	55                   	push   bp
     e59:	8b ec                	mov    bp,sp
     e5b:	81 ec 80 00          	sub    sp,0x80
     e5f:	1e                   	push   ds
     e60:	8d 76 80             	lea    si,[bp-0x80]
     e63:	16                   	push   ss
     e64:	1f                   	pop    ds
     e65:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
     e68:	0a c0                	or     al,al
     e6a:	75 06                	jne    0xe72
     e6c:	b4 19                	mov    ah,0x19
     e6e:	cd 21                	int    0x21
     e70:	fe c0                	inc    al
     e72:	8a d0                	mov    dl,al
     e74:	04 40                	add    al,0x40
     e76:	88 04                	mov    BYTE PTR [si],al
     e78:	46                   	inc    si
     e79:	c7 04 3a 5c          	mov    WORD PTR [si],0x5c3a
     e7d:	46                   	inc    si
     e7e:	46                   	inc    si
     e7f:	b4 47                	mov    ah,0x47
     e81:	cd 21                	int    0x21
     e83:	73 03                	jae    0xe88
     e85:	c6 04 00             	mov    BYTE PTR [si],0x0
     e88:	8d 76 80             	lea    si,[bp-0x80]
     e8b:	1e                   	push   ds
     e8c:	56                   	push   si
     e8d:	1e                   	push   ds
     e8e:	56                   	push   si
     e8f:	9a ff ff 00 00       	call   0x0:0xffff
     e94:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     e97:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     e9a:	33 db                	xor    bx,bx
     e9c:	fc                   	cld
     e9d:	ac                   	lods   al,BYTE PTR ds:[si]
     e9e:	0a c0                	or     al,al
     ea0:	74 06                	je     0xea8
     ea2:	43                   	inc    bx
     ea3:	26 88 01             	mov    BYTE PTR es:[bx+di],al
     ea6:	e2 f5                	loop   0xe9d
     ea8:	26 88 1d             	mov    BYTE PTR es:[di],bl
     eab:	1f                   	pop    ds
     eac:	8b e5                	mov    sp,bp
     eae:	5d                   	pop    bp
     eaf:	ca 08 00             	retf   0x8
     eb2:	55                   	push   bp
     eb3:	8b ec                	mov    bp,sp
     eb5:	81 ec 80 00          	sub    sp,0x80
     eb9:	e8 61 00             	call   0xf1d
     ebc:	8b 46 80             	mov    ax,WORD PTR [bp-0x80]
     ebf:	0a c0                	or     al,al
     ec1:	74 2a                	je     0xeed
     ec3:	80 fc 3a             	cmp    ah,0x3a
     ec6:	75 20                	jne    0xee8
     ec8:	24 df                	and    al,0xdf
     eca:	2c 41                	sub    al,0x41
     ecc:	8a d0                	mov    dl,al
     ece:	b4 0e                	mov    ah,0xe
     ed0:	cd 21                	int    0x21
     ed2:	b4 19                	mov    ah,0x19
     ed4:	cd 21                	int    0x21
     ed6:	3a c2                	cmp    al,dl
     ed8:	74 08                	je     0xee2
     eda:	c7 06 78 18 0f 00    	mov    WORD PTR ds:0x1878,0xf
     ee0:	eb 0b                	jmp    0xeed
     ee2:	80 7e 82 00          	cmp    BYTE PTR [bp-0x7e],0x0
     ee6:	74 05                	je     0xeed
     ee8:	b4 3b                	mov    ah,0x3b
     eea:	e8 54 00             	call   0xf41
     eed:	8b e5                	mov    sp,bp
     eef:	5d                   	pop    bp
     ef0:	ca 04 00             	retf   0x4
     ef3:	55                   	push   bp
     ef4:	8b ec                	mov    bp,sp
     ef6:	81 ec 80 00          	sub    sp,0x80
     efa:	e8 20 00             	call   0xf1d
     efd:	b4 39                	mov    ah,0x39
     eff:	e8 3f 00             	call   0xf41
     f02:	8b e5                	mov    sp,bp
     f04:	5d                   	pop    bp
     f05:	ca 04 00             	retf   0x4
     f08:	55                   	push   bp
     f09:	8b ec                	mov    bp,sp
     f0b:	81 ec 80 00          	sub    sp,0x80
     f0f:	e8 0b 00             	call   0xf1d
     f12:	b4 3a                	mov    ah,0x3a
     f14:	e8 2a 00             	call   0xf41
     f17:	8b e5                	mov    sp,bp
     f19:	5d                   	pop    bp
     f1a:	ca 04 00             	retf   0x4
     f1d:	1e                   	push   ds
     f1e:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     f21:	8d 7e 80             	lea    di,[bp-0x80]
     f24:	16                   	push   ss
     f25:	07                   	pop    es
     f26:	06                   	push   es
     f27:	57                   	push   di
     f28:	06                   	push   es
     f29:	57                   	push   di
     f2a:	fc                   	cld
     f2b:	ac                   	lods   al,BYTE PTR ds:[si]
     f2c:	3c 7f                	cmp    al,0x7f
     f2e:	72 02                	jb     0xf32
     f30:	b0 7f                	mov    al,0x7f
     f32:	98                   	cbw
     f33:	8b c8                	mov    cx,ax
     f35:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     f37:	32 c0                	xor    al,al
     f39:	aa                   	stos   BYTE PTR es:[di],al
     f3a:	9a ff ff 00 00       	call   0x0:0xffff
     f3f:	1f                   	pop    ds
     f40:	c3                   	ret
     f41:	1e                   	push   ds
     f42:	8d 56 80             	lea    dx,[bp-0x80]
     f45:	16                   	push   ss
     f46:	1f                   	pop    ds
     f47:	cd 21                	int    0x21
     f49:	1f                   	pop    ds
     f4a:	73 03                	jae    0xf4f
     f4c:	a3 78 18             	mov    ds:0x1878,ax
     f4f:	c3                   	ret
     f50:	45                   	inc    bp
     f51:	55                   	push   bp
     f52:	8b ec                	mov    bp,sp
     f54:	1e                   	push   ds
     f55:	33 db                	xor    bx,bx
     f57:	9a 66 0f 00 00       	call   0x0:0xf66
     f5c:	bb 03 00             	mov    bx,0x3
     f5f:	b8 6f 0f             	mov    ax,0xf6f
     f62:	ba 4e 14             	mov    dx,0x144e
     f65:	9a 8e 0f 00 00       	call   0x0:0xf8e
     f6a:	8b e5                	mov    sp,bp
     f6c:	5d                   	pop    bp
     f6d:	4d                   	dec    bp
     f6e:	cb                   	retf
     f6f:	16                   	push   ss
     f70:	1f                   	pop    ds
     f71:	ba 07 00             	mov    dx,0x7
     f74:	3c 83                	cmp    al,0x83
     f76:	74 11                	je     0xf89
     f78:	ba 08 00             	mov    dx,0x8
     f7b:	3c 84                	cmp    al,0x84
     f7d:	74 0a                	je     0xf89
     f7f:	ba 09 00             	mov    dx,0x9
     f82:	3c 85                	cmp    al,0x85
     f84:	74 03                	je     0xf89
     f86:	ba 06 00             	mov    dx,0x6
     f89:	52                   	push   dx
     f8a:	bb 01 00             	mov    bx,0x1
     f8d:	9a ff ff 00 00       	call   0x0:0xffff
     f92:	58                   	pop    ax
     f93:	b9 ff ff             	mov    cx,0xffff
     f96:	8b d9                	mov    bx,cx
     f98:	e9 c7 f0             	jmp    0x62
     f9b:	3f                   	aas
     f9c:	1f                   	pop    ds
     f9d:	0a c0                	or     al,al
     f9f:	74 22                	je     0xfc3
     fa1:	32 c9                	xor    cl,cl
     fa3:	8a ec                	mov    ch,ah
     fa5:	8a e6                	mov    ah,dh
     fa7:	80 e4 80             	and    ah,0x80
     faa:	05 7e 3f             	add    ax,0x3f7e
     fad:	80 ce 80             	or     dh,0x80
     fb0:	50                   	push   ax
     fb1:	52                   	push   dx
     fb2:	53                   	push   bx
     fb3:	51                   	push   cx
     fb4:	33 c9                	xor    cx,cx
     fb6:	51                   	push   cx
     fb7:	8b dc                	mov    bx,sp
     fb9:	9b 36 db 2f          	fld    TBYTE PTR ss:[bx]
     fbd:	90                   	nop
     fbe:	9b                   	fwait
     fbf:	83 c4 0a             	add    sp,0xa
     fc2:	cb                   	retf
     fc3:	9b d9 ee             	fldz
     fc6:	cb                   	retf
     fc7:	83 ec 0a             	sub    sp,0xa
     fca:	8b dc                	mov    bx,sp
     fcc:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
     fd0:	90                   	nop
     fd1:	9b                   	fwait
     fd2:	83 c4 02             	add    sp,0x2
     fd5:	59                   	pop    cx
     fd6:	5b                   	pop    bx
     fd7:	5a                   	pop    dx
     fd8:	58                   	pop    ax
     fd9:	8b f8                	mov    di,ax
     fdb:	25 ff 7f             	and    ax,0x7fff
     fde:	2d 7e 3f             	sub    ax,0x3f7e
     fe1:	76 1a                	jbe    0xffd
     fe3:	0a e4                	or     ah,ah
     fe5:	75 21                	jne    0x1008
     fe7:	8a e5                	mov    ah,ch
     fe9:	d0 e1                	shl    cl,1
     feb:	80 d4 00             	adc    ah,0x0
     fee:	83 d3 00             	adc    bx,0x0
     ff1:	83 d2 00             	adc    dx,0x0
     ff4:	72 0e                	jb     0x1004
     ff6:	d1 e2                	shl    dx,1
     ff8:	d1 e7                	shl    di,1
     ffa:	d1 da                	rcr    dx,1
     ffc:	cb                   	retf
     ffd:	33 c0                	xor    ax,ax
     fff:	33 db                	xor    bx,bx
    1001:	33 d2                	xor    dx,dx
    1003:	cb                   	retf
    1004:	fe c0                	inc    al
    1006:	75 ee                	jne    0xff6
    1008:	b8 08 00             	mov    ax,0x8
    100b:	e9 52 f0             	jmp    0x60
    100e:	9b d9 3e ae 2e       	fstcw  WORD PTR ds:0x2eae
    1013:	9b 2e d9 2e 9b 0f    	fldcw  WORD PTR cs:0xf9b
    1019:	9b db 1e aa 2e       	fistp  DWORD PTR ds:0x2eaa
    101e:	90                   	nop
    101f:	9b 9b d9 2e ae 2e    	fldcw  WORD PTR ds:0x2eae
    1025:	90                   	nop
    1026:	9b                   	fwait
    1027:	a1 aa 2e             	mov    ax,ds:0x2eaa
    102a:	8b 16 ac 2e          	mov    dx,WORD PTR ds:0x2eac
    102e:	cb                   	retf
    102f:	9b d9 fc             	frndint
    1032:	9b db 1e aa 2e       	fistp  DWORD PTR ds:0x2eaa
    1037:	90                   	nop
    1038:	9b                   	fwait
    1039:	a1 aa 2e             	mov    ax,ds:0x2eaa
    103c:	8b 16 ac 2e          	mov    dx,WORD PTR ds:0x2eac
    1040:	cb                   	retf
    1041:	9b d9 3e ae 2e       	fstcw  WORD PTR ds:0x2eae
    1046:	9b 2e d9 2e 9b 0f    	fldcw  WORD PTR cs:0xf9b
    104c:	9b d9 fc             	frndint
    104f:	90                   	nop
    1050:	9b 9b d9 2e ae 2e    	fldcw  WORD PTR ds:0x2eae
    1056:	cb                   	retf
    1057:	9b d9 3e ae 2e       	fstcw  WORD PTR ds:0x2eae
    105c:	9b 2e d9 2e 9b 0f    	fldcw  WORD PTR cs:0xf9b
    1062:	9b d9 c0             	fld    st(0)
    1065:	9b d9 fc             	frndint
    1068:	9b de e9             	fsubp  st(1),st
    106b:	90                   	nop
    106c:	9b 9b d9 2e ae 2e    	fldcw  WORD PTR ds:0x2eae
    1072:	cb                   	retf
    1073:	9b d9 fa             	fsqrt
    1076:	cb                   	retf
    1077:	e8 43 00             	call   0x10bd
    107a:	cb                   	retf
    107b:	e8 43 00             	call   0x10c1
    107e:	cb                   	retf
    107f:	e8 38 01             	call   0x11ba
    1082:	cb                   	retf
    1083:	e8 a7 01             	call   0x122d
    1086:	cb                   	retf
    1087:	e8 1d 02             	call   0x12a7
    108a:	cb                   	retf
    108b:	35 c2 68             	xor    ax,0x68c2
    108e:	21 a2 da 0f          	and    WORD PTR [bp+si+0xfda],sp
    1092:	c9                   	leave
    1093:	fe                   	(bad)
    1094:	3f                   	aas
    1095:	35 c2 68             	xor    ax,0x68c2
    1098:	21 a2 da 0f          	and    WORD PTR [bp+si+0xfda],sp
    109c:	c9                   	leave
    109d:	ff                   	(bad)
    109e:	3f                   	aas
    109f:	00 42 c0             	add    BYTE PTR [bp+si-0x40],al
    10a2:	ff 00                	inc    WORD PTR [bx+si]
    10a4:	48                   	dec    ax
    10a5:	c0 ff 00             	sar    bh,0x0
    10a8:	4a                   	dec    dx
    10a9:	c0 ff 00             	sar    bh,0x0
    10ac:	00 00                	add    BYTE PTR [bx+si],al
    10ae:	3f                   	aas
    10af:	85 64 de             	test   WORD PTR [si-0x22],sp
    10b2:	f9                   	stc
    10b3:	33 f3                	xor    si,bx
    10b5:	04 b5                	add    al,0xb5
    10b7:	ff                   	(bad)
    10b8:	3f                   	aas
    10b9:	00 00                	add    BYTE PTR [bx+si],al
    10bb:	80 7f b1 00          	cmp    BYTE PTR [bx-0x4f],0x0
    10bf:	eb 06                	jmp    0x10c7
    10c1:	b1 02                	mov    cl,0x2
    10c3:	eb 02                	jmp    0x10c7
    10c5:	b1 04                	mov    cl,0x4
    10c7:	9b d9 e5             	fxam
    10ca:	55                   	push   bp
    10cb:	8b ec                	mov    bp,sp
    10cd:	8d 66 fe             	lea    sp,[bp-0x2]
    10d0:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    10d4:	9b                   	fwait
    10d5:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    10d8:	9e                   	sahf
    10d9:	72 0f                	jb     0x10ea
    10db:	75 2e                	jne    0x110b
    10dd:	80 f9 02             	cmp    cl,0x2
    10e0:	75 06                	jne    0x10e8
    10e2:	9b dd d8             	fstp   st(0)
    10e5:	9b d9 e8             	fld1
    10e8:	eb 1e                	jmp    0x1108
    10ea:	74 0e                	je     0x10fa
    10ec:	7b 0c                	jnp    0x10fa
    10ee:	9b dd d8             	fstp   st(0)
    10f1:	9b 2e d9 06 9f 10    	fld    DWORD PTR cs:0x109f
    10f7:	9b d9 e4             	ftst
    10fa:	eb 0c                	jmp    0x1108
    10fc:	9b de d9             	fcompp
    10ff:	9b 2e d9 06 9f 10    	fld    DWORD PTR cs:0x109f
    1105:	9b d9 e4             	ftst
    1108:	e9 ab 00             	jmp    0x11b6
    110b:	9b d9 e1             	fabs
    110e:	9b 2e db 2e 8b 10    	fld    TBYTE PTR cs:0x108b
    1114:	9b d9 e5             	fxam
    1117:	9b d9 c9             	fxch   st(1)
    111a:	9b d9 f8             	fprem
    111d:	b5 02                	mov    ch,0x2
    111f:	22 ec                	and    ch,ah
    1121:	d0 ed                	shr    ch,1
    1123:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    1127:	9b                   	fwait
    1128:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    112b:	9e                   	sahf
    112c:	7a ce                	jp     0x10fc
    112e:	b0 03                	mov    al,0x3
    1130:	22 c4                	and    al,ah
    1132:	d0 e4                	shl    ah,1
    1134:	d0 e4                	shl    ah,1
    1136:	d0 d0                	rcl    al,1
    1138:	04 fc                	add    al,0xfc
    113a:	d0 d0                	rcl    al,1
    113c:	80 f9 02             	cmp    cl,0x2
    113f:	75 04                	jne    0x1145
    1141:	02 c1                	add    al,cl
    1143:	b5 00                	mov    ch,0x0
    1145:	24 07                	and    al,0x7
    1147:	a8 01                	test   al,0x1
    1149:	74 05                	je     0x1150
    114b:	9b de e9             	fsubp  st(1),st
    114e:	eb 03                	jmp    0x1153
    1150:	9b dd d9             	fstp   st(1)
    1153:	9b d9 f2             	fptan
    1156:	80 f9 04             	cmp    cl,0x4
    1159:	74 29                	je     0x1184
    115b:	a8 03                	test   al,0x3
    115d:	7a 03                	jp     0x1162
    115f:	9b d9 c9             	fxch   st(1)
    1162:	9b d9 c1             	fld    st(1)
    1165:	9b d8 c8             	fmul   st,st(0)
    1168:	9b d9 c9             	fxch   st(1)
    116b:	9b d8 c8             	fmul   st,st(0)
    116e:	9b de c1             	faddp  st(1),st
    1171:	9b d9 fa             	fsqrt
    1174:	d0 e8                	shr    al,1
    1176:	d0 e8                	shr    al,1
    1178:	32 c5                	xor    al,ch
    117a:	74 03                	je     0x117f
    117c:	9b d9 e0             	fchs
    117f:	9b de f9             	fdivp  st(1),st
    1182:	eb 32                	jmp    0x11b6
    1184:	8a e0                	mov    ah,al
    1186:	d0 ec                	shr    ah,1
    1188:	80 e4 01             	and    ah,0x1
    118b:	32 e5                	xor    ah,ch
    118d:	74 03                	je     0x1192
    118f:	9b d9 e0             	fchs
    1192:	a8 03                	test   al,0x3
    1194:	7a 1d                	jp     0x11b3
    1196:	9b d9 c9             	fxch   st(1)
    1199:	9b d9 e4             	ftst
    119c:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    11a0:	90                   	nop
    11a1:	9b                   	fwait
    11a2:	f6 46 ff 40          	test   BYTE PTR [bp-0x1],0x40
    11a6:	74 0b                	je     0x11b3
    11a8:	9b de d9             	fcompp
    11ab:	9b 2e d9 06 b9 10    	fld    DWORD PTR cs:0x10b9
    11b1:	eb 03                	jmp    0x11b6
    11b3:	9b de f9             	fdivp  st(1),st
    11b6:	8b e5                	mov    sp,bp
    11b8:	5d                   	pop    bp
    11b9:	c3                   	ret
    11ba:	9b d9 e5             	fxam
    11bd:	55                   	push   bp
    11be:	8b ec                	mov    bp,sp
    11c0:	8d 66 fe             	lea    sp,[bp-0x2]
    11c3:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    11c7:	9b                   	fwait
    11c8:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    11cb:	9e                   	sahf
    11cc:	91                   	xchg   cx,ax
    11cd:	72 04                	jb     0x11d3
    11cf:	75 1c                	jne    0x11ed
    11d1:	eb 4c                	jmp    0x121f
    11d3:	74 4a                	je     0x121f
    11d5:	7b 48                	jnp    0x121f
    11d7:	9b dd d8             	fstp   st(0)
    11da:	9b 2e db 2e 95 10    	fld    TBYTE PTR cs:0x1095
    11e0:	eb 35                	jmp    0x1217
    11e2:	9b de d9             	fcompp
    11e5:	9b 2e db 2e 8b 10    	fld    TBYTE PTR cs:0x108b
    11eb:	eb 2a                	jmp    0x1217
    11ed:	9b d9 e1             	fabs
    11f0:	9b d9 e8             	fld1
    11f3:	9b d8 d1             	fcom   st(1)
    11f6:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    11fa:	9b                   	fwait
    11fb:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    11fe:	9e                   	sahf
    11ff:	74 e1                	je     0x11e2
    1201:	73 03                	jae    0x1206
    1203:	9b d9 c9             	fxch   st(1)
    1206:	9b d9 f3             	fpatan
    1209:	73 0c                	jae    0x1217
    120b:	9b 2e db 2e 95 10    	fld    TBYTE PTR cs:0x1095
    1211:	9b de e9             	fsubp  st(1),st
    1214:	80 f5 02             	xor    ch,0x2
    1217:	f6 c5 02             	test   ch,0x2
    121a:	74 03                	je     0x121f
    121c:	9b d9 e0             	fchs
    121f:	8b e5                	mov    sp,bp
    1221:	5d                   	pop    bp
    1222:	c3                   	ret
    1223:	9b d9 e8             	fld1
    1226:	eb 08                	jmp    0x1230
    1228:	9b d9 ec             	fldlg2
    122b:	eb 03                	jmp    0x1230
    122d:	9b d9 ed             	fldln2
    1230:	9b d9 c9             	fxch   st(1)
    1233:	55                   	push   bp
    1234:	8b ec                	mov    bp,sp
    1236:	9b d9 e5             	fxam
    1239:	8d 66 f6             	lea    sp,[bp-0xa]
    123c:	9b dd 7e f6          	fstsw  WORD PTR [bp-0xa]
    1240:	9b                   	fwait
    1241:	8a 66 f7             	mov    ah,BYTE PTR [bp-0x9]
    1244:	9e                   	sahf
    1245:	72 0c                	jb     0x1253
    1247:	74 05                	je     0x124e
    1249:	f6 c4 02             	test   ah,0x2
    124c:	74 22                	je     0x1270
    124e:	9b dd d8             	fstp   st(0)
    1251:	eb 0f                	jmp    0x1262
    1253:	74 16                	je     0x126b
    1255:	9b dd d9             	fstp   st(1)
    1258:	7b 11                	jnp    0x126b
    125a:	9b dd d9             	fstp   st(1)
    125d:	f6 c4 02             	test   ah,0x2
    1260:	74 33                	je     0x1295
    1262:	9b dd d8             	fstp   st(0)
    1265:	9b 2e d9 06 a3 10    	fld    DWORD PTR cs:0x10a3
    126b:	9b d9 e4             	ftst
    126e:	eb 25                	jmp    0x1295
    1270:	9b d9 c0             	fld    st(0)
    1273:	9b db 7e f6          	fstp   TBYTE PTR [bp-0xa]
    1277:	90                   	nop
    1278:	9b                   	fwait
    1279:	81 7e fe ff 3f       	cmp    WORD PTR [bp-0x2],0x3fff
    127e:	75 12                	jne    0x1292
    1280:	81 7e fc 00 80       	cmp    WORD PTR [bp-0x4],0x8000
    1285:	75 0b                	jne    0x1292
    1287:	9b d9 e8             	fld1
    128a:	9b de e9             	fsubp  st(1),st
    128d:	9b d9 f9             	fyl2xp1
    1290:	eb 03                	jmp    0x1295
    1292:	9b d9 f1             	fyl2x
    1295:	8b e5                	mov    sp,bp
    1297:	5d                   	pop    bp
    1298:	c3                   	ret
    1299:	2b c9                	sub    cx,cx
    129b:	eb 12                	jmp    0x12af
    129d:	9b d9 e9             	fldl2t
    12a0:	b1 01                	mov    cl,0x1
    12a2:	9b d9 c9             	fxch   st(1)
    12a5:	eb 08                	jmp    0x12af
    12a7:	9b d9 ea             	fldl2e
    12aa:	b1 01                	mov    cl,0x1
    12ac:	9b d9 c9             	fxch   st(1)
    12af:	9b d9 e5             	fxam
    12b2:	55                   	push   bp
    12b3:	8b ec                	mov    bp,sp
    12b5:	8d 66 fc             	lea    sp,[bp-0x4]
    12b8:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    12bc:	e3 03                	jcxz   0x12c1
    12be:	9b d9 c9             	fxch   st(1)
    12c1:	9b                   	fwait
    12c2:	8a 66 fd             	mov    ah,BYTE PTR [bp-0x3]
    12c5:	9e                   	sahf
    12c6:	93                   	xchg   bx,ax
    12c7:	72 10                	jb     0x12d9
    12c9:	75 29                	jne    0x12f4
    12cb:	9b dd d8             	fstp   st(0)
    12ce:	e3 03                	jcxz   0x12d3
    12d0:	9b dd d8             	fstp   st(0)
    12d3:	9b d9 e8             	fld1
    12d6:	e9 a8 00             	jmp    0x1381
    12d9:	e3 03                	jcxz   0x12de
    12db:	9b dd d8             	fstp   st(0)
    12de:	74 0e                	je     0x12ee
    12e0:	7b 0c                	jnp    0x12ee
    12e2:	9b dd d8             	fstp   st(0)
    12e5:	9b 2e d9 06 b9 10    	fld    DWORD PTR cs:0x10b9
    12eb:	e9 88 00             	jmp    0x1376
    12ee:	9b d9 e4             	ftst
    12f1:	e9 8d 00             	jmp    0x1381
    12f4:	e3 03                	jcxz   0x12f9
    12f6:	9b de c9             	fmulp  st(1),st
    12f9:	9b d9 e1             	fabs
    12fc:	9b 2e d8 16 ab 10    	fcom   DWORD PTR cs:0x10ab
    1302:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    1306:	9b                   	fwait
    1307:	f6 46 fd 41          	test   BYTE PTR [bp-0x3],0x41
    130b:	74 0b                	je     0x1318
    130d:	9b d9 f0             	f2xm1
    1310:	9b d9 e8             	fld1
    1313:	9b de c1             	faddp  st(1),st
    1316:	eb 5e                	jmp    0x1376
    1318:	9b d9 e8             	fld1
    131b:	9b d9 c1             	fld    st(1)
    131e:	9b d9 7e fc          	fstcw  WORD PTR [bp-0x4]
    1322:	9b d9 fd             	fscale
    1325:	80 4e fd 0f          	or     BYTE PTR [bp-0x3],0xf
    1329:	90                   	nop
    132a:	9b 9b d9 6e fc       	fldcw  WORD PTR [bp-0x4]
    132f:	9b d9 fc             	frndint
    1332:	80 66 fd f3          	and    BYTE PTR [bp-0x3],0xf3
    1336:	90                   	nop
    1337:	9b 9b d9 6e fc       	fldcw  WORD PTR [bp-0x4]
    133c:	9b df 56 fe          	fist   WORD PTR [bp-0x2]
    1340:	9b d9 c9             	fxch   st(1)
    1343:	9b d9 e0             	fchs
    1346:	9b d9 c9             	fxch   st(1)
    1349:	9b d9 fd             	fscale
    134c:	9b dd d9             	fstp   st(1)
    134f:	9b de e9             	fsubp  st(1),st
    1352:	9b d9 f0             	f2xm1
    1355:	9b d9 e8             	fld1
    1358:	9b de c1             	faddp  st(1),st
    135b:	d1 6e fe             	shr    WORD PTR [bp-0x2],1
    135e:	73 09                	jae    0x1369
    1360:	9b 2e db 2e af 10    	fld    TBYTE PTR cs:0x10af
    1366:	9b de c9             	fmulp  st(1),st
    1369:	9b df 46 fe          	fild   WORD PTR [bp-0x2]
    136d:	9b d9 c9             	fxch   st(1)
    1370:	9b d9 fd             	fscale
    1373:	9b dd d9             	fstp   st(1)
    1376:	f6 c7 02             	test   bh,0x2
    1379:	74 06                	je     0x1381
    137b:	9b d9 e8             	fld1
    137e:	9b de f1             	fdivrp st(1),st
    1381:	8b e5                	mov    sp,bp
    1383:	5d                   	pop    bp
    1384:	c3                   	ret
    1385:	8b 2e 58 18          	mov    bp,WORD PTR ds:0x1858
    1389:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    138c:	a3 58 18             	mov    ds:0x1858,ax
    138f:	8b 26 5a 18          	mov    sp,WORD PTR ds:0x185a
    1393:	8f 06 5a 18          	pop    WORD PTR ds:0x185a
    1397:	eb 03                	jmp    0x139c
    1399:	e8 0a 01             	call   0x14a6
    139c:	1e                   	push   ds
    139d:	8b 2e 58 18          	mov    bp,WORD PTR ds:0x1858
    13a1:	eb 3a                	jmp    0x13dd
    13a3:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    13a6:	26 8b 0d             	mov    cx,WORD PTR es:[di]
    13a9:	e3 4d                	jcxz   0x13f8
    13ab:	47                   	inc    di
    13ac:	47                   	inc    di
    13ad:	26 8b 05             	mov    ax,WORD PTR es:[di]
    13b0:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    13b4:	8b d8                	mov    bx,ax
    13b6:	0b da                	or     bx,dx
    13b8:	74 51                	je     0x140b
    13ba:	8b f4                	mov    si,sp
    13bc:	36 c5 74 06          	lds    si,DWORD PTR ss:[si+0x6]
    13c0:	c5 34                	lds    si,DWORD PTR [si]
    13c2:	3b f0                	cmp    si,ax
    13c4:	75 06                	jne    0x13cc
    13c6:	8c db                	mov    bx,ds
    13c8:	3b da                	cmp    bx,dx
    13ca:	74 3f                	je     0x140b
    13cc:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    13cf:	8c db                	mov    bx,ds
    13d1:	0b de                	or     bx,si
    13d3:	75 ed                	jne    0x13c2
    13d5:	83 c7 08             	add    di,0x8
    13d8:	e2 d3                	loop   0x13ad
    13da:	8b 6e 00             	mov    bp,WORD PTR [bp+0x0]
    13dd:	0b ed                	or     bp,bp
    13df:	75 c2                	jne    0x13a3
    13e1:	1f                   	pop    ds
    13e2:	a1 5c 18             	mov    ax,ds:0x185c
    13e5:	0b 06 5e 18          	or     ax,WORD PTR ds:0x185e
    13e9:	74 07                	je     0x13f2
    13eb:	e8 b1 01             	call   0x159f
    13ee:	ff 1e 5c 18          	call   DWORD PTR ds:0x185c
    13f2:	b8 d9 00             	mov    ax,0xd9
    13f5:	e9 97 ec             	jmp    0x8f
    13f8:	1f                   	pop    ds
    13f9:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    13fc:	a3 58 18             	mov    ds:0x1858,ax
    13ff:	8b 6e 02             	mov    bp,WORD PTR [bp+0x2]
    1402:	e8 0f 01             	call   0x1514
    1405:	26 ff 5d 02          	call   DWORD PTR es:[di+0x2]
    1409:	eb 91                	jmp    0x139c
    140b:	1f                   	pop    ds
    140c:	59                   	pop    cx
    140d:	5b                   	pop    bx
    140e:	58                   	pop    ax
    140f:	5a                   	pop    dx
    1410:	8b e5                	mov    sp,bp
    1412:	89 2e 58 18          	mov    WORD PTR ds:0x1858,bp
    1416:	c7 46 04 4a 14       	mov    WORD PTR [bp+0x4],0x144a
    141b:	8c 4e 06             	mov    WORD PTR [bp+0x6],cs
    141e:	8b 6e 02             	mov    bp,WORD PTR [bp+0x2]
    1421:	52                   	push   dx
    1422:	50                   	push   ax
    1423:	53                   	push   bx
    1424:	51                   	push   cx
    1425:	ff 36 5a 18          	push   WORD PTR ds:0x185a
    1429:	89 26 5a 18          	mov    WORD PTR ds:0x185a,sp
    142d:	e8 0f 01             	call   0x153f
    1430:	26 ff 6d 04          	jmp    DWORD PTR es:[di+0x4]
    1434:	e8 39 01             	call   0x1570
    1437:	55                   	push   bp
    1438:	0e                   	push   cs
    1439:	e8 14 00             	call   0x1450
    143c:	8b 2e 58 18          	mov    bp,WORD PTR ds:0x1858
    1440:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    1443:	a3 58 18             	mov    ds:0x1858,ax
    1446:	5d                   	pop    bp
    1447:	ca 12 00             	retf   0x12
    144a:	00 00                	add    BYTE PTR [bx+si],al
    144c:	50                   	push   ax
    144d:	14 79                	adc    al,0x79
    144f:	1b 8b 2e 5a          	sbb    cx,WORD PTR [bp+di+0x5a2e]
    1453:	18 b0 01 50          	sbb    BYTE PTR [bx+si+0x5001],dh
    1457:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    145a:	06                   	push   es
    145b:	57                   	push   di
    145c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    145f:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    1463:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    1466:	a3 5a 18             	mov    ds:0x185a,ax
    1469:	cb                   	retf
    146a:	8b dc                	mov    bx,sp
    146c:	36 8b 47 04          	mov    ax,WORD PTR ss:[bx+0x4]
    1470:	a3 58 18             	mov    ds:0x1858,ax
    1473:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1477:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    147b:	75 24                	jne    0x14a1
    147d:	83 3e c0 2e 00       	cmp    WORD PTR ds:0x2ec0,0x0
    1482:	74 19                	je     0x149d
    1484:	c7 06 c4 2e 03 00    	mov    WORD PTR ds:0x2ec4,0x3
    148a:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    148e:	8f 06 c6 2e          	pop    WORD PTR ds:0x2ec6
    1492:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1496:	8f 06 c8 2e          	pop    WORD PTR ds:0x2ec8
    149a:	e8 07 00             	call   0x14a4
    149d:	26 ff 5d 02          	call   DWORD PTR es:[di+0x2]
    14a1:	ca 08 00             	retf   0x8
    14a4:	90                   	nop
    14a5:	c3                   	ret
    14a6:	83 3e c0 2e 00       	cmp    WORD PTR ds:0x2ec0,0x0
    14ab:	74 66                	je     0x1513
    14ad:	8b dc                	mov    bx,sp
    14af:	be 06 00             	mov    si,0x6
    14b2:	e8 15 01             	call   0x15ca
    14b5:	75 5c                	jne    0x1513
    14b7:	55                   	push   bp
    14b8:	8b ec                	mov    bp,sp
    14ba:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    14bd:	a3 c6 2e             	mov    ds:0x2ec6,ax
    14c0:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    14c3:	a3 c8 2e             	mov    ds:0x2ec8,ax
    14c6:	33 c0                	xor    ax,ax
    14c8:	a3 ce 2e             	mov    ds:0x2ece,ax
    14cb:	a3 d6 2e             	mov    ds:0x2ed6,ax
    14ce:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    14d1:	8c c0                	mov    ax,es
    14d3:	0b c7                	or     ax,di
    14d5:	74 3c                	je     0x1513
    14d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14da:	26 8b 7d e8          	mov    di,WORD PTR es:[di-0x18]
    14de:	26 8a 05             	mov    al,BYTE PTR es:[di]
    14e1:	47                   	inc    di
    14e2:	a2 ce 2e             	mov    ds:0x2ece,al
    14e5:	89 3e d2 2e          	mov    WORD PTR ds:0x2ed2,di
    14e9:	8c 06 d4 2e          	mov    WORD PTR ds:0x2ed4,es
    14ed:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    14f0:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    14f4:	8c c0                	mov    ax,es
    14f6:	0b c7                	or     ax,di
    14f8:	74 0f                	je     0x1509
    14fa:	26 8a 05             	mov    al,BYTE PTR es:[di]
    14fd:	47                   	inc    di
    14fe:	a2 d6 2e             	mov    ds:0x2ed6,al
    1501:	89 3e da 2e          	mov    WORD PTR ds:0x2eda,di
    1505:	8c 06 dc 2e          	mov    WORD PTR ds:0x2edc,es
    1509:	c7 06 c4 2e 01 00    	mov    WORD PTR ds:0x2ec4,0x1
    150f:	5d                   	pop    bp
    1510:	e8 91 ff             	call   0x14a4
    1513:	c3                   	ret
    1514:	83 3e c0 2e 00       	cmp    WORD PTR ds:0x2ec0,0x0
    1519:	74 23                	je     0x153e
    151b:	8b dc                	mov    bx,sp
    151d:	be 06 00             	mov    si,0x6
    1520:	e8 a7 00             	call   0x15ca
    1523:	75 19                	jne    0x153e
    1525:	c7 06 c4 2e 03 00    	mov    WORD PTR ds:0x2ec4,0x3
    152b:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    152f:	8f 06 c6 2e          	pop    WORD PTR ds:0x2ec6
    1533:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1537:	8f 06 c8 2e          	pop    WORD PTR ds:0x2ec8
    153b:	e8 66 ff             	call   0x14a4
    153e:	c3                   	ret
    153f:	83 3e c0 2e 00       	cmp    WORD PTR ds:0x2ec0,0x0
    1544:	74 29                	je     0x156f
    1546:	8b 1e 5a 18          	mov    bx,WORD PTR ds:0x185a
    154a:	be 06 00             	mov    si,0x6
    154d:	52                   	push   dx
    154e:	50                   	push   ax
    154f:	e8 78 00             	call   0x15ca
    1552:	58                   	pop    ax
    1553:	5a                   	pop    dx
    1554:	75 19                	jne    0x156f
    1556:	c7 06 c4 2e 02 00    	mov    WORD PTR ds:0x2ec4,0x2
    155c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1560:	8f 06 c6 2e          	pop    WORD PTR ds:0x2ec6
    1564:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1568:	8f 06 c8 2e          	pop    WORD PTR ds:0x2ec8
    156c:	e8 35 ff             	call   0x14a4
    156f:	c3                   	ret
    1570:	83 3e c0 2e 00       	cmp    WORD PTR ds:0x2ec0,0x0
    1575:	74 27                	je     0x159e
    1577:	8b 1e 5a 18          	mov    bx,WORD PTR ds:0x185a
    157b:	be 06 00             	mov    si,0x6
    157e:	e8 49 00             	call   0x15ca
    1581:	75 1b                	jne    0x159e
    1583:	c7 06 c4 2e 05 00    	mov    WORD PTR ds:0x2ec4,0x5
    1589:	5b                   	pop    bx
    158a:	8f 06 c6 2e          	pop    WORD PTR ds:0x2ec6
    158e:	8f 06 c8 2e          	pop    WORD PTR ds:0x2ec8
    1592:	ff 36 c8 2e          	push   WORD PTR ds:0x2ec8
    1596:	ff 36 c6 2e          	push   WORD PTR ds:0x2ec6
    159a:	53                   	push   bx
    159b:	e8 06 ff             	call   0x14a4
    159e:	c3                   	ret
    159f:	83 3e c0 2e 00       	cmp    WORD PTR ds:0x2ec0,0x0
    15a4:	74 23                	je     0x15c9
    15a6:	8b dc                	mov    bx,sp
    15a8:	be 06 00             	mov    si,0x6
    15ab:	e8 1c 00             	call   0x15ca
    15ae:	75 19                	jne    0x15c9
    15b0:	c7 06 c4 2e 04 00    	mov    WORD PTR ds:0x2ec4,0x4
    15b6:	ff 36 5c 18          	push   WORD PTR ds:0x185c
    15ba:	8f 06 c6 2e          	pop    WORD PTR ds:0x2ec6
    15be:	ff 36 5e 18          	push   WORD PTR ds:0x185e
    15c2:	8f 06 c8 2e          	pop    WORD PTR ds:0x2ec8
    15c6:	e8 db fe             	call   0x14a4
    15c9:	c3                   	ret
    15ca:	36 8b 00             	mov    ax,WORD PTR ss:[bx+si]
    15cd:	36 0b 40 02          	or     ax,WORD PTR ss:[bx+si+0x2]
    15d1:	74 13                	je     0x15e6
    15d3:	06                   	push   es
    15d4:	57                   	push   di
    15d5:	36 c4 38             	les    di,DWORD PTR ss:[bx+si]
    15d8:	8b 0e 64 18          	mov    cx,WORD PTR ds:0x1864
    15dc:	8b 1e 66 18          	mov    bx,WORD PTR ds:0x1866
    15e0:	e8 b6 0c             	call   0x2299
    15e3:	5f                   	pop    di
    15e4:	07                   	pop    es
    15e5:	c3                   	ret
    15e6:	83 cb 01             	or     bx,0x1
    15e9:	c3                   	ret
    15ea:	c7 06 24 00 b0 2e    	mov    WORD PTR ds:0x24,0x2eb0
    15f0:	8c 1e 26 00          	mov    WORD PTR ds:0x26,ds
    15f4:	c7 06 bc 2e a4 14    	mov    WORD PTR ds:0x2ebc,0x14a4
    15fa:	8c 0e be 2e          	mov    WORD PTR ds:0x2ebe,cs
    15fe:	c7 06 e2 2e 34 14    	mov    WORD PTR ds:0x2ee2,0x1434
    1604:	8c 0e e4 2e          	mov    WORD PTR ds:0x2ee4,cs
    1608:	a1 68 18             	mov    ax,ds:0x1868
    160b:	0b 06 6a 18          	or     ax,WORD PTR ds:0x186a
    160f:	74 09                	je     0x161a
    1611:	b8 b0 2e             	mov    ax,0x2eb0
    1614:	8c da                	mov    dx,ds
    1616:	ff 1e 68 18          	call   DWORD PTR ds:0x1868
    161a:	c3                   	ret
    161b:	8b dc                	mov    bx,sp
    161d:	8c da                	mov    dx,ds
    161f:	36 c5 77 0a          	lds    si,DWORD PTR ss:[bx+0xa]
    1623:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    1627:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    162b:	fc                   	cld
    162c:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    162e:	8e da                	mov    ds,dx
    1630:	ca 0a 00             	retf   0xa
    1633:	80 3e 88 18 02       	cmp    BYTE PTR ds:0x1888,0x2
    1638:	72 1b                	jb     0x1655
    163a:	66 c1 e0 10          	shl    eax,0x10
    163e:	66 0f ac d0 10       	shrd   eax,edx,0x10
    1643:	66 c1 e1 10          	shl    ecx,0x10
    1647:	66 0f ac d9 10       	shrd   ecx,ebx,0x10
    164c:	66 f7 e9             	imul   ecx
    164f:	66 0f a4 c2 10       	shld   edx,eax,0x10
    1654:	cb                   	retf
    1655:	8b f0                	mov    si,ax
    1657:	8b fa                	mov    di,dx
    1659:	f7 e1                	mul    cx
    165b:	50                   	push   ax
    165c:	52                   	push   dx
    165d:	8b c6                	mov    ax,si
    165f:	f7 e3                	mul    bx
    1661:	8b d8                	mov    bx,ax
    1663:	8b c7                	mov    ax,di
    1665:	f7 e1                	mul    cx
    1667:	8b c8                	mov    cx,ax
    1669:	5a                   	pop    dx
    166a:	58                   	pop    ax
    166b:	03 d3                	add    dx,bx
    166d:	03 d1                	add    dx,cx
    166f:	cb                   	retf
    1670:	80 3e 88 18 02       	cmp    BYTE PTR ds:0x1888,0x2
    1675:	72 27                	jb     0x169e
    1677:	66 c1 e0 10          	shl    eax,0x10
    167b:	66 0f ac d0 10       	shrd   eax,edx,0x10
    1680:	66 c1 e1 10          	shl    ecx,0x10
    1684:	66 0f ac d9 10       	shrd   ecx,ebx,0x10
    1689:	74 5e                	je     0x16e9
    168b:	66 99                	cdq
    168d:	66 f7 f9             	idiv   ecx
    1690:	66 8b ca             	mov    ecx,edx
    1693:	66 0f a4 c2 10       	shld   edx,eax,0x10
    1698:	66 0f a4 cb 10       	shld   ebx,ecx,0x10
    169d:	cb                   	retf
    169e:	55                   	push   bp
    169f:	33 ed                	xor    bp,bp
    16a1:	0b d2                	or     dx,dx
    16a3:	79 08                	jns    0x16ad
    16a5:	45                   	inc    bp
    16a6:	f7 d8                	neg    ax
    16a8:	83 d2 00             	adc    dx,0x0
    16ab:	f7 da                	neg    dx
    16ad:	0b db                	or     bx,bx
    16af:	74 3e                	je     0x16ef
    16b1:	79 0b                	jns    0x16be
    16b3:	45                   	inc    bp
    16b4:	45                   	inc    bp
    16b5:	f7 d9                	neg    cx
    16b7:	83 d3 00             	adc    bx,0x0
    16ba:	f7 db                	neg    bx
    16bc:	74 33                	je     0x16f1
    16be:	55                   	push   bp
    16bf:	8b f1                	mov    si,cx
    16c1:	8b fb                	mov    di,bx
    16c3:	33 db                	xor    bx,bx
    16c5:	8b ca                	mov    cx,dx
    16c7:	8b d0                	mov    dx,ax
    16c9:	33 c0                	xor    ax,ax
    16cb:	bd 10 00             	mov    bp,0x10
    16ce:	d1 e0                	shl    ax,1
    16d0:	d1 d2                	rcl    dx,1
    16d2:	d1 d1                	rcl    cx,1
    16d4:	d1 d3                	rcl    bx,1
    16d6:	40                   	inc    ax
    16d7:	2b ce                	sub    cx,si
    16d9:	1b df                	sbb    bx,di
    16db:	73 05                	jae    0x16e2
    16dd:	48                   	dec    ax
    16de:	03 ce                	add    cx,si
    16e0:	13 df                	adc    bx,di
    16e2:	4d                   	dec    bp
    16e3:	75 e9                	jne    0x16ce
    16e5:	5d                   	pop    bp
    16e6:	eb 16                	jmp    0x16fe
    16e8:	5d                   	pop    bp
    16e9:	b8 03 00             	mov    ax,0x3
    16ec:	e9 71 e9             	jmp    0x60
    16ef:	e3 f7                	jcxz   0x16e8
    16f1:	93                   	xchg   bx,ax
    16f2:	92                   	xchg   dx,ax
    16f3:	f7 f1                	div    cx
    16f5:	93                   	xchg   bx,ax
    16f6:	f7 f1                	div    cx
    16f8:	8b ca                	mov    cx,dx
    16fa:	8b d3                	mov    dx,bx
    16fc:	33 db                	xor    bx,bx
    16fe:	d1 ed                	shr    bp,1
    1700:	73 08                	jae    0x170a
    1702:	f7 d9                	neg    cx
    1704:	83 d3 00             	adc    bx,0x0
    1707:	f7 db                	neg    bx
    1709:	45                   	inc    bp
    170a:	4d                   	dec    bp
    170b:	75 07                	jne    0x1714
    170d:	f7 d8                	neg    ax
    170f:	83 d2 00             	adc    dx,0x0
    1712:	f7 da                	neg    dx
    1714:	5d                   	pop    bp
    1715:	cb                   	retf
    1716:	80 3e 88 18 02       	cmp    BYTE PTR ds:0x1888,0x2
    171b:	72 10                	jb     0x172d
    171d:	66 c1 e2 10          	shl    edx,0x10
    1721:	8b d0                	mov    dx,ax
    1723:	66 d3 ea             	shr    edx,cl
    1726:	8b c2                	mov    ax,dx
    1728:	66 c1 ea 10          	shr    edx,0x10
    172c:	cb                   	retf
    172d:	83 e1 1f             	and    cx,0x1f
    1730:	74 06                	je     0x1738
    1732:	d1 ea                	shr    dx,1
    1734:	d1 d8                	rcr    ax,1
    1736:	e2 fa                	loop   0x1732
    1738:	cb                   	retf
    1739:	80 3e 88 18 02       	cmp    BYTE PTR ds:0x1888,0x2
    173e:	72 10                	jb     0x1750
    1740:	66 c1 e2 10          	shl    edx,0x10
    1744:	8b d0                	mov    dx,ax
    1746:	66 d3 e2             	shl    edx,cl
    1749:	8b c2                	mov    ax,dx
    174b:	66 c1 ea 10          	shr    edx,0x10
    174f:	cb                   	retf
    1750:	83 e1 1f             	and    cx,0x1f
    1753:	74 06                	je     0x175b
    1755:	d1 e0                	shl    ax,1
    1757:	d1 d2                	rcl    dx,1
    1759:	e2 fa                	loop   0x1755
    175b:	cb                   	retf
    175c:	80 3e 88 18 02       	cmp    BYTE PTR ds:0x1888,0x2
    1761:	72 1f                	jb     0x1782
    1763:	66 c1 e0 10          	shl    eax,0x10
    1767:	66 0f ac d0 10       	shrd   eax,edx,0x10
    176c:	66 c1 e1 10          	shl    ecx,0x10
    1770:	66 0f ac d9 10       	shrd   ecx,ebx,0x10
    1775:	66 f7 e9             	imul   ecx
    1778:	72 50                	jb     0x17ca
    177a:	90                   	nop
    177b:	90                   	nop
    177c:	66 0f a4 c2 10       	shld   edx,eax,0x10
    1781:	cb                   	retf
    1782:	8b f2                	mov    si,dx
    1784:	33 f3                	xor    si,bx
    1786:	0b d2                	or     dx,dx
    1788:	79 07                	jns    0x1791
    178a:	f7 d8                	neg    ax
    178c:	83 d2 00             	adc    dx,0x0
    178f:	f7 da                	neg    dx
    1791:	0b db                	or     bx,bx
    1793:	79 07                	jns    0x179c
    1795:	f7 d9                	neg    cx
    1797:	83 d3 00             	adc    bx,0x0
    179a:	f7 db                	neg    bx
    179c:	0b d2                	or     dx,dx
    179e:	74 07                	je     0x17a7
    17a0:	91                   	xchg   cx,ax
    17a1:	87 d3                	xchg   bx,dx
    17a3:	0b d2                	or     dx,dx
    17a5:	75 23                	jne    0x17ca
    17a7:	8b f8                	mov    di,ax
    17a9:	f7 e3                	mul    bx
    17ab:	72 1d                	jb     0x17ca
    17ad:	97                   	xchg   di,ax
    17ae:	f7 e1                	mul    cx
    17b0:	03 d7                	add    dx,di
    17b2:	72 16                	jb     0x17ca
    17b4:	8b c8                	mov    cx,ax
    17b6:	0b ca                	or     cx,dx
    17b8:	74 0f                	je     0x17c9
    17ba:	0b f6                	or     si,si
    17bc:	79 07                	jns    0x17c5
    17be:	f7 d8                	neg    ax
    17c0:	83 d2 00             	adc    dx,0x0
    17c3:	f7 da                	neg    dx
    17c5:	33 f2                	xor    si,dx
    17c7:	78 01                	js     0x17ca
    17c9:	cb                   	retf
    17ca:	e9 71 ec             	jmp    0x43e
    17cd:	fc                   	cld
    17ce:	8b dc                	mov    bx,sp
    17d0:	8c da                	mov    dx,ds
    17d2:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    17d6:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    17da:	ac                   	lods   al,BYTE PTR ds:[si]
    17db:	aa                   	stos   BYTE PTR es:[di],al
    17dc:	8a c8                	mov    cl,al
    17de:	32 ed                	xor    ch,ch
    17e0:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    17e2:	8e da                	mov    ds,dx
    17e4:	ca 04 00             	retf   0x4
    17e7:	fc                   	cld
    17e8:	8b dc                	mov    bx,sp
    17ea:	8c da                	mov    dx,ds
    17ec:	36 c5 77 0a          	lds    si,DWORD PTR ss:[bx+0xa]
    17f0:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    17f4:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    17f8:	ac                   	lods   al,BYTE PTR ds:[si]
    17f9:	3a c1                	cmp    al,cl
    17fb:	76 02                	jbe    0x17ff
    17fd:	8a c1                	mov    al,cl
    17ff:	aa                   	stos   BYTE PTR es:[di],al
    1800:	8a c8                	mov    cl,al
    1802:	32 ed                	xor    ch,ch
    1804:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1806:	8e da                	mov    ds,dx
    1808:	ca 0a 00             	retf   0xa
    180b:	fc                   	cld
    180c:	8b dc                	mov    bx,sp
    180e:	8c da                	mov    dx,ds
    1810:	36 c4 7f 0c          	les    di,DWORD PTR ss:[bx+0xc]
    1814:	36 c5 77 08          	lds    si,DWORD PTR ss:[bx+0x8]
    1818:	8a 04                	mov    al,BYTE PTR [si]
    181a:	32 e4                	xor    ah,ah
    181c:	36 8b 4f 06          	mov    cx,WORD PTR ss:[bx+0x6]
    1820:	0b c9                	or     cx,cx
    1822:	7f 03                	jg     0x1827
    1824:	b9 01 00             	mov    cx,0x1
    1827:	03 f1                	add    si,cx
    1829:	2b c1                	sub    ax,cx
    182b:	72 13                	jb     0x1840
    182d:	40                   	inc    ax
    182e:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    1832:	0b c9                	or     cx,cx
    1834:	7d 02                	jge    0x1838
    1836:	33 c9                	xor    cx,cx
    1838:	3b c1                	cmp    ax,cx
    183a:	76 06                	jbe    0x1842
    183c:	8b c1                	mov    ax,cx
    183e:	eb 02                	jmp    0x1842
    1840:	33 c0                	xor    ax,ax
    1842:	aa                   	stos   BYTE PTR es:[di],al
    1843:	8b c8                	mov    cx,ax
    1845:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1847:	8e da                	mov    ds,dx
    1849:	ca 08 00             	retf   0x8
    184c:	fc                   	cld
    184d:	8b dc                	mov    bx,sp
    184f:	8c da                	mov    dx,ds
    1851:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1855:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    1859:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
    185c:	32 ed                	xor    ch,ch
    185e:	ac                   	lods   al,BYTE PTR ds:[si]
    185f:	26 00 05             	add    BYTE PTR es:[di],al
    1862:	73 08                	jae    0x186c
    1864:	26 c6 05 ff          	mov    BYTE PTR es:[di],0xff
    1868:	8a c1                	mov    al,cl
    186a:	f6 d0                	not    al
    186c:	03 f9                	add    di,cx
    186e:	47                   	inc    di
    186f:	8a c8                	mov    cl,al
    1871:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1873:	8e da                	mov    ds,dx
    1875:	ca 04 00             	retf   0x4
    1878:	55                   	push   bp
    1879:	8b ec                	mov    bp,sp
    187b:	1e                   	push   ds
    187c:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    187f:	fc                   	cld
    1880:	ac                   	lods   al,BYTE PTR ds:[si]
    1881:	0a c0                	or     al,al
    1883:	74 2c                	je     0x18b1
    1885:	8a d0                	mov    dl,al
    1887:	32 f6                	xor    dh,dh
    1889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    188c:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
    188f:	32 ed                	xor    ch,ch
    1891:	2b ca                	sub    cx,dx
    1893:	72 1c                	jb     0x18b1
    1895:	41                   	inc    cx
    1896:	47                   	inc    di
    1897:	ac                   	lods   al,BYTE PTR ds:[si]
    1898:	f2 ae                	repnz scas al,BYTE PTR es:[di]
    189a:	75 15                	jne    0x18b1
    189c:	8b c7                	mov    ax,di
    189e:	8b d9                	mov    bx,cx
    18a0:	8b ca                	mov    cx,dx
    18a2:	49                   	dec    cx
    18a3:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    18a5:	74 0e                	je     0x18b5
    18a7:	8b f8                	mov    di,ax
    18a9:	8b cb                	mov    cx,bx
    18ab:	8b 76 0a             	mov    si,WORD PTR [bp+0xa]
    18ae:	46                   	inc    si
    18af:	eb e6                	jmp    0x1897
    18b1:	33 c0                	xor    ax,ax
    18b3:	eb 04                	jmp    0x18b9
    18b5:	48                   	dec    ax
    18b6:	2b 46 06             	sub    ax,WORD PTR [bp+0x6]
    18b9:	1f                   	pop    ds
    18ba:	5d                   	pop    bp
    18bb:	ca 08 00             	retf   0x8
    18be:	fc                   	cld
    18bf:	8b dc                	mov    bx,sp
    18c1:	8c da                	mov    dx,ds
    18c3:	36 c5 77 08          	lds    si,DWORD PTR ss:[bx+0x8]
    18c7:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    18cb:	ac                   	lods   al,BYTE PTR ds:[si]
    18cc:	26 8a 25             	mov    ah,BYTE PTR es:[di]
    18cf:	47                   	inc    di
    18d0:	8a c8                	mov    cl,al
    18d2:	3a cc                	cmp    cl,ah
    18d4:	76 02                	jbe    0x18d8
    18d6:	8a cc                	mov    cl,ah
    18d8:	0a c9                	or     cl,cl
    18da:	74 06                	je     0x18e2
    18dc:	32 ed                	xor    ch,ch
    18de:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    18e0:	75 02                	jne    0x18e4
    18e2:	3a c4                	cmp    al,ah
    18e4:	8e da                	mov    ds,dx
    18e6:	ca 08 00             	retf   0x8
    18e9:	fc                   	cld
    18ea:	8b dc                	mov    bx,sp
    18ec:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    18f0:	b0 01                	mov    al,0x1
    18f2:	aa                   	stos   BYTE PTR es:[di],al
    18f3:	36 8a 47 04          	mov    al,BYTE PTR ss:[bx+0x4]
    18f7:	aa                   	stos   BYTE PTR es:[di],al
    18f8:	ca 02 00             	retf   0x2
    18fb:	fc                   	cld
    18fc:	8b dc                	mov    bx,sp
    18fe:	8c da                	mov    dx,ds
    1900:	36 c4 7f 0a          	les    di,DWORD PTR ss:[bx+0xa]
    1904:	36 c5 77 06          	lds    si,DWORD PTR ss:[bx+0x6]
    1908:	36 8b 47 04          	mov    ax,WORD PTR ss:[bx+0x4]
    190c:	aa                   	stos   BYTE PTR es:[di],al
    190d:	8b c8                	mov    cx,ax
    190f:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1911:	8e da                	mov    ds,dx
    1913:	ca 06 00             	retf   0x6
    1916:	55                   	push   bp
    1917:	8b ec                	mov    bp,sp
    1919:	81 ec 00 02          	sub    sp,0x200
    191d:	83 7e 06 01          	cmp    WORD PTR [bp+0x6],0x1
    1921:	7d 05                	jge    0x1928
    1923:	c7 46 06 01 00       	mov    WORD PTR [bp+0x6],0x1
    1928:	8d be 00 ff          	lea    di,[bp-0x100]
    192c:	16                   	push   ss
    192d:	57                   	push   di
    192e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1931:	06                   	push   es
    1932:	57                   	push   di
    1933:	b8 01 00             	mov    ax,0x1
    1936:	50                   	push   ax
    1937:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    193a:	48                   	dec    ax
    193b:	50                   	push   ax
    193c:	0e                   	push   cs
    193d:	e8 cb fe             	call   0x180b
    1940:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1943:	06                   	push   es
    1944:	57                   	push   di
    1945:	0e                   	push   cs
    1946:	e8 03 ff             	call   0x184c
    1949:	8d be 00 fe          	lea    di,[bp-0x200]
    194d:	16                   	push   ss
    194e:	57                   	push   di
    194f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1952:	06                   	push   es
    1953:	57                   	push   di
    1954:	ff 76 06             	push   WORD PTR [bp+0x6]
    1957:	b8 ff 00             	mov    ax,0xff
    195a:	50                   	push   ax
    195b:	0e                   	push   cs
    195c:	e8 ac fe             	call   0x180b
    195f:	0e                   	push   cs
    1960:	e8 e9 fe             	call   0x184c
    1963:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1966:	06                   	push   es
    1967:	57                   	push   di
    1968:	ff 76 08             	push   WORD PTR [bp+0x8]
    196b:	0e                   	push   cs
    196c:	e8 78 fe             	call   0x17e7
    196f:	8b e5                	mov    sp,bp
    1971:	5d                   	pop    bp
    1972:	ca 0c 00             	retf   0xc
    1975:	55                   	push   bp
    1976:	8b ec                	mov    bp,sp
    1978:	81 ec 00 02          	sub    sp,0x200
    197c:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    1980:	7e 5c                	jle    0x19de
    1982:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    1986:	7e 56                	jle    0x19de
    1988:	81 7e 08 ff 00       	cmp    WORD PTR [bp+0x8],0xff
    198d:	7f 4f                	jg     0x19de
    198f:	81 7e 06 ff 00       	cmp    WORD PTR [bp+0x6],0xff
    1994:	7e 05                	jle    0x199b
    1996:	c7 46 06 ff 00       	mov    WORD PTR [bp+0x6],0xff
    199b:	8d be 00 ff          	lea    di,[bp-0x100]
    199f:	16                   	push   ss
    19a0:	57                   	push   di
    19a1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19a4:	06                   	push   es
    19a5:	57                   	push   di
    19a6:	b8 01 00             	mov    ax,0x1
    19a9:	50                   	push   ax
    19aa:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    19ad:	48                   	dec    ax
    19ae:	50                   	push   ax
    19af:	0e                   	push   cs
    19b0:	e8 58 fe             	call   0x180b
    19b3:	8d be 00 fe          	lea    di,[bp-0x200]
    19b7:	16                   	push   ss
    19b8:	57                   	push   di
    19b9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19bc:	06                   	push   es
    19bd:	57                   	push   di
    19be:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    19c1:	03 46 06             	add    ax,WORD PTR [bp+0x6]
    19c4:	50                   	push   ax
    19c5:	b8 ff 00             	mov    ax,0xff
    19c8:	50                   	push   ax
    19c9:	0e                   	push   cs
    19ca:	e8 3e fe             	call   0x180b
    19cd:	0e                   	push   cs
    19ce:	e8 7b fe             	call   0x184c
    19d1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19d4:	06                   	push   es
    19d5:	57                   	push   di
    19d6:	b8 ff 00             	mov    ax,0xff
    19d9:	50                   	push   ax
    19da:	0e                   	push   cs
    19db:	e8 09 fe             	call   0x17e7
    19de:	8b e5                	mov    sp,bp
    19e0:	5d                   	pop    bp
    19e1:	ca 08 00             	retf   0x8
    19e4:	fc                   	cld
    19e5:	8b dc                	mov    bx,sp
    19e7:	8c da                	mov    dx,ds
    19e9:	36 c4 7f 0a          	les    di,DWORD PTR ss:[bx+0xa]
    19ed:	36 c5 77 06          	lds    si,DWORD PTR ss:[bx+0x6]
    19f1:	36 8b 5f 04          	mov    bx,WORD PTR ss:[bx+0x4]
    19f5:	8a cf                	mov    cl,bh
    19f7:	32 ed                	xor    ch,ch
    19f9:	32 c0                	xor    al,al
    19fb:	f3 aa                	rep stos BYTE PTR es:[di],al
    19fd:	8a cb                	mov    cl,bl
    19ff:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1a01:	b1 20                	mov    cl,0x20
    1a03:	2a cb                	sub    cl,bl
    1a05:	2a cf                	sub    cl,bh
    1a07:	f3 aa                	rep stos BYTE PTR es:[di],al
    1a09:	8e da                	mov    ds,dx
    1a0b:	ca 06 00             	retf   0x6
    1a0e:	fc                   	cld
    1a0f:	8b dc                	mov    bx,sp
    1a11:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    1a15:	36 8b 47 04          	mov    ax,WORD PTR ss:[bx+0x4]
    1a19:	ab                   	stos   WORD PTR es:[di],ax
    1a1a:	b9 0f 00             	mov    cx,0xf
    1a1d:	33 c0                	xor    ax,ax
    1a1f:	f3 ab                	rep stos WORD PTR es:[di],ax
    1a21:	ca 02 00             	retf   0x2
    1a24:	8b dc                	mov    bx,sp
    1a26:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    1a2a:	36 8a 47 04          	mov    al,BYTE PTR ss:[bx+0x4]
    1a2e:	8a d8                	mov    bl,al
    1a30:	32 ff                	xor    bh,bh
    1a32:	b1 03                	mov    cl,0x3
    1a34:	d3 eb                	shr    bx,cl
    1a36:	8a c8                	mov    cl,al
    1a38:	80 e1 07             	and    cl,0x7
    1a3b:	b0 01                	mov    al,0x1
    1a3d:	d2 e0                	shl    al,cl
    1a3f:	26 08 01             	or     BYTE PTR es:[bx+di],al
    1a42:	ca 02 00             	retf   0x2
    1a45:	8b dc                	mov    bx,sp
    1a47:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1a4b:	36 8a 47 06          	mov    al,BYTE PTR ss:[bx+0x6]
    1a4f:	36 8a 57 04          	mov    dl,BYTE PTR ss:[bx+0x4]
    1a53:	2a d0                	sub    dl,al
    1a55:	72 1f                	jb     0x1a76
    1a57:	fe c2                	inc    dl
    1a59:	8a d8                	mov    bl,al
    1a5b:	32 ff                	xor    bh,bh
    1a5d:	b1 03                	mov    cl,0x3
    1a5f:	d3 eb                	shr    bx,cl
    1a61:	8a c8                	mov    cl,al
    1a63:	80 e1 07             	and    cl,0x7
    1a66:	b0 01                	mov    al,0x1
    1a68:	d2 e0                	shl    al,cl
    1a6a:	26 08 01             	or     BYTE PTR es:[bx+di],al
    1a6d:	d0 c0                	rol    al,1
    1a6f:	83 d3 00             	adc    bx,0x0
    1a72:	fe ca                	dec    dl
    1a74:	75 f4                	jne    0x1a6a
    1a76:	ca 04 00             	retf   0x4
    1a79:	fc                   	cld
    1a7a:	8b dc                	mov    bx,sp
    1a7c:	8c da                	mov    dx,ds
    1a7e:	36 c5 77 0a          	lds    si,DWORD PTR ss:[bx+0xa]
    1a82:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    1a86:	36 8b 5f 04          	mov    bx,WORD PTR ss:[bx+0x4]
    1a8a:	8a cf                	mov    cl,bh
    1a8c:	32 ed                	xor    ch,ch
    1a8e:	03 f1                	add    si,cx
    1a90:	8a cb                	mov    cl,bl
    1a92:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1a94:	8e da                	mov    ds,dx
    1a96:	ca 0a 00             	retf   0xa
    1a99:	8a e8                	mov    ch,al
    1a9b:	b1 03                	mov    cl,0x3
    1a9d:	d2 ed                	shr    ch,cl
    1a9f:	2a ee                	sub    ch,dh
    1aa1:	72 11                	jb     0x1ab4
    1aa3:	3a ea                	cmp    ch,dl
    1aa5:	73 0d                	jae    0x1ab4
    1aa7:	8a d5                	mov    dl,ch
    1aa9:	32 f6                	xor    dh,dh
    1aab:	24 07                	and    al,0x7
    1aad:	8a c8                	mov    cl,al
    1aaf:	8a c4                	mov    al,ah
    1ab1:	d2 c0                	rol    al,cl
    1ab3:	cb                   	retf
    1ab4:	99                   	cwd
    1ab5:	92                   	xchg   dx,ax
    1ab6:	33 d2                	xor    dx,dx
    1ab8:	cb                   	retf
    1ab9:	fc                   	cld
    1aba:	8b dc                	mov    bx,sp
    1abc:	8c da                	mov    dx,ds
    1abe:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1ac2:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    1ac6:	b9 10 00             	mov    cx,0x10
    1ac9:	ad                   	lods   ax,WORD PTR ds:[si]
    1aca:	26 0b 05             	or     ax,WORD PTR es:[di]
    1acd:	ab                   	stos   WORD PTR es:[di],ax
    1ace:	e2 f9                	loop   0x1ac9
    1ad0:	8e da                	mov    ds,dx
    1ad2:	ca 04 00             	retf   0x4
    1ad5:	fc                   	cld
    1ad6:	8b dc                	mov    bx,sp
    1ad8:	8c da                	mov    dx,ds
    1ada:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1ade:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    1ae2:	b9 10 00             	mov    cx,0x10
    1ae5:	ad                   	lods   ax,WORD PTR ds:[si]
    1ae6:	f7 d0                	not    ax
    1ae8:	26 23 05             	and    ax,WORD PTR es:[di]
    1aeb:	ab                   	stos   WORD PTR es:[di],ax
    1aec:	e2 f7                	loop   0x1ae5
    1aee:	8e da                	mov    ds,dx
    1af0:	ca 04 00             	retf   0x4
    1af3:	fc                   	cld
    1af4:	8b dc                	mov    bx,sp
    1af6:	8c da                	mov    dx,ds
    1af8:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1afc:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    1b00:	b9 10 00             	mov    cx,0x10
    1b03:	ad                   	lods   ax,WORD PTR ds:[si]
    1b04:	26 23 05             	and    ax,WORD PTR es:[di]
    1b07:	ab                   	stos   WORD PTR es:[di],ax
    1b08:	e2 f9                	loop   0x1b03
    1b0a:	8e da                	mov    ds,dx
    1b0c:	ca 04 00             	retf   0x4
    1b0f:	fc                   	cld
    1b10:	8b dc                	mov    bx,sp
    1b12:	8c da                	mov    dx,ds
    1b14:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1b18:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    1b1c:	b9 10 00             	mov    cx,0x10
    1b1f:	f3 a7                	repz cmps WORD PTR ds:[si],WORD PTR es:[di]
    1b21:	8e da                	mov    ds,dx
    1b23:	ca 08 00             	retf   0x8
    1b26:	fc                   	cld
    1b27:	8b dc                	mov    bx,sp
    1b29:	8c da                	mov    dx,ds
    1b2b:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1b2f:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    1b33:	b9 10 00             	mov    cx,0x10
    1b36:	ad                   	lods   ax,WORD PTR ds:[si]
    1b37:	26 0b 05             	or     ax,WORD PTR es:[di]
    1b3a:	af                   	scas   ax,WORD PTR es:[di]
    1b3b:	75 02                	jne    0x1b3f
    1b3d:	e2 f7                	loop   0x1b36
    1b3f:	8e da                	mov    ds,dx
    1b41:	ca 08 00             	retf   0x8
    1b44:	8b dc                	mov    bx,sp
    1b46:	1e                   	push   ds
    1b47:	36 c5 7f 04          	lds    di,DWORD PTR ss:[bx+0x4]
    1b4b:	33 c9                	xor    cx,cx
    1b4d:	89 0d                	mov    WORD PTR [di],cx
    1b4f:	b8 00 3d             	mov    ax,0x3d00
    1b52:	81 7d 02 b1 d7       	cmp    WORD PTR [di+0x2],0xd7b1
    1b57:	74 0d                	je     0x1b66
    1b59:	b0 02                	mov    al,0x2
    1b5b:	ff 05                	inc    WORD PTR [di]
    1b5d:	81 7d 02 b3 d7       	cmp    WORD PTR [di+0x2],0xd7b3
    1b62:	74 02                	je     0x1b66
    1b64:	b4 3c                	mov    ah,0x3c
    1b66:	80 7d 30 00          	cmp    BYTE PTR [di+0x30],0x0
    1b6a:	74 09                	je     0x1b75
    1b6c:	8d 55 30             	lea    dx,[di+0x30]
    1b6f:	cd 21                	int    0x21
    1b71:	72 5a                	jb     0x1bcd
    1b73:	89 05                	mov    WORD PTR [di],ax
    1b75:	b8 a1 0a             	mov    ax,0xaa1
    1b78:	ba 94 1b             	mov    dx,0x1b94
    1b7b:	33 c9                	xor    cx,cx
    1b7d:	33 db                	xor    bx,bx
    1b7f:	81 7d 02 b1 d7       	cmp    WORD PTR [di+0x2],0xd7b1
    1b84:	74 2f                	je     0x1bb5
    1b86:	8b 1d                	mov    bx,WORD PTR [di]
    1b88:	b8 00 44             	mov    ax,0x4400
    1b8b:	cd 21                	int    0x21
    1b8d:	f6 c2 80             	test   dl,0x80
    1b90:	b8 f6 0a             	mov    ax,0xaf6
    1b93:	ba aa 1b             	mov    dx,0x1baa
    1b96:	8b c8                	mov    cx,ax
    1b98:	8b da                	mov    bx,dx
    1b9a:	75 14                	jne    0x1bb0
    1b9c:	81 7d 02 b3 d7       	cmp    WORD PTR [di+0x2],0xd7b3
    1ba1:	75 03                	jne    0x1ba6
    1ba3:	e8 2b 00             	call   0x1bd1
    1ba6:	b8 d1 0a             	mov    ax,0xad1
    1ba9:	ba c9 1b             	mov    dx,0x1bc9
    1bac:	33 c9                	xor    cx,cx
    1bae:	33 db                	xor    bx,bx
    1bb0:	c7 45 02 b2 d7       	mov    WORD PTR [di+0x2],0xd7b2
    1bb5:	89 45 14             	mov    WORD PTR [di+0x14],ax
    1bb8:	89 55 16             	mov    WORD PTR [di+0x16],dx
    1bbb:	89 4d 18             	mov    WORD PTR [di+0x18],cx
    1bbe:	89 5d 1a             	mov    WORD PTR [di+0x1a],bx
    1bc1:	c7 45 1c 16 0b       	mov    WORD PTR [di+0x1c],0xb16
    1bc6:	c7 45 1e 1e 1f       	mov    WORD PTR [di+0x1e],0x1f1e
    1bcb:	33 c0                	xor    ax,ax
    1bcd:	1f                   	pop    ds
    1bce:	ca 04 00             	retf   0x4
    1bd1:	33 d2                	xor    dx,dx
    1bd3:	33 c9                	xor    cx,cx
    1bd5:	8b 1d                	mov    bx,WORD PTR [di]
    1bd7:	b8 02 42             	mov    ax,0x4202
    1bda:	cd 21                	int    0x21
    1bdc:	2d 80 00             	sub    ax,0x80
    1bdf:	83 da 00             	sbb    dx,0x0
    1be2:	73 04                	jae    0x1be8
    1be4:	33 c0                	xor    ax,ax
    1be6:	33 d2                	xor    dx,dx
    1be8:	8b ca                	mov    cx,dx
    1bea:	8b d0                	mov    dx,ax
    1bec:	8b 1d                	mov    bx,WORD PTR [di]
    1bee:	b8 00 42             	mov    ax,0x4200
    1bf1:	cd 21                	int    0x21
    1bf3:	8d 95 80 00          	lea    dx,[di+0x80]
    1bf7:	b9 80 00             	mov    cx,0x80
    1bfa:	8b 1d                	mov    bx,WORD PTR [di]
    1bfc:	b4 3f                	mov    ah,0x3f
    1bfe:	cd 21                	int    0x21
    1c00:	73 02                	jae    0x1c04
    1c02:	33 c0                	xor    ax,ax
    1c04:	33 db                	xor    bx,bx
    1c06:	3b d8                	cmp    bx,ax
    1c08:	74 20                	je     0x1c2a
    1c0a:	80 b9 80 00 1a       	cmp    BYTE PTR [bx+di+0x80],0x1a
    1c0f:	74 03                	je     0x1c14
    1c11:	43                   	inc    bx
    1c12:	eb f2                	jmp    0x1c06
    1c14:	8b d3                	mov    dx,bx
    1c16:	2b d0                	sub    dx,ax
    1c18:	b9 ff ff             	mov    cx,0xffff
    1c1b:	8b 1d                	mov    bx,WORD PTR [di]
    1c1d:	b8 02 42             	mov    ax,0x4202
    1c20:	cd 21                	int    0x21
    1c22:	33 c9                	xor    cx,cx
    1c24:	8b 1d                	mov    bx,WORD PTR [di]
    1c26:	b4 40                	mov    ah,0x40
    1c28:	cd 21                	int    0x21
    1c2a:	c3                   	ret
    1c2b:	e8 5a 00             	call   0x1c88
    1c2e:	8b dc                	mov    bx,sp
    1c30:	8b ca                	mov    cx,dx
    1c32:	36 f7 67 04          	mul    WORD PTR ss:[bx+0x4]
    1c36:	8b c1                	mov    ax,cx
    1c38:	8b ca                	mov    cx,dx
    1c3a:	36 f7 67 04          	mul    WORD PTR ss:[bx+0x4]
    1c3e:	03 c1                	add    ax,cx
    1c40:	83 d2 00             	adc    dx,0x0
    1c43:	8b c2                	mov    ax,dx
    1c45:	ca 02 00             	retf   0x2
    1c48:	e8 3d 00             	call   0x1c88
    1c4b:	93                   	xchg   bx,ax
    1c4c:	b8 80 00             	mov    ax,0x80
    1c4f:	b9 20 00             	mov    cx,0x20
    1c52:	f6 c6 80             	test   dh,0x80
    1c55:	75 0a                	jne    0x1c61
    1c57:	d1 e3                	shl    bx,1
    1c59:	d1 d2                	rcl    dx,1
    1c5b:	fe c8                	dec    al
    1c5d:	e2 f3                	loop   0x1c52
    1c5f:	32 c0                	xor    al,al
    1c61:	80 e6 7f             	and    dh,0x7f
    1c64:	cb                   	retf
    1c65:	e8 20 00             	call   0x1c88
    1c68:	9b 2e df 06 86 1c    	fild   WORD PTR cs:0x1c86
    1c6e:	9b db 06 7a 18       	fild   DWORD PTR ds:0x187a
    1c73:	9b 2e d8 06 82 1c    	fadd   DWORD PTR cs:0x1c82
    1c79:	9b d9 fd             	fscale
    1c7c:	9b dd d9             	fstp   st(1)
    1c7f:	90                   	nop
    1c80:	9b                   	fwait
    1c81:	cb                   	retf
    1c82:	00 00                	add    BYTE PTR [bx+si],al
    1c84:	00 4f e0             	add    BYTE PTR [bx-0x20],cl
    1c87:	ff a1 7a 18          	jmp    WORD PTR [bx+di+0x187a]
    1c8b:	8b 1e 7c 18          	mov    bx,WORD PTR ds:0x187c
    1c8f:	8b c8                	mov    cx,ax
    1c91:	2e f7 26 be 1c       	mul    WORD PTR cs:0x1cbe
    1c96:	d1 e1                	shl    cx,1
    1c98:	d1 e1                	shl    cx,1
    1c9a:	d1 e1                	shl    cx,1
    1c9c:	02 e9                	add    ch,cl
    1c9e:	03 d1                	add    dx,cx
    1ca0:	03 d3                	add    dx,bx
    1ca2:	d1 e3                	shl    bx,1
    1ca4:	d1 e3                	shl    bx,1
    1ca6:	03 d3                	add    dx,bx
    1ca8:	02 f3                	add    dh,bl
    1caa:	b1 05                	mov    cl,0x5
    1cac:	d3 e3                	shl    bx,cl
    1cae:	02 f3                	add    dh,bl
    1cb0:	05 01 00             	add    ax,0x1
    1cb3:	83 d2 00             	adc    dx,0x0
    1cb6:	a3 7a 18             	mov    ds:0x187a,ax
    1cb9:	89 16 7c 18          	mov    WORD PTR ds:0x187c,dx
    1cbd:	c3                   	ret
    1cbe:	05 84 b4             	add    ax,0xb484
    1cc1:	2c cd                	sub    al,0xcd
    1cc3:	21 89 0e 7a          	and    WORD PTR [bx+di+0x7a0e],cx
    1cc7:	18 89 16 7c          	sbb    BYTE PTR [bx+di+0x7c16],cl
    1ccb:	18 cb                	sbb    bl,cl
    1ccd:	8b cf                	mov    cx,di
    1ccf:	be 0a 00             	mov    si,0xa
    1cd2:	8b da                	mov    bx,dx
    1cd4:	0b db                	or     bx,bx
    1cd6:	79 11                	jns    0x1ce9
    1cd8:	f7 db                	neg    bx
    1cda:	f7 d8                	neg    ax
    1cdc:	83 db 00             	sbb    bx,0x0
    1cdf:	e8 07 00             	call   0x1ce9
    1ce2:	4f                   	dec    di
    1ce3:	26 c6 05 2d          	mov    BYTE PTR es:[di],0x2d
    1ce7:	41                   	inc    cx
    1ce8:	c3                   	ret
    1ce9:	33 d2                	xor    dx,dx
    1ceb:	93                   	xchg   bx,ax
    1cec:	f7 f6                	div    si
    1cee:	93                   	xchg   bx,ax
    1cef:	f7 f6                	div    si
    1cf1:	80 c2 30             	add    dl,0x30
    1cf4:	80 fa 3a             	cmp    dl,0x3a
    1cf7:	72 03                	jb     0x1cfc
    1cf9:	80 c2 07             	add    dl,0x7
    1cfc:	4f                   	dec    di
    1cfd:	26 88 15             	mov    BYTE PTR es:[di],dl
    1d00:	8b d0                	mov    dx,ax
    1d02:	0b d3                	or     dx,bx
    1d04:	75 e3                	jne    0x1ce9
    1d06:	2b cf                	sub    cx,di
    1d08:	c3                   	ret
    1d09:	33 c0                	xor    ax,ax
    1d0b:	33 d2                	xor    dx,dx
    1d0d:	33 f6                	xor    si,si
    1d0f:	e3 5d                	jcxz   0x1d6e
    1d11:	26 80 3d 2b          	cmp    BYTE PTR es:[di],0x2b
    1d15:	74 07                	je     0x1d1e
    1d17:	26 80 3d 2d          	cmp    BYTE PTR es:[di],0x2d
    1d1b:	75 05                	jne    0x1d22
    1d1d:	4e                   	dec    si
    1d1e:	47                   	inc    di
    1d1f:	49                   	dec    cx
    1d20:	74 4c                	je     0x1d6e
    1d22:	26 80 3d 24          	cmp    BYTE PTR es:[di],0x24
    1d26:	74 48                	je     0x1d70
    1d28:	26 8a 1d             	mov    bl,BYTE PTR es:[di]
    1d2b:	80 eb 3a             	sub    bl,0x3a
    1d2e:	80 c3 0a             	add    bl,0xa
    1d31:	73 25                	jae    0x1d58
    1d33:	f6 c6 f0             	test   dh,0xf0
    1d36:	75 36                	jne    0x1d6e
    1d38:	53                   	push   bx
    1d39:	d1 e0                	shl    ax,1
    1d3b:	d1 d2                	rcl    dx,1
    1d3d:	52                   	push   dx
    1d3e:	50                   	push   ax
    1d3f:	d1 e0                	shl    ax,1
    1d41:	d1 d2                	rcl    dx,1
    1d43:	d1 e0                	shl    ax,1
    1d45:	d1 d2                	rcl    dx,1
    1d47:	5b                   	pop    bx
    1d48:	03 c3                	add    ax,bx
    1d4a:	5b                   	pop    bx
    1d4b:	13 d3                	adc    dx,bx
    1d4d:	5b                   	pop    bx
    1d4e:	32 ff                	xor    bh,bh
    1d50:	03 c3                	add    ax,bx
    1d52:	83 d2 00             	adc    dx,0x0
    1d55:	47                   	inc    di
    1d56:	e2 d0                	loop   0x1d28
    1d58:	8b d8                	mov    bx,ax
    1d5a:	0b da                	or     bx,dx
    1d5c:	74 0f                	je     0x1d6d
    1d5e:	0b f6                	or     si,si
    1d60:	79 07                	jns    0x1d69
    1d62:	f7 da                	neg    dx
    1d64:	f7 d8                	neg    ax
    1d66:	83 da 00             	sbb    dx,0x0
    1d69:	33 f2                	xor    si,dx
    1d6b:	78 01                	js     0x1d6e
    1d6d:	c3                   	ret
    1d6e:	f9                   	stc
    1d6f:	c3                   	ret
    1d70:	47                   	inc    di
    1d71:	49                   	dec    cx
    1d72:	74 fa                	je     0x1d6e
    1d74:	26 8a 1d             	mov    bl,BYTE PTR es:[di]
    1d77:	80 fb 61             	cmp    bl,0x61
    1d7a:	72 03                	jb     0x1d7f
    1d7c:	80 eb 20             	sub    bl,0x20
    1d7f:	80 eb 3a             	sub    bl,0x3a
    1d82:	80 c3 0a             	add    bl,0xa
    1d85:	72 0b                	jb     0x1d92
    1d87:	80 eb 17             	sub    bl,0x17
    1d8a:	80 c3 06             	add    bl,0x6
    1d8d:	73 c9                	jae    0x1d58
    1d8f:	80 c3 0a             	add    bl,0xa
    1d92:	b7 04                	mov    bh,0x4
    1d94:	d1 e0                	shl    ax,1
    1d96:	d1 d2                	rcl    dx,1
    1d98:	72 d4                	jb     0x1d6e
    1d9a:	fe cf                	dec    bh
    1d9c:	75 f6                	jne    0x1d94
    1d9e:	0a c3                	or     al,bl
    1da0:	47                   	inc    di
    1da1:	e2 d1                	loop   0x1d74
    1da3:	0b f6                	or     si,si
    1da5:	79 07                	jns    0x1dae
    1da7:	f7 da                	neg    dx
    1da9:	f7 d8                	neg    ax
    1dab:	83 da 00             	sbb    dx,0x0
    1dae:	f8                   	clc
    1daf:	c3                   	ret
    1db0:	55                   	push   bp
    1db1:	8b ec                	mov    bp,sp
    1db3:	83 ec 20             	sub    sp,0x20
    1db6:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1db9:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    1dbc:	8d 7e 00             	lea    di,[bp+0x0]
    1dbf:	16                   	push   ss
    1dc0:	07                   	pop    es
    1dc1:	e8 09 ff             	call   0x1ccd
    1dc4:	1e                   	push   ds
    1dc5:	8b f7                	mov    si,di
    1dc7:	16                   	push   ss
    1dc8:	1f                   	pop    ds
    1dc9:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1dcc:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    1dcf:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1dd2:	3b c2                	cmp    ax,dx
    1dd4:	7e 02                	jle    0x1dd8
    1dd6:	8b c2                	mov    ax,dx
    1dd8:	3b ca                	cmp    cx,dx
    1dda:	7e 02                	jle    0x1dde
    1ddc:	8b ca                	mov    cx,dx
    1dde:	3b c1                	cmp    ax,cx
    1de0:	7d 02                	jge    0x1de4
    1de2:	8b c1                	mov    ax,cx
    1de4:	fc                   	cld
    1de5:	aa                   	stos   BYTE PTR es:[di],al
    1de6:	2b c1                	sub    ax,cx
    1de8:	74 08                	je     0x1df2
    1dea:	51                   	push   cx
    1deb:	8b c8                	mov    cx,ax
    1ded:	b0 20                	mov    al,0x20
    1def:	f3 aa                	rep stos BYTE PTR es:[di],al
    1df1:	59                   	pop    cx
    1df2:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1df4:	1f                   	pop    ds
    1df5:	8b e5                	mov    sp,bp
    1df7:	5d                   	pop    bp
    1df8:	ca 0c 00             	retf   0xc
    1dfb:	55                   	push   bp
    1dfc:	8b ec                	mov    bp,sp
    1dfe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e01:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
    1e04:	32 ed                	xor    ch,ch
    1e06:	47                   	inc    di
    1e07:	e3 09                	jcxz   0x1e12
    1e09:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    1e0d:	75 03                	jne    0x1e12
    1e0f:	47                   	inc    di
    1e10:	e2 f7                	loop   0x1e09
    1e12:	e8 f4 fe             	call   0x1d09
    1e15:	72 02                	jb     0x1e19
    1e17:	e3 09                	jcxz   0x1e22
    1e19:	8b cf                	mov    cx,di
    1e1b:	2b 4e 0a             	sub    cx,WORD PTR [bp+0xa]
    1e1e:	33 c0                	xor    ax,ax
    1e20:	33 d2                	xor    dx,dx
    1e22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e25:	26 89 0d             	mov    WORD PTR es:[di],cx
    1e28:	5d                   	pop    bp
    1e29:	ca 08 00             	retf   0x8
    1e2c:	55                   	push   bp
    1e2d:	8b ec                	mov    bp,sp
    1e2f:	83 ec 40             	sub    sp,0x40
    1e32:	8b 4e 0c             	mov    cx,WORD PTR [bp+0xc]
    1e35:	0b c9                	or     cx,cx
    1e37:	79 0e                	jns    0x1e47
    1e39:	b9 08 00             	mov    cx,0x8
    1e3c:	2b 4e 0e             	sub    cx,WORD PTR [bp+0xe]
    1e3f:	83 f9 fe             	cmp    cx,0xfffe
    1e42:	7e 03                	jle    0x1e47
    1e44:	b9 fe ff             	mov    cx,0xfffe
    1e47:	8d 7e c0             	lea    di,[bp-0x40]
    1e4a:	16                   	push   ss
    1e4b:	07                   	pop    es
    1e4c:	e8 bf e7             	call   0x60e
    1e4f:	1e                   	push   ds
    1e50:	8b f7                	mov    si,di
    1e52:	16                   	push   ss
    1e53:	1f                   	pop    ds
    1e54:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1e57:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    1e5a:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1e5d:	3b c2                	cmp    ax,dx
    1e5f:	7e 02                	jle    0x1e63
    1e61:	8b c2                	mov    ax,dx
    1e63:	3b ca                	cmp    cx,dx
    1e65:	7e 02                	jle    0x1e69
    1e67:	8b ca                	mov    cx,dx
    1e69:	3b c1                	cmp    ax,cx
    1e6b:	7d 02                	jge    0x1e6f
    1e6d:	8b c1                	mov    ax,cx
    1e6f:	fc                   	cld
    1e70:	aa                   	stos   BYTE PTR es:[di],al
    1e71:	2b c1                	sub    ax,cx
    1e73:	74 08                	je     0x1e7d
    1e75:	51                   	push   cx
    1e76:	8b c8                	mov    cx,ax
    1e78:	b0 20                	mov    al,0x20
    1e7a:	f3 aa                	rep stos BYTE PTR es:[di],al
    1e7c:	59                   	pop    cx
    1e7d:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1e7f:	1f                   	pop    ds
    1e80:	8b e5                	mov    sp,bp
    1e82:	5d                   	pop    bp
    1e83:	ca 0a 00             	retf   0xa
    1e86:	55                   	push   bp
    1e87:	8b ec                	mov    bp,sp
    1e89:	83 ec 0a             	sub    sp,0xa
    1e8c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e8f:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
    1e92:	32 ed                	xor    ch,ch
    1e94:	47                   	inc    di
    1e95:	e3 09                	jcxz   0x1ea0
    1e97:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    1e9b:	75 03                	jne    0x1ea0
    1e9d:	47                   	inc    di
    1e9e:	e2 f7                	loop   0x1e97
    1ea0:	e8 3b e9             	call   0x7de
    1ea3:	72 02                	jb     0x1ea7
    1ea5:	e3 0e                	jcxz   0x1eb5
    1ea7:	8b cf                	mov    cx,di
    1ea9:	2b 4e 0a             	sub    cx,WORD PTR [bp+0xa]
    1eac:	9b db 7e f6          	fstp   TBYTE PTR [bp-0xa]
    1eb0:	9b d9 ee             	fldz
    1eb3:	90                   	nop
    1eb4:	9b                   	fwait
    1eb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb8:	26 89 0d             	mov    WORD PTR es:[di],cx
    1ebb:	8b e5                	mov    sp,bp
    1ebd:	5d                   	pop    bp
    1ebe:	ca 08 00             	retf   0x8
    1ec1:	8b dc                	mov    bx,sp
    1ec3:	8c da                	mov    dx,ds
    1ec5:	36 c5 77 0a          	lds    si,DWORD PTR ss:[bx+0xa]
    1ec9:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    1ecd:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    1ed1:	fc                   	cld
    1ed2:	3b f7                	cmp    si,di
    1ed4:	73 07                	jae    0x1edd
    1ed6:	03 f1                	add    si,cx
    1ed8:	03 f9                	add    di,cx
    1eda:	4e                   	dec    si
    1edb:	4f                   	dec    di
    1edc:	fd                   	std
    1edd:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1edf:	fc                   	cld
    1ee0:	8e da                	mov    ds,dx
    1ee2:	ca 0a 00             	retf   0xa
    1ee5:	8b dc                	mov    bx,sp
    1ee7:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    1eeb:	36 8b 4f 06          	mov    cx,WORD PTR ss:[bx+0x6]
    1eef:	36 8a 47 04          	mov    al,BYTE PTR ss:[bx+0x4]
    1ef3:	fc                   	cld
    1ef4:	f3 aa                	rep stos BYTE PTR es:[di],al
    1ef6:	ca 08 00             	retf   0x8
    1ef9:	8b dc                	mov    bx,sp
    1efb:	36 8a 47 04          	mov    al,BYTE PTR ss:[bx+0x4]
    1eff:	3c 61                	cmp    al,0x61
    1f01:	72 06                	jb     0x1f09
    1f03:	3c 7a                	cmp    al,0x7a
    1f05:	77 02                	ja     0x1f09
    1f07:	2c 20                	sub    al,0x20
    1f09:	ca 02 00             	retf   0x2
    1f0c:	34 1f                	xor    al,0x1f
    1f0e:	00 00                	add    BYTE PTR [bx+si],al
    1f10:	00 00                	add    BYTE PTR [bx+si],al
    1f12:	00 00                	add    BYTE PTR [bx+si],al
    1f14:	2c 1f                	sub    al,0x1f
    1f16:	04 00                	add    al,0x0
    1f18:	00 00                	add    BYTE PTR [bx+si],al
    1f1a:	00 00                	add    BYTE PTR [bx+si],al
    1f1c:	61                   	popa
    1f1d:	20 22                	and    BYTE PTR [bp+si],ah
    1f1f:	1f                   	pop    ds
    1f20:	9a 1f 26 1f cb       	call   0xcb1f:0x261f
    1f25:	1f                   	pop    ds
    1f26:	2a 1f                	sub    bl,BYTE PTR [bx]
    1f28:	66 1f                	popd   ds
    1f2a:	24 20                	and    al,0x20
    1f2c:	07                   	pop    es
    1f2d:	54                   	push   sp
    1f2e:	4f                   	dec    di
    1f2f:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
    1f32:	63 74 07             	arpl   WORD PTR [si+0x7],si
    1f35:	07                   	pop    es
    1f36:	54                   	push   sp
    1f37:	4f                   	dec    di
    1f38:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
    1f3b:	63 74 2c             	arpl   WORD PTR [si+0x2c],si
    1f3e:	1f                   	pop    ds
    1f3f:	1b 23                	sbb    sp,WORD PTR [bp+di]
    1f41:	00 00                	add    BYTE PTR [bx+si],al
    1f43:	00 00                	add    BYTE PTR [bx+si],al
    1f45:	00 00                	add    BYTE PTR [bx+si],al
    1f47:	06                   	push   es
    1f48:	53                   	push   bx
    1f49:	79 73                	jns    0x1fbe
    1f4b:	74 65                	je     0x1fb2
    1f4d:	6d                   	ins    WORD PTR es:[di],dx
    1f4e:	00 00                	add    BYTE PTR [bx+si],al
    1f50:	8b dc                	mov    bx,sp
    1f52:	36 80 7f 08 00       	cmp    BYTE PTR ss:[bx+0x8],0x0
    1f57:	74 0a                	je     0x1f63
    1f59:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    1f5d:	06                   	push   es
    1f5e:	57                   	push   di
    1f5f:	26 ff 5d f4          	call   DWORD PTR es:[di-0xc]
    1f63:	ca 06 00             	retf   0x6
    1f66:	8b dc                	mov    bx,sp
    1f68:	36 80 7f 08 00       	cmp    BYTE PTR ss:[bx+0x8],0x0
    1f6d:	74 0d                	je     0x1f7c
    1f6f:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    1f73:	06                   	push   es
    1f74:	57                   	push   di
    1f75:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f78:	26 ff 5d f8          	call   DWORD PTR es:[di-0x8]
    1f7c:	ca 06 00             	retf   0x6
    1f7f:	8b dc                	mov    bx,sp
    1f81:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    1f85:	8c c0                	mov    ax,es
    1f87:	0b c7                	or     ax,di
    1f89:	74 0c                	je     0x1f97
    1f8b:	b0 01                	mov    al,0x1
    1f8d:	50                   	push   ax
    1f8e:	06                   	push   es
    1f8f:	57                   	push   di
    1f90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f93:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    1f97:	ca 04 00             	retf   0x4
    1f9a:	55                   	push   bp
    1f9b:	8b ec                	mov    bp,sp
    1f9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa0:	26 8b 45 ea          	mov    ax,WORD PTR es:[di-0x16]
    1fa4:	50                   	push   ax
    1fa5:	e8 77 e2             	call   0x21f
    1fa8:	59                   	pop    cx
    1fa9:	8b d8                	mov    bx,ax
    1fab:	8b f8                	mov    di,ax
    1fad:	8e c2                	mov    es,dx
    1faf:	fc                   	cld
    1fb0:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1fb3:	ab                   	stos   WORD PTR es:[di],ax
    1fb4:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1fb7:	ab                   	stos   WORD PTR es:[di],ax
    1fb8:	33 c0                	xor    ax,ax
    1fba:	83 e9 04             	sub    cx,0x4
    1fbd:	d1 e9                	shr    cx,1
    1fbf:	f3 ab                	rep stos WORD PTR es:[di],ax
    1fc1:	13 c8                	adc    cx,ax
    1fc3:	f3 aa                	rep stos BYTE PTR es:[di],al
    1fc5:	8b c3                	mov    ax,bx
    1fc7:	5d                   	pop    bp
    1fc8:	ca 04 00             	retf   0x4
    1fcb:	8b dc                	mov    bx,sp
    1fcd:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    1fd1:	8b cf                	mov    cx,di
    1fd3:	8c c3                	mov    bx,es
    1fd5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fd8:	26 8b 45 ea          	mov    ax,WORD PTR es:[di-0x16]
    1fdc:	e8 5d e3             	call   0x33c
    1fdf:	ca 04 00             	retf   0x4
    1fe2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe5:	06                   	push   es
    1fe6:	57                   	push   di
    1fe7:	26 ff 5d f4          	call   DWORD PTR es:[di-0xc]
    1feb:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    1fee:	89 56 08             	mov    WORD PTR [bp+0x8],dx
    1ff1:	8b dc                	mov    bx,sp
    1ff3:	83 c3 04             	add    bx,0x4
    1ff6:	36 c7 47 04 1c 20    	mov    WORD PTR ss:[bx+0x4],0x201c
    1ffc:	36 8c 4f 06          	mov    WORD PTR ss:[bx+0x6],cs
    2000:	36 89 6f 02          	mov    WORD PTR ss:[bx+0x2],bp
    2004:	a1 58 18             	mov    ax,ds:0x1858
    2007:	36 89 07             	mov    WORD PTR ss:[bx],ax
    200a:	89 1e 58 18          	mov    WORD PTR ds:0x1858,bx
    200e:	cb                   	retf
    200f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2012:	06                   	push   es
    2013:	57                   	push   di
    2014:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2017:	26 ff 5d f8          	call   DWORD PTR es:[di-0x8]
    201b:	cb                   	retf
    201c:	01 00                	add    WORD PTR [bx+si],ax
    201e:	00 00                	add    BYTE PTR [bx+si],al
    2020:	00 00                	add    BYTE PTR [bx+si],al
    2022:	26 20 3f             	and    BYTE PTR es:[bx],bh
    2025:	1f                   	pop    ds
    2026:	b0 01                	mov    al,0x1
    2028:	50                   	push   ax
    2029:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    202c:	06                   	push   es
    202d:	57                   	push   di
    202e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2031:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    2035:	e9 4d f3             	jmp    0x1385
    2038:	8b dc                	mov    bx,sp
    203a:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    203e:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2041:	0b c0                	or     ax,ax
    2043:	7e 11                	jle    0x2056
    2045:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    2049:	26 c4 3d             	les    di,DWORD PTR es:[di]
    204c:	e8 36 00             	call   0x2085
    204f:	74 03                	je     0x2054
    2051:	26 ff 2d             	jmp    DWORD PTR es:[di]
    2054:	8b dc                	mov    bx,sp
    2056:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    205a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    205d:	26 ff 6d f0          	jmp    DWORD PTR es:[di-0x10]
    2061:	ca 08 00             	retf   0x8
    2064:	b8 d2 00             	mov    ax,0xd2
    2067:	e9 25 e0             	jmp    0x8f
    206a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    206d:	e8 15 00             	call   0x2085
    2070:	74 f2                	je     0x2064
    2072:	26 ff 2d             	jmp    DWORD PTR es:[di]
    2075:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2078:	e8 0a 00             	call   0x2085
    207b:	74 e7                	je     0x2064
    207d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2080:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    2084:	cb                   	retf
    2085:	8b df                	mov    bx,di
    2087:	fc                   	cld
    2088:	26 8b 7f e6          	mov    di,WORD PTR es:[bx-0x1a]
    208c:	0b ff                	or     di,di
    208e:	74 0b                	je     0x209b
    2090:	26 8b 0d             	mov    cx,WORD PTR es:[di]
    2093:	8b d1                	mov    dx,cx
    2095:	47                   	inc    di
    2096:	47                   	inc    di
    2097:	f2 af                	repnz scas ax,WORD PTR es:[di]
    2099:	74 0b                	je     0x20a6
    209b:	26 c4 5f ec          	les    bx,DWORD PTR es:[bx-0x14]
    209f:	8c c1                	mov    cx,es
    20a1:	0b cb                	or     cx,bx
    20a3:	75 e3                	jne    0x2088
    20a5:	c3                   	ret
    20a6:	4a                   	dec    dx
    20a7:	d1 e2                	shl    dx,1
    20a9:	2b d1                	sub    dx,cx
    20ab:	d1 e2                	shl    dx,1
    20ad:	03 fa                	add    di,dx
    20af:	c3                   	ret
    20b0:	8b dc                	mov    bx,sp
    20b2:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    20b6:	26 8b 4d ea          	mov    cx,WORD PTR es:[di-0x16]
    20ba:	8b c7                	mov    ax,di
    20bc:	8c c2                	mov    dx,es
    20be:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    20c2:	8b df                	mov    bx,di
    20c4:	fc                   	cld
    20c5:	ab                   	stos   WORD PTR es:[di],ax
    20c6:	8b c2                	mov    ax,dx
    20c8:	ab                   	stos   WORD PTR es:[di],ax
    20c9:	33 c0                	xor    ax,ax
    20cb:	83 e9 04             	sub    cx,0x4
    20ce:	d1 e9                	shr    cx,1
    20d0:	f3 ab                	rep stos WORD PTR es:[di],ax
    20d2:	13 c8                	adc    cx,ax
    20d4:	f3 aa                	rep stos BYTE PTR es:[di],al
    20d6:	8b c3                	mov    ax,bx
    20d8:	8c c2                	mov    dx,es
    20da:	ca 08 00             	retf   0x8
    20dd:	8b dc                	mov    bx,sp
    20df:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    20e3:	26 8b 05             	mov    ax,WORD PTR es:[di]
    20e6:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    20ea:	ca 04 00             	retf   0x4
    20ed:	8b dc                	mov    bx,sp
    20ef:	1e                   	push   ds
    20f0:	fc                   	cld
    20f1:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    20f5:	8b 74 e8             	mov    si,WORD PTR [si-0x18]
    20f8:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    20fc:	ac                   	lods   al,BYTE PTR ds:[si]
    20fd:	aa                   	stos   BYTE PTR es:[di],al
    20fe:	8a c8                	mov    cl,al
    2100:	32 ed                	xor    ch,ch
    2102:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2104:	1f                   	pop    ds
    2105:	ca 04 00             	retf   0x4
    2108:	8b dc                	mov    bx,sp
    210a:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    210e:	26 8b 45 ec          	mov    ax,WORD PTR es:[di-0x14]
    2112:	26 8b 55 ee          	mov    dx,WORD PTR es:[di-0x12]
    2116:	ca 04 00             	retf   0x4
    2119:	8b dc                	mov    bx,sp
    211b:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    211f:	26 8b 45 ea          	mov    ax,WORD PTR es:[di-0x16]
    2123:	ca 04 00             	retf   0x4
    2126:	8b dc                	mov    bx,sp
    2128:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    212c:	26 8b 45 e0          	mov    ax,WORD PTR es:[di-0x20]
    2130:	8b d0                	mov    dx,ax
    2132:	0b c0                	or     ax,ax
    2134:	74 02                	je     0x2138
    2136:	8c c2                	mov    dx,es
    2138:	ca 04 00             	retf   0x4
    213b:	55                   	push   bp
    213c:	8b ec                	mov    bp,sp
    213e:	1e                   	push   ds
    213f:	fc                   	cld
    2140:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2143:	8a 24                	mov    ah,BYTE PTR [si]
    2145:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    2148:	33 db                	xor    bx,bx
    214a:	8b 7c e4             	mov    di,WORD PTR [si-0x1c]
    214d:	0b ff                	or     di,di
    214f:	74 11                	je     0x2162
    2151:	8b 15                	mov    dx,WORD PTR [di]
    2153:	47                   	inc    di
    2154:	47                   	inc    di
    2155:	8a 5d 04             	mov    bl,BYTE PTR [di+0x4]
    2158:	3a dc                	cmp    bl,ah
    215a:	74 14                	je     0x2170
    215c:	8d 79 05             	lea    di,[bx+di+0x5]
    215f:	4a                   	dec    dx
    2160:	75 f3                	jne    0x2155
    2162:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    2165:	8c d9                	mov    cx,ds
    2167:	0b ce                	or     cx,si
    2169:	75 df                	jne    0x214a
    216b:	33 c0                	xor    ax,ax
    216d:	99                   	cwd
    216e:	eb 15                	jmp    0x2185
    2170:	57                   	push   di
    2171:	56                   	push   si
    2172:	8d 75 05             	lea    si,[di+0x5]
    2175:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2178:	47                   	inc    di
    2179:	e8 b3 00             	call   0x222f
    217c:	5e                   	pop    si
    217d:	5f                   	pop    di
    217e:	75 dc                	jne    0x215c
    2180:	8b 05                	mov    ax,WORD PTR [di]
    2182:	8b 55 02             	mov    dx,WORD PTR [di+0x2]
    2185:	1f                   	pop    ds
    2186:	5d                   	pop    bp
    2187:	ca 08 00             	retf   0x8
    218a:	55                   	push   bp
    218b:	8b ec                	mov    bp,sp
    218d:	1e                   	push   ds
    218e:	fc                   	cld
    218f:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    2192:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2195:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2198:	33 db                	xor    bx,bx
    219a:	8b 7c e4             	mov    di,WORD PTR [si-0x1c]
    219d:	0b ff                	or     di,di
    219f:	74 10                	je     0x21b1
    21a1:	8b 0d                	mov    cx,WORD PTR [di]
    21a3:	47                   	inc    di
    21a4:	47                   	inc    di
    21a5:	3b 05                	cmp    ax,WORD PTR [di]
    21a7:	74 19                	je     0x21c2
    21a9:	8a 5d 04             	mov    bl,BYTE PTR [di+0x4]
    21ac:	8d 79 05             	lea    di,[bx+di+0x5]
    21af:	e2 f4                	loop   0x21a5
    21b1:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    21b4:	8c d9                	mov    cx,ds
    21b6:	0b ce                	or     cx,si
    21b8:	75 e0                	jne    0x219a
    21ba:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    21bd:	32 c0                	xor    al,al
    21bf:	aa                   	stos   BYTE PTR es:[di],al
    21c0:	eb 13                	jmp    0x21d5
    21c2:	3b 55 02             	cmp    dx,WORD PTR [di+0x2]
    21c5:	75 e2                	jne    0x21a9
    21c7:	8d 75 04             	lea    si,[di+0x4]
    21ca:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    21cd:	ac                   	lods   al,BYTE PTR ds:[si]
    21ce:	aa                   	stos   BYTE PTR es:[di],al
    21cf:	8a c8                	mov    cl,al
    21d1:	32 ed                	xor    ch,ch
    21d3:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    21d5:	1f                   	pop    ds
    21d6:	5d                   	pop    bp
    21d7:	ca 08 00             	retf   0x8
    21da:	55                   	push   bp
    21db:	8b ec                	mov    bp,sp
    21dd:	1e                   	push   ds
    21de:	fc                   	cld
    21df:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    21e2:	8a 24                	mov    ah,BYTE PTR [si]
    21e4:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    21e7:	c5 34                	lds    si,DWORD PTR [si]
    21e9:	33 db                	xor    bx,bx
    21eb:	8b 7c e2             	mov    di,WORD PTR [si-0x1e]
    21ee:	0b ff                	or     di,di
    21f0:	74 12                	je     0x2204
    21f2:	8b 15                	mov    dx,WORD PTR [di]
    21f4:	83 c7 04             	add    di,0x4
    21f7:	8a 5d 04             	mov    bl,BYTE PTR [di+0x4]
    21fa:	3a dc                	cmp    bl,ah
    21fc:	74 14                	je     0x2212
    21fe:	8d 79 05             	lea    di,[bx+di+0x5]
    2201:	4a                   	dec    dx
    2202:	75 f3                	jne    0x21f7
    2204:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    2207:	8c d9                	mov    cx,ds
    2209:	0b ce                	or     cx,si
    220b:	75 de                	jne    0x21eb
    220d:	33 c0                	xor    ax,ax
    220f:	99                   	cwd
    2210:	eb 18                	jmp    0x222a
    2212:	57                   	push   di
    2213:	56                   	push   si
    2214:	8d 75 05             	lea    si,[di+0x5]
    2217:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    221a:	47                   	inc    di
    221b:	e8 11 00             	call   0x222f
    221e:	5e                   	pop    si
    221f:	5f                   	pop    di
    2220:	75 dc                	jne    0x21fe
    2222:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2225:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2228:	03 05                	add    ax,WORD PTR [di]
    222a:	1f                   	pop    ds
    222b:	5d                   	pop    bp
    222c:	ca 08 00             	retf   0x8
    222f:	8a cc                	mov    cl,ah
    2231:	32 ed                	xor    ch,ch
    2233:	ac                   	lods   al,BYTE PTR ds:[si]
    2234:	26 32 05             	xor    al,BYTE PTR es:[di]
    2237:	47                   	inc    di
    2238:	24 df                	and    al,0xdf
    223a:	e1 f7                	loope  0x2233
    223c:	c3                   	ret
    223d:	55                   	push   bp
    223e:	8b ec                	mov    bp,sp
    2240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2243:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
    2246:	8b 5e 0c             	mov    bx,WORD PTR [bp+0xc]
    2249:	33 c0                	xor    ax,ax
    224b:	e8 4e 00             	call   0x229c
    224e:	75 01                	jne    0x2251
    2250:	40                   	inc    ax
    2251:	5d                   	pop    bp
    2252:	ca 08 00             	retf   0x8
    2255:	55                   	push   bp
    2256:	8b ec                	mov    bp,sp
    2258:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    225b:	8c c0                	mov    ax,es
    225d:	0b c7                	or     ax,di
    225f:	74 0e                	je     0x226f
    2261:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    2264:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    2267:	33 c0                	xor    ax,ax
    2269:	e8 2d 00             	call   0x2299
    226c:	75 01                	jne    0x226f
    226e:	40                   	inc    ax
    226f:	5d                   	pop    bp
    2270:	ca 08 00             	retf   0x8
    2273:	55                   	push   bp
    2274:	8b ec                	mov    bp,sp
    2276:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2279:	8b c7                	mov    ax,di
    227b:	8c c2                	mov    dx,es
    227d:	8b f0                	mov    si,ax
    227f:	0b f2                	or     si,dx
    2281:	74 0b                	je     0x228e
    2283:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    2286:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    2289:	e8 0d 00             	call   0x2299
    228c:	75 04                	jne    0x2292
    228e:	5d                   	pop    bp
    228f:	ca 08 00             	retf   0x8
    2292:	5d                   	pop    bp
    2293:	b8 0a 00             	mov    ax,0xa
    2296:	e9 c7 dd             	jmp    0x60
    2299:	26 c4 3d             	les    di,DWORD PTR es:[di]
    229c:	3b f9                	cmp    di,cx
    229e:	75 06                	jne    0x22a6
    22a0:	8c c6                	mov    si,es
    22a2:	3b f3                	cmp    si,bx
    22a4:	74 0b                	je     0x22b1
    22a6:	26 c4 7d ec          	les    di,DWORD PTR es:[di-0x14]
    22aa:	8c c6                	mov    si,es
    22ac:	0b f7                	or     si,di
    22ae:	75 ec                	jne    0x229c
    22b0:	4e                   	dec    si
    22b1:	c3                   	ret
    22b2:	01 08                	add    WORD PTR [bx+si],cx
    22b4:	53                   	push   bx
    22b5:	68 6f 72             	push   0x726f
    22b8:	74 69                	je     0x2323
    22ba:	6e                   	outs   dx,BYTE PTR ds:[si]
    22bb:	74 00                	je     0x22bd
    22bd:	80 ff ff             	cmp    bh,0xff
    22c0:	ff                   	(bad)
    22c1:	7f 00                	jg     0x22c3
    22c3:	00 00                	add    BYTE PTR [bx+si],al
    22c5:	01 04                	add    WORD PTR [si],ax
    22c7:	42                   	inc    dx
    22c8:	79 74                	jns    0x233e
    22ca:	65 01 00             	add    WORD PTR gs:[bx+si],ax
    22cd:	00 00                	add    BYTE PTR [bx+si],al
    22cf:	00 ff                	add    bh,bh
    22d1:	00 00                	add    BYTE PTR [bx+si],al
    22d3:	00 01                	add    BYTE PTR [bx+di],al
    22d5:	07                   	pop    es
    22d6:	49                   	dec    cx
    22d7:	6e                   	outs   dx,BYTE PTR ds:[si]
    22d8:	74 65                	je     0x233f
    22da:	67 65 72 02          	addr32 gs jb 0x22e0
    22de:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    22e2:	ff                   	(bad)
    22e3:	7f 00                	jg     0x22e5
    22e5:	00 01                	add    BYTE PTR [bx+di],al
    22e7:	04 57                	add    al,0x57
    22e9:	6f                   	outs   dx,WORD PTR ds:[si]
    22ea:	72 64                	jb     0x2350
    22ec:	03 00                	add    ax,WORD PTR [bx+si]
    22ee:	00 00                	add    BYTE PTR [bx+si],al
    22f0:	00 ff                	add    bh,bh
    22f2:	ff 00                	inc    WORD PTR [bx+si]
    22f4:	00 01                	add    BYTE PTR [bx+di],al
    22f6:	07                   	pop    es
    22f7:	4c                   	dec    sp
    22f8:	6f                   	outs   dx,WORD PTR ds:[si]
    22f9:	6e                   	outs   dx,BYTE PTR ds:[si]
    22fa:	67 69 6e 74 04 00    	imul   bp,WORD PTR [esi+0x74],0x4
    2300:	00 00                	add    BYTE PTR [bx+si],al
    2302:	80 ff ff             	cmp    bh,0xff
    2305:	ff                   	(bad)
    2306:	7f 03                	jg     0x230b
    2308:	07                   	pop    es
    2309:	42                   	inc    dx
    230a:	6f                   	outs   dx,WORD PTR ds:[si]
    230b:	6f                   	outs   dx,WORD PTR ds:[si]
    230c:	6c                   	ins    BYTE PTR es:[di],dx
    230d:	65 61                	gs popa
    230f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2310:	00 00                	add    BYTE PTR [bx+si],al
    2312:	00 00                	add    BYTE PTR [bx+si],al
    2314:	00 01                	add    BYTE PTR [bx+di],al
    2316:	00 00                	add    BYTE PTR [bx+si],al
    2318:	00 07                	add    BYTE PTR [bx],al
    231a:	23 ff                	and    di,di
    231c:	ff 05                	inc    WORD PTR [di]
    231e:	46                   	inc    si
    231f:	61                   	popa
    2320:	6c                   	ins    BYTE PTR es:[di],dx
    2321:	73 65                	jae    0x2388
    2323:	04 54                	add    al,0x54
    2325:	72 75                	jb     0x239c
    2327:	65 02 04             	add    al,BYTE PTR gs:[si]
    232a:	43                   	inc    bx
    232b:	68 61 72             	push   0x7261
    232e:	01 00                	add    WORD PTR [bx+si],ax
    2330:	00 00                	add    BYTE PTR [bx+si],al
    2332:	00 ff                	add    bh,bh
    2334:	00 00                	add    BYTE PTR [bx+si],al
    2336:	00 04                	add    BYTE PTR [si],al
    2338:	06                   	push   es
    2339:	53                   	push   bx
    233a:	69 6e 67 6c 65       	imul   bp,WORD PTR [bp+0x67],0x656c
    233f:	00 04                	add    BYTE PTR [si],al
    2341:	06                   	push   es
    2342:	44                   	inc    sp
    2343:	6f                   	outs   dx,WORD PTR ds:[si]
    2344:	75 62                	jne    0x23a8
    2346:	6c                   	ins    BYTE PTR es:[di],dx
    2347:	65 01 04             	add    WORD PTR gs:[si],ax
    234a:	08 45 78             	or     BYTE PTR [di+0x78],al
    234d:	74 65                	je     0x23b4
    234f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2350:	64 65 64 02 04       	fs gs add al,BYTE PTR fs:[si]
    2355:	04 43                	add    al,0x43
    2357:	6f                   	outs   dx,WORD PTR ds:[si]
    2358:	6d                   	ins    WORD PTR es:[di],dx
    2359:	70 03                	jo     0x235e
    235b:	04 04                	add    al,0x4
    235d:	52                   	push   dx
    235e:	65 61                	gs popa
    2360:	6c                   	ins    BYTE PTR es:[di],dx
    2361:	04 05                	add    al,0x5
    2363:	06                   	push   es
    2364:	53                   	push   bx
    2365:	74 72                	je     0x23d9
    2367:	69 6e 67 ff 04       	imul   bp,WORD PTR [bp+0x67],0x4ff
    236c:	09 54 44             	or     WORD PTR [si+0x44],dx
    236f:	61                   	popa
    2370:	74 65                	je     0x23d7
    2372:	54                   	push   sp
    2373:	69                   	.byte 0x69
    2374:	6d                   	ins    WORD PTR es:[di],dx
    2375:	65                   	gs
    2376:	01                   	.byte 0x1
