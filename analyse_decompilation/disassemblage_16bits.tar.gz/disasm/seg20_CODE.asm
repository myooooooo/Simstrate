; ================================================================
; seg20_CODE  (24087 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	14 00                	adc    al,0x0
       2:	0c 09                	or     al,0x9
       4:	9f                   	lahf
       5:	02 b2 00 00          	add    dh,BYTE PTR [bp+si+0x0]
       9:	00 9e 00 6a          	add    BYTE PTR [bp+0x6a00],bl
       d:	06                   	push   es
       e:	fb                   	sti
       f:	04 27                	add    al,0x27
      11:	09 39                	or     WORD PTR [bx+di],di
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 4b 09 cb       	call   0xcb09:0x4b1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 10                	adc    BYTE PTR [bx+si],dl
      2d:	0c d6                	or     al,0xd6
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 65                	sbb    al,0x65
      61:	0a e2                	or     ah,dl
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	13 54 46             	adc    dx,WORD PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	43                   	inc    bx
      a6:	44                   	inc    sp
      a7:	44                   	inc    sp
      a8:	5f                   	pop    di
      a9:	44                   	inc    sp
      aa:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
      ae:	69 6f 6e 73 1b       	imul   bp,WORD PTR [bx+0x6e],0x1b73
      b3:	00 b0 0d c4          	add    BYTE PTR [bx+si-0x3bf3],dh
      b7:	00 09                	add    BYTE PTR [bx+di],cl
      b9:	46                   	inc    si
      ba:	6f                   	outs   dx,WORD PTR ds:[si]
      bb:	72 6d                	jb     0x12a
      bd:	43                   	inc    bx
      be:	6c                   	ins    BYTE PTR es:[di],dx
      bf:	6f                   	outs   dx,WORD PTR ds:[si]
      c0:	73 65                	jae    0x127
      c2:	ef                   	out    dx,ax
      c3:	11 d6                	adc    si,dx
      c5:	00 0d                	add    BYTE PTR [di],cl
      c7:	50                   	push   ax
      c8:	72 69                	jb     0x133
      ca:	6e                   	outs   dx,BYTE PTR ds:[si]
      cb:	74 42                	je     0x10f
      cd:	74 6e                	je     0x13d
      cf:	43                   	inc    bx
      d0:	6c                   	ins    BYTE PTR es:[di],dx
      d1:	69 63 6b b0 47       	imul   sp,WORD PTR [bp+di+0x6b],0x47b0
      d6:	e7 00                	out    0x0,ax
      d8:	0c 48                	or     al,0x48
      da:	65 6c                	gs ins BYTE PTR es:[di],dx
      dc:	70 42                	jo     0x120
      de:	74 6e                	je     0x14e
      e0:	43                   	inc    bx
      e1:	6c                   	ins    BYTE PTR es:[di],dx
      e2:	69 63 6b 09 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c09
      e7:	f8                   	clc
      e8:	00 0c                	add    BYTE PTR [si],cl
      ea:	54                   	push   sp
      eb:	65 73 74             	gs jae 0x162
      ee:	42                   	inc    dx
      ef:	74 6e                	je     0x15f
      f1:	43                   	inc    bx
      f2:	6c                   	ins    BYTE PTR es:[di],dx
      f3:	69 63 6b ed 12       	imul   sp,WORD PTR [bp+di+0x6b],0x12ed
      f8:	0c 01                	or     al,0x1
      fa:	0f 53 70 69          	rcpps  xmm6,XMMWORD PTR [bx+si+0x69]
      fe:	6e                   	outs   dx,BYTE PTR ds:[si]
      ff:	45                   	inc    bp
     100:	64 69 74 31 43 68    	imul   si,WORD PTR fs:[si+0x31],0x6843
     106:	61                   	popa
     107:	6e                   	outs   dx,BYTE PTR ds:[si]
     108:	67 65 cf             	addr32 gs iret
     10b:	0d 1f 01             	or     ax,0x11f
     10e:	0e                   	push   cs
     10f:	46                   	inc    si
     110:	6f                   	outs   dx,WORD PTR ds:[si]
     111:	72 6d                	jb     0x180
     113:	43                   	inc    bx
     114:	6c                   	ins    BYTE PTR es:[di],dx
     115:	6f                   	outs   dx,WORD PTR ds:[si]
     116:	73 65                	jae    0x17d
     118:	51                   	push   cx
     119:	75 65                	jne    0x180
     11b:	72 79                	jb     0x196
     11d:	fa                   	cli
     11e:	10 2c                	adc    BYTE PTR [si],ch
     120:	01 08                	add    WORD PTR [bx+si],cx
     122:	46                   	inc    si
     123:	6f                   	outs   dx,WORD PTR ds:[si]
     124:	72 6d                	jb     0x193
     126:	53                   	push   bx
     127:	68 6f 77             	push   0x776f
     12a:	3b 0a                	cmp    cx,WORD PTR [bp+si]
     12c:	3b 01                	cmp    ax,WORD PTR [bx+di]
     12e:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     131:	72 6d                	jb     0x1a0
     133:	43                   	inc    bx
     134:	72 65                	jb     0x19b
     136:	61                   	popa
     137:	74 65                	je     0x19e
     139:	d8 2a                	fsubr  DWORD PTR [bp+si]
     13b:	50                   	push   ax
     13c:	01 10                	add    WORD PTR [bx+si],dx
     13e:	56                   	push   si
     13f:	65 72 69             	gs jb  0x1ab
     142:	66 69 65 72 42 74 6e 	imul   esp,DWORD PTR [di+0x72],0x436e7442
     149:	43 
     14a:	6c                   	ins    BYTE PTR es:[di],dx
     14b:	69 63 6b f0 2a       	imul   sp,WORD PTR [bp+di+0x6b],0x2af0
     150:	63 01                	arpl   WORD PTR [bx+di],ax
     152:	0e                   	push   cs
     153:	44                   	inc    sp
     154:	65 66 61             	gs popad
     157:	75 74                	jne    0x1cd
     159:	42                   	inc    dx
     15a:	74 6e                	je     0x1ca
     15c:	43                   	inc    bx
     15d:	6c                   	ins    BYTE PTR es:[di],dx
     15e:	69 63 6b 92 19       	imul   sp,WORD PTR [bp+di+0x6b],0x1992
     163:	74 01                	je     0x166
     165:	0c 44                	or     al,0x44
     167:	42                   	inc    dx
     168:	45                   	inc    bp
     169:	64 69 74 32 45 6e    	imul   si,WORD PTR fs:[si+0x32],0x6e45
     16f:	74 65                	je     0x1d6
     171:	72 08                	jb     0x17b
     173:	2b 88 01 0f          	sub    cx,WORD PTR [bx+si+0xf01]
     177:	49                   	dec    cx
     178:	6e                   	outs   dx,BYTE PTR ds:[si]
     179:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     17e:	42                   	inc    dx
     17f:	74 6e                	je     0x1ef
     181:	43                   	inc    bx
     182:	6c                   	ins    BYTE PTR es:[di],dx
     183:	69 63 6b 71 1d       	imul   sp,WORD PTR [bp+di+0x6b],0x1d71
     188:	98                   	cbw
     189:	01 0b                	add    WORD PTR [bp+di],cx
     18b:	44                   	inc    sp
     18c:	42                   	inc    dx
     18d:	45                   	inc    bp
     18e:	64 69 74 32 45 78    	imul   si,WORD PTR fs:[si+0x32],0x7845
     194:	69 74 36 22 ab       	imul   si,WORD PTR [si+0x36],0xab22
     199:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     19d:	45                   	inc    bp
     19e:	64 69 74 32 4b 65    	imul   si,WORD PTR fs:[si+0x32],0x654b
     1a4:	79 44                	jns    0x1ea
     1a6:	6f                   	outs   dx,WORD PTR ds:[si]
     1a7:	77 6e                	ja     0x217
     1a9:	8d 21                	lea    sp,[bx+di]
     1ab:	bc 01 0c             	mov    sp,0xc01
     1ae:	44                   	inc    sp
     1af:	42                   	inc    dx
     1b0:	45                   	inc    bp
     1b1:	64 69 74 32 4b 65    	imul   si,WORD PTR fs:[si+0x32],0x654b
     1b7:	79 55                	jns    0x20e
     1b9:	70 56                	jo     0x211
     1bb:	47                   	inc    di
     1bc:	cd 01                	int    0x1
     1be:	0c 46                	or     al,0x46
     1c0:	6f                   	outs   dx,WORD PTR ds:[si]
     1c1:	72 6d                	jb     0x230
     1c3:	4b                   	dec    bx
     1c4:	65 79 50             	gs jns 0x217
     1c7:	72 65                	jb     0x22e
     1c9:	73 73                	jae    0x23e
     1cb:	83 13 e1             	adc    WORD PTR [bp+di],0xffe1
     1ce:	01 0f                	add    WORD PTR [bx],cx
     1d0:	43                   	inc    bx
     1d1:	6f                   	outs   dx,WORD PTR ds:[si]
     1d2:	6d                   	ins    WORD PTR es:[di],dx
     1d3:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     1d6:	6f                   	outs   dx,WORD PTR ds:[si]
     1d7:	78 32                	js     0x20b
     1d9:	43                   	inc    bx
     1da:	68 61 6e             	push   0x6e61
     1dd:	67 65 38 13          	cmp    BYTE PTR gs:[ebx],dl
     1e1:	f5                   	cmc
     1e2:	01 0f                	add    WORD PTR [bx],cx
     1e4:	43                   	inc    bx
     1e5:	6f                   	outs   dx,WORD PTR ds:[si]
     1e6:	6d                   	ins    WORD PTR es:[di],dx
     1e7:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     1ea:	6f                   	outs   dx,WORD PTR ds:[si]
     1eb:	78 31                	js     0x21e
     1ed:	43                   	inc    bx
     1ee:	68 61 6e             	push   0x6e61
     1f1:	67 65 58             	addr32 gs pop ax
     1f4:	48                   	dec    ax
     1f5:	0a 02                	or     al,BYTE PTR [bp+si]
     1f7:	10 44 42             	adc    BYTE PTR [si+0x42],al
     1fa:	45                   	inc    bp
     1fb:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     201:	75 73                	jne    0x276
     203:	65 44                	gs inc sp
     205:	6f                   	outs   dx,WORD PTR ds:[si]
     206:	77 6e                	ja     0x276
     208:	71 47                	jno    0x251
     20a:	1a 02                	sbb    al,BYTE PTR [bp+si]
     20c:	0b 46 6f             	or     ax,WORD PTR [bp+0x6f]
     20f:	72 6d                	jb     0x27e
     211:	4b                   	dec    bx
     212:	65 79 44             	gs jns 0x259
     215:	6f                   	outs   dx,WORD PTR ds:[si]
     216:	77 6e                	ja     0x286
     218:	e9 4c 2d             	jmp    0x2f67
     21b:	02 0e 43 6f          	add    cl,BYTE PTR ds:0x6f43
     21f:	70 69                	jo     0x28a
     221:	65 72 42             	gs jb  0x266
     224:	74 6e                	je     0x294
     226:	43                   	inc    bx
     227:	6c                   	ins    BYTE PTR es:[di],dx
     228:	69 63 6b 83 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c83
     22d:	3d 02 0b             	cmp    ax,0xb02
     230:	50                   	push   ax
     231:	72 69                	jb     0x29c
     233:	6e                   	outs   dx,BYTE PTR ds:[si]
     234:	74 31                	je     0x267
     236:	43                   	inc    bx
     237:	6c                   	ins    BYTE PTR es:[di],dx
     238:	69 63 6b c6 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5cc6
     23d:	4c                   	dec    sp
     23e:	02 0a                	add    cl,BYTE PTR [bp+si]
     240:	43                   	inc    bx
     241:	6f                   	outs   dx,WORD PTR ds:[si]
     242:	70 79                	jo     0x2bd
     244:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     247:	69 63 6b e6 48       	imul   sp,WORD PTR [bp+di+0x6b],0x48e6
     24c:	61                   	popa
     24d:	02 10                	add    dl,BYTE PTR [bx+si]
     24f:	50                   	push   ax
     250:	61                   	popa
     251:	6e                   	outs   dx,BYTE PTR ds:[si]
     252:	65 6c                	gs ins BYTE PTR es:[di],dx
     254:	31 37                	xor    WORD PTR [bx],si
     256:	4d                   	dec    bp
     257:	6f                   	outs   dx,WORD PTR ds:[si]
     258:	75 73                	jne    0x2cd
     25a:	65 44                	gs inc sp
     25c:	6f                   	outs   dx,WORD PTR ds:[si]
     25d:	77 6e                	ja     0x2cd
     25f:	b0 12                	mov    al,0x12
     261:	79 02                	jns    0x265
     263:	13 50 72             	adc    dx,WORD PTR [bx+si+0x72]
     266:	69 6e 74 52 61       	imul   bp,WORD PTR [bp+0x74],0x6152
     26b:	70 69                	jo     0x2d6
     26d:	64 65 42             	fs gs inc dx
     270:	74 6e                	je     0x2e0
     272:	43                   	inc    bx
     273:	6c                   	ins    BYTE PTR es:[di],dx
     274:	69 63 6b ae 14       	imul   sp,WORD PTR [bp+di+0x6b],0x14ae
     279:	8d 02                	lea    ax,[bp+si]
     27b:	0f 53 70 69          	rcpps  xmm6,XMMWORD PTR [bx+si+0x69]
     27f:	6e                   	outs   dx,BYTE PTR ds:[si]
     280:	45                   	inc    bp
     281:	64 69 74 32 43 68    	imul   si,WORD PTR fs:[si+0x32],0x6843
     287:	61                   	popa
     288:	6e                   	outs   dx,BYTE PTR ds:[si]
     289:	67 65 fb             	addr32 gs sti
     28c:	12 23                	adc    ah,BYTE PTR [bp+di]
     28e:	09 0f                	or     WORD PTR [bx],cx
     290:	43                   	inc    bx
     291:	6f                   	outs   dx,WORD PTR ds:[si]
     292:	6d                   	ins    WORD PTR es:[di],dx
     293:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     296:	6f                   	outs   dx,WORD PTR ds:[si]
     297:	78 33                	js     0x2cc
     299:	43                   	inc    bx
     29a:	68 61 6e             	push   0x6e61
     29d:	67 65 7b 00          	addr32 gs jnp 0x2a1
     2a1:	c6                   	(bad)
     2a2:	08 7c 01             	or     BYTE PTR [si+0x1],bh
     2a5:	00 00                	add    BYTE PTR [bx+si],al
     2a7:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     2ab:	62 65 64             	bound  sp,DWORD PTR [di+0x64]
     2ae:	4e                   	dec    si
     2af:	6f                   	outs   dx,WORD PTR ds:[si]
     2b0:	74 65                	je     0x317
     2b2:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     2b5:	6b 31 80             	imul   si,WORD PTR [bx+di],0xff80
     2b8:	01 04                	add    WORD PTR [si],ax
     2ba:	00 07                	add    BYTE PTR [bx],al
     2bc:	54                   	push   sp
     2bd:	61                   	popa
     2be:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2c1:	43                   	inc    bx
     2c2:	47                   	inc    di
     2c3:	84 01                	test   BYTE PTR [bx+di],al
     2c5:	08 00                	or     BYTE PTR [bx+si],al
     2c7:	0c 44                	or     al,0x44
     2c9:	61                   	popa
     2ca:	74 61                	je     0x32d
     2cc:	53                   	push   bx
     2cd:	6f                   	outs   dx,WORD PTR ds:[si]
     2ce:	75 72                	jne    0x342
     2d0:	63 65 43             	arpl   WORD PTR [di+0x43],sp
     2d3:	47                   	inc    di
     2d4:	88 01                	mov    BYTE PTR [bx+di],al
     2d6:	0c 00                	or     al,0x0
     2d8:	06                   	push   es
     2d9:	50                   	push   ax
     2da:	61                   	popa
     2db:	6e                   	outs   dx,BYTE PTR ds:[si]
     2dc:	65 6c                	gs ins BYTE PTR es:[di],dx
     2de:	32 8c 01 10          	xor    cl,BYTE PTR [si+0x1001]
     2e2:	00 07                	add    BYTE PTR [bx],al
     2e4:	4c                   	dec    sp
     2e5:	61                   	popa
     2e6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2e9:	50                   	push   ax
     2ea:	31 90 01 14          	xor    WORD PTR [bx+si+0x1401],dx
     2ee:	00 0c                	add    BYTE PTR [si],cl
     2f0:	50                   	push   ax
     2f1:	72 69                	jb     0x35c
     2f3:	6e                   	outs   dx,BYTE PTR ds:[si]
     2f4:	74 44                	je     0x33a
     2f6:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     2fb:	31 94 01 04          	xor    WORD PTR [si+0x401],dx
     2ff:	00 08                	add    BYTE PTR [bx+si],cl
     301:	54                   	push   sp
     302:	61                   	popa
     303:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     306:	43                   	inc    bx
     307:	50                   	push   ax
     308:	31 98 01 08          	xor    WORD PTR [bx+si+0x801],bx
     30c:	00 0d                	add    BYTE PTR [di],cl
     30e:	44                   	inc    sp
     30f:	61                   	popa
     310:	74 61                	je     0x373
     312:	53                   	push   bx
     313:	6f                   	outs   dx,WORD PTR ds:[si]
     314:	75 72                	jne    0x388
     316:	63 65 43             	arpl   WORD PTR [di+0x43],sp
     319:	50                   	push   ax
     31a:	31 9c 01 04          	xor    WORD PTR [si+0x401],bx
     31e:	00 08                	add    BYTE PTR [bx+si],cl
     320:	54                   	push   sp
     321:	61                   	popa
     322:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     325:	43                   	inc    bx
     326:	50                   	push   ax
     327:	32 a0 01 08          	xor    ah,BYTE PTR [bx+si+0x801]
     32b:	00 0d                	add    BYTE PTR [di],cl
     32d:	44                   	inc    sp
     32e:	61                   	popa
     32f:	74 61                	je     0x392
     331:	53                   	push   bx
     332:	6f                   	outs   dx,WORD PTR ds:[si]
     333:	75 72                	jne    0x3a7
     335:	63 65 43             	arpl   WORD PTR [di+0x43],sp
     338:	50                   	push   ax
     339:	32 a4 01 0c          	xor    ah,BYTE PTR [si+0xc01]
     33d:	00 0a                	add    BYTE PTR [bp+si],cl
     33f:	50                   	push   ax
     340:	61                   	popa
     341:	6e                   	outs   dx,BYTE PTR ds:[si]
     342:	65 6c                	gs ins BYTE PTR es:[di],dx
     344:	4c                   	dec    sp
     345:	4f                   	dec    di
     346:	55                   	push   bp
     347:	50                   	push   ax
     348:	45                   	inc    bp
     349:	a8 01                	test   al,0x1
     34b:	18 00                	sbb    BYTE PTR [bx+si],al
     34d:	09 47 72             	or     WORD PTR [bx+0x72],ax
     350:	6f                   	outs   dx,WORD PTR ds:[si]
     351:	75 70                	jne    0x3c3
     353:	42                   	inc    dx
     354:	6f                   	outs   dx,WORD PTR ds:[si]
     355:	78 32                	js     0x389
     357:	ac                   	lods   al,BYTE PTR ds:[si]
     358:	01 18                	add    WORD PTR [bx+si],bx
     35a:	00 09                	add    BYTE PTR [bx+di],cl
     35c:	47                   	inc    di
     35d:	72 6f                	jb     0x3ce
     35f:	75 70                	jne    0x3d1
     361:	42                   	inc    dx
     362:	6f                   	outs   dx,WORD PTR ds:[si]
     363:	78 33                	js     0x398
     365:	b0 01                	mov    al,0x1
     367:	18 00                	sbb    BYTE PTR [bx+si],al
     369:	09 47 72             	or     WORD PTR [bx+0x72],ax
     36c:	6f                   	outs   dx,WORD PTR ds:[si]
     36d:	75 70                	jne    0x3df
     36f:	42                   	inc    dx
     370:	6f                   	outs   dx,WORD PTR ds:[si]
     371:	78 34                	js     0x3a7
     373:	b4 01                	mov    ah,0x1
     375:	0c 00                	or     al,0x0
     377:	06                   	push   es
     378:	50                   	push   ax
     379:	61                   	popa
     37a:	6e                   	outs   dx,BYTE PTR ds:[si]
     37b:	65 6c                	gs ins BYTE PTR es:[di],dx
     37d:	31 b8 01 0c          	xor    WORD PTR [bx+si+0xc01],di
     381:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     385:	6e                   	outs   dx,BYTE PTR ds:[si]
     386:	65 6c                	gs ins BYTE PTR es:[di],dx
     388:	36 bc 01 0c          	ss mov sp,0xc01
     38c:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     390:	6e                   	outs   dx,BYTE PTR ds:[si]
     391:	65 6c                	gs ins BYTE PTR es:[di],dx
     393:	37                   	aaa
     394:	c0 01 0c             	rol    BYTE PTR [bx+di],0xc
     397:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     39b:	6e                   	outs   dx,BYTE PTR ds:[si]
     39c:	65 6c                	gs ins BYTE PTR es:[di],dx
     39e:	38 c4                	cmp    ah,al
     3a0:	01 0c                	add    WORD PTR [si],cx
     3a2:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     3a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     3a7:	65 6c                	gs ins BYTE PTR es:[di],dx
     3a9:	39 c8                	cmp    ax,cx
     3ab:	01 0c                	add    WORD PTR [si],cx
     3ad:	00 07                	add    BYTE PTR [bx],al
     3af:	50                   	push   ax
     3b0:	61                   	popa
     3b1:	6e                   	outs   dx,BYTE PTR ds:[si]
     3b2:	65 6c                	gs ins BYTE PTR es:[di],dx
     3b4:	31 30                	xor    WORD PTR [bx+si],si
     3b6:	cc                   	int3
     3b7:	01 0c                	add    WORD PTR [si],cx
     3b9:	00 07                	add    BYTE PTR [bx],al
     3bb:	50                   	push   ax
     3bc:	61                   	popa
     3bd:	6e                   	outs   dx,BYTE PTR ds:[si]
     3be:	65 6c                	gs ins BYTE PTR es:[di],dx
     3c0:	31 31                	xor    WORD PTR [bx+di],si
     3c2:	d0 01                	rol    BYTE PTR [bx+di],1
     3c4:	0c 00                	or     al,0x0
     3c6:	07                   	pop    es
     3c7:	50                   	push   ax
     3c8:	61                   	popa
     3c9:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ca:	65 6c                	gs ins BYTE PTR es:[di],dx
     3cc:	31 32                	xor    WORD PTR [bp+si],si
     3ce:	d4 01                	aam    0x1
     3d0:	0c 00                	or     al,0x0
     3d2:	07                   	pop    es
     3d3:	50                   	push   ax
     3d4:	61                   	popa
     3d5:	6e                   	outs   dx,BYTE PTR ds:[si]
     3d6:	65 6c                	gs ins BYTE PTR es:[di],dx
     3d8:	31 33                	xor    WORD PTR [bp+di],si
     3da:	d8 01                	fadd   DWORD PTR [bx+di]
     3dc:	1c 00                	sbb    al,0x0
     3de:	08 44 42             	or     BYTE PTR [si+0x42],al
     3e1:	45                   	inc    bp
     3e2:	64 69 74 31 33 dc    	imul   si,WORD PTR fs:[si+0x31],0xdc33
     3e8:	01 1c                	add    WORD PTR [si],bx
     3ea:	00 08                	add    BYTE PTR [bx+si],cl
     3ec:	44                   	inc    sp
     3ed:	42                   	inc    dx
     3ee:	45                   	inc    bp
     3ef:	64 69 74 31 35 e0    	imul   si,WORD PTR fs:[si+0x31],0xe035
     3f5:	01 1c                	add    WORD PTR [si],bx
     3f7:	00 08                	add    BYTE PTR [bx+si],cl
     3f9:	44                   	inc    sp
     3fa:	42                   	inc    dx
     3fb:	45                   	inc    bp
     3fc:	64 69 74 31 37 e4    	imul   si,WORD PTR fs:[si+0x31],0xe437
     402:	01 1c                	add    WORD PTR [si],bx
     404:	00 08                	add    BYTE PTR [bx+si],cl
     406:	44                   	inc    sp
     407:	42                   	inc    dx
     408:	45                   	inc    bp
     409:	64 69 74 31 39 e8    	imul   si,WORD PTR fs:[si+0x31],0xe839
     40f:	01 1c                	add    WORD PTR [si],bx
     411:	00 08                	add    BYTE PTR [bx+si],cl
     413:	44                   	inc    sp
     414:	42                   	inc    dx
     415:	45                   	inc    bp
     416:	64 69 74 32 31 ec    	imul   si,WORD PTR fs:[si+0x32],0xec31
     41c:	01 1c                	add    WORD PTR [si],bx
     41e:	00 08                	add    BYTE PTR [bx+si],cl
     420:	44                   	inc    sp
     421:	42                   	inc    dx
     422:	45                   	inc    bp
     423:	64 69 74 32 33 f0    	imul   si,WORD PTR fs:[si+0x32],0xf033
     429:	01 1c                	add    WORD PTR [si],bx
     42b:	00 08                	add    BYTE PTR [bx+si],cl
     42d:	44                   	inc    sp
     42e:	42                   	inc    dx
     42f:	45                   	inc    bp
     430:	64 69 74 32 35 f4    	imul   si,WORD PTR fs:[si+0x32],0xf435
     436:	01 1c                	add    WORD PTR [si],bx
     438:	00 08                	add    BYTE PTR [bx+si],cl
     43a:	44                   	inc    sp
     43b:	42                   	inc    dx
     43c:	45                   	inc    bp
     43d:	64 69 74 32 38 f8    	imul   si,WORD PTR fs:[si+0x32],0xf838
     443:	01 1c                	add    WORD PTR [si],bx
     445:	00 08                	add    BYTE PTR [bx+si],cl
     447:	44                   	inc    sp
     448:	42                   	inc    dx
     449:	45                   	inc    bp
     44a:	64 69 74 32 36 fc    	imul   si,WORD PTR fs:[si+0x32],0xfc36
     450:	01 1c                	add    WORD PTR [si],bx
     452:	00 08                	add    BYTE PTR [bx+si],cl
     454:	44                   	inc    sp
     455:	42                   	inc    dx
     456:	45                   	inc    bp
     457:	64 69 74 32 34 00    	imul   si,WORD PTR fs:[si+0x32],0x34
     45d:	02 1c                	add    bl,BYTE PTR [si]
     45f:	00 08                	add    BYTE PTR [bx+si],cl
     461:	44                   	inc    sp
     462:	42                   	inc    dx
     463:	45                   	inc    bp
     464:	64 69 74 32 32 04    	imul   si,WORD PTR fs:[si+0x32],0x432
     46a:	02 1c                	add    bl,BYTE PTR [si]
     46c:	00 08                	add    BYTE PTR [bx+si],cl
     46e:	44                   	inc    sp
     46f:	42                   	inc    dx
     470:	45                   	inc    bp
     471:	64 69 74 32 30 08    	imul   si,WORD PTR fs:[si+0x32],0x830
     477:	02 1c                	add    bl,BYTE PTR [si]
     479:	00 08                	add    BYTE PTR [bx+si],cl
     47b:	44                   	inc    sp
     47c:	42                   	inc    dx
     47d:	45                   	inc    bp
     47e:	64 69 74 31 38 0c    	imul   si,WORD PTR fs:[si+0x31],0xc38
     484:	02 1c                	add    bl,BYTE PTR [si]
     486:	00 08                	add    BYTE PTR [bx+si],cl
     488:	44                   	inc    sp
     489:	42                   	inc    dx
     48a:	45                   	inc    bp
     48b:	64 69 74 31 36 10    	imul   si,WORD PTR fs:[si+0x31],0x1036
     491:	02 1c                	add    bl,BYTE PTR [si]
     493:	00 08                	add    BYTE PTR [bx+si],cl
     495:	44                   	inc    sp
     496:	42                   	inc    dx
     497:	45                   	inc    bp
     498:	64 69 74 31 34 14    	imul   si,WORD PTR fs:[si+0x31],0x1434
     49e:	02 0c                	add    cl,BYTE PTR [si]
     4a0:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     4a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a5:	65 6c                	gs ins BYTE PTR es:[di],dx
     4a7:	35 18 02             	xor    ax,0x218
     4aa:	18 00                	sbb    BYTE PTR [bx+si],al
     4ac:	09 47 72             	or     WORD PTR [bx+0x72],ax
     4af:	6f                   	outs   dx,WORD PTR ds:[si]
     4b0:	75 70                	jne    0x522
     4b2:	42                   	inc    dx
     4b3:	6f                   	outs   dx,WORD PTR ds:[si]
     4b4:	78 35                	js     0x4eb
     4b6:	1c 02                	sbb    al,0x2
     4b8:	0c 00                	or     al,0x0
     4ba:	07                   	pop    es
     4bb:	50                   	push   ax
     4bc:	61                   	popa
     4bd:	6e                   	outs   dx,BYTE PTR ds:[si]
     4be:	65 6c                	gs ins BYTE PTR es:[di],dx
     4c0:	31 35                	xor    WORD PTR [di],si
     4c2:	20 02                	and    BYTE PTR [bp+si],al
     4c4:	10 00                	adc    BYTE PTR [bx+si],al
     4c6:	06                   	push   es
     4c7:	4c                   	dec    sp
     4c8:	61                   	popa
     4c9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4cc:	36 24 02             	ss and al,0x2
     4cf:	1c 00                	sbb    al,0x0
     4d1:	07                   	pop    es
     4d2:	44                   	inc    sp
     4d3:	42                   	inc    dx
     4d4:	45                   	inc    bp
     4d5:	64 69 74 35 28 02    	imul   si,WORD PTR fs:[si+0x35],0x228
     4db:	1c 00                	sbb    al,0x0
     4dd:	07                   	pop    es
     4de:	44                   	inc    sp
     4df:	42                   	inc    dx
     4e0:	45                   	inc    bp
     4e1:	64 69 74 37 2c 02    	imul   si,WORD PTR fs:[si+0x37],0x22c
     4e7:	20 00                	and    BYTE PTR [bx+si],al
     4e9:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     4ec:	6d                   	ins    WORD PTR es:[di],dx
     4ed:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     4f0:	6f                   	outs   dx,WORD PTR ds:[si]
     4f1:	78 32                	js     0x525
     4f3:	30 02                	xor    BYTE PTR [bp+si],al
     4f5:	1c 00                	sbb    al,0x0
     4f7:	07                   	pop    es
     4f8:	44                   	inc    sp
     4f9:	42                   	inc    dx
     4fa:	45                   	inc    bp
     4fb:	64 69 74 39 34 02    	imul   si,WORD PTR fs:[si+0x39],0x234
     501:	0c 00                	or     al,0x0
     503:	07                   	pop    es
     504:	50                   	push   ax
     505:	61                   	popa
     506:	6e                   	outs   dx,BYTE PTR ds:[si]
     507:	65 6c                	gs ins BYTE PTR es:[di],dx
     509:	31 34                	xor    WORD PTR [si],si
     50b:	38 02                	cmp    BYTE PTR [bp+si],al
     50d:	10 00                	adc    BYTE PTR [bx+si],al
     50f:	06                   	push   es
     510:	4c                   	dec    sp
     511:	61                   	popa
     512:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     515:	35 3c 02             	xor    ax,0x23c
     518:	1c 00                	sbb    al,0x0
     51a:	07                   	pop    es
     51b:	44                   	inc    sp
     51c:	42                   	inc    dx
     51d:	45                   	inc    bp
     51e:	64 69 74 34 40 02    	imul   si,WORD PTR fs:[si+0x34],0x240
     524:	1c 00                	sbb    al,0x0
     526:	07                   	pop    es
     527:	44                   	inc    sp
     528:	42                   	inc    dx
     529:	45                   	inc    bp
     52a:	64 69 74 36 44 02    	imul   si,WORD PTR fs:[si+0x36],0x244
     530:	20 00                	and    BYTE PTR [bx+si],al
     532:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     535:	6d                   	ins    WORD PTR es:[di],dx
     536:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     539:	6f                   	outs   dx,WORD PTR ds:[si]
     53a:	78 31                	js     0x56d
     53c:	48                   	dec    ax
     53d:	02 1c                	add    bl,BYTE PTR [si]
     53f:	00 07                	add    BYTE PTR [bx],al
     541:	44                   	inc    sp
     542:	42                   	inc    dx
     543:	45                   	inc    bp
     544:	64 69 74 38 4c 02    	imul   si,WORD PTR fs:[si+0x38],0x24c
     54a:	18 00                	sbb    BYTE PTR [bx+si],al
     54c:	09 47 72             	or     WORD PTR [bx+0x72],ax
     54f:	6f                   	outs   dx,WORD PTR ds:[si]
     550:	75 70                	jne    0x5c2
     552:	42                   	inc    dx
     553:	6f                   	outs   dx,WORD PTR ds:[si]
     554:	78 36                	js     0x58c
     556:	50                   	push   ax
     557:	02 24                	add    ah,BYTE PTR [si]
     559:	00 05                	add    BYTE PTR [di],al
     55b:	4d                   	dec    bp
     55c:	65 6d                	gs ins WORD PTR es:[di],dx
     55e:	6f                   	outs   dx,WORD PTR ds:[si]
     55f:	31 54 02             	xor    WORD PTR [si+0x2],dx
     562:	28 00                	sub    BYTE PTR [bx+si],al
     564:	0a 50 6f             	or     dl,BYTE PTR [bx+si+0x6f]
     567:	70 75                	jo     0x5de
     569:	70 4d                	jo     0x5b8
     56b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     56d:	75 31                	jne    0x5a0
     56f:	58                   	pop    ax
     570:	02 2c                	add    ch,BYTE PTR [si]
     572:	00 06 50 72          	add    BYTE PTR ds:0x7250,al
     576:	69 6e 74 31 5c       	imul   bp,WORD PTR [bp+0x74],0x5c31
     57b:	02 2c                	add    ch,BYTE PTR [si]
     57d:	00 05                	add    BYTE PTR [di],al
     57f:	43                   	inc    bx
     580:	6f                   	outs   dx,WORD PTR ds:[si]
     581:	70 79                	jo     0x5fc
     583:	31 60 02             	xor    WORD PTR [bx+si+0x2],sp
     586:	30 00                	xor    BYTE PTR [bx+si],al
     588:	06                   	push   es
     589:	49                   	dec    cx
     58a:	6d                   	ins    WORD PTR es:[di],dx
     58b:	61                   	popa
     58c:	67 65 31 64 02 34    	xor    WORD PTR gs:[edx+eax*1+0x34],sp
     592:	00 07                	add    BYTE PTR [bx],al
     594:	54                   	push   sp
     595:	65 73 74             	gs jae 0x60c
     598:	42                   	inc    dx
     599:	74 6e                	je     0x609
     59b:	68 02 0c             	push   0xc02
     59e:	00 07                	add    BYTE PTR [bx],al
     5a0:	50                   	push   ax
     5a1:	61                   	popa
     5a2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5a3:	65 6c                	gs ins BYTE PTR es:[di],dx
     5a5:	31 36 6c 02          	xor    WORD PTR ds:0x26c,si
     5a9:	1c 00                	sbb    al,0x0
     5ab:	07                   	pop    es
     5ac:	44                   	inc    sp
     5ad:	42                   	inc    dx
     5ae:	45                   	inc    bp
     5af:	64 69 74 32 70 02    	imul   si,WORD PTR fs:[si+0x32],0x270
     5b5:	0c 00                	or     al,0x0
     5b7:	07                   	pop    es
     5b8:	50                   	push   ax
     5b9:	61                   	popa
     5ba:	6e                   	outs   dx,BYTE PTR ds:[si]
     5bb:	65 6c                	gs ins BYTE PTR es:[di],dx
     5bd:	31 38                	xor    WORD PTR [bx+si],di
     5bf:	74 02                	je     0x5c3
     5c1:	1c 00                	sbb    al,0x0
     5c3:	08 44 42             	or     BYTE PTR [si+0x42],al
     5c6:	45                   	inc    bp
     5c7:	64 69 74 31 30 78    	imul   si,WORD PTR fs:[si+0x31],0x7830
     5cd:	02 0c                	add    cl,BYTE PTR [si]
     5cf:	00 07                	add    BYTE PTR [bx],al
     5d1:	50                   	push   ax
     5d2:	61                   	popa
     5d3:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d4:	65 6c                	gs ins BYTE PTR es:[di],dx
     5d6:	31 39                	xor    WORD PTR [bx+di],di
     5d8:	7c 02                	jl     0x5dc
     5da:	1c 00                	sbb    al,0x0
     5dc:	07                   	pop    es
     5dd:	44                   	inc    sp
     5de:	42                   	inc    dx
     5df:	45                   	inc    bp
     5e0:	64 69 74 33 80 02    	imul   si,WORD PTR fs:[si+0x33],0x280
     5e6:	0c 00                	or     al,0x0
     5e8:	07                   	pop    es
     5e9:	50                   	push   ax
     5ea:	61                   	popa
     5eb:	6e                   	outs   dx,BYTE PTR ds:[si]
     5ec:	65 6c                	gs ins BYTE PTR es:[di],dx
     5ee:	32 30                	xor    dh,BYTE PTR [bx+si]
     5f0:	84 02                	test   BYTE PTR [bp+si],al
     5f2:	1c 00                	sbb    al,0x0
     5f4:	08 44 42             	or     BYTE PTR [si+0x42],al
     5f7:	45                   	inc    bp
     5f8:	64 69 74 31 31 88    	imul   si,WORD PTR fs:[si+0x31],0x8831
     5fe:	02 0c                	add    cl,BYTE PTR [si]
     600:	00 07                	add    BYTE PTR [bx],al
     602:	50                   	push   ax
     603:	61                   	popa
     604:	6e                   	outs   dx,BYTE PTR ds:[si]
     605:	65 6c                	gs ins BYTE PTR es:[di],dx
     607:	32 31                	xor    dh,BYTE PTR [bx+di]
     609:	8c 02                	mov    WORD PTR [bp+si],es
     60b:	1c 00                	sbb    al,0x0
     60d:	08 44 42             	or     BYTE PTR [si+0x42],al
     610:	45                   	inc    bp
     611:	64 69 74 31 32 90    	imul   si,WORD PTR fs:[si+0x31],0x9032
     617:	02 0c                	add    cl,BYTE PTR [si]
     619:	00 07                	add    BYTE PTR [bx],al
     61b:	50                   	push   ax
     61c:	61                   	popa
     61d:	6e                   	outs   dx,BYTE PTR ds:[si]
     61e:	65 6c                	gs ins BYTE PTR es:[di],dx
     620:	32 32                	xor    dh,BYTE PTR [bp+si]
     622:	94                   	xchg   sp,ax
     623:	02 0c                	add    cl,BYTE PTR [si]
     625:	00 07                	add    BYTE PTR [bx],al
     627:	50                   	push   ax
     628:	61                   	popa
     629:	6e                   	outs   dx,BYTE PTR ds:[si]
     62a:	65 6c                	gs ins BYTE PTR es:[di],dx
     62c:	32 33                	xor    dh,BYTE PTR [bp+di]
     62e:	98                   	cbw
     62f:	02 0c                	add    cl,BYTE PTR [si]
     631:	00 07                	add    BYTE PTR [bx],al
     633:	50                   	push   ax
     634:	61                   	popa
     635:	6e                   	outs   dx,BYTE PTR ds:[si]
     636:	65 6c                	gs ins BYTE PTR es:[di],dx
     638:	32 34                	xor    dh,BYTE PTR [si]
     63a:	9c                   	pushf
     63b:	02 0c                	add    cl,BYTE PTR [si]
     63d:	00 07                	add    BYTE PTR [bx],al
     63f:	50                   	push   ax
     640:	61                   	popa
     641:	6e                   	outs   dx,BYTE PTR ds:[si]
     642:	65 6c                	gs ins BYTE PTR es:[di],dx
     644:	32 35                	xor    dh,BYTE PTR [di]
     646:	a0 02 10             	mov    al,ds:0x1002
     649:	00 07                	add    BYTE PTR [bx],al
     64b:	4c                   	dec    sp
     64c:	61                   	popa
     64d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     650:	31 30                	xor    WORD PTR [bx+si],si
     652:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     653:	02 0c                	add    cl,BYTE PTR [si]
     655:	00 07                	add    BYTE PTR [bx],al
     657:	50                   	push   ax
     658:	61                   	popa
     659:	6e                   	outs   dx,BYTE PTR ds:[si]
     65a:	65 6c                	gs ins BYTE PTR es:[di],dx
     65c:	32 36 a8 02          	xor    dh,BYTE PTR ds:0x2a8
     660:	10 00                	adc    BYTE PTR [bx+si],al
     662:	07                   	pop    es
     663:	4c                   	dec    sp
     664:	61                   	popa
     665:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     668:	31 31                	xor    WORD PTR [bx+di],si
     66a:	ac                   	lods   al,BYTE PTR ds:[si]
     66b:	02 38                	add    bh,BYTE PTR [bx+si]
     66d:	00 07                	add    BYTE PTR [bx],al
     66f:	45                   	inc    bp
     670:	64 69 74 4e 69 76    	imul   si,WORD PTR fs:[si+0x4e],0x7669
     676:	b0 02                	mov    al,0x2
     678:	0c 00                	or     al,0x0
     67a:	07                   	pop    es
     67b:	50                   	push   ax
     67c:	61                   	popa
     67d:	6e                   	outs   dx,BYTE PTR ds:[si]
     67e:	65 6c                	gs ins BYTE PTR es:[di],dx
     680:	31 37                	xor    WORD PTR [bx],si
     682:	b4 02                	mov    ah,0x2
     684:	3c 00                	cmp    al,0x0
     686:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     689:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     68e:	74 31                	je     0x6c1
     690:	b8 02 1c             	mov    ax,0x1c02
     693:	00 07                	add    BYTE PTR [bx],al
     695:	44                   	inc    sp
     696:	42                   	inc    dx
     697:	45                   	inc    bp
     698:	64 69 74 31 bc 02    	imul   si,WORD PTR fs:[si+0x31],0x2bc
     69e:	18 00                	sbb    BYTE PTR [bx+si],al
     6a0:	09 47 72             	or     WORD PTR [bx+0x72],ax
     6a3:	6f                   	outs   dx,WORD PTR ds:[si]
     6a4:	75 70                	jne    0x716
     6a6:	42                   	inc    dx
     6a7:	6f                   	outs   dx,WORD PTR ds:[si]
     6a8:	78 31                	js     0x6db
     6aa:	c0 02 0c             	rol    BYTE PTR [bp+si],0xc
     6ad:	00 07                	add    BYTE PTR [bx],al
     6af:	50                   	push   ax
     6b0:	61                   	popa
     6b1:	6e                   	outs   dx,BYTE PTR ds:[si]
     6b2:	65 6c                	gs ins BYTE PTR es:[di],dx
     6b4:	32 37                	xor    dh,BYTE PTR [bx]
     6b6:	c4 02                	les    ax,DWORD PTR [bp+si]
     6b8:	10 00                	adc    BYTE PTR [bx+si],al
     6ba:	06                   	push   es
     6bb:	4c                   	dec    sp
     6bc:	61                   	popa
     6bd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6c0:	31 c8                	xor    ax,cx
     6c2:	02 0c                	add    cl,BYTE PTR [si]
     6c4:	00 07                	add    BYTE PTR [bx],al
     6c6:	50                   	push   ax
     6c7:	61                   	popa
     6c8:	6e                   	outs   dx,BYTE PTR ds:[si]
     6c9:	65 6c                	gs ins BYTE PTR es:[di],dx
     6cb:	32 39                	xor    bh,BYTE PTR [bx+di]
     6cd:	cc                   	int3
     6ce:	02 10                	add    dl,BYTE PTR [bx+si]
     6d0:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     6d4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6d7:	33 d0                	xor    dx,ax
     6d9:	02 0c                	add    cl,BYTE PTR [si]
     6db:	00 07                	add    BYTE PTR [bx],al
     6dd:	50                   	push   ax
     6de:	61                   	popa
     6df:	6e                   	outs   dx,BYTE PTR ds:[si]
     6e0:	65 6c                	gs ins BYTE PTR es:[di],dx
     6e2:	33 30                	xor    si,WORD PTR [bx+si]
     6e4:	d4 02                	aam    0x2
     6e6:	3c 00                	cmp    al,0x0
     6e8:	0a 53 70             	or     dl,BYTE PTR [bp+di+0x70]
     6eb:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     6f0:	74 50                	je     0x742
     6f2:	31 d8                	xor    ax,bx
     6f4:	02 3c                	add    bh,BYTE PTR [si]
     6f6:	00 0a                	add    BYTE PTR [bp+si],cl
     6f8:	53                   	push   bx
     6f9:	70 69                	jo     0x764
     6fb:	6e                   	outs   dx,BYTE PTR ds:[si]
     6fc:	45                   	inc    bp
     6fd:	64 69 74 50 32 dc    	imul   si,WORD PTR fs:[si+0x50],0xdc32
     703:	02 0c                	add    cl,BYTE PTR [si]
     705:	00 07                	add    BYTE PTR [bx],al
     707:	50                   	push   ax
     708:	61                   	popa
     709:	6e                   	outs   dx,BYTE PTR ds:[si]
     70a:	65 6c                	gs ins BYTE PTR es:[di],dx
     70c:	32 38                	xor    bh,BYTE PTR [bx+si]
     70e:	e0 02                	loopne 0x712
     710:	38 00                	cmp    BYTE PTR [bx+si],al
     712:	05 45 64             	add    ax,0x6445
     715:	69 74 31 e4 02       	imul   si,WORD PTR [si+0x31],0x2e4
     71a:	0c 00                	or     al,0x0
     71c:	07                   	pop    es
     71d:	50                   	push   ax
     71e:	61                   	popa
     71f:	6e                   	outs   dx,BYTE PTR ds:[si]
     720:	65 6c                	gs ins BYTE PTR es:[di],dx
     722:	36 36 e8 02 0c       	ss ss call 0x1329
     727:	00 07                	add    BYTE PTR [bx],al
     729:	50                   	push   ax
     72a:	61                   	popa
     72b:	6e                   	outs   dx,BYTE PTR ds:[si]
     72c:	65 6c                	gs ins BYTE PTR es:[di],dx
     72e:	33 31                	xor    si,WORD PTR [bx+di]
     730:	ec                   	in     al,dx
     731:	02 0c                	add    cl,BYTE PTR [si]
     733:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     737:	6e                   	outs   dx,BYTE PTR ds:[si]
     738:	65 6c                	gs ins BYTE PTR es:[di],dx
     73a:	33 f0                	xor    si,ax
     73c:	02 34                	add    dh,BYTE PTR [si]
     73e:	00 09                	add    BYTE PTR [bx+di],cl
     740:	44                   	inc    sp
     741:	65 66 61             	gs popad
     744:	75 74                	jne    0x7ba
     746:	42                   	inc    dx
     747:	74 6e                	je     0x7b7
     749:	f4                   	hlt
     74a:	02 34                	add    dh,BYTE PTR [si]
     74c:	00 0a                	add    BYTE PTR [bp+si],cl
     74e:	49                   	dec    cx
     74f:	6e                   	outs   dx,BYTE PTR ds:[si]
     750:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     755:	42                   	inc    dx
     756:	74 6e                	je     0x7c6
     758:	f8                   	clc
     759:	02 34                	add    dh,BYTE PTR [si]
     75b:	00 0a                	add    BYTE PTR [bp+si],cl
     75d:	42                   	inc    dx
     75e:	61                   	popa
     75f:	73 63                	jae    0x7c4
     761:	75 6c                	jne    0x7cf
     763:	65 42                	gs inc dx
     765:	74 6e                	je     0x7d5
     767:	fc                   	cld
     768:	02 0c                	add    cl,BYTE PTR [si]
     76a:	00 07                	add    BYTE PTR [bx],al
     76c:	50                   	push   ax
     76d:	61                   	popa
     76e:	6e                   	outs   dx,BYTE PTR ds:[si]
     76f:	65 6c                	gs ins BYTE PTR es:[di],dx
     771:	33 32                	xor    si,WORD PTR [bp+si]
     773:	00 03                	add    BYTE PTR [bp+di],al
     775:	0c 00                	or     al,0x0
     777:	06                   	push   es
     778:	50                   	push   ax
     779:	61                   	popa
     77a:	6e                   	outs   dx,BYTE PTR ds:[si]
     77b:	65 6c                	gs ins BYTE PTR es:[di],dx
     77d:	34 04                	xor    al,0x4
     77f:	03 40 00             	add    ax,WORD PTR [bx+si+0x0]
     782:	0a 43 68             	or     al,BYTE PTR [bp+di+0x68]
     785:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     789:	6f                   	outs   dx,WORD PTR ds:[si]
     78a:	78 56                	js     0x7e2
     78c:	31 08                	xor    WORD PTR [bx+si],cx
     78e:	03 34                	add    si,WORD PTR [si]
     790:	00 0b                	add    BYTE PTR [bp+di],cl
     792:	56                   	push   si
     793:	65 72 69             	gs jb  0x7ff
     796:	66 69 65 72 42 74 6e 	imul   esp,DWORD PTR [di+0x72],0xc6e7442
     79d:	0c 
     79e:	03 34                	add    si,WORD PTR [si]
     7a0:	00 05                	add    BYTE PTR [di],al
     7a2:	4f                   	dec    di
     7a3:	4b                   	dec    bx
     7a4:	42                   	inc    dx
     7a5:	74 6e                	je     0x815
     7a7:	10 03                	adc    BYTE PTR [bp+di],al
     7a9:	34 00                	xor    al,0x0
     7ab:	08 50 72             	or     BYTE PTR [bx+si+0x72],dl
     7ae:	69 6e 74 42 74       	imul   bp,WORD PTR [bp+0x74],0x7442
     7b3:	6e                   	outs   dx,BYTE PTR ds:[si]
     7b4:	14 03                	adc    al,0x3
     7b6:	34 00                	xor    al,0x0
     7b8:	07                   	pop    es
     7b9:	48                   	dec    ax
     7ba:	65 6c                	gs ins BYTE PTR es:[di],dx
     7bc:	70 42                	jo     0x800
     7be:	74 6e                	je     0x82e
     7c0:	18 03                	sbb    BYTE PTR [bp+di],al
     7c2:	34 00                	xor    al,0x0
     7c4:	09 43 6f             	or     WORD PTR [bp+di+0x6f],ax
     7c7:	70 69                	jo     0x832
     7c9:	65 72 42             	gs jb  0x80e
     7cc:	74 6e                	je     0x83c
     7ce:	1c 03                	sbb    al,0x3
     7d0:	34 00                	xor    al,0x0
     7d2:	0e                   	push   cs
     7d3:	50                   	push   ax
     7d4:	72 69                	jb     0x83f
     7d6:	6e                   	outs   dx,BYTE PTR ds:[si]
     7d7:	74 52                	je     0x82b
     7d9:	61                   	popa
     7da:	70 69                	jo     0x845
     7dc:	64 65 42             	fs gs inc dx
     7df:	74 6e                	je     0x84f
     7e1:	20 03                	and    BYTE PTR [bp+di],al
     7e3:	34 00                	xor    al,0x0
     7e5:	09 43 61             	or     WORD PTR [bp+di+0x61],ax
     7e8:	6e                   	outs   dx,BYTE PTR ds:[si]
     7e9:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     7ec:	42                   	inc    dx
     7ed:	74 6e                	je     0x85d
     7ef:	24 03                	and    al,0x3
     7f1:	10 00                	adc    BYTE PTR [bx+si],al
     7f3:	06                   	push   es
     7f4:	4c                   	dec    sp
     7f5:	61                   	popa
     7f6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7f9:	32 28                	xor    ch,BYTE PTR [bx+si]
     7fb:	03 0c                	add    cx,WORD PTR [si]
     7fd:	00 07                	add    BYTE PTR [bx],al
     7ff:	50                   	push   ax
     800:	61                   	popa
     801:	6e                   	outs   dx,BYTE PTR ds:[si]
     802:	65 6c                	gs ins BYTE PTR es:[di],dx
     804:	33 33                	xor    si,WORD PTR [bp+di]
     806:	2c 03                	sub    al,0x3
     808:	0c 00                	or     al,0x0
     80a:	07                   	pop    es
     80b:	50                   	push   ax
     80c:	61                   	popa
     80d:	6e                   	outs   dx,BYTE PTR ds:[si]
     80e:	65 6c                	gs ins BYTE PTR es:[di],dx
     810:	33 34                	xor    si,WORD PTR [si]
     812:	30 03                	xor    BYTE PTR [bp+di],al
     814:	0c 00                	or     al,0x0
     816:	07                   	pop    es
     817:	50                   	push   ax
     818:	61                   	popa
     819:	6e                   	outs   dx,BYTE PTR ds:[si]
     81a:	65 6c                	gs ins BYTE PTR es:[di],dx
     81c:	33 35                	xor    si,WORD PTR [di]
     81e:	34 03                	xor    al,0x3
     820:	1c 00                	sbb    al,0x0
     822:	08 44 42             	or     BYTE PTR [si+0x42],al
     825:	45                   	inc    bp
     826:	64 69 74 32 37 38    	imul   si,WORD PTR fs:[si+0x32],0x3837
     82c:	03 1c                	add    bx,WORD PTR [si]
     82e:	00 08                	add    BYTE PTR [bx+si],cl
     830:	44                   	inc    sp
     831:	42                   	inc    dx
     832:	45                   	inc    bp
     833:	64 69 74 32 39 3c    	imul   si,WORD PTR fs:[si+0x32],0x3c39
     839:	03 1c                	add    bx,WORD PTR [si]
     83b:	00 08                	add    BYTE PTR [bx+si],cl
     83d:	44                   	inc    sp
     83e:	42                   	inc    dx
     83f:	45                   	inc    bp
     840:	64 69 74 33 30 40    	imul   si,WORD PTR fs:[si+0x33],0x4030
     846:	03 1c                	add    bx,WORD PTR [si]
     848:	00 08                	add    BYTE PTR [bx+si],cl
     84a:	44                   	inc    sp
     84b:	42                   	inc    dx
     84c:	45                   	inc    bp
     84d:	64 69 74 33 31 44    	imul   si,WORD PTR fs:[si+0x33],0x4431
     853:	03 1c                	add    bx,WORD PTR [si]
     855:	00 08                	add    BYTE PTR [bx+si],cl
     857:	44                   	inc    sp
     858:	42                   	inc    dx
     859:	45                   	inc    bp
     85a:	64 69 74 33 32 48    	imul   si,WORD PTR fs:[si+0x33],0x4832
     860:	03 1c                	add    bx,WORD PTR [si]
     862:	00 08                	add    BYTE PTR [bx+si],cl
     864:	44                   	inc    sp
     865:	42                   	inc    dx
     866:	45                   	inc    bp
     867:	64 69 74 33 34 4c    	imul   si,WORD PTR fs:[si+0x33],0x4c34
     86d:	03 0c                	add    cx,WORD PTR [si]
     86f:	00 07                	add    BYTE PTR [bx],al
     871:	50                   	push   ax
     872:	61                   	popa
     873:	6e                   	outs   dx,BYTE PTR ds:[si]
     874:	65 6c                	gs ins BYTE PTR es:[di],dx
     876:	33 36 50 03          	xor    si,WORD PTR ds:0x350
     87a:	3c 00                	cmp    al,0x0
     87c:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     87f:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     884:	74 32                	je     0x8b8
     886:	54                   	push   sp
     887:	03 1c                	add    bx,WORD PTR [si]
     889:	00 08                	add    BYTE PTR [bx+si],cl
     88b:	44                   	inc    sp
     88c:	42                   	inc    dx
     88d:	45                   	inc    bp
     88e:	64 69 74 33 35 58    	imul   si,WORD PTR fs:[si+0x33],0x5835
     894:	03 20                	add    sp,WORD PTR [bx+si]
     896:	00 09                	add    BYTE PTR [bx+di],cl
     898:	43                   	inc    bx
     899:	6f                   	outs   dx,WORD PTR ds:[si]
     89a:	6d                   	ins    WORD PTR es:[di],dx
     89b:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     89e:	6f                   	outs   dx,WORD PTR ds:[si]
     89f:	78 33                	js     0x8d4
     8a1:	5c                   	pop    sp
     8a2:	03 0c                	add    cx,WORD PTR [si]
     8a4:	00 07                	add    BYTE PTR [bx],al
     8a6:	50                   	push   ax
     8a7:	61                   	popa
     8a8:	6e                   	outs   dx,BYTE PTR ds:[si]
     8a9:	65 6c                	gs ins BYTE PTR es:[di],dx
     8ab:	33 37                	xor    si,WORD PTR [bx]
     8ad:	60                   	pusha
     8ae:	03 1c                	add    bx,WORD PTR [si]
     8b0:	00 08                	add    BYTE PTR [bx+si],cl
     8b2:	44                   	inc    sp
     8b3:	42                   	inc    dx
     8b4:	45                   	inc    bp
     8b5:	64 69 74 33 33 64    	imul   si,WORD PTR fs:[si+0x33],0x6433
     8bb:	03 0c                	add    cx,WORD PTR [si]
     8bd:	00 07                	add    BYTE PTR [bx],al
     8bf:	50                   	push   ax
     8c0:	61                   	popa
     8c1:	6e                   	outs   dx,BYTE PTR ds:[si]
     8c2:	65 6c                	gs ins BYTE PTR es:[di],dx
     8c4:	33 38                	xor    di,WORD PTR [bx+si]
     8c6:	11 00                	adc    WORD PTR [bx+si],ax
     8c8:	ed                   	in     ax,dx
     8c9:	01 ee                	add    si,bp
     8cb:	0a 38                	or     bh,BYTE PTR [bx+si]
     8cd:	01 7d 0d             	add    WORD PTR [di+0xd],di
     8d0:	c8 08 36 09          	enter  0x3608,0x9
     8d4:	ad                   	lods   ax,WORD PTR ds:[si]
     8d5:	0d fa 08             	or     ax,0x8fa
     8d8:	17                   	pop    ss
     8d9:	06                   	push   es
     8da:	e2 08                	loop   0x8e4
     8dc:	7e 08                	jle    0x8e6
     8de:	21 12                	and    WORD PTR [bp+si],dx
     8e0:	0c 01                	or     al,0x1
     8e2:	ea 08 22 00 70       	jmp    0x7000:0x2208
     8e7:	15 14 1b             	adc    ax,0x1b14
     8ea:	ee                   	out    dx,al
     8eb:	08 91 12 02          	or     BYTE PTR [bx+di+0x212],dl
     8ef:	09 c6                	or     si,ax
     8f1:	03 f6                	add    si,si
     8f3:	08 94 00 ff          	or     BYTE PTR [si-0x100],dl
     8f7:	ff 65 06             	jmp    WORD PTR [di+0x6]
     8fa:	10 4a ac             	adc    BYTE PTR [bp+si-0x54],cl
     8fd:	04 21                	add    al,0x21
     8ff:	5c                   	pop    sp
     900:	90                   	nop
     901:	0b 0a                	or     cx,WORD PTR [bp+si]
     903:	09 eb                	or     bx,bp
     905:	03 c9                	add    cx,cx
     907:	14 22                	adc    al,0x22
     909:	27                   	daa
     90a:	69 0d 07 13          	imul   cx,WORD PTR [di],0x1307
     90e:	54                   	push   sp
     90f:	46                   	inc    si
     910:	6f                   	outs   dx,WORD PTR ds:[si]
     911:	72 6d                	jb     0x980
     913:	53                   	push   bx
     914:	43                   	inc    bx
     915:	44                   	inc    sp
     916:	44                   	inc    sp
     917:	5f                   	pop    di
     918:	44                   	inc    sp
     919:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     91d:	69 6f 6e 73 22       	imul   bp,WORD PTR [bx+0x6e],0x2273
     922:	00 3a                	add    BYTE PTR [bp+si],bh
     924:	09 7b 06             	or     WORD PTR [bp+di+0x6],di
     927:	67 09 38             	or     WORD PTR [eax],di
     92a:	00 04                	add    BYTE PTR [si],al
     92c:	53                   	push   bx
     92d:	63 64 64             	arpl   WORD PTR [si+0x64],sp
     930:	00 00                	add    BYTE PTR [bx+si],al
     932:	01 00                	add    WORD PTR [bx+si],ax
     934:	2f                   	das
     935:	00 35                	add    BYTE PTR [di],dh
     937:	11 be 09 40          	adc    WORD PTR [bp+0x4009],di
     93b:	09 00                	or     WORD PTR [bx+si],ax
     93d:	00 dc                	add    ah,bl
     93f:	09 60 09             	or     WORD PTR [bx+si+0x9],sp
     942:	55                   	push   bp
     943:	89 e5                	mov    bp,sp
     945:	b8 0c 01             	mov    ax,0x10c
     948:	9a 44 04 c9 09       	call   0x9c9:0x444
     94d:	81 ec 0c 01          	sub    sp,0x10c
     951:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     955:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     959:	b0 01                	mov    al,0x1
     95b:	50                   	push   ax
     95c:	b8 22 00             	mov    ax,0x22
     95f:	ba 8f 09             	mov    dx,0x98f
     962:	52                   	push   dx
     963:	50                   	push   ax
     964:	9a 53 25 b3 09       	call   0x9b3:0x2553
     969:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     96c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     96f:	b8 3c 09             	mov    ax,0x93c
     972:	0e                   	push   cs
     973:	50                   	push   ax
     974:	55                   	push   bp
     975:	ff 36 58 18          	push   WORD PTR ds:0x1858
     979:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     97d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     980:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     984:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     988:	6a 00                	push   0x0
     98a:	06                   	push   es
     98b:	57                   	push   di
     98c:	9a 6b 0e a8 09       	call   0x9a8:0xe6b
     991:	b8 32 09             	mov    ax,0x932
     994:	0e                   	push   cs
     995:	50                   	push   ax
     996:	55                   	push   bp
     997:	ff 36 58 18          	push   WORD PTR ds:0x1858
     99b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     99f:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     9a3:	06                   	push   es
     9a4:	57                   	push   di
     9a5:	9a bf 2b fa 0a       	call   0xafa:0x2bbf
     9aa:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     9ae:	06                   	push   es
     9af:	57                   	push   di
     9b0:	9a 45 5d e4 09       	call   0x9e4:0x5d45
     9b5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     9b9:	83 c4 06             	add    sp,0x6
     9bc:	eb 12                	jmp    0x9d0
     9be:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
     9c2:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
     9c6:	ea 85 13 ce 09       	jmp    0x9ce:0x1385
     9cb:	9a 34 14 f1 09       	call   0x9f1:0x1434
     9d0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     9d4:	83 c4 06             	add    sp,0x6
     9d7:	b8 e7 09             	mov    ax,0x9e7
     9da:	0e                   	push   cs
     9db:	50                   	push   ax
     9dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     9df:	06                   	push   es
     9e0:	57                   	push   di
     9e1:	9a 1d 5f 0e 0a       	call   0xa0e:0x5f1d
     9e6:	cb                   	retf
     9e7:	c9                   	leave
     9e8:	cb                   	retf
     9e9:	55                   	push   bp
     9ea:	89 e5                	mov    bp,sp
     9ec:	31 c0                	xor    ax,ax
     9ee:	9a 44 04 44 0a       	call   0xa44:0x444
     9f3:	c6 06 8e 04 01       	mov    BYTE PTR ds:0x48e,0x1
     9f8:	6a 00                	push   0x0
     9fa:	9a c2 38 01 0e       	call   0xe01:0x38c2
     9ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a02:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     a09:	06                   	push   es
     a0a:	57                   	push   di
     a0b:	9a 56 55 ce 11       	call   0x11ce:0x5556
     a10:	9a c3 28 c9 0a       	call   0xac9:0x28c3
     a15:	c9                   	leave
     a16:	ca 04 00             	retf   0x4
     a19:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     a1c:	6d                   	ins    WORD PTR es:[di],dx
     a1d:	73 74                	jae    0xa93
     a1f:	72 61                	jb     0xa82
     a21:	74 20                	je     0xa43
     a23:	2d 20 03             	sub    ax,0x320
     a26:	20 2d                	and    BYTE PTR [di],ch
     a28:	20 07                	and    BYTE PTR [bx],al
     a2a:	4e                   	dec    si
     a2b:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
     a30:	20 01                	and    BYTE PTR [bx+di],al
     a32:	2d 00 00             	sub    ax,0x0
     a35:	00 00                	add    BYTE PTR [bx+si],al
     a37:	02 00                	add    al,BYTE PTR [bx+si]
     a39:	00 00                	add    BYTE PTR [bx+si],al
     a3b:	55                   	push   bp
     a3c:	89 e5                	mov    bp,sp
     a3e:	b8 04 03             	mov    ax,0x304
     a41:	9a 44 04 75 0a       	call   0xa75:0x444
     a46:	81 ec 04 03          	sub    sp,0x304
     a4a:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     a4e:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
     a53:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
     a57:	50                   	push   ax
     a58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a5b:	26 c4 bd 64 02       	les    di,DWORD PTR es:[di+0x264]
     a60:	06                   	push   es
     a61:	57                   	push   di
     a62:	9a 77 1c 99 0a       	call   0xa99:0x1c77
     a67:	8d be fc fd          	lea    di,[bp-0x204]
     a6b:	16                   	push   ss
     a6c:	57                   	push   di
     a6d:	bf 19 0a             	mov    di,0xa19
     a70:	0e                   	push   cs
     a71:	57                   	push   di
     a72:	9a cd 17 7f 0a       	call   0xa7f:0x17cd
     a77:	bf fa 1d             	mov    di,0x1dfa
     a7a:	1e                   	push   ds
     a7b:	57                   	push   di
     a7c:	9a 4c 18 89 0a       	call   0xa89:0x184c
     a81:	bf 25 0a             	mov    di,0xa25
     a84:	0e                   	push   cs
     a85:	57                   	push   di
     a86:	9a 4c 18 9e 0a       	call   0xa9e:0x184c
     a8b:	8d be fc fc          	lea    di,[bp-0x304]
     a8f:	16                   	push   ss
     a90:	57                   	push   di
     a91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a94:	06                   	push   es
     a95:	57                   	push   di
     a96:	9a 53 1d a8 0a       	call   0xaa8:0x1d53
     a9b:	9a 4c 18 b8 0a       	call   0xab8:0x184c
     aa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aa3:	06                   	push   es
     aa4:	57                   	push   di
     aa5:	9a 8c 1d dd 0a       	call   0xadd:0x1d8c
     aaa:	8d be fc fc          	lea    di,[bp-0x304]
     aae:	16                   	push   ss
     aaf:	57                   	push   di
     ab0:	bf 29 0a             	mov    di,0xa29
     ab3:	0e                   	push   cs
     ab4:	57                   	push   di
     ab5:	9a cd 17 ce 0a       	call   0xace:0x17cd
     aba:	8d be fc fd          	lea    di,[bp-0x204]
     abe:	16                   	push   ss
     abf:	57                   	push   di
     ac0:	a1 06 1e             	mov    ax,ds:0x1e06
     ac3:	99                   	cwd
     ac4:	52                   	push   dx
     ac5:	50                   	push   ax
     ac6:	9a a9 08 05 16       	call   0x1605:0x8a9
     acb:	9a 4c 18 22 0b       	call   0xb22:0x184c
     ad0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ad3:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
     ad8:	06                   	push   es
     ad9:	57                   	push   di
     ada:	9a 8c 1d 06 0c       	call   0xc06:0x1d8c
     adf:	6a 00                	push   0x0
     ae1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ae4:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     ae9:	06                   	push   es
     aea:	57                   	push   di
     aeb:	9a 6f 24 ff ff       	call   0xffff:0x246f
     af0:	6a 01                	push   0x1
     af2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     af5:	06                   	push   es
     af6:	57                   	push   di
     af7:	9a 6b 0e c2 0d       	call   0xdc2:0xe6b
     afc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aff:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
     b04:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     b08:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     b0c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     b11:	06                   	push   es
     b12:	57                   	push   di
     b13:	26 c4 3d             	les    di,DWORD PTR es:[di]
     b16:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
     b1a:	2d 01 00             	sub    ax,0x1
     b1d:	71 05                	jno    0xb24
     b1f:	9a 3e 04 62 0b       	call   0xb62:0x43e
     b24:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
     b28:	31 c0                	xor    ax,ax
     b2a:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
     b2e:	7e 03                	jle    0xb33
     b30:	e9 c4 00             	jmp    0xbf7
     b33:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     b36:	eb 03                	jmp    0xb3b
     b38:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     b3b:	8d be f6 fd          	lea    di,[bp-0x20a]
     b3f:	16                   	push   ss
     b40:	57                   	push   di
     b41:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b44:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     b48:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     b4d:	06                   	push   es
     b4e:	57                   	push   di
     b4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
     b52:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
     b56:	8d be fc fe          	lea    di,[bp-0x104]
     b5a:	16                   	push   ss
     b5b:	57                   	push   di
     b5c:	68 ff 00             	push   0xff
     b5f:	9a e7 17 72 0b       	call   0xb72:0x17e7
     b64:	bf 31 0a             	mov    di,0xa31
     b67:	0e                   	push   cs
     b68:	57                   	push   di
     b69:	8d be fc fe          	lea    di,[bp-0x104]
     b6d:	16                   	push   ss
     b6e:	57                   	push   di
     b6f:	9a 78 18 94 0b       	call   0xb94:0x1878
     b74:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b77:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
     b7b:	7e 6e                	jle    0xbeb
     b7d:	8d be f6 fd          	lea    di,[bp-0x20a]
     b81:	16                   	push   ss
     b82:	57                   	push   di
     b83:	8d be fc fe          	lea    di,[bp-0x104]
     b87:	16                   	push   ss
     b88:	57                   	push   di
     b89:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b8c:	05 01 00             	add    ax,0x1
     b8f:	71 05                	jno    0xb96
     b91:	9a 3e 04 9c 0b       	call   0xb9c:0x43e
     b96:	50                   	push   ax
     b97:	6a 64                	push   0x64
     b99:	9a 0b 18 a8 0b       	call   0xba8:0x180b
     b9e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ba1:	99                   	cwd
     ba2:	bf 33 0a             	mov    di,0xa33
     ba5:	9a 16 04 be 0b       	call   0xbbe:0x416
     baa:	c1 e0 08             	shl    ax,0x8
     bad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bb0:	03 f8                	add    di,ax
     bb2:	81 c7 6a 03          	add    di,0x36a
     bb6:	06                   	push   es
     bb7:	57                   	push   di
     bb8:	68 ff 00             	push   0xff
     bbb:	9a e7 17 ce 0b       	call   0xbce:0x17e7
     bc0:	8d be fc fe          	lea    di,[bp-0x104]
     bc4:	16                   	push   ss
     bc5:	57                   	push   di
     bc6:	ff 76 fc             	push   WORD PTR [bp-0x4]
     bc9:	6a 64                	push   0x64
     bcb:	9a 75 19 1a 0c       	call   0xc1a:0x1975
     bd0:	ff 76 fe             	push   WORD PTR [bp-0x2]
     bd3:	8d be fc fe          	lea    di,[bp-0x104]
     bd7:	16                   	push   ss
     bd8:	57                   	push   di
     bd9:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     bdd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     be2:	06                   	push   es
     be3:	57                   	push   di
     be4:	26 c4 3d             	les    di,DWORD PTR es:[di]
     be7:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
     beb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     bee:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
     bf2:	74 03                	je     0xbf7
     bf4:	e9 41 ff             	jmp    0xb38
     bf7:	6a 00                	push   0x0
     bf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bfc:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
     c01:	06                   	push   es
     c02:	57                   	push   di
     c03:	9a 77 1c 46 0c       	call   0xc46:0x1c77
     c08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c0b:	06                   	push   es
     c0c:	57                   	push   di
     c0d:	9a 7d 52 3e 0c       	call   0xc3e:0x527d
     c12:	2d 01 00             	sub    ax,0x1
     c15:	71 05                	jno    0xc1c
     c17:	9a 3e 04 4d 0c       	call   0xc4d:0x43e
     c1c:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
     c20:	31 c0                	xor    ax,ax
     c22:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
     c26:	7e 03                	jle    0xc2b
     c28:	e9 a4 00             	jmp    0xccf
     c2b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c2e:	eb 03                	jmp    0xc33
     c30:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     c33:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c39:	06                   	push   es
     c3a:	57                   	push   di
     c3b:	9a 46 52 5e 0c       	call   0xc5e:0x5246
     c40:	52                   	push   dx
     c41:	50                   	push   ax
     c42:	bf 99 03             	mov    di,0x399
     c45:	b8 66 0c             	mov    ax,0xc66
     c48:	50                   	push   ax
     c49:	57                   	push   di
     c4a:	9a 55 22 6d 0c       	call   0xc6d:0x2255
     c4f:	08 c0                	or     al,al
     c51:	74 70                	je     0xcc3
     c53:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c59:	06                   	push   es
     c5a:	57                   	push   di
     c5b:	9a 46 52 46 1c       	call   0x1c46:0x5246
     c60:	52                   	push   dx
     c61:	50                   	push   ax
     c62:	bf 99 03             	mov    di,0x399
     c65:	b8 c1 0c             	mov    ax,0xcc1
     c68:	50                   	push   ax
     c69:	57                   	push   di
     c6a:	9a 73 22 a5 0c       	call   0xca5:0x2273
     c6f:	89 c7                	mov    di,ax
     c71:	8e c2                	mov    es,dx
     c73:	89 be f6 fe          	mov    WORD PTR [bp-0x10a],di
     c77:	8c 86 f8 fe          	mov    WORD PTR [bp-0x108],es
     c7b:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     c7f:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
     c83:	74 3e                	je     0xcc3
     c85:	a1 06 1e             	mov    ax,ds:0x1e06
     c88:	99                   	cwd
     c89:	8b c8                	mov    cx,ax
     c8b:	8b da                	mov    bx,dx
     c8d:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     c91:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     c95:	09 d2                	or     dx,dx
     c97:	79 07                	jns    0xca0
     c99:	f7 d2                	not    dx
     c9b:	f7 d8                	neg    ax
     c9d:	83 da ff             	sbb    dx,0xffff
     ca0:	71 05                	jno    0xca7
     ca2:	9a 3e 04 b8 0d       	call   0xdb8:0x43e
     ca7:	3b d3                	cmp    dx,bx
     ca9:	7c 0a                	jl     0xcb5
     cab:	7f 04                	jg     0xcb1
     cad:	3b c1                	cmp    ax,cx
     caf:	76 04                	jbe    0xcb5
     cb1:	b0 00                	mov    al,0x0
     cb3:	eb 02                	jmp    0xcb7
     cb5:	b0 01                	mov    al,0x1
     cb7:	50                   	push   ax
     cb8:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
     cbc:	06                   	push   es
     cbd:	57                   	push   di
     cbe:	9a 77 1c a3 0e       	call   0xea3:0x1c77
     cc3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     cc6:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
     cca:	74 03                	je     0xccf
     ccc:	e9 61 ff             	jmp    0xc30
     ccf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cd2:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
     cd7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     cdc:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
     ce1:	7f 0b                	jg     0xcee
     ce3:	6a 01                	push   0x1
     ce5:	06                   	push   es
     ce6:	57                   	push   di
     ce7:	26 c4 3d             	les    di,DWORD PTR es:[di]
     cea:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cf1:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     cf6:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
     cfb:	7d 10                	jge    0xd0d
     cfd:	6a 01                	push   0x1
     cff:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
     d04:	06                   	push   es
     d05:	57                   	push   di
     d06:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d09:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     d0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d10:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
     d15:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     d1a:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     d1e:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     d22:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
     d27:	7f 0b                	jg     0xd34
     d29:	6a 02                	push   0x2
     d2b:	06                   	push   es
     d2c:	57                   	push   di
     d2d:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d30:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     d34:	83 3e 06 1e 01       	cmp    WORD PTR ds:0x1e06,0x1
     d39:	7f 0f                	jg     0xd4a
     d3b:	6a 01                	push   0x1
     d3d:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     d41:	06                   	push   es
     d42:	57                   	push   di
     d43:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d46:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     d4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d4d:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
     d52:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
     d57:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
     d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d5f:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
     d64:	06                   	push   es
     d65:	57                   	push   di
     d66:	9a 4d 5d 12 13       	call   0x1312:0x5d4d
     d6b:	bf 16 1e             	mov    di,0x1e16
     d6e:	1e                   	push   ds
     d6f:	57                   	push   di
     d70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d73:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
     d78:	06                   	push   es
     d79:	57                   	push   di
     d7a:	9a 17 30 91 0d       	call   0xd91:0x3017
     d7f:	bf 24 1e             	mov    di,0x1e24
     d82:	1e                   	push   ds
     d83:	57                   	push   di
     d84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d87:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     d8c:	06                   	push   es
     d8d:	57                   	push   di
     d8e:	9a 17 30 a5 0d       	call   0xda5:0x3017
     d93:	bf 24 1e             	mov    di,0x1e24
     d96:	1e                   	push   ds
     d97:	57                   	push   di
     d98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d9b:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
     da0:	06                   	push   es
     da1:	57                   	push   di
     da2:	9a 17 30 9c 15       	call   0x159c:0x3017
     da7:	c6 06 8e 04 00       	mov    BYTE PTR ds:0x48e,0x0
     dac:	c9                   	leave
     dad:	ca 08 00             	retf   0x8
     db0:	55                   	push   bp
     db1:	89 e5                	mov    bp,sp
     db3:	31 c0                	xor    ax,ax
     db5:	9a 44 04 d7 0d       	call   0xdd7:0x444
     dba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dbd:	06                   	push   es
     dbe:	57                   	push   di
     dbf:	9a 16 2b 10 0e       	call   0xe10:0x2b16
     dc4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     dc7:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
     dcb:	c9                   	leave
     dcc:	ca 0c 00             	retf   0xc
     dcf:	55                   	push   bp
     dd0:	89 e5                	mov    bp,sp
     dd2:	31 c0                	xor    ax,ax
     dd4:	9a 44 04 74 0e       	call   0xe74:0x444
     dd9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ddc:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
     de0:	80 3e 8e 04 00       	cmp    BYTE PTR ds:0x48e,0x0
     de5:	75 7c                	jne    0xe63
     de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dea:	26 83 bd 04 01 01    	cmp    WORD PTR es:[di+0x104],0x1
     df0:	b0 00                	mov    al,0x0
     df2:	75 01                	jne    0xdf5
     df4:	40                   	inc    ax
     df5:	26 22 85 68 03       	and    al,BYTE PTR es:[di+0x368]
     dfa:	08 c0                	or     al,al
     dfc:	74 3b                	je     0xe39
     dfe:	9a ca 39 53 0e       	call   0xe53:0x39ca
     e03:	3d 06 00             	cmp    ax,0x6
     e06:	75 12                	jne    0xe1a
     e08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e0b:	06                   	push   es
     e0c:	57                   	push   di
     e0d:	9a 74 34 a6 10       	call   0x10a6:0x3474
     e12:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     e15:	26 88 05             	mov    BYTE PTR es:[di],al
     e18:	eb 1f                	jmp    0xe39
     e1a:	3d 07 00             	cmp    ax,0x7
     e1d:	75 0c                	jne    0xe2b
     e1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e22:	26 c7 85 04 01 02 00 	mov    WORD PTR es:[di+0x104],0x2
     e29:	eb 0e                	jmp    0xe39
     e2b:	3d 02 00             	cmp    ax,0x2
     e2e:	75 09                	jne    0xe39
     e30:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     e33:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     e37:	eb 00                	jmp    0xe39
     e39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e3c:	26 83 bd 04 01 02    	cmp    WORD PTR es:[di+0x104],0x2
     e42:	b0 00                	mov    al,0x0
     e44:	75 01                	jne    0xe47
     e46:	40                   	inc    ax
     e47:	26 22 85 68 03       	and    al,BYTE PTR es:[di+0x368]
     e4c:	08 c0                	or     al,al
     e4e:	74 13                	je     0xe63
     e50:	9a 48 3a 0f 12       	call   0x120f:0x3a48
     e55:	3d 06 00             	cmp    ax,0x6
     e58:	b0 00                	mov    al,0x0
     e5a:	75 01                	jne    0xe5d
     e5c:	40                   	inc    ax
     e5d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     e60:	26 88 05             	mov    BYTE PTR es:[di],al
     e63:	c9                   	leave
     e64:	ca 0c 00             	retf   0xc
     e67:	03 20                	add    sp,WORD PTR [bx+si]
     e69:	2d 20 55             	sub    ax,0x5520
     e6c:	89 e5                	mov    bp,sp
     e6e:	b8 00 02             	mov    ax,0x200
     e71:	9a 44 04 b1 0e       	call   0xeb1:0x444
     e76:	81 ec 00 02          	sub    sp,0x200
     e7a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
     e7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e80:	26 88 85 68 03       	mov    BYTE PTR es:[di+0x368],al
     e85:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
     e8b:	74 03                	je     0xe90
     e8d:	e9 8b 00             	jmp    0xf1b
     e90:	8d be 00 fe          	lea    di,[bp-0x200]
     e94:	16                   	push   ss
     e95:	57                   	push   di
     e96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e99:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
     e9e:	06                   	push   es
     e9f:	57                   	push   di
     ea0:	9a 53 1d c6 0e       	call   0xec6:0x1d53
     ea5:	8d be 00 ff          	lea    di,[bp-0x100]
     ea9:	16                   	push   ss
     eaa:	57                   	push   di
     eab:	68 ff 00             	push   0xff
     eae:	9a e7 17 04 0f       	call   0xf04:0x17e7
     eb3:	8d be 00 fe          	lea    di,[bp-0x200]
     eb7:	16                   	push   ss
     eb8:	57                   	push   di
     eb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ebc:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     ec1:	06                   	push   es
     ec2:	57                   	push   di
     ec3:	9a 53 1d d5 0e       	call   0xed5:0x1d53
     ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ecb:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
     ed0:	06                   	push   es
     ed1:	57                   	push   di
     ed2:	9a 8c 1d ea 0e       	call   0xeea:0x1d8c
     ed7:	8d be 00 ff          	lea    di,[bp-0x100]
     edb:	16                   	push   ss
     edc:	57                   	push   di
     edd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ee0:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     ee5:	06                   	push   es
     ee6:	57                   	push   di
     ee7:	9a 8c 1d fa 0e       	call   0xefa:0x1d8c
     eec:	8d be 00 fe          	lea    di,[bp-0x200]
     ef0:	16                   	push   ss
     ef1:	57                   	push   di
     ef2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ef5:	06                   	push   es
     ef6:	57                   	push   di
     ef7:	9a 53 1d 19 0f       	call   0xf19:0x1d53
     efc:	bf 67 0e             	mov    di,0xe67
     eff:	0e                   	push   cs
     f00:	57                   	push   di
     f01:	9a 4c 18 0f 0f       	call   0xf0f:0x184c
     f06:	8d be 00 ff          	lea    di,[bp-0x100]
     f0a:	16                   	push   ss
     f0b:	57                   	push   di
     f0c:	9a 4c 18 b5 10       	call   0x10b5:0x184c
     f11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f14:	06                   	push   es
     f15:	57                   	push   di
     f16:	9a 8c 1d 2a 0f       	call   0xf2a:0x1d8c
     f1b:	6a 00                	push   0x0
     f1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f20:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
     f25:	06                   	push   es
     f26:	57                   	push   di
     f27:	9a 77 1c 45 0f       	call   0xf45:0x1c77
     f2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f2f:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
     f35:	b0 00                	mov    al,0x0
     f37:	75 01                	jne    0xf3a
     f39:	40                   	inc    ax
     f3a:	50                   	push   ax
     f3b:	26 c4 bd 10 03       	les    di,DWORD PTR es:[di+0x310]
     f40:	06                   	push   es
     f41:	57                   	push   di
     f42:	9a 77 1c 60 0f       	call   0xf60:0x1c77
     f47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f4a:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
     f50:	b0 00                	mov    al,0x0
     f52:	75 01                	jne    0xf55
     f54:	40                   	inc    ax
     f55:	50                   	push   ax
     f56:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
     f5b:	06                   	push   es
     f5c:	57                   	push   di
     f5d:	9a 77 1c 7b 0f       	call   0xf7b:0x1c77
     f62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f65:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
     f6b:	b0 00                	mov    al,0x0
     f6d:	75 01                	jne    0xf70
     f6f:	40                   	inc    ax
     f70:	50                   	push   ax
     f71:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
     f76:	06                   	push   es
     f77:	57                   	push   di
     f78:	9a 77 1c 90 0f       	call   0xf90:0x1c77
     f7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f80:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
     f85:	50                   	push   ax
     f86:	26 c4 bd 20 03       	les    di,DWORD PTR es:[di+0x320]
     f8b:	06                   	push   es
     f8c:	57                   	push   di
     f8d:	9a 77 1c ab 0f       	call   0xfab:0x1c77
     f92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f95:	26 c4 bd 18 03       	les    di,DWORD PTR es:[di+0x318]
     f9a:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
     f9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fa1:	26 c4 bd 20 03       	les    di,DWORD PTR es:[di+0x320]
     fa6:	06                   	push   es
     fa7:	57                   	push   di
     fa8:	9a 9d 17 c0 0f       	call   0xfc0:0x179d
     fad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fb0:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
     fb5:	50                   	push   ax
     fb6:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
     fbb:	06                   	push   es
     fbc:	57                   	push   di
     fbd:	9a 77 1c d5 0f       	call   0xfd5:0x1c77
     fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fc5:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
     fca:	50                   	push   ax
     fcb:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
     fd0:	06                   	push   es
     fd1:	57                   	push   di
     fd2:	9a 77 1c f0 0f       	call   0xff0:0x1c77
     fd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fda:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
     fe0:	b0 00                	mov    al,0x0
     fe2:	75 01                	jne    0xfe5
     fe4:	40                   	inc    ax
     fe5:	50                   	push   ax
     fe6:	26 c4 bd b8 02       	les    di,DWORD PTR es:[di+0x2b8]
     feb:	06                   	push   es
     fec:	57                   	push   di
     fed:	9a 77 1c 05 10       	call   0x1005:0x1c77
     ff2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ff5:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
     ffa:	50                   	push   ax
     ffb:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    1000:	06                   	push   es
    1001:	57                   	push   di
    1002:	9a b8 1c 1a 10       	call   0x101a:0x1cb8
    1007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    100a:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    100f:	50                   	push   ax
    1010:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    1015:	06                   	push   es
    1016:	57                   	push   di
    1017:	9a b8 1c 2f 10       	call   0x102f:0x1cb8
    101c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    101f:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    1024:	50                   	push   ax
    1025:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    102a:	06                   	push   es
    102b:	57                   	push   di
    102c:	9a b8 1c 44 10       	call   0x1044:0x1cb8
    1031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1034:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    1039:	50                   	push   ax
    103a:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    103f:	06                   	push   es
    1040:	57                   	push   di
    1041:	9a b8 1c 59 10       	call   0x1059:0x1cb8
    1046:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1049:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    104e:	50                   	push   ax
    104f:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    1054:	06                   	push   es
    1055:	57                   	push   di
    1056:	9a b8 1c 75 10       	call   0x1075:0x1cb8
    105b:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    1060:	75 30                	jne    0x1092
    1062:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1065:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    106a:	50                   	push   ax
    106b:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    1070:	06                   	push   es
    1071:	57                   	push   di
    1072:	9a 77 1c 90 10       	call   0x1090:0x1c77
    1077:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    107a:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
    1080:	b0 00                	mov    al,0x0
    1082:	75 01                	jne    0x1085
    1084:	40                   	inc    ax
    1085:	50                   	push   ax
    1086:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    108b:	06                   	push   es
    108c:	57                   	push   di
    108d:	9a 77 1c 21 11       	call   0x1121:0x1c77
    1092:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1095:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
    109b:	b0 00                	mov    al,0x0
    109d:	75 01                	jne    0x10a0
    109f:	40                   	inc    ax
    10a0:	50                   	push   ax
    10a1:	06                   	push   es
    10a2:	57                   	push   di
    10a3:	9a 24 29 10 11       	call   0x1110:0x2924
    10a8:	c9                   	leave
    10a9:	ca 06 00             	retf   0x6
    10ac:	55                   	push   bp
    10ad:	89 e5                	mov    bp,sp
    10af:	b8 02 00             	mov    ax,0x2
    10b2:	9a 44 04 03 11       	call   0x1103:0x444
    10b7:	83 ec 02             	sub    sp,0x2
    10ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10bd:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
    10c3:	b0 00                	mov    al,0x0
    10c5:	75 01                	jne    0x10c8
    10c7:	40                   	inc    ax
    10c8:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    10cb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    10ce:	c9                   	leave
    10cf:	ca 04 00             	retf   0x4
    10d2:	11 4d 6f             	adc    WORD PTR [di+0x6f],cx
    10d5:	64 65 41             	fs gs inc cx
    10d8:	6d                   	ins    WORD PTR es:[di],dx
    10d9:	6f                   	outs   dx,WORD PTR ds:[si]
    10da:	72 74                	jb     0x1150
    10dc:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    10e1:	65 6e                	outs   dx,BYTE PTR gs:[si]
    10e3:	74 00                	je     0x10e5
    10e5:	80 ff ff             	cmp    bh,0xff
    10e8:	ff                   	(bad)
    10e9:	7f 00                	jg     0x10eb
    10eb:	00 0d                	add    BYTE PTR [di],cl
    10ed:	49                   	dec    cx
    10ee:	46                   	inc    si
    10ef:	41                   	inc    cx
    10f0:	4e                   	dec    si
    10f1:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
    10f4:	61                   	popa
    10f5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10f6:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    10f9:	73 55                	jae    0x1150
    10fb:	89 e5                	mov    bp,sp
    10fd:	b8 08 00             	mov    ax,0x8
    1100:	9a 44 04 4a 11       	call   0x114a:0x444
    1105:	83 ec 08             	sub    sp,0x8
    1108:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    110b:	06                   	push   es
    110c:	57                   	push   di
    110d:	9a ab 2d c1 11       	call   0x11c1:0x2dab
    1112:	6a 00                	push   0x0
    1114:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1117:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    111c:	06                   	push   es
    111d:	57                   	push   di
    111e:	9a 77 1c 74 11       	call   0x1174:0x1c77
    1123:	bf d2 10             	mov    di,0x10d2
    1126:	0e                   	push   cs
    1127:	57                   	push   di
    1128:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    112b:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    1130:	06                   	push   es
    1131:	57                   	push   di
    1132:	9a 9b 3b 88 11       	call   0x1188:0x3b9b
    1137:	89 c7                	mov    di,ax
    1139:	8e c2                	mov    es,dx
    113b:	06                   	push   es
    113c:	57                   	push   di
    113d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1140:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1144:	bf e4 10             	mov    di,0x10e4
    1147:	9a 16 04 aa 11       	call   0x11aa:0x416
    114c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    114f:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    1154:	b0 00                	mov    al,0x0
    1156:	7c 01                	jl     0x1159
    1158:	40                   	inc    ax
    1159:	8a d0                	mov    dl,al
    115b:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    115f:	b0 00                	mov    al,0x0
    1161:	75 01                	jne    0x1164
    1163:	40                   	inc    ax
    1164:	22 c2                	and    al,dl
    1166:	50                   	push   ax
    1167:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    116a:	26 c4 bd 5c 03       	les    di,DWORD PTR es:[di+0x35c]
    116f:	06                   	push   es
    1170:	57                   	push   di
    1171:	9a 77 1c 2a 13       	call   0x132a:0x1c77
    1176:	bf ec 10             	mov    di,0x10ec
    1179:	0e                   	push   cs
    117a:	57                   	push   di
    117b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    117e:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    1183:	06                   	push   es
    1184:	57                   	push   di
    1185:	9a 43 3c 8a 15       	call   0x158a:0x3c43
    118a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    118d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1190:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1193:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    1196:	74 19                	je     0x11b1
    1198:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    119b:	06                   	push   es
    119c:	57                   	push   di
    119d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    11a0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    11a4:	bf e4 10             	mov    di,0x10e4
    11a7:	9a 16 04 dc 11       	call   0x11dc:0x416
    11ac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    11af:	eb 05                	jmp    0x11b6
    11b1:	c7 46 fe 08 00       	mov    WORD PTR [bp-0x2],0x8
    11b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    11b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11bc:	06                   	push   es
    11bd:	57                   	push   di
    11be:	9a c6 13 ed 11       	call   0x11ed:0x13c6
    11c3:	6a fe                	push   0xfffe
    11c5:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    11c9:	06                   	push   es
    11ca:	57                   	push   di
    11cb:	9a a9 63 3e 12       	call   0x123e:0x63a9
    11d0:	c9                   	leave
    11d1:	ca 08 00             	retf   0x8
    11d4:	55                   	push   bp
    11d5:	89 e5                	mov    bp,sp
    11d7:	31 c0                	xor    ax,ax
    11d9:	9a 44 04 f8 11       	call   0x11f8:0x444
    11de:	6a 00                	push   0x0
    11e0:	9a a5 13 e7 12       	call   0x12e7:0x13a5
    11e5:	c9                   	leave
    11e6:	ca 08 00             	retf   0x8
    11e9:	00 00                	add    BYTE PTR [bx+si],al
    11eb:	a0 12 06             	mov    al,ds:0x612
    11ee:	12 55 89             	adc    dl,BYTE PTR [di-0x77]
    11f1:	e5 b8                	in     ax,0xb8
    11f3:	04 02                	add    al,0x2
    11f5:	9a 44 04 b8 12       	call   0x12b8:0x444
    11fa:	81 ec 04 02          	sub    sp,0x204
    11fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1201:	06                   	push   es
    1202:	57                   	push   di
    1203:	9a 69 31 73 12       	call   0x1273:0x3169
    1208:	08 c0                	or     al,al
    120a:	74 08                	je     0x1214
    120c:	9a d1 37 37 12       	call   0x1237:0x37d1
    1211:	e9 98 00             	jmp    0x12ac
    1214:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1217:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    121c:	06                   	push   es
    121d:	57                   	push   di
    121e:	9a 17 2f dc 12       	call   0x12dc:0x2f17
    1223:	08 c0                	or     al,al
    1225:	75 03                	jne    0x122a
    1227:	e9 82 00             	jmp    0x12ac
    122a:	ff 76 08             	push   WORD PTR [bp+0x8]
    122d:	ff 76 06             	push   WORD PTR [bp+0x6]
    1230:	b0 01                	mov    al,0x1
    1232:	50                   	push   ax
    1233:	b8 b4 25             	mov    ax,0x25b4
    1236:	ba 68 12             	mov    dx,0x1268
    1239:	52                   	push   dx
    123a:	50                   	push   ax
    123b:	9a 53 25 92 12       	call   0x1292:0x2553
    1240:	a3 04 20             	mov    ds:0x2004,ax
    1243:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    1247:	b8 e9 11             	mov    ax,0x11e9
    124a:	0e                   	push   cs
    124b:	50                   	push   ax
    124c:	55                   	push   bp
    124d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1251:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1255:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1259:	89 be fc fd          	mov    WORD PTR [bp-0x204],di
    125d:	8c 86 fe fd          	mov    WORD PTR [bp-0x202],es
    1261:	6a 01                	push   0x1
    1263:	06                   	push   es
    1264:	57                   	push   di
    1265:	9a 8d 2f cb 12       	call   0x12cb:0x2f8d
    126a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    126d:	06                   	push   es
    126e:	57                   	push   di
    126f:	b8 d4 11             	mov    ax,0x11d4
    1272:	ba c2 12             	mov    dx,0x12c2
    1275:	c4 be fc fd          	les    di,DWORD PTR [bp-0x204]
    1279:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    127e:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    1283:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    1288:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    128d:	06                   	push   es
    128e:	57                   	push   di
    128f:	9a 45 5d a9 12       	call   0x12a9:0x5d45
    1294:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1298:	83 c4 06             	add    sp,0x6
    129b:	b8 ac 12             	mov    ax,0x12ac
    129e:	0e                   	push   cs
    129f:	50                   	push   ax
    12a0:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    12a4:	06                   	push   es
    12a5:	57                   	push   di
    12a6:	9a 1d 5f 2a 15       	call   0x152a:0x5f1d
    12ab:	cb                   	retf
    12ac:	c9                   	leave
    12ad:	ca 08 00             	retf   0x8
    12b0:	55                   	push   bp
    12b1:	89 e5                	mov    bp,sp
    12b3:	31 c0                	xor    ax,ax
    12b5:	9a 44 04 f5 12       	call   0x12f5:0x444
    12ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12bd:	06                   	push   es
    12be:	57                   	push   di
    12bf:	9a 69 31 dc 14       	call   0x14dc:0x3169
    12c4:	08 c0                	or     al,al
    12c6:	74 07                	je     0x12cf
    12c8:	9a d1 37 3a 47       	call   0x473a:0x37d1
    12cd:	eb 1a                	jmp    0x12e9
    12cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12d2:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    12d7:	06                   	push   es
    12d8:	57                   	push   di
    12d9:	9a 17 2f ff ff       	call   0xffff:0x2f17
    12de:	08 c0                	or     al,al
    12e0:	74 07                	je     0x12e9
    12e2:	6a 01                	push   0x1
    12e4:	9a a5 13 ff ff       	call   0xffff:0x13a5
    12e9:	c9                   	leave
    12ea:	ca 08 00             	retf   0x8
    12ed:	55                   	push   bp
    12ee:	89 e5                	mov    bp,sp
    12f0:	31 c0                	xor    ax,ax
    12f2:	9a 44 04 03 13       	call   0x1303:0x444
    12f7:	c9                   	leave
    12f8:	ca 08 00             	retf   0x8
    12fb:	55                   	push   bp
    12fc:	89 e5                	mov    bp,sp
    12fe:	31 c0                	xor    ax,ax
    1300:	9a 44 04 40 13       	call   0x1340:0x444
    1305:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1308:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    130d:	06                   	push   es
    130e:	57                   	push   di
    130f:	9a 07 5c 4f 13       	call   0x134f:0x5c07
    1314:	3d 01 00             	cmp    ax,0x1
    1317:	b0 00                	mov    al,0x0
    1319:	75 01                	jne    0x131c
    131b:	40                   	inc    ax
    131c:	50                   	push   ax
    131d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1320:	26 c4 bd 5c 03       	les    di,DWORD PTR es:[di+0x35c]
    1325:	06                   	push   es
    1326:	57                   	push   di
    1327:	9a 77 1c 75 13       	call   0x1375:0x1c77
    132c:	c9                   	leave
    132d:	ca 08 00             	retf   0x8
    1330:	00 00                	add    BYTE PTR [bx+si],al
    1332:	00 00                	add    BYTE PTR [bx+si],al
    1334:	02 00                	add    al,BYTE PTR [bx+si]
    1336:	00 00                	add    BYTE PTR [bx+si],al
    1338:	55                   	push   bp
    1339:	89 e5                	mov    bp,sp
    133b:	31 c0                	xor    ax,ax
    133d:	9a 44 04 58 13       	call   0x1358:0x444
    1342:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1345:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    134a:	06                   	push   es
    134b:	57                   	push   di
    134c:	9a 07 5c 9a 13       	call   0x139a:0x5c07
    1351:	99                   	cwd
    1352:	bf 30 13             	mov    di,0x1330
    1355:	9a 16 04 8b 13       	call   0x138b:0x416
    135a:	c1 e0 08             	shl    ax,0x8
    135d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1360:	03 f8                	add    di,ax
    1362:	81 c7 6a 03          	add    di,0x36a
    1366:	06                   	push   es
    1367:	57                   	push   di
    1368:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    136b:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    1370:	06                   	push   es
    1371:	57                   	push   di
    1372:	9a 8c 1d c0 13       	call   0x13c0:0x1d8c
    1377:	c9                   	leave
    1378:	ca 08 00             	retf   0x8
    137b:	00 00                	add    BYTE PTR [bx+si],al
    137d:	00 00                	add    BYTE PTR [bx+si],al
    137f:	02 00                	add    al,BYTE PTR [bx+si]
    1381:	00 00                	add    BYTE PTR [bx+si],al
    1383:	55                   	push   bp
    1384:	89 e5                	mov    bp,sp
    1386:	31 c0                	xor    ax,ax
    1388:	9a 44 04 a3 13       	call   0x13a3:0x444
    138d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1390:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    1395:	06                   	push   es
    1396:	57                   	push   di
    1397:	9a 07 5c 15 1c       	call   0x1c15:0x5c07
    139c:	99                   	cwd
    139d:	bf 7b 13             	mov    di,0x137b
    13a0:	9a 16 04 ce 13       	call   0x13ce:0x416
    13a5:	c1 e0 08             	shl    ax,0x8
    13a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ab:	03 f8                	add    di,ax
    13ad:	81 c7 6a 03          	add    di,0x36a
    13b1:	06                   	push   es
    13b2:	57                   	push   di
    13b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13b6:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    13bb:	06                   	push   es
    13bc:	57                   	push   di
    13bd:	9a 8c 1d f1 13       	call   0x13f1:0x1d8c
    13c2:	c9                   	leave
    13c3:	ca 08 00             	retf   0x8
    13c6:	55                   	push   bp
    13c7:	89 e5                	mov    bp,sp
    13c9:	31 c0                	xor    ax,ax
    13cb:	9a 44 04 b7 14       	call   0x14b7:0x444
    13d0:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    13d5:	74 03                	je     0x13da
    13d7:	e9 c8 00             	jmp    0x14a2
    13da:	83 7e 0a 0b          	cmp    WORD PTR [bp+0xa],0xb
    13de:	b0 00                	mov    al,0x0
    13e0:	7c 01                	jl     0x13e3
    13e2:	40                   	inc    ax
    13e3:	50                   	push   ax
    13e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e7:	26 c4 bd 48 03       	les    di,DWORD PTR es:[di+0x348]
    13ec:	06                   	push   es
    13ed:	57                   	push   di
    13ee:	9a 77 1c 0a 14       	call   0x140a:0x1c77
    13f3:	83 7e 0a 0b          	cmp    WORD PTR [bp+0xa],0xb
    13f7:	b0 00                	mov    al,0x0
    13f9:	7c 01                	jl     0x13fc
    13fb:	40                   	inc    ax
    13fc:	50                   	push   ax
    13fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1400:	26 c4 bd 40 03       	les    di,DWORD PTR es:[di+0x340]
    1405:	06                   	push   es
    1406:	57                   	push   di
    1407:	9a 77 1c 23 14       	call   0x1423:0x1c77
    140c:	83 7e 0a 0a          	cmp    WORD PTR [bp+0xa],0xa
    1410:	b0 00                	mov    al,0x0
    1412:	7c 01                	jl     0x1415
    1414:	40                   	inc    ax
    1415:	50                   	push   ax
    1416:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1419:	26 c4 bd 44 03       	les    di,DWORD PTR es:[di+0x344]
    141e:	06                   	push   es
    141f:	57                   	push   di
    1420:	9a 77 1c 3c 14       	call   0x143c:0x1c77
    1425:	83 7e 0a 0a          	cmp    WORD PTR [bp+0xa],0xa
    1429:	b0 00                	mov    al,0x0
    142b:	7c 01                	jl     0x142e
    142d:	40                   	inc    ax
    142e:	50                   	push   ax
    142f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1432:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
    1437:	06                   	push   es
    1438:	57                   	push   di
    1439:	9a 77 1c 55 14       	call   0x1455:0x1c77
    143e:	83 7e 0a 09          	cmp    WORD PTR [bp+0xa],0x9
    1442:	b0 00                	mov    al,0x0
    1444:	7c 01                	jl     0x1447
    1446:	40                   	inc    ax
    1447:	50                   	push   ax
    1448:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    144b:	26 c4 bd 3c 03       	les    di,DWORD PTR es:[di+0x33c]
    1450:	06                   	push   es
    1451:	57                   	push   di
    1452:	9a 77 1c 6e 14       	call   0x146e:0x1c77
    1457:	83 7e 0a 09          	cmp    WORD PTR [bp+0xa],0x9
    145b:	b0 00                	mov    al,0x0
    145d:	7c 01                	jl     0x1460
    145f:	40                   	inc    ax
    1460:	50                   	push   ax
    1461:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1464:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    1469:	06                   	push   es
    146a:	57                   	push   di
    146b:	9a 77 1c 87 14       	call   0x1487:0x1c77
    1470:	83 7e 0a 08          	cmp    WORD PTR [bp+0xa],0x8
    1474:	b0 00                	mov    al,0x0
    1476:	7c 01                	jl     0x1479
    1478:	40                   	inc    ax
    1479:	50                   	push   ax
    147a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    147d:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    1482:	06                   	push   es
    1483:	57                   	push   di
    1484:	9a 77 1c a0 14       	call   0x14a0:0x1c77
    1489:	83 7e 0a 08          	cmp    WORD PTR [bp+0xa],0x8
    148d:	b0 00                	mov    al,0x0
    148f:	7c 01                	jl     0x1492
    1491:	40                   	inc    ax
    1492:	50                   	push   ax
    1493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1496:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    149b:	06                   	push   es
    149c:	57                   	push   di
    149d:	9a 77 1c 6f 1a       	call   0x1a6f:0x1c77
    14a2:	c9                   	leave
    14a3:	ca 06 00             	retf   0x6
    14a6:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    14aa:	ff                   	(bad)
    14ab:	7f 00                	jg     0x14ad
    14ad:	00 55 89             	add    BYTE PTR [di-0x77],dl
    14b0:	e5 b8                	in     ax,0xb8
    14b2:	02 00                	add    al,BYTE PTR [bx+si]
    14b4:	9a 44 04 d1 14       	call   0x14d1:0x444
    14b9:	83 ec 02             	sub    sp,0x2
    14bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14bf:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    14c4:	06                   	push   es
    14c5:	57                   	push   di
    14c6:	9a 33 17 3a 21       	call   0x213a:0x1733
    14cb:	bf a6 14             	mov    di,0x14a6
    14ce:	9a 16 04 11 15       	call   0x1511:0x416
    14d3:	50                   	push   ax
    14d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14d7:	06                   	push   es
    14d8:	57                   	push   di
    14d9:	9a c6 13 96 1f       	call   0x1f96:0x13c6
    14de:	c9                   	leave
    14df:	ca 08 00             	retf   0x8
    14e2:	0a 23                	or     ah,BYTE PTR [bp+di]
    14e4:	2c 23                	sub    al,0x23
    14e6:	23 30                	and    si,WORD PTR [bx+si]
    14e8:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    14eb:	23 23                	and    sp,WORD PTR [bp+di]
    14ed:	07                   	pop    es
    14ee:	23 30                	and    si,WORD PTR [bx+si]
    14f0:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    14f3:	23 23                	and    sp,WORD PTR [bp+di]
    14f5:	07                   	pop    es
    14f6:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    14fa:	2b 30                	sub    si,WORD PTR [bx+si]
    14fc:	30 01                	xor    BYTE PTR [bx+di],al
    14fe:	30 05                	xor    BYTE PTR [di],al
    1500:	23 2c                	and    bp,WORD PTR [si]
    1502:	23 23                	and    sp,WORD PTR [bp+di]
    1504:	30 02                	xor    BYTE PTR [bp+si],al
    1506:	23 30                	and    si,WORD PTR [bx+si]
    1508:	55                   	push   bp
    1509:	89 e5                	mov    bp,sp
    150b:	b8 14 03             	mov    ax,0x314
    150e:	9a 44 04 a3 15       	call   0x15a3:0x444
    1513:	81 ec 14 03          	sub    sp,0x314
    1517:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    151a:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    151e:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    1522:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1525:	06                   	push   es
    1526:	57                   	push   di
    1527:	9a d5 33 54 15       	call   0x1554:0x33d5
    152c:	89 c7                	mov    di,ax
    152e:	8e c2                	mov    es,dx
    1530:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    1534:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    1538:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    153c:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    1540:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1544:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1548:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    154c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    154f:	06                   	push   es
    1550:	57                   	push   di
    1551:	9a d5 33 23 16       	call   0x1623:0x33d5
    1556:	89 c7                	mov    di,ax
    1558:	8e c2                	mov    es,dx
    155a:	06                   	push   es
    155b:	57                   	push   di
    155c:	9a 99 20 2e 16       	call   0x162e:0x2099
    1561:	8d be f4 fc          	lea    di,[bp-0x30c]
    1565:	16                   	push   ss
    1566:	57                   	push   di
    1567:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    156b:	06                   	push   es
    156c:	57                   	push   di
    156d:	9a 9f 1a 7b 15       	call   0x157b:0x1a9f
    1572:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1576:	06                   	push   es
    1577:	57                   	push   di
    1578:	9a 5f 1a ab 19       	call   0x19ab:0x1a5f
    157d:	89 c7                	mov    di,ax
    157f:	8e c2                	mov    es,dx
    1581:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1585:	06                   	push   es
    1586:	57                   	push   di
    1587:	9a 9b 3b ff 19       	call   0x19ff:0x3b9b
    158c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    158f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1592:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1595:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1598:	bf 58 0a             	mov    di,0xa58
    159b:	b8 b6 15             	mov    ax,0x15b6
    159e:	50                   	push   ax
    159f:	57                   	push   di
    15a0:	9a 55 22 bd 15       	call   0x15bd:0x2255
    15a5:	08 c0                	or     al,al
    15a7:	75 03                	jne    0x15ac
    15a9:	e9 bb 01             	jmp    0x1767
    15ac:	ff 76 fe             	push   WORD PTR [bp-0x2]
    15af:	ff 76 fc             	push   WORD PTR [bp-0x4]
    15b2:	bf 58 0a             	mov    di,0xa58
    15b5:	b8 62 17             	mov    ax,0x1762
    15b8:	50                   	push   ax
    15b9:	57                   	push   di
    15ba:	9a 73 22 dc 15       	call   0x15dc:0x2273
    15bf:	89 c7                	mov    di,ax
    15c1:	8e c2                	mov    es,dx
    15c3:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    15c7:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    15cb:	bf e2 14             	mov    di,0x14e2
    15ce:	0e                   	push   cs
    15cf:	57                   	push   di
    15d0:	8d be fc fd          	lea    di,[bp-0x204]
    15d4:	16                   	push   ss
    15d5:	57                   	push   di
    15d6:	68 ff 00             	push   0xff
    15d9:	9a e7 17 13 16       	call   0x1613:0x17e7
    15de:	8d be f0 fc          	lea    di,[bp-0x310]
    15e2:	16                   	push   ss
    15e3:	57                   	push   di
    15e4:	8d be fc fd          	lea    di,[bp-0x204]
    15e8:	16                   	push   ss
    15e9:	57                   	push   di
    15ea:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    15ee:	06                   	push   es
    15ef:	57                   	push   di
    15f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15f3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    15f7:	83 ec 0a             	sub    sp,0xa
    15fa:	89 e3                	mov    bx,sp
    15fc:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1600:	90                   	nop
    1601:	9b                   	fwait
    1602:	9a d4 10 85 16       	call   0x1685:0x10d4
    1607:	8d be fc fe          	lea    di,[bp-0x104]
    160b:	16                   	push   ss
    160c:	57                   	push   di
    160d:	68 ff 00             	push   0xff
    1610:	9a e7 17 42 16       	call   0x1642:0x17e7
    1615:	8d be fc fe          	lea    di,[bp-0x104]
    1619:	16                   	push   ss
    161a:	57                   	push   di
    161b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    161e:	06                   	push   es
    161f:	57                   	push   di
    1620:	9a d5 33 a3 16       	call   0x16a3:0x33d5
    1625:	89 c7                	mov    di,ax
    1627:	8e c2                	mov    es,dx
    1629:	06                   	push   es
    162a:	57                   	push   di
    162b:	9a 03 20 ae 16       	call   0x16ae:0x2003
    1630:	8b d0                	mov    dx,ax
    1632:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1636:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    163a:	2d 05 00             	sub    ax,0x5
    163d:	71 05                	jno    0x1644
    163f:	9a 3e 04 5c 16       	call   0x165c:0x43e
    1644:	3b c2                	cmp    ax,dx
    1646:	7e 03                	jle    0x164b
    1648:	e9 08 01             	jmp    0x1753
    164b:	bf ed 14             	mov    di,0x14ed
    164e:	0e                   	push   cs
    164f:	57                   	push   di
    1650:	8d be fc fd          	lea    di,[bp-0x204]
    1654:	16                   	push   ss
    1655:	57                   	push   di
    1656:	68 ff 00             	push   0xff
    1659:	9a e7 17 93 16       	call   0x1693:0x17e7
    165e:	8d be f0 fc          	lea    di,[bp-0x310]
    1662:	16                   	push   ss
    1663:	57                   	push   di
    1664:	8d be fc fd          	lea    di,[bp-0x204]
    1668:	16                   	push   ss
    1669:	57                   	push   di
    166a:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    166e:	06                   	push   es
    166f:	57                   	push   di
    1670:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1673:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1677:	83 ec 0a             	sub    sp,0xa
    167a:	89 e3                	mov    bx,sp
    167c:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1680:	90                   	nop
    1681:	9b                   	fwait
    1682:	9a d4 10 e7 17       	call   0x17e7:0x10d4
    1687:	8d be fc fe          	lea    di,[bp-0x104]
    168b:	16                   	push   ss
    168c:	57                   	push   di
    168d:	68 ff 00             	push   0xff
    1690:	9a e7 17 c2 16       	call   0x16c2:0x17e7
    1695:	8d be fc fe          	lea    di,[bp-0x104]
    1699:	16                   	push   ss
    169a:	57                   	push   di
    169b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    169e:	06                   	push   es
    169f:	57                   	push   di
    16a0:	9a d5 33 ec 16       	call   0x16ec:0x33d5
    16a5:	89 c7                	mov    di,ax
    16a7:	8e c2                	mov    es,dx
    16a9:	06                   	push   es
    16aa:	57                   	push   di
    16ab:	9a 03 20 f7 16       	call   0x16f7:0x2003
    16b0:	8b d0                	mov    dx,ax
    16b2:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    16b6:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    16ba:	2d 05 00             	sub    ax,0x5
    16bd:	71 05                	jno    0x16c4
    16bf:	9a 3e 04 dc 16       	call   0x16dc:0x43e
    16c4:	3b c2                	cmp    ax,dx
    16c6:	7e 03                	jle    0x16cb
    16c8:	e9 88 00             	jmp    0x1753
    16cb:	bf f5 14             	mov    di,0x14f5
    16ce:	0e                   	push   cs
    16cf:	57                   	push   di
    16d0:	8d be fc fd          	lea    di,[bp-0x204]
    16d4:	16                   	push   ss
    16d5:	57                   	push   di
    16d6:	68 ff 00             	push   0xff
    16d9:	9a e7 17 0b 17       	call   0x170b:0x17e7
    16de:	8d be fc fd          	lea    di,[bp-0x204]
    16e2:	16                   	push   ss
    16e3:	57                   	push   di
    16e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e7:	06                   	push   es
    16e8:	57                   	push   di
    16e9:	9a d5 33 05 18       	call   0x1805:0x33d5
    16ee:	89 c7                	mov    di,ax
    16f0:	8e c2                	mov    es,dx
    16f2:	06                   	push   es
    16f3:	57                   	push   di
    16f4:	9a 03 20 10 18       	call   0x1810:0x2003
    16f9:	8b d0                	mov    dx,ax
    16fb:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    16ff:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1703:	2d 05 00             	sub    ax,0x5
    1706:	71 05                	jno    0x170d
    1708:	9a 3e 04 39 17       	call   0x1739:0x43e
    170d:	3b c2                	cmp    ax,dx
    170f:	b0 00                	mov    al,0x0
    1711:	7e 01                	jle    0x1714
    1713:	40                   	inc    ax
    1714:	8a d0                	mov    dl,al
    1716:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    171b:	b0 00                	mov    al,0x0
    171d:	73 01                	jae    0x1720
    171f:	40                   	inc    ax
    1720:	22 c2                	and    al,dl
    1722:	08 c0                	or     al,al
    1724:	74 17                	je     0x173d
    1726:	bf fd 14             	mov    di,0x14fd
    1729:	0e                   	push   cs
    172a:	57                   	push   di
    172b:	8d be fc fd          	lea    di,[bp-0x204]
    172f:	16                   	push   ss
    1730:	57                   	push   di
    1731:	68 ff 00             	push   0xff
    1734:	6a 03                	push   0x3
    1736:	9a 16 19 51 17       	call   0x1751:0x1916
    173b:	eb a1                	jmp    0x16de
    173d:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1742:	76 0f                	jbe    0x1753
    1744:	8d be fc fd          	lea    di,[bp-0x204]
    1748:	16                   	push   ss
    1749:	57                   	push   di
    174a:	6a 03                	push   0x3
    174c:	6a 01                	push   0x1
    174e:	9a 75 19 78 17       	call   0x1778:0x1975
    1753:	8d be fc fd          	lea    di,[bp-0x204]
    1757:	16                   	push   ss
    1758:	57                   	push   di
    1759:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    175d:	06                   	push   es
    175e:	57                   	push   di
    175f:	9a f9 60 71 17       	call   0x1771:0x60f9
    1764:	e9 ec 01             	jmp    0x1953
    1767:	ff 76 fe             	push   WORD PTR [bp-0x2]
    176a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    176d:	bf c8 07             	mov    di,0x7c8
    1770:	b8 8b 17             	mov    ax,0x178b
    1773:	50                   	push   ax
    1774:	57                   	push   di
    1775:	9a 55 22 92 17       	call   0x1792:0x2255
    177a:	08 c0                	or     al,al
    177c:	75 03                	jne    0x1781
    177e:	e9 d2 01             	jmp    0x1953
    1781:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1784:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1787:	bf c8 07             	mov    di,0x7c8
    178a:	b8 51 19             	mov    ax,0x1951
    178d:	50                   	push   ax
    178e:	57                   	push   di
    178f:	9a 73 22 b1 17       	call   0x17b1:0x2273
    1794:	89 c7                	mov    di,ax
    1796:	8e c2                	mov    es,dx
    1798:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    179c:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    17a0:	bf ff 14             	mov    di,0x14ff
    17a3:	0e                   	push   cs
    17a4:	57                   	push   di
    17a5:	8d be fc fd          	lea    di,[bp-0x204]
    17a9:	16                   	push   ss
    17aa:	57                   	push   di
    17ab:	68 ff 00             	push   0xff
    17ae:	9a e7 17 f5 17       	call   0x17f5:0x17e7
    17b3:	8d be ec fc          	lea    di,[bp-0x314]
    17b7:	16                   	push   ss
    17b8:	57                   	push   di
    17b9:	8d be fc fd          	lea    di,[bp-0x204]
    17bd:	16                   	push   ss
    17be:	57                   	push   di
    17bf:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    17c3:	06                   	push   es
    17c4:	57                   	push   di
    17c5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17c8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    17cc:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    17d0:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    17d4:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    17d9:	83 ec 0a             	sub    sp,0xa
    17dc:	89 e3                	mov    bx,sp
    17de:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    17e2:	90                   	nop
    17e3:	9b                   	fwait
    17e4:	9a d4 10 74 18       	call   0x1874:0x10d4
    17e9:	8d be fc fe          	lea    di,[bp-0x104]
    17ed:	16                   	push   ss
    17ee:	57                   	push   di
    17ef:	68 ff 00             	push   0xff
    17f2:	9a e7 17 24 18       	call   0x1824:0x17e7
    17f7:	8d be fc fe          	lea    di,[bp-0x104]
    17fb:	16                   	push   ss
    17fc:	57                   	push   di
    17fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1800:	06                   	push   es
    1801:	57                   	push   di
    1802:	9a d5 33 92 18       	call   0x1892:0x33d5
    1807:	89 c7                	mov    di,ax
    1809:	8e c2                	mov    es,dx
    180b:	06                   	push   es
    180c:	57                   	push   di
    180d:	9a 03 20 9d 18       	call   0x189d:0x2003
    1812:	8b d0                	mov    dx,ax
    1814:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1818:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    181c:	2d 05 00             	sub    ax,0x5
    181f:	71 05                	jno    0x1826
    1821:	9a 3e 04 3e 18       	call   0x183e:0x43e
    1826:	3b c2                	cmp    ax,dx
    1828:	7e 03                	jle    0x182d
    182a:	e9 15 01             	jmp    0x1942
    182d:	bf 05 15             	mov    di,0x1505
    1830:	0e                   	push   cs
    1831:	57                   	push   di
    1832:	8d be fc fd          	lea    di,[bp-0x204]
    1836:	16                   	push   ss
    1837:	57                   	push   di
    1838:	68 ff 00             	push   0xff
    183b:	9a e7 17 82 18       	call   0x1882:0x17e7
    1840:	8d be ec fc          	lea    di,[bp-0x314]
    1844:	16                   	push   ss
    1845:	57                   	push   di
    1846:	8d be fc fd          	lea    di,[bp-0x204]
    184a:	16                   	push   ss
    184b:	57                   	push   di
    184c:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1850:	06                   	push   es
    1851:	57                   	push   di
    1852:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1855:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1859:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    185d:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1861:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1866:	83 ec 0a             	sub    sp,0xa
    1869:	89 e3                	mov    bx,sp
    186b:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    186f:	90                   	nop
    1870:	9b                   	fwait
    1871:	9a d4 10 60 1a       	call   0x1a60:0x10d4
    1876:	8d be fc fe          	lea    di,[bp-0x104]
    187a:	16                   	push   ss
    187b:	57                   	push   di
    187c:	68 ff 00             	push   0xff
    187f:	9a e7 17 b1 18       	call   0x18b1:0x17e7
    1884:	8d be fc fe          	lea    di,[bp-0x104]
    1888:	16                   	push   ss
    1889:	57                   	push   di
    188a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    188d:	06                   	push   es
    188e:	57                   	push   di
    188f:	9a d5 33 db 18       	call   0x18db:0x33d5
    1894:	89 c7                	mov    di,ax
    1896:	8e c2                	mov    es,dx
    1898:	06                   	push   es
    1899:	57                   	push   di
    189a:	9a 03 20 e6 18       	call   0x18e6:0x2003
    189f:	8b d0                	mov    dx,ax
    18a1:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    18a5:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    18a9:	2d 05 00             	sub    ax,0x5
    18ac:	71 05                	jno    0x18b3
    18ae:	9a 3e 04 cb 18       	call   0x18cb:0x43e
    18b3:	3b c2                	cmp    ax,dx
    18b5:	7e 03                	jle    0x18ba
    18b7:	e9 88 00             	jmp    0x1942
    18ba:	bf f5 14             	mov    di,0x14f5
    18bd:	0e                   	push   cs
    18be:	57                   	push   di
    18bf:	8d be fc fd          	lea    di,[bp-0x204]
    18c3:	16                   	push   ss
    18c4:	57                   	push   di
    18c5:	68 ff 00             	push   0xff
    18c8:	9a e7 17 fa 18       	call   0x18fa:0x17e7
    18cd:	8d be fc fd          	lea    di,[bp-0x204]
    18d1:	16                   	push   ss
    18d2:	57                   	push   di
    18d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d6:	06                   	push   es
    18d7:	57                   	push   di
    18d8:	9a d5 33 67 19       	call   0x1967:0x33d5
    18dd:	89 c7                	mov    di,ax
    18df:	8e c2                	mov    es,dx
    18e1:	06                   	push   es
    18e2:	57                   	push   di
    18e3:	9a 03 20 72 19       	call   0x1972:0x2003
    18e8:	8b d0                	mov    dx,ax
    18ea:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    18ee:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    18f2:	2d 05 00             	sub    ax,0x5
    18f5:	71 05                	jno    0x18fc
    18f7:	9a 3e 04 28 19       	call   0x1928:0x43e
    18fc:	3b c2                	cmp    ax,dx
    18fe:	b0 00                	mov    al,0x0
    1900:	7e 01                	jle    0x1903
    1902:	40                   	inc    ax
    1903:	8a d0                	mov    dl,al
    1905:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    190a:	b0 00                	mov    al,0x0
    190c:	73 01                	jae    0x190f
    190e:	40                   	inc    ax
    190f:	22 c2                	and    al,dl
    1911:	08 c0                	or     al,al
    1913:	74 17                	je     0x192c
    1915:	bf fd 14             	mov    di,0x14fd
    1918:	0e                   	push   cs
    1919:	57                   	push   di
    191a:	8d be fc fd          	lea    di,[bp-0x204]
    191e:	16                   	push   ss
    191f:	57                   	push   di
    1920:	68 ff 00             	push   0xff
    1923:	6a 03                	push   0x3
    1925:	9a 16 19 40 19       	call   0x1940:0x1916
    192a:	eb a1                	jmp    0x18cd
    192c:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1931:	76 0f                	jbe    0x1942
    1933:	8d be fc fd          	lea    di,[bp-0x204]
    1937:	16                   	push   ss
    1938:	57                   	push   di
    1939:	6a 03                	push   0x3
    193b:	6a 01                	push   0x1
    193d:	9a 75 19 9b 19       	call   0x199b:0x1975
    1942:	8d be fc fd          	lea    di,[bp-0x204]
    1946:	16                   	push   ss
    1947:	57                   	push   di
    1948:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    194c:	06                   	push   es
    194d:	57                   	push   di
    194e:	9a f9 60 11 1a       	call   0x1a11:0x60f9
    1953:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1957:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    195b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    195f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1962:	06                   	push   es
    1963:	57                   	push   di
    1964:	9a d5 33 99 22       	call   0x2299:0x33d5
    1969:	89 c7                	mov    di,ax
    196b:	8e c2                	mov    es,dx
    196d:	06                   	push   es
    196e:	57                   	push   di
    196f:	9a 99 20 78 25       	call   0x2578:0x2099
    1974:	c9                   	leave
    1975:	ca 08 00             	retf   0x8
    1978:	0a 23                	or     ah,BYTE PTR [bp+di]
    197a:	2c 23                	sub    al,0x23
    197c:	23 30                	and    si,WORD PTR [bx+si]
    197e:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1981:	23 23                	and    sp,WORD PTR [bp+di]
    1983:	05 23 2c             	add    ax,0x2c23
    1986:	23 23                	and    sp,WORD PTR [bp+di]
    1988:	30 05                	xor    BYTE PTR [di],al
    198a:	23 30                	and    si,WORD PTR [bx+si]
    198c:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    198f:	02 23                	add    ah,BYTE PTR [bp+di]
    1991:	30 55 89             	xor    BYTE PTR [di-0x77],dl
    1994:	e5 b8                	in     ax,0xb8
    1996:	10 01                	adc    BYTE PTR [bx+di],al
    1998:	9a 44 04 b2 19       	call   0x19b2:0x444
    199d:	81 ec 10 01          	sub    sp,0x110
    19a1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19a4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    19a7:	bf 22 00             	mov    di,0x22
    19aa:	b8 c5 19             	mov    ax,0x19c5
    19ad:	50                   	push   ax
    19ae:	57                   	push   di
    19af:	9a 55 22 cc 19       	call   0x19cc:0x2255
    19b4:	08 c0                	or     al,al
    19b6:	75 03                	jne    0x19bb
    19b8:	e9 4e 01             	jmp    0x1b09
    19bb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19be:	ff 76 0a             	push   WORD PTR [bp+0xa]
    19c1:	bf 22 00             	mov    di,0x22
    19c4:	b8 e6 19             	mov    ax,0x19e6
    19c7:	50                   	push   ax
    19c8:	57                   	push   di
    19c9:	9a 73 22 18 1a       	call   0x1a18:0x2273
    19ce:	89 c7                	mov    di,ax
    19d0:	8e c2                	mov    es,dx
    19d2:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    19d5:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    19d8:	8d be f8 fe          	lea    di,[bp-0x108]
    19dc:	16                   	push   ss
    19dd:	57                   	push   di
    19de:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    19e1:	06                   	push   es
    19e2:	57                   	push   di
    19e3:	9a 9f 1a f0 19       	call   0x19f0:0x1a9f
    19e8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    19eb:	06                   	push   es
    19ec:	57                   	push   di
    19ed:	9a 5f 1a 13 1b       	call   0x1b13:0x1a5f
    19f2:	89 c7                	mov    di,ax
    19f4:	8e c2                	mov    es,dx
    19f6:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    19fa:	06                   	push   es
    19fb:	57                   	push   di
    19fc:	9a 9b 3b 67 1b       	call   0x1b67:0x3b9b
    1a01:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a04:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1a07:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a0a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a0d:	bf 58 0a             	mov    di,0xa58
    1a10:	b8 28 1a             	mov    ax,0x1a28
    1a13:	50                   	push   ax
    1a14:	57                   	push   di
    1a15:	9a 55 22 2f 1a       	call   0x1a2f:0x2255
    1a1a:	08 c0                	or     al,al
    1a1c:	74 56                	je     0x1a74
    1a1e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a21:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a24:	bf 58 0a             	mov    di,0xa58
    1a27:	b8 7e 1a             	mov    ax,0x1a7e
    1a2a:	50                   	push   ax
    1a2b:	57                   	push   di
    1a2c:	9a 73 22 85 1a       	call   0x1a85:0x2273
    1a31:	89 c7                	mov    di,ax
    1a33:	8e c2                	mov    es,dx
    1a35:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1a38:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1a3b:	8d be f4 fe          	lea    di,[bp-0x10c]
    1a3f:	16                   	push   ss
    1a40:	57                   	push   di
    1a41:	bf 78 19             	mov    di,0x1978
    1a44:	0e                   	push   cs
    1a45:	57                   	push   di
    1a46:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1a49:	06                   	push   es
    1a4a:	57                   	push   di
    1a4b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a4e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1a52:	83 ec 0a             	sub    sp,0xa
    1a55:	89 e3                	mov    bx,sp
    1a57:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1a5b:	90                   	nop
    1a5c:	9b                   	fwait
    1a5d:	9a d4 10 d7 1a       	call   0x1ad7:0x10d4
    1a62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a65:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    1a6a:	06                   	push   es
    1a6b:	57                   	push   di
    1a6c:	9a 8c 1d e6 1a       	call   0x1ae6:0x1d8c
    1a71:	e9 95 00             	jmp    0x1b09
    1a74:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a77:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a7a:	bf c8 07             	mov    di,0x7c8
    1a7d:	b8 95 1a             	mov    ax,0x1a95
    1a80:	50                   	push   ax
    1a81:	57                   	push   di
    1a82:	9a 55 22 9c 1a       	call   0x1a9c:0x2255
    1a87:	08 c0                	or     al,al
    1a89:	74 5f                	je     0x1aea
    1a8b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a8e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a91:	bf c8 07             	mov    di,0x7c8
    1a94:	b8 79 1b             	mov    ax,0x1b79
    1a97:	50                   	push   ax
    1a98:	57                   	push   di
    1a99:	9a 73 22 1a 1b       	call   0x1b1a:0x2273
    1a9e:	89 c7                	mov    di,ax
    1aa0:	8e c2                	mov    es,dx
    1aa2:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1aa5:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1aa8:	8d be f0 fe          	lea    di,[bp-0x110]
    1aac:	16                   	push   ss
    1aad:	57                   	push   di
    1aae:	bf 83 19             	mov    di,0x1983
    1ab1:	0e                   	push   cs
    1ab2:	57                   	push   di
    1ab3:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1ab6:	06                   	push   es
    1ab7:	57                   	push   di
    1ab8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1abb:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1abf:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1ac2:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    1ac5:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    1ac9:	83 ec 0a             	sub    sp,0xa
    1acc:	89 e3                	mov    bx,sp
    1ace:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1ad2:	90                   	nop
    1ad3:	9b                   	fwait
    1ad4:	9a d4 10 84 23       	call   0x2384:0x10d4
    1ad9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1adc:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    1ae1:	06                   	push   es
    1ae2:	57                   	push   di
    1ae3:	9a 8c 1d 07 1b       	call   0x1b07:0x1d8c
    1ae8:	eb 1f                	jmp    0x1b09
    1aea:	8d be f8 fe          	lea    di,[bp-0x108]
    1aee:	16                   	push   ss
    1aef:	57                   	push   di
    1af0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1af3:	06                   	push   es
    1af4:	57                   	push   di
    1af5:	9a 24 15 34 1e       	call   0x1e34:0x1524
    1afa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1afd:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    1b02:	06                   	push   es
    1b03:	57                   	push   di
    1b04:	9a 8c 1d c9 1c       	call   0x1cc9:0x1d8c
    1b09:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b0c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1b0f:	bf 22 00             	mov    di,0x22
    1b12:	b8 2d 1b             	mov    ax,0x1b2d
    1b15:	50                   	push   ax
    1b16:	57                   	push   di
    1b17:	9a 55 22 34 1b       	call   0x1b34:0x2255
    1b1c:	08 c0                	or     al,al
    1b1e:	75 03                	jne    0x1b23
    1b20:	e9 d4 00             	jmp    0x1bf7
    1b23:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b26:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1b29:	bf 22 00             	mov    di,0x22
    1b2c:	b8 4e 1b             	mov    ax,0x1b4e
    1b2f:	50                   	push   ax
    1b30:	57                   	push   di
    1b31:	9a 73 22 80 1b       	call   0x1b80:0x2273
    1b36:	89 c7                	mov    di,ax
    1b38:	8e c2                	mov    es,dx
    1b3a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1b3d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1b40:	8d be f8 fe          	lea    di,[bp-0x108]
    1b44:	16                   	push   ss
    1b45:	57                   	push   di
    1b46:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b49:	06                   	push   es
    1b4a:	57                   	push   di
    1b4b:	9a 9f 1a 58 1b       	call   0x1b58:0x1a9f
    1b50:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b53:	06                   	push   es
    1b54:	57                   	push   di
    1b55:	9a 5f 1a 01 1c       	call   0x1c01:0x1a5f
    1b5a:	89 c7                	mov    di,ax
    1b5c:	8e c2                	mov    es,dx
    1b5e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1b62:	06                   	push   es
    1b63:	57                   	push   di
    1b64:	9a 9b 3b 6a 1e       	call   0x1e6a:0x3b9b
    1b69:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b6c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1b6f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b72:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b75:	bf 58 0a             	mov    di,0xa58
    1b78:	b8 90 1b             	mov    ax,0x1b90
    1b7b:	50                   	push   ax
    1b7c:	57                   	push   di
    1b7d:	9a 55 22 97 1b       	call   0x1b97:0x2255
    1b82:	08 c0                	or     al,al
    1b84:	74 2e                	je     0x1bb4
    1b86:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b89:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b8c:	bf 58 0a             	mov    di,0xa58
    1b8f:	b8 b0 1b             	mov    ax,0x1bb0
    1b92:	50                   	push   ax
    1b93:	57                   	push   di
    1b94:	9a 73 22 c5 1b       	call   0x1bc5:0x2273
    1b99:	89 c7                	mov    di,ax
    1b9b:	8e c2                	mov    es,dx
    1b9d:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1ba0:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1ba3:	bf 89 19             	mov    di,0x1989
    1ba6:	0e                   	push   cs
    1ba7:	57                   	push   di
    1ba8:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1bab:	06                   	push   es
    1bac:	57                   	push   di
    1bad:	9a f9 60 be 1b       	call   0x1bbe:0x60f9
    1bb2:	eb 43                	jmp    0x1bf7
    1bb4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1bb7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bba:	bf c8 07             	mov    di,0x7c8
    1bbd:	b8 d5 1b             	mov    ax,0x1bd5
    1bc0:	50                   	push   ax
    1bc1:	57                   	push   di
    1bc2:	9a 55 22 dc 1b       	call   0x1bdc:0x2255
    1bc7:	08 c0                	or     al,al
    1bc9:	74 2c                	je     0x1bf7
    1bcb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1bce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bd1:	bf c8 07             	mov    di,0x7c8
    1bd4:	b8 f5 1b             	mov    ax,0x1bf5
    1bd7:	50                   	push   ax
    1bd8:	57                   	push   di
    1bd9:	9a 73 22 08 1c       	call   0x1c08:0x2273
    1bde:	89 c7                	mov    di,ax
    1be0:	8e c2                	mov    es,dx
    1be2:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1be5:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1be8:	bf 8f 19             	mov    di,0x198f
    1beb:	0e                   	push   cs
    1bec:	57                   	push   di
    1bed:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1bf0:	06                   	push   es
    1bf1:	57                   	push   di
    1bf2:	9a f9 60 7c 1e       	call   0x1e7c:0x60f9
    1bf7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bfa:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bfd:	bf 26 06             	mov    di,0x626
    1c00:	b8 29 1c             	mov    ax,0x1c29
    1c03:	50                   	push   ax
    1c04:	57                   	push   di
    1c05:	9a 55 22 1c 1c       	call   0x1c1c:0x2255
    1c0a:	50                   	push   ax
    1c0b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c0e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1c11:	bf 14 1b             	mov    di,0x1b14
    1c14:	b8 d3 1c             	mov    ax,0x1cd3
    1c17:	50                   	push   ax
    1c18:	57                   	push   di
    1c19:	9a 55 22 30 1c       	call   0x1c30:0x2255
    1c1e:	50                   	push   ax
    1c1f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c22:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1c25:	bf 22 00             	mov    di,0x22
    1c28:	b8 96 1c             	mov    ax,0x1c96
    1c2b:	50                   	push   ax
    1c2c:	57                   	push   di
    1c2d:	9a 55 22 4d 1c       	call   0x1c4d:0x2255
    1c32:	5a                   	pop    dx
    1c33:	0a c2                	or     al,dl
    1c35:	5a                   	pop    dx
    1c36:	0a c2                	or     al,dl
    1c38:	08 c0                	or     al,al
    1c3a:	74 50                	je     0x1c8c
    1c3c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c3f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1c42:	bf da 05             	mov    di,0x5da
    1c45:	b8 e3 26             	mov    ax,0x26e3
    1c48:	50                   	push   ax
    1c49:	57                   	push   di
    1c4a:	9a 73 22 71 1c       	call   0x1c71:0x2273
    1c4f:	89 c7                	mov    di,ax
    1c51:	8e c2                	mov    es,dx
    1c53:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1c56:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1c59:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1c5d:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    1c61:	09 d2                	or     dx,dx
    1c63:	79 07                	jns    0x1c6c
    1c65:	f7 d2                	not    dx
    1c67:	f7 d8                	neg    ax
    1c69:	83 da ff             	sbb    dx,0xffff
    1c6c:	71 05                	jno    0x1c73
    1c6e:	9a 3e 04 7f 1c       	call   0x1c7f:0x43e
    1c73:	f7 d2                	not    dx
    1c75:	f7 d8                	neg    ax
    1c77:	83 da ff             	sbb    dx,0xffff
    1c7a:	71 05                	jno    0x1c81
    1c7c:	9a 3e 04 9d 1c       	call   0x1c9d:0x43e
    1c81:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c84:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1c88:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1c8c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c8f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1c92:	bf 22 00             	mov    di,0x22
    1c95:	b8 ad 1c             	mov    ax,0x1cad
    1c98:	50                   	push   ax
    1c99:	57                   	push   di
    1c9a:	9a 55 22 b4 1c       	call   0x1cb4:0x2255
    1c9f:	08 c0                	or     al,al
    1ca1:	74 35                	je     0x1cd8
    1ca3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ca6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ca9:	bf 22 00             	mov    di,0x22
    1cac:	b8 e2 1c             	mov    ax,0x1ce2
    1caf:	50                   	push   ax
    1cb0:	57                   	push   di
    1cb1:	9a 73 22 e9 1c       	call   0x1ce9:0x2273
    1cb6:	89 c7                	mov    di,ax
    1cb8:	8e c2                	mov    es,dx
    1cba:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1cbd:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1cc0:	6a ff                	push   0xffff
    1cc2:	6a fa                	push   0xfffa
    1cc4:	06                   	push   es
    1cc5:	57                   	push   di
    1cc6:	9a d5 1e 15 1d       	call   0x1d15:0x1ed5
    1ccb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cce:	06                   	push   es
    1ccf:	57                   	push   di
    1cd0:	9a 3f 4a 1f 1d       	call   0x1d1f:0x4a3f
    1cd5:	e9 94 00             	jmp    0x1d6c
    1cd8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cdb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1cde:	bf a2 0b             	mov    di,0xba2
    1ce1:	b8 f9 1c             	mov    ax,0x1cf9
    1ce4:	50                   	push   ax
    1ce5:	57                   	push   di
    1ce6:	9a 55 22 00 1d       	call   0x1d00:0x2255
    1ceb:	08 c0                	or     al,al
    1ced:	74 34                	je     0x1d23
    1cef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cf2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1cf5:	bf a2 0b             	mov    di,0xba2
    1cf8:	b8 9e 1d             	mov    ax,0x1d9e
    1cfb:	50                   	push   ax
    1cfc:	57                   	push   di
    1cfd:	9a 73 22 34 1d       	call   0x1d34:0x2273
    1d02:	89 c7                	mov    di,ax
    1d04:	8e c2                	mov    es,dx
    1d06:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1d09:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1d0c:	6a ff                	push   0xffff
    1d0e:	6a fa                	push   0xfffa
    1d10:	06                   	push   es
    1d11:	57                   	push   di
    1d12:	9a d5 1e 60 1d       	call   0x1d60:0x1ed5
    1d17:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d1a:	06                   	push   es
    1d1b:	57                   	push   di
    1d1c:	9a e7 5b 2d 1d       	call   0x1d2d:0x5be7
    1d21:	eb 49                	jmp    0x1d6c
    1d23:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d26:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d29:	bf 14 1b             	mov    di,0x1b14
    1d2c:	b8 44 1d             	mov    ax,0x1d44
    1d2f:	50                   	push   ax
    1d30:	57                   	push   di
    1d31:	9a 55 22 4b 1d       	call   0x1d4b:0x2255
    1d36:	08 c0                	or     al,al
    1d38:	74 32                	je     0x1d6c
    1d3a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d3d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d40:	bf 14 1b             	mov    di,0x1b14
    1d43:	b8 6a 1d             	mov    ax,0x1d6a
    1d46:	50                   	push   ax
    1d47:	57                   	push   di
    1d48:	9a 73 22 7a 1d       	call   0x1d7a:0x2273
    1d4d:	89 c7                	mov    di,ax
    1d4f:	8e c2                	mov    es,dx
    1d51:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1d54:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1d57:	6a ff                	push   0xffff
    1d59:	6a fa                	push   0xfffa
    1d5b:	06                   	push   es
    1d5c:	57                   	push   di
    1d5d:	9a d5 1e bd 1d       	call   0x1dbd:0x1ed5
    1d62:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d65:	06                   	push   es
    1d66:	57                   	push   di
    1d67:	9a e7 5b 8a 1d       	call   0x1d8a:0x5be7
    1d6c:	c9                   	leave
    1d6d:	ca 08 00             	retf   0x8
    1d70:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1d73:	e5 b8                	in     ax,0xb8
    1d75:	08 02                	or     BYTE PTR [bp+si],al
    1d77:	9a 44 04 91 1d       	call   0x1d91:0x444
    1d7c:	81 ec 08 02          	sub    sp,0x208
    1d80:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d83:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d86:	bf 14 1b             	mov    di,0x1b14
    1d89:	b8 7c 24             	mov    ax,0x247c
    1d8c:	50                   	push   ax
    1d8d:	57                   	push   di
    1d8e:	9a 55 22 a5 1d       	call   0x1da5:0x2255
    1d93:	50                   	push   ax
    1d94:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d97:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d9a:	bf 22 00             	mov    di,0x22
    1d9d:	b8 eb 1d             	mov    ax,0x1deb
    1da0:	50                   	push   ax
    1da1:	57                   	push   di
    1da2:	9a 55 22 f2 1d       	call   0x1df2:0x2255
    1da7:	5a                   	pop    dx
    1da8:	0a c2                	or     al,dl
    1daa:	08 c0                	or     al,al
    1dac:	74 11                	je     0x1dbf
    1dae:	6a 00                	push   0x0
    1db0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db3:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    1db8:	06                   	push   es
    1db9:	57                   	push   di
    1dba:	9a 77 1c d1 1d       	call   0x1dd1:0x1c77
    1dbf:	bf 70 1d             	mov    di,0x1d70
    1dc2:	0e                   	push   cs
    1dc3:	57                   	push   di
    1dc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dc7:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    1dcc:	06                   	push   es
    1dcd:	57                   	push   di
    1dce:	9a 8c 1d eb 1f       	call   0x1feb:0x1d8c
    1dd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd6:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
    1ddc:	75 03                	jne    0x1de1
    1dde:	e9 9e 03             	jmp    0x217f
    1de1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1de4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1de7:	bf 22 00             	mov    di,0x22
    1dea:	b8 05 1e             	mov    ax,0x1e05
    1ded:	50                   	push   ax
    1dee:	57                   	push   di
    1def:	9a 55 22 0c 1e       	call   0x1e0c:0x2255
    1df4:	08 c0                	or     al,al
    1df6:	75 03                	jne    0x1dfb
    1df8:	e9 9d 01             	jmp    0x1f98
    1dfb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1dfe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e01:	bf 22 00             	mov    di,0x22
    1e04:	b8 1d 1e             	mov    ax,0x1e1d
    1e07:	50                   	push   ax
    1e08:	57                   	push   di
    1e09:	9a 73 22 83 1e       	call   0x1e83:0x2273
    1e0e:	89 c7                	mov    di,ax
    1e10:	8e c2                	mov    es,dx
    1e12:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1e15:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1e18:	06                   	push   es
    1e19:	57                   	push   di
    1e1a:	9a e4 1a 51 1e       	call   0x1e51:0x1ae4
    1e1f:	08 c0                	or     al,al
    1e21:	74 03                	je     0x1e26
    1e23:	e9 72 01             	jmp    0x1f98
    1e26:	8d be f8 fe          	lea    di,[bp-0x108]
    1e2a:	16                   	push   ss
    1e2b:	57                   	push   di
    1e2c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e2f:	06                   	push   es
    1e30:	57                   	push   di
    1e31:	9a d8 14 0e 22       	call   0x220e:0x14d8
    1e36:	83 c4 04             	add    sp,0x4
    1e39:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    1e3e:	74 03                	je     0x1e43
    1e40:	e9 36 01             	jmp    0x1f79
    1e43:	8d be f8 fd          	lea    di,[bp-0x208]
    1e47:	16                   	push   ss
    1e48:	57                   	push   di
    1e49:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e4c:	06                   	push   es
    1e4d:	57                   	push   di
    1e4e:	9a 9f 1a 5b 1e       	call   0x1e5b:0x1a9f
    1e53:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e56:	06                   	push   es
    1e57:	57                   	push   di
    1e58:	9a 5f 1a bc 1e       	call   0x1ebc:0x1a5f
    1e5d:	89 c7                	mov    di,ax
    1e5f:	8e c2                	mov    es,dx
    1e61:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e65:	06                   	push   es
    1e66:	57                   	push   di
    1e67:	9a 9b 3b 21 20       	call   0x2021:0x3b9b
    1e6c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e6f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1e72:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e75:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1e78:	bf 58 0a             	mov    di,0xa58
    1e7b:	b8 93 1e             	mov    ax,0x1e93
    1e7e:	50                   	push   ax
    1e7f:	57                   	push   di
    1e80:	9a 55 22 9a 1e       	call   0x1e9a:0x2255
    1e85:	08 c0                	or     al,al
    1e87:	74 45                	je     0x1ece
    1e89:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e8c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1e8f:	bf 58 0a             	mov    di,0xa58
    1e92:	b8 d8 1e             	mov    ax,0x1ed8
    1e95:	50                   	push   ax
    1e96:	57                   	push   di
    1e97:	9a 73 22 df 1e       	call   0x1edf:0x2273
    1e9c:	89 c7                	mov    di,ax
    1e9e:	8e c2                	mov    es,dx
    1ea0:	06                   	push   es
    1ea1:	57                   	push   di
    1ea2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ea5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1ea9:	83 ec 08             	sub    sp,0x8
    1eac:	89 e3                	mov    bx,sp
    1eae:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1eb2:	90                   	nop
    1eb3:	9b                   	fwait
    1eb4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1eb7:	06                   	push   es
    1eb8:	57                   	push   di
    1eb9:	9a 18 1b 18 1f       	call   0x1f18:0x1b18
    1ebe:	89 c7                	mov    di,ax
    1ec0:	8e c2                	mov    es,dx
    1ec2:	06                   	push   es
    1ec3:	57                   	push   di
    1ec4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ec7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    1ecb:	e9 ab 00             	jmp    0x1f79
    1ece:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ed1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ed4:	bf 67 0c             	mov    di,0xc67
    1ed7:	b8 ef 1e             	mov    ax,0x1eef
    1eda:	50                   	push   ax
    1edb:	57                   	push   di
    1edc:	9a 55 22 f6 1e       	call   0x1ef6:0x2255
    1ee1:	08 c0                	or     al,al
    1ee3:	74 44                	je     0x1f29
    1ee5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ee8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1eeb:	bf 67 0c             	mov    di,0xc67
    1eee:	b8 33 1f             	mov    ax,0x1f33
    1ef1:	50                   	push   ax
    1ef2:	57                   	push   di
    1ef3:	9a 73 22 3a 1f       	call   0x1f3a:0x2273
    1ef8:	89 c7                	mov    di,ax
    1efa:	8e c2                	mov    es,dx
    1efc:	06                   	push   es
    1efd:	57                   	push   di
    1efe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f01:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1f05:	83 ec 08             	sub    sp,0x8
    1f08:	89 e3                	mov    bx,sp
    1f0a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1f0e:	90                   	nop
    1f0f:	9b                   	fwait
    1f10:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f13:	06                   	push   es
    1f14:	57                   	push   di
    1f15:	9a 18 1b 6a 1f       	call   0x1f6a:0x1b18
    1f1a:	89 c7                	mov    di,ax
    1f1c:	8e c2                	mov    es,dx
    1f1e:	06                   	push   es
    1f1f:	57                   	push   di
    1f20:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f23:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    1f27:	eb 50                	jmp    0x1f79
    1f29:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f2c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1f2f:	bf c8 07             	mov    di,0x7c8
    1f32:	b8 4a 1f             	mov    ax,0x1f4a
    1f35:	50                   	push   ax
    1f36:	57                   	push   di
    1f37:	9a 55 22 51 1f       	call   0x1f51:0x2255
    1f3c:	08 c0                	or     al,al
    1f3e:	74 39                	je     0x1f79
    1f40:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f43:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1f46:	bf c8 07             	mov    di,0x7c8
    1f49:	b8 33 20             	mov    ax,0x2033
    1f4c:	50                   	push   ax
    1f4d:	57                   	push   di
    1f4e:	9a 73 22 8a 1f       	call   0x1f8a:0x2273
    1f53:	89 c7                	mov    di,ax
    1f55:	8e c2                	mov    es,dx
    1f57:	06                   	push   es
    1f58:	57                   	push   di
    1f59:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f5c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1f60:	52                   	push   dx
    1f61:	50                   	push   ax
    1f62:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f65:	06                   	push   es
    1f66:	57                   	push   di
    1f67:	9a 18 1b 83 1f       	call   0x1f83:0x1b18
    1f6c:	89 c7                	mov    di,ax
    1f6e:	8e c2                	mov    es,dx
    1f70:	06                   	push   es
    1f71:	57                   	push   di
    1f72:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f75:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    1f79:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f7c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f7f:	bf 22 00             	mov    di,0x22
    1f82:	b8 a2 1f             	mov    ax,0x1fa2
    1f85:	50                   	push   ax
    1f86:	57                   	push   di
    1f87:	9a 73 22 a9 1f       	call   0x1fa9:0x2273
    1f8c:	52                   	push   dx
    1f8d:	50                   	push   ax
    1f8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f91:	06                   	push   es
    1f92:	57                   	push   di
    1f93:	9a 08 15 87 21       	call   0x2187:0x1508
    1f98:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f9b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f9e:	bf a2 0b             	mov    di,0xba2
    1fa1:	b8 bc 1f             	mov    ax,0x1fbc
    1fa4:	50                   	push   ax
    1fa5:	57                   	push   di
    1fa6:	9a 55 22 c3 1f       	call   0x1fc3:0x2255
    1fab:	08 c0                	or     al,al
    1fad:	75 03                	jne    0x1fb2
    1faf:	e9 7e 01             	jmp    0x2130
    1fb2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1fb5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fb8:	bf a2 0b             	mov    di,0xba2
    1fbb:	b8 d4 1f             	mov    ax,0x1fd4
    1fbe:	50                   	push   ax
    1fbf:	57                   	push   di
    1fc0:	9a 73 22 3a 20       	call   0x203a:0x2273
    1fc5:	89 c7                	mov    di,ax
    1fc7:	8e c2                	mov    es,dx
    1fc9:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1fcc:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1fcf:	06                   	push   es
    1fd0:	57                   	push   di
    1fd1:	9a d7 2a 08 20       	call   0x2008:0x2ad7
    1fd6:	08 c0                	or     al,al
    1fd8:	74 03                	je     0x1fdd
    1fda:	e9 53 01             	jmp    0x2130
    1fdd:	8d be f8 fe          	lea    di,[bp-0x108]
    1fe1:	16                   	push   ss
    1fe2:	57                   	push   di
    1fe3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1fe6:	06                   	push   es
    1fe7:	57                   	push   di
    1fe8:	9a 53 1d b4 21       	call   0x21b4:0x1d53
    1fed:	83 c4 04             	add    sp,0x4
    1ff0:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    1ff5:	74 03                	je     0x1ffa
    1ff7:	e9 36 01             	jmp    0x2130
    1ffa:	8d be f8 fd          	lea    di,[bp-0x208]
    1ffe:	16                   	push   ss
    1fff:	57                   	push   di
    2000:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2003:	06                   	push   es
    2004:	57                   	push   di
    2005:	9a 92 2a 12 20       	call   0x2012:0x2a92
    200a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    200d:	06                   	push   es
    200e:	57                   	push   di
    200f:	9a 52 2a 73 20       	call   0x2073:0x2a52
    2014:	89 c7                	mov    di,ax
    2016:	8e c2                	mov    es,dx
    2018:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    201c:	06                   	push   es
    201d:	57                   	push   di
    201e:	9a 9b 3b 20 23       	call   0x2320:0x3b9b
    2023:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2026:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2029:	ff 76 fe             	push   WORD PTR [bp-0x2]
    202c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    202f:	bf 58 0a             	mov    di,0xa58
    2032:	b8 4a 20             	mov    ax,0x204a
    2035:	50                   	push   ax
    2036:	57                   	push   di
    2037:	9a 55 22 51 20       	call   0x2051:0x2255
    203c:	08 c0                	or     al,al
    203e:	74 45                	je     0x2085
    2040:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2043:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2046:	bf 58 0a             	mov    di,0xa58
    2049:	b8 8f 20             	mov    ax,0x208f
    204c:	50                   	push   ax
    204d:	57                   	push   di
    204e:	9a 73 22 96 20       	call   0x2096:0x2273
    2053:	89 c7                	mov    di,ax
    2055:	8e c2                	mov    es,dx
    2057:	06                   	push   es
    2058:	57                   	push   di
    2059:	26 c4 3d             	les    di,DWORD PTR es:[di]
    205c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2060:	83 ec 08             	sub    sp,0x8
    2063:	89 e3                	mov    bx,sp
    2065:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2069:	90                   	nop
    206a:	9b                   	fwait
    206b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    206e:	06                   	push   es
    206f:	57                   	push   di
    2070:	9a 0b 2b cf 20       	call   0x20cf:0x2b0b
    2075:	89 c7                	mov    di,ax
    2077:	8e c2                	mov    es,dx
    2079:	06                   	push   es
    207a:	57                   	push   di
    207b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    207e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2082:	e9 ab 00             	jmp    0x2130
    2085:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2088:	ff 76 fc             	push   WORD PTR [bp-0x4]
    208b:	bf 67 0c             	mov    di,0xc67
    208e:	b8 a6 20             	mov    ax,0x20a6
    2091:	50                   	push   ax
    2092:	57                   	push   di
    2093:	9a 55 22 ad 20       	call   0x20ad:0x2255
    2098:	08 c0                	or     al,al
    209a:	74 44                	je     0x20e0
    209c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    209f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20a2:	bf 67 0c             	mov    di,0xc67
    20a5:	b8 ea 20             	mov    ax,0x20ea
    20a8:	50                   	push   ax
    20a9:	57                   	push   di
    20aa:	9a 73 22 f1 20       	call   0x20f1:0x2273
    20af:	89 c7                	mov    di,ax
    20b1:	8e c2                	mov    es,dx
    20b3:	06                   	push   es
    20b4:	57                   	push   di
    20b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20b8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    20bc:	83 ec 08             	sub    sp,0x8
    20bf:	89 e3                	mov    bx,sp
    20c1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    20c5:	90                   	nop
    20c6:	9b                   	fwait
    20c7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20ca:	06                   	push   es
    20cb:	57                   	push   di
    20cc:	9a 0b 2b 21 21       	call   0x2121:0x2b0b
    20d1:	89 c7                	mov    di,ax
    20d3:	8e c2                	mov    es,dx
    20d5:	06                   	push   es
    20d6:	57                   	push   di
    20d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20da:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    20de:	eb 50                	jmp    0x2130
    20e0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20e3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20e6:	bf c8 07             	mov    di,0x7c8
    20e9:	b8 01 21             	mov    ax,0x2101
    20ec:	50                   	push   ax
    20ed:	57                   	push   di
    20ee:	9a 55 22 08 21       	call   0x2108:0x2255
    20f3:	08 c0                	or     al,al
    20f5:	74 39                	je     0x2130
    20f7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20fa:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20fd:	bf c8 07             	mov    di,0x7c8
    2100:	b8 32 23             	mov    ax,0x2332
    2103:	50                   	push   ax
    2104:	57                   	push   di
    2105:	9a 73 22 41 21       	call   0x2141:0x2273
    210a:	89 c7                	mov    di,ax
    210c:	8e c2                	mov    es,dx
    210e:	06                   	push   es
    210f:	57                   	push   di
    2110:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2113:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2117:	52                   	push   dx
    2118:	50                   	push   ax
    2119:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    211c:	06                   	push   es
    211d:	57                   	push   di
    211e:	9a 0b 2b cb 21       	call   0x21cb:0x2b0b
    2123:	89 c7                	mov    di,ax
    2125:	8e c2                	mov    es,dx
    2127:	06                   	push   es
    2128:	57                   	push   di
    2129:	26 c4 3d             	les    di,DWORD PTR es:[di]
    212c:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    2130:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2133:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2136:	bf eb 03             	mov    di,0x3eb
    2139:	b8 51 21             	mov    ax,0x2151
    213c:	50                   	push   ax
    213d:	57                   	push   di
    213e:	9a 55 22 58 21       	call   0x2158:0x2255
    2143:	08 c0                	or     al,al
    2145:	74 38                	je     0x217f
    2147:	ff 76 0c             	push   WORD PTR [bp+0xc]
    214a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    214d:	bf eb 03             	mov    di,0x3eb
    2150:	b8 71 21             	mov    ax,0x2171
    2153:	50                   	push   ax
    2154:	57                   	push   di
    2155:	9a 73 22 96 21       	call   0x2196:0x2273
    215a:	89 c7                	mov    di,ax
    215c:	8e c2                	mov    es,dx
    215e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2161:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2164:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    216a:	75 13                	jne    0x217f
    216c:	06                   	push   es
    216d:	57                   	push   di
    216e:	9a 33 17 7d 21       	call   0x217d:0x1733
    2173:	52                   	push   dx
    2174:	50                   	push   ax
    2175:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2178:	06                   	push   es
    2179:	57                   	push   di
    217a:	9a 8b 17 ad 2f       	call   0x2fad:0x178b
    217f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2182:	06                   	push   es
    2183:	57                   	push   di
    2184:	9a 69 31 ca 2a       	call   0x2aca:0x3169
    2189:	c9                   	leave
    218a:	ca 08 00             	retf   0x8
    218d:	55                   	push   bp
    218e:	89 e5                	mov    bp,sp
    2190:	b8 04 01             	mov    ax,0x104
    2193:	9a 44 04 d2 21       	call   0x21d2:0x444
    2198:	81 ec 04 01          	sub    sp,0x104
    219c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    219f:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    21a3:	75 13                	jne    0x21b8
    21a5:	6a 00                	push   0x0
    21a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21aa:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    21af:	06                   	push   es
    21b0:	57                   	push   di
    21b1:	9a 77 1c 1d 22       	call   0x221d:0x1c77
    21b6:	eb 67                	jmp    0x221f
    21b8:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    21bb:	26 83 3d 09          	cmp    WORD PTR es:[di],0x9
    21bf:	74 5e                	je     0x221f
    21c1:	ff 76 12             	push   WORD PTR [bp+0x12]
    21c4:	ff 76 10             	push   WORD PTR [bp+0x10]
    21c7:	bf 22 00             	mov    di,0x22
    21ca:	b8 e2 21             	mov    ax,0x21e2
    21cd:	50                   	push   ax
    21ce:	57                   	push   di
    21cf:	9a 55 22 e9 21       	call   0x21e9:0x2255
    21d4:	08 c0                	or     al,al
    21d6:	74 47                	je     0x221f
    21d8:	ff 76 12             	push   WORD PTR [bp+0x12]
    21db:	ff 76 10             	push   WORD PTR [bp+0x10]
    21de:	bf 22 00             	mov    di,0x22
    21e1:	b8 fa 21             	mov    ax,0x21fa
    21e4:	50                   	push   ax
    21e5:	57                   	push   di
    21e6:	9a 73 22 3f 22       	call   0x223f:0x2273
    21eb:	89 c7                	mov    di,ax
    21ed:	8e c2                	mov    es,dx
    21ef:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21f2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21f5:	06                   	push   es
    21f6:	57                   	push   di
    21f7:	9a e4 1a c8 22       	call   0x22c8:0x1ae4
    21fc:	08 c0                	or     al,al
    21fe:	75 1f                	jne    0x221f
    2200:	8d be fc fe          	lea    di,[bp-0x104]
    2204:	16                   	push   ss
    2205:	57                   	push   di
    2206:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2209:	06                   	push   es
    220a:	57                   	push   di
    220b:	9a 24 15 21 24       	call   0x2421:0x1524
    2210:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2213:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    2218:	06                   	push   es
    2219:	57                   	push   di
    221a:	9a 8c 1d 58 22       	call   0x2258:0x1d8c
    221f:	c9                   	leave
    2220:	ca 0e 00             	retf   0xe
    2223:	0a 23                	or     ah,BYTE PTR [bp+di]
    2225:	2c 23                	sub    al,0x23
    2227:	23 30                	and    si,WORD PTR [bx+si]
    2229:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    222c:	23 23                	and    sp,WORD PTR [bp+di]
    222e:	05 23 2c             	add    ax,0x2c23
    2231:	23 23                	and    sp,WORD PTR [bp+di]
    2233:	30 01                	xor    BYTE PTR [bx+di],al
    2235:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2238:	e5 b8                	in     ax,0xb8
    223a:	14 02                	adc    al,0x2
    223c:	9a 44 04 5f 22       	call   0x225f:0x444
    2241:	81 ec 14 02          	sub    sp,0x214
    2245:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2248:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    224c:	75 4d                	jne    0x229b
    224e:	ff 76 12             	push   WORD PTR [bp+0x12]
    2251:	ff 76 10             	push   WORD PTR [bp+0x10]
    2254:	bf c1 05             	mov    di,0x5c1
    2257:	b8 79 22             	mov    ax,0x2279
    225a:	50                   	push   ax
    225b:	57                   	push   di
    225c:	9a 55 22 80 22       	call   0x2280:0x2255
    2261:	08 c0                	or     al,al
    2263:	74 36                	je     0x229b
    2265:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2268:	31 c0                	xor    ax,ax
    226a:	26 89 05             	mov    WORD PTR es:[di],ax
    226d:	6a 08                	push   0x8
    226f:	ff 76 12             	push   WORD PTR [bp+0x12]
    2272:	ff 76 10             	push   WORD PTR [bp+0x10]
    2275:	bf c1 05             	mov    di,0x5c1
    2278:	b8 6a 24             	mov    ax,0x246a
    227b:	50                   	push   ax
    227c:	57                   	push   di
    227d:	9a 73 22 cf 22       	call   0x22cf:0x2273
    2282:	89 c7                	mov    di,ax
    2284:	8e c2                	mov    es,dx
    2286:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    228b:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    2290:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2294:	06                   	push   es
    2295:	57                   	push   di
    2296:	9a b2 77 51 25       	call   0x2551:0x77b2
    229b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    229e:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    22a2:	74 03                	je     0x22a7
    22a4:	e9 1a 04             	jmp    0x26c1
    22a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22aa:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    22af:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    22b4:	74 03                	je     0x22b9
    22b6:	e9 08 04             	jmp    0x26c1
    22b9:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    22be:	ff 76 12             	push   WORD PTR [bp+0x12]
    22c1:	ff 76 10             	push   WORD PTR [bp+0x10]
    22c4:	bf 22 00             	mov    di,0x22
    22c7:	b8 e2 22             	mov    ax,0x22e2
    22ca:	50                   	push   ax
    22cb:	57                   	push   di
    22cc:	9a 55 22 e9 22       	call   0x22e9:0x2255
    22d1:	08 c0                	or     al,al
    22d3:	75 03                	jne    0x22d8
    22d5:	e9 9a 01             	jmp    0x2472
    22d8:	ff 76 12             	push   WORD PTR [bp+0x12]
    22db:	ff 76 10             	push   WORD PTR [bp+0x10]
    22de:	bf 22 00             	mov    di,0x22
    22e1:	b8 06 23             	mov    ax,0x2306
    22e4:	50                   	push   ax
    22e5:	57                   	push   di
    22e6:	9a 73 22 39 23       	call   0x2339:0x2273
    22eb:	89 c7                	mov    di,ax
    22ed:	8e c2                	mov    es,dx
    22ef:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    22f3:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    22f7:	8d be f4 fd          	lea    di,[bp-0x20c]
    22fb:	16                   	push   ss
    22fc:	57                   	push   di
    22fd:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2301:	06                   	push   es
    2302:	57                   	push   di
    2303:	9a 9f 1a 11 23       	call   0x2311:0x1a9f
    2308:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    230c:	06                   	push   es
    230d:	57                   	push   di
    230e:	9a 5f 1a 17 27       	call   0x2717:0x1a5f
    2313:	89 c7                	mov    di,ax
    2315:	8e c2                	mov    es,dx
    2317:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    231b:	06                   	push   es
    231c:	57                   	push   di
    231d:	9a 9b 3b 37 2b       	call   0x2b37:0x3b9b
    2322:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2325:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2328:	ff 76 fa             	push   WORD PTR [bp-0x6]
    232b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    232e:	bf 58 0a             	mov    di,0xa58
    2331:	b8 49 23             	mov    ax,0x2349
    2334:	50                   	push   ax
    2335:	57                   	push   di
    2336:	9a 55 22 50 23       	call   0x2350:0x2255
    233b:	08 c0                	or     al,al
    233d:	74 58                	je     0x2397
    233f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2342:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2345:	bf 58 0a             	mov    di,0xa58
    2348:	b8 a1 23             	mov    ax,0x23a1
    234b:	50                   	push   ax
    234c:	57                   	push   di
    234d:	9a 73 22 92 23       	call   0x2392:0x2273
    2352:	89 c7                	mov    di,ax
    2354:	8e c2                	mov    es,dx
    2356:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    235a:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    235e:	8d be f0 fd          	lea    di,[bp-0x210]
    2362:	16                   	push   ss
    2363:	57                   	push   di
    2364:	bf 23 22             	mov    di,0x2223
    2367:	0e                   	push   cs
    2368:	57                   	push   di
    2369:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    236d:	06                   	push   es
    236e:	57                   	push   di
    236f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2372:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2376:	83 ec 0a             	sub    sp,0xa
    2379:	89 e3                	mov    bx,sp
    237b:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    237f:	90                   	nop
    2380:	9b                   	fwait
    2381:	9a d4 10 00 24       	call   0x2400:0x10d4
    2386:	8d be f8 fe          	lea    di,[bp-0x108]
    238a:	16                   	push   ss
    238b:	57                   	push   di
    238c:	68 ff 00             	push   0xff
    238f:	9a e7 17 a8 23       	call   0x23a8:0x17e7
    2394:	e9 9a 00             	jmp    0x2431
    2397:	ff 76 fa             	push   WORD PTR [bp-0x6]
    239a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    239d:	bf c8 07             	mov    di,0x7c8
    23a0:	b8 b8 23             	mov    ax,0x23b8
    23a3:	50                   	push   ax
    23a4:	57                   	push   di
    23a5:	9a 55 22 bf 23       	call   0x23bf:0x2255
    23aa:	08 c0                	or     al,al
    23ac:	74 64                	je     0x2412
    23ae:	ff 76 fa             	push   WORD PTR [bp-0x6]
    23b1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    23b4:	bf c8 07             	mov    di,0x7c8
    23b7:	b8 51 2b             	mov    ax,0x2b51
    23ba:	50                   	push   ax
    23bb:	57                   	push   di
    23bc:	9a 73 22 0e 24       	call   0x240e:0x2273
    23c1:	89 c7                	mov    di,ax
    23c3:	8e c2                	mov    es,dx
    23c5:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    23c9:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    23cd:	8d be ec fd          	lea    di,[bp-0x214]
    23d1:	16                   	push   ss
    23d2:	57                   	push   di
    23d3:	bf 2e 22             	mov    di,0x222e
    23d6:	0e                   	push   cs
    23d7:	57                   	push   di
    23d8:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    23dc:	06                   	push   es
    23dd:	57                   	push   di
    23de:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23e1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    23e5:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    23e9:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    23ed:	9b db 86 ec fe       	fild   DWORD PTR [bp-0x114]
    23f2:	83 ec 0a             	sub    sp,0xa
    23f5:	89 e3                	mov    bx,sp
    23f7:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    23fb:	90                   	nop
    23fc:	9b                   	fwait
    23fd:	9a d4 10 9d 2d       	call   0x2d9d:0x10d4
    2402:	8d be f8 fe          	lea    di,[bp-0x108]
    2406:	16                   	push   ss
    2407:	57                   	push   di
    2408:	68 ff 00             	push   0xff
    240b:	9a e7 17 2f 24       	call   0x242f:0x17e7
    2410:	eb 1f                	jmp    0x2431
    2412:	8d be f4 fd          	lea    di,[bp-0x20c]
    2416:	16                   	push   ss
    2417:	57                   	push   di
    2418:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    241c:	06                   	push   es
    241d:	57                   	push   di
    241e:	9a 24 15 ff ff       	call   0xffff:0x1524
    2423:	8d be f8 fe          	lea    di,[bp-0x108]
    2427:	16                   	push   ss
    2428:	57                   	push   di
    2429:	68 ff 00             	push   0xff
    242c:	9a e7 17 41 24       	call   0x2441:0x17e7
    2431:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2435:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2439:	2d 04 00             	sub    ax,0x4
    243c:	71 05                	jno    0x2443
    243e:	9a 3e 04 56 24       	call   0x2456:0x43e
    2443:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2446:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    244a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    244e:	2d 04 00             	sub    ax,0x4
    2451:	71 05                	jno    0x2458
    2453:	9a 3e 04 83 24       	call   0x2483:0x43e
    2458:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    245b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    245e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2461:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2465:	06                   	push   es
    2466:	57                   	push   di
    2467:	9a d4 19 ba 24       	call   0x24ba:0x19d4
    246c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    246f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2472:	ff 76 12             	push   WORD PTR [bp+0x12]
    2475:	ff 76 10             	push   WORD PTR [bp+0x10]
    2478:	bf 14 1b             	mov    di,0x1b14
    247b:	b8 96 24             	mov    ax,0x2496
    247e:	50                   	push   ax
    247f:	57                   	push   di
    2480:	9a 55 22 9d 24       	call   0x249d:0x2255
    2485:	08 c0                	or     al,al
    2487:	75 03                	jne    0x248c
    2489:	e9 7f 00             	jmp    0x250b
    248c:	ff 76 12             	push   WORD PTR [bp+0x12]
    248f:	ff 76 10             	push   WORD PTR [bp+0x10]
    2492:	bf 14 1b             	mov    di,0x1b14
    2495:	b8 79 27             	mov    ax,0x2779
    2498:	50                   	push   ax
    2499:	57                   	push   di
    249a:	9a 73 22 c8 24       	call   0x24c8:0x2273
    249f:	89 c7                	mov    di,ax
    24a1:	8e c2                	mov    es,dx
    24a3:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    24a7:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    24ab:	8d be f4 fd          	lea    di,[bp-0x20c]
    24af:	16                   	push   ss
    24b0:	57                   	push   di
    24b1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24b5:	06                   	push   es
    24b6:	57                   	push   di
    24b7:	9a 53 1d 03 25       	call   0x2503:0x1d53
    24bc:	8d be f8 fe          	lea    di,[bp-0x108]
    24c0:	16                   	push   ss
    24c1:	57                   	push   di
    24c2:	68 ff 00             	push   0xff
    24c5:	9a e7 17 da 24       	call   0x24da:0x17e7
    24ca:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24ce:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    24d2:	2d 04 00             	sub    ax,0x4
    24d5:	71 05                	jno    0x24dc
    24d7:	9a 3e 04 ef 24       	call   0x24ef:0x43e
    24dc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24df:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24e3:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    24e7:	2d 04 00             	sub    ax,0x4
    24ea:	71 05                	jno    0x24f1
    24ec:	9a 3e 04 23 25       	call   0x2523:0x43e
    24f1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    24f4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    24f7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    24fa:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24fe:	06                   	push   es
    24ff:	57                   	push   di
    2500:	9a d4 19 47 25       	call   0x2547:0x19d4
    2505:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2508:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    250b:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    2510:	77 03                	ja     0x2515
    2512:	e9 ac 01             	jmp    0x26c1
    2515:	8d be f8 fd          	lea    di,[bp-0x208]
    2519:	16                   	push   ss
    251a:	57                   	push   di
    251b:	bf 34 22             	mov    di,0x2234
    251e:	0e                   	push   cs
    251f:	57                   	push   di
    2520:	9a cd 17 2e 25       	call   0x252e:0x17cd
    2525:	8d be f8 fe          	lea    di,[bp-0x108]
    2529:	16                   	push   ss
    252a:	57                   	push   di
    252b:	9a 4c 18 38 25       	call   0x2538:0x184c
    2530:	bf 34 22             	mov    di,0x2234
    2533:	0e                   	push   cs
    2534:	57                   	push   di
    2535:	9a 4c 18 d4 25       	call   0x25d4:0x184c
    253a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    253d:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2542:	06                   	push   es
    2543:	57                   	push   di
    2544:	9a 8c 1d 8d 25       	call   0x258d:0x1d8c
    2549:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    254c:	06                   	push   es
    254d:	57                   	push   di
    254e:	9a d5 33 4e 31       	call   0x314e:0x33d5
    2553:	89 c7                	mov    di,ax
    2555:	8e c2                	mov    es,dx
    2557:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    255b:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    255f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2562:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2567:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    256b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    256f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2573:	06                   	push   es
    2574:	57                   	push   di
    2575:	9a 99 20 98 25       	call   0x2598:0x2099
    257a:	8d be f4 fd          	lea    di,[bp-0x20c]
    257e:	16                   	push   ss
    257f:	57                   	push   di
    2580:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2583:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2588:	06                   	push   es
    2589:	57                   	push   di
    258a:	9a 53 1d a8 25       	call   0x25a8:0x1d53
    258f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2593:	06                   	push   es
    2594:	57                   	push   di
    2595:	9a 03 20 c8 25       	call   0x25c8:0x2003
    259a:	50                   	push   ax
    259b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259e:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    25a3:	06                   	push   es
    25a4:	57                   	push   di
    25a5:	9a bf 17 bd 25       	call   0x25bd:0x17bf
    25aa:	8d be f4 fd          	lea    di,[bp-0x20c]
    25ae:	16                   	push   ss
    25af:	57                   	push   di
    25b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b3:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    25b8:	06                   	push   es
    25b9:	57                   	push   di
    25ba:	9a 53 1d ea 25       	call   0x25ea:0x1d53
    25bf:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    25c3:	06                   	push   es
    25c4:	57                   	push   di
    25c5:	9a 4e 20 e2 5d       	call   0x5de2:0x204e
    25ca:	b9 03 00             	mov    cx,0x3
    25cd:	f7 e9                	imul   cx
    25cf:	71 05                	jno    0x25d6
    25d1:	9a 3e 04 47 26       	call   0x2647:0x43e
    25d6:	99                   	cwd
    25d7:	b9 02 00             	mov    cx,0x2
    25da:	f7 f9                	idiv   cx
    25dc:	50                   	push   ax
    25dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e0:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    25e5:	06                   	push   es
    25e6:	57                   	push   di
    25e7:	9a e1 17 fa 25       	call   0x25fa:0x17e1
    25ec:	ff 76 fe             	push   WORD PTR [bp-0x2]
    25ef:	ff 76 fc             	push   WORD PTR [bp-0x4]
    25f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f5:	06                   	push   es
    25f6:	57                   	push   di
    25f7:	9a 06 1a 1a 26       	call   0x261a:0x1a06
    25fc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    25ff:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2602:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2605:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    260a:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    260e:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2612:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2615:	06                   	push   es
    2616:	57                   	push   di
    2617:	9a 7b 17 28 26       	call   0x2628:0x177b
    261c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    261f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2623:	06                   	push   es
    2624:	57                   	push   di
    2625:	9a 9d 17 32 26       	call   0x2632:0x179d
    262a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    262d:	06                   	push   es
    262e:	57                   	push   di
    262f:	9a a9 18 69 26       	call   0x2669:0x18a9
    2634:	8b d0                	mov    dx,ax
    2636:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    263a:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    263e:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    2642:	71 05                	jno    0x2649
    2644:	9a 3e 04 5d 26       	call   0x265d:0x43e
    2649:	3b c2                	cmp    ax,dx
    264b:	7e 20                	jle    0x266d
    264d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2651:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2655:	2d 08 00             	sub    ax,0x8
    2658:	71 05                	jno    0x265f
    265a:	9a 3e 04 8a 26       	call   0x268a:0x43e
    265f:	50                   	push   ax
    2660:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2664:	06                   	push   es
    2665:	57                   	push   di
    2666:	9a 7b 17 75 26       	call   0x2675:0x177b
    266b:	eb bd                	jmp    0x262a
    266d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2670:	06                   	push   es
    2671:	57                   	push   di
    2672:	9a f4 18 ac 26       	call   0x26ac:0x18f4
    2677:	8b d0                	mov    dx,ax
    2679:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    267d:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2681:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    2685:	71 05                	jno    0x268c
    2687:	9a 3e 04 a0 26       	call   0x26a0:0x43e
    268c:	3b c2                	cmp    ax,dx
    268e:	7e 20                	jle    0x26b0
    2690:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2694:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2698:	2d 08 00             	sub    ax,0x8
    269b:	71 05                	jno    0x26a2
    269d:	9a 3e 04 d6 26       	call   0x26d6:0x43e
    26a2:	50                   	push   ax
    26a3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26a7:	06                   	push   es
    26a8:	57                   	push   di
    26a9:	9a 9d 17 bf 26       	call   0x26bf:0x179d
    26ae:	eb bd                	jmp    0x266d
    26b0:	6a 01                	push   0x1
    26b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b5:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    26ba:	06                   	push   es
    26bb:	57                   	push   di
    26bc:	9a 77 1c 62 27       	call   0x2762:0x1c77
    26c1:	c9                   	leave
    26c2:	ca 0e 00             	retf   0xe
    26c5:	eb ff                	jmp    0x26c6
    26c7:	ff                   	(bad)
    26c8:	ff                   	(bad)
    26c9:	ff                   	(bad)
    26ca:	ff                   	(bad)
    26cb:	ff 02                	inc    WORD PTR [bp+si]
    26cd:	55                   	push   bp
    26ce:	89 e5                	mov    bp,sp
    26d0:	b8 08 00             	mov    ax,0x8
    26d3:	9a 44 04 ed 26       	call   0x26ed:0x444
    26d8:	83 ec 08             	sub    sp,0x8
    26db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26de:	06                   	push   es
    26df:	57                   	push   di
    26e0:	9a 7d 52 0f 27       	call   0x270f:0x527d
    26e5:	2d 01 00             	sub    ax,0x1
    26e8:	71 05                	jno    0x26ef
    26ea:	9a 3e 04 1e 27       	call   0x271e:0x43e
    26ef:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26f2:	31 c0                	xor    ax,ax
    26f4:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    26f7:	7e 03                	jle    0x26fc
    26f9:	e9 d5 00             	jmp    0x27d1
    26fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26ff:	eb 03                	jmp    0x2704
    2701:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2704:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2707:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    270a:	06                   	push   es
    270b:	57                   	push   di
    270c:	9a 46 52 2f 27       	call   0x272f:0x5246
    2711:	52                   	push   dx
    2712:	50                   	push   ax
    2713:	bf 22 00             	mov    di,0x22
    2716:	b8 37 27             	mov    ax,0x2737
    2719:	50                   	push   ax
    271a:	57                   	push   di
    271b:	9a 55 22 3e 27       	call   0x273e:0x2255
    2720:	08 c0                	or     al,al
    2722:	74 42                	je     0x2766
    2724:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2727:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    272a:	06                   	push   es
    272b:	57                   	push   di
    272c:	9a 46 52 71 27       	call   0x2771:0x5246
    2731:	52                   	push   dx
    2732:	50                   	push   ax
    2733:	bf 22 00             	mov    di,0x22
    2736:	b8 1f 28             	mov    ax,0x281f
    2739:	50                   	push   ax
    273a:	57                   	push   di
    273b:	9a 73 22 56 27       	call   0x2756:0x2273
    2740:	89 c7                	mov    di,ax
    2742:	8e c2                	mov    es,dx
    2744:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2747:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    274a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    274d:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2750:	bf c5 26             	mov    di,0x26c5
    2753:	9a 16 04 80 27       	call   0x2780:0x416
    2758:	52                   	push   dx
    2759:	50                   	push   ax
    275a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    275d:	06                   	push   es
    275e:	57                   	push   di
    275f:	9a d5 1e c4 27       	call   0x27c4:0x1ed5
    2764:	eb 60                	jmp    0x27c6
    2766:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2769:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    276c:	06                   	push   es
    276d:	57                   	push   di
    276e:	9a 46 52 91 27       	call   0x2791:0x5246
    2773:	52                   	push   dx
    2774:	50                   	push   ax
    2775:	bf 14 1b             	mov    di,0x1b14
    2778:	b8 99 27             	mov    ax,0x2799
    277b:	50                   	push   ax
    277c:	57                   	push   di
    277d:	9a 55 22 a0 27       	call   0x27a0:0x2255
    2782:	08 c0                	or     al,al
    2784:	74 40                	je     0x27c6
    2786:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2789:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    278c:	06                   	push   es
    278d:	57                   	push   di
    278e:	9a 46 52 eb 27       	call   0x27eb:0x5246
    2793:	52                   	push   dx
    2794:	50                   	push   ax
    2795:	bf 14 1b             	mov    di,0x1b14
    2798:	b8 3c 28             	mov    ax,0x283c
    279b:	50                   	push   ax
    279c:	57                   	push   di
    279d:	9a 73 22 b8 27       	call   0x27b8:0x2273
    27a2:	89 c7                	mov    di,ax
    27a4:	8e c2                	mov    es,dx
    27a6:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    27a9:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    27ac:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    27af:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    27b2:	bf c5 26             	mov    di,0x26c5
    27b5:	9a 16 04 de 27       	call   0x27de:0x416
    27ba:	52                   	push   dx
    27bb:	50                   	push   ax
    27bc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    27bf:	06                   	push   es
    27c0:	57                   	push   di
    27c1:	9a d5 1e 73 2f       	call   0x2f73:0x1ed5
    27c6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    27c9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    27cc:	74 03                	je     0x27d1
    27ce:	e9 30 ff             	jmp    0x2701
    27d1:	c9                   	leave
    27d2:	ca 08 00             	retf   0x8
    27d5:	55                   	push   bp
    27d6:	89 e5                	mov    bp,sp
    27d8:	b8 04 00             	mov    ax,0x4
    27db:	9a 44 04 f5 27       	call   0x27f5:0x444
    27e0:	83 ec 04             	sub    sp,0x4
    27e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e6:	06                   	push   es
    27e7:	57                   	push   di
    27e8:	9a 7d 52 17 28       	call   0x2817:0x527d
    27ed:	2d 01 00             	sub    ax,0x1
    27f0:	71 05                	jno    0x27f7
    27f2:	9a 3e 04 26 28       	call   0x2826:0x43e
    27f7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    27fa:	31 c0                	xor    ax,ax
    27fc:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    27ff:	7e 03                	jle    0x2804
    2801:	e9 1c 01             	jmp    0x2920
    2804:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2807:	eb 03                	jmp    0x280c
    2809:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    280c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    280f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2812:	06                   	push   es
    2813:	57                   	push   di
    2814:	9a 46 52 34 28       	call   0x2834:0x5246
    2819:	52                   	push   dx
    281a:	50                   	push   ax
    281b:	bf 26 06             	mov    di,0x626
    281e:	b8 59 28             	mov    ax,0x2859
    2821:	50                   	push   ax
    2822:	57                   	push   di
    2823:	9a 55 22 43 28       	call   0x2843:0x2255
    2828:	50                   	push   ax
    2829:	ff 76 fe             	push   WORD PTR [bp-0x2]
    282c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    282f:	06                   	push   es
    2830:	57                   	push   di
    2831:	9a 46 52 51 28       	call   0x2851:0x5246
    2836:	52                   	push   dx
    2837:	50                   	push   ax
    2838:	bf 14 1b             	mov    di,0x1b14
    283b:	b8 63 2e             	mov    ax,0x2e63
    283e:	50                   	push   ax
    283f:	57                   	push   di
    2840:	9a 55 22 60 28       	call   0x2860:0x2255
    2845:	50                   	push   ax
    2846:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2849:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284c:	06                   	push   es
    284d:	57                   	push   di
    284e:	9a 46 52 80 28       	call   0x2880:0x5246
    2853:	52                   	push   dx
    2854:	50                   	push   ax
    2855:	bf 22 00             	mov    di,0x22
    2858:	b8 6e 29             	mov    ax,0x296e
    285b:	50                   	push   ax
    285c:	57                   	push   di
    285d:	9a 55 22 9e 28       	call   0x289e:0x2255
    2862:	5a                   	pop    dx
    2863:	0a c2                	or     al,dl
    2865:	5a                   	pop    dx
    2866:	0a c2                	or     al,dl
    2868:	08 c0                	or     al,al
    286a:	75 03                	jne    0x286f
    286c:	e9 a6 00             	jmp    0x2915
    286f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2873:	74 58                	je     0x28cd
    2875:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2878:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287b:	06                   	push   es
    287c:	57                   	push   di
    287d:	9a 46 52 bb 28       	call   0x28bb:0x5246
    2882:	89 c7                	mov    di,ax
    2884:	8e c2                	mov    es,dx
    2886:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    288a:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    288e:	09 d2                	or     dx,dx
    2890:	79 07                	jns    0x2899
    2892:	f7 d2                	not    dx
    2894:	f7 d8                	neg    ax
    2896:	83 da ff             	sbb    dx,0xffff
    2899:	71 05                	jno    0x28a0
    289b:	9a 3e 04 ac 28       	call   0x28ac:0x43e
    28a0:	f7 d2                	not    dx
    28a2:	f7 d8                	neg    ax
    28a4:	83 da ff             	sbb    dx,0xffff
    28a7:	71 05                	jno    0x28ae
    28a9:	9a 3e 04 f6 28       	call   0x28f6:0x43e
    28ae:	52                   	push   dx
    28af:	50                   	push   ax
    28b0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b6:	06                   	push   es
    28b7:	57                   	push   di
    28b8:	9a 46 52 d8 28       	call   0x28d8:0x5246
    28bd:	89 c7                	mov    di,ax
    28bf:	8e c2                	mov    es,dx
    28c1:	58                   	pop    ax
    28c2:	5a                   	pop    dx
    28c3:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    28c7:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    28cb:	eb 48                	jmp    0x2915
    28cd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d3:	06                   	push   es
    28d4:	57                   	push   di
    28d5:	9a 46 52 05 29       	call   0x2905:0x5246
    28da:	89 c7                	mov    di,ax
    28dc:	8e c2                	mov    es,dx
    28de:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    28e2:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    28e6:	09 d2                	or     dx,dx
    28e8:	79 07                	jns    0x28f1
    28ea:	f7 d2                	not    dx
    28ec:	f7 d8                	neg    ax
    28ee:	83 da ff             	sbb    dx,0xffff
    28f1:	71 05                	jno    0x28f8
    28f3:	9a 3e 04 2d 29       	call   0x292d:0x43e
    28f8:	52                   	push   dx
    28f9:	50                   	push   ax
    28fa:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2900:	06                   	push   es
    2901:	57                   	push   di
    2902:	9a 46 52 3a 29       	call   0x293a:0x5246
    2907:	89 c7                	mov    di,ax
    2909:	8e c2                	mov    es,dx
    290b:	58                   	pop    ax
    290c:	5a                   	pop    dx
    290d:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2911:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2915:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2918:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    291b:	74 03                	je     0x2920
    291d:	e9 e9 fe             	jmp    0x2809
    2920:	c9                   	leave
    2921:	ca 06 00             	retf   0x6
    2924:	55                   	push   bp
    2925:	89 e5                	mov    bp,sp
    2927:	b8 08 00             	mov    ax,0x8
    292a:	9a 44 04 44 29       	call   0x2944:0x444
    292f:	83 ec 08             	sub    sp,0x8
    2932:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2935:	06                   	push   es
    2936:	57                   	push   di
    2937:	9a 7d 52 66 29       	call   0x2966:0x527d
    293c:	2d 01 00             	sub    ax,0x1
    293f:	71 05                	jno    0x2946
    2941:	9a 3e 04 75 29       	call   0x2975:0x43e
    2946:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2949:	31 c0                	xor    ax,ax
    294b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    294e:	7e 03                	jle    0x2953
    2950:	e9 f9 00             	jmp    0x2a4c
    2953:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2956:	eb 03                	jmp    0x295b
    2958:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    295b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    295e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2961:	06                   	push   es
    2962:	57                   	push   di
    2963:	9a 46 52 86 29       	call   0x2986:0x5246
    2968:	52                   	push   dx
    2969:	50                   	push   ax
    296a:	bf 22 00             	mov    di,0x22
    296d:	b8 8e 29             	mov    ax,0x298e
    2970:	50                   	push   ax
    2971:	57                   	push   di
    2972:	9a 55 22 95 29       	call   0x2995:0x2255
    2977:	08 c0                	or     al,al
    2979:	74 2e                	je     0x29a9
    297b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    297e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2981:	06                   	push   es
    2982:	57                   	push   di
    2983:	9a 46 52 b4 29       	call   0x29b4:0x5246
    2988:	52                   	push   dx
    2989:	50                   	push   ax
    298a:	bf 22 00             	mov    di,0x22
    298d:	b8 a4 29             	mov    ax,0x29a4
    2990:	50                   	push   ax
    2991:	57                   	push   di
    2992:	9a 73 22 c3 29       	call   0x29c3:0x2273
    2997:	89 c7                	mov    di,ax
    2999:	8e c2                	mov    es,dx
    299b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    299e:	50                   	push   ax
    299f:	06                   	push   es
    29a0:	57                   	push   di
    29a1:	9a fe 1a bc 29       	call   0x29bc:0x1afe
    29a6:	e9 98 00             	jmp    0x2a41
    29a9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29af:	06                   	push   es
    29b0:	57                   	push   di
    29b1:	9a 46 52 d4 29       	call   0x29d4:0x5246
    29b6:	52                   	push   dx
    29b7:	50                   	push   ax
    29b8:	bf a2 0b             	mov    di,0xba2
    29bb:	b8 dc 29             	mov    ax,0x29dc
    29be:	50                   	push   ax
    29bf:	57                   	push   di
    29c0:	9a 55 22 e3 29       	call   0x29e3:0x2255
    29c5:	08 c0                	or     al,al
    29c7:	74 2d                	je     0x29f6
    29c9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29cf:	06                   	push   es
    29d0:	57                   	push   di
    29d1:	9a 46 52 01 2a       	call   0x2a01:0x5246
    29d6:	52                   	push   dx
    29d7:	50                   	push   ax
    29d8:	bf a2 0b             	mov    di,0xba2
    29db:	b8 f2 29             	mov    ax,0x29f2
    29de:	50                   	push   ax
    29df:	57                   	push   di
    29e0:	9a 73 22 10 2a       	call   0x2a10:0x2273
    29e5:	89 c7                	mov    di,ax
    29e7:	8e c2                	mov    es,dx
    29e9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    29ec:	50                   	push   ax
    29ed:	06                   	push   es
    29ee:	57                   	push   di
    29ef:	9a f1 2a 09 2a       	call   0x2a09:0x2af1
    29f4:	eb 4b                	jmp    0x2a41
    29f6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29fc:	06                   	push   es
    29fd:	57                   	push   di
    29fe:	9a 46 52 21 2a       	call   0x2a21:0x5246
    2a03:	52                   	push   dx
    2a04:	50                   	push   ax
    2a05:	bf 26 06             	mov    di,0x626
    2a08:	b8 29 2a             	mov    ax,0x2a29
    2a0b:	50                   	push   ax
    2a0c:	57                   	push   di
    2a0d:	9a 55 22 30 2a       	call   0x2a30:0x2255
    2a12:	08 c0                	or     al,al
    2a14:	74 2b                	je     0x2a41
    2a16:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a1c:	06                   	push   es
    2a1d:	57                   	push   di
    2a1e:	9a 46 52 66 2a       	call   0x2a66:0x5246
    2a23:	52                   	push   dx
    2a24:	50                   	push   ax
    2a25:	bf 26 06             	mov    di,0x626
    2a28:	b8 3f 2a             	mov    ax,0x2a3f
    2a2b:	50                   	push   ax
    2a2c:	57                   	push   di
    2a2d:	9a 73 22 59 2a       	call   0x2a59:0x2273
    2a32:	89 c7                	mov    di,ax
    2a34:	8e c2                	mov    es,dx
    2a36:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2a39:	50                   	push   ax
    2a3a:	06                   	push   es
    2a3b:	57                   	push   di
    2a3c:	9a 70 25 97 2a       	call   0x2a97:0x2570
    2a41:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a44:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2a47:	74 03                	je     0x2a4c
    2a49:	e9 0c ff             	jmp    0x2958
    2a4c:	c9                   	leave
    2a4d:	ca 06 00             	retf   0x6
    2a50:	55                   	push   bp
    2a51:	89 e5                	mov    bp,sp
    2a53:	b8 04 00             	mov    ax,0x4
    2a56:	9a 44 04 70 2a       	call   0x2a70:0x444
    2a5b:	83 ec 04             	sub    sp,0x4
    2a5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a61:	06                   	push   es
    2a62:	57                   	push   di
    2a63:	9a 7d 52 8f 2a       	call   0x2a8f:0x527d
    2a68:	2d 01 00             	sub    ax,0x1
    2a6b:	71 05                	jno    0x2a72
    2a6d:	9a 3e 04 9e 2a       	call   0x2a9e:0x43e
    2a72:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a75:	31 c0                	xor    ax,ax
    2a77:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2a7a:	7f 58                	jg     0x2ad4
    2a7c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a7f:	eb 03                	jmp    0x2a84
    2a81:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2a84:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a8a:	06                   	push   es
    2a8b:	57                   	push   di
    2a8c:	9a 46 52 af 2a       	call   0x2aaf:0x5246
    2a91:	52                   	push   dx
    2a92:	50                   	push   ax
    2a93:	bf 22 00             	mov    di,0x22
    2a96:	b8 b7 2a             	mov    ax,0x2ab7
    2a99:	50                   	push   ax
    2a9a:	57                   	push   di
    2a9b:	9a 55 22 be 2a       	call   0x2abe:0x2255
    2aa0:	08 c0                	or     al,al
    2aa2:	74 28                	je     0x2acc
    2aa4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2aa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aaa:	06                   	push   es
    2aab:	57                   	push   di
    2aac:	9a 46 52 86 43       	call   0x4386:0x5246
    2ab1:	52                   	push   dx
    2ab2:	50                   	push   ax
    2ab3:	bf 22 00             	mov    di,0x22
    2ab6:	b8 47 44             	mov    ax,0x4447
    2ab9:	50                   	push   ax
    2aba:	57                   	push   di
    2abb:	9a 73 22 e0 2a       	call   0x2ae0:0x2273
    2ac0:	52                   	push   dx
    2ac1:	50                   	push   ax
    2ac2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac5:	06                   	push   es
    2ac6:	57                   	push   di
    2ac7:	9a 08 15 ea 2a       	call   0x2aea:0x1508
    2acc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2acf:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2ad2:	75 ad                	jne    0x2a81
    2ad4:	c9                   	leave
    2ad5:	ca 04 00             	retf   0x4
    2ad8:	55                   	push   bp
    2ad9:	89 e5                	mov    bp,sp
    2adb:	31 c0                	xor    ax,ax
    2add:	9a 44 04 f8 2a       	call   0x2af8:0x444
    2ae2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae5:	06                   	push   es
    2ae6:	57                   	push   di
    2ae7:	9a db 38 02 2b       	call   0x2b02:0x38db
    2aec:	c9                   	leave
    2aed:	ca 08 00             	retf   0x8
    2af0:	55                   	push   bp
    2af1:	89 e5                	mov    bp,sp
    2af3:	31 c0                	xor    ax,ax
    2af5:	9a 44 04 10 2b       	call   0x2b10:0x444
    2afa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afd:	06                   	push   es
    2afe:	57                   	push   di
    2aff:	9a 3b 32 bd 2b       	call   0x2bbd:0x323b
    2b04:	c9                   	leave
    2b05:	ca 08 00             	retf   0x8
    2b08:	55                   	push   bp
    2b09:	89 e5                	mov    bp,sp
    2b0b:	31 c0                	xor    ax,ax
    2b0d:	9a 44 04 1f 2b       	call   0x2b1f:0x444
    2b12:	c9                   	leave
    2b13:	ca 08 00             	retf   0x8
    2b16:	55                   	push   bp
    2b17:	89 e5                	mov    bp,sp
    2b19:	b8 04 00             	mov    ax,0x4
    2b1c:	9a 44 04 c8 2b       	call   0x2bc8:0x444
    2b21:	83 ec 04             	sub    sp,0x4
    2b24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b27:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    2b2c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b2f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b32:	06                   	push   es
    2b33:	57                   	push   di
    2b34:	9a 02 32 45 2b       	call   0x2b45:0x3202
    2b39:	08 c0                	or     al,al
    2b3b:	74 16                	je     0x2b53
    2b3d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b40:	06                   	push   es
    2b41:	57                   	push   di
    2b42:	9a d2 31 66 2b       	call   0x2b66:0x31d2
    2b47:	6a 00                	push   0x0
    2b49:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b4c:	06                   	push   es
    2b4d:	57                   	push   di
    2b4e:	9a d2 2e 80 2b       	call   0x2b80:0x2ed2
    2b53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b56:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    2b5b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b5e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b61:	06                   	push   es
    2b62:	57                   	push   di
    2b63:	9a 02 32 74 2b       	call   0x2b74:0x3202
    2b68:	08 c0                	or     al,al
    2b6a:	74 16                	je     0x2b82
    2b6c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b6f:	06                   	push   es
    2b70:	57                   	push   di
    2b71:	9a d2 31 95 2b       	call   0x2b95:0x31d2
    2b76:	6a 00                	push   0x0
    2b78:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b7b:	06                   	push   es
    2b7c:	57                   	push   di
    2b7d:	9a d2 2e af 2b       	call   0x2baf:0x2ed2
    2b82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b85:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    2b8a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2b8d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2b90:	06                   	push   es
    2b91:	57                   	push   di
    2b92:	9a 02 32 a3 2b       	call   0x2ba3:0x3202
    2b97:	08 c0                	or     al,al
    2b99:	74 16                	je     0x2bb1
    2b9b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2b9e:	06                   	push   es
    2b9f:	57                   	push   di
    2ba0:	9a d2 31 b9 2b       	call   0x2bb9:0x31d2
    2ba5:	6a 00                	push   0x0
    2ba7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2baa:	06                   	push   es
    2bab:	57                   	push   di
    2bac:	9a d2 2e 36 2c       	call   0x2c36:0x2ed2
    2bb1:	c9                   	leave
    2bb2:	ca 04 00             	retf   0x4
    2bb5:	01 00                	add    WORD PTR [bx+si],ax
    2bb7:	2f                   	das
    2bb8:	00 21                	add    BYTE PTR [bx+di],ah
    2bba:	2c 2b                	sub    al,0x2b
    2bbc:	2d 2b 2c             	sub    ax,0x2c2b
    2bbf:	55                   	push   bp
    2bc0:	89 e5                	mov    bp,sp
    2bc2:	b8 06 00             	mov    ax,0x6
    2bc5:	9a 44 04 3f 2d       	call   0x2d3f:0x444
    2bca:	83 ec 06             	sub    sp,0x6
    2bcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd0:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    2bd5:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    2bda:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    2bde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be1:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    2be6:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2beb:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    2bef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf2:	26 8a 85 68 03       	mov    al,BYTE PTR es:[di+0x368]
    2bf7:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2bfc:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    2c00:	b8 b5 2b             	mov    ax,0x2bb5
    2c03:	0e                   	push   cs
    2c04:	50                   	push   ax
    2c05:	55                   	push   bp
    2c06:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2c0a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2c0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c11:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    2c16:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2c19:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2c1c:	06                   	push   es
    2c1d:	57                   	push   di
    2c1e:	9a d2 31 68 2c       	call   0x2c68:0x31d2
    2c23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c26:	06                   	push   es
    2c27:	57                   	push   di
    2c28:	9a ac 10 40 2c       	call   0x2c40:0x10ac
    2c2d:	50                   	push   ax
    2c2e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c31:	06                   	push   es
    2c32:	57                   	push   di
    2c33:	9a fb 2f 50 2c       	call   0x2c50:0x2ffb
    2c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c3b:	06                   	push   es
    2c3c:	57                   	push   di
    2c3d:	9a ac 10 87 2c       	call   0x2c87:0x10ac
    2c42:	08 c0                	or     al,al
    2c44:	75 0e                	jne    0x2c54
    2c46:	6a 01                	push   0x1
    2c48:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c4b:	06                   	push   es
    2c4c:	57                   	push   di
    2c4d:	9a d2 2e 5e 2c       	call   0x2c5e:0x2ed2
    2c52:	eb 0c                	jmp    0x2c60
    2c54:	6a 00                	push   0x0
    2c56:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c59:	06                   	push   es
    2c5a:	57                   	push   di
    2c5b:	9a d2 2e 92 2c       	call   0x2c92:0x2ed2
    2c60:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c63:	06                   	push   es
    2c64:	57                   	push   di
    2c65:	9a bf 31 7d 2c       	call   0x2c7d:0x31bf
    2c6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c6d:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    2c72:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2c75:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2c78:	06                   	push   es
    2c79:	57                   	push   di
    2c7a:	9a d2 31 c4 2c       	call   0x2cc4:0x31d2
    2c7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c82:	06                   	push   es
    2c83:	57                   	push   di
    2c84:	9a ac 10 9c 2c       	call   0x2c9c:0x10ac
    2c89:	50                   	push   ax
    2c8a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c8d:	06                   	push   es
    2c8e:	57                   	push   di
    2c8f:	9a fb 2f ac 2c       	call   0x2cac:0x2ffb
    2c94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c97:	06                   	push   es
    2c98:	57                   	push   di
    2c99:	9a ac 10 e3 2c       	call   0x2ce3:0x10ac
    2c9e:	08 c0                	or     al,al
    2ca0:	75 0e                	jne    0x2cb0
    2ca2:	6a 01                	push   0x1
    2ca4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2ca7:	06                   	push   es
    2ca8:	57                   	push   di
    2ca9:	9a d2 2e ba 2c       	call   0x2cba:0x2ed2
    2cae:	eb 0c                	jmp    0x2cbc
    2cb0:	6a 00                	push   0x0
    2cb2:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2cb5:	06                   	push   es
    2cb6:	57                   	push   di
    2cb7:	9a d2 2e ee 2c       	call   0x2cee:0x2ed2
    2cbc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2cbf:	06                   	push   es
    2cc0:	57                   	push   di
    2cc1:	9a bf 31 d9 2c       	call   0x2cd9:0x31bf
    2cc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc9:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    2cce:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2cd1:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2cd4:	06                   	push   es
    2cd5:	57                   	push   di
    2cd6:	9a d2 31 20 2d       	call   0x2d20:0x31d2
    2cdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cde:	06                   	push   es
    2cdf:	57                   	push   di
    2ce0:	9a ac 10 f8 2c       	call   0x2cf8:0x10ac
    2ce5:	50                   	push   ax
    2ce6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2ce9:	06                   	push   es
    2cea:	57                   	push   di
    2ceb:	9a fb 2f 08 2d       	call   0x2d08:0x2ffb
    2cf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cf3:	06                   	push   es
    2cf4:	57                   	push   di
    2cf5:	9a ac 10 97 2d       	call   0x2d97:0x10ac
    2cfa:	08 c0                	or     al,al
    2cfc:	75 0e                	jne    0x2d0c
    2cfe:	6a 01                	push   0x1
    2d00:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d03:	06                   	push   es
    2d04:	57                   	push   di
    2d05:	9a d2 2e 16 2d       	call   0x2d16:0x2ed2
    2d0a:	eb 0c                	jmp    0x2d18
    2d0c:	6a 00                	push   0x0
    2d0e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d11:	06                   	push   es
    2d12:	57                   	push   di
    2d13:	9a d2 2e 00 2e       	call   0x2e00:0x2ed2
    2d18:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d1b:	06                   	push   es
    2d1c:	57                   	push   di
    2d1d:	9a bf 31 93 2d       	call   0x2d93:0x31bf
    2d22:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2d26:	83 c4 06             	add    sp,0x6
    2d29:	eb 1b                	jmp    0x2d46
    2d2b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2d2e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2d31:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2d34:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d37:	9a 2d 34 1d 31       	call   0x311d:0x342d
    2d3c:	ea 85 13 44 2d       	jmp    0x2d44:0x1385
    2d41:	9a 34 14 b4 2d       	call   0x2db4:0x1434
    2d46:	c9                   	leave
    2d47:	ca 04 00             	retf   0x4
    2d4a:	11 4d 6f             	adc    WORD PTR [di+0x6f],cx
    2d4d:	64 65 41             	fs gs inc cx
    2d50:	6d                   	ins    WORD PTR es:[di],dx
    2d51:	6f                   	outs   dx,WORD PTR ds:[si]
    2d52:	72 74                	jb     0x2dc8
    2d54:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    2d59:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2d5b:	74 00                	je     0x2d5d
    2d5d:	80 ff ff             	cmp    bh,0xff
    2d60:	ff                   	(bad)
    2d61:	7f 00                	jg     0x2d63
    2d63:	00 10                	add    BYTE PTR [bx+si],dl
    2d65:	44                   	inc    sp
    2d66:	65 6d                	gs ins WORD PTR es:[di],dx
    2d68:	61                   	popa
    2d69:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d6a:	64 65 45             	fs gs inc bp
    2d6d:	76 6f                	jbe    0x2dde
    2d6f:	6c                   	ins    BYTE PTR es:[di],dx
    2d70:	75 74                	jne    0x2de6
    2d72:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
    2d77:	00 00                	add    BYTE PTR [bx+si],al
    2d79:	02 00                	add    al,BYTE PTR [bx+si]
    2d7b:	00 00                	add    BYTE PTR [bx+si],al
    2d7d:	11 46 61             	adc    WORD PTR [bp+0x61],ax
    2d80:	63 74 65             	arpl   WORD PTR [si+0x65],si
    2d83:	75 72                	jne    0x2df7
    2d85:	54                   	push   sp
    2d86:	65 6d                	gs ins WORD PTR es:[di],dx
    2d88:	70 73                	jo     0x2dfd
    2d8a:	46                   	inc    si
    2d8b:	61                   	popa
    2d8c:	62 50 63             	bound  dx,DWORD PTR [bx+si+0x63]
    2d8f:	01 00                	add    WORD PTR [bx+si],ax
    2d91:	2f                   	das
    2d92:	00 1d                	add    BYTE PTR [di],bl
    2d94:	2e 0e                	cs push cs
    2d96:	31 a1 2d 02          	xor    WORD PTR [bx+di+0x22d],sp
    2d9a:	00 d8                	add    al,bl
    2d9c:	00 53 31             	add    BYTE PTR [bp+di+0x31],dl
    2d9f:	32 31                	xor    dh,BYTE PTR [bx+di]
    2da1:	a9 2d 00             	test   ax,0x2d
    2da4:	00 00                	add    BYTE PTR [bx+si],al
    2da6:	00 3a                	add    BYTE PTR [bp+si],bh
    2da8:	31 0e 2e 55          	xor    WORD PTR ds:0x552e,cx
    2dac:	89 e5                	mov    bp,sp
    2dae:	b8 12 00             	mov    ax,0x12
    2db1:	9a 44 04 32 2e       	call   0x2e32:0x444
    2db6:	83 ec 12             	sub    sp,0x12
    2db9:	b8 99 2d             	mov    ax,0x2d99
    2dbc:	0e                   	push   cs
    2dbd:	50                   	push   ax
    2dbe:	55                   	push   bp
    2dbf:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2dc3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2dc7:	b8 8f 2d             	mov    ax,0x2d8f
    2dca:	0e                   	push   cs
    2dcb:	50                   	push   ax
    2dcc:	55                   	push   bp
    2dcd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2dd1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2dd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd8:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    2ddd:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2de0:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2de3:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
    2de8:	c7 46 f0 00 00       	mov    WORD PTR [bp-0x10],0x0
    2ded:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    2df1:	8d 7e ee             	lea    di,[bp-0x12]
    2df4:	16                   	push   ss
    2df5:	57                   	push   di
    2df6:	6a 00                	push   0x0
    2df8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2dfb:	06                   	push   es
    2dfc:	57                   	push   di
    2dfd:	9a 95 28 b8 2e       	call   0x2eb8:0x2895
    2e02:	08 c0                	or     al,al
    2e04:	75 0a                	jne    0x2e10
    2e06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e09:	06                   	push   es
    2e0a:	57                   	push   di
    2e0b:	9a e9 09 c6 2e       	call   0x2ec6:0x9e9
    2e10:	bf 4a 2d             	mov    di,0x2d4a
    2e13:	0e                   	push   cs
    2e14:	57                   	push   di
    2e15:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2e18:	06                   	push   es
    2e19:	57                   	push   di
    2e1a:	9a 9b 3b d5 2e       	call   0x2ed5:0x3b9b
    2e1f:	89 c7                	mov    di,ax
    2e21:	8e c2                	mov    es,dx
    2e23:	06                   	push   es
    2e24:	57                   	push   di
    2e25:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e28:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2e2c:	bf 5c 2d             	mov    di,0x2d5c
    2e2f:	9a 16 04 80 2e       	call   0x2e80:0x416
    2e34:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e3a:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    2e3f:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    2e42:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    2e45:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2e4a:	06                   	push   es
    2e4b:	57                   	push   di
    2e4c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e4f:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2e53:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2e56:	7e 0f                	jle    0x2e67
    2e58:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e5b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2e5e:	06                   	push   es
    2e5f:	57                   	push   di
    2e60:	9a 2e 5c 8b 2e       	call   0x2e8b:0x5c2e
    2e65:	eb 26                	jmp    0x2e8d
    2e67:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2e6a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2e6f:	06                   	push   es
    2e70:	57                   	push   di
    2e71:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e74:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2e78:	2d 01 00             	sub    ax,0x1
    2e7b:	71 05                	jno    0x2e82
    2e7d:	9a 3e 04 ea 2e       	call   0x2eea:0x43e
    2e82:	50                   	push   ax
    2e83:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2e86:	06                   	push   es
    2e87:	57                   	push   di
    2e88:	9a 2e 5c 1b 2f       	call   0x2f1b:0x5c2e
    2e8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e90:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    2e95:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2e98:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2e9b:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
    2ea0:	c7 46 f0 00 00       	mov    WORD PTR [bp-0x10],0x0
    2ea5:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    2ea9:	8d 7e ee             	lea    di,[bp-0x12]
    2eac:	16                   	push   ss
    2ead:	57                   	push   di
    2eae:	6a 00                	push   0x0
    2eb0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2eb3:	06                   	push   es
    2eb4:	57                   	push   di
    2eb5:	9a 95 28 ef 2f       	call   0x2fef:0x2895
    2eba:	08 c0                	or     al,al
    2ebc:	75 0a                	jne    0x2ec8
    2ebe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec1:	06                   	push   es
    2ec2:	57                   	push   di
    2ec3:	9a e9 09 fd 2f       	call   0x2ffd:0x9e9
    2ec8:	bf 64 2d             	mov    di,0x2d64
    2ecb:	0e                   	push   cs
    2ecc:	57                   	push   di
    2ecd:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2ed0:	06                   	push   es
    2ed1:	57                   	push   di
    2ed2:	9a 9b 3b 82 2f       	call   0x2f82:0x3b9b
    2ed7:	89 c7                	mov    di,ax
    2ed9:	8e c2                	mov    es,dx
    2edb:	06                   	push   es
    2edc:	57                   	push   di
    2edd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ee0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2ee4:	bf 5c 2d             	mov    di,0x2d5c
    2ee7:	9a 16 04 38 2f       	call   0x2f38:0x416
    2eec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2eef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef2:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    2ef7:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    2efa:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    2efd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f02:	06                   	push   es
    2f03:	57                   	push   di
    2f04:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f07:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2f0b:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2f0e:	7e 0f                	jle    0x2f1f
    2f10:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f13:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2f16:	06                   	push   es
    2f17:	57                   	push   di
    2f18:	9a 2e 5c 43 2f       	call   0x2f43:0x5c2e
    2f1d:	eb 26                	jmp    0x2f45
    2f1f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2f22:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f27:	06                   	push   es
    2f28:	57                   	push   di
    2f29:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f2c:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2f30:	2d 01 00             	sub    ax,0x1
    2f33:	71 05                	jno    0x2f3a
    2f35:	9a 3e 04 56 2f       	call   0x2f56:0x43e
    2f3a:	50                   	push   ax
    2f3b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2f3e:	06                   	push   es
    2f3f:	57                   	push   di
    2f40:	9a 2e 5c 4d 2f       	call   0x2f4d:0x5c2e
    2f45:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2f48:	06                   	push   es
    2f49:	57                   	push   di
    2f4a:	9a 07 5c 52 30       	call   0x3052:0x5c07
    2f4f:	99                   	cwd
    2f50:	bf 75 2d             	mov    di,0x2d75
    2f53:	9a 16 04 21 30       	call   0x3021:0x416
    2f58:	c1 e0 08             	shl    ax,0x8
    2f5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f5e:	03 f8                	add    di,ax
    2f60:	81 c7 6a 03          	add    di,0x36a
    2f64:	06                   	push   es
    2f65:	57                   	push   di
    2f66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f69:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    2f6e:	06                   	push   es
    2f6f:	57                   	push   di
    2f70:	9a 8c 1d aa 30       	call   0x30aa:0x1d8c
    2f75:	bf 7d 2d             	mov    di,0x2d7d
    2f78:	0e                   	push   cs
    2f79:	57                   	push   di
    2f7a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2f7d:	06                   	push   es
    2f7e:	57                   	push   di
    2f7f:	9a 43 3c 0c 30       	call   0x300c:0x3c43
    2f84:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2f87:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2f8a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2f8d:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    2f90:	74 1f                	je     0x2fb1
    2f92:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2f95:	06                   	push   es
    2f96:	57                   	push   di
    2f97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f9a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2f9e:	52                   	push   dx
    2f9f:	50                   	push   ax
    2fa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa3:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    2fa8:	06                   	push   es
    2fa9:	57                   	push   di
    2faa:	9a 8b 17 c2 2f       	call   0x2fc2:0x178b
    2faf:	eb 13                	jmp    0x2fc4
    2fb1:	6a 00                	push   0x0
    2fb3:	6a 64                	push   0x64
    2fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb8:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    2fbd:	06                   	push   es
    2fbe:	57                   	push   di
    2fbf:	9a 8b 17 e4 30       	call   0x30e4:0x178b
    2fc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc7:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    2fcc:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2fcf:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2fd2:	c7 46 ee 02 00       	mov    WORD PTR [bp-0x12],0x2
    2fd7:	c7 46 f0 00 00       	mov    WORD PTR [bp-0x10],0x0
    2fdc:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    2fe0:	8d 7e ee             	lea    di,[bp-0x12]
    2fe3:	16                   	push   ss
    2fe4:	57                   	push   di
    2fe5:	6a 00                	push   0x0
    2fe7:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2fea:	06                   	push   es
    2feb:	57                   	push   di
    2fec:	9a 95 28 ff ff       	call   0xffff:0x2895
    2ff1:	08 c0                	or     al,al
    2ff3:	75 0a                	jne    0x2fff
    2ff5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff8:	06                   	push   es
    2ff9:	57                   	push   di
    2ffa:	9a e9 09 03 31       	call   0x3103:0x9e9
    2fff:	bf 64 2d             	mov    di,0x2d64
    3002:	0e                   	push   cs
    3003:	57                   	push   di
    3004:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3007:	06                   	push   es
    3008:	57                   	push   di
    3009:	9a 9b 3b b9 30       	call   0x30b9:0x3b9b
    300e:	89 c7                	mov    di,ax
    3010:	8e c2                	mov    es,dx
    3012:	06                   	push   es
    3013:	57                   	push   di
    3014:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3017:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    301b:	bf 5c 2d             	mov    di,0x2d5c
    301e:	9a 16 04 6f 30       	call   0x306f:0x416
    3023:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3026:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3029:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    302e:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    3031:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    3034:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3039:	06                   	push   es
    303a:	57                   	push   di
    303b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    303e:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3042:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    3045:	7e 0f                	jle    0x3056
    3047:	ff 76 fe             	push   WORD PTR [bp-0x2]
    304a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    304d:	06                   	push   es
    304e:	57                   	push   di
    304f:	9a 2e 5c 7a 30       	call   0x307a:0x5c2e
    3054:	eb 26                	jmp    0x307c
    3056:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3059:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    305e:	06                   	push   es
    305f:	57                   	push   di
    3060:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3063:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3067:	2d 01 00             	sub    ax,0x1
    306a:	71 05                	jno    0x3071
    306c:	9a 3e 04 8d 30       	call   0x308d:0x43e
    3071:	50                   	push   ax
    3072:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3075:	06                   	push   es
    3076:	57                   	push   di
    3077:	9a 2e 5c 84 30       	call   0x3084:0x5c2e
    307c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    307f:	06                   	push   es
    3080:	57                   	push   di
    3081:	9a 07 5c 07 32       	call   0x3207:0x5c07
    3086:	99                   	cwd
    3087:	bf 75 2d             	mov    di,0x2d75
    308a:	9a 16 04 22 31       	call   0x3122:0x416
    308f:	c1 e0 08             	shl    ax,0x8
    3092:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3095:	03 f8                	add    di,ax
    3097:	81 c7 6a 03          	add    di,0x36a
    309b:	06                   	push   es
    309c:	57                   	push   di
    309d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30a0:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    30a5:	06                   	push   es
    30a6:	57                   	push   di
    30a7:	9a 8c 1d ec 31       	call   0x31ec:0x1d8c
    30ac:	bf 7d 2d             	mov    di,0x2d7d
    30af:	0e                   	push   cs
    30b0:	57                   	push   di
    30b1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    30b4:	06                   	push   es
    30b5:	57                   	push   di
    30b6:	9a 43 3c 89 31       	call   0x3189:0x3c43
    30bb:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    30be:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    30c1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    30c4:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    30c7:	74 1f                	je     0x30e8
    30c9:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    30cc:	06                   	push   es
    30cd:	57                   	push   di
    30ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30d1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    30d5:	52                   	push   dx
    30d6:	50                   	push   ax
    30d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30da:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    30df:	06                   	push   es
    30e0:	57                   	push   di
    30e1:	9a 8b 17 f9 30       	call   0x30f9:0x178b
    30e6:	eb 13                	jmp    0x30fb
    30e8:	6a 00                	push   0x0
    30ea:	6a 64                	push   0x64
    30ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30ef:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    30f4:	06                   	push   es
    30f5:	57                   	push   di
    30f6:	9a 8b 17 44 33       	call   0x3344:0x178b
    30fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30fe:	06                   	push   es
    30ff:	57                   	push   di
    3100:	9a 3b 32 c6 33       	call   0x33c6:0x323b
    3105:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3109:	83 c4 06             	add    sp,0x6
    310c:	eb 1b                	jmp    0x3129
    310e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3111:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3114:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3117:	ff 76 f6             	push   WORD PTR [bp-0xa]
    311a:	9a 2d 34 27 37       	call   0x3727:0x342d
    311f:	ea 85 13 27 31       	jmp    0x3127:0x1385
    3124:	9a 34 14 58 31       	call   0x3158:0x1434
    3129:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    312d:	83 c4 06             	add    sp,0x6
    3130:	eb 28                	jmp    0x315a
    3132:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3135:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3138:	eb 1b                	jmp    0x3155
    313a:	c6 06 8e 04 01       	mov    BYTE PTR ds:0x48e,0x1
    313f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3142:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    3149:	06                   	push   es
    314a:	57                   	push   di
    314b:	9a 56 55 d7 47       	call   0x47d7:0x5556
    3150:	9a c3 28 8f 4c       	call   0x4c8f:0x28c3
    3155:	9a 34 14 72 31       	call   0x3172:0x1434
    315a:	c9                   	leave
    315b:	ca 04 00             	retf   0x4
    315e:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    3161:	6c                   	ins    BYTE PTR es:[di],dx
    3162:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    3167:	6f                   	outs   dx,WORD PTR ds:[si]
    3168:	6e                   	outs   dx,BYTE PTR ds:[si]
    3169:	55                   	push   bp
    316a:	89 e5                	mov    bp,sp
    316c:	b8 02 00             	mov    ax,0x2
    316f:	9a 44 04 44 32       	call   0x3244:0x444
    3174:	83 ec 02             	sub    sp,0x2
    3177:	bf 5e 31             	mov    di,0x315e
    317a:	0e                   	push   cs
    317b:	57                   	push   di
    317c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    317f:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3184:	06                   	push   es
    3185:	57                   	push   di
    3186:	9a 9b 3b 64 32       	call   0x3264:0x3b9b
    318b:	89 c7                	mov    di,ax
    318d:	8e c2                	mov    es,dx
    318f:	06                   	push   es
    3190:	57                   	push   di
    3191:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3194:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    3198:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    319b:	26 88 85 69 03       	mov    BYTE PTR es:[di+0x369],al
    31a0:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
    31a6:	74 48                	je     0x31f0
    31a8:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    31ad:	26 8a 45 3e          	mov    al,BYTE PTR es:[di+0x3e]
    31b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31b4:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    31b9:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    31bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31c0:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    31c5:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    31c9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    31cc:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    31d0:	74 09                	je     0x31db
    31d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31d5:	26 c6 85 69 03 00    	mov    BYTE PTR es:[di+0x369],0x0
    31db:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    31de:	50                   	push   ax
    31df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e2:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    31e7:	06                   	push   es
    31e8:	57                   	push   di
    31e9:	9a 77 1c 2a 33       	call   0x332a:0x1c77
    31ee:	eb 04                	jmp    0x31f4
    31f0:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    31f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f7:	26 8a 85 69 03       	mov    al,BYTE PTR es:[di+0x369]
    31fc:	50                   	push   ax
    31fd:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
    3202:	06                   	push   es
    3203:	57                   	push   di
    3204:	9a 11 6e f5 32       	call   0x32f5:0x6e11
    3209:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    320c:	c9                   	leave
    320d:	ca 04 00             	retf   0x4
    3210:	11 4d 6f             	adc    WORD PTR [di+0x6f],cx
    3213:	64 65 41             	fs gs inc cx
    3216:	6d                   	ins    WORD PTR es:[di],dx
    3217:	6f                   	outs   dx,WORD PTR ds:[si]
    3218:	72 74                	jb     0x328e
    321a:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    321f:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3221:	74 00                	je     0x3223
    3223:	80 ff ff             	cmp    bh,0xff
    3226:	ff                   	(bad)
    3227:	7f 00                	jg     0x3229
    3229:	00 10                	add    BYTE PTR [bx+si],dl
    322b:	44                   	inc    sp
    322c:	65 6d                	gs ins WORD PTR es:[di],dx
    322e:	61                   	popa
    322f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3230:	64 65 45             	fs gs inc bp
    3233:	76 6f                	jbe    0x32a4
    3235:	6c                   	ins    BYTE PTR es:[di],dx
    3236:	75 74                	jne    0x32ac
    3238:	69 6f 6e 55 89       	imul   bp,WORD PTR [bx+0x6e],0x8955
    323d:	e5 b8                	in     ax,0xb8
    323f:	04 00                	add    al,0x0
    3241:	9a 44 04 e5 32       	call   0x32e5:0x444
    3246:	83 ec 04             	sub    sp,0x4
    3249:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    324c:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3251:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3254:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3257:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    325d:	75 11                	jne    0x3270
    325f:	06                   	push   es
    3260:	57                   	push   di
    3261:	9a 3c 53 6e 32       	call   0x326e:0x533c
    3266:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3269:	06                   	push   es
    326a:	57                   	push   di
    326b:	9a 8b 55 8b 32       	call   0x328b:0x558b
    3270:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3273:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    3278:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    327b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    327e:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3284:	75 11                	jne    0x3297
    3286:	06                   	push   es
    3287:	57                   	push   di
    3288:	9a 3c 53 95 32       	call   0x3295:0x533c
    328d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3290:	06                   	push   es
    3291:	57                   	push   di
    3292:	9a 8b 55 b2 32       	call   0x32b2:0x558b
    3297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329a:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    329f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    32a2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    32a5:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    32ab:	75 11                	jne    0x32be
    32ad:	06                   	push   es
    32ae:	57                   	push   di
    32af:	9a 3c 53 bc 32       	call   0x32bc:0x533c
    32b4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32b7:	06                   	push   es
    32b8:	57                   	push   di
    32b9:	9a 8b 55 d0 32       	call   0x32d0:0x558b
    32be:	bf 10 32             	mov    di,0x3210
    32c1:	0e                   	push   cs
    32c2:	57                   	push   di
    32c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32c6:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    32cb:	06                   	push   es
    32cc:	57                   	push   di
    32cd:	9a 9b 3b 58 33       	call   0x3358:0x3b9b
    32d2:	89 c7                	mov    di,ax
    32d4:	8e c2                	mov    es,dx
    32d6:	06                   	push   es
    32d7:	57                   	push   di
    32d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32db:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    32df:	bf 22 32             	mov    di,0x3222
    32e2:	9a 16 04 6d 33       	call   0x336d:0x416
    32e7:	50                   	push   ax
    32e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32eb:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    32f0:	06                   	push   es
    32f1:	57                   	push   di
    32f2:	9a 2e 5c 04 33       	call   0x3304:0x5c2e
    32f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32fa:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    32ff:	06                   	push   es
    3300:	57                   	push   di
    3301:	9a 07 5c 7d 33       	call   0x337d:0x5c07
    3306:	3d 01 00             	cmp    ax,0x1
    3309:	b0 00                	mov    al,0x0
    330b:	75 01                	jne    0x330e
    330d:	40                   	inc    ax
    330e:	8a d0                	mov    dl,al
    3310:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    3315:	b0 00                	mov    al,0x0
    3317:	7c 01                	jl     0x331a
    3319:	40                   	inc    ax
    331a:	22 c2                	and    al,dl
    331c:	50                   	push   ax
    331d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3320:	26 c4 bd 5c 03       	les    di,DWORD PTR es:[di+0x35c]
    3325:	06                   	push   es
    3326:	57                   	push   di
    3327:	9a 77 1c e2 43       	call   0x43e2:0x1c77
    332c:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    3331:	75 13                	jne    0x3346
    3333:	6a 00                	push   0x0
    3335:	6a 08                	push   0x8
    3337:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    333a:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    333f:	06                   	push   es
    3340:	57                   	push   di
    3341:	9a 8b 17 d1 34       	call   0x34d1:0x178b
    3346:	bf 2a 32             	mov    di,0x322a
    3349:	0e                   	push   cs
    334a:	57                   	push   di
    334b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    334e:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    3353:	06                   	push   es
    3354:	57                   	push   di
    3355:	9a 9b 3b 91 33       	call   0x3391:0x3b9b
    335a:	89 c7                	mov    di,ax
    335c:	8e c2                	mov    es,dx
    335e:	06                   	push   es
    335f:	57                   	push   di
    3360:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3363:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3367:	bf 22 32             	mov    di,0x3222
    336a:	9a 16 04 a6 33       	call   0x33a6:0x416
    336f:	50                   	push   ax
    3370:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3373:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    3378:	06                   	push   es
    3379:	57                   	push   di
    337a:	9a 2e 5c b6 33       	call   0x33b6:0x5c2e
    337f:	bf 2a 32             	mov    di,0x322a
    3382:	0e                   	push   cs
    3383:	57                   	push   di
    3384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3387:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    338c:	06                   	push   es
    338d:	57                   	push   di
    338e:	9a 9b 3b 6e 34       	call   0x346e:0x3b9b
    3393:	89 c7                	mov    di,ax
    3395:	8e c2                	mov    es,dx
    3397:	06                   	push   es
    3398:	57                   	push   di
    3399:	26 c4 3d             	les    di,DWORD PTR es:[di]
    339c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    33a0:	bf 22 32             	mov    di,0x3222
    33a3:	9a 16 04 7d 34       	call   0x347d:0x416
    33a8:	50                   	push   ax
    33a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33ac:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    33b1:	06                   	push   es
    33b2:	57                   	push   di
    33b3:	9a 2e 5c 03 35       	call   0x3503:0x5c2e
    33b8:	ff 76 08             	push   WORD PTR [bp+0x8]
    33bb:	ff 76 06             	push   WORD PTR [bp+0x6]
    33be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c1:	06                   	push   es
    33c2:	57                   	push   di
    33c3:	9a 38 13 d6 33       	call   0x33d6:0x1338
    33c8:	ff 76 08             	push   WORD PTR [bp+0x8]
    33cb:	ff 76 06             	push   WORD PTR [bp+0x6]
    33ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d1:	06                   	push   es
    33d2:	57                   	push   di
    33d3:	9a 83 13 e0 33       	call   0x33e0:0x1383
    33d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33db:	06                   	push   es
    33dc:	57                   	push   di
    33dd:	9a 50 2a ee 33       	call   0x33ee:0x2a50
    33e2:	6a ff                	push   0xffff
    33e4:	6a fa                	push   0xfffa
    33e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e9:	06                   	push   es
    33ea:	57                   	push   di
    33eb:	9a cd 26 fa 33       	call   0x33fa:0x26cd
    33f0:	6a 00                	push   0x0
    33f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33f5:	06                   	push   es
    33f6:	57                   	push   di
    33f7:	9a d5 27 04 34       	call   0x3404:0x27d5
    33fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33ff:	06                   	push   es
    3400:	57                   	push   di
    3401:	9a 69 31 72 34       	call   0x3472:0x3169
    3406:	c9                   	leave
    3407:	ca 04 00             	retf   0x4
    340a:	11 4e 6f             	adc    WORD PTR [bp+0x6f],cx
    340d:	6d                   	ins    WORD PTR es:[di],dx
    340e:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
    3411:	45                   	inc    bp
    3412:	6e                   	outs   dx,BYTE PTR ds:[si]
    3413:	74 72                	je     0x3487
    3415:	65 70 72             	gs jo  0x348a
    3418:	69 73 65 73 11       	imul   si,WORD PTR [bp+di+0x65],0x1173
    341d:	4d                   	dec    bp
    341e:	6f                   	outs   dx,WORD PTR ds:[si]
    341f:	64 65 41             	fs gs inc cx
    3422:	6d                   	ins    WORD PTR es:[di],dx
    3423:	6f                   	outs   dx,WORD PTR ds:[si]
    3424:	72 74                	jb     0x349a
    3426:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    342b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    342d:	74 0d                	je     0x343c
    342f:	49                   	dec    cx
    3430:	46                   	inc    si
    3431:	41                   	inc    cx
    3432:	4e                   	dec    si
    3433:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
    3436:	61                   	popa
    3437:	6e                   	outs   dx,BYTE PTR ds:[si]
    3438:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    343b:	73 10                	jae    0x344d
    343d:	44                   	inc    sp
    343e:	65 6d                	gs ins WORD PTR es:[di],dx
    3440:	61                   	popa
    3441:	6e                   	outs   dx,BYTE PTR ds:[si]
    3442:	64 65 45             	fs gs inc bp
    3445:	76 6f                	jbe    0x34b6
    3447:	6c                   	ins    BYTE PTR es:[di],dx
    3448:	75 74                	jne    0x34be
    344a:	69 6f 6e 11 46       	imul   bp,WORD PTR [bx+0x6e],0x4611
    344f:	61                   	popa
    3450:	63 74 65             	arpl   WORD PTR [si+0x65],si
    3453:	75 72                	jne    0x34c7
    3455:	54                   	push   sp
    3456:	65 6d                	gs ins WORD PTR es:[di],dx
    3458:	70 73                	jo     0x34cd
    345a:	46                   	inc    si
    345b:	61                   	popa
    345c:	62 50 63             	bound  dx,DWORD PTR [bx+si+0x63]
    345f:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    3462:	6c                   	ins    BYTE PTR es:[di],dx
    3463:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    3468:	6f                   	outs   dx,WORD PTR ds:[si]
    3469:	6e                   	outs   dx,BYTE PTR ds:[si]
    346a:	01 00                	add    WORD PTR [bx+si],ax
    346c:	2f                   	das
    346d:	00 a4 34 18          	add    BYTE PTR [si+0x1834],ah
    3471:	37                   	aaa
    3472:	8e 34                	mov    ?,WORD PTR [si]
    3474:	55                   	push   bp
    3475:	89 e5                	mov    bp,sp
    3477:	b8 08 00             	mov    ax,0x8
    347a:	9a 44 04 2c 37       	call   0x372c:0x444
    347f:	83 ec 08             	sub    sp,0x8
    3482:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3486:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3489:	06                   	push   es
    348a:	57                   	push   di
    348b:	9a db 38 cd 48       	call   0x48cd:0x38db
    3490:	08 c0                	or     al,al
    3492:	75 03                	jne    0x3497
    3494:	e9 97 02             	jmp    0x372e
    3497:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    349a:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    349f:	06                   	push   es
    34a0:	57                   	push   di
    34a1:	9a 3c 53 b3 34       	call   0x34b3:0x533c
    34a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34a9:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    34ae:	06                   	push   es
    34af:	57                   	push   di
    34b0:	9a 3c 53 c2 34       	call   0x34c2:0x533c
    34b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34b8:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    34bd:	06                   	push   es
    34be:	57                   	push   di
    34bf:	9a 3c 53 e7 34       	call   0x34e7:0x533c
    34c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c7:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    34cc:	06                   	push   es
    34cd:	57                   	push   di
    34ce:	9a 33 17 3d 35       	call   0x353d:0x1733
    34d3:	52                   	push   dx
    34d4:	50                   	push   ax
    34d5:	bf 0a 34             	mov    di,0x340a
    34d8:	0e                   	push   cs
    34d9:	57                   	push   di
    34da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34dd:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    34e2:	06                   	push   es
    34e3:	57                   	push   di
    34e4:	9a 9b 3b 1a 35       	call   0x351a:0x3b9b
    34e9:	89 c7                	mov    di,ax
    34eb:	8e c2                	mov    es,dx
    34ed:	06                   	push   es
    34ee:	57                   	push   di
    34ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34f2:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    34f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34f9:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    34fe:	06                   	push   es
    34ff:	57                   	push   di
    3500:	9a 07 5c 96 35       	call   0x3596:0x5c07
    3505:	99                   	cwd
    3506:	52                   	push   dx
    3507:	50                   	push   ax
    3508:	bf 1c 34             	mov    di,0x341c
    350b:	0e                   	push   cs
    350c:	57                   	push   di
    350d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3510:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3515:	06                   	push   es
    3516:	57                   	push   di
    3517:	9a 9b 3b 53 35       	call   0x3553:0x3b9b
    351c:	89 c7                	mov    di,ax
    351e:	8e c2                	mov    es,dx
    3520:	06                   	push   es
    3521:	57                   	push   di
    3522:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3525:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3529:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    352e:	75 34                	jne    0x3564
    3530:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3533:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    3538:	06                   	push   es
    3539:	57                   	push   di
    353a:	9a 33 17 03 36       	call   0x3603:0x1733
    353f:	52                   	push   dx
    3540:	50                   	push   ax
    3541:	bf 2e 34             	mov    di,0x342e
    3544:	0e                   	push   cs
    3545:	57                   	push   di
    3546:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3549:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    354e:	06                   	push   es
    354f:	57                   	push   di
    3550:	9a 9b 3b 7a 35       	call   0x357a:0x3b9b
    3555:	89 c7                	mov    di,ax
    3557:	8e c2                	mov    es,dx
    3559:	06                   	push   es
    355a:	57                   	push   di
    355b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    355e:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3562:	eb 25                	jmp    0x3589
    3564:	6a 00                	push   0x0
    3566:	6a 08                	push   0x8
    3568:	bf 2e 34             	mov    di,0x342e
    356b:	0e                   	push   cs
    356c:	57                   	push   di
    356d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3570:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3575:	06                   	push   es
    3576:	57                   	push   di
    3577:	9a 9b 3b ad 35       	call   0x35ad:0x3b9b
    357c:	89 c7                	mov    di,ax
    357e:	8e c2                	mov    es,dx
    3580:	06                   	push   es
    3581:	57                   	push   di
    3582:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3585:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3589:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    358c:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    3591:	06                   	push   es
    3592:	57                   	push   di
    3593:	9a 07 5c c9 35       	call   0x35c9:0x5c07
    3598:	99                   	cwd
    3599:	52                   	push   dx
    359a:	50                   	push   ax
    359b:	bf 3c 34             	mov    di,0x343c
    359e:	0e                   	push   cs
    359f:	57                   	push   di
    35a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35a3:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    35a8:	06                   	push   es
    35a9:	57                   	push   di
    35aa:	9a 9b 3b e0 35       	call   0x35e0:0x3b9b
    35af:	89 c7                	mov    di,ax
    35b1:	8e c2                	mov    es,dx
    35b3:	06                   	push   es
    35b4:	57                   	push   di
    35b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35b8:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    35bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35bf:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    35c4:	06                   	push   es
    35c5:	57                   	push   di
    35c6:	9a 07 5c 7a 39       	call   0x397a:0x5c07
    35cb:	99                   	cwd
    35cc:	52                   	push   dx
    35cd:	50                   	push   ax
    35ce:	bf 3c 34             	mov    di,0x343c
    35d1:	0e                   	push   cs
    35d2:	57                   	push   di
    35d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35d6:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    35db:	06                   	push   es
    35dc:	57                   	push   di
    35dd:	9a 9b 3b 19 36       	call   0x3619:0x3b9b
    35e2:	89 c7                	mov    di,ax
    35e4:	8e c2                	mov    es,dx
    35e6:	06                   	push   es
    35e7:	57                   	push   di
    35e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35eb:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    35ef:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    35f4:	7c 66                	jl     0x365c
    35f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35f9:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    35fe:	06                   	push   es
    35ff:	57                   	push   di
    3600:	9a 33 17 35 36       	call   0x3635:0x1733
    3605:	52                   	push   dx
    3606:	50                   	push   ax
    3607:	bf 4d 34             	mov    di,0x344d
    360a:	0e                   	push   cs
    360b:	57                   	push   di
    360c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    360f:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    3614:	06                   	push   es
    3615:	57                   	push   di
    3616:	9a 9b 3b 4b 36       	call   0x364b:0x3b9b
    361b:	89 c7                	mov    di,ax
    361d:	8e c2                	mov    es,dx
    361f:	06                   	push   es
    3620:	57                   	push   di
    3621:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3624:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    362b:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    3630:	06                   	push   es
    3631:	57                   	push   di
    3632:	9a 33 17 26 3c       	call   0x3c26:0x1733
    3637:	52                   	push   dx
    3638:	50                   	push   ax
    3639:	bf 4d 34             	mov    di,0x344d
    363c:	0e                   	push   cs
    363d:	57                   	push   di
    363e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3641:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    3646:	06                   	push   es
    3647:	57                   	push   di
    3648:	9a 9b 3b 72 36       	call   0x3672:0x3b9b
    364d:	89 c7                	mov    di,ax
    364f:	8e c2                	mov    es,dx
    3651:	06                   	push   es
    3652:	57                   	push   di
    3653:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3656:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    365a:	eb 4a                	jmp    0x36a6
    365c:	6a 00                	push   0x0
    365e:	6a 64                	push   0x64
    3660:	bf 4d 34             	mov    di,0x344d
    3663:	0e                   	push   cs
    3664:	57                   	push   di
    3665:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3668:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    366d:	06                   	push   es
    366e:	57                   	push   di
    366f:	9a 9b 3b 97 36       	call   0x3697:0x3b9b
    3674:	89 c7                	mov    di,ax
    3676:	8e c2                	mov    es,dx
    3678:	06                   	push   es
    3679:	57                   	push   di
    367a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    367d:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3681:	6a 00                	push   0x0
    3683:	6a 64                	push   0x64
    3685:	bf 4d 34             	mov    di,0x344d
    3688:	0e                   	push   cs
    3689:	57                   	push   di
    368a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    368d:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    3692:	06                   	push   es
    3693:	57                   	push   di
    3694:	9a 9b 3b c1 36       	call   0x36c1:0x3b9b
    3699:	89 c7                	mov    di,ax
    369b:	8e c2                	mov    es,dx
    369d:	06                   	push   es
    369e:	57                   	push   di
    369f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36a2:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    36a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36a9:	26 8a 85 69 03       	mov    al,BYTE PTR es:[di+0x369]
    36ae:	50                   	push   ax
    36af:	bf 5f 34             	mov    di,0x345f
    36b2:	0e                   	push   cs
    36b3:	57                   	push   di
    36b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b7:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    36bc:	06                   	push   es
    36bd:	57                   	push   di
    36be:	9a 9b 3b eb 36       	call   0x36eb:0x3b9b
    36c3:	89 c7                	mov    di,ax
    36c5:	8e c2                	mov    es,dx
    36c7:	06                   	push   es
    36c8:	57                   	push   di
    36c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36cc:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    36d0:	b8 6a 34             	mov    ax,0x346a
    36d3:	0e                   	push   cs
    36d4:	50                   	push   ax
    36d5:	55                   	push   bp
    36d6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    36da:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    36de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36e1:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    36e6:	06                   	push   es
    36e7:	57                   	push   di
    36e8:	9a a0 54 fa 36       	call   0x36fa:0x54a0
    36ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36f0:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    36f5:	06                   	push   es
    36f6:	57                   	push   di
    36f7:	9a a0 54 09 37       	call   0x3709:0x54a0
    36fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ff:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3704:	06                   	push   es
    3705:	57                   	push   di
    3706:	9a a0 54 2c 39       	call   0x392c:0x54a0
    370b:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    370f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3713:	83 c4 06             	add    sp,0x6
    3716:	eb 16                	jmp    0x372e
    3718:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    371b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    371e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3721:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3724:	9a 2d 34 ff ff       	call   0xffff:0x342d
    3729:	9a 34 14 e4 38       	call   0x38e4:0x1434
    372e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3731:	c9                   	leave
    3732:	ca 04 00             	retf   0x4
    3735:	14 43                	adc    al,0x43
    3737:	61                   	popa
    3738:	70 69                	jo     0x37a3
    373a:	74 61                	je     0x379d
    373c:	6c                   	ins    BYTE PTR es:[di],dx
    373d:	53                   	push   bx
    373e:	6f                   	outs   dx,WORD PTR ds:[si]
    373f:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    3742:	6c                   	ins    BYTE PTR es:[di],dx
    3743:	49                   	dec    cx
    3744:	6e                   	outs   dx,BYTE PTR ds:[si]
    3745:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
    374a:	00 00                	add    BYTE PTR [bx+si],al
    374c:	00 00                	add    BYTE PTR [bx+si],al
    374e:	12 44 75             	adc    al,BYTE PTR [si+0x75]
    3751:	72 65                	jb     0x37b8
    3753:	65 41                	gs inc cx
    3755:	6d                   	ins    WORD PTR es:[di],dx
    3756:	6f                   	outs   dx,WORD PTR ds:[si]
    3757:	72 74                	jb     0x37cd
    3759:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    375e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3760:	74 13                	je     0x3775
    3762:	43                   	inc    bx
    3763:	6f                   	outs   dx,WORD PTR ds:[si]
    3764:	65 66 66 41          	gs data32 inc ecx
    3768:	6d                   	ins    WORD PTR es:[di],dx
    3769:	6f                   	outs   dx,WORD PTR ds:[si]
    376a:	72 74                	jb     0x37e0
    376c:	44                   	inc    sp
    376d:	65 67 72 65          	gs addr32 jb 0x37d6
    3771:	73 73                	jae    0x37e6
    3773:	69 66 00 00 80       	imul   sp,WORD PTR [bp+0x0],0x8000
    3778:	3f                   	aas
    3779:	00 00                	add    BYTE PTR [bx+si],al
    377b:	a0 40 11             	mov    al,ds:0x1140
    377e:	4d                   	dec    bp
    377f:	61                   	popa
    3780:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3783:	6e                   	outs   dx,BYTE PTR ds:[si]
    3784:	65 73 49             	gs jae 0x37d0
    3787:	6e                   	outs   dx,BYTE PTR ds:[si]
    3788:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
    378d:	65 73 0a             	gs jae 0x379a
    3790:	48                   	dec    ax
    3791:	53                   	push   bx
    3792:	56                   	push   si
    3793:	6f                   	outs   dx,WORD PTR ds:[si]
    3794:	6c                   	ins    BYTE PTR es:[di],dx
    3795:	75 6d                	jne    0x3804
    3797:	65 50                	gs push ax
    3799:	63 00                	arpl   WORD PTR [bx+si],ax
    379b:	00 c8                	add    al,cl
    379d:	42                   	inc    dx
    379e:	0b 48 53             	or     cx,WORD PTR [bx+si+0x53]
    37a1:	53                   	push   bx
    37a2:	75 72                	jne    0x3816
    37a4:	43                   	inc    bx
    37a5:	6f                   	outs   dx,WORD PTR ds:[si]
    37a6:	75 74                	jne    0x381c
    37a8:	50                   	push   ax
    37a9:	63 00                	arpl   WORD PTR [bx+si],ax
    37ab:	80 ff ff             	cmp    bh,0xff
    37ae:	ff                   	(bad)
    37af:	7f 00                	jg     0x37b1
    37b1:	00 09                	add    BYTE PTR [bx+di],cl
    37b3:	49                   	dec    cx
    37b4:	46                   	inc    si
    37b5:	41                   	inc    cx
    37b6:	53                   	push   bx
    37b7:	65 75 69             	gs jne 0x3823
    37ba:	6c                   	ins    BYTE PTR es:[di],dx
    37bb:	31 09                	xor    WORD PTR [bx+di],cx
    37bd:	49                   	dec    cx
    37be:	46                   	inc    si
    37bf:	41                   	inc    cx
    37c0:	53                   	push   bx
    37c1:	65 75 69             	gs jne 0x382d
    37c4:	6c                   	ins    BYTE PTR es:[di],dx
    37c5:	32 09                	xor    cl,BYTE PTR [bx+di]
    37c7:	49                   	dec    cx
    37c8:	46                   	inc    si
    37c9:	41                   	inc    cx
    37ca:	53                   	push   bx
    37cb:	65 75 69             	gs jne 0x3837
    37ce:	6c                   	ins    BYTE PTR es:[di],dx
    37cf:	33 09                	xor    cx,WORD PTR [bx+di]
    37d1:	49                   	dec    cx
    37d2:	46                   	inc    si
    37d3:	41                   	inc    cx
    37d4:	53                   	push   bx
    37d5:	65 75 69             	gs jne 0x3841
    37d8:	6c                   	ins    BYTE PTR es:[di],dx
    37d9:	34 09                	xor    al,0x9
    37db:	49                   	dec    cx
    37dc:	46                   	inc    si
    37dd:	41                   	inc    cx
    37de:	53                   	push   bx
    37df:	65 75 69             	gs jne 0x384b
    37e2:	6c                   	ins    BYTE PTR es:[di],dx
    37e3:	35 09 49             	xor    ax,0x4909
    37e6:	46                   	inc    si
    37e7:	41                   	inc    cx
    37e8:	53                   	push   bx
    37e9:	65 75 69             	gs jne 0x3855
    37ec:	6c                   	ins    BYTE PTR es:[di],dx
    37ed:	36 09 49 46          	or     WORD PTR ss:[bx+di+0x46],cx
    37f1:	41                   	inc    cx
    37f2:	53                   	push   bx
    37f3:	65 75 69             	gs jne 0x385f
    37f6:	6c                   	ins    BYTE PTR es:[di],dx
    37f7:	37                   	aaa
    37f8:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
    37fb:	41                   	inc    cx
    37fc:	53                   	push   bx
    37fd:	65 75 69             	gs jne 0x3869
    3800:	6c                   	ins    BYTE PTR es:[di],dx
    3801:	38 09                	cmp    BYTE PTR [bx+di],cl
    3803:	49                   	dec    cx
    3804:	46                   	inc    si
    3805:	41                   	inc    cx
    3806:	53                   	push   bx
    3807:	65 75 69             	gs jne 0x3873
    380a:	6c                   	ins    BYTE PTR es:[di],dx
    380b:	39 0a                	cmp    WORD PTR [bp+si],cx
    380d:	49                   	dec    cx
    380e:	46                   	inc    si
    380f:	41                   	inc    cx
    3810:	53                   	push   bx
    3811:	65 75 69             	gs jne 0x387d
    3814:	6c                   	ins    BYTE PTR es:[di],dx
    3815:	31 30                	xor    WORD PTR [bx+si],si
    3817:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
    381a:	41                   	inc    cx
    381b:	54                   	push   sp
    381c:	61                   	popa
    381d:	72 69                	jb     0x3888
    381f:	66 31 09             	xor    DWORD PTR [bx+di],ecx
    3822:	49                   	dec    cx
    3823:	46                   	inc    si
    3824:	41                   	inc    cx
    3825:	54                   	push   sp
    3826:	61                   	popa
    3827:	72 69                	jb     0x3892
    3829:	66 32 09             	data32 xor cl,BYTE PTR [bx+di]
    382c:	49                   	dec    cx
    382d:	46                   	inc    si
    382e:	41                   	inc    cx
    382f:	54                   	push   sp
    3830:	61                   	popa
    3831:	72 69                	jb     0x389c
    3833:	66 33 09             	xor    ecx,DWORD PTR [bx+di]
    3836:	49                   	dec    cx
    3837:	46                   	inc    si
    3838:	41                   	inc    cx
    3839:	54                   	push   sp
    383a:	61                   	popa
    383b:	72 69                	jb     0x38a6
    383d:	66 34 09             	data32 xor al,0x9
    3840:	49                   	dec    cx
    3841:	46                   	inc    si
    3842:	41                   	inc    cx
    3843:	54                   	push   sp
    3844:	61                   	popa
    3845:	72 69                	jb     0x38b0
    3847:	66 35 09 49 46 41    	xor    eax,0x41464909
    384d:	54                   	push   sp
    384e:	61                   	popa
    384f:	72 69                	jb     0x38ba
    3851:	66 36 09 49 46       	or     DWORD PTR ss:[bx+di+0x46],ecx
    3856:	41                   	inc    cx
    3857:	54                   	push   sp
    3858:	61                   	popa
    3859:	72 69                	jb     0x38c4
    385b:	66 37                	data32 aaa
    385d:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
    3860:	41                   	inc    cx
    3861:	54                   	push   sp
    3862:	61                   	popa
    3863:	72 69                	jb     0x38ce
    3865:	66 38 09             	data32 cmp BYTE PTR [bx+di],cl
    3868:	49                   	dec    cx
    3869:	46                   	inc    si
    386a:	41                   	inc    cx
    386b:	54                   	push   sp
    386c:	61                   	popa
    386d:	72 69                	jb     0x38d8
    386f:	66 39 0a             	cmp    DWORD PTR [bp+si],ecx
    3872:	49                   	dec    cx
    3873:	46                   	inc    si
    3874:	41                   	inc    cx
    3875:	54                   	push   sp
    3876:	61                   	popa
    3877:	72 69                	jb     0x38e2
    3879:	66 31 30             	xor    DWORD PTR [bx+si],esi
    387c:	0a 49 46             	or     cl,BYTE PTR [bx+di+0x46]
    387f:	41                   	inc    cx
    3880:	54                   	push   sp
    3881:	61                   	popa
    3882:	72 69                	jb     0x38ed
    3884:	66 31 31             	xor    DWORD PTR [bx+di],esi
    3887:	01 00                	add    WORD PTR [bx+si],ax
    3889:	00 00                	add    BYTE PTR [bx+si],al
    388b:	0a 00                	or     al,BYTE PTR [bx+si]
    388d:	00 00                	add    BYTE PTR [bx+si],al
    388f:	01 00                	add    WORD PTR [bx+si],ax
    3891:	00 00                	add    BYTE PTR [bx+si],al
    3893:	0b 00                	or     ax,WORD PTR [bx+si]
    3895:	00 00                	add    BYTE PTR [bx+si],al
    3897:	01 00                	add    WORD PTR [bx+si],ax
    3899:	00 00                	add    BYTE PTR [bx+si],al
    389b:	02 00                	add    al,BYTE PTR [bx+si]
    389d:	00 00                	add    BYTE PTR [bx+si],al
    389f:	10 54 65             	adc    BYTE PTR [si+0x65],dl
    38a2:	6d                   	ins    WORD PTR es:[di],dx
    38a3:	70 73                	jo     0x3918
    38a5:	46                   	inc    si
    38a6:	61                   	popa
    38a7:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    38aa:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    38ad:	69 6f 6e 0d 44       	imul   bp,WORD PTR [bx+0x6e],0x440d
    38b2:	65 6d                	gs ins WORD PTR es:[di],dx
    38b4:	61                   	popa
    38b5:	6e                   	outs   dx,BYTE PTR ds:[si]
    38b6:	64 65 50             	fs gs push ax
    38b9:	6f                   	outs   dx,WORD PTR ds:[si]
    38ba:	74 45                	je     0x3901
    38bc:	6e                   	outs   dx,BYTE PTR ds:[si]
    38bd:	74 10                	je     0x38cf
    38bf:	44                   	inc    sp
    38c0:	65 6d                	gs ins WORD PTR es:[di],dx
    38c2:	61                   	popa
    38c3:	6e                   	outs   dx,BYTE PTR ds:[si]
    38c4:	64 65 50             	fs gs push ax
    38c7:	61                   	popa
    38c8:	72 61                	jb     0x392b
    38ca:	6d                   	ins    WORD PTR es:[di],dx
    38cb:	65 74 72             	gs je  0x3940
    38ce:	65 00 00             	add    BYTE PTR gs:[bx+si],al
    38d1:	20 41 eb             	and    BYTE PTR [bx+di-0x15],al
    38d4:	ff                   	(bad)
    38d5:	ff                   	(bad)
    38d6:	ff                   	(bad)
    38d7:	ff                   	(bad)
    38d8:	ff                   	(bad)
    38d9:	ff 02                	inc    WORD PTR [bp+si]
    38db:	55                   	push   bp
    38dc:	89 e5                	mov    bp,sp
    38de:	b8 2c 02             	mov    ax,0x22c
    38e1:	9a 44 04 2e 3c       	call   0x3c2e:0x444
    38e6:	81 ec 2c 02          	sub    sp,0x22c
    38ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ed:	26 8b 85 94 01       	mov    ax,WORD PTR es:[di+0x194]
    38f2:	26 8b 95 96 01       	mov    dx,WORD PTR es:[di+0x196]
    38f7:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    38fb:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    38ff:	26 8b 85 9c 01       	mov    ax,WORD PTR es:[di+0x19c]
    3904:	26 8b 95 9e 01       	mov    dx,WORD PTR es:[di+0x19e]
    3909:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    390d:	89 96 e8 fe          	mov    WORD PTR [bp-0x118],dx
    3911:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3916:	89 be d8 fe          	mov    WORD PTR [bp-0x128],di
    391a:	8c 86 da fe          	mov    WORD PTR [bp-0x126],es
    391e:	bf 35 37             	mov    di,0x3735
    3921:	0e                   	push   cs
    3922:	57                   	push   di
    3923:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3927:	06                   	push   es
    3928:	57                   	push   di
    3929:	9a 9b 3b 8e 39       	call   0x398e:0x3b9b
    392e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3931:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3934:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3937:	06                   	push   es
    3938:	57                   	push   di
    3939:	26 c4 3d             	les    di,DWORD PTR es:[di]
    393c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3940:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    3944:	90                   	nop
    3945:	9b 9b dd 46 ec       	fld    QWORD PTR [bp-0x14]
    394a:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    3950:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    3955:	90                   	nop
    3956:	9b                   	fwait
    3957:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    395b:	9e                   	sahf
    395c:	77 0f                	ja     0x396d
    395e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3961:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3967:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    396d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3970:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    3975:	06                   	push   es
    3976:	57                   	push   di
    3977:	9a 07 5c 7a 42       	call   0x427a:0x5c07
    397c:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    3980:	bf 4e 37             	mov    di,0x374e
    3983:	0e                   	push   cs
    3984:	57                   	push   di
    3985:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3989:	06                   	push   es
    398a:	57                   	push   di
    398b:	9a 9b 3b 45 3a       	call   0x3a45:0x3b9b
    3990:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3993:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3996:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3999:	06                   	push   es
    399a:	57                   	push   di
    399b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    399e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    39a2:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    39a5:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    39a8:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    39ac:	7f 0c                	jg     0x39ba
    39ae:	7c 06                	jl     0x39b6
    39b0:	83 7e e8 64          	cmp    WORD PTR [bp-0x18],0x64
    39b4:	77 04                	ja     0x39ba
    39b6:	b0 00                	mov    al,0x0
    39b8:	eb 02                	jmp    0x39bc
    39ba:	b0 01                	mov    al,0x1
    39bc:	8a d0                	mov    dl,al
    39be:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    39c2:	7c 0c                	jl     0x39d0
    39c4:	7f 06                	jg     0x39cc
    39c6:	83 7e e8 00          	cmp    WORD PTR [bp-0x18],0x0
    39ca:	72 04                	jb     0x39d0
    39cc:	b0 00                	mov    al,0x0
    39ce:	eb 02                	jmp    0x39d2
    39d0:	b0 01                	mov    al,0x1
    39d2:	0a c2                	or     al,dl
    39d4:	08 c0                	or     al,al
    39d6:	74 0f                	je     0x39e7
    39d8:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    39db:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    39e1:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    39e7:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    39ec:	7d 03                	jge    0x39f1
    39ee:	e9 c2 00             	jmp    0x3ab3
    39f1:	83 be dc fe 01       	cmp    WORD PTR [bp-0x124],0x1
    39f6:	75 3f                	jne    0x3a37
    39f8:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    39fc:	7f 0c                	jg     0x3a0a
    39fe:	7c 06                	jl     0x3a06
    3a00:	83 7e e8 0f          	cmp    WORD PTR [bp-0x18],0xf
    3a04:	77 04                	ja     0x3a0a
    3a06:	b0 00                	mov    al,0x0
    3a08:	eb 02                	jmp    0x3a0c
    3a0a:	b0 01                	mov    al,0x1
    3a0c:	8a d0                	mov    dl,al
    3a0e:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    3a12:	7c 0c                	jl     0x3a20
    3a14:	7f 06                	jg     0x3a1c
    3a16:	83 7e e8 01          	cmp    WORD PTR [bp-0x18],0x1
    3a1a:	72 04                	jb     0x3a20
    3a1c:	b0 00                	mov    al,0x0
    3a1e:	eb 02                	jmp    0x3a22
    3a20:	b0 01                	mov    al,0x1
    3a22:	0a c2                	or     al,dl
    3a24:	08 c0                	or     al,al
    3a26:	74 0f                	je     0x3a37
    3a28:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a2b:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3a31:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    3a37:	bf 61 37             	mov    di,0x3761
    3a3a:	0e                   	push   cs
    3a3b:	57                   	push   di
    3a3c:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3a40:	06                   	push   es
    3a41:	57                   	push   di
    3a42:	9a 9b 3b c1 3a       	call   0x3ac1:0x3b9b
    3a47:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3a4a:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3a4d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a50:	06                   	push   es
    3a51:	57                   	push   di
    3a52:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a55:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3a59:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    3a5d:	90                   	nop
    3a5e:	9b                   	fwait
    3a5f:	83 be dc fe 01       	cmp    WORD PTR [bp-0x124],0x1
    3a64:	75 4d                	jne    0x3ab3
    3a66:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    3a6a:	9b 2e d8 1e 79 37    	fcomp  DWORD PTR cs:0x3779
    3a70:	9b dd be d4 fe       	fstsw  WORD PTR [bp-0x12c]
    3a75:	90                   	nop
    3a76:	9b                   	fwait
    3a77:	8a a6 d5 fe          	mov    ah,BYTE PTR [bp-0x12b]
    3a7b:	9e                   	sahf
    3a7c:	b0 00                	mov    al,0x0
    3a7e:	76 01                	jbe    0x3a81
    3a80:	40                   	inc    ax
    3a81:	8a d0                	mov    dl,al
    3a83:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    3a87:	9b 2e d8 1e 75 37    	fcomp  DWORD PTR cs:0x3775
    3a8d:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    3a92:	90                   	nop
    3a93:	9b                   	fwait
    3a94:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    3a98:	9e                   	sahf
    3a99:	b0 00                	mov    al,0x0
    3a9b:	73 01                	jae    0x3a9e
    3a9d:	40                   	inc    ax
    3a9e:	0a c2                	or     al,dl
    3aa0:	08 c0                	or     al,al
    3aa2:	74 0f                	je     0x3ab3
    3aa4:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3aa7:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3aad:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    3ab3:	bf 7d 37             	mov    di,0x377d
    3ab6:	0e                   	push   cs
    3ab7:	57                   	push   di
    3ab8:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3abc:	06                   	push   es
    3abd:	57                   	push   di
    3abe:	9a 9b 3b 33 3b       	call   0x3b33:0x3b9b
    3ac3:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3ac6:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3ac9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3acc:	06                   	push   es
    3acd:	57                   	push   di
    3ace:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ad1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3ad5:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3ad8:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3adb:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    3adf:	7f 0d                	jg     0x3aee
    3ae1:	7c 07                	jl     0x3aea
    3ae3:	81 7e e8 10 27       	cmp    WORD PTR [bp-0x18],0x2710
    3ae8:	77 04                	ja     0x3aee
    3aea:	b0 00                	mov    al,0x0
    3aec:	eb 02                	jmp    0x3af0
    3aee:	b0 01                	mov    al,0x1
    3af0:	8a d0                	mov    dl,al
    3af2:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    3af6:	7c 0c                	jl     0x3b04
    3af8:	7f 06                	jg     0x3b00
    3afa:	83 7e e8 01          	cmp    WORD PTR [bp-0x18],0x1
    3afe:	72 04                	jb     0x3b04
    3b00:	b0 00                	mov    al,0x0
    3b02:	eb 02                	jmp    0x3b06
    3b04:	b0 01                	mov    al,0x1
    3b06:	0a c2                	or     al,dl
    3b08:	08 c0                	or     al,al
    3b0a:	74 0f                	je     0x3b1b
    3b0c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3b0f:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3b15:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    3b1b:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    3b20:	7d 03                	jge    0x3b25
    3b22:	e9 ea 00             	jmp    0x3c0f
    3b25:	bf 8f 37             	mov    di,0x378f
    3b28:	0e                   	push   cs
    3b29:	57                   	push   di
    3b2a:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3b2e:	06                   	push   es
    3b2f:	57                   	push   di
    3b30:	9a 9b 3b a8 3b       	call   0x3ba8:0x3b9b
    3b35:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3b38:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3b3b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3b3e:	06                   	push   es
    3b3f:	57                   	push   di
    3b40:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b43:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3b47:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    3b4b:	90                   	nop
    3b4c:	9b 9b dd 46 ec       	fld    QWORD PTR [bp-0x14]
    3b51:	9b 2e d8 1e 9a 37    	fcomp  DWORD PTR cs:0x379a
    3b57:	9b dd be d4 fe       	fstsw  WORD PTR [bp-0x12c]
    3b5c:	90                   	nop
    3b5d:	9b                   	fwait
    3b5e:	8a a6 d5 fe          	mov    ah,BYTE PTR [bp-0x12b]
    3b62:	9e                   	sahf
    3b63:	b0 00                	mov    al,0x0
    3b65:	76 01                	jbe    0x3b68
    3b67:	40                   	inc    ax
    3b68:	8a d0                	mov    dl,al
    3b6a:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    3b6e:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    3b74:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    3b79:	90                   	nop
    3b7a:	9b                   	fwait
    3b7b:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    3b7f:	9e                   	sahf
    3b80:	b0 00                	mov    al,0x0
    3b82:	73 01                	jae    0x3b85
    3b84:	40                   	inc    ax
    3b85:	0a c2                	or     al,dl
    3b87:	08 c0                	or     al,al
    3b89:	74 0f                	je     0x3b9a
    3b8b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3b8e:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3b94:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    3b9a:	bf 9e 37             	mov    di,0x379e
    3b9d:	0e                   	push   cs
    3b9e:	57                   	push   di
    3b9f:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3ba3:	06                   	push   es
    3ba4:	57                   	push   di
    3ba5:	9a 9b 3b 41 3c       	call   0x3c41:0x3b9b
    3baa:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3bad:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3bb0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3bb3:	06                   	push   es
    3bb4:	57                   	push   di
    3bb5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bb8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3bbc:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    3bc0:	90                   	nop
    3bc1:	9b 9b dd 46 ec       	fld    QWORD PTR [bp-0x14]
    3bc6:	9b 2e d8 1e 9a 37    	fcomp  DWORD PTR cs:0x379a
    3bcc:	9b dd be d4 fe       	fstsw  WORD PTR [bp-0x12c]
    3bd1:	90                   	nop
    3bd2:	9b                   	fwait
    3bd3:	8a a6 d5 fe          	mov    ah,BYTE PTR [bp-0x12b]
    3bd7:	9e                   	sahf
    3bd8:	b0 00                	mov    al,0x0
    3bda:	76 01                	jbe    0x3bdd
    3bdc:	40                   	inc    ax
    3bdd:	8a d0                	mov    dl,al
    3bdf:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    3be3:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    3be9:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    3bee:	90                   	nop
    3bef:	9b                   	fwait
    3bf0:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    3bf4:	9e                   	sahf
    3bf5:	b0 00                	mov    al,0x0
    3bf7:	73 01                	jae    0x3bfa
    3bf9:	40                   	inc    ax
    3bfa:	0a c2                	or     al,dl
    3bfc:	08 c0                	or     al,al
    3bfe:	74 0f                	je     0x3c0f
    3c00:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3c03:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3c09:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    3c0f:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    3c14:	74 03                	je     0x3c19
    3c16:	e9 0e 05             	jmp    0x4127
    3c19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c1c:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    3c21:	06                   	push   es
    3c22:	57                   	push   di
    3c23:	9a 33 17 4d 4c       	call   0x4c4d:0x1733
    3c28:	bf aa 37             	mov    di,0x37aa
    3c2b:	9a 16 04 26 3e       	call   0x3e26:0x416
    3c30:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    3c33:	bf b2 37             	mov    di,0x37b2
    3c36:	0e                   	push   cs
    3c37:	57                   	push   di
    3c38:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3c3c:	06                   	push   es
    3c3d:	57                   	push   di
    3c3e:	9a 9b 3b 59 3c       	call   0x3c59:0x3b9b
    3c43:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    3c47:	89 96 70 ff          	mov    WORD PTR [bp-0x90],dx
    3c4b:	bf bc 37             	mov    di,0x37bc
    3c4e:	0e                   	push   cs
    3c4f:	57                   	push   di
    3c50:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3c54:	06                   	push   es
    3c55:	57                   	push   di
    3c56:	9a 9b 3b 71 3c       	call   0x3c71:0x3b9b
    3c5b:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    3c5f:	89 96 7c ff          	mov    WORD PTR [bp-0x84],dx
    3c63:	bf c6 37             	mov    di,0x37c6
    3c66:	0e                   	push   cs
    3c67:	57                   	push   di
    3c68:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3c6c:	06                   	push   es
    3c6d:	57                   	push   di
    3c6e:	9a 9b 3b 87 3c       	call   0x3c87:0x3b9b
    3c73:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    3c76:	89 56 88             	mov    WORD PTR [bp-0x78],dx
    3c79:	bf d0 37             	mov    di,0x37d0
    3c7c:	0e                   	push   cs
    3c7d:	57                   	push   di
    3c7e:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3c82:	06                   	push   es
    3c83:	57                   	push   di
    3c84:	9a 9b 3b 9d 3c       	call   0x3c9d:0x3b9b
    3c89:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    3c8c:	89 56 94             	mov    WORD PTR [bp-0x6c],dx
    3c8f:	bf da 37             	mov    di,0x37da
    3c92:	0e                   	push   cs
    3c93:	57                   	push   di
    3c94:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3c98:	06                   	push   es
    3c99:	57                   	push   di
    3c9a:	9a 9b 3b b3 3c       	call   0x3cb3:0x3b9b
    3c9f:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    3ca2:	89 56 a0             	mov    WORD PTR [bp-0x60],dx
    3ca5:	bf e4 37             	mov    di,0x37e4
    3ca8:	0e                   	push   cs
    3ca9:	57                   	push   di
    3caa:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3cae:	06                   	push   es
    3caf:	57                   	push   di
    3cb0:	9a 9b 3b c9 3c       	call   0x3cc9:0x3b9b
    3cb5:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    3cb8:	89 56 ac             	mov    WORD PTR [bp-0x54],dx
    3cbb:	bf ee 37             	mov    di,0x37ee
    3cbe:	0e                   	push   cs
    3cbf:	57                   	push   di
    3cc0:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3cc4:	06                   	push   es
    3cc5:	57                   	push   di
    3cc6:	9a 9b 3b df 3c       	call   0x3cdf:0x3b9b
    3ccb:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    3cce:	89 56 b8             	mov    WORD PTR [bp-0x48],dx
    3cd1:	bf f8 37             	mov    di,0x37f8
    3cd4:	0e                   	push   cs
    3cd5:	57                   	push   di
    3cd6:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3cda:	06                   	push   es
    3cdb:	57                   	push   di
    3cdc:	9a 9b 3b f5 3c       	call   0x3cf5:0x3b9b
    3ce1:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    3ce4:	89 56 c4             	mov    WORD PTR [bp-0x3c],dx
    3ce7:	bf 02 38             	mov    di,0x3802
    3cea:	0e                   	push   cs
    3ceb:	57                   	push   di
    3cec:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3cf0:	06                   	push   es
    3cf1:	57                   	push   di
    3cf2:	9a 9b 3b 0b 3d       	call   0x3d0b:0x3b9b
    3cf7:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    3cfa:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    3cfd:	bf 0c 38             	mov    di,0x380c
    3d00:	0e                   	push   cs
    3d01:	57                   	push   di
    3d02:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d06:	06                   	push   es
    3d07:	57                   	push   di
    3d08:	9a 9b 3b 21 3d       	call   0x3d21:0x3b9b
    3d0d:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    3d10:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    3d13:	bf 17 38             	mov    di,0x3817
    3d16:	0e                   	push   cs
    3d17:	57                   	push   di
    3d18:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d1c:	06                   	push   es
    3d1d:	57                   	push   di
    3d1e:	9a 9b 3b 39 3d       	call   0x3d39:0x3b9b
    3d23:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    3d27:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    3d2b:	bf 21 38             	mov    di,0x3821
    3d2e:	0e                   	push   cs
    3d2f:	57                   	push   di
    3d30:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d34:	06                   	push   es
    3d35:	57                   	push   di
    3d36:	9a 9b 3b 51 3d       	call   0x3d51:0x3b9b
    3d3b:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    3d3f:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    3d43:	bf 2b 38             	mov    di,0x382b
    3d46:	0e                   	push   cs
    3d47:	57                   	push   di
    3d48:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d4c:	06                   	push   es
    3d4d:	57                   	push   di
    3d4e:	9a 9b 3b 69 3d       	call   0x3d69:0x3b9b
    3d53:	89 86 02 ff          	mov    WORD PTR [bp-0xfe],ax
    3d57:	89 96 04 ff          	mov    WORD PTR [bp-0xfc],dx
    3d5b:	bf 35 38             	mov    di,0x3835
    3d5e:	0e                   	push   cs
    3d5f:	57                   	push   di
    3d60:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d64:	06                   	push   es
    3d65:	57                   	push   di
    3d66:	9a 9b 3b 81 3d       	call   0x3d81:0x3b9b
    3d6b:	89 86 0e ff          	mov    WORD PTR [bp-0xf2],ax
    3d6f:	89 96 10 ff          	mov    WORD PTR [bp-0xf0],dx
    3d73:	bf 3f 38             	mov    di,0x383f
    3d76:	0e                   	push   cs
    3d77:	57                   	push   di
    3d78:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d7c:	06                   	push   es
    3d7d:	57                   	push   di
    3d7e:	9a 9b 3b 99 3d       	call   0x3d99:0x3b9b
    3d83:	89 86 1a ff          	mov    WORD PTR [bp-0xe6],ax
    3d87:	89 96 1c ff          	mov    WORD PTR [bp-0xe4],dx
    3d8b:	bf 49 38             	mov    di,0x3849
    3d8e:	0e                   	push   cs
    3d8f:	57                   	push   di
    3d90:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3d94:	06                   	push   es
    3d95:	57                   	push   di
    3d96:	9a 9b 3b b1 3d       	call   0x3db1:0x3b9b
    3d9b:	89 86 26 ff          	mov    WORD PTR [bp-0xda],ax
    3d9f:	89 96 28 ff          	mov    WORD PTR [bp-0xd8],dx
    3da3:	bf 53 38             	mov    di,0x3853
    3da6:	0e                   	push   cs
    3da7:	57                   	push   di
    3da8:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3dac:	06                   	push   es
    3dad:	57                   	push   di
    3dae:	9a 9b 3b c9 3d       	call   0x3dc9:0x3b9b
    3db3:	89 86 32 ff          	mov    WORD PTR [bp-0xce],ax
    3db7:	89 96 34 ff          	mov    WORD PTR [bp-0xcc],dx
    3dbb:	bf 5d 38             	mov    di,0x385d
    3dbe:	0e                   	push   cs
    3dbf:	57                   	push   di
    3dc0:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3dc4:	06                   	push   es
    3dc5:	57                   	push   di
    3dc6:	9a 9b 3b e1 3d       	call   0x3de1:0x3b9b
    3dcb:	89 86 3e ff          	mov    WORD PTR [bp-0xc2],ax
    3dcf:	89 96 40 ff          	mov    WORD PTR [bp-0xc0],dx
    3dd3:	bf 67 38             	mov    di,0x3867
    3dd6:	0e                   	push   cs
    3dd7:	57                   	push   di
    3dd8:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3ddc:	06                   	push   es
    3ddd:	57                   	push   di
    3dde:	9a 9b 3b f9 3d       	call   0x3df9:0x3b9b
    3de3:	89 86 4a ff          	mov    WORD PTR [bp-0xb6],ax
    3de7:	89 96 4c ff          	mov    WORD PTR [bp-0xb4],dx
    3deb:	bf 71 38             	mov    di,0x3871
    3dee:	0e                   	push   cs
    3def:	57                   	push   di
    3df0:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3df4:	06                   	push   es
    3df5:	57                   	push   di
    3df6:	9a 9b 3b 11 3e       	call   0x3e11:0x3b9b
    3dfb:	89 86 56 ff          	mov    WORD PTR [bp-0xaa],ax
    3dff:	89 96 58 ff          	mov    WORD PTR [bp-0xa8],dx
    3e03:	bf 7c 38             	mov    di,0x387c
    3e06:	0e                   	push   cs
    3e07:	57                   	push   di
    3e08:	c4 be d8 fe          	les    di,DWORD PTR [bp-0x128]
    3e0c:	06                   	push   es
    3e0d:	57                   	push   di
    3e0e:	9a 9b 3b 83 41       	call   0x4183:0x3b9b
    3e13:	89 86 62 ff          	mov    WORD PTR [bp-0x9e],ax
    3e17:	89 96 64 ff          	mov    WORD PTR [bp-0x9c],dx
    3e1b:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    3e1e:	2d 01 00             	sub    ax,0x1
    3e21:	71 05                	jno    0x3e28
    3e23:	9a 3e 04 60 3e       	call   0x3e60:0x43e
    3e28:	99                   	cwd
    3e29:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    3e2d:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    3e31:	b8 01 00             	mov    ax,0x1
    3e34:	31 d2                	xor    dx,dx
    3e36:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    3e3a:	7f 60                	jg     0x3e9c
    3e3c:	7c 06                	jl     0x3e44
    3e3e:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    3e42:	77 58                	ja     0x3e9c
    3e44:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3e47:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3e4a:	eb 08                	jmp    0x3e54
    3e4c:	83 46 e8 01          	add    WORD PTR [bp-0x18],0x1
    3e50:	83 56 ea 00          	adc    WORD PTR [bp-0x16],0x0
    3e54:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3e57:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    3e5a:	bf 87 38             	mov    di,0x3887
    3e5d:	9a 16 04 d7 3e       	call   0x3ed7:0x416
    3e62:	6b f8 0c             	imul   di,ax,0xc
    3e65:	8d bb 62 ff          	lea    di,[bp+di-0x9e]
    3e69:	16                   	push   ss
    3e6a:	07                   	pop    es
    3e6b:	89 be d0 fe          	mov    WORD PTR [bp-0x130],di
    3e6f:	8c 86 d2 fe          	mov    WORD PTR [bp-0x12e],es
    3e73:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e76:	06                   	push   es
    3e77:	57                   	push   di
    3e78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e7b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e7f:	c4 be d0 fe          	les    di,DWORD PTR [bp-0x130]
    3e83:	9b 26 dd 5d 04       	fstp   QWORD PTR es:[di+0x4]
    3e88:	90                   	nop
    3e89:	9b                   	fwait
    3e8a:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3e8d:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    3e90:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    3e94:	75 b6                	jne    0x3e4c
    3e96:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    3e9a:	75 b0                	jne    0x3e4c
    3e9c:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    3e9f:	99                   	cwd
    3ea0:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    3ea4:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    3ea8:	b8 01 00             	mov    ax,0x1
    3eab:	31 d2                	xor    dx,dx
    3ead:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    3eb1:	7f 60                	jg     0x3f13
    3eb3:	7c 06                	jl     0x3ebb
    3eb5:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    3eb9:	77 58                	ja     0x3f13
    3ebb:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3ebe:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3ec1:	eb 08                	jmp    0x3ecb
    3ec3:	83 46 e8 01          	add    WORD PTR [bp-0x18],0x1
    3ec7:	83 56 ea 00          	adc    WORD PTR [bp-0x16],0x0
    3ecb:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3ece:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    3ed1:	bf 8f 38             	mov    di,0x388f
    3ed4:	9a 16 04 47 3f       	call   0x3f47:0x416
    3ed9:	6b f8 0c             	imul   di,ax,0xc
    3edc:	8d bb de fe          	lea    di,[bp+di-0x122]
    3ee0:	16                   	push   ss
    3ee1:	07                   	pop    es
    3ee2:	89 be d0 fe          	mov    WORD PTR [bp-0x130],di
    3ee6:	8c 86 d2 fe          	mov    WORD PTR [bp-0x12e],es
    3eea:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3eed:	06                   	push   es
    3eee:	57                   	push   di
    3eef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ef2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ef6:	c4 be d0 fe          	les    di,DWORD PTR [bp-0x130]
    3efa:	9b 26 dd 5d 04       	fstp   QWORD PTR es:[di+0x4]
    3eff:	90                   	nop
    3f00:	9b                   	fwait
    3f01:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3f04:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    3f07:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    3f0b:	75 b6                	jne    0x3ec3
    3f0d:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    3f11:	75 b0                	jne    0x3ec3
    3f13:	9b dd 86 72 ff       	fld    QWORD PTR [bp-0x8e]
    3f18:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    3f1e:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    3f23:	90                   	nop
    3f24:	9b                   	fwait
    3f25:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    3f29:	9e                   	sahf
    3f2a:	77 10                	ja     0x3f3c
    3f2c:	c4 be 6e ff          	les    di,DWORD PTR [bp-0x92]
    3f30:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3f36:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    3f3c:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    3f3f:	2d 01 00             	sub    ax,0x1
    3f42:	71 05                	jno    0x3f49
    3f44:	9a 3e 04 87 3f       	call   0x3f87:0x43e
    3f49:	99                   	cwd
    3f4a:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    3f4e:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    3f52:	b8 02 00             	mov    ax,0x2
    3f55:	31 d2                	xor    dx,dx
    3f57:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    3f5b:	7e 03                	jle    0x3f60
    3f5d:	e9 c2 00             	jmp    0x4022
    3f60:	7c 09                	jl     0x3f6b
    3f62:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    3f66:	76 03                	jbe    0x3f6b
    3f68:	e9 b7 00             	jmp    0x4022
    3f6b:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3f6e:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3f71:	eb 08                	jmp    0x3f7b
    3f73:	83 46 e8 01          	add    WORD PTR [bp-0x18],0x1
    3f77:	83 56 ea 00          	adc    WORD PTR [bp-0x16],0x0
    3f7b:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3f7e:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    3f81:	bf 87 38             	mov    di,0x3887
    3f84:	9a 16 04 b0 3f       	call   0x3fb0:0x416
    3f89:	6b f8 0c             	imul   di,ax,0xc
    3f8c:	8d bb 62 ff          	lea    di,[bp+di-0x9e]
    3f90:	16                   	push   ss
    3f91:	07                   	pop    es
    3f92:	89 be d0 fe          	mov    WORD PTR [bp-0x130],di
    3f96:	8c 86 d2 fe          	mov    WORD PTR [bp-0x12e],es
    3f9a:	9b 26 dd 45 04       	fld    QWORD PTR es:[di+0x4]
    3f9f:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3fa2:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    3fa5:	2d 01 00             	sub    ax,0x1
    3fa8:	83 da 00             	sbb    dx,0x0
    3fab:	71 05                	jno    0x3fb2
    3fad:	9a 3e 04 b8 3f       	call   0x3fb8:0x43e
    3fb2:	bf 87 38             	mov    di,0x3887
    3fb5:	9a 16 04 8c 40       	call   0x408c:0x416
    3fba:	6b f8 0c             	imul   di,ax,0xc
    3fbd:	9b dc 9b 66 ff       	fcomp  QWORD PTR [bp+di-0x9a]
    3fc2:	9b dd be cc fe       	fstsw  WORD PTR [bp-0x134]
    3fc7:	90                   	nop
    3fc8:	9b                   	fwait
    3fc9:	8a a6 cd fe          	mov    ah,BYTE PTR [bp-0x133]
    3fcd:	9e                   	sahf
    3fce:	b0 00                	mov    al,0x0
    3fd0:	77 01                	ja     0x3fd3
    3fd2:	40                   	inc    ax
    3fd3:	8a d0                	mov    dl,al
    3fd5:	c4 be d0 fe          	les    di,DWORD PTR [bp-0x130]
    3fd9:	9b 26 dd 45 04       	fld    QWORD PTR es:[di+0x4]
    3fde:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    3fe4:	9b dd be ce fe       	fstsw  WORD PTR [bp-0x132]
    3fe9:	90                   	nop
    3fea:	9b                   	fwait
    3feb:	8a a6 cf fe          	mov    ah,BYTE PTR [bp-0x131]
    3fef:	9e                   	sahf
    3ff0:	b0 00                	mov    al,0x0
    3ff2:	77 01                	ja     0x3ff5
    3ff4:	40                   	inc    ax
    3ff5:	0a c2                	or     al,dl
    3ff7:	08 c0                	or     al,al
    3ff9:	74 0f                	je     0x400a
    3ffb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ffe:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4004:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    400a:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    400d:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4010:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    4014:	74 03                	je     0x4019
    4016:	e9 5a ff             	jmp    0x3f73
    4019:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    401d:	74 03                	je     0x4022
    401f:	e9 51 ff             	jmp    0x3f73
    4022:	9b dd 86 ee fe       	fld    QWORD PTR [bp-0x112]
    4027:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    402d:	9b dd be d6 fe       	fstsw  WORD PTR [bp-0x12a]
    4032:	90                   	nop
    4033:	9b                   	fwait
    4034:	8a a6 d7 fe          	mov    ah,BYTE PTR [bp-0x129]
    4038:	9e                   	sahf
    4039:	73 10                	jae    0x404b
    403b:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    403f:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4045:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    404b:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    404e:	99                   	cwd
    404f:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    4053:	89 96 d6 fe          	mov    WORD PTR [bp-0x12a],dx
    4057:	b8 02 00             	mov    ax,0x2
    405a:	31 d2                	xor    dx,dx
    405c:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    4060:	7e 03                	jle    0x4065
    4062:	e9 c2 00             	jmp    0x4127
    4065:	7c 09                	jl     0x4070
    4067:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    406b:	76 03                	jbe    0x4070
    406d:	e9 b7 00             	jmp    0x4127
    4070:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    4073:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    4076:	eb 08                	jmp    0x4080
    4078:	83 46 e8 01          	add    WORD PTR [bp-0x18],0x1
    407c:	83 56 ea 00          	adc    WORD PTR [bp-0x16],0x0
    4080:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4083:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4086:	bf 8f 38             	mov    di,0x388f
    4089:	9a 16 04 b5 40       	call   0x40b5:0x416
    408e:	6b f8 0c             	imul   di,ax,0xc
    4091:	8d bb de fe          	lea    di,[bp+di-0x122]
    4095:	16                   	push   ss
    4096:	07                   	pop    es
    4097:	89 be d0 fe          	mov    WORD PTR [bp-0x130],di
    409b:	8c 86 d2 fe          	mov    WORD PTR [bp-0x12e],es
    409f:	9b 26 dd 45 04       	fld    QWORD PTR es:[di+0x4]
    40a4:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    40a7:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    40aa:	2d 01 00             	sub    ax,0x1
    40ad:	83 da 00             	sbb    dx,0x0
    40b0:	71 05                	jno    0x40b7
    40b2:	9a 3e 04 bd 40       	call   0x40bd:0x43e
    40b7:	bf 8f 38             	mov    di,0x388f
    40ba:	9a 16 04 62 41       	call   0x4162:0x416
    40bf:	6b f8 0c             	imul   di,ax,0xc
    40c2:	9b dc 9b e2 fe       	fcomp  QWORD PTR [bp+di-0x11e]
    40c7:	9b dd be cc fe       	fstsw  WORD PTR [bp-0x134]
    40cc:	90                   	nop
    40cd:	9b                   	fwait
    40ce:	8a a6 cd fe          	mov    ah,BYTE PTR [bp-0x133]
    40d2:	9e                   	sahf
    40d3:	b0 00                	mov    al,0x0
    40d5:	73 01                	jae    0x40d8
    40d7:	40                   	inc    ax
    40d8:	8a d0                	mov    dl,al
    40da:	c4 be d0 fe          	les    di,DWORD PTR [bp-0x130]
    40de:	9b 26 dd 45 04       	fld    QWORD PTR es:[di+0x4]
    40e3:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    40e9:	9b dd be ce fe       	fstsw  WORD PTR [bp-0x132]
    40ee:	90                   	nop
    40ef:	9b                   	fwait
    40f0:	8a a6 cf fe          	mov    ah,BYTE PTR [bp-0x131]
    40f4:	9e                   	sahf
    40f5:	b0 00                	mov    al,0x0
    40f7:	73 01                	jae    0x40fa
    40f9:	40                   	inc    ax
    40fa:	0a c2                	or     al,dl
    40fc:	08 c0                	or     al,al
    40fe:	74 0f                	je     0x410f
    4100:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4103:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4109:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    410f:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4112:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4115:	3b 96 d6 fe          	cmp    dx,WORD PTR [bp-0x12a]
    4119:	74 03                	je     0x411e
    411b:	e9 5a ff             	jmp    0x4078
    411e:	3b 86 d4 fe          	cmp    ax,WORD PTR [bp-0x12c]
    4122:	74 03                	je     0x4127
    4124:	e9 51 ff             	jmp    0x4078
    4127:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    412c:	7e 07                	jle    0x4135
    412e:	c7 46 f8 02 00       	mov    WORD PTR [bp-0x8],0x2
    4133:	eb 05                	jmp    0x413a
    4135:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    413a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    413d:	89 86 da fe          	mov    WORD PTR [bp-0x126],ax
    4141:	b8 01 00             	mov    ax,0x1
    4144:	3b 86 da fe          	cmp    ax,WORD PTR [bp-0x126]
    4148:	7e 03                	jle    0x414d
    414a:	e9 2d 02             	jmp    0x437a
    414d:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    4151:	eb 04                	jmp    0x4157
    4153:	ff 86 e0 fe          	inc    WORD PTR [bp-0x120]
    4157:	8b 86 e0 fe          	mov    ax,WORD PTR [bp-0x120]
    415b:	99                   	cwd
    415c:	bf 97 38             	mov    di,0x3897
    415f:	9a 16 04 03 43       	call   0x4303:0x416
    4164:	8b f8                	mov    di,ax
    4166:	c1 e7 02             	shl    di,0x2
    4169:	c4 bb de fe          	les    di,DWORD PTR [bp+di-0x122]
    416d:	89 be d6 fe          	mov    WORD PTR [bp-0x12a],di
    4171:	8c 86 d8 fe          	mov    WORD PTR [bp-0x128],es
    4175:	bf 9f 38             	mov    di,0x389f
    4178:	0e                   	push   cs
    4179:	57                   	push   di
    417a:	c4 be d6 fe          	les    di,DWORD PTR [bp-0x12a]
    417e:	06                   	push   es
    417f:	57                   	push   di
    4180:	9a 9b 3b d2 41       	call   0x41d2:0x3b9b
    4185:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4188:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    418b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    418e:	06                   	push   es
    418f:	57                   	push   di
    4190:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4193:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4197:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    419b:	90                   	nop
    419c:	9b 9b dd 46 ec       	fld    QWORD PTR [bp-0x14]
    41a1:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    41a7:	9b dd be d4 fe       	fstsw  WORD PTR [bp-0x12c]
    41ac:	90                   	nop
    41ad:	9b                   	fwait
    41ae:	8a a6 d5 fe          	mov    ah,BYTE PTR [bp-0x12b]
    41b2:	9e                   	sahf
    41b3:	77 0f                	ja     0x41c4
    41b5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    41b8:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    41be:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    41c4:	bf b0 38             	mov    di,0x38b0
    41c7:	0e                   	push   cs
    41c8:	57                   	push   di
    41c9:	c4 be d6 fe          	les    di,DWORD PTR [bp-0x12a]
    41cd:	06                   	push   es
    41ce:	57                   	push   di
    41cf:	9a 9b 3b 44 42       	call   0x4244:0x3b9b
    41d4:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    41d7:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    41da:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    41dd:	06                   	push   es
    41de:	57                   	push   di
    41df:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41e2:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    41e6:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    41e9:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    41ec:	8b 86 e0 fe          	mov    ax,WORD PTR [bp-0x120]
    41f0:	3d 01 00             	cmp    ax,0x1
    41f3:	75 1f                	jne    0x4214
    41f5:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    41f9:	7c 08                	jl     0x4203
    41fb:	7f 15                	jg     0x4212
    41fd:	83 7e e8 00          	cmp    WORD PTR [bp-0x18],0x0
    4201:	77 0f                	ja     0x4212
    4203:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4206:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    420c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4212:	eb 22                	jmp    0x4236
    4214:	3d 02 00             	cmp    ax,0x2
    4217:	75 1d                	jne    0x4236
    4219:	83 7e ea 00          	cmp    WORD PTR [bp-0x16],0x0
    421d:	7c 08                	jl     0x4227
    421f:	7f 15                	jg     0x4236
    4221:	83 7e e8 00          	cmp    WORD PTR [bp-0x18],0x0
    4225:	73 0f                	jae    0x4236
    4227:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    422a:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4230:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4236:	bf be 38             	mov    di,0x38be
    4239:	0e                   	push   cs
    423a:	57                   	push   di
    423b:	c4 be d6 fe          	les    di,DWORD PTR [bp-0x12a]
    423f:	06                   	push   es
    4240:	57                   	push   di
    4241:	9a 9b 3b 0c 45       	call   0x450c:0x3b9b
    4246:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4249:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    424c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    424f:	06                   	push   es
    4250:	57                   	push   di
    4251:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4254:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4258:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    425c:	90                   	nop
    425d:	9b                   	fwait
    425e:	31 c0                	xor    ax,ax
    4260:	89 86 de fe          	mov    WORD PTR [bp-0x122],ax
    4264:	8b 86 e0 fe          	mov    ax,WORD PTR [bp-0x120]
    4268:	3d 01 00             	cmp    ax,0x1
    426b:	75 15                	jne    0x4282
    426d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4270:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    4275:	06                   	push   es
    4276:	57                   	push   di
    4277:	9a 07 5c 94 42       	call   0x4294:0x5c07
    427c:	89 86 de fe          	mov    WORD PTR [bp-0x122],ax
    4280:	eb 18                	jmp    0x429a
    4282:	3d 02 00             	cmp    ax,0x2
    4285:	75 13                	jne    0x429a
    4287:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    428a:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    428f:	06                   	push   es
    4290:	57                   	push   di
    4291:	9a 07 5c 2f 47       	call   0x472f:0x5c07
    4296:	89 86 de fe          	mov    WORD PTR [bp-0x122],ax
    429a:	8b 86 de fe          	mov    ax,WORD PTR [bp-0x122]
    429e:	3d 00 00             	cmp    ax,0x0
    42a1:	74 05                	je     0x42a8
    42a3:	3d 02 00             	cmp    ax,0x2
    42a6:	75 4f                	jne    0x42f7
    42a8:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    42ac:	9b 2e d8 1e 9a 37    	fcomp  DWORD PTR cs:0x379a
    42b2:	9b dd be d2 fe       	fstsw  WORD PTR [bp-0x12e]
    42b7:	90                   	nop
    42b8:	9b                   	fwait
    42b9:	8a a6 d3 fe          	mov    ah,BYTE PTR [bp-0x12d]
    42bd:	9e                   	sahf
    42be:	b0 00                	mov    al,0x0
    42c0:	76 01                	jbe    0x42c3
    42c2:	40                   	inc    ax
    42c3:	8a d0                	mov    dl,al
    42c5:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    42c9:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    42cf:	9b dd be d4 fe       	fstsw  WORD PTR [bp-0x12c]
    42d4:	90                   	nop
    42d5:	9b                   	fwait
    42d6:	8a a6 d5 fe          	mov    ah,BYTE PTR [bp-0x12b]
    42da:	9e                   	sahf
    42db:	b0 00                	mov    al,0x0
    42dd:	73 01                	jae    0x42e0
    42df:	40                   	inc    ax
    42e0:	0a c2                	or     al,dl
    42e2:	08 c0                	or     al,al
    42e4:	74 0f                	je     0x42f5
    42e6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    42e9:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    42ef:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    42f5:	eb 76                	jmp    0x436d
    42f7:	3d 01 00             	cmp    ax,0x1
    42fa:	75 71                	jne    0x436d
    42fc:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    4300:	9a 41 10 90 43       	call   0x4390:0x1041
    4305:	9b dc 5e ec          	fcomp  QWORD PTR [bp-0x14]
    4309:	9b dd be d0 fe       	fstsw  WORD PTR [bp-0x130]
    430e:	90                   	nop
    430f:	9b                   	fwait
    4310:	8a a6 d1 fe          	mov    ah,BYTE PTR [bp-0x12f]
    4314:	9e                   	sahf
    4315:	b0 00                	mov    al,0x0
    4317:	74 01                	je     0x431a
    4319:	40                   	inc    ax
    431a:	8a c8                	mov    cl,al
    431c:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    4320:	9b 2e d8 1e cf 38    	fcomp  DWORD PTR cs:0x38cf
    4326:	9b dd be d2 fe       	fstsw  WORD PTR [bp-0x12e]
    432b:	90                   	nop
    432c:	9b                   	fwait
    432d:	8a a6 d3 fe          	mov    ah,BYTE PTR [bp-0x12d]
    4331:	9e                   	sahf
    4332:	b0 00                	mov    al,0x0
    4334:	76 01                	jbe    0x4337
    4336:	40                   	inc    ax
    4337:	8a d0                	mov    dl,al
    4339:	9b dd 46 ec          	fld    QWORD PTR [bp-0x14]
    433d:	9b 2e d8 1e 4a 37    	fcomp  DWORD PTR cs:0x374a
    4343:	9b dd be d4 fe       	fstsw  WORD PTR [bp-0x12c]
    4348:	90                   	nop
    4349:	9b                   	fwait
    434a:	8a a6 d5 fe          	mov    ah,BYTE PTR [bp-0x12b]
    434e:	9e                   	sahf
    434f:	b0 00                	mov    al,0x0
    4351:	77 01                	ja     0x4354
    4353:	40                   	inc    ax
    4354:	0a c2                	or     al,dl
    4356:	0a c1                	or     al,cl
    4358:	08 c0                	or     al,al
    435a:	74 0f                	je     0x436b
    435c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    435f:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4365:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    436b:	eb 00                	jmp    0x436d
    436d:	8b 86 e0 fe          	mov    ax,WORD PTR [bp-0x120]
    4371:	3b 86 da fe          	cmp    ax,WORD PTR [bp-0x126]
    4375:	74 03                	je     0x437a
    4377:	e9 d9 fd             	jmp    0x4153
    437a:	c6 46 fe 00          	mov    BYTE PTR [bp-0x2],0x0
    437e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4381:	06                   	push   es
    4382:	57                   	push   di
    4383:	9a 7d 52 da 43       	call   0x43da:0x527d
    4388:	2d 01 00             	sub    ax,0x1
    438b:	71 05                	jno    0x4392
    438d:	9a 3e 04 cf 43       	call   0x43cf:0x43e
    4392:	99                   	cwd
    4393:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    4397:	89 96 da fe          	mov    WORD PTR [bp-0x126],dx
    439b:	31 c0                	xor    ax,ax
    439d:	31 d2                	xor    dx,dx
    439f:	3b 96 da fe          	cmp    dx,WORD PTR [bp-0x126]
    43a3:	7e 03                	jle    0x43a8
    43a5:	e9 5e 03             	jmp    0x4706
    43a8:	7c 09                	jl     0x43b3
    43aa:	3b 86 d8 fe          	cmp    ax,WORD PTR [bp-0x128]
    43ae:	76 03                	jbe    0x43b3
    43b0:	e9 53 03             	jmp    0x4706
    43b3:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    43b6:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    43b9:	eb 08                	jmp    0x43c3
    43bb:	83 46 e8 01          	add    WORD PTR [bp-0x18],0x1
    43bf:	83 56 ea 00          	adc    WORD PTR [bp-0x16],0x0
    43c3:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    43c6:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    43c9:	bf aa 37             	mov    di,0x37aa
    43cc:	9a 16 04 e9 43       	call   0x43e9:0x416
    43d1:	50                   	push   ax
    43d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43d5:	06                   	push   es
    43d6:	57                   	push   di
    43d7:	9a 46 52 09 44       	call   0x4409:0x5246
    43dc:	52                   	push   dx
    43dd:	50                   	push   ax
    43de:	bf 99 03             	mov    di,0x399
    43e1:	b8 11 44             	mov    ax,0x4411
    43e4:	50                   	push   ax
    43e5:	57                   	push   di
    43e6:	9a 55 22 fe 43       	call   0x43fe:0x2255
    43eb:	08 c0                	or     al,al
    43ed:	75 03                	jne    0x43f2
    43ef:	e9 fc 02             	jmp    0x46ee
    43f2:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    43f5:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    43f8:	bf aa 37             	mov    di,0x37aa
    43fb:	9a 16 04 18 44       	call   0x4418:0x416
    4400:	50                   	push   ax
    4401:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4404:	06                   	push   es
    4405:	57                   	push   di
    4406:	9a 46 52 3f 44       	call   0x443f:0x5246
    440b:	52                   	push   dx
    440c:	50                   	push   ax
    440d:	bf 99 03             	mov    di,0x399
    4410:	b8 71 46             	mov    ax,0x4671
    4413:	50                   	push   ax
    4414:	57                   	push   di
    4415:	9a 73 22 34 44       	call   0x4434:0x2273
    441a:	89 c7                	mov    di,ax
    441c:	8e c2                	mov    es,dx
    441e:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4423:	75 03                	jne    0x4428
    4425:	e9 c6 02             	jmp    0x46ee
    4428:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    442b:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    442e:	bf aa 37             	mov    di,0x37aa
    4431:	9a 16 04 4e 44       	call   0x444e:0x416
    4436:	50                   	push   ax
    4437:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    443a:	06                   	push   es
    443b:	57                   	push   di
    443c:	9a 46 52 68 44       	call   0x4468:0x5246
    4441:	52                   	push   dx
    4442:	50                   	push   ax
    4443:	bf a2 0b             	mov    di,0xba2
    4446:	b8 70 44             	mov    ax,0x4470
    4449:	50                   	push   ax
    444a:	57                   	push   di
    444b:	9a 55 22 5d 44       	call   0x445d:0x2255
    4450:	50                   	push   ax
    4451:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4454:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4457:	bf aa 37             	mov    di,0x37aa
    445a:	9a 16 04 77 44       	call   0x4477:0x416
    445f:	50                   	push   ax
    4460:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4463:	06                   	push   es
    4464:	57                   	push   di
    4465:	9a 46 52 9a 44       	call   0x449a:0x5246
    446a:	52                   	push   dx
    446b:	50                   	push   ax
    446c:	bf 22 00             	mov    di,0x22
    446f:	b8 a2 44             	mov    ax,0x44a2
    4472:	50                   	push   ax
    4473:	57                   	push   di
    4474:	9a 55 22 8f 44       	call   0x448f:0x2255
    4479:	5a                   	pop    dx
    447a:	0a c2                	or     al,dl
    447c:	08 c0                	or     al,al
    447e:	75 03                	jne    0x4483
    4480:	e9 6b 02             	jmp    0x46ee
    4483:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4486:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4489:	bf aa 37             	mov    di,0x37aa
    448c:	9a 16 04 a9 44       	call   0x44a9:0x416
    4491:	50                   	push   ax
    4492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4495:	06                   	push   es
    4496:	57                   	push   di
    4497:	9a 46 52 c6 44       	call   0x44c6:0x5246
    449c:	52                   	push   dx
    449d:	50                   	push   ax
    449e:	bf 22 00             	mov    di,0x22
    44a1:	b8 ce 44             	mov    ax,0x44ce
    44a4:	50                   	push   ax
    44a5:	57                   	push   di
    44a6:	9a 55 22 bb 44       	call   0x44bb:0x2255
    44ab:	08 c0                	or     al,al
    44ad:	74 65                	je     0x4514
    44af:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    44b2:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    44b5:	bf aa 37             	mov    di,0x37aa
    44b8:	9a 16 04 d5 44       	call   0x44d5:0x416
    44bd:	50                   	push   ax
    44be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c1:	06                   	push   es
    44c2:	57                   	push   di
    44c3:	9a 46 52 2b 45       	call   0x452b:0x5246
    44c8:	52                   	push   dx
    44c9:	50                   	push   ax
    44ca:	bf 22 00             	mov    di,0x22
    44cd:	b8 f2 44             	mov    ax,0x44f2
    44d0:	50                   	push   ax
    44d1:	57                   	push   di
    44d2:	9a 73 22 20 45       	call   0x4520:0x2273
    44d7:	89 c7                	mov    di,ax
    44d9:	8e c2                	mov    es,dx
    44db:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    44df:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    44e3:	8d be d4 fd          	lea    di,[bp-0x22c]
    44e7:	16                   	push   ss
    44e8:	57                   	push   di
    44e9:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    44ed:	06                   	push   es
    44ee:	57                   	push   di
    44ef:	9a 9f 1a fd 44       	call   0x44fd:0x1a9f
    44f4:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    44f8:	06                   	push   es
    44f9:	57                   	push   di
    44fa:	9a 5f 1a 33 45       	call   0x4533:0x1a5f
    44ff:	89 c7                	mov    di,ax
    4501:	8e c2                	mov    es,dx
    4503:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    4507:	06                   	push   es
    4508:	57                   	push   di
    4509:	9a 9b 3b 9d 45       	call   0x459d:0x3b9b
    450e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4511:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    4514:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4517:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    451a:	bf aa 37             	mov    di,0x37aa
    451d:	9a 16 04 3a 45       	call   0x453a:0x416
    4522:	50                   	push   ax
    4523:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4526:	06                   	push   es
    4527:	57                   	push   di
    4528:	9a 46 52 57 45       	call   0x4557:0x5246
    452d:	52                   	push   dx
    452e:	50                   	push   ax
    452f:	bf a2 0b             	mov    di,0xba2
    4532:	b8 5f 45             	mov    ax,0x455f
    4535:	50                   	push   ax
    4536:	57                   	push   di
    4537:	9a 55 22 4c 45       	call   0x454c:0x2255
    453c:	08 c0                	or     al,al
    453e:	74 65                	je     0x45a5
    4540:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4543:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4546:	bf aa 37             	mov    di,0x37aa
    4549:	9a 16 04 66 45       	call   0x4566:0x416
    454e:	50                   	push   ax
    454f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4552:	06                   	push   es
    4553:	57                   	push   di
    4554:	9a 46 52 0f 46       	call   0x460f:0x5246
    4559:	52                   	push   dx
    455a:	50                   	push   ax
    455b:	bf a2 0b             	mov    di,0xba2
    455e:	b8 83 45             	mov    ax,0x4583
    4561:	50                   	push   ax
    4562:	57                   	push   di
    4563:	9a 73 22 04 46       	call   0x4604:0x2273
    4568:	89 c7                	mov    di,ax
    456a:	8e c2                	mov    es,dx
    456c:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    4570:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    4574:	8d be d4 fd          	lea    di,[bp-0x22c]
    4578:	16                   	push   ss
    4579:	57                   	push   di
    457a:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    457e:	06                   	push   es
    457f:	57                   	push   di
    4580:	9a 92 2a 8e 45       	call   0x458e:0x2a92
    4585:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4589:	06                   	push   es
    458a:	57                   	push   di
    458b:	9a 52 2a 17 46       	call   0x4617:0x2a52
    4590:	89 c7                	mov    di,ax
    4592:	8e c2                	mov    es,dx
    4594:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    4598:	06                   	push   es
    4599:	57                   	push   di
    459a:	9a 9b 3b e7 4a       	call   0x4ae7:0x3b9b
    459f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    45a2:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    45a5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    45a8:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    45ad:	75 17                	jne    0x45c6
    45af:	26 83 7d 0c 01       	cmp    WORD PTR es:[di+0xc],0x1
    45b4:	75 10                	jne    0x45c6
    45b6:	c7 46 fa ff 00       	mov    WORD PTR [bp-0x6],0xff
    45bb:	c7 46 fc 00 00       	mov    WORD PTR [bp-0x4],0x0
    45c0:	c6 46 fe 01          	mov    BYTE PTR [bp-0x2],0x1
    45c4:	eb 0a                	jmp    0x45d0
    45c6:	c7 46 fa fa ff       	mov    WORD PTR [bp-0x6],0xfffa
    45cb:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
    45d0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    45d3:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    45d8:	75 11                	jne    0x45eb
    45da:	26 83 7d 0c 02       	cmp    WORD PTR es:[di+0xc],0x2
    45df:	75 0a                	jne    0x45eb
    45e1:	c7 46 fa 80 00       	mov    WORD PTR [bp-0x6],0x80
    45e6:	c7 46 fc 00 00       	mov    WORD PTR [bp-0x4],0x0
    45eb:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    45ee:	31 c0                	xor    ax,ax
    45f0:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    45f4:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    45f8:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    45fb:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    45fe:	bf aa 37             	mov    di,0x37aa
    4601:	9a 16 04 1e 46       	call   0x461e:0x416
    4606:	50                   	push   ax
    4607:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    460a:	06                   	push   es
    460b:	57                   	push   di
    460c:	9a 46 52 3b 46       	call   0x463b:0x5246
    4611:	52                   	push   dx
    4612:	50                   	push   ax
    4613:	bf 22 00             	mov    di,0x22
    4616:	b8 43 46             	mov    ax,0x4643
    4619:	50                   	push   ax
    461a:	57                   	push   di
    461b:	9a 55 22 30 46       	call   0x4630:0x2255
    4620:	08 c0                	or     al,al
    4622:	74 4f                	je     0x4673
    4624:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4627:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    462a:	bf aa 37             	mov    di,0x37aa
    462d:	9a 16 04 4a 46       	call   0x464a:0x416
    4632:	50                   	push   ax
    4633:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4636:	06                   	push   es
    4637:	57                   	push   di
    4638:	9a 46 52 8a 46       	call   0x468a:0x5246
    463d:	52                   	push   dx
    463e:	50                   	push   ax
    463f:	bf 22 00             	mov    di,0x22
    4642:	b8 92 46             	mov    ax,0x4692
    4645:	50                   	push   ax
    4646:	57                   	push   di
    4647:	9a 73 22 64 46       	call   0x4664:0x2273
    464c:	89 c7                	mov    di,ax
    464e:	8e c2                	mov    es,dx
    4650:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    4654:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    4658:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    465b:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    465e:	bf d3 38             	mov    di,0x38d3
    4661:	9a 16 04 7f 46       	call   0x467f:0x416
    4666:	52                   	push   dx
    4667:	50                   	push   ax
    4668:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    466c:	06                   	push   es
    466d:	57                   	push   di
    466e:	9a d5 1e ec 46       	call   0x46ec:0x1ed5
    4673:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    4676:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    4679:	bf aa 37             	mov    di,0x37aa
    467c:	9a 16 04 99 46       	call   0x4699:0x416
    4681:	50                   	push   ax
    4682:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4685:	06                   	push   es
    4686:	57                   	push   di
    4687:	9a 46 52 b6 46       	call   0x46b6:0x5246
    468c:	52                   	push   dx
    468d:	50                   	push   ax
    468e:	bf a2 0b             	mov    di,0xba2
    4691:	b8 be 46             	mov    ax,0x46be
    4694:	50                   	push   ax
    4695:	57                   	push   di
    4696:	9a 55 22 ab 46       	call   0x46ab:0x2255
    469b:	08 c0                	or     al,al
    469d:	74 4f                	je     0x46ee
    469f:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    46a2:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    46a5:	bf aa 37             	mov    di,0x37aa
    46a8:	9a 16 04 c5 46       	call   0x46c5:0x416
    46ad:	50                   	push   ax
    46ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46b1:	06                   	push   es
    46b2:	57                   	push   di
    46b3:	9a 46 52 ff ff       	call   0xffff:0x5246
    46b8:	52                   	push   dx
    46b9:	50                   	push   ax
    46ba:	bf a2 0b             	mov    di,0xba2
    46bd:	b8 79 4a             	mov    ax,0x4a79
    46c0:	50                   	push   ax
    46c1:	57                   	push   di
    46c2:	9a 73 22 df 46       	call   0x46df:0x2273
    46c7:	89 c7                	mov    di,ax
    46c9:	8e c2                	mov    es,dx
    46cb:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    46cf:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    46d3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    46d6:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    46d9:	bf d3 38             	mov    di,0x38d3
    46dc:	9a 16 04 5e 47       	call   0x475e:0x416
    46e1:	52                   	push   dx
    46e2:	50                   	push   ax
    46e3:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    46e7:	06                   	push   es
    46e8:	57                   	push   di
    46e9:	9a d5 1e 76 48       	call   0x4876:0x1ed5
    46ee:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    46f1:	8b 56 ea             	mov    dx,WORD PTR [bp-0x16]
    46f4:	3b 96 da fe          	cmp    dx,WORD PTR [bp-0x126]
    46f8:	74 03                	je     0x46fd
    46fa:	e9 be fc             	jmp    0x43bb
    46fd:	3b 86 d8 fe          	cmp    ax,WORD PTR [bp-0x128]
    4701:	74 03                	je     0x4706
    4703:	e9 b5 fc             	jmp    0x43bb
    4706:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4709:	26 80 bd 68 03 00    	cmp    BYTE PTR es:[di+0x368],0x0
    470f:	74 20                	je     0x4731
    4711:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    4715:	b0 00                	mov    al,0x0
    4717:	75 01                	jne    0x471a
    4719:	40                   	inc    ax
    471a:	26 88 85 69 03       	mov    BYTE PTR es:[di+0x369],al
    471f:	26 8a 85 69 03       	mov    al,BYTE PTR es:[di+0x369]
    4724:	50                   	push   ax
    4725:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
    472a:	06                   	push   es
    472b:	57                   	push   di
    472c:	9a 11 6e a7 49       	call   0x49a7:0x6e11
    4731:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    4735:	74 07                	je     0x473e
    4737:	9a fb 36 41 47       	call   0x4741:0x36fb
    473c:	eb 05                	jmp    0x4743
    473e:	9a 75 36 90 5c       	call   0x5c90:0x3675
    4743:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    4747:	b0 00                	mov    al,0x0
    4749:	75 01                	jne    0x474c
    474b:	40                   	inc    ax
    474c:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    474f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4752:	c9                   	leave
    4753:	ca 04 00             	retf   0x4
    4756:	55                   	push   bp
    4757:	89 e5                	mov    bp,sp
    4759:	31 c0                	xor    ax,ax
    475b:	9a 44 04 79 47       	call   0x4779:0x444
    4760:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4763:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
    4767:	75 04                	jne    0x476d
    4769:	26 c6 05 2c          	mov    BYTE PTR es:[di],0x2c
    476d:	c9                   	leave
    476e:	ca 0c 00             	retf   0xc
    4771:	55                   	push   bp
    4772:	89 e5                	mov    bp,sp
    4774:	31 c0                	xor    ax,ax
    4776:	9a 44 04 b8 47       	call   0x47b8:0x444
    477b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    477f:	b0 00                	mov    al,0x0
    4781:	75 01                	jne    0x4784
    4783:	40                   	inc    ax
    4784:	8a d0                	mov    dl,al
    4786:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4789:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    478d:	b0 00                	mov    al,0x0
    478f:	75 01                	jne    0x4792
    4791:	40                   	inc    ax
    4792:	22 c2                	and    al,dl
    4794:	08 c0                	or     al,al
    4796:	74 14                	je     0x47ac
    4798:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    479b:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    47a0:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    47a5:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    47aa:	74 00                	je     0x47ac
    47ac:	c9                   	leave
    47ad:	ca 0e 00             	retf   0xe
    47b0:	55                   	push   bp
    47b1:	89 e5                	mov    bp,sp
    47b3:	31 c0                	xor    ax,ax
    47b5:	9a 44 04 e6 47       	call   0x47e6:0x444
    47ba:	6a 01                	push   0x1
    47bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47bf:	26 c4 bd 14 03       	les    di,DWORD PTR es:[di+0x314]
    47c4:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    47c9:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    47ce:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    47d2:	06                   	push   es
    47d3:	57                   	push   di
    47d4:	9a b2 77 52 48       	call   0x4852:0x77b2
    47d9:	c9                   	leave
    47da:	ca 08 00             	retf   0x8
    47dd:	55                   	push   bp
    47de:	89 e5                	mov    bp,sp
    47e0:	b8 04 00             	mov    ax,0x4
    47e3:	9a 44 04 61 48       	call   0x4861:0x444
    47e8:	83 ec 04             	sub    sp,0x4
    47eb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    47ee:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    47f3:	b0 00                	mov    al,0x0
    47f5:	75 01                	jne    0x47f8
    47f7:	40                   	inc    ax
    47f8:	8a c8                	mov    cl,al
    47fa:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    4800:	b0 00                	mov    al,0x0
    4802:	77 01                	ja     0x4805
    4804:	40                   	inc    ax
    4805:	8a d0                	mov    dl,al
    4807:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    480d:	b0 00                	mov    al,0x0
    480f:	76 01                	jbe    0x4812
    4811:	40                   	inc    ax
    4812:	22 c2                	and    al,dl
    4814:	0a c1                	or     al,cl
    4816:	08 c0                	or     al,al
    4818:	74 3a                	je     0x4854
    481a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    481e:	31 c0                	xor    ax,ax
    4820:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    4824:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    4828:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    482c:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    4830:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4833:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    4837:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    483a:	06                   	push   es
    483b:	57                   	push   di
    483c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    483f:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    4843:	6a 02                	push   0x2
    4845:	6a 00                	push   0x0
    4847:	6a 00                	push   0x0
    4849:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    484d:	06                   	push   es
    484e:	57                   	push   di
    484f:	9a b2 77 b8 48       	call   0x48b8:0x77b2
    4854:	c9                   	leave
    4855:	ca 0c 00             	retf   0xc
    4858:	55                   	push   bp
    4859:	89 e5                	mov    bp,sp
    485b:	b8 04 00             	mov    ax,0x4
    485e:	9a 44 04 7d 48       	call   0x487d:0x444
    4863:	83 ec 04             	sub    sp,0x4
    4866:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    486a:	75 76                	jne    0x48e2
    486c:	ff 76 14             	push   WORD PTR [bp+0x14]
    486f:	ff 76 12             	push   WORD PTR [bp+0x12]
    4872:	bf c1 05             	mov    di,0x5c1
    4875:	b8 99 48             	mov    ax,0x4899
    4878:	50                   	push   ax
    4879:	57                   	push   di
    487a:	9a 55 22 a0 48       	call   0x48a0:0x2255
    487f:	08 c0                	or     al,al
    4881:	74 5f                	je     0x48e2
    4883:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4887:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    488a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    488d:	6a 08                	push   0x8
    488f:	ff 76 14             	push   WORD PTR [bp+0x14]
    4892:	ff 76 12             	push   WORD PTR [bp+0x12]
    4895:	bf c1 05             	mov    di,0x5c1
    4898:	b8 04 49             	mov    ax,0x4904
    489b:	50                   	push   ax
    489c:	57                   	push   di
    489d:	9a 73 22 ef 48       	call   0x48ef:0x2273
    48a2:	89 c7                	mov    di,ax
    48a4:	8e c2                	mov    es,dx
    48a6:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    48ab:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    48b0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    48b3:	06                   	push   es
    48b4:	57                   	push   di
    48b5:	9a b2 77 c2 48       	call   0x48c2:0x77b2
    48ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    48bd:	06                   	push   es
    48be:	57                   	push   di
    48bf:	9a 03 73 49 49       	call   0x4949:0x7303
    48c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48c7:	06                   	push   es
    48c8:	57                   	push   di
    48c9:	b8 dd 47             	mov    ax,0x47dd
    48cc:	ba 83 4d             	mov    dx,0x4d83
    48cf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    48d2:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    48d6:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    48da:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    48de:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    48e2:	c9                   	leave
    48e3:	ca 10 00             	retf   0x10
    48e6:	55                   	push   bp
    48e7:	89 e5                	mov    bp,sp
    48e9:	b8 04 00             	mov    ax,0x4
    48ec:	9a 44 04 0b 49       	call   0x490b:0x444
    48f1:	83 ec 04             	sub    sp,0x4
    48f4:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    48f8:	75 51                	jne    0x494b
    48fa:	ff 76 14             	push   WORD PTR [bp+0x14]
    48fd:	ff 76 12             	push   WORD PTR [bp+0x12]
    4900:	bf c1 05             	mov    di,0x5c1
    4903:	b8 1b 49             	mov    ax,0x491b
    4906:	50                   	push   ax
    4907:	57                   	push   di
    4908:	9a 55 22 22 49       	call   0x4922:0x2255
    490d:	08 c0                	or     al,al
    490f:	74 3a                	je     0x494b
    4911:	ff 76 14             	push   WORD PTR [bp+0x14]
    4914:	ff 76 12             	push   WORD PTR [bp+0x12]
    4917:	bf c1 05             	mov    di,0x5c1
    491a:	b8 f2 49             	mov    ax,0x49f2
    491d:	50                   	push   ax
    491e:	57                   	push   di
    491f:	9a 73 22 5a 49       	call   0x495a:0x2273
    4924:	89 c7                	mov    di,ax
    4926:	8e c2                	mov    es,dx
    4928:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    492d:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    4932:	74 17                	je     0x494b
    4934:	6a 08                	push   0x8
    4936:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    493b:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    4940:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4944:	06                   	push   es
    4945:	57                   	push   di
    4946:	9a b2 77 af 5c       	call   0x5caf:0x77b2
    494b:	c9                   	leave
    494c:	ca 10 00             	retf   0x10
    494f:	01 09                	add    WORD PTR [bx+di],cx
    4951:	55                   	push   bp
    4952:	89 e5                	mov    bp,sp
    4954:	b8 04 04             	mov    ax,0x404
    4957:	9a 44 04 77 49       	call   0x4977:0x444
    495c:	81 ec 04 04          	sub    sp,0x404
    4960:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4963:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    4967:	76 27                	jbe    0x4990
    4969:	8d be 00 fe          	lea    di,[bp-0x200]
    496d:	16                   	push   ss
    496e:	57                   	push   di
    496f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4972:	06                   	push   es
    4973:	57                   	push   di
    4974:	9a cd 17 81 49       	call   0x4981:0x17cd
    4979:	bf 4f 49             	mov    di,0x494f
    497c:	0e                   	push   cs
    497d:	57                   	push   di
    497e:	9a 4c 18 8e 49       	call   0x498e:0x184c
    4983:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4986:	06                   	push   es
    4987:	57                   	push   di
    4988:	ff 76 0c             	push   WORD PTR [bp+0xc]
    498b:	9a e7 17 ae 49       	call   0x49ae:0x17e7
    4990:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    4993:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4998:	75 03                	jne    0x499d
    499a:	e9 2a 03             	jmp    0x4cc7
    499d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    49a0:	ff 76 08             	push   WORD PTR [bp+0x8]
    49a3:	bf 0c 01             	mov    di,0x10c
    49a6:	b8 be 49             	mov    ax,0x49be
    49a9:	50                   	push   ax
    49aa:	57                   	push   di
    49ab:	9a 55 22 c5 49       	call   0x49c5:0x2255
    49b0:	08 c0                	or     al,al
    49b2:	74 52                	je     0x4a06
    49b4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    49b7:	ff 76 08             	push   WORD PTR [bp+0x8]
    49ba:	bf 0c 01             	mov    di,0x10c
    49bd:	b8 12 4b             	mov    ax,0x4b12
    49c0:	50                   	push   ax
    49c1:	57                   	push   di
    49c2:	9a 73 22 e1 49       	call   0x49e1:0x2273
    49c7:	89 c7                	mov    di,ax
    49c9:	8e c2                	mov    es,dx
    49cb:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    49cf:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    49d3:	8d be fc fc          	lea    di,[bp-0x304]
    49d7:	16                   	push   ss
    49d8:	57                   	push   di
    49d9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    49dc:	06                   	push   es
    49dd:	57                   	push   di
    49de:	9a cd 17 f7 49       	call   0x49f7:0x17cd
    49e3:	8d be fc fd          	lea    di,[bp-0x204]
    49e7:	16                   	push   ss
    49e8:	57                   	push   di
    49e9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    49ed:	06                   	push   es
    49ee:	57                   	push   di
    49ef:	9a 53 1d 5b 4a       	call   0x4a5b:0x1d53
    49f4:	9a 4c 18 04 4a       	call   0x4a04:0x184c
    49f9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    49fc:	06                   	push   es
    49fd:	57                   	push   di
    49fe:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4a01:	9a e7 17 17 4a       	call   0x4a17:0x17e7
    4a06:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a09:	ff 76 08             	push   WORD PTR [bp+0x8]
    4a0c:	bf ad 0d             	mov    di,0xdad
    4a0f:	b8 27 4a             	mov    ax,0x4a27
    4a12:	50                   	push   ax
    4a13:	57                   	push   di
    4a14:	9a 55 22 2e 4a       	call   0x4a2e:0x2255
    4a19:	08 c0                	or     al,al
    4a1b:	74 52                	je     0x4a6f
    4a1d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a20:	ff 76 08             	push   WORD PTR [bp+0x8]
    4a23:	bf ad 0d             	mov    di,0xdad
    4a26:	b8 d7 5d             	mov    ax,0x5dd7
    4a29:	50                   	push   ax
    4a2a:	57                   	push   di
    4a2b:	9a 73 22 4a 4a       	call   0x4a4a:0x2273
    4a30:	89 c7                	mov    di,ax
    4a32:	8e c2                	mov    es,dx
    4a34:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4a38:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4a3c:	8d be fc fc          	lea    di,[bp-0x304]
    4a40:	16                   	push   ss
    4a41:	57                   	push   di
    4a42:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4a45:	06                   	push   es
    4a46:	57                   	push   di
    4a47:	9a cd 17 60 4a       	call   0x4a60:0x17cd
    4a4c:	8d be fc fd          	lea    di,[bp-0x204]
    4a50:	16                   	push   ss
    4a51:	57                   	push   di
    4a52:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4a56:	06                   	push   es
    4a57:	57                   	push   di
    4a58:	9a 53 1d 5d 4b       	call   0x4b5d:0x1d53
    4a5d:	9a 4c 18 6d 4a       	call   0x4a6d:0x184c
    4a62:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4a65:	06                   	push   es
    4a66:	57                   	push   di
    4a67:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4a6a:	9a e7 17 80 4a       	call   0x4a80:0x17e7
    4a6f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a72:	ff 76 08             	push   WORD PTR [bp+0x8]
    4a75:	bf 22 00             	mov    di,0x22
    4a78:	b8 93 4a             	mov    ax,0x4a93
    4a7b:	50                   	push   ax
    4a7c:	57                   	push   di
    4a7d:	9a 55 22 9a 4a       	call   0x4a9a:0x2255
    4a82:	08 c0                	or     al,al
    4a84:	75 03                	jne    0x4a89
    4a86:	e9 7f 00             	jmp    0x4b08
    4a89:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a8c:	ff 76 08             	push   WORD PTR [bp+0x8]
    4a8f:	bf 22 00             	mov    di,0x22
    4a92:	b8 cd 4a             	mov    ax,0x4acd
    4a95:	50                   	push   ax
    4a96:	57                   	push   di
    4a97:	9a 73 22 b6 4a       	call   0x4ab6:0x2273
    4a9c:	89 c7                	mov    di,ax
    4a9e:	8e c2                	mov    es,dx
    4aa0:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4aa4:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4aa8:	8d be fc fb          	lea    di,[bp-0x404]
    4aac:	16                   	push   ss
    4aad:	57                   	push   di
    4aae:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4ab1:	06                   	push   es
    4ab2:	57                   	push   di
    4ab3:	9a cd 17 f9 4a       	call   0x4af9:0x17cd
    4ab8:	8d be fc fc          	lea    di,[bp-0x304]
    4abc:	16                   	push   ss
    4abd:	57                   	push   di
    4abe:	8d be fc fd          	lea    di,[bp-0x204]
    4ac2:	16                   	push   ss
    4ac3:	57                   	push   di
    4ac4:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4ac8:	06                   	push   es
    4ac9:	57                   	push   di
    4aca:	9a 9f 1a d8 4a       	call   0x4ad8:0x1a9f
    4acf:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4ad3:	06                   	push   es
    4ad4:	57                   	push   di
    4ad5:	9a 5f 1a ff ff       	call   0xffff:0x1a5f
    4ada:	89 c7                	mov    di,ax
    4adc:	8e c2                	mov    es,dx
    4ade:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    4ae2:	06                   	push   es
    4ae3:	57                   	push   di
    4ae4:	9a 9b 3b df 53       	call   0x53df:0x3b9b
    4ae9:	89 c7                	mov    di,ax
    4aeb:	8e c2                	mov    es,dx
    4aed:	06                   	push   es
    4aee:	57                   	push   di
    4aef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4af2:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    4af6:	9a 4c 18 06 4b       	call   0x4b06:0x184c
    4afb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4afe:	06                   	push   es
    4aff:	57                   	push   di
    4b00:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b03:	9a e7 17 19 4b       	call   0x4b19:0x17e7
    4b08:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b0b:	ff 76 08             	push   WORD PTR [bp+0x8]
    4b0e:	bf 90 0b             	mov    di,0xb90
    4b11:	b8 29 4b             	mov    ax,0x4b29
    4b14:	50                   	push   ax
    4b15:	57                   	push   di
    4b16:	9a 55 22 30 4b       	call   0x4b30:0x2255
    4b1b:	08 c0                	or     al,al
    4b1d:	74 52                	je     0x4b71
    4b1f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b22:	ff 76 08             	push   WORD PTR [bp+0x8]
    4b25:	bf 90 0b             	mov    di,0xb90
    4b28:	b8 7b 4b             	mov    ax,0x4b7b
    4b2b:	50                   	push   ax
    4b2c:	57                   	push   di
    4b2d:	9a 73 22 4c 4b       	call   0x4b4c:0x2273
    4b32:	89 c7                	mov    di,ax
    4b34:	8e c2                	mov    es,dx
    4b36:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4b3a:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4b3e:	8d be fc fc          	lea    di,[bp-0x304]
    4b42:	16                   	push   ss
    4b43:	57                   	push   di
    4b44:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4b47:	06                   	push   es
    4b48:	57                   	push   di
    4b49:	9a cd 17 62 4b       	call   0x4b62:0x17cd
    4b4e:	8d be fc fd          	lea    di,[bp-0x204]
    4b52:	16                   	push   ss
    4b53:	57                   	push   di
    4b54:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4b58:	06                   	push   es
    4b59:	57                   	push   di
    4b5a:	9a 53 1d c6 4b       	call   0x4bc6:0x1d53
    4b5f:	9a 4c 18 6f 4b       	call   0x4b6f:0x184c
    4b64:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4b67:	06                   	push   es
    4b68:	57                   	push   di
    4b69:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b6c:	9a e7 17 82 4b       	call   0x4b82:0x17e7
    4b71:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b74:	ff 76 08             	push   WORD PTR [bp+0x8]
    4b77:	bf 17 06             	mov    di,0x617
    4b7a:	b8 92 4b             	mov    ax,0x4b92
    4b7d:	50                   	push   ax
    4b7e:	57                   	push   di
    4b7f:	9a 55 22 99 4b       	call   0x4b99:0x2255
    4b84:	08 c0                	or     al,al
    4b86:	74 52                	je     0x4bda
    4b88:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b8b:	ff 76 08             	push   WORD PTR [bp+0x8]
    4b8e:	bf 17 06             	mov    di,0x617
    4b91:	b8 e4 4b             	mov    ax,0x4be4
    4b94:	50                   	push   ax
    4b95:	57                   	push   di
    4b96:	9a 73 22 b5 4b       	call   0x4bb5:0x2273
    4b9b:	89 c7                	mov    di,ax
    4b9d:	8e c2                	mov    es,dx
    4b9f:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4ba3:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4ba7:	8d be fc fc          	lea    di,[bp-0x304]
    4bab:	16                   	push   ss
    4bac:	57                   	push   di
    4bad:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4bb0:	06                   	push   es
    4bb1:	57                   	push   di
    4bb2:	9a cd 17 cb 4b       	call   0x4bcb:0x17cd
    4bb7:	8d be fc fd          	lea    di,[bp-0x204]
    4bbb:	16                   	push   ss
    4bbc:	57                   	push   di
    4bbd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4bc1:	06                   	push   es
    4bc2:	57                   	push   di
    4bc3:	9a 53 1d 2f 4c       	call   0x4c2f:0x1d53
    4bc8:	9a 4c 18 d8 4b       	call   0x4bd8:0x184c
    4bcd:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4bd0:	06                   	push   es
    4bd1:	57                   	push   di
    4bd2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bd5:	9a e7 17 eb 4b       	call   0x4beb:0x17e7
    4bda:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bdd:	ff 76 08             	push   WORD PTR [bp+0x8]
    4be0:	bf 14 1b             	mov    di,0x1b14
    4be3:	b8 fb 4b             	mov    ax,0x4bfb
    4be6:	50                   	push   ax
    4be7:	57                   	push   di
    4be8:	9a 55 22 02 4c       	call   0x4c02:0x2255
    4bed:	08 c0                	or     al,al
    4bef:	74 52                	je     0x4c43
    4bf1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bf4:	ff 76 08             	push   WORD PTR [bp+0x8]
    4bf7:	bf 14 1b             	mov    di,0x1b14
    4bfa:	b8 0d 4d             	mov    ax,0x4d0d
    4bfd:	50                   	push   ax
    4bfe:	57                   	push   di
    4bff:	9a 73 22 1e 4c       	call   0x4c1e:0x2273
    4c04:	89 c7                	mov    di,ax
    4c06:	8e c2                	mov    es,dx
    4c08:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4c0c:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4c10:	8d be fc fc          	lea    di,[bp-0x304]
    4c14:	16                   	push   ss
    4c15:	57                   	push   di
    4c16:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4c19:	06                   	push   es
    4c1a:	57                   	push   di
    4c1b:	9a cd 17 34 4c       	call   0x4c34:0x17cd
    4c20:	8d be fc fd          	lea    di,[bp-0x204]
    4c24:	16                   	push   ss
    4c25:	57                   	push   di
    4c26:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4c2a:	06                   	push   es
    4c2b:	57                   	push   di
    4c2c:	9a 53 1d 37 4d       	call   0x4d37:0x1d53
    4c31:	9a 4c 18 41 4c       	call   0x4c41:0x184c
    4c36:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4c39:	06                   	push   es
    4c3a:	57                   	push   di
    4c3b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4c3e:	9a e7 17 54 4c       	call   0x4c54:0x17e7
    4c43:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c46:	ff 76 08             	push   WORD PTR [bp+0x8]
    4c49:	bf eb 03             	mov    di,0x3eb
    4c4c:	b8 64 4c             	mov    ax,0x4c64
    4c4f:	50                   	push   ax
    4c50:	57                   	push   di
    4c51:	9a 55 22 6b 4c       	call   0x4c6b:0x2255
    4c56:	08 c0                	or     al,al
    4c58:	74 6d                	je     0x4cc7
    4c5a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c5d:	ff 76 08             	push   WORD PTR [bp+0x8]
    4c60:	bf eb 03             	mov    di,0x3eb
    4c63:	b8 88 4c             	mov    ax,0x4c88
    4c66:	50                   	push   ax
    4c67:	57                   	push   di
    4c68:	9a 73 22 9d 4c       	call   0x4c9d:0x2273
    4c6d:	89 c7                	mov    di,ax
    4c6f:	8e c2                	mov    es,dx
    4c71:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    4c75:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    4c79:	8d be fc fd          	lea    di,[bp-0x204]
    4c7d:	16                   	push   ss
    4c7e:	57                   	push   di
    4c7f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4c83:	06                   	push   es
    4c84:	57                   	push   di
    4c85:	9a 33 17 ff ff       	call   0xffff:0x1733
    4c8a:	52                   	push   dx
    4c8b:	50                   	push   ax
    4c8c:	9a a9 08 ff ff       	call   0xffff:0x8a9
    4c91:	8d be 00 ff          	lea    di,[bp-0x100]
    4c95:	16                   	push   ss
    4c96:	57                   	push   di
    4c97:	68 ff 00             	push   0xff
    4c9a:	9a e7 17 ad 4c       	call   0x4cad:0x17e7
    4c9f:	8d be fc fd          	lea    di,[bp-0x204]
    4ca3:	16                   	push   ss
    4ca4:	57                   	push   di
    4ca5:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4ca8:	06                   	push   es
    4ca9:	57                   	push   di
    4caa:	9a cd 17 b8 4c       	call   0x4cb8:0x17cd
    4caf:	8d be 00 ff          	lea    di,[bp-0x100]
    4cb3:	16                   	push   ss
    4cb4:	57                   	push   di
    4cb5:	9a 4c 18 c5 4c       	call   0x4cc5:0x184c
    4cba:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4cbd:	06                   	push   es
    4cbe:	57                   	push   di
    4cbf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4cc2:	9a e7 17 f2 4c       	call   0x4cf2:0x17e7
    4cc7:	c9                   	leave
    4cc8:	ca 0c 00             	retf   0xc
    4ccb:	01 09                	add    WORD PTR [bx+di],cx
    4ccd:	03 20                	add    sp,WORD PTR [bx+si]
    4ccf:	2f                   	das
    4cd0:	20 0d                	and    BYTE PTR [di],cl
    4cd2:	49                   	dec    cx
    4cd3:	46                   	inc    si
    4cd4:	41                   	inc    cx
    4cd5:	4e                   	dec    si
    4cd6:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
    4cd9:	61                   	popa
    4cda:	6e                   	outs   dx,BYTE PTR ds:[si]
    4cdb:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    4cde:	73 00                	jae    0x4ce0
    4ce0:	80 ff ff             	cmp    bh,0xff
    4ce3:	ff                   	(bad)
    4ce4:	7f 00                	jg     0x4ce6
    4ce6:	00 01                	add    BYTE PTR [bx+di],al
    4ce8:	20 55 89             	and    BYTE PTR [di-0x77],dl
    4ceb:	e5 b8                	in     ax,0xb8
    4ced:	0a 05                	or     al,BYTE PTR [di]
    4cef:	9a 44 04 1d 4d       	call   0x4d1d:0x444
    4cf4:	81 ec 0a 05          	sub    sp,0x50a
    4cf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cfb:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    4d00:	89 be f6 fe          	mov    WORD PTR [bp-0x10a],di
    4d04:	8c 86 f8 fe          	mov    WORD PTR [bp-0x108],es
    4d08:	06                   	push   es
    4d09:	57                   	push   di
    4d0a:	9a e3 49 6f 4f       	call   0x4f6f:0x49e3
    4d0f:	8d be f6 fd          	lea    di,[bp-0x20a]
    4d13:	16                   	push   ss
    4d14:	57                   	push   di
    4d15:	bf fa 1d             	mov    di,0x1dfa
    4d18:	1e                   	push   ds
    4d19:	57                   	push   di
    4d1a:	9a cd 17 27 4d       	call   0x4d27:0x17cd
    4d1f:	bf cb 4c             	mov    di,0x4ccb
    4d22:	0e                   	push   cs
    4d23:	57                   	push   di
    4d24:	9a 4c 18 3c 4d       	call   0x4d3c:0x184c
    4d29:	8d be f6 fc          	lea    di,[bp-0x30a]
    4d2d:	16                   	push   ss
    4d2e:	57                   	push   di
    4d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d32:	06                   	push   es
    4d33:	57                   	push   di
    4d34:	9a 53 1d 0b 53       	call   0x530b:0x1d53
    4d39:	9a 4c 18 4a 4d       	call   0x4d4a:0x184c
    4d3e:	8d be 00 ff          	lea    di,[bp-0x100]
    4d42:	16                   	push   ss
    4d43:	57                   	push   di
    4d44:	68 ff 00             	push   0xff
    4d47:	9a e7 17 0b 51       	call   0x510b:0x17e7
    4d4c:	8d be 00 ff          	lea    di,[bp-0x100]
    4d50:	16                   	push   ss
    4d51:	57                   	push   di
    4d52:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4d56:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4d5b:	06                   	push   es
    4d5c:	57                   	push   di
    4d5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d60:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4d64:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4d69:	8d be 00 ff          	lea    di,[bp-0x100]
    4d6d:	16                   	push   ss
    4d6e:	57                   	push   di
    4d6f:	68 ff 00             	push   0xff
    4d72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d75:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    4d7a:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    4d7f:	55                   	push   bp
    4d80:	9a 51 49 bc 4d       	call   0x4dbc:0x4951
    4d85:	8d be 00 ff          	lea    di,[bp-0x100]
    4d89:	16                   	push   ss
    4d8a:	57                   	push   di
    4d8b:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4d8f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4d94:	06                   	push   es
    4d95:	57                   	push   di
    4d96:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d99:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4d9d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4da2:	8d be 00 ff          	lea    di,[bp-0x100]
    4da6:	16                   	push   ss
    4da7:	57                   	push   di
    4da8:	68 ff 00             	push   0xff
    4dab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dae:	26 ff b5 b2 02       	push   WORD PTR es:[di+0x2b2]
    4db3:	26 ff b5 b0 02       	push   WORD PTR es:[di+0x2b0]
    4db8:	55                   	push   bp
    4db9:	9a 51 49 d8 4d       	call   0x4dd8:0x4951
    4dbe:	8d be 00 ff          	lea    di,[bp-0x100]
    4dc2:	16                   	push   ss
    4dc3:	57                   	push   di
    4dc4:	68 ff 00             	push   0xff
    4dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dca:	26 ff b5 ba 02       	push   WORD PTR es:[di+0x2ba]
    4dcf:	26 ff b5 b8 02       	push   WORD PTR es:[di+0x2b8]
    4dd4:	55                   	push   bp
    4dd5:	9a 51 49 11 4e       	call   0x4e11:0x4951
    4dda:	8d be 00 ff          	lea    di,[bp-0x100]
    4dde:	16                   	push   ss
    4ddf:	57                   	push   di
    4de0:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4de4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4de9:	06                   	push   es
    4dea:	57                   	push   di
    4deb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dee:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4df2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4df7:	8d be 00 ff          	lea    di,[bp-0x100]
    4dfb:	16                   	push   ss
    4dfc:	57                   	push   di
    4dfd:	68 ff 00             	push   0xff
    4e00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e03:	26 ff b5 6a 02       	push   WORD PTR es:[di+0x26a]
    4e08:	26 ff b5 68 02       	push   WORD PTR es:[di+0x268]
    4e0d:	55                   	push   bp
    4e0e:	9a 51 49 2d 4e       	call   0x4e2d:0x4951
    4e13:	8d be 00 ff          	lea    di,[bp-0x100]
    4e17:	16                   	push   ss
    4e18:	57                   	push   di
    4e19:	68 ff 00             	push   0xff
    4e1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e1f:	26 ff b5 6e 02       	push   WORD PTR es:[di+0x26e]
    4e24:	26 ff b5 6c 02       	push   WORD PTR es:[di+0x26c]
    4e29:	55                   	push   bp
    4e2a:	9a 51 49 6d 4e       	call   0x4e6d:0x4951
    4e2f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4e34:	76 18                	jbe    0x4e4e
    4e36:	8d be 00 ff          	lea    di,[bp-0x100]
    4e3a:	16                   	push   ss
    4e3b:	57                   	push   di
    4e3c:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4e40:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4e45:	06                   	push   es
    4e46:	57                   	push   di
    4e47:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e4a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4e4e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4e53:	8d be 00 ff          	lea    di,[bp-0x100]
    4e57:	16                   	push   ss
    4e58:	57                   	push   di
    4e59:	68 ff 00             	push   0xff
    4e5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5f:	26 ff b5 72 02       	push   WORD PTR es:[di+0x272]
    4e64:	26 ff b5 70 02       	push   WORD PTR es:[di+0x270]
    4e69:	55                   	push   bp
    4e6a:	9a 51 49 89 4e       	call   0x4e89:0x4951
    4e6f:	8d be 00 ff          	lea    di,[bp-0x100]
    4e73:	16                   	push   ss
    4e74:	57                   	push   di
    4e75:	68 ff 00             	push   0xff
    4e78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e7b:	26 ff b5 76 02       	push   WORD PTR es:[di+0x276]
    4e80:	26 ff b5 74 02       	push   WORD PTR es:[di+0x274]
    4e85:	55                   	push   bp
    4e86:	9a 51 49 c9 4e       	call   0x4ec9:0x4951
    4e8b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4e90:	76 18                	jbe    0x4eaa
    4e92:	8d be 00 ff          	lea    di,[bp-0x100]
    4e96:	16                   	push   ss
    4e97:	57                   	push   di
    4e98:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4e9c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4ea1:	06                   	push   es
    4ea2:	57                   	push   di
    4ea3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ea6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4eaa:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4eaf:	8d be 00 ff          	lea    di,[bp-0x100]
    4eb3:	16                   	push   ss
    4eb4:	57                   	push   di
    4eb5:	68 ff 00             	push   0xff
    4eb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ebb:	26 ff b5 1a 02       	push   WORD PTR es:[di+0x21a]
    4ec0:	26 ff b5 18 02       	push   WORD PTR es:[di+0x218]
    4ec5:	55                   	push   bp
    4ec6:	9a 51 49 e5 4e       	call   0x4ee5:0x4951
    4ecb:	8d be 00 ff          	lea    di,[bp-0x100]
    4ecf:	16                   	push   ss
    4ed0:	57                   	push   di
    4ed1:	68 ff 00             	push   0xff
    4ed4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ed7:	26 ff b5 5a 03       	push   WORD PTR es:[di+0x35a]
    4edc:	26 ff b5 58 03       	push   WORD PTR es:[di+0x358]
    4ee1:	55                   	push   bp
    4ee2:	9a 51 49 25 4f       	call   0x4f25:0x4951
    4ee7:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4eec:	76 18                	jbe    0x4f06
    4eee:	8d be 00 ff          	lea    di,[bp-0x100]
    4ef2:	16                   	push   ss
    4ef3:	57                   	push   di
    4ef4:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4ef8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4efd:	06                   	push   es
    4efe:	57                   	push   di
    4eff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f02:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4f06:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4f0b:	8d be 00 ff          	lea    di,[bp-0x100]
    4f0f:	16                   	push   ss
    4f10:	57                   	push   di
    4f11:	68 ff 00             	push   0xff
    4f14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f17:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    4f1c:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    4f21:	55                   	push   bp
    4f22:	9a 51 49 41 4f       	call   0x4f41:0x4951
    4f27:	8d be 00 ff          	lea    di,[bp-0x100]
    4f2b:	16                   	push   ss
    4f2c:	57                   	push   di
    4f2d:	68 ff 00             	push   0xff
    4f30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f33:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    4f38:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    4f3d:	55                   	push   bp
    4f3e:	9a 51 49 95 4f       	call   0x4f95:0x4951
    4f43:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4f48:	76 18                	jbe    0x4f62
    4f4a:	8d be 00 ff          	lea    di,[bp-0x100]
    4f4e:	16                   	push   ss
    4f4f:	57                   	push   di
    4f50:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4f54:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4f59:	06                   	push   es
    4f5a:	57                   	push   di
    4f5b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f5e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4f62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f65:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    4f6a:	06                   	push   es
    4f6b:	57                   	push   di
    4f6c:	9a 07 5c ed 5b       	call   0x5bed:0x5c07
    4f71:	3d 01 00             	cmp    ax,0x1
    4f74:	75 5c                	jne    0x4fd2
    4f76:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4f7b:	8d be 00 ff          	lea    di,[bp-0x100]
    4f7f:	16                   	push   ss
    4f80:	57                   	push   di
    4f81:	68 ff 00             	push   0xff
    4f84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f87:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    4f8c:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    4f91:	55                   	push   bp
    4f92:	9a 51 49 b1 4f       	call   0x4fb1:0x4951
    4f97:	8d be 00 ff          	lea    di,[bp-0x100]
    4f9b:	16                   	push   ss
    4f9c:	57                   	push   di
    4f9d:	68 ff 00             	push   0xff
    4fa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fa3:	26 ff b5 62 03       	push   WORD PTR es:[di+0x362]
    4fa8:	26 ff b5 60 03       	push   WORD PTR es:[di+0x360]
    4fad:	55                   	push   bp
    4fae:	9a 51 49 03 50       	call   0x5003:0x4951
    4fb3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4fb8:	76 18                	jbe    0x4fd2
    4fba:	8d be 00 ff          	lea    di,[bp-0x100]
    4fbe:	16                   	push   ss
    4fbf:	57                   	push   di
    4fc0:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    4fc4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4fc9:	06                   	push   es
    4fca:	57                   	push   di
    4fcb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fce:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4fd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fd5:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    4fda:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4fdf:	75 03                	jne    0x4fe4
    4fe1:	e9 f8 00             	jmp    0x50dc
    4fe4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4fe9:	8d be 00 ff          	lea    di,[bp-0x100]
    4fed:	16                   	push   ss
    4fee:	57                   	push   di
    4fef:	68 ff 00             	push   0xff
    4ff2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ff5:	26 ff b5 4e 02       	push   WORD PTR es:[di+0x24e]
    4ffa:	26 ff b5 4c 02       	push   WORD PTR es:[di+0x24c]
    4fff:	55                   	push   bp
    5000:	9a 51 49 43 50       	call   0x5043:0x4951
    5005:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    500a:	76 18                	jbe    0x5024
    500c:	8d be 00 ff          	lea    di,[bp-0x100]
    5010:	16                   	push   ss
    5011:	57                   	push   di
    5012:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5016:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    501b:	06                   	push   es
    501c:	57                   	push   di
    501d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5020:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5024:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5029:	8d be 00 ff          	lea    di,[bp-0x100]
    502d:	16                   	push   ss
    502e:	57                   	push   di
    502f:	68 ff 00             	push   0xff
    5032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5035:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    503a:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    503f:	55                   	push   bp
    5040:	9a 51 49 5f 50       	call   0x505f:0x4951
    5045:	8d be 00 ff          	lea    di,[bp-0x100]
    5049:	16                   	push   ss
    504a:	57                   	push   di
    504b:	68 ff 00             	push   0xff
    504e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5051:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    5056:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    505b:	55                   	push   bp
    505c:	9a 51 49 9f 50       	call   0x509f:0x4951
    5061:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5066:	76 18                	jbe    0x5080
    5068:	8d be 00 ff          	lea    di,[bp-0x100]
    506c:	16                   	push   ss
    506d:	57                   	push   di
    506e:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5072:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5077:	06                   	push   es
    5078:	57                   	push   di
    5079:	26 c4 3d             	les    di,DWORD PTR es:[di]
    507c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5080:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5085:	8d be 00 ff          	lea    di,[bp-0x100]
    5089:	16                   	push   ss
    508a:	57                   	push   di
    508b:	68 ff 00             	push   0xff
    508e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5091:	26 ff b5 8a 02       	push   WORD PTR es:[di+0x28a]
    5096:	26 ff b5 88 02       	push   WORD PTR es:[di+0x288]
    509b:	55                   	push   bp
    509c:	9a 51 49 bb 50       	call   0x50bb:0x4951
    50a1:	8d be 00 ff          	lea    di,[bp-0x100]
    50a5:	16                   	push   ss
    50a6:	57                   	push   di
    50a7:	68 ff 00             	push   0xff
    50aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50ad:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    50b2:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    50b7:	55                   	push   bp
    50b8:	9a 51 49 fb 50       	call   0x50fb:0x4951
    50bd:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    50c2:	76 18                	jbe    0x50dc
    50c4:	8d be 00 ff          	lea    di,[bp-0x100]
    50c8:	16                   	push   ss
    50c9:	57                   	push   di
    50ca:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    50ce:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    50d3:	06                   	push   es
    50d4:	57                   	push   di
    50d5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50d8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    50dc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    50e1:	8d be 00 ff          	lea    di,[bp-0x100]
    50e5:	16                   	push   ss
    50e6:	57                   	push   di
    50e7:	68 ff 00             	push   0xff
    50ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50ed:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    50f2:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    50f7:	55                   	push   bp
    50f8:	9a 51 49 47 51       	call   0x5147:0x4951
    50fd:	8d be f6 fd          	lea    di,[bp-0x20a]
    5101:	16                   	push   ss
    5102:	57                   	push   di
    5103:	bf cb 4c             	mov    di,0x4ccb
    5106:	0e                   	push   cs
    5107:	57                   	push   di
    5108:	9a cd 17 16 51       	call   0x5116:0x17cd
    510d:	8d be 00 ff          	lea    di,[bp-0x100]
    5111:	16                   	push   ss
    5112:	57                   	push   di
    5113:	9a 4c 18 24 51       	call   0x5124:0x184c
    5118:	8d be 00 ff          	lea    di,[bp-0x100]
    511c:	16                   	push   ss
    511d:	57                   	push   di
    511e:	68 ff 00             	push   0xff
    5121:	9a e7 17 25 53       	call   0x5325:0x17e7
    5126:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    512b:	7c 1c                	jl     0x5149
    512d:	8d be 00 ff          	lea    di,[bp-0x100]
    5131:	16                   	push   ss
    5132:	57                   	push   di
    5133:	68 ff 00             	push   0xff
    5136:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5139:	26 ff b5 22 02       	push   WORD PTR es:[di+0x222]
    513e:	26 ff b5 20 02       	push   WORD PTR es:[di+0x220]
    5143:	55                   	push   bp
    5144:	9a 51 49 87 51       	call   0x5187:0x4951
    5149:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    514e:	76 18                	jbe    0x5168
    5150:	8d be 00 ff          	lea    di,[bp-0x100]
    5154:	16                   	push   ss
    5155:	57                   	push   di
    5156:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    515a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    515f:	06                   	push   es
    5160:	57                   	push   di
    5161:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5164:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5168:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    516d:	8d be 00 ff          	lea    di,[bp-0x100]
    5171:	16                   	push   ss
    5172:	57                   	push   di
    5173:	68 ff 00             	push   0xff
    5176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5179:	26 ff b5 92 02       	push   WORD PTR es:[di+0x292]
    517e:	26 ff b5 90 02       	push   WORD PTR es:[di+0x290]
    5183:	55                   	push   bp
    5184:	9a 51 49 a3 51       	call   0x51a3:0x4951
    5189:	8d be 00 ff          	lea    di,[bp-0x100]
    518d:	16                   	push   ss
    518e:	57                   	push   di
    518f:	68 ff 00             	push   0xff
    5192:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5195:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    519a:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    519f:	55                   	push   bp
    51a0:	9a 51 49 bf 51       	call   0x51bf:0x4951
    51a5:	8d be 00 ff          	lea    di,[bp-0x100]
    51a9:	16                   	push   ss
    51aa:	57                   	push   di
    51ab:	68 ff 00             	push   0xff
    51ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51b1:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    51b6:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    51bb:	55                   	push   bp
    51bc:	9a 51 49 ff 51       	call   0x51ff:0x4951
    51c1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    51c6:	76 18                	jbe    0x51e0
    51c8:	8d be 00 ff          	lea    di,[bp-0x100]
    51cc:	16                   	push   ss
    51cd:	57                   	push   di
    51ce:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    51d2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    51d7:	06                   	push   es
    51d8:	57                   	push   di
    51d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51dc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    51e0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    51e5:	8d be 00 ff          	lea    di,[bp-0x100]
    51e9:	16                   	push   ss
    51ea:	57                   	push   di
    51eb:	68 ff 00             	push   0xff
    51ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51f1:	26 ff b5 96 02       	push   WORD PTR es:[di+0x296]
    51f6:	26 ff b5 94 02       	push   WORD PTR es:[di+0x294]
    51fb:	55                   	push   bp
    51fc:	9a 51 49 1b 52       	call   0x521b:0x4951
    5201:	8d be 00 ff          	lea    di,[bp-0x100]
    5205:	16                   	push   ss
    5206:	57                   	push   di
    5207:	68 ff 00             	push   0xff
    520a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    520d:	26 ff b5 42 02       	push   WORD PTR es:[di+0x242]
    5212:	26 ff b5 40 02       	push   WORD PTR es:[di+0x240]
    5217:	55                   	push   bp
    5218:	9a 51 49 37 52       	call   0x5237:0x4951
    521d:	8d be 00 ff          	lea    di,[bp-0x100]
    5221:	16                   	push   ss
    5222:	57                   	push   di
    5223:	68 ff 00             	push   0xff
    5226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5229:	26 ff b5 2a 02       	push   WORD PTR es:[di+0x22a]
    522e:	26 ff b5 28 02       	push   WORD PTR es:[di+0x228]
    5233:	55                   	push   bp
    5234:	9a 51 49 77 52       	call   0x5277:0x4951
    5239:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    523e:	76 18                	jbe    0x5258
    5240:	8d be 00 ff          	lea    di,[bp-0x100]
    5244:	16                   	push   ss
    5245:	57                   	push   di
    5246:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    524a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    524f:	06                   	push   es
    5250:	57                   	push   di
    5251:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5254:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5258:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    525d:	8d be 00 ff          	lea    di,[bp-0x100]
    5261:	16                   	push   ss
    5262:	57                   	push   di
    5263:	68 ff 00             	push   0xff
    5266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5269:	26 ff b5 9a 02       	push   WORD PTR es:[di+0x29a]
    526e:	26 ff b5 98 02       	push   WORD PTR es:[di+0x298]
    5273:	55                   	push   bp
    5274:	9a 51 49 93 52       	call   0x5293:0x4951
    5279:	8d be 00 ff          	lea    di,[bp-0x100]
    527d:	16                   	push   ss
    527e:	57                   	push   di
    527f:	68 ff 00             	push   0xff
    5282:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5285:	26 ff b5 46 02       	push   WORD PTR es:[di+0x246]
    528a:	26 ff b5 44 02       	push   WORD PTR es:[di+0x244]
    528f:	55                   	push   bp
    5290:	9a 51 49 af 52       	call   0x52af:0x4951
    5295:	8d be 00 ff          	lea    di,[bp-0x100]
    5299:	16                   	push   ss
    529a:	57                   	push   di
    529b:	68 ff 00             	push   0xff
    529e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52a1:	26 ff b5 2e 02       	push   WORD PTR es:[di+0x22e]
    52a6:	26 ff b5 2c 02       	push   WORD PTR es:[di+0x22c]
    52ab:	55                   	push   bp
    52ac:	9a 51 49 ef 52       	call   0x52ef:0x4951
    52b1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    52b6:	76 18                	jbe    0x52d0
    52b8:	8d be 00 ff          	lea    di,[bp-0x100]
    52bc:	16                   	push   ss
    52bd:	57                   	push   di
    52be:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    52c2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    52c7:	06                   	push   es
    52c8:	57                   	push   di
    52c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52cc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    52d0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    52d5:	8d be 00 ff          	lea    di,[bp-0x100]
    52d9:	16                   	push   ss
    52da:	57                   	push   di
    52db:	68 ff 00             	push   0xff
    52de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52e1:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    52e6:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    52eb:	55                   	push   bp
    52ec:	9a 51 49 86 53       	call   0x5386:0x4951
    52f1:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    52f6:	7c 74                	jl     0x536c
    52f8:	8d be f6 fd          	lea    di,[bp-0x20a]
    52fc:	16                   	push   ss
    52fd:	57                   	push   di
    52fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5301:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    5306:	06                   	push   es
    5307:	57                   	push   di
    5308:	9a 53 1d 20 53       	call   0x5320:0x1d53
    530d:	8d be f6 fc          	lea    di,[bp-0x30a]
    5311:	16                   	push   ss
    5312:	57                   	push   di
    5313:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5316:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    531b:	06                   	push   es
    531c:	57                   	push   di
    531d:	9a 53 1d 57 53       	call   0x5357:0x1d53
    5322:	9a be 18 38 53       	call   0x5338:0x18be
    5327:	74 43                	je     0x536c
    5329:	8d be f6 fb          	lea    di,[bp-0x40a]
    532d:	16                   	push   ss
    532e:	57                   	push   di
    532f:	8d be 00 ff          	lea    di,[bp-0x100]
    5333:	16                   	push   ss
    5334:	57                   	push   di
    5335:	9a cd 17 42 53       	call   0x5342:0x17cd
    533a:	bf cd 4c             	mov    di,0x4ccd
    533d:	0e                   	push   cs
    533e:	57                   	push   di
    533f:	9a 4c 18 5c 53       	call   0x535c:0x184c
    5344:	8d be f6 fa          	lea    di,[bp-0x50a]
    5348:	16                   	push   ss
    5349:	57                   	push   di
    534a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    534d:	26 c4 bd a8 02       	les    di,DWORD PTR es:[di+0x2a8]
    5352:	06                   	push   es
    5353:	57                   	push   di
    5354:	9a 53 1d 53 5c       	call   0x5c53:0x1d53
    5359:	9a 4c 18 6a 53       	call   0x536a:0x184c
    535e:	8d be 00 ff          	lea    di,[bp-0x100]
    5362:	16                   	push   ss
    5363:	57                   	push   di
    5364:	68 ff 00             	push   0xff
    5367:	9a e7 17 06 54       	call   0x5406:0x17e7
    536c:	8d be 00 ff          	lea    di,[bp-0x100]
    5370:	16                   	push   ss
    5371:	57                   	push   di
    5372:	68 ff 00             	push   0xff
    5375:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5378:	26 ff b5 4a 02       	push   WORD PTR es:[di+0x24a]
    537d:	26 ff b5 48 02       	push   WORD PTR es:[di+0x248]
    5382:	55                   	push   bp
    5383:	9a 51 49 a2 53       	call   0x53a2:0x4951
    5388:	8d be 00 ff          	lea    di,[bp-0x100]
    538c:	16                   	push   ss
    538d:	57                   	push   di
    538e:	68 ff 00             	push   0xff
    5391:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5394:	26 ff b5 32 02       	push   WORD PTR es:[di+0x232]
    5399:	26 ff b5 30 02       	push   WORD PTR es:[di+0x230]
    539e:	55                   	push   bp
    539f:	9a 51 49 33 54       	call   0x5433:0x4951
    53a4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    53a9:	76 18                	jbe    0x53c3
    53ab:	8d be 00 ff          	lea    di,[bp-0x100]
    53af:	16                   	push   ss
    53b0:	57                   	push   di
    53b1:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    53b5:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    53ba:	06                   	push   es
    53bb:	57                   	push   di
    53bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53bf:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    53c3:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    53c8:	74 03                	je     0x53cd
    53ca:	e9 10 07             	jmp    0x5add
    53cd:	bf d1 4c             	mov    di,0x4cd1
    53d0:	0e                   	push   cs
    53d1:	57                   	push   di
    53d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    53d5:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    53da:	06                   	push   es
    53db:	57                   	push   di
    53dc:	9a 43 3c ff ff       	call   0xffff:0x3c43
    53e1:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    53e5:	89 96 fc fe          	mov    WORD PTR [bp-0x104],dx
    53e9:	8b 86 fa fe          	mov    ax,WORD PTR [bp-0x106]
    53ed:	0b 86 fc fe          	or     ax,WORD PTR [bp-0x104]
    53f1:	74 1b                	je     0x540e
    53f3:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    53f7:	06                   	push   es
    53f8:	57                   	push   di
    53f9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53fc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5400:	bf df 4c             	mov    di,0x4cdf
    5403:	9a 16 04 96 54       	call   0x5496:0x416
    5408:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    540c:	eb 06                	jmp    0x5414
    540e:	c7 86 fe fe 08 00    	mov    WORD PTR [bp-0x102],0x8
    5414:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5419:	8d be 00 ff          	lea    di,[bp-0x100]
    541d:	16                   	push   ss
    541e:	57                   	push   di
    541f:	68 ff 00             	push   0xff
    5422:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5425:	26 ff b5 b2 01       	push   WORD PTR es:[di+0x1b2]
    542a:	26 ff b5 b0 01       	push   WORD PTR es:[di+0x1b0]
    542f:	55                   	push   bp
    5430:	9a 51 49 4f 54       	call   0x544f:0x4951
    5435:	8d be 00 ff          	lea    di,[bp-0x100]
    5439:	16                   	push   ss
    543a:	57                   	push   di
    543b:	68 ff 00             	push   0xff
    543e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5441:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    5446:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    544b:	55                   	push   bp
    544c:	9a 51 49 6b 54       	call   0x546b:0x4951
    5451:	8d be 00 ff          	lea    di,[bp-0x100]
    5455:	16                   	push   ss
    5456:	57                   	push   di
    5457:	68 ff 00             	push   0xff
    545a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    545d:	26 ff b5 16 02       	push   WORD PTR es:[di+0x216]
    5462:	26 ff b5 14 02       	push   WORD PTR es:[di+0x214]
    5467:	55                   	push   bp
    5468:	9a 51 49 b2 54       	call   0x54b2:0x4951
    546d:	8d be 00 ff          	lea    di,[bp-0x100]
    5471:	16                   	push   ss
    5472:	57                   	push   di
    5473:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5477:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    547c:	06                   	push   es
    547d:	57                   	push   di
    547e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5481:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5485:	bf e7 4c             	mov    di,0x4ce7
    5488:	0e                   	push   cs
    5489:	57                   	push   di
    548a:	8d be 00 ff          	lea    di,[bp-0x100]
    548e:	16                   	push   ss
    548f:	57                   	push   di
    5490:	68 ff 00             	push   0xff
    5493:	9a e7 17 f9 54       	call   0x54f9:0x17e7
    5498:	8d be 00 ff          	lea    di,[bp-0x100]
    549c:	16                   	push   ss
    549d:	57                   	push   di
    549e:	68 ff 00             	push   0xff
    54a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54a4:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    54a9:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    54ae:	55                   	push   bp
    54af:	9a 51 49 ce 54       	call   0x54ce:0x4951
    54b4:	8d be 00 ff          	lea    di,[bp-0x100]
    54b8:	16                   	push   ss
    54b9:	57                   	push   di
    54ba:	68 ff 00             	push   0xff
    54bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54c0:	26 ff b5 12 02       	push   WORD PTR es:[di+0x212]
    54c5:	26 ff b5 10 02       	push   WORD PTR es:[di+0x210]
    54ca:	55                   	push   bp
    54cb:	9a 51 49 15 55       	call   0x5515:0x4951
    54d0:	8d be 00 ff          	lea    di,[bp-0x100]
    54d4:	16                   	push   ss
    54d5:	57                   	push   di
    54d6:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    54da:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    54df:	06                   	push   es
    54e0:	57                   	push   di
    54e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54e4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    54e8:	bf e7 4c             	mov    di,0x4ce7
    54eb:	0e                   	push   cs
    54ec:	57                   	push   di
    54ed:	8d be 00 ff          	lea    di,[bp-0x100]
    54f1:	16                   	push   ss
    54f2:	57                   	push   di
    54f3:	68 ff 00             	push   0xff
    54f6:	9a e7 17 5c 55       	call   0x555c:0x17e7
    54fb:	8d be 00 ff          	lea    di,[bp-0x100]
    54ff:	16                   	push   ss
    5500:	57                   	push   di
    5501:	68 ff 00             	push   0xff
    5504:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5507:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    550c:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    5511:	55                   	push   bp
    5512:	9a 51 49 31 55       	call   0x5531:0x4951
    5517:	8d be 00 ff          	lea    di,[bp-0x100]
    551b:	16                   	push   ss
    551c:	57                   	push   di
    551d:	68 ff 00             	push   0xff
    5520:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5523:	26 ff b5 0e 02       	push   WORD PTR es:[di+0x20e]
    5528:	26 ff b5 0c 02       	push   WORD PTR es:[di+0x20c]
    552d:	55                   	push   bp
    552e:	9a 51 49 78 55       	call   0x5578:0x4951
    5533:	8d be 00 ff          	lea    di,[bp-0x100]
    5537:	16                   	push   ss
    5538:	57                   	push   di
    5539:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    553d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5542:	06                   	push   es
    5543:	57                   	push   di
    5544:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5547:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    554b:	bf e7 4c             	mov    di,0x4ce7
    554e:	0e                   	push   cs
    554f:	57                   	push   di
    5550:	8d be 00 ff          	lea    di,[bp-0x100]
    5554:	16                   	push   ss
    5555:	57                   	push   di
    5556:	68 ff 00             	push   0xff
    5559:	9a e7 17 bf 55       	call   0x55bf:0x17e7
    555e:	8d be 00 ff          	lea    di,[bp-0x100]
    5562:	16                   	push   ss
    5563:	57                   	push   di
    5564:	68 ff 00             	push   0xff
    5567:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    556a:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    556f:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    5574:	55                   	push   bp
    5575:	9a 51 49 94 55       	call   0x5594:0x4951
    557a:	8d be 00 ff          	lea    di,[bp-0x100]
    557e:	16                   	push   ss
    557f:	57                   	push   di
    5580:	68 ff 00             	push   0xff
    5583:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5586:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    558b:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    5590:	55                   	push   bp
    5591:	9a 51 49 db 55       	call   0x55db:0x4951
    5596:	8d be 00 ff          	lea    di,[bp-0x100]
    559a:	16                   	push   ss
    559b:	57                   	push   di
    559c:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    55a0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    55a5:	06                   	push   es
    55a6:	57                   	push   di
    55a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55aa:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    55ae:	bf e7 4c             	mov    di,0x4ce7
    55b1:	0e                   	push   cs
    55b2:	57                   	push   di
    55b3:	8d be 00 ff          	lea    di,[bp-0x100]
    55b7:	16                   	push   ss
    55b8:	57                   	push   di
    55b9:	68 ff 00             	push   0xff
    55bc:	9a e7 17 22 56       	call   0x5622:0x17e7
    55c1:	8d be 00 ff          	lea    di,[bp-0x100]
    55c5:	16                   	push   ss
    55c6:	57                   	push   di
    55c7:	68 ff 00             	push   0xff
    55ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55cd:	26 ff b5 e6 01       	push   WORD PTR es:[di+0x1e6]
    55d2:	26 ff b5 e4 01       	push   WORD PTR es:[di+0x1e4]
    55d7:	55                   	push   bp
    55d8:	9a 51 49 f7 55       	call   0x55f7:0x4951
    55dd:	8d be 00 ff          	lea    di,[bp-0x100]
    55e1:	16                   	push   ss
    55e2:	57                   	push   di
    55e3:	68 ff 00             	push   0xff
    55e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55e9:	26 ff b5 06 02       	push   WORD PTR es:[di+0x206]
    55ee:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    55f3:	55                   	push   bp
    55f4:	9a 51 49 3e 56       	call   0x563e:0x4951
    55f9:	8d be 00 ff          	lea    di,[bp-0x100]
    55fd:	16                   	push   ss
    55fe:	57                   	push   di
    55ff:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5603:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5608:	06                   	push   es
    5609:	57                   	push   di
    560a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    560d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5611:	bf e7 4c             	mov    di,0x4ce7
    5614:	0e                   	push   cs
    5615:	57                   	push   di
    5616:	8d be 00 ff          	lea    di,[bp-0x100]
    561a:	16                   	push   ss
    561b:	57                   	push   di
    561c:	68 ff 00             	push   0xff
    561f:	9a e7 17 85 56       	call   0x5685:0x17e7
    5624:	8d be 00 ff          	lea    di,[bp-0x100]
    5628:	16                   	push   ss
    5629:	57                   	push   di
    562a:	68 ff 00             	push   0xff
    562d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5630:	26 ff b5 ea 01       	push   WORD PTR es:[di+0x1ea]
    5635:	26 ff b5 e8 01       	push   WORD PTR es:[di+0x1e8]
    563a:	55                   	push   bp
    563b:	9a 51 49 5a 56       	call   0x565a:0x4951
    5640:	8d be 00 ff          	lea    di,[bp-0x100]
    5644:	16                   	push   ss
    5645:	57                   	push   di
    5646:	68 ff 00             	push   0xff
    5649:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    564c:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    5651:	26 ff b5 00 02       	push   WORD PTR es:[di+0x200]
    5656:	55                   	push   bp
    5657:	9a 51 49 a1 56       	call   0x56a1:0x4951
    565c:	8d be 00 ff          	lea    di,[bp-0x100]
    5660:	16                   	push   ss
    5661:	57                   	push   di
    5662:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5666:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    566b:	06                   	push   es
    566c:	57                   	push   di
    566d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5670:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5674:	bf e7 4c             	mov    di,0x4ce7
    5677:	0e                   	push   cs
    5678:	57                   	push   di
    5679:	8d be 00 ff          	lea    di,[bp-0x100]
    567d:	16                   	push   ss
    567e:	57                   	push   di
    567f:	68 ff 00             	push   0xff
    5682:	9a e7 17 ef 56       	call   0x56ef:0x17e7
    5687:	8d be 00 ff          	lea    di,[bp-0x100]
    568b:	16                   	push   ss
    568c:	57                   	push   di
    568d:	68 ff 00             	push   0xff
    5690:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5693:	26 ff b5 ee 01       	push   WORD PTR es:[di+0x1ee]
    5698:	26 ff b5 ec 01       	push   WORD PTR es:[di+0x1ec]
    569d:	55                   	push   bp
    569e:	9a 51 49 bd 56       	call   0x56bd:0x4951
    56a3:	8d be 00 ff          	lea    di,[bp-0x100]
    56a7:	16                   	push   ss
    56a8:	57                   	push   di
    56a9:	68 ff 00             	push   0xff
    56ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56af:	26 ff b5 fe 01       	push   WORD PTR es:[di+0x1fe]
    56b4:	26 ff b5 fc 01       	push   WORD PTR es:[di+0x1fc]
    56b9:	55                   	push   bp
    56ba:	9a 51 49 0b 57       	call   0x570b:0x4951
    56bf:	8d be 00 ff          	lea    di,[bp-0x100]
    56c3:	16                   	push   ss
    56c4:	57                   	push   di
    56c5:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    56c9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    56ce:	06                   	push   es
    56cf:	57                   	push   di
    56d0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56d3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    56d7:	83 be fe fe 07       	cmp    WORD PTR [bp-0x102],0x7
    56dc:	75 72                	jne    0x5750
    56de:	bf e7 4c             	mov    di,0x4ce7
    56e1:	0e                   	push   cs
    56e2:	57                   	push   di
    56e3:	8d be 00 ff          	lea    di,[bp-0x100]
    56e7:	16                   	push   ss
    56e8:	57                   	push   di
    56e9:	68 ff 00             	push   0xff
    56ec:	9a e7 17 1b 57       	call   0x571b:0x17e7
    56f1:	8d be 00 ff          	lea    di,[bp-0x100]
    56f5:	16                   	push   ss
    56f6:	57                   	push   di
    56f7:	68 ff 00             	push   0xff
    56fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56fd:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    5702:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    5707:	55                   	push   bp
    5708:	9a 51 49 84 57       	call   0x5784:0x4951
    570d:	8d be f6 fd          	lea    di,[bp-0x20a]
    5711:	16                   	push   ss
    5712:	57                   	push   di
    5713:	bf cb 4c             	mov    di,0x4ccb
    5716:	0e                   	push   cs
    5717:	57                   	push   di
    5718:	9a cd 17 26 57       	call   0x5726:0x17cd
    571d:	8d be 00 ff          	lea    di,[bp-0x100]
    5721:	16                   	push   ss
    5722:	57                   	push   di
    5723:	9a 4c 18 34 57       	call   0x5734:0x184c
    5728:	8d be 00 ff          	lea    di,[bp-0x100]
    572c:	16                   	push   ss
    572d:	57                   	push   di
    572e:	68 ff 00             	push   0xff
    5731:	9a e7 17 68 57       	call   0x5768:0x17e7
    5736:	8d be 00 ff          	lea    di,[bp-0x100]
    573a:	16                   	push   ss
    573b:	57                   	push   di
    573c:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5740:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5745:	06                   	push   es
    5746:	57                   	push   di
    5747:	26 c4 3d             	les    di,DWORD PTR es:[di]
    574a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    574e:	eb 6a                	jmp    0x57ba
    5750:	83 be fe fe 07       	cmp    WORD PTR [bp-0x102],0x7
    5755:	7e 63                	jle    0x57ba
    5757:	bf e7 4c             	mov    di,0x4ce7
    575a:	0e                   	push   cs
    575b:	57                   	push   di
    575c:	8d be 00 ff          	lea    di,[bp-0x100]
    5760:	16                   	push   ss
    5761:	57                   	push   di
    5762:	68 ff 00             	push   0xff
    5765:	9a e7 17 d2 57       	call   0x57d2:0x17e7
    576a:	8d be 00 ff          	lea    di,[bp-0x100]
    576e:	16                   	push   ss
    576f:	57                   	push   di
    5770:	68 ff 00             	push   0xff
    5773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5776:	26 ff b5 f2 01       	push   WORD PTR es:[di+0x1f2]
    577b:	26 ff b5 f0 01       	push   WORD PTR es:[di+0x1f0]
    5780:	55                   	push   bp
    5781:	9a 51 49 a0 57       	call   0x57a0:0x4951
    5786:	8d be 00 ff          	lea    di,[bp-0x100]
    578a:	16                   	push   ss
    578b:	57                   	push   di
    578c:	68 ff 00             	push   0xff
    578f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5792:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    5797:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    579c:	55                   	push   bp
    579d:	9a 51 49 ee 57       	call   0x57ee:0x4951
    57a2:	8d be 00 ff          	lea    di,[bp-0x100]
    57a6:	16                   	push   ss
    57a7:	57                   	push   di
    57a8:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    57ac:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    57b1:	06                   	push   es
    57b2:	57                   	push   di
    57b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57b6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    57ba:	83 be fe fe 08       	cmp    WORD PTR [bp-0x102],0x8
    57bf:	75 72                	jne    0x5833
    57c1:	bf e7 4c             	mov    di,0x4ce7
    57c4:	0e                   	push   cs
    57c5:	57                   	push   di
    57c6:	8d be 00 ff          	lea    di,[bp-0x100]
    57ca:	16                   	push   ss
    57cb:	57                   	push   di
    57cc:	68 ff 00             	push   0xff
    57cf:	9a e7 17 fe 57       	call   0x57fe:0x17e7
    57d4:	8d be 00 ff          	lea    di,[bp-0x100]
    57d8:	16                   	push   ss
    57d9:	57                   	push   di
    57da:	68 ff 00             	push   0xff
    57dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57e0:	26 ff b5 f6 01       	push   WORD PTR es:[di+0x1f6]
    57e5:	26 ff b5 f4 01       	push   WORD PTR es:[di+0x1f4]
    57ea:	55                   	push   bp
    57eb:	9a 51 49 67 58       	call   0x5867:0x4951
    57f0:	8d be f6 fd          	lea    di,[bp-0x20a]
    57f4:	16                   	push   ss
    57f5:	57                   	push   di
    57f6:	bf cb 4c             	mov    di,0x4ccb
    57f9:	0e                   	push   cs
    57fa:	57                   	push   di
    57fb:	9a cd 17 09 58       	call   0x5809:0x17cd
    5800:	8d be 00 ff          	lea    di,[bp-0x100]
    5804:	16                   	push   ss
    5805:	57                   	push   di
    5806:	9a 4c 18 17 58       	call   0x5817:0x184c
    580b:	8d be 00 ff          	lea    di,[bp-0x100]
    580f:	16                   	push   ss
    5810:	57                   	push   di
    5811:	68 ff 00             	push   0xff
    5814:	9a e7 17 4b 58       	call   0x584b:0x17e7
    5819:	8d be 00 ff          	lea    di,[bp-0x100]
    581d:	16                   	push   ss
    581e:	57                   	push   di
    581f:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5823:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5828:	06                   	push   es
    5829:	57                   	push   di
    582a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    582d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5831:	eb 6a                	jmp    0x589d
    5833:	83 be fe fe 08       	cmp    WORD PTR [bp-0x102],0x8
    5838:	7e 63                	jle    0x589d
    583a:	bf e7 4c             	mov    di,0x4ce7
    583d:	0e                   	push   cs
    583e:	57                   	push   di
    583f:	8d be 00 ff          	lea    di,[bp-0x100]
    5843:	16                   	push   ss
    5844:	57                   	push   di
    5845:	68 ff 00             	push   0xff
    5848:	9a e7 17 b5 58       	call   0x58b5:0x17e7
    584d:	8d be 00 ff          	lea    di,[bp-0x100]
    5851:	16                   	push   ss
    5852:	57                   	push   di
    5853:	68 ff 00             	push   0xff
    5856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5859:	26 ff b5 36 03       	push   WORD PTR es:[di+0x336]
    585e:	26 ff b5 34 03       	push   WORD PTR es:[di+0x334]
    5863:	55                   	push   bp
    5864:	9a 51 49 83 58       	call   0x5883:0x4951
    5869:	8d be 00 ff          	lea    di,[bp-0x100]
    586d:	16                   	push   ss
    586e:	57                   	push   di
    586f:	68 ff 00             	push   0xff
    5872:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5875:	26 ff b5 f6 01       	push   WORD PTR es:[di+0x1f6]
    587a:	26 ff b5 f4 01       	push   WORD PTR es:[di+0x1f4]
    587f:	55                   	push   bp
    5880:	9a 51 49 d1 58       	call   0x58d1:0x4951
    5885:	8d be 00 ff          	lea    di,[bp-0x100]
    5889:	16                   	push   ss
    588a:	57                   	push   di
    588b:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    588f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5894:	06                   	push   es
    5895:	57                   	push   di
    5896:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5899:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    589d:	83 be fe fe 09       	cmp    WORD PTR [bp-0x102],0x9
    58a2:	75 72                	jne    0x5916
    58a4:	bf e7 4c             	mov    di,0x4ce7
    58a7:	0e                   	push   cs
    58a8:	57                   	push   di
    58a9:	8d be 00 ff          	lea    di,[bp-0x100]
    58ad:	16                   	push   ss
    58ae:	57                   	push   di
    58af:	68 ff 00             	push   0xff
    58b2:	9a e7 17 e1 58       	call   0x58e1:0x17e7
    58b7:	8d be 00 ff          	lea    di,[bp-0x100]
    58bb:	16                   	push   ss
    58bc:	57                   	push   di
    58bd:	68 ff 00             	push   0xff
    58c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58c3:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    58c8:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    58cd:	55                   	push   bp
    58ce:	9a 51 49 4a 59       	call   0x594a:0x4951
    58d3:	8d be f6 fd          	lea    di,[bp-0x20a]
    58d7:	16                   	push   ss
    58d8:	57                   	push   di
    58d9:	bf cb 4c             	mov    di,0x4ccb
    58dc:	0e                   	push   cs
    58dd:	57                   	push   di
    58de:	9a cd 17 ec 58       	call   0x58ec:0x17cd
    58e3:	8d be 00 ff          	lea    di,[bp-0x100]
    58e7:	16                   	push   ss
    58e8:	57                   	push   di
    58e9:	9a 4c 18 fa 58       	call   0x58fa:0x184c
    58ee:	8d be 00 ff          	lea    di,[bp-0x100]
    58f2:	16                   	push   ss
    58f3:	57                   	push   di
    58f4:	68 ff 00             	push   0xff
    58f7:	9a e7 17 2e 59       	call   0x592e:0x17e7
    58fc:	8d be 00 ff          	lea    di,[bp-0x100]
    5900:	16                   	push   ss
    5901:	57                   	push   di
    5902:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5906:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    590b:	06                   	push   es
    590c:	57                   	push   di
    590d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5910:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5914:	eb 6a                	jmp    0x5980
    5916:	83 be fe fe 09       	cmp    WORD PTR [bp-0x102],0x9
    591b:	7e 63                	jle    0x5980
    591d:	bf e7 4c             	mov    di,0x4ce7
    5920:	0e                   	push   cs
    5921:	57                   	push   di
    5922:	8d be 00 ff          	lea    di,[bp-0x100]
    5926:	16                   	push   ss
    5927:	57                   	push   di
    5928:	68 ff 00             	push   0xff
    592b:	9a e7 17 a2 59       	call   0x59a2:0x17e7
    5930:	8d be 00 ff          	lea    di,[bp-0x100]
    5934:	16                   	push   ss
    5935:	57                   	push   di
    5936:	68 ff 00             	push   0xff
    5939:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    593c:	26 ff b5 3a 03       	push   WORD PTR es:[di+0x33a]
    5941:	26 ff b5 38 03       	push   WORD PTR es:[di+0x338]
    5946:	55                   	push   bp
    5947:	9a 51 49 66 59       	call   0x5966:0x4951
    594c:	8d be 00 ff          	lea    di,[bp-0x100]
    5950:	16                   	push   ss
    5951:	57                   	push   di
    5952:	68 ff 00             	push   0xff
    5955:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5958:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    595d:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    5962:	55                   	push   bp
    5963:	9a 51 49 be 59       	call   0x59be:0x4951
    5968:	8d be 00 ff          	lea    di,[bp-0x100]
    596c:	16                   	push   ss
    596d:	57                   	push   di
    596e:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5972:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5977:	06                   	push   es
    5978:	57                   	push   di
    5979:	26 c4 3d             	les    di,DWORD PTR es:[di]
    597c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5980:	83 be fe fe 0a       	cmp    WORD PTR [bp-0x102],0xa
    5985:	74 03                	je     0x598a
    5987:	e9 dc 00             	jmp    0x5a66
    598a:	83 be fe fe 0a       	cmp    WORD PTR [bp-0x102],0xa
    598f:	7e 72                	jle    0x5a03
    5991:	bf e7 4c             	mov    di,0x4ce7
    5994:	0e                   	push   cs
    5995:	57                   	push   di
    5996:	8d be 00 ff          	lea    di,[bp-0x100]
    599a:	16                   	push   ss
    599b:	57                   	push   di
    599c:	68 ff 00             	push   0xff
    599f:	9a e7 17 ce 59       	call   0x59ce:0x17e7
    59a4:	8d be 00 ff          	lea    di,[bp-0x100]
    59a8:	16                   	push   ss
    59a9:	57                   	push   di
    59aa:	68 ff 00             	push   0xff
    59ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59b0:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    59b5:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    59ba:	55                   	push   bp
    59bb:	9a 51 49 30 5a       	call   0x5a30:0x4951
    59c0:	8d be f6 fd          	lea    di,[bp-0x20a]
    59c4:	16                   	push   ss
    59c5:	57                   	push   di
    59c6:	bf cb 4c             	mov    di,0x4ccb
    59c9:	0e                   	push   cs
    59ca:	57                   	push   di
    59cb:	9a cd 17 d9 59       	call   0x59d9:0x17cd
    59d0:	8d be 00 ff          	lea    di,[bp-0x100]
    59d4:	16                   	push   ss
    59d5:	57                   	push   di
    59d6:	9a 4c 18 e7 59       	call   0x59e7:0x184c
    59db:	8d be 00 ff          	lea    di,[bp-0x100]
    59df:	16                   	push   ss
    59e0:	57                   	push   di
    59e1:	68 ff 00             	push   0xff
    59e4:	9a e7 17 14 5a       	call   0x5a14:0x17e7
    59e9:	8d be 00 ff          	lea    di,[bp-0x100]
    59ed:	16                   	push   ss
    59ee:	57                   	push   di
    59ef:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    59f3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    59f8:	06                   	push   es
    59f9:	57                   	push   di
    59fa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    59fd:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a01:	eb 63                	jmp    0x5a66
    5a03:	bf e7 4c             	mov    di,0x4ce7
    5a06:	0e                   	push   cs
    5a07:	57                   	push   di
    5a08:	8d be 00 ff          	lea    di,[bp-0x100]
    5a0c:	16                   	push   ss
    5a0d:	57                   	push   di
    5a0e:	68 ff 00             	push   0xff
    5a11:	9a e7 17 7e 5a       	call   0x5a7e:0x17e7
    5a16:	8d be 00 ff          	lea    di,[bp-0x100]
    5a1a:	16                   	push   ss
    5a1b:	57                   	push   di
    5a1c:	68 ff 00             	push   0xff
    5a1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a22:	26 ff b5 42 03       	push   WORD PTR es:[di+0x342]
    5a27:	26 ff b5 40 03       	push   WORD PTR es:[di+0x340]
    5a2c:	55                   	push   bp
    5a2d:	9a 51 49 4c 5a       	call   0x5a4c:0x4951
    5a32:	8d be 00 ff          	lea    di,[bp-0x100]
    5a36:	16                   	push   ss
    5a37:	57                   	push   di
    5a38:	68 ff 00             	push   0xff
    5a3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a3e:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    5a43:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    5a48:	55                   	push   bp
    5a49:	9a 51 49 9a 5a       	call   0x5a9a:0x4951
    5a4e:	8d be 00 ff          	lea    di,[bp-0x100]
    5a52:	16                   	push   ss
    5a53:	57                   	push   di
    5a54:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5a58:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5a5d:	06                   	push   es
    5a5e:	57                   	push   di
    5a5f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a62:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a66:	83 be fe fe 0b       	cmp    WORD PTR [bp-0x102],0xb
    5a6b:	75 70                	jne    0x5add
    5a6d:	bf e7 4c             	mov    di,0x4ce7
    5a70:	0e                   	push   cs
    5a71:	57                   	push   di
    5a72:	8d be 00 ff          	lea    di,[bp-0x100]
    5a76:	16                   	push   ss
    5a77:	57                   	push   di
    5a78:	68 ff 00             	push   0xff
    5a7b:	9a e7 17 aa 5a       	call   0x5aaa:0x17e7
    5a80:	8d be 00 ff          	lea    di,[bp-0x100]
    5a84:	16                   	push   ss
    5a85:	57                   	push   di
    5a86:	68 ff 00             	push   0xff
    5a89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a8c:	26 ff b5 4a 03       	push   WORD PTR es:[di+0x34a]
    5a91:	26 ff b5 48 03       	push   WORD PTR es:[di+0x348]
    5a96:	55                   	push   bp
    5a97:	9a 51 49 2f 5b       	call   0x5b2f:0x4951
    5a9c:	8d be f6 fd          	lea    di,[bp-0x20a]
    5aa0:	16                   	push   ss
    5aa1:	57                   	push   di
    5aa2:	bf cb 4c             	mov    di,0x4ccb
    5aa5:	0e                   	push   cs
    5aa6:	57                   	push   di
    5aa7:	9a cd 17 b5 5a       	call   0x5ab5:0x17cd
    5aac:	8d be 00 ff          	lea    di,[bp-0x100]
    5ab0:	16                   	push   ss
    5ab1:	57                   	push   di
    5ab2:	9a 4c 18 c3 5a       	call   0x5ac3:0x184c
    5ab7:	8d be 00 ff          	lea    di,[bp-0x100]
    5abb:	16                   	push   ss
    5abc:	57                   	push   di
    5abd:	68 ff 00             	push   0xff
    5ac0:	9a e7 17 fb 5a       	call   0x5afb:0x17e7
    5ac5:	8d be 00 ff          	lea    di,[bp-0x100]
    5ac9:	16                   	push   ss
    5aca:	57                   	push   di
    5acb:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5acf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5ad4:	06                   	push   es
    5ad5:	57                   	push   di
    5ad6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ad9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5add:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    5ae2:	7d 03                	jge    0x5ae7
    5ae4:	e9 fd 00             	jmp    0x5be4
    5ae7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5aec:	8d be f6 fd          	lea    di,[bp-0x20a]
    5af0:	16                   	push   ss
    5af1:	57                   	push   di
    5af2:	8d be 00 ff          	lea    di,[bp-0x100]
    5af6:	16                   	push   ss
    5af7:	57                   	push   di
    5af8:	9a cd 17 05 5b       	call   0x5b05:0x17cd
    5afd:	bf e7 4c             	mov    di,0x4ce7
    5b00:	0e                   	push   cs
    5b01:	57                   	push   di
    5b02:	9a 4c 18 13 5b       	call   0x5b13:0x184c
    5b07:	8d be 00 ff          	lea    di,[bp-0x100]
    5b0b:	16                   	push   ss
    5b0c:	57                   	push   di
    5b0d:	68 ff 00             	push   0xff
    5b10:	9a e7 17 12 5c       	call   0x5c12:0x17e7
    5b15:	8d be 00 ff          	lea    di,[bp-0x100]
    5b19:	16                   	push   ss
    5b1a:	57                   	push   di
    5b1b:	68 ff 00             	push   0xff
    5b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b21:	26 ff b5 ce 02       	push   WORD PTR es:[di+0x2ce]
    5b26:	26 ff b5 cc 02       	push   WORD PTR es:[di+0x2cc]
    5b2b:	55                   	push   bp
    5b2c:	9a 51 49 52 5b       	call   0x5b52:0x4951
    5b31:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    5b36:	7e 1c                	jle    0x5b54
    5b38:	8d be 00 ff          	lea    di,[bp-0x100]
    5b3c:	16                   	push   ss
    5b3d:	57                   	push   di
    5b3e:	68 ff 00             	push   0xff
    5b41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b44:	26 ff b5 c6 02       	push   WORD PTR es:[di+0x2c6]
    5b49:	26 ff b5 c4 02       	push   WORD PTR es:[di+0x2c4]
    5b4e:	55                   	push   bp
    5b4f:	9a 51 49 8b 5b       	call   0x5b8b:0x4951
    5b54:	8d be 00 ff          	lea    di,[bp-0x100]
    5b58:	16                   	push   ss
    5b59:	57                   	push   di
    5b5a:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5b5e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b63:	06                   	push   es
    5b64:	57                   	push   di
    5b65:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b68:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5b6c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5b71:	8d be 00 ff          	lea    di,[bp-0x100]
    5b75:	16                   	push   ss
    5b76:	57                   	push   di
    5b77:	68 ff 00             	push   0xff
    5b7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b7d:	26 ff b5 d2 02       	push   WORD PTR es:[di+0x2d2]
    5b82:	26 ff b5 d0 02       	push   WORD PTR es:[di+0x2d0]
    5b87:	55                   	push   bp
    5b88:	9a 51 49 a7 5b       	call   0x5ba7:0x4951
    5b8d:	8d be 00 ff          	lea    di,[bp-0x100]
    5b91:	16                   	push   ss
    5b92:	57                   	push   di
    5b93:	68 ff 00             	push   0xff
    5b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b99:	26 ff b5 d6 02       	push   WORD PTR es:[di+0x2d6]
    5b9e:	26 ff b5 d4 02       	push   WORD PTR es:[di+0x2d4]
    5ba3:	55                   	push   bp
    5ba4:	9a 51 49 ca 5b       	call   0x5bca:0x4951
    5ba9:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    5bae:	7e 1c                	jle    0x5bcc
    5bb0:	8d be 00 ff          	lea    di,[bp-0x100]
    5bb4:	16                   	push   ss
    5bb5:	57                   	push   di
    5bb6:	68 ff 00             	push   0xff
    5bb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bbc:	26 ff b5 da 02       	push   WORD PTR es:[di+0x2da]
    5bc1:	26 ff b5 d8 02       	push   WORD PTR es:[di+0x2d8]
    5bc6:	55                   	push   bp
    5bc7:	9a 51 49 ff ff       	call   0xffff:0x4951
    5bcc:	8d be 00 ff          	lea    di,[bp-0x100]
    5bd0:	16                   	push   ss
    5bd1:	57                   	push   di
    5bd2:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5bd6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5bdb:	06                   	push   es
    5bdc:	57                   	push   di
    5bdd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5be0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5be4:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5be8:	06                   	push   es
    5be9:	57                   	push   di
    5bea:	9a 3f 4a f8 5b       	call   0x5bf8:0x4a3f
    5bef:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5bf3:	06                   	push   es
    5bf4:	57                   	push   di
    5bf5:	9a ff 49 03 5c       	call   0x5c03:0x49ff
    5bfa:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    5bfe:	06                   	push   es
    5bff:	57                   	push   di
    5c00:	9a e3 49 ff ff       	call   0xffff:0x49e3
    5c05:	c9                   	leave
    5c06:	ca 08 00             	retf   0x8
    5c09:	55                   	push   bp
    5c0a:	89 e5                	mov    bp,sp
    5c0c:	b8 08 00             	mov    ax,0x8
    5c0f:	9a 44 04 28 5c       	call   0x5c28:0x444
    5c14:	83 ec 08             	sub    sp,0x8
    5c17:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c1a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c1d:	bf ac 04             	mov    di,0x4ac
    5c20:	b8 ff ff             	mov    ax,0xffff
    5c23:	50                   	push   ax
    5c24:	57                   	push   di
    5c25:	9a 73 22 8b 5c       	call   0x5c8b:0x2273
    5c2a:	89 c7                	mov    di,ax
    5c2c:	8e c2                	mov    es,dx
    5c2e:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    5c32:	99                   	cwd
    5c33:	b9 02 00             	mov    cx,0x2
    5c36:	f7 f9                	idiv   cx
    5c38:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5c3b:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    5c3f:	99                   	cwd
    5c40:	b9 02 00             	mov    cx,0x2
    5c43:	f7 f9                	idiv   cx
    5c45:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5c48:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5c4b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5c4e:	06                   	push   es
    5c4f:	57                   	push   di
    5c50:	9a d4 19 a5 5c       	call   0x5ca5:0x19d4
    5c55:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5c58:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5c5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c5e:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    5c63:	26 c6 45 25 00       	mov    BYTE PTR es:[di+0x25],0x0
    5c68:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5c6b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5c6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c71:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    5c76:	06                   	push   es
    5c77:	57                   	push   di
    5c78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c7b:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    5c7f:	c9                   	leave
    5c80:	ca 08 00             	retf   0x8
    5c83:	55                   	push   bp
    5c84:	89 e5                	mov    bp,sp
    5c86:	31 c0                	xor    ax,ax
    5c88:	9a 44 04 cf 5c       	call   0x5ccf:0x444
    5c8d:	9a c6 34 ff ff       	call   0xffff:0x34c6
    5c92:	08 c0                	or     al,al
    5c94:	74 2c                	je     0x5cc2
    5c96:	6a 00                	push   0x0
    5c98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c9b:	26 c4 bd 64 02       	les    di,DWORD PTR es:[di+0x264]
    5ca0:	06                   	push   es
    5ca1:	57                   	push   di
    5ca2:	9a 77 1c c0 5c       	call   0x5cc0:0x1c77
    5ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5caa:	06                   	push   es
    5cab:	57                   	push   di
    5cac:	9a 2d 5a c1 5d       	call   0x5dc1:0x5a2d
    5cb1:	6a 01                	push   0x1
    5cb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cb6:	26 c4 bd 64 02       	les    di,DWORD PTR es:[di+0x264]
    5cbb:	06                   	push   es
    5cbc:	57                   	push   di
    5cbd:	9a 77 1c e3 5c       	call   0x5ce3:0x1c77
    5cc2:	c9                   	leave
    5cc3:	ca 08 00             	retf   0x8
    5cc6:	55                   	push   bp
    5cc7:	89 e5                	mov    bp,sp
    5cc9:	b8 14 00             	mov    ax,0x14
    5ccc:	9a 44 04 3a 5d       	call   0x5d3a:0x444
    5cd1:	83 ec 14             	sub    sp,0x14
    5cd4:	6a 00                	push   0x0
    5cd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cd9:	26 c4 bd 64 02       	les    di,DWORD PTR es:[di+0x264]
    5cde:	06                   	push   es
    5cdf:	57                   	push   di
    5ce0:	9a 77 1c f6 5c       	call   0x5cf6:0x1c77
    5ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ce8:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    5cec:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5cf1:	06                   	push   es
    5cf2:	57                   	push   di
    5cf3:	9a bf 17 09 5d       	call   0x5d09:0x17bf
    5cf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cfb:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    5cff:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5d04:	06                   	push   es
    5d05:	57                   	push   di
    5d06:	9a e1 17 23 5d       	call   0x5d23:0x17e1
    5d0b:	31 c0                	xor    ax,ax
    5d0d:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    5d10:	31 c0                	xor    ax,ax
    5d12:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    5d15:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5d18:	ff 76 ec             	push   WORD PTR [bp-0x14]
    5d1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d1e:	06                   	push   es
    5d1f:	57                   	push   di
    5d20:	9a d4 19 b2 5d       	call   0x5db2:0x19d4
    5d25:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    5d28:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    5d2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d2e:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    5d32:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    5d35:	71 05                	jno    0x5d3c
    5d37:	9a 3e 04 4e 5d       	call   0x5d4e:0x43e
    5d3c:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    5d3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d42:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    5d46:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    5d49:	71 05                	jno    0x5d50
    5d4b:	9a 3e 04 62 5d       	call   0x5d62:0x43e
    5d50:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    5d53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d56:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    5d5a:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    5d5d:	71 05                	jno    0x5d64
    5d5f:	9a 3e 04 76 5d       	call   0x5d76:0x43e
    5d64:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5d67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d6a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    5d6e:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    5d71:	71 05                	jno    0x5d78
    5d73:	9a 3e 04 ff ff       	call   0xffff:0x43e
    5d78:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    5d7b:	31 c0                	xor    ax,ax
    5d7d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5d80:	31 c0                	xor    ax,ax
    5d82:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5d85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d88:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5d8d:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    5d91:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d97:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5d9c:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    5da0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5da3:	6a 00                	push   0x0
    5da5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5da8:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5dad:	06                   	push   es
    5dae:	57                   	push   di
    5daf:	9a 77 1c 12 5e       	call   0x5e12:0x1c77
    5db4:	8d 7e f8             	lea    di,[bp-0x8]
    5db7:	16                   	push   ss
    5db8:	57                   	push   di
    5db9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dbc:	06                   	push   es
    5dbd:	57                   	push   di
    5dbe:	9a d5 33 ff ff       	call   0xffff:0x33d5
    5dc3:	52                   	push   dx
    5dc4:	50                   	push   ax
    5dc5:	8d 7e f0             	lea    di,[bp-0x10]
    5dc8:	16                   	push   ss
    5dc9:	57                   	push   di
    5dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dcd:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5dd2:	06                   	push   es
    5dd3:	57                   	push   di
    5dd4:	9a 94 1f ff ff       	call   0xffff:0x1f94
    5dd9:	89 c7                	mov    di,ax
    5ddb:	8e c2                	mov    es,dx
    5ddd:	06                   	push   es
    5dde:	57                   	push   di
    5ddf:	9a 10 1b ff ff       	call   0xffff:0x1b10
    5de4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5de7:	26 c4 bd 60 02       	les    di,DWORD PTR es:[di+0x260]
    5dec:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    5df1:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    5df6:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    5dfa:	06                   	push   es
    5dfb:	57                   	push   di
    5dfc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5dff:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    5e03:	6a 01                	push   0x1
    5e05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e08:	26 c4 bd 64 02       	les    di,DWORD PTR es:[di+0x264]
    5e0d:	06                   	push   es
    5e0e:	57                   	push   di
    5e0f:	9a 77 1c ff ff       	call   0xffff:0x1c77
    5e14:	c9                   	leave
    5e15:	ca                   	.byte 0xca
    5e16:	08                   	.byte 0x8
