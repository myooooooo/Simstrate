; ================================================================
; seg11_CODE  (17963 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	0b 00                	or     ax,WORD PTR [bx+si]
       2:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
       3:	0d 16 03             	or     ax,0x316
       6:	ae                   	scas   al,BYTE PTR es:[di]
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 4e          	add    BYTE PTR [bp+0x4e00],bl
       d:	05 fb 04             	add    ax,0x4fb
      10:	bb 0d 39             	mov    bx,0x390d
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f ce 0d cb       	call   0xcb0d:0xce1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 78 1a             	adc    BYTE PTR [bx+si+0x1a],bh
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 80                	sbb    al,0x80
      61:	0e                   	push   cs
      62:	e2 2f                	loop   0x93
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	42                   	inc    dx
      a8:	5f                   	pop    di
      a9:	42                   	inc    dx
      aa:	69 6c 61 6e 20       	imul   bp,WORD PTR [si+0x61],0x206e
      af:	00 e9                	add    cl,ch
      b1:	2f                   	das
      b2:	c2 00 0b             	ret    0xb00
      b5:	49                   	dec    cx
      b6:	6e                   	outs   dx,BYTE PTR ds:[si]
      b7:	64 65 78 31          	fs gs js 0xec
      bb:	43                   	inc    bx
      bc:	6c                   	ins    BYTE PTR es:[di],dx
      bd:	69 63 6b 08 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3008
      c2:	d7                   	xlat   BYTE PTR ds:[bx]
      c3:	00 10                	add    BYTE PTR [bx+si],dl
      c5:	52                   	push   dx
      c6:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
      ca:	72 63                	jb     0x12f
      cc:	68 65 72             	push   0x7265
      cf:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      d2:	69 63 6b 2e 10       	imul   sp,WORD PTR [bp+di+0x6b],0x102e
      d7:	ea 00 0e 49 6d       	jmp    0x6d49:0xe00
      dc:	70 72                	jo     0x150
      de:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      e3:	43                   	inc    bx
      e4:	6c                   	ins    BYTE PTR es:[di],dx
      e5:	69 63 6b 3b 24       	imul   sp,WORD PTR [bp+di+0x6b],0x243b
      ea:	fc                   	cld
      eb:	00 0d                	add    BYTE PTR [di],cl
      ed:	51                   	push   cx
      ee:	75 69                	jne    0x159
      f0:	74 74                	je     0x166
      f2:	65 72 31             	gs jb  0x126
      f5:	43                   	inc    bx
      f6:	6c                   	ins    BYTE PTR es:[di],dx
      f7:	69 63 6b 53 24       	imul   sp,WORD PTR [bp+di+0x6b],0x2453
      fc:	11 01                	adc    WORD PTR [bx+di],ax
      fe:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
     101:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     107:	61                   	popa
     108:	6e                   	outs   dx,BYTE PTR ds:[si]
     109:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     10c:	69 63 6b 29 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3029
     111:	29 01                	sub    WORD PTR [bx+di],ax
     113:	13 55 74             	adc    dx,WORD PTR [di+0x74]
     116:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     11b:	72 6c                	jb     0x189
     11d:	61                   	popa
     11e:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     123:	6c                   	ins    BYTE PTR es:[di],dx
     124:	69 63 6b 48 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3048
     129:	3b 01                	cmp    ax,WORD PTR [bx+di]
     12b:	0d 41 70             	or     ax,0x7041
     12e:	72 6f                	jb     0x19f
     130:	70 6f                	jo     0x1a1
     132:	73 31                	jae    0x165
     134:	43                   	inc    bx
     135:	6c                   	ins    BYTE PTR es:[di],dx
     136:	69 63 6b f2 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2df2
     13b:	4b                   	dec    bx
     13c:	01 0b                	add    WORD PTR [bp+di],cx
     13e:	46                   	inc    si
     13f:	6f                   	outs   dx,WORD PTR ds:[si]
     140:	72 6d                	jb     0x1af
     142:	4b                   	dec    bx
     143:	65 79 44             	gs jns 0x18a
     146:	6f                   	outs   dx,WORD PTR ds:[si]
     147:	77 6e                	ja     0x1b7
     149:	2a 20                	sub    ah,BYTE PTR [bx+si]
     14b:	5a                   	pop    dx
     14c:	01 0a                	add    WORD PTR [bp+si],cx
     14e:	46                   	inc    si
     14f:	6f                   	outs   dx,WORD PTR ds:[si]
     150:	72 6d                	jb     0x1bf
     152:	43                   	inc    bx
     153:	72 65                	jb     0x1ba
     155:	61                   	popa
     156:	74 65                	je     0x1bd
     158:	1c 24                	sbb    al,0x24
     15a:	68 01 09             	push   0x901
     15d:	46                   	inc    si
     15e:	6f                   	outs   dx,WORD PTR ds:[si]
     15f:	72 6d                	jb     0x1ce
     161:	43                   	inc    bx
     162:	6c                   	ins    BYTE PTR es:[di],dx
     163:	6f                   	outs   dx,WORD PTR ds:[si]
     164:	73 65                	jae    0x1cb
     166:	95                   	xchg   bp,ax
     167:	27                   	daa
     168:	77 01                	ja     0x16b
     16a:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     16d:	72 6d                	jb     0x1dc
     16f:	52                   	push   dx
     170:	65 73 69             	gs jae 0x1dc
     173:	7a 65                	jp     0x1da
     175:	d5 28                	aad    0x28
     177:	8e 01                	mov    es,WORD PTR [bx+di]
     179:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     17c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     17f:	45                   	inc    bp
     180:	52                   	push   dx
     181:	47                   	inc    di
     182:	43                   	inc    bx
     183:	61                   	popa
     184:	6c                   	ins    BYTE PTR es:[di],dx
     185:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     188:	65 6c                	gs ins BYTE PTR es:[di],dx
     18a:	64 73 ac             	fs jae 0x139
     18d:	25 a0 01             	and    ax,0x1a0
     190:	0d 50 65             	or     ax,0x6550
     193:	72 69                	jb     0x1fe
     195:	6f                   	outs   dx,WORD PTR ds:[si]
     196:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     19b:	69 63 6b f1 26       	imul   sp,WORD PTR [bp+di+0x6b],0x26f1
     1a0:	ad                   	lods   ax,WORD PTR ds:[si]
     1a1:	01 08                	add    WORD PTR [bx+si],cx
     1a3:	4e                   	dec    si
     1a4:	31 31                	xor    WORD PTR [bx+di],si
     1a6:	43                   	inc    bx
     1a7:	6c                   	ins    BYTE PTR es:[di],dx
     1a8:	69 63 6b 9f 15       	imul   sp,WORD PTR [bp+di+0x6b],0x159f
     1ad:	bd 01 0b             	mov    bp,0xb01
     1b0:	44                   	inc    sp
     1b1:	42                   	inc    dx
     1b2:	45                   	inc    bp
     1b3:	64 69 74 31 45 78    	imul   si,WORD PTR fs:[si+0x31],0x7845
     1b9:	69 74 ec 15 ce       	imul   si,WORD PTR [si-0x14],0xce15
     1be:	01 0c                	add    WORD PTR [si],cx
     1c0:	44                   	inc    sp
     1c1:	42                   	inc    dx
     1c2:	45                   	inc    bp
     1c3:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1c9:	79 55                	jns    0x220
     1cb:	70 4f                	jo     0x21c
     1cd:	16                   	push   ss
     1ce:	e1 01                	loope  0x1d1
     1d0:	0e                   	push   cs
     1d1:	44                   	inc    sp
     1d2:	42                   	inc    dx
     1d3:	45                   	inc    bp
     1d4:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1da:	79 44                	jns    0x220
     1dc:	6f                   	outs   dx,WORD PTR ds:[si]
     1dd:	77 6e                	ja     0x24d
     1df:	01 24                	add    WORD PTR [si],sp
     1e1:	ee                   	out    dx,al
     1e2:	01 08                	add    WORD PTR [bx+si],cx
     1e4:	46                   	inc    si
     1e5:	6f                   	outs   dx,WORD PTR ds:[si]
     1e6:	72 6d                	jb     0x255
     1e8:	53                   	push   bx
     1e9:	68 6f 77             	push   0x776f
     1ec:	e0 30                	loopne 0x21e
     1ee:	03 02                	add    ax,WORD PTR [bp+si]
     1f0:	10 44 42             	adc    BYTE PTR [si+0x42],al
     1f3:	45                   	inc    bp
     1f4:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     1fa:	75 73                	jne    0x26f
     1fc:	65 44                	gs inc sp
     1fe:	6f                   	outs   dx,WORD PTR ds:[si]
     1ff:	77 6e                	ja     0x26f
     201:	be 2f 13             	mov    si,0x132f
     204:	02 0b                	add    cl,BYTE PTR [bp+di]
     206:	46                   	inc    si
     207:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     20c:	43                   	inc    bx
     20d:	6c                   	ins    BYTE PTR es:[di],dx
     20e:	69 63 6b f2 36       	imul   sp,WORD PTR [bp+di+0x6b],0x36f2
     213:	24 02                	and    al,0x2
     215:	0c 43                	or     al,0x43
     217:	6f                   	outs   dx,WORD PTR ds:[si]
     218:	70 69                	jo     0x283
     21a:	65 72 31             	gs jb  0x24e
     21d:	43                   	inc    bx
     21e:	6c                   	ins    BYTE PTR es:[di],dx
     21f:	69 63 6b 97 31       	imul   sp,WORD PTR [bp+di+0x6b],0x3197
     224:	39 02                	cmp    WORD PTR [bp+si],ax
     226:	10 50 61             	adc    BYTE PTR [bx+si+0x61],dl
     229:	6e                   	outs   dx,BYTE PTR ds:[si]
     22a:	65 6c                	gs ins BYTE PTR es:[di],dx
     22c:	31 30                	xor    WORD PTR [bx+si],si
     22e:	4d                   	dec    bp
     22f:	6f                   	outs   dx,WORD PTR ds:[si]
     230:	75 73                	jne    0x2a5
     232:	65 44                	gs inc sp
     234:	6f                   	outs   dx,WORD PTR ds:[si]
     235:	77 6e                	ja     0x2a5
     237:	f4                   	hlt
     238:	44                   	inc    sp
     239:	4d                   	dec    bp
     23a:	02 0f                	add    cl,BYTE PTR [bx]
     23c:	53                   	push   bx
     23d:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     242:	69 6f 6e 31 43       	imul   bp,WORD PTR [bx+0x6e],0x4331
     247:	6c                   	ins    BYTE PTR es:[di],dx
     248:	69 63 6b 22 45       	imul   sp,WORD PTR [bp+di+0x6b],0x4522
     24d:	69 02 17 43          	imul   ax,WORD PTR [bp+si],0x4317
     251:	6f                   	outs   dx,WORD PTR ds:[si]
     252:	6d                   	ins    WORD PTR es:[di],dx
     253:	70 74                	jo     0x2c9
     255:	65 44                	gs inc sp
     257:	65 52                	gs push dx
     259:	65 73 75             	gs jae 0x2d1
     25c:	6c                   	ins    BYTE PTR es:[di],dx
     25d:	74 61                	je     0x2c0
     25f:	74 73                	je     0x2d4
     261:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     264:	69 63 6b 50 45       	imul   sp,WORD PTR [bp+di+0x6b],0x4550
     269:	79 02                	jns    0x26d
     26b:	0b 42 69             	or     ax,WORD PTR [bp+si+0x69]
     26e:	6c                   	ins    BYTE PTR es:[di],dx
     26f:	61                   	popa
     270:	6e                   	outs   dx,BYTE PTR ds:[si]
     271:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     274:	69 63 6b 7e 45       	imul   sp,WORD PTR [bp+di+0x6b],0x457e
     279:	98                   	cbw
     27a:	02 1a                	add    bl,BYTE PTR [bp+si]
     27c:	54                   	push   sp
     27d:	61                   	popa
     27e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     281:	61                   	popa
     282:	75 44                	jne    0x2c8
     284:	65 46                	gs inc si
     286:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     28b:	65 6d                	gs ins WORD PTR es:[di],dx
     28d:	65 6e                	outs   dx,BYTE PTR gs:[si]
     28f:	74 31                	je     0x2c2
     291:	43                   	inc    bx
     292:	6c                   	ins    BYTE PTR es:[di],dx
     293:	69 63 6b ac 45       	imul   sp,WORD PTR [bp+di+0x6b],0x45ac
     298:	b6 02                	mov    dh,0x2
     29a:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     29d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2a0:	61                   	popa
     2a1:	75 44                	jne    0x2e7
     2a3:	65 54                	gs push sp
     2a5:	72 65                	jb     0x30c
     2a7:	73 6f                	jae    0x318
     2a9:	72 65                	jb     0x310
     2ab:	72 69                	jb     0x316
     2ad:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2b1:	69 63 6b 08 46       	imul   sp,WORD PTR [bp+di+0x6b],0x4608
     2b6:	d3 02                	rol    WORD PTR [bp+si],cl
     2b8:	18 52 61             	sbb    BYTE PTR [bp+si+0x61],dl
     2bb:	70 70                	jo     0x32d
     2bd:	65 6c                	gs ins BYTE PTR es:[di],dx
     2bf:	44                   	inc    sp
     2c0:	65 73 44             	gs jae 0x307
     2c3:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     2c7:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     2cc:	43                   	inc    bx
     2cd:	6c                   	ins    BYTE PTR es:[di],dx
     2ce:	69 63 6b 8f 24       	imul   sp,WORD PTR [bp+di+0x6b],0x248f
     2d3:	e2 02                	loop   0x2d7
     2d5:	0a 4e 31             	or     cl,BYTE PTR [bp+0x31]
     2d8:	30 30                	xor    BYTE PTR [bx+si],dh
     2da:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2dd:	69 63 6b 00 32       	imul   sp,WORD PTR [bp+di+0x6b],0x3200
     2e2:	fd                   	std
     2e3:	02 16 49 6d          	add    dl,BYTE PTR ds:0x6d49
     2e7:	70 72                	jo     0x35b
     2e9:	65 73 73             	gs jae 0x35f
     2ec:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     2f1:	70 69                	jo     0x35c
     2f3:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     2f8:	69 63 6b f3 25       	imul   sp,WORD PTR [bp+di+0x6b],0x25f3
     2fd:	0a 03                	or     al,BYTE PTR [bp+di]
     2ff:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     302:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     305:	69 63 6b da 45       	imul   sp,WORD PTR [bp+di+0x6b],0x45da
     30a:	b7 0d                	mov    bh,0xd
     30c:	09 53 49             	or     WORD PTR [bp+di+0x49],dx
     30f:	47                   	inc    di
     310:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     313:	69 63 6b b3 00       	imul   sp,WORD PTR [bp+di+0x6b],0xb3
     318:	66 0d 7c 01 00 00    	or     eax,0x17c
     31e:	06                   	push   es
     31f:	50                   	push   ax
     320:	61                   	popa
     321:	6e                   	outs   dx,BYTE PTR ds:[si]
     322:	65 6c                	gs ins BYTE PTR es:[di],dx
     324:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     328:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     32c:	6e                   	outs   dx,BYTE PTR ds:[si]
     32d:	65 6c                	gs ins BYTE PTR es:[di],dx
     32f:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     333:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     337:	6e                   	outs   dx,BYTE PTR ds:[si]
     338:	65 6c                	gs ins BYTE PTR es:[di],dx
     33a:	35 88 01             	xor    ax,0x188
     33d:	00 00                	add    BYTE PTR [bx+si],al
     33f:	06                   	push   es
     340:	50                   	push   ax
     341:	61                   	popa
     342:	6e                   	outs   dx,BYTE PTR ds:[si]
     343:	65 6c                	gs ins BYTE PTR es:[di],dx
     345:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     349:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     34d:	6e                   	outs   dx,BYTE PTR ds:[si]
     34e:	65 6c                	gs ins BYTE PTR es:[di],dx
     350:	36 90                	ss nop
     352:	01 00                	add    WORD PTR [bx+si],ax
     354:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     358:	6e                   	outs   dx,BYTE PTR ds:[si]
     359:	65 6c                	gs ins BYTE PTR es:[di],dx
     35b:	37                   	aaa
     35c:	94                   	xchg   sp,ax
     35d:	01 00                	add    WORD PTR [bx+si],ax
     35f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     363:	6e                   	outs   dx,BYTE PTR ds:[si]
     364:	65 6c                	gs ins BYTE PTR es:[di],dx
     366:	38 98 01 00          	cmp    BYTE PTR [bx+si+0x1],bl
     36a:	00 07                	add    BYTE PTR [bx],al
     36c:	50                   	push   ax
     36d:	61                   	popa
     36e:	6e                   	outs   dx,BYTE PTR ds:[si]
     36f:	65 6c                	gs ins BYTE PTR es:[di],dx
     371:	33 37                	xor    si,WORD PTR [bx]
     373:	9c                   	pushf
     374:	01 00                	add    WORD PTR [bx+si],ax
     376:	00 07                	add    BYTE PTR [bx],al
     378:	50                   	push   ax
     379:	61                   	popa
     37a:	6e                   	outs   dx,BYTE PTR ds:[si]
     37b:	65 6c                	gs ins BYTE PTR es:[di],dx
     37d:	33 38                	xor    di,WORD PTR [bx+si]
     37f:	a0 01 04             	mov    al,ds:0x401
     382:	00 09                	add    BYTE PTR [bx+di],cl
     384:	4d                   	dec    bp
     385:	61                   	popa
     386:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     38b:	75 31                	jne    0x3be
     38d:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     38e:	01 08                	add    WORD PTR [bx+si],cx
     390:	00 08                	add    BYTE PTR [bx+si],cl
     392:	46                   	inc    si
     393:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     398:	72 31                	jb     0x3cb
     39a:	a8 01                	test   al,0x1
     39c:	08 00                	or     BYTE PTR [bx+si],al
     39e:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     3a1:	70 72                	jo     0x415
     3a3:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     3a8:	ac                   	lods   al,BYTE PTR ds:[si]
     3a9:	01 08                	add    WORD PTR [bx+si],cx
     3ab:	00 02                	add    BYTE PTR [bp+si],al
     3ad:	4e                   	dec    si
     3ae:	31 b0 01 08          	xor    WORD PTR [bx+si+0x801],si
     3b2:	00 08                	add    BYTE PTR [bx+si],cl
     3b4:	51                   	push   cx
     3b5:	75 69                	jne    0x420
     3b7:	74 74                	je     0x42d
     3b9:	65 72 31             	gs jb  0x3ed
     3bc:	b4 01                	mov    ah,0x1
     3be:	08 00                	or     BYTE PTR [bx+si],al
     3c0:	0a 41 66             	or     al,BYTE PTR [bx+di+0x66]
     3c3:	66 69 63 68 61 67 65 	imul   esp,DWORD PTR [bp+di+0x68],0x31656761
     3ca:	31 
     3cb:	b8 01 08             	mov    ax,0x801
     3ce:	00 0d                	add    BYTE PTR [di],cl
     3d0:	42                   	inc    dx
     3d1:	61                   	popa
     3d2:	72 72                	jb     0x446
     3d4:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     3d7:	75 74                	jne    0x44d
     3d9:	69 6c 73 31 bc       	imul   bp,WORD PTR [si+0x73],0xbc31
     3de:	01 08                	add    WORD PTR [bx+si],cx
     3e0:	00 0b                	add    BYTE PTR [bp+di],cl
     3e2:	50                   	push   ax
     3e3:	6c                   	ins    BYTE PTR es:[di],dx
     3e4:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     3ea:	61                   	popa
     3eb:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ec:	31 c0                	xor    ax,ax
     3ee:	01 08                	add    WORD PTR [bx+si],cx
     3f0:	00 02                	add    BYTE PTR [bp+si],al
     3f2:	4e                   	dec    si
     3f3:	32 c4                	xor    al,ah
     3f5:	01 08                	add    WORD PTR [bx+si],cx
     3f7:	00 05                	add    BYTE PTR [di],al
     3f9:	5a                   	pop    dx
     3fa:	6f                   	outs   dx,WORD PTR ds:[si]
     3fb:	6f                   	outs   dx,WORD PTR ds:[si]
     3fc:	6d                   	ins    WORD PTR es:[di],dx
     3fd:	31 c8                	xor    ax,cx
     3ff:	01 08                	add    WORD PTR [bx+si],cx
     401:	00 05                	add    BYTE PTR [di],al
     403:	41                   	inc    cx
     404:	69 64 65 31 cc       	imul   sp,WORD PTR [si+0x65],0xcc31
     409:	01 08                	add    WORD PTR [bx+si],cx
     40b:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     40f:	64 65 78 31          	fs gs js 0x444
     413:	d0 01                	rol    BYTE PTR [bx+di],1
     415:	08 00                	or     BYTE PTR [bx+si],al
     417:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     41a:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     41d:	72 63                	jb     0x482
     41f:	68 65 72             	push   0x7265
     422:	31 d4                	xor    sp,dx
     424:	01 08                	add    WORD PTR [bx+si],cx
     426:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     42a:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     42f:	72 6c                	jb     0x49d
     431:	61                   	popa
     432:	69 64 65 31 d8       	imul   sp,WORD PTR [si+0x65],0xd831
     437:	01 08                	add    WORD PTR [bx+si],cx
     439:	00 08                	add    BYTE PTR [bx+si],cl
     43b:	41                   	inc    cx
     43c:	70 72                	jo     0x4b0
     43e:	6f                   	outs   dx,WORD PTR ds:[si]
     43f:	70 6f                	jo     0x4b0
     441:	73 31                	jae    0x474
     443:	dc 01                	fadd   QWORD PTR [bx+di]
     445:	0c 00                	or     al,0x0
     447:	08 54 61             	or     BYTE PTR [si+0x61],dl
     44a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     44d:	45                   	inc    bp
     44e:	52                   	push   dx
     44f:	47                   	inc    di
     450:	e0 01                	loopne 0x453
     452:	0c 00                	or     al,0x0
     454:	09 54 61             	or     WORD PTR [si+0x61],dx
     457:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     45a:	45                   	inc    bp
     45b:	52                   	push   dx
     45c:	50                   	push   ax
     45d:	31 e4                	xor    sp,sp
     45f:	01 0c                	add    WORD PTR [si],cx
     461:	00 09                	add    BYTE PTR [bx+di],cl
     463:	54                   	push   sp
     464:	61                   	popa
     465:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     468:	45                   	inc    bp
     469:	52                   	push   dx
     46a:	50                   	push   ax
     46b:	32 e8                	xor    ch,al
     46d:	01 10                	add    WORD PTR [bx+si],dx
     46f:	00 0d                	add    BYTE PTR [di],cl
     471:	44                   	inc    sp
     472:	61                   	popa
     473:	74 61                	je     0x4d6
     475:	53                   	push   bx
     476:	6f                   	outs   dx,WORD PTR ds:[si]
     477:	75 72                	jne    0x4eb
     479:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     47c:	52                   	push   dx
     47d:	47                   	inc    di
     47e:	ec                   	in     al,dx
     47f:	01 08                	add    WORD PTR [bx+si],cx
     481:	00 08                	add    BYTE PTR [bx+si],cl
     483:	50                   	push   ax
     484:	65 72 69             	gs jb  0x4f0
     487:	6f                   	outs   dx,WORD PTR ds:[si]
     488:	64 65 31 f0          	fs gs xor ax,si
     48c:	01 08                	add    WORD PTR [bx+si],cx
     48e:	00 0b                	add    BYTE PTR [bp+di],cl
     490:	45                   	inc    bp
     491:	6e                   	outs   dx,BYTE PTR ds:[si]
     492:	74 72                	je     0x506
     494:	65 70 72             	gs jo  0x509
     497:	69 73 65 31 f4       	imul   si,WORD PTR [bp+di+0x65],0xf431
     49c:	01 14                	add    WORD PTR [si],dx
     49e:	00 0c                	add    BYTE PTR [si],cl
     4a0:	50                   	push   ax
     4a1:	72 69                	jb     0x50c
     4a3:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a4:	74 44                	je     0x4ea
     4a6:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     4ab:	31 f8                	xor    ax,di
     4ad:	01 18                	add    WORD PTR [bx+si],bx
     4af:	00 17                	add    BYTE PTR [bx],dl
     4b1:	54                   	push   sp
     4b2:	61                   	popa
     4b3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4b6:	45                   	inc    bp
     4b7:	52                   	push   dx
     4b8:	47                   	inc    di
     4b9:	41                   	inc    cx
     4ba:	63 74 69             	arpl   WORD PTR [si+0x69],si
     4bd:	66 49                	dec    ecx
     4bf:	6d                   	ins    WORD PTR es:[di],dx
     4c0:	6d                   	ins    WORD PTR es:[di],dx
     4c1:	6f                   	outs   dx,WORD PTR ds:[si]
     4c2:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     4c5:	69 73 65 fc 01       	imul   si,WORD PTR [bp+di+0x65],0x1fc
     4ca:	18 00                	sbb    BYTE PTR [bx+si],al
     4cc:	16                   	push   ss
     4cd:	54                   	push   sp
     4ce:	61                   	popa
     4cf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4d2:	45                   	inc    bp
     4d3:	52                   	push   dx
     4d4:	47                   	inc    di
     4d5:	41                   	inc    cx
     4d6:	63 74 69             	arpl   WORD PTR [si+0x69],si
     4d9:	66 43                	inc    ebx
     4db:	69 72 63 75 6c       	imul   si,WORD PTR [bp+si+0x63],0x6c75
     4e0:	61                   	popa
     4e1:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e2:	74 00                	je     0x4e4
     4e4:	02 18                	add    bl,BYTE PTR [bx+si]
     4e6:	00 0d                	add    BYTE PTR [di],cl
     4e8:	54                   	push   sp
     4e9:	61                   	popa
     4ea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4ed:	45                   	inc    bp
     4ee:	52                   	push   dx
     4ef:	47                   	inc    di
     4f0:	41                   	inc    cx
     4f1:	63 74 69             	arpl   WORD PTR [si+0x69],si
     4f4:	66 04 02             	data32 add al,0x2
     4f7:	18 00                	sbb    BYTE PTR [bx+si],al
     4f9:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     4fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4ff:	45                   	inc    bp
     500:	52                   	push   dx
     501:	47                   	inc    di
     502:	52                   	push   dx
     503:	65 73 73             	gs jae 0x579
     506:	6f                   	outs   dx,WORD PTR ds:[si]
     507:	75 72                	jne    0x57b
     509:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     50c:	50                   	push   ax
     50d:	72 6f                	jb     0x57e
     50f:	70 72                	jo     0x583
     511:	65 73 08             	gs jae 0x51c
     514:	02 18                	add    bl,BYTE PTR [bx+si]
     516:	00 1c                	add    BYTE PTR [si],bl
     518:	54                   	push   sp
     519:	61                   	popa
     51a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     51d:	45                   	inc    bp
     51e:	52                   	push   dx
     51f:	47                   	inc    di
     520:	52                   	push   dx
     521:	65 73 73             	gs jae 0x597
     524:	6f                   	outs   dx,WORD PTR ds:[si]
     525:	75 72                	jne    0x599
     527:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     52a:	45                   	inc    bp
     52b:	6d                   	ins    WORD PTR es:[di],dx
     52c:	70 72                	jo     0x5a0
     52e:	75 6e                	jne    0x59e
     530:	74 65                	je     0x597
     532:	65 73 0c             	gs jae 0x541
     535:	02 18                	add    bl,BYTE PTR [bx+si]
     537:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     53b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     53e:	45                   	inc    bp
     53f:	52                   	push   dx
     540:	47                   	inc    di
     541:	50                   	push   ax
     542:	61                   	popa
     543:	73 73                	jae    0x5b8
     545:	69 66 10 02 18       	imul   sp,WORD PTR [bp+0x10],0x1802
     54a:	00 13                	add    BYTE PTR [bp+di],dl
     54c:	54                   	push   sp
     54d:	61                   	popa
     54e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     551:	45                   	inc    bp
     552:	52                   	push   dx
     553:	47                   	inc    di
     554:	56                   	push   si
     555:	61                   	popa
     556:	6c                   	ins    BYTE PTR es:[di],dx
     557:	65 75 72             	gs jne 0x5cc
     55a:	53                   	push   bx
     55b:	74 6f                	je     0x5cc
     55d:	63 6b 14             	arpl   WORD PTR [bp+di+0x14],bp
     560:	02 08                	add    cl,BYTE PTR [bx+si]
     562:	00 03                	add    BYTE PTR [bp+di],al
     564:	4e                   	dec    si
     565:	31 31                	xor    WORD PTR [bx+di],si
     567:	18 02                	sbb    BYTE PTR [bp+si],al
     569:	08 00                	or     BYTE PTR [bx+si],al
     56b:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     56e:	31 1c                	xor    WORD PTR [si],bx
     570:	02 08                	add    cl,BYTE PTR [bx+si]
     572:	00 03                	add    BYTE PTR [bp+di],al
     574:	4e                   	dec    si
     575:	33 31                	xor    si,WORD PTR [bx+di]
     577:	20 02                	and    BYTE PTR [bp+si],al
     579:	08 00                	or     BYTE PTR [bx+si],al
     57b:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     57e:	31 24                	xor    WORD PTR [si],sp
     580:	02 08                	add    cl,BYTE PTR [bx+si]
     582:	00 03                	add    BYTE PTR [bp+di],al
     584:	4e                   	dec    si
     585:	35 31 28             	xor    ax,0x2831
     588:	02 08                	add    cl,BYTE PTR [bx+si]
     58a:	00 03                	add    BYTE PTR [bp+di],al
     58c:	4e                   	dec    si
     58d:	36 31 2c             	xor    WORD PTR ss:[si],bp
     590:	02 08                	add    cl,BYTE PTR [bx+si]
     592:	00 03                	add    BYTE PTR [bp+di],al
     594:	4e                   	dec    si
     595:	37                   	aaa
     596:	31 30                	xor    WORD PTR [bx+si],si
     598:	02 08                	add    cl,BYTE PTR [bx+si]
     59a:	00 03                	add    BYTE PTR [bp+di],al
     59c:	4e                   	dec    si
     59d:	38 31                	cmp    BYTE PTR [bx+di],dh
     59f:	34 02                	xor    al,0x2
     5a1:	00 00                	add    BYTE PTR [bx+si],al
     5a3:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     5a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     5a7:	65 6c                	gs ins BYTE PTR es:[di],dx
     5a9:	4c                   	dec    sp
     5aa:	4f                   	dec    di
     5ab:	55                   	push   bp
     5ac:	50                   	push   ax
     5ad:	45                   	inc    bp
     5ae:	38 02                	cmp    BYTE PTR [bp+si],al
     5b0:	1c 00                	sbb    al,0x0
     5b2:	11 54 61             	adc    WORD PTR [si+0x61],dx
     5b5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5b8:	45                   	inc    bp
     5b9:	52                   	push   dx
     5ba:	47                   	inc    di
     5bb:	50                   	push   ax
     5bc:	65 72 69             	gs jb  0x628
     5bf:	6f                   	outs   dx,WORD PTR ds:[si]
     5c0:	64 65 4e             	fs gs dec si
     5c3:	6f                   	outs   dx,WORD PTR ds:[si]
     5c4:	3c 02                	cmp    al,0x2
     5c6:	1c 00                	sbb    al,0x0
     5c8:	14 54                	adc    al,0x54
     5ca:	61                   	popa
     5cb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ce:	45                   	inc    bp
     5cf:	52                   	push   dx
     5d0:	47                   	inc    di
     5d1:	45                   	inc    bp
     5d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d3:	74 72                	je     0x647
     5d5:	65 70 72             	gs jo  0x64a
     5d8:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     5dd:	40                   	inc    ax
     5de:	02 20                	add    ah,BYTE PTR [bx+si]
     5e0:	00 15                	add    BYTE PTR [di],dl
     5e2:	54                   	push   sp
     5e3:	61                   	popa
     5e4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5e7:	45                   	inc    bp
     5e8:	52                   	push   dx
     5e9:	47                   	inc    di
     5ea:	43                   	inc    bx
     5eb:	61                   	popa
     5ec:	70 69                	jo     0x657
     5ee:	74 61                	je     0x651
     5f0:	6c                   	ins    BYTE PTR es:[di],dx
     5f1:	53                   	push   bx
     5f2:	6f                   	outs   dx,WORD PTR ds:[si]
     5f3:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     5f6:	6c                   	ins    BYTE PTR es:[di],dx
     5f7:	44                   	inc    sp
     5f8:	02 20                	add    ah,BYTE PTR [bx+si]
     5fa:	00 10                	add    BYTE PTR [bx+si],dl
     5fc:	54                   	push   sp
     5fd:	61                   	popa
     5fe:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     601:	45                   	inc    bp
     602:	52                   	push   dx
     603:	47                   	inc    di
     604:	52                   	push   dx
     605:	65 73 65             	gs jae 0x66d
     608:	72 76                	jb     0x680
     60a:	65 73 48             	gs jae 0x655
     60d:	02 20                	add    ah,BYTE PTR [bx+si]
     60f:	00 13                	add    BYTE PTR [bp+di],dl
     611:	54                   	push   sp
     612:	61                   	popa
     613:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     616:	45                   	inc    bp
     617:	52                   	push   dx
     618:	47                   	inc    di
     619:	52                   	push   dx
     61a:	65 73 75             	gs jae 0x692
     61d:	6c                   	ins    BYTE PTR es:[di],dx
     61e:	74 61                	je     0x681
     620:	74 4e                	je     0x670
     622:	65 74 4c             	gs je  0x671
     625:	02 20                	add    ah,BYTE PTR [bx+si]
     627:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     62b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     62e:	45                   	inc    bp
     62f:	52                   	push   dx
     630:	47                   	inc    di
     631:	53                   	push   bx
     632:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     637:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     63c:	74 74                	je     0x6b2
     63e:	65 50                	gs push ax
     640:	02 20                	add    ah,BYTE PTR [bx+si]
     642:	00 0b                	add    BYTE PTR [bp+di],cl
     644:	54                   	push   sp
     645:	61                   	popa
     646:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     649:	45                   	inc    bp
     64a:	52                   	push   dx
     64b:	47                   	inc    di
     64c:	43                   	inc    bx
     64d:	41                   	inc    cx
     64e:	46                   	inc    si
     64f:	54                   	push   sp
     650:	02 20                	add    ah,BYTE PTR [bx+si]
     652:	00 0d                	add    BYTE PTR [di],cl
     654:	54                   	push   sp
     655:	61                   	popa
     656:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     659:	45                   	inc    bp
     65a:	52                   	push   dx
     65b:	47                   	inc    di
     65c:	49                   	dec    cx
     65d:	6d                   	ins    WORD PTR es:[di],dx
     65e:	70 6f                	jo     0x6cf
     660:	74 58                	je     0x6ba
     662:	02 20                	add    ah,BYTE PTR [bx+si]
     664:	00 0b                	add    BYTE PTR [bp+di],cl
     666:	54                   	push   sp
     667:	61                   	popa
     668:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     66b:	45                   	inc    bp
     66c:	52                   	push   dx
     66d:	47                   	inc    di
     66e:	49                   	dec    cx
     66f:	46                   	inc    si
     670:	41                   	inc    cx
     671:	5c                   	pop    sp
     672:	02 20                	add    ah,BYTE PTR [bx+si]
     674:	00 0f                	add    BYTE PTR [bx],cl
     676:	54                   	push   sp
     677:	61                   	popa
     678:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     67b:	45                   	inc    bp
     67c:	52                   	push   dx
     67d:	47                   	inc    di
     67e:	43                   	inc    bx
     67f:	6c                   	ins    BYTE PTR es:[di],dx
     680:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     685:	60                   	pusha
     686:	02 20                	add    ah,BYTE PTR [bx+si]
     688:	00 14                	add    BYTE PTR [si],dl
     68a:	54                   	push   sp
     68b:	61                   	popa
     68c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     68f:	45                   	inc    bp
     690:	52                   	push   dx
     691:	47                   	inc    di
     692:	46                   	inc    si
     693:	6f                   	outs   dx,WORD PTR ds:[si]
     694:	75 72                	jne    0x708
     696:	6e                   	outs   dx,BYTE PTR ds:[si]
     697:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     69c:	72 73                	jb     0x711
     69e:	64 02 20             	add    ah,BYTE PTR fs:[bx+si]
     6a1:	00 12                	add    BYTE PTR [bp+si],dl
     6a3:	54                   	push   sp
     6a4:	61                   	popa
     6a5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a8:	45                   	inc    bp
     6a9:	52                   	push   dx
     6aa:	47                   	inc    di
     6ab:	54                   	push   sp
     6ac:	72 65                	jb     0x713
     6ae:	73 6f                	jae    0x71f
     6b0:	72 65                	jb     0x717
     6b2:	72 69                	jb     0x71d
     6b4:	65 68 02 20          	gs push 0x2002
     6b8:	00 0f                	add    BYTE PTR [bx],cl
     6ba:	54                   	push   sp
     6bb:	61                   	popa
     6bc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6bf:	45                   	inc    bp
     6c0:	52                   	push   dx
     6c1:	47                   	inc    di
     6c2:	45                   	inc    bp
     6c3:	6d                   	ins    WORD PTR es:[di],dx
     6c4:	70 72                	jo     0x738
     6c6:	75 6e                	jne    0x736
     6c8:	74 6c                	je     0x736
     6ca:	02 20                	add    ah,BYTE PTR [bx+si]
     6cc:	00 15                	add    BYTE PTR [di],dl
     6ce:	54                   	push   sp
     6cf:	61                   	popa
     6d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6d3:	45                   	inc    bp
     6d4:	52                   	push   dx
     6d5:	47                   	inc    di
     6d6:	44                   	inc    sp
     6d7:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     6db:	76 65                	jbe    0x742
     6dd:	72 74                	jb     0x753
     6df:	41                   	inc    cx
     6e0:	75 74                	jne    0x756
     6e2:	6f                   	outs   dx,WORD PTR ds:[si]
     6e3:	70 02                	jo     0x6e7
     6e5:	20 00                	and    BYTE PTR [bx+si],al
     6e7:	16                   	push   ss
     6e8:	54                   	push   sp
     6e9:	61                   	popa
     6ea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6ed:	45                   	inc    bp
     6ee:	52                   	push   dx
     6ef:	47                   	inc    di
     6f0:	44                   	inc    sp
     6f1:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     6f5:	76 65                	jbe    0x75c
     6f7:	72 74                	jb     0x76d
     6f9:	4e                   	dec    si
     6fa:	41                   	inc    cx
     6fb:	75 74                	jne    0x771
     6fd:	6f                   	outs   dx,WORD PTR ds:[si]
     6fe:	74 02                	je     0x702
     700:	20 00                	and    BYTE PTR [bx+si],al
     702:	15 54 61             	adc    ax,0x6154
     705:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     708:	45                   	inc    bp
     709:	52                   	push   dx
     70a:	47                   	inc    di
     70b:	41                   	inc    cx
     70c:	6d                   	ins    WORD PTR es:[di],dx
     70d:	6f                   	outs   dx,WORD PTR ds:[si]
     70e:	72 74                	jb     0x784
     710:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     715:	65 6e                	outs   dx,BYTE PTR gs:[si]
     717:	74 78                	je     0x791
     719:	02 20                	add    ah,BYTE PTR [bx+si]
     71b:	00 10                	add    BYTE PTR [bx+si],dl
     71d:	54                   	push   sp
     71e:	61                   	popa
     71f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     722:	45                   	inc    bp
     723:	52                   	push   dx
     724:	47                   	inc    di
     725:	43                   	inc    bx
     726:	65 73 73             	gs jae 0x79c
     729:	69 6f 6e 73 7c       	imul   bp,WORD PTR [bx+0x6e],0x7c73
     72e:	02 1c                	add    bl,BYTE PTR [si]
     730:	00 10                	add    BYTE PTR [bx+si],dl
     732:	54                   	push   sp
     733:	61                   	popa
     734:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     737:	45                   	inc    bp
     738:	52                   	push   dx
     739:	47                   	inc    di
     73a:	4d                   	dec    bp
     73b:	61                   	popa
     73c:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     73f:	6e                   	outs   dx,BYTE PTR ds:[si]
     740:	65 73 80             	gs jae 0x6c3
     743:	02 20                	add    ah,BYTE PTR [bx+si]
     745:	00 1d                	add    BYTE PTR [di],bl
     747:	54                   	push   sp
     748:	61                   	popa
     749:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     74c:	45                   	inc    bp
     74d:	52                   	push   dx
     74e:	47                   	inc    di
     74f:	49                   	dec    cx
     750:	6d                   	ins    WORD PTR es:[di],dx
     751:	6d                   	ins    WORD PTR es:[di],dx
     752:	6f                   	outs   dx,WORD PTR ds:[si]
     753:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     756:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     75b:	6f                   	outs   dx,WORD PTR ds:[si]
     75c:	6e                   	outs   dx,BYTE PTR ds:[si]
     75d:	73 42                	jae    0x7a1
     75f:	72 75                	jb     0x7d6
     761:	74 65                	je     0x7c8
     763:	73 84                	jae    0x6e9
     765:	02 20                	add    ah,BYTE PTR [bx+si]
     767:	00 1c                	add    BYTE PTR [si],bl
     769:	54                   	push   sp
     76a:	61                   	popa
     76b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     76e:	45                   	inc    bp
     76f:	52                   	push   dx
     770:	47                   	inc    di
     771:	43                   	inc    bx
     772:	6f                   	outs   dx,WORD PTR ds:[si]
     773:	75 74                	jne    0x7e9
     775:	73 46                	jae    0x7bd
     777:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     77c:	72 6f                	jb     0x7ed
     77e:	64 75 63             	fs jne 0x7e4
     781:	74 69                	je     0x7ec
     783:	6f                   	outs   dx,WORD PTR ds:[si]
     784:	6e                   	outs   dx,BYTE PTR ds:[si]
     785:	88 02                	mov    BYTE PTR [bp+si],al
     787:	1c 00                	sbb    al,0x0
     789:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     78c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     78f:	45                   	inc    bp
     790:	52                   	push   dx
     791:	47                   	inc    di
     792:	50                   	push   ax
     793:	72 6f                	jb     0x804
     795:	64 75 63             	fs jne 0x7fb
     798:	74 69                	je     0x803
     79a:	66 73 8c             	data32 jae 0x729
     79d:	02 1c                	add    bl,BYTE PTR [si]
     79f:	00 10                	add    BYTE PTR [bx+si],dl
     7a1:	54                   	push   sp
     7a2:	61                   	popa
     7a3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7a6:	45                   	inc    bp
     7a7:	52                   	push   dx
     7a8:	47                   	inc    di
     7a9:	56                   	push   si
     7aa:	65 6e                	outs   dx,BYTE PTR gs:[si]
     7ac:	64 65 75 72          	fs gs jne 0x822
     7b0:	73 90                	jae    0x742
     7b2:	02 1c                	add    bl,BYTE PTR [si]
     7b4:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     7b8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7bb:	45                   	inc    bp
     7bc:	52                   	push   dx
     7bd:	47                   	inc    di
     7be:	43                   	inc    bx
     7bf:	61                   	popa
     7c0:	64 72 65             	fs jb  0x828
     7c3:	73 94                	jae    0x759
     7c5:	02 20                	add    ah,BYTE PTR [bx+si]
     7c7:	00 14                	add    BYTE PTR [si],dl
     7c9:	54                   	push   sp
     7ca:	61                   	popa
     7cb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7ce:	45                   	inc    bp
     7cf:	52                   	push   dx
     7d0:	47                   	inc    di
     7d1:	43                   	inc    bx
     7d2:	6f                   	outs   dx,WORD PTR ds:[si]
     7d3:	75 74                	jne    0x849
     7d5:	45                   	inc    bp
     7d6:	6d                   	ins    WORD PTR es:[di],dx
     7d7:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     7da:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     7dd:	98                   	cbw
     7de:	02 20                	add    ah,BYTE PTR [bx+si]
     7e0:	00 14                	add    BYTE PTR [si],dl
     7e2:	54                   	push   sp
     7e3:	61                   	popa
     7e4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7e7:	45                   	inc    bp
     7e8:	52                   	push   dx
     7e9:	47                   	inc    di
     7ea:	43                   	inc    bx
     7eb:	6f                   	outs   dx,WORD PTR ds:[si]
     7ec:	75 74                	jne    0x862
     7ee:	4c                   	dec    sp
     7ef:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     7f4:	69 65 9c 02 20       	imul   sp,WORD PTR [di-0x64],0x2002
     7f9:	00 15                	add    BYTE PTR [di],dl
     7fb:	54                   	push   sp
     7fc:	61                   	popa
     7fd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     800:	45                   	inc    bp
     801:	52                   	push   dx
     802:	47                   	inc    di
     803:	43                   	inc    bx
     804:	6f                   	outs   dx,WORD PTR ds:[si]
     805:	75 74                	jne    0x87b
     807:	46                   	inc    si
     808:	6f                   	outs   dx,WORD PTR ds:[si]
     809:	72 6d                	jb     0x878
     80b:	61                   	popa
     80c:	74 69                	je     0x877
     80e:	6f                   	outs   dx,WORD PTR ds:[si]
     80f:	6e                   	outs   dx,BYTE PTR ds:[si]
     810:	a0 02 20             	mov    al,ds:0x2002
     813:	00 15                	add    BYTE PTR [di],dl
     815:	54                   	push   sp
     816:	61                   	popa
     817:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     81a:	45                   	inc    bp
     81b:	52                   	push   dx
     81c:	47                   	inc    di
     81d:	44                   	inc    sp
     81e:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     823:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     826:	69 6f 6e 73 a4       	imul   bp,WORD PTR [bx+0x6e],0xa473
     82b:	02 1c                	add    bl,BYTE PTR [si]
     82d:	00 0f                	add    BYTE PTR [bx],cl
     82f:	54                   	push   sp
     830:	61                   	popa
     831:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     834:	45                   	inc    bp
     835:	52                   	push   dx
     836:	47                   	inc    di
     837:	53                   	push   bx
     838:	70 65                	jo     0x89f
     83a:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     83d:	6c                   	ins    BYTE PTR es:[di],dx
     83e:	a8 02                	test   al,0x2
     840:	18 00                	sbb    BYTE PTR [bx+si],al
     842:	0d 54 61             	or     ax,0x6154
     845:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     848:	45                   	inc    bp
     849:	52                   	push   dx
     84a:	47                   	inc    di
     84b:	44                   	inc    sp
     84c:	65 74 74             	gs je  0x8c3
     84f:	65 ac                	lods   al,BYTE PTR gs:[si]
     851:	02 20                	add    ah,BYTE PTR [bx+si]
     853:	00 15                	add    BYTE PTR [di],dl
     855:	54                   	push   sp
     856:	61                   	popa
     857:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     85a:	45                   	inc    bp
     85b:	52                   	push   dx
     85c:	47                   	inc    di
     85d:	54                   	push   sp
     85e:	56                   	push   si
     85f:	41                   	inc    cx
     860:	44                   	inc    sp
     861:	65 64 75 63          	gs fs jne 0x8c8
     865:	74 69                	je     0x8d0
     867:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     86a:	b0 02                	mov    al,0x2
     86c:	20 00                	and    BYTE PTR [bx+si],al
     86e:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     871:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     874:	45                   	inc    bp
     875:	52                   	push   dx
     876:	47                   	inc    di
     877:	52                   	push   dx
     878:	65 6d                	gs ins WORD PTR es:[di],dx
     87a:	75 6e                	jne    0x8ea
     87c:	65 72 61             	gs jb  0x8e0
     87f:	74 69                	je     0x8ea
     881:	6f                   	outs   dx,WORD PTR ds:[si]
     882:	6e                   	outs   dx,BYTE PTR ds:[si]
     883:	43                   	inc    bx
     884:	61                   	popa
     885:	64 72 65             	fs jb  0x8ed
     888:	73 b4                	jae    0x83e
     88a:	02 20                	add    ah,BYTE PTR [bx+si]
     88c:	00 14                	add    BYTE PTR [si],dl
     88e:	54                   	push   sp
     88f:	61                   	popa
     890:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     893:	45                   	inc    bp
     894:	52                   	push   dx
     895:	47                   	inc    di
     896:	54                   	push   sp
     897:	56                   	push   si
     898:	41                   	inc    cx
     899:	43                   	inc    bx
     89a:	6f                   	outs   dx,WORD PTR ds:[si]
     89b:	6c                   	ins    BYTE PTR es:[di],dx
     89c:	6c                   	ins    BYTE PTR es:[di],dx
     89d:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     8a1:	65 b8 02 08          	gs mov ax,0x802
     8a5:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
     8a9:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     8ac:	31 bc 02 08          	xor    WORD PTR [si+0x802],di
     8b0:	00 02                	add    BYTE PTR [bp+si],al
     8b2:	4e                   	dec    si
     8b3:	33 c0                	xor    ax,ax
     8b5:	02 00                	add    al,BYTE PTR [bx+si]
     8b7:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     8bb:	6e                   	outs   dx,BYTE PTR ds:[si]
     8bc:	65 6c                	gs ins BYTE PTR es:[di],dx
     8be:	34 c4                	xor    al,0xc4
     8c0:	02 24                	add    ah,BYTE PTR [si]
     8c2:	00 09                	add    BYTE PTR [bx+di],cl
     8c4:	47                   	inc    di
     8c5:	72 6f                	jb     0x936
     8c7:	75 70                	jne    0x939
     8c9:	42                   	inc    dx
     8ca:	6f                   	outs   dx,WORD PTR ds:[si]
     8cb:	78 31                	js     0x8fe
     8cd:	c8 02 28 00          	enter  0x2802,0x0
     8d1:	06                   	push   es
     8d2:	53                   	push   bx
     8d3:	68 61 70             	push   0x7061
     8d6:	65 33 cc             	gs xor cx,sp
     8d9:	02 24                	add    ah,BYTE PTR [si]
     8db:	00 09                	add    BYTE PTR [bx+di],cl
     8dd:	47                   	inc    di
     8de:	72 6f                	jb     0x94f
     8e0:	75 70                	jne    0x952
     8e2:	42                   	inc    dx
     8e3:	6f                   	outs   dx,WORD PTR ds:[si]
     8e4:	78 33                	js     0x919
     8e6:	d0 02                	rol    BYTE PTR [bp+si],1
     8e8:	28 00                	sub    BYTE PTR [bx+si],al
     8ea:	06                   	push   es
     8eb:	53                   	push   bx
     8ec:	68 61 70             	push   0x7061
     8ef:	65 34 d4             	gs xor al,0xd4
     8f2:	02 00                	add    al,BYTE PTR [bx+si]
     8f4:	00 07                	add    BYTE PTR [bx],al
     8f6:	50                   	push   ax
     8f7:	61                   	popa
     8f8:	6e                   	outs   dx,BYTE PTR ds:[si]
     8f9:	65 6c                	gs ins BYTE PTR es:[di],dx
     8fb:	31 30                	xor    WORD PTR [bx+si],si
     8fd:	d8 02                	fadd   DWORD PTR [bp+si]
     8ff:	00 00                	add    BYTE PTR [bx+si],al
     901:	07                   	pop    es
     902:	50                   	push   ax
     903:	61                   	popa
     904:	6e                   	outs   dx,BYTE PTR ds:[si]
     905:	65 6c                	gs ins BYTE PTR es:[di],dx
     907:	31 31                	xor    WORD PTR [bx+di],si
     909:	dc 02                	fadd   QWORD PTR [bp+si]
     90b:	2c 00                	sub    al,0x0
     90d:	07                   	pop    es
     90e:	44                   	inc    sp
     90f:	42                   	inc    dx
     910:	45                   	inc    bp
     911:	64 69 74 31 e0 02    	imul   si,WORD PTR fs:[si+0x31],0x2e0
     917:	2c 00                	sub    al,0x0
     919:	07                   	pop    es
     91a:	44                   	inc    sp
     91b:	42                   	inc    dx
     91c:	45                   	inc    bp
     91d:	64 69 74 32 e4 02    	imul   si,WORD PTR fs:[si+0x32],0x2e4
     923:	2c 00                	sub    al,0x0
     925:	07                   	pop    es
     926:	44                   	inc    sp
     927:	42                   	inc    dx
     928:	45                   	inc    bp
     929:	64 69 74 33 e8 02    	imul   si,WORD PTR fs:[si+0x33],0x2e8
     92f:	24 00                	and    al,0x0
     931:	09 47 72             	or     WORD PTR [bx+0x72],ax
     934:	6f                   	outs   dx,WORD PTR ds:[si]
     935:	75 70                	jne    0x9a7
     937:	42                   	inc    dx
     938:	6f                   	outs   dx,WORD PTR ds:[si]
     939:	78 34                	js     0x96f
     93b:	ec                   	in     al,dx
     93c:	02 28                	add    ch,BYTE PTR [bx+si]
     93e:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
     942:	61                   	popa
     943:	70 65                	jo     0x9aa
     945:	35 f0 02             	xor    ax,0x2f0
     948:	00 00                	add    BYTE PTR [bx+si],al
     94a:	07                   	pop    es
     94b:	50                   	push   ax
     94c:	61                   	popa
     94d:	6e                   	outs   dx,BYTE PTR ds:[si]
     94e:	65 6c                	gs ins BYTE PTR es:[di],dx
     950:	31 32                	xor    WORD PTR [bp+si],si
     952:	f4                   	hlt
     953:	02 00                	add    al,BYTE PTR [bx+si]
     955:	00 07                	add    BYTE PTR [bx],al
     957:	50                   	push   ax
     958:	61                   	popa
     959:	6e                   	outs   dx,BYTE PTR ds:[si]
     95a:	65 6c                	gs ins BYTE PTR es:[di],dx
     95c:	31 33                	xor    WORD PTR [bp+di],si
     95e:	f8                   	clc
     95f:	02 00                	add    al,BYTE PTR [bx+si]
     961:	00 07                	add    BYTE PTR [bx],al
     963:	50                   	push   ax
     964:	61                   	popa
     965:	6e                   	outs   dx,BYTE PTR ds:[si]
     966:	65 6c                	gs ins BYTE PTR es:[di],dx
     968:	31 34                	xor    WORD PTR [si],si
     96a:	fc                   	cld
     96b:	02 2c                	add    ch,BYTE PTR [si]
     96d:	00 07                	add    BYTE PTR [bx],al
     96f:	44                   	inc    sp
     970:	42                   	inc    dx
     971:	45                   	inc    bp
     972:	64 69 74 34 00 03    	imul   si,WORD PTR fs:[si+0x34],0x300
     978:	2c 00                	sub    al,0x0
     97a:	07                   	pop    es
     97b:	44                   	inc    sp
     97c:	42                   	inc    dx
     97d:	45                   	inc    bp
     97e:	64 69 74 35 04 03    	imul   si,WORD PTR fs:[si+0x35],0x304
     984:	2c 00                	sub    al,0x0
     986:	07                   	pop    es
     987:	44                   	inc    sp
     988:	42                   	inc    dx
     989:	45                   	inc    bp
     98a:	64 69 74 36 08 03    	imul   si,WORD PTR fs:[si+0x36],0x308
     990:	2c 00                	sub    al,0x0
     992:	07                   	pop    es
     993:	44                   	inc    sp
     994:	42                   	inc    dx
     995:	45                   	inc    bp
     996:	64 69 74 37 0c 03    	imul   si,WORD PTR fs:[si+0x37],0x30c
     99c:	00 00                	add    BYTE PTR [bx+si],al
     99e:	07                   	pop    es
     99f:	50                   	push   ax
     9a0:	61                   	popa
     9a1:	6e                   	outs   dx,BYTE PTR ds:[si]
     9a2:	65 6c                	gs ins BYTE PTR es:[di],dx
     9a4:	31 35                	xor    WORD PTR [di],si
     9a6:	10 03                	adc    BYTE PTR [bp+di],al
     9a8:	2c 00                	sub    al,0x0
     9aa:	07                   	pop    es
     9ab:	44                   	inc    sp
     9ac:	42                   	inc    dx
     9ad:	45                   	inc    bp
     9ae:	64 69 74 38 14 03    	imul   si,WORD PTR fs:[si+0x38],0x314
     9b4:	00 00                	add    BYTE PTR [bx+si],al
     9b6:	06                   	push   es
     9b7:	50                   	push   ax
     9b8:	61                   	popa
     9b9:	6e                   	outs   dx,BYTE PTR ds:[si]
     9ba:	65 6c                	gs ins BYTE PTR es:[di],dx
     9bc:	39 18                	cmp    WORD PTR [bx+si],bx
     9be:	03 24                	add    sp,WORD PTR [si]
     9c0:	00 09                	add    BYTE PTR [bx+di],cl
     9c2:	47                   	inc    di
     9c3:	72 6f                	jb     0xa34
     9c5:	75 70                	jne    0xa37
     9c7:	42                   	inc    dx
     9c8:	6f                   	outs   dx,WORD PTR ds:[si]
     9c9:	78 32                	js     0x9fd
     9cb:	1c 03                	sbb    al,0x3
     9cd:	28 00                	sub    BYTE PTR [bx+si],al
     9cf:	06                   	push   es
     9d0:	53                   	push   bx
     9d1:	68 61 70             	push   0x7061
     9d4:	65 36 20 03          	gs and BYTE PTR ss:[bp+di],al
     9d8:	24 00                	and    al,0x0
     9da:	09 47 72             	or     WORD PTR [bx+0x72],ax
     9dd:	6f                   	outs   dx,WORD PTR ds:[si]
     9de:	75 70                	jne    0xa50
     9e0:	42                   	inc    dx
     9e1:	6f                   	outs   dx,WORD PTR ds:[si]
     9e2:	78 35                	js     0xa19
     9e4:	24 03                	and    al,0x3
     9e6:	28 00                	sub    BYTE PTR [bx+si],al
     9e8:	06                   	push   es
     9e9:	53                   	push   bx
     9ea:	68 61 70             	push   0x7061
     9ed:	65 31 28             	xor    WORD PTR gs:[bx+si],bp
     9f0:	03 00                	add    ax,WORD PTR [bx+si]
     9f2:	00 07                	add    BYTE PTR [bx],al
     9f4:	50                   	push   ax
     9f5:	61                   	popa
     9f6:	6e                   	outs   dx,BYTE PTR ds:[si]
     9f7:	65 6c                	gs ins BYTE PTR es:[di],dx
     9f9:	31 36 2c 03          	xor    WORD PTR ds:0x32c,si
     9fd:	00 00                	add    BYTE PTR [bx+si],al
     9ff:	07                   	pop    es
     a00:	50                   	push   ax
     a01:	61                   	popa
     a02:	6e                   	outs   dx,BYTE PTR ds:[si]
     a03:	65 6c                	gs ins BYTE PTR es:[di],dx
     a05:	31 37                	xor    WORD PTR [bx],si
     a07:	30 03                	xor    BYTE PTR [bp+di],al
     a09:	2c 00                	sub    al,0x0
     a0b:	07                   	pop    es
     a0c:	44                   	inc    sp
     a0d:	42                   	inc    dx
     a0e:	45                   	inc    bp
     a0f:	64 69 74 39 34 03    	imul   si,WORD PTR fs:[si+0x39],0x334
     a15:	2c 00                	sub    al,0x0
     a17:	08 44 42             	or     BYTE PTR [si+0x42],al
     a1a:	45                   	inc    bp
     a1b:	64 69 74 31 30 38    	imul   si,WORD PTR fs:[si+0x31],0x3830
     a21:	03 2c                	add    bp,WORD PTR [si]
     a23:	00 08                	add    BYTE PTR [bx+si],cl
     a25:	44                   	inc    sp
     a26:	42                   	inc    dx
     a27:	45                   	inc    bp
     a28:	64 69 74 31 31 3c    	imul   si,WORD PTR fs:[si+0x31],0x3c31
     a2e:	03 2c                	add    bp,WORD PTR [si]
     a30:	00 08                	add    BYTE PTR [bx+si],cl
     a32:	44                   	inc    sp
     a33:	42                   	inc    dx
     a34:	45                   	inc    bp
     a35:	64 69 74 31 32 40    	imul   si,WORD PTR fs:[si+0x31],0x4032
     a3b:	03 00                	add    ax,WORD PTR [bx+si]
     a3d:	00 07                	add    BYTE PTR [bx],al
     a3f:	50                   	push   ax
     a40:	61                   	popa
     a41:	6e                   	outs   dx,BYTE PTR ds:[si]
     a42:	65 6c                	gs ins BYTE PTR es:[di],dx
     a44:	31 38                	xor    WORD PTR [bx+si],di
     a46:	44                   	inc    sp
     a47:	03 24                	add    sp,WORD PTR [si]
     a49:	00 09                	add    BYTE PTR [bx+di],cl
     a4b:	47                   	inc    di
     a4c:	72 6f                	jb     0xabd
     a4e:	75 70                	jne    0xac0
     a50:	42                   	inc    dx
     a51:	6f                   	outs   dx,WORD PTR ds:[si]
     a52:	78 36                	js     0xa8a
     a54:	48                   	dec    ax
     a55:	03 28                	add    bp,WORD PTR [bx+si]
     a57:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
     a5b:	61                   	popa
     a5c:	70 65                	jo     0xac3
     a5e:	32 4c 03             	xor    cl,BYTE PTR [si+0x3]
     a61:	00 00                	add    BYTE PTR [bx+si],al
     a63:	07                   	pop    es
     a64:	50                   	push   ax
     a65:	61                   	popa
     a66:	6e                   	outs   dx,BYTE PTR ds:[si]
     a67:	65 6c                	gs ins BYTE PTR es:[di],dx
     a69:	31 39                	xor    WORD PTR [bx+di],di
     a6b:	50                   	push   ax
     a6c:	03 00                	add    ax,WORD PTR [bx+si]
     a6e:	00 07                	add    BYTE PTR [bx],al
     a70:	50                   	push   ax
     a71:	61                   	popa
     a72:	6e                   	outs   dx,BYTE PTR ds:[si]
     a73:	65 6c                	gs ins BYTE PTR es:[di],dx
     a75:	32 30                	xor    dh,BYTE PTR [bx+si]
     a77:	54                   	push   sp
     a78:	03 00                	add    ax,WORD PTR [bx+si]
     a7a:	00 07                	add    BYTE PTR [bx],al
     a7c:	50                   	push   ax
     a7d:	61                   	popa
     a7e:	6e                   	outs   dx,BYTE PTR ds:[si]
     a7f:	65 6c                	gs ins BYTE PTR es:[di],dx
     a81:	32 31                	xor    dh,BYTE PTR [bx+di]
     a83:	58                   	pop    ax
     a84:	03 00                	add    ax,WORD PTR [bx+si]
     a86:	00 07                	add    BYTE PTR [bx],al
     a88:	50                   	push   ax
     a89:	61                   	popa
     a8a:	6e                   	outs   dx,BYTE PTR ds:[si]
     a8b:	65 6c                	gs ins BYTE PTR es:[di],dx
     a8d:	32 32                	xor    dh,BYTE PTR [bp+si]
     a8f:	5c                   	pop    sp
     a90:	03 2c                	add    bp,WORD PTR [si]
     a92:	00 08                	add    BYTE PTR [bx+si],cl
     a94:	44                   	inc    sp
     a95:	42                   	inc    dx
     a96:	45                   	inc    bp
     a97:	64 69 74 31 33 60    	imul   si,WORD PTR fs:[si+0x31],0x6033
     a9d:	03 2c                	add    bp,WORD PTR [si]
     a9f:	00 08                	add    BYTE PTR [bx+si],cl
     aa1:	44                   	inc    sp
     aa2:	42                   	inc    dx
     aa3:	45                   	inc    bp
     aa4:	64 69 74 31 34 64    	imul   si,WORD PTR fs:[si+0x31],0x6434
     aaa:	03 2c                	add    bp,WORD PTR [si]
     aac:	00 08                	add    BYTE PTR [bx+si],cl
     aae:	44                   	inc    sp
     aaf:	42                   	inc    dx
     ab0:	45                   	inc    bp
     ab1:	64 69 74 31 35 68    	imul   si,WORD PTR fs:[si+0x31],0x6835
     ab7:	03 2c                	add    bp,WORD PTR [si]
     ab9:	00 08                	add    BYTE PTR [bx+si],cl
     abb:	44                   	inc    sp
     abc:	42                   	inc    dx
     abd:	45                   	inc    bp
     abe:	64 69 74 31 36 6c    	imul   si,WORD PTR fs:[si+0x31],0x6c36
     ac4:	03 2c                	add    bp,WORD PTR [si]
     ac6:	00 08                	add    BYTE PTR [bx+si],cl
     ac8:	44                   	inc    sp
     ac9:	42                   	inc    dx
     aca:	45                   	inc    bp
     acb:	64 69 74 31 37 70    	imul   si,WORD PTR fs:[si+0x31],0x7037
     ad1:	03 00                	add    ax,WORD PTR [bx+si]
     ad3:	00 07                	add    BYTE PTR [bx],al
     ad5:	50                   	push   ax
     ad6:	61                   	popa
     ad7:	6e                   	outs   dx,BYTE PTR ds:[si]
     ad8:	65 6c                	gs ins BYTE PTR es:[di],dx
     ada:	32 33                	xor    dh,BYTE PTR [bp+di]
     adc:	74 03                	je     0xae1
     ade:	2c 00                	sub    al,0x0
     ae0:	08 44 42             	or     BYTE PTR [si+0x42],al
     ae3:	45                   	inc    bp
     ae4:	64 69 74 31 38 78    	imul   si,WORD PTR fs:[si+0x31],0x7838
     aea:	03 00                	add    ax,WORD PTR [bx+si]
     aec:	00 07                	add    BYTE PTR [bx],al
     aee:	50                   	push   ax
     aef:	61                   	popa
     af0:	6e                   	outs   dx,BYTE PTR ds:[si]
     af1:	65 6c                	gs ins BYTE PTR es:[di],dx
     af3:	34 34                	xor    al,0x34
     af5:	7c 03                	jl     0xafa
     af7:	30 00                	xor    BYTE PTR [bx+si],al
     af9:	07                   	pop    es
     afa:	4c                   	dec    sp
     afb:	61                   	popa
     afc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     aff:	55                   	push   bp
     b00:	30 80 03 30          	xor    BYTE PTR [bx+si+0x3003],al
     b04:	00 07                	add    BYTE PTR [bx],al
     b06:	4c                   	dec    sp
     b07:	61                   	popa
     b08:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     b0b:	55                   	push   bp
     b0c:	31 84 03 30          	xor    WORD PTR [si+0x3003],ax
     b10:	00 07                	add    BYTE PTR [bx],al
     b12:	4c                   	dec    sp
     b13:	61                   	popa
     b14:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     b17:	55                   	push   bp
     b18:	32 88 03 30          	xor    cl,BYTE PTR [bx+si+0x3003]
     b1c:	00 07                	add    BYTE PTR [bx],al
     b1e:	4c                   	dec    sp
     b1f:	61                   	popa
     b20:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     b23:	55                   	push   bp
     b24:	33 8c 03 08          	xor    cx,WORD PTR [si+0x803]
     b28:	00 08                	add    BYTE PTR [bx+si],cl
     b2a:	45                   	inc    bp
     b2b:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     b31:	31 90 03 08          	xor    WORD PTR [bx+si+0x803],dx
     b35:	00 07                	add    BYTE PTR [bx],al
     b37:	43                   	inc    bx
     b38:	6f                   	outs   dx,WORD PTR ds:[si]
     b39:	70 69                	jo     0xba4
     b3b:	65 72 31             	gs jb  0xb6f
     b3e:	94                   	xchg   sp,ax
     b3f:	03 34                	add    si,WORD PTR [si]
     b41:	00 05                	add    BYTE PTR [di],al
     b43:	4d                   	dec    bp
     b44:	65 6d                	gs ins WORD PTR es:[di],dx
     b46:	6f                   	outs   dx,WORD PTR ds:[si]
     b47:	31 98 03 0c          	xor    WORD PTR [bx+si+0xc03],bx
     b4b:	00 08                	add    BYTE PTR [bx+si],cl
     b4d:	54                   	push   sp
     b4e:	61                   	popa
     b4f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b52:	45                   	inc    bp
     b53:	44                   	inc    sp
     b54:	47                   	inc    di
     b55:	9c                   	pushf
     b56:	03 18                	add    bx,WORD PTR [bx+si]
     b58:	00 12                	add    BYTE PTR [bp+si],dl
     b5a:	54                   	push   sp
     b5b:	61                   	popa
     b5c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b5f:	45                   	inc    bp
     b60:	52                   	push   dx
     b61:	47                   	inc    di
     b62:	4e                   	dec    si
     b63:	65 77 45             	gs ja  0xbab
     b66:	6d                   	ins    WORD PTR es:[di],dx
     b67:	70 72                	jo     0xbdb
     b69:	75 6e                	jne    0xbd9
     b6b:	74 a0                	je     0xb0d
     b6d:	03 08                	add    cx,WORD PTR [bx+si]
     b6f:	00 10                	add    BYTE PTR [bx+si],dl
     b71:	41                   	inc    cx
     b72:	75 74                	jne    0xbe8
     b74:	72 65                	jb     0xbdb
     b76:	73 52                	jae    0xbca
     b78:	65 73 75             	gs jae 0xbf0
     b7b:	6c                   	ins    BYTE PTR es:[di],dx
     b7c:	74 61                	je     0xbdf
     b7e:	74 73                	je     0xbf3
     b80:	31 a4 03 08          	xor    WORD PTR [si+0x803],sp
     b84:	00 0a                	add    BYTE PTR [bp+si],cl
     b86:	53                   	push   bx
     b87:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     b8c:	69 6f 6e 31 a8       	imul   bp,WORD PTR [bx+0x6e],0xa831
     b91:	03 08                	add    cx,WORD PTR [bx+si]
     b93:	00 12                	add    BYTE PTR [bp+si],dl
     b95:	43                   	inc    bx
     b96:	6f                   	outs   dx,WORD PTR ds:[si]
     b97:	6d                   	ins    WORD PTR es:[di],dx
     b98:	70 74                	jo     0xc0e
     b9a:	65 44                	gs inc sp
     b9c:	65 52                	gs push dx
     b9e:	65 73 75             	gs jae 0xc16
     ba1:	6c                   	ins    BYTE PTR es:[di],dx
     ba2:	74 61                	je     0xc05
     ba4:	74 73                	je     0xc19
     ba6:	31 ac 03 08          	xor    WORD PTR [si+0x803],bp
     baa:	00 06 42 69          	add    BYTE PTR ds:0x6942,al
     bae:	6c                   	ins    BYTE PTR es:[di],dx
     baf:	61                   	popa
     bb0:	6e                   	outs   dx,BYTE PTR ds:[si]
     bb1:	31 b0 03 08          	xor    WORD PTR [bx+si+0x803],si
     bb5:	00 15                	add    BYTE PTR [di],dl
     bb7:	54                   	push   sp
     bb8:	61                   	popa
     bb9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bbc:	61                   	popa
     bbd:	75 44                	jne    0xc03
     bbf:	65 46                	gs inc si
     bc1:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     bc6:	65 6d                	gs ins WORD PTR es:[di],dx
     bc8:	65 6e                	outs   dx,BYTE PTR gs:[si]
     bca:	74 31                	je     0xbfd
     bcc:	b4 03                	mov    ah,0x3
     bce:	08 00                	or     BYTE PTR [bx+si],al
     bd0:	14 54                	adc    al,0x54
     bd2:	61                   	popa
     bd3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bd6:	61                   	popa
     bd7:	75 44                	jne    0xc1d
     bd9:	65 54                	gs push sp
     bdb:	72 65                	jb     0xc42
     bdd:	73 6f                	jae    0xc4e
     bdf:	72 65                	jb     0xc46
     be1:	72 69                	jb     0xc4c
     be3:	65 31 b8 03 08       	xor    WORD PTR gs:[bx+si+0x803],di
     be8:	00 02                	add    BYTE PTR [bp+si],al
     bea:	4e                   	dec    si
     beb:	34 bc                	xor    al,0xbc
     bed:	03 08                	add    cx,WORD PTR [bx+si]
     bef:	00 13                	add    BYTE PTR [bp+di],dl
     bf1:	52                   	push   dx
     bf2:	61                   	popa
     bf3:	70 70                	jo     0xc65
     bf5:	65 6c                	gs ins BYTE PTR es:[di],dx
     bf7:	44                   	inc    sp
     bf8:	65 73 44             	gs jae 0xc3f
     bfb:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     bff:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     c04:	c0 03 08             	rol    BYTE PTR [bp+di],0x8
     c07:	00 05                	add    BYTE PTR [di],al
     c09:	4e                   	dec    si
     c0a:	31 30                	xor    WORD PTR [bx+si],si
     c0c:	30 31                	xor    BYTE PTR [bx+di],dh
     c0e:	c4 03                	les    ax,DWORD PTR [bp+di]
     c10:	08 00                	or     BYTE PTR [bx+si],al
     c12:	05 4e 31             	add    ax,0x314e
     c15:	35 30 31             	xor    ax,0x3130
     c18:	c8 03 08 00          	enter  0x803,0x0
     c1c:	05 4e 32             	add    ax,0x324e
     c1f:	30 30                	xor    BYTE PTR [bx+si],dh
     c21:	31 cc                	xor    sp,cx
     c23:	03 08                	add    cx,WORD PTR [bx+si]
     c25:	00 04                	add    BYTE PTR [si],al
     c27:	4e                   	dec    si
     c28:	37                   	aaa
     c29:	35 31 d0             	xor    ax,0xd031
     c2c:	03 08                	add    cx,WORD PTR [bx+si]
     c2e:	00 04                	add    BYTE PTR [si],al
     c30:	4e                   	dec    si
     c31:	35 30 31             	xor    ax,0x3130
     c34:	d4 03                	aam    0x3
     c36:	08 00                	or     BYTE PTR [bx+si],al
     c38:	02 4e 35             	add    cl,BYTE PTR [bp+0x35]
     c3b:	d8 03                	fadd   DWORD PTR [bp+di]
     c3d:	08 00                	or     BYTE PTR [bx+si],al
     c3f:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     c42:	70 72                	jo     0xcb6
     c44:	65 73 73             	gs jae 0xcba
     c47:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     c4c:	70 69                	jo     0xcb7
     c4e:	64 65 31 dc          	fs gs xor sp,bx
     c52:	03 08                	add    cx,WORD PTR [bx+si]
     c54:	00 02                	add    BYTE PTR [bp+si],al
     c56:	4e                   	dec    si
     c57:	36 e0 03             	ss loopne 0xc5d
     c5a:	08 00                	or     BYTE PTR [bx+si],al
     c5c:	1b 43 6f             	sbb    ax,WORD PTR [bp+di+0x6f]
     c5f:	6e                   	outs   dx,BYTE PTR ds:[si]
     c60:	66 69 67 75 72 61 74 	imul   esp,DWORD PTR [bx+0x75],0x69746172
     c67:	69 
     c68:	6f                   	outs   dx,WORD PTR ds:[si]
     c69:	6e                   	outs   dx,BYTE PTR ds:[si]
     c6a:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
     c6d:	69 6d 70 72 65       	imul   bp,WORD PTR [di+0x70],0x6572
     c72:	73 73                	jae    0xce7
     c74:	69 6f 6e 31 e4       	imul   bp,WORD PTR [bx+0x6e],0xe431
     c79:	03 38                	add    di,WORD PTR [bx+si]
     c7b:	00 13                	add    BYTE PTR [bp+di],dl
     c7d:	50                   	push   ax
     c7e:	72 69                	jb     0xce9
     c80:	6e                   	outs   dx,BYTE PTR ds:[si]
     c81:	74 65                	je     0xce8
     c83:	72 53                	jb     0xcd8
     c85:	65 74 75             	gs je  0xcfd
     c88:	70 44                	jo     0xcce
     c8a:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     c8f:	31 e8                	xor    ax,bp
     c91:	03 08                	add    cx,WORD PTR [bx+si]
     c93:	00 05                	add    BYTE PTR [di],al
     c95:	4e                   	dec    si
     c96:	31 32                	xor    WORD PTR [bp+si],si
     c98:	35 31 ec             	xor    ax,0xec31
     c9b:	03 08                	add    cx,WORD PTR [bx+si]
     c9d:	00 08                	add    BYTE PTR [bx+si],cl
     c9f:	50                   	push   ax
     ca0:	65 72 69             	gs jb  0xd0c
     ca3:	6f                   	outs   dx,WORD PTR ds:[si]
     ca4:	64 65 32 f0          	fs gs xor dh,al
     ca8:	03 08                	add    cx,WORD PTR [bx+si]
     caa:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
     cae:	74 72                	je     0xd22
     cb0:	65 31 f4             	gs xor sp,si
     cb3:	03 08                	add    cx,WORD PTR [bx+si]
     cb5:	00 04                	add    BYTE PTR [si],al
     cb7:	4e                   	dec    si
     cb8:	32 30                	xor    dh,BYTE PTR [bx+si]
     cba:	31 f8                	xor    ax,di
     cbc:	03 08                	add    cx,WORD PTR [bx+si]
     cbe:	00 04                	add    BYTE PTR [si],al
     cc0:	4e                   	dec    si
     cc1:	31 39                	xor    WORD PTR [bx+di],di
     cc3:	31 fc                	xor    sp,di
     cc5:	03 08                	add    cx,WORD PTR [bx+si]
     cc7:	00 04                	add    BYTE PTR [si],al
     cc9:	4e                   	dec    si
     cca:	31 38                	xor    WORD PTR [bx+si],di
     ccc:	31 00                	xor    WORD PTR [bx+si],ax
     cce:	04 08                	add    al,0x8
     cd0:	00 04                	add    BYTE PTR [si],al
     cd2:	4e                   	dec    si
     cd3:	31 37                	xor    WORD PTR [bx],si
     cd5:	31 04                	xor    WORD PTR [si],ax
     cd7:	04 08                	add    al,0x8
     cd9:	00 04                	add    BYTE PTR [si],al
     cdb:	4e                   	dec    si
     cdc:	31 36 31 08          	xor    WORD PTR ds:0x831,si
     ce0:	04 08                	add    al,0x8
     ce2:	00 04                	add    BYTE PTR [si],al
     ce4:	4e                   	dec    si
     ce5:	31 35                	xor    WORD PTR [di],si
     ce7:	31 0c                	xor    WORD PTR [si],cx
     ce9:	04 08                	add    al,0x8
     ceb:	00 04                	add    BYTE PTR [si],al
     ced:	4e                   	dec    si
     cee:	31 34                	xor    WORD PTR [si],si
     cf0:	31 10                	xor    WORD PTR [bx+si],dx
     cf2:	04 08                	add    al,0x8
     cf4:	00 04                	add    BYTE PTR [si],al
     cf6:	4e                   	dec    si
     cf7:	31 33                	xor    WORD PTR [bp+di],si
     cf9:	31 14                	xor    WORD PTR [si],dx
     cfb:	04 08                	add    al,0x8
     cfd:	00 04                	add    BYTE PTR [si],al
     cff:	4e                   	dec    si
     d00:	31 32                	xor    WORD PTR [bp+si],si
     d02:	31 18                	xor    WORD PTR [bx+si],bx
     d04:	04 08                	add    al,0x8
     d06:	00 04                	add    BYTE PTR [si],al
     d08:	4e                   	dec    si
     d09:	31 31                	xor    WORD PTR [bx+di],si
     d0b:	31 1c                	xor    WORD PTR [si],bx
     d0d:	04 08                	add    al,0x8
     d0f:	00 04                	add    BYTE PTR [si],al
     d11:	4e                   	dec    si
     d12:	31 30                	xor    WORD PTR [bx+si],si
     d14:	31 20                	xor    WORD PTR [bx+si],sp
     d16:	04 08                	add    al,0x8
     d18:	00 03                	add    BYTE PTR [bp+di],al
     d1a:	4e                   	dec    si
     d1b:	39 31                	cmp    WORD PTR [bx+di],si
     d1d:	24 04                	and    al,0x4
     d1f:	08 00                	or     BYTE PTR [bx+si],al
     d21:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     d24:	32 28                	xor    ch,BYTE PTR [bx+si]
     d26:	04 08                	add    al,0x8
     d28:	00 03                	add    BYTE PTR [bp+di],al
     d2a:	4e                   	dec    si
     d2b:	37                   	aaa
     d2c:	32 2c                	xor    ch,BYTE PTR [si]
     d2e:	04 08                	add    al,0x8
     d30:	00 03                	add    BYTE PTR [bp+di],al
     d32:	4e                   	dec    si
     d33:	36 32 30             	xor    dh,BYTE PTR ss:[bx+si]
     d36:	04 08                	add    al,0x8
     d38:	00 03                	add    BYTE PTR [bp+di],al
     d3a:	4e                   	dec    si
     d3b:	35 32 34             	xor    ax,0x3432
     d3e:	04 08                	add    al,0x8
     d40:	00 03                	add    BYTE PTR [bp+di],al
     d42:	4e                   	dec    si
     d43:	34 32                	xor    al,0x32
     d45:	38 04                	cmp    BYTE PTR [si],al
     d47:	08 00                	or     BYTE PTR [bx+si],al
     d49:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     d4c:	32 3c                	xor    bh,BYTE PTR [si]
     d4e:	04 08                	add    al,0x8
     d50:	00 03                	add    BYTE PTR [bp+di],al
     d52:	4e                   	dec    si
     d53:	32 32                	xor    dh,BYTE PTR [bp+si]
     d55:	40                   	inc    ax
     d56:	04 08                	add    al,0x8
     d58:	00 03                	add    BYTE PTR [bp+di],al
     d5a:	4e                   	dec    si
     d5b:	31 32                	xor    WORD PTR [bp+si],si
     d5d:	44                   	inc    sp
     d5e:	04 08                	add    al,0x8
     d60:	00 04                	add    BYTE PTR [si],al
     d62:	53                   	push   bx
     d63:	49                   	dec    cx
     d64:	47                   	inc    di
     d65:	31 0f                	xor    WORD PTR [bx],cx
     d67:	00 ad 0d 92          	add    BYTE PTR [di-0x6df3],ch
     d6b:	0d ef 02             	or     ax,0x2ef
     d6e:	72 0d                	jb     0xd7d
     d70:	94                   	xchg   sp,ax
     d71:	00 65 1d             	add    BYTE PTR [di+0x1d],ah
     d74:	38 01                	cmp    BYTE PTR [bx+di],al
     d76:	82 0d c8             	or     BYTE PTR [di],0xc8
     d79:	08 b1 11 7e          	or     BYTE PTR [bx+di+0x7e11],dh
     d7d:	08 a2 0d 58          	or     BYTE PTR [bp+si+0x580d],ah
     d81:	0a 86 0d c8          	or     al,BYTE PTR [bp-0x37f3]
     d85:	07                   	pop    es
     d86:	8a 0d                	mov    cl,BYTE PTR [di]
     d88:	67 0c c3             	addr32 or al,0xc3
     d8b:	11 0c                	adc    WORD PTR [si],cx
     d8d:	01 9a 0d 7d          	add    WORD PTR [bp+si+0x7d0d],bx
     d91:	00 71 38             	add    BYTE PTR [bx+di+0x38],dh
     d94:	22 00                	and    al,BYTE PTR [bx+si]
     d96:	97                   	xchg   di,ax
     d97:	11 17                	adc    WORD PTR [bx],dx
     d99:	06                   	push   es
     d9a:	9e                   	sahf
     d9b:	0d 91 12             	or     ax,0x1291
     d9e:	eb 36                	jmp    0xdd6
     da0:	2b 07                	sub    ax,WORD PTR [bx]
     da2:	49                   	dec    cx
     da3:	10 07                	adc    BYTE PTR [bx],al
     da5:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
     da9:	72 6d                	jb     0xe18
     dab:	53                   	push   bx
     dac:	45                   	inc    bp
     dad:	52                   	push   dx
     dae:	42                   	inc    dx
     daf:	5f                   	pop    di
     db0:	42                   	inc    dx
     db1:	69 6c 61 6e 22       	imul   bp,WORD PTR [si+0x61],0x226e
     db6:	00 f5                	add    ch,dh
     db8:	0d 7b 06             	or     ax,0x67b
     dbb:	e6 0d                	out    0xd,al
     dbd:	38 00                	cmp    BYTE PTR [bx+si],al
     dbf:	04 53                	add    al,0x53
     dc1:	65 72 62             	gs jb  0xe26
     dc4:	00 00                	add    BYTE PTR [bx+si],al
     dc6:	55                   	push   bp
     dc7:	89 e5                	mov    bp,sp
     dc9:	31 c0                	xor    ax,ax
     dcb:	9a 44 04 00 0e       	call   0xe00:0x444
     dd0:	6a 00                	push   0x0
     dd2:	9a c2 38 de 0f       	call   0xfde:0x38c2
     dd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dda:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     de1:	06                   	push   es
     de2:	57                   	push   di
     de3:	9a 56 55 0e 0e       	call   0xe0e:0x5556
     de8:	9a c3 28 2c 12       	call   0x122c:0x28c3
     ded:	c9                   	leave
     dee:	ca 04 00             	retf   0x4
     df1:	00 00                	add    BYTE PTR [bx+si],al
     df3:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     df4:	0e                   	push   cs
     df5:	28 0e 55 89          	sub    BYTE PTR ds:0x8955,cl
     df9:	e5 b8                	in     ax,0xb8
     dfb:	08 00                	or     BYTE PTR [bx+si],al
     dfd:	9a 44 04 c2 0e       	call   0xec2:0x444
     e02:	83 ec 08             	sub    sp,0x8
     e05:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     e09:	06                   	push   es
     e0a:	57                   	push   di
     e0b:	9a 03 73 2f 0e       	call   0xe2f:0x7303
     e10:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
     e14:	7f 03                	jg     0xe19
     e16:	e9 96 00             	jmp    0xeaf
     e19:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     e1d:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     e21:	b0 01                	mov    al,0x1
     e23:	50                   	push   ax
     e24:	b8 22 00             	mov    ax,0x22
     e27:	ba 63 0e             	mov    dx,0xe63
     e2a:	52                   	push   dx
     e2b:	50                   	push   ax
     e2c:	9a 53 25 8c 0e       	call   0xe8c:0x2553
     e31:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e34:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     e37:	b8 f1 0d             	mov    ax,0xdf1
     e3a:	0e                   	push   cs
     e3b:	50                   	push   ax
     e3c:	55                   	push   bp
     e3d:	ff 36 58 18          	push   WORD PTR ds:0x1858
     e41:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     e45:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e48:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     e4b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     e4e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     e51:	26 89 85 4c 04       	mov    WORD PTR es:[di+0x44c],ax
     e56:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     e59:	26 89 85 4a 04       	mov    WORD PTR es:[di+0x44a],ax
     e5e:	06                   	push   es
     e5f:	57                   	push   di
     e60:	9a ea 1a 72 0e       	call   0xe72:0x1aea
     e65:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e68:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
     e6d:	06                   	push   es
     e6e:	57                   	push   di
     e6f:	9a da 1f b7 0e       	call   0xeb7:0x1fda
     e74:	6a ff                	push   0xffff
     e76:	6a f0                	push   0xfff0
     e78:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e7b:	06                   	push   es
     e7c:	57                   	push   di
     e7d:	9a d5 1e 6b 0f       	call   0xf6b:0x1ed5
     e82:	6a 02                	push   0x2
     e84:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e87:	06                   	push   es
     e88:	57                   	push   di
     e89:	9a 14 3a 96 0e       	call   0xe96:0x3a14
     e8e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     e91:	06                   	push   es
     e92:	57                   	push   di
     e93:	9a 45 5d ac 0e       	call   0xeac:0x5d45
     e98:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     e9c:	83 c4 06             	add    sp,0x6
     e9f:	b8 af 0e             	mov    ax,0xeaf
     ea2:	0e                   	push   cs
     ea3:	50                   	push   ax
     ea4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ea7:	06                   	push   es
     ea8:	57                   	push   di
     ea9:	9a 1d 5f d0 0e       	call   0xed0:0x5f1d
     eae:	cb                   	retf
     eaf:	c9                   	leave
     eb0:	ca 04 00             	retf   0x4
     eb3:	00 00                	add    BYTE PTR [bx+si],al
     eb5:	f7 0f 12 0f          	test   WORD PTR [bx],0xf12
     eb9:	55                   	push   bp
     eba:	89 e5                	mov    bp,sp
     ebc:	b8 0a 00             	mov    ax,0xa
     ebf:	9a 44 04 0e 10       	call   0x100e:0x444
     ec4:	83 ec 0a             	sub    sp,0xa
     ec7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     ecb:	06                   	push   es
     ecc:	57                   	push   di
     ecd:	9a 03 73 19 0f       	call   0xf19:0x7303
     ed2:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
     ed6:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
     eda:	7e 1e                	jle    0xefa
     edc:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     ee0:	75 14                	jne    0xef6
     ee2:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     ee6:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
     eec:	b0 00                	mov    al,0x0
     eee:	75 01                	jne    0xef1
     ef0:	40                   	inc    ax
     ef1:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     ef4:	eb 04                	jmp    0xefa
     ef6:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
     efa:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
     efe:	75 03                	jne    0xf03
     f00:	e9 ff 00             	jmp    0x1002
     f03:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     f07:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     f0b:	b0 01                	mov    al,0x1
     f0d:	50                   	push   ax
     f0e:	b8 22 00             	mov    ax,0x22
     f11:	ba 4d 0f             	mov    dx,0xf4d
     f14:	52                   	push   dx
     f15:	50                   	push   ax
     f16:	9a 53 25 79 0f       	call   0xf79:0x2553
     f1b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f1e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f21:	b8 b3 0e             	mov    ax,0xeb3
     f24:	0e                   	push   cs
     f25:	50                   	push   ax
     f26:	55                   	push   bp
     f27:	ff 36 58 18          	push   WORD PTR ds:0x1858
     f2b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     f2f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     f32:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     f35:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     f38:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     f3b:	26 89 85 4c 04       	mov    WORD PTR es:[di+0x44c],ax
     f40:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     f43:	26 89 85 4a 04       	mov    WORD PTR es:[di+0x44a],ax
     f48:	06                   	push   es
     f49:	57                   	push   di
     f4a:	9a ea 1a 5c 0f       	call   0xf5c:0x1aea
     f4f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f52:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
     f57:	06                   	push   es
     f58:	57                   	push   di
     f59:	9a da 1f b3 0f       	call   0xfb3:0x1fda
     f5e:	68 ff 00             	push   0xff
     f61:	6a ff                	push   0xffff
     f63:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f66:	06                   	push   es
     f67:	57                   	push   di
     f68:	9a d5 1e 9b 0f       	call   0xf9b:0x1ed5
     f6d:	6a 00                	push   0x0
     f6f:	6a 00                	push   0x0
     f71:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f74:	06                   	push   es
     f75:	57                   	push   di
     f76:	9a b2 36 85 0f       	call   0xf85:0x36b2
     f7b:	6a 02                	push   0x2
     f7d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f80:	06                   	push   es
     f81:	57                   	push   di
     f82:	9a 14 3a 91 0f       	call   0xf91:0x3a14
     f87:	6a 01                	push   0x1
     f89:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f8c:	06                   	push   es
     f8d:	57                   	push   di
     f8e:	9a e5 34 c0 0f       	call   0xfc0:0x34e5
     f93:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     f96:	06                   	push   es
     f97:	57                   	push   di
     f98:	9a b9 62 e6 15       	call   0x15e6:0x62b9
     f9d:	50                   	push   ax
     f9e:	6a 04                	push   0x4
     fa0:	9a ff ff 00 00       	call   0x0:0xffff
     fa5:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     fa9:	74 0c                	je     0xfb7
     fab:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     fae:	06                   	push   es
     faf:	57                   	push   di
     fb0:	9a 96 32 22 10       	call   0x1022:0x3296
     fb5:	eb 34                	jmp    0xfeb
     fb7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     fbb:	06                   	push   es
     fbc:	57                   	push   di
     fbd:	9a 03 73 e9 0f       	call   0xfe9:0x7303
     fc2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fc5:	ff 76 fc             	push   WORD PTR [bp-0x4]
     fc8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     fcb:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
     fd0:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
     fd5:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     fd9:	06                   	push   es
     fda:	57                   	push   di
     fdb:	9a 1a 31 83 10       	call   0x1083:0x311a
     fe0:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     fe4:	06                   	push   es
     fe5:	57                   	push   di
     fe6:	9a 03 73 ff 0f       	call   0xfff:0x7303
     feb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     fef:	83 c4 06             	add    sp,0x6
     ff2:	b8 02 10             	mov    ax,0x1002
     ff5:	0e                   	push   cs
     ff6:	50                   	push   ax
     ff7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ffa:	06                   	push   es
     ffb:	57                   	push   di
     ffc:	9a 1d 5f 74 10       	call   0x1074:0x5f1d
    1001:	cb                   	retf
    1002:	c9                   	leave
    1003:	ca 06 00             	retf   0x6
    1006:	55                   	push   bp
    1007:	89 e5                	mov    bp,sp
    1009:	31 c0                	xor    ax,ax
    100b:	9a 44 04 37 10       	call   0x1037:0x444
    1010:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1013:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    1018:	26 ff b5 4c 04       	push   WORD PTR es:[di+0x44c]
    101d:	6a 00                	push   0x0
    101f:	9a b9 0e 2c 10       	call   0x102c:0xeb9
    1024:	c9                   	leave
    1025:	ca 08 00             	retf   0x8
    1028:	00 00                	add    BYTE PTR [bx+si],al
    102a:	e9 10 bd             	jmp    0xcd3d
    102d:	10 55 89             	adc    BYTE PTR [di-0x77],dl
    1030:	e5 b8                	in     ax,0xb8
    1032:	08 00                	or     BYTE PTR [bx+si],al
    1034:	9a 44 04 38 11       	call   0x1138:0x444
    1039:	83 ec 08             	sub    sp,0x8
    103c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    103f:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    1044:	06                   	push   es
    1045:	57                   	push   di
    1046:	9a 17 2f 17 32       	call   0x3217:0x2f17
    104b:	08 c0                	or     al,al
    104d:	75 03                	jne    0x1052
    104f:	e9 b3 00             	jmp    0x1105
    1052:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1055:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    105a:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    105f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1062:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1065:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    106a:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    106f:	06                   	push   es
    1070:	57                   	push   di
    1071:	9a d0 3f 8a 10       	call   0x108a:0x3fd0
    1076:	ff 76 08             	push   WORD PTR [bp+0x8]
    1079:	ff 76 06             	push   WORD PTR [bp+0x6]
    107c:	b0 01                	mov    al,0x1
    107e:	50                   	push   ax
    107f:	b8 b4 25             	mov    ax,0x25b4
    1082:	ba b2 10             	mov    dx,0x10b2
    1085:	52                   	push   dx
    1086:	50                   	push   ax
    1087:	9a 53 25 db 10       	call   0x10db:0x2553
    108c:	a3 04 20             	mov    ds:0x2004,ax
    108f:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    1093:	b8 28 10             	mov    ax,0x1028
    1096:	0e                   	push   cs
    1097:	50                   	push   ax
    1098:	55                   	push   bp
    1099:	ff 36 58 18          	push   WORD PTR ds:0x1858
    109d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    10a1:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    10a5:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    10a8:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    10ab:	6a 01                	push   0x1
    10ad:	06                   	push   es
    10ae:	57                   	push   di
    10af:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    10b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10b7:	06                   	push   es
    10b8:	57                   	push   di
    10b9:	b8 06 10             	mov    ax,0x1006
    10bc:	ba dc 1a             	mov    dx,0x1adc
    10bf:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    10c2:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    10c7:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    10cc:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    10d1:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    10d6:	06                   	push   es
    10d7:	57                   	push   di
    10d8:	9a 45 5d f2 10       	call   0x10f2:0x5d45
    10dd:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    10e1:	83 c4 06             	add    sp,0x6
    10e4:	b8 f5 10             	mov    ax,0x10f5
    10e7:	0e                   	push   cs
    10e8:	50                   	push   ax
    10e9:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    10ed:	06                   	push   es
    10ee:	57                   	push   di
    10ef:	9a 1d 5f 03 11       	call   0x1103:0x5f1d
    10f4:	cb                   	retf
    10f5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    10fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10fe:	06                   	push   es
    10ff:	57                   	push   di
    1100:	9a d0 3f 51 11       	call   0x1151:0x3fd0
    1105:	c9                   	leave
    1106:	ca 08 00             	retf   0x8
    1109:	0a 23                	or     ah,BYTE PTR [bp+di]
    110b:	2c 23                	sub    al,0x23
    110d:	23 30                	and    si,WORD PTR [bx+si]
    110f:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1112:	23 23                	and    sp,WORD PTR [bp+di]
    1114:	07                   	pop    es
    1115:	23 30                	and    si,WORD PTR [bx+si]
    1117:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    111a:	23 23                	and    sp,WORD PTR [bp+di]
    111c:	07                   	pop    es
    111d:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    1121:	2b 30                	sub    si,WORD PTR [bx+si]
    1123:	30 01                	xor    BYTE PTR [bx+di],al
    1125:	30 05                	xor    BYTE PTR [di],al
    1127:	23 2c                	and    bp,WORD PTR [si]
    1129:	23 23                	and    sp,WORD PTR [bp+di]
    112b:	30 02                	xor    BYTE PTR [bp+si],al
    112d:	23 30                	and    si,WORD PTR [bx+si]
    112f:	55                   	push   bp
    1130:	89 e5                	mov    bp,sp
    1132:	b8 14 03             	mov    ax,0x314
    1135:	9a 44 04 ca 11       	call   0x11ca:0x444
    113a:	81 ec 14 03          	sub    sp,0x314
    113e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1141:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    1145:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    1149:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    114c:	06                   	push   es
    114d:	57                   	push   di
    114e:	9a d5 33 7b 11       	call   0x117b:0x33d5
    1153:	89 c7                	mov    di,ax
    1155:	8e c2                	mov    es,dx
    1157:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    115b:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    115f:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    1163:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    1167:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    116b:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    116f:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1173:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1176:	06                   	push   es
    1177:	57                   	push   di
    1178:	9a d5 33 4a 12       	call   0x124a:0x33d5
    117d:	89 c7                	mov    di,ax
    117f:	8e c2                	mov    es,dx
    1181:	06                   	push   es
    1182:	57                   	push   di
    1183:	9a 99 20 55 12       	call   0x1255:0x2099
    1188:	8d be f4 fc          	lea    di,[bp-0x30c]
    118c:	16                   	push   ss
    118d:	57                   	push   di
    118e:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1192:	06                   	push   es
    1193:	57                   	push   di
    1194:	9a 9f 1a a2 11       	call   0x11a2:0x1a9f
    1199:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    119d:	06                   	push   es
    119e:	57                   	push   di
    119f:	9a 5f 1a b3 15       	call   0x15b3:0x1a5f
    11a4:	89 c7                	mov    di,ax
    11a6:	8e c2                	mov    es,dx
    11a8:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    11ac:	06                   	push   es
    11ad:	57                   	push   di
    11ae:	9a 9b 3b 39 17       	call   0x1739:0x3b9b
    11b3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    11b6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    11b9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    11bc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    11bf:	bf 58 0a             	mov    di,0xa58
    11c2:	b8 dd 11             	mov    ax,0x11dd
    11c5:	50                   	push   ax
    11c6:	57                   	push   di
    11c7:	9a 55 22 e4 11       	call   0x11e4:0x2255
    11cc:	08 c0                	or     al,al
    11ce:	75 03                	jne    0x11d3
    11d0:	e9 bb 01             	jmp    0x138e
    11d3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    11d6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    11d9:	bf 58 0a             	mov    di,0xa58
    11dc:	b8 89 13             	mov    ax,0x1389
    11df:	50                   	push   ax
    11e0:	57                   	push   di
    11e1:	9a 73 22 03 12       	call   0x1203:0x2273
    11e6:	89 c7                	mov    di,ax
    11e8:	8e c2                	mov    es,dx
    11ea:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    11ee:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    11f2:	bf 09 11             	mov    di,0x1109
    11f5:	0e                   	push   cs
    11f6:	57                   	push   di
    11f7:	8d be fc fd          	lea    di,[bp-0x204]
    11fb:	16                   	push   ss
    11fc:	57                   	push   di
    11fd:	68 ff 00             	push   0xff
    1200:	9a e7 17 3a 12       	call   0x123a:0x17e7
    1205:	8d be f0 fc          	lea    di,[bp-0x310]
    1209:	16                   	push   ss
    120a:	57                   	push   di
    120b:	8d be fc fd          	lea    di,[bp-0x204]
    120f:	16                   	push   ss
    1210:	57                   	push   di
    1211:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1215:	06                   	push   es
    1216:	57                   	push   di
    1217:	26 c4 3d             	les    di,DWORD PTR es:[di]
    121a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    121e:	83 ec 0a             	sub    sp,0xa
    1221:	89 e3                	mov    bx,sp
    1223:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1227:	90                   	nop
    1228:	9b                   	fwait
    1229:	9a d4 10 ac 12       	call   0x12ac:0x10d4
    122e:	8d be fc fe          	lea    di,[bp-0x104]
    1232:	16                   	push   ss
    1233:	57                   	push   di
    1234:	68 ff 00             	push   0xff
    1237:	9a e7 17 69 12       	call   0x1269:0x17e7
    123c:	8d be fc fe          	lea    di,[bp-0x104]
    1240:	16                   	push   ss
    1241:	57                   	push   di
    1242:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1245:	06                   	push   es
    1246:	57                   	push   di
    1247:	9a d5 33 ca 12       	call   0x12ca:0x33d5
    124c:	89 c7                	mov    di,ax
    124e:	8e c2                	mov    es,dx
    1250:	06                   	push   es
    1251:	57                   	push   di
    1252:	9a 03 20 d5 12       	call   0x12d5:0x2003
    1257:	8b d0                	mov    dx,ax
    1259:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    125d:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1261:	2d 05 00             	sub    ax,0x5
    1264:	71 05                	jno    0x126b
    1266:	9a 3e 04 83 12       	call   0x1283:0x43e
    126b:	3b c2                	cmp    ax,dx
    126d:	7e 03                	jle    0x1272
    126f:	e9 08 01             	jmp    0x137a
    1272:	bf 14 11             	mov    di,0x1114
    1275:	0e                   	push   cs
    1276:	57                   	push   di
    1277:	8d be fc fd          	lea    di,[bp-0x204]
    127b:	16                   	push   ss
    127c:	57                   	push   di
    127d:	68 ff 00             	push   0xff
    1280:	9a e7 17 ba 12       	call   0x12ba:0x17e7
    1285:	8d be f0 fc          	lea    di,[bp-0x310]
    1289:	16                   	push   ss
    128a:	57                   	push   di
    128b:	8d be fc fd          	lea    di,[bp-0x204]
    128f:	16                   	push   ss
    1290:	57                   	push   di
    1291:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1295:	06                   	push   es
    1296:	57                   	push   di
    1297:	26 c4 3d             	les    di,DWORD PTR es:[di]
    129a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    129e:	83 ec 0a             	sub    sp,0xa
    12a1:	89 e3                	mov    bx,sp
    12a3:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    12a7:	90                   	nop
    12a8:	9b                   	fwait
    12a9:	9a d4 10 0e 14       	call   0x140e:0x10d4
    12ae:	8d be fc fe          	lea    di,[bp-0x104]
    12b2:	16                   	push   ss
    12b3:	57                   	push   di
    12b4:	68 ff 00             	push   0xff
    12b7:	9a e7 17 e9 12       	call   0x12e9:0x17e7
    12bc:	8d be fc fe          	lea    di,[bp-0x104]
    12c0:	16                   	push   ss
    12c1:	57                   	push   di
    12c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c5:	06                   	push   es
    12c6:	57                   	push   di
    12c7:	9a d5 33 13 13       	call   0x1313:0x33d5
    12cc:	89 c7                	mov    di,ax
    12ce:	8e c2                	mov    es,dx
    12d0:	06                   	push   es
    12d1:	57                   	push   di
    12d2:	9a 03 20 1e 13       	call   0x131e:0x2003
    12d7:	8b d0                	mov    dx,ax
    12d9:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    12dd:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    12e1:	2d 05 00             	sub    ax,0x5
    12e4:	71 05                	jno    0x12eb
    12e6:	9a 3e 04 03 13       	call   0x1303:0x43e
    12eb:	3b c2                	cmp    ax,dx
    12ed:	7e 03                	jle    0x12f2
    12ef:	e9 88 00             	jmp    0x137a
    12f2:	bf 1c 11             	mov    di,0x111c
    12f5:	0e                   	push   cs
    12f6:	57                   	push   di
    12f7:	8d be fc fd          	lea    di,[bp-0x204]
    12fb:	16                   	push   ss
    12fc:	57                   	push   di
    12fd:	68 ff 00             	push   0xff
    1300:	9a e7 17 32 13       	call   0x1332:0x17e7
    1305:	8d be fc fd          	lea    di,[bp-0x204]
    1309:	16                   	push   ss
    130a:	57                   	push   di
    130b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    130e:	06                   	push   es
    130f:	57                   	push   di
    1310:	9a d5 33 2c 14       	call   0x142c:0x33d5
    1315:	89 c7                	mov    di,ax
    1317:	8e c2                	mov    es,dx
    1319:	06                   	push   es
    131a:	57                   	push   di
    131b:	9a 03 20 37 14       	call   0x1437:0x2003
    1320:	8b d0                	mov    dx,ax
    1322:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1326:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    132a:	2d 05 00             	sub    ax,0x5
    132d:	71 05                	jno    0x1334
    132f:	9a 3e 04 60 13       	call   0x1360:0x43e
    1334:	3b c2                	cmp    ax,dx
    1336:	b0 00                	mov    al,0x0
    1338:	7e 01                	jle    0x133b
    133a:	40                   	inc    ax
    133b:	8a d0                	mov    dl,al
    133d:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1342:	b0 00                	mov    al,0x0
    1344:	73 01                	jae    0x1347
    1346:	40                   	inc    ax
    1347:	22 c2                	and    al,dl
    1349:	08 c0                	or     al,al
    134b:	74 17                	je     0x1364
    134d:	bf 24 11             	mov    di,0x1124
    1350:	0e                   	push   cs
    1351:	57                   	push   di
    1352:	8d be fc fd          	lea    di,[bp-0x204]
    1356:	16                   	push   ss
    1357:	57                   	push   di
    1358:	68 ff 00             	push   0xff
    135b:	6a 03                	push   0x3
    135d:	9a 16 19 78 13       	call   0x1378:0x1916
    1362:	eb a1                	jmp    0x1305
    1364:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1369:	76 0f                	jbe    0x137a
    136b:	8d be fc fd          	lea    di,[bp-0x204]
    136f:	16                   	push   ss
    1370:	57                   	push   di
    1371:	6a 03                	push   0x3
    1373:	6a 01                	push   0x1
    1375:	9a 75 19 9f 13       	call   0x139f:0x1975
    137a:	8d be fc fd          	lea    di,[bp-0x204]
    137e:	16                   	push   ss
    137f:	57                   	push   di
    1380:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1384:	06                   	push   es
    1385:	57                   	push   di
    1386:	9a f9 60 98 13       	call   0x1398:0x60f9
    138b:	e9 ec 01             	jmp    0x157a
    138e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1391:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1394:	bf c8 07             	mov    di,0x7c8
    1397:	b8 b2 13             	mov    ax,0x13b2
    139a:	50                   	push   ax
    139b:	57                   	push   di
    139c:	9a 55 22 b9 13       	call   0x13b9:0x2255
    13a1:	08 c0                	or     al,al
    13a3:	75 03                	jne    0x13a8
    13a5:	e9 d2 01             	jmp    0x157a
    13a8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    13ab:	ff 76 fc             	push   WORD PTR [bp-0x4]
    13ae:	bf c8 07             	mov    di,0x7c8
    13b1:	b8 78 15             	mov    ax,0x1578
    13b4:	50                   	push   ax
    13b5:	57                   	push   di
    13b6:	9a 73 22 d8 13       	call   0x13d8:0x2273
    13bb:	89 c7                	mov    di,ax
    13bd:	8e c2                	mov    es,dx
    13bf:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    13c3:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    13c7:	bf 26 11             	mov    di,0x1126
    13ca:	0e                   	push   cs
    13cb:	57                   	push   di
    13cc:	8d be fc fd          	lea    di,[bp-0x204]
    13d0:	16                   	push   ss
    13d1:	57                   	push   di
    13d2:	68 ff 00             	push   0xff
    13d5:	9a e7 17 1c 14       	call   0x141c:0x17e7
    13da:	8d be ec fc          	lea    di,[bp-0x314]
    13de:	16                   	push   ss
    13df:	57                   	push   di
    13e0:	8d be fc fd          	lea    di,[bp-0x204]
    13e4:	16                   	push   ss
    13e5:	57                   	push   di
    13e6:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    13ea:	06                   	push   es
    13eb:	57                   	push   di
    13ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13ef:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    13f3:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    13f7:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    13fb:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1400:	83 ec 0a             	sub    sp,0xa
    1403:	89 e3                	mov    bx,sp
    1405:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1409:	90                   	nop
    140a:	9b                   	fwait
    140b:	9a d4 10 9b 14       	call   0x149b:0x10d4
    1410:	8d be fc fe          	lea    di,[bp-0x104]
    1414:	16                   	push   ss
    1415:	57                   	push   di
    1416:	68 ff 00             	push   0xff
    1419:	9a e7 17 4b 14       	call   0x144b:0x17e7
    141e:	8d be fc fe          	lea    di,[bp-0x104]
    1422:	16                   	push   ss
    1423:	57                   	push   di
    1424:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1427:	06                   	push   es
    1428:	57                   	push   di
    1429:	9a d5 33 b9 14       	call   0x14b9:0x33d5
    142e:	89 c7                	mov    di,ax
    1430:	8e c2                	mov    es,dx
    1432:	06                   	push   es
    1433:	57                   	push   di
    1434:	9a 03 20 c4 14       	call   0x14c4:0x2003
    1439:	8b d0                	mov    dx,ax
    143b:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    143f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1443:	2d 05 00             	sub    ax,0x5
    1446:	71 05                	jno    0x144d
    1448:	9a 3e 04 65 14       	call   0x1465:0x43e
    144d:	3b c2                	cmp    ax,dx
    144f:	7e 03                	jle    0x1454
    1451:	e9 15 01             	jmp    0x1569
    1454:	bf 2c 11             	mov    di,0x112c
    1457:	0e                   	push   cs
    1458:	57                   	push   di
    1459:	8d be fc fd          	lea    di,[bp-0x204]
    145d:	16                   	push   ss
    145e:	57                   	push   di
    145f:	68 ff 00             	push   0xff
    1462:	9a e7 17 a9 14       	call   0x14a9:0x17e7
    1467:	8d be ec fc          	lea    di,[bp-0x314]
    146b:	16                   	push   ss
    146c:	57                   	push   di
    146d:	8d be fc fd          	lea    di,[bp-0x204]
    1471:	16                   	push   ss
    1472:	57                   	push   di
    1473:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1477:	06                   	push   es
    1478:	57                   	push   di
    1479:	26 c4 3d             	les    di,DWORD PTR es:[di]
    147c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1480:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1484:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1488:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    148d:	83 ec 0a             	sub    sp,0xa
    1490:	89 e3                	mov    bx,sp
    1492:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1496:	90                   	nop
    1497:	9b                   	fwait
    1498:	9a d4 10 9d 17       	call   0x179d:0x10d4
    149d:	8d be fc fe          	lea    di,[bp-0x104]
    14a1:	16                   	push   ss
    14a2:	57                   	push   di
    14a3:	68 ff 00             	push   0xff
    14a6:	9a e7 17 d8 14       	call   0x14d8:0x17e7
    14ab:	8d be fc fe          	lea    di,[bp-0x104]
    14af:	16                   	push   ss
    14b0:	57                   	push   di
    14b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14b4:	06                   	push   es
    14b5:	57                   	push   di
    14b6:	9a d5 33 02 15       	call   0x1502:0x33d5
    14bb:	89 c7                	mov    di,ax
    14bd:	8e c2                	mov    es,dx
    14bf:	06                   	push   es
    14c0:	57                   	push   di
    14c1:	9a 03 20 0d 15       	call   0x150d:0x2003
    14c6:	8b d0                	mov    dx,ax
    14c8:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    14cc:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    14d0:	2d 05 00             	sub    ax,0x5
    14d3:	71 05                	jno    0x14da
    14d5:	9a 3e 04 f2 14       	call   0x14f2:0x43e
    14da:	3b c2                	cmp    ax,dx
    14dc:	7e 03                	jle    0x14e1
    14de:	e9 88 00             	jmp    0x1569
    14e1:	bf 1c 11             	mov    di,0x111c
    14e4:	0e                   	push   cs
    14e5:	57                   	push   di
    14e6:	8d be fc fd          	lea    di,[bp-0x204]
    14ea:	16                   	push   ss
    14eb:	57                   	push   di
    14ec:	68 ff 00             	push   0xff
    14ef:	9a e7 17 21 15       	call   0x1521:0x17e7
    14f4:	8d be fc fd          	lea    di,[bp-0x204]
    14f8:	16                   	push   ss
    14f9:	57                   	push   di
    14fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14fd:	06                   	push   es
    14fe:	57                   	push   di
    14ff:	9a d5 33 8e 15       	call   0x158e:0x33d5
    1504:	89 c7                	mov    di,ax
    1506:	8e c2                	mov    es,dx
    1508:	06                   	push   es
    1509:	57                   	push   di
    150a:	9a 03 20 99 15       	call   0x1599:0x2003
    150f:	8b d0                	mov    dx,ax
    1511:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1515:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1519:	2d 05 00             	sub    ax,0x5
    151c:	71 05                	jno    0x1523
    151e:	9a 3e 04 4f 15       	call   0x154f:0x43e
    1523:	3b c2                	cmp    ax,dx
    1525:	b0 00                	mov    al,0x0
    1527:	7e 01                	jle    0x152a
    1529:	40                   	inc    ax
    152a:	8a d0                	mov    dl,al
    152c:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1531:	b0 00                	mov    al,0x0
    1533:	73 01                	jae    0x1536
    1535:	40                   	inc    ax
    1536:	22 c2                	and    al,dl
    1538:	08 c0                	or     al,al
    153a:	74 17                	je     0x1553
    153c:	bf 24 11             	mov    di,0x1124
    153f:	0e                   	push   cs
    1540:	57                   	push   di
    1541:	8d be fc fd          	lea    di,[bp-0x204]
    1545:	16                   	push   ss
    1546:	57                   	push   di
    1547:	68 ff 00             	push   0xff
    154a:	6a 03                	push   0x3
    154c:	9a 16 19 67 15       	call   0x1567:0x1916
    1551:	eb a1                	jmp    0x14f4
    1553:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1558:	76 0f                	jbe    0x1569
    155a:	8d be fc fd          	lea    di,[bp-0x204]
    155e:	16                   	push   ss
    155f:	57                   	push   di
    1560:	6a 03                	push   0x3
    1562:	6a 01                	push   0x1
    1564:	9a 75 19 a7 15       	call   0x15a7:0x1975
    1569:	8d be fc fd          	lea    di,[bp-0x204]
    156d:	16                   	push   ss
    156e:	57                   	push   di
    156f:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1573:	06                   	push   es
    1574:	57                   	push   di
    1575:	9a f9 60 4b 17       	call   0x174b:0x60f9
    157a:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    157e:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1582:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1586:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1589:	06                   	push   es
    158a:	57                   	push   di
    158b:	9a d5 33 b2 16       	call   0x16b2:0x33d5
    1590:	89 c7                	mov    di,ax
    1592:	8e c2                	mov    es,dx
    1594:	06                   	push   es
    1595:	57                   	push   di
    1596:	9a 99 20 15 19       	call   0x1915:0x2099
    159b:	c9                   	leave
    159c:	ca 08 00             	retf   0x8
    159f:	55                   	push   bp
    15a0:	89 e5                	mov    bp,sp
    15a2:	31 c0                	xor    ax,ax
    15a4:	9a 44 04 ba 15       	call   0x15ba:0x444
    15a9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15ac:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15af:	bf a2 0b             	mov    di,0xba2
    15b2:	b8 c7 15             	mov    ax,0x15c7
    15b5:	50                   	push   ax
    15b6:	57                   	push   di
    15b7:	9a 55 22 ce 15       	call   0x15ce:0x2255
    15bc:	50                   	push   ax
    15bd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15c0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15c3:	bf 22 00             	mov    di,0x22
    15c6:	b8 09 16             	mov    ax,0x1609
    15c9:	50                   	push   ax
    15ca:	57                   	push   di
    15cb:	9a 55 22 f4 15       	call   0x15f4:0x2255
    15d0:	5a                   	pop    dx
    15d1:	0a c2                	or     al,dl
    15d3:	08 c0                	or     al,al
    15d5:	74 11                	je     0x15e8
    15d7:	6a 00                	push   0x0
    15d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15dc:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    15e1:	06                   	push   es
    15e2:	57                   	push   di
    15e3:	9a 77 1c 3c 16       	call   0x163c:0x1c77
    15e8:	c9                   	leave
    15e9:	ca 08 00             	retf   0x8
    15ec:	55                   	push   bp
    15ed:	89 e5                	mov    bp,sp
    15ef:	31 c0                	xor    ax,ax
    15f1:	9a 44 04 10 16       	call   0x1610:0x444
    15f6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    15f9:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    15fd:	75 3f                	jne    0x163e
    15ff:	ff 76 12             	push   WORD PTR [bp+0x12]
    1602:	ff 76 10             	push   WORD PTR [bp+0x10]
    1605:	bf a2 0b             	mov    di,0xba2
    1608:	b8 1d 16             	mov    ax,0x161d
    160b:	50                   	push   ax
    160c:	57                   	push   di
    160d:	9a 55 22 24 16       	call   0x1624:0x2255
    1612:	50                   	push   ax
    1613:	ff 76 12             	push   WORD PTR [bp+0x12]
    1616:	ff 76 10             	push   WORD PTR [bp+0x10]
    1619:	bf 22 00             	mov    di,0x22
    161c:	b8 e1 16             	mov    ax,0x16e1
    161f:	50                   	push   ax
    1620:	57                   	push   di
    1621:	9a 55 22 58 16       	call   0x1658:0x2255
    1626:	5a                   	pop    dx
    1627:	0a c2                	or     al,dl
    1629:	08 c0                	or     al,al
    162b:	74 11                	je     0x163e
    162d:	6a 00                	push   0x0
    162f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1632:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1637:	06                   	push   es
    1638:	57                   	push   di
    1639:	9a 77 1c 71 16       	call   0x1671:0x1c77
    163e:	c9                   	leave
    163f:	ca 0e 00             	retf   0xe
    1642:	0a 23                	or     ah,BYTE PTR [bp+di]
    1644:	2c 23                	sub    al,0x23
    1646:	23 30                	and    si,WORD PTR [bx+si]
    1648:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    164b:	23 23                	and    sp,WORD PTR [bp+di]
    164d:	01 20                	add    WORD PTR [bx+si],sp
    164f:	55                   	push   bp
    1650:	89 e5                	mov    bp,sp
    1652:	b8 10 02             	mov    ax,0x210
    1655:	9a 44 04 78 16       	call   0x1678:0x444
    165a:	81 ec 10 02          	sub    sp,0x210
    165e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1661:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    1665:	75 4d                	jne    0x16b4
    1667:	ff 76 12             	push   WORD PTR [bp+0x12]
    166a:	ff 76 10             	push   WORD PTR [bp+0x10]
    166d:	bf c1 05             	mov    di,0x5c1
    1670:	b8 92 16             	mov    ax,0x1692
    1673:	50                   	push   ax
    1674:	57                   	push   di
    1675:	9a 55 22 99 16       	call   0x1699:0x2255
    167a:	08 c0                	or     al,al
    167c:	74 36                	je     0x16b4
    167e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1681:	31 c0                	xor    ax,ax
    1683:	26 89 05             	mov    WORD PTR es:[di],ax
    1686:	6a 08                	push   0x8
    1688:	ff 76 12             	push   WORD PTR [bp+0x12]
    168b:	ff 76 10             	push   WORD PTR [bp+0x10]
    168e:	bf c1 05             	mov    di,0x5c1
    1691:	b8 07 18             	mov    ax,0x1807
    1694:	50                   	push   ax
    1695:	57                   	push   di
    1696:	9a 73 22 e8 16       	call   0x16e8:0x2273
    169b:	89 c7                	mov    di,ax
    169d:	8e c2                	mov    es,dx
    169f:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    16a4:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    16a9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    16ad:	06                   	push   es
    16ae:	57                   	push   di
    16af:	9a b2 77 ee 18       	call   0x18ee:0x77b2
    16b4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    16b7:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    16bb:	74 03                	je     0x16c0
    16bd:	e9 9e 03             	jmp    0x1a5e
    16c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c3:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    16c8:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    16cd:	74 03                	je     0x16d2
    16cf:	e9 8c 03             	jmp    0x1a5e
    16d2:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    16d7:	ff 76 12             	push   WORD PTR [bp+0x12]
    16da:	ff 76 10             	push   WORD PTR [bp+0x10]
    16dd:	bf 22 00             	mov    di,0x22
    16e0:	b8 fb 16             	mov    ax,0x16fb
    16e3:	50                   	push   ax
    16e4:	57                   	push   di
    16e5:	9a 55 22 02 17       	call   0x1702:0x2255
    16ea:	08 c0                	or     al,al
    16ec:	75 03                	jne    0x16f1
    16ee:	e9 1e 01             	jmp    0x180f
    16f1:	ff 76 12             	push   WORD PTR [bp+0x12]
    16f4:	ff 76 10             	push   WORD PTR [bp+0x10]
    16f7:	bf 22 00             	mov    di,0x22
    16fa:	b8 1f 17             	mov    ax,0x171f
    16fd:	50                   	push   ax
    16fe:	57                   	push   di
    16ff:	9a 73 22 52 17       	call   0x1752:0x2273
    1704:	89 c7                	mov    di,ax
    1706:	8e c2                	mov    es,dx
    1708:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    170c:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1710:	8d be f4 fd          	lea    di,[bp-0x20c]
    1714:	16                   	push   ss
    1715:	57                   	push   di
    1716:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    171a:	06                   	push   es
    171b:	57                   	push   di
    171c:	9a 9f 1a 2a 17       	call   0x172a:0x1a9f
    1721:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1725:	06                   	push   es
    1726:	57                   	push   di
    1727:	9a 5f 1a 19 18       	call   0x1819:0x1a5f
    172c:	89 c7                	mov    di,ax
    172e:	8e c2                	mov    es,dx
    1730:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1734:	06                   	push   es
    1735:	57                   	push   di
    1736:	9a 9b 3b 0b 1b       	call   0x1b0b:0x3b9b
    173b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    173e:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1741:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1744:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1747:	bf 58 0a             	mov    di,0xa58
    174a:	b8 62 17             	mov    ax,0x1762
    174d:	50                   	push   ax
    174e:	57                   	push   di
    174f:	9a 55 22 69 17       	call   0x1769:0x2255
    1754:	08 c0                	or     al,al
    1756:	74 57                	je     0x17af
    1758:	ff 76 fa             	push   WORD PTR [bp-0x6]
    175b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    175e:	bf 58 0a             	mov    di,0xa58
    1761:	b8 17 1b             	mov    ax,0x1b17
    1764:	50                   	push   ax
    1765:	57                   	push   di
    1766:	9a 73 22 ab 17       	call   0x17ab:0x2273
    176b:	89 c7                	mov    di,ax
    176d:	8e c2                	mov    es,dx
    176f:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    1773:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    1777:	8d be f0 fd          	lea    di,[bp-0x210]
    177b:	16                   	push   ss
    177c:	57                   	push   di
    177d:	bf 42 16             	mov    di,0x1642
    1780:	0e                   	push   cs
    1781:	57                   	push   di
    1782:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1786:	06                   	push   es
    1787:	57                   	push   di
    1788:	26 c4 3d             	les    di,DWORD PTR es:[di]
    178b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    178f:	83 ec 0a             	sub    sp,0xa
    1792:	89 e3                	mov    bx,sp
    1794:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1798:	90                   	nop
    1799:	9b                   	fwait
    179a:	9a d4 10 05 1c       	call   0x1c05:0x10d4
    179f:	8d be f8 fe          	lea    di,[bp-0x108]
    17a3:	16                   	push   ss
    17a4:	57                   	push   di
    17a5:	68 ff 00             	push   0xff
    17a8:	9a e7 17 cc 17       	call   0x17cc:0x17e7
    17ad:	eb 1f                	jmp    0x17ce
    17af:	8d be f4 fd          	lea    di,[bp-0x20c]
    17b3:	16                   	push   ss
    17b4:	57                   	push   di
    17b5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    17b9:	06                   	push   es
    17ba:	57                   	push   di
    17bb:	9a 24 15 b3 39       	call   0x39b3:0x1524
    17c0:	8d be f8 fe          	lea    di,[bp-0x108]
    17c4:	16                   	push   ss
    17c5:	57                   	push   di
    17c6:	68 ff 00             	push   0xff
    17c9:	9a e7 17 de 17       	call   0x17de:0x17e7
    17ce:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    17d2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    17d6:	2d 04 00             	sub    ax,0x4
    17d9:	71 05                	jno    0x17e0
    17db:	9a 3e 04 f3 17       	call   0x17f3:0x43e
    17e0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17e3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    17e7:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    17eb:	2d 04 00             	sub    ax,0x4
    17ee:	71 05                	jno    0x17f5
    17f0:	9a 3e 04 20 18       	call   0x1820:0x43e
    17f5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    17f8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17fb:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17fe:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1802:	06                   	push   es
    1803:	57                   	push   di
    1804:	9a d4 19 57 18       	call   0x1857:0x19d4
    1809:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    180c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    180f:	ff 76 12             	push   WORD PTR [bp+0x12]
    1812:	ff 76 10             	push   WORD PTR [bp+0x10]
    1815:	bf a2 0b             	mov    di,0xba2
    1818:	b8 33 18             	mov    ax,0x1833
    181b:	50                   	push   ax
    181c:	57                   	push   di
    181d:	9a 55 22 3a 18       	call   0x183a:0x2255
    1822:	08 c0                	or     al,al
    1824:	75 03                	jne    0x1829
    1826:	e9 7f 00             	jmp    0x18a8
    1829:	ff 76 12             	push   WORD PTR [bp+0x12]
    182c:	ff 76 10             	push   WORD PTR [bp+0x10]
    182f:	bf a2 0b             	mov    di,0xba2
    1832:	b8 a9 1a             	mov    ax,0x1aa9
    1835:	50                   	push   ax
    1836:	57                   	push   di
    1837:	9a 73 22 65 18       	call   0x1865:0x2273
    183c:	89 c7                	mov    di,ax
    183e:	8e c2                	mov    es,dx
    1840:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1844:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1848:	8d be f4 fd          	lea    di,[bp-0x20c]
    184c:	16                   	push   ss
    184d:	57                   	push   di
    184e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1852:	06                   	push   es
    1853:	57                   	push   di
    1854:	9a 53 1d a0 18       	call   0x18a0:0x1d53
    1859:	8d be f8 fe          	lea    di,[bp-0x108]
    185d:	16                   	push   ss
    185e:	57                   	push   di
    185f:	68 ff 00             	push   0xff
    1862:	9a e7 17 77 18       	call   0x1877:0x17e7
    1867:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    186b:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    186f:	2d 04 00             	sub    ax,0x4
    1872:	71 05                	jno    0x1879
    1874:	9a 3e 04 8c 18       	call   0x188c:0x43e
    1879:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    187c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1880:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1884:	2d 04 00             	sub    ax,0x4
    1887:	71 05                	jno    0x188e
    1889:	9a 3e 04 c0 18       	call   0x18c0:0x43e
    188e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1891:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1894:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1897:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    189b:	06                   	push   es
    189c:	57                   	push   di
    189d:	9a d4 19 e4 18       	call   0x18e4:0x19d4
    18a2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    18a5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    18a8:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    18ad:	77 03                	ja     0x18b2
    18af:	e9 ac 01             	jmp    0x1a5e
    18b2:	8d be f8 fd          	lea    di,[bp-0x208]
    18b6:	16                   	push   ss
    18b7:	57                   	push   di
    18b8:	bf 4d 16             	mov    di,0x164d
    18bb:	0e                   	push   cs
    18bc:	57                   	push   di
    18bd:	9a cd 17 cb 18       	call   0x18cb:0x17cd
    18c2:	8d be f8 fe          	lea    di,[bp-0x108]
    18c6:	16                   	push   ss
    18c7:	57                   	push   di
    18c8:	9a 4c 18 d5 18       	call   0x18d5:0x184c
    18cd:	bf 4d 16             	mov    di,0x164d
    18d0:	0e                   	push   cs
    18d1:	57                   	push   di
    18d2:	9a 4c 18 71 19       	call   0x1971:0x184c
    18d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18da:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    18df:	06                   	push   es
    18e0:	57                   	push   di
    18e1:	9a 8c 1d 2a 19       	call   0x192a:0x1d8c
    18e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e9:	06                   	push   es
    18ea:	57                   	push   di
    18eb:	9a d5 33 c1 21       	call   0x21c1:0x33d5
    18f0:	89 c7                	mov    di,ax
    18f2:	8e c2                	mov    es,dx
    18f4:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    18f8:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    18fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ff:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1904:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1908:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    190c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1910:	06                   	push   es
    1911:	57                   	push   di
    1912:	9a 99 20 35 19       	call   0x1935:0x2099
    1917:	8d be f4 fd          	lea    di,[bp-0x20c]
    191b:	16                   	push   ss
    191c:	57                   	push   di
    191d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1920:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1925:	06                   	push   es
    1926:	57                   	push   di
    1927:	9a 53 1d 45 19       	call   0x1945:0x1d53
    192c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1930:	06                   	push   es
    1931:	57                   	push   di
    1932:	9a 03 20 65 19       	call   0x1965:0x2003
    1937:	50                   	push   ax
    1938:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193b:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1940:	06                   	push   es
    1941:	57                   	push   di
    1942:	9a bf 17 5a 19       	call   0x195a:0x17bf
    1947:	8d be f4 fd          	lea    di,[bp-0x20c]
    194b:	16                   	push   ss
    194c:	57                   	push   di
    194d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1950:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1955:	06                   	push   es
    1956:	57                   	push   di
    1957:	9a 53 1d 87 19       	call   0x1987:0x1d53
    195c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1960:	06                   	push   es
    1961:	57                   	push   di
    1962:	9a 4e 20 55 32       	call   0x3255:0x204e
    1967:	b9 03 00             	mov    cx,0x3
    196a:	f7 e9                	imul   cx
    196c:	71 05                	jno    0x1973
    196e:	9a 3e 04 e4 19       	call   0x19e4:0x43e
    1973:	99                   	cwd
    1974:	b9 02 00             	mov    cx,0x2
    1977:	f7 f9                	idiv   cx
    1979:	50                   	push   ax
    197a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    197d:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1982:	06                   	push   es
    1983:	57                   	push   di
    1984:	9a e1 17 97 19       	call   0x1997:0x17e1
    1989:	ff 76 fe             	push   WORD PTR [bp-0x2]
    198c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    198f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1992:	06                   	push   es
    1993:	57                   	push   di
    1994:	9a 06 1a b7 19       	call   0x19b7:0x1a06
    1999:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    199c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    199f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a2:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    19a7:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    19ab:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    19af:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19b2:	06                   	push   es
    19b3:	57                   	push   di
    19b4:	9a 7b 17 c5 19       	call   0x19c5:0x177b
    19b9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19bc:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    19c0:	06                   	push   es
    19c1:	57                   	push   di
    19c2:	9a 9d 17 cf 19       	call   0x19cf:0x179d
    19c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19ca:	06                   	push   es
    19cb:	57                   	push   di
    19cc:	9a a9 18 06 1a       	call   0x1a06:0x18a9
    19d1:	8b d0                	mov    dx,ax
    19d3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    19d7:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    19db:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    19df:	71 05                	jno    0x19e6
    19e1:	9a 3e 04 fa 19       	call   0x19fa:0x43e
    19e6:	3b c2                	cmp    ax,dx
    19e8:	7e 20                	jle    0x1a0a
    19ea:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    19ee:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    19f2:	2d 08 00             	sub    ax,0x8
    19f5:	71 05                	jno    0x19fc
    19f7:	9a 3e 04 27 1a       	call   0x1a27:0x43e
    19fc:	50                   	push   ax
    19fd:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1a01:	06                   	push   es
    1a02:	57                   	push   di
    1a03:	9a 7b 17 12 1a       	call   0x1a12:0x177b
    1a08:	eb bd                	jmp    0x19c7
    1a0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a0d:	06                   	push   es
    1a0e:	57                   	push   di
    1a0f:	9a f4 18 49 1a       	call   0x1a49:0x18f4
    1a14:	8b d0                	mov    dx,ax
    1a16:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1a1a:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1a1e:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    1a22:	71 05                	jno    0x1a29
    1a24:	9a 3e 04 3d 1a       	call   0x1a3d:0x43e
    1a29:	3b c2                	cmp    ax,dx
    1a2b:	7e 20                	jle    0x1a4d
    1a2d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1a31:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1a35:	2d 08 00             	sub    ax,0x8
    1a38:	71 05                	jno    0x1a3f
    1a3a:	9a 3e 04 6b 1a       	call   0x1a6b:0x43e
    1a3f:	50                   	push   ax
    1a40:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1a44:	06                   	push   es
    1a45:	57                   	push   di
    1a46:	9a 9d 17 5c 1a       	call   0x1a5c:0x179d
    1a4b:	eb bd                	jmp    0x1a0a
    1a4d:	6a 01                	push   0x1
    1a4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a52:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    1a57:	06                   	push   es
    1a58:	57                   	push   di
    1a59:	9a 77 1c 14 1c       	call   0x1c14:0x1c77
    1a5e:	c9                   	leave
    1a5f:	ca 0e 00             	retf   0xe
    1a62:	55                   	push   bp
    1a63:	89 e5                	mov    bp,sp
    1a65:	b8 04 00             	mov    ax,0x4
    1a68:	9a 44 04 82 1a       	call   0x1a82:0x444
    1a6d:	83 ec 04             	sub    sp,0x4
    1a70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a73:	06                   	push   es
    1a74:	57                   	push   di
    1a75:	9a 7d 52 a1 1a       	call   0x1aa1:0x527d
    1a7a:	2d 01 00             	sub    ax,0x1
    1a7d:	71 05                	jno    0x1a84
    1a7f:	9a 3e 04 b0 1a       	call   0x1ab0:0x43e
    1a84:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a87:	31 c0                	xor    ax,ax
    1a89:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1a8c:	7f 58                	jg     0x1ae6
    1a8e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a91:	eb 03                	jmp    0x1a96
    1a93:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1a96:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a9c:	06                   	push   es
    1a9d:	57                   	push   di
    1a9e:	9a 46 52 c1 1a       	call   0x1ac1:0x5246
    1aa3:	52                   	push   dx
    1aa4:	50                   	push   ax
    1aa5:	bf 22 00             	mov    di,0x22
    1aa8:	b8 c9 1a             	mov    ax,0x1ac9
    1aab:	50                   	push   ax
    1aac:	57                   	push   di
    1aad:	9a 55 22 d0 1a       	call   0x1ad0:0x2255
    1ab2:	08 c0                	or     al,al
    1ab4:	74 28                	je     0x1ade
    1ab6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ab9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1abc:	06                   	push   es
    1abd:	57                   	push   di
    1abe:	9a 46 52 dc 21       	call   0x21dc:0x5246
    1ac3:	52                   	push   dx
    1ac4:	50                   	push   ax
    1ac5:	bf 22 00             	mov    di,0x22
    1ac8:	b8 75 39             	mov    ax,0x3975
    1acb:	50                   	push   ax
    1acc:	57                   	push   di
    1acd:	9a 73 22 f3 1a       	call   0x1af3:0x2273
    1ad2:	52                   	push   dx
    1ad3:	50                   	push   ax
    1ad4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad7:	06                   	push   es
    1ad8:	57                   	push   di
    1ad9:	9a 2f 11 50 1e       	call   0x1e50:0x112f
    1ade:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ae1:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1ae4:	75 ad                	jne    0x1a93
    1ae6:	c9                   	leave
    1ae7:	ca 04 00             	retf   0x4
    1aea:	55                   	push   bp
    1aeb:	89 e5                	mov    bp,sp
    1aed:	b8 04 00             	mov    ax,0x4
    1af0:	9a 44 04 eb 1b       	call   0x1beb:0x444
    1af5:	83 ec 04             	sub    sp,0x4
    1af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1afb:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    1b00:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1b03:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1b06:	06                   	push   es
    1b07:	57                   	push   di
    1b08:	9a d2 31 2d 1b       	call   0x1b2d:0x31d2
    1b0d:	6a 01                	push   0x1
    1b0f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b12:	06                   	push   es
    1b13:	57                   	push   di
    1b14:	9a fb 2f 23 1b       	call   0x1b23:0x2ffb
    1b19:	6a 00                	push   0x0
    1b1b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b1e:	06                   	push   es
    1b1f:	57                   	push   di
    1b20:	9a d2 2e 4e 1b       	call   0x1b4e:0x2ed2
    1b25:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b28:	06                   	push   es
    1b29:	57                   	push   di
    1b2a:	9a bf 31 42 1b       	call   0x1b42:0x31bf
    1b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b32:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    1b37:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1b3a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1b3d:	06                   	push   es
    1b3e:	57                   	push   di
    1b3f:	9a d2 31 64 1b       	call   0x1b64:0x31d2
    1b44:	6a 01                	push   0x1
    1b46:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b49:	06                   	push   es
    1b4a:	57                   	push   di
    1b4b:	9a fb 2f 5a 1b       	call   0x1b5a:0x2ffb
    1b50:	6a 00                	push   0x0
    1b52:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b55:	06                   	push   es
    1b56:	57                   	push   di
    1b57:	9a d2 2e 85 1b       	call   0x1b85:0x2ed2
    1b5c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b5f:	06                   	push   es
    1b60:	57                   	push   di
    1b61:	9a bf 31 79 1b       	call   0x1b79:0x31bf
    1b66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b69:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    1b6e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1b71:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1b74:	06                   	push   es
    1b75:	57                   	push   di
    1b76:	9a d2 31 9b 1b       	call   0x1b9b:0x31d2
    1b7b:	6a 01                	push   0x1
    1b7d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b80:	06                   	push   es
    1b81:	57                   	push   di
    1b82:	9a fb 2f 91 1b       	call   0x1b91:0x2ffb
    1b87:	6a 00                	push   0x0
    1b89:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b8c:	06                   	push   es
    1b8d:	57                   	push   di
    1b8e:	9a d2 2e bc 1b       	call   0x1bbc:0x2ed2
    1b93:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1b96:	06                   	push   es
    1b97:	57                   	push   di
    1b98:	9a bf 31 b0 1b       	call   0x1bb0:0x31bf
    1b9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ba0:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    1ba5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1ba8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1bab:	06                   	push   es
    1bac:	57                   	push   di
    1bad:	9a d2 31 d2 1b       	call   0x1bd2:0x31d2
    1bb2:	6a 01                	push   0x1
    1bb4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1bb7:	06                   	push   es
    1bb8:	57                   	push   di
    1bb9:	9a fb 2f c8 1b       	call   0x1bc8:0x2ffb
    1bbe:	6a 00                	push   0x0
    1bc0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1bc3:	06                   	push   es
    1bc4:	57                   	push   di
    1bc5:	9a d2 2e 42 1e       	call   0x1e42:0x2ed2
    1bca:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1bcd:	06                   	push   es
    1bce:	57                   	push   di
    1bcf:	9a bf 31 a7 1f       	call   0x1fa7:0x31bf
    1bd4:	c9                   	leave
    1bd5:	ca 04 00             	retf   0x4
    1bd8:	01 23                	add    WORD PTR [bp+di],sp
    1bda:	00 00                	add    BYTE PTR [bx+si],al
    1bdc:	00 00                	add    BYTE PTR [bx+si],al
    1bde:	ff 00                	inc    WORD PTR [bx+si]
    1be0:	00 00                	add    BYTE PTR [bx+si],al
    1be2:	55                   	push   bp
    1be3:	89 e5                	mov    bp,sp
    1be5:	b8 02 02             	mov    ax,0x202
    1be8:	9a 44 04 50 1c       	call   0x1c50:0x444
    1bed:	81 ec 02 02          	sub    sp,0x202
    1bf1:	8d be fe fd          	lea    di,[bp-0x202]
    1bf5:	16                   	push   ss
    1bf6:	57                   	push   di
    1bf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bfa:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    1bff:	99                   	cwd
    1c00:	52                   	push   dx
    1c01:	50                   	push   ax
    1c02:	9a a9 08 2a 1c       	call   0x1c2a:0x8a9
    1c07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c0a:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    1c0f:	06                   	push   es
    1c10:	57                   	push   di
    1c11:	9a 8c 1d 39 1c       	call   0x1c39:0x1d8c
    1c16:	8d be fe fd          	lea    di,[bp-0x202]
    1c1a:	16                   	push   ss
    1c1b:	57                   	push   di
    1c1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c1f:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    1c24:	99                   	cwd
    1c25:	52                   	push   dx
    1c26:	50                   	push   ax
    1c27:	9a a9 08 9b 1c       	call   0x1c9b:0x8a9
    1c2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c2f:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    1c34:	06                   	push   es
    1c35:	57                   	push   di
    1c36:	9a 8c 1d 1e 1d       	call   0x1d1e:0x1d8c
    1c3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c3e:	81 c7 4e 04          	add    di,0x44e
    1c42:	06                   	push   es
    1c43:	57                   	push   di
    1c44:	8d be fe fe          	lea    di,[bp-0x102]
    1c48:	16                   	push   ss
    1c49:	57                   	push   di
    1c4a:	68 ff 00             	push   0xff
    1c4d:	9a e7 17 60 1c       	call   0x1c60:0x17e7
    1c52:	bf d8 1b             	mov    di,0x1bd8
    1c55:	0e                   	push   cs
    1c56:	57                   	push   di
    1c57:	8d be fe fe          	lea    di,[bp-0x102]
    1c5b:	16                   	push   ss
    1c5c:	57                   	push   di
    1c5d:	9a 78 18 69 1c       	call   0x1c69:0x1878
    1c62:	99                   	cwd
    1c63:	bf da 1b             	mov    di,0x1bda
    1c66:	9a 16 04 85 1c       	call   0x1c85:0x416
    1c6b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1c6e:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1c72:	76 3d                	jbe    0x1cb1
    1c74:	8d be fe fe          	lea    di,[bp-0x102]
    1c78:	16                   	push   ss
    1c79:	57                   	push   di
    1c7a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1c7d:	30 e4                	xor    ah,ah
    1c7f:	50                   	push   ax
    1c80:	6a 01                	push   0x1
    1c82:	9a 75 19 af 1c       	call   0x1caf:0x1975
    1c87:	8d be fe fd          	lea    di,[bp-0x202]
    1c8b:	16                   	push   ss
    1c8c:	57                   	push   di
    1c8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c90:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    1c95:	99                   	cwd
    1c96:	52                   	push   dx
    1c97:	50                   	push   ax
    1c98:	9a a9 08 fa 1c       	call   0x1cfa:0x8a9
    1c9d:	8d be fe fe          	lea    di,[bp-0x102]
    1ca1:	16                   	push   ss
    1ca2:	57                   	push   di
    1ca3:	68 ff 00             	push   0xff
    1ca6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1ca9:	30 e4                	xor    ah,ah
    1cab:	50                   	push   ax
    1cac:	9a 16 19 bf 1c       	call   0x1cbf:0x1916
    1cb1:	bf d8 1b             	mov    di,0x1bd8
    1cb4:	0e                   	push   cs
    1cb5:	57                   	push   di
    1cb6:	8d be fe fe          	lea    di,[bp-0x102]
    1cba:	16                   	push   ss
    1cbb:	57                   	push   di
    1cbc:	9a 78 18 c8 1c       	call   0x1cc8:0x1878
    1cc1:	99                   	cwd
    1cc2:	bf da 1b             	mov    di,0x1bda
    1cc5:	9a 16 04 e4 1c       	call   0x1ce4:0x416
    1cca:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1ccd:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1cd1:	76 3d                	jbe    0x1d10
    1cd3:	8d be fe fe          	lea    di,[bp-0x102]
    1cd7:	16                   	push   ss
    1cd8:	57                   	push   di
    1cd9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1cdc:	30 e4                	xor    ah,ah
    1cde:	50                   	push   ax
    1cdf:	6a 01                	push   0x1
    1ce1:	9a 75 19 0e 1d       	call   0x1d0e:0x1975
    1ce6:	8d be fe fd          	lea    di,[bp-0x202]
    1cea:	16                   	push   ss
    1ceb:	57                   	push   di
    1cec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cef:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    1cf4:	99                   	cwd
    1cf5:	52                   	push   dx
    1cf6:	50                   	push   ax
    1cf7:	9a a9 08 34 23       	call   0x2334:0x8a9
    1cfc:	8d be fe fe          	lea    di,[bp-0x102]
    1d00:	16                   	push   ss
    1d01:	57                   	push   di
    1d02:	68 ff 00             	push   0xff
    1d05:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1d08:	30 e4                	xor    ah,ah
    1d0a:	50                   	push   ax
    1d0b:	9a 16 19 46 1d       	call   0x1d46:0x1916
    1d10:	8d be fe fe          	lea    di,[bp-0x102]
    1d14:	16                   	push   ss
    1d15:	57                   	push   di
    1d16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d19:	06                   	push   es
    1d1a:	57                   	push   di
    1d1b:	9a 8c 1d 6b 20       	call   0x206b:0x1d8c
    1d20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d23:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    1d28:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1d2c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1d30:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1d34:	eb 03                	jmp    0x1d39
    1d36:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    1d39:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1d3c:	30 e4                	xor    ah,ah
    1d3e:	05 01 00             	add    ax,0x1
    1d41:	71 05                	jno    0x1d48
    1d43:	9a 3e 04 97 1d       	call   0x1d97:0x43e
    1d48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d4b:	26 3b 85 4a 04       	cmp    ax,WORD PTR es:[di+0x44a]
    1d50:	b0 00                	mov    al,0x0
    1d52:	75 01                	jne    0x1d55
    1d54:	40                   	inc    ax
    1d55:	50                   	push   ax
    1d56:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1d59:	30 e4                	xor    ah,ah
    1d5b:	50                   	push   ax
    1d5c:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1d60:	06                   	push   es
    1d61:	57                   	push   di
    1d62:	9a 53 13 70 1d       	call   0x1d70:0x1353
    1d67:	89 c7                	mov    di,ax
    1d69:	8e c2                	mov    es,dx
    1d6b:	06                   	push   es
    1d6c:	57                   	push   di
    1d6d:	9a 75 12 8d 1d       	call   0x1d8d:0x1275
    1d72:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    1d76:	75 be                	jne    0x1d36
    1d78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d7b:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    1d80:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1d84:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1d88:	06                   	push   es
    1d89:	57                   	push   di
    1d8a:	9a 26 13 e2 1d       	call   0x1de2:0x1326
    1d8f:	2d 01 00             	sub    ax,0x1
    1d92:	71 05                	jno    0x1d99
    1d94:	9a 3e 04 a0 1d       	call   0x1da0:0x43e
    1d99:	99                   	cwd
    1d9a:	bf da 1b             	mov    di,0x1bda
    1d9d:	9a 16 04 c3 1d       	call   0x1dc3:0x416
    1da2:	88 86 f9 fe          	mov    BYTE PTR [bp-0x107],al
    1da6:	b0 00                	mov    al,0x0
    1da8:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    1dac:	77 4a                	ja     0x1df8
    1dae:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1db1:	eb 03                	jmp    0x1db6
    1db3:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    1db6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1db9:	30 e4                	xor    ah,ah
    1dbb:	05 01 00             	add    ax,0x1
    1dbe:	71 05                	jno    0x1dc5
    1dc0:	9a 3e 04 98 1f       	call   0x1f98:0x43e
    1dc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dc8:	26 3b 85 4c 04       	cmp    ax,WORD PTR es:[di+0x44c]
    1dcd:	b0 00                	mov    al,0x0
    1dcf:	75 01                	jne    0x1dd2
    1dd1:	40                   	inc    ax
    1dd2:	50                   	push   ax
    1dd3:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1dd6:	30 e4                	xor    ah,ah
    1dd8:	50                   	push   ax
    1dd9:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1ddd:	06                   	push   es
    1dde:	57                   	push   di
    1ddf:	9a 53 13 ed 1d       	call   0x1ded:0x1353
    1de4:	89 c7                	mov    di,ax
    1de6:	8e c2                	mov    es,dx
    1de8:	06                   	push   es
    1de9:	57                   	push   di
    1dea:	9a 75 12 b6 20       	call   0x20b6:0x1275
    1def:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1df2:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    1df6:	75 bb                	jne    0x1db3
    1df8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dfb:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    1e00:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1e04:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1e08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0b:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    1e10:	99                   	cwd
    1e11:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1e15:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1e19:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1e1e:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    1e23:	99                   	cwd
    1e24:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1e28:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    1e2c:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1e31:	8d be ea fe          	lea    di,[bp-0x116]
    1e35:	16                   	push   ss
    1e36:	57                   	push   di
    1e37:	6a 01                	push   0x1
    1e39:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1e3d:	06                   	push   es
    1e3e:	57                   	push   di
    1e3f:	9a 95 28 ad 1e       	call   0x1ead:0x2895
    1e44:	08 c0                	or     al,al
    1e46:	75 0a                	jne    0x1e52
    1e48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e4b:	06                   	push   es
    1e4c:	57                   	push   di
    1e4d:	9a c6 0d bb 1e       	call   0x1ebb:0xdc6
    1e52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e55:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    1e5a:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1e5e:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1e62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e65:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    1e6a:	99                   	cwd
    1e6b:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    1e6f:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    1e73:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    1e78:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    1e7d:	99                   	cwd
    1e7e:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1e82:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1e86:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1e8b:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    1e91:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    1e97:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1e9c:	8d be e2 fe          	lea    di,[bp-0x11e]
    1ea0:	16                   	push   ss
    1ea1:	57                   	push   di
    1ea2:	6a 02                	push   0x2
    1ea4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1ea8:	06                   	push   es
    1ea9:	57                   	push   di
    1eaa:	9a 95 28 18 1f       	call   0x1f18:0x2895
    1eaf:	08 c0                	or     al,al
    1eb1:	75 0a                	jne    0x1ebd
    1eb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb6:	06                   	push   es
    1eb7:	57                   	push   di
    1eb8:	9a c6 0d 26 1f       	call   0x1f26:0xdc6
    1ebd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec0:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    1ec5:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1ec9:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1ecd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ed0:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    1ed5:	99                   	cwd
    1ed6:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    1eda:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    1ede:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    1ee3:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    1ee8:	99                   	cwd
    1ee9:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1eed:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1ef1:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1ef6:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    1efc:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    1f02:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1f07:	8d be e2 fe          	lea    di,[bp-0x11e]
    1f0b:	16                   	push   ss
    1f0c:	57                   	push   di
    1f0d:	6a 02                	push   0x2
    1f0f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1f13:	06                   	push   es
    1f14:	57                   	push   di
    1f15:	9a 95 28 72 1f       	call   0x1f72:0x2895
    1f1a:	08 c0                	or     al,al
    1f1c:	75 0a                	jne    0x1f28
    1f1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f21:	06                   	push   es
    1f22:	57                   	push   di
    1f23:	9a c6 0d 80 1f       	call   0x1f80:0xdc6
    1f28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2b:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    1f30:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1f34:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3b:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    1f40:	99                   	cwd
    1f41:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1f45:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1f49:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1f4e:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    1f53:	99                   	cwd
    1f54:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1f58:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    1f5c:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1f61:	8d be ea fe          	lea    di,[bp-0x116]
    1f65:	16                   	push   ss
    1f66:	57                   	push   di
    1f67:	6a 01                	push   0x1
    1f69:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1f6d:	06                   	push   es
    1f6e:	57                   	push   di
    1f6f:	9a 95 28 a0 23       	call   0x23a0:0x2895
    1f74:	08 c0                	or     al,al
    1f76:	75 0a                	jne    0x1f82
    1f78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7b:	06                   	push   es
    1f7c:	57                   	push   di
    1f7d:	9a c6 0d 8a 1f       	call   0x1f8a:0xdc6
    1f82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f85:	06                   	push   es
    1f86:	57                   	push   di
    1f87:	9a 62 1a f4 1f       	call   0x1ff4:0x1a62
    1f8c:	c9                   	leave
    1f8d:	ca 04 00             	retf   0x4
    1f90:	55                   	push   bp
    1f91:	89 e5                	mov    bp,sp
    1f93:	31 c0                	xor    ax,ax
    1f95:	9a 44 04 e2 1f       	call   0x1fe2:0x444
    1f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f9d:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    1fa2:	06                   	push   es
    1fa3:	57                   	push   di
    1fa4:	9a d2 31 b6 1f       	call   0x1fb6:0x31d2
    1fa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fac:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    1fb1:	06                   	push   es
    1fb2:	57                   	push   di
    1fb3:	9a d2 31 c5 1f       	call   0x1fc5:0x31d2
    1fb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fbb:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    1fc0:	06                   	push   es
    1fc1:	57                   	push   di
    1fc2:	9a d2 31 d4 1f       	call   0x1fd4:0x31d2
    1fc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fca:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    1fcf:	06                   	push   es
    1fd0:	57                   	push   di
    1fd1:	9a d2 31 11 29       	call   0x2911:0x31d2
    1fd6:	c9                   	leave
    1fd7:	ca 04 00             	retf   0x4
    1fda:	55                   	push   bp
    1fdb:	89 e5                	mov    bp,sp
    1fdd:	31 c0                	xor    ax,ax
    1fdf:	9a 44 04 02 20       	call   0x2002:0x444
    1fe4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1fe7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fea:	26 89 85 4a 04       	mov    WORD PTR es:[di+0x44a],ax
    1fef:	06                   	push   es
    1ff0:	57                   	push   di
    1ff1:	9a e2 1b 14 20       	call   0x2014:0x1be2
    1ff6:	c9                   	leave
    1ff7:	ca 06 00             	retf   0x6
    1ffa:	55                   	push   bp
    1ffb:	89 e5                	mov    bp,sp
    1ffd:	31 c0                	xor    ax,ax
    1fff:	9a 44 04 33 20       	call   0x2033:0x444
    2004:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200a:	26 89 85 4c 04       	mov    WORD PTR es:[di+0x44c],ax
    200f:	06                   	push   es
    2010:	57                   	push   di
    2011:	9a e2 1b 2e 24       	call   0x242e:0x1be2
    2016:	c9                   	leave
    2017:	ca 06 00             	retf   0x6
    201a:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    201d:	6d                   	ins    WORD PTR es:[di],dx
    201e:	73 74                	jae    0x2094
    2020:	72 61                	jb     0x2083
    2022:	74 20                	je     0x2044
    2024:	2d 20 03             	sub    ax,0x320
    2027:	20 2d                	and    BYTE PTR [di],ch
    2029:	20 55 89             	and    BYTE PTR [di-0x77],dl
    202c:	e5 b8                	in     ax,0xb8
    202e:	02 03                	add    al,BYTE PTR [bp+di]
    2030:	9a 44 04 47 20       	call   0x2047:0x444
    2035:	81 ec 02 03          	sub    sp,0x302
    2039:	8d be fe fe          	lea    di,[bp-0x102]
    203d:	16                   	push   ss
    203e:	57                   	push   di
    203f:	bf 1a 20             	mov    di,0x201a
    2042:	0e                   	push   cs
    2043:	57                   	push   di
    2044:	9a cd 17 51 20       	call   0x2051:0x17cd
    2049:	bf fa 1d             	mov    di,0x1dfa
    204c:	1e                   	push   ds
    204d:	57                   	push   di
    204e:	9a 4c 18 5b 20       	call   0x205b:0x184c
    2053:	bf 26 20             	mov    di,0x2026
    2056:	0e                   	push   cs
    2057:	57                   	push   di
    2058:	9a 4c 18 70 20       	call   0x2070:0x184c
    205d:	8d be fe fd          	lea    di,[bp-0x202]
    2061:	16                   	push   ss
    2062:	57                   	push   di
    2063:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2066:	06                   	push   es
    2067:	57                   	push   di
    2068:	9a 53 1d 95 20       	call   0x2095:0x1d53
    206d:	9a 4c 18 81 20       	call   0x2081:0x184c
    2072:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2075:	81 c7 4e 04          	add    di,0x44e
    2079:	06                   	push   es
    207a:	57                   	push   di
    207b:	68 ff 00             	push   0xff
    207e:	9a e7 17 1b 21       	call   0x211b:0x17e7
    2083:	bf fa 1d             	mov    di,0x1dfa
    2086:	1e                   	push   ds
    2087:	57                   	push   di
    2088:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    208b:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    2090:	06                   	push   es
    2091:	57                   	push   di
    2092:	9a 8c 1d 10 22       	call   0x2210:0x1d8c
    2097:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    209a:	26 c7 85 48 04 64 00 	mov    WORD PTR es:[di+0x448],0x64
    20a1:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    20a6:	b0 00                	mov    al,0x0
    20a8:	7c 01                	jl     0x20ab
    20aa:	40                   	inc    ax
    20ab:	50                   	push   ax
    20ac:	26 c4 bd b0 03       	les    di,DWORD PTR es:[di+0x3b0]
    20b1:	06                   	push   es
    20b2:	57                   	push   di
    20b3:	9a a5 13 d0 20       	call   0x20d0:0x13a5
    20b8:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    20bd:	b0 00                	mov    al,0x0
    20bf:	7c 01                	jl     0x20c2
    20c1:	40                   	inc    ax
    20c2:	50                   	push   ax
    20c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20c6:	26 c4 bd b4 03       	les    di,DWORD PTR es:[di+0x3b4]
    20cb:	06                   	push   es
    20cc:	57                   	push   di
    20cd:	9a a5 13 ea 20       	call   0x20ea:0x13a5
    20d2:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    20d7:	b0 00                	mov    al,0x0
    20d9:	7c 01                	jl     0x20dc
    20db:	40                   	inc    ax
    20dc:	50                   	push   ax
    20dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20e0:	26 c4 bd 44 04       	les    di,DWORD PTR es:[di+0x444]
    20e5:	06                   	push   es
    20e6:	57                   	push   di
    20e7:	9a a5 13 11 21       	call   0x2111:0x13a5
    20ec:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    20f2:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    20f8:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    20fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2101:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    2106:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2109:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    210c:	06                   	push   es
    210d:	57                   	push   di
    210e:	9a 26 13 45 21       	call   0x2145:0x1326
    2113:	2d 01 00             	sub    ax,0x1
    2116:	71 05                	jno    0x211d
    2118:	9a 3e 04 7d 21       	call   0x217d:0x43e
    211d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2120:	31 c0                	xor    ax,ax
    2122:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2125:	7f 33                	jg     0x215a
    2127:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    212a:	eb 03                	jmp    0x212f
    212c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    212f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2132:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    2136:	7c 1a                	jl     0x2152
    2138:	6a 00                	push   0x0
    213a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    213d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2140:	06                   	push   es
    2141:	57                   	push   di
    2142:	9a 53 13 50 21       	call   0x2150:0x1353
    2147:	89 c7                	mov    di,ax
    2149:	8e c2                	mov    es,dx
    214b:	06                   	push   es
    214c:	57                   	push   di
    214d:	9a a5 13 9f 21       	call   0x219f:0x13a5
    2152:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2155:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2158:	75 d2                	jne    0x212c
    215a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    215d:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    2162:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2165:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2168:	31 c0                	xor    ax,ax
    216a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    216d:	eb 03                	jmp    0x2172
    216f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2172:	a1 4c 01             	mov    ax,ds:0x14c
    2175:	2d 01 00             	sub    ax,0x1
    2178:	71 05                	jno    0x217f
    217a:	9a 3e 04 8c 21       	call   0x218c:0x43e
    217f:	8b d0                	mov    dx,ax
    2181:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2184:	05 01 00             	add    ax,0x1
    2187:	71 05                	jno    0x218e
    2189:	9a 3e 04 e6 21       	call   0x21e6:0x43e
    218e:	3b c2                	cmp    ax,dx
    2190:	7e 1a                	jle    0x21ac
    2192:	6a 00                	push   0x0
    2194:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2197:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    219a:	06                   	push   es
    219b:	57                   	push   di
    219c:	9a 53 13 aa 21       	call   0x21aa:0x1353
    21a1:	89 c7                	mov    di,ax
    21a3:	8e c2                	mov    es,dx
    21a5:	06                   	push   es
    21a6:	57                   	push   di
    21a7:	9a a5 13 b2 24       	call   0x24b2:0x13a5
    21ac:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    21b0:	75 bd                	jne    0x216f
    21b2:	6a 00                	push   0x0
    21b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b7:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    21bc:	06                   	push   es
    21bd:	57                   	push   di
    21be:	9a d0 1c d2 21       	call   0x21d2:0x1cd0
    21c3:	6a 00                	push   0x0
    21c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c8:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    21cd:	06                   	push   es
    21ce:	57                   	push   di
    21cf:	9a d0 1c 16 24       	call   0x2416:0x1cd0
    21d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d7:	06                   	push   es
    21d8:	57                   	push   di
    21d9:	9a 7d 52 08 22       	call   0x2208:0x527d
    21de:	2d 01 00             	sub    ax,0x1
    21e1:	71 05                	jno    0x21e8
    21e3:	9a 3e 04 17 22       	call   0x2217:0x43e
    21e8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    21eb:	31 c0                	xor    ax,ax
    21ed:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    21f0:	7e 03                	jle    0x21f5
    21f2:	e9 a7 00             	jmp    0x229c
    21f5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    21f8:	eb 03                	jmp    0x21fd
    21fa:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    21fd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2200:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2203:	06                   	push   es
    2204:	57                   	push   di
    2205:	9a 46 52 28 22       	call   0x2228:0x5246
    220a:	52                   	push   dx
    220b:	50                   	push   ax
    220c:	bf 99 03             	mov    di,0x399
    220f:	b8 30 22             	mov    ax,0x2230
    2212:	50                   	push   ax
    2213:	57                   	push   di
    2214:	9a 55 22 37 22       	call   0x2237:0x2255
    2219:	08 c0                	or     al,al
    221b:	74 74                	je     0x2291
    221d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2220:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2223:	06                   	push   es
    2224:	57                   	push   di
    2225:	9a 46 52 48 27       	call   0x2748:0x5246
    222a:	52                   	push   dx
    222b:	50                   	push   ax
    222c:	bf 99 03             	mov    di,0x399
    222f:	b8 8f 22             	mov    ax,0x228f
    2232:	50                   	push   ax
    2233:	57                   	push   di
    2234:	9a 73 22 74 22       	call   0x2274:0x2273
    2239:	89 c7                	mov    di,ax
    223b:	8e c2                	mov    es,dx
    223d:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2240:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2243:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2248:	74 47                	je     0x2291
    224a:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    224e:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    2252:	74 3d                	je     0x2291
    2254:	a1 06 1e             	mov    ax,ds:0x1e06
    2257:	99                   	cwd
    2258:	8b c8                	mov    cx,ax
    225a:	8b da                	mov    bx,dx
    225c:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2260:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2264:	09 d2                	or     dx,dx
    2266:	79 07                	jns    0x226f
    2268:	f7 d2                	not    dx
    226a:	f7 d8                	neg    ax
    226c:	83 da ff             	sbb    dx,0xffff
    226f:	71 05                	jno    0x2276
    2271:	9a 3e 04 29 23       	call   0x2329:0x43e
    2276:	3b d3                	cmp    dx,bx
    2278:	7c 0a                	jl     0x2284
    227a:	7f 04                	jg     0x2280
    227c:	3b c1                	cmp    ax,cx
    227e:	76 04                	jbe    0x2284
    2280:	b0 00                	mov    al,0x0
    2282:	eb 02                	jmp    0x2286
    2284:	b0 01                	mov    al,0x1
    2286:	50                   	push   ax
    2287:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    228a:	06                   	push   es
    228b:	57                   	push   di
    228c:	9a 77 1c b0 22       	call   0x22b0:0x1c77
    2291:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2294:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2297:	74 03                	je     0x229c
    2299:	e9 5e ff             	jmp    0x21fa
    229c:	8d be fe fe          	lea    di,[bp-0x102]
    22a0:	16                   	push   ss
    22a1:	57                   	push   di
    22a2:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    22a6:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    22ab:	06                   	push   es
    22ac:	57                   	push   di
    22ad:	9a 53 1d bf 22       	call   0x22bf:0x1d53
    22b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b5:	26 c4 bd 7c 03       	les    di,DWORD PTR es:[di+0x37c]
    22ba:	06                   	push   es
    22bb:	57                   	push   di
    22bc:	9a 8c 1d d5 22       	call   0x22d5:0x1d8c
    22c1:	8d be fe fe          	lea    di,[bp-0x102]
    22c5:	16                   	push   ss
    22c6:	57                   	push   di
    22c7:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    22cb:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    22d0:	06                   	push   es
    22d1:	57                   	push   di
    22d2:	9a 53 1d e4 22       	call   0x22e4:0x1d53
    22d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22da:	26 c4 bd 80 03       	les    di,DWORD PTR es:[di+0x380]
    22df:	06                   	push   es
    22e0:	57                   	push   di
    22e1:	9a 8c 1d fa 22       	call   0x22fa:0x1d8c
    22e6:	8d be fe fe          	lea    di,[bp-0x102]
    22ea:	16                   	push   ss
    22eb:	57                   	push   di
    22ec:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    22f0:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    22f5:	06                   	push   es
    22f6:	57                   	push   di
    22f7:	9a 53 1d 09 23       	call   0x2309:0x1d53
    22fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ff:	26 c4 bd 84 03       	les    di,DWORD PTR es:[di+0x384]
    2304:	06                   	push   es
    2305:	57                   	push   di
    2306:	9a 8c 1d 1f 23       	call   0x231f:0x1d8c
    230b:	8d be fe fe          	lea    di,[bp-0x102]
    230f:	16                   	push   ss
    2310:	57                   	push   di
    2311:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2315:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    231a:	06                   	push   es
    231b:	57                   	push   di
    231c:	9a 53 1d 8c 23       	call   0x238c:0x1d53
    2321:	bf 26 20             	mov    di,0x2026
    2324:	0e                   	push   cs
    2325:	57                   	push   di
    2326:	9a 4c 18 49 23       	call   0x2349:0x184c
    232b:	8d be fe fd          	lea    di,[bp-0x202]
    232f:	16                   	push   ss
    2330:	57                   	push   di
    2331:	9a fe 15 44 23       	call   0x2344:0x15fe
    2336:	83 ec 08             	sub    sp,0x8
    2339:	89 e3                	mov    bx,sp
    233b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    233f:	90                   	nop
    2340:	9b                   	fwait
    2341:	9a bf 1c 5e 23       	call   0x235e:0x1cbf
    2346:	9a 4c 18 53 23       	call   0x2353:0x184c
    234b:	bf 26 20             	mov    di,0x2026
    234e:	0e                   	push   cs
    234f:	57                   	push   di
    2350:	9a 4c 18 73 23       	call   0x2373:0x184c
    2355:	8d be fe fc          	lea    di,[bp-0x302]
    2359:	16                   	push   ss
    235a:	57                   	push   di
    235b:	9a fe 15 6e 23       	call   0x236e:0x15fe
    2360:	83 ec 08             	sub    sp,0x8
    2363:	89 e3                	mov    bx,sp
    2365:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2369:	90                   	nop
    236a:	9b                   	fwait
    236b:	9a e4 1c 5a 27       	call   0x275a:0x1ce4
    2370:	9a 4c 18 7d 23       	call   0x237d:0x184c
    2375:	bf 26 20             	mov    di,0x2026
    2378:	0e                   	push   cs
    2379:	57                   	push   di
    237a:	9a 4c 18 f3 23       	call   0x23f3:0x184c
    237f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2382:	26 c4 bd 88 03       	les    di,DWORD PTR es:[di+0x388]
    2387:	06                   	push   es
    2388:	57                   	push   di
    2389:	9a 8c 1d 9b 25       	call   0x259b:0x1d8c
    238e:	bf 4e 1e             	mov    di,0x1e4e
    2391:	1e                   	push   ds
    2392:	57                   	push   di
    2393:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2396:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    239b:	06                   	push   es
    239c:	57                   	push   di
    239d:	9a 17 30 b4 23       	call   0x23b4:0x3017
    23a2:	bf 78 1e             	mov    di,0x1e78
    23a5:	1e                   	push   ds
    23a6:	57                   	push   di
    23a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23aa:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    23af:	06                   	push   es
    23b0:	57                   	push   di
    23b1:	9a 17 30 c8 23       	call   0x23c8:0x3017
    23b6:	bf 86 1e             	mov    di,0x1e86
    23b9:	1e                   	push   ds
    23ba:	57                   	push   di
    23bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23be:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    23c3:	06                   	push   es
    23c4:	57                   	push   di
    23c5:	9a 17 30 dc 23       	call   0x23dc:0x3017
    23ca:	bf 86 1e             	mov    di,0x1e86
    23cd:	1e                   	push   ds
    23ce:	57                   	push   di
    23cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d2:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    23d7:	06                   	push   es
    23d8:	57                   	push   di
    23d9:	9a 17 30 ee 28       	call   0x28ee:0x3017
    23de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e1:	26 c7 85 4c 04 01 00 	mov    WORD PTR es:[di+0x44c],0x1
    23e8:	a1 4c 01             	mov    ax,ds:0x14c
    23eb:	2d 01 00             	sub    ax,0x1
    23ee:	71 05                	jno    0x23f5
    23f0:	9a 3e 04 09 24       	call   0x2409:0x43e
    23f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f8:	26 89 85 4a 04       	mov    WORD PTR es:[di+0x44a],ax
    23fd:	c9                   	leave
    23fe:	ca 08 00             	retf   0x8
    2401:	55                   	push   bp
    2402:	89 e5                	mov    bp,sp
    2404:	31 c0                	xor    ax,ax
    2406:	9a 44 04 24 24       	call   0x2424:0x444
    240b:	6a fe                	push   0xfffe
    240d:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2411:	06                   	push   es
    2412:	57                   	push   di
    2413:	9a a9 63 4d 24       	call   0x244d:0x63a9
    2418:	c9                   	leave
    2419:	ca 08 00             	retf   0x8
    241c:	55                   	push   bp
    241d:	89 e5                	mov    bp,sp
    241f:	31 c0                	xor    ax,ax
    2421:	9a 44 04 43 24       	call   0x2443:0x444
    2426:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2429:	06                   	push   es
    242a:	57                   	push   di
    242b:	9a 90 1f ed 25       	call   0x25ed:0x1f90
    2430:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2433:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    2437:	c9                   	leave
    2438:	ca 0c 00             	retf   0xc
    243b:	55                   	push   bp
    243c:	89 e5                	mov    bp,sp
    243e:	31 c0                	xor    ax,ax
    2440:	9a 44 04 5b 24       	call   0x245b:0x444
    2445:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2448:	06                   	push   es
    2449:	57                   	push   di
    244a:	9a 56 55 6f 24       	call   0x246f:0x5556
    244f:	c9                   	leave
    2450:	ca 08 00             	retf   0x8
    2453:	55                   	push   bp
    2454:	89 e5                	mov    bp,sp
    2456:	31 c0                	xor    ax,ax
    2458:	9a 44 04 98 24       	call   0x2498:0x444
    245d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2460:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    2466:	75 0b                	jne    0x2473
    2468:	6a 00                	push   0x0
    246a:	06                   	push   es
    246b:	57                   	push   di
    246c:	9a 14 3a 7d 24       	call   0x247d:0x3a14
    2471:	eb 0c                	jmp    0x247f
    2473:	6a 02                	push   0x2
    2475:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2478:	06                   	push   es
    2479:	57                   	push   di
    247a:	9a 14 3a 46 2e       	call   0x2e46:0x3a14
    247f:	c9                   	leave
    2480:	ca 08 00             	retf   0x8
    2483:	fa                   	cli
    2484:	24 01                	and    al,0x1
    2486:	25 08 25             	and    ax,0x2508
    2489:	0f 25                	(bad)
    248b:	16                   	push   ss
    248c:	25 1d 25             	and    ax,0x251d
    248f:	55                   	push   bp
    2490:	89 e5                	mov    bp,sp
    2492:	b8 0e 00             	mov    ax,0xe
    2495:	9a 44 04 b9 24       	call   0x24b9:0x444
    249a:	83 ec 0e             	sub    sp,0xe
    249d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a0:	26 8b 85 48 04       	mov    ax,WORD PTR es:[di+0x448]
    24a5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    24a8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24ab:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24ae:	bf 94 00             	mov    di,0x94
    24b1:	b8 cc 24             	mov    ax,0x24cc
    24b4:	50                   	push   ax
    24b5:	57                   	push   di
    24b6:	9a 55 22 d3 24       	call   0x24d3:0x2255
    24bb:	08 c0                	or     al,al
    24bd:	75 03                	jne    0x24c2
    24bf:	e9 bf 00             	jmp    0x2581
    24c2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24c5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24c8:	bf 94 00             	mov    di,0x94
    24cb:	b8 e4 24             	mov    ax,0x24e4
    24ce:	50                   	push   ax
    24cf:	57                   	push   di
    24d0:	9a 73 22 41 25       	call   0x2541:0x2273
    24d5:	52                   	push   dx
    24d6:	50                   	push   ax
    24d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24da:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    24df:	06                   	push   es
    24e0:	57                   	push   di
    24e1:	9a 2b 16 37 25       	call   0x2537:0x162b
    24e6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    24e9:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    24ec:	3d 05 00             	cmp    ax,0x5
    24ef:	77 33                	ja     0x2524
    24f1:	89 c3                	mov    bx,ax
    24f3:	d1 e3                	shl    bx,1
    24f5:	2e ff a7 83 24       	jmp    WORD PTR cs:[bx+0x2483]
    24fa:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    24ff:	eb 23                	jmp    0x2524
    2501:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    2506:	eb 1c                	jmp    0x2524
    2508:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    250d:	eb 15                	jmp    0x2524
    250f:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    2514:	eb 0e                	jmp    0x2524
    2516:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    251b:	eb 07                	jmp    0x2524
    251d:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    2522:	eb 00                	jmp    0x2524
    2524:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2527:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    252c:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    252f:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2532:	06                   	push   es
    2533:	57                   	push   di
    2534:	9a 26 13 6c 25       	call   0x256c:0x1326
    2539:	2d 01 00             	sub    ax,0x1
    253c:	71 05                	jno    0x2543
    253e:	9a 3e 04 b5 25       	call   0x25b5:0x43e
    2543:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2546:	31 c0                	xor    ax,ax
    2548:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    254b:	7f 34                	jg     0x2581
    254d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2550:	eb 03                	jmp    0x2555
    2552:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    2555:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2558:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    255b:	b0 00                	mov    al,0x0
    255d:	75 01                	jne    0x2560
    255f:	40                   	inc    ax
    2560:	50                   	push   ax
    2561:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2564:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2567:	06                   	push   es
    2568:	57                   	push   di
    2569:	9a 53 13 77 25       	call   0x2577:0x1353
    256e:	89 c7                	mov    di,ax
    2570:	8e c2                	mov    es,dx
    2572:	06                   	push   es
    2573:	57                   	push   di
    2574:	9a 75 12 0b 26       	call   0x260b:0x1275
    2579:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    257c:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    257f:	75 d1                	jne    0x2552
    2581:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2584:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2587:	26 3b 85 48 04       	cmp    ax,WORD PTR es:[di+0x448]
    258c:	74 1a                	je     0x25a8
    258e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2591:	26 ff b5 48 04       	push   WORD PTR es:[di+0x448]
    2596:	06                   	push   es
    2597:	57                   	push   di
    2598:	9a f4 5d a2 2e       	call   0x2ea2:0x5df4
    259d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    25a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a3:	26 89 85 48 04       	mov    WORD PTR es:[di+0x448],ax
    25a8:	c9                   	leave
    25a9:	ca 08 00             	retf   0x8
    25ac:	55                   	push   bp
    25ad:	89 e5                	mov    bp,sp
    25af:	b8 02 00             	mov    ax,0x2
    25b2:	9a 44 04 c5 25       	call   0x25c5:0x444
    25b7:	83 ec 02             	sub    sp,0x2
    25ba:	a1 4c 01             	mov    ax,ds:0x14c
    25bd:	2d 01 00             	sub    ax,0x1
    25c0:	71 05                	jno    0x25c7
    25c2:	9a 3e 04 fc 25       	call   0x25fc:0x43e
    25c7:	50                   	push   ax
    25c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25cb:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    25d0:	9a 32 3e c9 26       	call   0x26c9:0x3e32
    25d5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    25d8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    25db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25de:	26 3b 85 4a 04       	cmp    ax,WORD PTR es:[di+0x44a]
    25e3:	74 0a                	je     0x25ef
    25e5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    25e8:	06                   	push   es
    25e9:	57                   	push   di
    25ea:	9a da 1f e3 26       	call   0x26e3:0x1fda
    25ef:	c9                   	leave
    25f0:	ca 08 00             	retf   0x8
    25f3:	55                   	push   bp
    25f4:	89 e5                	mov    bp,sp
    25f6:	b8 08 00             	mov    ax,0x8
    25f9:	9a 44 04 12 26       	call   0x2612:0x444
    25fe:	83 ec 08             	sub    sp,0x8
    2601:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2604:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2607:	bf 94 00             	mov    di,0x94
    260a:	b8 25 26             	mov    ax,0x2625
    260d:	50                   	push   ax
    260e:	57                   	push   di
    260f:	9a 55 22 2c 26       	call   0x262c:0x2255
    2614:	08 c0                	or     al,al
    2616:	75 03                	jne    0x261b
    2618:	e9 ca 00             	jmp    0x26e5
    261b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    261e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2621:	bf 94 00             	mov    di,0x94
    2624:	b8 47 26             	mov    ax,0x2647
    2627:	50                   	push   ax
    2628:	57                   	push   di
    2629:	9a 73 22 4e 26       	call   0x264e:0x2273
    262e:	89 c7                	mov    di,ax
    2630:	8e c2                	mov    es,dx
    2632:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2635:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    263a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    263d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2640:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2643:	bf 94 00             	mov    di,0x94
    2646:	b8 5f 26             	mov    ax,0x265f
    2649:	50                   	push   ax
    264a:	57                   	push   di
    264b:	9a 73 22 6f 26       	call   0x266f:0x2273
    2650:	52                   	push   dx
    2651:	50                   	push   ax
    2652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2655:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    265a:	06                   	push   es
    265b:	57                   	push   di
    265c:	9a 2b 16 0a 27       	call   0x270a:0x162b
    2661:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2664:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2667:	05 01 00             	add    ax,0x1
    266a:	71 05                	jno    0x2671
    266c:	9a 3e 04 a3 26       	call   0x26a3:0x43e
    2671:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    2675:	b0 00                	mov    al,0x0
    2677:	7d 01                	jge    0x267a
    2679:	40                   	inc    ax
    267a:	8a c8                	mov    cl,al
    267c:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2680:	b0 00                	mov    al,0x0
    2682:	7d 01                	jge    0x2685
    2684:	40                   	inc    ax
    2685:	8a d0                	mov    dl,al
    2687:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    268b:	b0 00                	mov    al,0x0
    268d:	7c 01                	jl     0x2690
    268f:	40                   	inc    ax
    2690:	22 c2                	and    al,dl
    2692:	22 c1                	and    al,cl
    2694:	08 c0                	or     al,al
    2696:	74 12                	je     0x26aa
    2698:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    269b:	05 01 00             	add    ax,0x1
    269e:	71 05                	jno    0x26a5
    26a0:	9a 3e 04 bb 26       	call   0x26bb:0x43e
    26a5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26a8:	eb 24                	jmp    0x26ce
    26aa:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    26ae:	75 1e                	jne    0x26ce
    26b0:	a1 4c 01             	mov    ax,ds:0x14c
    26b3:	2d 01 00             	sub    ax,0x1
    26b6:	71 05                	jno    0x26bd
    26b8:	9a 3e 04 fa 26       	call   0x26fa:0x43e
    26bd:	50                   	push   ax
    26be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c1:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    26c6:	9a 32 3e ff ff       	call   0xffff:0x3e32
    26cb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26ce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    26d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d4:	26 3b 85 4a 04       	cmp    ax,WORD PTR es:[di+0x44a]
    26d9:	74 0a                	je     0x26e5
    26db:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26de:	06                   	push   es
    26df:	57                   	push   di
    26e0:	9a da 1f 8f 27       	call   0x278f:0x1fda
    26e5:	c9                   	leave
    26e6:	ca 08 00             	retf   0x8
    26e9:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    26ed:	ff                   	(bad)
    26ee:	7f 00                	jg     0x26f0
    26f0:	00 55 89             	add    BYTE PTR [di-0x77],dl
    26f3:	e5 b8                	in     ax,0xb8
    26f5:	06                   	push   es
    26f6:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    26fa:	11 27                	adc    WORD PTR [bx],sp
    26fc:	81 ec 06 02          	sub    sp,0x206
    2700:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2703:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2706:	bf 94 00             	mov    di,0x94
    2709:	b8 21 27             	mov    ax,0x2721
    270c:	50                   	push   ax
    270d:	57                   	push   di
    270e:	9a 55 22 28 27       	call   0x2728:0x2255
    2713:	08 c0                	or     al,al
    2715:	74 7a                	je     0x2791
    2717:	ff 76 0c             	push   WORD PTR [bp+0xc]
    271a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    271d:	bf 94 00             	mov    di,0x94
    2720:	b8 b8 27             	mov    ax,0x27b8
    2723:	50                   	push   ax
    2724:	57                   	push   di
    2725:	9a 73 22 55 27       	call   0x2755:0x2273
    272a:	89 c7                	mov    di,ax
    272c:	8e c2                	mov    es,dx
    272e:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2731:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2734:	8d be fa fd          	lea    di,[bp-0x206]
    2738:	16                   	push   ss
    2739:	57                   	push   di
    273a:	8d be fa fe          	lea    di,[bp-0x106]
    273e:	16                   	push   ss
    273f:	57                   	push   di
    2740:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2743:	06                   	push   es
    2744:	57                   	push   di
    2745:	9a 2a 51 ff ff       	call   0xffff:0x512a
    274a:	83 c4 04             	add    sp,0x4
    274d:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    2751:	50                   	push   ax
    2752:	9a e9 18 62 27       	call   0x2762:0x18e9
    2757:	9a da 08 ff ff       	call   0xffff:0x8da
    275c:	bf e9 26             	mov    di,0x26e9
    275f:	9a 16 04 9d 27       	call   0x279d:0x416
    2764:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2767:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    276a:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    276e:	b0 00                	mov    al,0x0
    2770:	7f 01                	jg     0x2773
    2772:	40                   	inc    ax
    2773:	8a d0                	mov    dl,al
    2775:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2779:	b0 00                	mov    al,0x0
    277b:	7e 01                	jle    0x277e
    277d:	40                   	inc    ax
    277e:	22 c2                	and    al,dl
    2780:	08 c0                	or     al,al
    2782:	74 0d                	je     0x2791
    2784:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2787:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    278a:	06                   	push   es
    278b:	57                   	push   di
    278c:	9a fa 1f 7e 31       	call   0x317e:0x1ffa
    2791:	c9                   	leave
    2792:	ca 08 00             	retf   0x8
    2795:	55                   	push   bp
    2796:	89 e5                	mov    bp,sp
    2798:	31 c0                	xor    ax,ax
    279a:	9a 44 04 de 28       	call   0x28de:0x444
    279f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a2:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    27a8:	b0 00                	mov    al,0x0
    27aa:	75 01                	jne    0x27ad
    27ac:	40                   	inc    ax
    27ad:	50                   	push   ax
    27ae:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    27b3:	06                   	push   es
    27b4:	57                   	push   di
    27b5:	9a 75 12 ff ff       	call   0xffff:0x1275
    27ba:	c9                   	leave
    27bb:	ca 08 00             	retf   0x8
    27be:	0f 41 63 74          	cmovno sp,WORD PTR [bp+di+0x74]
    27c2:	69 66 49 6d 6d       	imul   sp,WORD PTR [bp+0x49],0x6d6d
    27c7:	6f                   	outs   dx,WORD PTR ds:[si]
    27c8:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    27cb:	69 73 65 15 49       	imul   si,WORD PTR [bp+di+0x65],0x4915
    27d0:	6d                   	ins    WORD PTR es:[di],dx
    27d1:	6d                   	ins    WORD PTR es:[di],dx
    27d2:	6f                   	outs   dx,WORD PTR ds:[si]
    27d3:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    27d6:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    27db:	6f                   	outs   dx,WORD PTR ds:[si]
    27dc:	6e                   	outs   dx,BYTE PTR ds:[si]
    27dd:	73 42                	jae    0x2821
    27df:	72 75                	jb     0x2856
    27e1:	74 65                	je     0x2848
    27e3:	73 0d                	jae    0x27f2
    27e5:	41                   	inc    cx
    27e6:	6d                   	ins    WORD PTR es:[di],dx
    27e7:	6f                   	outs   dx,WORD PTR ds:[si]
    27e8:	72 74                	jb     0x285e
    27ea:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    27ef:	65 6e                	outs   dx,BYTE PTR gs:[si]
    27f1:	74 0b                	je     0x27fe
    27f3:	56                   	push   si
    27f4:	61                   	popa
    27f5:	6c                   	ins    BYTE PTR es:[di],dx
    27f6:	65 75 72             	gs jne 0x286b
    27f9:	53                   	push   bx
    27fa:	74 6f                	je     0x286b
    27fc:	63 6b 0e             	arpl   WORD PTR [bp+di+0xe],bp
    27ff:	41                   	inc    cx
    2800:	63 74 69             	arpl   WORD PTR [si+0x69],si
    2803:	66 43                	inc    ebx
    2805:	69 72 63 75 6c       	imul   si,WORD PTR [bp+si+0x63],0x6c75
    280a:	61                   	popa
    280b:	6e                   	outs   dx,BYTE PTR ds:[si]
    280c:	74 07                	je     0x2815
    280e:	43                   	inc    bx
    280f:	6c                   	ins    BYTE PTR es:[di],dx
    2810:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    2815:	0a 54 72             	or     dl,BYTE PTR [si+0x72]
    2818:	65 73 6f             	gs jae 0x288a
    281b:	72 65                	jb     0x2882
    281d:	72 69                	jb     0x2888
    281f:	65 05 41 63          	gs add ax,0x6341
    2823:	74 69                	je     0x288e
    2825:	66 11 52 65          	adc    DWORD PTR [bp+si+0x65],edx
    2829:	73 73                	jae    0x289e
    282b:	6f                   	outs   dx,WORD PTR ds:[si]
    282c:	75 72                	jne    0x28a0
    282e:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    2831:	50                   	push   ax
    2832:	72 6f                	jb     0x28a3
    2834:	70 72                	jo     0x28a8
    2836:	65 73 0d             	gs jae 0x2846
    2839:	43                   	inc    bx
    283a:	61                   	popa
    283b:	70 69                	jo     0x28a6
    283d:	74 61                	je     0x28a0
    283f:	6c                   	ins    BYTE PTR es:[di],dx
    2840:	53                   	push   bx
    2841:	6f                   	outs   dx,WORD PTR ds:[si]
    2842:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    2845:	6c                   	ins    BYTE PTR es:[di],dx
    2846:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    2849:	73 65                	jae    0x28b0
    284b:	72 76                	jb     0x28c3
    284d:	65 73 0b             	gs jae 0x285b
    2850:	52                   	push   dx
    2851:	65 73 75             	gs jae 0x28c9
    2854:	6c                   	ins    BYTE PTR es:[di],dx
    2855:	74 61                	je     0x28b8
    2857:	74 4e                	je     0x28a7
    2859:	65 74 10             	gs je  0x286c
    285c:	56                   	push   si
    285d:	61                   	popa
    285e:	72 69                	jb     0x28c9
    2860:	61                   	popa
    2861:	74 69                	je     0x28cc
    2863:	6f                   	outs   dx,WORD PTR ds:[si]
    2864:	6e                   	outs   dx,BYTE PTR ds:[si]
    2865:	45                   	inc    bp
    2866:	6d                   	ins    WORD PTR es:[di],dx
    2867:	70 72                	jo     0x28db
    2869:	75 6e                	jne    0x28d9
    286b:	74 00                	je     0x286d
    286d:	00 00                	add    BYTE PTR [bx+si],al
    286f:	00 0a                	add    BYTE PTR [bp+si],cl
    2871:	4e                   	dec    si
    2872:	65 77 45             	gs ja  0x28ba
    2875:	6d                   	ins    WORD PTR es:[di],dx
    2876:	70 72                	jo     0x28ea
    2878:	75 6e                	jne    0x28e8
    287a:	74 05                	je     0x2881
    287c:	44                   	inc    sp
    287d:	65 74 74             	gs je  0x28f4
    2880:	65 0d 44 65          	gs or  ax,0x6544
    2884:	63 6f 75             	arpl   WORD PTR [bx+0x75],bp
    2887:	76 65                	jbe    0x28ee
    2889:	72 74                	jb     0x28ff
    288b:	41                   	inc    cx
    288c:	75 74                	jne    0x2902
    288e:	6f                   	outs   dx,WORD PTR ds:[si]
    288f:	0e                   	push   cs
    2890:	44                   	inc    sp
    2891:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    2895:	76 65                	jbe    0x28fc
    2897:	72 74                	jb     0x290d
    2899:	4e                   	dec    si
    289a:	61                   	popa
    289b:	75 74                	jne    0x2911
    289d:	6f                   	outs   dx,WORD PTR ds:[si]
    289e:	14 52                	adc    al,0x52
    28a0:	65 73 73             	gs jae 0x2916
    28a3:	6f                   	outs   dx,WORD PTR ds:[si]
    28a4:	75 72                	jne    0x2918
    28a6:	63 65 73             	arpl   WORD PTR [di+0x73],sp
    28a9:	45                   	inc    bp
    28aa:	6d                   	ins    WORD PTR es:[di],dx
    28ab:	70 72                	jo     0x291f
    28ad:	75 6e                	jne    0x291d
    28af:	74 65                	je     0x2916
    28b1:	65 73 07             	gs jae 0x28bb
    28b4:	45                   	inc    bp
    28b5:	6d                   	ins    WORD PTR es:[di],dx
    28b6:	70 72                	jo     0x292a
    28b8:	75 6e                	jne    0x2928
    28ba:	74 0c                	je     0x28c8
    28bc:	46                   	inc    si
    28bd:	6f                   	outs   dx,WORD PTR ds:[si]
    28be:	75 72                	jne    0x2932
    28c0:	6e                   	outs   dx,BYTE PTR ds:[si]
    28c1:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    28c6:	72 73                	jb     0x293b
    28c8:	05 49 6d             	add    ax,0x6d49
    28cb:	70 6f                	jo     0x293c
    28cd:	74 06                	je     0x28d5
    28cf:	50                   	push   ax
    28d0:	61                   	popa
    28d1:	73 73                	jae    0x2946
    28d3:	69 66 55 89 e5       	imul   sp,WORD PTR [bp+0x55],0xe589
    28d8:	b8 2a 01             	mov    ax,0x12a
    28db:	9a 44 04 f5 28       	call   0x28f5:0x444
    28e0:	81 ec 2a 01          	sub    sp,0x12a
    28e4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28e7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28ea:	bf 38 01             	mov    di,0x138
    28ed:	b8 ff ff             	mov    ax,0xffff
    28f0:	50                   	push   ax
    28f1:	57                   	push   di
    28f2:	9a 73 22 83 29       	call   0x2983:0x2273
    28f7:	89 c7                	mov    di,ax
    28f9:	8e c2                	mov    es,dx
    28fb:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    28ff:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2903:	bf ce 27             	mov    di,0x27ce
    2906:	0e                   	push   cs
    2907:	57                   	push   di
    2908:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    290c:	06                   	push   es
    290d:	57                   	push   di
    290e:	9a 9b 3b 33 29       	call   0x2933:0x3b9b
    2913:	89 c7                	mov    di,ax
    2915:	8e c2                	mov    es,dx
    2917:	06                   	push   es
    2918:	57                   	push   di
    2919:	26 c4 3d             	les    di,DWORD PTR es:[di]
    291c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2920:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2925:	bf e4 27             	mov    di,0x27e4
    2928:	0e                   	push   cs
    2929:	57                   	push   di
    292a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    292e:	06                   	push   es
    292f:	57                   	push   di
    2930:	9a 9b 3b 63 29       	call   0x2963:0x3b9b
    2935:	89 c7                	mov    di,ax
    2937:	8e c2                	mov    es,dx
    2939:	06                   	push   es
    293a:	57                   	push   di
    293b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    293e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2942:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2947:	9b de e1             	fsubrp st(1),st
    294a:	83 ec 08             	sub    sp,0x8
    294d:	89 e3                	mov    bx,sp
    294f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2953:	90                   	nop
    2954:	9b                   	fwait
    2955:	bf be 27             	mov    di,0x27be
    2958:	0e                   	push   cs
    2959:	57                   	push   di
    295a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    295e:	06                   	push   es
    295f:	57                   	push   di
    2960:	9a 9b 3b 98 29       	call   0x2998:0x3b9b
    2965:	89 c7                	mov    di,ax
    2967:	8e c2                	mov    es,dx
    2969:	06                   	push   es
    296a:	57                   	push   di
    296b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    296e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2972:	bf f2 27             	mov    di,0x27f2
    2975:	0e                   	push   cs
    2976:	57                   	push   di
    2977:	8d be 00 ff          	lea    di,[bp-0x100]
    297b:	16                   	push   ss
    297c:	57                   	push   di
    297d:	68 ff 00             	push   0xff
    2980:	9a e7 17 fb 2d       	call   0x2dfb:0x17e7
    2985:	8d be 00 ff          	lea    di,[bp-0x100]
    2989:	16                   	push   ss
    298a:	57                   	push   di
    298b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    298e:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    2993:	06                   	push   es
    2994:	57                   	push   di
    2995:	9a 9b 3b bf 29       	call   0x29bf:0x3b9b
    299a:	89 c7                	mov    di,ax
    299c:	8e c2                	mov    es,dx
    299e:	06                   	push   es
    299f:	57                   	push   di
    29a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29a3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    29a7:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    29ac:	8d be 00 ff          	lea    di,[bp-0x100]
    29b0:	16                   	push   ss
    29b1:	57                   	push   di
    29b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b5:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    29ba:	06                   	push   es
    29bb:	57                   	push   di
    29bc:	9a 9b 3b f0 29       	call   0x29f0:0x3b9b
    29c1:	89 c7                	mov    di,ax
    29c3:	8e c2                	mov    es,dx
    29c5:	06                   	push   es
    29c6:	57                   	push   di
    29c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29ca:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    29ce:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    29d3:	9b de c1             	faddp  st(1),st
    29d6:	83 ec 08             	sub    sp,0x8
    29d9:	89 e3                	mov    bx,sp
    29db:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    29df:	90                   	nop
    29e0:	9b                   	fwait
    29e1:	8d be 00 ff          	lea    di,[bp-0x100]
    29e5:	16                   	push   ss
    29e6:	57                   	push   di
    29e7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    29eb:	06                   	push   es
    29ec:	57                   	push   di
    29ed:	9a 9b 3b 0d 2a       	call   0x2a0d:0x3b9b
    29f2:	89 c7                	mov    di,ax
    29f4:	8e c2                	mov    es,dx
    29f6:	06                   	push   es
    29f7:	57                   	push   di
    29f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29fb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    29ff:	bf f2 27             	mov    di,0x27f2
    2a02:	0e                   	push   cs
    2a03:	57                   	push   di
    2a04:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2a08:	06                   	push   es
    2a09:	57                   	push   di
    2a0a:	9a 9b 3b 2f 2a       	call   0x2a2f:0x3b9b
    2a0f:	89 c7                	mov    di,ax
    2a11:	8e c2                	mov    es,dx
    2a13:	06                   	push   es
    2a14:	57                   	push   di
    2a15:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a18:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2a1c:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2a21:	bf 0d 28             	mov    di,0x280d
    2a24:	0e                   	push   cs
    2a25:	57                   	push   di
    2a26:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2a2a:	06                   	push   es
    2a2b:	57                   	push   di
    2a2c:	9a 9b 3b 59 2a       	call   0x2a59:0x3b9b
    2a31:	89 c7                	mov    di,ax
    2a33:	8e c2                	mov    es,dx
    2a35:	06                   	push   es
    2a36:	57                   	push   di
    2a37:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a3a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2a3e:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2a43:	9b de c1             	faddp  st(1),st
    2a46:	9b db be e0 fe       	fstp   TBYTE PTR [bp-0x120]
    2a4b:	bf 15 28             	mov    di,0x2815
    2a4e:	0e                   	push   cs
    2a4f:	57                   	push   di
    2a50:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2a54:	06                   	push   es
    2a55:	57                   	push   di
    2a56:	9a 9b 3b 89 2a       	call   0x2a89:0x3b9b
    2a5b:	89 c7                	mov    di,ax
    2a5d:	8e c2                	mov    es,dx
    2a5f:	06                   	push   es
    2a60:	57                   	push   di
    2a61:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a64:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2a68:	9b db ae e0 fe       	fld    TBYTE PTR [bp-0x120]
    2a6d:	9b de c1             	faddp  st(1),st
    2a70:	83 ec 08             	sub    sp,0x8
    2a73:	89 e3                	mov    bx,sp
    2a75:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2a79:	90                   	nop
    2a7a:	9b                   	fwait
    2a7b:	bf fe 27             	mov    di,0x27fe
    2a7e:	0e                   	push   cs
    2a7f:	57                   	push   di
    2a80:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2a84:	06                   	push   es
    2a85:	57                   	push   di
    2a86:	9a 9b 3b a6 2a       	call   0x2aa6:0x3b9b
    2a8b:	89 c7                	mov    di,ax
    2a8d:	8e c2                	mov    es,dx
    2a8f:	06                   	push   es
    2a90:	57                   	push   di
    2a91:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a94:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2a98:	bf be 27             	mov    di,0x27be
    2a9b:	0e                   	push   cs
    2a9c:	57                   	push   di
    2a9d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2aa1:	06                   	push   es
    2aa2:	57                   	push   di
    2aa3:	9a 9b 3b c8 2a       	call   0x2ac8:0x3b9b
    2aa8:	89 c7                	mov    di,ax
    2aaa:	8e c2                	mov    es,dx
    2aac:	06                   	push   es
    2aad:	57                   	push   di
    2aae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ab1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2ab5:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2aba:	bf fe 27             	mov    di,0x27fe
    2abd:	0e                   	push   cs
    2abe:	57                   	push   di
    2abf:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2ac3:	06                   	push   es
    2ac4:	57                   	push   di
    2ac5:	9a 9b 3b f8 2a       	call   0x2af8:0x3b9b
    2aca:	89 c7                	mov    di,ax
    2acc:	8e c2                	mov    es,dx
    2ace:	06                   	push   es
    2acf:	57                   	push   di
    2ad0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ad3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2ad7:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2adc:	9b de c1             	faddp  st(1),st
    2adf:	83 ec 08             	sub    sp,0x8
    2ae2:	89 e3                	mov    bx,sp
    2ae4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2ae8:	90                   	nop
    2ae9:	9b                   	fwait
    2aea:	bf 20 28             	mov    di,0x2820
    2aed:	0e                   	push   cs
    2aee:	57                   	push   di
    2aef:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2af3:	06                   	push   es
    2af4:	57                   	push   di
    2af5:	9a 9b 3b 15 2b       	call   0x2b15:0x3b9b
    2afa:	89 c7                	mov    di,ax
    2afc:	8e c2                	mov    es,dx
    2afe:	06                   	push   es
    2aff:	57                   	push   di
    2b00:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b03:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2b07:	bf 38 28             	mov    di,0x2838
    2b0a:	0e                   	push   cs
    2b0b:	57                   	push   di
    2b0c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b10:	06                   	push   es
    2b11:	57                   	push   di
    2b12:	9a 9b 3b 37 2b       	call   0x2b37:0x3b9b
    2b17:	89 c7                	mov    di,ax
    2b19:	8e c2                	mov    es,dx
    2b1b:	06                   	push   es
    2b1c:	57                   	push   di
    2b1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b20:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2b24:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2b29:	bf 46 28             	mov    di,0x2846
    2b2c:	0e                   	push   cs
    2b2d:	57                   	push   di
    2b2e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b32:	06                   	push   es
    2b33:	57                   	push   di
    2b34:	9a 9b 3b 61 2b       	call   0x2b61:0x3b9b
    2b39:	89 c7                	mov    di,ax
    2b3b:	8e c2                	mov    es,dx
    2b3d:	06                   	push   es
    2b3e:	57                   	push   di
    2b3f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b42:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2b46:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2b4b:	9b de c1             	faddp  st(1),st
    2b4e:	9b db be e0 fe       	fstp   TBYTE PTR [bp-0x120]
    2b53:	bf 4f 28             	mov    di,0x284f
    2b56:	0e                   	push   cs
    2b57:	57                   	push   di
    2b58:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b5c:	06                   	push   es
    2b5d:	57                   	push   di
    2b5e:	9a 9b 3b 91 2b       	call   0x2b91:0x3b9b
    2b63:	89 c7                	mov    di,ax
    2b65:	8e c2                	mov    es,dx
    2b67:	06                   	push   es
    2b68:	57                   	push   di
    2b69:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b6c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2b70:	9b db ae e0 fe       	fld    TBYTE PTR [bp-0x120]
    2b75:	9b de c1             	faddp  st(1),st
    2b78:	83 ec 08             	sub    sp,0x8
    2b7b:	89 e3                	mov    bx,sp
    2b7d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2b81:	90                   	nop
    2b82:	9b                   	fwait
    2b83:	bf 26 28             	mov    di,0x2826
    2b86:	0e                   	push   cs
    2b87:	57                   	push   di
    2b88:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b8c:	06                   	push   es
    2b8d:	57                   	push   di
    2b8e:	9a 9b 3b b2 2b       	call   0x2bb2:0x3b9b
    2b93:	89 c7                	mov    di,ax
    2b95:	8e c2                	mov    es,dx
    2b97:	06                   	push   es
    2b98:	57                   	push   di
    2b99:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b9c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2ba0:	bf 5b 28             	mov    di,0x285b
    2ba3:	0e                   	push   cs
    2ba4:	57                   	push   di
    2ba5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ba8:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    2bad:	06                   	push   es
    2bae:	57                   	push   di
    2baf:	9a 9b 3b f7 2b       	call   0x2bf7:0x3b9b
    2bb4:	89 c7                	mov    di,ax
    2bb6:	8e c2                	mov    es,dx
    2bb8:	06                   	push   es
    2bb9:	57                   	push   di
    2bba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bbd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2bc1:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    2bc6:	90                   	nop
    2bc7:	9b 9b dd 86 f8 fe    	fld    QWORD PTR [bp-0x108]
    2bcd:	9b 2e d8 1e 6c 28    	fcomp  DWORD PTR cs:0x286c
    2bd3:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    2bd8:	90                   	nop
    2bd9:	9b                   	fwait
    2bda:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    2bde:	9e                   	sahf
    2bdf:	77 27                	ja     0x2c08
    2be1:	6a 00                	push   0x0
    2be3:	6a 00                	push   0x0
    2be5:	6a 00                	push   0x0
    2be7:	6a 00                	push   0x0
    2be9:	bf 70 28             	mov    di,0x2870
    2bec:	0e                   	push   cs
    2bed:	57                   	push   di
    2bee:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2bf2:	06                   	push   es
    2bf3:	57                   	push   di
    2bf4:	9a 9b 3b 26 2c       	call   0x2c26:0x3b9b
    2bf9:	89 c7                	mov    di,ax
    2bfb:	8e c2                	mov    es,dx
    2bfd:	06                   	push   es
    2bfe:	57                   	push   di
    2bff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c02:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2c06:	eb 2d                	jmp    0x2c35
    2c08:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    2c0c:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    2c10:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    2c14:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    2c18:	bf 70 28             	mov    di,0x2870
    2c1b:	0e                   	push   cs
    2c1c:	57                   	push   di
    2c1d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2c21:	06                   	push   es
    2c22:	57                   	push   di
    2c23:	9a 9b 3b 43 2c       	call   0x2c43:0x3b9b
    2c28:	89 c7                	mov    di,ax
    2c2a:	8e c2                	mov    es,dx
    2c2c:	06                   	push   es
    2c2d:	57                   	push   di
    2c2e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c31:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2c35:	bf 81 28             	mov    di,0x2881
    2c38:	0e                   	push   cs
    2c39:	57                   	push   di
    2c3a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2c3e:	06                   	push   es
    2c3f:	57                   	push   di
    2c40:	9a 9b 3b 65 2c       	call   0x2c65:0x3b9b
    2c45:	89 c7                	mov    di,ax
    2c47:	8e c2                	mov    es,dx
    2c49:	06                   	push   es
    2c4a:	57                   	push   di
    2c4b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c4e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2c52:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2c57:	bf 8f 28             	mov    di,0x288f
    2c5a:	0e                   	push   cs
    2c5b:	57                   	push   di
    2c5c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2c60:	06                   	push   es
    2c61:	57                   	push   di
    2c62:	9a 9b 3b 95 2c       	call   0x2c95:0x3b9b
    2c67:	89 c7                	mov    di,ax
    2c69:	8e c2                	mov    es,dx
    2c6b:	06                   	push   es
    2c6c:	57                   	push   di
    2c6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c70:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2c74:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2c79:	9b de c1             	faddp  st(1),st
    2c7c:	83 ec 08             	sub    sp,0x8
    2c7f:	89 e3                	mov    bx,sp
    2c81:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2c85:	90                   	nop
    2c86:	9b                   	fwait
    2c87:	bf 7b 28             	mov    di,0x287b
    2c8a:	0e                   	push   cs
    2c8b:	57                   	push   di
    2c8c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2c90:	06                   	push   es
    2c91:	57                   	push   di
    2c92:	9a 9b 3b b2 2c       	call   0x2cb2:0x3b9b
    2c97:	89 c7                	mov    di,ax
    2c99:	8e c2                	mov    es,dx
    2c9b:	06                   	push   es
    2c9c:	57                   	push   di
    2c9d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ca0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2ca4:	bf b3 28             	mov    di,0x28b3
    2ca7:	0e                   	push   cs
    2ca8:	57                   	push   di
    2ca9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2cad:	06                   	push   es
    2cae:	57                   	push   di
    2caf:	9a 9b 3b d4 2c       	call   0x2cd4:0x3b9b
    2cb4:	89 c7                	mov    di,ax
    2cb6:	8e c2                	mov    es,dx
    2cb8:	06                   	push   es
    2cb9:	57                   	push   di
    2cba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cbd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2cc1:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2cc6:	bf 7b 28             	mov    di,0x287b
    2cc9:	0e                   	push   cs
    2cca:	57                   	push   di
    2ccb:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2ccf:	06                   	push   es
    2cd0:	57                   	push   di
    2cd1:	9a 9b 3b fe 2c       	call   0x2cfe:0x3b9b
    2cd6:	89 c7                	mov    di,ax
    2cd8:	8e c2                	mov    es,dx
    2cda:	06                   	push   es
    2cdb:	57                   	push   di
    2cdc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cdf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2ce3:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2ce8:	9b de c1             	faddp  st(1),st
    2ceb:	9b db be e0 fe       	fstp   TBYTE PTR [bp-0x120]
    2cf0:	bf bb 28             	mov    di,0x28bb
    2cf3:	0e                   	push   cs
    2cf4:	57                   	push   di
    2cf5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2cf9:	06                   	push   es
    2cfa:	57                   	push   di
    2cfb:	9a 9b 3b 28 2d       	call   0x2d28:0x3b9b
    2d00:	89 c7                	mov    di,ax
    2d02:	8e c2                	mov    es,dx
    2d04:	06                   	push   es
    2d05:	57                   	push   di
    2d06:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d09:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2d0d:	9b db ae e0 fe       	fld    TBYTE PTR [bp-0x120]
    2d12:	9b de c1             	faddp  st(1),st
    2d15:	9b db be d6 fe       	fstp   TBYTE PTR [bp-0x12a]
    2d1a:	bf c8 28             	mov    di,0x28c8
    2d1d:	0e                   	push   cs
    2d1e:	57                   	push   di
    2d1f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d23:	06                   	push   es
    2d24:	57                   	push   di
    2d25:	9a 9b 3b 58 2d       	call   0x2d58:0x3b9b
    2d2a:	89 c7                	mov    di,ax
    2d2c:	8e c2                	mov    es,dx
    2d2e:	06                   	push   es
    2d2f:	57                   	push   di
    2d30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d33:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2d37:	9b db ae d6 fe       	fld    TBYTE PTR [bp-0x12a]
    2d3c:	9b de c1             	faddp  st(1),st
    2d3f:	83 ec 08             	sub    sp,0x8
    2d42:	89 e3                	mov    bx,sp
    2d44:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2d48:	90                   	nop
    2d49:	9b                   	fwait
    2d4a:	bf 9e 28             	mov    di,0x289e
    2d4d:	0e                   	push   cs
    2d4e:	57                   	push   di
    2d4f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d53:	06                   	push   es
    2d54:	57                   	push   di
    2d55:	9a 9b 3b 75 2d       	call   0x2d75:0x3b9b
    2d5a:	89 c7                	mov    di,ax
    2d5c:	8e c2                	mov    es,dx
    2d5e:	06                   	push   es
    2d5f:	57                   	push   di
    2d60:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d63:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2d67:	bf 26 28             	mov    di,0x2826
    2d6a:	0e                   	push   cs
    2d6b:	57                   	push   di
    2d6c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d70:	06                   	push   es
    2d71:	57                   	push   di
    2d72:	9a 9b 3b 97 2d       	call   0x2d97:0x3b9b
    2d77:	89 c7                	mov    di,ax
    2d79:	8e c2                	mov    es,dx
    2d7b:	06                   	push   es
    2d7c:	57                   	push   di
    2d7d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d80:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2d84:	9b db be ea fe       	fstp   TBYTE PTR [bp-0x116]
    2d89:	bf 9e 28             	mov    di,0x289e
    2d8c:	0e                   	push   cs
    2d8d:	57                   	push   di
    2d8e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d92:	06                   	push   es
    2d93:	57                   	push   di
    2d94:	9a 9b 3b c7 2d       	call   0x2dc7:0x3b9b
    2d99:	89 c7                	mov    di,ax
    2d9b:	8e c2                	mov    es,dx
    2d9d:	06                   	push   es
    2d9e:	57                   	push   di
    2d9f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2da2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2da6:	9b db ae ea fe       	fld    TBYTE PTR [bp-0x116]
    2dab:	9b de c1             	faddp  st(1),st
    2dae:	83 ec 08             	sub    sp,0x8
    2db1:	89 e3                	mov    bx,sp
    2db3:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2db7:	90                   	nop
    2db8:	9b                   	fwait
    2db9:	bf ce 28             	mov    di,0x28ce
    2dbc:	0e                   	push   cs
    2dbd:	57                   	push   di
    2dbe:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2dc2:	06                   	push   es
    2dc3:	57                   	push   di
    2dc4:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    2dc9:	89 c7                	mov    di,ax
    2dcb:	8e c2                	mov    es,dx
    2dcd:	06                   	push   es
    2dce:	57                   	push   di
    2dcf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dd2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2dd6:	c9                   	leave
    2dd7:	ca 08 00             	retf   0x8
    2dda:	bf 2e 9a             	mov    di,0x9a2e
    2ddd:	2e 4b                	cs dec bx
    2ddf:	2e 3c 2e             	cs cmp al,0x2e
    2de2:	e8 2e 7b             	call   0xa913
    2de5:	2e e8 2e 5c          	cs call 0x8a17
    2de9:	2e 00 00             	add    BYTE PTR cs:[bx+si],al
    2dec:	00 00                	add    BYTE PTR [bx+si],al
    2dee:	ff 00                	inc    WORD PTR [bx+si]
    2df0:	00 00                	add    BYTE PTR [bx+si],al
    2df2:	55                   	push   bp
    2df3:	89 e5                	mov    bp,sp
    2df5:	b8 04 00             	mov    ax,0x4
    2df8:	9a 44 04 6c 2e       	call   0x2e6c:0x444
    2dfd:	83 ec 04             	sub    sp,0x4
    2e00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e03:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2e08:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2e0b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2e0e:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    2e12:	b0 00                	mov    al,0x0
    2e14:	74 01                	je     0x2e17
    2e16:	40                   	inc    ax
    2e17:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    2e1b:	08 c0                	or     al,al
    2e1d:	75 03                	jne    0x2e22
    2e1f:	e9 ee 00             	jmp    0x2f10
    2e22:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e25:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2e28:	2d 21 00             	sub    ax,0x21
    2e2b:	3d 07 00             	cmp    ax,0x7
    2e2e:	76 03                	jbe    0x2e33
    2e30:	e9 b5 00             	jmp    0x2ee8
    2e33:	89 c3                	mov    bx,ax
    2e35:	d1 e3                	shl    bx,1
    2e37:	2e ff a7 da 2d       	jmp    WORD PTR cs:[bx+0x2dda]
    2e3c:	6a 00                	push   0x0
    2e3e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e41:	06                   	push   es
    2e42:	57                   	push   di
    2e43:	9a d0 1c 57 2e       	call   0x2e57:0x1cd0
    2e48:	e9 9d 00             	jmp    0x2ee8
    2e4b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e4e:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2e52:	06                   	push   es
    2e53:	57                   	push   di
    2e54:	9a d0 1c 77 2e       	call   0x2e77:0x1cd0
    2e59:	e9 8c 00             	jmp    0x2ee8
    2e5c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e5f:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2e63:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    2e67:	71 05                	jno    0x2e6e
    2e69:	9a 3e 04 8b 2e       	call   0x2e8b:0x43e
    2e6e:	50                   	push   ax
    2e6f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e72:	06                   	push   es
    2e73:	57                   	push   di
    2e74:	9a d0 1c 96 2e       	call   0x2e96:0x1cd0
    2e79:	eb 6d                	jmp    0x2ee8
    2e7b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e7e:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2e82:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    2e86:	71 05                	jno    0x2e8d
    2e88:	9a 3e 04 b0 2e       	call   0x2eb0:0x43e
    2e8d:	50                   	push   ax
    2e8e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e91:	06                   	push   es
    2e92:	57                   	push   di
    2e93:	9a d0 1c bb 2e       	call   0x2ebb:0x1cd0
    2e98:	eb 4e                	jmp    0x2ee8
    2e9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9d:	06                   	push   es
    2e9e:	57                   	push   di
    2e9f:	9a f4 18 c7 2e       	call   0x2ec7:0x18f4
    2ea4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ea7:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    2eab:	71 05                	jno    0x2eb2
    2ead:	9a 3e 04 d9 2e       	call   0x2ed9:0x43e
    2eb2:	50                   	push   ax
    2eb3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2eb6:	06                   	push   es
    2eb7:	57                   	push   di
    2eb8:	9a d0 1c e4 2e       	call   0x2ee4:0x1cd0
    2ebd:	eb 29                	jmp    0x2ee8
    2ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec2:	06                   	push   es
    2ec3:	57                   	push   di
    2ec4:	9a f4 18 01 31       	call   0x3101:0x18f4
    2ec9:	8b d0                	mov    dx,ax
    2ecb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ece:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2ed2:	2b c2                	sub    ax,dx
    2ed4:	71 05                	jno    0x2edb
    2ed6:	9a 3e 04 f6 2e       	call   0x2ef6:0x43e
    2edb:	50                   	push   ax
    2edc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2edf:	06                   	push   es
    2ee0:	57                   	push   di
    2ee1:	9a d0 1c 55 2f       	call   0x2f55:0x1cd0
    2ee6:	eb 00                	jmp    0x2ee8
    2ee8:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2eeb:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2eee:	31 d2                	xor    dx,dx
    2ef0:	bf ea 2d             	mov    di,0x2dea
    2ef3:	9a 16 04 4a 2f       	call   0x2f4a:0x416
    2ef8:	3c 21                	cmp    al,0x21
    2efa:	72 14                	jb     0x2f10
    2efc:	3c 24                	cmp    al,0x24
    2efe:	76 08                	jbe    0x2f08
    2f00:	3c 26                	cmp    al,0x26
    2f02:	74 04                	je     0x2f08
    2f04:	3c 28                	cmp    al,0x28
    2f06:	75 08                	jne    0x2f10
    2f08:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f0b:	31 c0                	xor    ax,ax
    2f0d:	26 89 05             	mov    WORD PTR es:[di],ax
    2f10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f13:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2f18:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2f1b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2f1e:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    2f22:	b0 00                	mov    al,0x0
    2f24:	74 01                	je     0x2f27
    2f26:	40                   	inc    ax
    2f27:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    2f2b:	08 c0                	or     al,al
    2f2d:	74 6e                	je     0x2f9d
    2f2f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f32:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2f35:	3d 27 00             	cmp    ax,0x27
    2f38:	75 1f                	jne    0x2f59
    2f3a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f3d:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2f41:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    2f45:	71 05                	jno    0x2f4c
    2f47:	9a 3e 04 6e 2f       	call   0x2f6e:0x43e
    2f4c:	50                   	push   ax
    2f4d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f50:	06                   	push   es
    2f51:	57                   	push   di
    2f52:	9a d0 1c 79 2f       	call   0x2f79:0x1cd0
    2f57:	eb 24                	jmp    0x2f7d
    2f59:	3d 25 00             	cmp    ax,0x25
    2f5c:	75 1f                	jne    0x2f7d
    2f5e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f61:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2f65:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    2f69:	71 05                	jno    0x2f70
    2f6b:	9a 3e 04 8b 2f       	call   0x2f8b:0x43e
    2f70:	50                   	push   ax
    2f71:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2f74:	06                   	push   es
    2f75:	57                   	push   di
    2f76:	9a d0 1c b8 2f       	call   0x2fb8:0x1cd0
    2f7b:	eb 00                	jmp    0x2f7d
    2f7d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f80:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2f83:	31 d2                	xor    dx,dx
    2f85:	bf ea 2d             	mov    di,0x2dea
    2f88:	9a 16 04 c6 2f       	call   0x2fc6:0x416
    2f8d:	3c 25                	cmp    al,0x25
    2f8f:	74 04                	je     0x2f95
    2f91:	3c 27                	cmp    al,0x27
    2f93:	75 08                	jne    0x2f9d
    2f95:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f98:	31 c0                	xor    ax,ax
    2f9a:	26 89 05             	mov    WORD PTR es:[di],ax
    2f9d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2fa0:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2fa4:	74 14                	je     0x2fba
    2fa6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa9:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    2fae:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    2fb3:	06                   	push   es
    2fb4:	57                   	push   di
    2fb5:	9a 30 22 e3 2f       	call   0x2fe3:0x2230
    2fba:	c9                   	leave
    2fbb:	ca 0e 00             	retf   0xe
    2fbe:	55                   	push   bp
    2fbf:	89 e5                	mov    bp,sp
    2fc1:	31 c0                	xor    ax,ax
    2fc3:	9a 44 04 f1 2f       	call   0x2ff1:0x444
    2fc8:	6a 01                	push   0x1
    2fca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fcd:	26 c4 bd b8 02       	les    di,DWORD PTR es:[di+0x2b8]
    2fd2:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    2fd6:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    2fda:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2fde:	06                   	push   es
    2fdf:	57                   	push   di
    2fe0:	9a b2 77 02 30       	call   0x3002:0x77b2
    2fe5:	c9                   	leave
    2fe6:	ca 08 00             	retf   0x8
    2fe9:	55                   	push   bp
    2fea:	89 e5                	mov    bp,sp
    2fec:	31 c0                	xor    ax,ax
    2fee:	9a 44 04 10 30       	call   0x3010:0x444
    2ff3:	6a 03                	push   0x3
    2ff5:	6a 00                	push   0x0
    2ff7:	6a 00                	push   0x0
    2ff9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2ffd:	06                   	push   es
    2ffe:	57                   	push   di
    2fff:	9a b2 77 23 30       	call   0x3023:0x77b2
    3004:	c9                   	leave
    3005:	ca 08 00             	retf   0x8
    3008:	55                   	push   bp
    3009:	89 e5                	mov    bp,sp
    300b:	31 c0                	xor    ax,ax
    300d:	9a 44 04 31 30       	call   0x3031:0x444
    3012:	68 05 01             	push   0x105
    3015:	bf 12 02             	mov    di,0x212
    3018:	1e                   	push   ds
    3019:	57                   	push   di
    301a:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    301e:	06                   	push   es
    301f:	57                   	push   di
    3020:	9a b2 77 42 30       	call   0x3042:0x77b2
    3025:	c9                   	leave
    3026:	ca 08 00             	retf   0x8
    3029:	55                   	push   bp
    302a:	89 e5                	mov    bp,sp
    302c:	31 c0                	xor    ax,ax
    302e:	9a 44 04 51 30       	call   0x3051:0x444
    3033:	6a 04                	push   0x4
    3035:	6a 00                	push   0x0
    3037:	6a 00                	push   0x0
    3039:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    303d:	06                   	push   es
    303e:	57                   	push   di
    303f:	9a b2 77 5f 30       	call   0x305f:0x77b2
    3044:	c9                   	leave
    3045:	ca 08 00             	retf   0x8
    3048:	55                   	push   bp
    3049:	89 e5                	mov    bp,sp
    304b:	b8 04 00             	mov    ax,0x4
    304e:	9a 44 04 6e 30       	call   0x306e:0x444
    3053:	83 ec 04             	sub    sp,0x4
    3056:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    305a:	06                   	push   es
    305b:	57                   	push   di
    305c:	9a 45 5d da 30       	call   0x30da:0x5d45
    3061:	c9                   	leave
    3062:	ca 08 00             	retf   0x8
    3065:	55                   	push   bp
    3066:	89 e5                	mov    bp,sp
    3068:	b8 04 00             	mov    ax,0x4
    306b:	9a 44 04 e9 30       	call   0x30e9:0x444
    3070:	83 ec 04             	sub    sp,0x4
    3073:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3076:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    307b:	b0 00                	mov    al,0x0
    307d:	75 01                	jne    0x3080
    307f:	40                   	inc    ax
    3080:	8a c8                	mov    cl,al
    3082:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    3088:	b0 00                	mov    al,0x0
    308a:	77 01                	ja     0x308d
    308c:	40                   	inc    ax
    308d:	8a d0                	mov    dl,al
    308f:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    3095:	b0 00                	mov    al,0x0
    3097:	76 01                	jbe    0x309a
    3099:	40                   	inc    ax
    309a:	22 c2                	and    al,dl
    309c:	0a c1                	or     al,cl
    309e:	08 c0                	or     al,al
    30a0:	74 3a                	je     0x30dc
    30a2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    30a6:	31 c0                	xor    ax,ax
    30a8:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    30ac:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    30b0:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    30b4:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    30b8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    30bb:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    30bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c2:	06                   	push   es
    30c3:	57                   	push   di
    30c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30c7:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    30cb:	6a 02                	push   0x2
    30cd:	6a 00                	push   0x0
    30cf:	6a 00                	push   0x0
    30d1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    30d5:	06                   	push   es
    30d6:	57                   	push   di
    30d7:	9a b2 77 69 31       	call   0x3169:0x77b2
    30dc:	c9                   	leave
    30dd:	ca 0c 00             	retf   0xc
    30e0:	55                   	push   bp
    30e1:	89 e5                	mov    bp,sp
    30e3:	b8 04 00             	mov    ax,0x4
    30e6:	9a 44 04 08 31       	call   0x3108:0x444
    30eb:	83 ec 04             	sub    sp,0x4
    30ee:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    30f2:	74 03                	je     0x30f7
    30f4:	e9 9c 00             	jmp    0x3193
    30f7:	ff 76 14             	push   WORD PTR [bp+0x14]
    30fa:	ff 76 12             	push   WORD PTR [bp+0x12]
    30fd:	bf c1 05             	mov    di,0x5c1
    3100:	b8 1b 31             	mov    ax,0x311b
    3103:	50                   	push   ax
    3104:	57                   	push   di
    3105:	9a 55 22 22 31       	call   0x3122:0x2255
    310a:	08 c0                	or     al,al
    310c:	75 03                	jne    0x3111
    310e:	e9 82 00             	jmp    0x3193
    3111:	ff 76 14             	push   WORD PTR [bp+0x14]
    3114:	ff 76 12             	push   WORD PTR [bp+0x12]
    3117:	bf c1 05             	mov    di,0x5c1
    311a:	b8 4a 31             	mov    ax,0x314a
    311d:	50                   	push   ax
    311e:	57                   	push   di
    311f:	9a 73 22 51 31       	call   0x3151:0x2273
    3124:	89 c7                	mov    di,ax
    3126:	8e c2                	mov    es,dx
    3128:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    312d:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    3132:	74 5f                	je     0x3193
    3134:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3138:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    313b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    313e:	6a 08                	push   0x8
    3140:	ff 76 14             	push   WORD PTR [bp+0x14]
    3143:	ff 76 12             	push   WORD PTR [bp+0x12]
    3146:	bf c1 05             	mov    di,0x5c1
    3149:	b8 b5 31             	mov    ax,0x31b5
    314c:	50                   	push   ax
    314d:	57                   	push   di
    314e:	9a 73 22 a0 31       	call   0x31a0:0x2273
    3153:	89 c7                	mov    di,ax
    3155:	8e c2                	mov    es,dx
    3157:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    315c:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    3161:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3164:	06                   	push   es
    3165:	57                   	push   di
    3166:	9a b2 77 73 31       	call   0x3173:0x77b2
    316b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    316e:	06                   	push   es
    316f:	57                   	push   di
    3170:	9a 03 73 fa 31       	call   0x31fa:0x7303
    3175:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3178:	06                   	push   es
    3179:	57                   	push   di
    317a:	b8 65 30             	mov    ax,0x3065
    317d:	ba 25 32             	mov    dx,0x3225
    3180:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3183:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    3187:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    318b:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    318f:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    3193:	c9                   	leave
    3194:	ca 10 00             	retf   0x10
    3197:	55                   	push   bp
    3198:	89 e5                	mov    bp,sp
    319a:	b8 04 00             	mov    ax,0x4
    319d:	9a 44 04 bc 31       	call   0x31bc:0x444
    31a2:	83 ec 04             	sub    sp,0x4
    31a5:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    31a9:	75 51                	jne    0x31fc
    31ab:	ff 76 14             	push   WORD PTR [bp+0x14]
    31ae:	ff 76 12             	push   WORD PTR [bp+0x12]
    31b1:	bf c1 05             	mov    di,0x5c1
    31b4:	b8 cc 31             	mov    ax,0x31cc
    31b7:	50                   	push   ax
    31b8:	57                   	push   di
    31b9:	9a 55 22 d3 31       	call   0x31d3:0x2255
    31be:	08 c0                	or     al,al
    31c0:	74 3a                	je     0x31fc
    31c2:	ff 76 14             	push   WORD PTR [bp+0x14]
    31c5:	ff 76 12             	push   WORD PTR [bp+0x12]
    31c8:	bf c1 05             	mov    di,0x5c1
    31cb:	b8 f1 34             	mov    ax,0x34f1
    31ce:	50                   	push   ax
    31cf:	57                   	push   di
    31d0:	9a 73 22 08 32       	call   0x3208:0x2273
    31d5:	89 c7                	mov    di,ax
    31d7:	8e c2                	mov    es,dx
    31d9:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    31de:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    31e3:	74 17                	je     0x31fc
    31e5:	6a 08                	push   0x8
    31e7:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    31ec:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    31f1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    31f5:	06                   	push   es
    31f6:	57                   	push   di
    31f7:	9a b2 77 1c 45       	call   0x451c:0x77b2
    31fc:	c9                   	leave
    31fd:	ca 10 00             	retf   0x10
    3200:	55                   	push   bp
    3201:	89 e5                	mov    bp,sp
    3203:	31 c0                	xor    ax,ax
    3205:	9a 44 04 3c 32       	call   0x323c:0x444
    320a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    320d:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3212:	06                   	push   es
    3213:	57                   	push   di
    3214:	9a 17 2f ff ff       	call   0xffff:0x2f17
    3219:	08 c0                	or     al,al
    321b:	74 0a                	je     0x3227
    321d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3220:	06                   	push   es
    3221:	57                   	push   di
    3222:	9a 96 32 94 32       	call   0x3294:0x3296
    3227:	c9                   	leave
    3228:	ca 08 00             	retf   0x8
    322b:	00 00                	add    BYTE PTR [bx+si],al
    322d:	00 00                	add    BYTE PTR [bx+si],al
    322f:	ff                   	(bad)
    3230:	ff 00                	inc    WORD PTR [bx+si]
    3232:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3235:	e5 b8                	in     ax,0xb8
    3237:	26 00 9a 44 04       	add    BYTE PTR es:[bp+si+0x444],bl
    323c:	73 32                	jae    0x3270
    323e:	83 ec 26             	sub    sp,0x26
    3241:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3245:	06                   	push   es
    3246:	57                   	push   di
    3247:	9a 04 2a ba 32       	call   0x32ba:0x2a04
    324c:	89 c7                	mov    di,ax
    324e:	8e c2                	mov    es,dx
    3250:	06                   	push   es
    3251:	57                   	push   di
    3252:	9a d2 21 0b 33       	call   0x330b:0x21d2
    3257:	50                   	push   ax
    3258:	bf 14 02             	mov    di,0x214
    325b:	1e                   	push   ds
    325c:	57                   	push   di
    325d:	6a 01                	push   0x1
    325f:	8d 7e da             	lea    di,[bp-0x26]
    3262:	16                   	push   ss
    3263:	57                   	push   di
    3264:	9a ff ff 00 00       	call   0x0:0xffff
    3269:	8b 46 dc             	mov    ax,WORD PTR [bp-0x24]
    326c:	99                   	cwd
    326d:	bf 2b 32             	mov    di,0x322b
    3270:	9a 16 04 9f 32       	call   0x329f:0x416
    3275:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3278:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    327b:	c9                   	leave
    327c:	ca 02 00             	retf   0x2
    327f:	00 01                	add    BYTE PTR [bx+di],al
    3281:	09 01                	or     WORD PTR [bx+di],ax
    3283:	20 03                	and    BYTE PTR [bp+di],al
    3285:	20 20                	and    BYTE PTR [bx+si],ah
    3287:	20 00                	and    BYTE PTR [bx+si],al
    3289:	80 ff ff             	cmp    bh,0xff
    328c:	ff                   	(bad)
    328d:	7f 00                	jg     0x328f
    328f:	00 00                	add    BYTE PTR [bx+si],al
    3291:	00 ce                	add    dh,cl
    3293:	36 af                	ss scas ax,WORD PTR es:[di]
    3295:	32 55 89             	xor    dl,BYTE PTR [di-0x77]
    3298:	e5 b8                	in     ax,0xb8
    329a:	0e                   	push   cs
    329b:	04 9a                	add    al,0x9a
    329d:	44                   	inc    sp
    329e:	04 c5                	add    al,0xc5
    32a0:	32 81 ec 0e          	xor    al,BYTE PTR [bx+di+0xeec]
    32a4:	04 6a                	add    al,0x6a
    32a6:	01 c4                	add    sp,ax
    32a8:	7e 06                	jle    0x32b0
    32aa:	06                   	push   es
    32ab:	57                   	push   di
    32ac:	9a 3a 3a b4 34       	call   0x34b4:0x3a3a
    32b1:	8d be fc fe          	lea    di,[bp-0x104]
    32b5:	16                   	push   ss
    32b6:	57                   	push   di
    32b7:	9a 4e 20 e3 32       	call   0x32e3:0x204e
    32bc:	8d be fc fe          	lea    di,[bp-0x104]
    32c0:	16                   	push   ss
    32c1:	57                   	push   di
    32c2:	9a f5 09 ca 32       	call   0x32ca:0x9f5
    32c7:	9a 08 04 5f 33       	call   0x335f:0x408
    32cc:	b8 90 32             	mov    ax,0x3290
    32cf:	0e                   	push   cs
    32d0:	50                   	push   ax
    32d1:	55                   	push   bp
    32d2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    32d6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    32da:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    32de:	06                   	push   es
    32df:	57                   	push   di
    32e0:	9a 04 2a 18 33       	call   0x3318:0x2a04
    32e5:	89 c7                	mov    di,ax
    32e7:	8e c2                	mov    es,dx
    32e9:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    32ed:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    32f1:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    32f5:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    32fa:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    32fe:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3302:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3306:	06                   	push   es
    3307:	57                   	push   di
    3308:	9a 99 20 27 33       	call   0x3327:0x2099
    330d:	6a 0a                	push   0xa
    330f:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3313:	06                   	push   es
    3314:	57                   	push   di
    3315:	9a 04 2a 34 33       	call   0x3334:0x2a04
    331a:	89 c7                	mov    di,ax
    331c:	8e c2                	mov    es,dx
    331e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3322:	06                   	push   es
    3323:	57                   	push   di
    3324:	9a f5 11 43 33       	call   0x3343:0x11f5
    3329:	6a 02                	push   0x2
    332b:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    332f:	06                   	push   es
    3330:	57                   	push   di
    3331:	9a 04 2a 83 34       	call   0x3483:0x2a04
    3336:	89 c7                	mov    di,ax
    3338:	8e c2                	mov    es,dx
    333a:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    333e:	06                   	push   es
    333f:	57                   	push   di
    3340:	9a 78 12 92 34       	call   0x3492:0x1278
    3345:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    334a:	eb 03                	jmp    0x334f
    334c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    334f:	8d be fc fe          	lea    di,[bp-0x104]
    3353:	16                   	push   ss
    3354:	57                   	push   di
    3355:	bf 7f 32             	mov    di,0x327f
    3358:	0e                   	push   cs
    3359:	57                   	push   di
    335a:	6a 00                	push   0x0
    335c:	9a b5 0d 64 33       	call   0x3364:0xdb5
    3361:	9a 78 0c 69 33       	call   0x3369:0xc78
    3366:	9a 08 04 97 33       	call   0x3397:0x408
    336b:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    336f:	75 db                	jne    0x334c
    3371:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3374:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    3379:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    337d:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    3381:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3386:	06                   	push   es
    3387:	57                   	push   di
    3388:	26 c4 3d             	les    di,DWORD PTR es:[di]
    338b:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    338f:	2d 01 00             	sub    ax,0x1
    3392:	71 05                	jno    0x3399
    3394:	9a 3e 04 d7 33       	call   0x33d7:0x43e
    3399:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    339d:	31 c0                	xor    ax,ax
    339f:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    33a3:	7e 03                	jle    0x33a8
    33a5:	e9 c8 00             	jmp    0x3470
    33a8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    33ab:	eb 03                	jmp    0x33b0
    33ad:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    33b0:	8d be f0 fc          	lea    di,[bp-0x310]
    33b4:	16                   	push   ss
    33b5:	57                   	push   di
    33b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    33b9:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    33bd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    33c2:	06                   	push   es
    33c3:	57                   	push   di
    33c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33c7:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    33cb:	8d be fc fd          	lea    di,[bp-0x204]
    33cf:	16                   	push   ss
    33d0:	57                   	push   di
    33d1:	68 ff 00             	push   0xff
    33d4:	9a e7 17 e7 33       	call   0x33e7:0x17e7
    33d9:	bf 80 32             	mov    di,0x3280
    33dc:	0e                   	push   cs
    33dd:	57                   	push   di
    33de:	8d be fc fd          	lea    di,[bp-0x204]
    33e2:	16                   	push   ss
    33e3:	57                   	push   di
    33e4:	9a 78 18 00 34       	call   0x3400:0x1878
    33e9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    33ec:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    33f0:	7e 26                	jle    0x3418
    33f2:	8d be fc fd          	lea    di,[bp-0x204]
    33f6:	16                   	push   ss
    33f7:	57                   	push   di
    33f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    33fb:	6a 01                	push   0x1
    33fd:	9a 75 19 16 34       	call   0x3416:0x1975
    3402:	bf 82 32             	mov    di,0x3282
    3405:	0e                   	push   cs
    3406:	57                   	push   di
    3407:	8d be fc fd          	lea    di,[bp-0x204]
    340b:	16                   	push   ss
    340c:	57                   	push   di
    340d:	68 ff 00             	push   0xff
    3410:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3413:	9a 16 19 2c 34       	call   0x342c:0x1916
    3418:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    341c:	75 bb                	jne    0x33d9
    341e:	8d be f0 fc          	lea    di,[bp-0x310]
    3422:	16                   	push   ss
    3423:	57                   	push   di
    3424:	bf 84 32             	mov    di,0x3284
    3427:	0e                   	push   cs
    3428:	57                   	push   di
    3429:	9a cd 17 37 34       	call   0x3437:0x17cd
    342e:	8d be fc fd          	lea    di,[bp-0x204]
    3432:	16                   	push   ss
    3433:	57                   	push   di
    3434:	9a 4c 18 45 34       	call   0x3445:0x184c
    3439:	8d be fc fd          	lea    di,[bp-0x204]
    343d:	16                   	push   ss
    343e:	57                   	push   di
    343f:	68 ff 00             	push   0xff
    3442:	9a e7 17 58 34       	call   0x3458:0x17e7
    3447:	8d be fc fe          	lea    di,[bp-0x104]
    344b:	16                   	push   ss
    344c:	57                   	push   di
    344d:	8d be fc fd          	lea    di,[bp-0x204]
    3451:	16                   	push   ss
    3452:	57                   	push   di
    3453:	6a 00                	push   0x0
    3455:	9a b5 0d 5d 34       	call   0x345d:0xdb5
    345a:	9a 78 0c 62 34       	call   0x3462:0xc78
    345f:	9a 08 04 be 34       	call   0x34be:0x408
    3464:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3467:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    346b:	74 03                	je     0x3470
    346d:	e9 3d ff             	jmp    0x33ad
    3470:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3474:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    3478:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    347c:	6a 06                	push   0x6
    347e:	06                   	push   es
    347f:	57                   	push   di
    3480:	9a 04 2a 9f 34       	call   0x349f:0x2a04
    3485:	89 c7                	mov    di,ax
    3487:	8e c2                	mov    es,dx
    3489:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    348d:	06                   	push   es
    348e:	57                   	push   di
    348f:	9a f5 11 ae 34       	call   0x34ae:0x11f5
    3494:	6a 00                	push   0x0
    3496:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    349a:	06                   	push   es
    349b:	57                   	push   di
    349c:	9a 04 2a 22 35       	call   0x3522:0x2a04
    34a1:	89 c7                	mov    di,ax
    34a3:	8e c2                	mov    es,dx
    34a5:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    34a9:	06                   	push   es
    34aa:	57                   	push   di
    34ab:	9a 78 12 49 35       	call   0x3549:0x1278
    34b0:	55                   	push   bp
    34b1:	9a 33 32 0a 37       	call   0x370a:0x3233
    34b6:	05 02 00             	add    ax,0x2
    34b9:	73 05                	jae    0x34c0
    34bb:	9a 3e 04 c8 34       	call   0x34c8:0x43e
    34c0:	31 d2                	xor    dx,dx
    34c2:	bf 88 32             	mov    di,0x3288
    34c5:	9a 16 04 dc 34       	call   0x34dc:0x416
    34ca:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    34ce:	8d be f2 fb          	lea    di,[bp-0x40e]
    34d2:	16                   	push   ss
    34d3:	57                   	push   di
    34d4:	bf 84 32             	mov    di,0x3284
    34d7:	0e                   	push   cs
    34d8:	57                   	push   di
    34d9:	9a cd 17 f6 34       	call   0x34f6:0x17cd
    34de:	8d be f2 fc          	lea    di,[bp-0x30e]
    34e2:	16                   	push   ss
    34e3:	57                   	push   di
    34e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34e7:	26 c4 bd 7c 03       	les    di,DWORD PTR es:[di+0x37c]
    34ec:	06                   	push   es
    34ed:	57                   	push   di
    34ee:	9a 53 1d 6e 35       	call   0x356e:0x1d53
    34f3:	9a 4c 18 04 35       	call   0x3504:0x184c
    34f8:	8d be fc fd          	lea    di,[bp-0x204]
    34fc:	16                   	push   ss
    34fd:	57                   	push   di
    34fe:	68 ff 00             	push   0xff
    3501:	9a e7 17 16 35       	call   0x3516:0x17e7
    3506:	6a 00                	push   0x0
    3508:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    350c:	b9 05 00             	mov    cx,0x5
    350f:	f7 e9                	imul   cx
    3511:	71 05                	jno    0x3518
    3513:	9a 3e 04 2c 35       	call   0x352c:0x43e
    3518:	50                   	push   ax
    3519:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    351d:	06                   	push   es
    351e:	57                   	push   di
    351f:	9a 72 2a 3e 35       	call   0x353e:0x2a72
    3524:	5a                   	pop    dx
    3525:	2b c2                	sub    ax,dx
    3527:	71 05                	jno    0x352e
    3529:	9a 3e 04 59 35       	call   0x3559:0x43e
    352e:	50                   	push   ax
    352f:	8d be fc fd          	lea    di,[bp-0x204]
    3533:	16                   	push   ss
    3534:	57                   	push   di
    3535:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3539:	06                   	push   es
    353a:	57                   	push   di
    353b:	9a 04 2a 9f 35       	call   0x359f:0x2a04
    3540:	89 c7                	mov    di,ax
    3542:	8e c2                	mov    es,dx
    3544:	06                   	push   es
    3545:	57                   	push   di
    3546:	9a 09 1f c6 35       	call   0x35c6:0x1f09
    354b:	8d be f2 fb          	lea    di,[bp-0x40e]
    354f:	16                   	push   ss
    3550:	57                   	push   di
    3551:	bf 84 32             	mov    di,0x3284
    3554:	0e                   	push   cs
    3555:	57                   	push   di
    3556:	9a cd 17 73 35       	call   0x3573:0x17cd
    355b:	8d be f2 fc          	lea    di,[bp-0x30e]
    355f:	16                   	push   ss
    3560:	57                   	push   di
    3561:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3564:	26 c4 bd 80 03       	les    di,DWORD PTR es:[di+0x380]
    3569:	06                   	push   es
    356a:	57                   	push   di
    356b:	9a 53 1d eb 35       	call   0x35eb:0x1d53
    3570:	9a 4c 18 81 35       	call   0x3581:0x184c
    3575:	8d be fc fd          	lea    di,[bp-0x204]
    3579:	16                   	push   ss
    357a:	57                   	push   di
    357b:	68 ff 00             	push   0xff
    357e:	9a e7 17 93 35       	call   0x3593:0x17e7
    3583:	6a 00                	push   0x0
    3585:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3589:	b9 04 00             	mov    cx,0x4
    358c:	f7 e9                	imul   cx
    358e:	71 05                	jno    0x3595
    3590:	9a 3e 04 a9 35       	call   0x35a9:0x43e
    3595:	50                   	push   ax
    3596:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    359a:	06                   	push   es
    359b:	57                   	push   di
    359c:	9a 72 2a bb 35       	call   0x35bb:0x2a72
    35a1:	5a                   	pop    dx
    35a2:	2b c2                	sub    ax,dx
    35a4:	71 05                	jno    0x35ab
    35a6:	9a 3e 04 d6 35       	call   0x35d6:0x43e
    35ab:	50                   	push   ax
    35ac:	8d be fc fd          	lea    di,[bp-0x204]
    35b0:	16                   	push   ss
    35b1:	57                   	push   di
    35b2:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    35b6:	06                   	push   es
    35b7:	57                   	push   di
    35b8:	9a 04 2a 1c 36       	call   0x361c:0x2a04
    35bd:	89 c7                	mov    di,ax
    35bf:	8e c2                	mov    es,dx
    35c1:	06                   	push   es
    35c2:	57                   	push   di
    35c3:	9a 09 1f 43 36       	call   0x3643:0x1f09
    35c8:	8d be f2 fb          	lea    di,[bp-0x40e]
    35cc:	16                   	push   ss
    35cd:	57                   	push   di
    35ce:	bf 84 32             	mov    di,0x3284
    35d1:	0e                   	push   cs
    35d2:	57                   	push   di
    35d3:	9a cd 17 f0 35       	call   0x35f0:0x17cd
    35d8:	8d be f2 fc          	lea    di,[bp-0x30e]
    35dc:	16                   	push   ss
    35dd:	57                   	push   di
    35de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35e1:	26 c4 bd 84 03       	les    di,DWORD PTR es:[di+0x384]
    35e6:	06                   	push   es
    35e7:	57                   	push   di
    35e8:	9a 53 1d 68 36       	call   0x3668:0x1d53
    35ed:	9a 4c 18 fe 35       	call   0x35fe:0x184c
    35f2:	8d be fc fd          	lea    di,[bp-0x204]
    35f6:	16                   	push   ss
    35f7:	57                   	push   di
    35f8:	68 ff 00             	push   0xff
    35fb:	9a e7 17 10 36       	call   0x3610:0x17e7
    3600:	6a 00                	push   0x0
    3602:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3606:	b9 03 00             	mov    cx,0x3
    3609:	f7 e9                	imul   cx
    360b:	71 05                	jno    0x3612
    360d:	9a 3e 04 26 36       	call   0x3626:0x43e
    3612:	50                   	push   ax
    3613:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3617:	06                   	push   es
    3618:	57                   	push   di
    3619:	9a 72 2a 38 36       	call   0x3638:0x2a72
    361e:	5a                   	pop    dx
    361f:	2b c2                	sub    ax,dx
    3621:	71 05                	jno    0x3628
    3623:	9a 3e 04 53 36       	call   0x3653:0x43e
    3628:	50                   	push   ax
    3629:	8d be fc fd          	lea    di,[bp-0x204]
    362d:	16                   	push   ss
    362e:	57                   	push   di
    362f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3633:	06                   	push   es
    3634:	57                   	push   di
    3635:	9a 04 2a 99 36       	call   0x3699:0x2a04
    363a:	89 c7                	mov    di,ax
    363c:	8e c2                	mov    es,dx
    363e:	06                   	push   es
    363f:	57                   	push   di
    3640:	9a 09 1f c0 36       	call   0x36c0:0x1f09
    3645:	8d be f2 fb          	lea    di,[bp-0x40e]
    3649:	16                   	push   ss
    364a:	57                   	push   di
    364b:	bf 84 32             	mov    di,0x3284
    364e:	0e                   	push   cs
    364f:	57                   	push   di
    3650:	9a cd 17 6d 36       	call   0x366d:0x17cd
    3655:	8d be f2 fc          	lea    di,[bp-0x30e]
    3659:	16                   	push   ss
    365a:	57                   	push   di
    365b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    365e:	26 c4 bd 88 03       	les    di,DWORD PTR es:[di+0x388]
    3663:	06                   	push   es
    3664:	57                   	push   di
    3665:	9a 53 1d 2a 38       	call   0x382a:0x1d53
    366a:	9a 4c 18 7b 36       	call   0x367b:0x184c
    366f:	8d be fc fd          	lea    di,[bp-0x204]
    3673:	16                   	push   ss
    3674:	57                   	push   di
    3675:	68 ff 00             	push   0xff
    3678:	9a e7 17 8d 36       	call   0x368d:0x17e7
    367d:	6a 00                	push   0x0
    367f:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3683:	b9 02 00             	mov    cx,0x2
    3686:	f7 e9                	imul   cx
    3688:	71 05                	jno    0x368f
    368a:	9a 3e 04 a3 36       	call   0x36a3:0x43e
    368f:	50                   	push   ax
    3690:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    3694:	06                   	push   es
    3695:	57                   	push   di
    3696:	9a 72 2a b5 36       	call   0x36b5:0x2a72
    369b:	5a                   	pop    dx
    369c:	2b c2                	sub    ax,dx
    369e:	71 05                	jno    0x36a5
    36a0:	9a 3e 04 d7 36       	call   0x36d7:0x43e
    36a5:	50                   	push   ax
    36a6:	8d be fc fd          	lea    di,[bp-0x204]
    36aa:	16                   	push   ss
    36ab:	57                   	push   di
    36ac:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    36b0:	06                   	push   es
    36b1:	57                   	push   di
    36b2:	9a 04 2a ff ff       	call   0xffff:0x2a04
    36b7:	89 c7                	mov    di,ax
    36b9:	8e c2                	mov    es,dx
    36bb:	06                   	push   es
    36bc:	57                   	push   di
    36bd:	9a 09 1f ff ff       	call   0xffff:0x1f09
    36c2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    36c6:	83 c4 06             	add    sp,0x6
    36c9:	b8 ee 36             	mov    ax,0x36ee
    36cc:	0e                   	push   cs
    36cd:	50                   	push   ax
    36ce:	8d be fc fe          	lea    di,[bp-0x104]
    36d2:	16                   	push   ss
    36d3:	57                   	push   di
    36d4:	9a 4f 0a dc 36       	call   0x36dc:0xa4f
    36d9:	9a 08 04 fb 36       	call   0x36fb:0x408
    36de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36e1:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    36e6:	06                   	push   es
    36e7:	57                   	push   di
    36e8:	9a e3 49 1f 37       	call   0x371f:0x49e3
    36ed:	cb                   	retf
    36ee:	c9                   	leave
    36ef:	ca 04 00             	retf   0x4
    36f2:	55                   	push   bp
    36f3:	89 e5                	mov    bp,sp
    36f5:	b8 04 00             	mov    ax,0x4
    36f8:	9a 44 04 46 37       	call   0x3746:0x444
    36fd:	83 ec 04             	sub    sp,0x4
    3700:	6a 00                	push   0x0
    3702:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3705:	06                   	push   es
    3706:	57                   	push   di
    3707:	9a 3a 3a 81 3a       	call   0x3a81:0x3a3a
    370c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    370f:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    3714:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3717:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    371a:	06                   	push   es
    371b:	57                   	push   di
    371c:	9a 3f 4a 29 37       	call   0x3729:0x4a3f
    3721:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3724:	06                   	push   es
    3725:	57                   	push   di
    3726:	9a ff 49 33 37       	call   0x3733:0x49ff
    372b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    372e:	06                   	push   es
    372f:	57                   	push   di
    3730:	9a e3 49 ef 37       	call   0x37ef:0x49e3
    3735:	c9                   	leave
    3736:	ca 08 00             	retf   0x8
    3739:	01 09                	add    WORD PTR [bx+di],cx
    373b:	01 20                	add    WORD PTR [bx+si],sp
    373d:	55                   	push   bp
    373e:	89 e5                	mov    bp,sp
    3740:	b8 06 02             	mov    ax,0x206
    3743:	9a 44 04 81 37       	call   0x3781:0x444
    3748:	81 ec 06 02          	sub    sp,0x206
    374c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    374f:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3754:	75 03                	jne    0x3759
    3756:	e9 d8 02             	jmp    0x3a31
    3759:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    375e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3761:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    3765:	3d 00 00             	cmp    ax,0x0
    3768:	75 32                	jne    0x379c
    376a:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    376d:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    3771:	76 27                	jbe    0x379a
    3773:	8d be fe fd          	lea    di,[bp-0x202]
    3777:	16                   	push   ss
    3778:	57                   	push   di
    3779:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    377c:	06                   	push   es
    377d:	57                   	push   di
    377e:	9a cd 17 8b 37       	call   0x378b:0x17cd
    3783:	bf 39 37             	mov    di,0x3739
    3786:	0e                   	push   cs
    3787:	57                   	push   di
    3788:	9a 4c 18 98 37       	call   0x3798:0x184c
    378d:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    3790:	06                   	push   es
    3791:	57                   	push   di
    3792:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3795:	9a e7 17 c8 37       	call   0x37c8:0x17e7
    379a:	eb 49                	jmp    0x37e5
    379c:	3d 01 00             	cmp    ax,0x1
    379f:	75 44                	jne    0x37e5
    37a1:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    37a4:	26 8a 05             	mov    al,BYTE PTR es:[di]
    37a7:	30 e4                	xor    ah,ah
    37a9:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    37ad:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    37b1:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    37b4:	7d 2d                	jge    0x37e3
    37b6:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    37ba:	8d be fe fd          	lea    di,[bp-0x202]
    37be:	16                   	push   ss
    37bf:	57                   	push   di
    37c0:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    37c3:	06                   	push   es
    37c4:	57                   	push   di
    37c5:	9a cd 17 d2 37       	call   0x37d2:0x17cd
    37ca:	bf 3b 37             	mov    di,0x373b
    37cd:	0e                   	push   cs
    37ce:	57                   	push   di
    37cf:	9a 4c 18 df 37       	call   0x37df:0x184c
    37d4:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    37d7:	06                   	push   es
    37d8:	57                   	push   di
    37d9:	ff 76 0e             	push   WORD PTR [bp+0xe]
    37dc:	9a e7 17 f6 37       	call   0x37f6:0x17e7
    37e1:	eb ca                	jmp    0x37ad
    37e3:	eb 00                	jmp    0x37e5
    37e5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37e8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37eb:	bf 0c 01             	mov    di,0x10c
    37ee:	b8 06 38             	mov    ax,0x3806
    37f1:	50                   	push   ax
    37f2:	57                   	push   di
    37f3:	9a 55 22 0d 38       	call   0x380d:0x2255
    37f8:	08 c0                	or     al,al
    37fa:	74 6b                	je     0x3867
    37fc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37ff:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3802:	bf 0c 01             	mov    di,0x10c
    3805:	b8 f3 38             	mov    ax,0x38f3
    3808:	50                   	push   ax
    3809:	57                   	push   di
    380a:	9a 73 22 38 38       	call   0x3838:0x2273
    380f:	89 c7                	mov    di,ax
    3811:	8e c2                	mov    es,dx
    3813:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3817:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    381b:	8d be fa fd          	lea    di,[bp-0x206]
    381f:	16                   	push   ss
    3820:	57                   	push   di
    3821:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3825:	06                   	push   es
    3826:	57                   	push   di
    3827:	9a 53 1d ac 38       	call   0x38ac:0x1d53
    382c:	8d be 00 ff          	lea    di,[bp-0x100]
    3830:	16                   	push   ss
    3831:	57                   	push   di
    3832:	68 ff 00             	push   0xff
    3835:	9a e7 17 63 38       	call   0x3863:0x17e7
    383a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    383f:	b0 00                	mov    al,0x0
    3841:	76 01                	jbe    0x3844
    3843:	40                   	inc    ax
    3844:	8a d0                	mov    dl,al
    3846:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    384b:	b0 00                	mov    al,0x0
    384d:	75 01                	jne    0x3850
    384f:	40                   	inc    ax
    3850:	22 c2                	and    al,dl
    3852:	08 c0                	or     al,al
    3854:	74 11                	je     0x3867
    3856:	8d be 00 ff          	lea    di,[bp-0x100]
    385a:	16                   	push   ss
    385b:	57                   	push   di
    385c:	6a 01                	push   0x1
    385e:	6a 01                	push   0x1
    3860:	9a 75 19 78 38       	call   0x3878:0x1975
    3865:	eb d3                	jmp    0x383a
    3867:	ff 76 0c             	push   WORD PTR [bp+0xc]
    386a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    386d:	bf ad 0d             	mov    di,0xdad
    3870:	b8 88 38             	mov    ax,0x3888
    3873:	50                   	push   ax
    3874:	57                   	push   di
    3875:	9a 55 22 8f 38       	call   0x388f:0x2255
    387a:	08 c0                	or     al,al
    387c:	74 6b                	je     0x38e9
    387e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3881:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3884:	bf ad 0d             	mov    di,0xdad
    3887:	b8 ff ff             	mov    ax,0xffff
    388a:	50                   	push   ax
    388b:	57                   	push   di
    388c:	9a 73 22 ba 38       	call   0x38ba:0x2273
    3891:	89 c7                	mov    di,ax
    3893:	8e c2                	mov    es,dx
    3895:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3899:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    389d:	8d be fa fd          	lea    di,[bp-0x206]
    38a1:	16                   	push   ss
    38a2:	57                   	push   di
    38a3:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    38a7:	06                   	push   es
    38a8:	57                   	push   di
    38a9:	9a 53 1d 2e 39       	call   0x392e:0x1d53
    38ae:	8d be 00 ff          	lea    di,[bp-0x100]
    38b2:	16                   	push   ss
    38b3:	57                   	push   di
    38b4:	68 ff 00             	push   0xff
    38b7:	9a e7 17 e5 38       	call   0x38e5:0x17e7
    38bc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    38c1:	b0 00                	mov    al,0x0
    38c3:	76 01                	jbe    0x38c6
    38c5:	40                   	inc    ax
    38c6:	8a d0                	mov    dl,al
    38c8:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    38cd:	b0 00                	mov    al,0x0
    38cf:	75 01                	jne    0x38d2
    38d1:	40                   	inc    ax
    38d2:	22 c2                	and    al,dl
    38d4:	08 c0                	or     al,al
    38d6:	74 11                	je     0x38e9
    38d8:	8d be 00 ff          	lea    di,[bp-0x100]
    38dc:	16                   	push   ss
    38dd:	57                   	push   di
    38de:	6a 01                	push   0x1
    38e0:	6a 01                	push   0x1
    38e2:	9a 75 19 fa 38       	call   0x38fa:0x1975
    38e7:	eb d3                	jmp    0x38bc
    38e9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    38ec:	ff 76 0a             	push   WORD PTR [bp+0xa]
    38ef:	bf 17 06             	mov    di,0x617
    38f2:	b8 0a 39             	mov    ax,0x390a
    38f5:	50                   	push   ax
    38f6:	57                   	push   di
    38f7:	9a 55 22 11 39       	call   0x3911:0x2255
    38fc:	08 c0                	or     al,al
    38fe:	74 6b                	je     0x396b
    3900:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3903:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3906:	bf 17 06             	mov    di,0x617
    3909:	b8 5e 3a             	mov    ax,0x3a5e
    390c:	50                   	push   ax
    390d:	57                   	push   di
    390e:	9a 73 22 3c 39       	call   0x393c:0x2273
    3913:	89 c7                	mov    di,ax
    3915:	8e c2                	mov    es,dx
    3917:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    391b:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    391f:	8d be fa fd          	lea    di,[bp-0x206]
    3923:	16                   	push   ss
    3924:	57                   	push   di
    3925:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3929:	06                   	push   es
    392a:	57                   	push   di
    392b:	9a 53 1d b1 3a       	call   0x3ab1:0x1d53
    3930:	8d be 00 ff          	lea    di,[bp-0x100]
    3934:	16                   	push   ss
    3935:	57                   	push   di
    3936:	68 ff 00             	push   0xff
    3939:	9a e7 17 67 39       	call   0x3967:0x17e7
    393e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3943:	b0 00                	mov    al,0x0
    3945:	76 01                	jbe    0x3948
    3947:	40                   	inc    ax
    3948:	8a d0                	mov    dl,al
    394a:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    394f:	b0 00                	mov    al,0x0
    3951:	75 01                	jne    0x3954
    3953:	40                   	inc    ax
    3954:	22 c2                	and    al,dl
    3956:	08 c0                	or     al,al
    3958:	74 11                	je     0x396b
    395a:	8d be 00 ff          	lea    di,[bp-0x100]
    395e:	16                   	push   ss
    395f:	57                   	push   di
    3960:	6a 01                	push   0x1
    3962:	6a 01                	push   0x1
    3964:	9a 75 19 7c 39       	call   0x397c:0x1975
    3969:	eb d3                	jmp    0x393e
    396b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    396e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3971:	bf 22 00             	mov    di,0x22
    3974:	b8 8f 39             	mov    ax,0x398f
    3977:	50                   	push   ax
    3978:	57                   	push   di
    3979:	9a 55 22 96 39       	call   0x3996:0x2255
    397e:	08 c0                	or     al,al
    3980:	75 03                	jne    0x3985
    3982:	e9 84 00             	jmp    0x3a09
    3985:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3988:	ff 76 0a             	push   WORD PTR [bp+0xa]
    398b:	bf 22 00             	mov    di,0x22
    398e:	b8 ff ff             	mov    ax,0xffff
    3991:	50                   	push   ax
    3992:	57                   	push   di
    3993:	9a 73 22 c1 39       	call   0x39c1:0x2273
    3998:	89 c7                	mov    di,ax
    399a:	8e c2                	mov    es,dx
    399c:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    39a0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    39a4:	8d be fa fd          	lea    di,[bp-0x206]
    39a8:	16                   	push   ss
    39a9:	57                   	push   di
    39aa:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    39ae:	06                   	push   es
    39af:	57                   	push   di
    39b0:	9a 24 15 ff ff       	call   0xffff:0x1524
    39b5:	8d be 00 ff          	lea    di,[bp-0x100]
    39b9:	16                   	push   ss
    39ba:	57                   	push   di
    39bb:	68 ff 00             	push   0xff
    39be:	9a e7 17 ec 39       	call   0x39ec:0x17e7
    39c3:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    39c7:	7e 40                	jle    0x3a09
    39c9:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    39cd:	30 e4                	xor    ah,ah
    39cf:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    39d3:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    39d8:	7d 2f                	jge    0x3a09
    39da:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    39de:	8d be fa fd          	lea    di,[bp-0x206]
    39e2:	16                   	push   ss
    39e3:	57                   	push   di
    39e4:	bf 3b 37             	mov    di,0x373b
    39e7:	0e                   	push   cs
    39e8:	57                   	push   di
    39e9:	9a cd 17 f7 39       	call   0x39f7:0x17cd
    39ee:	8d be 00 ff          	lea    di,[bp-0x100]
    39f2:	16                   	push   ss
    39f3:	57                   	push   di
    39f4:	9a 4c 18 05 3a       	call   0x3a05:0x184c
    39f9:	8d be 00 ff          	lea    di,[bp-0x100]
    39fd:	16                   	push   ss
    39fe:	57                   	push   di
    39ff:	68 ff 00             	push   0xff
    3a02:	9a e7 17 17 3a       	call   0x3a17:0x17e7
    3a07:	eb ca                	jmp    0x39d3
    3a09:	8d be fe fd          	lea    di,[bp-0x202]
    3a0d:	16                   	push   ss
    3a0e:	57                   	push   di
    3a0f:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    3a12:	06                   	push   es
    3a13:	57                   	push   di
    3a14:	9a cd 17 22 3a       	call   0x3a22:0x17cd
    3a19:	8d be 00 ff          	lea    di,[bp-0x100]
    3a1d:	16                   	push   ss
    3a1e:	57                   	push   di
    3a1f:	9a 4c 18 2f 3a       	call   0x3a2f:0x184c
    3a24:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    3a27:	06                   	push   es
    3a28:	57                   	push   di
    3a29:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3a2c:	9a e7 17 43 3a       	call   0x3a43:0x17e7
    3a31:	c9                   	leave
    3a32:	ca 0e 00             	retf   0xe
    3a35:	01 09                	add    WORD PTR [bx+di],cx
    3a37:	00 01                	add    BYTE PTR [bx+di],al
    3a39:	20 55 89             	and    BYTE PTR [di-0x77],dl
    3a3c:	e5 b8                	in     ax,0xb8
    3a3e:	04 03                	add    al,0x3
    3a40:	9a 44 04 92 3a       	call   0x3a92:0x444
    3a45:	81 ec 04 03          	sub    sp,0x304
    3a49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a4c:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    3a51:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    3a55:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    3a59:	06                   	push   es
    3a5a:	57                   	push   di
    3a5b:	9a e3 49 ff ff       	call   0xffff:0x49e3
    3a60:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3a65:	8d be 00 ff          	lea    di,[bp-0x100]
    3a69:	16                   	push   ss
    3a6a:	57                   	push   di
    3a6b:	68 ff 00             	push   0xff
    3a6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a71:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    3a76:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    3a7b:	6a 00                	push   0x0
    3a7d:	55                   	push   bp
    3a7e:	9a 3d 37 1c 3b       	call   0x3b1c:0x373d
    3a83:	8d be fc fd          	lea    di,[bp-0x204]
    3a87:	16                   	push   ss
    3a88:	57                   	push   di
    3a89:	8d be 00 ff          	lea    di,[bp-0x100]
    3a8d:	16                   	push   ss
    3a8e:	57                   	push   di
    3a8f:	9a cd 17 9c 3a       	call   0x3a9c:0x17cd
    3a94:	bf 35 3a             	mov    di,0x3a35
    3a97:	0e                   	push   cs
    3a98:	57                   	push   di
    3a99:	9a 4c 18 b6 3a       	call   0x3ab6:0x184c
    3a9e:	8d be fc fc          	lea    di,[bp-0x304]
    3aa2:	16                   	push   ss
    3aa3:	57                   	push   di
    3aa4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aa7:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3aac:	06                   	push   es
    3aad:	57                   	push   di
    3aae:	9a 53 1d 4c 3b       	call   0x3b4c:0x1d53
    3ab3:	9a 4c 18 c4 3a       	call   0x3ac4:0x184c
    3ab8:	8d be 00 ff          	lea    di,[bp-0x100]
    3abc:	16                   	push   ss
    3abd:	57                   	push   di
    3abe:	68 ff 00             	push   0xff
    3ac1:	9a e7 17 2d 3b       	call   0x3b2d:0x17e7
    3ac6:	8d be 00 ff          	lea    di,[bp-0x100]
    3aca:	16                   	push   ss
    3acb:	57                   	push   di
    3acc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3ad0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3ad5:	06                   	push   es
    3ad6:	57                   	push   di
    3ad7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ada:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3ade:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    3ae2:	75 17                	jne    0x3afb
    3ae4:	bf 37 3a             	mov    di,0x3a37
    3ae7:	0e                   	push   cs
    3ae8:	57                   	push   di
    3ae9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3aed:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3af2:	06                   	push   es
    3af3:	57                   	push   di
    3af4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3af7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3afb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3b00:	8d be 00 ff          	lea    di,[bp-0x100]
    3b04:	16                   	push   ss
    3b05:	57                   	push   di
    3b06:	68 ff 00             	push   0xff
    3b09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b0c:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    3b11:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    3b16:	6a 0a                	push   0xa
    3b18:	55                   	push   bp
    3b19:	9a 3d 37 7d 3b       	call   0x3b7d:0x373d
    3b1e:	8d be fc fd          	lea    di,[bp-0x204]
    3b22:	16                   	push   ss
    3b23:	57                   	push   di
    3b24:	8d be 00 ff          	lea    di,[bp-0x100]
    3b28:	16                   	push   ss
    3b29:	57                   	push   di
    3b2a:	9a cd 17 37 3b       	call   0x3b37:0x17cd
    3b2f:	bf 38 3a             	mov    di,0x3a38
    3b32:	0e                   	push   cs
    3b33:	57                   	push   di
    3b34:	9a 4c 18 51 3b       	call   0x3b51:0x184c
    3b39:	8d be fc fc          	lea    di,[bp-0x304]
    3b3d:	16                   	push   ss
    3b3e:	57                   	push   di
    3b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b42:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3b47:	06                   	push   es
    3b48:	57                   	push   di
    3b49:	9a 53 1d cb 3b       	call   0x3bcb:0x1d53
    3b4e:	9a 4c 18 5f 3b       	call   0x3b5f:0x184c
    3b53:	8d be 00 ff          	lea    di,[bp-0x100]
    3b57:	16                   	push   ss
    3b58:	57                   	push   di
    3b59:	68 ff 00             	push   0xff
    3b5c:	9a e7 17 ac 3b       	call   0x3bac:0x17e7
    3b61:	8d be 00 ff          	lea    di,[bp-0x100]
    3b65:	16                   	push   ss
    3b66:	57                   	push   di
    3b67:	68 ff 00             	push   0xff
    3b6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b6d:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    3b72:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    3b77:	6a 25                	push   0x25
    3b79:	55                   	push   bp
    3b7a:	9a 3d 37 9b 3b       	call   0x3b9b:0x373d
    3b7f:	8d be 00 ff          	lea    di,[bp-0x100]
    3b83:	16                   	push   ss
    3b84:	57                   	push   di
    3b85:	68 ff 00             	push   0xff
    3b88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b8b:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    3b90:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    3b95:	6a 46                	push   0x46
    3b97:	55                   	push   bp
    3b98:	9a 3d 37 38 3c       	call   0x3c38:0x373d
    3b9d:	8d be fc fd          	lea    di,[bp-0x204]
    3ba1:	16                   	push   ss
    3ba2:	57                   	push   di
    3ba3:	8d be 00 ff          	lea    di,[bp-0x100]
    3ba7:	16                   	push   ss
    3ba8:	57                   	push   di
    3ba9:	9a cd 17 b6 3b       	call   0x3bb6:0x17cd
    3bae:	bf 38 3a             	mov    di,0x3a38
    3bb1:	0e                   	push   cs
    3bb2:	57                   	push   di
    3bb3:	9a 4c 18 d0 3b       	call   0x3bd0:0x184c
    3bb8:	8d be fc fc          	lea    di,[bp-0x304]
    3bbc:	16                   	push   ss
    3bbd:	57                   	push   di
    3bbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bc1:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    3bc6:	06                   	push   es
    3bc7:	57                   	push   di
    3bc8:	9a 53 1d ff ff       	call   0xffff:0x1d53
    3bcd:	9a 4c 18 de 3b       	call   0x3bde:0x184c
    3bd2:	8d be 00 ff          	lea    di,[bp-0x100]
    3bd6:	16                   	push   ss
    3bd7:	57                   	push   di
    3bd8:	68 ff 00             	push   0xff
    3bdb:	9a e7 17 7b 3d       	call   0x3d7b:0x17e7
    3be0:	8d be 00 ff          	lea    di,[bp-0x100]
    3be4:	16                   	push   ss
    3be5:	57                   	push   di
    3be6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3bea:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3bef:	06                   	push   es
    3bf0:	57                   	push   di
    3bf1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bf4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3bf8:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    3bfc:	75 17                	jne    0x3c15
    3bfe:	bf 37 3a             	mov    di,0x3a37
    3c01:	0e                   	push   cs
    3c02:	57                   	push   di
    3c03:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3c07:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3c0c:	06                   	push   es
    3c0d:	57                   	push   di
    3c0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c11:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3c15:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3c1a:	8d be 00 ff          	lea    di,[bp-0x100]
    3c1e:	16                   	push   ss
    3c1f:	57                   	push   di
    3c20:	68 ff 00             	push   0xff
    3c23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c26:	26 ff b5 c6 02       	push   WORD PTR es:[di+0x2c6]
    3c2b:	26 ff b5 c4 02       	push   WORD PTR es:[di+0x2c4]
    3c30:	ff 36 18 02          	push   WORD PTR ds:0x218
    3c34:	55                   	push   bp
    3c35:	9a 3d 37 7c 3c       	call   0x3c7c:0x373d
    3c3a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3c3f:	76 18                	jbe    0x3c59
    3c41:	8d be 00 ff          	lea    di,[bp-0x100]
    3c45:	16                   	push   ss
    3c46:	57                   	push   di
    3c47:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3c4b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3c50:	06                   	push   es
    3c51:	57                   	push   di
    3c52:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c55:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3c59:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3c5e:	8d be 00 ff          	lea    di,[bp-0x100]
    3c62:	16                   	push   ss
    3c63:	57                   	push   di
    3c64:	68 ff 00             	push   0xff
    3c67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c6a:	26 ff b5 ce 02       	push   WORD PTR es:[di+0x2ce]
    3c6f:	26 ff b5 cc 02       	push   WORD PTR es:[di+0x2cc]
    3c74:	ff 36 1a 02          	push   WORD PTR ds:0x21a
    3c78:	55                   	push   bp
    3c79:	9a 3d 37 c0 3c       	call   0x3cc0:0x373d
    3c7e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3c83:	76 18                	jbe    0x3c9d
    3c85:	8d be 00 ff          	lea    di,[bp-0x100]
    3c89:	16                   	push   ss
    3c8a:	57                   	push   di
    3c8b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3c8f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3c94:	06                   	push   es
    3c95:	57                   	push   di
    3c96:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c99:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3c9d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3ca2:	8d be 00 ff          	lea    di,[bp-0x100]
    3ca6:	16                   	push   ss
    3ca7:	57                   	push   di
    3ca8:	68 ff 00             	push   0xff
    3cab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cae:	26 ff b5 d6 02       	push   WORD PTR es:[di+0x2d6]
    3cb3:	26 ff b5 d4 02       	push   WORD PTR es:[di+0x2d4]
    3cb8:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    3cbc:	55                   	push   bp
    3cbd:	9a 3d 37 e0 3c       	call   0x3ce0:0x373d
    3cc2:	8d be 00 ff          	lea    di,[bp-0x100]
    3cc6:	16                   	push   ss
    3cc7:	57                   	push   di
    3cc8:	68 ff 00             	push   0xff
    3ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cce:	26 ff b5 de 02       	push   WORD PTR es:[di+0x2de]
    3cd3:	26 ff b5 dc 02       	push   WORD PTR es:[di+0x2dc]
    3cd8:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    3cdc:	55                   	push   bp
    3cdd:	9a 3d 37 24 3d       	call   0x3d24:0x373d
    3ce2:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3ce7:	76 18                	jbe    0x3d01
    3ce9:	8d be 00 ff          	lea    di,[bp-0x100]
    3ced:	16                   	push   ss
    3cee:	57                   	push   di
    3cef:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3cf3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3cf8:	06                   	push   es
    3cf9:	57                   	push   di
    3cfa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cfd:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3d01:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3d06:	8d be 00 ff          	lea    di,[bp-0x100]
    3d0a:	16                   	push   ss
    3d0b:	57                   	push   di
    3d0c:	68 ff 00             	push   0xff
    3d0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d12:	26 ff b5 da 02       	push   WORD PTR es:[di+0x2da]
    3d17:	26 ff b5 d8 02       	push   WORD PTR es:[di+0x2d8]
    3d1c:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    3d20:	55                   	push   bp
    3d21:	9a 3d 37 44 3d       	call   0x3d44:0x373d
    3d26:	8d be 00 ff          	lea    di,[bp-0x100]
    3d2a:	16                   	push   ss
    3d2b:	57                   	push   di
    3d2c:	68 ff 00             	push   0xff
    3d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d32:	26 ff b5 e2 02       	push   WORD PTR es:[di+0x2e2]
    3d37:	26 ff b5 e0 02       	push   WORD PTR es:[di+0x2e0]
    3d3c:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    3d40:	55                   	push   bp
    3d41:	9a 3d 37 9b 3d       	call   0x3d9b:0x373d
    3d46:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3d4b:	76 18                	jbe    0x3d65
    3d4d:	8d be 00 ff          	lea    di,[bp-0x100]
    3d51:	16                   	push   ss
    3d52:	57                   	push   di
    3d53:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3d57:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3d5c:	06                   	push   es
    3d5d:	57                   	push   di
    3d5e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d61:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3d65:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3d6a:	bf 35 3a             	mov    di,0x3a35
    3d6d:	0e                   	push   cs
    3d6e:	57                   	push   di
    3d6f:	8d be 00 ff          	lea    di,[bp-0x100]
    3d73:	16                   	push   ss
    3d74:	57                   	push   di
    3d75:	68 ff 00             	push   0xff
    3d78:	9a e7 17 42 3f       	call   0x3f42:0x17e7
    3d7d:	8d be 00 ff          	lea    di,[bp-0x100]
    3d81:	16                   	push   ss
    3d82:	57                   	push   di
    3d83:	68 ff 00             	push   0xff
    3d86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d89:	26 ff b5 e6 02       	push   WORD PTR es:[di+0x2e6]
    3d8e:	26 ff b5 e4 02       	push   WORD PTR es:[di+0x2e4]
    3d93:	ff 36 20 02          	push   WORD PTR ds:0x220
    3d97:	55                   	push   bp
    3d98:	9a 3d 37 df 3d       	call   0x3ddf:0x373d
    3d9d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3da2:	76 18                	jbe    0x3dbc
    3da4:	8d be 00 ff          	lea    di,[bp-0x100]
    3da8:	16                   	push   ss
    3da9:	57                   	push   di
    3daa:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3dae:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3db3:	06                   	push   es
    3db4:	57                   	push   di
    3db5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3db8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3dbc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3dc1:	8d be 00 ff          	lea    di,[bp-0x100]
    3dc5:	16                   	push   ss
    3dc6:	57                   	push   di
    3dc7:	68 ff 00             	push   0xff
    3dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dcd:	26 ff b5 ea 02       	push   WORD PTR es:[di+0x2ea]
    3dd2:	26 ff b5 e8 02       	push   WORD PTR es:[di+0x2e8]
    3dd7:	ff 36 1a 02          	push   WORD PTR ds:0x21a
    3ddb:	55                   	push   bp
    3ddc:	9a 3d 37 23 3e       	call   0x3e23:0x373d
    3de1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3de6:	76 18                	jbe    0x3e00
    3de8:	8d be 00 ff          	lea    di,[bp-0x100]
    3dec:	16                   	push   ss
    3ded:	57                   	push   di
    3dee:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3df2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3df7:	06                   	push   es
    3df8:	57                   	push   di
    3df9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3dfc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3e00:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3e05:	8d be 00 ff          	lea    di,[bp-0x100]
    3e09:	16                   	push   ss
    3e0a:	57                   	push   di
    3e0b:	68 ff 00             	push   0xff
    3e0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e11:	26 ff b5 f2 02       	push   WORD PTR es:[di+0x2f2]
    3e16:	26 ff b5 f0 02       	push   WORD PTR es:[di+0x2f0]
    3e1b:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    3e1f:	55                   	push   bp
    3e20:	9a 3d 37 43 3e       	call   0x3e43:0x373d
    3e25:	8d be 00 ff          	lea    di,[bp-0x100]
    3e29:	16                   	push   ss
    3e2a:	57                   	push   di
    3e2b:	68 ff 00             	push   0xff
    3e2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e31:	26 ff b5 fe 02       	push   WORD PTR es:[di+0x2fe]
    3e36:	26 ff b5 fc 02       	push   WORD PTR es:[di+0x2fc]
    3e3b:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    3e3f:	55                   	push   bp
    3e40:	9a 3d 37 87 3e       	call   0x3e87:0x373d
    3e45:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3e4a:	76 18                	jbe    0x3e64
    3e4c:	8d be 00 ff          	lea    di,[bp-0x100]
    3e50:	16                   	push   ss
    3e51:	57                   	push   di
    3e52:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3e56:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3e5b:	06                   	push   es
    3e5c:	57                   	push   di
    3e5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e60:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3e64:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3e69:	8d be 00 ff          	lea    di,[bp-0x100]
    3e6d:	16                   	push   ss
    3e6e:	57                   	push   di
    3e6f:	68 ff 00             	push   0xff
    3e72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e75:	26 ff b5 f6 02       	push   WORD PTR es:[di+0x2f6]
    3e7a:	26 ff b5 f4 02       	push   WORD PTR es:[di+0x2f4]
    3e7f:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    3e83:	55                   	push   bp
    3e84:	9a 3d 37 a7 3e       	call   0x3ea7:0x373d
    3e89:	8d be 00 ff          	lea    di,[bp-0x100]
    3e8d:	16                   	push   ss
    3e8e:	57                   	push   di
    3e8f:	68 ff 00             	push   0xff
    3e92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e95:	26 ff b5 02 03       	push   WORD PTR es:[di+0x302]
    3e9a:	26 ff b5 00 03       	push   WORD PTR es:[di+0x300]
    3e9f:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    3ea3:	55                   	push   bp
    3ea4:	9a 3d 37 eb 3e       	call   0x3eeb:0x373d
    3ea9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3eae:	76 18                	jbe    0x3ec8
    3eb0:	8d be 00 ff          	lea    di,[bp-0x100]
    3eb4:	16                   	push   ss
    3eb5:	57                   	push   di
    3eb6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3eba:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3ebf:	06                   	push   es
    3ec0:	57                   	push   di
    3ec1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ec4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3ec8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3ecd:	8d be 00 ff          	lea    di,[bp-0x100]
    3ed1:	16                   	push   ss
    3ed2:	57                   	push   di
    3ed3:	68 ff 00             	push   0xff
    3ed6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed9:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    3ede:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    3ee3:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    3ee7:	55                   	push   bp
    3ee8:	9a 3d 37 0b 3f       	call   0x3f0b:0x373d
    3eed:	8d be 00 ff          	lea    di,[bp-0x100]
    3ef1:	16                   	push   ss
    3ef2:	57                   	push   di
    3ef3:	68 ff 00             	push   0xff
    3ef6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef9:	26 ff b5 06 03       	push   WORD PTR es:[di+0x306]
    3efe:	26 ff b5 04 03       	push   WORD PTR es:[di+0x304]
    3f03:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    3f07:	55                   	push   bp
    3f08:	9a 3d 37 62 3f       	call   0x3f62:0x373d
    3f0d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3f12:	76 18                	jbe    0x3f2c
    3f14:	8d be 00 ff          	lea    di,[bp-0x100]
    3f18:	16                   	push   ss
    3f19:	57                   	push   di
    3f1a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3f1e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3f23:	06                   	push   es
    3f24:	57                   	push   di
    3f25:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f28:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3f2c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3f31:	bf 35 3a             	mov    di,0x3a35
    3f34:	0e                   	push   cs
    3f35:	57                   	push   di
    3f36:	8d be 00 ff          	lea    di,[bp-0x100]
    3f3a:	16                   	push   ss
    3f3b:	57                   	push   di
    3f3c:	68 ff 00             	push   0xff
    3f3f:	9a e7 17 b7 3f       	call   0x3fb7:0x17e7
    3f44:	8d be 00 ff          	lea    di,[bp-0x100]
    3f48:	16                   	push   ss
    3f49:	57                   	push   di
    3f4a:	68 ff 00             	push   0xff
    3f4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f50:	26 ff b5 0a 03       	push   WORD PTR es:[di+0x30a]
    3f55:	26 ff b5 08 03       	push   WORD PTR es:[di+0x308]
    3f5a:	ff 36 20 02          	push   WORD PTR ds:0x220
    3f5e:	55                   	push   bp
    3f5f:	9a 3d 37 a6 3f       	call   0x3fa6:0x373d
    3f64:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3f69:	76 18                	jbe    0x3f83
    3f6b:	8d be 00 ff          	lea    di,[bp-0x100]
    3f6f:	16                   	push   ss
    3f70:	57                   	push   di
    3f71:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    3f75:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3f7a:	06                   	push   es
    3f7b:	57                   	push   di
    3f7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f7f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3f83:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3f88:	8d be 00 ff          	lea    di,[bp-0x100]
    3f8c:	16                   	push   ss
    3f8d:	57                   	push   di
    3f8e:	68 ff 00             	push   0xff
    3f91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f94:	26 ff b5 0e 03       	push   WORD PTR es:[di+0x30e]
    3f99:	26 ff b5 0c 03       	push   WORD PTR es:[di+0x30c]
    3f9e:	ff 36 18 02          	push   WORD PTR ds:0x218
    3fa2:	55                   	push   bp
    3fa3:	9a 3d 37 ef 3f       	call   0x3fef:0x373d
    3fa8:	8d be fc fd          	lea    di,[bp-0x204]
    3fac:	16                   	push   ss
    3fad:	57                   	push   di
    3fae:	8d be 00 ff          	lea    di,[bp-0x100]
    3fb2:	16                   	push   ss
    3fb3:	57                   	push   di
    3fb4:	9a cd 17 c1 3f       	call   0x3fc1:0x17cd
    3fb9:	bf 35 3a             	mov    di,0x3a35
    3fbc:	0e                   	push   cs
    3fbd:	57                   	push   di
    3fbe:	9a 4c 18 cf 3f       	call   0x3fcf:0x184c
    3fc3:	8d be 00 ff          	lea    di,[bp-0x100]
    3fc7:	16                   	push   ss
    3fc8:	57                   	push   di
    3fc9:	68 ff 00             	push   0xff
    3fcc:	9a e7 17 f7 41       	call   0x41f7:0x17e7
    3fd1:	8d be 00 ff          	lea    di,[bp-0x100]
    3fd5:	16                   	push   ss
    3fd6:	57                   	push   di
    3fd7:	68 ff 00             	push   0xff
    3fda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fdd:	26 ff b5 12 03       	push   WORD PTR es:[di+0x312]
    3fe2:	26 ff b5 10 03       	push   WORD PTR es:[di+0x310]
    3fe7:	ff 36 20 02          	push   WORD PTR ds:0x220
    3feb:	55                   	push   bp
    3fec:	9a 3d 37 50 40       	call   0x4050:0x373d
    3ff1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3ff6:	76 18                	jbe    0x4010
    3ff8:	8d be 00 ff          	lea    di,[bp-0x100]
    3ffc:	16                   	push   ss
    3ffd:	57                   	push   di
    3ffe:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4002:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4007:	06                   	push   es
    4008:	57                   	push   di
    4009:	26 c4 3d             	les    di,DWORD PTR es:[di]
    400c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4010:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    4014:	75 17                	jne    0x402d
    4016:	bf 37 3a             	mov    di,0x3a37
    4019:	0e                   	push   cs
    401a:	57                   	push   di
    401b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    401f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4024:	06                   	push   es
    4025:	57                   	push   di
    4026:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4029:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    402d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4032:	8d be 00 ff          	lea    di,[bp-0x100]
    4036:	16                   	push   ss
    4037:	57                   	push   di
    4038:	68 ff 00             	push   0xff
    403b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    403e:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
    4043:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    4048:	ff 36 18 02          	push   WORD PTR ds:0x218
    404c:	55                   	push   bp
    404d:	9a 3d 37 94 40       	call   0x4094:0x373d
    4052:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4057:	76 18                	jbe    0x4071
    4059:	8d be 00 ff          	lea    di,[bp-0x100]
    405d:	16                   	push   ss
    405e:	57                   	push   di
    405f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4063:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4068:	06                   	push   es
    4069:	57                   	push   di
    406a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    406d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4071:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4076:	8d be 00 ff          	lea    di,[bp-0x100]
    407a:	16                   	push   ss
    407b:	57                   	push   di
    407c:	68 ff 00             	push   0xff
    407f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4082:	26 ff b5 22 03       	push   WORD PTR es:[di+0x322]
    4087:	26 ff b5 20 03       	push   WORD PTR es:[di+0x320]
    408c:	ff 36 1a 02          	push   WORD PTR ds:0x21a
    4090:	55                   	push   bp
    4091:	9a 3d 37 d8 40       	call   0x40d8:0x373d
    4096:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    409b:	76 18                	jbe    0x40b5
    409d:	8d be 00 ff          	lea    di,[bp-0x100]
    40a1:	16                   	push   ss
    40a2:	57                   	push   di
    40a3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    40a7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    40ac:	06                   	push   es
    40ad:	57                   	push   di
    40ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40b1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    40b5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    40ba:	8d be 00 ff          	lea    di,[bp-0x100]
    40be:	16                   	push   ss
    40bf:	57                   	push   di
    40c0:	68 ff 00             	push   0xff
    40c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40c6:	26 ff b5 2a 03       	push   WORD PTR es:[di+0x32a]
    40cb:	26 ff b5 28 03       	push   WORD PTR es:[di+0x328]
    40d0:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    40d4:	55                   	push   bp
    40d5:	9a 3d 37 f8 40       	call   0x40f8:0x373d
    40da:	8d be 00 ff          	lea    di,[bp-0x100]
    40de:	16                   	push   ss
    40df:	57                   	push   di
    40e0:	68 ff 00             	push   0xff
    40e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e6:	26 ff b5 32 03       	push   WORD PTR es:[di+0x332]
    40eb:	26 ff b5 30 03       	push   WORD PTR es:[di+0x330]
    40f0:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    40f4:	55                   	push   bp
    40f5:	9a 3d 37 3c 41       	call   0x413c:0x373d
    40fa:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    40ff:	76 18                	jbe    0x4119
    4101:	8d be 00 ff          	lea    di,[bp-0x100]
    4105:	16                   	push   ss
    4106:	57                   	push   di
    4107:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    410b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4110:	06                   	push   es
    4111:	57                   	push   di
    4112:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4115:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4119:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    411e:	8d be 00 ff          	lea    di,[bp-0x100]
    4122:	16                   	push   ss
    4123:	57                   	push   di
    4124:	68 ff 00             	push   0xff
    4127:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    412a:	26 ff b5 2e 03       	push   WORD PTR es:[di+0x32e]
    412f:	26 ff b5 2c 03       	push   WORD PTR es:[di+0x32c]
    4134:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    4138:	55                   	push   bp
    4139:	9a 3d 37 5c 41       	call   0x415c:0x373d
    413e:	8d be 00 ff          	lea    di,[bp-0x100]
    4142:	16                   	push   ss
    4143:	57                   	push   di
    4144:	68 ff 00             	push   0xff
    4147:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    414a:	26 ff b5 36 03       	push   WORD PTR es:[di+0x336]
    414f:	26 ff b5 34 03       	push   WORD PTR es:[di+0x334]
    4154:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    4158:	55                   	push   bp
    4159:	9a 3d 37 a0 41       	call   0x41a0:0x373d
    415e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4163:	76 18                	jbe    0x417d
    4165:	8d be 00 ff          	lea    di,[bp-0x100]
    4169:	16                   	push   ss
    416a:	57                   	push   di
    416b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    416f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4174:	06                   	push   es
    4175:	57                   	push   di
    4176:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4179:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    417d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4182:	8d be 00 ff          	lea    di,[bp-0x100]
    4186:	16                   	push   ss
    4187:	57                   	push   di
    4188:	68 ff 00             	push   0xff
    418b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    418e:	26 ff b5 42 03       	push   WORD PTR es:[di+0x342]
    4193:	26 ff b5 40 03       	push   WORD PTR es:[di+0x340]
    4198:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    419c:	55                   	push   bp
    419d:	9a 3d 37 c0 41       	call   0x41c0:0x373d
    41a2:	8d be 00 ff          	lea    di,[bp-0x100]
    41a6:	16                   	push   ss
    41a7:	57                   	push   di
    41a8:	68 ff 00             	push   0xff
    41ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41ae:	26 ff b5 3a 03       	push   WORD PTR es:[di+0x33a]
    41b3:	26 ff b5 38 03       	push   WORD PTR es:[di+0x338]
    41b8:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    41bc:	55                   	push   bp
    41bd:	9a 3d 37 17 42       	call   0x4217:0x373d
    41c2:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    41c7:	76 18                	jbe    0x41e1
    41c9:	8d be 00 ff          	lea    di,[bp-0x100]
    41cd:	16                   	push   ss
    41ce:	57                   	push   di
    41cf:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    41d3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    41d8:	06                   	push   es
    41d9:	57                   	push   di
    41da:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41dd:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    41e1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    41e6:	bf 35 3a             	mov    di,0x3a35
    41e9:	0e                   	push   cs
    41ea:	57                   	push   di
    41eb:	8d be 00 ff          	lea    di,[bp-0x100]
    41ef:	16                   	push   ss
    41f0:	57                   	push   di
    41f1:	68 ff 00             	push   0xff
    41f4:	9a e7 17 22 44       	call   0x4422:0x17e7
    41f9:	8d be 00 ff          	lea    di,[bp-0x100]
    41fd:	16                   	push   ss
    41fe:	57                   	push   di
    41ff:	68 ff 00             	push   0xff
    4202:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4205:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    420a:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    420f:	ff 36 20 02          	push   WORD PTR ds:0x220
    4213:	55                   	push   bp
    4214:	9a 3d 37 5b 42       	call   0x425b:0x373d
    4219:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    421e:	76 18                	jbe    0x4238
    4220:	8d be 00 ff          	lea    di,[bp-0x100]
    4224:	16                   	push   ss
    4225:	57                   	push   di
    4226:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    422a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    422f:	06                   	push   es
    4230:	57                   	push   di
    4231:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4234:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4238:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    423d:	8d be 00 ff          	lea    di,[bp-0x100]
    4241:	16                   	push   ss
    4242:	57                   	push   di
    4243:	68 ff 00             	push   0xff
    4246:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4249:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    424e:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    4253:	ff 36 1a 02          	push   WORD PTR ds:0x21a
    4257:	55                   	push   bp
    4258:	9a 3d 37 9f 42       	call   0x429f:0x373d
    425d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4262:	76 18                	jbe    0x427c
    4264:	8d be 00 ff          	lea    di,[bp-0x100]
    4268:	16                   	push   ss
    4269:	57                   	push   di
    426a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    426e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4273:	06                   	push   es
    4274:	57                   	push   di
    4275:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4278:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    427c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4281:	8d be 00 ff          	lea    di,[bp-0x100]
    4285:	16                   	push   ss
    4286:	57                   	push   di
    4287:	68 ff 00             	push   0xff
    428a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    428d:	26 ff b5 4e 03       	push   WORD PTR es:[di+0x34e]
    4292:	26 ff b5 4c 03       	push   WORD PTR es:[di+0x34c]
    4297:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    429b:	55                   	push   bp
    429c:	9a 3d 37 bf 42       	call   0x42bf:0x373d
    42a1:	8d be 00 ff          	lea    di,[bp-0x100]
    42a5:	16                   	push   ss
    42a6:	57                   	push   di
    42a7:	68 ff 00             	push   0xff
    42aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42ad:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    42b2:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    42b7:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    42bb:	55                   	push   bp
    42bc:	9a 3d 37 03 43       	call   0x4303:0x373d
    42c1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    42c6:	76 18                	jbe    0x42e0
    42c8:	8d be 00 ff          	lea    di,[bp-0x100]
    42cc:	16                   	push   ss
    42cd:	57                   	push   di
    42ce:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    42d2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    42d7:	06                   	push   es
    42d8:	57                   	push   di
    42d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42dc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    42e0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    42e5:	8d be 00 ff          	lea    di,[bp-0x100]
    42e9:	16                   	push   ss
    42ea:	57                   	push   di
    42eb:	68 ff 00             	push   0xff
    42ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42f1:	26 ff b5 5a 03       	push   WORD PTR es:[di+0x35a]
    42f6:	26 ff b5 58 03       	push   WORD PTR es:[di+0x358]
    42fb:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    42ff:	55                   	push   bp
    4300:	9a 3d 37 23 43       	call   0x4323:0x373d
    4305:	8d be 00 ff          	lea    di,[bp-0x100]
    4309:	16                   	push   ss
    430a:	57                   	push   di
    430b:	68 ff 00             	push   0xff
    430e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4311:	26 ff b5 6a 03       	push   WORD PTR es:[di+0x36a]
    4316:	26 ff b5 68 03       	push   WORD PTR es:[di+0x368]
    431b:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    431f:	55                   	push   bp
    4320:	9a 3d 37 67 43       	call   0x4367:0x373d
    4325:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    432a:	76 18                	jbe    0x4344
    432c:	8d be 00 ff          	lea    di,[bp-0x100]
    4330:	16                   	push   ss
    4331:	57                   	push   di
    4332:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4336:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    433b:	06                   	push   es
    433c:	57                   	push   di
    433d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4340:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4344:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4349:	8d be 00 ff          	lea    di,[bp-0x100]
    434d:	16                   	push   ss
    434e:	57                   	push   di
    434f:	68 ff 00             	push   0xff
    4352:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4355:	26 ff b5 52 03       	push   WORD PTR es:[di+0x352]
    435a:	26 ff b5 50 03       	push   WORD PTR es:[di+0x350]
    435f:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    4363:	55                   	push   bp
    4364:	9a 3d 37 87 43       	call   0x4387:0x373d
    4369:	8d be 00 ff          	lea    di,[bp-0x100]
    436d:	16                   	push   ss
    436e:	57                   	push   di
    436f:	68 ff 00             	push   0xff
    4372:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4375:	26 ff b5 62 03       	push   WORD PTR es:[di+0x362]
    437a:	26 ff b5 60 03       	push   WORD PTR es:[di+0x360]
    437f:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    4383:	55                   	push   bp
    4384:	9a 3d 37 cb 43       	call   0x43cb:0x373d
    4389:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    438e:	76 18                	jbe    0x43a8
    4390:	8d be 00 ff          	lea    di,[bp-0x100]
    4394:	16                   	push   ss
    4395:	57                   	push   di
    4396:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    439a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    439f:	06                   	push   es
    43a0:	57                   	push   di
    43a1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43a4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    43a8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    43ad:	8d be 00 ff          	lea    di,[bp-0x100]
    43b1:	16                   	push   ss
    43b2:	57                   	push   di
    43b3:	68 ff 00             	push   0xff
    43b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43b9:	26 ff b5 56 03       	push   WORD PTR es:[di+0x356]
    43be:	26 ff b5 54 03       	push   WORD PTR es:[di+0x354]
    43c3:	ff 36 1c 02          	push   WORD PTR ds:0x21c
    43c7:	55                   	push   bp
    43c8:	9a 3d 37 eb 43       	call   0x43eb:0x373d
    43cd:	8d be 00 ff          	lea    di,[bp-0x100]
    43d1:	16                   	push   ss
    43d2:	57                   	push   di
    43d3:	68 ff 00             	push   0xff
    43d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43d9:	26 ff b5 66 03       	push   WORD PTR es:[di+0x366]
    43de:	26 ff b5 64 03       	push   WORD PTR es:[di+0x364]
    43e3:	ff 36 1e 02          	push   WORD PTR ds:0x21e
    43e7:	55                   	push   bp
    43e8:	9a 3d 37 42 44       	call   0x4442:0x373d
    43ed:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    43f2:	76 18                	jbe    0x440c
    43f4:	8d be 00 ff          	lea    di,[bp-0x100]
    43f8:	16                   	push   ss
    43f9:	57                   	push   di
    43fa:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    43fe:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4403:	06                   	push   es
    4404:	57                   	push   di
    4405:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4408:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    440c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4411:	bf 35 3a             	mov    di,0x3a35
    4414:	0e                   	push   cs
    4415:	57                   	push   di
    4416:	8d be 00 ff          	lea    di,[bp-0x100]
    441a:	16                   	push   ss
    441b:	57                   	push   di
    441c:	68 ff 00             	push   0xff
    441f:	9a e7 17 97 44       	call   0x4497:0x17e7
    4424:	8d be 00 ff          	lea    di,[bp-0x100]
    4428:	16                   	push   ss
    4429:	57                   	push   di
    442a:	68 ff 00             	push   0xff
    442d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4430:	26 ff b5 6e 03       	push   WORD PTR es:[di+0x36e]
    4435:	26 ff b5 6c 03       	push   WORD PTR es:[di+0x36c]
    443a:	ff 36 20 02          	push   WORD PTR ds:0x220
    443e:	55                   	push   bp
    443f:	9a 3d 37 86 44       	call   0x4486:0x373d
    4444:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4449:	76 18                	jbe    0x4463
    444b:	8d be 00 ff          	lea    di,[bp-0x100]
    444f:	16                   	push   ss
    4450:	57                   	push   di
    4451:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    4455:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    445a:	06                   	push   es
    445b:	57                   	push   di
    445c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    445f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4463:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4468:	8d be 00 ff          	lea    di,[bp-0x100]
    446c:	16                   	push   ss
    446d:	57                   	push   di
    446e:	68 ff 00             	push   0xff
    4471:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4474:	26 ff b5 72 03       	push   WORD PTR es:[di+0x372]
    4479:	26 ff b5 70 03       	push   WORD PTR es:[di+0x370]
    447e:	ff 36 18 02          	push   WORD PTR ds:0x218
    4482:	55                   	push   bp
    4483:	9a 3d 37 cf 44       	call   0x44cf:0x373d
    4488:	8d be fc fd          	lea    di,[bp-0x204]
    448c:	16                   	push   ss
    448d:	57                   	push   di
    448e:	8d be 00 ff          	lea    di,[bp-0x100]
    4492:	16                   	push   ss
    4493:	57                   	push   di
    4494:	9a cd 17 a1 44       	call   0x44a1:0x17cd
    4499:	bf 35 3a             	mov    di,0x3a35
    449c:	0e                   	push   cs
    449d:	57                   	push   di
    449e:	9a 4c 18 af 44       	call   0x44af:0x184c
    44a3:	8d be 00 ff          	lea    di,[bp-0x100]
    44a7:	16                   	push   ss
    44a8:	57                   	push   di
    44a9:	68 ff 00             	push   0xff
    44ac:	9a e7 17 fc 44       	call   0x44fc:0x17e7
    44b1:	8d be 00 ff          	lea    di,[bp-0x100]
    44b5:	16                   	push   ss
    44b6:	57                   	push   di
    44b7:	68 ff 00             	push   0xff
    44ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44bd:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    44c2:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    44c7:	ff 36 20 02          	push   WORD PTR ds:0x220
    44cb:	55                   	push   bp
    44cc:	9a 3d 37 ff ff       	call   0xffff:0x373d
    44d1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    44d6:	76 18                	jbe    0x44f0
    44d8:	8d be 00 ff          	lea    di,[bp-0x100]
    44dc:	16                   	push   ss
    44dd:	57                   	push   di
    44de:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    44e2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    44e7:	06                   	push   es
    44e8:	57                   	push   di
    44e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44ec:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    44f0:	c9                   	leave
    44f1:	ca 06 00             	retf   0x6
    44f4:	55                   	push   bp
    44f5:	89 e5                	mov    bp,sp
    44f7:	31 c0                	xor    ax,ax
    44f9:	9a 44 04 2a 45       	call   0x452a:0x444
    44fe:	c7 06 44 01 15 00    	mov    WORD PTR ds:0x144,0x15
    4504:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4507:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    450c:	a3 46 01             	mov    ds:0x146,ax
    450f:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    4514:	a3 48 01             	mov    ds:0x148,ax
    4517:	06                   	push   es
    4518:	57                   	push   di
    4519:	9a 56 55 4a 45       	call   0x454a:0x5556
    451e:	c9                   	leave
    451f:	ca 08 00             	retf   0x8
    4522:	55                   	push   bp
    4523:	89 e5                	mov    bp,sp
    4525:	31 c0                	xor    ax,ax
    4527:	9a 44 04 58 45       	call   0x4558:0x444
    452c:	c7 06 44 01 16 00    	mov    WORD PTR ds:0x144,0x16
    4532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4535:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    453a:	a3 46 01             	mov    ds:0x146,ax
    453d:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    4542:	a3 48 01             	mov    ds:0x148,ax
    4545:	06                   	push   es
    4546:	57                   	push   di
    4547:	9a 56 55 78 45       	call   0x4578:0x5556
    454c:	c9                   	leave
    454d:	ca 08 00             	retf   0x8
    4550:	55                   	push   bp
    4551:	89 e5                	mov    bp,sp
    4553:	31 c0                	xor    ax,ax
    4555:	9a 44 04 86 45       	call   0x4586:0x444
    455a:	c7 06 44 01 17 00    	mov    WORD PTR ds:0x144,0x17
    4560:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4563:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    4568:	a3 46 01             	mov    ds:0x146,ax
    456b:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    4570:	a3 48 01             	mov    ds:0x148,ax
    4573:	06                   	push   es
    4574:	57                   	push   di
    4575:	9a 56 55 a6 45       	call   0x45a6:0x5556
    457a:	c9                   	leave
    457b:	ca 08 00             	retf   0x8
    457e:	55                   	push   bp
    457f:	89 e5                	mov    bp,sp
    4581:	31 c0                	xor    ax,ax
    4583:	9a 44 04 b4 45       	call   0x45b4:0x444
    4588:	c7 06 44 01 18 00    	mov    WORD PTR ds:0x144,0x18
    458e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4591:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    4596:	a3 46 01             	mov    ds:0x146,ax
    4599:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    459e:	a3 48 01             	mov    ds:0x148,ax
    45a1:	06                   	push   es
    45a2:	57                   	push   di
    45a3:	9a 56 55 d4 45       	call   0x45d4:0x5556
    45a8:	c9                   	leave
    45a9:	ca 08 00             	retf   0x8
    45ac:	55                   	push   bp
    45ad:	89 e5                	mov    bp,sp
    45af:	31 c0                	xor    ax,ax
    45b1:	9a 44 04 e2 45       	call   0x45e2:0x444
    45b6:	c7 06 44 01 19 00    	mov    WORD PTR ds:0x144,0x19
    45bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45bf:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    45c4:	a3 46 01             	mov    ds:0x146,ax
    45c7:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    45cc:	a3 48 01             	mov    ds:0x148,ax
    45cf:	06                   	push   es
    45d0:	57                   	push   di
    45d1:	9a 56 55 02 46       	call   0x4602:0x5556
    45d6:	c9                   	leave
    45d7:	ca 08 00             	retf   0x8
    45da:	55                   	push   bp
    45db:	89 e5                	mov    bp,sp
    45dd:	31 c0                	xor    ax,ax
    45df:	9a 44 04 10 46       	call   0x4610:0x444
    45e4:	c7 06 44 01 1a 00    	mov    WORD PTR ds:0x144,0x1a
    45ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45ed:	26 8b 85 4c 04       	mov    ax,WORD PTR es:[di+0x44c]
    45f2:	a3 46 01             	mov    ds:0x146,ax
    45f5:	26 8b 85 4a 04       	mov    ax,WORD PTR es:[di+0x44a]
    45fa:	a3 48 01             	mov    ds:0x148,ax
    45fd:	06                   	push   es
    45fe:	57                   	push   di
    45ff:	9a 56 55 ff ff       	call   0xffff:0x5556
    4604:	c9                   	leave
    4605:	ca 08 00             	retf   0x8
    4608:	55                   	push   bp
    4609:	89 e5                	mov    bp,sp
    460b:	31 c0                	xor    ax,ax
    460d:	9a 44 04 ff ff       	call   0xffff:0x444
    4612:	ff 36 50 01          	push   WORD PTR ds:0x150
    4616:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4619:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    461e:	26 ff b5 4c 04       	push   WORD PTR es:[di+0x44c]
    4623:	9a a1 0c ff ff       	call   0xffff:0xca1
    4628:	c9                   	leave
    4629:	ca                   	.byte 0xca
    462a:	08                   	.byte 0x8
